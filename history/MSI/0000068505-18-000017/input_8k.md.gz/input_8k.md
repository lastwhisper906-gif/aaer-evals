# MSI 8-K — 0000068505-18-000015 filed 2018-05-03

## item codes, every 8-K on or before 2018-05-04

- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2018-05-04

- none on or before 2018-05-04

## item 2.02 — earnings release, exhibit 99.1

[0000068505-18-000015:8k_2_02:1]
EX-99.1
2
msiq12018pressrelease.htm
EXHIBIT 99.1

[0000068505-18-000015:8k_2_02:2]
Exhibit

[0000068505-18-000015:8k_2_02:3]
Exhibit 99.1

[0000068505-18-000015:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2018 Financial Results

[0000068505-18-000015:8k_2_02:5]
Company raises full-year revenue and earnings outlook

[0000068505-18-000015:8k_2_02:6]
| • | Sales of $1.5 billion, up 15 percent from a year ago |

[0000068505-18-000015:8k_2_02:7]
| • | Organic revenue1 growth of 10 percent; North America organic growth of 8 percent |

[0000068505-18-000015:8k_2_02:8]
| • | Backlog of $9.6 billion, up $1.1 billion or 13 percent from a year ago |

[0000068505-18-000015:8k_2_02:9]
| • | GAAP earnings per share (EPS) of $0.69, up 53 percent |

[0000068505-18-000015:8k_2_02:10]
| • | Non-GAAP EPS* of $1.10, up 55 percent |

[0000068505-18-000015:8k_2_02:11]
| • | Completed $500 million debt-funded U.S. pension contribution |

[0000068505-18-000015:8k_2_02:12]
| • | Completed acquisitions of Avigilon and Airbus DS Communications |

[0000068505-18-000015:8k_2_02:13]
CHICAGO – May 3, 2018 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2018. Click here for a printable news release and financial tables.

[0000068505-18-000015:8k_2_02:14]
“Q1 was outstanding,” said Greg Brown, chairman and CEO of Motorola Solutions. “Our record Q1 backlog position and acquisition of Avigilon provide a strong foundation for continued revenue and earnings growth.”

[0000068505-18-000015:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-18-000015:8k_2_02:16]
|  | Q1 2018 |  | Q1 2017 |  | % Change |
| Sales | $1,468 | $1,281 | 15 | % |
| GAAP |  |  |  |
| Operating Earnings | $171 | $173 | (1 | )% |
| % of Sales | 11.6 | % | 13.5 | % |  |
| EPS | $0.69 | $0.45 | 53 | % |
| Non-GAAP |  |  |  |
| Operating Earnings | $260 | $212 | 23 | % |
| % of Sales | 17.7 | % | 16.5 | % |  |
| EPS | $1.10 | $0.71 | 55 | % |
| Product Segment |  |  |  |
| Sales | $801 | $703 | 14 | % |
| GAAP Operating Earnings | $89 | $88 | 1 | % |
| % of Sales | 11.1 | % | 12.5 | % |  |
| Non-GAAP Operating Earnings | $127 | $94 | 35 | % |
| % of Sales | 15.9 | % | 13.4 | % |  |
| Services Segment |  |  |  |
| Sales | $667 | $578 | 15 | % |
| GAAP Operating Earnings | $82 | $85 | (4 | )% |
| % of Sales | 12.3 | % | 14.7 | % |  |
| Non-GAAP Operating Earnings | $133 | $118 | 13 | % |
| % of Sales | 19.9 | % | 20.4 | % |  |

[0000068505-18-000015:8k_2_02:17]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.41 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-18-000015:8k_2_02:18]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-18-000015:8k_2_02:19]
| • | Revenue - Sales increased 15 percent from the year-ago quarter driven by growth in all regions. Approximately $49 million of revenue growth was related to acquisitions, including $22 million from the acquisitions of Airbus DS Communications and Avigilon. In addition, $15 million was related to the adoption of accounting standard ASC 606. Products segment sales grew 14 percent with growth in every region. The Services segment grew 15 percent with growth in every region led by Managed & Support Services. |

[0000068505-18-000015:8k_2_02:20]
| • | Operating margin - GAAP operating margin was 11.6 percent of sales, compared with 13.5 percent in the year-ago quarter. The decline reflects higher transaction costs related to acquisitions and a $52 million collection of a legal judgment in the prior year, offset by higher sales volume and higher gross margin. Non-GAAP operating margin was 17.7 percent of sales, compared with 16.5 percent in the year-ago quarter driven primarily by higher sales and higher gross margin. |

[0000068505-18-000015:8k_2_02:21]
| • | Cash flow - Operating cash flow was negative $500 million, versus $142 million of operating cash generated in the year-ago quarter. Free cash flow2 was negative $541 million, versus $74 million of free cash flow generated in the year-ago quarter. Cash flow for the quarter was down due to a $500 million debt-funded U.S. pension contribution, higher cash tax payments, higher incentive payments and a $52 million collection of a legal judgment in the prior year offset by lower capital expenditures associated with the company's ERP implementation in the prior year. |

[0000068505-18-000015:8k_2_02:22]
| • | Capital allocation - The company paid $1.1 billion for acquisitions, repurchased $66 million of its common stock and paid $84 million in cash dividends. |

[0000068505-18-000015:8k_2_02:23]
| • | Backlog - The company ended the quarter with backlog of $9.6 billion, up $1.1 billion from the year-ago quarter. Products segment backlog was up 11 percent or $166 million, and Services was up 14 percent or $973 million. Land mobile radio demand led by the Americas continues to drive backlog growth. |

[0000068505-18-000015:8k_2_02:24]
KEY HIGHLIGHTS

[0000068505-18-000015:8k_2_02:25]
Strategic wins

[0000068505-18-000015:8k_2_02:26]
| • | Selected by the state of Florida to build and manage a new statewide public safety network |

[0000068505-18-000015:8k_2_02:27]
| • | $40 million for a four-year Managed & Support Services contract for the state of Maryland |

[0000068505-18-000015:8k_2_02:28]
| • | $20 million for additional Managed & Support Services for the state of Indiana |

[0000068505-18-000015:8k_2_02:29]
| • | $15 million for a P25 system in Miami-Dade County, Florida |

[0000068505-18-000015:8k_2_02:30]
| • | $6 million for a two-year Managed & Support Services contract for Petrobras, a large petroleum company in Latin America |

[0000068505-18-000015:8k_2_02:31]
Innovation and investments in growth

[0000068505-18-000015:8k_2_02:32]
| • | Announced the LEX L11 Mission Critical LTE handheld device for global broadband networks, including FirstNet in the U.S. |

[0000068505-18-000015:8k_2_02:33]
| • | Announced the Capture mobile camera app, which allows first responders to capture image, video and audio evidence on any Android or iOS-based smartphone |

[0000068505-18-000015:8k_2_02:34]
| • | Completed the acquisitions of Avigilon, a leader in advanced video surveillance and analytics, and Airbus DS Communications (Plant Holdings, Inc.), a leading provider in North America of command center software for emergency call-handling |

[0000068505-18-000015:8k_2_02:35]
BUSINESS OUTLOOK

[0000068505-18-000015:8k_2_02:36]
| • | Second-quarter 2018 - Motorola Solutions expects revenue growth of approximately 15 percent, with organic growth of approximately 4 percent, compared with the second quarter of 2017. The company expects non-GAAP earnings in the range of $1.34 to $1.39 per share. |

[0000068505-18-000015:8k_2_02:37]
| • | Full-year 2018 - The company now expects revenue growth of approximately 14 percent, up from the prior outlook of 10 to 11 percent provided at the Financial Analyst Meeting on Feb. 27. The company now expects non-GAAP earnings per share in the range of $6.70 to $6.85, up from the prior outlook of $6.50 to $6.65. This assumes current foreign exchange rates, approximately 172 million fully diluted shares and a 25 percent effective tax rate. |

[0000068505-18-000015:8k_2_02:38]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, May 3. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-18-000015:8k_2_02:39]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-18-000015:8k_2_02:40]
A comparison of results from operations is as follows:

[0000068505-18-000015:8k_2_02:41]
|  | Q1 2018 |  | Q1 2017 |  |
| Net sales | $1,468 | $1,281 |
| Gross margin | 669 |  | 570 |  |
| Operating earnings | 171 |  | 173 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 117 |  | 77 |  |
| Diluted EPS | $0.69 | $0.45 |
| Weighted average diluted common shares outstanding | 170.6 |  | 169.9 |  |

[0000068505-18-000015:8k_2_02:42]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-18-000015:8k_2_02:43]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the first quarter of 2018.

[0000068505-18-000015:8k_2_02:44]
| (per diluted common share) | Q1 2018 |  |
| GAAP Earnings | $0.69 |
| Highlighted Items: |  |
| Share-based compensation expense | 0.08 |  |
| Reorganization of business charges | 0.06 |  |
| Intangibles amortization expense | 0.19 |  |
| Loss on legal settlements | 0.01 |  |
| Loss on Avigilon derivative instruments | 0.06 |  |
| Release of FIN 48 reserve | (0.01 | ) |
| Sale of investments | (0.05 | ) |
| Acquisition-related transaction fees | 0.07 |  |
| Non-GAAP Diluted EPS | $1.10 |

[0000068505-18-000015:8k_2_02:45]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-18-000015:8k_2_02:46]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-18-000015:8k_2_02:47]
Organic revenue:  Reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters, and excludes the affects of ASC 606. Management believes organic revenue helps it and investors better identify the underlying trends of established and ongoing operations by excluding the effects of acquisitions and accounting adjustments which can obscure period to period comparisons.

[0000068505-18-000015:8k_2_02:48]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments, significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-18-000015:8k_2_02:49]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-18-000015:8k_2_02:50]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-18-000015:8k_2_02:51]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-18-000015:8k_2_02:52]
BUSINESS RISKS

[0000068505-18-000015:8k_2_02:53]
undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-18-000015:8k_2_02:54]
DEFINITIONS

[0000068505-18-000015:8k_2_02:55]
1 Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters and excluding the effects of ASC 606.

[0000068505-18-000015:8k_2_02:56]
2  Free cash flow represents operating cash flow less capital expenditures.

[0000068505-18-000015:8k_2_02:57]
ABOUT MOTOROLA SOLUTIONS

[0000068505-18-000015:8k_2_02:58]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0000068505-18-000015:8k_2_02:59]
MEDIA CONTACT

[0000068505-18-000015:8k_2_02:60]
Tama McWhinney

[0000068505-18-000015:8k_2_02:61]
Motorola Solutions

[0000068505-18-000015:8k_2_02:62]
+1 847-538-1865

[0000068505-18-000015:8k_2_02:63]
tama.mcwhinney@motorolasolutions.com

[0000068505-18-000015:8k_2_02:64]
INVESTOR CONTACT

[0000068505-18-000015:8k_2_02:65]
Chris Kutsor

[0000068505-18-000015:8k_2_02:66]
Motorola Solutions

[0000068505-18-000015:8k_2_02:67]
+1 847-576-4995

[0000068505-18-000015:8k_2_02:68]
chris.kutsor@motorolasolutions.com

[0000068505-18-000015:8k_2_02:69]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2018 Motorola Solutions, Inc. All rights reserved.

[0000068505-18-000015:8k_2_02:70]
GAAP-1

[0000068505-18-000015:8k_2_02:71]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:72]
Condensed Consolidated Statements of Operations

[0000068505-18-000015:8k_2_02:73]
(In millions, except per share amounts)

[0000068505-18-000015:8k_2_02:74]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Net sales from products | $ | 801 |  |  | $ | 703 |  |
| Net sales from services | 667 |  |  | 578 |  |
| Net sales | 1,468 |  |  | 1,281 |  |
| Costs of products sales | 383 |  |  | 347 |  |
| Costs of services sales | 416 |  |  | 364 |  |
| Costs of sales | 799 |  |  | 711 |  |
| Gross margin | 669 |  |  | 570 |  |
| Selling, general and administrative expenses | 279 |  |  | 244 |  |
| Research and development expenditures | 152 |  |  | 135 |  |
| Other charges | 26 |  |  | (18 | ) |
| Intangibles amortization | 41 |  |  | 36 |  |
| Operating earnings | 171 |  |  | 173 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (46 | ) |  | (51 | ) |
| Gains on sales of investments and businesses, net | 11 |  |  | 3 |  |
| Other | 4 |  |  | (5 | ) |
| Total other expense | (31 | ) |  | (53 | ) |
| Net earnings before income taxes | 140 |  |  | 120 |  |
| Income tax expense | 23 |  |  | 42 |  |
| Net earnings | 117 |  |  | 78 |  |
| Less: Earnings attributable to noncontrolling interests | — |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 117 |  |  | $ | 77 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 0.73 |  |  | $ | 0.47 |  |
| Diluted | $ | 0.69 |  |  | $ | 0.45 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 161.4 |  |  | 164.2 |  |
| Diluted | 170.6 |  |  | 169.9 |  |

[0000068505-18-000015:8k_2_02:75]
|  | Percentage of Net Sales* |
| Net sales from products | 54.6 | % |  | 54.9 | % |
| Net sales from services | 45.4 | % |  | 45.1 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.8 | % |  | 49.4 | % |
| Costs of services sales | 62.4 | % |  | 63.0 | % |
| Costs of sales | 54.4 | % |  | 55.5 | % |
| Gross margin | 45.6 | % |  | 44.5 | % |
| Selling, general and administrative expenses | 19.0 | % |  | 19.0 | % |
| Research and development expenditures | 10.4 | % |  | 10.5 | % |
| Other charges | 1.8 | % |  | (1.4 | )% |
| Intangibles amortization | 2.8 | % |  | 2.8 | % |
| Operating earnings | 11.6 | % |  | 13.5 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.1 | )% |  | (4.0 | )% |
| Gains on sales of investments and businesses, net | 0.7 | % |  | 0.2 | % |
| Other | 0.3 | % |  | (0.4 | )% |
| Total other expense | (2.1 | )% |  | (4.1 | )% |
| Net earnings before income taxes | 9.5 | % |  | 9.4 | % |
| Income tax expense | 1.6 | % |  | 3.3 | % |
| Net earnings | 8.0 | % |  | 6.1 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 8.0 | % |  | 6.0 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-18-000015:8k_2_02:76]
GAAP-2

[0000068505-18-000015:8k_2_02:77]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:78]
Condensed Consolidated Balance Sheets

[0000068505-18-000015:8k_2_02:79]
(In millions)

[0000068505-18-000015:8k_2_02:80]
|  |  | March 31, 2018 |  | December 31, 2017 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 795 |  |  | $ | 1,205 |  |
| Restricted cash |  | 63 |  |  | 63 |  |
| Total cash and cash equivalents |  | 858 |  |  | 1,268 |  |
| Accounts receivable, net |  | 1,179 |  |  | 1,523 |  |
| Contract assets |  | 800 |  |  | — |  |
| Inventories, net |  | 441 |  |  | 327 |  |
| Other current assets |  | 343 |  |  | 832 |  |
| Total current assets |  | 3,621 |  |  | 3,950 |  |
| Property, plant and equipment, net |  | 900 |  |  | 856 |  |
| Investments |  | 174 |  |  | 247 |  |
| Deferred income taxes |  | 973 |  |  | 1,023 |  |
| Goodwill |  | 1,535 |  |  | 938 |  |
| Intangible assets |  | 1,436 |  |  | 861 |  |
| Other assets |  | 412 |  |  | 333 |  |
| Total assets |  | $ | 9,051 |  |  | $ | 8,208 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 492 |  |  | $ | 52 |  |
| Accounts payable |  | 463 |  |  | 593 |  |
| Contract liabilities |  | 1,069 |  |  | — |  |
| Accrued liabilities |  | 1,072 |  |  | 2,286 |  |
| Total current liabilities |  | 3,096 |  |  | 2,931 |  |
| Long-term debt |  | 5,304 |  |  | 4,419 |  |
| Other liabilities |  | 2,190 |  |  | 2,585 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,554 | ) |  | (1,742 | ) |
| Noncontrolling interests |  | 15 |  |  | 15 |  |
| Total liabilities and stockholders’ equity |  | $ | 9,051 |  |  | $ | 8,208 |  |
| Financial Ratios: |  |  |  |  |
| Net cash (debt)* |  | $ | (4,938 | ) |  | $ | (3,203 | ) |
| *Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |  |  |

[0000068505-18-000015:8k_2_02:81]
GAAP-3

[0000068505-18-000015:8k_2_02:82]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:83]
Condensed Consolidated Statements of Cash Flows

[0000068505-18-000015:8k_2_02:84]
(In millions)

[0000068505-18-000015:8k_2_02:85]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 117 |  |  | $ | 77 |  |
| Earnings attributable to noncontrolling interests | — |  |  | 1 |  |
| Net earnings | 117 |  |  | 78 |  |
| Adjustments to reconcile Net earnings to Net cash provided by (used for) operating activities: |  |  |  |
| Depreciation and amortization | 82 |  |  | 80 |  |
| Non-cash other charges | 3 |  |  | 15 |  |
| Non-U.S. pension settlement loss | — |  |  | 9 |  |
| Share-based compensation expense | 17 |  |  | 17 |  |
| Gains on sales of investments and businesses, net | (11 | ) |  | (3 | ) |
| Deferred income taxes | 7 |  |  | 23 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable, contract assets and contract liabilities | 195 |  |  | 368 |  |
| Inventories | (9 | ) |  | (69 | ) |
| Other current assets | 2 |  |  | (59 | ) |
| Accounts payable and accrued liabilities | (350 | ) |  | (307 | ) |
| Other assets and liabilities | (553 | ) |  | (10 | ) |
| Net cash (used for) provided by operating activities | (500 | ) |  | 142 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (1,125 | ) |  | (106 | ) |
| Proceeds from sales of investments and businesses, net | 77 |  |  | 53 |  |
| Capital expenditures | (41 | ) |  | (68 | ) |
| Net cash used for investing activities | (1,089 | ) |  | (121 | ) |
| Financing |  |  |  |
| Repayment of debt | (50 | ) |  | (1 | ) |
| Net proceeds from issuance of debt | 1,296 |  |  | — |  |
| Issuance of common stock | 53 |  |  | 22 |  |
| Purchase of common stock | (66 | ) |  | (178 | ) |
| Payment of dividends | (84 | ) |  | (77 | ) |
| Net cash provided by (used for) financing activities | 1,149 |  |  | (234 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 30 |  |  | 12 |  |
| Net decrease in cash and cash equivalents | (410 | ) |  | (201 | ) |
| Cash and cash equivalents, beginning of period | 1,268 |  |  | 1,030 |  |
| Cash and cash equivalents, end of period | $ | 858 |  |  | $ | 829 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | (541 | ) |  | $ | 74 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-18-000015:8k_2_02:86]
GAAP-4

[0000068505-18-000015:8k_2_02:87]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:88]
Segment Information

[0000068505-18-000015:8k_2_02:89]
(In millions)

[0000068505-18-000015:8k_2_02:90]
| Net Sales |
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Products | $ | 801 |  |  | $ | 703 |  |  | 14 | % |
| Services | 667 |  |  | 578 |  |  | 15 | % |
| Total Motorola Solutions | $ | 1,468 |  |  | $ | 1,281 |  |  | 15 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Products | $ | 89 |  |  | $ | 88 |  |  | 1 | % |
| Services | 82 |  |  | 85 |  |  | (4 | )% |
| Total Motorola Solutions | $ | 171 |  |  | $ | 173 |  |  | (1 | )% |

[0000068505-18-000015:8k_2_02:91]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  |  |
| Products | 11.1 | % |  | 12.5 | % |  |  |
| Services | 12.3 | % |  | 14.7 | % |  |  |
| Total Motorola Solutions | 11.6 | % |  | 13.5 | % |  |  |

[0000068505-18-000015:8k_2_02:92]
Non-GAAP-1

[0000068505-18-000015:8k_2_02:93]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:94]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-18-000015:8k_2_02:95]
| Q1 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 13 |  |  | 3 |  |  | 10 |  |  | 0.06 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 41 |  |  | 8 |  |  | 33 |  |  | 0.19 |  |
| Loss on legal settlements |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on derivative instruments related to Avigilon |  | Other expense |  | 14 |  |  | 4 |  |  | 10 |  |  | 0.06 |  |
| Release of FIN 48 reserve |  | Income tax benefit |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Sale of investments |  | Sale of Investment or Business (Gain) or Loss |  | (11 | ) |  | (3 | ) |  | (8 | ) |  | (0.05 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 17 |  |  | 5 |  |  | 12 |  |  | 0.07 |  |
| Total impact on Net earnings |  |  |  | $ | 92 |  |  | $ | 22 |  |  | $ | 70 |  |  | $ | 0.41 |  |

[0000068505-18-000015:8k_2_02:96]
Non-GAAP-2

[0000068505-18-000015:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:98]
Non-GAAP Segment Information

[0000068505-18-000015:8k_2_02:99]
(In millions)

[0000068505-18-000015:8k_2_02:100]
| Net Sales |
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Products | $ | 801 |  |  | $ | 703 |  |  | 14 | % |
| Services | 667 |  |  | 578 |  |  | 15 | % |
| Total Motorola Solutions | $ | 1,468 |  |  | $ | 1,281 |  |  | 15 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Products | $ | 127 |  |  | $ | 94 |  |  | 35 | % |
| Services | 133 |  |  | 118 |  |  | 13 | % |
| Total Motorola Solutions | $ | 260 |  |  | $ | 212 |  |  | 23 | % |

[0000068505-18-000015:8k_2_02:101]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  |  |
| Products | 15.9 | % |  | 13.4 | % |  |  |
| Services | 19.9 | % |  | 20.4 | % |  |  |
| Total Motorola Solutions | 17.7 | % |  | 16.5 | % |  |  |

[0000068505-18-000015:8k_2_02:102]
Non-GAAP-3

[0000068505-18-000015:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:104]
Operating Earnings after Non-GAAP Adjustments

[0000068505-18-000015:8k_2_02:105]
| Q1 2018 |
|  |  | TOTAL |  | Products |  | Services |
| Net sales |  | $ | 1,468 |  |  | $ | 801 |  |  | $ | 667 |  |
| Operating earnings ("OE") |  | $ | 171 |  |  | $ | 89 |  |  | $ | 82 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 13 |  |  | 10 |  |  | 3 |  |
| Intangibles amortization expense |  | 41 |  |  | 4 |  |  | 37 |  |
| Acquisition-related transaction fees |  | 17 |  |  | 11 |  |  | 6 |  |
| Loss on legal settlements |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 89 |  |  | 38 |  |  | 51 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 260 |  |  | $ | 127 |  |  | $ | 133 |  |

[0000068505-18-000015:8k_2_02:106]
| Operating earnings as a percentage of net sales - GAAP |  | 11.6 | % |  | 11.1 | % |  | 12.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 17.7 | % |  | 15.9 | % |  | 19.9 | % |

[0000068505-18-000015:8k_2_02:107]
Non-GAAP-4

[0000068505-18-000015:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:109]
Non-GAAP Organic Revenue

[0000068505-18-000015:8k_2_02:110]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |
|  |  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Net sales |  | $ | 1,468 |  |  | $ | 1,281 |  |  | 15 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (54 | ) |  | (5 | ) |  |  |
| ASC 606 impact |  | (15 | ) |  | — |  |  |  |
| Organic revenue |  | 1,399 |  |  | 1,276 |  |  | 10 | % |
| Less foreign exchange impact |  | (39 | ) |  | — |  |  |  |
| Organic revenue in constant currency |  | $ | 1,360 |  |  | $ | 1,276 |  |  | 7 | % |

[0000068505-18-000015:8k_2_02:111]
| North America |
|  |  | Three Months Ended |  |  |
|  |  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Americas net sales |  | $ | 995 |  |  | $ | 865 |  |  | 15 | % |
| Adjustments: |  |  |  |  |  |  |
| Latin America |  | (93 | ) |  | (65 | ) |  | 43 | % |
| North America acquisitions |  | (25 | ) |  | — |  |  |  |
| ASC 606 impact |  | (15 | ) |  | — |  |  |  |
| North America organic revenue |  | 862 |  |  | 800 |  |  | 8 | % |
| Less foreign exchange impact |  | (5 | ) |  | — |  |  |  |
| North America organic revenue in constant currency |  | $ | 857 |  |  | $ | 800 |  |  | 7 | % |

[0000068505-18-000015:8k_2_02:112]
Pro Forma-1

[0000068505-18-000015:8k_2_02:113]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000015:8k_2_02:114]
Third-Party Sales Commissions Classification

[0000068505-18-000015:8k_2_02:115]
| Total Motorola Solutions |
|  |  | April 1, 2017 |  | July 1, 2017 |  | September 30, 2017 |  | December 31, 2017 |  | 2017 |
| Net sales, as reported |  | $ | 1,281 |  |  | $ | 1,497 |  |  | $ | 1,645 |  |  | $ | 1,957 |  |  | $ | 6,380 |  |
| Third-party sales commissions adjustment * |  | 13 |  |  | 15 |  |  | 18 |  |  | 22 |  |  | 68 |  |
| Pro Forma net sales |  | 1,294 |  |  | 1,512 |  |  | 1,663 |  |  | 1,979 |  |  | 6,448 |  |
| Non-GAAP operating expenses, as reported** |  | 364 |  |  | 378 |  |  | 386 |  |  | 407 |  |  | 1,535 |  |
| Third-party sales commissions adjustment * |  | 13 |  |  | 15 |  |  | 18 |  |  | 22 |  |  | 68 |  |
| Pro forma non-GAAP operating expenses |  | 377 |  |  | 393 |  |  | 404 |  |  | 429 |  |  | 1,603 |  |
| Non-GAAP earnings, as reported |  | 120 |  |  | 189 |  |  | 259 |  |  | 355 |  |  | 923 |  |
| Pro forma earnings |  | $ | 120 |  |  | $ | 189 |  |  | $ | 259 |  |  | $ | 355 |  |  | $ | 923 |  |

[0000068505-18-000015:8k_2_02:116]
* Amounts adjusted to reflect the change in financial statement presentation of third-party sales commissions under the adoption of ASU No. 2014-09 ("ASC 606")

[0000068505-18-000015:8k_2_02:117]
** Amounts adjusted to reflect the change in financial statement presentation of net periodic cost (benefit) under the adoption of ASU Non. 2017-07
