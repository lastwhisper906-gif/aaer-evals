# MSI note change history — 0000068505-17-000017 → 0000068505-18-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0000068505-18-000017:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at March 31, 2018.
  (was, 2017-11-03, similarity 0.9883):
[0000068505-17-000017:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at September 30, 2017.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0000068505-18-000017:note_history:2]
The condensed consolidated financial statements as of March 31, 2018 and for the three months ended March 31, 2018 and April 1, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2017-11-03, similarity 0.9307):
[0000068505-17-000017:note_history:2]
The condensed consolidated financial statements as of September 30, 2017 and for the three and nine months ended September 30, 2017 and October 1, 2016 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2018-05-04):
[0000068505-18-000017:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three months ended March 31, 2018 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2017-11-03, similarity 0.9573):
[0000068505-17-000017:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2016. The results of operations for the three and nine months ended September 30, 2017 are not necessarily indicative of the operating results to be expected for the full year.

- added (2018-05-04):
[0000068505-18-000017:note_history:4]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

- added (2018-05-04):
[0000068505-18-000017:note_history:5]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc.("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

- added (2018-05-04):
[0000068505-18-000017:note_history:6]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company has begun to assess the impact of the ASU on its financial statements and expects a material impact to its balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards. The Company has also begun to catalog its existing lease contracts and identify changes needed to systems and processes.

- changed (2018-05-04):
[0000068505-18-000017:note_history:7]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements.
  (was, 2017-11-03, similarity 0.9864):
[0000068505-17-000017:note_history:7]
In August 2017, the FASB issued ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and the timing of adoption.

- added (2018-05-04):
[0000068505-18-000017:note_history:8]
Recently Adopted Accounting Pronouncements

- added (2018-05-04):
[0000068505-18-000017:note_history:9]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. The Company recognized $30 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company will recognize tax expense when intra-entity transfers of assets other than inventory occur.

- added (2018-05-04):
[0000068505-18-000017:note_history:10]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $20 million and $3 million in the three months ended March 31, 2018 and April 1, 2017, respectively.

- added (2018-05-04):
[0000068505-18-000017:note_history:11]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers", and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

- added (2018-05-04):
[0000068505-18-000017:note_history:12]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Managed & Support services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

- added (2018-05-04):
[0000068505-18-000017:note_history:13]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

- added (2018-05-04):
[0000068505-18-000017:note_history:14]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

- added (2018-05-04):
[0000068505-18-000017:note_history:15]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

- added (2018-05-04):
[0000068505-18-000017:note_history:16]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as a non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

- added (2018-05-04):
[0000068505-18-000017:note_history:17]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer respectively. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

- added (2018-05-04):
[0000068505-18-000017:note_history:18]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 are as follows:

- added (2018-05-04):
[0000068505-18-000017:note_history:19]
Balance Sheet (Selected captions)

- added (2018-05-04):
[0000068505-18-000017:note_history:20]
| (In millions) | December 31, 2017 |  | Reclassification of Contract Assets |  | Reclassification of Non-customer receivables |  | Reclassification of Contract Liabilities |  | Impact of Adoption on Open Contracts |  | January 1, 2018 |
|  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |
| ASSETS |
| Accounts receivable, net | $ | 1,523 |  |  | $ | (297 | ) |  | $ | (24 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | 1,198 |  |
| Contract assets | — |  |  | 846 |  |  | — |  |  | — |  |  | 85 |  |  | 931 |  |
| Inventories, net | 327 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 328 |  |
| Other current assets | 832 |  |  | (549 | ) |  | 24 |  |  | — |  |  | (23 | ) |  | 284 |  |
| Deferred income taxes | 1,023 |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | 982 |  |
| Other assets | 333 |  |  | — |  |  | — |  |  | — |  |  | 85 |  |  | 418 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Contract liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | (17 | ) |  | $ | 1,082 |  |
| Accrued liabilities | 2,286 |  |  | — |  |  | — |  |  | (1,099 | ) |  | — |  |  | 1,187 |  |
| Other liabilities | 2,585 |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | 2,578 |  |
| Stockholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings | 467 |  |  | — |  |  | — |  |  | — |  |  | 127 |  |  | 594 |  |

- added (2018-05-04):
[0000068505-18-000017:note_history:21]
Adoption Impact to Financial Statements

- added (2018-05-04):
[0000068505-18-000017:note_history:22]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three months ended March 31, 2018 is as follows:

- added (2018-05-04):
[0000068505-18-000017:note_history:23]
Statements of Operations (Selected captions)

- added (2018-05-04):
[0000068505-18-000017:note_history:24]
| (In millions) | March 31, 2018 |  | Adjustments due to ASC 606 |  | March 31, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,468 |  |  | $ | (15 | ) |  | $ | 1,453 |  |
| Gross margin | 669 |  |  | (15 | ) |  | 654 |  |
| Selling, general and administrative expenses | 279 |  |  | (13 | ) |  | 266 |  |
| Operating Earnings | 171 |  |  | (2 | ) |  | 169 |  |
| Net earnings before income taxes | 140 |  |  | (2 | ) |  | 138 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 117 |  |  | $ | (2 | ) |  | $ | 115 |  |

- added (2018-05-04):
[0000068505-18-000017:note_history:25]
Balance Sheet (Selected captions)

- added (2018-05-04):
[0000068505-18-000017:note_history:26]
| (In millions) | March 31, 2018 |  | Adjustments due to ASC 606 |  | March 31, 2018 Balances Under ASC 605 |
| Accounts receivable, net | $ | 1,179 |  |  | $ | 222 |  |  | $ | 1,401 |  |
| Contract assets | 800 |  |  | (800 | ) |  | — |  |
| Other current assets | 343 |  |  | 520 |  |  | 863 |  |
| Deferred income taxes | 973 |  |  | 41 |  |  | 1,014 |  |
| Other assets | 412 |  |  | (86 | ) |  | 326 |  |
| Contract liabilities | $ | 1,069 |  |  | $ | (1,069 | ) |  | $ | — |  |
| Accrued liabilities | 1,072 |  |  | 1,086 |  |  | 2,158 |  |
| Other liabilities | 2,190 |  |  | 9 |  |  | 2,199 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 531 |  |  | (129 | ) |  | 402 |  |

- added (2018-05-04):
[0000068505-18-000017:note_history:27]
There is no impact to the Statement of comprehensive income or the Statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the balance sheet and disclosed above.

- removed (2018-05-04):
[0000068505-17-000017:note_history:28]
On July 28, 2017, the Company announced its intention to purchase Plant Holdings, Inc., the parent company of Airbus DS Communications. This acquisition will expand the Company's software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

- removed (2018-05-04):
[0000068505-17-000017:note_history:29]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU No. 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

- removed (2018-05-04):
[0000068505-17-000017:note_history:30]
The Company has continued to analyze the impact of the new standard on its financial results based on an inventory of the Company's current contracts with customers. The Company has obtained an understanding of the new standard and currently believes that it will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of the Company's contracts is currently recognized under percentage of completion accounting applying a cost-to-cost method, including contracts for radio network deployments based on the ASTRO P25, TETRA, and LTE technologies, as well as certain offerings within its Smart Public Safety Solutions requiring significant integration (collectively "network integration contracts").

- removed (2018-05-04):
[0000068505-17-000017:note_history:31]
Under the new standard, the Company must identify the distinct promises to transfer goods and/or services within its contracts using certain factors. For network integration contracts, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard will impact the Company's network integration contracts that include devices and accessories, with the resulting impact being revenue recognized earlier as control of the devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's network integration contracts, it will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in the Company's contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

- removed (2018-05-04):
[0000068505-17-000017:note_history:32]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While the Company has contracts which fall under these rules in the current standard, it has not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, the Company does not anticipate a significant acceleration of revenue upon applying the new standard to its current contracts under these fact patterns.

- removed (2018-05-04):
[0000068505-17-000017:note_history:33]
The new standard also requires the concept of transfer of control to determine whether an entity must present revenue from providing goods or services at the gross amount billed to a customer (as a principal) or at the net amount retained (as an agent). Therefore, an entity must assess whether it controls the goods or services provided to a customer before they are transferred. The new standard provides three indicators to assist entities in determining control. Under the current standard, eight indicators (including the three indicators under the new standard) exist to evaluate whether an entity should present revenue gross as a principal or net as an agent. Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and remaining three indicators under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, upon adoption of the new standard the Company will present associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses.

- removed (2018-05-04):
[0000068505-17-000017:note_history:34]
Under current accounting standards, the Company expenses sales commissions as incurred. However, under ASU No. 2014-09, the Company will capitalize sales commissions as incremental costs to obtain a contract. Such costs will be classified as a contract asset and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

- removed (2018-05-04):
[0000068505-17-000017:note_history:35]
The Company continues to evaluate the impact of ASU No. 2014-09 on its financial results and prepare for the adoption of the standard on January 1, 2018, including readying its internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. The Company expects to adopt this standard under the modified retrospective method of adoption, which recognizes the cumulative effect of transition as an adjustment to retained earnings for contracts that are not completed as of the adoption date, without restating prior period financial statements.

- removed (2018-05-04):
[0000068505-17-000017:note_history:36]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- removed (2018-05-04):
[0000068505-17-000017:note_history:37]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company on January 1, 2018 with early adoption permitted. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

- removed (2018-05-04):
[0000068505-17-000017:note_history:38]
In October 2016, the FASB issued ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The Company intends to adopt the ASU on January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company continues to assess the impact of this ASU but anticipates that the impact will be immaterial based on existing deferred taxes from intra-entity asset transfers other than inventory.

- removed (2018-05-04):
[0000068505-17-000017:note_history:39]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in total cash, which is inclusive of cash and cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for the Company on January 1, 2018 with early adoption permitted. The Company intends to adopt the ASU on January 1, 2018. Upon adoption, the ASU requires retrospective application. The Company does not anticipate significant changes to the Company's financial statements and related disclosures from adoption of the ASU.

- removed (2018-05-04):
[0000068505-17-000017:note_history:40]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the Company plans to update the presentation of net periodic cost (benefit) accordingly, noting all components of the Company's net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of approximately $15 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-05-04):
[0000068505-18-000017:note_history:41]
As of March 31, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"), of which $400 million was borrowed as of March 31, 2018 to facilitate the Avigilon acquisition. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts was 3.25%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 31, 2018.

- added (2018-05-04):
[0000068505-18-000017:note_history:42]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, the Company entered into a term loan for $400 million and a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable quarterly. The weighted average borrowing rate for amounts outstanding during the quarter ended March 31, 2018 was 3.54%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- added (2018-05-04):
[0000068505-18-000017:note_history:43]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan.

- changed (2018-05-04):
[0000068505-18-000017:note_history:44]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of March 31, 2018 was $590 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.
  (was, 2017-11-03, similarity 0.6271):
[0000068505-17-000017:note_history:44]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). In the event of conversion, the notes may be settled in either cash or stock, at the Company's discretion. The Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- removed (2018-05-04):
[0000068505-17-000017:note_history:45]
As of September 30, 2017, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 30, 2017. During the quarter ended September 30, 2017, the Company had borrowings and repayments of $150 million under the 2017 Motorola Solutions Credit Agreement. Such borrowings were used to purchase Kodiak Networks, and were repaid using cash from operations within the quarter.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-04):
[0000068505-18-000017:note_history:46]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- added (2018-05-04):
[0000068505-18-000017:note_history:47]
| (in millions) | Products |  | Services |
| Regions |  |  |  |
| Americas | $ | 599 |  |  | $ | 396 |  |
| EMEA | 118 |  |  | 220 |  |
| AP | 84 |  |  | 51 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Major Products and Services |  |  |  |
| Systems and Integration | $ | 182 |  |  | $ | 168 |  |
| Devices | 619 |  |  | — |  |
| Managed & Support Services | — |  |  | 499 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Customer Type |  |  |  |
| Direct | $ | 466 |  |  | $ | 657 |  |
| Indirect | 335 |  |  | 10 |  |
| Total | $ | 801 |  |  | $ | 667 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-04):
[0000068505-18-000017:note_history:48]
Revenue from Contracts with Customers

- added (2018-05-04):
[0000068505-18-000017:note_history:49]
The Company adopted ASC 606 and all the related amendments on January 1, 2018, applying the modified retrospective method to all contracts not completed as of the date of adoption. The cumulative effect of adopting ASC 606 for contracts that were open as of the date of adoption is recognized as an adjustment to opening retained earnings in the period of adoption. All of the periods prior to the adoption of ASC 606 will continue to reflect the financial results recognized under the guidance of the previous revenue recognition standard.

- added (2018-05-04):
[0000068505-18-000017:note_history:50]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

- added (2018-05-04):
[0000068505-18-000017:note_history:51]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

- added (2018-05-04):
[0000068505-18-000017:note_history:52]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

- added (2018-05-04):
[0000068505-18-000017:note_history:53]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) noncash consideration, and (iv) consideration payable to a customer.

- added (2018-05-04):
[0000068505-18-000017:note_history:54]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

- added (2018-05-04):
[0000068505-18-000017:note_history:55]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.

- added (2018-05-04):
[0000068505-18-000017:note_history:56]
Disaggregation of Revenue

- added (2018-05-04):
[0000068505-18-000017:note_history:57]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- added (2018-05-04):
[0000068505-18-000017:note_history:58]
| (in millions) | Products |  | Services |
| Regions |  |  |  |
| Americas | $ | 599 |  |  | $ | 396 |  |
| EMEA | 118 |  |  | 220 |  |
| AP | 84 |  |  | 51 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Major Products and Services |  |  |  |
| Systems and Integration | $ | 182 |  |  | $ | 168 |  |
| Devices | 619 |  |  | — |  |
| Managed & Support Services | — |  |  | 499 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Customer Type |  |  |  |
| Direct | $ | 466 |  |  | $ | 657 |  |
| Indirect | 335 |  |  | 10 |  |
| Total | $ | 801 |  |  | $ | 667 |  |

- added (2018-05-04):
[0000068505-18-000017:note_history:59]
Products: The Products segment is comprised of Systems and Devices. Direct customers of the Products segment are typically government public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products sales, it records consideration from shipping and handling on a gross basis with Net sales.

- added (2018-05-04):
[0000068505-18-000017:note_history:60]
Systems: Systems include customized end-to-end radio network, command center, and video solutions. Radio network and command center solutions includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised, as described in Integration Services below. The radio network and command center solutions represent distinct performance obligations for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. System revenue is recognized over an average duration of approximately one to two years.

- added (2018-05-04):
[0000068505-18-000017:note_history:61]
Systems also includes Avigilon end-to-end security and surveillance solutions including video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

- added (2018-05-04):
[0000068505-18-000017:note_history:62]
Devices: Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Devices also includes video surveillance cameras sold by Avigilon. Devices are considered capable of being distinct and distinct within the context of our contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

- added (2018-05-04):
[0000068505-18-000017:note_history:63]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including Integration services and Managed & Support services. Direct customers of the Services segment are typically government public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

- added (2018-05-04):
[0000068505-18-000017:note_history:64]
Integration Services:  Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Integration services are typically sold under a fixed price contract and bundled with other hardware or software offerings. The services can be sold in a contract as a distinct performance obligation. However, integration services typically are not distinct in the context of the contract as they represent a component of the system performance obligation subject to customization and integration services on hardware and software solutions. Revenue recognition on integration services is recognized over time based on input measures of costs incurred or units completed. Integration services are typically project implementations with an average duration of approximately one to two years.

- added (2018-05-04):
[0000068505-18-000017:note_history:65]
Managed & Support Services:  Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions. Managed & Support services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since Managed & Support services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly it does not constrain its contract price. Certain contracts may also contain variable consideration driven by number of users. Revenue is typically recognized on Managed & Support services over time as a series of services performed over the contract term on a straight-line basis.

- added (2018-05-04):
[0000068505-18-000017:note_history:66]
Significant Judgments

- added (2018-05-04):
[0000068505-18-000017:note_history:67]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

- added (2018-05-04):
[0000068505-18-000017:note_history:68]
The Company accounts for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized product solutions. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

- added (2018-05-04):
[0000068505-18-000017:note_history:69]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

- added (2018-05-04):
[0000068505-18-000017:note_history:70]
Remaining Performance Obligations

- added (2018-05-04):
[0000068505-18-000017:note_history:71]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 31, 2018 is $6.5 billion. A total of $1.7 billion is from Product performance obligations that are not yet satisfied, of which $1.0 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.8 billion is from Services performance obligations that are not yet satisfied as of March 31, 2018. The determination of Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Managed & Support services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.7 billion from unsatisfied Services performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed.

- added (2018-05-04):
[0000068505-18-000017:note_history:72]
Contract Balances

- added (2018-05-04):
[0000068505-18-000017:note_history:73]
| (in millions) | January 1, 2018 |  |  | March 31, 2018 |  |
| Receivables | $ | 1,198 |  |  | $ | 1,179 |  |
| Contract assets | 931 |  |  | 800 |  |
| Contract liabilities | 1,082 |  |  | 1,069 |  |
| Non-current contract liabilities | 162 |  |  | 167 |  |

- added (2018-05-04):
[0000068505-18-000017:note_history:74]
Contract assets consist of amounts formerly classified as Revenue in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of revenue recognized, Customer downpayments and Deferred revenue.

- added (2018-05-04):
[0000068505-18-000017:note_history:75]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over-time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Managed & Support services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year, applying practical expedients available under the accounting standards.

- added (2018-05-04):
[0000068505-18-000017:note_history:76]
Revenue recognized during the three months ended March 31, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $332 million. Revenue of $9 million was recognized during the three months ended March 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. During the three months ended March 31, 2018, the Company added Accounts receivable of $87 million, Contract assets of $26 million, and Contract liabilities of $48 million related to acquisitions.

- added (2018-05-04):
[0000068505-18-000017:note_history:77]
There have been no impairment losses recognized on customer receivables or contract assets during the three months ended March 31, 2018.

- added (2018-05-04):
[0000068505-18-000017:note_history:78]
Contract Cost Balances

- added (2018-05-04):
[0000068505-18-000017:note_history:79]
| (in millions) | January 1, 2018 |  |  | March 31, 2018 |  |
| Current contract cost assets | $ | 62 |  |  | $ | 62 |  |
| Non-current contract cost assets | 85 |  |  | 92 |  |

- added (2018-05-04):
[0000068505-18-000017:note_history:80]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $12 million for the three months ended March 31, 2018.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-04):
[0000068505-18-000017:note_history:81]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

- added (2018-05-04):
[0000068505-18-000017:note_history:82]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

- added (2018-05-04):
[0000068505-18-000017:note_history:83]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

- added (2018-05-04):
[0000068505-18-000017:note_history:84]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) noncash consideration, and (iv) consideration payable to a customer.

- added (2018-05-04):
[0000068505-18-000017:note_history:85]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

- added (2018-05-04):
[0000068505-18-000017:note_history:86]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.
