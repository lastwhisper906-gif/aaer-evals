# MSI notes — 0000068505-18-000017


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-18-000017:notes:1]
[same as prior period, unchanged from 0000068505-17-000017:notes:1]

[0000068505-18-000017:notes:2]
|  | March 31, 2018 |  | December 31, 2017 |
| Corporate bonds | $ | 2 |  |  | $ | 2 |  |
| Common stock | — |  |  | 13 |  |
|  | 2 |  |  | 15 |  |
| Strategic investments, at cost | 66 |  |  | 78 |  |
| Company owned life insurance policies | 95 |  |  | 141 |  |
| Equity method investments | 9 |  |  | 13 |  |
| Other investments | 2 |  |  | — |  |
|  | $ | 174 |  |  | $ | 247 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-18-000017:notes:3]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of March 31, 2018 and December 31, 2017 were as follows:

[0000068505-18-000017:notes:4]
| March 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | — |  |  | 2 |  |  | 2 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 25 |  |  | $ | 25 |  |

[0000068505-18-000017:notes:5]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | — |  |  | 2 |  |  | 2 |  |
| Common stock | 13 |  |  | — |  |  | 13 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-18-000017:notes:6]
[same as prior period, unchanged from 0000068505-17-000017:notes:7]

[0000068505-18-000017:notes:7]
[same as prior period, unchanged from 0000068505-17-000017:notes:8]

[0000068505-18-000017:notes:8]
[same as prior period, unchanged from 0000068505-17-000017:notes:9]

[0000068505-18-000017:notes:9]
|  | March 31, 2018 |  | December 31, 2017 |
| Long-term receivables | $ | 32 |  |  | $ | 37 |  |
| Less current portion | (18 | ) |  | (18 | ) |
| Non-current long-term receivables | $ | 14 |  |  | $ | 19 |  |

[0000068505-18-000017:notes:10]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $74 million at March 31, 2018, compared to $93 million at December 31, 2017.

[0000068505-18-000017:notes:11]
[same as prior period, unchanged from 0000068505-17-000017:notes:12]

[0000068505-18-000017:notes:12]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended March 31, 2018 and April 1, 2017:

[0000068505-18-000017:notes:13]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Accounts receivable sales proceeds | $ | 55 |  |  | $ | 19 |  |
| Long-term receivables sales proceeds | 13 |  |  | 46 |  |
| Total proceeds from receivable sales | $ | 68 |  |  | $ | 65 |  |

[0000068505-18-000017:notes:14]
At March 31, 2018, the Company had retained servicing obligations for $848 million of long-term receivables, compared to $873 million at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000017:notes:15]
[same as prior period, unchanged from 0000068505-17-000017:notes:16]

[0000068505-18-000017:notes:16]
An aging analysis of financing receivables at March 31, 2018 and December 31, 2017 is as follows:

[0000068505-18-000017:notes:17]
| March 31, 2018 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 20 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |
| Commercial loans and leases secured | 12 |  |  | — |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 32 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 4 |  |

[0000068505-18-000017:notes:18]
| December 31, 2017 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 21 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |
| Commercial loans and leases secured | 16 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 37 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 3 |  |


## msi:OtherChargesTableTextBlock

[0000068505-18-000017:notes:19]
[same as prior period, unchanged from 0000068505-17-000017:notes:20]

[0000068505-18-000017:notes:20]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Other charges: |  |  |  |
| Intangibles amortization (Note 14) | $ | 41 |  |  | $ | 36 |  |
| Reorganization of business (Note 13) | 8 |  |  | 15 |  |
| Building impairment | — |  |  | 8 |  |
| Loss on legal settlements | 1 |  |  | — |  |
| Gain on recovery of financial receivables | — |  |  | (42 | ) |
| Acquisition-related transaction fees | 17 |  |  | 1 |  |
|  | $ | 67 |  |  | $ | 18 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-18-000017:notes:21]
[same as prior period, unchanged from 0000068505-17-000017:notes:22]

[0000068505-18-000017:notes:22]
| March 31, 2018 | Three Months Ended |
| Products | $ | 10 |  |
| Services | 3 |  |
|  | $ | 13 |  |

[0000068505-18-000017:notes:23]
| April 1, 2017 | Three Months Ended |
| Products | $ | 13 |  |
| Services | 6 |  |
|  | $ | 19 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-18-000017:notes:24]
[same as prior period, unchanged from 0000068505-17-000017:notes:25]

[0000068505-18-000017:notes:25]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Share-based compensation expense included in: |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |
| Selling, general and administrative expenses | 11 |  |  | 11 |  |
| Research and development expenditures | 4 |  |  | 4 |  |
| Share-based compensation expense included in Operating earnings | 17 |  |  | 17 |  |
| Tax benefit | 4 |  |  | 6 |  |
| Share-based compensation expense, net of tax | $ | 13 |  |  | $ | 11 |  |
| Decrease in basic earnings per share | $ | (0.08 | ) |  | $ | (0.07 | ) |
| Decrease in diluted earnings per share | $ | (0.08 | ) |  | $ | (0.06 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-18-000017:notes:26]
[same as prior period, unchanged from 0000068505-17-000017:notes:27]

[0000068505-18-000017:notes:27]
|  | March 31, 2018 |  | December 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 681 |  |  | $ | 80 |  |  | $ | 173 |  |  | $ | 76 |  |
| Services | 1,131 |  |  | 296 |  |  | 1,010 |  |  | 246 |  |
|  | $ | 1,812 |  |  | $ | 376 |  |  | $ | 1,183 |  |  | $ | 322 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-18-000017:notes:28]
[same as prior period, unchanged from 0000068505-17-000017:notes:29]

[0000068505-18-000017:notes:29]
|  | March 31, 2018 |  | December 31, 2017 |
| Defined benefit plans | $ | 1,507 |  |  | $ | 2,019 |  |
| Non-current contract liabilities (Note 2) | 167 |  |  | — |  |
| Deferred revenue (Note 1) | — |  |  | 169 |  |
| Unrecognized tax benefits | 53 |  |  | 54 |  |
| Deferred income taxes | 248 |  |  | 115 |  |
| Other | 215 |  |  | 228 |  |
|  | $ | 2,190 |  |  | $ | 2,585 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-18-000017:notes:30]
[same as prior period, unchanged from 0000068505-17-000017:notes:31]

[0000068505-18-000017:notes:31]
[same as prior period, unchanged from 0000068505-17-000017:notes:32]

[0000068505-18-000017:notes:32]
[same as prior period, unchanged from 0000068505-17-000017:notes:33]

[0000068505-18-000017:notes:33]
During the three months ending March 31, 2018, the Company recognized $17 million of acquisition-related transaction fees for the Avigilon and Plant acquisitions.

[0000068505-18-000017:notes:34]
During the three months ended April 1, 2017, the Company recognized $8 million of building impairments related to the sale of its Basingstoke building.

[0000068505-18-000017:notes:35]
During the three months ended April 1, 2017, the Company recognized a net gain of $42 million related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business. The net gain of $42 million was based on $52 million of proceeds received, net $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-18-000017:notes:36]
[same as prior period, unchanged from 0000068505-17-000017:notes:37]

[0000068505-18-000017:notes:37]
[same as prior period, unchanged from 0000068505-17-000017:notes:38]

[0000068505-18-000017:notes:38]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Interest income (expense), net: |  |  |  |
| Interest expense | $ | (54 | ) |  | $ | (54 | ) |
| Interest income | 8 |  |  | 3 |  |
|  | $ | (46 | ) |  | $ | (51 | ) |
| Other: |  |  |  |
| Net periodic postretirement benefit (Note 7) | $ | 20 |  |  | $ | 12 |  |
| Non-U.S. pension settlement loss (Note 7) | — |  |  | (9 | ) |
| Foreign currency loss | (11 | ) |  | (2 | ) |
| Loss on derivative instruments | (4 | ) |  | (7 | ) |
| Gains (losses) on equity method investments | 1 |  |  | (1 | ) |
| Other | (2 | ) |  | 2 |  |
|  | $ | 4 |  |  | $ | (5 | ) |

[0000068505-18-000017:notes:39]
During the three months ended March 31, 2018, the Company recognized a foreign currency loss of $11 million, primarily driven by the Euro and British pound, and a loss of $4 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations, which includes a loss of $14 million on foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the purchase of Avigilon.

[0000068505-18-000017:notes:40]
During the three months ended April 1, 2017, the Company recognized a foreign currency loss of $2 million, primarily driven by the Euro and a loss of $7 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-18-000017:notes:41]
[same as prior period, unchanged from 0000068505-17-000017:notes:43]

[0000068505-18-000017:notes:42]
[same as prior period, unchanged from 0000068505-17-000017:notes:44]

[0000068505-18-000017:notes:43]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Basic earnings per common share: |  |  |  |
| Earnings | $ | 117 |  |  | $ | 77 |  |
| Weighted average common shares outstanding | 161.4 |  |  | 164.2 |  |
| Per share amount | $ | 0.73 |  |  | $ | 0.47 |  |
| Diluted earnings per common share: |  |  |  |
| Earnings | $ | 117 |  |  | $ | 77 |  |
| Weighted average common shares outstanding | 161.4 |  |  | 164.2 |  |
| Add effect of dilutive securities: |  |  |  |
| Share-based awards | 4.2 |  |  | 3.3 |  |
| Senior Convertible Notes | 5.0 |  |  | 2.4 |  |
| Diluted weighted average common shares outstanding | 170.6 |  |  | 169.9 |  |
| Per share amount | $ | 0.69 |  |  | $ | 0.45 |  |

[0000068505-18-000017:notes:44]
In the computation of diluted earnings per common share for the three months ended March 31, 2018, the assumed exercise of 1.5 million options, including 1.2 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive. For the three months ended April 1, 2017, the assumed exercise of 2.7 million options, including 2.3 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-18-000017:notes:45]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Since the Company’s intention is to settle the par value of the Senior Convertible Notes in cash upon conversion, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-18-000017:notes:46]
[same as prior period, unchanged from 0000068505-17-000017:notes:50]

[0000068505-18-000017:notes:47]
[same as prior period, unchanged from 0000068505-17-000017:notes:51]

[0000068505-18-000017:notes:48]
[same as prior period, unchanged from 0000068505-17-000017:notes:52]

[0000068505-18-000017:notes:49]
|  | March 31, 2018 |  | December 31, 2017 |
| Accounts receivable | $ | 1,227 |  |  | $ | 1,568 |  |
| Less allowance for doubtful accounts | (48 | ) |  | (45 | ) |
|  | $ | 1,179 |  |  | $ | 1,523 |  |

[0000068505-18-000017:notes:50]
During the three months ended March 31, 2018, $297 million of Unbilled accounts receivable were reclassified to Contract assets and $24 million of non-customer miscellaneous receivables were reclassified to Other current assets as a result of the adoption of ASC 606. In addition, $87 million of receivables were acquired with the purchases of Avigilon and Plant.

[0000068505-18-000017:notes:51]
[same as prior period, unchanged from 0000068505-17-000017:notes:54]

[0000068505-18-000017:notes:52]
[same as prior period, unchanged from 0000068505-17-000017:notes:55]

[0000068505-18-000017:notes:53]
|  | March 31, 2018 |  | December 31, 2017 |
| Finished goods | $ | 233 |  |  | $ | 178 |  |
| Work-in-process and production materials | 342 |  |  | 282 |  |
|  | 575 |  |  | 460 |  |
| Less inventory reserves | (134 | ) |  | (133 | ) |
|  | $ | 441 |  |  | $ | 327 |  |

[0000068505-18-000017:notes:54]
During the three months ended March 31, 2018, Inventories, net increased by $114 million, primarily driven by $103 million from the acquisitions of Avigilon and Plant.

[0000068505-18-000017:notes:55]
[same as prior period, unchanged from 0000068505-17-000017:notes:58]

[0000068505-18-000017:notes:56]
[same as prior period, unchanged from 0000068505-17-000017:notes:59]

[0000068505-18-000017:notes:57]
|  | March 31, 2018 |  | December 31, 2017 |
| Costs and earnings in excess of billings (Note 1) | $ | — |  |  | $ | 549 |  |
| Current contract cost assets (Note 2) | 62 |  |  | 62 |  |
| Tax-related refunds receivable | 95 |  |  | 90 |  |
| Other | 186 |  |  | 131 |  |
|  | $ | 343 |  |  | $ | 832 |  |

[0000068505-18-000017:notes:58]
[same as prior period, unchanged from 0000068505-17-000017:notes:61]

[0000068505-18-000017:notes:59]
[same as prior period, unchanged from 0000068505-17-000017:notes:62]

[0000068505-18-000017:notes:60]
|  | March 31, 2018 |  | December 31, 2017 |
| Land | $ | 11 |  |  | $ | 11 |  |
| Building | 348 |  |  | 316 |  |
| Machinery and equipment | 2,187 |  |  | 2,122 |  |
|  | 2,546 |  |  | 2,449 |  |
| Less accumulated depreciation | (1,646 | ) |  | (1,593 | ) |
|  | $ | 900 |  |  | $ | 856 |  |

[0000068505-18-000017:notes:61]
During the three months ended March 31, 2018, the Company acquired $31 million of Property, plant and equipment in the purchases of Avigilon and Plant.

[0000068505-18-000017:notes:62]
Depreciation expense for the three months ended March 31, 2018 and April 1, 2017 was $41 million and $44 million, respectively.

[0000068505-18-000017:notes:63]
[same as prior period, unchanged from 0000068505-17-000017:notes:65]

[0000068505-18-000017:notes:64]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have readily determinable fair values and are recorded at cost less impairments and adjusted for observable fair value movements. The Company did not recognize any impairments or adjustments to fair value during the three months ended March 31, 2018.

[0000068505-18-000017:notes:65]
Company owned life insurance policies were recorded at their cash surrender value of $95 million and $141 million, at March 31, 2018 and December 31, 2017, respectively. During the three months ended March 31, 2018, the Company withdrew $60 million of excess cash from its company-sponsored life insurance investments.

[0000068505-18-000017:notes:66]
As of December 31, 2017, the Company had unrealized gains of $8 million related to available-for-sale securities, which were realized upon the sale of the investment in the first quarter of 2018.

[0000068505-18-000017:notes:67]
During the three months ended March 31, 2018, Gains on the sale of investments and businesses were $11 million, compared to gains of $3 million during the three months ended April 1, 2017.

[0000068505-18-000017:notes:68]
[same as prior period, unchanged from 0000068505-17-000017:notes:68]

[0000068505-18-000017:notes:69]
[same as prior period, unchanged from 0000068505-17-000017:notes:69]

[0000068505-18-000017:notes:70]
|  | March 31, 2018 |  | December 31, 2017 |
| Defined benefit plan assets | 151 |  |  | 133 |  |
| Tax receivable | 101 |  |  | 101 |  |
| Non-current contract cost assets (Note 2) | 92 |  |  | — |  |
| Other | 68 |  |  | 99 |  |
|  | $ | 412 |  |  | $ | 333 |  |

[0000068505-18-000017:notes:71]
[same as prior period, unchanged from 0000068505-17-000017:notes:71]

[0000068505-18-000017:notes:72]
[same as prior period, unchanged from 0000068505-17-000017:notes:72]

[0000068505-18-000017:notes:73]
|  | March 31, 2018 |  | December 31, 2017 |
| Deferred revenue (Note 1) | $ | — |  |  | $ | 613 |  |
| Compensation | 213 |  |  | 273 |  |
| Billings in excess of costs and earnings (Note 1) | — |  |  | 428 |  |
| Tax liabilities | 67 |  |  | 107 |  |
| Deferred consideration on Airwave acquisition | 88 |  |  | 83 |  |
| Dividend payable | 84 |  |  | 84 |  |
| Trade liabilities | 138 |  |  | 151 |  |
| Departmental accruals | 67 |  |  | 54 |  |
| Other | 415 |  |  | 493 |  |
|  | $ | 1,072 |  |  | $ | 2,286 |  |

[0000068505-18-000017:notes:74]
Deferred consideration in conjunction with the acquisition of Airwave will be paid on November 15, 2018.

[0000068505-18-000017:notes:75]
[same as prior period, unchanged from 0000068505-17-000017:notes:74]

[0000068505-18-000017:notes:76]
The Company made a $500 million contribution to our U.S. Pension Plans during the three months ended March 31, 2018.

[0000068505-18-000017:notes:77]
During the three months ended March 31, 2018, deferred income taxes increased by $133 million, primarily driven by $144 million related to the acquisitions of Avigilon and Plant.

[0000068505-18-000017:notes:78]
[same as prior period, unchanged from 0000068505-17-000017:notes:75]

[0000068505-18-000017:notes:79]
[same as prior period, unchanged from 0000068505-17-000017:notes:76]

[0000068505-18-000017:notes:80]
During the three months ended March 31, 2018, the Company paid an aggregate of $66 million, including transaction costs, to repurchase approximately 0.6 million shares at an average price of $101.54 per share. As of March 31, 2018, the Company had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-18-000017:notes:81]
Payment of Dividends: During the three months ended March 31, 2018 and April 1, 2017, the Company paid $84 million and $77 million, respectively, in cash dividends to holders of its common stock.

[0000068505-18-000017:notes:82]
[same as prior period, unchanged from 0000068505-17-000017:notes:79]

[0000068505-18-000017:notes:83]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three months ended March 31, 2018 and April 1, 2017:

[0000068505-18-000017:notes:84]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Foreign Currency Translation Adjustments: |  |  |  |
| Balance at beginning of period | $ | (353 | ) |  | $ | (494 | ) |
| Other comprehensive income before reclassification adjustment | 51 |  |  | 37 |  |
| Tax expense | (3 | ) |  | (3 | ) |
| Other comprehensive income, net of tax | 48 |  |  | 34 |  |
| Balance at end of period | $ | (305 | ) |  | $ | (460 | ) |
| Available-for-Sale Securities: |  |  |  |
| Balance at beginning of period | $ | 6 |  |  | $ | — |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | (8 | ) |  | — |  |
| Tax expense | 2 |  |  | — |  |
| Other comprehensive loss, net of tax | (6 | ) |  | — |  |
| Balance at end of period | $ | — |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |
| Balance at beginning of period | $ | (2,215 | ) |  | $ | (1,823 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 18 |  |  | 16 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4 | ) |  | (4 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other income (expense) | — |  |  | 9 |  |
| Tax benefit | (2 | ) |  | (2 | ) |
| Other comprehensive income, net of tax | 12 |  |  | 19 |  |
| Balance at end of period | $ | (2,203 | ) |  | $ | (1,804 | ) |
| Total Accumulated other comprehensive loss | $ | (2,508 | ) |  | $ | (2,264 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-18-000017:notes:85]
The condensed consolidated financial statements as of March 31, 2018 and for the three months ended March 31, 2018 and April 1, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-18-000017:notes:86]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three months ended March 31, 2018 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-18-000017:notes:87]
[same as prior period, unchanged from 0000068505-17-000017:notes:84]


## us-gaap:CapitalizedContractCostTableTextBlock

[0000068505-18-000017:notes:88]
| (in millions) | January 1, 2018 |  |  | March 31, 2018 |  |
| Current contract cost assets | $ | 62 |  |  | $ | 62 |  |
| Non-current contract cost assets | 85 |  |  | 92 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-18-000017:notes:89]
Commitments and Contingencies

[0000068505-18-000017:notes:90]
Legal Matters

[0000068505-18-000017:notes:91]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-18-000017:notes:92]
Other Indemnifications

[0000068505-18-000017:notes:93]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-18-000017:notes:94]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at March 31, 2018.

[0000068505-18-000017:notes:95]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000068505-18-000017:notes:96]
| (in millions) | January 1, 2018 |  |  | March 31, 2018 |  |
| Receivables | $ | 1,198 |  |  | $ | 1,179 |  |
| Contract assets | 931 |  |  | 800 |  |
| Contract liabilities | 1,082 |  |  | 1,069 |  |
| Non-current contract liabilities | 162 |  |  | 167 |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-18-000017:notes:97]
Debt and Credit Facilities

[0000068505-18-000017:notes:98]
As of March 31, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"), of which $400 million was borrowed as of March 31, 2018 to facilitate the Avigilon acquisition. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts was 3.25%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 31, 2018.

[0000068505-18-000017:notes:99]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, the Company entered into a term loan for $400 million and a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable quarterly. The weighted average borrowing rate for amounts outstanding during the quarter ended March 31, 2018 was 3.54%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-18-000017:notes:100]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan.

[0000068505-18-000017:notes:101]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of March 31, 2018 was $590 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-18-000017:notes:102]
[same as prior period, unchanged from 0000068505-17-000017:notes:95]

[0000068505-18-000017:notes:103]
[same as prior period, unchanged from 0000068505-17-000017:notes:96]

[0000068505-18-000017:notes:104]
As of March 31, 2018, the Company had outstanding foreign exchange contracts with notional amounts totaling $643 million, compared to $507 million outstanding at December 31, 2017. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-18-000017:notes:105]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of March 31, 2018, and the corresponding positions as of December 31, 2017:

[0000068505-18-000017:notes:106]
|  | Notional Amount |
| Net Buy (Sell) by Currency | March 31, 2018 |  | December 31, 2017 |
| Euro | $ | 238 |  |  | $ | 149 |  |
| British Pound | 103 |  |  | 72 |  |
| Chinese Renminbi | (72 | ) |  | (73 | ) |
| Brazilian Real | (45 | ) |  | (45 | ) |
| Australian Dollar | (42 | ) |  | (64 | ) |

[0000068505-18-000017:notes:107]
As of the three months ended March 31, 2018, the Company had entered into forward contracts to sell £25 million, expiring in June 2018, as well as to sell £25 million, expiring in September 2018. The forward contracts have been designated as a net investment hedge which is in place to partially hedge the Company's British pound foreign currency exposure on its net investment in Airwave Solutions Limited. The gains and losses on the Company's net investment in British pound-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive loss. As of March 31, 2018, the fair value of the derivative contracts was a $7 million liability.

[0000068505-18-000017:notes:108]
[same as prior period, unchanged from 0000068505-17-000017:notes:101]

[0000068505-18-000017:notes:109]
Certain of the Company's subsidiaries have variable interest loans denominated in the Euro and Chilean Peso. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as hedges. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swaps was de minimus at March 31, 2018 and December 31, 2017.

[0000068505-18-000017:notes:110]
[same as prior period, unchanged from 0000068505-17-000017:notes:103]

[0000068505-18-000017:notes:111]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of March 31, 2018, all of the counterparties have investment grade credit ratings. As of March 31, 2018, the Company had $4 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-18-000017:notes:112]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of March 31, 2018 and December 31, 2017:

[0000068505-18-000017:notes:113]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| March 31, 2018 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 7 |  |  | Other liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 4 |  |  | Other current assets |  | $ | 18 |  |  | Accrued liabilities |
| Total derivatives | $ | 4 |  |  |  |  | $ | 25 |  |  |  |

[0000068505-18-000017:notes:114]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2017 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 3 |  |  | Other liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other current assets |  | $ | 2 |  |  | Accrued liabilities |
| Total derivatives | $ | 5 |  |  |  |  | $ | 5 |  |  |  |

[0000068505-18-000017:notes:115]
The following table summarizes the effect of derivatives designated as hedging instruments on the Company's condensed consolidated financial statements for the three months ended March 31, 2018 and April 1, 2017:

[0000068505-18-000017:notes:116]
|  | Three Months Ended |  | Balance SheetLocation |
| Loss on Derivative Instruments | March 31, 2018 |  | April 1, 2017 |  |
| Foreign exchange contracts | $ | (3 | ) |  | $ | — |  |  | Other comprehensive income (loss) |

[0000068505-18-000017:notes:117]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated financial statements for the three months ended March 31, 2018 and April 1, 2017:

[0000068505-18-000017:notes:118]
|  | Three Months Ended |  | Statements ofOperations Location |
| Loss on Derivative Instruments | March 31, 2018 |  | April 1, 2017 |  |
| Foreign exchange contracts | (4 | ) |  | (7 | ) |  | Other income (expense) |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000068505-18-000017:notes:119]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-18-000017:notes:120]
| (in millions) | Products |  | Services |
| Regions |  |  |  |
| Americas | $ | 599 |  |  | $ | 396 |  |
| EMEA | 118 |  |  | 220 |  |
| AP | 84 |  |  | 51 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Major Products and Services |  |  |  |
| Systems and Integration | $ | 182 |  |  | $ | 168 |  |
| Devices | 619 |  |  | — |  |
| Managed & Support Services | — |  |  | 499 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Customer Type |  |  |  |
| Direct | $ | 466 |  |  | $ | 657 |  |
| Indirect | 335 |  |  | 10 |  |
| Total | $ | 801 |  |  | $ | 667 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-18-000017:notes:121]
[same as prior period, unchanged from 0000068505-17-000017:notes:112]

[0000068505-18-000017:notes:122]
During the three months ended March 31, 2018, the Company granted 0.3 million RSUs and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $36 million and $7 million, respectively, and 0.2 million stock options and 0.2 million performance options ("POs") with an aggregate grant-date fair value of $5 million and $7 million, respectively. Share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-18-000017:notes:123]
[same as prior period, unchanged from 0000068505-17-000017:notes:114]

[0000068505-18-000017:notes:124]
The Company holds or has held certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements on a recurring basis. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date. Fair value is measured using the fair value hierarchy and related valuation methodologies as defined in the authoritative literature. This guidance specifies a hierarchy of valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions.

[0000068505-18-000017:notes:125]
[same as prior period, unchanged from 0000068505-17-000017:notes:116]

[0000068505-18-000017:notes:126]
[same as prior period, unchanged from 0000068505-17-000017:notes:117]

[0000068505-18-000017:notes:127]
[same as prior period, unchanged from 0000068505-17-000017:notes:118]

[0000068505-18-000017:notes:128]
[same as prior period, unchanged from 0000068505-17-000017:notes:119]

[0000068505-18-000017:notes:129]
The Company had no Level 3 holdings as of March 31, 2018 or December 31, 2017.

[0000068505-18-000017:notes:130]
At March 31, 2018 and December 31, 2017, the Company had $306 million and $633 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-18-000017:notes:131]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at March 31, 2018 and December 31, 2017 was $5.9 billion and $4.6 billion (Level 2), respectively.

[0000068505-18-000017:notes:132]
[same as prior period, unchanged from 0000068505-17-000017:notes:123]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-18-000017:notes:133]
[same as prior period, unchanged from 0000068505-17-000017:notes:124]

[0000068505-18-000017:notes:134]
[same as prior period, unchanged from 0000068505-17-000017:notes:125]

[0000068505-18-000017:notes:135]
Avigilon Corporation

[0000068505-18-000017:notes:136]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. Prior to the end of the first quarter, $35 million of the assumed debt was repaid and subsequent to the quarter, the remaining $40 million was repaid.

[0000068505-18-000017:notes:137]
The acquisition of Avigilon has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value. The valuation of assets acquired and liabilities assumed in the acquisition has not yet been finalized as of March 31, 2018.  As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. The final allocation could differ materially from the preliminary allocation. The final allocation may include: (i) changes in allocations to intangible assets such as trade names, customer relationships, developed technology and goodwill, and (ii) other changes to assets and liabilities. The following table summarizes preliminary fair values of assets acquired and liabilities assumed as of the March 28, 2018 acquisition date:

[0000068505-18-000017:notes:138]
| Accounts receivable, net |  | $ | 67 |  |
| Inventory |  | 93 |  |
| Other current assets |  | 24 |  |
| Property, plant and equipment, net |  | 23 |  |
| Deferred income taxes |  | 4 |  |
| Accounts payable |  | (21 | ) |
| Accrued liabilities |  | (26 | ) |
| Deferred income tax liabilities |  | (131 | ) |
| Goodwill |  | 433 |  |
| Intangible assets |  | 508 |  |
| Total consideration |  | $ | 974 |  |

[0000068505-18-000017:notes:139]
Acquired intangible assets consist of $120 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to 20 years. The preliminary fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-18-000017:notes:140]
Goodwill is calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. Goodwill is not deductible for tax purposes.

[0000068505-18-000017:notes:141]
The pro forma effect of this acquisition is not significant.

[0000068505-18-000017:notes:142]
[same as prior period, unchanged from 0000068505-17-000017:notes:133]

[0000068505-18-000017:notes:143]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million net cash. This acquisition will expand the Company's software portfolio in the Command Center with additional solutions for Next Generation 9-1-1. The Company recognized $157 million of goodwill, $77 million of identifiable intangible assets and $3 million of net assets acquired. The identifiable intangible assets were classified as $40 million of customer-related intangibles, $26 million of completed technology and $11 million of trade names. The identifiable intangible assets will be amortized over a period of 10 to 20 years. The purchase accounting is not yet complete and as such the final allocation between identifiable intangibles and goodwill may be subject to change.

[0000068505-18-000017:notes:144]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers, for a gross purchase price of $225 million. As a result of the acquisition, the Company recognized $191 million of goodwill, $44 million of identifiable intangible assets and $10 million of acquired liabilities. The identifiable intangible assets were classified as $25 million of customer-related intangibles and $19 million of completed technology and will be amortized over a period of 13 to 16 years.

[0000068505-18-000017:notes:145]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides Managed & Support services for communications systems to public safety and commercial customers in Chile, for a gross purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $16 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-18-000017:notes:146]
The pro forma effects of these acquisitions are not significant.

[0000068505-18-000017:notes:147]
[same as prior period, unchanged from 0000068505-17-000017:notes:138]

[0000068505-18-000017:notes:148]
[same as prior period, unchanged from 0000068505-17-000017:notes:139]

[0000068505-18-000017:notes:149]
|  | March 31, 2018 |  | December 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 555 |  |  | $ | 59 |  |  | $ | 148 |  |  | $ | 55 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,178 |  |  | 289 |  |  | 977 |  |  | 242 |  |
| Other intangibles | 77 |  |  | 26 |  |  | 56 |  |  | 23 |  |
|  | $ | 1,812 |  |  | $ | 376 |  |  | $ | 1,183 |  |  | $ | 322 |  |

[0000068505-18-000017:notes:150]
Amortization expense on intangible assets was $41 million for the three months ended March 31, 2018 and $36 million for the three months ended April 1, 2017. As of March 31, 2018, annual amortization expense is estimated to be $202 million in 2018, $214 million in 2019, $209 million in 2020, $207 million in 2021, $204 million in 2022, and $96 million in 2023.

[0000068505-18-000017:notes:151]
[same as prior period, unchanged from 0000068505-17-000017:notes:142]

[0000068505-18-000017:notes:152]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2018 to March 31, 2018:

[0000068505-18-000017:notes:153]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2018 | $ | 316 |  |  | $ | 622 |  |  | $ | 938 |  |
| Goodwill acquired | 433 |  |  | 157 |  |  | 590 |  |
| Purchase accounting adjustments | — |  |  | (2 | ) |  | (2 | ) |
| Foreign currency | — |  |  | 9 |  |  | 9 |  |
| Balance as of March 31, 2018 | $ | 749 |  |  | $ | 786 |  |  | $ | 1,535 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-18-000017:notes:154]
[same as prior period, unchanged from 0000068505-17-000017:notes:145]

[0000068505-18-000017:notes:155]
[same as prior period, unchanged from 0000068505-17-000017:notes:146]

[0000068505-18-000017:notes:156]
[same as prior period, unchanged from 0000068505-17-000017:notes:147]

[0000068505-18-000017:notes:157]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Net earnings before income taxes | $ | 140 |  |  | $ | 120 |  |
| Income tax expense | 23 |  |  | 42 |  |
| Effective tax rate | 16 | % |  | 35 | % |

[0000068505-18-000017:notes:158]
The Company recorded $23 million of net tax expense during the three months ended March 31, 2018, resulting in an effective tax rate of 16%, compared to $42 million of net tax expense during the three months ended April 1, 2017, resulting in an effective tax rate of 35%. The effective tax rate for the three months ended March 31, 2018 of 16% is lower than the effective tax rate for the three months ended April 1, 2017 of 35%, primarily due to the corporate income tax rate decrease from 35% to 21%, as a result of the U.S. Tax Cuts and Jobs Act (the “Tax Act”) enacted December 22, 2017. The effective tax rate in the first quarter of 2018 was lower than the U.S. statutory tax rate of 21% primarily driven by a tax benefit due to the recognition of excess tax benefits on share-based compensation. The effective tax rate in the first quarter of 2017 was equal to the U.S. statutory tax rate of 35%.

[0000068505-18-000017:notes:159]
Under the guidance in the U.S. Securities and Exchange Commission's Staff Accounting Bulletin No. 118 that addresses the FASB's ASC Topic 740, "Income Taxes," the Company recorded provisional amounts for the impact of the Tax Act in 2017. The Company is continuing to analyze the impact of the recently issued IRS Notices. For the three months ended March 31, 2018, the Company has not recorded any material adjustments to the previously recorded tax impact.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-18-000017:notes:160]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company has begun to assess the impact of the ASU on its financial statements and expects a material impact to its balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards. The Company has also begun to catalog its existing lease contracts and identify changes needed to systems and processes.

[0000068505-18-000017:notes:161]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements.

[0000068505-18-000017:notes:162]
Recently Adopted Accounting Pronouncements

[0000068505-18-000017:notes:163]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. The Company recognized $30 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-18-000017:notes:164]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $20 million and $3 million in the three months ended March 31, 2018 and April 1, 2017, respectively.

[0000068505-18-000017:notes:165]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers", and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-18-000017:notes:166]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Managed & Support services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-18-000017:notes:167]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-18-000017:notes:168]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

[0000068505-18-000017:notes:169]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

[0000068505-18-000017:notes:170]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as a non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000017:notes:171]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer respectively. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

[0000068505-18-000017:notes:172]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 are as follows:

[0000068505-18-000017:notes:173]
Balance Sheet (Selected captions)

[0000068505-18-000017:notes:174]
| (In millions) | December 31, 2017 |  | Reclassification of Contract Assets |  | Reclassification of Non-customer receivables |  | Reclassification of Contract Liabilities |  | Impact of Adoption on Open Contracts |  | January 1, 2018 |
|  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |
| ASSETS |
| Accounts receivable, net | $ | 1,523 |  |  | $ | (297 | ) |  | $ | (24 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | 1,198 |  |
| Contract assets | — |  |  | 846 |  |  | — |  |  | — |  |  | 85 |  |  | 931 |  |
| Inventories, net | 327 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 328 |  |
| Other current assets | 832 |  |  | (549 | ) |  | 24 |  |  | — |  |  | (23 | ) |  | 284 |  |
| Deferred income taxes | 1,023 |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | 982 |  |
| Other assets | 333 |  |  | — |  |  | — |  |  | — |  |  | 85 |  |  | 418 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Contract liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | (17 | ) |  | $ | 1,082 |  |
| Accrued liabilities | 2,286 |  |  | — |  |  | — |  |  | (1,099 | ) |  | — |  |  | 1,187 |  |
| Other liabilities | 2,585 |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | 2,578 |  |
| Stockholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings | 467 |  |  | — |  |  | — |  |  | — |  |  | 127 |  |  | 594 |  |

[0000068505-18-000017:notes:175]
Adoption Impact to Financial Statements

[0000068505-18-000017:notes:176]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three months ended March 31, 2018 is as follows:

[0000068505-18-000017:notes:177]
Statements of Operations (Selected captions)

[0000068505-18-000017:notes:178]
| (In millions) | March 31, 2018 |  | Adjustments due to ASC 606 |  | March 31, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,468 |  |  | $ | (15 | ) |  | $ | 1,453 |  |
| Gross margin | 669 |  |  | (15 | ) |  | 654 |  |
| Selling, general and administrative expenses | 279 |  |  | (13 | ) |  | 266 |  |
| Operating Earnings | 171 |  |  | (2 | ) |  | 169 |  |
| Net earnings before income taxes | 140 |  |  | (2 | ) |  | 138 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 117 |  |  | $ | (2 | ) |  | $ | 115 |  |

[0000068505-18-000017:notes:179]
| (In millions) | March 31, 2018 |  | Adjustments due to ASC 606 |  | March 31, 2018 Balances Under ASC 605 |
| Accounts receivable, net | $ | 1,179 |  |  | $ | 222 |  |  | $ | 1,401 |  |
| Contract assets | 800 |  |  | (800 | ) |  | — |  |
| Other current assets | 343 |  |  | 520 |  |  | 863 |  |
| Deferred income taxes | 973 |  |  | 41 |  |  | 1,014 |  |
| Other assets | 412 |  |  | (86 | ) |  | 326 |  |
| Contract liabilities | $ | 1,069 |  |  | $ | (1,069 | ) |  | $ | — |  |
| Accrued liabilities | 1,072 |  |  | 1,086 |  |  | 2,158 |  |
| Other liabilities | 2,190 |  |  | 9 |  |  | 2,199 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 531 |  |  | (129 | ) |  | 402 |  |

[0000068505-18-000017:notes:180]
There is no impact to the Statement of comprehensive income or the Statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the balance sheet and disclosed above.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-18-000017:notes:181]
[same as prior period, unchanged from 0000068505-17-000017:notes:164]

[0000068505-18-000017:notes:182]
[same as prior period, unchanged from 0000068505-17-000017:notes:165]

[0000068505-18-000017:notes:183]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

[0000068505-18-000017:notes:184]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc.("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

[0000068505-18-000017:notes:185]
[same as prior period, unchanged from 0000068505-17-000017:notes:167]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-18-000017:notes:186]
[same as prior period, unchanged from 0000068505-17-000017:notes:168]

[0000068505-18-000017:notes:187]
[same as prior period, unchanged from 0000068505-17-000017:notes:169]

[0000068505-18-000017:notes:188]
[same as prior period, unchanged from 0000068505-17-000017:notes:170]

[0000068505-18-000017:notes:189]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 46 |  |  | 10 |  |  | 10 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (68 | ) |  | (58 | ) |  | (24 | ) |  | (23 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 14 |  |  | 11 |  |  | 3 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Settlement loss | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | (8 | ) |  | $ | (1 | ) |  | $ | (10 | ) |  | $ | 1 |  |  | $ | (5 | ) |  | $ | (5 | ) |

[0000068505-18-000017:notes:190]
The Company made a $500 million contribution to its U.S. Pension Plans during the three months ended March 31, 2018.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-18-000017:notes:191]
[same as prior period, unchanged from 0000068505-17-000017:notes:174]

[0000068505-18-000017:notes:192]
2018 Charges

[0000068505-18-000017:notes:193]
During the three months ended March 31, 2018, the Company recorded net reorganization of business charges of $13 million including $8 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $13 million were charges of $22 million related to employee separation costs and $2 million related to exit costs, partially offset by $11 million of reversals for accruals no longer needed.

[0000068505-18-000017:notes:194]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2018 to March 31, 2018:

[0000068505-18-000017:notes:195]
|  | January 1, 2018 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | March 31, 2018 |
| Exit costs | $ | 9 |  |  | $ | 2 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 9 |  |
| Employee separation costs | 41 |  |  | 22 |  |  | (11 | ) |  | (13 | ) |  | 39 |  |
|  | $ | 50 |  |  | $ | 24 |  |  | $ | (11 | ) |  | $ | (15 | ) |  | $ | 48 |  |

[0000068505-18-000017:notes:196]
[same as prior period, unchanged from 0000068505-17-000017:notes:180]

[0000068505-18-000017:notes:197]
At January 1, 2018, the Company had $9 million of accruals for exit costs. During the three months ended March 31, 2018, there were $2 million of additional charges and $2 million of cash payments related to the exit of leased facilities. The remaining accrual of $9 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at March 31, 2018, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-18-000017:notes:198]
[same as prior period, unchanged from 0000068505-17-000017:notes:182]

[0000068505-18-000017:notes:199]
At January 1, 2018, the Company had an accrual of $41 million for employee separation costs. The 2018 additional charges of $22 million represent severance costs for approximately 300 employees. The adjustment of $11 million reflects reversals for accruals no longer needed. The $13 million used reflects cash payments to severed employees. The remaining accrual of $39 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at March 31, 2018, is expected to be paid, primarily within one year, to approximately 400 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-18-000017:notes:200]
[same as prior period, unchanged from 0000068505-17-000017:notes:175]

[0000068505-18-000017:notes:201]
During the three months ended April 1, 2017, the Company recorded net reorganization of business charges of $19 million including $15 million of charges in Other charges and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $19 million were charges of $15 million related to employee separation costs and $4 million for exit costs.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-18-000017:notes:202]
Revenue from Contracts with Customers

[0000068505-18-000017:notes:203]
The Company adopted ASC 606 and all the related amendments on January 1, 2018, applying the modified retrospective method to all contracts not completed as of the date of adoption. The cumulative effect of adopting ASC 606 for contracts that were open as of the date of adoption is recognized as an adjustment to opening retained earnings in the period of adoption. All of the periods prior to the adoption of ASC 606 will continue to reflect the financial results recognized under the guidance of the previous revenue recognition standard.

[0000068505-18-000017:notes:204]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

[0000068505-18-000017:notes:205]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

[0000068505-18-000017:notes:206]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

[0000068505-18-000017:notes:207]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) noncash consideration, and (iv) consideration payable to a customer.

[0000068505-18-000017:notes:208]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

[0000068505-18-000017:notes:209]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.

[0000068505-18-000017:notes:210]
Disaggregation of Revenue

[0000068505-18-000017:notes:211]
Products: The Products segment is comprised of Systems and Devices. Direct customers of the Products segment are typically government public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products sales, it records consideration from shipping and handling on a gross basis with Net sales.

[0000068505-18-000017:notes:212]
Systems: Systems include customized end-to-end radio network, command center, and video solutions. Radio network and command center solutions includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised, as described in Integration Services below. The radio network and command center solutions represent distinct performance obligations for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. System revenue is recognized over an average duration of approximately one to two years.

[0000068505-18-000017:notes:213]
Systems also includes Avigilon end-to-end security and surveillance solutions including video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

[0000068505-18-000017:notes:214]
Devices: Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Devices also includes video surveillance cameras sold by Avigilon. Devices are considered capable of being distinct and distinct within the context of our contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-18-000017:notes:215]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including Integration services and Managed & Support services. Direct customers of the Services segment are typically government public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-18-000017:notes:216]
Integration Services:  Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Integration services are typically sold under a fixed price contract and bundled with other hardware or software offerings. The services can be sold in a contract as a distinct performance obligation. However, integration services typically are not distinct in the context of the contract as they represent a component of the system performance obligation subject to customization and integration services on hardware and software solutions. Revenue recognition on integration services is recognized over time based on input measures of costs incurred or units completed. Integration services are typically project implementations with an average duration of approximately one to two years.

[0000068505-18-000017:notes:217]
Managed & Support Services:  Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions. Managed & Support services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since Managed & Support services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly it does not constrain its contract price. Certain contracts may also contain variable consideration driven by number of users. Revenue is typically recognized on Managed & Support services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-18-000017:notes:218]
Significant Judgments

[0000068505-18-000017:notes:219]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-18-000017:notes:220]
The Company accounts for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized product solutions. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-18-000017:notes:221]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-18-000017:notes:222]
Remaining Performance Obligations

[0000068505-18-000017:notes:223]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 31, 2018 is $6.5 billion. A total of $1.7 billion is from Product performance obligations that are not yet satisfied, of which $1.0 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.8 billion is from Services performance obligations that are not yet satisfied as of March 31, 2018. The determination of Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Managed & Support services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.7 billion from unsatisfied Services performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed.

[0000068505-18-000017:notes:224]
Contract Balances

[0000068505-18-000017:notes:225]
Contract assets consist of amounts formerly classified as Revenue in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of revenue recognized, Customer downpayments and Deferred revenue.

[0000068505-18-000017:notes:226]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over-time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Managed & Support services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year, applying practical expedients available under the accounting standards.

[0000068505-18-000017:notes:227]
Revenue recognized during the three months ended March 31, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $332 million. Revenue of $9 million was recognized during the three months ended March 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. During the three months ended March 31, 2018, the Company added Accounts receivable of $87 million, Contract assets of $26 million, and Contract liabilities of $48 million related to acquisitions.

[0000068505-18-000017:notes:228]
There have been no impairment losses recognized on customer receivables or contract assets during the three months ended March 31, 2018.

[0000068505-18-000017:notes:229]
Contract Cost Balances

[0000068505-18-000017:notes:230]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $12 million for the three months ended March 31, 2018.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-18-000017:notes:231]
[same as prior period, unchanged from 0000068505-17-000017:notes:187]

[0000068505-18-000017:notes:232]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Products | $ | 801 |  |  | $ | 703 |  |
| Services | 667 |  |  | 578 |  |
|  | $ | 1,468 |  |  | $ | 1,281 |  |

[0000068505-18-000017:notes:233]
[same as prior period, unchanged from 0000068505-17-000017:notes:189]

[0000068505-18-000017:notes:234]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Products | $ | 89 |  |  | $ | 88 |  |
| Services | 82 |  |  | 85 |  |
| Operating earnings | 171 |  |  | 173 |  |
| Total other expense | (31 | ) |  | (53 | ) |
| Earnings before income taxes | $ | 140 |  |  | $ | 120 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-18-000017:notes:235]
[same as prior period, unchanged from 0000068505-17-000017:notes:191]

[0000068505-18-000017:notes:236]
[same as prior period, unchanged from 0000068505-17-000017:notes:192]

[0000068505-18-000017:notes:237]
Products: The Products segment is comprised of Devices, Systems and Avigilon. Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Devices also includes video surveillance cameras sold by Avigilon. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. Systems also includes Avigilon advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, and access control solutions. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce.

[0000068505-18-000017:notes:238]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including Integration services and Managed & Support services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed services offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions.
