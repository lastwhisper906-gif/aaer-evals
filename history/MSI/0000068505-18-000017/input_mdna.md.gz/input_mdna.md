# MSI MD&A — 0000068505-18-000017


## mdna

[0000068505-18-000017:mdna:1]
[same as prior period, unchanged from 0000068505-17-000017:mdna:1]

[0000068505-18-000017:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three months ended March 31, 2018 and April 1, 2017, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2017.

[0000068505-18-000017:mdna:3]
[same as prior period, unchanged from 0000068505-17-000017:mdna:3]

[0000068505-18-000017:mdna:4]
[same as prior period, unchanged from 0000068505-17-000017:mdna:13]

[0000068505-18-000017:mdna:5]
On March 28, 2018, we completed the acquisition of Avigilon Corporation, a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

[0000068505-18-000017:mdna:6]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

[0000068505-18-000017:mdna:7]
We adopted ASU No. 2014-09, "Revenue from Contracts with Customers", and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to our opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods. The impact from adoption increased Net sales by $15 million.

[0000068505-18-000017:mdna:8]
[same as prior period, unchanged from 0000068505-17-000017:mdna:4]

[0000068505-18-000017:mdna:9]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 17,000 employees worldwide, based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-18-000017:mdna:10]
[same as prior period, unchanged from 0000068505-17-000017:mdna:6]

[0000068505-18-000017:mdna:11]
Products: The Products segment is comprised of Devices, Systems and Avigilon. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Devices also includes video surveillance cameras sold by Avigilon. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. Systems also includes Avigilon advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, and access control solutions. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the first quarter of 2018, the segment’s net sales were $801 million, representing 55% of our consolidated net sales.

[0000068505-18-000017:mdna:12]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including Integration services and Managed & Support services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. In the first quarter of 2018, the segment’s net sales were $667 million, representing 45% of our consolidated net sales.

[0000068505-18-000017:mdna:13]
First Quarter Summary

[0000068505-18-000017:mdna:14]
| • | Net sales were $1.5 billion in the first quarter of 2018, up $187 million, or 15%, from the first quarter of 2017. |

[0000068505-18-000017:mdna:15]
| • | We generated operating earnings of $171 million, or 12% of net sales, in the first quarter of 2018, compared to $173 million, or 14% of net sales, in the first quarter of 2017. |

[0000068505-18-000017:mdna:16]
| • | We had net earnings attributable to Motorola Solutions, Inc. of $117 million, or $0.69 per diluted common share, in the first quarter of 2018, compared to $77 million, or $0.45 per diluted common share, in the first quarter of 2017. |

[0000068505-18-000017:mdna:17]
| • | We used net cash for operating activities of $500 million during the first quarter of 2018, primarily driven by the $500 million contribution to our U.S. pension plan, compared to $142 million of net cash generated in the first quarter of 2017. |

[0000068505-18-000017:mdna:18]
| • | We returned $150 million in capital to shareholders through dividends and share repurchases during the first quarter of 2018. |

[0000068505-18-000017:mdna:19]
[same as prior period, unchanged from 0000068505-17-000017:mdna:21]

[0000068505-18-000017:mdna:20]
| • | Products: Net sales were $801 million in the first quarter of 2018, an increase of $98 million, or 14% compared to net sales of $703 million during the first quarter of 2017. On a geographic basis, net sales increased in every region, compared to the year-ago quarter. |

[0000068505-18-000017:mdna:21]
| • | Services: Net sales were $667 million in the first quarter of 2018, an increase of $89 million, or 15% compared to net sales of $578 million in the first quarter of 2017. On a geographic basis, net sales increased in every region, compared to the year-ago quarter. |

[0000068505-18-000017:mdna:22]
31

[0000068505-18-000017:mdna:23]
[same as prior period, unchanged from 0000068505-17-000017:mdna:25]

[0000068505-18-000017:mdna:24]
|  | Three Months Ended |
| (Dollars in millions, except per share amounts) | March 31, 2018 |  | % ofSales* |  | April 1, 2017 |  | % ofSales* |
| Net sales from products | $ | 801 |  |  |  |  | $ | 703 |  |  |  |
| Net sales from services | 667 |  |  |  |  | 578 |  |  |  |
| Net sales | 1,468 |  |  |  |  | 1,281 |  |  |  |
| Costs of products sales | 383 |  |  | 47.8 | % |  | 347 |  |  | 49.4 | % |
| Costs of services sales | 416 |  |  | 62.4 | % |  | 364 |  |  | 63.0 | % |
| Costs of sales | 799 |  |  |  |  | 711 |  |  |  |
| Gross margin | 669 |  |  | 45.6 | % |  | 570 |  |  | 44.5 | % |
| Selling, general and administrative expenses | 279 |  |  | 19.0 | % |  | 244 |  |  | 19.0 | % |
| Research and development expenditures | 152 |  |  | 10.4 | % |  | 135 |  |  | 10.5 | % |
| Other charges | 67 |  |  | 4.6 | % |  | 18 |  |  | 1.4 | % |
| Operating earnings | 171 |  |  | 11.6 | % |  | 173 |  |  | 13.5 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net | (46 | ) |  | (3.1 | )% |  | (51 | ) |  | (4.0 | )% |
| Gains on sales of investments and businesses, net | 11 |  |  | 0.7 | % |  | 3 |  |  | 0.2 | % |
| Other | 4 |  |  | 0.3 | % |  | (5 | ) |  | (0.4 | )% |
| Total other expense | (31 | ) |  | (2.1 | )% |  | (53 | ) |  | (4.1 | )% |
| Earnings before income taxes | 140 |  |  | 9.5 | % |  | 120 |  |  | 9.4 | % |
| Income tax expense | 23 |  |  | 1.6 | % |  | 42 |  |  | 3.3 | % |
| Net earnings | 117 |  |  | 8.0 | % |  | 78 |  |  | 6.1 | % |
| Less: Earnings attributable to noncontrolling interests | — |  |  | — | % |  | 1 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 117 |  |  | 8.0 | % |  | $ | 77 |  |  | 6.0 | % |
| Earnings per diluted common share | $ | 0.69 |  |  |  |  |  | $ | 0.45 |  |  |  |  |

[0000068505-18-000017:mdna:25]
[same as prior period, unchanged from 0000068505-17-000017:mdna:27]

[0000068505-18-000017:mdna:26]
32

[0000068505-18-000017:mdna:27]
Results of Operations—Three months ended March 31, 2018 compared to three months ended April 1, 2017

[0000068505-18-000017:mdna:28]
The results of operations for the first quarter of 2018 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-18-000017:mdna:29]
[same as prior period, unchanged from 0000068505-17-000017:mdna:31]

[0000068505-18-000017:mdna:30]
Net sales were $1.5 billion in the first quarter of 2018, a $187 million, or 15%, increase compared to the first quarter of 2017, reflecting solid demand across the globe for our products and services. The net sales increase for the first quarter of 2018 included $49 million from acquisitions, $39 million from favorable foreign currency rates and $15 million from the adoption of ASC 606. The increase in net sales is reflective of growth in every region. Devices net sales within the Products segment increased in the Americas and EMEA. Systems net sales within the Products segment increased in EMEA and AP. The Services segment net sales increased in every region. The Services segment net sales increase in the Americas was driven by the acquisition of Interexport, Kodiak Networks and Plant and growth in Managed & Support services absent of acquisitions. The Services segment net sales increase in EMEA and AP was driven by growth in both Managed & Support services and Integration services.

[0000068505-18-000017:mdna:31]
[same as prior period, unchanged from 0000068505-17-000017:mdna:33]

[0000068505-18-000017:mdna:32]
Gross margin was $669 million, or 45.6% of net sales, in the first quarter of 2018, compared to $570 million, or 44.5% of net sales, in the first quarter of 2017. The increase in gross margin percentage was primarily driven by a favorable mix in the Products segment.

[0000068505-18-000017:mdna:33]
[same as prior period, unchanged from 0000068505-17-000017:mdna:35]

[0000068505-18-000017:mdna:34]
SG&A expenses were $279 million, or 19.0% of net sales, in the first quarter of 2018, compared to $244 million, or 19.0% of net sales, in the first quarter of 2017. The increase in SG&A expenditures is primarily due to the change in classification of our third-party sales commissions from the adoption of ASC 606 and increased expenses associated with acquired businesses.

[0000068505-18-000017:mdna:35]
[same as prior period, unchanged from 0000068505-17-000017:mdna:37]

[0000068505-18-000017:mdna:36]
R&D expenditures were $152 million, or 10.4% of net sales, in the first quarter of 2018 and $135 million, or 10.5% of net sales, in the first quarter of 2017. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-18-000017:mdna:37]
[same as prior period, unchanged from 0000068505-17-000017:mdna:39]

[0000068505-18-000017:mdna:38]
We recorded net charges of $67 million in the first quarter of 2018, compared to net charges of $18 million in the first quarter of 2017. The net Other charges in the first quarter of 2018 were primarily driven by: (i) $41 million of charges relating to the amortization of intangibles, (ii) $17 million of acquisition related transaction fees and (iii) $8 million of net reorganization of business charges.

[0000068505-18-000017:mdna:39]
The net charges in the first quarter of 2017 of $18 million included: (i) $36 million of charges relating to the amortization of intangibles, (ii) $15 million of net reorganization of business charges and (iii) $8 million of charges related to a building impairment, partially offset by a net gain of $42 million, related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-18-000017:mdna:40]
[same as prior period, unchanged from 0000068505-17-000017:mdna:41]

[0000068505-18-000017:mdna:41]
Net interest expense was $46 million in the first quarter of 2018 and $51 million in the first quarter of 2017. The decrease in net interest expense in the first quarter of 2018 as compared to the first quarter of 2017 was a result of higher interest income due to amounts associated with a tax refund received within the first quarter of 2018.

[0000068505-18-000017:mdna:42]
[same as prior period, unchanged from 0000068505-17-000017:mdna:43]

[0000068505-18-000017:mdna:43]
Net gains on sales of investments and businesses were $11 million in the first quarter of 2018 compared to net gains of $3 million in the first quarter of 2017. The net gains in the first quarter of 2018 and 2017 were related to sales of various equity investments.

[0000068505-18-000017:mdna:44]
[same as prior period, unchanged from 0000068505-17-000017:mdna:45]

[0000068505-18-000017:mdna:45]
Net Other income was $4 million in the first quarter of 2018, compared to an expense of $5 million in the first quarter of 2017. The net other income in the first quarter of 2018 was primarily comprised of $20 million of net periodic postretirement benefit, partially offset by: (i) $11 million foreign currency loss and (ii) $4 million loss on derivative instruments, including losses of $14 million associated with foreign currency derivative contracts related to the acquisition of Avigilon. The net Other expense in the first quarter of 2017 was primarily comprised of: (i) $9 million of charges relating to the Non-U.S. pension settlement loss, (ii) $7 million loss on derivative instruments, and (iii) a $2 million foreign currency loss, partially offset by $12 million of net periodic postretirement benefit.

[0000068505-18-000017:mdna:46]
[same as prior period, unchanged from 0000068505-17-000017:mdna:47]

[0000068505-18-000017:mdna:47]
We recorded $23 million of net tax expense in the first quarter of 2018, resulting in an effective tax rate of 16%, compared to $42 million of net tax expense in the first quarter of 2017, resulting in an effective tax rate of 35%. Our effective tax rate for the three months ended March 31, 2018 of 16% is lower than our effective tax rate for the three months ended April 1, 2017 of 35%, primarily due to the corporate income tax rate decrease from 35% to 21%, as a result of the U.S. Tax Cuts and Jobs Act (the “Tax Act”) enacted December 22, 2017. Our effective tax rate in the first quarter of 2018 was lower than the U.S. statutory tax rate of 21% primarily driven by a tax benefit due to the recognition of excess tax benefits on share-based compensation. Our effective tax rate in the first quarter of 2017 was equal to the U.S. statutory tax rate of 35%.

[0000068505-18-000017:mdna:48]
[same as prior period, unchanged from 0000068505-17-000017:mdna:49]

[0000068505-18-000017:mdna:49]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $117 million, or $0.69 per diluted share, in the first quarter of 2018, compared to net earnings attributable to Motorola Solutions, Inc. of $77 million, or $0.45 per diluted share, in the first quarter of 2017.

[0000068505-18-000017:mdna:50]
The increase in net earnings and net earnings per diluted share in the first quarter of 2018, as compared to the first quarter of 2017, was primarily driven by: (i) higher sales in both the Products and Services segments, (ii) lower Other non-operating expenses, net, and (iii) lower income tax expense, partially offset by higher operating expenses.

[0000068505-18-000017:mdna:51]
[same as prior period, unchanged from 0000068505-17-000017:mdna:75]

[0000068505-18-000017:mdna:52]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three months ended March 31, 2018 and April 1, 2017, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-18-000017:mdna:53]
[same as prior period, unchanged from 0000068505-17-000017:mdna:77]

[0000068505-18-000017:mdna:54]
For both the first quarter of 2018 and 2017, the segment’s net sales represented 55% of our consolidated net sales.

[0000068505-18-000017:mdna:55]
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Segment net sales | $ | 801 |  |  | $ | 703 |  |  | 14 | % |
| Operating earnings | 89 |  |  | 88 |  |  | 1 | % |

[0000068505-18-000017:mdna:56]
Three months ended March 31, 2018 compared to three months ended April 1, 2017

[0000068505-18-000017:mdna:57]
The segment’s net sales increased $98 million, to $801 million in the first quarter of 2018, as compared to $703 million during the first quarter of 2017. The increase in the segment's net sales was driven by an increase in both Systems and Devices sales. Devices net sales increased in the Americas and EMEA. Systems net sales increased in EMEA and AP.

[0000068505-18-000017:mdna:58]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 76% of the segment’s net sales in the first quarter of 2018, compared to 75% of the segment's net sales in the first quarter of 2017.

[0000068505-18-000017:mdna:59]
The segment had operating earnings of $89 million in the first quarter of 2018, compared to $88 million in the first quarter of 2017. The increase in operating earnings in the first quarter of 2018 compared to the first quarter of 2017 was driven by higher net sales, offset by higher SG&A expenses, R&D expenditures, and Other charges.

[0000068505-18-000017:mdna:60]
[same as prior period, unchanged from 0000068505-17-000017:mdna:88]

[0000068505-18-000017:mdna:61]
For both the first quarter of 2018 and 2017, the segment’s net sales represented 45% of our consolidated net sales.

[0000068505-18-000017:mdna:62]
|  | Three Months Ended |  |  |
|  | March 31, 2018 |  | April 1, 2017 |  | % Change |
| Segment net sales | $ | 667 |  |  | $ | 578 |  |  | 15 | % |
| Operating earnings | 82 |  |  | 85 |  |  | (4 | )% |

[0000068505-18-000017:mdna:63]
Three months ended March 31, 2018 compared to three months ended April 1, 2017

[0000068505-18-000017:mdna:64]
The segment’s net sales increased $89 million, or 15%, to $667 million in the first quarter of 2018, as compared to $578 million in the first quarter of 2017. The increase in the segment's net sales was driven by Interexport, Kodiak Networks, and Plant, as well as growth in Managed & Support services absent of acquisitions in every region and Integration services absent of acquisitions in both the EMEA and AP. On a geographic basis, net sales for the first quarter of 2018 increased in every region, compared to the first quarter of 2017.

[0000068505-18-000017:mdna:65]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 59% of the segment’s net sales in the first quarter of 2018, compared to 58% of the segment’s net sales in the first quarter of 2017.

[0000068505-18-000017:mdna:66]
The segment had operating earnings of $82 million in the first quarter of 2018, compared to $85 million in the first quarter of 2017. The decrease in operating earnings in the first quarter of 2018 compared to the first quarter of 2017 was driven by higher SG&A expenses, R&D expenditures, and Other charges, offset by higher sales.

[0000068505-18-000017:mdna:67]
[same as prior period, unchanged from 0000068505-17-000017:mdna:99]

[0000068505-18-000017:mdna:68]
During the first quarter of 2018, we recorded net reorganization of business charges of $13 million including $8 million of charges recorded within Other charges and $5 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $13 million were charges of $22 million related to employee separation costs and $2 million related to exit costs, partially offset by $11 million of reversals for accruals no longer needed.

[0000068505-18-000017:mdna:69]
During the first quarter of 2017, we recorded net reorganization of business charges of $19 million including $15 million of charges recorded within Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $19 million were charges of $15 million related to employee separation costs and $4 million for exit costs.

[0000068505-18-000017:mdna:70]
[same as prior period, unchanged from 0000068505-17-000017:mdna:106]

[0000068505-18-000017:mdna:71]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Products | $ | 10 |  |  | $ | 13 |  |
| Services | 3 |  |  | 6 |  |
|  | $ | 13 |  |  | $ | 19 |  |

[0000068505-18-000017:mdna:72]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $15 million in the first quarter of 2018 and $30 million in the first quarter of 2017. The reorganization of business accruals at March 31, 2018 were $48 million, of which $39 million relate to employee separation costs that are expected to be paid within one year and $9 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-18-000017:mdna:73]
[same as prior period, unchanged from 0000068505-17-000017:mdna:109]

[0000068505-18-000017:mdna:74]
We decreased the aggregate of our cash and cash equivalent balances by $410 million from $1.3 billion as of December 31, 2017 to $858 million as of March 31, 2018. As highlighted in the condensed consolidated statements of cash flows, our liquidity and available capital resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0000068505-18-000017:mdna:75]
[same as prior period, unchanged from 0000068505-17-000017:mdna:111]

[0000068505-18-000017:mdna:76]
At March 31, 2018, $440 million of the $858 million cash and cash equivalents balance was held in the U.S. and approximately $418 million was held by us or our subsidiaries in other countries. Restricted cash was $63 million at March 31, 2018 and December 31, 2017.

[0000068505-18-000017:mdna:77]
[same as prior period, unchanged from 0000068505-17-000017:mdna:113]

[0000068505-18-000017:mdna:78]
Net cash used for operating activities in the first quarter of 2018 was $500 million, as compared to $142 million provided by operating activities in the first quarter of 2017. Operating cash flows in the first quarter of 2018, as compared to the first quarter of 2017, were negatively impacted by the $500 million contribution to our U.S. pension plan, higher incentive payments, higher tax payments and the recovery of financial receivables owed to us in the first quarter of 2017. The contribution to our U.S. pension plan moves the next anticipated required contribution to 2024, or beyond.

[0000068505-18-000017:mdna:79]
[same as prior period, unchanged from 0000068505-17-000017:mdna:115]

[0000068505-18-000017:mdna:80]
Net cash used by investing activities was $1.1 billion in the first quarter of 2018, compared to $121 million in the first quarter of 2017. The $1.1 billion of cash used in the first quarter of 2018 included: (i) $1.1 billion used for acquisitions and investments and (ii) $41 million in capital expenditures, partially offset by $77 million of proceeds from sales of investments and businesses. The cash usage of $121 million in the first quarter of 2017 consisted primarily of: (i) $106 million cash used for acquisitions and investments and (ii) $68 million in capital expenditures, partially offset by $53 million of proceeds from the sale of investments and businesses.

[0000068505-18-000017:mdna:81]
Acquisition and Investments:  We used net cash for acquisitions and investments of $1.1 billion during the first quarter of 2018 compared to $106 million in the first quarter of 2017. The cash used during the first quarter of 2018 was primarily used for the acquisitions of Avigilon for a total of $887 million, net of cash acquired, and Plant for total of $237 million, net of cash acquired. The cash used during the first quarter of 2017 was used for several debt and equity investments, including the acquisition of Interexport for $55 million, net of cash acquired.

[0000068505-18-000017:mdna:82]
Sales of Investments and Businesses:  We received $77 million of proceeds related to the sales of investments and businesses in the first quarter of 2018 compared to $53 million in the first quarter of 2017. The proceeds in the first quarter of 2018 primarily consisted of $60 million of excess cash withdrawn from company-sponsored life insurance investments. The proceeds from the first quarter of 2017 primarily consisted of the sales of various debt and equity investments.

[0000068505-18-000017:mdna:83]
Capital Expenditures:  Capital expenditures decreased in the first quarter of 2018 to $41 million, compared to $68 million in the first quarter of 2017. The decrease in capital expenditures was primarily related to lower information technology spend.

[0000068505-18-000017:mdna:84]
[same as prior period, unchanged from 0000068505-17-000017:mdna:122]

[0000068505-18-000017:mdna:85]
Net cash provided by financing activities was $1.1 billion in the first quarter of 2018, compared to $234 million used in the first quarter of 2017. Cash provided by financing activities in the first quarter of 2018 was primarily comprised of $1.3 billion of proceeds from the issuance of debt and $53 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, partially offset by: (i) $84 million of cash used for the payment of dividends, (ii) $66 million used for purchases under our share repurchase program, and (iii) $50 million used for the repayment of debt. Net cash used for financing activities in the first quarter of 2017 was primarily comprised of $178 million used for purchases under our share repurchase program and $77 million of cash used for the payment of dividends, partially offset by $22 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-18-000017:mdna:86]
Current and Long-Term Debt:  We had outstanding long-term debt of $5.8 billion and $4.5 billion, including the current portions of $492 million and $52 million at March 31, 2018 and December 31, 2017, respectively. In the acquisition of Avigilon, we assumed $75 million of debt, which was entirely made up of borrowings under Avigilon's credit facility and is classified as current debt. Immediately following the transaction, in advance of March 31, 2018, we repaid approximately $35 million of the acquired debt. Subsequent to the end of the first quarter of 2018, we repaid the remaining $40 million.

[0000068505-18-000017:mdna:87]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million and a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable quarterly. The weighted average borrowing rate for amounts outstanding during the quarter ended March 31, 2018 was 3.54%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-18-000017:mdna:88]
In February of 2018, we issued $500 million of 4.60% Senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan.

[0000068505-18-000017:mdna:89]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-18-000017:mdna:90]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. We continue to believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty, or volatility in the capital markets, or deterioration in our credit ratings, may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-18-000017:mdna:91]
Share Repurchase Program: During the three months ended March 31, 2018, we paid an aggregate of $66 million, including transaction costs, to repurchase approximately 0.6 million shares at an average price of $101.54 per share. As of March 31, 2018, the Company had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-18-000017:mdna:92]
Payment of Dividends: During the first quarter of 2018, we paid $84 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $84 million in cash dividends to holders of our common stock.

[0000068505-18-000017:mdna:93]
[same as prior period, unchanged from 0000068505-17-000017:mdna:129]

[0000068505-18-000017:mdna:94]
As of March 31, 2018, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"), of which $400 million was borrowed as of March 31, 2018 to facilitate the Avigilon acquisition. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The weighted average borrowing rate on outstanding amounts was 3.25%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of March 31, 2018.

[0000068505-18-000017:mdna:95]
[same as prior period, unchanged from 0000068505-17-000017:mdna:131]

[0000068505-18-000017:mdna:96]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $74 million at March 31, 2018, compared to $93 million at December 31, 2017.

[0000068505-18-000017:mdna:97]
[same as prior period, unchanged from 0000068505-17-000017:mdna:134]

[0000068505-18-000017:mdna:98]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended March 31, 2018 and April 1, 2017:

[0000068505-18-000017:mdna:99]
|  | Three Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |
| Accounts receivable sales proceeds | $ | 55 |  |  | $ | 19 |  |
| Long-term receivables sales proceeds | 13 |  |  | 46 |  |
| Total proceeds from sales of accounts receivable | $ | 68 |  |  | $ | 65 |  |

[0000068505-18-000017:mdna:100]
At March 31, 2018, the Company had retained servicing obligations for $848 million of long-term receivables, compared to $873 million at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000017:mdna:101]
Other Contingencies

[0000068505-18-000017:mdna:102]
[same as prior period, unchanged from 0000068505-17-000017:mdna:139]

[0000068505-18-000017:mdna:103]
[same as prior period, unchanged from 0000068505-17-000017:mdna:140]

[0000068505-18-000017:mdna:104]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at March 31, 2018.

[0000068505-18-000017:mdna:105]
[same as prior period, unchanged from 0000068505-17-000017:mdna:142]

[0000068505-18-000017:mdna:106]
[same as prior period, unchanged from 0000068505-17-000017:mdna:143]

[0000068505-18-000017:mdna:107]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. We have begun to assess the impact of the ASU on our financial statements and expect a material impact to our balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards. We have also begun to catalog our existing lease contracts and identify changes needed to systems and processes.

[0000068505-18-000017:mdna:108]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for us on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). We are currently assessing the impact of this ASU, including transition elections and required elections, on our consolidated financial statements.

[0000068505-18-000017:mdna:109]
Recently Adopted Accounting Pronouncements

[0000068505-18-000017:mdna:110]
We adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. We recognized $30 million related to the cumulative effect of applying the ASU as an adjustment to our opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, we will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-18-000017:mdna:111]
We adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. We have restated our comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of our net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. We reclassified $20 million and $3 million in the three months ended March 31, 2018 and April 1, 2017, respectively.

[0000068505-18-000017:mdna:112]
We adopted ASU No. 2014-09, "Revenue from Contracts with Customers", and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to our opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-18-000017:mdna:113]
We retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of our System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Managed & Support services contracts continue to be recognized ratably over relevant contract terms as we stand ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-18-000017:mdna:114]
Under the new standard, we identified distinct promises to transfer goods and/or services within our contracts. For contracts that are recognized under percentage of completion accounting, we considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts our system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within our system contracts, we continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-18-000017:mdna:115]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to a lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

[0000068505-18-000017:mdna:116]
Historically, we presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, we have determined that we are the principal in contracts that involve a third-party sales representative. Thus, we present associated revenues on a gross

[0000068505-18-000017:mdna:117]
basis, with the affect being an equal increase to selling, general and administrative expenses for our cost of third-party commissions.

[0000068505-18-000017:mdna:118]
Under prior accounting standards, we expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, we capitalize sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as a non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000017:mdna:119]
The new standard clarified the definition of a receivable and requires us to present our net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which we have received, or is due, consideration from a customer respectively. We reclassified our customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

[0000068505-18-000017:mdna:120]
39
