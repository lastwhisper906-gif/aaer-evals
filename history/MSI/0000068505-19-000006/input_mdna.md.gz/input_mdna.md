# MSI MD&A — 0000068505-19-000006


## mdna

[0000068505-19-000006:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-19-000006:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2018 and 2017 and results of operations for each of the three years in the period ended December 31, 2018. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-19-000006:mdna:3]
During the second quarter of 2018, we modified our internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership in part as a result of recent acquisitions contributing to the growth within the newly-aligned Services and Software segment. Previously, we had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration-related revenue and costs moving from the old Services segment into the newly-presented Products and Systems Integration segment and software-related revenue and costs moving from the old Products segment into the newly-presented Services and Software segment.

[0000068505-19-000006:mdna:4]
Executive Overview

[0000068505-19-000006:mdna:5]
Recent Acquisitions and Developments

[0000068505-19-000006:mdna:6]
On January 7, 2019, we announced that we acquired VaaS International Holdings, Inc. ("VaaS"), a "video analysis as a service" company that is a leading global provider of data and image analytics for vehicle location for a purchase price of $445 million. This acquisition expands our command center software portfolio.

[0000068505-19-000006:mdna:7]
We have reached an agreement with the U.K. Home Office on terms for the new direction of the U.K. Emergency Services Network (“ESN”) that we expect to sign in early 2019. During the fourth quarter of 2018, we signed an agreement to extend the Airwave contract through 2022 with substantially similar terms to the prior agreement.

[0000068505-19-000006:mdna:8]
On March 28, 2018, we completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million.

[0000068505-19-000006:mdna:9]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-19-000006:mdna:10]
On August 28, 2017, we completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk for commercial customers, for a purchase price of $225 million.

[0000068505-19-000006:mdna:11]
On March 13, 2017, we completed the acquisition of Interexport, a managed service provider of communications systems to public safety and commercial customers in Chile, for a purchase price of $98 billion Chilean pesos, or approximately $147 million.

[0000068505-19-000006:mdna:12]
On November 10, 2016, we completed the acquisition of Spillman Technologies ("Spillman"), a provider of comprehensive law enforcement and public safety software solutions, for a purchase price of $221 million. The acquisition expands our command center services and software portfolio and enables us to offer a full suite of solutions to a broader customer base.

[0000068505-19-000006:mdna:13]
On February 19, 2016, we completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which we invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt.

[0000068505-19-000006:mdna:14]
Our Business

[0000068505-19-000006:mdna:15]
Motorola Solutions is a leading global provider of mission-critical communications. Our technology platforms in communications, software, video, and services make cities safer and help communities and businesses thrive. At Motorola Solutions, we are ushering in a new era in public safety and security. We serve our customers with a global footprint of sales in more than 100 countries and 16,000 employees worldwide based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-19-000006:mdna:16]
We conduct our business globally and manage it by two segments:

[0000068505-19-000006:mdna:17]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, such as video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions typically managing a mobile workforce. In 2018, the segment’s net sales were $5.1 billion, representing 69% of our consolidated net sales.

[0000068505-19-000006:mdna:18]
Services and Software: The Services and Software segment provides a broad range of solution offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings

[0000068505-19-000006:mdna:19]
beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on premise and “as a service.” In 2018, the segment’s net sales were $2.2 billion, representing 31% of our consolidated net sales.

[0000068505-19-000006:mdna:20]
2018 Financial Results

[0000068505-19-000006:mdna:21]
| • | Net sales were $7.3 billion in 2018 compared to $6.4 billion in 2017 and grew in the Americas and EMEA. |

[0000068505-19-000006:mdna:22]
| • | Operating earnings were $1.3 billion in both 2018 and 2017. |

[0000068505-19-000006:mdna:23]
| • | Earnings attributable to Motorola Solutions, Inc. were $966 million, or $5.62 per diluted common share in 2018, compared to losses of $155 million, or $(0.95) per diluted common share in 2017. |

[0000068505-19-000006:mdna:24]
| • | Our operating cash flow decreased $271 million to $1.1 billion in 2018. The decrease is driven by the $500 million contribution to our U.S. pension plan, partially offset by higher earnings. |

[0000068505-19-000006:mdna:25]
| • | We returned $469 million of capital in the form of $132 million in share repurchases and $337 million in dividends in 2018 and invested $1.2 billion in acquisitions. |

[0000068505-19-000006:mdna:26]
| • | We increased our quarterly dividend by 10% to $0.57 per share in November 2018. |

[0000068505-19-000006:mdna:27]
| • | Ended 2018 with a backlog position of $10.6 billion, up $988 million compared to 2017. |

[0000068505-19-000006:mdna:28]
Segment Financial Highlights

[0000068505-19-000006:mdna:29]
| • | In the Products and Systems Integration segment, net sales were $5.1 billion in 2018, an increase of $587 million, or 13%, compared to $4.5 billion in 2017. On a geographic basis, net sales increased in the Americas and EMEA, partially offset by AP. Operating earnings were $854 million in 2018, compared to $969 million in 2017. Operating margin decreased in 2018 to 16.7% from 21.5% in 2017 driven by costs related to the closure of certain supply chain operations in Europe, an increase to an existing environmental reserve related to a legacy business, and higher expenses related to acquisitions. |

[0000068505-19-000006:mdna:30]
| • | In the Services and Software segment, net sales were $2.2 billion in 2018, an increase of $376 million, or 20%, compared to $1.9 billion in 2017. On a geographic basis, net sales increased in every region. The increase in net sales was driven by growth excluding acquisitions in both Services and Software and also including the acquisitions of Plant, Kodiak Networks, and Interexport. Operating earnings were $401 million in 2018, compared to $315 million in 2017. Operating margin increased in 2018 to 17.9% from 16.9% in 2017 on higher sales and gross margin. |

[0000068505-19-000006:mdna:31]
Looking Forward

[0000068505-19-000006:mdna:32]
Entering 2019, we believe we are well-positioned for continued leadership in mission-critical communications. Our technology platforms in communications, video, services, and software help make cities safer and enable communities and businesses to thrive. At Motorola Solutions, we are ushering in a new era in public safety and security. We are a leading provider of solutions that enable first responders, federal and local governments, as well as commercial customers, to communicate in everyday and extreme situations.

[0000068505-19-000006:mdna:33]
Our land mobile radio ("LMR") solutions are uniquely designed, built, and delivered for our customers’ specific needs, and we continue to expect LMR to be the preferred solution for our customers in the years ahead.

[0000068505-19-000006:mdna:34]
Our services and software business supplements our LMR business. As communication networks have become increasingly complex, software-centric, and data-driven, we have expanded our services offering to maintain, monitor, secure and manage our customers' networks. We expect continued growth for our value-added services going forward. Additionally, we have command center software solutions for the public safety workflow to serve the 6,000+ emergency call centers in North America. We have invested organically and via the acquisitions of Plant, Kodiak Networks and Spillman in 2018, 2017 and 2016, respectively, to add new capabilities to our command center software offering. These investments help improve efficiency for first responders by enabling them to make use of rich data content such as pictures, video, and text messages. From shorter response times to new applications such as proactive incident management, we are providing new capabilities with command center software solutions increasingly delivered as a service. Next Generation 9-1-1 is an important and growing movement that the U.S. and other countries are expected to continue prioritizing for investment. We expect our overall revenue mix to continue to shift towards services and software over time.

[0000068505-19-000006:mdna:35]
Our largest investment in 2018 was the acquisition of Avigilon and its video and analytics solutions, which are an increasingly powerful tool for first responders. Video devices, video management, video analytics software, and access control solutions for both government and commercial customers is a large and expanding market. There are video cameras deployed across airports, rail, streets, and public and private buildings that use advanced tools including artificial intelligence and machine learning to capture, analyze, and use all of this content in a meaningful way. Our offerings, including high-definition cameras, advanced video analytics, and video management solutions provide a scalable architecture that allow for easier and faster deployments than other point solutions that are in the marketplace today.

[0000068505-19-000006:mdna:36]
We remain committed to driving shareholder value with revenue growth, operating leverage, cash flow generation, and efficient capital deployment. Our framework for efficient capital deployment of cash flow from operations consists of approximately: (i) 50% for acquisitions or share repurchases, (ii) 30% for dividends, and (iii) 20% for investments in the business

[0000068505-19-000006:mdna:37]
through capital expenditures. We expect to continue a balanced approach in allocating capital through this framework. Our share repurchase program has approximately $1.6 billion of authority available as of December 31, 2018.

[0000068505-19-000006:mdna:38]
28

[0000068505-19-000006:mdna:39]
Results of Operations

[0000068505-19-000006:mdna:40]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2018 |  | % ofSales ** |  | 2017 |  | % ofSales ** |  | 2016 |  | % ofSales ** |
| Net sales from products | $ | 4,463 |  |  |  |  | $ | 3,772 |  |  |  |  | $ | 3,649 |  |  |  |
| Net sales from services | 2,880 |  |  |  |  | 2,608 |  |  |  |  | 2,389 |  |  |  |
| Net sales | 7,343 |  |  |  |  | 6,380 |  |  |  |  | 6,038 |  |  |  |
| Costs of product sales | 2,035 |  |  | 45.6 | % |  | 1,686 |  |  | 44.7 | % |  | 1,649 |  |  | 45.2 | % |
| Costs of services sales | 1,828 |  |  | 63.5 | % |  | 1,670 |  |  | 64.0 | % |  | 1,520 |  |  | 63.6 | % |
| Costs of sales | 3,863 |  |  | 52.6 | % |  | 3,356 |  |  | 52.6 | % |  | 3,169 |  |  | 52.5 | % |
| Gross margin | 3,480 |  |  | 47.4 | % |  | 3,024 |  |  | 47.4 | % |  | 2,869 |  |  | 47.5 | % |
| Selling, general and administrative expenses | 1,254 |  |  | 17.1 | % |  | 1,025 |  |  | 16.1 | % |  | 1,044 |  |  | 17.3 | % |
| Research and development expenditures | 637 |  |  | 8.7 | % |  | 568 |  |  | 8.9 | % |  | 553 |  |  | 9.2 | % |
| Other charges | 334 |  |  | 4.5 | % |  | 147 |  |  | 2.3 | % |  | 224 |  |  | 3.7 | % |
| Operating earnings | 1,255 |  |  | 17.1 | % |  | 1,284 |  |  | 20.1 | % |  | 1,048 |  |  | 17.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (222 | ) |  | (3.0 | )% |  | (201 | ) |  | (3.2 | )% |  | (205 | ) |  | (3.4 | )% |
| Gains (losses) on sales of investments and businesses, net | 16 |  |  | 0.2 | % |  | 3 |  |  | — | % |  | (6 | ) |  | (0.1 | )% |
| Other | 53 |  |  | 0.7 | % |  | (10 | ) |  | (0.2 | )% |  | 7 |  |  | 0.1 | % |
| Total other expense | (153 | ) |  | (2.1 | )% |  | (208 | ) |  | (3.3 | )% |  | (204 | ) |  | (3.4 | )% |
| Net earnings before income taxes | 1,102 |  |  | 15.0 | % |  | 1,076 |  |  | 16.9 | % |  | 844 |  |  | 14.0 | % |
| Income tax expense | 133 |  |  | 1.8 | % |  | 1,227 |  |  | 19.2 | % |  | 282 |  |  | 4.7 | % |
| Net earnings (loss) | 969 |  |  | 13.2 | % |  | (151 | ) |  | (2.4 | )% |  | 562 |  |  | 9.3 | % |
| Less: Earnings attributable to noncontrolling interests | 3 |  |  | — | % |  | 4 |  |  | 0.1 | % |  | 2 |  |  | — | % |
| Net earnings (loss)* | $ | 966 |  |  | 13.2 | % |  | $ | (155 | ) |  | (2.4 | )% |  | $ | 560 |  |  | 9.3 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings per diluted common share* | $ | 5.62 |  |  |  |  | $ | (0.95 | ) |  |  |  | $ | 3.24 |  |  |  |

[0000068505-19-000006:mdna:41]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-19-000006:mdna:42]
**    Percentages may not add due to rounding.

[0000068505-19-000006:mdna:43]
Geographic Market Sales by Locale of End Customer

[0000068505-19-000006:mdna:44]
|  | 2018 |  | 2017 |  | 2016 |
| Americas | 69 | % |  | 68 | % |  | 68 | % |
| EMEA | 22 | % |  | 21 | % |  | 21 | % |
| AP | 9 | % |  | 11 | % |  | 11 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-19-000006:mdna:45]
29

[0000068505-19-000006:mdna:46]
Results of Operations—2018 Compared to 2017

[0000068505-19-000006:mdna:47]
Net Sales

[0000068505-19-000006:mdna:48]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Net sales from Products and Systems Integration | $ | 5,100 |  |  | $ | 4,513 |  |  | 13 | % |
| Net sales from Services and Software | 2,243 |  |  | 1,867 |  |  | 20 | % |
| Net sales | $ | 7,343 |  |  | $ | 6,380 |  |  | 15 | % |

[0000068505-19-000006:mdna:49]
The Products and Systems Integration segment’s net sales represented 69% of our consolidated net sales in 2018, compared to 71% in 2017. The Services and Software segment’s net sales represented 31% of our consolidated net sales in 2018, compared to 29% in 2017.

[0000068505-19-000006:mdna:50]
Net sales were up $963 million, or 15%, compared to 2017. The increase in net sales was driven by the Americas and EMEA with a 13% increase in the Products and Systems Integration segment and a 20% increase in the Services and Software segment. This growth includes:

[0000068505-19-000006:mdna:51]
| • | $507 million of incremental revenue from the acquisitions of Avigilon and Plant in 2018 and Kodiak Networks and Interexport which were acquired during 2017; |

[0000068505-19-000006:mdna:52]
| • | $83 million from the adoption of Accounting Standards Codification ("ASC") 606 (see Note 1 of our consolidated financial statements); and |

[0000068505-19-000006:mdna:53]
| • | $32 million from favorable currency rates. |

[0000068505-19-000006:mdna:54]
Regional results include:

[0000068505-19-000006:mdna:55]
| • | the Americas grew 17% across all products within both the Products and Systems Integration and the Services and Software segments, inclusive of incremental revenue from acquisitions; |

[0000068505-19-000006:mdna:56]
| • | EMEA grew 18% on broad-based growth within all offerings within our Products and Systems Integration and Services and Software segments, inclusive of incremental revenue from acquisitions; and |

[0000068505-19-000006:mdna:57]
| • | AP was relatively flat with growth in the Services and Software segment offset by lower Products and Systems Integration revenue. |

[0000068505-19-000006:mdna:58]
Products and Systems Integration

[0000068505-19-000006:mdna:59]
The 13% growth in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000006:mdna:60]
| • | $318 million of incremental revenue from the acquisitions of Avigilon in 2018 and Interexport during 2017; |

[0000068505-19-000006:mdna:61]
| • | $78 million from the adoption of ASC 606; |

[0000068505-19-000006:mdna:62]
| • | Devices revenues were up significantly due to the acquisition of Avigilon along with strong demand in the Americas and EMEA; and |

[0000068505-19-000006:mdna:63]
| • | Systems and Systems Integration revenues increased 10% in 2018, as compared to 2017 driven by incremental revenue from Avigilon, as well as system deployments in EMEA and AP. |

[0000068505-19-000006:mdna:64]
Services and Software

[0000068505-19-000006:mdna:65]
The 20% growth in the Services and Software segment was driven by the following:

[0000068505-19-000006:mdna:66]
| • | $189 million of incremental revenue primarily from the acquisitions of Plant and Avigilon in 2018 and Kodiak Networks and Interexport during 2017; |

[0000068505-19-000006:mdna:67]
| • | $5 million from the adoption of ASC 606; |

[0000068505-19-000006:mdna:68]
| • | Services were up $174 million, or 9%, driven by growth in both maintenance and managed service revenues, and incremental revenue from the acquisitions of Interexport and Plant; and |

[0000068505-19-000006:mdna:69]
| • | Software was up $202 million, or 89%, driven primarily by incremental revenue from the acquisitions of Plant, Avigilon, and Kodiak Networks, and growth in our command center software suite. |

[0000068505-19-000006:mdna:70]
Gross Margin

[0000068505-19-000006:mdna:71]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Gross margin | $ | 3,480 |  |  | $ | 3,024 |  |  | 15 | % |

[0000068505-19-000006:mdna:72]
Gross margin was 47.4% of net sales in both 2018 and 2017. The primary drivers of increases, with offsetting decreases, are as follows:

[0000068505-19-000006:mdna:73]
| • | higher margins within the Services and Software segment primarily driven by operational improvements and efficiencies in service delivery costs of our Services portfolio and higher margin contribution within our Software portfolio from acquisitions; |

[0000068505-19-000006:mdna:74]
| • | lower margins in the Products and Systems Integration segment primarily driven by lower margin in Systems and Systems Integration due to certain large projects where we have taken an integrator role, partially offset by higher Devices volumes; and |

[0000068505-19-000006:mdna:75]
| • | $50 million of additional reorganization of business charges (see further detail in “Reorganization of Businesses” section) primarily associated with costs related to the closure of certain supply chain operations in Europe in 2018 as compared to 2017. |

[0000068505-19-000006:mdna:76]
Selling, General and Administrative Expenses

[0000068505-19-000006:mdna:77]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Selling, general and administrative expenses | $ | 1,254 |  |  | $ | 1,025 |  |  | 22 | % |

[0000068505-19-000006:mdna:78]
SG&A expenses increased 22% compared to 2017. SG&A expenses were 17.1% of net sales compared to 16.1% of net sales in 2017.

[0000068505-19-000006:mdna:79]
The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses, $72 million related to the change in classification of our third-party sales commissions from the adoption of ASC 606, and higher incentive compensation.

[0000068505-19-000006:mdna:80]
Research and Development Expenditures

[0000068505-19-000006:mdna:81]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Research and development expenditures | $ | 637 |  |  | $ | 568 |  |  | 12 | % |

[0000068505-19-000006:mdna:82]
R&D expenditures increased 12%. R&D expenditures were 8.7% of net sales compared to 8.9% of net sales in 2017. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-19-000006:mdna:83]
Other Charges

[0000068505-19-000006:mdna:84]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Other charges | $ | 334 |  |  | $ | 147 |  |

[0000068505-19-000006:mdna:85]
The Other charges in 2018 as compared to 2017 can be summarized as follows:

[0000068505-19-000006:mdna:86]
| • | $188 million of amortization of intangibles in 2018 compared to $151 million in 2017, driven by 2018 acquisitions; |

[0000068505-19-000006:mdna:87]
| • | $61 million of net reorganization of business charges in 2018 as compared to $33 million in 2017, with higher charges coming in 2018 as we continue to integrate acquisitions (see further detail in “Reorganization of Businesses” section); |

[0000068505-19-000006:mdna:88]
| • | a $57 million charge in 2018 related to ongoing remediation efforts for an environmental clean-up incurred by a legacy business (see Note 3 of our consolidated financial statements); |

[0000068505-19-000006:mdna:89]
| • | a gain of $47 million in 2017, related to the recovery of financial receivables owed to us by a former customer of a legacy business; and |

[0000068505-19-000006:mdna:90]
31

[0000068505-19-000006:mdna:91]
| • | $24 million of charges for acquisition-related transaction fees in 2018 as compared to $1 million in 2017. |

[0000068505-19-000006:mdna:92]
Operating Earnings

[0000068505-19-000006:mdna:93]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Operating earnings from Products and Systems Integration | $ | 854 |  |  | $ | 969 |  |
| Operating earnings from Services and Software | 401 |  |  | 315 |  |
| Operating earnings | $ | 1,255 |  |  | $ | 1,284 |  |

[0000068505-19-000006:mdna:94]
Operating earnings were down $29 million, or 2%, compared to 2017. The decrease in Operating earnings was due to:

[0000068505-19-000006:mdna:95]
| • | Products and Systems Integration was down $115 million from 2017 to 2018, driven by: (i) $69 million more reorganization of business expenses, (ii) environmental reserve expenses of $40 million in 2018, (iii) $28 million more intangible amortization driven by acquisitions, and (iv) $12 million of acquisition-related transaction fees; and |

[0000068505-19-000006:mdna:96]
| • | partially offset by the Services and Software segment, which was up $86 million from 2017 to 2018, driven by higher sales and partially offset by: (i) environmental reserve expenses of $17 million in 2018, (ii) $9 million more reorganization of business expenses, (iii) $9 million more intangible amortization from 2018 acquisitions, and (iv) $11 million more of acquisition-related transactions fees. |

[0000068505-19-000006:mdna:97]
Net Interest Expense

[0000068505-19-000006:mdna:98]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Interest expense, net | $ | (222 | ) |  | $ | (201 | ) |

[0000068505-19-000006:mdna:99]
The increase in net interest expense in 2018 compared to 2017 was a result of increases in outstanding debt:

[0000068505-19-000006:mdna:100]
| • | $500 million of Senior notes due in 2028, that were used to make a voluntary contribution to the U.S. pension plan, issued during the first quarter of 2018; |

[0000068505-19-000006:mdna:101]
| • | $400 million term loan due in 2021 ("the Term Loan") that was issued during the first quarter of 2018 and was used to complete the acquisition of Avigilon; |

[0000068505-19-000006:mdna:102]
| • | $400 million borrowed under our revolving credit facility at the end of the first quarter of 2018 and repaid throughout the year; and |

[0000068505-19-000006:mdna:103]
| • | $200 million of follow-on Senior notes due in 2028, issued in the third quarter of 2018, which were used to repurchase $200 million of Convertible Notes. |

[0000068505-19-000006:mdna:104]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-19-000006:mdna:105]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Gains (losses) on sales of investments and businesses, net | $ | 16 |  |  | $ | 3 |  |

[0000068505-19-000006:mdna:106]
The net gains in 2018 and 2017 were primarily related to the sales of various equity investments.

[0000068505-19-000006:mdna:107]
Other

[0000068505-19-000006:mdna:108]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Other income (expense) | $ | 53 |  |  | $ | (10 | ) |

[0000068505-19-000006:mdna:109]
The net Other income in 2018 as compared to 2017 was primarily comprised of:

[0000068505-19-000006:mdna:110]
| • | $75 million of net periodic pension and postretirement benefit in 2018 as compared to $46 million in 2017; |

[0000068505-19-000006:mdna:111]
| • | $48 million of losses on settlements within our U.K. defined benefit plan during 2017 with no activity in 2018; |

[0000068505-19-000006:mdna:112]
| • | $11 million of favorable fair value adjustments to investments; |

[0000068505-19-000006:mdna:113]
32

[0000068505-19-000006:mdna:114]
| • | a $6 million gain from the repurchase of $200 million of our Convertible Notes in 2018, |

[0000068505-19-000006:mdna:115]
| • | foreign currency losses of $24 million in 2018 as compared to $31 million of losses in 2017; and |

[0000068505-19-000006:mdna:116]
| • | a $14 million loss on derivative instruments in 2018, as compared to a gain of $15 million in 2017. |

[0000068505-19-000006:mdna:117]
Effective Tax Rate

[0000068505-19-000006:mdna:118]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Income tax expense | $ | 133 |  |  | $ | 1,227 |  |

[0000068505-19-000006:mdna:119]
Income tax expense decreased by $1.1 billion compared to 2017, for an effective tax rate of 12%. Our effective tax rate for 2018 was lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-19-000006:mdna:120]
| • | a $79 million benefit related to updates of the provisional amounts on the impact of the Tax Act; and |

[0000068505-19-000006:mdna:121]
| • | a $30 million benefit due to the recognition of excess tax benefits on share-based compensation. |

[0000068505-19-000006:mdna:122]
Our effective tax rate in 2017 was 114% primarily due to the implementation of Tax Act. As a result of the Tax Act we recorded $874 million of non-recurring charges, primarily related to:

[0000068505-19-000006:mdna:123]
| • | a $471 million valuation allowance against U.S. foreign tax credit carryforwards; and |

[0000068505-19-000006:mdna:124]
| • | income tax expense of $366 million from the remeasurement of our deferred tax balances at the lower federal tax rate of 21%. |

[0000068505-19-000006:mdna:125]
Excluding the income tax effects from the Tax Act, our effective tax rate was lower than the 2017 U.S. statutory tax rate of 35% (see Note 6 of our consolidated financial statements).

[0000068505-19-000006:mdna:126]
Results of Operations—2017 Compared to 2016

[0000068505-19-000006:mdna:127]
Net Sales

[0000068505-19-000006:mdna:128]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |  | % Change |
| Net sales from Products and Systems Integration | $ | 4,513 |  |  | $ | 4,394 |  |  | 3 | % |
| Net sales from Services and Software | 1,867 |  |  | 1,644 |  |  | 14 | % |
| Net sales | $ | 6,380 |  |  | $ | 6,038 |  |  | 6 | % |

[0000068505-19-000006:mdna:129]
The Products and Systems Integration segment’s net sales represented 71% of our consolidated net sales in 2017, compared to 73% in 2016. The Services and Software segment’s net sales represented 29% of our consolidated net sales in 2017, compared to 27% in 2016.

[0000068505-19-000006:mdna:130]
Net sales were up $342 million, or 6%, compared to 2016. The increase in net sales is reflective of growth in every region with a 3% increase in the Products and Systems Integration segment and a 14% increase in the Services and Software segment. The growth includes:

[0000068505-19-000006:mdna:131]
| • | $186 million of incremental revenue from the acquisitions of Interexport and Kodiak Networks in 2017 and Spillman and Airwave which were acquired during 2016; and |

[0000068505-19-000006:mdna:132]
| • | $8 million from favorable currency rates. |

[0000068505-19-000006:mdna:133]
Regional results include:

[0000068505-19-000006:mdna:134]
| • | the Americas grew 7% due to increases in the Services and Software segment, inclusive of incremental revenue from acquisitions, as well as in Systems and System Integration, offset by a slight decrease in Device revenues; |

[0000068505-19-000006:mdna:135]
| • | EMEA grew 5% across all portfolios within our Products and Systems Integration segment, as well as within our Services and Software segment, inclusive of incremental revenues from Airwave; and |

[0000068505-19-000006:mdna:136]
| • | AP grew 1% due to increases in both Devices and Systems and Systems Integration within our Products and Systems Integration segment, partially offset by a slight decrease in our Services and Software segment. |

[0000068505-19-000006:mdna:137]
Products and Systems Integration

[0000068505-19-000006:mdna:138]
The 3% growth in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000006:mdna:139]
| • | Systems and Systems Integration revenues increased 5% in 2017 as compared to 2016 driven by system deployments in the Americas and $19 million of incremental revenue from the acquisition of Interexport in 2017; and |

[0000068505-19-000006:mdna:140]
33

[0000068505-19-000006:mdna:141]
| • | an increase in Devices in every region. |

[0000068505-19-000006:mdna:142]
Services and Software

[0000068505-19-000006:mdna:143]
The 14% growth in the Services and Software segment was driven by the following:

[0000068505-19-000006:mdna:144]
| • | $167 million of incremental revenue from the acquisitions of Interexport and Kodiak Networks in 2017 and Spillman and Airwave in 2016; |

[0000068505-19-000006:mdna:145]
| • | Services were up $128 million, or 8%, driven by incremental revenue from the acquisitions of Interexport and Airwave as well as growth in maintenance services and managed service revenues; and |

[0000068505-19-000006:mdna:146]
| • | Software was up $95 million, or 72%, driven primarily by incremental revenue from the acquisitions of Spillman and Kodiak Networks, in addition to higher command center software sales not attributed to acquisitions. |

[0000068505-19-000006:mdna:147]
Gross Margin

[0000068505-19-000006:mdna:148]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |  | % Change |
| Gross margin | $ | 3,024 |  |  | $ | 2,869 |  |  | 5 | % |

[0000068505-19-000006:mdna:149]
Gross margin was 47.4% of net sales compared to 47.5% of net sales in 2016. The primary drivers of the decrease are:

[0000068505-19-000006:mdna:150]
| • | lower margins within the Services and Software segment driven by the acquisition of Interexport which is a managed services provider with lower gross margins than the segment total; partially offset by higher gross margin associated with the Spillman acquisition; and |

[0000068505-19-000006:mdna:151]
| • | lower margins within the Products and Systems Integration segment driven by a slight decline in our Devices margins due to product mix, partially offset by higher margins within our Systems and Systems Integration portfolio due to a favorable mix of projects. |

[0000068505-19-000006:mdna:152]
Selling, General and Administrative Expenses

[0000068505-19-000006:mdna:153]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |  | % Change |
| Selling, general and administrative expenses | $ | 1,025 |  |  | $ | 1,044 |  |  | (2 | )% |

[0000068505-19-000006:mdna:154]
SG&A expenses decreased 2% compared to 2016. SG&A expenses were 16.1% of net sales compared to 17.3% of net sales in 2016.

[0000068505-19-000006:mdna:155]
The decrease in SG&A expenses is primarily due to cost savings initiatives, partially offset by higher expenses associated with acquired businesses.

[0000068505-19-000006:mdna:156]
Research and Development Expenditures

[0000068505-19-000006:mdna:157]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |  | % Change |
| Research and development expenditures | $ | 568 |  |  | $ | 553 |  |  | 3 | % |

[0000068505-19-000006:mdna:158]
R&D expenditures increased 3% compared to 2016. R&D expenditures were 8.9% of net sales compared to 9.2% of net sales in 2016. The increase in R&D expenditures is primarily due to higher expenses associated with acquired businesses.

[0000068505-19-000006:mdna:159]
Other Charges

[0000068505-19-000006:mdna:160]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |
| Other charges | $ | 147 |  |  | $ | 224 |  |

[0000068505-19-000006:mdna:161]
The decrease in Other charges in 2017 as compared to 2016 can be summarized as follows:

[0000068505-19-000006:mdna:162]
| • | $33 million of reorganization of business charges in 2017 as compared to $97 million including a $17 million building impairment and a $3 million impairment of our corporate aircraft in 2016; |

[0000068505-19-000006:mdna:163]
| • | a gain of $47 million in 2017 related to the recovery of financial receivables owed to us by a former customer of a legacy business; |

[0000068505-19-000006:mdna:164]
| • | $1 million of acquisition related transaction fees in 2017 as compared to $13 million in 2016; and |

[0000068505-19-000006:mdna:165]
| • | partially offset by $151 million of amortization of intangibles in 2017 compared to $113 million in 2016, driven primarily by 2017 acquisitions. |

[0000068505-19-000006:mdna:166]
Operating Earnings

[0000068505-19-000006:mdna:167]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |
| Operating earnings from Products and Systems Integration | $ | 969 |  |  | $ | 762 |  |
| Operating earnings from Services and Software | 315 |  |  | 286 |  |
| Operating earnings | $ | 1,284 |  |  | $ | 1,048 |  |

[0000068505-19-000006:mdna:168]
Operating earnings were up $236 million, or 23%, compared to 2016. The increase in Operating earnings was due to the following:

[0000068505-19-000006:mdna:169]
| • | Products and Systems Integration was up $207 million from 2016 to 2017, primarily driven by: (i) $73 million less reorganization of business expenses, (ii) $33 million of income related to the recovery of financial receivables owed to us by a former customer of a legacy business, (iii) higher earnings, and (iv) lower SG&A and R&D expenses; and |

[0000068505-19-000006:mdna:170]
| • | Services and Software was up $29 million from 2016 to 2017, primarily driven by: (i) higher earnings, (ii) $23 million less reorganization of business expenses, (iii) $14 million of income related to the recovery of financial receivables owed to us by a former customer of a legacy business, and (iv) $12 million less acquisition-related transaction fees, partially offset by $37 million more intangible amortization driven by acquisitions. |

[0000068505-19-000006:mdna:171]
Net Interest Expense

[0000068505-19-000006:mdna:172]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |
| Interest expense, net | $ | (201 | ) |  | $ | (205 | ) |

[0000068505-19-000006:mdna:173]
The decrease in net interest expense in 2017 compared to 2016 was a result of lower average outstanding debt balances in 2017 as compared to 2016, as a result of the repayment of our $675 million term loan in December 2016.

[0000068505-19-000006:mdna:174]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-19-000006:mdna:175]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |
| Gains (losses) on sales of investments and businesses, net | $ | 3 |  |  | $ | (6 | ) |

[0000068505-19-000006:mdna:176]
The net gains in 2017 were primarily related to the sales of various equity investments. The net losses in 2016 consisted primarily of:

[0000068505-19-000006:mdna:177]
| • | a $19 million loss on the sale of an investment in U.K. treasury securities liquidated in order to purchase Airwave; |

[0000068505-19-000006:mdna:178]
| • | a $7 million loss from the sale of our Malaysia manufacturing operations; and |

[0000068505-19-000006:mdna:179]
| • | partially offset by $20 million of gains on the sales of equity investments. |

[0000068505-19-000006:mdna:180]
35

[0000068505-19-000006:mdna:181]
Other

[0000068505-19-000006:mdna:182]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |
| Other income (expense) | $ | (10 | ) |  | $ | 7 |  |

[0000068505-19-000006:mdna:183]
The increase in net Other income (expense) in 2017 as compared to 2016 was primarily comprised of:

[0000068505-19-000006:mdna:184]
| • | $48 million of losses on settlements within our U.K. defined benefit plan in 2017 compared to $26 million in 2016; |

[0000068505-19-000006:mdna:185]
| • | foreign currency losses of $31 million in 2017 compared to $46 million of gains in 2016; |

[0000068505-19-000006:mdna:186]
| • | a $46 million net periodic pension and postretirement benefit in 2017 compared to $45 million in 2016; |

[0000068505-19-000006:mdna:187]
| • | a $15 million gain on derivative instruments in 2017 compared to a $56 million loss in 2016; and |

[0000068505-19-000006:mdna:188]
| • | a $10 million foreign currency loss on British Pounds purchased and held in anticipation of the acquisition of Airwave in 2016. |

[0000068505-19-000006:mdna:189]
Effective Tax Rate

[0000068505-19-000006:mdna:190]
|  | Years ended December 31 |
| (In millions) | 2017 |  | 2016 |
| Income tax expense | $ | 1,227 |  |  | $ | 282 |  |

[0000068505-19-000006:mdna:191]
Income tax expense increased by $945 million compared to 2016, for an effective tax rate of 114% primarily due to the effects of the Tax Act. As a result of the Tax Act we recorded $874 million of non-recurring charges that included the following:

[0000068505-19-000006:mdna:192]
| • | a $471 million valuation allowance against U.S. foreign tax credit carryforwards; and |

[0000068505-19-000006:mdna:193]
| • | income tax expense of $366 million from the remeasurement of our deferred tax balances at the lower federal tax rate of 21%. |

[0000068505-19-000006:mdna:194]
Excluding the income tax effects from the Tax Act, our effective tax rate was lower than the U.S. statutory tax rate of 35%.

[0000068505-19-000006:mdna:195]
Our effective tax rate of 33% in 2016 was lower than the U.S. statutory tax rate of 35% primarily due to lower tax rates on non-U.S. income (see Note 6 of our consolidated financial statements).

[0000068505-19-000006:mdna:196]
Reorganization of Businesses

[0000068505-19-000006:mdna:197]
In 2018, we recorded net reorganization of business charges of $120 million relating to the separation of 1,200 employees, of which 700 were indirect employees and 500 were direct employees. The $120 million of charges included $59 million recorded to Cost of sales and $61 million recorded to Other charges. Included in the aggregate $120 million are charges of $122 million for employee separation costs and $16 million for exit costs, partially offset by $18 million of reversals for accruals no longer needed.

[0000068505-19-000006:mdna:198]
During 2017, we recorded net reorganization of business charges of $42 million relating to the separation of 400 employees, of which 300 were indirect employees and 100 were direct employees. The $42 million of charges included $9 million recorded to Cost of sales and $33 million recorded to Other charges. Included in the aggregate $42 million are charges of$43 million for employee separation costs and $8 million for exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-19-000006:mdna:199]
During 2016, we recorded net reorganization of business charges of $140 million relating to the separation of 1,300 employees, of which 900 were indirect employees and 400 were direct employees. The $140 million of charges included $43 million recorded to Cost of sales and $97 million recorded to Other charges. Included in the aggregate $140 million are charges of: (i) $120 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-19-000006:mdna:200]
During 2018, 2017, and 2016 we continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. As a result, we communicated our plan to close one of our manufacturing facilities in Europe during the fourth quarter of 2018, resulting in a charge of $44 million and impacting 165 employees primarily within the Products and Systems Integration segment. The remainder of the initiatives impacted both of our segments and affected employees located in all geographic regions.

[0000068505-19-000006:mdna:201]
The following table displays the net charges incurred by business segment:

[0000068505-19-000006:mdna:202]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Products and Systems Integration | $ | 101 |  |  | $ | 32 |  |  | $ | 107 |  |
| Services and Software | 19 |  |  | 10 |  |  | 33 |  |
|  | $ | 120 |  |  | $ | 42 |  |  | $ | 140 |  |

[0000068505-19-000006:mdna:203]
Cash payments for exit costs and employee severance in connection with the reorganization of business plans were $65 million, $93 million, and $79 million in 2018, 2017, and 2016, respectively. The reorganization of business accruals at December 31, 2018 were $105 million, of which $84 million relates to employee separation costs that are expected to be paid within one year and $21 million relates primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-19-000006:mdna:204]
Liquidity and Capital Resources

[0000068505-19-000006:mdna:205]
|  | Years Ended December 31 |
|  | 2018 |  | 2017 |  | 2016 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 1,075 |  |  | $ | 1,346 |  |  | $ | 1,165 |  |
| Investing activities | (1,266 | ) |  | (448 | ) |  | (1,002 | ) |
| Financing activities | 220 |  |  | (722 | ) |  | (1,042 | ) |
| Effect of exchange rates on cash, cash equivalents, and restricted cash | (40 | ) |  | 62 |  |  | (71 | ) |
| Increase (decrease) in cash, cash equivalents, and restricted cash | $ | (11 | ) |  | $ | 238 |  |  | $ | (950 | ) |

[0000068505-19-000006:mdna:206]
Cash and Cash Equivalents

[0000068505-19-000006:mdna:207]
At December 31, 2018, $750 million of the $1.3 billion cash and cash equivalents balance was held in the U.S. and $507 million was held by us or our subsidiaries in other countries, with approximately $147 million held in the United Kingdom. Restricted cash was approximately $11 million at December 31, 2018 and $63 million at December 31, 2017. During the year ended December 31, 2018, restricted cash decreased from $63 million to $11 million due to the completion of a settlement related to our legacy Networks business.

[0000068505-19-000006:mdna:208]
In 2018, we repatriated approximately $502 million in cash to the U.S. from international jurisdictions. Undistributed earnings that we intend to reinvest indefinitely, and for which no U.S. income taxes have been provided for, except the tax effect of the Tax Act deemed repatriation, aggregate to $1.5 billion at December 31, 2018. We currently have no plans to repatriate the foreign earnings permanently reinvested. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-19-000006:mdna:209]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy.  While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-19-000006:mdna:210]
Operating Activities

[0000068505-19-000006:mdna:211]
The decrease in operating cash flows from 2017 to 2018 was driven by (see additional discussion under "Sales of Receivables" below):

[0000068505-19-000006:mdna:212]
| • | a $500 million debt-funded voluntary contribution to our U.S. pension plan in the first quarter of 2018, compared to no material contributions to our U.S. pension plans in 2017; |

[0000068505-19-000006:mdna:213]
| • | a $51 million payment out of restricted cash related to a settlement arising from a legacy business in 2018, as compared to the recovery of $47 million of financial receivables owed to us by a former customer of a legacy business in 2017; |

[0000068505-19-000006:mdna:214]
| • | $28 million of higher interest payments driven by additional debt issued in 2018 as compared to 2017; and |

[0000068505-19-000006:mdna:215]
| • | partially offset by higher earnings in 2018 as compared to 2017. |

[0000068505-19-000006:mdna:216]
The increase in operating cash flows from 2016 to 2017 was driven by:

[0000068505-19-000006:mdna:217]
| • | higher operating earnings in 2017 as compared to 2016; |

[0000068505-19-000006:mdna:218]
| • | improved net working capital in 2017 as compared to 2016; and |

[0000068505-19-000006:mdna:219]
| • | partially offset by $56 million of higher tax payments in 2017 as compared to 2016 when we received certain refunds in the U.S. and foreign jurisdictions. |

[0000068505-19-000006:mdna:220]
We do not expect to make any material contributions to our pension plans in 2019.

[0000068505-19-000006:mdna:221]
Investing Activities

[0000068505-19-000006:mdna:222]
The increase in net cash used by investing activities from 2017 to 2018 was primarily due to:

[0000068505-19-000006:mdna:223]
| • | a $760 million increase in acquisitions and investments, primarily driven by the purchases of Avigilon and Plant Holdings for $903 million, and $237 million, respectively, as compared to 2017 when we made acquisitions of Kodiak Networks and Interexport for $225 million and $55 million, respectively; and |

[0000068505-19-000006:mdna:224]
| • | $88 million of lower proceeds from sales of investments and businesses, driven by the $60 million of excess cash withdrawn from company-sponsored life insurance investments in 2018, as compared to $183 million of cash received from short-term government securities that were previously maintained in foreign countries in 2017; and |

[0000068505-19-000006:mdna:225]
| • | partially offset by $30 million lower capital expenditures in 2018 as compared 2017, due to lower information technology ("IT") spend as we completed our ERP implementation in 2017, as well as lower facilities spend. |

[0000068505-19-000006:mdna:226]
The decrease in net cash used by investing activities from 2016 to 2017 was primarily due to:

[0000068505-19-000006:mdna:227]
| • | a $1.1 billion decrease in acquisitions and investments, driven by the purchase of Airwave for $1.0 billion and $217 million for Spillman in 2016, as compared to 2017 when we made acquisitions of Kodiak Networks and Interexport for $225 million and $55 million, respectively; |

[0000068505-19-000006:mdna:228]
| • | a $487 million decrease in sales of investments and businesses, driven by the liquidation of $382 million of short-term government securities used to acquire Airwave, the sale of $242 million of short-term debt and equity securities, and $46 million from the sale of our Penang, Malaysia supply chain operations to an outsourced manufacturer in 2016, as compared to the sale of $183 million of short-term government securities previously maintained in foreign countries; |

[0000068505-19-000006:mdna:229]
| • | a decrease in capital spending in 2017 from 2016 driven by lower facilities spend as we completed refresh activities around our regional and corporate headquarters, lower spend on customer networks, and partially offset by higher IT expenditures as we worked towards the completion of our ERP implementation in 2017; and |

[0000068505-19-000006:mdna:230]
| • | a decrease in sales of property, plant, and equipment driven by proceeds received in 2016 of $73 million from the sale of buildings and land associated with the sale of our Schaumburg campus and the sale of our aging corporate aircraft. |

[0000068505-19-000006:mdna:231]
Financing Activities

[0000068505-19-000006:mdna:232]
The increase in cash provided by financing activities in 2018 as compared to 2017 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" below):

[0000068505-19-000006:mdna:233]
| • | the issuance of $500 million of 4.60% Senior notes due 2028 in the first quarter of 2018, of which the proceeds were contributed to our U.S. pension plan; |

[0000068505-19-000006:mdna:234]
| • | we entered into the Term Loan for $400 million in the first quarter of 2018 with a maturity date of March 26, 2021 to complete the acquisition of Avigilon; |

[0000068505-19-000006:mdna:235]
| • | $400 million borrowing from our revolving credit facility in the first quarter of 2018 to complete the acquisition of Avigilon, repaying the full $400 million throughout 2018; |

[0000068505-19-000006:mdna:236]
| • | in the third quarter of 2018, we issued an additional $200 million on the outstanding 4.60% Senior notes due in 2028, of which the proceeds were used to repurchase $200 million of our outstanding convertible note with Silver Lake Partners; |

[0000068505-19-000006:mdna:237]
| • | $169 million of cash was used during the third quarter of 2018 to pay the conversion premium on the repurchase of our convertible note with Silver Lake Partners; |

[0000068505-19-000006:mdna:238]
| • | $76 million used in the fourth quarter of 2018 to pay a contractually-defined deferred purchase price of Airwave; |

[0000068505-19-000006:mdna:239]
| • | $168 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2018, as compared to $82 million in 2017; |

[0000068505-19-000006:mdna:240]
| • | $337 million of cash used for the payment of dividends in 2018 as compared to $307 million in 2017; and |

[0000068505-19-000006:mdna:241]
| • | partially offset by $132 million used for purchases under our share repurchase program in 2018 as compared to $483 million in 2017. |

[0000068505-19-000006:mdna:242]
The decrease in cash used for financing activities in 2017, as compared to 2016 was driven by:

[0000068505-19-000006:mdna:243]
| • | $483 million used for purchases under our share repurchase program in 2017, as compared to $842 million in 2016; |

[0000068505-19-000006:mdna:244]
| • | a $675 million term loan issued in 2016 to complete the purchase of Airwave, of which the entire term loan was repaid by the end of 2016; and |

[0000068505-19-000006:mdna:245]
| • | partially offset by $307 million of cash used for the payment of dividends in 2017, as compared to $280 million in 2016. |

[0000068505-19-000006:mdna:246]
Sales of Receivables

[0000068505-19-000006:mdna:247]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables. Servicing obligations are limited to collection activities for sold accounts receivable and long-term receivables.

[0000068505-19-000006:mdna:248]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2018, 2017, and 2016:

[0000068505-19-000006:mdna:249]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Accounts receivable sales proceeds | $ | 77 |  |  | $ | 193 |  |  | $ | 51 |  |
| Long-term receivables sales proceeds | 270 |  |  | 284 |  |  | 289 |  |
| Total proceeds from receivable sales | $ | 347 |  |  | $ | 477 |  |  | $ | 340 |  |

[0000068505-19-000006:mdna:250]
The proceeds of our receivable sales are included in "Operating Activities" within our Consolidated Statements of Cash Flows.

[0000068505-19-000006:mdna:251]
At December 31, 2018, the Company had retained servicing obligations for $970 million of long-term receivables, compared to $873 million of long-term receivables at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-19-000006:mdna:252]
Debt

[0000068505-19-000006:mdna:253]
We had outstanding long-term debt of $5.3 billion and $4.5 billion, including the current portions of $31 million and $52 million, at December 31, 2018 and December 31, 2017, respectively.

[0000068505-19-000006:mdna:254]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a Term Loan for $400 million with a maturity date of March 26, 2021. Interest on the Term Loan is variable, indexed to London Inter-bank Offered Rate ("LIBOR"), and paid monthly. The weighted average borrowing rate for amounts outstanding during the year ended December 31, 2018 was 3.47%. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-19-000006:mdna:255]
In February of 2018, we issued $500 million of 4.60% Senior notes due in 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan.

[0000068505-19-000006:mdna:256]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.0% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.8252, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a published conversion price of $67.45 per share). The exercise price adjusts automatically for dividends. On September 5, 2018, we agreed with Silver Lake Partners to repurchase $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. As of December 31, 2018, we paid $369 million of cash to Silver Lake Partners. Of the $369 million paid to Silver Lake Partners, $169 million was paid during the third quarter of 2018 using cash on the balance sheet and the remaining $200 million was paid on October 15, 2018. The $200 million that was paid during the fourth quarter was from the additional $200 million issued on the outstanding 4.60% Senior notes due in 2028. We settled the issuance of the additional Senior notes on October 5, 2018 and received net proceeds of $196 million. In the event of an additional conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-19-000006:mdna:257]
In connection with the completion of the acquisition of Airwave, we entered into a term loan with an initial principal amount of $675 million. We repaid all amounts borrowed under this term loan as of December 31, 2016.

[0000068505-19-000006:mdna:258]
Credit Facilities

[0000068505-19-000006:mdna:259]
As of December 31, 2018, we had a $2.2 billion unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, we borrowed $400 million under the facility to complete the Avigilon acquisition. The entire $400 million was re-paid during the year ended December 31, 2018. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2018. No letters of credit were issued under the revolving credit facility as of December 31, 2018.

[0000068505-19-000006:mdna:260]
Share Repurchase Program

[0000068505-19-000006:mdna:261]
Through a series of actions, the board of directors has authorized an aggregate share repurchase amount of up to $14.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2018, we have used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $1.6 billion of authority available for future repurchases.

[0000068505-19-000006:mdna:262]
Our share repurchases, including transaction costs, for 2018, 2017, and 2016 can be summarized as follows:

[0000068505-19-000006:mdna:263]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Aggregate Amount (in millions) |
| 2018 | 1.2 |  |  | $ | 112.42 |  |  | $ | 132 |  |
| 2017 | 5.7 |  |  | 85.32 |  |  | 483 |  |
| 2016 | 12.0 |  |  | 70.28 |  |  | 842 |  |

[0000068505-19-000006:mdna:264]
Subsequent to the year ended December 31, 2018, the Company paid an aggregate of $125 million, including transaction costs, to repurchase 1.1 million shares at an average purchase price of $116.04 per share, leaving approximately $1.5 billion of authority available for future repurchases.

[0000068505-19-000006:mdna:265]
Dividends

[0000068505-19-000006:mdna:266]
We paid cash dividends to holders of our common stock of $337 million in 2018, $307 million in 2017, and $280 million in 2016. Subsequent to quarter end, we paid an additional $93 million in cash dividends to holders of our common stock.

[0000068505-19-000006:mdna:267]
Adequate Internal Funding Resources

[0000068505-19-000006:mdna:268]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our $2.2 billion revolving credit facility.

[0000068505-19-000006:mdna:269]
Contractual Obligations and Other Purchase Commitments

[0000068505-19-000006:mdna:270]
Summarized in the table and text below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2018.

[0000068505-19-000006:mdna:271]
|  | Payments Due by Period |
| (in millions) | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations, gross | $ | 5,382 |  |  | $ | 31 |  |  | $ | 801 |  |  | $ | 810 |  |  | $ | 767 |  |  | $ | 604 |  |  | $ | — |  |  | $ | 2,369 |  |
| Lease obligations | 722 |  |  | 131 |  |  | 120 |  |  | 112 |  |  | 101 |  |  | 54 |  |  | — |  |  | 204 |  |
| Purchase obligations* | 124 |  |  | 92 |  |  | 16 |  |  | 12 |  |  | 3 |  |  | 1 |  |  | — |  |  | — |  |
| Tax obligations | 76 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |
| Total contractual obligations | $ | 6,304 |  |  | $ | 265 |  |  | $ | 937 |  |  | $ | 934 |  |  | $ | 871 |  |  | $ | 659 |  |  | $ | 65 |  |  | $ | 2,573 |  |

[0000068505-19-000006:mdna:272]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-19-000006:mdna:273]
Lease Obligations:  We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations, net of minimum sublease rentals, totaled $722 million. Rental expense, net of sublease income, was $108 million in 2018, $94 million in 2017, and $84 million in 2016.

[0000068505-19-000006:mdna:274]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. We had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2023. The total payments expected to be made under these agreements are $124 million, of which $113 million relate to take-or-pay obligations from arrangements with suppliers for the sourcing of inventory supplies and materials. We do not anticipate the cancellation of any of our take or pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-19-000006:mdna:275]
Tax Obligations:  We have approximately $76 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve

[0000068505-19-000006:mdna:276]
months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $10 million tax charge to a $30 million tax benefit, with cash payments not expected to exceed $20 million.

[0000068505-19-000006:mdna:277]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take-or-pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-19-000006:mdna:278]
We outsource certain corporate functions, such as benefit administration and information technology-related services, under third-party contracts, the longest of which is expected to expire in 2023. Our remaining payments under these contracts are approximately $114 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in penalties substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-19-000006:mdna:279]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance bonds, bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. At December 31, 2018, outstanding Performance Bonds totaled approximately $2.5 billion, compared to $2.4 billion at December 31, 2017. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-19-000006:mdna:280]
Off-Balance Sheet Arrangements:  At December 31, 2018, we had no significant off-balance sheet arrangements other than operating leases and guarantees to third parties as described in Note 11 to the consolidated financial statements and our obligation to settle the embedded conversion option under the Senior Convertible Notes described in Note 4 to the consolidated financial statements.

[0000068505-19-000006:mdna:281]
Other Contingencies

[0000068505-19-000006:mdna:282]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-19-000006:mdna:283]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us. Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 18 months, and for amounts not in excess of a percentage of the contract value.

[0000068505-19-000006:mdna:284]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on our consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-19-000006:mdna:285]
Long-term Customer Financing Commitments

[0000068505-19-000006:mdna:286]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $62 million at December 31, 2018, compared to $93 million at December 31, 2017.

[0000068505-19-000006:mdna:287]
Outstanding Long-Term Receivables:  We had non-current long-term receivables of $24 million at December 31, 2018, compared to $19 million at December 31, 2017. There were no allowances for losses in 2018 and 2017. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 8.46%.

[0000068505-19-000006:mdna:288]
Critical Accounting Policies

[0000068505-19-000006:mdna:289]
Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-19-000006:mdna:290]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-19-000006:mdna:291]
Revenue Recognition

[0000068505-19-000006:mdna:292]
We enter into arrangements which consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we generally allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-19-000006:mdna:293]
We account for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, we have determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on our customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-19-000006:mdna:294]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. Adjustments to Estimated Costs at Completion were not significant to operating earnings for the years 2018, 2017, and 2016. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-19-000006:mdna:295]
Retirement Benefits

[0000068505-19-000006:mdna:296]
Our benefit obligations and net periodic pension cost (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions.  The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-19-000006:mdna:297]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-19-000006:mdna:298]
There are various assumptions used in calculating the net periodic cost (benefit) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.   We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-19-000006:mdna:299]
42

[0000068505-19-000006:mdna:300]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost and the net retirement health care expense. Our investment return assumption for the U.S. Pension Benefit Plans was 6.95% in both 2018 and 2017. Our investment return assumption for the Postretirement Health Care Benefits Plan was 7.00% in both 2018 and 2017. Our weighted average investment return assumption for the Non-U.S. Plans was 5.18% in 2018 and 5.20% in 2017. At December 31, 2018, the pension plans, including the U.S. Pension Benefit Plans and Non-U.S. Plans investment portfolios were comprised of approximately 28% equity investments, while the Postretirement Health Care Benefits Plan was all comprised of approximately 31% equity investments.

[0000068505-19-000006:mdna:301]
A second key assumption is the discount rate. The discount rate assumptions used for pension benefits and Postretirement Health Care Benefits Plan reflects, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 4.47% and 3.79% at December 2018 and 2017, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 2.67% and 2.34% at December 2018 and 2017, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 4.29% and 3.62% at December 31, 2018 and 2017, respectively.

[0000068505-19-000006:mdna:302]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from ten to thirty-one years. Prior service costs are being amortized over periods ranging from two to five years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-19-000006:mdna:303]
Valuation and Recoverability of Goodwill

[0000068505-19-000006:mdna:304]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: adverse changes in macroeconomic conditions, adverse changes in the industry or market in which we transact, changes in cost factors negatively impacting earnings and cash flows, negative or declining overall financial performance, events affecting the carrying value or composition of a reporting unit, or a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-19-000006:mdna:305]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Services and Software segments are comprised of three and two reporting units, respectively. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal years 2018, 2017, and 2016, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-19-000006:mdna:306]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-19-000006:mdna:307]
We use the asset and liability method of accounting for income taxes. Under this method, income tax expense is recognized for the amount of taxes payable or refundable for the current year.  In addition, deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Management makes assumptions, judgments and estimates to determine our current and deferred tax provision and also the deferred tax assets and liabilities. We evaluate our deferred tax assets quarterly to determine if adjustments to our valuation allowance are required based on the consideration of all available positive and negative evidence.

[0000068505-19-000006:mdna:308]
Our assumptions, judgments and estimates for computing the income tax provision takes into account current tax laws, our interpretation of current tax law and possible outcomes of current and future audits conducted by foreign and domestic tax authorities. We believe such estimates to be reasonable; however, the final determination of any of the audits could significantly impact the amounts provided for income taxes in our financial statements.

[0000068505-19-000006:mdna:309]
Recent Accounting Pronouncements

[0000068505-19-000006:mdna:310]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842”; ASU No. 2018-10, “Codification Improvements to Topic 842, Leases”; and ASU No. 2018-11, “Targeted Improvements.” The new standard establishes a right-of-use ("ROU") model that requires a lessee to recognize a ROU asset

[0000068505-19-000006:mdna:311]
and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement.

[0000068505-19-000006:mdna:312]
The ASU is effective for us on January 1, 2019. A modified retrospective transition approach is required, applying the new standard to all leases existing at the date of initial application. An entity may choose to use either the effective date or the beginning of the earliest comparative period presented in the financial statements as its date of initial application. We will adopt the new standard on January 1, 2019 and use the effective date as the date of initial application. Consequently, financial information will not be updated and disclosures required under the new standard will not be provided for dates and periods before January 1, 2019.

[0000068505-19-000006:mdna:313]
The new standard provides for a number of optional practical expedients in transition. We will elect the practical expedients, which permit us to not reassess prior conclusions about lease identification, lease classification and initial direct costs under the new standard. We do not expect to elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised.

[0000068505-19-000006:mdna:314]
The new standard also provides practical expedients for an entity’s ongoing accounting. We currently expect to elect the short-term lease recognition exemption for all leases that qualify. This means, for those leases that qualify, we will not recognize ROU assets or lease liabilities, and this includes not recognizing ROU assets or lease liabilities for existing short-term leases in transition. We also currently expect to elect the practical expedient to not separate lease and non-lease components for all leases.

[0000068505-19-000006:mdna:315]
We are continuing to assess the impact of the ASU on our consolidated financial statements, required disclosures, and changes to internal controls. Based on the work completed, we expect to recognize additional operating lease liabilities ranging from $600 million to $650 million, with corresponding ROU assets of the same amount based on the present value of the remaining minimum rental payments determined under current leasing standards for existing operating leases less accumulated impairment losses.

[0000068505-19-000006:mdna:316]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-19-000006:mdna:317]
Recently Adopted Accounting Pronouncements

[0000068505-19-000006:mdna:318]
We early adopted ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" on December 1, 2018, using the modified retrospective method of adoption. The ASU requires a cumulative effect adjustment to the opening balance of retained earnings as of the beginning of the fiscal year of adoption for the previously recorded ineffectiveness included in retained earnings related to existing net investment hedges as of the date of adoption. We did not record a cumulative effect adjustment to retained earnings as no net investment hedges existed as of the ASU adoption date. New hedging relationships entered after the adoption date have been presented in the financial statements using the guidance of the ASU. There were no material changes to our financial statements from the adoption of the ASU.

[0000068505-19-000006:mdna:319]
We adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. We recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to our opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, we will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-19-000006:mdna:320]
We adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. We have restated our comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of our net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. We reclassified $75 million of benefits, $2 million of expense, and $19 million of benefits in the years ended December 31, 2018, 2017 and 2016, respectively.

[0000068505-19-000006:mdna:321]
We adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to our opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-19-000006:mdna:322]
We have retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of our Systems and Systems Integration contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be

[0000068505-19-000006:mdna:323]
recognized ratably over relevant contract terms as we stand ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-19-000006:mdna:324]
Under the new standard, we identified distinct promises to transfer goods and services within our contracts. For system contracts that are recognized under percentage of completion accounting, we have considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts our system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within our system contracts, we continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-19-000006:mdna:325]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

[0000068505-19-000006:mdna:326]
Historically, we presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, we have determined that we are the principal in contracts that involve a third-party sales representative. Thus, under the new standard, we present associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for our cost of third-party commissions.

[0000068505-19-000006:mdna:327]
Under prior accounting standards, we expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, we capitalize sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-19-000006:mdna:328]
The new standard clarified the definition of a receivable and requires us to present our net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which we have received, or are due, consideration from a customer. We reclassified our customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

[0000068505-19-000006:mdna:329]
Forward-Looking Statements

[0000068505-19-000006:mdna:330]
receivable and the terms and amounts of such sales, (v) the outcome and effect of ongoing and future legal proceedings, (w) the impact of the loss of key customers, (x) the expected effective tax rate and deductibility of certain items, and (y) the impact of the adoption of accounting pronouncements on our retained earnings; and (5) “Quantitative and Qualitative Disclosures about Market Risk,” about: (a) the impact of foreign currency exchange risks, (b) future hedging activity and expectations of the Company, and (c) the ability of counterparties to financial instruments to perform their obligations.

[0000068505-19-000006:mdna:331]
Some of the risk factors that affect our business and financial results are discussed in “Item 1A: Risk Factors.” We caution the reader that the risk factors discussed in “Item 1A: Risk Factors,” and those described elsewhere in this report or in our other Securities and Exchange Commission filings, could cause our actual results to differ materially from those stated in the forward-looking statements.

[0000068505-19-000006:mdna:332]
46
