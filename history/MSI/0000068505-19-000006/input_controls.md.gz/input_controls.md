# MSI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000068505-19-000006:item_9a:1]
Item 9A. Controls and Procedures

[0000068505-19-000006:item_9a:2]
Evaluation of Disclosure Controls and Procedures.

[0000068505-19-000006:item_9a:3]
Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of the end of the period covered by this annual report (the “Evaluation Date”). Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (“SEC”) reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-19-000006:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting.

[0000068505-19-000006:item_9a:5]
Motorola Solutions’ management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Rule 13a-15(f) of the Exchange Act. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we assessed the effectiveness of our internal control over financial reporting as of December 31, 2018, using the criteria set forth in the Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based on this assessment, management has concluded that our internal control over financial reporting is effective as of December 31, 2018.

[0000068505-19-000006:item_9a:6]
On March 28, 2018 the Company completed the acquisition of Avigilon Corporation. As permitted for recently acquired businesses, management has excluded the acquired business from its assessment of internal control over financial reporting. The excluded Avigilon Corporation business represents 12.6% of total assets and 5.2% of net sales related to the consolidated financial statements amounts, as of and for the year ended December 31, 2018.

[0000068505-19-000006:item_9a:7]
The Company’s independent registered public accounting firm, KPMG LLP, has issued a report on the Company’s internal control over financial reporting. The report on the audit of internal control over financial reporting appears in this Form 10-K.

[0000068505-19-000006:item_9a:8]
Changes in Internal Control Over Financial Reporting.

[0000068505-19-000006:item_9a:9]
Effective January 1, 2018, we adopted the new revenue standard ASC 606. We have implemented new accounting processes related to revenue recognition and related disclosures, including related control activities. There have been no changes in our internal control over financial reporting that occurred during the quarter ended December 31, 2018, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.
