# MSI notes — 0000068505-19-000006


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-19-000006:notes:1]
Investments consist of the following:

[0000068505-19-000006:notes:2]
| December 31 | 2018 |  | 2017 |
| Corporate bonds | $ | 1 |  |  | $ | 2 |  |
| Common stock | 19 |  |  | 13 |  |
| Strategic investments, at cost | 62 |  |  | 78 |  |
| Company-owned life insurance policies | 75 |  |  | 141 |  |
| Equity method investments | 12 |  |  | 13 |  |
|  | $ | 169 |  |  | $ | 247 |  |


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-19-000006:notes:3]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-19-000006:notes:4]
| December 31 | 2018 |  | 2017 |
| Long-term receivables, gross | $ | 33 |  |  | $ | 37 |  |
| Less allowance for losses | (2 | ) |  | — |  |
| Long-term receivables | $ | 31 |  |  | $ | 37 |  |
| Less current portion | (7 | ) |  | (18 | ) |
| Non-current long-term receivables | $ | 24 |  |  | $ | 19 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-19-000006:notes:5]
Long-term Financing and Sales of Receivables

[0000068505-19-000006:notes:6]
Long-term Financing

[0000068505-19-000006:notes:7]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized Interest income on long-term receivables of $1 million, $1 million, and $2 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0000068505-19-000006:notes:8]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $62 million at December 31, 2018, compared to $93 million at December 31, 2017.

[0000068505-19-000006:notes:9]
Sales of Receivables

[0000068505-19-000006:notes:10]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements. The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-19-000006:notes:11]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2018, 2017 and 2016.

[0000068505-19-000006:notes:12]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Accounts receivable sales proceeds | $ | 77 |  |  | $ | 193 |  |  | $ | 51 |  |
| Long-term receivables sales proceeds | 270 |  |  | 284 |  |  | 289 |  |
| Total proceeds from receivable sales | $ | 347 |  |  | $ | 477 |  |  | $ | 340 |  |

[0000068505-19-000006:notes:13]
At December 31, 2018, the Company had retained servicing obligations for $970 million of long-term receivables, compared to $873 million of long-term receivables at December 31, 2017. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-19-000006:notes:14]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-19-000006:notes:15]
An aging analysis of financing receivables at December 31, 2018 and December 31, 2017 is as follows:

[0000068505-19-000006:notes:16]
| December 31, 2018 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 22 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 11 |  |  | — |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 33 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |

[0000068505-19-000006:notes:17]
| December 31, 2017 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 21 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |
| Commercial loans and leases secured | 16 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 37 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 3 |  |

[0000068505-19-000006:notes:18]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.

[0000068505-19-000006:notes:19]
The Company’s policy for valuing the allowance for credit losses is to review all customer financing receivables for collectability on an individual receivable basis. For those receivables where collection risk is probable, the Company calculates the value of impairment based on the net present value of expected future cash flows from the customer.


## msi:OtherChargesTableTextBlock

[0000068505-19-000006:notes:20]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-19-000006:notes:21]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 14) | $ | 188 |  |  | $ | 151 |  |  | $ | 113 |  |
| Reorganization of businesses (Note 13) | 61 |  |  | 33 |  |  | 77 |  |
| Loss (gain) on legal settlements | 3 |  |  | (1 | ) |  | — |  |
| Asset impairments | 1 |  |  | 10 |  |  | 21 |  |
| Environmental reserve expense | 57 |  |  | — |  |  | — |  |
| Gain on the recovery of financial receivables | — |  |  | (47 | ) |  | — |  |
| Acquisition-related transaction fees | 24 |  |  | 1 |  |  | 13 |  |
|  | $ | 334 |  |  | $ | 147 |  |  | $ | 224 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-19-000006:notes:22]
The following table displays the net charges incurred by segment:

[0000068505-19-000006:notes:23]
| Year ended December 31 | 2017 |
| Products and Systems Integration | $ | 32 |  |
| Services and Software | 10 |  |
|  | $ | 42 |  |

[0000068505-19-000006:notes:24]
| Year ended December 31 | 2016 |
| Products and Systems integration | $ | 107 |  |
| Services and Software | 33 |  |
|  | $ | 140 |  |

[0000068505-19-000006:notes:25]
| Year ended December 31 | 2018 |
| Products and Systems Integration | $ | 101 |  |
| Services and Software | 19 |  |
|  | $ | 120 |  |


## msi:ScheduleOfAccumulatedBenefitObligationsForPlansTableTextBlock

[0000068505-19-000006:notes:26]
The accumulated benefit obligations for the plans were as follows:

[0000068505-19-000006:notes:27]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |
| December 31 | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Accumulated benefit obligation | $ | 4,864 |  |  | $ | 5,235 |  |  | $ | 1,649 |  |  | $ | 1,838 |  |


## msi:ScheduleOfCorporateRelatedExpensesAndAssetsTableTextBlock

[0000068505-19-000006:notes:28]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-19-000006:notes:29]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| Products and Systems Integration | $ | 72 |  |  | $ | 113 |  |  | $ | 104 |  |  | $ | 71 |  |  | $ | 69 |  |  | $ | 72 |  |
| Services and Software | 125 |  |  | 114 |  |  | 167 |  |  | 101 |  |  | 123 |  |  | 110 |  |
|  | $ | 197 |  |  | $ | 227 |  |  | $ | 271 |  |  | $ | 172 |  |  | $ | 192 |  |  | $ | 182 |  |


## msi:ScheduleOfDefinedBenefitPlanTargetandActualAssetAllocationTableTextBlock

[0000068505-19-000006:notes:30]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-19-000006:notes:31]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 30 | % |  | 31 | % |  | 32 | % |  | 35 | % |
| Fixed income securities | 51 | % |  | 49 | % |  | 49 | % |  | 44 | % |
| Cash and other investments | 19 | % |  | 20 | % |  | 19 | % |  | 21 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 28 | % |  | 29 | % |  | 31 | % |  | 34 | % |
| Fixed income securities | 50 | % |  | 49 | % |  | 48 | % |  | 44 | % |
| Cash and other investments | 22 | % |  | 22 | % |  | 21 | % |  | 22 | % |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-19-000006:notes:32]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-19-000006:notes:33]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 11 |  |  | $ | 9 |  |  | $ | 9 |  |
| Selling, general and administrative expenses | 45 |  |  | 43 |  |  | 45 |  |
| Research and development expenditures | 17 |  |  | 14 |  |  | 14 |  |
| Share-based compensation expense included in Operating earnings | 73 |  |  | 66 |  |  | 68 |  |
| Tax benefit | 18 |  |  | 22 |  |  | 21 |  |
| Share-based compensation expense, net of tax | $ | 55 |  |  | $ | 44 |  |  | $ | 47 |  |
| Decrease in basic earnings per share | $ | (0.34 | ) |  | $ | (0.27 | ) |  | $ | (0.28 | ) |
| Decrease in diluted earnings per share | $ | (0.32 | ) |  | $ | (0.27 | ) |  | $ | (0.27 | ) |


## msi:ScheduleOfExpectedFutureServiceBenefitPaymentsTableTextBlock

[0000068505-19-000006:notes:34]
The following benefit payments are expected to be paid:

[0000068505-19-000006:notes:35]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2019 | $ | 144 |  |  | $ | 47 |  |  | $ | 7 |  |
| 2020 | 161 |  |  | 48 |  |  | 7 |  |
| 2021 | 181 |  |  | 50 |  |  | 6 |  |
| 2022 | 203 |  |  | 51 |  |  | 6 |  |
| 2023 | 224 |  |  | 52 |  |  | 5 |  |
| 2024-2028 | 1,418 |  |  | 277 |  |  | 23 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-19-000006:notes:36]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-19-000006:notes:37]
|  | 2018 |  | 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 510 |  |  | $ | 38 |  |  | $ | 12 |  |  | $ | 8 |  |
| Services and Software | 1,209 |  |  | 451 |  |  | 1,171 |  |  | 314 |  |
|  | $ | 1,719 |  |  | $ | 489 |  |  | $ | 1,183 |  |  | $ | 322 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-19-000006:notes:38]
Other liabilities consist of the following:

[0000068505-19-000006:notes:39]
| December 31 | 2018 |  | 2017 |
| Defined benefit plans (Note 7) | $ | 1,557 |  |  | $ | 2,019 |  |
| Non-current contract liabilities (Note 2) | 214 |  |  | — |  |
| Deferred revenue (Note 1) | — |  |  | 169 |  |
| Unrecognized tax benefits (Note 6) | 51 |  |  | 54 |  |
| Deferred income taxes (Note 6) | 201 |  |  | 115 |  |
| Other | 277 |  |  | 228 |  |
|  | $ | 2,300 |  |  | $ | 2,585 |  |


## msi:ScheduleOfPensionAndPostretirementHealthCarePlanAssetsTextBlockTableTextBlock

[0000068505-19-000006:notes:40]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2018 and 2017 were as follows:

[0000068505-19-000006:notes:41]
U.S. Pension Benefit Plans

[0000068505-19-000006:notes:42]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Commingled funds | 2,074 |  |  | — |  |  | 2,074 |  |
| Government fixed income securities | 13 |  |  | 340 |  |  | 353 |  |
| Corporate fixed income securities | — |  |  | 964 |  |  | 964 |  |
| Short-term investment funds | 243 |  |  | — |  |  | 243 |  |
| Total investment securities | $ | 2,340 |  |  | $ | 1,304 |  |  | $ | 3,644 |  |
| Accrued income receivable |  |  |  |  | 16 |  |
| Cash |  |  |  |  | 13 |  |
| Fair value plan assets |  |  |  |  | $ | 3,673 |  |

[0000068505-19-000006:notes:43]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Commingled funds | 2,198 |  |  | — |  |  | 2,198 |  |
| Government fixed income securities | 10 |  |  | 285 |  |  | 295 |  |
| Corporate fixed income securities | — |  |  | 900 |  |  | 900 |  |
| Short-term investment funds | 186 |  |  | — |  |  | 186 |  |
| Total investment securities | $ | 2,404 |  |  | $ | 1,185 |  |  | $ | 3,589 |  |
| Accrued income receivable |  |  |  |  | 12 |  |
| Cash |  |  |  |  | 13 |  |
| Fair value plan assets |  |  |  |  | $ | 3,614 |  |

[0000068505-19-000006:notes:44]
Non-U.S. Pension Benefit Plans

[0000068505-19-000006:notes:45]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 140 |  |  | $ | — |  |  | $ | 140 |  |
| Commingled funds | 476 |  |  | 16 |  |  | 492 |  |
| Government fixed income securities | 4 |  |  | 647 |  |  | 651 |  |
| Short-term investment funds | 60 |  |  | — |  |  | 60 |  |
| Total investment securities | $ | 680 |  |  | $ | 663 |  |  | $ | 1,343 |  |
| Cash |  |  |  |  | 3 |  |
| Accrued income receivable |  |  |  |  | 42 |  |
| Insurance contracts |  |  |  |  | 50 |  |
| Fair value plan assets |  |  |  |  | $ | 1,438 |  |

[0000068505-19-000006:notes:46]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 136 |  |  | $ | — |  |  | $ | 136 |  |
| Commingled funds | 431 |  |  | 38 |  |  | 469 |  |
| Government fixed income securities | 3 |  |  | 779 |  |  | 782 |  |
| Short-term investment funds | 92 |  |  | — |  |  | 92 |  |
| Total investment securities | $ | 662 |  |  | $ | 817 |  |  | $ | 1,479 |  |
| Cash |  |  |  |  | 3 |  |
| Accrued income receivable |  |  |  |  | 55 |  |
| Insurance contracts |  |  |  |  | 53 |  |
| Fair value plan assets |  |  |  |  | $ | 1,590 |  |

[0000068505-19-000006:notes:47]
Postretirement Health Care Benefits Plan

[0000068505-19-000006:notes:48]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Commingled funds | $ | 74 |  |  | $ | — |  |  | $ | 74 |  |
| Government fixed income securities | — |  |  | 12 |  |  | 12 |  |
| Corporate fixed income securities | — |  |  | 34 |  |  | 34 |  |
| Short-term investment funds | 9 |  |  | — |  |  | 9 |  |
| Total investment securities | $ | 83 |  |  | $ | 46 |  |  | $ | 129 |  |
| Cash |  |  |  |  | $ | 4 |  |
| Fair value plan assets |  |  |  |  | $ | 133 |  |

[0000068505-19-000006:notes:49]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Commingled funds | 92 |  |  | — |  |  | 92 |  |
| Government fixed income securities | — |  |  | 12 |  |  | 12 |  |
| Corporate fixed income securities | — |  |  | 38 |  |  | 38 |  |
| Short-term investment funds | 8 |  |  | — |  |  | 8 |  |
| Fair value plan assets | $ | 101 |  |  | $ | 50 |  |  | $ | 151 |  |


## msi:ScheduleOfStatusOfCompanyPensionPlansTableTextBlock

[0000068505-19-000006:notes:50]
The status of the Company’s plans is as follows:

[0000068505-19-000006:notes:51]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 5,235 |  |  | $ | 4,644 |  |  | $ | 1,844 |  |  | $ | 1,791 |  |  | $ | 85 |  |  | $ | 83 |  |
| Service cost | — |  |  | — |  |  | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Interest cost | 186 |  |  | 185 |  |  | 38 |  |  | 40 |  |  | 2 |  |  | 3 |  |
| Plan amendments | — |  |  | — |  |  | 10 |  |  | — |  |  | — |  |  | — |  |
| Settlement | — |  |  | — |  |  | — |  |  | (201 | ) |  | — |  |  | — |  |
| Actuarial loss (gain) | (452 | ) |  | 502 |  |  | (97 | ) |  | 52 |  |  | (8 | ) |  | 6 |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (98 | ) |  | 193 |  |  | — |  |  | — |  |
| Benefit payments | (105 | ) |  | (96 | ) |  | (46 | ) |  | (34 | ) |  | (7 | ) |  | (7 | ) |
| Benefit obligation at December 31 | $ | 4,864 |  |  | $ | 5,235 |  |  | $ | 1,654 |  |  | $ | 1,844 |  |  | $ | 72 |  |  | $ | 85 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,614 |  |  | $ | 3,195 |  |  | $ | 1,590 |  |  | $ | 1,565 |  |  | $ | 151 |  |  | $ | 136 |  |
| Return on plan assets | (339 | ) |  | 512 |  |  | (28 | ) |  | 96 |  |  | (12 | ) |  | 21 |  |
| Company contributions | 503 |  |  | 3 |  |  | 8 |  |  | 7 |  |  | — |  |  | — |  |
| Settlements | — |  |  | — |  |  | — |  |  | (201 | ) |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (88 | ) |  | 157 |  |  | — |  |  | — |  |
| Benefit payments | (105 | ) |  | (96 | ) |  | (44 | ) |  | (34 | ) |  | (6 | ) |  | (6 | ) |
| Fair value at December 31 | $ | 3,673 |  |  | $ | 3,614 |  |  | $ | 1,438 |  |  | $ | 1,590 |  |  | $ | 133 |  |  | $ | 151 |  |
| Funded status of the plan | $ | (1,191 | ) |  | $ | (1,621 | ) |  | $ | (216 | ) |  | $ | (254 | ) |  | $ | 61 |  |  | $ | 66 |  |
| Unrecognized net loss | 2,329 |  |  | 2,229 |  |  | 543 |  |  | 518 |  |  | 74 |  |  | 64 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | 11 |  |  | — |  |  | (35 | ) |  | (49 | ) |
| Prepaid pension cost | $ | 1,138 |  |  | $ | 608 |  |  | $ | 338 |  |  | $ | 264 |  |  | $ | 100 |  |  | $ | 81 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3 | ) |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (1,188 | ) |  | (1,618 | ) |  | (265 | ) |  | (294 | ) |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 49 |  |  | 40 |  |  | 61 |  |  | 66 |  |
| Deferred income taxes | 561 |  |  | 544 |  |  | 55 |  |  | 58 |  |  | 10 |  |  | 6 |  |
| Accumulated other comprehensive loss | 1,768 |  |  | 1,685 |  |  | 499 |  |  | 460 |  |  | 29 |  |  | 9 |  |
| Prepaid pension cost | $ | 1,138 |  |  | $ | 608 |  |  | $ | 338 |  |  | $ | 264 |  |  | $ | 100 |  |  | $ | 81 |  |


## msi:ScheduleOfSummaryOfOpenTaxYearsByMajorJurisdictionTableTextBlock

[0000068505-19-000006:notes:52]
A summary of open tax years by major jurisdiction is presented below:

[0000068505-19-000006:notes:53]
| Jurisdiction | Tax Years |
| United States | 2014-2018 |
| Australia | 2012-2018 |
| Canada | 2014-2018 |
| Germany | 2011-2018 |
| India | 1997-2018 |
| Israel | 2015-2018 |
| Poland | 2014-2018 |
| Malaysia | 2012-2018 |
| United Kingdom | 2017 |


## msi:ScheduleOfTaxCutsAndJobsActof2017IncompleteAccountingProvisionalIncomeTaxExpenseBenefitTableTextBlock

[0000068505-19-000006:notes:54]
For the year ended December 31, 2018, the Company has recorded the following adjustments to the previously recorded provisional tax amounts:

[0000068505-19-000006:notes:55]
|  | December 31, 2018 | December 31, 2017 | Adjustment | Financial Statement Location |
| Valuation allowance on foreign tax credit carryforward | $ | 400 |  | $ | 471 |  | $ | (71 | ) | Deferred tax expense |
| Re-measurement of U.S. deferred tax balances at 21% | 353 |  | 366 |  | (13 | ) | Deferred tax expense |
| Transition tax on repatriation of foreign earnings | 18 |  | 16 |  | 2 |  | Current tax expense |
| Uncertain tax positions on foreign operations | 21 |  | 21 |  | — |  | Current tax expense |
| Disallowed deduction of covered employees' incentive plans | 3 |  | — |  | 3 |  | Deferred tax expense |
| Total | $ | 795 |  | $ | 874 |  | $ | (79 | ) |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineBenefitObligationsForPlansTableTextBlock

[0000068505-19-000006:notes:56]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-19-000006:notes:57]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Discount rate | 4.47 | % |  | 3.79 | % |  | 2.67 | % |  | 2.34 | % |  | 4.29 | % |  | 3.62 | % |
| Future compensation increase rate | n/a |  |  | n/a |  |  | 0.52 | % |  | 0.52 | % |  | n/a |  |  | n/a |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineCostsForPlansTableTextBlock

[0000068505-19-000006:notes:58]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-19-000006:notes:59]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Discount rate | 3.57 | % |  | 4.02 | % |  | 2.08 | % |  | 2.22 | % |  | 3.16 | % |  | 3.29 | % |
| Investment return assumption | 6.95 | % |  | 6.95 | % |  | 5.18 | % |  | 5.20 | % |  | 7.00 | % |  | 7.00 | % |


## msi:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanEmployeeStockOptionsValuationAssumptionsTableTextBlock

[0000068505-19-000006:notes:60]
The following assumptions were used for the calculations.

[0000068505-19-000006:notes:61]
|  | 2018Performance Options |  | 2017Performance Options |  | 2016Performance Options |
| Expected volatility of common stock | 25.0 | % |  | 24.1 | % |  | 25.3 | % |
| Expected volatility of the S&P 500 | 25.3 | % |  | 25.6 | % |  | 19.8 | % |
| Risk-free interest rate | 2.7 | % |  | 2.4 | % |  | 1.7 | % |
| Dividend yield | 3.1 | % |  | 3.7 | % |  | 2.8 | % |
| Expected life (years) | 6.5 |  |  | 6.5 |  |  | 6.5 |  |

[0000068505-19-000006:notes:62]
|  | 2018Market Stock Units |  | 2017Market Stock Units |  | 2016Market Stock Units |
| Expected volatility of common stock | 25.0 | % |  | 24.1 | % |  | 24.2 | % |
| Risk-free interest rate | 2.4 | % |  | 1.7 | % |  | 1.1 | % |
| Dividend yield | 2.2 | % |  | 2.9 | % |  | 2.8 | % |

[0000068505-19-000006:notes:63]
|  | 2017 PCSOs |
| Expected volatility of common stock | 24.1 | % |
| Risk-free interest rate | 1.8 | % |
| Dividend yield | 3.0 | % |
| Expected life (years) | 3.5 |  |


## msi:ShareBasedCompensationCostsPolicyTextBlock

[0000068505-19-000006:notes:64]
The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance-based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.


## msi:ValuationAndQualifyingAccountsTableTextBlock

[0000068505-19-000006:notes:65]
The following table presents the valuation and qualifying account activity for the years ended December 31, 2018, 2017, and 2016:

[0000068505-19-000006:notes:66]
|  | Balance atJanuary 1 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31 |
| 2018 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 45 |  |  | $ | 37 |  |  | $ | (30 | ) |  | $ | (1 | ) |  | $ | 51 |  |
| Inventory reserves | 133 |  |  | 22 |  |  | (12 | ) |  | — |  |  | 143 |  |
| 2017 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 44 |  |  | 16 |  |  | (16 | ) |  | 1 |  |  | 45 |  |
| Inventory reserves | 131 |  |  | 21 |  |  | (19 | ) |  | — |  |  | 133 |  |
| 2016 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 28 |  |  | 44 |  |  | (26 | ) |  | (2 | ) |  | 44 |  |
| Inventory reserves | 142 |  |  | 20 |  |  | (33 | ) |  | 2 |  |  | 131 |  |

[0000068505-19-000006:notes:67]
* Adjustments include translation adjustments


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-19-000006:notes:68]
Valuation and Qualifying Accounts


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-19-000006:notes:69]
Other Financial Data

[0000068505-19-000006:notes:70]
Statement of Operations Information

[0000068505-19-000006:notes:71]
Other Charges (Income)

[0000068505-19-000006:notes:72]
During the year ended December 31, 2018, the Company became aware of additional remediation requirements for the Superfund site, resulting in a charge of $57 million primarily due to: (i) changes in the expected timeline of the remediation activities to 30 years and (ii) additional costs for further remediation efforts, increasing the reserve to $107 million. The current portion of the estimated environmental liability is included in the “Accrued liabilities” statement line and the non-current portion is included in the “Other liabilities” statement line within the Company's Consolidated Balance Sheet.

[0000068505-19-000006:notes:73]
During the year ended December 31, 2018, the Company expensed $24 million of acquisition-related transaction fees related to the acquisitions of Avigilon, Plant, and VaaS compared to $1 million during the year ended December 31, 2017, and $13 million during the year ended December 31, 2016 related to the acquisition of Airwave.

[0000068505-19-000006:notes:74]
During the years ended December 31, 2018, December 31, 2017 and December 31, 2016, the Company recognized $1 million, $10 million and $21 million, respectively, of asset impairments. During the years ended December 31, 2017 and December 31, 2016, the impairments were primarily related to building impairments from the sale of various corporate and manufacturing facilities.

[0000068505-19-000006:notes:75]
During the year ended December 31, 2017, the Company recognized a net gain of $47 million related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business. The net gain of $47 million was based on $57 million of proceeds received, net $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-19-000006:notes:76]
Other Income (Expense)

[0000068505-19-000006:notes:77]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-19-000006:notes:78]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (240 | ) |  | $ | (215 | ) |  | $ | (225 | ) |
| Interest income | 18 |  |  | 14 |  |  | 20 |  |
|  | $ | (222 | ) |  | $ | (201 | ) |  | $ | (205 | ) |
| Other: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 7) | $ | 75 |  |  | $ | 46 |  |  | $ | 45 |  |
| Non-U.S. pension settlement loss (Note 7) | — |  |  | (48 | ) |  | (26 | ) |
| Gain (loss) from the extinguishment of long-term debt (Note 4) | 6 |  |  | — |  |  | (2 | ) |
| Investment impairments | (5 | ) |  | — |  |  | (4 | ) |
| Foreign currency gain (loss) | (24 | ) |  | (31 | ) |  | 46 |  |
| Gain (loss) on derivative instruments | (14 | ) |  | 15 |  |  | (56 | ) |
| Gains on equity method investments | 1 |  |  | 1 |  |  | 5 |  |
| Fair value adjustments to equity investments | 11 |  |  | — |  |  | — |  |
| Realized foreign currency loss on acquisition | — |  |  | — |  |  | (10 | ) |
| Other | 3 |  |  | 7 |  |  | 9 |  |
|  | $ | 53 |  |  | $ | (10 | ) |  | $ | 7 |  |

[0000068505-19-000006:notes:79]
During the year ended December 31, 2018, the Company recognized a foreign currency loss of $24 million, primarily driven by the Brazilian real, the Australian dollar and the Argentinian peso. In addition, the Company recognized a $14 million loss on derivative instruments related to foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the purchase of Avigilon as well as $5 million of impairments on strategic investments. These losses were offset by an $11 million gain related to an increase in the fair value of common stock held in a strategic investment.

[0000068505-19-000006:notes:80]
During the year ended December 31, 2017, the Company recognized a foreign currency loss of $31 million, primarily driven by the Euro and British pound, partially offset by a gain of $15 million, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-19-000006:notes:81]
During the year ended December 31, 2016, the Company recognized foreign currency gain of $46 million, primarily driven by the British pound, offset by a loss of $56 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations. The Company also realized a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave during the year ended December 31, 2016.

[0000068505-19-000006:notes:82]
Earnings Per Common Share

[0000068505-19-000006:notes:83]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-19-000006:notes:84]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Net Earnings (loss) |
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Basic earnings per common share: |  |  |  |  |  |
| Earnings (loss) | $ | 966 |  |  | $ | (155 | ) |  | $ | 560 |  |
| Weighted average common shares outstanding | 162.4 |  |  | 162.9 |  |  | 169.6 |  |
| Per share amount | $ | 5.95 |  |  | $ | (0.95 | ) |  | $ | 3.30 |  |
| Diluted earnings per common share: |  |  |  |  |  |
| Earnings (loss) | $ | 966 |  |  | $ | (155 | ) |  | $ | 560 |  |
| Weighted average common shares outstanding | 162.4 |  |  | 162.9 |  |  | 169.6 |  |
| Add effect of dilutive securities: |  |  |  |  |  |
| Share-based awards | 4.2 |  |  | — |  |  | 2.7 |  |
| Senior Convertible Notes | 5.4 |  |  | — |  |  | 0.8 |  |
| Diluted weighted average common shares outstanding | 172.0 |  |  | 162.9 |  |  | 173.1 |  |
| Per share amount | $ | 5.62 |  |  | $ | (0.95 | ) |  | $ | 3.24 |  |

[0000068505-19-000006:notes:85]
In the computation of diluted earnings per common share for the year ended December 31, 2018, the assumed exercise of 0.8 million options, including 0.6 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2017, the Company recorded a net loss and, accordingly, the basic and diluted weighted average shares outstanding are equal because any increase to the basic shares would be antidilutive, including the assumed exercise of 8.7 million stock options, the assumed vesting of 1.4 million RSUs, and 3.1 million shares related to the Senior Convertible Notes. In the computation of diluted earnings per common share for the year ended December 31, 2016, the assumed exercise of 2.8 million stock options and the assumed vesting of 0.3 million RSUs, including 2.0 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-19-000006:notes:86]
On August 25, 2015, the Company issued $1.0 billion of 2.0% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. On September 5, 2018, the Company agreed with Silver Lake Partners to re-purchase $200 million principal of the convertible notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. The Company paid the $369 million during the year ended December 31, 2018. In the event of an additional conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Since the Company’s intention is to settle the par value of the Senior Convertible Notes in cash upon conversion, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-19-000006:notes:87]
Balance Sheet Information

[0000068505-19-000006:notes:88]
Accounts Receivable, Net

[0000068505-19-000006:notes:89]
Accounts receivable, net, consists of the following:

[0000068505-19-000006:notes:90]
| December 31 | 2018 |  | 2017 |
| Accounts receivable | $ | 1,344 |  |  | $ | 1,568 |  |
| Less allowance for doubtful accounts | (51 | ) |  | (45 | ) |
|  | $ | 1,293 |  |  | $ | 1,523 |  |

[0000068505-19-000006:notes:91]
During the year ended December 31, 2018, $297 million of Unbilled accounts receivable were reclassified to Contract assets and $24 million of non-customer miscellaneous receivables were reclassified to Other current assets as a result of the adoption of ASC 606.

[0000068505-19-000006:notes:92]
Inventories, Net

[0000068505-19-000006:notes:93]
Inventories, net, consist of the following:

[0000068505-19-000006:notes:94]
| December 31 | 2018 |  | 2017 |
| Finished goods | $ | 206 |  |  | $ | 178 |  |
| Work-in-process and production materials | 293 |  |  | 282 |  |
|  | 499 |  |  | 460 |  |
| Less inventory reserves | (143 | ) |  | (133 | ) |
|  | $ | 356 |  |  | $ | 327 |  |

[0000068505-19-000006:notes:95]
Other Current Assets

[0000068505-19-000006:notes:96]
Other current assets consist of the following:

[0000068505-19-000006:notes:97]
| December 31 | 2018 |  | 2017 |
| Costs and earnings in excess of billings (Note 1) | $ | — |  |  | $ | 549 |  |
| Current contract cost assets (Note 2) | 30 |  |  | 62 |  |
| Tax-related refunds receivables and prepayments | 138 |  |  | 90 |  |
| Other | 186 |  |  | 131 |  |
|  | $ | 354 |  |  | $ | 832 |  |

[0000068505-19-000006:notes:98]
Property, Plant and Equipment, Net

[0000068505-19-000006:notes:99]
Property, plant and equipment, net, consist of the following:

[0000068505-19-000006:notes:100]
| December 31 | 2018 |  | 2017 |
| Land | $ | 10 |  |  | $ | 11 |  |
| Leasehold improvements | 362 |  |  | 316 |  |
| Machinery and equipment | 1,886 |  |  | 2,122 |  |
|  | 2,258 |  |  | 2,449 |  |
| Less accumulated depreciation | (1,363 | ) |  | (1,593 | ) |
|  | $ | 895 |  |  | $ | 856 |  |

[0000068505-19-000006:notes:101]
Depreciation expense for the years ended December 31, 2018, 2017, and 2016 was $172 million, $192 million and $182 million, respectively.

[0000068505-19-000006:notes:102]
Property, plant and equipment, net includes capital leases of $56 million, net of accumulated depreciation of $23 million, as of December 31, 2018.

[0000068505-19-000006:notes:103]
Investments

[0000068505-19-000006:notes:104]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the year ended December 31, 2018.

[0000068505-19-000006:notes:105]
The Company’s common stock portfolio reflects an investment in a publicly-traded company within the communications services sector and is valued utilizing active market prices for similar instruments. During the year ended December 31, 2018, the Company recognized $11 million in Other income (expense) related to an increase in the fair value of the investments.

[0000068505-19-000006:notes:106]
Company-owned life insurance policies are recorded at their cash surrender value. During the year ended December 31, 2018, the Company withdrew $60 million of excess cash from its company-sponsored life insurance investments.

[0000068505-19-000006:notes:107]
During the year ended December 31, 2018, Gains on the sale of investments and businesses were $16 million, compared to $3 million during the year ended December 31, 2017, and losses of $6 million during the year ended December 31, 2016. During the year ended December 31, 2018, the Company recorded investment impairment charges of $5 million, compared to $4 million during the year ended December 31, 2016, representing other-than-temporary declines in the value of the Company’s equity investment portfolio. There were no investment impairments recorded during the year ended December 31, 2017. Investment impairment charges are included in Other within Other income (expense) in the Company’s Consolidated Statements of Operations.

[0000068505-19-000006:notes:108]
Other Assets

[0000068505-19-000006:notes:109]
Other assets consist of the following:

[0000068505-19-000006:notes:110]
| December 31 | 2018 |  | 2017 |
| Defined benefit plan assets | $ | 135 |  |  | $ | 133 |  |
| Tax receivable | 39 |  |  | 101 |  |
| Non-current contract cost assets (Note 2) | 98 |  |  | — |  |
| Other | 72 |  |  | 99 |  |
|  | $ | 344 |  |  | $ | 333 |  |

[0000068505-19-000006:notes:111]
Accrued Liabilities

[0000068505-19-000006:notes:112]
Accrued liabilities consist of the following:

[0000068505-19-000006:notes:113]
| December 31 | 2018 |  | 2017 |
| Deferred revenue (Note 1) | $ | — |  |  | $ | 613 |  |
| Compensation | 324 |  |  | 273 |  |
| Billings in excess of costs and earnings (Note 1) | — |  |  | 428 |  |
| Tax liabilities (Note 6) | 111 |  |  | 107 |  |
| Deferred consideration on Airwave acquisition (Note 14) | — |  |  | 83 |  |
| Dividend payable | 93 |  |  | 84 |  |
| Trade liabilities | 185 |  |  | 151 |  |
| Other | 497 |  |  | 547 |  |
|  | $ | 1,210 |  |  | $ | 2,286 |  |

[0000068505-19-000006:notes:114]
The deferred consideration in conjunction with the acquisition of Airwave was paid during the fourth quarter of 2018.

[0000068505-19-000006:notes:115]
Other Liabilities

[0000068505-19-000006:notes:116]
Stockholders’ Equity Information

[0000068505-19-000006:notes:117]
Share Repurchase Program:  Through a series of actions, the board of directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2018, the Company had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-19-000006:notes:118]
The Company's share repurchases, including transaction costs, for 2018, 2017, and 2016 can be summarized as follows:

[0000068505-19-000006:notes:119]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Aggregate Amount (in millions) |
| 2018 | 1.2 |  |  | $ | 112.42 |  |  | $ | 132 |  |
| 2017 | 5.7 |  |  | 85.32 |  |  | 483 |  |
| 2016 | 12.0 |  |  | 70.28 |  |  | 842 |  |

[0000068505-19-000006:notes:120]
Payment of Dividends:  On November 15, 2018, the Company announced that its board of directors approved an increase in the quarterly cash dividend from $0.52 per share to $0.57 per share of common stock. During the years ended December 31, 2018, 2017, and 2016 the Company paid $337 million, $307 million, and $280 million, respectively, in cash dividends to holders of its common stock.

[0000068505-19-000006:notes:121]
Accumulated Other Comprehensive Loss

[0000068505-19-000006:notes:122]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2018, 2017, and 2016:

[0000068505-19-000006:notes:123]
|  | Years ended December 31 |
|  | 2018 |  | 2017 |  | 2016 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (353 | ) |  | $ | (494 | ) |  | $ | (266 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (94 | ) |  | 133 |  |  | (227 | ) |
| Tax benefit (expense) | 3 |  |  | 8 |  |  | (1 | ) |
| Other comprehensive income (loss), net of tax | (91 | ) |  | 141 |  |  | (228 | ) |
| Balance at end of period | $ | (444 | ) |  | $ | (353 | ) |  | $ | (494 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |
| Balance at beginning of period | $ | 6 |  |  | $ | — |  |  | $ | (3 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (8 | ) |  | 8 |  |  | — |  |
| Tax benefit (expense) | 2 |  |  | (2 | ) |  | — |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (6 | ) |  | 6 |  |  | — |  |
| Reclassification adjustment into Losses (Gains) on sales of investments and businesses | — |  |  | — |  |  | 5 |  |
| Tax benefit | — |  |  | — |  |  | (2 | ) |
| Reclassification adjustment into Net earnings, net of tax | — |  |  | — |  |  | 3 |  |
| Other comprehensive income (loss), net of tax | (6 | ) |  | 6 |  |  | 3 |  |
| Balance at end of period | $ | — |  |  | $ | 6 |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (2,215 | ) |  | $ | (1,823 | ) |  | $ | (1,597 | ) |
| Other comprehensive loss before reclassification adjustment | (200 | ) |  | (260 | ) |  | (368 | ) |
| Tax benefit (expense) | 46 |  |  | (213 | ) |  | 98 |  |
| Other comprehensive loss before reclassification adjustment, net of tax | (154 | ) |  | (473 | ) |  | (270 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 76 |  |  | 65 |  |  | 53 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (15 | ) |  | (18 | ) |  | (27 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other income (expense) | — |  |  | 48 |  |  | 26 |  |
| Tax benefit | (13 | ) |  | (14 | ) |  | (8 | ) |
| Reclassification adjustments into Net earnings, net of tax | 48 |  |  | 81 |  |  | 44 |  |
| Other comprehensive loss, net of tax | (106 | ) |  | (392 | ) |  | (226 | ) |
| Balance at end of period | $ | (2,321 | ) |  | $ | (2,215 | ) |  | $ | (1,823 | ) |
| Total Accumulated other comprehensive loss | $ | (2,765 | ) |  | $ | (2,562 | ) |  | $ | (2,317 | ) |

[0000068505-19-000006:notes:124]
During the year ended December 31, 2017, the Company reclassified $270 million of stranded tax effects out of Accumulated other comprehensive loss and into Retained earnings. The stranded tax effects remained a component of Accumulated other comprehensive loss as a result of the remeasurement of our deferred tax assets related to our U.S. Pension Plans through the statement of operations, to the U.S. federal tax rate of 21%. As a result, stranded tax effects within Accumulated other comprehensive loss which would not be realized at the established historical tax rates have been adjusted through equity.


## us-gaap:CapitalizedContractCostTableTextBlock

[0000068505-19-000006:notes:125]
| (in millions) | December 31, 2018 |  |  | January 1, 2018 |  |
| Current contract cost assets | $ | 30 |  |  | $ | 62 |  |
| Non-current contract cost assets | 98 |  |  | 85 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000068505-19-000006:notes:126]
The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-19-000006:notes:127]
Commitments and Contingencies

[0000068505-19-000006:notes:128]
Lease Obligations

[0000068505-19-000006:notes:129]
The Company leases certain office, factory and warehouse space, land, and other equipment under principally non-cancelable operating leases. Rental expense, net of sublease income, for the years ended December 31, 2018, 2017 and 2016 was $108 million, $94 million, and $84 million, respectively.

[0000068505-19-000006:notes:130]
At December 31, 2018, future minimum lease obligations, net of minimum sublease rentals, for the next five years and beyond are as follows:

[0000068505-19-000006:notes:131]
| (in millions) | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Beyond |  |
|  | $ | 131 |  | $ | 120 |  | $ | 112 |  | $ | 101 |  | $ | 54 |  | $ | 204 |  |

[0000068505-19-000006:notes:132]
Purchase Obligations

[0000068505-19-000006:notes:133]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. As of December 31, 2018, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2023. The Company expects to make total payments of $124 million under these arrangements as follows: $92 million in 2019, $16 million in 2020, $12 million in 2021, $3 million in 2022, and $1 million in 2023.

[0000068505-19-000006:notes:134]
The Company outsources certain corporate functions, such as benefit administration and information technology-related services, under various contracts, the longest of which is expected to expire in 2023. The remaining payments under these contracts are approximately $114 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-19-000006:notes:135]
Legal Matters

[0000068505-19-000006:notes:136]
The Company is a defendant in various lawsuits, claims, and actions that arise in the normal course of business. While the outcome of these matters is currently not determinable, the Company does not expect the ultimate disposition of these matters to have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-19-000006:notes:137]
Indemnifications

[0000068505-19-000006:notes:138]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-19-000006:notes:139]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at December 31, 2018.

[0000068505-19-000006:notes:140]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:ConsolidationPolicyTextBlock

[0000068505-19-000006:notes:141]
The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-19-000006:notes:142]
The consolidated financial statements as of December 31, 2018 and 2017 and for the years ended December 31, 2018, 2017 and 2016, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000068505-19-000006:notes:143]
| (in millions) | December 31, 2018 |  |  | January 1, 2018 |  |
| Receivables | $ | 1,293 |  |  | $ | 1,198 |  |
| Contract assets | 1,012 |  |  | 931 |  |
| Contract liabilities | 1,263 |  |  | 1,082 |  |
| Non-current contract liabilities | 214 |  |  | 162 |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-19-000006:notes:144]
Debt and Credit Facilities

[0000068505-19-000006:notes:145]
Long-Term Debt

[0000068505-19-000006:notes:146]
| December 31 | 2018 |  | 2017 |
| 2.0% Senior Convertible Notes due 2020 | $ | 800 |  |  | $ | 1,000 |  |
| Term Loan due 2021 | 399 |  |  | — |  |
| 3.5% senior notes due 2021 | 397 |  |  | 396 |  |
| 3.75% senior notes due 2022 | 748 |  |  | 747 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 594 |  |
| 4.0% senior notes due 2024 | 591 |  |  | 590 |  |
| 6.5% debentures due 2025 | 118 |  |  | 118 |  |
| 7.5% debentures due 2025 | 346 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 690 |  |  | — |  |
| 6.5% debentures due 2028 | 36 |  |  | 36 |  |
| 6.625% senior notes due 2037 | 54 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 62 |  |  | 108 |  |
|  | 5,324 |  |  | 4,476 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (4 | ) |  | (5 | ) |
| Less: current portion | (31 | ) |  | (52 | ) |
| Long-term debt | $ | 5,289 |  |  | $ | 4,419 |  |

[0000068505-19-000006:notes:147]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.0% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.8252, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.45 per share). The exercise price adjusts automatically for dividends. As of August 25, 2015, the Company recorded a long-term debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company calculated the fair value of the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. As of December 31, 2018, the remaining unamortized debt discount has been fully amortized as a component of interest expense.

[0000068505-19-000006:notes:148]
On September 5, 2018, the Company agreed with Silver Lake Partners to repurchase $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. During the year ended December 31, 2018, the Company recorded a gain of $6 million from the extinguishment of the convertible debt. Of the $369 million paid to Silver Lake Partners, $169 million was paid during the third quarter of 2018 and the remaining $200 million was paid on October 15, 2018. The $200 million that was paid during the fourth quarter was from the additional $200 million issued on the outstanding 4.60% Senior notes due in 2028. The Company settled the issuance of these notes on October 5, 2018 and received net proceeds of $196 million. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of December 31, 2018 was $673 million. In the event of an additional conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. For the year ended December 31, 2018, total interest expense relating to both the contractual interest coupon and amortization of the debt discount was $20 million, compared to $23 million for the year December 31, 2017 and $24 million for the year ended December 31, 2016.

[0000068505-19-000006:notes:149]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan in the first quarter of 2018.

[0000068505-19-000006:notes:150]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2019—$31 million; 2020—$801 million; 2021—$810 million; 2022—$767 million; and 2023—$604 million.

[0000068505-19-000006:notes:151]
Credit Facilities

[0000068505-19-000006:notes:152]
As of December 31, 2018,  the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, the Company borrowed $400 million under the facility to complete the Avigilon acquisition which was re-paid by December 31, 2018. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Inter-bank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2018. No letters of credit were issued under the revolving credit facility as of December 31, 2018.

[0000068505-19-000006:notes:153]
Also in conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the year ended December 31, 2018 was 3.47%. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-19-000006:notes:154]
Risk Management

[0000068505-19-000006:notes:155]
Foreign Currency Risk

[0000068505-19-000006:notes:156]
The Company is exposed to foreign currency risk as a result of buying and selling in various currencies, our net investments in foreign entities, and monetary assets and liabilities denominated in a currency other than the functional currency of the legal entity holding the instrument. The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-19-000006:notes:157]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-19-000006:notes:158]
At December 31, 2018, the Company had outstanding foreign exchange contracts with notional amounts totaling $819 million, compared to $507 million outstanding at December 31, 2017. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-19-000006:notes:159]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2018 and the corresponding positions as of December 31, 2017:

[0000068505-19-000006:notes:160]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2018 |  | 2017 |
| British Pound | $ | 139 |  |  | $ | 72 |  |
| Euro | 89 |  |  | 149 |  |
| Australian Dollar | (105 | ) |  | (64 | ) |
| Chinese Renminbi | (55 | ) |  | (73 | ) |
| Brazilian Real | (41 | ) |  | (45 | ) |

[0000068505-19-000006:notes:161]
During the year ended December 31, 2018, the Company entered into forward contracts to sell €85 million, that expire in December 2019 as well as to sell €10 million, that will expire in January 2020. The forward contracts have been designated as a net investment hedges which are in place to partially hedge the Company's Euro foreign currency exposure on its net investments in certain foreign subsidiaries that are Euro-denominated. The gains and losses on the Company's net investments in Euro-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive income (loss) with the exception of the excluded component which will be amortized on a straight-line basis to Interest expense, net.

[0000068505-19-000006:notes:162]
Counterparty Risk

[0000068505-19-000006:notes:163]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2018, all of the counterparties have investment grade credit ratings. As of December 31, 2018, the credit risk with all counterparties was approximately $5 million.

[0000068505-19-000006:notes:164]
Derivative Financial Instruments

[0000068505-19-000006:notes:165]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2018 and 2017:

[0000068505-19-000006:notes:166]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2018 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other assets |  | $ | 4 |  |  | Accrued liabilities |

[0000068505-19-000006:notes:167]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2017 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 3 |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other assets |  | $ | 2 |  |  | Accrued liabilities |
| Total derivatives | $ | 5 |  |  |  |  | $ | 5 |  |  |  |

[0000068505-19-000006:notes:168]
The following table summarizes the effect of derivatives designated as hedging instruments, for the years ended December 31, 2018, 2017 and 2016:

[0000068505-19-000006:notes:169]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2018 |  | 2017 |  | 2016 |
| Foreign exchange contracts | $ | — |  |  | $ | (3 | ) |  | $ | — |  | Other comprehensive income (loss) |

[0000068505-19-000006:notes:170]
The following table summarizes the effect of derivatives not designated as hedging instruments, for the years ended December 31, 2018, 2017 and 2016:

[0000068505-19-000006:notes:171]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2018 |  | 2017 |  | 2016 |
| Interest agreements | $ | — |  |  | $ | — |  |  | $ | 1 |  | Other income (expense) |
| Foreign exchange contracts | (14 | ) |  | 15 |  |  | (57 | ) | Other income (expense) |
| Total derivatives | $ | (14 | ) |  | $ | 15 |  |  | $ | (56 | ) |  |


## us-gaap:DerivativesPolicyTextBlock

[0000068505-19-000006:notes:172]
Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income (loss). Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income (loss) at their initial value and amortized into Interest expense, net on a straight-line basis.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000068505-19-000006:notes:173]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the year ended December 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-19-000006:notes:174]
| (in millions) | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |
| Americas | $ | 3,743 |  |  | $ | 1,320 |  |
| EMEA | 845 |  |  | 755 |  |
| Asia Pacific | 512 |  |  | 168 |  |
| Total | $ | 5,100 |  |  | $ | 2,243 |  |
| Major Products and Services |  |  |  |
| Devices | $ | 3,216 |  |  | $ | — |  |
| Systems and Systems Integration | 1,884 |  |  | — |  |
| Services | — |  |  | 1,815 |  |
| Software | — |  |  | 428 |  |
| Total | $ | 5,100 |  |  | $ | 2,243 |  |
| Customer Type |  |  |  |
| Direct | $ | 3,317 |  |  | $ | 2,134 |  |
| Indirect | 1,783 |  |  | 109 |  |
| Total | $ | 5,100 |  |  | $ | 2,243 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-19-000006:notes:175]
Share-Based Compensation Plans and Other Incentive Plans

[0000068505-19-000006:notes:176]
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option granted and stock appreciation right has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-19-000006:notes:177]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-19-000006:notes:178]
Performance-based stock options (“performance options”) and market stock units ("MSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years.

[0000068505-19-000006:notes:179]
On August 25, 2015, in conjunction with the issuance of the Senior Convertible Notes, and on March 9, 2017, the Company approved grants of performance-contingent stock options (“PCSOs”) to certain executive officers. The PCSOs vest upon satisfaction of the following stock price hurdles which must be maintained for 10-consecutive trading days within the performance period ending August 25, 2018 and continuous employment over the vesting period. For PCSOs granted on August 25, 2015, 20% of the total award will vest at an $85 stock price, an additional 30% of the total award will vest at a $102.50 stock price, and the final 50% of the total award will vest at a $120 stock price. For options granted March 9, 2017, 44% of the total award will vest at an $85 stock price, an additional 24% of the total award will vest at a $102.50 stock price, and the final 32% of the award will vest at a $120 stock price. As of December 31, 2018, all stock price hurdles have been met and therefore, all PCSO grants have vested. The August 25, 2015 awards have a seven-year term and a per share exercise price of $68.50. The March 9, 2017 awards have a five-and-a-half-year term and a per share exercise price of $81.37.

[0000068505-19-000006:notes:180]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2018, 2017 and 2016, employees purchased 0.8 million, 0.8 million and 0.9 million shares, respectively, at purchase prices of $72.96 and $88.84, $63.96 and $72.11, and $57.60 and $64.69, respectively.

[0000068505-19-000006:notes:181]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-19-000006:notes:182]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2018, 2017 and 2016 was $23.31, $15.16 and $13.09, respectively, using the following weighted-average assumptions:

[0000068505-19-000006:notes:183]
|  | 2018 |  | 2017 |  | 2016 |
| Expected volatility | 24.7 | % |  | 24.0 | % |  | 23.7 | % |
| Risk-free interest rate | 2.7 | % |  | 2.1 | % |  | 1.4 | % |
| Dividend yield | 2.4 | % |  | 3.5 | % |  | 2.9 | % |
| Expected life (years) | 5.9 |  |  | 5.9 |  |  | 6.0 |  |

[0000068505-19-000006:notes:184]
The Company calculates the value of each performance option, MSU, and PCSO using the Monte Carlo simulation, estimated on the date of grant. The fair value of performance options and MSUs granted during 2018 was $42.19 and $125.33, respectively. The fair value of performance options, MSUs, and PCSOs granted during 2017 was $21.47, $85.74, and $7.76, respectively. The fair value of performance options and MSUs granted during 2016 was $19.80 and $76.48, respectively. The following assumptions were used for the calculations.

[0000068505-19-000006:notes:185]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PCSOs. The selection of the implied volatility approach was based upon the availability of actively traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. The Company uses the historical volatility as the expected volatility assumption in the valuation of performance options in order to calculate the correlation coefficients between the S&P 500 and the Company's stock, which can only be calculated using historical data.

[0000068505-19-000006:notes:186]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-19-000006:notes:187]
The Company has applied forfeiture rates, estimated based on historical data, of 10%-35% to the stock option fair values calculated by the Black-Scholes option pricing model. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-19-000006:notes:188]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, including performance options and PCSOs, at December 31, 2018 (in thousands, except exercise price and years):

[0000068505-19-000006:notes:189]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| Under $30 | 266 |  |  | $ | 29 |  |  | 1 |  | 266 |  |  | $ | 29 |  |  | 1 |
| $30-$40 | 1,198 |  |  | 39 |  |  | 2 |  | 1,198 |  |  | 39 |  |  | 2 |
| $41-$50 | — |  |  | — |  |  | 0 |  | — |  |  | — |  |  | 0 |
| $51-$60 | 671 |  |  | 54 |  |  | 4 |  | 671 |  |  | 54 |  |  | 4 |
| $61-$70 | 1,815 |  |  | 68 |  |  | 4 |  | 1,796 |  |  | 68 |  |  | 4 |
| $71-$80 | 469 |  |  | 72 |  |  | 7 |  | 86 |  |  | 72 |  |  | 7 |
| $81 and over | 1,151 |  |  | 92 |  |  | 8 |  | 247 |  |  | 82 |  |  | 5 |
|  | 5,570 |  |  |  |  |  |  | 4,264 |  |  |  |  |  |

[0000068505-19-000006:notes:190]
As of December 31, 2018, the weighted average contractual life for options outstanding and exercisable was five and four years, respectively.

[0000068505-19-000006:notes:191]
Current Year Activity

[0000068505-19-000006:notes:192]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-19-000006:notes:193]
|  | Stock Options |  | Performance Options* |  | Restricted Stock Units |  | Market Stock Units |
| Shares Outstanding in Thousands | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2018 | 4,604 |  |  | $ | 52 |  |  | 2,678 |  |  | $ | 72 |  |  | 1,257 |  |  | $ | 70 |  |  | 139 |  |  | $ | 78 |  |
| Granted | 272 |  |  | 111 |  |  | 159 |  |  | 108 |  |  | 484 |  |  | 105 |  |  | 53 |  |  | 125 |  |
| Releases/Exercised | (1,445 | ) |  | 52 |  |  | (774 | ) |  | 71 |  |  | (570 | ) |  | 70 |  |  | (101 | ) |  | 73 |  |
| Adjustment for payout factor | — |  |  | — |  |  | 115 |  |  | 67 |  |  | — |  |  | — |  |  | 31 |  |  | 73 |  |
| Forfeited/Canceled | (20 | ) |  | 88 |  |  | (19 | ) |  | 81 |  |  | (74 | ) |  | 82 |  |  | — |  |  | — |  |
| Balance as of December 31, 2018 | 3,411 |  |  | $ | 57 |  |  | 2,159 |  |  | $ | 74 |  |  | 1,097 |  |  | $ | 84 |  |  | 122 |  |  | $ | 102 |  |
| Vested or expected to vest | 3,032 |  |  | 50 |  |  | 1,492 |  |  | 70 |  |  | 462 |  |  | 71 |  |  | 89 |  |  | 80 |  |

[0000068505-19-000006:notes:194]
* Inclusive of PCSO awards

[0000068505-19-000006:notes:195]
At December 31, 2018 and 2017, 8.6 million and 9.6 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-19-000006:notes:196]
Total Share-Based Compensation Expense

[0000068505-19-000006:notes:197]
At December 31, 2018, the Company had unrecognized compensation expense related to RS, RSUs, and MSUs of $59 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately two years. The total fair value of RS, RSU and MSU shares vested during the years ended December 31, 2018, 2017, and 2016 was $40 million, $39 million, and $54 million, respectively. The aggregate fair value of outstanding RS, RSUs, and MSUs as of December 31, 2018 was $105 million.

[0000068505-19-000006:notes:198]
At December 31, 2018, the Company had $15 million of total unrecognized compensation expense, net of estimated forfeitures, related to stock option plans including performance options and PCSOs that will be recognized over the weighted average period of approximately two years, and $4 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. Cash received from stock option exercises and the employee stock purchase plan was $168 million, $82 million, and $93 million for the years ended December 31, 2018, 2017, and 2016, respectively. The total intrinsic value of options exercised during the years ended December 31, 2018, 2017, and 2016 was $125 million, $31 million, and $16 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2018 was $288 million and $252 million, respectively, based on a December 31, 2018 stock price of $115.04 per share.

[0000068505-19-000006:notes:199]
Motorola Solutions Incentive Plans

[0000068505-19-000006:notes:200]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2018, 2017 and 2016 was $143 million, $122 million and $114 million, respectively.

[0000068505-19-000006:notes:201]
Long-Range Incentive Plan

[0000068505-19-000006:notes:202]
The Long-Range Incentive Plan (“LRIP”) rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. The expense for LRIP for the years ended December 31, 2018, 2017 and 2016 was $31 million, $9 million and $12 million, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000068505-19-000006:notes:203]
The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for net earnings attributable to Motorola Solutions, Inc. for all periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-19-000006:notes:204]
Fair Value Measurements

[0000068505-19-000006:notes:205]
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-19-000006:notes:206]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-19-000006:notes:207]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-19-000006:notes:208]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-19-000006:notes:209]
Investments and Derivatives

[0000068505-19-000006:notes:210]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2018 and December 31, 2017 were as follows:

[0000068505-19-000006:notes:211]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Corporate bonds | 1 |  |  | — |  |  | 1 |  |
| Common stock and equivalents | 19 |  |  | — |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |

[0000068505-19-000006:notes:212]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | — |  |  | 2 |  |  | 2 |  |
| Common stock and equivalents | 13 |  |  | — |  |  | 13 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |

[0000068505-19-000006:notes:213]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-19-000006:notes:214]
The following is a description of the categories of investments:

[0000068505-19-000006:notes:215]
Equities — A diversified portfolio of corporate common stock and preferred stock.

[0000068505-19-000006:notes:216]
Commingled funds — A diversified portfolio of assets that includes corporate common stock, preferred stock, emerging market and high-yield fixed income securities among others.

[0000068505-19-000006:notes:217]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-19-000006:notes:218]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-19-000006:notes:219]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-19-000006:notes:220]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-19-000006:notes:221]
At December 31, 2018, the Company had $734 million of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $633 million at December 31, 2017. The money market funds had quoted market prices that are approximately at par.

[0000068505-19-000006:notes:222]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2018 was $5.4 billion (Level 2), compared to a face value of $5.3 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-19-000006:notes:223]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000068505-19-000006:notes:224]
Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-19-000006:notes:225]
Intangible Assets and Goodwill

[0000068505-19-000006:notes:226]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-19-000006:notes:227]
Avigilon Corporation

[0000068505-19-000006:notes:228]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. Prior to the end of the first quarter, $35 million of the assumed debt was repaid with the remaining $40 million repaid during the second quarter of 2018.

[0000068505-19-000006:notes:229]
The acquisition of Avigilon has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change. The following table summarizes fair values of assets acquired and liabilities assumed as of the March 28, 2018 acquisition date:

[0000068505-19-000006:notes:230]
| Accounts receivable, net |  | $ | 67 |  |
| Inventory |  | 93 |  |
| Other current assets |  | 18 |  |
| Property, plant and equipment, net |  | 33 |  |
| Deferred income taxes |  | 4 |  |
| Accounts payable |  | (21 | ) |
| Accrued liabilities |  | (28 | ) |
| Deferred income tax liabilities |  | (124 | ) |
| Goodwill |  | 434 |  |
| Intangible assets |  | 498 |  |
| Total consideration |  | $ | 974 |  |

[0000068505-19-000006:notes:231]
Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to 20 years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-19-000006:notes:232]
Goodwill is calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. Goodwill is not deductible for tax purposes.

[0000068505-19-000006:notes:233]
The pro forma effect of this acquisition is not significant.

[0000068505-19-000006:notes:234]
Other Acquisitions

[0000068505-19-000006:notes:235]
On April 9, 2018, the Company completed the acquisition of a provider of two-way radio communications for a purchase price of $11 million, recognizing $7 million of identifiable intangible assets, which will be amortized over a period of seven years. The results of operations for this acquisition have been included in the Company’s Consolidated Statements of Operations subsequent to the acquisition date.

[0000068505-19-000006:notes:236]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million; net of cash acquired. This acquisition will expand the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1. The Company recognized $151 million of goodwill, $80 million of identifiable intangible assets and $6 million of net assets. Goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of 10 to 20 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change.

[0000068505-19-000006:notes:237]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk for commercial customers, for a purchase price of $225 million. As a result of the acquisition, the Company recognized $191 million of goodwill, $44 million of identifiable intangible assets and $10 million of acquired liabilities. The identifiable intangible assets were classified as $25 million of customer-related intangibles and $19 million of completed technology and will be amortized over a period of 13 to 16 years.

[0000068505-19-000006:notes:238]
On March 13, 2017, the Company completed the acquisition of Interexport, a managed service provider for communications systems to public safety and commercial customers in Chile, for a purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $16 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-19-000006:notes:239]
On November 10, 2016, the Company completed the acquisition of Spillman Technologies, Inc., a provider of comprehensive law enforcement and public safety software solutions, for a purchase price of $221 million. As a result of the acquisition, the Company recognized $144 million of goodwill, $115 million of identifiable intangible assets, and $38 million of acquired liabilities. The identifiable intangible assets were classified as $49 million of completed technology, $59 million of customer-related intangibles, and $7 million of other intangibles and will be amortized over a period of seven to ten years.

[0000068505-19-000006:notes:240]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited, a holding company of Airwave Solutions Limited, the largest private operator of a public safety network in the world. All of the outstanding equity of Airwave was acquired for the sum of £1, after which the Company invested into Airwave £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. As a result of the acquisition, the Company recognized $875 million of identifiable intangible assets, $191 million of goodwill, and $16 million of net other tangible assets. As part of the acquisition, the Company recorded $82 million of deferred consideration, which was paid during the fourth quarter of 2018. The identifiable intangible assets were classified as $846 million of customer relationships and $29 million of trade names. All intangibles have a useful life of seven years, over which amortization expense will be recognized on a straight line basis.

[0000068505-19-000006:notes:241]
During the year ended December 31, 2016, the Company completed the acquisition of several software and service-based providers for a total of $30 million, recognizing $6 million of goodwill, $15 million of intangible assets, and $9 million of tangible net assets related to these acquisitions. Under the preliminary purchase accounting, the $15 million of identifiable intangible assets were classified as: (i) $7 million of completed technology and (ii) $8 million of customer-related intangibles and will be amortized over a period of five years. During the first quarter of 2017, the Company completed the purchase accounting and recorded an additional $11 million completed technology intangible asset that will be amortized over a period of eight years.

[0000068505-19-000006:notes:242]
The results of operations for these acquisitions have been included in the Company’s Consolidated Statements of Operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-19-000006:notes:243]
On January 7, 2019, the Company completed the acquisition of VaaS, a data and image analytics company based in Livermore, California and Fort Worth, Texas for a total consideration, including contingent consideration, of $445 million in a combination of cash and equity. The acquisition of VaaS enables the Company to expand on its command center software portfolio to help shorten response times and improve the speed and accuracy of investigations. As of the date of issuance of the Company's financial statements, the purchase accounting has not been completed.

[0000068505-19-000006:notes:244]
Intangible Assets

[0000068505-19-000006:notes:245]
Amortized intangible assets are comprised of the following:

[0000068505-19-000006:notes:246]
|  | 2018 |  | 2017 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 558 |  |  | $ | 92 |  |  | $ | 148 |  |  | $ | 55 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,085 |  |  | 364 |  |  | 977 |  |  | 242 |  |
| Other intangibles | 74 |  |  | 31 |  |  | 56 |  |  | 23 |  |
|  | $ | 1,719 |  |  | $ | 489 |  |  | $ | 1,183 |  |  | $ | 322 |  |

[0000068505-19-000006:notes:247]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $188 million, $151 million, and $113 million for the years ended December 31, 2018, 2017, and 2016, respectively.  As of December 31, 2018, future amortization expense is estimated to be $187 million in 2019, $183 million in 2020, $181 million in 2021, $178 million in 2022, and $81 million in 2023.

[0000068505-19-000006:notes:248]
Goodwill

[0000068505-19-000006:notes:249]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2017 to December 31, 2018:

[0000068505-19-000006:notes:250]
|  | Products and Systems Integration |  | Services and Software |  | Total |
| Balance as of January 1, 2017 | $ | 347 |  |  | $ | 381 |  |  | $ | 728 |  |
| Goodwill acquired | 14 |  |  | 177 |  |  | 191 |  |
| Purchase accounting adjustments | — |  |  | 2 |  |  | 2 |  |
| Foreign currency translation | 1 |  |  | 16 |  |  | 17 |  |
| Balance as of December 31, 2017 | $ | 362 |  |  | $ | 576 |  |  | $ | 938 |  |
| Goodwill acquired | 360 |  |  | 225 |  |  | 585 |  |
| Purchase accounting adjustments | — |  |  | 1 |  |  | 1 |  |
| Foreign currency translation | — |  |  | (10 | ) |  | (10 | ) |
| Balance as of December 31, 2018 | $ | 722 |  |  | $ | 792 |  |  | $ | 1,514 |  |

[0000068505-19-000006:notes:251]
During the second quarter of 2018, the Company modified its internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership, in part, as a result of recent acquisitions contributing to the growth within the newly-aligned Services and Software segment. Previously, the Company had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration-related revenue and costs moving from the old Services segment into the newly-presented Products and Systems Integration segment and software-related revenue and costs moving from the old Products segment into the newly-presented Services and Software segment.

[0000068505-19-000006:notes:252]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment.

[0000068505-19-000006:notes:253]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2018, 2017, and 2016. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2018, 2017, and 2016, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000068505-19-000006:notes:254]
Goodwill is assessed for impairment at least annually at the reporting unit, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and SG&A costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it’s determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform the first step of the impairment process, which compares the fair value of the reporting unit to its book value. If the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-19-000006:notes:255]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000068505-19-000006:notes:256]
Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-19-000006:notes:257]
Income Taxes

[0000068505-19-000006:notes:258]
Components of Income Tax Expense

[0000068505-19-000006:notes:259]
Components of earnings (loss) before income taxes are as follows:

[0000068505-19-000006:notes:260]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| United States | $ | 980 |  |  | $ | 959 |  |  | $ | 651 |  |
| Other nations | 122 |  |  | 117 |  |  | 193 |  |
|  | $ | 1,102 |  |  | $ | 1,076 |  |  | $ | 844 |  |

[0000068505-19-000006:notes:261]
Components of income tax expense (benefit) are as follows:

[0000068505-19-000006:notes:262]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| United States | $ | 16 |  |  | $ | 43 |  |  | $ | 20 |  |
| Other nations | 88 |  |  | 75 |  |  | 31 |  |
| States (U.S.) | 20 |  |  | 9 |  |  | 18 |  |
| Current income tax expense | 124 |  |  | 127 |  |  | 69 |  |
| United States | 39 |  |  | 1,078 |  |  | 180 |  |
| Other nations | (18 | ) |  | (8 | ) |  | 36 |  |
| States (U.S.) | (12 | ) |  | 30 |  |  | (3 | ) |
| Deferred income tax expense | 9 |  |  | 1,100 |  |  | 213 |  |
| Total income tax expense | $ | 133 |  |  | $ | 1,227 |  |  | $ | 282 |  |

[0000068505-19-000006:notes:263]
Differences between income tax expense (benefit) computed at the U.S. federal statutory tax rate of 21% and income tax expense (benefit) as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-19-000006:notes:264]
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |
| Income tax expense at statutory rate | $ | 231 |  | 21.0 | % |  | $ | 377 |  | 35.0 | % |  | $ | 295 |  | 35.0 | % |
| Non-U.S. tax expense (benefit) on non-U.S. earnings | 7 |  | 0.6 | % |  | (28 | ) | (2.6 | )% |  | (25 | ) | (3.0 | )% |
| State income taxes, net of federal benefit | 11 |  | 1.0 | % |  | 39 |  | 3.6 | % |  | 26 |  | 3.1 | % |
| Reserve for uncertain tax positions | 2 |  | 0.2 | % |  | 3 |  | 0.3 | % |  | (13 | ) | (1.6 | )% |
| Other provisions | (1 | ) | (0.1 | )% |  | 3 |  | 0.3 | % |  | 4 |  | 0.4 | % |
| Valuation allowances | (14 | ) | (1.3 | )% |  | (8 | ) | (0.7 | )% |  | (7 | ) | (0.8 | )% |
| Section 199 deduction | — |  | — | % |  | (18 | ) | (1.7 | )% |  | (15 | ) | (1.7 | )% |
| U.S. tax on undistributed non-U.S. earnings | 6 |  | 0.5 | % |  | 20 |  | 1.9 | % |  | 25 |  | 3.0 | % |
| Stock compensation | (30 | ) | (2.7 | )% |  | (14 | ) | (1.3 | )% |  | (8 | ) | (1.0 | )% |
| Loss on sale of investment | — |  | — | % |  | (21 | ) | (2.0 | )% |  | — |  | — | % |
| U.S. tax reform | (79 | ) | (7.2 | )% |  | 874 |  | 81.2 | % |  | — |  | — | % |
|  | $ | 133 |  | 12.0 | % |  | $ | 1,227 |  | 114.0 | % |  | $ | 282 |  | 33.4 | % |

[0000068505-19-000006:notes:265]
Income tax expense for the year ended December 31, 2018 was $133 million, a decrease of $1.1 billion, primarily driven by the following items: (i) the U.S. corporate income tax rate decrease from 35% to 21% as a result of the U.S. Tax Cuts and Jobs Act (the ”Tax Act”) enacted December 22, 2017, (ii) $874 million of non-recurring charges during the prior year related to the enactment of the Tax Act, and (iii) $79 million of non-recurring benefits during the current year as a result of changes to 2017 Tax Act enactment-date provisional amounts. The effective tax rate is below the current U.S. federal statutory rate of 21% primarily driven by a tax benefit due to the recognition of excess tax benefits of share-based compensation and tax benefits due to changes to 2017 Tax Act enactment-date provisional amounts.

[0000068505-19-000006:notes:266]
Under the guidance in the U.S. Securities and Exchange Commission's Staff Accounting Bulletin No. 118 ("SAB 118"), the Company recorded provisional amounts for the impact of the Tax Act as of December 31, 2017, representing $874 million of incremental tax expense. Under the transitional provisions of SAB 118, the Company had a one-year measurement period to complete the accounting for the initial tax effects of the Tax Act. The Company recorded its final adjustments to the provisional amounts in 2018. Final regulations will be issued in the future and may be applied retroactively to the date of enactment of US Tax Reform that may result in changes to the tax amounts recorded as a result of the Tax Act. For the year ended December 31, 2018, the Company has recorded the following adjustments to the previously recorded provisional tax amounts:

[0000068505-19-000006:notes:267]
Deferred tax balances that were recorded within Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are a result of retirement benefit adjustments, currency translation adjustments, and fair value adjustments to available-for-sale securities. The adjustments were charges of $38 million for the year ended December 31, 2018 and benefits of $49 million, and $87 million for the years ended December 31, 2017 and 2016, respectively.

[0000068505-19-000006:notes:268]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the Tax Act, dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-19-000006:notes:269]
Undistributed foreign earnings that the Company intends to reinvest indefinitely, aggregate to $1.5 billion at December 31, 2018. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-19-000006:notes:270]
Gross deferred tax assets were $2.0 billion and $2.1 billion at December 31, 2018 and 2017, respectively. Deferred tax assets, net of valuation allowances, were $1.6 billion at December 31, 2018 and $1.5 billion at December 31, 2017, respectively. Gross deferred tax liabilities were $771 million and $546 million at December 31, 2018 and 2017, respectively.

[0000068505-19-000006:notes:271]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-19-000006:notes:272]
| December 31 | 2018 |  | 2017 |
| Inventory | $ | 28 |  |  | $ | 46 |  |
| Accrued liabilities and allowances | 84 |  |  | 74 |  |
| Employee benefits | 402 |  |  | 374 |  |
| Capitalized items | (68 | ) |  | 18 |  |
| Tax basis differences on investments | (2 | ) |  | — |  |
| Depreciation tax basis differences on fixed assets | 47 |  |  | 72 |  |
| Undistributed non-U.S. earnings | (26 | ) |  | (26 | ) |
| Tax carryforwards | 613 |  |  | 778 |  |
| Business reorganization | 10 |  |  | 16 |  |
| Warranty and customer liabilities | 19 |  |  | 21 |  |
| Deferred revenue and costs | 147 |  |  | 142 |  |
| Valuation allowances | (461 | ) |  | (604 | ) |
| Other | (9 | ) |  | (3 | ) |
|  | $ | 784 |  |  | $ | 908 |  |

[0000068505-19-000006:notes:273]
At December 31, 2018 and 2017, the Company had valuation allowances of $461 million and $604 million, respectively, against its deferred tax assets, including $86 million and $90 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance decreased $139 million during 2018 primarily related to a $71 million release of valuation allowances as a result of changes to 2017 Tax Act enactment-date provision amounts and $63 million of foreign tax credits expiring in 2018. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-19-000006:notes:274]
Tax carryforwards are as follows:

[0000068505-19-000006:notes:275]
| December 31, 2018 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 73 |  |  | $ | 15 |  |  | 2022-2036 |
| Foreign tax credits | — |  |  | 334 |  |  | 2019-2023 |
| General business credits | — |  |  | 51 |  |  | 2026-2037 |
| State tax losses | — |  |  | 35 |  |  | 2019-2030 |
| State tax credits | — |  |  | 32 |  |  | 2019-2031 |
| Non-U.S. Subsidiaries: |  |  |  |  |  |
| Japan tax losses | 102 |  |  | 32 |  |  | 2019-2025 |
| Germany tax losses | 26 |  |  | 8 |  |  | Unlimited |
| United Kingdom tax losses | 81 |  |  | 14 |  |  | Unlimited |
| Singapore tax losses | 33 |  |  | 6 |  |  | Unlimited |
| Canada tax losses | 46 |  |  | 12 |  |  | 2024-2025 |
| Other subsidiaries tax losses | 128 |  |  | 36 |  |  | Various |
| Spain tax credits | — |  |  | 25 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 13 |  |  | Various |
|  |  |  | $ | 613 |  |  |  |

[0000068505-19-000006:notes:276]
The Company had unrecognized tax benefits of $76 million at both December 31, 2018 and December 31, 2017, of which approximately $30 million, if recognized, would affect the effective tax rate for both 2018 and 2017, net of resulting changes to valuation allowances.

[0000068505-19-000006:notes:277]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-19-000006:notes:278]
|  | 2018 |  | 2017 |
| Balance at January 1 | $ | 76 |  |  | $ | 68 |  |
| Additions based on tax positions related to current year | 4 |  |  | 10 |  |
| Additions for tax positions of prior years | 1 |  |  | 22 |  |
| Reductions for tax positions of prior years | — |  |  | (1 | ) |
| Settlements and agreements | (2 | ) |  | (20 | ) |
| Lapse of statute of limitations | (3 | ) |  | (3 | ) |
| Balance at December 31 | $ | 76 |  |  | $ | 76 |  |

[0000068505-19-000006:notes:279]
The Internal Revenue Service ("IRS") is currently examining the Company's 2014 and 2015 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-19-000006:notes:280]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s consolidated financial position, liquidity, or results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-19-000006:notes:281]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $10 million tax charge to a $30 million tax benefit, with cash payments not to exceed $20 million.

[0000068505-19-000006:notes:282]
At December 31, 2018, the Company had $30 million accrued for interest and $17 million accrued for penalties on unrecognized tax benefits. At December 31, 2017, the Company had $31 million and $19 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:IncomeTaxPolicyTextBlock

[0000068505-19-000006:notes:283]
The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.


## us-gaap:InventoryPolicyTextBlock

[0000068505-19-000006:notes:284]
Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or net realizable value.


## us-gaap:InvestmentPolicyTextBlock

[0000068505-19-000006:notes:285]
Investments in debt securities classified as available-for-sale are carried at fair value with changes in fair value recorded in other comprehensive income. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-19-000006:notes:286]
The Company assesses declines in the fair value of debt securities and equity method investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s Consolidated Statements of Operations in the period in which they become impaired.

[0000068505-19-000006:notes:287]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded in Other within Other income (expense).


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-19-000006:notes:288]
Recent Accounting Pronouncements: In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842”; ASU No. 2018-10, “Codification Improvements to Topic 842, Leases”; and ASU No. 2018-11, “Targeted Improvements.” The new standard establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement.

[0000068505-19-000006:notes:289]
The ASU is effective for the Company on January 1, 2019. A modified retrospective transition approach is required, applying the new standard to all leases existing at the date of initial application. An entity may choose to use either the effective date or the beginning of the earliest comparative period presented in the financial statements as its date of initial application. The Company will adopt the new standard on January 1, 2019 and use the effective date as the date of initial application. Consequently, financial information will not be updated and disclosures required under the new standard will not be provided for dates and periods before January 1, 2019.

[0000068505-19-000006:notes:290]
The new standard provides for a number of optional practical expedients in transition. The Company will elect the practical expedients, which permits the Company to not reassess prior conclusions about lease identification, lease classification and initial direct costs under the new standard. The Company does not expect to elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised.

[0000068505-19-000006:notes:291]
The new standard also provides practical expedients for an entity’s ongoing accounting. The Company currently expects to elect the short-term lease recognition exemption for all leases that qualify. This means, for those leases that qualify, The Company will not recognize ROU assets or lease liabilities, and this includes not recognizing ROU assets or lease liabilities for existing short-term leases in transition. The Company also currently expects to elect the practical expedient to not separate lease and non-lease components for all leases.

[0000068505-19-000006:notes:292]
The Company is continuing to assess the impact of the ASU on its consolidated financial statements, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects to recognize additional operating lease liabilities ranging from $600 million to $650 million, with corresponding ROU assets of the same amount based on the present value of the remaining minimum rental payments determined under current leasing standards for existing operating leases less accumulated impairment losses.

[0000068505-19-000006:notes:293]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-19-000006:notes:294]
Recently Adopted Accounting Pronouncements: The Company early adopted ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" on December 1, 2018, using the modified retrospective method of adoption. The ASU requires a cumulative effect adjustment to the opening balance of retained earnings as of the beginning of the fiscal year of adoption for the previously recorded ineffectiveness included in retained earnings related to existing net investment hedges as of the date of adoption. The Company did not record a cumulative effect adjustment to retained earnings as no net investment hedges existed as of the ASU adoption date. New hedging relationships entered after the adoption date have been presented in the financial statements using the guidance of the ASU. There were no material changes to the Company’s financial statements from the adoption of the ASU.

[0000068505-19-000006:notes:295]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. The Company recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-19-000006:notes:296]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $75 million of benefits, $2 million of expense, and $19 million of benefits in the years ended December 31, 2018, 2017 and 2016, respectively.

[0000068505-19-000006:notes:297]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-19-000006:notes:298]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its Systems and Systems Integration contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-19-000006:notes:299]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-19-000006:notes:300]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

[0000068505-19-000006:notes:301]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

[0000068505-19-000006:notes:302]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-19-000006:notes:303]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

[0000068505-19-000006:notes:304]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 is as follows:

[0000068505-19-000006:notes:305]
Balance Sheet (Selected captions)

[0000068505-19-000006:notes:306]
| (In millions) | December 31, 2017 |  | Reclassification of Contract Assets |  | Reclassification of Non-customer receivables |  | Reclassification of Contract Liabilities |  | Impact of Adoption on Open Contracts |  | January 1, 2018 |
|  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |
| ASSETS |
| Accounts receivable, net | $ | 1,523 |  |  | $ | (297 | ) |  | $ | (24 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | 1,198 |  |
| Contract assets | — |  |  | 846 |  |  | — |  |  | — |  |  | 85 |  |  | 931 |  |
| Inventories, net | 327 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 328 |  |
| Other current assets | 832 |  |  | (549 | ) |  | 24 |  |  | — |  |  | (23 | ) |  | 284 |  |
| Deferred income taxes | 1,023 |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | 982 |  |
| Other assets | 333 |  |  | — |  |  | — |  |  | — |  |  | 85 |  |  | 418 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Contract liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | (17 | ) |  | $ | 1,082 |  |
| Accrued liabilities | 2,286 |  |  | — |  |  | — |  |  | (1,099 | ) |  | — |  |  | 1,187 |  |
| Other liabilities | 2,585 |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | 2,578 |  |
| Stockholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings | 467 |  |  | — |  |  | — |  |  | — |  |  | 127 |  |  | 594 |  |

[0000068505-19-000006:notes:307]
The impact of the adoption of ASC 606 to the consolidated financial statements for the year ended December 31, 2018 is as follows:

[0000068505-19-000006:notes:308]
Statements of Operations (Selected captions)

[0000068505-19-000006:notes:309]
|  | Year Ended |
| (In millions) | December 31, 2018 |  | Adjustments due to ASC 606 |  | December 31, 2018 Balances Under ASC 605 |
| Net sales | $ | 7,343 |  |  | $ | (83 | ) |  | $ | 7,260 |  |
| Gross margin | 3,480 |  |  | (82 | ) |  | 3,398 |  |
| Selling, general and administrative expenses | 1,254 |  |  | (64 | ) |  | 1,190 |  |
| Operating earnings | 1,255 |  |  | (18 | ) |  | 1,237 |  |
| Net earnings before income taxes | 1,102 |  |  | (18 | ) |  | 1,084 |  |
| Net earnings attributable to Motorola Solutions Inc. | 966 |  |  | (18 | ) |  | 948 |  |

[0000068505-19-000006:notes:310]
| (In millions) | December 31, 2018 |  | Adjustments due to ASC 606 |  | December 31, 2018 Balances Under ASC 605 |
| ASSETS |
| Accounts receivable, net | $ | 1,293 |  |  | $ | 416 |  |  | $ | 1,709 |  |
| Contract assets | 1,012 |  |  | (1,012 | ) |  | — |  |
| Other current assets | 354 |  |  | 531 |  |  | 885 |  |
| Deferred income taxes | 985 |  |  | 41 |  |  | 1,026 |  |
| Other assets | 344 |  |  | (99 | ) |  | 245 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |
| Contract liabilities | $ | 1,263 |  |  | $ | (1,263 | ) |  | $ | — |  |
| Accrued liabilities | 1,210 |  |  | 1,275 |  |  | 2,485 |  |
| Other liabilities | 2,300 |  |  | 10 |  |  | 2,310 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 1,051 |  |  | (145 | ) |  | 906 |  |

[0000068505-19-000006:notes:311]
There is no impact to the Consolidated Statements of Comprehensive Income (Loss) or the Statements of Cash Flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the Consolidated Balance Sheet and disclosed above.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-19-000006:notes:312]
Retirement Benefits

[0000068505-19-000006:notes:313]
Pension and Postretirement Health Care Benefits Plans

[0000068505-19-000006:notes:314]
The Company’s non-contributory U.S. pension plan (the "U.S. Pension Plan") provides benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. Effective January 1, 2007, eligible compensation was capped at the IRS limit plus $175,000 (the "Cap") or, for those already in excess of the Cap as of January 1, 2007, the eligible compensation used to compute such employee's MSPP benefit for all future years is the greater of: (i) such employee's eligible compensation as of January 1, 2007 (frozen at that amount) or (ii) the relevant Cap for the given year. In December 2008, the Company amended the U.S. Pension Plan and MSSP (together the "U.S. Pension Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-19-000006:notes:315]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of amendments, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. During 2014, the Postretirement Health Care Benefits Plan was then further amended ("The New Amendment") to provide the annual subsidy discussed as part of the Original Amendment to all participants remaining under the plan effective March 1, 2015. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-19-000006:notes:316]
The amendments to the Postretirement Health Care Benefits Plan required remeasurement of the plan, resulting in a reduction in the Postretirement Benefit Obligation. A substantial portion of the decrease related to prior service credits and will be amortized as a credit to the Consolidated Statements of Operations over approximately five years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan.

[0000068505-19-000006:notes:317]
Non U.S. Pension Benefit Plans

[0000068505-19-000006:notes:318]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-19-000006:notes:319]
In June 2015, the Company amended its Non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-19-000006:notes:320]
During the years ended December 31, 2017 and 2016, the Company offered lump-sum settlements to certain participants in the Non-U.S. defined benefit plan within the United Kingdom. The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments. As a result of the actions taken, the Company recorded settlement losses of $48 million and $26 million in 2017 and 2016, respectively, which are recorded within Other income (expense) within the Consolidated Statement of Operations.

[0000068505-19-000006:notes:321]
Net Periodic Cost (Benefit)

[0000068505-19-000006:notes:322]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-19-000006:notes:323]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 186 |  |  | 185 |  |  | 182 |  |  | 38 |  |  | 40 |  |  | 55 |  |  | 2 |  |  | 3 |  |  | 4 |  |
| Expected return on plan assets | (270 | ) |  | (229 | ) |  | (220 | ) |  | (92 | ) |  | (92 | ) |  | (93 | ) |  | (10 | ) |  | (10 | ) |  | (9 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 57 |  |  | 44 |  |  | 37 |  |  | 15 |  |  | 16 |  |  | 11 |  |  | 4 |  |  | 5 |  |  | 5 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (15 | ) |  | (18 | ) |  | (27 | ) |
| Settlement loss | — |  |  | — |  |  | — |  |  | — |  |  | 48 |  |  | 26 |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (27 | ) |  | $ | — |  |  | $ | (1 | ) |  | $ | (36 | ) |  | $ | 15 |  |  | $ | 10 |  |  | $ | (19 | ) |  | $ | (20 | ) |  | $ | (27 | ) |

[0000068505-19-000006:notes:324]
The benefit obligation and plan assets for the Company's U.S. Pension Benefit Plan and Postretirement Health Care Benefit Plan are measured as of December 31, 2018. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-19-000006:notes:325]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from ten to thirty-one years. Prior service costs will be amortized over periods ranging from two to five years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-19-000006:notes:326]
The net periodic cost for 2019 will include amortization of the unrecognized net loss for the U.S. Pension Benefit Plans and Non U.S. Pension Benefit Plans, currently included in Accumulated other comprehensive income (loss), of $47 million and $16 million, respectively. It is estimated that the 2019 net periodic expense for the Postretirement Health Care Benefits Plan will include amortization of net periodic benefits of $11 million, comprised of unrecognized net losses and prior service benefits, currently included in Accumulated other comprehensive income (loss).

[0000068505-19-000006:notes:327]
Actuarial Assumptions

[0000068505-19-000006:notes:328]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-19-000006:notes:329]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined pension benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-19-000006:notes:330]
The Company used Mortality Improvement Scale MP-2016 to calculate the 2018, 2017, and 2016 projected benefit obligations.

[0000068505-19-000006:notes:331]
Investment Policy

[0000068505-19-000006:notes:332]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-19-000006:notes:333]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-19-000006:notes:334]
Cash Funding

[0000068505-19-000006:notes:335]
The Company made $503 million of contributions, of which $500 million was voluntary, and $3 million of contributions to its U.S. Pension Benefit Plans during 2018 and 2017, respectively. The Company contributed $8 million to its Non U.S. Pension Benefit Plans during 2018, compared to $7 million contributed in 2017. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2018 or 2017.

[0000068505-19-000006:notes:336]
Expected Future Benefit Payments

[0000068505-19-000006:notes:337]
Other Benefit Plans

[0000068505-19-000006:notes:338]
Split-Dollar Life Insurance Arrangements

[0000068505-19-000006:notes:339]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-19-000006:notes:340]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2018, 2017 and 2016. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $61 million and $62 million as of December 31, 2018 and December 31, 2017, respectively.

[0000068505-19-000006:notes:341]
Deferred Compensation Plan

[0000068505-19-000006:notes:342]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-19-000006:notes:343]
Defined Contribution Plan

[0000068505-19-000006:notes:344]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the 401(k) plan is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2018, 2017 and 2016 were $31 million, $28 million and $26 million, respectively.

[0000068505-19-000006:notes:345]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2018, 2017, and 2016 the Company made no discretionary contributions.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000068505-19-000006:notes:346]
Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, five to twenty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-19-000006:notes:347]
Quarterly and Other Financial Data (unaudited)

[0000068505-19-000006:notes:348]
|  | 2018 |  | 2017 |
|  | 1st |  | 2nd |  | 3rd |  | 4th |  | 1st |  | 2nd |  | 3rd |  | 4th |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,468 |  |  | $ | 1,760 |  |  | $ | 1,862 |  |  | $ | 2,254 |  |  | $ | 1,281 |  |  | $ | 1,497 |  |  | $ | 1,645 |  |  | $ | 1,957 |  |
| Costs of sales | 799 |  |  | 938 |  |  | 961 |  |  | 1,166 |  |  | 711 |  |  | 807 |  |  | 851 |  |  | 987 |  |
| Gross margin | 669 |  |  | 822 |  |  | 901 |  |  | 1,088 |  |  | 570 |  |  | 690 |  |  | 794 |  |  | 970 |  |
| Selling, general and administrative expenses | 279 |  |  | 316 |  |  | 323 |  |  | 337 |  |  | 244 |  |  | 254 |  |  | 259 |  |  | 267 |  |
| Research and development expenditures | 152 |  |  | 162 |  |  | 158 |  |  | 165 |  |  | 135 |  |  | 138 |  |  | 141 |  |  | 155 |  |
| Other charges | 67 |  |  | 71 |  |  | 126 |  |  | 70 |  |  | 18 |  |  | 37 |  |  | 47 |  |  | 45 |  |
| Operating earnings | 171 |  |  | 273 |  |  | 294 |  |  | 516 |  |  | 173 |  |  | 261 |  |  | 347 |  |  | 503 |  |
| Net earnings (loss)* | 117 |  |  | 180 |  |  | 247 |  |  | 423 |  |  | 77 |  |  | 131 |  |  | 212 |  |  | (575 | ) |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings (loss)*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 0.73 |  |  | $ | 1.11 |  |  | $ | 1.52 |  |  | $ | 2.58 |  |  | $ | 0.47 |  |  | $ | 0.80 |  |  | $ | 1.30 |  |  | $ | (3.56 | ) |
| Diluted earnings per common share | 0.69 |  |  | 1.05 |  |  | 1.43 |  |  | 2.44 |  |  | 0.45 |  |  | 0.78 |  |  | 1.25 |  |  | (3.56 | ) |
| Dividends declared | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 0.57 |  |  | $ | 0.47 |  |  | $ | 0.47 |  |  | $ | 0.47 |  |  | $ | 0.52 |  |
| Dividends paid | 0.52 |  |  | 0.52 |  |  | 0.52 |  |  | 0.52 |  |  | 0.47 |  |  | 0.47 |  |  | 0.47 |  |  | 0.47 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 110.29 |  |  | $ | 118.37 |  |  | $ | 130.34 |  |  | $ | 133.97 |  |  | $ | 87.00 |  |  | $ | 89.15 |  |  | $ | 93.75 |  |  | $ | 95.30 |  |
| Low | $ | 89.18 |  |  | $ | 103.18 |  |  | $ | 114.95 |  |  | $ | 108.25 |  |  | $ | 76.92 |  |  | $ | 79.63 |  |  | $ | 82.86 |  |  | $ | 84.56 |  |

[0000068505-19-000006:notes:349]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.


## us-gaap:ReceivablesPolicyTextBlock

[0000068505-19-000006:notes:350]
Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-19-000006:notes:351]
Reorganization of Businesses

[0000068505-19-000006:notes:352]
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits. In addition to the Severance Plan, during the year ended December 31, 2016, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at six months of salary, were equalized for all employment level grades and capped at a full year’s salary.

[0000068505-19-000006:notes:353]
The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-19-000006:notes:354]
During 2018, 2017, and 2016 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. As a result, the Company communicated its plan to close one of its manufacturing facilities in Europe during the fourth quarter of 2018 resulting in a charge of $44 million and impacting 165 employees, primarily within the Products and Systems Integration segment. The remainder of the initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-19-000006:notes:355]
2018 Charges

[0000068505-19-000006:notes:356]
During 2018, the Company recorded net reorganization of business charges of $120 million, including $59 million of charges in Costs of sales and $61 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $120 million were charges of $122 million for employee separation costs and $16 million for exit costs, partially offset by $18 million of reversals of accruals no longer needed.

[0000068505-19-000006:notes:357]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2018 to December 31, 2018:

[0000068505-19-000006:notes:358]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 9 |  |  | $ | 16 |  |  | $ | — |  |  | $ | (4 | ) |  | $ | 21 |  |
| Employee separation costs | 41 |  |  | 122 |  |  | (18 | ) |  | (61 | ) |  | 84 |  |
|  | $ | 50 |  |  | $ | 138 |  |  | $ | (18 | ) |  | $ | (65 | ) |  | $ | 105 |  |

[0000068505-19-000006:notes:359]
Exit Costs

[0000068505-19-000006:notes:360]
At January 1, 2018, the Company had $9 million accrual for exit costs. There were $16 million of additional charges in 2018. The $4 million used in 2018 reflects cash payments. The remaining accrual of $21 million, which the current portion is included in Accrued liabilities and the non-current portion is included in Other liabilities in the Company’s Consolidated Balance Sheet at December 31, 2018, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-19-000006:notes:361]
Employee Separation Costs

[0000068505-19-000006:notes:362]
At January 1, 2018, the Company had an accrual of $41 million for employee separation costs. The 2018 additional charges of $122 million represent severance costs for approximately an additional 1,200 employees, of which 500 were direct employees and 700 were indirect employees. The adjustments of $18 million reflect reversals of accruals no longer needed. The $61 million used in 2018 reflects cash payments to severed employees. The remaining accrual of $84 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2018, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 200 employees to be separated in 2019.

[0000068505-19-000006:notes:363]
2017 Charges

[0000068505-19-000006:notes:364]
During 2017, the Company recorded net reorganization of business charges of $42 million, including $9 million of charges in Costs of sales and $33 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $42 million were charges of $43 million for employee separation costs and $8 million for exit costs, partially offset by $9 million of reversals of accruals no longer needed.

[0000068505-19-000006:notes:365]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2017 to December 31, 2017:

[0000068505-19-000006:notes:366]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 7 |  |  | $ | 8 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 9 |  |
| Employee separation costs | 94 |  |  | 43 |  |  | (9 | ) |  | (87 | ) |  | 41 |  |
|  | $ | 101 |  |  | $ | 51 |  |  | $ | (9 | ) |  | $ | (93 | ) |  | $ | 50 |  |

[0000068505-19-000006:notes:367]
At January 1, 2017, the Company had $7 million accrual for exit costs. There were $8 million of additional charges in 2017. The $6 million used in 2017 reflects cash payments. The remaining accrual of $9 million, which the current portion was included in Accrued liabilities and the non-current portion was included in Other liabilities in the Company’s Consolidated Balance Sheet at December 31, 2017, primarily represented future cash payments for lease obligations.

[0000068505-19-000006:notes:368]
At January 1, 2017, the Company had an accrual of $94 million for employee separation costs. The additional 2017 charges of $43 million represent severance costs for approximately an additional 400 employees, of which 100 were direct employees and 300 were indirect employees. The adjustments of $9 million reflect reversals of accruals no longer needed. The $87 million used in 2017 reflects cash payments to severed employees. The remaining accrual of $41 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2017.

[0000068505-19-000006:notes:369]
2016 Charges

[0000068505-19-000006:notes:370]
During 2016, the Company recorded net reorganization of business charges of $140 million, including $43 million of charges in Costs of sales and $97 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $140 million are charges of: (i) $120 million for employee separation costs, (ii) a $17 million building impairment charge, (iii) $5 million of charges for exit costs, and (iv) $3 million for the impairment of corporate aircraft, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-19-000006:notes:371]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2016 to December 31, 2016:

[0000068505-19-000006:notes:372]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 9 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | (6 | ) |  | $ | 7 |  |
| Employee separation costs | 51 |  |  | 120 |  |  | (4 | ) |  | (73 | ) |  | 94 |  |
|  | $ | 60 |  |  | $ | 125 |  |  | $ | (5 | ) |  | $ | (79 | ) |  | $ | 101 |  |

[0000068505-19-000006:notes:373]
At January 1, 2016, the Company had $9 million accrual for exit costs. There were $5 million of additional charges in 2016. The $6 million used in 2016 reflects cash payments. The remaining accrual of $7 million, which the current portion was included in Accrued liabilities and the non-current portion was included in Other liabilities in the Company’s Consolidated Balance Sheet at December 31, 2016, primarily represented future cash payments for lease obligations.

[0000068505-19-000006:notes:374]
At January 1, 2016, the Company had an accrual of $51 million for employee separation costs. The additional 2016 charges of $120 million represent severance costs for approximately an additional 1,300 employees, of which 400 were direct employees and 900 were indirect employees. The adjustments of $4 million reflect of reversals of accruals no longer needed. The $73 million used in 2016 reflects cash payments to these severed employees. The remaining accrual of $94 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2016.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000068505-19-000006:notes:375]
Net sales consist of a wide range of goods and services including the delivery of devices, systems and system integration and a full set of software and service offerings. The Company recognizes revenues when, or as, it transfers control of promised goods or services to its customers in an amount that reflects the consideration to which it expects to be entitled to in exchange for those goods and services. Refer to Note 2 for further discussion of the Company’s accounting policies for revenue from contract with its customers.

[0000068505-19-000006:notes:376]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

[0000068505-19-000006:notes:377]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

[0000068505-19-000006:notes:378]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

[0000068505-19-000006:notes:379]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) non-cash consideration, and (iv) consideration payable to a customer.

[0000068505-19-000006:notes:380]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

[0000068505-19-000006:notes:381]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-19-000006:notes:382]
Revenue from Contracts with Customers

[0000068505-19-000006:notes:383]
Disaggregation of Revenue

[0000068505-19-000006:notes:384]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government, public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-19-000006:notes:385]
Devices: Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Devices also includes video cameras sold by Avigilon. Devices are considered capable of being distinct and distinct within the context of our contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-19-000006:notes:386]
Systems and Systems Integration: Systems and Systems Integration include customized radio network, video solutions and implementation, optimization, and integration of networks, devices, software, and applications. Radio network includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, and repeaters. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Systems and Systems Integration revenue is recognized over an average duration of approximately one to two years.

[0000068505-19-000006:notes:387]
Systems also include Avigilon security and video solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-19-000006:notes:388]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-19-000006:notes:389]
Services:  Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer or Motorola Solutions-owned networks. Services are provided across all radio network technologies. Services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-19-000006:notes:390]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-19-000006:notes:391]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis.

[0000068505-19-000006:notes:392]
Significant Judgments

[0000068505-19-000006:notes:393]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-19-000006:notes:394]
The Company accounts for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-19-000006:notes:395]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-19-000006:notes:396]
Remaining Performance Obligations

[0000068505-19-000006:notes:397]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of December 31, 2018 is $7.2 billion. A total of $3.2 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.0 billion is from Services and Software performance obligations that are not yet satisfied as of December 31, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-19-000006:notes:398]
Contract Balances

[0000068505-19-000006:notes:399]
Contract assets consist of amounts formerly classified as Costs and earnings in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of costs and earnings recognized, Customer downpayments and Deferred revenue.

[0000068505-19-000006:notes:400]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-19-000006:notes:401]
Revenue recognized during the year ended December 31, 2018 which was previously included in Contract liabilities as of January 1, 2018 was $836 million. Revenue of $15 million was reversed during the year ended December 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-19-000006:notes:402]
There have been no material impairment losses recognized on contract assets during the year ended December 31, 2018.

[0000068505-19-000006:notes:403]
Contract Cost Balances

[0000068505-19-000006:notes:404]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $44 million for the year ended December 31, 2018.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000068505-19-000006:notes:405]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| United States | $ | 4,361 |  |  | $ | 3,725 |  |  | $ | 3,566 |  |  | $ | 5,441 |  |  | $ | 5,138 |  |  | $ | 5,653 |  |
| United Kingdom | 638 |  |  | 558 |  |  | 528 |  |  | 2,284 |  |  | 2,329 |  |  | 2,300 |  |
| Canada | 303 |  |  | 251 |  |  | 222 |  |  | 1,014 |  |  | 97 |  |  | 91 |  |
| Other, net of eliminations | 2,041 |  |  | 1,846 |  |  | 1,722 |  |  | 670 |  |  | 644 |  |  | 419 |  |
|  | $ | 7,343 |  |  | $ | 6,380 |  |  | $ | 6,038 |  |  | $ | 9,409 |  |  | $ | 8,208 |  |  | $ | 8,463 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-19-000006:notes:406]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-19-000006:notes:407]
|  | Net Sales |  | Operating Earnings |
| Years ended December 31 | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| Products and Systems Integration | $ | 5,100 |  |  | $ | 4,513 |  |  | $ | 4,394 |  |  | $ | 854 |  |  | $ | 969 |  |  | $ | 762 |  |
| Services and Software | 2,243 |  |  | 1,867 |  |  | 1,644 |  |  | 401 |  |  | 315 |  |  | 286 |  |
|  | $ | 7,343 |  |  | $ | 6,380 |  |  | $ | 6,038 |  |  | 1,255 |  |  | 1,284 |  |  | 1,048 |  |
| Total other expense |  |  |  |  |  |  | (153 | ) |  | (208 | ) |  | (204 | ) |
| Net earnings before income taxes |  |  |  |  |  |  | $ | 1,102 |  |  | $ | 1,076 |  |  | $ | 844 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-19-000006:notes:408]
Information by Segment and Geographic Region

[0000068505-19-000006:notes:409]
The Company conducts its business globally and manages it through the following two segments:

[0000068505-19-000006:notes:410]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, including video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions and typically managing a mobile workforce. In 2018, the segment’s net sales were $5.1 billion, representing 69% of the Company's consolidated net sales.

[0000068505-19-000006:notes:411]
Services and Software: The Services and Software segment provides a broad range of solution offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced platforms include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on premise and “as a service.” In 2018, the segment’s net sales were $2.2 billion, representing 31% of the Company's consolidated net sales.

[0000068505-19-000006:notes:412]
For the years ended December 31, 2018, 2017 and 2016, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-19-000006:notes:413]
Segment Information

[0000068505-19-000006:notes:414]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-19-000006:notes:415]
Geographic Area Information

[0000068505-19-000006:notes:416]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-19-000006:notes:417]
Summary of Significant Accounting Policies

[0000068505-19-000006:notes:418]
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-19-000006:notes:419]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-19-000006:notes:420]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of devices, systems and system integration and a full set of software and service offerings. The Company recognizes revenues when, or as, it transfers control of promised goods or services to its customers in an amount that reflects the consideration to which it expects to be entitled to in exchange for those goods and services. Refer to Note 2 for further discussion of the Company’s accounting policies for revenue from contract with its customers.

[0000068505-19-000006:notes:421]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $11 million at December 31, 2018 and $63 million at December 31, 2017.

[0000068505-19-000006:notes:422]
Investments: Investments in debt securities classified as available-for-sale are carried at fair value with changes in fair value recorded in other comprehensive income. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-19-000006:notes:423]
Inventories: Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or net realizable value.

[0000068505-19-000006:notes:424]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, five to twenty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-19-000006:notes:425]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and SG&A costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it’s determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform the first step of the impairment process, which compares the fair value of the reporting unit to its book value. If the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-19-000006:notes:426]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-19-000006:notes:427]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-19-000006:notes:428]
Long-term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-19-000006:notes:429]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the “Accrued liabilities” statement line and the non-current portion is included in the “Other liabilities” statement line within the Company’s Consolidated Balance Sheet.

[0000068505-19-000006:notes:430]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-19-000006:notes:431]
Derivative Instruments: Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income (loss). Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income (loss) at their initial value and amortized into Interest expense, net on a straight-line basis.

[0000068505-19-000006:notes:432]
Earnings Per Share: The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for net earnings attributable to Motorola Solutions, Inc. for all periods presented.

[0000068505-19-000006:notes:433]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance-based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-19-000006:notes:434]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s Consolidated Balance Sheets using a December 31 measurement date.

[0000068505-19-000006:notes:435]
Recent Acquisitions

[0000068505-19-000006:notes:436]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a leading global provider of data and image analytics for vehicle location for a purchase price of $445 million. This acquisition expands the Company's command center software portfolio.

[0000068505-19-000006:notes:437]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million.

[0000068505-19-000006:notes:438]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-19-000006:notes:439]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk for commercial customers, for a purchase price of $225 million.

[0000068505-19-000006:notes:440]
On March 13, 2017, the Company completed the acquisition of Interexport, a managed service provider of communications systems to public safety and commercial customers in Chile, for a purchase price of $98 billion Chilean pesos, or approximately $147 million.

[0000068505-19-000006:notes:441]
On November 10, 2016, the Company completed the acquisition of Spillman Technologies ("Spillman"), a provider of comprehensive law enforcement and public safety software solutions, for a purchase price of $221 million. The acquisition expands the Company's command center software and services portfolio and enables it to offer a full suite of solutions to a broader customer base.

[0000068505-19-000006:notes:442]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt.
