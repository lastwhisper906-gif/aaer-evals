# MSI note change history — 0000068505-18-000023 → 0000068505-18-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000068505-18-000029:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at September 29, 2018.
  (was, 2018-08-03, similarity 0.9892):
[0000068505-18-000023:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at June 30, 2018.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000068505-18-000029:note_history:2]
The condensed consolidated financial statements as of September 29, 2018 and for the three and nine months ended September 29, 2018 and September 30, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2018-08-03, similarity 0.9321):
[0000068505-18-000023:note_history:2]
The condensed consolidated financial statements as of June 30, 2018 and for the three and six months ended June 30, 2018 and July 1, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2018-11-02):
[0000068505-18-000029:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three and nine months ended September 29, 2018 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2018-08-03, similarity 0.8076):
[0000068505-18-000023:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three and six months ended June 30, 2018 are not necessarily indicative of the operating results to be expected for the full year.

- added (2018-11-02):
[0000068505-18-000029:note_history:4]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

- added (2018-11-02):
[0000068505-18-000029:note_history:5]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

- added (2018-11-02):
[0000068505-18-000029:note_history:6]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. In July 2018, the FASB issued ASU 2018-11 that amended the ASU to include an additional (and optional) transition relief. The additional transition relief provides entities the option to adopt the ASU by applying the new ASU at the adoption date and recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption without restatement of comparative periods. The new ASU must be adopted utilizing the modified retrospective method as of the earliest comparative period presented if the optional adoption method is not selected. The Company will adopt the ASU on January 1, 2019, utilizing the modified retrospective method as of the adoption date. The Company is continuing to assess the impact of the ASU on its condensed consolidated financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects a material impact to its condensed consolidated balance sheet through the recording of right-of-use assets and lease obligations that are not required to be recorded within the condensed consolidated balance sheet under current accounting standards.

- added (2018-11-02):
[0000068505-18-000029:note_history:7]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires entities to estimate and recognize current expected credit losses rather than delay recognition of credit losses until the loss is probable of occurring. The ASU is effective for the Company on January 1, 2020, and interim periods within that reporting period with early option permitted. The Company is currently evaluating the impact of the ASU on its consolidated financial statements and disclosures.

- added (2018-11-02):
[0000068505-18-000029:note_history:8]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2020 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

- changed (2018-11-02):
[0000068505-18-000029:note_history:9]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $18 million and $10 million in the three months ended September 29, 2018 and September 30, 2017, respectively, and $58 million and $10 million in the nine months ended September 29, 2018 and September 30, 2017, respectively.
  (was, 2018-08-03, similarity 0.9499):
[0000068505-18-000023:note_history:9]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company recorded $20 million and $4 million in the three months ended June 30, 2018 and July 1, 2017, respectively, and $40 million and $1 million in the six months ended June 30, 2018 and July 1, 2017, respectively.

- changed (2018-11-02):
[0000068505-18-000029:note_history:10]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.
  (was, 2018-08-03, similarity 0.9978):
[0000068505-18-000023:note_history:10]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as a non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

- changed (2018-11-02):
[0000068505-18-000029:note_history:11]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.
  (was, 2018-08-03, similarity 0.9955):
[0000068505-18-000023:note_history:11]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer respectively. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

- changed (2018-11-02):
[0000068505-18-000029:note_history:12]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three and nine months ended September 29, 2018 is as follows:
  (was, 2018-08-03, similarity 0.9459):
[0000068505-18-000023:note_history:12]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three and six months ended June 30, 2018 is as follows:

- changed (2018-11-02):
[0000068505-18-000029:note_history:13]
|  | Three Months Ended |
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,862 |  |  | $ | (19 | ) |  | $ | 1,843 |  |
| Gross margin | 901 |  |  | (18 | ) |  | 883 |  |
| Selling, general and administrative expenses | 323 |  |  | (17 | ) |  | 306 |  |
| Operating earnings | 294 |  |  | (1 | ) |  | 293 |  |
| Net earnings before income taxes | 270 |  |  | (1 | ) |  | 269 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 247 |  |  | $ | (1 | ) |  | $ | 246 |  |
  (was, 2018-08-03, similarity 0.9512):
[0000068505-18-000023:note_history:13]
|  | Three Months Ended |
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,760 |  |  | $ | (24 | ) |  | $ | 1,736 |  |
| Gross margin | 822 |  |  | (24 | ) |  | 798 |  |
| Selling, general and administrative expenses | 316 |  |  | (16 | ) |  | 300 |  |
| Operating Earnings | 273 |  |  | (8 | ) |  | 265 |  |
| Net earnings before income taxes | 227 |  |  | (8 | ) |  | 219 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 180 |  |  | $ | (8 | ) |  | $ | 172 |  |

- changed (2018-11-02):
[0000068505-18-000029:note_history:14]
|  | Nine Months Ended |
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| Net sales | $ | 5,089 |  |  | $ | (58 | ) |  | $ | 5,031 |  |
| Gross margin | 2,392 |  |  | (57 | ) |  | 2,335 |  |
| Selling, general and administrative expenses | 918 |  |  | (46 | ) |  | 872 |  |
| Operating earnings | 739 |  |  | (11 | ) |  | 728 |  |
| Net earnings before income taxes | 637 |  |  | (11 | ) |  | 626 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 544 |  |  | $ | (11 | ) |  | $ | 533 |  |
  (was, 2018-08-03, similarity 0.6959):
[0000068505-18-000023:note_history:14]
|  | Six Months Ended |
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Net sales | 3,227 |  |  | (39 | ) |  | 3,188 |  |
| Gross margin | 1,491 |  |  | (39 | ) |  | 1,452 |  |
| Selling, general and administrative expenses | 594 |  |  | (29 | ) |  | 565 |  |
| Operating Earnings | 445 |  |  | (10 | ) |  | 435 |  |
| Net earnings before income taxes | 367 |  |  | (10 | ) |  | 357 |  |
| Net earnings attributable to Motorola Solutions Inc. | 297 |  |  | (10 | ) |  | 287 |  |

- added (2018-11-02):
[0000068505-18-000029:note_history:15]
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| ASSETS |
| Accounts receivable, net | $ | 1,179 |  |  | $ | 315 |  |  | $ | 1,494 |  |
| Contract assets | 917 |  |  | (917 | ) |  | — |  |
| Other current assets | 350 |  |  | 540 |  |  | 890 |  |
| Deferred income taxes | 949 |  |  | 41 |  |  | 990 |  |
| Other assets | 444 |  |  | (95 | ) |  | 349 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |
| Contract liabilities | $ | 1,127 |  |  | $ | (1,127 | ) |  | $ | — |  |
| Accrued liabilities | 1,168 |  |  | 1,139 |  |  | 2,307 |  |
| Other liabilities | 2,175 |  |  | 10 |  |  | 2,185 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 788 |  |  | (138 | ) |  | 650 |  |

- changed (2018-11-02):
[0000068505-18-000029:note_history:16]
There is no impact to the condensed consolidated statement of comprehensive income or the statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the condensed consolidated balance sheet and disclosed above.
  (was, 2018-08-03, similarity 0.9105):
[0000068505-18-000023:note_history:16]
There is no impact to the Statement of comprehensive income or the Statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the balance sheet and disclosed above.

- removed (2018-11-02):
[0000068505-18-000023:note_history:17]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The Company will adopt the ASU on January 1, 2019, utilizing the modified retrospective method upon adoption. The Company has begun to assess the impact of the ASU on its financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects a material impact to its balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards.

- removed (2018-11-02):
[0000068505-18-000023:note_history:18]
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Accounts receivable, net | $ | 1,159 |  |  | $ | 205 |  |  | $ | 1,364 |  |
| Contract assets | 760 |  |  | (760 | ) |  | — |  |
| Other current assets | 330 |  |  | 491 |  |  | 821 |  |
| Deferred income taxes | 945 |  |  | 41 |  |  | 986 |  |
| Other assets | 420 |  |  | (92 | ) |  | 328 |  |
| Contract liabilities | $ | 1,049 |  |  | $ | (1,049 | ) |  | $ | — |  |
| Accrued liabilities | 1,096 |  |  | 1,061 |  |  | 2,157 |  |
| Other liabilities | 2,153 |  |  | 10 |  |  | 2,163 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 627 |  |  | (137 | ) |  | 490 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000068505-18-000029:note_history:19]
As of September 29, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, the Company borrowed $400 million under the facility to complete the Avigilon acquisition. As of September 29, 2018, the outstanding loan amount under the facility was $100 million, with $200 million paid during the third quarter. Subsequent to the quarter, the Company paid the remaining $100 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts for the three and nine months ended September 29, 2018 was 3.58%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 29, 2018.
  (was, 2018-08-03, similarity 0.7601):
[0000068505-18-000023:note_history:19]
As of June 30, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). During the first quarter of 2018, $400 million was borrowed under this facility for the Avigilon acquisition, of which $100 million was repaid during the three months ended June 30, 2018. As of June 30, 2018, the outstanding loan amount was $300 million. Subsequent to the quarter, the Company paid an additional $50 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts was 3.75%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 30, 2018.

- added (2018-11-02):
[0000068505-18-000029:note_history:20]
Also in conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the three and nine months ended September 29, 2018 were 3.33% and 3.43%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- added (2018-11-02):
[0000068505-18-000029:note_history:21]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.8252, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.45 per share). The exercise price adjusts automatically for dividends. On September 5, 2018, the Company agreed with Silver Lake Partners to repurchase $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. As of September 29, 2018, the Company paid $169 million of cash to Silver Lake Partners and recorded a gain of $6 million from the extinguishment of the convertible debt. The principal amount of $200 million was reclassified to short term debt. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of September 29, 2018 was $712 million. In the event of an additional conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- added (2018-11-02):
[0000068505-18-000029:note_history:22]
On September 28, 2018, the Company issued an additional $200 million on the outstanding 4.60% Senior notes due 2028 bringing the outstanding total to $700 million. The Company settled the issuance on October 5, 2018 and recognized net proceeds of $196 million, subsequent to quarter end, which was then used to pay the $200 million principal due to Silver Lake Partners on October 15, 2018.

- removed (2018-11-02):
[0000068505-18-000023:note_history:23]
To complete the acquisition of Avigilon in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable monthly, subject to the Company's discretion. The weighted average borrowing rate for amounts outstanding during the six months ended June 30, 2018 was 3.35%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- removed (2018-11-02):
[0000068505-18-000023:note_history:24]
Also in conjunction with the acquisition of Avigilon in March 2018, the Company assumed $75 million of borrowings under Avigilon's revolving credit facility, of which $35 million was repaid during the first quarter of 2018 with the remaining $40 million paid during the second quarter of 2018, resulting in the closure of the facility.

- removed (2018-11-02):
[0000068505-18-000023:note_history:25]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of June 30, 2018 was $682 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## msi:RevenuefromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-11-02):
[0000068505-18-000029:note_history:26]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

- added (2018-11-02):
[0000068505-18-000029:note_history:27]
Significant Judgments

- added (2018-11-02):
[0000068505-18-000029:note_history:28]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

- added (2018-11-02):
[0000068505-18-000029:note_history:29]
The Company accounts for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized product solutions. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

- added (2018-11-02):
[0000068505-18-000029:note_history:30]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000068505-18-000029:note_history:31]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2018-08-03, similarity 0.6595):
[0000068505-18-000023:note_history:31]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2018-11-02):
[0000068505-18-000029:note_history:32]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 957 |  |  | $ | 343 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 199 |  |  | 189 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 132 |  |  | 42 |  |  | 353 |  |  | 126 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 828 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 460 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 455 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 119 |  |  | — |  |  | 303 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 811 |  |  | $ | 543 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 477 |  |  | 31 |  |  | 1,261 |  |  | 74 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
  (was, 2018-08-03, similarity 0.9907):
[0000068505-18-000023:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 878 |  |  | $ | 331 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 188 |  |  | 194 |  |  | 345 |  |  | 375 |  |
| AP | 123 |  |  | 46 |  |  | 220 |  |  | 84 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 725 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 464 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 456 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 115 |  |  | — |  |  | 184 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 740 |  |  | $ | 537 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 449 |  |  | 34 |  |  | 784 |  |  | 44 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0000068505-18-000029:note_history:33]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2018-08-03, similarity 0.6595):
[0000068505-18-000023:note_history:33]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2018-11-02):
[0000068505-18-000029:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 957 |  |  | $ | 343 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 199 |  |  | 189 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 132 |  |  | 42 |  |  | 353 |  |  | 126 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 828 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 460 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 455 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 119 |  |  | — |  |  | 303 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 811 |  |  | $ | 543 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 477 |  |  | 31 |  |  | 1,261 |  |  | 74 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
  (was, 2018-08-03, similarity 0.9907):
[0000068505-18-000023:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 878 |  |  | $ | 331 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 188 |  |  | 194 |  |  | 345 |  |  | 375 |  |
| AP | 123 |  |  | 46 |  |  | 220 |  |  | 84 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 725 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 464 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 456 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 115 |  |  | — |  |  | 184 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 740 |  |  | $ | 537 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 449 |  |  | 34 |  |  | 784 |  |  | 44 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

- added (2018-11-02):
[0000068505-18-000029:note_history:35]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government, public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.

- changed (2018-11-02):
[0000068505-18-000029:note_history:36]
Systems also include Avigilon end-to-end security and surveillance solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.
  (was, 2018-08-03, similarity 0.9992):
[0000068505-18-000023:note_history:36]
Systems also includes Avigilon end-to-end security and surveillance solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

- added (2018-11-02):
[0000068505-18-000029:note_history:37]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

- changed (2018-11-02):
[0000068505-18-000029:note_history:38]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.
  (was, 2018-08-03, similarity 0.9989):
[0000068505-18-000023:note_history:38]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

- changed (2018-11-02):
[0000068505-18-000029:note_history:39]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis.
  (was, 2018-08-03, similarity 0.9985):
[0000068505-18-000023:note_history:39]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over-time as the customer simultaneously receives and consumes the services on a straight-line basis.

- changed (2018-11-02):
[0000068505-18-000029:note_history:40]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of September 29, 2018 is $6.1 billion. A total of $3.3 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.9 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $2.8 billion is from Services and Software performance obligations that are not yet satisfied as of September 29, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2018-08-03, similarity 0.9908):
[0000068505-18-000023:note_history:40]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 30, 2018 is $6.2 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.1 billion is from Services and Software performance obligations that are not yet satisfied as of June 30, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.1 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- added (2018-11-02):
[0000068505-18-000029:note_history:41]
| (in millions) | September 29, 2018 |  | January 1, 2018 |  |
| Receivables | $ | 1,179 |  |  | $ | 1,198 |  |
| Contract assets | 917 |  |  | 931 |  |
| Contract liabilities | 1,127 |  |  | 1,082 |  |
| Non-current contract liabilities | 159 |  |  | 162 |  |

- changed (2018-11-02):
[0000068505-18-000029:note_history:42]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.
  (was, 2018-08-03, similarity 0.9986):
[0000068505-18-000023:note_history:42]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over-time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

- added (2018-11-02):
[0000068505-18-000029:note_history:43]
Revenue recognized during the three months ended September 29, 2018 which was previously included in Contract liabilities as of July 1, 2018 is $327 million. Revenue recognized during the nine months ended September 29, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $777 million. Revenue of $7 million was reversed during the three months ended September 29, 2018 and $4 million of revenue was reversed during the nine months ended September 29, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

- changed (2018-11-02):
[0000068505-18-000029:note_history:44]
There have been no material impairment losses recognized on contract assets during the nine months ended September 29, 2018.
  (was, 2018-08-03, similarity 0.9304):
[0000068505-18-000023:note_history:44]
There have been no material impairment losses recognized on contract assets during the six months ended June 30, 2018.

- changed (2018-11-02):
[0000068505-18-000029:note_history:45]
| (in millions) | September 29, 2018 |  | January 1, 2018 |  |
| Current contract cost assets | $ | 57 |  |  | $ | 62 |  |
| Non-current contract cost assets | 95 |  |  | 85 |  |
  (was, 2018-08-03, similarity 0.926):
[0000068505-18-000023:note_history:45]
| (in millions) | January 1, 2018 |  |  | June 30, 2018 |  |
| Current contract cost assets | $ | 62 |  |  | $ | 47 |  |
| Non-current contract cost assets | 85 |  |  | 90 |  |

- changed (2018-11-02):
[0000068505-18-000029:note_history:46]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $11 million and $34 million for the three and nine months ended September 29, 2018, respectively.
  (was, 2018-08-03, similarity 0.9706):
[0000068505-18-000023:note_history:46]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $11 million and $23 million for the three and six months ended June 30, 2018, respectively.

- removed (2018-11-02):
[0000068505-18-000023:note_history:47]
The Company adopted ASC 606 and all the related amendments on January 1, 2018, applying the modified retrospective method to all contracts not completed as of the date of adoption. The cumulative effect of adopting ASC 606 for contracts that were open as of the date of adoption is recognized as an adjustment to opening retained earnings in the period of adoption. All of the periods prior to the adoption of ASC 606 will continue to reflect the financial results recognized under the guidance of the previous revenue recognition standard.

- removed (2018-11-02):
[0000068505-18-000023:note_history:48]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.

- removed (2018-11-02):
[0000068505-18-000023:note_history:49]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

- removed (2018-11-02):
[0000068505-18-000023:note_history:50]
| (in millions) | January 1, 2018 |  |  | June 30, 2018 |  |
| Receivables | $ | 1,198 |  |  | $ | 1,159 |  |
| Contract assets | 931 |  |  | 760 |  |
| Contract liabilities | 1,082 |  |  | 1,049 |  |
| Non-current contract liabilities | 162 |  |  | 180 |  |

- removed (2018-11-02):
[0000068505-18-000023:note_history:51]
Revenue recognized during the three months ended June 30, 2018 which was previously included in Contract liabilities as of April 1, 2018 is $365 million. Revenue recognized during the six months ended June 30, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $541 million. Revenue of $6 million was reversed during the three months ended June 30, 2018 and $3 million of revenue was recognized during the six months ended June 30, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.
