# MSI 8-K — 0000068505-19-000003 filed 2019-02-07

## item codes, every 8-K on or before 2019-02-15

- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2019-02-15

- none on or before 2019-02-15

## item 2.02 — earnings release, exhibit 99.1

[0000068505-19-000003:8k_2_02:1]
EX-99.1
2
msiq42018pressrelease1.htm
EXHIBIT 99.1

[0000068505-19-000003:8k_2_02:2]
Exhibit

[0000068505-19-000003:8k_2_02:3]
Exhibit 99.1

[0000068505-19-000003:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-19-000003:8k_2_02:5]
Record Q4 and 2018 revenue, earnings per share and ending backlog

[0000068505-19-000003:8k_2_02:6]
| • | Revenue of $2.3 billion, up 15 percent from Q4 in the prior year; up 15 percent for full year |

[0000068505-19-000003:8k_2_02:7]
| • | Backlog of $10.6 billion, up $988 million or 10 percent from a year ago |

[0000068505-19-000003:8k_2_02:8]
| • | Operating cash flow of $812 million, up $51 million from Q4 in the prior year |

[0000068505-19-000003:8k_2_02:9]
| • | GAAP earnings (loss) per share (EPS) of $2.44, up from ($3.56); $5.62 for full year, up from ($0.95) |

[0000068505-19-000003:8k_2_02:10]
| • | Non-GAAP EPS* of $2.63, up 25 percent; $7.15 for full year, up 31 percent |

[0000068505-19-000003:8k_2_02:11]
CHICAGO – Feb. 7, 2019 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full-year 2018. Click here for a printable news release and financial tables.

[0000068505-19-000003:8k_2_02:12]
“From strong organic revenue growth and cash generation to record EPS and backlog, we delivered an outstanding 2018, capped by an excellent fourth quarter,” said Greg Brown, chairman and CEO, Motorola Solutions.

[0000068505-19-000003:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-19-000003:8k_2_02:14]
|  | Fourth Quarter | Full Year |
|  | Q4 2018 |  | Q4 2017 |  | % Change | 2018 |  | 2017 |  | % Change |
| Sales | $2,254 | $1,957 | 15 | % | $7,343 | $6,380 | 15 | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $516 | $503 | 3 | % | $1,255 | $1,284 | (2 | )% |
| % of Sales | 22.9 | % | 25.7 | % |  | 17.1 | % | 20.1 | % |  |
| EPS | $2.44 | ($3.56) | N/M** |  | $5.62 | ($0.95) | N/M |  |
| Non-GAAP |  |  |  |  |  |  |
| Operating Earnings | $650 | $566 | 15 | % | $1,740 | $1,506 | 16 | % |
| % of Sales | 28.8 | % | 28.9 | % |  | 23.7 | % | 23.6 | % |  |
| EPS | $2.63 | $2.10 | 25 | % | $7.15 | $5.46 | 31 | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $1,670 | $1,437 | 16 | % | $5,100 | $4,513 | 13 | % |
| GAAP Operating Earnings | $405 | $416 | (3 | )% | $854 | $969 | (12 | )% |
| % of Sales | 24.3 | % | 28.9 | % |  | 16.7 | % | 21.5 | % |  |
| Non-GAAP Operating Earnings | $483 | $435 | 11 | % | $1,109 | $1,026 | 8 | % |
| % of Sales | 28.9 | % | 30.3 | % |  | 21.7 | % | 22.7 | % |  |
| Services and Software Segment |  |  |  |  |  |  |
| Sales | $584 | $520 | 12 | % | $2,243 | $1,867 | 20 | % |
| GAAP Operating Earnings | $111 | $87 | 28 | % | $401 | $315 | 27 | % |
| % of Sales | 19.0 | % | 16.7 | % |  | 17.9 | % | 16.9 | % |  |
| Non-GAAP Operating Earnings | $167 | $131 | 27 | % | $631 | $480 | 31 | % |
| % of Sales | 28.6 | % | 25.2 | % |  | 28.1 | % | 25.7 | % |  |

[0000068505-19-000003:8k_2_02:15]
*Q4 Non-GAAP EPS financial information excludes the after-tax impact of approximately $0.19 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-19-000003:8k_2_02:16]
** N/M = Percent change is not meaningful due to the prior year net loss related to tax reform

[0000068505-19-000003:8k_2_02:17]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-19-000003:8k_2_02:18]
| • | Revenue - Fourth-quarter sales were $2.3 billion, up $297 million, or 15 percent from the year-ago quarter, driven by growth in the Americas and EMEA. Approximately $159 million was related to acquisitions, and $25 million was related to the adoption of ASC 606. The Products and Systems Integration segment grew 16 percent driven by the Americas and EMEA. The Services and Software segment grew 12 percent with growth in all regions. |

[0000068505-19-000003:8k_2_02:19]
| • | Operating margin - GAAP operating margin was 22.9 percent of sales, compared with 25.7 percent in the year-ago quarter. The decline was primarily due to costs related to the closure of certain supply chain operations in Europe and acquisition-related operating expenses. Non-GAAP operating margin was 28.8 percent of sales, compared with 28.9 percent in the year-ago quarter. Higher gross margins were offset by higher operating expenses related to acquisitions. |

[0000068505-19-000003:8k_2_02:20]
| • | Taxes - The GAAP effective tax rate was 8.8 percent, compared with 223.4 percent in the year-ago quarter. The non-GAAP effective tax rate was 23.5 percent compared with 32.8 percent in the year-ago quarter. Both tax rates for the fourth quarter of 2018 were favorably affected by the ongoing rate reduction and by other provisional adjustments as a result of the U.S. Tax Cuts and Jobs Act of 2017. |

[0000068505-19-000003:8k_2_02:21]
| • | Cash flow - Operating cash flow was $812 million, compared with $761 million of operating cash generated in the year-ago quarter driven primarily by higher earnings. Free cash flow was $743 million, compared with $740 million in the year-ago quarter on higher earnings partially offset by higher capital expenditures related primarily to the Airwave extension. |

[0000068505-19-000003:8k_2_02:22]
| • | Capital allocation - The company paid $85 million in cash dividends, repurchased $66 million of common stock and repaid the remaining $100 million on the revolving credit facility. |

[0000068505-19-000003:8k_2_02:23]
| • | Backlog - The company ended the quarter with backlog of $10.6 billion, up $988 million from the year-ago quarter inclusive of a $205 million unfavorable currency change. Services and Software backlog was up 18 percent or $1.1 billion primarily due to growth in the Americas and the Airwave contract extension through the end of 2022. Products and Systems Integration backlog was down $116 million primarily on two large system deployments in the Middle East and Africa. Products and System Integration backlog grew in the Americas and AP. |

[0000068505-19-000003:8k_2_02:24]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-19-000003:8k_2_02:25]
| • | Revenue - Full-year sales were $7.3 billion, up $963 million, or 15 percent driven by growth in the Americas and EMEA. Approximately $507 million of revenue growth was related to acquisitions, and $83 million was related to the adoption of ASC 606. The Products and Systems Integration segment grew 13 percent driven by the Americas and EMEA. The Services and Software segment grew 20 percent with growth in all regions. |

[0000068505-19-000003:8k_2_02:26]
| • | Operating margin - GAAP operating margin was 17.1 percent of sales, compared with 20.1 percent in the prior year driven primarily by costs related to the closure of certain supply chain operations in Europe, an increase to an existing environmental reserve related to a legacy business and higher expenses related to acquisitions. Non-GAAP operating margin was 23.7 percent of sales, compared with 23.6 percent in the prior year due to higher revenue and gross margin partially offset by higher operating expenses related to acquisitions. |

[0000068505-19-000003:8k_2_02:27]
| • | Taxes - The GAAP effective tax rate was 12.0 percent, compared with 114.1 percent in 2017. The Non-GAAP effective tax rate was 21.7 percent compared with 31.0 percent in the previous year. Both the tax rates for the full year 2018 were favorably affected primarily by the ongoing rate reduction and by other provisional adjustments as a result of the U.S. Tax Cuts and Jobs Act of 2017. |

[0000068505-19-000003:8k_2_02:28]
| • | Cash flow - Operating cash flow was $1.1 billion, compared with $1.3 billion in the prior year. Excluding the voluntary $500 million debt funded U.S. pension contribution in Q1, operating cash flow was $1.575 billion. Free cash flow was $878 million, compared with $1.1 billion in the prior year. Excluding the U.S. pension contribution in Q1, free cash flow was $1.4 billion. The higher cash flow, excluding the U.S. pension contribution, was driven primarily by higher earnings. |

[0000068505-19-000003:8k_2_02:29]
| • | Capital allocation - The company repurchased $132 million of its common stock, paid $337 million in cash dividends and invested $1.2 billion in acquisitions. From a financing perspective, the company issued $500 million in senior unsecured debt to make a $500 million voluntary contribution to the U.S. pension plan in Q1. Additionally, the company entered into a $400 million term loan and borrowed $400 million under the revolving credit facility to complete the Avigilon acquisition in Q1. The revolving credit facility was paid off throughout the year. The company also repurchased 20 percent of the Silver Lake convertible notes for $369 million in Q3, of which $200 million of principal was repaid with new senior unsecured debt in Q4. |

[0000068505-19-000003:8k_2_02:30]
KEY HIGHLIGHTS

[0000068505-19-000003:8k_2_02:31]
Services and Software wins

[0000068505-19-000003:8k_2_02:32]
| • | $1.1 billion contract extension through 2022 for the Airwave network in the U.K. |

[0000068505-19-000003:8k_2_02:33]
| • | $71 million services award from Maricopa County, Arizona |

[0000068505-19-000003:8k_2_02:34]
| • | $26 million Next Gen 911 Core Services contract in North America |

[0000068505-19-000003:8k_2_02:35]
| • | $16 million services award in Australia |

[0000068505-19-000003:8k_2_02:36]
Products and Systems Integration wins

[0000068505-19-000003:8k_2_02:37]
| • | $47 million P25 order with Snohomish County, Washington |

[0000068505-19-000003:8k_2_02:38]
| • | $24 million P25 order with Ingham County, Michigan |

[0000068505-19-000003:8k_2_02:39]
| • | $16 million P25 order with Riverside County, California |

[0000068505-19-000003:8k_2_02:40]
BUSINESS OUTLOOK

[0000068505-19-000003:8k_2_02:41]
| • | First-quarter 2019 - Motorola Solutions expects revenue growth of approximately 11 percent compared with the first quarter of 2018. The company expects non-GAAP earnings in the range of $1.11 to $1.16 per share. This assumes current foreign exchange rates, approximately 174 million fully diluted shares and a 25 percent effective tax rate. |

[0000068505-19-000003:8k_2_02:42]
| • | Full-year 2019 - The company expects revenue growth of approximately 6 to 7 percent and non-GAAP earnings per share in the range of $7.55 to $7.70. This assumes current foreign exchange rates, approximately 175 million fully diluted shares and a 25 percent effective tax rate. |

[0000068505-19-000003:8k_2_02:43]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) on Thursday, Feb 7. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-19-000003:8k_2_02:44]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-19-000003:8k_2_02:45]
A comparison of results from operations is as follows:

[0000068505-19-000003:8k_2_02:46]
|  | Fourth Quarter | Full Year |
|  | 2018 | 2017 | 2018 | 2017 |
| Net sales | $2,254 | $1,957 | $7,343 | $6,380 |
| Gross margin | $1,088 | $970 | $3,480 | $3,024 |
| Operating earnings | $516 | $503 | $1,255 | $1,284 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings (loss) | 423 |  | (575 | ) | 966 |  | (155 | ) |
| Diluted EPS | $2.44 | ($3.56) | $5.62 | ($0.95) |
| Weighted average diluted common shares outstanding | 173.4 |  | 161.7 |  | 172.0 |  | 162.9 |  |

[0000068505-19-000003:8k_2_02:47]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-19-000003:8k_2_02:48]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the fourth quarter of 2018.

[0000068505-19-000003:8k_2_02:49]
| (per diluted common share) | Q4 2018 |  |
| GAAP Earnings | $2.44 |
| Highlighted Items: |  |
| Share-based compensation expense | 0.09 |  |
| Reorganization of business charges | 0.25 |  |
| Intangibles amortization expense | 0.22 |  |
| Asset impairment | 0.01 |  |
| Acquisition-related transaction fees | 0.03 |  |
| Fair value adjustments to equity investments | (0.02 | ) |
| Investment impairments | 0.02 |  |
| FIN 48 reserve, valuation allowance, and other | (0.03 | ) |
| Adjustments to the provisional tax expense as a result of the tax reform | (0.38 | ) |
| Non-GAAP Diluted EPS | $2.63 |

[0000068505-19-000003:8k_2_02:50]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-19-000003:8k_2_02:51]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-19-000003:8k_2_02:52]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, asset impairments, reorganization of business charges, non-cash pension adjustments, significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-19-000003:8k_2_02:53]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its

[0000068505-19-000003:8k_2_02:54]
performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-19-000003:8k_2_02:55]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-19-000003:8k_2_02:56]
Adjusted operating cash flow:  Adjusted operating cash flow information reflects operating cash flow under GAAP excluding a $500 million voluntary, debt-funded U.S. pension contribution in the first quarter 2018. The Company has excluded the impact of this contribution because the company believes that this item does not reflect expected future operating cash flows and does not contribute to a meaningful evaluation of the company's current operating cash flow performance or comparisons to the company's past operating cash flow performance.

[0000068505-19-000003:8k_2_02:57]
Free cash flow:  Free cash flow represents operating cash flow less capital expenditures. We believe that free cash flow is also useful to investors as the basis for comparing our performance and coverage ratios with other companies in our industries, although our measure of free cash flow may not be directly comparable to similar measures used by other companies

[0000068505-19-000003:8k_2_02:58]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters and excluding the effects of ASC 606.  The Company believes non-GAAP organic revenue growth provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-19-000003:8k_2_02:59]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-19-000003:8k_2_02:60]
BUSINESS RISKS

[0000068505-19-000003:8k_2_02:61]
company's ability to refresh existing and introduce new products and technologies in a timely manner; (5) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (6) negative impact on the company's business from global economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company's products; (iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company's suppliers that may no longer have access to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company's pension plan and other defined benefit plans, which could impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (7) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or those it sells to or operates or maintains for its customers; (8) the outcome of ongoing and future tax matters; (9) the company's ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (10) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (11) the impact on the company's performance and financial results from strategic acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-19-000003:8k_2_02:62]
ABOUT MOTOROLA SOLUTIONS

[0000068505-19-000003:8k_2_02:63]
Motorola Solutions is a global leader in mission-critical communications. Our technology platforms in communications, software, video and services make cities safer and help communities and businesses thrive. At Motorola Solutions, we are ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com

[0000068505-19-000003:8k_2_02:64]
MEDIA CONTACT

[0000068505-19-000003:8k_2_02:65]
Kate Dyer

[0000068505-19-000003:8k_2_02:66]
Motorola Solutions

[0000068505-19-000003:8k_2_02:67]
+224-374-3124

[0000068505-19-000003:8k_2_02:68]
Kate.Dyer@motorolasolutions.com

[0000068505-19-000003:8k_2_02:69]
INVESTOR CONTACT

[0000068505-19-000003:8k_2_02:70]
Chris Kutsor

[0000068505-19-000003:8k_2_02:71]
Motorola Solutions

[0000068505-19-000003:8k_2_02:72]
+1 847-576-4995

[0000068505-19-000003:8k_2_02:73]
chris.kutsor@motorolasolutions.com

[0000068505-19-000003:8k_2_02:74]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2019 Motorola Solutions, Inc. All rights reserved.

[0000068505-19-000003:8k_2_02:75]
GAAP-1

[0000068505-19-000003:8k_2_02:76]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:77]
Consolidated Statements of Operations

[0000068505-19-000003:8k_2_02:78]
(In millions, except per share amounts)

[0000068505-19-000003:8k_2_02:79]
|  | Three Months Ended |
|  | December 31, 2018 |  | December 31, 2017 |
| Net sales from products | $ | 1,470 |  |  | $ | 1,233 |  |
| Net sales from services | 784 |  |  | 724 |  |
| Net sales | 2,254 |  |  | 1,957 |  |
| Costs of products sales | 652 |  |  | 519 |  |
| Costs of services sales | 514 |  |  | 468 |  |
| Costs of sales | 1,166 |  |  | 987 |  |
| Gross margin | 1,088 |  |  | 970 |  |
| Selling, general and administrative expenses | 337 |  |  | 267 |  |
| Research and development expenditures | 165 |  |  | 154 |  |
| Other charges | 22 |  |  | 7 |  |
| Intangibles amortization | 48 |  |  | 39 |  |
| Operating earnings | 516 |  |  | 503 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (59 | ) |  | (47 | ) |
| Other | 7 |  |  | 9 |  |
| Total other expense | (52 | ) |  | (38 | ) |
| Net earnings before income taxes | 464 |  |  | 465 |  |
| Income tax expense | 40 |  |  | 1,039 |  |
| Net earnings (loss) | 424 |  |  | (574 | ) |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 423 |  |  | $ | (575 | ) |
| Earnings (loss) per common share: |  |  |  |
| Basic: | $ | 2.58 |  |  | $ | (3.56 | ) |
| Diluted: | $ | 2.44 |  |  | $ | (3.56 | ) |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 163.5 |  |  | 161.7 |  |
| Diluted | 173.4 |  |  | 161.7 |  |

[0000068505-19-000003:8k_2_02:80]
|  | Percentage of Net Sales* |
| Net sales from products | 65.2 | % |  | 63.0 | % |
| Net sales from services | 34.8 | % |  | 37.0 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 44.4 | % |  | 42.1 | % |
| Costs of services sales | 65.6 | % |  | 64.6 | % |
| Costs of sales | 51.7 | % |  | 50.4 | % |
| Gross margin | 48.3 | % |  | 49.6 | % |
| Selling, general and administrative expenses | 15.0 | % |  | 13.6 | % |
| Research and development expenditures | 7.3 | % |  | 7.9 | % |
| Other charges | 1.0 | % |  | 0.4 | % |
| Intangibles amortization | 2.1 | % |  | 2.0 | % |
| Operating earnings | 22.9 | % |  | 25.7 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.6 | )% |  | (2.4 | )% |
| Other | 0.3 | % |  | 0.5 | % |
| Total other expense | (2.3 | )% |  | (1.9 | )% |
| Net earnings before income taxes | 20.6 | % |  | 23.8 | % |
| Income tax expense | 1.8 | % |  | 53.1 | % |
| Net earnings (loss) | 18.8 | % |  | (29.3 | )% |
| Less: Earnings attributable to noncontrolling interests | — | % |  | 0.1 | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | 18.8 | % |  | (29.4 | )% |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-19-000003:8k_2_02:81]
GAAP-2

[0000068505-19-000003:8k_2_02:82]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:83]
Consolidated Statements of Operations

[0000068505-19-000003:8k_2_02:84]
(In millions, except per share amounts)

[0000068505-19-000003:8k_2_02:85]
|  | Years Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2016 |
| Net sales from products | $ | 4,463 |  |  | $ | 3,772 |  |  | $ | 3,649 |  |
| Net sales from services | 2,880 |  |  | 2,608 |  |  | 2,389 |  |
| Net sales | 7,343 |  |  | 6,380 |  |  | 6,038 |  |
| Costs of products sales | 2,035 |  |  | 1,686 |  |  | 1,649 |  |
| Costs of services sales | 1,828 |  |  | 1,670 |  |  | 1,520 |  |
| Costs of sales | 3,863 |  |  | 3,356 |  |  | 3,169 |  |
| Gross margin | 3,480 |  |  | 3,024 |  |  | 2,869 |  |
| Selling, general and administrative expenses | 1,254 |  |  | 1,025 |  |  | 1,044 |  |
| Research and development expenditures | 637 |  |  | 568 |  |  | 553 |  |
| Other charges (income) | 146 |  |  | (4 | ) |  | 111 |  |
| Intangibles amortization | 188 |  |  | 151 |  |  | 113 |  |
| Operating earnings | 1,255 |  |  | 1,284 |  |  | 1,048 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (222 | ) |  | (201 | ) |  | (205 | ) |
| Gains (losses) on sales of investments and businesses, net | 16 |  |  | 3 |  |  | (6 | ) |
| Other | 53 |  |  | (10 | ) |  | 7 |  |
| Total other expense | (153 | ) |  | (208 | ) |  | (204 | ) |
| Net earnings before income taxes | 1,102 |  |  | 1,076 |  |  | 844 |  |
| Income tax expense | 133 |  |  | 1,227 |  |  | 282 |  |
| Net earnings (loss) | 969 |  |  | (151 | ) |  | 562 |  |
| Less: Earnings attributable to noncontrolling interests | 3 |  |  | 4 |  |  | 2 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 966 |  |  | $ | (155 | ) |  | $ | 560 |  |
| Earnings (loss) per common share: |  |  |  |  |  |
| Basic: | $ | 5.95 |  |  | $ | (0.95 | ) |  | $ | 3.30 |  |
| Diluted: | $ | 5.62 |  |  | $ | (0.95 | ) |  | $ | 3.24 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 162.4 |  |  | 162.9 |  |  | 169.6 |  |
| Diluted | 172.0 |  |  | 162.9 |  |  | 173.1 |  |

[0000068505-19-000003:8k_2_02:86]
|  | Percentage of Net Sales* |
| Net sales from products | 60.8 | % |  | 59.1 | % |  | 60.4 | % |
| Net sales from services | 39.2 | % |  | 40.9 | % |  | 39.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 45.6 | % |  | 44.7 | % |  | 45.2 | % |
| Costs of services sales | 63.5 | % |  | 64.0 | % |  | 63.6 | % |
| Costs of sales | 52.6 | % |  | 52.6 | % |  | 52.5 | % |
| Gross margin | 47.4 | % |  | 47.4 | % |  | 47.5 | % |
| Selling, general and administrative expenses | 17.1 | % |  | 16.1 | % |  | 17.3 | % |
| Research and development expenditures | 8.7 | % |  | 8.9 | % |  | 9.2 | % |
| Other charges | 2.0 | % |  | (0.1 | )% |  | 1.8 | % |
| Intangibles amortization | 2.6 | % |  | 2.4 | % |  | 1.9 | % |
| Operating earnings | 17.1 | % |  | 20.1 | % |  | 17.4 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (3.0 | )% |  | (3.2 | )% |  | (3.4 | )% |
| Gains (losses) on sales of investments and businesses, net | 0.2 | % |  | — | % |  | (0.1 | )% |
| Other | 0.7 | % |  | (0.2 | )% |  | 0.1 | % |
| Total other expense | (2.1 | )% |  | (3.3 | )% |  | (3.4 | )% |
| Net earnings before income taxes | 15.0 | % |  | 16.9 | % |  | 14.0 | % |
| Income tax expense | 1.8 | % |  | 19.2 | % |  | 4.7 | % |
| Net earnings (loss) | 13.2 | % |  | (2.4 | )% |  | 9.3 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | 0.1 | % |  | — | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | 13.2 | % |  | (2.4 | )% |  | 9.3 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-19-000003:8k_2_02:87]
GAAP-3

[0000068505-19-000003:8k_2_02:88]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:89]
Consolidated Balance Sheets

[0000068505-19-000003:8k_2_02:90]
(In millions)

[0000068505-19-000003:8k_2_02:91]
|  |  | December 31, 2018 |  | December 31, 2017 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,246 |  |  | $ | 1,205 |  |
| Restricted cash |  | 11 |  |  | 63 |  |
| Total cash and cash equivalents |  | 1,257 |  |  | 1,268 |  |
| Accounts receivable, net |  | 1,293 |  |  | 1,523 |  |
| Contract assets |  | 1,012 |  |  | — |  |
| Inventories, net |  | 356 |  |  | 327 |  |
| Other current assets |  | 354 |  |  | 832 |  |
| Total current assets |  | 4,272 |  |  | 3,950 |  |
| Property, plant and equipment, net |  | 895 |  |  | 856 |  |
| Investments |  | 169 |  |  | 247 |  |
| Deferred income taxes |  | 985 |  |  | 1,023 |  |
| Goodwill |  | 1,514 |  |  | 938 |  |
| Intangible assets |  | 1,230 |  |  | 861 |  |
| Other assets |  | 344 |  |  | 333 |  |
| Total assets |  | $ | 9,409 |  |  | $ | 8,208 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 31 |  |  | $ | 52 |  |
| Accounts payable |  | 592 |  |  | 593 |  |
| Contract liabilities |  | 1,263 |  |  | — |  |
| Accrued liabilities |  | 1,210 |  |  | 2,286 |  |
| Total current liabilities |  | 3,096 |  |  | 2,931 |  |
| Long-term debt |  | 5,289 |  |  | 4,419 |  |
| Other liabilities |  | 2,300 |  |  | 2,585 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,293 | ) |  | (1,742 | ) |
| Noncontrolling interests |  | 17 |  |  | 15 |  |
| Total liabilities and stockholders’ equity |  | $ | 9,409 |  |  | $ | 8,208 |  |

[0000068505-19-000003:8k_2_02:92]
GAAP-4

[0000068505-19-000003:8k_2_02:93]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:94]
Consolidated Statements of Cash Flows

[0000068505-19-000003:8k_2_02:95]
(In millions)

[0000068505-19-000003:8k_2_02:96]
|  | Three Months Ended |
|  | December 31, 2018 |  | December 31, 2017 |
| Operating |  |  |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 423 |  |  | $ | (575 | ) |
| Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings (loss) | 424 |  |  | (574 | ) |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 93 |  |  | 89 |  |
| Non-cash other charges | — |  |  | 3 |  |
| Non-U.S. pension settlement loss | — |  |  | 2 |  |
| Share-based compensation expense | 20 |  |  | 17 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (124 | ) |  | (141 | ) |
| Inventories | 10 |  |  | 37 |  |
| Other current assets and contract assets | (114 | ) |  | 42 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 441 |  |  | 338 |  |
| Other assets and liabilities | 72 |  |  | (54 | ) |
| Deferred income taxes | (10 | ) |  | 1,002 |  |
| Net cash provided by operating activities | 812 |  |  | 761 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (6 | ) |  | (21 | ) |
| Proceeds from sales of investments | 5 |  |  | 9 |  |
| Capital expenditures | (69 | ) |  | (21 | ) |
| Net cash used for investing activities | (70 | ) |  | (33 | ) |
| Financing |  |  |  |
| Repayment of debt | (311 | ) |  | (7 | ) |
| Net proceeds from issuance of debt | 195 |  |  | 3 |  |
| Issuance of common stock | 29 |  |  | 21 |  |
| Purchase of common stock | (66 | ) |  | (125 | ) |
| Payment of dividends | (85 | ) |  | (76 | ) |
| Deferred acquisition costs | (76 | ) |  | (2 | ) |
| Net cash used for financing activities | (314 | ) |  | (186 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (22 | ) |  | 9 |  |
| Net increase in cash and cash equivalents | 406 |  |  | 551 |  |
| Cash, cash equivalents, and restricted cash, beginning of period | 851 |  |  | 717 |  |
| Cash, cash equivalents, and restricted cash, end of period | $ | 1,257 |  |  | $ | 1,268 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 743 |  |  | $ | 740 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-19-000003:8k_2_02:97]
GAAP-5

[0000068505-19-000003:8k_2_02:98]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:99]
Consolidated Statements of Cash Flows

[0000068505-19-000003:8k_2_02:100]
(In millions)

[0000068505-19-000003:8k_2_02:101]
|  | Years Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2016 |
| Operating |  |  |  |  |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 966 |  |  | $ | (155 | ) |  | $ | 560 |  |
| Earnings attributable to noncontrolling interests | 3 |  |  | 4 |  |  | 2 |  |
| Net earnings (loss) | 969 |  |  | (151 | ) |  | 562 |  |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 360 |  |  | 343 |  |  | 295 |  |
| Non-cash other charges | 56 |  |  | 32 |  |  | 54 |  |
| Non-U.S. pension settlement loss | — |  |  | 48 |  |  | 26 |  |
| Share-based compensation expense | 73 |  |  | 66 |  |  | 68 |  |
| Loss (gains) on sales of investments and businesses, net | (16 | ) |  | (3 | ) |  | 6 |  |
| Loss (gain) from the extinguishment of long term debt | (6 | ) |  | — |  |  | 2 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | 62 |  |  | (60 | ) |  | (6 | ) |
| Inventories | 71 |  |  | (46 | ) |  | 6 |  |
| Other current assets and contract assets | (251 | ) |  | (99 | ) |  | (185 | ) |
| Accounts payable, accrued liabilities, and contract liabilities | 271 |  |  | 160 |  |  | 241 |  |
| Other assets and liabilities | (523 | ) |  | (44 | ) |  | (117 | ) |
| Deferred income taxes | 9 |  |  | 1,100 |  |  | 213 |  |
| Net cash provided by operating activities | 1,075 |  |  | 1,346 |  |  | 1,165 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (1,164 | ) |  | (404 | ) |  | (1,474 | ) |
| Proceeds from sales of investments | 95 |  |  | 183 |  |  | 670 |  |
| Capital expenditures | (197 | ) |  | (227 | ) |  | (271 | ) |
| Proceeds from sales of property, plant and equipment | — |  |  | — |  |  | 73 |  |
| Net cash used for investing activities | (1,266 | ) |  | (448 | ) |  | (1,002 | ) |
| Financing |  |  |  |  |  |
| Repayment of debt | (723 | ) |  | (21 | ) |  | (686 | ) |
| Net proceeds from issuance of debt | 1,490 |  |  | 10 |  |  | 673 |  |
| Issuance of common stock | 168 |  |  | 82 |  |  | 93 |  |
| Purchase of common stock | (132 | ) |  | (483 | ) |  | (842 | ) |
| Payment of dividends | (337 | ) |  | (307 | ) |  | (280 | ) |
| Payment of dividends to non-controlling interest | (1 | ) |  | (1 | ) |  | — |  |
| Settlement of conversion premium on convertible debt | (169 | ) |  | — |  |  | — |  |
| Deferred acquisition costs | (76 | ) |  | (2 | ) |  | — |  |
| Net cash provided by (used for) financing activities | 220 |  |  | (722 | ) |  | (1,042 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (40 | ) |  | 62 |  |  | (71 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | (11 | ) |  | 238 |  |  | (950 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period | 1,268 |  |  | 1,030 |  |  | 1,980 |  |
| Cash, cash equivalents, and restricted cash, end of period | $ | 1,257 |  |  | $ | 1,268 |  |  | $ | 1,030 |  |
| Financial Ratios: |  |  |  |  |  |
| Free cash flow* | $ | 878 |  |  | $ | 1,119 |  |  | $ | 894 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |  |  |

[0000068505-19-000003:8k_2_02:102]
GAAP-6

[0000068505-19-000003:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:104]
Segment Information

[0000068505-19-000003:8k_2_02:105]
(In millions)

[0000068505-19-000003:8k_2_02:106]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Products and Systems Integration | $ | 1,670 |  |  | $ | 1,437 |  |  | 16 | % |
| Services and Software | 584 |  |  | 520 |  |  | 12 | % |
| Total Motorola Solutions | $ | 2,254 |  |  | $ | 1,957 |  |  | 15 | % |
|  | Years Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |  |
| Products and Systems Integration | $ | 5,100 |  |  | $ | 4,513 |  |  | 13 | % |
| Services and Software | 2,243 |  |  | 1,867 |  |  | 20 | % |
| Total Motorola Solutions | $ | 7,343 |  |  | $ | 6,380 |  |  | 15 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Products and Systems Integration | $ | 405 |  |  | $ | 416 |  |  | (3 | )% |
| Services and Software | 111 |  |  | 87 |  |  | 28 | % |
| Total Motorola Solutions | $ | 516 |  |  | $ | 503 |  |  | 3 | % |
|  | Years Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Products and Systems Integration | $ | 854 |  |  | $ | 969 |  |  | (12 | )% |
| Services and Software | 401 |  |  | 315 |  |  | 27 | % |
| Total Motorola Solutions | $ | 1,255 |  |  | $ | 1,284 |  |  | (2 | )% |

[0000068505-19-000003:8k_2_02:107]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  |  |
| Products and Systems Integration | 24.3 | % |  | 28.9 | % |  |  |
| Services and Software | 19.0 | % |  | 16.7 | % |  |  |
| Total Motorola Solutions | 22.9 | % |  | 25.7 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  |  |
| Products and Systems Integration | 16.7 | % |  | 21.5 | % |  |  |
| Services and Software | 17.9 | % |  | 16.9 | % |  |  |
| Total Motorola Solutions | 17.1 | % |  | 20.1 | % |  |  |

[0000068505-19-000003:8k_2_02:108]
Non-GAAP-1

[0000068505-19-000003:8k_2_02:109]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:110]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-19-000003:8k_2_02:111]
| Q1 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 13 |  |  | 3 |  |  | 10 |  |  | 0.06 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 41 |  |  | 8 |  |  | 33 |  |  | 0.19 |  |
| Loss on legal settlements |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on derivative instruments related to Avigilon purchase |  | Other expense |  | 14 |  |  | 4 |  |  | 10 |  |  | 0.06 |  |
| Release of FIN 48 reserve |  | Income tax expense |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | (11 | ) |  | (3 | ) |  | (8 | ) |  | (0.05 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 17 |  |  | 5 |  |  | 12 |  |  | 0.07 |  |
| Total impact on Net earnings |  |  |  | $ | 92 |  |  | $ | 22 |  |  | $ | 70 |  |  | $ | 0.41 |  |
| Q2 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.10 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 53 |  |  | 12 |  |  | 41 |  |  | 0.23 |  |
| Avigilon purchase accounting adjustment |  | Cost of sales |  | 10 |  |  | 3 |  |  | 7 |  |  | 0.04 |  |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on foreign currency related to Avigilon purchase |  | Other expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| FIN 48 reserve |  | Income tax expense |  | — |  |  | (1 | ) |  | 1 |  |  | 0.01 |  |
| State audit settlement |  | Income tax expense |  | — |  |  | 12 |  |  | (12 | ) |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 107 |  |  | $ | 36 |  |  | $ | 71 |  |  | $ | 0.41 |  |
| Q3 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 19 |  |  | $ | 5 |  |  | $ | 14 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.11 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 46 |  |  | 10 |  |  | 36 |  |  | 0.21 |  |
| Avigilon purchase accounting adjustment |  | Cost of sales |  | 9 |  |  | 2 |  |  | 7 |  |  | 0.04 |  |
| Gain from the extinguishment of convertible debt |  | Other income |  | (6 | ) |  | — |  |  | (6 | ) |  | (0.03 | ) |
| Fair value adjustments to equity investments |  | Other income |  | (7 | ) |  | (2 | ) |  | (5 | ) |  | (0.03 | ) |
| Loss on legal settlement |  | Other charges |  | 2 |  |  | 1 |  |  | 1 |  |  | 0.01 |  |
| Environmental reserve expense |  | Other charges |  | 57 |  |  | 14 |  |  | 43 |  |  | 0.25 |  |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | (6 | ) |  | (1 | ) |  | (5 | ) |  | (0.03 | ) |
| Return-to-provision adjustments as related to federal tax reform |  | Income tax expense |  | — |  |  | 16 |  |  | (16 | ) |  | (0.10 | ) |
| Total impact on Net earnings |  |  |  | $ | 139 |  |  | $ | 51 |  |  | $ | 88 |  |  | $ | 0.51 |  |
| Q4 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 20 |  |  | $ | 5 |  |  | $ | 15 |  |  | $ | 0.09 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 58 |  |  | 13 |  |  | 45 |  |  | 0.25 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 48 |  |  | 10 |  |  | 38 |  |  | 0.22 |  |
| Asset impairment |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Acquisition-related transaction fees |  | Other charges |  | 7 |  |  | 1 |  |  | 6 |  |  | 0.03 |  |
| Fair value adjustments to equity investments |  | Other income |  | (4 | ) |  | (1 | ) |  | (3 | ) |  | (0.02 | ) |
| Investment impairments |  | Investment impairments |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| FIN 48 reserve, valuation allowance, and other |  | Income tax expense |  | — |  |  | 6 |  |  | (6 | ) |  | (0.03 | ) |
| Adjustments to the provisional tax expense as a result of the tax reform |  | Income tax expense |  | — |  |  | 65 |  |  | (65 | ) |  | (0.38 | ) |
| Total impact on Net earnings |  |  |  | $ | 135 |  |  | $ | 100 |  |  | $ | 35 |  |  | $ | 0.19 |  |

[0000068505-19-000003:8k_2_02:112]
| FY 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 73 |  |  | $ | 18 |  |  | $ | 55 |  |  | $ | 0.32 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 120 |  |  | 28 |  |  | 92 |  |  | 0.53 |  |
| Avigilon purchase accounting adjustment |  | Cost of sales |  | 19 |  |  | 5 |  |  | 14 |  |  | 0.08 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 188 |  |  | 40 |  |  | 148 |  |  | 0.86 |  |
| Loss on legal settlements |  | Other charges |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Loss on derivative instruments related to Avigilon purchase |  | Other expense |  | 14 |  |  | 4 |  |  | 10 |  |  | 0.06 |  |
| Gain from the extinguishment of convertible debt |  | Other income |  | (6 | ) |  | — |  |  | (6 | ) |  | (0.03 | ) |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | (16 | ) |  | (4 | ) |  | (12 | ) |  | (0.07 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 24 |  |  | 6 |  |  | 18 |  |  | 0.10 |  |
| Fair value adjustments to equity investments |  | Other income |  | (11 | ) |  | (3 | ) |  | (8 | ) |  | (0.05 | ) |
| Loss on foreign currency related to Avigilon purchase |  | Other expense |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Asset impairment |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Investment impairments |  | Investment impairments |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Environmental reserve expense |  | Other charges |  | 57 |  |  | 14 |  |  | 43 |  |  | 0.25 |  |
| FIN 48 reserve, valuation allowance, and other |  | Income tax expense |  | — |  |  | 18 |  |  | (18 | ) |  | (0.10 | ) |
| Adjustments to the provisional tax expense as a result of the tax reform |  | Income tax expense |  | — |  |  | 81 |  |  | (81 | ) |  | (0.47 | ) |
| Total impact on Net earnings |  |  |  | $ | 473 |  |  | $ | 209 |  |  | $ | 264 |  |  | $ | 1.53 |  |

[0000068505-19-000003:8k_2_02:113]
Non-GAAP-2

[0000068505-19-000003:8k_2_02:114]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:115]
Non-GAAP Segment Information

[0000068505-19-000003:8k_2_02:116]
(In millions)

[0000068505-19-000003:8k_2_02:117]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Products and Systems Integration | $ | 1,670 |  |  | $ | 1,437 |  |  | 16 | % |
| Services and Software | 584 |  |  | 520 |  |  | 12 | % |
| Total Motorola Solutions | $ | 2,254 |  |  | $ | 1,957 |  |  | 15 | % |
|  | Years Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |  |
| Products and Systems Integration | $ | 5,100 |  |  | $ | 4,513 |  |  | 13 | % |
| Services and Software | 2,243 |  |  | 1,867 |  |  | 20 | % |
| Total Motorola Solutions | $ | 7,343 |  |  | $ | 6,380 |  |  | 15 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Products and Systems Integration | $ | 483 |  |  | $ | 435 |  |  | 11 | % |
| Services and Software | 167 |  |  | 131 |  |  | 27 | % |
| Total Motorola Solutions | $ | 650 |  |  | $ | 566 |  |  | 15 | % |
|  | Years Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Products and Systems Integration | $ | 1,109 |  |  | $ | 1,026 |  |  | 8 | % |
| Services and Software | 631 |  |  | 480 |  |  | 31 | % |
| Total Motorola Solutions | $ | 1,740 |  |  | $ | 1,506 |  |  | 16 | % |

[0000068505-19-000003:8k_2_02:118]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  |  |
| Products and Systems Integration | 28.9 | % |  | 30.3 | % |  |  |
| Services and Software | 28.6 | % |  | 25.2 | % |  |  |
| Total Motorola Solutions | 28.8 | % |  | 28.9 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2018 |  | December 31, 2017 |  |  |
| Products and Systems Integration | 21.7 | % |  | 22.7 | % |  |  |
| Services and Software | 28.1 | % |  | 25.7 | % |  |  |
| Total Motorola Solutions | 23.7 | % |  | 23.6 | % |  |  |

[0000068505-19-000003:8k_2_02:119]
Non-GAAP-3

[0000068505-19-000003:8k_2_02:120]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:121]
Operating Earnings after Non-GAAP Adjustments

[0000068505-19-000003:8k_2_02:122]
| Q1 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,468 |  |  | $ | 952 |  |  | $ | 516 |  |
| Operating earnings ("OE") |  | $ | 171 |  |  | $ | 90 |  |  | $ | 81 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 13 |  |  | 9 |  |  | 4 |  |
| Intangibles amortization expense |  | 41 |  |  | 1 |  |  | 40 |  |
| Acquisition-related transaction fees |  | 17 |  |  | 12 |  |  | 5 |  |
| Loss on legal settlements |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 89 |  |  | 35 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 260 |  |  | $ | 125 |  |  | $ | 135 |  |

[0000068505-19-000003:8k_2_02:123]
| Operating earnings as a percentage of net sales - GAAP |  | 11.6 | % |  | 9.5 | % |  | 15.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 17.7 | % |  | 13.1 | % |  | 26.2 | % |

[0000068505-19-000003:8k_2_02:124]
| Q2 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,760 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Operating earnings ("OE") |  | $ | 273 |  |  | $ | 175 |  |  | $ | 98 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 25 |  |  | 19 |  |  | 6 |  |
| Intangibles amortization expense |  | 53 |  |  | 10 |  |  | 43 |  |
| Avigilon purchase accounting adjustment |  | 10 |  |  | 10 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 105 |  |  | 51 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 378 |  |  | $ | 226 |  |  | $ | 152 |  |

[0000068505-19-000003:8k_2_02:125]
| Operating earnings as a percentage of net sales - GAAP |  | 15.5 | % |  | 14.7 | % |  | 17.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 21.5 | % |  | 19.0 | % |  | 26.6 | % |

[0000068505-19-000003:8k_2_02:126]
| Q3 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,862 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Operating earnings ("OE") |  | $ | 294 |  |  | $ | 183 |  |  | $ | 111 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 19 |  |  | 13 |  |  | 6 |  |
| Reorganization of business charges |  | 25 |  |  | 19 |  |  | 6 |  |
| Intangibles amortization expense |  | 46 |  |  | 11 |  |  | 35 |  |
| Avigilon purchase accounting adjustment |  | 9 |  |  | 9 |  |  | — |  |
| Loss on legal settlement |  | 2 |  |  | 1 |  |  | 1 |  |
| Environmental reserve expense |  | 57 |  |  | 40 |  |  | 17 |  |
| Total above-OE non-GAAP adjustments |  | 158 |  |  | 93 |  |  | 65 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 452 |  |  | $ | 276 |  |  | $ | 176 |  |

[0000068505-19-000003:8k_2_02:127]
| Operating earnings as a percentage of net sales - GAAP |  | 15.8 | % |  | 14.2 | % |  | 19.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.3 | % |  | 21.4 | % |  | 30.7 | % |

[0000068505-19-000003:8k_2_02:128]
| Q4 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 2,254 |  |  | $ | 1,670 |  |  | $ | 584 |  |
| Operating earnings ("OE") |  | $ | 516 |  |  | $ | 405 |  |  | $ | 111 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 20 |  |  | 14 |  |  | 6 |  |
| Reorganization of business charges |  | 58 |  |  | 53 |  |  | 5 |  |
| Intangibles amortization expense |  | 48 |  |  | 11 |  |  | 37 |  |
| Asset impairment |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition-related transaction fees |  | 7 |  |  | — |  |  | 7 |  |
| Total above-OE non-GAAP adjustments |  | 134 |  |  | 78 |  |  | 56 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 650 |  |  | $ | 483 |  |  | $ | 167 |  |

[0000068505-19-000003:8k_2_02:129]
| Operating earnings as a percentage of net sales - GAAP |  | 22.9 | % |  | 24.3 | % |  | 19.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.8 | % |  | 28.9 | % |  | 28.6 | % |

[0000068505-19-000003:8k_2_02:130]
| FY 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 7,343 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |
| Operating earnings ("OE") |  | $ | 1,255 |  |  | $ | 854 |  |  | $ | 401 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 73 |  |  | 50 |  |  | 23 |  |
| Reorganization of business charges |  | 120 |  |  | 101 |  |  | 19 |  |
| Intangibles amortization expense |  | 188 |  |  | 31 |  |  | 157 |  |
| Environmental reserve expense |  | 57 |  |  | 40 |  |  | 17 |  |
| Acquisition-related transaction fees |  | 24 |  |  | 12 |  |  | 12 |  |
| Asset impairment |  | 1 |  |  | — |  |  | 1 |  |
| Avigilon purchase accounting adjustment |  | 19 |  |  | 19 |  |  | — |  |
| Loss on legal settlements |  | 3 |  |  | 2 |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 485 |  |  | 255 |  |  | 230 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,740 |  |  | $ | 1,109 |  |  | $ | 631 |  |

[0000068505-19-000003:8k_2_02:131]
| Operating earnings as a percentage of net sales - GAAP |  | 17.1 | % |  | 16.7 | % |  | 17.9 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 23.7 | % |  | 21.7 | % |  | 28.1 | % |

[0000068505-19-000003:8k_2_02:132]
Non-GAAP-4

[0000068505-19-000003:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:134]
Non-GAAP Organic Revenue

[0000068505-19-000003:8k_2_02:135]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Net sales |  | $ | 2,254 |  |  | $ | 1,957 |  |  | 15 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (159 | ) |  | — |  |  |  |
| ASC 606 impact |  | (25 | ) |  | — |  |  |  |
| Organic revenue |  | $ | 2,070 |  |  | $ | 1,957 |  |  | 6 | % |

[0000068505-19-000003:8k_2_02:136]
| Total Motorola Solutions |
|  |  | Years Ended |  |  |
|  |  | December 31, 2018 |  | December 31, 2017 |  | % Change |
| Net sales |  | $ | 7,343 |  |  | $ | 6,380 |  |  | 15 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (516 | ) |  | (9 | ) |  |  |
| ASC 606 impact |  | (83 | ) |  | — |  |  |  |
| Organic revenue |  | $ | 6,744 |  |  | $ | 6,371 |  |  | 6 | % |

[0000068505-19-000003:8k_2_02:137]
Non-GAAP-5

[0000068505-19-000003:8k_2_02:138]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000003:8k_2_02:139]
Non-GAAP Adjusted Operating Cash Flow

[0000068505-19-000003:8k_2_02:140]
|  |  | Year Ended December 31, 2018 |
| Net cash provided by operating activities |  | $ | 1,075 |  |
| Voluntary, debt-funded U.S. pension contribution |  | 500 |  |
| Adjusted Operating cash flow |  | $ | 1,575 |  |
