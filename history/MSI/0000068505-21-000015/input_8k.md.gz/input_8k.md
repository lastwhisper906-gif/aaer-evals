# MSI 8-K — 0000068505-21-000013 filed 2021-05-06

## item codes, every 8-K on or before 2021-05-06

- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2021-05-06

- none on or before 2021-05-06

## item 2.02 — earnings release, exhibit 99.1

[0000068505-21-000013:8k_2_02:1]
EX-99.1
2
msiq12021pressrelease.htm
EX-99.1

[0000068505-21-000013:8k_2_02:2]
Document

[0000068505-21-000013:8k_2_02:3]
Exhibit 99.1

[0000068505-21-000013:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2021 Financial Results

[0000068505-21-000013:8k_2_02:5]
Company raises full-year revenue and EPS guidance following strong Q1 results

[0000068505-21-000013:8k_2_02:6]
•Sales of $1.8 billion, up 7% versus a year ago

[0000068505-21-000013:8k_2_02:7]
•Software and Services segment sales grew 15% and expanded operating margins

[0000068505-21-000013:8k_2_02:8]
•GAAP earnings per share (EPS) of $1.41

[0000068505-21-000013:8k_2_02:9]
•Non-GAAP EPS* of $1.87, up 26% versus a year ago

[0000068505-21-000013:8k_2_02:10]
•Backlog of $11.3 billion, up 8% versus a year ago

[0000068505-21-000013:8k_2_02:11]
•Generated $370 million of operating cash flow, up 20% versus a year ago

[0000068505-21-000013:8k_2_02:12]
•Announced $2 billion increase to share repurchase program

[0000068505-21-000013:8k_2_02:13]
CHICAGO – May 6, 2021 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2021.

[0000068505-21-000013:8k_2_02:14]
"Q1 was an outstanding quarter, with record first-quarter revenue, operating earnings, cash flow and ending backlog,” said Greg Brown, chairman and CEO of Motorola Solutions. “I’m very pleased with our double digit growth in video security, command center software and LMR services. This strong demand combined with our ending backlog position is driving our increased expectations for the full year.”

[0000068505-21-000013:8k_2_02:15]
The company also announced that its board of directors has approved, subsequent to quarter end, a $2 billion increase to the share repurchase program, raising the total authorization since July 2011 to $16 billion. Under the company’s previously authorized $14 billion share repurchase program, approximately $479 million in repurchase authority remained at the end of the first quarter of 2021. The company may continue to repurchase shares from time to time in the open market or in other privately negotiated transactions, subject to market conditions.

[0000068505-21-000013:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-21-000013:8k_2_02:17]
|  | Q1 2021 |  | Q1 2020 | % Change |
| Sales | $1,773 |  | $1,655 | 7 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $298 |  | $259 | 15 | % |
| % of Sales | 16.8 | % |  | 15.6 | % |  |
| EPS | $1.41 |  | $1.12 | 26 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $411 |  | $347 | 18 | % |
| % of Sales | 23.2 | % |  | 21.0 | % |  |
| EPS | $1.87 |  | $1.49 | 26 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,015 |  | $993 | 2 | % |
| GAAP Operating Earnings | $77 |  | $92 | (16) | % |
| % of Sales | 7.6 | % |  | 9.3 | % |  |
| Non-GAAP Operating Earnings* | $131 |  | $123 | 7 | % |
| % of Sales | 12.9 | % |  | 12.4 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $758 |  | $662 | 15 | % |
| GAAP Operating Earnings | $221 |  | $167 | 32 | % |
| % of Sales | 29.1 | % |  | 25.2 | % |  |
| Non-GAAP Operating Earnings* | $280 |  | $224 | 25 | % |
| % of Sales | 36.9 | % |  | 33.8 | % |  |

[0000068505-21-000013:8k_2_02:18]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.46 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-21-000013:8k_2_02:19]
1

[0000068505-21-000013:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-21-000013:8k_2_02:21]
•Revenue - Sales were $1.8 billion, up 7% from the year-ago quarter driven by growth in both North America and International. Revenue from acquisitions was $48 million and currency tailwinds were $32 million in the quarter. The Products and Systems Integration segment grew 2% driven primarily by growth in video security and professional and commercial radio (PCR). The Software and Services segment grew 15%, driven by growth in LMR services, video security, and command center software.

[0000068505-21-000013:8k_2_02:22]
•Operating margin - GAAP operating margin was 16.8% of sales, up from 15.6% in the year-ago quarter. Non-GAAP operating margin was 23.2% of sales, up from 21.0% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margins was primarily due to higher sales and improved operating leverage in both segments.

[0000068505-21-000013:8k_2_02:23]
•Taxes - The GAAP effective tax rate was 15.1%, compared to 11.8% in the year-ago quarter. The non-GAAP effective tax rate was 17.7%, compared to 15.4% in the year-ago quarter. Both the GAAP and non-GAAP tax rates were higher in the first quarter of 2021 primarily due to lower tax benefits on share-based compensation.

[0000068505-21-000013:8k_2_02:24]
•Cash flow - Operating cash flow was $370 million, compared to $308 million in the year-ago quarter. Free cash flow was $318 million, compared to $260 million in the year-ago quarter. Cash flow for the quarter increased primarily due to higher earnings and improved working capital.

[0000068505-21-000013:8k_2_02:25]
•Capital allocation - During the quarter, the company repurchased $170 million of shares, paid $121 million in cash dividends, and incurred $52 million of capital expenditures. Additionally, the company entered into a new five-year $2.25 billion revolving credit facility, which replaces the prior $2.2 billion revolving credit facility.

[0000068505-21-000013:8k_2_02:26]
•Backlog - The company ended the quarter with backlog of $11.3 billion, up 8% or $866 million from the year-ago quarter. Software and Services segment backlog was up 7% or $548 million. The growth was primarily driven by multi-year services and software agreements in North America. Products and Systems Integration segment backlog was up 11%, or $318 million. The growth was driven by strong LMR demand in North America and International.

[0000068505-21-000013:8k_2_02:27]
2

[0000068505-21-000013:8k_2_02:28]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-21-000013:8k_2_02:29]
Software and Services

[0000068505-21-000013:8k_2_02:30]
•$40+ million P25 services, upgrade and body-worn camera orders with Nashville, TN

[0000068505-21-000013:8k_2_02:31]
•$35 million PTT over broadband multi-year contract with large U.S. customer

[0000068505-21-000013:8k_2_02:32]
•$22 million P25 and PTT over broadband contract with large Middle Eastern customer

[0000068505-21-000013:8k_2_02:33]
•$13 million body-worn camera orders with multiple U.K. customers

[0000068505-21-000013:8k_2_02:34]
•$5 million command center software cloud suite contract with St. Lucie, FL

[0000068505-21-000013:8k_2_02:35]
•Announced integration of V300 body-worn camera with APX P25 radio

[0000068505-21-000013:8k_2_02:36]
Products and Systems Integration

[0000068505-21-000013:8k_2_02:37]
•$300+ million TETRA frame agreement with German MOD; $154 million initial order received in Q1

[0000068505-21-000013:8k_2_02:38]
•$72 million of video sales with government customers, up 32% year over year

[0000068505-21-000013:8k_2_02:39]
•$37 million P25 upgrade order for government agency in Canada

[0000068505-21-000013:8k_2_02:40]
•$33 million TETRA upgrade for large customer in Europe

[0000068505-21-000013:8k_2_02:41]
•$12 million P25 order with large U.S. federal customer

[0000068505-21-000013:8k_2_02:42]
BUSINESS OUTLOOK

[0000068505-21-000013:8k_2_02:43]
•Second-quarter 2021 - Motorola Solutions expects revenue growth of 19% to 20% compared to the second quarter of 2020. The company expects non-GAAP earnings per share in the range of $1.90 to $1.95. This assumes current foreign exchange rates, approximately 173 million fully diluted shares, and an effective tax rate of 23% to 24%.

[0000068505-21-000013:8k_2_02:44]
•Full-year 2021 - Motorola Solutions now expects revenue growth of 8% to 9%, up from the prior guidance of growth of 7.25% to 8%, and non-GAAP earnings per share in the range of $8.70 to $8.80, up from the prior guidance of $8.50 to $8.62. This assumes current foreign exchange rates, approximately 173 million fully diluted shares, and an effective tax rate of 22.5% to 23%.

[0000068505-21-000013:8k_2_02:45]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-21-000013:8k_2_02:46]
COVID-19

[0000068505-21-000013:8k_2_02:47]
In response to the COVID-19 pandemic, the company continues to adhere to its plans to keep its employees and customers healthy and safe, including having office workers work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings, and using thermal scanning. We have continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service our mission-critical networks on-site as needed to ensure seamless operations. In addition, the company's supply chain partners remain supportive and continue to work to fulfill the necessary service levels to the company and its customers.

[0000068505-21-000013:8k_2_02:48]
The sales teams’ have continued to improve virtual engagement with our customers. Additionally, the company’s engineering teams have adapted its solutions offerings to equip customers with the latest technology in an effort to protect their workplace from the spread of COVID-19. Specifically, in Video Security and Analytics, the company has adapted its software and hardware offerings to provide analytics for occupancy counting, face mask detection and thermal detection capabilities.

[0000068505-21-000013:8k_2_02:49]
3

[0000068505-21-000013:8k_2_02:50]
Although the COVID-19 pandemic continued to influence our business activities in the first quarter of 2021, the negative impacts on our business from COVID-19 have begun to ease. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 (the "ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We continue to evaluate the potential impact of the ARPA on our business and results of operations. In addition, we continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-21-000013:8k_2_02:51]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, May 6. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-21-000013:8k_2_02:52]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-21-000013:8k_2_02:53]
A comparison of results from operations is as follows:

[0000068505-21-000013:8k_2_02:54]
|  | Q1 2021 | Q1 2020 |
| Net sales | $1,773 | $1,655 |
| Gross margin | 860 |  | 787 |  |
| Operating earnings | 298 |  | 259 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 244 |  | 197 |  |
| Diluted EPS | 1.41 |  | 1.12 |  |
| Weighted average diluted common shares outstanding | 173.2 |  | 175.9 |  |

[0000068505-21-000013:8k_2_02:55]
HIGHLIGHTED ITEMS

[0000068505-21-000013:8k_2_02:56]
The table below includes highlighted items, share-based compensation expense and intangible assets amortization expense for the first quarter of 2021.

[0000068505-21-000013:8k_2_02:57]
| (per diluted common share) | Q1 2021 |
| GAAP EPS | $1.41 |
| Highlighted Items: |  |
| Intangible assets amortization expense | 0.26 |  |
| Share-based compensation expenses | 0.13 |  |
| Reorganization of business charges | 0.07 |  |
| Operating lease asset impairments | 0.03 |  |
| Hytera-related legal expenses | 0.01 |  |
| Acquisition-related transaction fees | 0.01 |  |
| Fair value adjustments to equity investments | (0.02) |  |
| Release of uncertain tax positions | (0.03) |  |
| Non-GAAP EPS | $1.87 |

[0000068505-21-000013:8k_2_02:58]
4

[0000068505-21-000013:8k_2_02:59]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-21-000013:8k_2_02:60]
In addition to the GAAP results included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-21-000013:8k_2_02:61]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-21-000013:8k_2_02:62]
Free cash flow: Free cash flow represents operating cash flow less capital expenditures. We believe that free cash flow is also useful to investors as the basis for comparing our performance and coverage ratios with other companies in our industries, although our measure of free cash flow may not be directly comparable to similar measures used by other companies.

[0000068505-21-000013:8k_2_02:63]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes non-GAAP organic revenue growth provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-21-000013:8k_2_02:64]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-21-000013:8k_2_02:65]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-21-000013:8k_2_02:66]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement

[0000068505-21-000013:8k_2_02:67]
5

[0000068505-21-000013:8k_2_02:68]
case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. The royalty rate is yet to be determined, and will be set by the Court absent agreement of the parties.

[0000068505-21-000013:8k_2_02:69]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for pre-judgment interest, although the precise amount of interest owed to the company by Hytera is still to be determined by the Court. On March 25, 2021, the Court entered rulings favorable to the company with respect to several of the company's post-trial motions, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award.

[0000068505-21-000013:8k_2_02:70]
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property.

[0000068505-21-000013:8k_2_02:71]
Management typically considers legal expenses associated with defending our intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both our GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. We anticipate further expenses associated with Hytera-related litigation; however, as of 2020, we believe that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate our business. In addition, if any contingent or actual gain associated with the Hytera litigation is recognized in the future, it will be similarly excluded from our non-GAAP operating income. We believe after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates our ongoing underlying business performance.

[0000068505-21-000013:8k_2_02:72]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-21-000013:8k_2_02:73]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-21-000013:8k_2_02:74]
6

[0000068505-21-000013:8k_2_02:75]
FORWARD LOOKING STATEMENTS

[0000068505-21-000013:8k_2_02:76]
ABOUT MOTOROLA SOLUTIONS

[0000068505-21-000013:8k_2_02:77]
Motorola Solutions is a global leader in mission-critical communications and analytics. Our technology platforms in land mobile radio mission critical communications, command center software and video security & analytics, bolstered by managed & support services, make cities safer and help businesses stay productive and secure. At Motorola Solutions, we are ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-21-000013:8k_2_02:78]
7

[0000068505-21-000013:8k_2_02:79]
MEDIA CONTACT

[0000068505-21-000013:8k_2_02:80]
Alexandra Reynolds

[0000068505-21-000013:8k_2_02:81]
Motorola Solutions

[0000068505-21-000013:8k_2_02:82]
+1 312-965-3968

[0000068505-21-000013:8k_2_02:83]
alexandra.reynolds@motorolasolutions.com

[0000068505-21-000013:8k_2_02:84]
INVESTOR CONTACT

[0000068505-21-000013:8k_2_02:85]
Tim Yocum

[0000068505-21-000013:8k_2_02:86]
Motorola Solutions

[0000068505-21-000013:8k_2_02:87]
+1 847-576-6899

[0000068505-21-000013:8k_2_02:88]
Tim.Yocum@motorolasolutions.com

[0000068505-21-000013:8k_2_02:89]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2021 Motorola Solutions, Inc. All rights reserved.

[0000068505-21-000013:8k_2_02:90]
GAAP-1

[0000068505-21-000013:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:92]
Condensed Consolidated Statements of Operations

[0000068505-21-000013:8k_2_02:93]
(In millions, except per share amounts)

[0000068505-21-000013:8k_2_02:94]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| Net sales from products | $ | 926 |  |  | $ | 884 |  |
| Net sales from services | 847 |  |  | 771 |  |
| Net sales | 1,773 |  |  | 1,655 |  |
| Costs of products sales | 438 |  |  | 397 |  |
| Costs of services sales | 475 |  |  | 471 |  |
| Costs of sales | 913 |  |  | 868 |  |
| Gross margin | 860 |  |  | 787 |  |
| Selling, general and administrative expenses | 303 |  |  | 341 |  |
| Research and development expenditures | 180 |  |  | 168 |  |
| Other charges (income) | 21 |  |  | (34) |  |
| Intangibles amortization | 58 |  |  | 53 |  |
| Operating earnings | 298 |  |  | 259 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (54) |  |  | (52) |  |
| Other, net | 45 |  |  | 17 |  |
| Total other expense | (9) |  |  | (35) |  |
| Net earnings before income taxes | 289 |  |  | 224 |  |
| Income tax expense | 44 |  |  | 26 |  |
| Net earnings | 245 |  |  | 198 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 244 |  |  | $ | 197 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.44 |  |  | $ | 1.15 |  |
| Diluted | $ | 1.41 |  |  | $ | 1.12 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 169.3 |  |  | 170.6 |  |
| Diluted | 173.2 |  |  | 175.9 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 52.2 | % |  | 53.4 | % |
| Net sales from services | 47.8 | % |  | 46.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.3 | % |  | 44.9 | % |
| Costs of services sales | 56.1 | % |  | 61.1 | % |
| Costs of sales | 51.5 | % |  | 52.4 | % |
| Gross margin | 48.5 | % |  | 47.6 | % |
| Selling, general and administrative expenses | 17.1 | % |  | 20.6 | % |
| Research and development expenditures | 10.2 | % |  | 10.2 | % |
| Other charges (income) | 1.2 | % |  | (2.1) | % |
| Intangibles amortization | 3.3 | % |  | 3.2 | % |
| Operating earnings | 16.8 | % |  | 15.6 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.0) | % |  | (3.1) | % |
| Other, net | 2.5 | % |  | 1.0 | % |
| Total other expense | (0.5) | % |  | (2.1) | % |
| Net earnings before income taxes | 16.3 | % |  | 13.5 | % |
| Income tax expense | 2.5 | % |  | 1.6 | % |
| Net earnings | 13.8 | % |  | 12.0 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 13.8 | % |  | 11.9 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-21-000013:8k_2_02:95]
9

[0000068505-21-000013:8k_2_02:96]
GAAP-2

[0000068505-21-000013:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:98]
Condensed Consolidated Balance Sheets

[0000068505-21-000013:8k_2_02:99]
(In millions)

[0000068505-21-000013:8k_2_02:100]
|  | April 3, 2021 |  | December 31, 2020 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,320 |  |  | $ | 1,254 |  |
| Accounts receivable, net | 1,090 |  |  | 1,390 |  |
| Contract assets | 767 |  |  | 933 |  |
| Inventories, net | 530 |  |  | 508 |  |
| Other current assets | 235 |  |  | 242 |  |
| Total current assets | 3,942 |  |  | 4,327 |  |
| Property, plant and equipment, net | 1,028 |  |  | 1,022 |  |
| Operating lease assets | 448 |  |  | 468 |  |
| Investments | 168 |  |  | 158 |  |
| Deferred income taxes | 955 |  |  | 966 |  |
| Goodwill | 2,221 |  |  | 2,219 |  |
| Intangible assets, net | 1,180 |  |  | 1,234 |  |
| Other assets | 481 |  |  | 482 |  |
| Total assets | $ | 10,423 |  |  | $ | 10,876 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |
| Current portion of long-term debt | $ | 11 |  |  | $ | 12 |  |
| Accounts payable | 484 |  |  | 612 |  |
| Contract liabilities | 1,419 |  |  | 1,554 |  |
| Accrued liabilities | 1,181 |  |  | 1,311 |  |
| Total current liabilities | 3,095 |  |  | 3,489 |  |
| Long-term debt | 5,164 |  |  | 5,163 |  |
| Operating lease liabilities | 356 |  |  | 402 |  |
| Other liabilities | 2,286 |  |  | 2,363 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) | (496) |  |  | (558) |  |
| Non-controlling interests | 18 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 10,423 |  |  | $ | 10,876 |  |

[0000068505-21-000013:8k_2_02:101]
GAAP-3

[0000068505-21-000013:8k_2_02:102]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:103]
Condensed Consolidated Statements of Cash Flows

[0000068505-21-000013:8k_2_02:104]
(In millions)

[0000068505-21-000013:8k_2_02:105]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| Operating |  |  |  |
| Net earnings | $ | 245 |  |  | $ | 198 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 110 |  |  | 99 |  |
| Non-cash other income | (7) |  |  | (51) |  |
| Share-based compensation expenses | 29 |  |  | 38 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 298 |  |  | 275 |  |
| Inventories | (24) |  |  | 2 |  |
| Other current assets and contract assets | 149 |  |  | 48 |  |
| Accounts payable, accrued liabilities, and contract liabilities | (426) |  |  | (301) |  |
| Other assets and liabilities | (5) |  |  | (4) |  |
| Deferred income taxes | 1 |  |  | 4 |  |
| Net cash provided by operating activities | 370 |  |  | 308 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (2) |  |  | (36) |  |
| Proceeds from sales of investments and businesses, net | 2 |  |  | 2 |  |
| Capital expenditures | (52) |  |  | (48) |  |
| Proceeds from sales of property, plant and equipment | — |  |  | 56 |  |
| Net cash used for investing activities | (52) |  |  | (26) |  |
| Financing |  |  |  |
| Revolving credit facility renewal fees | (7) |  |  | — |  |
| Repayment of debt | (3) |  |  | (4) |  |
| Proceeds from unsecured revolving credit facility draw | — |  |  | 800 |  |
| Issuances of common stock | 45 |  |  | 5 |  |
| Purchases of common stock | (170) |  |  | (253) |  |
| Payments of dividends | (121) |  |  | (109) |  |
| Net cash provided by (used for) financing activities | (256) |  |  | 439 |  |
| Effect of exchange rate changes on total cash and cash equivalents | 4 |  |  | (50) |  |
| Net increase in total cash and cash equivalents | 66 |  |  | 671 |  |
| Cash and cash equivalents, beginning of period | 1,254 |  |  | 1,001 |  |
| Cash and cash equivalents, end of period | $ | 1,320 |  |  | $ | 1,672 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 318 |  |  | $ | 260 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-21-000013:8k_2_02:106]
11

[0000068505-21-000013:8k_2_02:107]
GAAP-4

[0000068505-21-000013:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:109]
Segment Information

[0000068505-21-000013:8k_2_02:110]
(In millions)

[0000068505-21-000013:8k_2_02:111]
| Net Sales |  |  |
|  | Three Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 1,015 |  |  | $ | 993 |  |  | 2 | % |  |  |
| Software and Services | 758 |  |  | 662 |  |  | 15 | % |  |  |
| Total Motorola Solutions | $ | 1,773 |  |  | $ | 1,655 |  |  | 7 | % |  |  |
| Operating Earnings |
|  | Three Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 77 |  |  | $ | 92 |  |  | (16) | % |  |  |
| Software and Services | 221 |  |  | 167 |  |  | 32 | % |  |  |
| Total Motorola Solutions | $ | 298 |  |  | $ | 259 |  |  | 15 | % |  |  |

[0000068505-21-000013:8k_2_02:112]
| Operating Earnings % |  |  |
|  | Three Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Products and Systems Integration | 7.6 | % |  | 9.3 | % |  |  |  |  |
| Software and Services | 29.1 | % |  | 25.2 | % |  |  |  |  |
| Total Motorola Solutions | 16.8 | % |  | 15.6 | % |  |  |  |  |

[0000068505-21-000013:8k_2_02:113]
12

[0000068505-21-000013:8k_2_02:114]
Non-GAAP-1

[0000068505-21-000013:8k_2_02:115]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:116]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expenses, and Highlighted Items)

[0000068505-21-000013:8k_2_02:117]
(In millions)

[0000068505-21-000013:8k_2_02:118]
| Q1 2021 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | TaxInc/(Exp) |  | PAT(Inc)/Exp |  | EPS impact |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 58 |  |  | $ | 13 |  |  | $ | 45 |  |  | $ | 0.26 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 29 |  |  | 6 |  |  | 23 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 16 |  |  | 3 |  |  | 13 |  |  | 0.07 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 7 |  |  | 1 |  |  | 6 |  |  | 0.03 |  |
| Hytera-related legal expenses |  | SG&A |  | 2 |  |  | 1 |  |  | 1 |  |  | 0.01 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | (5) |  |  | (1) |  |  | (4) |  |  | (0.02) |  |
| Release of uncertain tax positions |  | Other income (expense) |  | (1) |  |  | 4 |  |  | (5) |  |  | (0.03) |  |
| Total impact on Net earnings |  |  |  | $ | 107 |  |  | $ | 27 |  |  | $ | 80 |  |  | $ | 0.46 |  |

[0000068505-21-000013:8k_2_02:119]
13

[0000068505-21-000013:8k_2_02:120]
Non-GAAP-2

[0000068505-21-000013:8k_2_02:121]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:122]
Non-GAAP Segment Information

[0000068505-21-000013:8k_2_02:123]
(In millions)

[0000068505-21-000013:8k_2_02:124]
| Net Sales |  |  |
|  | Three Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 1,015 |  |  | $ | 993 |  |  | 2 | % |  |  |
| Software and Services | 758 |  |  | 662 |  |  | 15 | % |  |  |
| Total Motorola Solutions | $ | 1,773 |  |  | $ | 1,655 |  |  | 7 | % |  |  |
| Non-GAAP Operating Earnings |  |  |
|  | Three Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 131 |  |  | $ | 123 |  |  | 7 | % |  |  |
| Software and Services | 280 |  |  | 224 |  |  | 25 | % |  |  |
| Total Motorola Solutions | $ | 411 |  |  | $ | 347 |  |  | 18 | % |  |  |

[0000068505-21-000013:8k_2_02:125]
| Non-GAAP Operating Earnings % |  |  |
|  | Three Months Ended |  |  |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Products and Systems Integration | 12.9 | % |  | 12.4 | % |  |  |  |  |
| Software and Services | 36.9 | % |  | 33.8 | % |  |  |  |  |
| Total Motorola Solutions | 23.2 | % |  | 21.0 | % |  |  |  |  |

[0000068505-21-000013:8k_2_02:126]
Non-GAAP-3

[0000068505-21-000013:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:128]
Operating Earnings after Non-GAAP Adjustments

[0000068505-21-000013:8k_2_02:129]
(In millions)

[0000068505-21-000013:8k_2_02:130]
| Q1 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,773 |  |  | $ | 1,015 |  |  | $ | 758 |  |
| Operating earnings ("OE") |  | $ | 298 |  |  | $ | 77 |  |  | $ | 221 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 58 |  |  | 13 |  |  | 45 |  |
| Share-based compensation expenses |  | 29 |  |  | 22 |  |  | 7 |  |
| Reorganization of business charges |  | 16 |  |  | 12 |  |  | 4 |  |
| Operating lease asset impairment |  | 7 |  |  | 5 |  |  | 2 |  |
| Hytera-related legal expenses |  | 2 |  |  | 2 |  |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 113 |  |  | 54 |  |  | 59 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 411 |  |  | $ | 131 |  |  | $ | 280 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 16.8 | % |  | 7.6 | % |  | 29.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 23.2 | % |  | 12.9 | % |  | 36.9 | % |

[0000068505-21-000013:8k_2_02:131]
15

[0000068505-21-000013:8k_2_02:132]
Non-GAAP-4

[0000068505-21-000013:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000013:8k_2_02:134]
Non-GAAP Organic Revenue

[0000068505-21-000013:8k_2_02:135]
(In millions)

[0000068505-21-000013:8k_2_02:136]
|  |  | Three Months Ended |  |  |
|  |  | April 3, 2021 |  | March 28, 2020 |  | % Change |
| Net sales |  | $ | 1,773 |  |  | $ | 1,655 |  |  | 7 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 49 |  |  | 1 |  |  |  |
| Organic revenue |  | $ | 1,724 |  |  | $ | 1,654 |  |  | 4 | % |

[0000068505-21-000013:8k_2_02:137]
16
