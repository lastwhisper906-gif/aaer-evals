# MSI note change history — 0000068505-20-000028 → 0000068505-21-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-05-06):
[0000068505-21-000015:note_history:1]
Commitments and Contingencies
Legal Matters

- added (2021-05-06):
[0000068505-21-000015:note_history:2]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. The royalty rate is yet to be determined, and will be set by the Court absent agreement of the parties.

- added (2021-05-06):
[0000068505-21-000015:note_history:3]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest, although the precise amount of interest owed to the Company by Hytera is still to be determined by the Court. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award.
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.

- removed (2021-05-06):
[0000068505-20-000028:note_history:4]
Commitments and ContingenciesLegal MattersOn February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in its trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. A motion for a new trial was filed by Hytera in April 2020. The Court denied the motion and upheld the damages awarded to the Company on October 20, 2020, subsequent to the quarter. Other post-trial motions are fully briefed and awaiting ruling, including the Company's motion for a permanent global injunction, as well as the Company's requests for attorneys' fees and increased damages to include post-trial amounts. Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in May 2020; the Company filed motions to dismiss the bankruptcy proceedings in July 2020. As of the third quarter of 2020, the United States Bankruptcy Court granted a continuance of Hytera’s sale motion and the Company’s motion to dismiss Hytera’s bankruptcy.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0000068505-21-000015:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of April 3, 2021 and for the three months ended April 3, 2021 and March 28, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2020-10-30, similarity 0.9329):
[0000068505-20-000028:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of September 26, 2020 and for the three and nine months ended September 26, 2020 and September 28, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- added (2021-05-06):
[0000068505-21-000015:note_history:6]
The Company operates on a 52-week fiscal year, with each fiscal year ending on December 31. With respect to each fiscal quarter, the Company operates on a 13-week fiscal quarter, with all fiscal quarters ending on a Saturday.

- changed (2021-05-06):
[0000068505-21-000015:note_history:7]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three months ended April 3, 2021 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2020-10-30, similarity 0.7219):
[0000068505-20-000028:note_history:7]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three and nine months ended September 26, 2020 are not necessarily indicative of the operating results to be expected for the full year.

- added (2021-05-06):
[0000068505-21-000015:note_history:8]
Change in Presentation

- added (2021-05-06):
[0000068505-21-000015:note_history:9]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Analytics, and Command Center Software.

- added (2021-05-06):
[0000068505-21-000015:note_history:10]
•LMR Mission Critical Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

- added (2021-05-06):
[0000068505-21-000015:note_history:11]
•Video Security and Analytics: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

- added (2021-05-06):
[0000068505-21-000015:note_history:12]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from 911 call to case closure.

- changed (2021-05-06):
[0000068505-21-000015:note_history:13]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to the Company's existing Command Center Software suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.
  (was, 2020-10-30, similarity 0.6352):
[0000068505-20-000028:note_history:13]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing command center software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

- added (2021-05-06):
[0000068505-21-000015:note_history:14]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2021-05-06):
[0000068505-21-000015:note_history:15]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Analytics technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2021-05-06):
[0000068505-21-000015:note_history:16]
On April 30, 2020, the Company acquired a cybersecurity services business for $32 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.
  (was, 2020-10-30, similarity 0.9732):
[0000068505-20-000028:note_history:16]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

- changed (2021-05-06):
[0000068505-21-000015:note_history:17]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with
  (was, 2020-10-30, similarity 0.7075):
[0000068505-20-000028:note_history:17]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

- added (2021-05-06):
[0000068505-21-000015:note_history:18]
cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

- changed (2021-05-06):
[0000068505-21-000015:note_history:19]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of the adoption of this ASU on its financial statements and disclosures.
  (was, 2020-10-30, similarity 0.9337):
[0000068505-20-000028:note_history:19]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share ("EPS"). The ASU clarifies that the average market price should be used to calculate the diluted EPS denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

- changed (2021-05-06):
[0000068505-21-000015:note_history:20]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statement disclosures.
  (was, 2020-10-30, similarity 0.6083):
[0000068505-20-000028:note_history:20]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The adoption of the ASU will not have a significant impact on the financial statement disclosures.

- removed (2021-05-06):
[0000068505-20-000028:note_history:21]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- removed (2021-05-06):
[0000068505-20-000028:note_history:22]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The business is a part of both the Product and Systems Integration segment and the Software and Services segment.

- removed (2021-05-06):
[0000068505-20-000028:note_history:23]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances the Company's video security platform by adding data to the Company’s existing license plate recognition (“LPR”) database within the Software and Services segment.

- removed (2021-05-06):
[0000068505-20-000028:note_history:24]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

- removed (2021-05-06):
[0000068505-20-000028:note_history:25]
On March 11, 2019, the Company acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.

- removed (2021-05-06):
[0000068505-20-000028:note_history:26]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

- removed (2021-05-06):
[0000068505-20-000028:note_history:27]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

- removed (2021-05-06):
[0000068505-20-000028:note_history:28]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information was not updated and disclosures required under ASC 326 are not provided for dates and periods before January 1, 2020.

- removed (2021-05-06):
[0000068505-20-000028:note_history:29]
The Company considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets, and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (Direct and Indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact to the Company's financial statements.

- removed (2021-05-06):
[0000068505-20-000028:note_history:30]
The following table displays the rollforward of the allowance for credit losses on the Company's trade receivables:

- removed (2021-05-06):
[0000068505-20-000028:note_history:31]
|  | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at September 26, 2020 |
| Allowance for credit losses | $ | 63 |  | $ | 38 |  | $ | (26) |  | $ | (2) |  | $ | 73 |  |

- removed (2021-05-06):
[0000068505-20-000028:note_history:32]
*Adjustments include translation adjustments


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-05-06):
[0000068505-21-000015:note_history:33]
Debt and Credit Facilities
On March 24, 2021, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in March 2026, which can be used for general corporate purposes and letters of credit (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement replaces the Company’s $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022. The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 3, 2021.

- added (2021-05-06):
[0000068505-21-000015:note_history:34]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 3, 2021 the Company had no outstanding debt under the commercial paper program.

- removed (2021-05-06):
[0000068505-20-000028:note_history:35]
Debt and Credit Facilities

- removed (2021-05-06):
[0000068505-20-000028:note_history:36]
|  | September 26, 2020 |  | December 31, 2019 |
| $2.2 billion unsecured revolving credit facility due April 2022 | $ | 200 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | — |  |  | 550 |  |
| 3.5% senior notes due 2023 | 323 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 582 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 993 |  |  | 988 |  |
| 6.5% debentures due 2025 | 70 |  |  | 72 |  |
| 7.5% debentures due 2025 | 252 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 692 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 2.3% senior notes due 2030 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 19 |  |  | 35 |  |
|  | 5,376 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (3) |  |
| Less: current portion | (212) |  |  | (16) |  |
| Long-term debt | $ | 5,162 |  |  | $ | 5,113 |  |

- removed (2021-05-06):
[0000068505-20-000028:note_history:37]
As of September 26, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020, of which $600 million was repaid during the nine months ended September 26, 2020. As of September 26, 2020, the outstanding loan amount was $200 million. Subsequent to the quarter, the company repaid an additional $100 million, bringing the outstanding loan amount to $100 million. The weighted average borrowing rate for amounts outstanding during the three and nine months ended September 26, 2020 were 1.50% and 1.71%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 26, 2020.

- removed (2021-05-06):
[0000068505-20-000028:note_history:38]
In August of 2020, the Company issued $900 million of 2.30% Senior notes due 2030. The Company recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% Senior notes due 2022 for a redemption price of $582 million, excluding approximately $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of its long-term debt under a tender offer, for a purchase price of $315 million, excluding approximately $5 million of accrued interest, all of which occurred during the three months ended September 26, 2020. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- removed (2021-05-06):
[0000068505-20-000028:note_history:39]
As of September 26, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140, as may be adjusted for dividends declared, per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using 
a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. The Company has an unsecured commercial paper program, backed by the unsecured revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 26, 2020 the Company had no outstanding debt under the commercial paper program.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-05-06):
[0000068505-20-000028:note_history:40]
|  | September 26, 2020 |  | December 31, 2019 |
| $2.2 billion unsecured revolving credit facility due April 2022 | $ | 200 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | — |  |  | 550 |  |
| 3.5% senior notes due 2023 | 323 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 582 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 993 |  |  | 988 |  |
| 6.5% debentures due 2025 | 70 |  |  | 72 |  |
| 7.5% debentures due 2025 | 252 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 692 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 2.3% senior notes due 2030 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 19 |  |  | 35 |  |
|  | 5,376 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (3) |  |
| Less: current portion | (212) |  |  | (16) |  |
| Long-term debt | $ | 5,162 |  |  | $ | 5,113 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-05-06):
[0000068505-21-000015:note_history:41]
The following table summarizes the disaggregation of the Company's revenue by segment, geography, major product and service type and customer type for the three months ended April 3, 2021 and March 28, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- added (2021-05-06):
[0000068505-21-000015:note_history:42]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |  | $ | 748 |  |  | $ | 368 |  |  | $ | 1,116 |  |
| International | 273 |  |  | 315 |  |  | 588 |  |  | 245 |  |  | 294 |  |  | 539 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |  | $ | 860 |  |  | $ | 490 |  |  | $ | 1,350 |  |
| Video Security and Analytics | 165 |  |  | 88 |  |  | 253 |  |  | 133 |  |  | 67 |  |  | 200 |  |
| Command Center Software | — |  |  | 119 |  |  | 119 |  |  | — |  |  | 105 |  |  | 105 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Customer Type: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |  | $ | 641 |  |  | $ | 621 |  |  | $ | 1,262 |  |
| Indirect | 411 |  |  | 68 |  |  | 479 |  |  | 352 |  |  | 41 |  |  | 393 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |

- removed (2021-05-06):
[0000068505-20-000028:note_history:43]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 26, 2020 and September 28, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:

- removed (2021-05-06):
[0000068505-20-000028:note_history:44]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 863 |  |  | $ | 405 |  |  | $ | 980 |  |  | $ | 364 |  |
| International | 300 |  |  | 300 |  |  | 369 |  |  | 281 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 719 |  |  | $ | — |  |  | $ | 896 |  |  | $ | — |  |
| Systems and Systems Integration | 444 |  |  | — |  |  | 453 |  |  | — |  |
| Services | — |  |  | 514 |  |  | — |  |  | 479 |  |
| Software | — |  |  | 191 |  |  | — |  |  | 166 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 733 |  |  | $ | 637 |  |  | $ | 860 |  |  | $ | 602 |  |
| Indirect | 430 |  |  | 68 |  |  | 489 |  |  | 43 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |

- removed (2021-05-06):
[0000068505-20-000028:note_history:45]
|  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 2,646 |  |  | $ | 1,026 |  |
| International | 794 |  |  | 871 |  |  | 1,010 |  |  | 829 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,921 |  |  | $ | — |  |  | $ | 2,391 |  |  | $ | — |  |
| Systems and Systems Integration | 1,203 |  |  | — |  |  | 1,265 |  |  | — |  |
| Services | — |  |  | 1,490 |  |  | — |  |  | 1,400 |  |
| Software | — |  |  | 527 |  |  | — |  |  | 455 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 2,289 |  |  | $ | 1,737 |  |
| Indirect | 1,116 |  |  | 148 |  |  | 1,367 |  |  | 118 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-05-06):
[0000068505-21-000015:note_history:46]
The following table summarizes the disaggregation of the Company's revenue by segment, geography, major product and service type and customer type for the three months ended April 3, 2021 and March 28, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- added (2021-05-06):
[0000068505-21-000015:note_history:47]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |  | $ | 748 |  |  | $ | 368 |  |  | $ | 1,116 |  |
| International | 273 |  |  | 315 |  |  | 588 |  |  | 245 |  |  | 294 |  |  | 539 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |  | $ | 860 |  |  | $ | 490 |  |  | $ | 1,350 |  |
| Video Security and Analytics | 165 |  |  | 88 |  |  | 253 |  |  | 133 |  |  | 67 |  |  | 200 |  |
| Command Center Software | — |  |  | 119 |  |  | 119 |  |  | — |  |  | 105 |  |  | 105 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Customer Type: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |  | $ | 641 |  |  | $ | 621 |  |  | $ | 1,262 |  |
| Indirect | 411 |  |  | 68 |  |  | 479 |  |  | 352 |  |  | 41 |  |  | 393 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |

- changed (2021-05-06):
[0000068505-21-000015:note_history:48]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 3, 2021 was $7.2 billion. A total of $3.3 billion was from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.6 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion was from Software and Services performance obligations that were not yet satisfied as of April 3, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2020-10-30, similarity 0.9733):
[0000068505-20-000028:note_history:48]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction prices associated with remaining performance obligations which are not yet satisfied as of September 26, 2020 are $6.8 billion. A total of $2.9 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion is from Software and Services performance obligations that are not yet satisfied as of September 26, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.4 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2021-05-06):
[0000068505-21-000015:note_history:49]
| (In millions) | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,090 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 767 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,419 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 280 |  |  | 283 |  |  |  |  |  |
  (was, 2020-10-30, similarity 0.9414):
[0000068505-20-000028:note_history:49]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,155 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 1,069 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,359 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 266 |  |  | 274 |  |  |  |  |  |

- changed (2021-05-06):
[0000068505-21-000015:note_history:50]
Revenue recognized during the three months ended April 3, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $396 million, compared to $382 million of revenue recognized during the three months ended March 28, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $4 million was reversed during the three months ended April 3, 2021 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $19 million of reversals for the three months ended March 28, 2020.
  (was, 2020-10-30, similarity 0.6066):
[0000068505-20-000028:note_history:50]
Revenue recognized during the three months ended September 26, 2020 which was previously included in Contract liabilities as of June 27, 2020 is $349 million, compared to $342 million of revenue recognized during the three months ended September 28, 2019 which was previously included in Contract liabilities as of June 29, 2019. Revenue recognized during the nine months ended September 26, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $807 million, compared to $783 million of revenue recognized during the nine months ended September 28, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $12 million and $48 million was reversed during the three and nine months ended September 26, 2020 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. Revenue of $26 million and $42 million was reversed for the three and nine months ended September 28, 2019 driven by changes in the estimates of progress on system contracts.

- changed (2021-05-06):
[0000068505-21-000015:note_history:51]
There were no material expected credit losses recognized on contract assets during each of the three months ended April 3, 2021 and March 28, 2020.
  (was, 2020-10-30, similarity 0.8693):
[0000068505-20-000028:note_history:51]
There were no material expected credit losses recognized on contract assets during the three and nine months ended September 26, 2020 and September 28, 2019.

- changed (2021-05-06):
[0000068505-21-000015:note_history:52]
| (In millions) | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 36 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 105 |  |  |  |  |  |
  (was, 2020-10-30, similarity 0.9298):
[0000068505-20-000028:note_history:52]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 25 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 101 |  |  | 107 |  |  |  |  |  |

- added (2021-05-06):
[0000068505-21-000015:note_history:53]
Amortization of non-current contract cost assets was $13 million for the three months ended April 3, 2021 and $11 million for the three months ended March 28, 2020

- removed (2021-05-06):
[0000068505-20-000028:note_history:54]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 26, 2020 and September 28, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:

- removed (2021-05-06):
[0000068505-20-000028:note_history:55]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 863 |  |  | $ | 405 |  |  | $ | 980 |  |  | $ | 364 |  |
| International | 300 |  |  | 300 |  |  | 369 |  |  | 281 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 719 |  |  | $ | — |  |  | $ | 896 |  |  | $ | — |  |
| Systems and Systems Integration | 444 |  |  | — |  |  | 453 |  |  | — |  |
| Services | — |  |  | 514 |  |  | — |  |  | 479 |  |
| Software | — |  |  | 191 |  |  | — |  |  | 166 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 733 |  |  | $ | 637 |  |  | $ | 860 |  |  | $ | 602 |  |
| Indirect | 430 |  |  | 68 |  |  | 489 |  |  | 43 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |

- removed (2021-05-06):
[0000068505-20-000028:note_history:56]
|  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 2,646 |  |  | $ | 1,026 |  |
| International | 794 |  |  | 871 |  |  | 1,010 |  |  | 829 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,921 |  |  | $ | — |  |  | $ | 2,391 |  |  | $ | — |  |
| Systems and Systems Integration | 1,203 |  |  | — |  |  | 1,265 |  |  | — |  |
| Services | — |  |  | 1,490 |  |  | — |  |  | 1,400 |  |
| Software | — |  |  | 527 |  |  | — |  |  | 455 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 2,289 |  |  | $ | 1,737 |  |
| Indirect | 1,116 |  |  | 148 |  |  | 1,367 |  |  | 118 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |

- removed (2021-05-06):
[0000068505-20-000028:note_history:57]
Amortization of non-current contract cost assets was $13 million and $35 million for the three and nine months ended September 26, 2020, respectively, and $10 million and $32 million for the three and nine months ended September 28, 2019, respectively
