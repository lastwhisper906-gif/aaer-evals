# MSI MD&A — 0000068505-21-000015


## mdna

[0000068505-21-000015:mdna:1]
[same as prior period, unchanged from 0000068505-20-000028:mdna:1]

[0000068505-21-000015:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” the “Company,” “we,” “our,” or “us”) for the three months ended April 3, 2021 and March 28, 2020, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2020 (the "Form 10-K").

[0000068505-21-000015:mdna:3]
Forward-Looking Statements

[0000068505-21-000015:mdna:4]
[same as prior period, unchanged from 0000068505-20-000028:mdna:3]

[0000068505-21-000015:mdna:5]
Business Overview

[0000068505-21-000015:mdna:6]
During the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within our reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which we refer to as “technologies” in this Quarterly Report on Form 10-Q): Land Mobile Radio Mission Critical Communication (“LMR” or “LMR Mission Critical Communications”), Video Security and Analytics and Command Center Software.

[0000068505-21-000015:mdna:7]
•LMR Mission Critical Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

[0000068505-21-000015:mdna:8]
•Video Security and Analytics: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

[0000068505-21-000015:mdna:9]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from 911 call to case closure.

[0000068505-21-000015:mdna:10]
24

[0000068505-21-000015:mdna:11]
First Quarter Financial Results

[0000068505-21-000015:mdna:12]
•Net sales were $1.8 billion in the first quarter of 2021 compared to $1.7 billion in the first quarter of 2020.

[0000068505-21-000015:mdna:13]
•Operating earnings were $298 million in the first quarter of 2021 compared to $259 million in the first quarter of 2020.

[0000068505-21-000015:mdna:14]
•Net earnings attributable to Motorola Solutions, Inc. were $244 million, or $1.41 per diluted common share, in the first quarter of 2021, compared to $197 million, or $1.12 per diluted common share, in the first quarter of 2020.

[0000068505-21-000015:mdna:15]
•Operating cash flow increased $62 million to $370 million in the first quarter of 2021 compared to $308 million in the first quarter of 2020.

[0000068505-21-000015:mdna:16]
•We repurchased $170 million of common stock and paid $121 million in dividends in the first quarter of 2021.

[0000068505-21-000015:mdna:17]
COVID-19

[0000068505-21-000015:mdna:18]
In response to the COVID-19 pandemic, there have been a broad number of governmental and commercial actions taken to limit the spread of the virus, including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns. We continue to adhere to applicable governmental and commercial restrictions and to assess the impact on our employees, customers, communities, liquidity and financial position.

[0000068505-21-000015:mdna:19]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including having office workers work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings, and using thermal scanning. We have continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service our mission-critical networks on-site as needed to ensure seamless operations. Our sales teams have also continued to improve virtual engagement with our customers. Additionally, our engineering teams have adapted our solutions offerings to equip our customers with the latest technology in an effort to protect their workplaces from the spread of COVID-19. Specifically, in Video Security and Analytics, we have adapted our software and hardware offerings to provide analytics addressing occupancy counting, face mask detection, and thermal detection capabilities.

[0000068505-21-000015:mdna:20]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of April 3, 2021. Additionally, we have no bond maturities until 2023. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint. In addition, our supply chain partners have been supportive and continue to work to fulfill the necessary service levels to the Company and its customers.

[0000068505-21-000015:mdna:21]
Although the COVID-19 pandemic continued to influence our activities in the first quarter of 2021, as described above, the negative impacts on our business from COVID-19 have begun to ease. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impacts on net sales and operating margin will be limited in 2021. Within the Products and Systems Integration segment, we are encouraged by strong LMR backlog, and the resiliency of the Video Security and Analytics technology that experienced growth in the first quarter of 2021 and which we expect to continue to grow for the remainder of 2021. In addition, in March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 (the "ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We continue to evaluate the potential impact of the ARPA on our business and results of operations.

[0000068505-21-000015:mdna:22]
Lastly, we evaluated whether there were any impairment indicators as of April 3, 2021, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the first quarter of 2021, we concluded our assets were fairly stated and recoverable.

[0000068505-21-000015:mdna:23]
[same as prior period, unchanged from 0000068505-20-000028:mdna:16]

[0000068505-21-000015:mdna:24]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Command Center Software | Software and Services | Callyo | Provider of cloud-based mobile applications for law enforcement in North America, including critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. | $63 million, inclusive of share-based compensation of $3 million | August 28, 2020 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | Pelco, Inc. | Global provider of video security solutions, adding a broad range of products for a variety of commercial and industrial environments and use cases. | $110 million | July 31, 2020 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | IndigoVision Group plc | Provider of video security solutions to enhance geographical reach across a wider customer base. | $37 million | June 16, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, and managed services, including security monitoring of network operations. | $32 million | April 30, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, managed services, and remediation and response capabilities. | $40 million, inclusive of share-based compensation of $6 million | March 3, 2020 |

[0000068505-21-000015:mdna:25]
26

[0000068505-21-000015:mdna:26]
[same as prior period, unchanged from 0000068505-20-000028:mdna:30]

[0000068505-21-000015:mdna:27]
|  | Three Months Ended |  |  |
| (Dollars in millions, except per share amounts) | April 3, 2021 |  | % ofSales* |  | March 28, 2020 |  | % ofSales* |  |  |  |  |  |  |  |  |
| Net sales from products | $ | 926 |  |  |  |  | $ | 884 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales from services | 847 |  |  |  |  | 771 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 1,773 |  |  |  |  | 1,655 |  |  |  |  |  |  |  |  |  |  |  |
| Costs of products sales | 438 |  |  | 47.3 | % |  | 397 |  |  | 44.9 | % |  |  |  |  |  |  |  |  |
| Costs of services sales | 475 |  |  | 56.1 | % |  | 471 |  |  | 61.1 | % |  |  |  |  |  |  |  |  |
| Costs of sales | 913 |  |  |  |  | 868 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 860 |  |  | 48.5 | % |  | 787 |  |  | 47.6 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 303 |  |  | 17.1 | % |  | 341 |  |  | 20.6 | % |  |  |  |  |  |  |  |  |
| Research and development expenditures | 180 |  |  | 10.2 | % |  | 168 |  |  | 10.2 | % |  |  |  |  |  |  |  |  |
| Other charges | 79 |  |  | 4.5 | % |  | 19 |  |  | 1.1 | % |  |  |  |  |  |  |  |  |
| Operating earnings | 298 |  |  | 16.8 | % |  | 259 |  |  | 15.6 | % |  |  |  |  |  |  |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (54) |  |  | (3.0) | % |  | (52) |  |  | (3.1) | % |  |  |  |  |  |  |  |  |
| Other, net | 45 |  |  | 2.5 | % |  | 17 |  |  | 1.0 | % |  |  |  |  |  |  |  |  |
| Total other expense | (9) |  |  | (0.5) | % |  | (35) |  |  | (2.1) | % |  |  |  |  |  |  |  |  |
| Net earnings before income taxes | 289 |  |  | 16.3 | % |  | 224 |  |  | 13.5 | % |  |  |  |  |  |  |  |  |
| Income tax expense | 44 |  |  | 2.5 | % |  | 26 |  |  | 1.6 | % |  |  |  |  |  |  |  |  |
| Net earnings | 245 |  |  | 13.8 | % |  | 198 |  |  | 12.0 | % |  |  |  |  |  |  |  |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 244 |  |  | 13.8 | % |  | $ | 197 |  |  | 11.9 | % |  |  |  |  |  |  |  |  |
| Earnings per diluted common share | $ | 1.41 |  |  |  |  | $ | 1.12 |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-21-000015:mdna:28]
[same as prior period, unchanged from 0000068505-20-000028:mdna:32]

[0000068505-21-000015:mdna:29]
27

[0000068505-21-000015:mdna:30]
Results of Operations—Three months ended April 3, 2021 compared to three months ended March 28, 2020

[0000068505-21-000015:mdna:31]
The results of operations for the first quarter of 2021 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-21-000015:mdna:32]
We use the following U.S. GAAP key financial performance measures to manage our business on a consolidated basis and by reporting segment, and to monitor and assess our results of operations:

[0000068505-21-000015:mdna:33]
•Net sales—a measure of our revenue for the current period.

[0000068505-21-000015:mdna:34]
•Operating earnings—a measure of our earnings from operations, before non-operating expenses and income taxes.

[0000068505-21-000015:mdna:35]
•Operating margins—a measure of our operating earnings as a percentage of total net sales.

[0000068505-21-000015:mdna:36]
Considered together, we believe these measures are strong indicators of our overall performance and our ability to create shareholder value. A discussion of our results of operations and financial condition follows.

[0000068505-21-000015:mdna:37]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |  | $ | 748 |  |  | $ | 368 |  |  | $ | 1,116 |  |
| International | 273 |  |  | 315 |  |  | 588 |  |  | 245 |  |  | 294 |  |  | 539 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Net sales by technology |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |  | $ | 860 |  |  | $ | 490 |  |  | $ | 1,350 |  |
| Video Security and Analytics | 165 |  |  | 88 |  |  | 253 |  |  | 133 |  |  | 67 |  |  | 200 |  |
| Command Center Software | — |  |  | 119 |  |  | 119 |  |  | — |  |  | 105 |  |  | 105 |  |
| Total | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Operating earnings | $ | 77 |  |  | $ | 221 |  |  | $ | 298 |  |  | $ | 92 |  |  | $ | 167 |  |  | $ | 259 |  |
| Operating margins | 7.6 | % |  | 29.2 | % |  | 16.8 | % |  | 9.3 | % |  | 25.2 | % |  | 15.6 | % |

[0000068505-21-000015:mdna:38]
[same as prior period, unchanged from 0000068505-20-000028:mdna:36]

[0000068505-21-000015:mdna:39]
The Products and Systems Integration segment’s net sales represented 57% of our net sales in the first quarter of 2021 and 60% in the first quarter of 2020. The Software and Services segment’s net sales represented 43% of our net sales in the first quarter of 2021 and 40% in the first quarter of 2020.

[0000068505-21-000015:mdna:40]
Net sales increased $118 million, or 7%, in the first quarter of 2021 compared to the first quarter of 2020. The $22 million, or 2%, increase in net sales within the Products and Systems Integration segment was driven by an 11% increase in the International region partially offset by a 1% decrease in the North America region. The $96 million, or 15%, increase in net sales within the Software and Services segment was driven by a 21% increase in the North America region and a 7% increase in the International region. Net sales includes:

[0000068505-21-000015:mdna:41]
•an increase in the Products and Systems Integration segment, inclusive of $35 million of revenue from acquisitions, driven by an increase in Video Security and Analytics and PCR, partially offset by a decrease in public safety LMR;

[0000068505-21-000015:mdna:42]
•an increase in the Software and Services segment, inclusive of $13 million of revenue from acquisitions, driven by an increase in LMR services, Video Security and Analytics, and Command Center Software; and

[0000068505-21-000015:mdna:43]
•$32 million from favorable currency rates.

[0000068505-21-000015:mdna:44]
[same as prior period, unchanged from 0000068505-20-000028:mdna:43]

[0000068505-21-000015:mdna:45]
•a 6% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR services, Video Security and Analytics, PCR and Command Center Software, partially offset by a decline in public safety LMR products, which were impacted by supply constraints; and

[0000068505-21-000015:mdna:46]
•a 9% increase in the International region, inclusive of revenue from acquisitions, primarily driven by an increase in Video Security and Analytics and public safety LMR.

[0000068505-21-000015:mdna:47]
[same as prior period, unchanged from 0000068505-20-000028:mdna:46]

[0000068505-21-000015:mdna:48]
The 2% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-21-000015:mdna:49]
•$32 million, or 24% growth in Video Security and Analytics, inclusive of revenue from acquisitions, driven by both the International and North America regions;

[0000068505-21-000015:mdna:50]
•$10 million, or 1% decrease in LMR, primarily impacted by supply constraints in North America public safety LMR, partially offset by an increase in PCR sales; and

[0000068505-21-000015:mdna:51]
•$15 million from favorable currency rates.

[0000068505-21-000015:mdna:52]
[same as prior period, unchanged from 0000068505-20-000028:mdna:51]

[0000068505-21-000015:mdna:53]
The 15% increase in the Software and Services segment was driven by the following:

[0000068505-21-000015:mdna:54]
•$61 million, or 12% growth in LMR services, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000015:mdna:55]
•$21 million, or 31% growth in Video Security and Analytics, inclusive of revenue from acquisitions, driven by both the International and North America regions;

[0000068505-21-000015:mdna:56]
•$14 million, or 13% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000015:mdna:57]
•$17 million from favorable currency rates.

[0000068505-21-000015:mdna:58]
[same as prior period, unchanged from 0000068505-20-000028:mdna:56]

[0000068505-21-000015:mdna:59]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |  | % Change |
| Gross margin | $ | 860 |  |  | $ | 787 |  |  | 9 | % |

[0000068505-21-000015:mdna:60]
Gross margin was 48.5% of net sales in the first quarter of 2021 compared to 47.6% in the first quarter of 2020. The primary drivers of this increase were:

[0000068505-21-000015:mdna:61]
•higher gross margin within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth and improved mix of service offerings; and

[0000068505-21-000015:mdna:62]
•higher gross margin in the Products and Systems Integration segment, inclusive of acquisitions, as a result of LMR project mix within North America.

[0000068505-21-000015:mdna:63]
[same as prior period, unchanged from 0000068505-20-000028:mdna:61]

[0000068505-21-000015:mdna:64]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |  | % Change |
| Selling, general and administrative expenses | $ | 303 |  |  | $ | 341 |  |  | (11) | % |

[0000068505-21-000015:mdna:65]
SG&A expenses decreased 11% in the first quarter of 2021 compared to the first quarter of 2020. SG&A expenses were 17.1% of net sales in the first quarter of 2021 compared to 20.6% of net sales in the first quarter of 2020. The decrease in SG&A expenses was primarily due to reduced legal expenses, indirect expenses, travel expenses and share-based compensation expenses. The overall reduction in SG&A expenses was partially offset by higher expenses associated with acquired businesses and employee incentive costs.

[0000068505-21-000015:mdna:66]
[same as prior period, unchanged from 0000068505-20-000028:mdna:64]

[0000068505-21-000015:mdna:67]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |  | % Change |
| Research and development expenditures | $ | 180 |  |  | $ | 168 |  |  | 7 | % |

[0000068505-21-000015:mdna:68]
R&D expenditures increased 7% in the first quarter of 2021 compared to the first quarter of 2020 primarily due to higher expenses associated with acquired businesses and higher employee incentive costs. R&D expenditures remained flat at 10.2% of net sales in the first quarter of 2021 and the first quarter of 2020.

[0000068505-21-000015:mdna:69]
[same as prior period, unchanged from 0000068505-20-000028:mdna:67]

[0000068505-21-000015:mdna:70]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |
| Other charges | $ | 79 |  |  | $ | 19 |  |

[0000068505-21-000015:mdna:71]
Other charges increased by $60 million in the first quarter of 2021 compared to the first quarter of 2020. The change was driven primarily by the following:

[0000068505-21-000015:mdna:72]
•$50 million gain on the sale of property, plant and equipment in the first quarter of 2020 that did not recur in the first quarter of 2021; and

[0000068505-21-000015:mdna:73]
•$7 million of operating lease asset impairments in the first quarter of 2021.

[0000068505-21-000015:mdna:74]
[same as prior period, unchanged from 0000068505-20-000028:mdna:74]

[0000068505-21-000015:mdna:75]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |
| Operating earnings from Products and Systems Integration | $ | 77 |  |  | $ | 92 |  |
| Operating earnings from Software and Services | 221 |  |  | 167 |  |
| Operating earnings | $ | 298 |  |  | $ | 259 |  |

[0000068505-21-000015:mdna:76]
Operating earnings increased $39 million, or 15%, compared to the first quarter of 2020. The increase in Operating earnings was due to:

[0000068505-21-000015:mdna:77]
•Software and Services increased by $54 million, driven by higher sales and gross margin contribution due to improved mix of service offerings, as well as improved operating leverage; and

[0000068505-21-000015:mdna:78]
•partially offset by a decline of $15 million in Products and Systems Integration, primarily driven by a $50 million gain on the sale of property, plant and equipment in the first quarter of 2020 that did not recur in the first quarter of 2021, as well as higher incentive costs, partially offset by lower legal expenses, indirect spend and travel expenses.

[0000068505-21-000015:mdna:79]
[same as prior period, unchanged from 0000068505-20-000028:mdna:79]

[0000068505-21-000015:mdna:80]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |
| Interest expense, net | $ | (54) |  |  | $ | (52) |  |

[0000068505-21-000015:mdna:81]
The increase in interest expense, net in the first quarter of 2021 compared to the first quarter of 2020 was a result of lower interest income earned on cash due to lower interest rates for the period ending April 3, 2021 compared to the period ending March 28, 2020.

[0000068505-21-000015:mdna:82]
[same as prior period, unchanged from 0000068505-20-000028:mdna:82]

[0000068505-21-000015:mdna:83]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |
| Other, net | $ | 45 |  |  | $ | 17 |  |

[0000068505-21-000015:mdna:84]
The increase in Other, net in the first quarter of 2021 compared to the first quarter of 2020 was driven primarily by:

[0000068505-21-000015:mdna:85]
•$30 million of net periodic pension and postretirement benefit in the first quarter of 2021 compared to $20 million of net periodic pension and postretirement benefit in the first quarter of 2020;

[0000068505-21-000015:mdna:86]
•$8 million loss on derivatives in the first quarter of 2021 compared to a $16 million loss on derivatives in the first quarter of 2020;

[0000068505-21-000015:mdna:87]
•$5 million of gains related to fair value adjustments to equity investments in the first quarter of 2021 compared to $1 million of gains related to fair value adjustments to equity investments in the first quarter of 2020; and

[0000068505-21-000015:mdna:88]
•partially offset by $14 million of foreign currency gains in the first quarter of 2021 compared to $18 million of foreign currency gains in the first quarter of 2020;

[0000068505-21-000015:mdna:89]
[same as prior period, unchanged from 0000068505-20-000028:mdna:89]

[0000068505-21-000015:mdna:90]
|  | Three Months Ended |
| (In millions) | April 3, 2021 |  | March 28, 2020 |
| Income tax expense | $ | 44 |  |  | $ | 26 |  |

[0000068505-21-000015:mdna:91]
Income tax expense increased by $18 million in the first quarter of 2021 compared to the first quarter of 2020, resulting in an effective tax rate of 15%. Our effective tax rate for the three months ended April 3, 2021 is higher than the effective tax rate for the three months ended March 28, 2020 of 12%, primarily due to lower tax benefits on share-based compensation.

[0000068505-21-000015:mdna:92]
[same as prior period, unchanged from 0000068505-20-000028:mdna:150]

[0000068505-21-000015:mdna:93]
During the first quarter of 2021, we recorded net reorganization of business charges of $16 million including $14 million of charges recorded within Other charges and $2 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $18 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-21-000015:mdna:94]
During the first quarter of 2020, we recorded net reorganization of business charges of $18 million including $12 million of charges in Other charges and $6 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $22 million related to employee separation costs and $4 million reversals for accruals no longer needed.

[0000068505-21-000015:mdna:95]
The following table displays the net charges incurred by segment:

[0000068505-21-000015:mdna:96]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Products and Systems Integration | $ | 12 |  |  | $ | 14 |  |  |  |  |  |
| Software and Services | 4 |  |  | 4 |  |  |  |  |  |
|  | $ | 16 |  |  | $ | 18 |  |  |  |  |  |

[0000068505-21-000015:mdna:97]
Cash payments for employee severance in connection with the reorganization of business plans were $37 million in the first quarter of 2021 and $22 million in the first quarter of 2020. The reorganization of business accrual at April 3, 2021 was $58 million related to employee separation costs that are expected to be paid within one year.

[0000068505-21-000015:mdna:98]
[same as prior period, unchanged from 0000068505-20-000028:mdna:158]

[0000068505-21-000015:mdna:99]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 370 |  |  | $ | 308 |  |
| Investing activities | (52) |  |  | (26) |  |
| Financing activities | (256) |  |  | 439 |  |
| Effect of exchange rates on cash and cash equivalents | 4 |  |  | (50) |  |
| Increase (decrease) in cash and cash equivalents | $ | 66 |  |  | $ | 671 |  |

[0000068505-21-000015:mdna:100]
[same as prior period, unchanged from 0000068505-20-000028:mdna:160]

[0000068505-21-000015:mdna:101]
At April 3, 2021, $834 million of the $1.3 billion cash and cash equivalents balance was held in the U.S. and $486 million was held in other countries, with $122 million held in the United Kingdom.

[0000068505-21-000015:mdna:102]
[same as prior period, unchanged from 0000068505-20-000028:mdna:162]

[0000068505-21-000015:mdna:103]
The increase in cash flows provided by operating activities from the first quarter of 2020 to the first quarter of 2021 was driven primarily by an increase in earnings as a result of increased sales volume and improved working capital, partially offset by higher income tax payments.

[0000068505-21-000015:mdna:104]
[same as prior period, unchanged from 0000068505-20-000028:mdna:164]

[0000068505-21-000015:mdna:105]
The increase in cash flows used for investing activities from the first quarter of 2020 to the first quarter of 2021 was primarily due to:

[0000068505-21-000015:mdna:106]
•$56 million decrease in the proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in the first quarter of 2020; and

[0000068505-21-000015:mdna:107]
•partially offset by $34 million decrease in cash used for acquisitions and investments.

[0000068505-21-000015:mdna:108]
[same as prior period, unchanged from 0000068505-20-000028:mdna:169]

[0000068505-21-000015:mdna:109]
The increase in cash flows used for financing activities from the first quarter of 2020 as compared to the cash provided by financing activities in the first quarter of 2021 was primarily driven by (also see further discussion in "Debt," "Share Repurchase Program" and "Dividends" below):

[0000068505-21-000015:mdna:110]
•$800 million of proceeds received from the draw on our syndicated, unsecured revolving credit facility during the first quarter of 2020;

[0000068505-21-000015:mdna:111]
•$12 million increase in the payment of dividends in the first quarter of 2021 compared to the first quarter of 2020;

[0000068505-21-000015:mdna:112]
•$7 million related to the payment of revolving credit facility renewal fees in the first quarter of 2021;

[0000068505-21-000015:mdna:113]
•partially offset by an $83 million decrease in share repurchases in the first quarter of 2021 compared to the first quarter of 2020; and

[0000068505-21-000015:mdna:114]
•$40 million increase of net proceeds from the issuance of common stock in the first quarter of 2021 compared to the first quarter of 2020.

[0000068505-21-000015:mdna:115]
[same as prior period, unchanged from 0000068505-20-000028:mdna:176]

[0000068505-21-000015:mdna:116]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended April 3, 2021 and March 28, 2020:

[0000068505-21-000015:mdna:117]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Contract-specific discounting facility | $ | 71 |  |  | $ | 44 |  |  |  |  |  |
| Accounts receivable sales proceeds | — |  |  | 24 |  |  |  |  |  |
| Long-term receivables sales proceeds | 54 |  |  | 41 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 125 |  |  | $ | 109 |  |  |  |  |  |

[0000068505-21-000015:mdna:118]
During the three months ended April 3, 2021, we utilized a contract-specific receivable discounting facility which began during the three months ended March 28, 2020, resulting in accounts receivable sales of $71 million. The net benefit to our operating cash flow from the utilization of the receivable discounting facility for the three months ended April 3, 2021 was $71 million, when adjusted for amounts that were collected under the commercial contract with the customer within the period in the absence of utilizing the discounting facility. The proceeds of our receivable sales are included in Operating activities within our Condensed Consolidated Statements of Cash Flows.

[0000068505-21-000015:mdna:119]
[same as prior period, unchanged from 0000068505-20-000028:mdna:180]

[0000068505-21-000015:mdna:120]
We had outstanding debt of $5.2 billion at both April 3, 2021 and December 31, 2020, including the current portions of $11 million and $12 million at April 3, 2021 and December 31, 2020, respectively.

[0000068505-21-000015:mdna:121]
On March 24, 2021, we entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in March 2026, which can be used for general corporate purposes and letters of credit (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement replaces our $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022. The 2021 Motorola Solutions Credit Agreement includes a $450 million letter of credit sublimit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with the financial covenants as of April 3, 2021.

[0000068505-21-000015:mdna:122]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, we intend to settle the principal amount of the Senior Convertible Notes in cash. We recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, we calculated the debt liability to be $986 million, indicating a $14 million discount to be

[0000068505-21-000015:mdna:123]
amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital.

[0000068505-21-000015:mdna:124]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of April 3, 2021 we had no outstanding debt under the commercial paper program.

[0000068505-21-000015:mdna:125]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement. Refer also to “COVID-19” in this Part I, Item 3 of this Form 10-Q for a discussion of the impact of COVID-19 on our liquidity.

[0000068505-21-000015:mdna:126]
[same as prior period, unchanged from 0000068505-20-000028:mdna:188]

[0000068505-21-000015:mdna:127]
During the three months ended April 3, 2021, we paid an aggregate of $170 million, including transaction costs, to repurchase approximately 1.0 million shares at an average price of $175.53 per share. As of April 3, 2021, the Company had used approximately $13.5 billion of the share repurchase authority to repurchase shares, leaving $479 million of authority available for future repurchases. Subsequent to quarter end, the Board of Directors approved a $2.0 billion increase to the share repurchase program, raising the remaining authority for future repurchases to $2.5 billion.

[0000068505-21-000015:mdna:128]
[same as prior period, unchanged from 0000068505-20-000028:mdna:190]

[0000068505-21-000015:mdna:129]
During the first quarter of 2021 we paid $121 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $121 million in cash dividends to holders of our common stock.

[0000068505-21-000015:mdna:130]
[same as prior period, unchanged from 0000068505-20-000028:mdna:192]

[0000068505-21-000015:mdna:131]
We had outstanding commitments to provide long-term financing to third parties totaling $82 million at April 3, 2021, compared to $78 million at December 31, 2020.

[0000068505-21-000015:mdna:132]
[same as prior period, unchanged from 0000068505-20-000028:mdna:194]

[0000068505-21-000015:mdna:133]
See “Recent Accounting Pronouncements” and “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1. of this Form 10-Q.
