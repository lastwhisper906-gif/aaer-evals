# MSI notes — 0000068505-21-000015


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-21-000015:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of April 3, 2021 and for the three months ended April 3, 2021 and March 28, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-21-000015:notes:2]
The Company operates on a 52-week fiscal year, with each fiscal year ending on December 31. With respect to each fiscal quarter, the Company operates on a 13-week fiscal quarter, with all fiscal quarters ending on a Saturday.

[0000068505-21-000015:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three months ended April 3, 2021 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-21-000015:notes:4]
[same as prior period, unchanged from 0000068505-20-000028:notes:3]

[0000068505-21-000015:notes:5]
Change in Presentation

[0000068505-21-000015:notes:6]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Analytics, and Command Center Software.

[0000068505-21-000015:notes:7]
•LMR Mission Critical Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

[0000068505-21-000015:notes:8]
•Video Security and Analytics: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

[0000068505-21-000015:notes:9]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from 911 call to case closure.

[0000068505-21-000015:notes:10]
[same as prior period, unchanged from 0000068505-20-000028:notes:4]

[0000068505-21-000015:notes:11]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to the Company's existing Command Center Software suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

[0000068505-21-000015:notes:12]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000015:notes:13]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Analytics technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000015:notes:14]
On April 30, 2020, the Company acquired a cybersecurity services business for $32 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-21-000015:notes:15]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with

[0000068505-21-000015:notes:16]
cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-21-000015:notes:17]
[same as prior period, unchanged from 0000068505-20-000028:notes:14]

[0000068505-21-000015:notes:18]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-21-000015:notes:19]
Recently Adopted Accounting Pronouncements

[0000068505-21-000015:notes:20]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statement disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-21-000015:notes:21]
[same as prior period, unchanged from 0000068505-20-000028:notes:24]

[0000068505-21-000015:notes:22]
The following table summarizes the disaggregation of the Company's revenue by segment, geography, major product and service type and customer type for the three months ended April 3, 2021 and March 28, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-21-000015:notes:23]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |  | $ | 748 |  |  | $ | 368 |  |  | $ | 1,116 |  |
| International | 273 |  |  | 315 |  |  | 588 |  |  | 245 |  |  | 294 |  |  | 539 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |  | $ | 860 |  |  | $ | 490 |  |  | $ | 1,350 |  |
| Video Security and Analytics | 165 |  |  | 88 |  |  | 253 |  |  | 133 |  |  | 67 |  |  | 200 |  |
| Command Center Software | — |  |  | 119 |  |  | 119 |  |  | — |  |  | 105 |  |  | 105 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Customer Type: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |  | $ | 641 |  |  | $ | 621 |  |  | $ | 1,262 |  |
| Indirect | 411 |  |  | 68 |  |  | 479 |  |  | 352 |  |  | 41 |  |  | 393 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |

[0000068505-21-000015:notes:24]
[same as prior period, unchanged from 0000068505-20-000028:notes:28]

[0000068505-21-000015:notes:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 3, 2021 was $7.2 billion. A total of $3.3 billion was from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.6 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion was from Software and Services performance obligations that were not yet satisfied as of April 3, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-21-000015:notes:26]
[same as prior period, unchanged from 0000068505-20-000028:notes:30]

[0000068505-21-000015:notes:27]
| (In millions) | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,090 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 767 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,419 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 280 |  |  | 283 |  |  |  |  |  |

[0000068505-21-000015:notes:28]
Revenue recognized during the three months ended April 3, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $396 million, compared to $382 million of revenue recognized during the three months ended March 28, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $4 million was reversed during the three months ended April 3, 2021 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $19 million of reversals for the three months ended March 28, 2020.

[0000068505-21-000015:notes:29]
There were no material expected credit losses recognized on contract assets during each of the three months ended April 3, 2021 and March 28, 2020.

[0000068505-21-000015:notes:30]
[same as prior period, unchanged from 0000068505-20-000028:notes:34]

[0000068505-21-000015:notes:31]
| (In millions) | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 36 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 105 |  |  |  |  |  |

[0000068505-21-000015:notes:32]
Amortization of non-current contract cost assets was $13 million for the three months ended April 3, 2021 and $11 million for the three months ended March 28, 2020


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-21-000015:notes:33]
Leases
Components of Lease Expense

[0000068505-21-000015:notes:34]
|  | Three months ended |  |  |
| (in millions) | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 33 |  |  | $ | 34 |  |  |  |  |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | 3 |  |  | 3 |  |  |  |  |  |
| Short-term lease cost | 1 |  |  | — |  |  |  |  |  |
| Variable cost | 9 |  |  | 8 |  |  |  |  |  |
| Sublease income | (1) |  |  | (1) |  |  |  |  |  |
| Net lease expense | $ | 45 |  |  | $ | 44 |  |  |  |  |  |

[0000068505-21-000015:notes:35]
Lease Assets and Liabilities

[0000068505-21-000015:notes:36]
| (in millions) |  | Statement Line Classification |  | April 3, 2021 |  | December 31, 2020 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 448 |  |  | $ | 468 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 27 |  |  | 30 |  |  |  |
|  |  |  |  | $ | 475 |  |  | $ | 498 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 135 |  |  | $ | 126 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 10 |  |  | 11 |  |  |  |
|  |  |  |  | $ | 145 |  |  | $ | 137 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 356 |  |  | $ | 402 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 3 |  |  | 5 |  |  |  |
|  |  |  |  | $ | 359 |  |  | $ | 407 |  |  |  |

[0000068505-21-000015:notes:37]
Other Information Related to Leases

[0000068505-21-000015:notes:38]
|  | Three Months Ended |  |  |
| (in millions) | April 3, 2021 |  | March 28, 2020 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 54 |  |  | $ | 37 |  |  |  |
| Net cash used for financing activities related to finance leases | 3 |  |  | 3 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 15 |  |  | $ | 19 |  |  |  |

[0000068505-21-000015:notes:39]
| (in millions) | April 3, 2021 |  | December 31, 2020 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 6 |
| Finance leases | 1 |  | 2 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.16 | % |  | 3.30 | % |
| Finance leases | 4.18 | % |  | 4.21 | % |

[0000068505-21-000015:notes:40]
Future Lease Payments

[0000068505-21-000015:notes:41]
|  | April 3, 2021 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2021 | $ | 88 |  |  | $ | 8 |  |  | $ | 96 |  |
| 2022 | 130 |  |  | 5 |  |  | 135 |  |
| 2023 | 76 |  |  | 1 |  |  | 77 |  |
| 2024 | 62 |  |  | — |  |  | 62 |  |
| 2025 | 50 |  |  | — |  |  | 50 |  |
| Thereafter | 138 |  |  | — |  |  | 138 |  |
| Total lease payments | 544 |  |  | 14 |  |  | 558 |  |
| Less: interest | 53 |  |  | 1 |  |  | 54 |  |
| Present value of lease liabilities | $ | 491 |  |  | $ | 13 |  |  | $ | 504 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-21-000015:notes:42]
[same as prior period, unchanged from 0000068505-20-000028:notes:48]

[0000068505-21-000015:notes:43]
Other Charges

[0000068505-21-000015:notes:44]
[same as prior period, unchanged from 0000068505-20-000028:notes:50]

[0000068505-21-000015:notes:45]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 58 |  |  | $ | 53 |  |  |  |  |  |
| Reorganization of business (Note 14) | 14 |  |  | 12 |  |  |  |  |  |
| Operating lease asset impairments | 7 |  |  | — |  |  |  |  |  |
| Acquisition-related transaction fees | 1 |  |  | 2 |  |  |  |  |  |
| Losses on legal settlements | — |  |  | 2 |  |  |  |  |  |
| Gain on sale of property, plant and equipment | — |  |  | (50) |  |  |  |  |  |
| Other | (1) |  |  | — |  |  |  |  |  |
|  | $ | 79 |  |  | $ | 19 |  |  |  |  |  |

[0000068505-21-000015:notes:46]
During the three months ended April 3, 2021, the Company recognized $7 million of operating lease asset impairments relating to the consolidation of acquired U.S. manufacturing and distribution facilities. This loss has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-21-000015:notes:47]
During the three months ended March 28, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe. This gain has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-21-000015:notes:48]
[same as prior period, unchanged from 0000068505-20-000028:notes:53]

[0000068505-21-000015:notes:49]
[same as prior period, unchanged from 0000068505-20-000028:notes:54]

[0000068505-21-000015:notes:50]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (56) |  |  | $ | (55) |  |  |  |  |  |
| Interest income | 2 |  |  | 3 |  |  |  |  |  |
|  | $ | (54) |  |  | $ | (52) |  |  |  |  |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 30 |  |  | $ | 20 |  |  |  |  |  |
| Foreign currency gain | 14 |  |  | 18 |  |  |  |  |  |
| Loss on derivative instruments | (8) |  |  | (16) |  |  |  |  |  |
| Gains on equity method investments | 2 |  |  | 1 |  |  |  |  |  |
| Fair value adjustments to equity investments | 5 |  |  | 1 |  |  |  |  |  |
| Other | 2 |  |  | (7) |  |  |  |  |  |
|  | $ | 45 |  |  | $ | 17 |  |  |  |  |  |

[0000068505-21-000015:notes:51]
[same as prior period, unchanged from 0000068505-20-000028:notes:57]

[0000068505-21-000015:notes:52]
[same as prior period, unchanged from 0000068505-20-000028:notes:58]

[0000068505-21-000015:notes:53]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 244 |  |  | $ | 197 |  |  |  |  |  |
| Weighted average common shares outstanding | 169.3 |  |  | 170.6 |  |  |  |  |  |
| Per share amount | $ | 1.44 |  |  | $ | 1.15 |  |  |  |  |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 244 |  |  | $ | 197 |  |  |  |  |  |
| Weighted average common shares outstanding | 169.3 |  |  | 170.6 |  |  |  |  |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.9 |  |  | 5.3 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 173.2 |  |  | 175.9 |  |  |  |  |  |
| Per share amount | $ | 1.41 |  |  | $ | 1.12 |  |  |  |  |  |

[0000068505-21-000015:notes:54]
In the computation of diluted earnings per common share for the three months ended April 3, 2021, the assumed exercise of 0.3 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the three months ended March 28, 2020, 0.2 million options were excluded because their inclusion would have been antidilutive.

[0000068505-21-000015:notes:55]
As of April 3, 2021, the Company had $1.0 billion of 1.75% Senior Convertible Notes outstanding which mature on September 15, 2024 ("Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. The conversion price is adjusted for dividends declared through the date of settlement. For the period ended April 3, 2021, there was no dilutive effect of the Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price.

[0000068505-21-000015:notes:56]
[same as prior period, unchanged from 0000068505-20-000028:notes:63]

[0000068505-21-000015:notes:57]
[same as prior period, unchanged from 0000068505-20-000028:notes:64]

[0000068505-21-000015:notes:58]
[same as prior period, unchanged from 0000068505-20-000028:notes:65]

[0000068505-21-000015:notes:59]
|  | April 3, 2021 |  | December 31, 2020 |
| Accounts receivable | $ | 1,167 |  |  | $ | 1,465 |  |
| Less allowance for credit losses | (77) |  |  | (75) |  |
|  | $ | 1,090 |  |  | $ | 1,390 |  |

[0000068505-21-000015:notes:60]
[same as prior period, unchanged from 0000068505-20-000028:notes:67]

[0000068505-21-000015:notes:61]
[same as prior period, unchanged from 0000068505-20-000028:notes:68]

[0000068505-21-000015:notes:62]
|  | April 3, 2021 |  | December 31, 2020 |
| Finished goods | $ | 261 |  |  | $ | 271 |  |
| Work-in-process and production materials | 392 |  |  | 360 |  |
|  | 653 |  |  | 631 |  |
| Less inventory reserves | (123) |  |  | (123) |  |
|  | $ | 530 |  |  | $ | 508 |  |

[0000068505-21-000015:notes:63]
[same as prior period, unchanged from 0000068505-20-000028:notes:70]

[0000068505-21-000015:notes:64]
[same as prior period, unchanged from 0000068505-20-000028:notes:71]

[0000068505-21-000015:notes:65]
|  | April 3, 2021 |  | December 31, 2020 |
| Current contract cost assets (Note 2) | $ | 36 |  |  | $ | 23 |  |
| Tax-related deposits | 43 |  |  | 52 |  |
| Other | 156 |  |  | 167 |  |
|  | $ | 235 |  |  | $ | 242 |  |

[0000068505-21-000015:notes:66]
[same as prior period, unchanged from 0000068505-20-000028:notes:73]

[0000068505-21-000015:notes:67]
Property, plant and equipment, net, consist of the following:

[0000068505-21-000015:notes:68]
|  | April 3, 2021 |  | December 31, 2020 |
| Land | $ | 6 |  |  | $ | 6 |  |
| Leasehold improvements | 449 |  |  | 439 |  |
| Machinery and equipment | 2,331 |  |  | 2,276 |  |
|  | 2,786 |  |  | 2,721 |  |
| Less accumulated depreciation | (1,758) |  |  | (1,699) |  |
|  | $ | 1,028 |  |  | $ | 1,022 |  |

[0000068505-21-000015:notes:69]
Depreciation expense for the three months ended April 3, 2021 and March 28, 2020 was $52 million and $46 million, respectively.

[0000068505-21-000015:notes:70]
[same as prior period, unchanged from 0000068505-20-000028:notes:77]

[0000068505-21-000015:notes:71]
[same as prior period, unchanged from 0000068505-20-000028:notes:78]

[0000068505-21-000015:notes:72]
|  | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Common stock | $ | 24 |  |  | $ | 19 |  |  |  |  |  |
| Strategic investments, at cost | 48 |  |  | 46 |  |  |  |  |  |
| Company-owned life insurance policies | 79 |  |  | 77 |  |  |  |  |  |
| Equity method investments | 17 |  |  | 16 |  |  |  |  |  |
|  | $ | 168 |  |  | $ | 158 |  |  |  |  |  |

[0000068505-21-000015:notes:73]
[same as prior period, unchanged from 0000068505-20-000028:notes:80]

[0000068505-21-000015:notes:74]
[same as prior period, unchanged from 0000068505-20-000028:notes:81]

[0000068505-21-000015:notes:75]
|  | April 3, 2021 |  | December 31, 2020 |
| Defined benefit plan assets | $ | 308 |  |  | $ | 283 |  |
| Non-current contract cost assets (Note 2) | 105 |  |  | 105 |  |
| Other | 68 |  |  | 94 |  |
|  | $ | 481 |  |  | $ | 482 |  |

[0000068505-21-000015:notes:76]
[same as prior period, unchanged from 0000068505-20-000028:notes:83]

[0000068505-21-000015:notes:77]
[same as prior period, unchanged from 0000068505-20-000028:notes:84]

[0000068505-21-000015:notes:78]
|  | April 3, 2021 |  | December 31, 2020 |
| Compensation | $ | 232 |  |  | $ | 291 |  |
| Tax liabilities | 89 |  |  | 147 |  |
| Dividend payable | 121 |  |  | 120 |  |
| Trade liabilities | 153 |  |  | 164 |  |
| Operating lease liabilities (Note 3) | 135 |  |  | 126 |  |
| Other | 451 |  |  | 463 |  |
|  | $ | 1,181 |  |  | $ | 1,311 |  |

[0000068505-21-000015:notes:79]
[same as prior period, unchanged from 0000068505-20-000028:notes:86]

[0000068505-21-000015:notes:80]
[same as prior period, unchanged from 0000068505-20-000028:notes:87]

[0000068505-21-000015:notes:81]
|  | April 3, 2021 |  | December 31, 2020 |
| Defined benefit plans | $ | 1,531 |  |  | $ | 1,578 |  |
| Non-current contract liabilities (Note 2) | 280 |  |  | 283 |  |
| Deferred income taxes | 176 |  |  | 180 |  |
| Other | 299 |  |  | 322 |  |
|  | $ | 2,286 |  |  | $ | 2,363 |  |

[0000068505-21-000015:notes:82]
[same as prior period, unchanged from 0000068505-20-000028:notes:89]

[0000068505-21-000015:notes:83]
Share Repurchase Program: During the three months ended April 3, 2021, the Company paid an aggregate of $170 million, including transaction costs, to repurchase approximately 1.0 million shares at an average price of $175.53 per share. As of April 3, 2021, the Company had $479 million of authority available for future repurchases. Subsequent to quarter end, the Board of Directors approved a $2.0 billion increase to the share repurchase program, raising the remaining authority for future repurchases to $2.5 billion.

[0000068505-21-000015:notes:84]
Payment of Dividends: During the three months ended April 3, 2021 and March 28, 2020, the Company paid $121 million and $109 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $121 million in cash dividends to holders of its common stock.

[0000068505-21-000015:notes:85]
[same as prior period, unchanged from 0000068505-20-000028:notes:92]

[0000068505-21-000015:notes:86]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended April 3, 2021 and March 28, 2020:

[0000068505-21-000015:notes:87]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (360) |  |  | $ | (410) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | 17 |  |  | (136) |  |  |  |  |  |
| Tax benefit (expense) | 2 |  |  | (2) |  |  |  |  |  |
| Other comprehensive income (loss), net of tax | 19 |  |  | (138) |  |  |  |  |  |
| Balance at end of period | $ | (341) |  |  | $ | (548) |  |  |  |  |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,086) |  |  | $ | (2,030) |  |  |  |  |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 22 |  |  | 19 |  |  |  |  |  |
| Reclassification adjustment - Prior service benefits into Other expense (Note 8) | (2) |  |  | (4) |  |  |  |  |  |
| Tax benefit | (3) |  |  | (3) |  |  |  |  |  |
| Other comprehensive income, net of tax | 17 |  |  | 12 |  |  |  |  |  |
| Balance at end of period | $ | (2,069) |  |  | $ | (2,018) |  |  |  |  |  |
| Total Accumulated other comprehensive loss | $ | (2,410) |  |  | $ | (2,566) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-21-000015:notes:88]
Debt and Credit Facilities
On March 24, 2021, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in March 2026, which can be used for general corporate purposes and letters of credit (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement replaces the Company’s $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022. The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 3, 2021.

[0000068505-21-000015:notes:89]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 3, 2021 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-21-000015:notes:90]
[same as prior period, unchanged from 0000068505-20-000028:notes:100]

[0000068505-21-000015:notes:91]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.2 billion for each of the periods ended April 3, 2021 and December 31, 2020. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-21-000015:notes:92]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 3, 2021, and the corresponding positions as of December 31, 2020:

[0000068505-21-000015:notes:93]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 3, 2021 |  | December 31, 2020 |
| Euro | $ | 170 |  |  | $ | 177 |  |
| Canadian dollar | 50 |  |  | 61 |  |
| Norwegian krone | 35 |  |  | 32 |  |
| Chinese renminbi | (94) |  |  | (90) |  |
| Australian dollar | (82) |  |  | (88) |  |

[0000068505-21-000015:notes:94]
[same as prior period, unchanged from 0000068505-20-000028:notes:104]

[0000068505-21-000015:notes:95]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 3, 2021, all of the counterparties had investment grade credit ratings. As of April 3, 2021, the Company had $7 million of exposure to aggregate credit risk with all counterparties.

[0000068505-21-000015:notes:96]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of April 3, 2021 and December 31, 2020:

[0000068505-21-000015:notes:97]
|  | Fair Values of Derivative Instruments |
| April 3, 2021 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 6 |  |  | $ | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 1 |  |  | 11 |  |
| Total derivatives | $ | 7 |  |  | $ | 12 |  |

[0000068505-21-000015:notes:98]
|  | Fair Values of Derivative Instruments |
| December 31, 2020 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 5 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 14 |  |  | 3 |  |
| Total derivatives | $ | 14 |  |  | $ | 8 |  |

[0000068505-21-000015:notes:99]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended April 3, 2021 and March 28, 2020:

[0000068505-21-000015:notes:100]
|  | Financial Statement Location | Three Months Ended |  |  |
| Foreign Exchange Contracts | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Effective portion | Accumulated othercomprehensive income | $ | 4 |  |  | $ | 19 |  |  |  |  |  |
| Forward points recognized | Other income (expense) | — |  |  | 1 |  |  |  |  |  |
| Undesignated derivatives recognized | Other income (expense) | (8) |  |  | (16) |  |  |  |  |  |

[0000068505-21-000015:notes:101]
[same as prior period, unchanged from 0000068505-20-000028:notes:111]

[0000068505-21-000015:notes:102]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of April 3, 2021, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £125 million of net investment hedges in certain British pound functional subsidiaries.
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-21-000015:notes:103]
[same as prior period, unchanged from 0000068505-20-000028:notes:114]

[0000068505-21-000015:notes:104]
[same as prior period, unchanged from 0000068505-20-000028:notes:115]

[0000068505-21-000015:notes:105]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Net earnings before income taxes | $ | 289 |  |  | $ | 224 |  |  |  |  |  |
| Income tax expense | 44 |  |  | 26 |  |  |  |  |  |
| Effective tax rate | 15 | % |  | 12 | % |  |  |  |  |

[0000068505-21-000015:notes:106]
During the three months ended April 3, 2021, the Company recorded $44 million of net tax expense, resulting in an effective tax rate of 15%. During the three months ended March 28, 2020, the Company recorded $26 million of net tax expense, resulting in an effective tax rate of 12%. The effective tax rates for each of the three months ended April 3, 2021 and March 28, 2020 was different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset primarily by tax benefits related to share-based compensation. The effective tax rate for the three months ended April 3, 2021 of 15% is higher than the effective tax rate for the three months ended March 28, 2020 of 12%, primarily due to lower tax benefits on share-based compensation.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-21-000015:notes:107]
[same as prior period, unchanged from 0000068505-20-000028:notes:118]

[0000068505-21-000015:notes:108]
[same as prior period, unchanged from 0000068505-20-000028:notes:119]

[0000068505-21-000015:notes:109]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 29 |  |  | 36 |  |  | 5 |  |  | 7 |  |  | — |  |  | 1 |  |
| Expected return on plan assets | (59) |  |  | (56) |  |  | (25) |  |  | (22) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 17 |  |  | 14 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |  | (4) |  |
| Net periodic pension benefits | $ | (13) |  |  | $ | (6) |  |  | $ | (16) |  |  | $ | (10) |  |  | $ | (3) |  |  | $ | (5) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-21-000015:notes:110]
[same as prior period, unchanged from 0000068505-20-000028:notes:122]

[0000068505-21-000015:notes:111]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 4 |  |  | $ | 5 |  |  |  |  |  |
| Selling, general and administrative expenses | 17 |  |  | 21 |  |  |  |  |  |
| Research and development expenditures | 8 |  |  | 12 |  |  |  |  |  |
| Share-based compensation expense included in Operating earnings | 29 |  |  | 38 |  |  |  |  |  |
| Tax benefit | (6) |  |  | (7) |  |  |  |  |  |
| Share-based compensation expense, net of tax | $ | 23 |  |  | $ | 31 |  |  |  |  |  |
| Decrease in basic earnings per share | $ | (0.14) |  |  | $ | (0.18) |  |  |  |  |  |
| Decrease in diluted earnings per share | $ | (0.13) |  |  | $ | (0.17) |  |  |  |  |  |

[0000068505-21-000015:notes:112]
During the three months ended April 3, 2021, the Company granted 0.3 million restricted stock units (RSUs), 0.07 million performance stock units (PSUs) and 0.05 million market stock units (MSUs) with an aggregate grant-date fair value of $50 million, $15 million, and $10 million, respectively, and 0.1 million stock options and 0.2 million performance options (POs) with an aggregate grant-date fair value of $6 million and $10 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-21-000015:notes:113]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 3, 2021 and December 31, 2020 were as follows:

[0000068505-21-000015:notes:114]
| April 3, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |
| Common stock | 24 |  |  | — |  |  |  |  | 24 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 12 |  |  |  |  | $ | 12 |  |

[0000068505-21-000015:notes:115]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 14 |  |  |  |  | $ | 14 |  |
| Common stock | 19 |  |  | — |  |  |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  |  |  | $ | 8 |  |

[0000068505-21-000015:notes:116]
The Company had no Level 3 holdings as of April 3, 2021 or December 31, 2020.

[0000068505-21-000015:notes:117]
At April 3, 2021 and December 31, 2020, the Company had $463 million and $448 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-21-000015:notes:118]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at April 3, 2021 and December 31, 2020 was $5.6 billion and $5.8 billion (Level 2), respectively.

[0000068505-21-000015:notes:119]
[same as prior period, unchanged from 0000068505-20-000028:notes:136]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-21-000015:notes:120]
[same as prior period, unchanged from 0000068505-20-000028:notes:137]

[0000068505-21-000015:notes:121]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended April 3, 2021 and March 28, 2020:

[0000068505-21-000015:notes:122]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Contract-specific discounting facility | $ | 71 |  |  | $ | 44 |  |  |  |  |  |
| Accounts receivable sales proceeds | — |  |  | 24 |  |  |  |  |  |
| Long-term receivables sales proceeds | 54 |  |  | 41 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 125 |  |  | $ | 109 |  |  |  |  |  |

[0000068505-21-000015:notes:123]
At April 3, 2021, the Company had retained servicing obligations for $927 million of long-term receivables, compared to $983 million at December 31, 2020. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $82 million at April 3, 2021, compared to $78 million at December 31, 2020.

[0000068505-21-000015:notes:124]
During the three months ended April 3, 2021, the Company utilized a contract-specific receivable discounting facility which began during the three months ended March 28, 2020, resulting in accounts receivable sales of $71 million. The net benefit to the Company's operating cash flow from the utilization of the receivable discounting facility for the three months ended April 3, 2021 was $71 million, when adjusted for amounts that were collected under the commercial contract with the customer within the period in the absence of utilizing the discounting facility. The proceeds of the Company's receivable sales are included in Operating activities within the Company's Condensed Consolidated Statements of Cash Flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-21-000015:notes:125]
Commitments and Contingencies
Legal Matters

[0000068505-21-000015:notes:126]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. The royalty rate is yet to be determined, and will be set by the Court absent agreement of the parties.

[0000068505-21-000015:notes:127]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest, although the precise amount of interest owed to the Company by Hytera is still to be determined by the Court. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award.
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-21-000015:notes:128]
[same as prior period, unchanged from 0000068505-20-000028:notes:142]

[0000068505-21-000015:notes:129]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Products and Systems Integration | $ | 1,015 |  |  | $ | 993 |  |  |  |  |  |
| Software and Services | 758 |  |  | 662 |  |  |  |  |  |
|  | $ | 1,773 |  |  | $ | 1,655 |  |  |  |  |  |

[0000068505-21-000015:notes:130]
[same as prior period, unchanged from 0000068505-20-000028:notes:144]

[0000068505-21-000015:notes:131]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  | March 28, 2020 |  |  |  |  |
| Products and Systems Integration | $ | 77 |  |  | $ | 92 |  |  |  |  |  |
| Software and Services | 221 |  |  | 167 |  |  |  |  |  |
| Operating earnings | 298 |  |  | 259 |  |  |  |  |  |
| Total other expense | (9) |  |  | (35) |  |  |  |  |  |
| Earnings before income taxes | $ | 289 |  |  | $ | 224 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-21-000015:notes:132]
Reorganization of Business
2021 Charges

[0000068505-21-000015:notes:133]
During the three months ended April 3, 2021, the Company recorded net reorganization of business charges of $16 million including $14 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $18 million related to employee separation, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-21-000015:notes:134]
[same as prior period, unchanged from 0000068505-20-000028:notes:150]

[0000068505-21-000015:notes:135]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  |  |
| Products and Systems Integration | $ | 12 |  |  |  |
| Software and Services | 4 |  |  |  |
|  | $ | 16 |  |  |  |

[0000068505-21-000015:notes:136]
Reorganization of Businesses Accruals

[0000068505-21-000015:notes:137]
| January 1, 2021 |  | Additional Charges |  | Adjustments |  | Amount Used |  | April 3, 2021 |
| $ | 79 |  |  | $ | 18 |  |  | $ | (2) |  |  | $ | (37) |  |  | $ | 58 |  |

[0000068505-21-000015:notes:138]
[same as prior period, unchanged from 0000068505-20-000028:notes:154]

[0000068505-21-000015:notes:139]
At January 1, 2021, the Company had an accrual of $79 million for employee separation costs. The 2021 additional charges of $18 million represent severance costs for approximately 200 employees. The adjustment of $2 million reflects reversals for accruals no longer needed. The $37 million used reflects cash payments to severed employees. The remaining accrual of $58 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at April 3, 2021, is expected to be paid, primarily within one year, to approximately 1,000 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-21-000015:notes:140]
[same as prior period, unchanged from 0000068505-20-000028:notes:147]

[0000068505-21-000015:notes:141]
During the three months ended March 28, 2020, the Company recorded net reorganization of business charges of $18 million including $12 million of charges in Other charges and $6 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $22 million related to employee separation, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-21-000015:notes:142]
|  | Three Months Ended |  |  |
|  | March 28, 2020 |  |  |
| Products and Systems Integration | $ | 14 |  |  |  |
| Software and Services | 4 |  |  |  |
|  | $ | 18 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-21-000015:notes:143]
Intangible Assets and Goodwill
On August 28, 2020, the Company acquired Callyo, a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing Command Center Software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The Company recognized $38 million of goodwill, $31 million of identifiable intangible assets, and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $27 million of customer relationships and $4 million of developed technology that will be amortized over a period of fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-21-000015:notes:144]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in Video Security and Analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $41 million of goodwill, $30 million of identifiable intangible assets, and $36 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the

[0000068505-21-000015:notes:145]
Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000015:notes:146]
On June 16, 2020, the Company acquired IndigoVision for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Analytics technology, providing enhanced geographical reach across a wider customer base. The Company recognized $14 million of goodwill, $22 million of identifiable intangible assets, and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000015:notes:147]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The Company recognized $23 million of goodwill, $10 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $8 million of customer relationships and $2 million of developed technology that will be amortized over a period of twelve years and three years, respectively. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-21-000015:notes:148]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The Company recognized $28 million of goodwill, $7 million of intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-21-000015:notes:149]
[same as prior period, unchanged from 0000068505-20-000028:notes:169]

[0000068505-21-000015:notes:150]
[same as prior period, unchanged from 0000068505-20-000028:notes:170]

[0000068505-21-000015:notes:151]
|  | April 3, 2021 |  | December 31, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 766 |  |  | $ | 229 |  |  | $ | 766 |  |  | $ | 210 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,350 |  |  | 734 |  |  | 1,335 |  |  | 685 |  |
| Other intangibles | 79 |  |  | 52 |  |  | 78 |  |  | 50 |  |
|  | $ | 2,197 |  |  | $ | 1,017 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-21-000015:notes:152]
Amortization expense on intangible assets was $58 million for the three months ended April 3, 2021. Amortization expense on intangible assets was $53 million for the three months ended March 28, 2020. As of April 3, 2021, annual amortization expense is estimated to be $209 million in 2021, $206 million 2022, $108 million in 2023, $83 million in 2024, $73 million in 2025, and $69 million in 2026.

[0000068505-21-000015:notes:153]
[same as prior period, unchanged from 0000068505-20-000028:notes:173]

[0000068505-21-000015:notes:154]
|  | April 3, 2021 |  | December 31, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 694 |  |  | $ | 142 |  |  | $ | 692 |  |  | $ | 129 |  |
| Software and Services | 1,503 |  |  | 875 |  |  | 1,489 |  |  | 818 |  |
|  | $ | 2,197 |  |  | $ | 1,017 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-21-000015:notes:155]
[same as prior period, unchanged from 0000068505-20-000028:notes:175]

[0000068505-21-000015:notes:156]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2021 to April 3, 2021:

[0000068505-21-000015:notes:157]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2021 | $ | 1,019 |  |  | $ | 1,200 |  |  | $ | 2,219 |  |
| Purchase accounting adjustments | (1) |  |  | (1) |  |  | (2) |  |
| Foreign currency | — |  |  | 4 |  |  | 4 |  |
| Balance as of April 3, 2021 | $ | 1,018 |  |  | $ | 1,203 |  |  | $ | 2,221 |  |
