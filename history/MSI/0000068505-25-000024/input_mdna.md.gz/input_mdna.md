# MSI MD&A — 0000068505-25-000024


## mdna

[0000068505-25-000024:mdna:1]
[same as prior period, unchanged from 0000068505-24-000034:mdna:1]

[0000068505-25-000024:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three months ended March 29, 2025 and March 30, 2024, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2024 (the "Form 10-K").

[0000068505-25-000024:mdna:3]
[same as prior period, unchanged from 0000068505-24-000034:mdna:3]

[0000068505-25-000024:mdna:4]
[same as prior period, unchanged from 0000068505-24-000034:mdna:4]

[0000068505-25-000024:mdna:5]
[same as prior period, unchanged from 0000068505-24-000034:mdna:5]

[0000068505-25-000024:mdna:6]
[same as prior period, unchanged from 0000068505-24-000034:mdna:6]

[0000068505-25-000024:mdna:7]
[same as prior period, unchanged from 0000068505-24-000034:mdna:7]

[0000068505-25-000024:mdna:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.

[0000068505-25-000024:mdna:9]
[same as prior period, unchanged from 0000068505-24-000034:mdna:9]

[0000068505-25-000024:mdna:10]
26

[0000068505-25-000024:mdna:11]
First Quarter Financial Results

[0000068505-25-000024:mdna:12]
•Net sales were $2.5 billion in the first quarter of 2025 compared to $2.4 billion in the first quarter of 2024.

[0000068505-25-000024:mdna:13]
•Operating earnings were $582 million in the first quarter of 2025 compared to $519 million in the first quarter of 2024.

[0000068505-25-000024:mdna:14]
•Net earnings attributable to Motorola Solutions, Inc. was $430 million, or $2.53 per diluted common share, in the first quarter of 2025, compared to a net loss of $39 million, or $(0.23) per diluted common share, in the first quarter of 2024.

[0000068505-25-000024:mdna:15]
•Operating cash flow increased $128 million to $510 million in the first quarter of 2025 compared to $382 million in the first quarter of 2024.

[0000068505-25-000024:mdna:16]
•We repurchased $325 million of common stock and paid $182 million in dividends in the first quarter of 2025.

[0000068505-25-000024:mdna:17]
[same as prior period, unchanged from 0000068505-24-000034:mdna:16]

[0000068505-25-000024:mdna:18]
Macroeconomic Environment Update

[0000068505-25-000024:mdna:19]
Beginning in February 2025, the United States implemented significant global tariffs on imports, contributing to a global trade landscape subject to changing import/export regulations, tariffs, trade barriers and trade disputes. As a result, we see growing volatility and uncertainty around the global supply chain.

[0000068505-25-000024:mdna:20]
We engage with global suppliers across a diverse network of locations around the world. We continue to work with our global supply base to mitigate our exposure to the risks to global reciprocal (and sectoral) tariffs that have developed, and which may continue to develop, in order to ensure supply continues at levels in order to meet our current customer demand. As a result of the dynamic environment, we expect increased costs on materials and components in 2025, which we currently expect to substantially mitigate.

[0000068505-25-000024:mdna:21]
U.K. Home Office Update

[0000068505-25-000024:mdna:22]
Beginning August 1, 2023, the United Kingdom's Competition and Markets Authority ("CMA") imposed a legal order which implemented a prospective price control ("the Charge Control") on Airwave, our private mobile radio communications network that provides mission-critical voice and data communications to emergency services and other agencies in Great Britain. Our appeal of the implementation of the Charge Control to the United Kingdom's Court of Appeal was unsuccessful and we have no further right to appeal to the United Kingdom Courts. Since August 1, 2023, revenue under the Airwave contract has been, and will continue to be, recognized in accordance with the Charge Control.

[0000068505-25-000024:mdna:23]
In 2024, we received a notice of contract extension (the “Deferred National Shutdown Notice”) from the Home Office of the United Kingdom (the "Home Office"). The Deferred National Shutdown Notice extends the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the Charge Control rates and is fully reflected in our reported backlog. In 2024, we filed proceedings with the U.K. High Court challenging the decision of the Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable U.K. procurement and public law. During the first quarter of 2025, these proceedings were discontinued.

[0000068505-25-000024:mdna:24]
On December 12, 2024, a proposed class representative filed a claim with the Competition Appeal Tribunal ("CAT") to bring collective proceedings against us, alleging that users of Airwave services during the period January 1, 2020 through July 31, 2023 suffered financial harm as a result of the pricing in effect during such time (the "Collective Proceeding"). The initial stage of the Collective Proceeding will involve potential "Certification" of the claim by the CAT, which we expect to be heard in September 2025.

[0000068505-25-000024:mdna:25]
[same as prior period, unchanged from 0000068505-24-000034:mdna:22]

[0000068505-25-000024:mdna:26]
| Segment | Technology | Acquisition | Description | Purchase Price | Date of Acquisition |
| Software and Services | Command Center | Theatro | Creator of AI and voice-powered communication and digital workflow software for frontline workers | $173 million and share-based compensation of $5 million | March 6, 2025 |
| Software and Services | Command Center | RapidDeploy | Provider of cloud-native 911 solutions. | $241 million and share-based compensation of $6 million | February 21, 2025 |
| Software and Services | Command Center | 3tc Software | Provider of control room software solutions. | $23 million and share-based compensation of $4 million | October 29, 2024 |
| Software and Services | Command Center | Noggin | Provider of cloud-based business continuity planning, operational resilience and critical event management software. | $91 million and share-based compensation of $19 million | July 1, 2024 |
| Software and Services | Video Security and Access Control | Unnamed vehicle location and management solutions business | Provider of vehicle location and management solutions. | $132 million and share-based compensation of $3 million | July 1, 2024 |
| Products and Systems Integration | Video Security and Access Control | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |

[0000068505-25-000024:mdna:27]
28

[0000068505-25-000024:mdna:28]
[same as prior period, unchanged from 0000068505-24-000034:mdna:25]

[0000068505-25-000024:mdna:29]
|  | Three Months Ended |  |  |
| (Dollars in millions, except per share amounts) | March 29, 2025 |  | % ofSales* |  | March 30, 2024 |  | % ofSales* |  |  |  |  |  |  |  |  |
| Net sales from products | $ | 1,448 |  |  |  |  | $ | 1,405 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales from services | 1,080 |  |  |  |  | 984 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 2,528 |  |  |  |  | 2,389 |  |  |  |  |  |  |  |  |  |  |  |
| Costs of products sales | 573 |  |  | 39.6 | % |  | 600 |  |  | 42.7 | % |  |  |  |  |  |  |  |  |
| Costs of services sales | 655 |  |  | 60.6 | % |  | 597 |  |  | 60.7 | % |  |  |  |  |  |  |  |  |
| Costs of sales | 1,228 |  |  |  |  | 1,197 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 1,300 |  |  | 51.4 | % |  | 1,192 |  |  | 49.9 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 436 |  |  | 17.2 | % |  | 397 |  |  | 16.6 | % |  |  |  |  |  |  |  |  |
| Research and development expenditures | 233 |  |  | 9.2 | % |  | 218 |  |  | 9.1 | % |  |  |  |  |  |  |  |  |
| Other charges | 49 |  |  | 1.9 | % |  | 58 |  |  | 2.4 | % |  |  |  |  |  |  |  |  |
| Operating earnings | 582 |  |  | 23.0 | % |  | 519 |  |  | 21.7 | % |  |  |  |  |  |  |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (51) |  |  | (2.0) | % |  | (44) |  |  | (1.8) | % |  |  |  |  |  |  |  |  |
| Other, net | 16 |  |  | 0.6 | % |  | (565) |  |  | (23.7) | % |  |  |  |  |  |  |  |  |
| Total other expense | (35) |  |  | (1.4) | % |  | (609) |  |  | (25.5) | % |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations before income taxes | 547 |  |  | 21.6 | % |  | (90) |  |  | (3.8) | % |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) | 115 |  |  | 4.5 | % |  | (52) |  |  | (2.2) | % |  |  |  |  |  |  |  |  |
| Net earnings (loss) | 432 |  |  | 17.1 | % |  | (38) |  |  | (1.6) | % |  |  |  |  |  |  |  |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 0.1 | % |  | 1 |  |  | — | % |  |  |  |  |  |  |  |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 430 |  |  | 17.0 | % |  | $ | (39) |  |  | (1.6) | % |  |  |  |  |  |  |  |  |
| Earnings (loss) per diluted common share | $ | 2.53 |  |  |  |  | $ | (0.23) |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-25-000024:mdna:30]
[same as prior period, unchanged from 0000068505-24-000034:mdna:27]

[0000068505-25-000024:mdna:31]
29

[0000068505-25-000024:mdna:32]
Results of Operations—Three months ended March 29, 2025 compared to three months ended March 30, 2024

[0000068505-25-000024:mdna:33]
The results of operations for the first quarter of 2025 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-25-000024:mdna:34]
[same as prior period, unchanged from 0000068505-24-000034:mdna:31]

[0000068505-25-000024:mdna:35]
[same as prior period, unchanged from 0000068505-24-000034:mdna:32]

[0000068505-25-000024:mdna:36]
[same as prior period, unchanged from 0000068505-24-000034:mdna:33]

[0000068505-25-000024:mdna:37]
[same as prior period, unchanged from 0000068505-24-000034:mdna:34]

[0000068505-25-000024:mdna:38]
[same as prior period, unchanged from 0000068505-24-000034:mdna:35]

[0000068505-25-000024:mdna:39]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |  | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |
| International | 368 |  |  | 308 |  |  | 676 |  |  | 408 |  |  | 288 |  |  | 696 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |  | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |
| Video | 231 |  |  | 210 |  |  | 441 |  |  | 235 |  |  | 163 |  |  | 398 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 169 |  |  | 169 |  |
| Total | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Operating earnings | $ | 352 |  |  | $ | 230 |  |  | $ | 582 |  |  | $ | 310 |  |  | $ | 209 |  |  | $ | 519 |  |
| Operating margins | 22.8 | % |  | 23.4 | % |  | 23.0 | % |  | 20.8 | % |  | 23.2 | % |  | 21.7 | % |

[0000068505-25-000024:mdna:40]
[same as prior period, unchanged from 0000068505-24-000034:mdna:37]

[0000068505-25-000024:mdna:41]
The Products and Systems Integration segment’s net sales represented 61% of our net sales in the first quarter of 2025 and 62% in the first quarter of 2024. The Software and Services segment’s net sales represented 39% of our net sales in the first quarter of 2025 and 38% in the first quarter of 2024.

[0000068505-25-000024:mdna:42]
Net sales increased $139 million, or 6%, in the first quarter of 2025 compared to the first quarter of 2024. The $83 million, or 9% increase in net sales within the Software and Services segment was driven by an increase of 10% in the North America region and an increase of 7% in the International region. The $56 million, or 4%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 9% in the North America region, partially offset by a decrease of 10% in the International region. Net sales includes:

[0000068505-25-000024:mdna:43]
•an increase in the Software and Services segment, inclusive of $32 million of revenue from acquisitions, driven by an increase in Video, LMR services and Command Center;

[0000068505-25-000024:mdna:44]
•an increase in the Products and Systems Integration segment, driven by an increase in LMR, partially offset by a decrease in Video; and

[0000068505-25-000024:mdna:45]
•inclusive of $25 million from unfavorable currency rates.

[0000068505-25-000024:mdna:46]
[same as prior period, unchanged from 0000068505-24-000034:mdna:43]

[0000068505-25-000024:mdna:47]
•a 9% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; partially offset by

[0000068505-25-000024:mdna:48]
•a 3% decrease in the International region, inclusive of revenue from acquisitions, driven by a decrease in LMR partially offset by an increase in Command Center and Video.

[0000068505-25-000024:mdna:49]
[same as prior period, unchanged from 0000068505-24-000034:mdna:46]

[0000068505-25-000024:mdna:50]
The 4% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-25-000024:mdna:51]
•$60 million, or 5%, growth in LMR, driven by the North America region, partially offset by the International region; partially offset by

[0000068505-25-000024:mdna:52]
•$4 million, or 2%, decrease in Video, driven by the International and North America regions; and

[0000068505-25-000024:mdna:53]
•inclusive of $14 million from unfavorable currency rates.

[0000068505-25-000024:mdna:54]
[same as prior period, unchanged from 0000068505-24-000034:mdna:51]

[0000068505-25-000024:mdna:55]
The 9% increase in the Software and Services segment was driven by the following:

[0000068505-25-000024:mdna:56]
•$47 million, or 29%, growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-25-000024:mdna:57]
•$19 million, or 3%, growth in LMR services, driven by the North America and International regions;

[0000068505-25-000024:mdna:58]
•$17 million, or 10%, growth in Command Center, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-25-000024:mdna:59]
•inclusive of $11 million from unfavorable currency rates.

[0000068505-25-000024:mdna:60]
[same as prior period, unchanged from 0000068505-24-000034:mdna:57]

[0000068505-25-000024:mdna:61]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 852 |  |  | $ | 774 |  |  | 10 | % |
| Gross margin from Software and Services | 448 |  |  | 418 |  |  | 7 | % |
| Gross margin | $ | 1,300 |  |  | $ | 1,192 |  |  | 9 | % |

[0000068505-25-000024:mdna:62]
Gross margin was 51.4% of net sales in the first quarter of 2025 compared to 49.9% in the first quarter of 2024. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000024:mdna:63]
•a 3.2% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, primarily driven by higher sales, favorable mix and lower direct material costs; partially offset by

[0000068505-25-000024:mdna:64]
•a 0.9% decrease in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by acquisitions and unfavorable mix.

[0000068505-25-000024:mdna:65]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-25-000024:mdna:66]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 341 |  |  | $ | 311 |  |  | 10 | % |
| SG&A expenses from Software and Services | 95 |  |  | 86 |  |  | 10 | % |
| SG&A expenses | $ | 436 |  |  | $ | 397 |  |  | 10 | % |

[0000068505-25-000024:mdna:67]
SG&A expenses increased 10% in the first quarter of 2025 compared to the first quarter of 2024 primarily driven by:

[0000068505-25-000024:mdna:68]
•a $30 million, or 10%, increase in Products and Systems Integration SG&A expenses primarily due to higher expenses related to legal matters, including Hytera related legal expenses, and higher employee incentive costs, including share based compensation; and

[0000068505-25-000024:mdna:69]
•a $9 million, or 10%, increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses and higher employee incentive costs.

[0000068505-25-000024:mdna:70]
SG&A expenses were 17.2% of net sales in the first quarter of 2025 compared to 16.6% of net sales in the first quarter of 2024.

[0000068505-25-000024:mdna:71]
Research and Development ("R&D") Expenditures

[0000068505-25-000024:mdna:72]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 142 |  |  | $ | 137 |  |  | 4 | % |
| R&D expenditures from Software and Services | 91 |  |  | 81 |  |  | 12 | % |
| R&D expenditures | $ | 233 |  |  | $ | 218 |  |  | 7 | % |

[0000068505-25-000024:mdna:73]
R&D expenditures increased 7% in the first quarter of 2025 compared to the first quarter of 2024 primarily driven by:

[0000068505-25-000024:mdna:74]
•a $5 million, or 4%, increase in Products and Systems Integration R&D expenditures primarily due to higher employee incentive costs; and

[0000068505-25-000024:mdna:75]
•a $10 million, or 12%, increase in Software and Services R&D expenditures primarily due to higher employee incentive costs, including share based compensation, and higher expenses associated with acquired businesses.

[0000068505-25-000024:mdna:76]
R&D expenditures were 9.2% of net sales in each of the first quarter of 2025 compared to 9.1% of net sales in the first quarter of 2024.

[0000068505-25-000024:mdna:77]
[same as prior period, unchanged from 0000068505-24-000034:mdna:68]

[0000068505-25-000024:mdna:78]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |
| Other charges from Products and Systems Integration | $ | 17 |  |  | $ | 16 |  |
| Other charges from Software and Services | 32 |  |  | 42 |  |
| Other charges | $ | 49 |  |  | $ | 58 |  |

[0000068505-25-000024:mdna:79]
Other charges decreased by $9 million in the first quarter of 2025 compared to the first quarter of 2024. The decrease was primarily driven by:

[0000068505-25-000024:mdna:80]
•$10 million of gains on the Hytera litigation for the amounts recovered through legal proceedings due to theft of our trade secrets in the first quarter of 2025 that did not occur in the first quarter of 2024; and

[0000068505-25-000024:mdna:81]
•$3 million of operating lease asset impairments in the first quarter of 2024 that did not occur in the first quarter of 2025; partially offset by

[0000068505-25-000024:mdna:82]
•$12 million of reorganization of business expenses in the first quarter of 2025 compared to $7 million of reorganization of business expenses in the first quarter of 2024.

[0000068505-25-000024:mdna:83]
[same as prior period, unchanged from 0000068505-24-000034:mdna:71]

[0000068505-25-000024:mdna:84]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |
| Operating earnings from Products and Systems Integration | $ | 352 |  |  | $ | 310 |  |
| Operating earnings from Software and Services | 230 |  |  | 209 |  |
| Operating earnings | $ | 582 |  |  | $ | 519 |  |

[0000068505-25-000024:mdna:85]
Operating earnings increased $63 million, or 12%, in the first quarter of 2025 compared to the first quarter of 2024. The increase in Operating earnings was due to:

[0000068505-25-000024:mdna:86]
•a $42 million increase in the Products and Systems Integration segment, primarily driven by higher sales, favorable change in year-over-year mix and lower direct material costs, partially offset by higher expenses related to legal matters, including Hytera related expenses, and higher employee incentive costs, including share-based compensation; and

[0000068505-25-000024:mdna:87]
•a $21 million increase in the Software and Services segment, primarily driven by higher sales, partially offset by higher expenses associated with acquired businesses and higher employee incentive costs.

[0000068505-25-000024:mdna:88]
[same as prior period, unchanged from 0000068505-24-000034:mdna:28]

[0000068505-25-000024:mdna:89]
[same as prior period, unchanged from 0000068505-24-000034:mdna:76]

[0000068505-25-000024:mdna:90]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |
| Interest expense, net | $ | (51) |  |  | $ | (44) |  |

[0000068505-25-000024:mdna:91]
The $7 million increase in Interest expense, net in the first quarter of 2025 compared to the first quarter of 2024 was primarily driven by higher interest rates on outstanding debt.

[0000068505-25-000024:mdna:92]
[same as prior period, unchanged from 0000068505-24-000034:mdna:79]

[0000068505-25-000024:mdna:93]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |
| Other, net | $ | 16 |  |  | $ | (565) |  |

[0000068505-25-000024:mdna:94]
The $581 million increase in Other, net in the first quarter of 2025 compared to the first quarter of 2024 was primarily driven by:

[0000068505-25-000024:mdna:95]
•$585 million loss from the extinguishment of 1.75% senior convertible notes issued to Silver Lake Partners ("Silver Lake Convertible Debt") in the first quarter of 2024; and

[0000068505-25-000024:mdna:96]
•$13 million gain on derivatives in the first quarter of 2025 compared to a $10 million loss on derivatives in the first quarter of 2024; partially offset by

[0000068505-25-000024:mdna:97]
•$20 million of foreign currency losses in the first quarter of 2025 compared to $1 million of foreign currency gains in the first quarter of 2024.

[0000068505-25-000024:mdna:98]
[same as prior period, unchanged from 0000068505-24-000034:mdna:87]

[0000068505-25-000024:mdna:99]
|  | Three Months Ended |
| (In millions) | March 29, 2025 |  | March 30, 2024 |
| Income tax expense (benefit) | $ | 115 |  |  | $ | (52) |  |

[0000068505-25-000024:mdna:100]
Income tax expense increased by $167 million in the first quarter of 2025 compared to the first quarter of 2024, resulting in an effective tax rate of 21%. Our effective tax rate for the three months ended March 29, 2025 of 21% was lower than the effective tax rate for the three months ended March 30, 2024 of 58%, primarily due to the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in 2024, partially offset by the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return.

[0000068505-25-000024:mdna:101]
[same as prior period, unchanged from 0000068505-24-000034:mdna:151]

[0000068505-25-000024:mdna:102]
During the first quarter of 2025, we recorded net reorganization of business charges of $17 million, consisting of $12 million of charges in Other charges and $5 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $19 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals that are no longer needed.

[0000068505-25-000024:mdna:103]
During the first quarter of 2024, we recorded net reorganization of business charges of $10 million, including $7 million of charges recorded in Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000024:mdna:104]
[same as prior period, unchanged from 0000068505-24-000034:mdna:156]

[0000068505-25-000024:mdna:105]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Products and Systems Integration | $ | 12 |  |  | $ | 8 |  |  |  |  |  |
| Software and Services | 5 |  |  | 2 |  |  |  |  |  |
|  | $ | 17 |  |  | $ | 10 |  |  |  |  |  |

[0000068505-25-000024:mdna:106]
Cash payments for employee severance in connection with the reorganization of business plans were $14 million in the first quarter of 2025 and $9 million in the first quarter of 2024. The reorganization of business accrual at March 29, 2025 was $30 million related to employee separation costs that are expected to be paid primarily within one year.

[0000068505-25-000024:mdna:107]
At January 1, 2025, we had an accrual of $1 million for exit costs related to our exit of the ESN contract with the U.K. Home Office. The $1 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at March 29, 2025, and are expected to be paid within one year.

[0000068505-25-000024:mdna:108]
[same as prior period, unchanged from 0000068505-24-000034:mdna:160]

[0000068505-25-000024:mdna:109]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 510 |  |  | $ | 382 |  |
| Investing activities | (477) |  |  | (47) |  |
| Financing activities | (597) |  |  | (512) |  |
| Effect of exchange rates on cash and cash equivalents | 26 |  |  | (16) |  |
| Decrease in cash and cash equivalents | $ | (538) |  |  | $ | (193) |  |

[0000068505-25-000024:mdna:110]
[same as prior period, unchanged from 0000068505-24-000034:mdna:162]

[0000068505-25-000024:mdna:111]
At March 29, 2025, $1.3 billion of the $1.6 billion cash and cash equivalents balance was held in the U.S. and $302 million was held in other countries.

[0000068505-25-000024:mdna:112]
[same as prior period, unchanged from 0000068505-24-000034:mdna:164]

[0000068505-25-000024:mdna:113]
The increase in cash flows provided by operating activities from the first quarter of 2024 to the first quarter of 2025 was driven primarily by higher earnings and improved working capital.

[0000068505-25-000024:mdna:114]
[same as prior period, unchanged from 0000068505-24-000034:mdna:166]

[0000068505-25-000024:mdna:115]
The increase in cash flows used for investing activities in the first quarter of 2025 compared to the first quarter of 2024 was primarily due to an increase in cash used for acquisitions and investments.

[0000068505-25-000024:mdna:116]
[same as prior period, unchanged from 0000068505-24-000034:mdna:168]

[0000068505-25-000024:mdna:117]
The increase in cash flows used for financing activities in the first quarter of 2025 compared to the first quarter of 2024 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-25-000024:mdna:118]
•$1.3 billion decrease in net proceeds from the issuance of debt in the first quarter of 2024 driven the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034 that did not occur in first quarter of 2025;

[0000068505-25-000024:mdna:119]
•$286 million increase in share repurchases in the first quarter of 2025 compared to the first quarter of 2024;

[0000068505-25-000024:mdna:120]
•$85 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first quarter of 2025 compared to the first quarter of 2024; and

[0000068505-25-000024:mdna:121]
•$19 million increase in the payment of dividends in the first quarter of 2025 compared to the first quarter of 2024; partially offset by

[0000068505-25-000024:mdna:122]
•$1.6 billion decrease in repayment of debt driven by the repurchase of Silver Lake Convertible Debt in the first quarter of 2024.

[0000068505-25-000024:mdna:123]
[same as prior period, unchanged from 0000068505-24-000034:mdna:175]

[0000068505-25-000024:mdna:124]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended March 29, 2025 and March 30, 2024:

[0000068505-25-000024:mdna:125]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Long-term receivables sales proceeds | $ | 24 |  |  | $ | 10 |  |  |  |  |  |

[0000068505-25-000024:mdna:126]
[same as prior period, unchanged from 0000068505-24-000034:mdna:178]

[0000068505-25-000024:mdna:127]
We had outstanding debt of $6.0 billion, of which $322 million was current, at both March 29, 2025 and December 31, 2024.

[0000068505-25-000024:mdna:128]
As of March 29, 2025, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were classified within the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-25-000024:mdna:129]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of March 29, 2025.

[0000068505-25-000024:mdna:130]
Subsequent to the quarter end, on April 25, 2025, we entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). The 2025 Motorola Solutions Credit Agreement replaces the 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement.

[0000068505-25-000024:mdna:131]
We have an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of March 29, 2025 we had no outstanding debt under the commercial paper program.

[0000068505-25-000024:mdna:132]
We have investment grade ratings on our senior unsecured long-term debt. We continue to believe that we will be able to maintain sufficient access to the capital markets in the next twelve months and the foreseeable future.

[0000068505-25-000024:mdna:133]
[same as prior period, unchanged from 0000068505-24-000034:mdna:187]

[0000068505-25-000024:mdna:134]
During the three months ended March 29, 2025, we repurchased approximately 0.7 million shares at an average price of $437.17 per share for an aggregate amount of $325 million, excluding transaction costs and excise tax. As of March 29, 2025, we had used approximately $16.1 billion of the share repurchase authority to repurchase shares, leaving $1.9 billion of authority available for future repurchases.

[0000068505-25-000024:mdna:135]
[same as prior period, unchanged from 0000068505-24-000034:mdna:189]

[0000068505-25-000024:mdna:136]
During the first quarter of 2025 we paid $182 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $182 million in cash dividends to holders of our common stock.

[0000068505-25-000024:mdna:137]
[same as prior period, unchanged from 0000068505-24-000034:mdna:191]

[0000068505-25-000024:mdna:138]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2025 Motorola Solutions Credit Agreement.

[0000068505-25-000024:mdna:139]
[same as prior period, unchanged from 0000068505-24-000034:mdna:193]

[0000068505-25-000024:mdna:140]
[same as prior period, unchanged from 0000068505-24-000034:mdna:194]

[0000068505-25-000024:mdna:141]
We had outstanding commitments to provide long-term financing to third parties totaling $150 million at March 29, 2025, compared to $105 million at December 31, 2024.

[0000068505-25-000024:mdna:142]
[same as prior period, unchanged from 0000068505-24-000034:mdna:196]

[0000068505-25-000024:mdna:143]
[same as prior period, unchanged from 0000068505-24-000034:mdna:197]
