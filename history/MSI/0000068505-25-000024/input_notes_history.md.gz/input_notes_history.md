# MSI note change history — 0000068505-24-000034 → 0000068505-25-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000068505-25-000024:note_history:1]
Hytera Civil Litigation
  (was, 2024-11-07, similarity 0.85):
[0000068505-24-000034:note_history:1]
Hytera Litigation

- changed (2025-05-01):
[0000068505-25-000024:note_history:2]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees. The Company continues to seek collection of the judgment through the ongoing legal process.
  (was, 2024-11-07, similarity 0.9995):
[0000068505-24-000034:note_history:2]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

- changed (2025-05-01):
[0000068505-25-000024:note_history:3]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera made de minimis quarterly royalty payments into the third-party escrow from October 2022 through November 2024; after which such de minimis royalty payments have been paid directly to the Company. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other Charges (Income) within the Consolidated Statement of Operations. On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million and that payment was recorded as a gain within Other charges (Income) within the Consolidated Statement of Operations.
  (was, 2024-11-07, similarity 0.7666):
[0000068505-24-000034:note_history:3]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through October 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

- changed (2025-05-01):
[0000068505-25-000024:note_history:4]
Following the February 14, 2020, verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. The issues of copyright recalculation and injunction are currently briefed and under consideration by the District Court.
  (was, 2024-11-07, similarity 0.9412):
[0000068505-24-000034:note_history:4]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case has been remanded to the District Court for further action per the Court of Appeals' decision.

- added (2025-05-01):
[0000068505-25-000024:note_history:5]
On January 2, 2025, Hytera filed a petition for Writ of certiorari with the Supreme Court of the United States. Hytera's petition was denied by the Supreme Court on February 24, 2025.

- changed (2025-05-01):
[0000068505-25-000024:note_history:6]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings from August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.
  (was, 2024-11-07, similarity 0.8952):
[0000068505-24-000034:note_history:6]
In 2024, the parties engaged in competing litigation in the District Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings on August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is now under consideration by the District Court.

- added (2025-05-01):
[0000068505-25-000024:note_history:7]
Hytera Criminal Litigation

- added (2025-05-01):
[0000068505-25-000024:note_history:8]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 6, 2025. Pursuant to the plea agreement reached between Hytera and the government, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000068505-25-000024:note_history:9]
Basis of Presentation
The condensed consolidated financial statements as of March 29, 2025 and for the three months ended March 29, 2025 and March 30, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2024-11-07, similarity 0.9317):
[0000068505-24-000034:note_history:9]
Basis of Presentation
The condensed consolidated financial statements as of September 28, 2024 and for the three and nine months ended September 28, 2024 and September 30, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2025-05-01):
[0000068505-25-000024:note_history:10]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three months ended March 29, 2025 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2024-11-07, similarity 0.9592):
[0000068505-24-000034:note_history:10]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three and nine months ended September 28, 2024 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2025-05-01):
[0000068505-25-000024:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.
  (was, 2024-11-07, similarity 0.9805):
[0000068505-24-000034:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.

- added (2025-05-01):
[0000068505-25-000024:note_history:12]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio of enterprise technologies, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services Segment.

- added (2025-05-01):
[0000068505-25-000024:note_history:13]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $241 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. This business is part of the Software and Services segment.

- changed (2025-05-01):
[0000068505-25-000024:note_history:14]
On October 29, 2024, the Company acquired 3tc Software ("3tc"), a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.
  (was, 2024-11-07, similarity 0.8156):
[0000068505-24-000034:note_history:14]
Subsequent to quarter end, on October 29, 2024, the Company acquired 3tc Software ("3tc"), a provider of control room software solutions for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the UK's public safety agencies. This business is part of the Software and Services segment.

- changed (2025-05-01):
[0000068505-25-000024:note_history:15]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and Systems Integration segment.
  (was, 2024-11-07, similarity 0.9978):
[0000068505-24-000034:note_history:15]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

- added (2025-05-01):
[0000068505-25-000024:note_history:16]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date", which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

- added (2025-05-01):
[0000068505-25-000024:note_history:17]
Recently Adopted Accounting Pronouncements
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The Company adopted ASU No. 2023-07 for the year ended December 31, 2024 and applied the required retrospective transition method. Refer to Note 13, "Segment Information" in this "Part 1 — Financial Information" of this Form 10-Q for the related disclosures.

- removed (2025-05-01):
[0000068505-24-000034:note_history:18]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is part of the Products and Systems Integration segment.

- removed (2025-05-01):
[0000068505-24-000034:note_history:19]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The ASU is effective for fiscal years beginning after December 15, 2023, and interim periods beginning in 2025, with early adoption permitted. The ASU will require the Company to disclose additional expense categories at the segment level including Cost of sales, Selling, general and administrative expenses, Research and development expenditures and Other charges once it adopts this ASU. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000068505-25-000024:note_history:20]
Debt and Credit Facilities
As of March 29, 2025, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.
  (was, 2024-11-07, similarity 0.9214):
[0000068505-24-000034:note_history:20]
As of September 28, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

- changed (2025-05-01):
[0000068505-25-000024:note_history:21]
As of March 29, 2025, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 29, 2025.
  (was, 2024-11-07, similarity 0.9795):
[0000068505-24-000034:note_history:21]
As of September 28, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 28, 2024.

- added (2025-05-01):
[0000068505-25-000024:note_history:22]
Subsequent to the quarter end, on April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). The 2025 Motorola Solutions Credit Agreement replaces the 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement.

- changed (2025-05-01):
[0000068505-25-000024:note_history:23]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 29, 2025 the Company had no outstanding debt under the commercial paper program.
  (was, 2024-11-07, similarity 0.9898):
[0000068505-24-000034:note_history:23]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 28, 2024 the Company had no outstanding debt under the commercial paper program.

- removed (2025-05-01):
[0000068505-24-000034:note_history:24]
Debt and Credit Facilities

- removed (2025-05-01):
[0000068505-24-000034:note_history:25]
|  | September 28, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | — |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 24 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 895 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 846 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 5,997 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (322) |  |  | (1,313) |  |
| Long-term debt | $ | 5,674 |  |  | $ | 4,705 |  |

- removed (2025-05-01):
[0000068505-24-000034:note_history:26]
During the three months ended September 28, 2024, the Company repaid the $313 million aggregate principal amount of the 4.0% senior notes due 2024.

- removed (2025-05-01):
[0000068505-24-000034:note_history:27]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the nine months ended September 28, 2024.

- removed (2025-05-01):
[0000068505-24-000034:note_history:28]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt in the first quarter of 2024.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2025-05-01):
[0000068505-24-000034:note_history:29]
|  | September 28, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | — |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 24 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 895 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 846 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 5,997 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (322) |  |  | (1,313) |  |
| Long-term debt | $ | 5,674 |  |  | $ | 4,705 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000068505-25-000024:note_history:30]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 29, 2025 and March 30, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2024-11-07, similarity 0.9143):
[0000068505-24-000034:note_history:30]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 28, 2024 and September 30, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2025-05-01):
[0000068505-25-000024:note_history:31]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |  | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |
| International | 368 |  |  | 308 |  |  | 676 |  |  | 408 |  |  | 288 |  |  | 696 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |  | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |
| Video | 231 |  |  | 210 |  |  | 441 |  |  | 235 |  |  | 163 |  |  | 398 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 169 |  |  | 169 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,016 |  |  | $ | 907 |  |  | 1,923 |  |  | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |
| Indirect | 530 |  |  | 75 |  |  | 605 |  |  | 630 |  |  | 77 |  |  | 707 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
  (was, 2024-11-07, similarity 0.9385):
[0000068505-24-000034:note_history:31]
|  | Three Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |  | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |
| International | 480 |  |  | 303 |  |  | 783 |  |  | 457 |  |  | 316 |  |  | 773 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |  | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |
| Video | 292 |  |  | 208 |  |  | 500 |  |  | 300 |  |  | 153 |  |  | 453 |  |
| Command Center | — |  |  | 202 |  |  | 202 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,108 |  |  | $ | 917 |  |  | 2,025 |  |  | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |
| Indirect | 676 |  |  | 89 |  |  | 765 |  |  | 672 |  |  | 85 |  |  | 757 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |

- removed (2025-05-01):
[0000068505-24-000034:note_history:32]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |  | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |
| International | 1,302 |  |  | 888 |  |  | 2,190 |  |  | 1,222 |  |  | 991 |  |  | 2,213 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |  | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |
| Video | 821 |  |  | 553 |  |  | 1,374 |  |  | 810 |  |  | 435 |  |  | 1,245 |  |
| Command Center | — |  |  | 581 |  |  | 581 |  |  | — |  |  | 535 |  |  | 535 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |  | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |
| Indirect | 1,964 |  |  | 256 |  |  | 2,220 |  |  | 1,893 |  |  | 248 |  |  | 2,141 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000068505-25-000024:note_history:33]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 29, 2025 and March 30, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2024-11-07, similarity 0.9143):
[0000068505-24-000034:note_history:33]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 28, 2024 and September 30, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2025-05-01):
[0000068505-25-000024:note_history:34]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |  | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |
| International | 368 |  |  | 308 |  |  | 676 |  |  | 408 |  |  | 288 |  |  | 696 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |  | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |
| Video | 231 |  |  | 210 |  |  | 441 |  |  | 235 |  |  | 163 |  |  | 398 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 169 |  |  | 169 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,016 |  |  | $ | 907 |  |  | 1,923 |  |  | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |
| Indirect | 530 |  |  | 75 |  |  | 605 |  |  | 630 |  |  | 77 |  |  | 707 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
  (was, 2024-11-07, similarity 0.9385):
[0000068505-24-000034:note_history:34]
|  | Three Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |  | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |
| International | 480 |  |  | 303 |  |  | 783 |  |  | 457 |  |  | 316 |  |  | 773 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |  | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |
| Video | 292 |  |  | 208 |  |  | 500 |  |  | 300 |  |  | 153 |  |  | 453 |  |
| Command Center | — |  |  | 202 |  |  | 202 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,108 |  |  | $ | 917 |  |  | 2,025 |  |  | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |
| Indirect | 676 |  |  | 89 |  |  | 765 |  |  | 672 |  |  | 85 |  |  | 757 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |

- changed (2025-05-01):
[0000068505-25-000024:note_history:35]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of March 29, 2025 was $8.9 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of March 29, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of March 29, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.
  (was, 2024-11-07, similarity 0.9885):
[0000068505-24-000034:note_history:35]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 28, 2024 was $9.1 billion. A total of $4.2 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 28, 2024, of which $2.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.9 billion was from Software and Services performance obligations that were not yet satisfied as of September 28, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- changed (2025-05-01):
[0000068505-25-000024:note_history:36]
| (In millions) | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 1,770 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,288 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 1,983 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 556 |  |  | 496 |  |  |  |  |  |
  (was, 2024-11-07, similarity 0.9772):
[0000068505-24-000034:note_history:36]
| (In millions) | September 28, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,848 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,301 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,942 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 480 |  |  | 424 |  |  |  |  |  |

- added (2025-05-01):
[0000068505-25-000024:note_history:37]
Revenue recognized during the three months ended March 29, 2025 which was previously included in Contract liabilities as of December 31, 2024 was $537 million, compared to $508 million of revenue recognized during the three months ended March 30, 2024 which was previously included in Contract liabilities as of December 31, 2023. Revenue of $9 million was reversed during the three months ended March 29, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $12 million of reversals for the three months ended March 30, 2024, primarily driven by changes in the estimates of progress on system contracts.

- changed (2025-05-01):
[0000068505-25-000024:note_history:38]
There were no material expected credit losses recorded on contract assets during each of the three months ended March 29, 2025 and March 30, 2024.
  (was, 2024-11-07, similarity 0.899):
[0000068505-24-000034:note_history:38]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 28, 2024 and September 30, 2023.

- changed (2025-05-01):
[0000068505-25-000024:note_history:39]
| (In millions) | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 129 |  |  | 141 |  |  |  |  |  |
  (was, 2024-11-07, similarity 0.9719):
[0000068505-24-000034:note_history:39]
| (In millions) | September 28, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 78 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 124 |  |  | 119 |  |  |  |  |  |

- added (2025-05-01):
[0000068505-25-000024:note_history:40]
Amortization of contract cost assets was $13 million for the three months ended March 29, 2025 and March 30, 2024.

- removed (2025-05-01):
[0000068505-24-000034:note_history:41]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |  | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |
| International | 1,302 |  |  | 888 |  |  | 2,190 |  |  | 1,222 |  |  | 991 |  |  | 2,213 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |  | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |
| Video | 821 |  |  | 553 |  |  | 1,374 |  |  | 810 |  |  | 435 |  |  | 1,245 |  |
| Command Center | — |  |  | 581 |  |  | 581 |  |  | — |  |  | 535 |  |  | 535 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |  | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |
| Indirect | 1,964 |  |  | 256 |  |  | 2,220 |  |  | 1,893 |  |  | 248 |  |  | 2,141 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |

- removed (2025-05-01):
[0000068505-24-000034:note_history:42]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first nine months of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.

- removed (2025-05-01):
[0000068505-24-000034:note_history:43]
Revenue recognized during the three months ended September 28, 2024 which was previously included in Contract liabilities as of June 29, 2024 was $572 million, compared to $475 million of revenue recognized during the three months ended September 30, 2023 which was previously included in Contract liabilities as of July 1, 2023. Revenue recognized during the nine months ended September 28, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $1.2 billion, compared to $1.1 billion recognized during the nine months ended September 30, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $6 million was recognized during the three months ended September 28, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. During the three months ended September 30, 2023, revenue adjustments driven by the changes in estimates of progress on system contracts were de minimis. Revenue of $11 million was reversed during the nine months ended September 28, 2024 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $18 million of reversals for the nine months ended September 30, 2023.

- removed (2025-05-01):
[0000068505-24-000034:note_history:44]
Amortization of contract cost assets was $13 million and $38 million for the three and nine months ended September 28, 2024, respectively, and $10 million and $35 million for the three and nine months ended September 30, 2023, respectively.
