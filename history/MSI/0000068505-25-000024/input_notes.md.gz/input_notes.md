# MSI notes — 0000068505-25-000024


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-25-000024:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of March 29, 2025 and for the three months ended March 29, 2025 and March 30, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-25-000024:notes:2]
[same as prior period, unchanged from 0000068505-24-000034:notes:2]

[0000068505-25-000024:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three months ended March 29, 2025 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-25-000024:notes:4]
[same as prior period, unchanged from 0000068505-24-000034:notes:4]

[0000068505-25-000024:notes:5]
[same as prior period, unchanged from 0000068505-24-000034:notes:5]

[0000068505-25-000024:notes:6]
[same as prior period, unchanged from 0000068505-24-000034:notes:6]

[0000068505-25-000024:notes:7]
[same as prior period, unchanged from 0000068505-24-000034:notes:7]

[0000068505-25-000024:notes:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.

[0000068505-25-000024:notes:9]
[same as prior period, unchanged from 0000068505-24-000034:notes:9]

[0000068505-25-000024:notes:10]
[same as prior period, unchanged from 0000068505-24-000034:notes:10]

[0000068505-25-000024:notes:11]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio of enterprise technologies, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services Segment.

[0000068505-25-000024:notes:12]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $241 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. This business is part of the Software and Services segment.

[0000068505-25-000024:notes:13]
On October 29, 2024, the Company acquired 3tc Software ("3tc"), a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.

[0000068505-25-000024:notes:14]
On July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

[0000068505-25-000024:notes:15]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

[0000068505-25-000024:notes:16]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and Systems Integration segment.

[0000068505-25-000024:notes:17]
[same as prior period, unchanged from 0000068505-24-000034:notes:16]

[0000068505-25-000024:notes:18]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date", which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-25-000024:notes:19]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.

[0000068505-25-000024:notes:20]
Recently Adopted Accounting Pronouncements
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The Company adopted ASU No. 2023-07 for the year ended December 31, 2024 and applied the required retrospective transition method. Refer to Note 13, "Segment Information" in this "Part 1 — Financial Information" of this Form 10-Q for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-25-000024:notes:21]
[same as prior period, unchanged from 0000068505-24-000034:notes:19]

[0000068505-25-000024:notes:22]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 29, 2025 and March 30, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-25-000024:notes:23]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |  | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |
| International | 368 |  |  | 308 |  |  | 676 |  |  | 408 |  |  | 288 |  |  | 696 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |  | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |
| Video | 231 |  |  | 210 |  |  | 441 |  |  | 235 |  |  | 163 |  |  | 398 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 169 |  |  | 169 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,016 |  |  | $ | 907 |  |  | 1,923 |  |  | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |
| Indirect | 530 |  |  | 75 |  |  | 605 |  |  | 630 |  |  | 77 |  |  | 707 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |

[0000068505-25-000024:notes:24]
[same as prior period, unchanged from 0000068505-24-000034:notes:23]

[0000068505-25-000024:notes:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of March 29, 2025 was $8.9 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of March 29, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of March 29, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-25-000024:notes:26]
[same as prior period, unchanged from 0000068505-24-000034:notes:27]

[0000068505-25-000024:notes:27]
| (In millions) | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 1,770 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,288 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 1,983 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 556 |  |  | 496 |  |  |  |  |  |

[0000068505-25-000024:notes:28]
[same as prior period, unchanged from 0000068505-24-000034:notes:26]

[0000068505-25-000024:notes:29]
Revenue recognized during the three months ended March 29, 2025 which was previously included in Contract liabilities as of December 31, 2024 was $537 million, compared to $508 million of revenue recognized during the three months ended March 30, 2024 which was previously included in Contract liabilities as of December 31, 2023. Revenue of $9 million was reversed during the three months ended March 29, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $12 million of reversals for the three months ended March 30, 2024, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-25-000024:notes:30]
There were no material expected credit losses recorded on contract assets during each of the three months ended March 29, 2025 and March 30, 2024.

[0000068505-25-000024:notes:31]
[same as prior period, unchanged from 0000068505-24-000034:notes:31]

[0000068505-25-000024:notes:32]
| (In millions) | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 129 |  |  | 141 |  |  |  |  |  |

[0000068505-25-000024:notes:33]
Amortization of contract cost assets was $13 million for the three months ended March 29, 2025 and March 30, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-25-000024:notes:34]
[same as prior period, unchanged from 0000068505-24-000034:notes:34]

[0000068505-25-000024:notes:35]
|  | Three Months Ended |  |  |
| (in millions) | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 35 |  |  | $ | 35 |  |  |  |  |  |
| Variable cost | 12 |  |  | 11 |  |  |  |  |  |
| Sublease income | (2) |  |  | (1) |  |  |  |  |  |
| Net lease expense from operating leases | $ | 45 |  |  | $ | 45 |  |  |  |  |  |

[0000068505-25-000024:notes:36]
[same as prior period, unchanged from 0000068505-24-000034:notes:36]

[0000068505-25-000024:notes:37]
| (in millions) |  | Statement Line Classification |  | March 29, 2025 |  | December 31, 2024 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 521 |  |  | $ | 529 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | 114 |  |  | 127 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | 412 |  |  | 427 |  |  |  |

[0000068505-25-000024:notes:38]
[same as prior period, unchanged from 0000068505-24-000034:notes:38]

[0000068505-25-000024:notes:39]
|  | Three Months Ended |  |  |
| (in millions) | March 29, 2025 |  | March 30, 2024 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 54 |  |  | $ | 38 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | 12 |  |  | 83 |  |  |  |

[0000068505-25-000024:notes:40]
|  | March 29, 2025 |  | December 31, 2024 |
| Weighted average remaining lease terms (years) | 5 |  | 5 |
| Weighted average discount rate: | 3.97 | % |  | 3.97 | % |

[0000068505-25-000024:notes:41]
[same as prior period, unchanged from 0000068505-24-000034:notes:42]

[0000068505-25-000024:notes:42]
|  | March 29, 2025 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2025 | $ | 97 |  |  |  |  |  |
| 2026 | 134 |  |  |  |  |  |
| 2027 | 114 |  |  |  |  |  |
| 2028 | 87 |  |  |  |  |  |
| 2029 | 65 |  |  |  |  |  |
| Thereafter | 85 |  |  |  |  |  |
| Total lease payments | 582 |  |  |  |  |  |
| Less: interest | 56 |  |  |  |  |  |
| Present value of lease liabilities | $ | 526 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-25-000024:notes:43]
[same as prior period, unchanged from 0000068505-24-000034:notes:44]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-25-000024:notes:44]
[same as prior period, unchanged from 0000068505-24-000034:notes:45]

[0000068505-25-000024:notes:45]
[same as prior period, unchanged from 0000068505-24-000034:notes:46]

[0000068505-25-000024:notes:46]
[same as prior period, unchanged from 0000068505-24-000034:notes:47]

[0000068505-25-000024:notes:47]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 37 |  |  | $ | 39 |  |  |  |  |  |
| Reorganization of business (Note 14) | 12 |  |  | 7 |  |  |  |  |  |
| Operating lease asset impairments | — |  |  | 3 |  |  |  |  |  |
| Acquisition-related transaction fees | 6 |  |  | 4 |  |  |  |  |  |
| Legal settlements | 4 |  |  | 6 |  |  |  |  |  |
| Gain on Hytera litigation | (10) |  |  | — |  |  |  |  |  |
| Other | — |  |  | (1) |  |  |  |  |  |
|  | $ | 49 |  |  | $ | 58 |  |  |  |  |  |

[0000068505-25-000024:notes:48]
During the three months ended March 29, 2025, the Company recognized a gain on the Hytera litigation of $10 million for amounts recovered through legal proceedings due to theft of the Company's trade secrets. Refer to "Hytera Civil Litigation" within "Note 12: commitments and Contingencies" in this "Part 1 — Financial Information" of this Form 10-Q.

[0000068505-25-000024:notes:49]
[same as prior period, unchanged from 0000068505-24-000034:notes:49]

[0000068505-25-000024:notes:50]
[same as prior period, unchanged from 0000068505-24-000034:notes:50]

[0000068505-25-000024:notes:51]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Interest, net: |  |  |  |  |  |  |  |
| Interest expense | $ | (69) |  |  | $ | (61) |  |  |  |  |  |
| Interest income | 18 |  |  | 17 |  |  |  |  |  |
|  | $ | (51) |  |  | $ | (44) |  |  |  |  |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 30 |  |  | $ | 32 |  |  |  |  |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | — |  |  | (585) |  |  |  |  |  |
| Investment impairments | — |  |  | (3) |  |  |  |  |  |
| Foreign currency gain (loss) | (20) |  |  | 1 |  |  |  |  |  |
| Gain (loss) on derivative instruments (Note 6) | 13 |  |  | (10) |  |  |  |  |  |
| Fair value adjustments to equity investments | (5) |  |  | (2) |  |  |  |  |  |
| Other | (2) |  |  | 2 |  |  |  |  |  |
|  | $ | 16 |  |  | $ | (565) |  |  |  |  |  |

[0000068505-25-000024:notes:52]
Earnings (Loss) Per Common Share

[0000068505-25-000024:notes:53]
Basic and diluted earnings (loss) per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-25-000024:notes:54]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings (loss) | $ | 430 |  |  | $ | (39) |  |  |  |  |  |
| Weighted average common shares outstanding | 166.9 |  |  | 166.3 |  |  |  |  |  |
| Per share amount | $ | 2.58 |  |  | $ | (0.23) |  |  |  |  |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings (loss) | $ | 430 |  |  | $ | (39) |  |  |  |  |  |
| Weighted average common shares outstanding | 166.9 |  |  | 166.3 |  |  |  |  |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.9 |  |  | — |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 169.8 |  |  | 166.3 |  |  |  |  |  |
| Per share amount | $ | 2.53 |  |  | $ | (0.23) |  |  |  |  |  |

[0000068505-25-000024:notes:55]
In the computation of diluted earnings per common share for the three months ended March 29, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000024:notes:56]
In the computation of diluted earnings per common share for the three months ended March 30, 2024, the Company recorded a net loss from continuing operations, which resulted in the presentation of diluted earnings (loss) per common share to be equal to basic earnings (loss) per common share, as any increase to the basic shares would be antidilutive. A total of 5.0 million shares outstanding were excluded from the computation of diluted earnings per common share for three months ended March 30, 2024, because their inclusion would have been antidilutive; these shares included 4.1 million share-based awards and 0.9 million shares related to the 1.75% senior convertible notes issued to Silver Lake Partners ("Silver Lake Convertible Debt").

[0000068505-25-000024:notes:57]
[same as prior period, unchanged from 0000068505-24-000034:notes:58]

[0000068505-25-000024:notes:58]
[same as prior period, unchanged from 0000068505-24-000034:notes:59]

[0000068505-25-000024:notes:59]
[same as prior period, unchanged from 0000068505-24-000034:notes:60]

[0000068505-25-000024:notes:60]
|  | March 29, 2025 |  | December 31, 2024 |
| Accounts receivable | $ | 1,851 |  |  | $ | 2,035 |  |
| Less allowance for credit losses | (81) |  |  | (83) |  |
|  | $ | 1,770 |  |  | $ | 1,952 |  |

[0000068505-25-000024:notes:61]
[same as prior period, unchanged from 0000068505-24-000034:notes:62]

[0000068505-25-000024:notes:62]
[same as prior period, unchanged from 0000068505-24-000034:notes:63]

[0000068505-25-000024:notes:63]
|  | March 29, 2025 |  | December 31, 2024 |
| Finished goods | $ | 411 |  |  | $ | 396 |  |
| Work-in-process and production materials | 550 |  |  | 498 |  |
|  | 961 |  |  | 894 |  |
| Less inventory reserves | (128) |  |  | (128) |  |
|  | $ | 833 |  |  | $ | 766 |  |

[0000068505-25-000024:notes:64]
[same as prior period, unchanged from 0000068505-24-000034:notes:65]

[0000068505-25-000024:notes:65]
[same as prior period, unchanged from 0000068505-24-000034:notes:66]

[0000068505-25-000024:notes:66]
|  | March 29, 2025 |  | December 31, 2024 |
| Current contract cost assets (Note 2) | $ | 69 |  |  | $ | 70 |  |
| Contractor receivables | 42 |  |  | 44 |  |
| Tax-related deposits | 53 |  |  | 54 |  |
| Other | 280 |  |  | 261 |  |
|  | $ | 444 |  |  | $ | 429 |  |

[0000068505-25-000024:notes:67]
[same as prior period, unchanged from 0000068505-24-000034:notes:68]

[0000068505-25-000024:notes:68]
[same as prior period, unchanged from 0000068505-24-000034:notes:69]

[0000068505-25-000024:notes:69]
|  | March 29, 2025 |  | December 31, 2024 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 451 |  |  | 441 |  |
| Machinery and equipment | 2,329 |  |  | 2,243 |  |
|  | 2,785 |  |  | 2,689 |  |
| Less accumulated depreciation | (1,746) |  |  | (1,667) |  |
|  | $ | 1,039 |  |  | $ | 1,022 |  |

[0000068505-25-000024:notes:70]
Depreciation expense was $44 million for the three months ended March 29, 2025 and March 30, 2024.

[0000068505-25-000024:notes:71]
[same as prior period, unchanged from 0000068505-24-000034:notes:73]

[0000068505-25-000024:notes:72]
[same as prior period, unchanged from 0000068505-24-000034:notes:74]

[0000068505-25-000024:notes:73]
|  | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Common stock | $ | 18 |  |  | $ | 23 |  |  |  |  |  |
| Strategic investments | 52 |  |  | 26 |  |  |  |  |  |
| Company-owned life insurance policies | 80 |  |  | 75 |  |  |  |  |  |
| Equity method investments | 11 |  |  | 11 |  |  |  |  |  |
|  | $ | 161 |  |  | $ | 135 |  |  |  |  |  |

[0000068505-25-000024:notes:74]
[same as prior period, unchanged from 0000068505-24-000034:notes:76]

[0000068505-25-000024:notes:75]
[same as prior period, unchanged from 0000068505-24-000034:notes:77]

[0000068505-25-000024:notes:76]
|  | March 29, 2025 |  | December 31, 2024 |
| Defined benefit plan assets | $ | 192 |  |  | $ | 162 |  |
| Non-current contract cost assets (Note 2) | 129 |  |  | 141 |  |
| Other | 62 |  |  | 72 |  |
|  | $ | 383 |  |  | $ | 375 |  |

[0000068505-25-000024:notes:77]
[same as prior period, unchanged from 0000068505-24-000034:notes:79]

[0000068505-25-000024:notes:78]
[same as prior period, unchanged from 0000068505-24-000034:notes:80]

[0000068505-25-000024:notes:79]
The Company's outstanding amounts related to the suppliers participating in this program was $27 million and $38 million as of March 29, 2025 and December 31, 2024, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-25-000024:notes:80]
[same as prior period, unchanged from 0000068505-24-000034:notes:82]

[0000068505-25-000024:notes:81]
[same as prior period, unchanged from 0000068505-24-000034:notes:83]

[0000068505-25-000024:notes:82]
|  | March 29, 2025 |  | December 31, 2024 |
| Compensation | $ | 465 |  |  | $ | 406 |  |
| Tax liabilities | 272 |  |  | 217 |  |
| Dividend payable | 182 |  |  | 182 |  |
| Trade liabilities | 161 |  |  | 160 |  |
| Operating lease liabilities (Note 3) | 114 |  |  | 127 |  |
| Customer reserves | 75 |  |  | 97 |  |
| Other | 503 |  |  | 454 |  |
|  | $ | 1,772 |  |  | $ | 1,643 |  |

[0000068505-25-000024:notes:83]
[same as prior period, unchanged from 0000068505-24-000034:notes:85]

[0000068505-25-000024:notes:84]
[same as prior period, unchanged from 0000068505-24-000034:notes:86]

[0000068505-25-000024:notes:85]
|  | March 29, 2025 |  | December 31, 2024 |
| Defined benefit plans (Note 8) | $ | 749 |  |  | $ | 768 |  |
| Non-current contract liabilities (Note 2) | 556 |  |  | 496 |  |
| Unrecognized tax benefits (Note 7) | 39 |  |  | 39 |  |
| Deferred income taxes (Note 7) | 87 |  |  | 87 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Deferred compensation | 88 |  |  | 89 |  |
| Other | 125 |  |  | 121 |  |
|  | $ | 1,763 |  |  | $ | 1,719 |  |

[0000068505-25-000024:notes:86]
[same as prior period, unchanged from 0000068505-24-000034:notes:88]

[0000068505-25-000024:notes:87]
Share Repurchase Program: During the three months ended March 29, 2025, the Company repurchased approximately 0.7 million shares at an average price of $437.17 per share for an aggregate amount of $325 million.

[0000068505-25-000024:notes:88]
Payment of Dividends: During the three months ended March 29, 2025 and March 30, 2024, the Company paid $182 million and $163 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $182 million in cash dividends to holders of its common stock.

[0000068505-25-000024:notes:89]
[same as prior period, unchanged from 0000068505-24-000034:notes:91]

[0000068505-25-000024:notes:90]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended March 29, 2025 and March 30, 2024:

[0000068505-25-000024:notes:91]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (546) |  |  | $ | (482) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | 38 |  |  | (27) |  |  |  |  |  |
| Tax benefit | 3 |  |  | 3 |  |  |  |  |  |
| Other comprehensive income (loss), net of tax | 41 |  |  | (24) |  |  |  |  |  |
| Balance at end of period | $ | (505) |  |  | $ | (506) |  |  |  |  |  |
| Derivative instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (7) |  |  | $ | (12) |  |  |  |  |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | 4 |  |  |  |  |  |
| Other comprehensive income, net of tax | — |  |  | 4 |  |  |  |  |  |
| Balance at end of period | $ | (7) |  |  | $ | (8) |  |  |  |  |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,986) |  |  | $ | (2,046) |  |  |  |  |  |
| Other comprehensive loss before reclassification adjustment | (12) |  |  | — |  |  |  |  |  |
| Tax benefit | 3 |  |  | — |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (9) |  |  | — |  |  |  |  |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 9 |  |  | 9 |  |  |  |  |  |
| Tax benefit (expense) | (2) |  |  | (2) |  |  |  |  |  |
| Reclassification adjustments into Net earnings, net of tax | 7 |  |  | 7 |  |  |  |  |  |
| Other comprehensive income, net of tax | (2) |  |  | 7 |  |  |  |  |  |
| Balance at end of period | $ | (1,988) |  |  | $ | (2,039) |  |  |  |  |  |
| Total Accumulated other comprehensive loss | $ | (2,500) |  |  | $ | (2,553) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-25-000024:notes:92]
Debt and Credit Facilities
As of March 29, 2025, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-25-000024:notes:93]
As of March 29, 2025, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 29, 2025.

[0000068505-25-000024:notes:94]
Subsequent to the quarter end, on April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). The 2025 Motorola Solutions Credit Agreement replaces the 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement.

[0000068505-25-000024:notes:95]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 29, 2025 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-25-000024:notes:96]
[same as prior period, unchanged from 0000068505-24-000034:notes:102]

[0000068505-25-000024:notes:97]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.1 billion and $1.0 billion for the periods ended March 29, 2025 and December 31, 2024, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-25-000024:notes:98]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of March 29, 2025, and the corresponding positions as of December 31, 2024:

[0000068505-25-000024:notes:99]
|  | Notional Amount |
| Net Buy (Sell) by Currency | March 29, 2025 |  | December 31, 2024 |
| British pound | $ | 173 |  |  | $ | 124 |  |
| Euro | 166 |  |  | 150 |  |
| Australian dollar | (129) |  |  | (136) |  |
| Chinese renminbi | (43) |  |  | (48) |  |
| Canadian dollar | 41 |  |  | 70 |  |

[0000068505-25-000024:notes:100]
[same as prior period, unchanged from 0000068505-24-000034:notes:106]

[0000068505-25-000024:notes:101]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of March 29, 2025, all of the counterparties had investment grade credit ratings. As of March 29, 2025, the Company had $7 million of exposure to aggregate credit risk with all counterparties.

[0000068505-25-000024:notes:102]
[same as prior period, unchanged from 0000068505-24-000034:notes:108]

[0000068505-25-000024:notes:103]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of March 29, 2025 and December 31, 2024:

[0000068505-25-000024:notes:104]
|  | Fair Values of Derivative Instruments |
| March 29, 2025 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 6 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 7 |  |  | 2 |  |
| Equity swap contracts | — |  |  | 1 |  |
| Total derivatives | $ | 7 |  |  | $ | 9 |  |

[0000068505-25-000024:notes:105]
|  | Fair Values of Derivative Instruments |
| December 31, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 7 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 3 |  |  | 9 |  |
| Equity swap contracts | — |  |  | 1 |  |
| Total derivatives | $ | 10 |  |  | $ | 10 |  |

[0000068505-25-000024:notes:106]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended March 29, 2025 and March 30, 2024:

[0000068505-25-000024:notes:107]
|  | Financial Statement Location | Three Months Ended |  |  |
| Derivatives | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | (6) |  |  | $ | 4 |  |  |  |  |  |
| Amortized hedge income | Other income (expense) | 1 |  |  | 1 |  |  |  |  |  |
| Treasury rate lock | Accumulated other comprehensive income (loss) | — |  |  | 4 |  |  |  |  |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | 13 |  |  | $ | (10) |  |  |  |  |  |
| Equity swap contracts | Selling, general and administrative expenses | (1) |  |  | 1 |  |  |  |  |  |

[0000068505-25-000024:notes:108]
[same as prior period, unchanged from 0000068505-24-000034:notes:114]

[0000068505-25-000024:notes:109]
The Company uses foreign exchange forward and option contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of March 29, 2025, the Company had €140 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in a British pound functional subsidiary.

[0000068505-25-000024:notes:110]
The Company excludes the difference between the spot rate and the forward rate of the forward contracts and initial time value of the options from its assessment of hedge effectiveness.The effect of the forward points recognized in forward contracts and the initial time value of the option contracts are amortized on a straight-line basis and recognized through interest expense within Other income (expense) in the Condensed Consolidated Statement of Operations.

[0000068505-25-000024:notes:111]
[same as prior period, unchanged from 0000068505-24-000034:notes:117]

[0000068505-25-000024:notes:112]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of March 29, 2025 was $18 million.

[0000068505-25-000024:notes:113]
[same as prior period, unchanged from 0000068505-24-000034:notes:119]

[0000068505-25-000024:notes:114]
In 2023, the Company entered into treasury rate agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the three months ended March 30, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated Other Comprehensive Income will be reclassified to interest expense on a straight-line basis over the 10-year term of the 2034 notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-25-000024:notes:115]
[same as prior period, unchanged from 0000068505-24-000034:notes:121]

[0000068505-25-000024:notes:116]
[same as prior period, unchanged from 0000068505-24-000034:notes:122]

[0000068505-25-000024:notes:117]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Earnings (loss) before income taxes | $ | 547 |  |  | $ | (90) |  |  |  |  |  |
| Income tax expense (benefit) | 115 |  |  | (52) |  |  |  |  |  |
| Effective tax rate | 21 | % |  | 58 | % |  |  |  |  |

[0000068505-25-000024:notes:118]
The effective tax rate for the three months ended March 29, 2025 of 21% was equal to the U.S. federal statutory tax rate of 21% primarily due to excess tax benefits of share-based compensation, offset by state tax expense.

[0000068505-25-000024:notes:119]
The effective tax rate for the three months ended March 30, 2024 of 58% was higher than the U.S. federal statutory tax rate of 21%, primarily due to the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt and state tax expense, offset by the tax benefit recognized upon the Company's decision to implement a business initiative which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, and excess tax benefits of share-based compensation.

[0000068505-25-000024:notes:120]
The effective tax rate for the three months ended March 29, 2025 of 21% was lower than the effective tax rate for the three months ended March 30, 2024 of 58%, primarily due to the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in 2024, partially offset by the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-25-000024:notes:121]
[same as prior period, unchanged from 0000068505-24-000034:notes:127]

[0000068505-25-000024:notes:122]
[same as prior period, unchanged from 0000068505-24-000034:notes:128]

[0000068505-25-000024:notes:123]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Interest cost | $ | 50 |  |  | $ | 47 |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 1 |  |
| Expected return on plan assets | (76) |  |  | (74) |  |  | (26) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 6 |  |  | 6 |  |  | 2 |  |  | 2 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | (1) |  |  | 1 |  |  | 1 |  |
| Net periodic pension benefits | $ | (20) |  |  | $ | (21) |  |  | $ | (11) |  |  | $ | (11) |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-25-000024:notes:124]
[same as prior period, unchanged from 0000068505-24-000034:notes:131]

[0000068505-25-000024:notes:125]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 14 |  |  | $ | 11 |  |  |  |  |  |
| Selling, general and administrative expenses | 35 |  |  | 30 |  |  |  |  |  |
| Research and development expenditures | 17 |  |  | 15 |  |  |  |  |  |
| Share-based compensation expense included in Operating earnings | 66 |  |  | 56 |  |  |  |  |  |
| Tax benefit | (14) |  |  | (11) |  |  |  |  |  |
| Share-based compensation expense, net of tax | $ | 52 |  |  | $ | 45 |  |  |  |  |  |
| Decrease in basic earnings per share | $ | (0.31) |  |  | $ | (0.27) |  |  |  |  |  |
| Decrease in diluted earnings per share | $ | (0.31) |  |  | $ | (0.27) |  |  |  |  |  |

[0000068505-25-000024:notes:126]
During the three months ended March 29, 2025, the Company granted 0.4 million RSUs, 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $175 million, $24 million and $17 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $7 million and $17 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-25-000024:notes:127]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of March 29, 2025 and December 31, 2024 were as follows:

[0000068505-25-000024:notes:128]
| March 29, 2025 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |
| Common stock | 18 |  |  | — |  |  |  |  | 18 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  |  |  | $ | 8 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |

[0000068505-25-000024:notes:129]
| December 31, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  |  |  | $ | 10 |  |
| Common stock | 23 |  |  | — |  |  |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |

[0000068505-25-000024:notes:130]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of March 29, 2025 or December 31, 2024.

[0000068505-25-000024:notes:131]
At March 29, 2025 and December 31, 2024, the Company had $686 million and $1.2 billion, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-25-000024:notes:132]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of March 29, 2025 was $5.8 billion. The fair value of long-term debt at December 31, 2024 was $5.8 billion.

[0000068505-25-000024:notes:133]
[same as prior period, unchanged from 0000068505-24-000034:notes:140]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-25-000024:notes:134]
[same as prior period, unchanged from 0000068505-24-000034:notes:141]

[0000068505-25-000024:notes:135]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended March 29, 2025 and March 30, 2024:

[0000068505-25-000024:notes:136]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Long-term receivables sales proceeds | $ | 24 |  |  | $ | 10 |  |  |  |  |  |

[0000068505-25-000024:notes:137]
At March 29, 2025, the Company had retained servicing obligations for $769 million of long-term receivables, compared to $794 million at December 31, 2024. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $150 million at March 29, 2025, compared to $105 million at December 31, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-25-000024:notes:138]
Commitments and Contingencies
Legal Matters

[0000068505-25-000024:notes:139]
Hytera Civil Litigation

[0000068505-25-000024:notes:140]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-25-000024:notes:141]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera made de minimis quarterly royalty payments into the third-party escrow from October 2022 through November 2024; after which such de minimis royalty payments have been paid directly to the Company. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other Charges (Income) within the Consolidated Statement of Operations. On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million and that payment was recorded as a gain within Other charges (Income) within the Consolidated Statement of Operations.

[0000068505-25-000024:notes:142]
Following the February 14, 2020, verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. The issues of copyright recalculation and injunction are currently briefed and under consideration by the District Court.

[0000068505-25-000024:notes:143]
On January 2, 2025, Hytera filed a petition for Writ of certiorari with the Supreme Court of the United States. Hytera's petition was denied by the Supreme Court on February 24, 2025.

[0000068505-25-000024:notes:144]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings from August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.

[0000068505-25-000024:notes:145]
Hytera Criminal Litigation

[0000068505-25-000024:notes:146]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 6, 2025. Pursuant to the plea agreement reached between Hytera and the government, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-25-000024:notes:147]
Segment Information
Significant Segment Expenses

[0000068505-25-000024:notes:148]
|  | Three Months Ended |
|  | March 29, 2025 |  |  |  |  |  | March 30, 2024 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  |  |  |  |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  |  |  |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Cost of sales | 694 |  | 534 |  | 1,228 |  |  |  |  |  | 716 |  | 481 |  | 1,197 |
| Gross margin | 852 |  | 448 |  | 1,300 |  |  |  |  |  | 774 |  | 418 |  | 1,192 |
| Research and development expenditures | 142 |  | 91 |  | 233 |  |  |  |  |  | 137 |  | 81 |  | 218 |
| Selling, general and administrative expenses | 341 |  | 95 |  | 436 |  |  |  |  |  | 311 |  | 86 |  | 397 |
| Other charges | 17 |  | 32 |  | 49 |  |  |  |  |  | 16 |  | 42 |  | 58 |
| Operating earnings | $ | 352 |  |  | $ | 230 |  |  | $ | 582 |  |  |  |  |  |  | $ | 310 |  |  | $ | 209 |  |  | $ | 519 |  |
| Total other expense |  |  |  |  | (35) |  |  |  |  |  |  |  |  |  | (609) |
| Earnings before income taxes |  |  |  |  | $ | 547 |  |  |  |  |  |  |  |  |  |  | $ | (90) |  |

[0000068505-25-000024:notes:149]
Capital Expenditures by Segment

[0000068505-25-000024:notes:150]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Products and Systems Integration | $ | 15 |  |  | $ | 17 |  |  |  |  |  |
| Software and Services | 22 |  | 29 |  |  |  |  |
|  | $ | 37 |  |  | $ | 46 |  |  |  |  |  |

[0000068505-25-000024:notes:151]
Depreciation Expense by Segment

[0000068505-25-000024:notes:152]
|  | Three Months Ended |  |  |
|  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Products and Systems Integration | $ | 22 |  |  | $ | 21 |  |  |  |  |  |
| Software and Services | 22 |  | 23 |  |  |  |  |
|  | $ | 44 |  |  | $ | 44 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-25-000024:notes:153]
Reorganization of Business
2025 Charges

[0000068505-25-000024:notes:154]
During the three months ended March 29, 2025, the Company recorded net reorganization of business charges of $17 million, consisting of $12 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $19 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals that are no longer needed.

[0000068505-25-000024:notes:155]
[same as prior period, unchanged from 0000068505-24-000034:notes:158]

[0000068505-25-000024:notes:156]
| March 29, 2025 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 12 |  |  |  |
| Software and Services | 5 |  |  |  |
|  | $ | 17 |  |  |  |

[0000068505-25-000024:notes:157]
[same as prior period, unchanged from 0000068505-24-000034:notes:160]

[0000068505-25-000024:notes:158]
|  | January 1, 2025 |  | Additional Charges |  | Adjustments |  | Amount Used |  | March 29, 2025 |
| Employee separation costs | $ | 27 |  |  | $ | 19 |  |  | $ | (2) |  |  | $ | (14) |  |  | $ | 30 |  |
| Exit costs | 1 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
|  | $ | 28 |  |  | $ | 19 |  |  | $ | (2) |  |  | $ | (14) |  |  | $ | 31 |  |

[0000068505-25-000024:notes:159]
[same as prior period, unchanged from 0000068505-24-000034:notes:162]

[0000068505-25-000024:notes:160]
At January 1, 2025, the Company had an accrual of $1 million for exit costs, related to the Company's exit of the Emergency Service Network contract with the U.K. Home Office. The $1 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at March 29, 2025, and are expected to be paid within one year.

[0000068505-25-000024:notes:161]
[same as prior period, unchanged from 0000068505-24-000034:notes:164]

[0000068505-25-000024:notes:162]
At January 1, 2025, the Company had an accrual of $27 million for employee separation costs. The 2025 additional charges of $19 million represent severance costs for approximately 280 employees. The adjustment of $2 million reflects reversals for accruals no longer needed. The $14 million used reflects cash payments to severed employees. The remaining accrual of $30 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at March 29, 2025, is expected to be paid, primarily within one year, to approximately 700 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-25-000024:notes:163]
2024 Charges

[0000068505-25-000024:notes:164]
During the three months ended March 30, 2024, the Company recorded net reorganization of business charges of $10 million, including $7 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000024:notes:165]
| March 30, 2024 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 8 |  |  |  |
| Software and Services | 2 |  |  |  |
|  | $ | 10 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-25-000024:notes:166]
Intangible Assets and Goodwill
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value price of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio of enterprise technologies, including body cameras, fixed video, panic buttons and radios. The Company recognized $126 million of goodwill, $54 million of identifiable intangible assets, and $7 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $24 million of customer relationships and $29 million of developed technology and will be amortized over a period of three, fifteen and twelve years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000024:notes:167]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $241 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. The Company recognized $186 million of goodwill, $77 million of identifiable intangible assets, and $22 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $6 million of trade names, $32 million of customer relationships and $39 million of developed technology and will be amortized over a period of nine, eighteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000024:notes:168]
On October 29, 2024, the Company acquired 3tc Software ("3tc"), a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing CAD for the U.K.'s public safety agencies. The Company recognized $13 million of goodwill, $11 million of identifiable intangible assets, and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $11 million of developed technology and will be amortized over a period of seven years. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000024:notes:169]
On July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The Company recognized $50 million of goodwill, $53 million of identifiable intangible assets, and $12 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $7 million of customer relationships and $45 million of developed technology and will be amortized over a period of three, fifteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-25-000024:notes:170]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The Company recognized $62 million of goodwill, $65 million of identifiable intangible assets and $5 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $11 million of trade names, $51 million of customer relationships and $3 million of developed technology and will be amortized over a period of nine, eighteen and six years, respectively. The acquisition expands the Company's video solutions within the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-25-000024:notes:171]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The Company recognized $16 million of goodwill, $22 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $10 million of customer relationships and $11 million of developed technology and will be amortized over a period of two, fourteen and ten years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting was completed as of the first quarter of 2025.

[0000068505-25-000024:notes:172]
[same as prior period, unchanged from 0000068505-24-000034:notes:175]

[0000068505-25-000024:notes:173]
[same as prior period, unchanged from 0000068505-24-000034:notes:176]

[0000068505-25-000024:notes:174]
|  | March 29, 2025 |  | December 31, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,302 |  |  | $ | 558 |  |  | $ | 1,226 |  |  | $ | 535 |  |
| Customer-related | 1,690 |  |  | 1,129 |  |  | 1,609 |  |  | 1,093 |  |
| Other intangibles | 127 |  |  | 79 |  |  | 118 |  |  | 76 |  |
|  | $ | 3,119 |  |  | $ | 1,766 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-25-000024:notes:175]
Amortization expense on intangible assets was $37 million for the three months ended March 29, 2025. Amortization expense on intangible assets was $39 million for the three months ended March 30, 2024. As of March 29, 2025, annual amortization expense is estimated to be $152 million in 2025, $145 million in 2026, $135 million in 2027, $134 million in 2028, $122 million in 2029 and $120 million in 2030.

[0000068505-25-000024:notes:176]
[same as prior period, unchanged from 0000068505-24-000034:notes:179]

[0000068505-25-000024:notes:177]
|  | March 29, 2025 |  | December 31, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 1,017 |  |  | $ | 427 |  |  | $ | 1,017 |  |  | $ | 409 |  |
| Software and Services | 2,102 |  |  | 1,339 |  |  | 1,936 |  |  | 1,295 |  |
|  | $ | 3,119 |  |  | $ | 1,766 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-25-000024:notes:178]
[same as prior period, unchanged from 0000068505-24-000034:notes:181]

[0000068505-25-000024:notes:179]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2025 to March 29, 2025:

[0000068505-25-000024:notes:180]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2025 | $ | 1,573 |  |  | $ | 1,953 |  |  | $ | 3,526 |  |
| Goodwill acquired | — |  |  | 312 |  |  | 312 |  |
| Purchase accounting adjustments | — |  |  | (6) |  |  | (6) |  |
| Foreign currency | 1 |  |  | 8 |  |  | 9 |  |
| Balance as of March 29, 2025 | $ | 1,574 |  |  | $ | 2,267 |  |  | $ | 3,841 |  |
