# MSI 8-K — 0000068505-25-000022 filed 2025-05-01

## item codes, every 8-K on or before 2025-05-01

- 2025-05-01 0000068505-25-000022 — 2.02, 9.01
- 2025-04-25 0001193125-25-096928 — 1.01, 1.02, 2.03, 9.01
- 2025-02-13 0000068505-25-000008 — 2.02, 9.01
- 2024-11-07 0000068505-24-000032 — 2.02, 9.01
- 2024-10-09 0001193125-24-235267 — 5.02
- 2024-08-26 0001193125-24-207088 — 5.02, 9.01
- 2024-08-01 0000068505-24-000022 — 2.02, 9.01
- 2024-05-17 0001193125-24-141186 — 5.07
- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2025-05-01

- none on or before 2025-05-01

## item 2.02 — earnings release, exhibit 99.1

[0000068505-25-000022:8k_2_02:1]
EX-99.1
2
msiq12025pressrelease.htm
EX-99.1

[0000068505-25-000022:8k_2_02:2]
Document

[0000068505-25-000022:8k_2_02:3]
Exhibit 99.1

[0000068505-25-000022:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2025 Financial Results

[0000068505-25-000022:8k_2_02:5]
Company Achieves Record Q1 Sales, Operating Earnings and Operating Cash Flow

[0000068505-25-000022:8k_2_02:6]
•Sales of $2.5 billion, up 6% versus a year ago

[0000068505-25-000022:8k_2_02:7]
◦Products and Systems Integration sales up 4%

[0000068505-25-000022:8k_2_02:8]
◦Software and Services sales up 9%

[0000068505-25-000022:8k_2_02:9]
•GAAP earnings per share ("EPS") of $2.53

[0000068505-25-000022:8k_2_02:10]
•Non-GAAP EPS* of $3.18, up 13% versus a year ago

[0000068505-25-000022:8k_2_02:11]
•Record Q1 operating cash flow of $510 million, up $128 million versus a year ago

[0000068505-25-000022:8k_2_02:12]
•Acquired RapidDeploy and Theatro for an aggregate of $414 million, net of cash acquired

[0000068505-25-000022:8k_2_02:13]
•Launched SVX, a converged, secure P25 speaker mic and body-worn camera for APX NEXT family of devices

[0000068505-25-000022:8k_2_02:14]
•Launched Assist, AI for public safety, with applications across the portfolio

[0000068505-25-000022:8k_2_02:15]
CHICAGO – May 1, 2025 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2025.

[0000068505-25-000022:8k_2_02:16]
"Q1 was an excellent start to the year, with record first-quarter sales, operating earnings and cash flow,” said Greg Brown, chairman and CEO, Motorola Solutions. “Our customers are continuing to prioritize investments in safety and security, which is driving our continued expectations for strong revenue, earnings and cash flow growth for the year.”

[0000068505-25-000022:8k_2_02:17]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-25-000022:8k_2_02:18]
|  | Q1 2025 |  | Q1 2024 | % Change |
| Sales | $2,528 |  | $2,389 | 6 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $582 |  | $519 | 12 | % |
| % of Sales | 23.0 | % |  | 21.7 | % |  |
| EPS | $2.53 |  | ($0.23) | 1,200 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $716 |  | $638 | 12 | % |
| % of Sales | 28.3 | % |  | 26.7 | % |  |
| EPS | $3.18 |  | $2.81 | 13 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,546 |  | $1,490 | 4 | % |
| GAAP Operating Earnings | $352 |  | $310 | 14 | % |
| % of Sales | 22.8 | % |  | 20.8 | % |  |
| Non-GAAP* Operating Earnings | $434 |  | $370 | 17 | % |
| % of Sales | 28.1 | % |  | 24.8 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $982 |  | $899 | 9 | % |
| GAAP Operating Earnings | $230 |  | $209 | 10 | % |
| % of Sales | 23.4 | % |  | 23.2 | % |  |
| Non-GAAP* Operating Earnings | $282 |  | $268 | 5 | % |
| % of Sales | 28.7 | % |  | 29.8 | % |  |

[0000068505-25-000022:8k_2_02:19]
* Non-GAAP financial information excludes the after-tax impact of approximately $0.65 per diluted share related to highlighted items, share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-25-000022:8k_2_02:20]
1

[0000068505-25-000022:8k_2_02:21]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-25-000022:8k_2_02:22]
•Revenue - Sales were $2.5 billion, up 6% from the year-ago quarter driven by growth in North America, partially offset by a decline internationally due to foreign currency headwinds and lower Ukraine revenue. Revenue from acquisitions was $32 million and foreign currency headwinds were $25 million in the quarter. The Products and Systems Integration segment grew 4%, driven by growth in Land Mobile Radio Communications ("LMR"). The Software and Services segment grew 9%, driven by growth in Video Security and Access Control ("Video"), LMR services and Command Center.

[0000068505-25-000022:8k_2_02:23]
•Operating margin - GAAP operating margin was 23.0% of sales, up from 21.7% in the year-ago quarter. Non-GAAP operating margin was 28.3% of sales, up 160 basis points from 26.7% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margins was driven by higher sales, favorable mix and lower direct material costs, partially offset by acquisitions.

[0000068505-25-000022:8k_2_02:24]
•Taxes - The GAAP effective tax rate during the quarter was 21.0%, down from 57.8% in the year-ago quarter driven by a non-deductible loss on the extinguishment of the Silver Lake convertible debt in the prior year. The non-GAAP effective tax rate was 21.1%, down from 22.1% in the year-ago quarter primarily due to higher benefits from share-based compensation recognized in the current quarter.

[0000068505-25-000022:8k_2_02:25]
•Cash flow - Operating cash flow was $510 million, compared to $382 million in the year-ago quarter and free cash flow was $473 million, up from $336 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings and working capital improvements.

[0000068505-25-000022:8k_2_02:26]
•Capital allocation - During the quarter, the company repurchased $325 million of common stock, paid $182 million in cash dividends and incurred $37 million of capital expenditures. Additionally, the company closed two acquisitions in Command Center; RapidDeploy, a cloud-native NG 911 solution provider, and Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers, for a combined $414 million, net of cash acquired.

[0000068505-25-000022:8k_2_02:27]
•Backlog - The company ended the quarter with backlog of $14.1 billion, down 2% or $306 million from the year-ago quarter. Products and Systems Integration segment backlog was down $1.0 billion, or 22%, driven primarily by strong LMR shipments. Software and Services segment backlog was up $732 million, or 8%, driven by strong demand across all three technologies, partially offset by revenue recognition from the U.K. Home Office.

[0000068505-25-000022:8k_2_02:28]
2

[0000068505-25-000022:8k_2_02:29]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-25-000022:8k_2_02:30]
Software and Services

[0000068505-25-000022:8k_2_02:31]
•$19M LMR managed services extension for an international customer

[0000068505-25-000022:8k_2_02:32]
•$18M LMR services renewal for a U.S. utility customer

[0000068505-25-000022:8k_2_02:33]
•$9M fixed video services contract renewal for the City of Chicago

[0000068505-25-000022:8k_2_02:34]
•$7M Command Center order for a U.S. federal customer

[0000068505-25-000022:8k_2_02:35]
•$5M Command Center order for Denver's Public Transport

[0000068505-25-000022:8k_2_02:36]
Products and Systems Integration

[0000068505-25-000022:8k_2_02:37]
•$19M TETRA award for a customer in Germany

[0000068505-25-000022:8k_2_02:38]
•$10M fixed video order for Duke Energy

[0000068505-25-000022:8k_2_02:39]
•$10M P25 system order for a customer in North Africa

[0000068505-25-000022:8k_2_02:40]
•$10M P25 device order for a U.S. state and local customer

[0000068505-25-000022:8k_2_02:41]
•$7M P25 device order for Aurora, CO

[0000068505-25-000022:8k_2_02:42]
BUSINESS OUTLOOK

[0000068505-25-000022:8k_2_02:43]
•Second quarter 2025 - The company expects revenue growth of approximately 4% compared to the second quarter of 2024 and non-GAAP EPS in the range of $3.32 to $3.37 per share. This assumes approximately 170 million of fully diluted shares and a non-GAAP effective tax rate of approximately 23.5%.

[0000068505-25-000022:8k_2_02:44]
•Full-year 2025 - The company is maintaining its prior guidance of approximately 5.5% revenue growth and non-GAAP EPS between $14.64 and $14.74 per share. This outlook assumes approximately $40 million in foreign exchange headwinds, 170 million of fully diluted shares and a non-GAAP effective tax rate of approximately 23.0%.

[0000068505-25-000022:8k_2_02:45]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-25-000022:8k_2_02:46]
RECENT EVENTS

[0000068505-25-000022:8k_2_02:47]
MACROECONOMIC ENVIRONMENT UPDATE

[0000068505-25-000022:8k_2_02:48]
Beginning in February 2025, the United States implemented significant global tariffs on imports, contributing to a global trade landscape subject to changing import/export regulations, tariffs, trade barriers and trade disputes. As a result, the company sees growing volatility and uncertainty around the global supply chain.

[0000068505-25-000022:8k_2_02:49]
The company engages with global suppliers across a diverse network of locations around the world. The company continues to work with our global supply base to mitigate its exposure to the risks to global reciprocal (and sectoral) tariffs that have developed, and which may continue to develop, in order to ensure supply continues at levels in order to meet the company's current customer demand. As a result of the dynamic environment, the company expects increased costs on materials and components in 2025, which the company currently expects to substantially mitigate.

[0000068505-25-000022:8k_2_02:50]
3

[0000068505-25-000022:8k_2_02:51]
U.K. HOME OFFICE UPDATE

[0000068505-25-000022:8k_2_02:52]
Beginning August 1, 2023, the United Kingdom's Competition Markets Authority ("CMA") imposed a legal order which implemented a prospective price control on Airwave (the "Airwave Charge Control"), the company's private mobile radio communications network that provides mission-critical voice and data communications to emergency services and other agencies in Great Britain. The company's appeal of the implementation of the Charge Control to the United Kingdom's Court of Appeal was unsuccessful and the company has no further right to appeal to the United Kingdom Courts. Since August 1, 2023, revenue under the Airwave contract has been, and will continue to be, recognized in accordance with the Airwave Charge Control.

[0000068505-25-000022:8k_2_02:53]
In 2024, the company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the U.K. Home Office. The Deferred National Shutdown Notice extends the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the Airwave Charge Control rates and is fully reflected in the company's reported backlog. In 2024, the company filed proceedings in the U.K. High Court challenging the decision of the U.K. Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable U.K. procurement and public law. During the first quarter of 2025, these proceedings were discontinued.

[0000068505-25-000022:8k_2_02:54]
On December 12, 2024, a proposed class representative filed a claim with the Competition Appeal Tribunal ("CAT") to bring collective proceedings against the company, alleging that users of Airwave services during the period January 1, 2020 through July 31, 2023 suffered financial harm as a result of the pricing in effect during such time (the "Collective Proceeding"). The initial stage of the Collective Proceeding will involve potential "Certification" of the claim by the CAT, which the company expects to be heard in September 2025.

[0000068505-25-000022:8k_2_02:55]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, May 1. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-25-000022:8k_2_02:56]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-25-000022:8k_2_02:57]
A comparison of results from operations is as follows:

[0000068505-25-000022:8k_2_02:58]
|  | Q1 2025 | Q1 2024 |
| Net sales | $2,528 | $2,389 |
| Gross margin | $1,300 | $1,192 |
| Operating earnings | $582 | $519 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $430 | ($39) |
| Diluted EPS | $2.53 | ($0.23) |
| Weighted average diluted common shares outstanding | 169.8 |  | 166.3 |  |

[0000068505-25-000022:8k_2_02:59]
4

[0000068505-25-000022:8k_2_02:60]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-25-000022:8k_2_02:61]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate, and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-25-000022:8k_2_02:62]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-25-000022:8k_2_02:63]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-25-000022:8k_2_02:64]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-25-000022:8k_2_02:65]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-25-000022:8k_2_02:66]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-25-000022:8k_2_02:67]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “District Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other

[0000068505-25-000022:8k_2_02:68]
5

[0000068505-25-000022:8k_2_02:69]
things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-25-000022:8k_2_02:70]
On December 17, 2020, the District Court held that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court’s previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through November 2024; after which such de minimis royalty payments have been paid directly to the company. The aggregate amount paid into escrow of approximately $61 million was released to the company on November 26, 2024 and was recorded as a gain within Other Charges (Income) within the Consolidated Statement of Operations. On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million and that payment was recorded as a gain within Other charges (Income) within the Consolidated Statement of Operations.

[0000068505-25-000022:8k_2_02:71]
Following the February 14, 2020 verdict and judgment in the company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera’s motion for rehearing. The case has been remanded to the District Court for further action per the Court of Appeals' decision. The issues of copyright recalculation and injunction are currently briefed and under consideration by the District Court.

[0000068505-25-000022:8k_2_02:72]
On January 2, 2025, Hytera filed a petition for Writ of certiorari with the Supreme Court of the United States. Hytera's petition was denied by the Supreme Court on February 24, 2025.

[0000068505-25-000022:8k_2_02:73]
6

[0000068505-25-000022:8k_2_02:74]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings from August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.

[0000068505-25-000022:8k_2_02:75]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $15 million of proceeds realized in 2022, $61 million realized in 2024 and $10 million realized in 2025. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-25-000022:8k_2_02:76]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-25-000022:8k_2_02:77]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net income measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-25-000022:8k_2_02:78]
FORWARD LOOKING STATEMENTS

[0000068505-25-000022:8k_2_02:79]
7

[0000068505-25-000022:8k_2_02:80]
the risks and uncertainties below, as well as those in Part I Item 1A of Motorola Solutions’ 2024 Annual Report on Form 10-K and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at www.motorolasolutions.com/investors, could cause Motorola Solutions’ actual results to differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (i) impact of current global economic and political conditions in the markets in which we operate (including, but not limited to, with respect to tariffs); (ii) increased areas of risk, increased competition and additional compliance obligations associated with the introduction of new or enhanced products and services in our segments; (iii) impact of catastrophic events on our business or our customers' or suppliers' business; (iv) social, ethical, environmental and competitive risks relating to the use of artificial intelligence ("AI") in our products and services; (v) the effectiveness of our strategic acquisitions, including the integrations of such acquired businesses; (vi) the inability of our products to meet our customers’ expectations or regulatory or industry standards; (vii) our inability to purchase a sufficient amount of materials, parts, and components, as well as software and services, at acceptable prices to meet the demands of our customers, and any disruption to our suppliers or significant increase in the price of supplies; (viii) risks related to our large, multi-year system and services contracts (including, but not limited to, with respect to the Airwave contract); (ix) the global nature of our employees, customers, suppliers and outsource partners; (x) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xi) the inability of our subcontractors to perform in a timely and compliant manner or adhere to our Human Rights Policy; (xii) increasing scrutiny and evolving expectations from investors, customers, lawmakers, regulators and other stakeholders regarding environmental, social and governance (“ESG”) related practices and disclosures, as well as recent U.S. based anti-ESG efforts; (xiii) challenges relating to existing or future legislation and regulations pertaining to AI, AI-enabled products and the use of biometrics and other video analytics; (xiv) the impact, including increased costs and potential liabilities, associated with changes in laws and regulations regarding cybersecurity, privacy, data protection, and information security; (xv) the impact of government regulation of radio frequencies; (xvi) regulations, laws and other compliance requirements applicable to our U.S. government customer contracts and grants; (xvii) the impact, including increased costs and additional compliance obligations, associated with existing or future telecommunications-related laws and regulations; (xviii) impact of product regulatory and safety, consumer, worker safety and environmental product compliance and remediation laws; (xix) the evolving state of environmental regulation relating to climate change, and the physical risks of climate change; (xx) impact of tax matters; (xxi) increased cybersecurity threats, a security breach or other significant disruption of our IT systems or those of our outsource partners, suppliers or customers; (xxii) our inability to protect our intellectual property or potential infringement of intellectual property rights of third parties; (xxiii) risks relating to intellectual property licenses and intellectual property indemnities in our customer and supplier contracts; (xxiv) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xxv) inability to attract and retain senior management and key employees; (xxvi) inability to access the capital markets for financing on acceptable terms and conditions; (xxvii) exposure to exchange rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; (xxviii) impact of returns on pension and retirement plan assets and interest rate changes; and (xix) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-25-000022:8k_2_02:81]
ABOUT MOTOROLA SOLUTIONS

[0000068505-25-000022:8k_2_02:82]
Motorola Solutions is solving for safer. We build and connect technologies to help protect people, property and places. Our solutions enable the collaboration between public safety agencies and enterprises that’s critical for a proactive approach to safety and security. Learn more about how we’re solving for safer communities, safer schools, safer hospitals, safer businesses – safer everywhere – at www.motorolasolutions.com.

[0000068505-25-000022:8k_2_02:83]
8

[0000068505-25-000022:8k_2_02:84]
MEDIA CONTACT

[0000068505-25-000022:8k_2_02:85]
Alexandra Reynolds

[0000068505-25-000022:8k_2_02:86]
Motorola Solutions

[0000068505-25-000022:8k_2_02:87]
+1 312-965-3968

[0000068505-25-000022:8k_2_02:88]
alexandra.reynolds@motorolasolutions.com

[0000068505-25-000022:8k_2_02:89]
INVESTOR CONTACT

[0000068505-25-000022:8k_2_02:90]
Tim Yocum

[0000068505-25-000022:8k_2_02:91]
Motorola Solutions

[0000068505-25-000022:8k_2_02:92]
+1 847-576-6899

[0000068505-25-000022:8k_2_02:93]
Tim.Yocum@motorolasolutions.com

[0000068505-25-000022:8k_2_02:94]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2025 Motorola Solutions, Inc. All rights reserved.

[0000068505-25-000022:8k_2_02:95]
9

[0000068505-25-000022:8k_2_02:96]
GAAP-1

[0000068505-25-000022:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:98]
Condensed Consolidated Statements of Operations

[0000068505-25-000022:8k_2_02:99]
(In millions, except per share amounts)

[0000068505-25-000022:8k_2_02:100]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| Net sales from products | $ | 1,448 |  |  | $ | 1,405 |  |
| Net sales from services | 1,080 |  |  | 984 |  |
| Net sales | 2,528 |  |  | 2,389 |  |
| Costs of products sales | 573 |  |  | 600 |  |
| Costs of services sales | 655 |  |  | 597 |  |
| Costs of sales | 1,228 |  |  | 1,197 |  |
| Gross margin | 1,300 |  |  | 1,192 |  |
| Selling, general and administrative expenses | 436 |  |  | 397 |  |
| Research and development expenditures | 233 |  |  | 218 |  |
| Other charges | 12 |  |  | 19 |  |
| Intangibles amortization | 37 |  |  | 39 |  |
| Operating earnings | 582 |  |  | 519 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (51) |  |  | (44) |  |
| Other, net | 16 |  |  | (565) |  |
| Total other expense | (35) |  |  | (609) |  |
| Earnings (loss) before income taxes | 547 |  |  | (90) |  |
| Income tax expense (benefit) | 115 |  |  | (52) |  |
| Net earnings (loss) | 432 |  |  | (38) |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 1 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 430 |  |  | $ | (39) |  |
| Earnings (loss) per common share: |  |  |  |
| Basic | $ | 2.58 |  |  | $ | (0.23) |  |
| Diluted | $ | 2.53 |  |  | $ | (0.23) |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.9 |  |  | 166.3 |  |
| Diluted | 169.8 |  |  | 166.3 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 57.3 | % |  | 58.8 | % |
| Net sales from services | 42.7 | % |  | 41.2 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 39.6 | % |  | 42.7 | % |
| Costs of services sales | 60.6 | % |  | 60.7 | % |
| Costs of sales | 48.6 | % |  | 50.1 | % |
| Gross margin | 51.4 | % |  | 49.9 | % |
| Selling, general and administrative expenses | 17.2 | % |  | 16.6 | % |
| Research and development expenditures | 9.2 | % |  | 9.1 | % |
| Other charges | 0.5 | % |  | 0.8 | % |
| Intangibles amortization | 1.5 | % |  | 1.6 | % |
| Operating earnings | 23.0 | % |  | 21.7 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.0) | % |  | (1.8) | % |
| Other, net | 0.6 | % |  | (23.7) | % |
| Total other expense | (1.4) | % |  | (25.5) | % |
| Earnings (loss) before income taxes | 21.6 | % |  | (3.8) | % |
| Income tax expense (benefit) | 4.5 | % |  | (2.2) | % |
| Net earnings (loss) | 17.1 | % |  | (1.6) | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | — | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | 17.0 | % |  | (1.6) | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-25-000022:8k_2_02:101]
10

[0000068505-25-000022:8k_2_02:102]
GAAP-2

[0000068505-25-000022:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:104]
Condensed Consolidated Balance Sheets

[0000068505-25-000022:8k_2_02:105]
(In millions)

[0000068505-25-000022:8k_2_02:106]
|  | March 29, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,564 |  |  | $ | 2,102 |  |
| Accounts receivable, net | 1,770 |  |  | 1,952 |  |
| Contract assets | 1,288 |  |  | 1,230 |  |
| Inventories, net | 833 |  |  | 766 |  |
| Other current assets | 444 |  |  | 429 |  |
| Total current assets | 5,899 |  |  | 6,479 |  |
| Property, plant and equipment, net | 1,039 |  |  | 1,022 |  |
| Operating lease assets | 521 |  |  | 529 |  |
| Investments | 161 |  |  | 135 |  |
| Deferred income taxes | 1,236 |  |  | 1,280 |  |
| Goodwill | 3,841 |  |  | 3,526 |  |
| Intangible assets, net | 1,353 |  |  | 1,249 |  |
| Other assets | 383 |  |  | 375 |  |
| Total assets | $ | 14,433 |  |  | $ | 14,595 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | 322 |  |  | $ | 322 |  |
| Accounts payable | 845 |  |  | 1,018 |  |
| Contract liabilities | 1,983 |  |  | 2,072 |  |
| Accrued liabilities | 1,772 |  |  | 1,643 |  |
| Total current liabilities | 4,922 |  |  | 5,055 |  |
| Long-term debt | 5,677 |  |  | 5,675 |  |
| Operating lease liabilities | 412 |  |  | 427 |  |
| Other liabilities | 1,763 |  |  | 1,719 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 1,641 |  |  | 1,703 |  |
| Non-controlling interests | 18 |  |  | 16 |  |
| Total liabilities and stockholders’ equity | $ | 14,433 |  |  | $ | 14,595 |  |

[0000068505-25-000022:8k_2_02:107]
GAAP-3

[0000068505-25-000022:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:109]
Condensed Consolidated Statements of Cash Flows

[0000068505-25-000022:8k_2_02:110]
(In millions)

[0000068505-25-000022:8k_2_02:111]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| Operating |  |  |  |
| Net earnings (loss) | $ | 432 |  |  | $ | (38) |  |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 81 |  |  | 83 |  |
| Non-cash other charges | 7 |  |  | 3 |  |
| Share-based compensation expenses | 66 |  |  | 56 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | — |  |  | 585 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 197 |  |  | 113 |  |
| Inventories | (62) |  |  | (7) |  |
| Other current assets and contract assets | (78) |  |  | (123) |  |
| Accounts payable, accrued liabilities and contract liabilities | (175) |  |  | (90) |  |
| Other assets and liabilities | 25 |  |  | (19) |  |
| Deferred income taxes | 17 |  |  | (181) |  |
| Net cash provided by operating activities | 510 |  |  | 382 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (450) |  |  | (37) |  |
| Proceeds from sales of investments and businesses, net | 10 |  |  | 36 |  |
| Capital expenditures | (37) |  |  | (46) |  |
| Net cash used for investing activities | (477) |  |  | (47) |  |
| Financing |  |  |  |
| Repayments of debt | — |  |  | (1,593) |  |
| Net proceeds from issuance of debt | — |  |  | 1,288 |  |
| Issuances of common stock, net of tax | (90) |  |  | (5) |  |
| Purchases of common stock | (325) |  |  | (39) |  |
| Payments of dividends | (182) |  |  | (163) |  |
| Net cash used for financing activities | (597) |  |  | (512) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 26 |  |  | (16) |  |
| Net decrease in total cash and cash equivalents | (538) |  |  | (193) |  |
| Cash and cash equivalents, beginning of period | 2,102 |  |  | 1,705 |  |
| Cash and cash equivalents, end of period | $ | 1,564 |  |  | $ | 1,512 |  |

[0000068505-25-000022:8k_2_02:112]
12

[0000068505-25-000022:8k_2_02:113]
Non-GAAP-1

[0000068505-25-000022:8k_2_02:114]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:115]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-25-000022:8k_2_02:116]
(In millions)

[0000068505-25-000022:8k_2_02:117]
|  |  | Three Months Ended |  |  |
|  |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 510 |  |  | $ | 382 |  |  |  |  |  |
| Capital expenditures |  | (37) |  |  | (46) |  |  |  |  |  |
| Free cash flow |  | $ | 473 |  |  | $ | 336 |  |  |  |  |  |

[0000068505-25-000022:8k_2_02:118]
13

[0000068505-25-000022:8k_2_02:119]
Non-GAAP-2

[0000068505-25-000022:8k_2_02:120]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:121]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-25-000022:8k_2_02:122]
(In millions)

[0000068505-25-000022:8k_2_02:123]
|  |  |  |  | Three Months Ended |  |  |
|  |  | Statement Line |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 430 |  |  | $ | (39) |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 66 |  |  | $ | 56 |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 37 |  |  | 39 |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 17 |  |  | 10 |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 14 |  |  | 1 |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 6 |  |  | 4 |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 5 |  |  | 2 |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 4 |  |  | 6 |  |  |  |  |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 1 |  |  | 1 |  |  |  |  |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | 585 |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | — |  |  | 3 |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | 3 |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | (10) |  |  | — |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 140 |  |  | $ | 710 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 30 |  | 189 |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 110 |  | 521 |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 540 |  |  | $ | 482 |  |  |  |  |  |

[0000068505-25-000022:8k_2_02:124]
Calculation of Non-GAAP Tax Rate

[0000068505-25-000022:8k_2_02:125]
(In millions)

[0000068505-25-000022:8k_2_02:126]
|  |  | Three Months Ended |  |  |
|  |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Net earnings before income taxes |  | $ | 547 |  |  | $ | (90) |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 140 |  |  | 710 |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 687 |  |  | 620 |  |  |  |  |  |
| Income tax expense (benefit) |  | 115 |  |  | (52) |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 30 |  |  | 189 |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | $ | 145 |  |  | $ | 137 |  |  |  |  |  |
| Non-GAAP Tax rate |  | 21.1 | % |  | 22.1 | % |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-25-000022:8k_2_02:127]
14

[0000068505-25-000022:8k_2_02:128]
Non-GAAP-2

[0000068505-25-000022:8k_2_02:129]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-25-000022:8k_2_02:130]
|  |  |  |  | Three Months Ended |  |  |
|  |  | Statement Line |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 2.53 |  |  | $ | (0.23) |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.39 |  |  | $ | 0.32 |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.22 |  |  | 0.23 |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.10 |  |  | 0.05 |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.08 |  |  | 0.01 |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.03 |  |  | 0.02 |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 0.03 |  |  | 0.01 |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 0.02 |  |  | 0.03 |  |  |  |  |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 0.01 |  |  | 0.01 |  |  |  |  |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | 3.42 |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | — |  |  | 0.02 |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | 0.02 |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | (0.06) |  |  | — |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.82 |  |  | $ | 4.14 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.17 |  | 1.10 |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.65 |  | 3.04 |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 3.18 |  |  | $ | 2.81 |  |  |  |  |  |
| GAAP Diluted Weighted Average Common Shares |  |  |  | 169.8 |  |  | 166.3 |  |  |  |  |  |
| Adjusted for dilutive shares outstanding** |  |  |  | — |  |  | 5.0 |  |  |  |  |  |
| Non-GAAP Diluted Weighted Average Common Shares |  |  |  | 169.8 |  |  | 171.3 |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |
| ** Under U.S. GAAP, the accounting for a net loss from continuing operations results in the presentation of diluted earnings per share equal to basic earnings per share, as any increase in basic shares would be anti-dilutive to earnings per share. As a result of the highlighted items identified during Q1 2024, the Company reported a net loss from continuing operations for the three months ended March 30, 2024 within our GAAP Condensed Consolidated Statement of Operations, while reporting earnings on a non-GAAP basis over the same periods. An adjustment is reflected to correct for the dilution of 5 million dilutive shares outstanding in Q1 2024. |

[0000068505-25-000022:8k_2_02:131]
Non-GAAP-3

[0000068505-25-000022:8k_2_02:132]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:133]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-25-000022:8k_2_02:134]
(In millions)

[0000068505-25-000022:8k_2_02:135]
|  |  | Three Months Ended |
|  |  | March 29, 2025 |  | March 30, 2024 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Operating earnings ("OE") |  | $ | 352 |  |  | $ | 230 |  |  | $ | 582 |  |  | $ | 310 |  |  | $ | 209 |  |  | $ | 519 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 48 |  |  | 18 |  |  | 66 |  |  | 39 |  |  | 17 |  |  | 56 |  |
| Intangible assets amortization expense |  | 16 |  |  | 21 |  |  | 37 |  |  | 9 |  |  | 30 |  |  | 39 |  |
| Reorganization of business charges |  | 12 |  |  | 5 |  |  | 17 |  |  | 8 |  |  | 2 |  |  | 10 |  |
| Hytera-related legal expenses |  | 14 |  |  | — |  |  | 14 |  |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition-related transaction fees |  | — |  |  | 6 |  |  | 6 |  |  | — |  |  | 4 |  |  | 4 |  |
| Legal settlements |  | 2 |  |  | 2 |  |  | 4 |  |  | 1 |  |  | 5 |  |  | 6 |  |
| Operating lease asset impairments |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Gain on Hytera legal settlement |  | (10) |  |  | — |  |  | (10) |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 82 |  |  | 52 |  |  | 134 |  |  | 60 |  |  | 59 |  |  | 119 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 434 |  |  | $ | 282 |  |  | $ | 716 |  |  | $ | 370 |  |  | $ | 268 |  |  | $ | 638 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 22.8 | % |  | 23.4 | % |  | 23.0 | % |  | 20.8 | % |  | 23.2 | % |  | 21.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.1 | % |  | 28.7 | % |  | 28.3 | % |  | 24.8 | % |  | 29.8 | % |  | 26.7 | % |

[0000068505-25-000022:8k_2_02:136]
16

[0000068505-25-000022:8k_2_02:137]
Non-GAAP-4

[0000068505-25-000022:8k_2_02:138]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000022:8k_2_02:139]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-25-000022:8k_2_02:140]
(In millions)

[0000068505-25-000022:8k_2_02:141]
|  |  | Three Months Ended |  |  |
|  |  | March 29, 2025 |  | March 30, 2024 |  | % Change |
| Net sales |  | $ | 2,528 |  |  | $ | 2,389 |  |  | 6 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 32 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,496 |  |  | $ | 2,389 |  |  | 4 | % |

[0000068505-25-000022:8k_2_02:142]
17
