# MSI 8-K — 0001193125-15-173187 filed 2015-05-06

## item codes, every 8-K on or before 2015-05-06

- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2015-05-06

- none on or before 2015-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-173187:8k_2_02:1]
EX-99.1
2
d921520dex991.htm
EX-99.1

[0001193125-15-173187:8k_2_02:2]
EX-99.1

[0001193125-15-173187:8k_2_02:3]
Exhibit 99.1

[0001193125-15-173187:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2015 Financial Results

[0001193125-15-173187:8k_2_02:5]
|  | • |  | Sales of $1.2 billion, flat from a year ago, including $40 million of unfavorable foreign currency impact |

[0001193125-15-173187:8k_2_02:6]
|  | • |  | North America sales grew 6 percent, driven by Product segment sales |

[0001193125-15-173187:8k_2_02:7]
|  | • |  | GAAP earnings per share (EPS) from continuing operations1 of $0.40 |

[0001193125-15-173187:8k_2_02:8]
|  | • |  | Non-GAAP2 earnings per share (EPS) from continuing operations of $0.38 driven by lower overall operating expenses |

[0001193125-15-173187:8k_2_02:9]
|  | • |  | Generated $151 million in operating cash flow |

[0001193125-15-173187:8k_2_02:10]
|  | • |  | Returned $728 million to shareholders through share repurchases and cash dividends, including the repurchase of $653 million of stock in the quarter |

[0001193125-15-173187:8k_2_02:11]
SCHAUMBURG, Ill. – May 6, 2015 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first
quarter of 2015. Click here for a printable news release and financial tables.

[0001193125-15-173187:8k_2_02:12]
SUPPORTING QUOTE

[0001193125-15-173187:8k_2_02:13]
“The company delivered strong double-digit profitability growth in the first quarter, driven primarily by strength in our North America business and a
leaner cost structure,” said Greg Brown, chairman and CEO of Motorola Solutions. “We remain committed to driving growth through innovation as well as improving operating leverage and cash flow generation.”

[0001193125-15-173187:8k_2_02:14]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0001193125-15-173187:8k_2_02:15]
|  |  | Q1 2015 |  |  | Q1 2014 |  |  | % Change |  |
| Sales |  | $ | 1,223 |  |  | $ | 1,228 |  |  |  | 0 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 119 |  |  | $ | 107 |  |  |  | 11 | % |
| % of Sales |  |  | 9.7 | % |  |  | 8.7 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.40 |  |  | $ | 0.33 |  |  |  | 21 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 156 |  |  | $ | 126 |  |  |  | 24 | % |
| % of Sales |  |  | 12.8 | % |  |  | 10.3 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.38 |  |  | $ | 0.28 |  |  |  | 36 | % |
| Product Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 758 |  |  | $ | 752 |  |  |  | 1 | % |
| GAAP Operating Earnings |  | $ | 64 |  |  | $ | 39 |  |  |  | 64 | % |
| % of Sales |  |  | 8.4 | % |  |  | 5.2 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 90 |  |  | $ | 52 |  |  |  | 73 | % |
| % of Sales |  |  | 11.9 | % |  |  | 6.9 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 465 |  |  | $ | 476 |  |  |  | -2 | % |
| GAAP Operating Earnings |  | $ | 55 |  |  | $ | 68 |  |  |  | -19 | % |
| % of Sales |  |  | 11.8 | % |  |  | 14.3 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 66 |  |  | $ | 74 |  |  |  | -11 | % |
| % of Sales |  |  | 14.2 | % |  |  | 15.5 | % |  |  |  |  |

[0001193125-15-173187:8k_2_02:16]
Non-GAAP financial information excludes the after-tax impact of approximately $0.02 per diluted share related to
share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0001193125-15-173187:8k_2_02:17]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-15-173187:8k_2_02:18]
|  | • |  | Revenue – Sales were flat, including $40 million of unfavorable foreign currency impact. These results reflect 6 percent growth in North America. Product sales grew 1 percent driven primarily by an improvement in device sales, while Services declined 2 percent driven by lower iDEN and system integration sales. |

[0001193125-15-173187:8k_2_02:19]
|  | • |  | Operating margin – GAAP operating margin was 9.7 percent of sales in the first quarter of 2015, compared with 8.7 percent in the first quarter of 2014; non-GAAP operating margin was 12.8 percent of sales, compared with 10.3 percent in the first quarter of 2014, reflecting $60 million in lower operating expenses compared with the first quarter of 2014, due largely to cost reduction and simplification initiatives across all categories as well as lower pension expense and a stronger dollar. |

[0001193125-15-173187:8k_2_02:20]
|  | • |  | Taxes – The first-quarter GAAP effective tax rate was 31 percent. This compares with a tax rate of 4 percent in the first quarter of 2014, which included $30 million of net tax benefit associated with the net reduction in previously unrecognized tax benefits. The first-quarter non-GAAP tax rate was 29 percent, compared with a tax rate of 33 percent in the first quarter of 2014. The full-year non-GAAP tax rate is expected to be approximately 33 percent. The full-year cash tax rate is expected to be approximately 15 percent. |

[0001193125-15-173187:8k_2_02:21]
|  | • |  | Cash flow – The company generated $151 million in operating cash from continuing operations during the quarter, reflecting an increase of $139 million over the prior year. The increase was largely driven by working capital improvements. |

[0001193125-15-173187:8k_2_02:22]
|  | • |  | Cash and cash equivalents – The company ended the quarter with cash and cash equivalents of $3.4 billion, reflecting a net debt position of $43 million3. The company repurchased $653 million of its common stock in the first quarter and paid $75 million in cash dividends. |

[0001193125-15-173187:8k_2_02:23]
KEY HIGHLIGHTS

[0001193125-15-173187:8k_2_02:24]
Strategic wins

[0001193125-15-173187:8k_2_02:25]
|  | • |  | $135 million system upgrade and multi-year managed services contract for the South Australia Government Radio Network that integrates voice and data capabilities, and covers more than 20 first responder agencies |

[0001193125-15-173187:8k_2_02:26]
|  | • |  | $46 million contract with $32 million of services for multi-year software upgrades and maintenance services with Hamilton County, Ohio |

[0001193125-15-173187:8k_2_02:27]
|  | • |  | $20 million contract for both expansion services and core products in Columbus, Georgia, that incorporates Smart Public Safety Services and P25 equipment and software |

[0001193125-15-173187:8k_2_02:28]
|  | • |  | $19 million contract to provide 25,000 digital TETRA radios, accessories, training and logistics services to the Central Procurement Office of Schleswig-Holstein AöR (GMSH) Germany |

[0001193125-15-173187:8k_2_02:29]
|  | • |  | A Real Time Crime Center win with the St. Louis Metropolitan Police Department to deploy an intelligence-led policing solution that integrates video management systems with computer-aided dispatch and public safety applications |

[0001193125-15-173187:8k_2_02:30]
Innovation and investments in growth

[0001193125-15-173187:8k_2_02:31]
|  | • |  | Completed two acquisitions in the Smart Public Safety business: Emergency CallWorks and PublicEngines, leading providers of software-based solutions that solidify Motorola Solutions’ offerings in command and control, next-generation 9-1-1 call center and intelligent-led policing solutions that enable predictive policing and citizen engagement capabilities for law enforcement and government entities |

[0001193125-15-173187:8k_2_02:32]
|  | • |  | Invested in three businesses that complement the company’s Smart Public Safety technology portfolio, through the company’s venture capital arm |

[0001193125-15-173187:8k_2_02:33]
|  | • |  | Announced the APX8000, the first all-band, Wi-Fi-enabled APX P25 portable two-way radio |

[0001193125-15-173187:8k_2_02:34]
|  | • |  | Upgraded the MTP3000 Series TETRA radios to meet mission-critical demands for improved ruggedness, coverage, encryption and other public safety-specific functionality |

[0001193125-15-173187:8k_2_02:35]
BUSINESS OUTLOOK4

[0001193125-15-173187:8k_2_02:36]
|  | • |  | Second quarter 2015 – Motorola Solutions expects a revenue decline of 3 to 5 percent compared with the second quarter of 2014. This assumes a $45 million5 unfavorable currency impact, which translates to revenue of flat to down 2 percent in constant currency. The company expects non-GAAP earnings per share from continuing operations in the range of $0.51 to $0.56 per share. |

[0001193125-15-173187:8k_2_02:37]
|  | • |  | Full-year 2015 – The company revenue outlook remains unchanged as revenue is expected to be flat to down 2 percent compared to 2014. This outlook translates to revenue growth of 1 to 3 percent in constant currency. The company now expects non-GAAP earnings per share from continuing operations in the range of $3.20 to $3.40 per share. |

[0001193125-15-173187:8k_2_02:38]
CONFERENCE CALL AND WEBCAST

[0001193125-15-173187:8k_2_02:39]
Motorola Solutions will host
its quarterly conference call beginning at 7 a.m. U.S. Central Daylight Time (8 a.m. U.S. Eastern Daylight Time) Wednesday, May 6. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-15-173187:8k_2_02:40]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0001193125-15-173187:8k_2_02:41]
A comparison of results from operations is as follows:

[0001193125-15-173187:8k_2_02:42]
|  |  | Q1 2015 |  |  | Q1 2014 |  |
| Net sales |  | $ | 1,223 |  |  | $ | 1,228 |  |
| Gross margin |  |  | 548 |  |  |  | 577 |  |
| Operating earnings |  |  | 119 |  |  |  | 107 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations |  |  | 87 |  |  |  | 85 |  |
| Net earnings |  |  | 74 |  |  |  | 127 |  |
| Diluted EPS from continuing operations |  | $ | 0.40 |  |  | $ | 0.33 |  |
| Weighted average diluted common shares outstanding |  |  | 217.8 |  |  |  | 258.3 |  |

[0001193125-15-173187:8k_2_02:43]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-15-173187:8k_2_02:44]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the first quarter of 2015.

[0001193125-15-173187:8k_2_02:45]
| (per diluted common share) |  | Q1 2015 |  |
| GAAP Earnings from Continuing Operations |  | $ | 0.40 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense and intangible amortization |  |  | 0.06 |  |
| Reorganization of business charges |  |  | 0.05 |  |
| Gain on Sale of equity investment |  |  | (0.13 | ) |
| Total Highlighted Items |  |  | (0.02 | ) |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 0.38 |  |

[0001193125-15-173187:8k_2_02:46]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-15-173187:8k_2_02:47]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-15-173187:8k_2_02:48]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-15-173187:8k_2_02:49]
Share-based compensation expense: The company has
excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation
contributed to the revenue earned during the periods

[0001193125-15-173187:8k_2_02:50]
presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily
because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-15-173187:8k_2_02:51]
Intangible assets amortization
expense: The company has excluded intangible assets amortization expense from its Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance
excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of
intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-15-173187:8k_2_02:52]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press
release.

[0001193125-15-173187:8k_2_02:53]
BUSINESS RISKS

[0001193125-15-173187:8k_2_02:54]
disruption in the company’s IT systems, those of our partners or suppliers or those we sell to or operate or maintain for our customers; (7) the outcome of ongoing and future tax
matters; (8) the company’s ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (9) risks
related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (10) the impact on the company’s performance and financial results from strategic acquisitions or divestitures;
(11) risks related to the company’s manufacturing and business operations in foreign countries; (12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems;
(13) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (14) the ownership
of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company’s intellectual property to others, as well as
expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the
impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow;
(19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or
regulations; (21) negative consequences from the company’s outsourcing of various activities, including certain business operations, information technology and administrative functions; (22) the impact of the sale of the
company’s enterprise legacy information systems, including components of the enterprise resource planning (ERP) system and the implementation of a new ERP system; and (23) the company’s ability to return proceeds of the sale of the
Enterprise business to shareholders and the timing thereof. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-15-173187:8k_2_02:55]
DEFINITIONS

[0001193125-15-173187:8k_2_02:56]
| 1 | Amounts attributable to Motorola Solutions, Inc. common shareholders. |

[0001193125-15-173187:8k_2_02:57]
| 2 | Non-GAAP financial information excludes from GAAP results the effects of share-based compensation expense, intangible assets amortization expense and highlighted items. |

[0001193125-15-173187:8k_2_02:58]
| 3 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-15-173187:8k_2_02:59]
| 4 | Business outlook excludes share-based compensation expense, intangible assets amortization expense and charges associated with items typically highlighted by the company in its quarterly earnings releases. |

[0001193125-15-173187:8k_2_02:60]
| 5 | Based on currency rates as of May 4, 2015. |

[0001193125-15-173187:8k_2_02:61]
ABOUT
MOTOROLA SOLUTIONS

[0001193125-15-173187:8k_2_02:62]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety
and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-15-173187:8k_2_02:63]
MEDIA CONTACT

[0001193125-15-173187:8k_2_02:64]
Kurt Ebenhoch

[0001193125-15-173187:8k_2_02:65]
Motorola Solutions

[0001193125-15-173187:8k_2_02:66]
+1 847-576-1341

[0001193125-15-173187:8k_2_02:67]
kurt.ebenhoch@motorolasolutions.com

[0001193125-15-173187:8k_2_02:68]
INVESTOR CONTACTS

[0001193125-15-173187:8k_2_02:69]
Shep Dunlap

[0001193125-15-173187:8k_2_02:70]
Motorola Solutions

[0001193125-15-173187:8k_2_02:71]
+1 847-576-6899

[0001193125-15-173187:8k_2_02:72]
shep.dunlap@motorolasolutions.com

[0001193125-15-173187:8k_2_02:73]
Chris Kutsor

[0001193125-15-173187:8k_2_02:74]
Motorola Solutions

[0001193125-15-173187:8k_2_02:75]
+1 847-576-4995

[0001193125-15-173187:8k_2_02:76]
chris.kutsor@motorolasolutions.com

[0001193125-15-173187:8k_2_02:77]
MOTOROLA, MOTOROLA
SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners.
©2015 Motorola Solutions, Inc. All rights reserved.

[0001193125-15-173187:8k_2_02:78]
GAAP-1

[0001193125-15-173187:8k_2_02:79]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:80]
Condensed Consolidated Statements of Operations

[0001193125-15-173187:8k_2_02:81]
(In millions, except per share amounts)

[0001193125-15-173187:8k_2_02:82]
|  |  | Three Months Ended |  |
|  |  | April 4, 2015 |  |  | March 29, 2014 |  |
| Net sales from products |  | $ | 758 |  |  | $ | 752 |  |
| Net sales from services |  |  | 465 |  |  |  | 476 |  |
| Net sales |  |  | 1,223 |  |  |  | 1,228 |  |
| Costs of products sales |  |  | 359 |  |  |  | 350 |  |
| Costs of services sales |  |  | 316 |  |  |  | 301 |  |
| Costs of sales |  |  | 675 |  |  |  | 651 |  |
| Gross margin |  |  | 548 |  |  |  | 577 |  |
| Selling, general and administrative expenses |  |  | 256 |  |  |  | 307 |  |
| Research and development expenditures |  |  | 159 |  |  |  | 174 |  |
| Other charges (income) |  |  | 12 |  |  |  | (12 | ) |
| Intangibles amortization |  |  | 2 |  |  |  | 1 |  |
| Operating earnings |  |  | 119 |  |  |  | 107 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (40 | ) |  |  | (25 | ) |
| Gains on sales of investments and businesses, net |  |  | 46 |  |  |  | 7 |  |
| Other |  |  | 3 |  |  |  | — |  |
| Total other income (expense) |  |  | 9 |  |  |  | (18 | ) |
| Earnings from continuing operations before income taxes |  |  | 128 |  |  |  | 89 |  |
| Income tax expense |  |  | 40 |  |  |  | 4 |  |
| Earnings from continuing operations |  |  | 88 |  |  |  | 85 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (13 | ) |  |  | 42 |  |
| Net earnings |  |  | 75 |  |  |  | 127 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 74 |  |  | $ | 127 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 87 |  |  | $ | 85 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (13 | ) |  |  | 42 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 74 |  |  | $ | 127 |  |
| Earnings (loss) per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.40 |  |  | $ | 0.33 |  |
| Discontinued operations |  |  | (0.06 | ) |  |  | 0.17 |  |
|  |  | $ | 0.34 |  |  | $ | 0.50 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.40 |  |  | $ | 0.33 |  |
| Discontinued operations |  |  | (0.06 | ) |  |  | 0.16 |  |
|  |  | $ | 0.34 |  |  | $ | 0.49 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 215.3 |  |  |  | 254.1 |  |
| Diluted |  |  | 217.8 |  |  |  | 258.3 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 62.0 | % |  |  | 61.2 | % |
| Net sales from services |  |  | 38.0 | % |  |  | 38.8 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 47.4 | % |  |  | 46.5 | % |
| Costs of services sales |  |  | 68.0 | % |  |  | 63.2 | % |
| Costs of sales |  |  | 55.2 | % |  |  | 53.0 | % |
| Gross margin |  |  | 44.8 | % |  |  | 47.0 | % |
| Selling, general and administrative expenses |  |  | 20.9 | % |  |  | 25.0 | % |
| Research and development expenditures |  |  | 13.0 | % |  |  | 14.2 | % |
| Other charges (income) |  |  | 1.0 | % |  |  | -1.0 | % |
| Intangibles amortization |  |  | 0.2 | % |  |  | 0.1 | % |
| Operating earnings |  |  | 9.7 | % |  |  | 8.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -3.3 | % |  |  | -2.0 | % |
| Gains on sales of investments and businesses, net |  |  | 3.8 | % |  |  | 0.6 | % |
| Other |  |  | 0.2 | % |  |  | 0.0 | % |
| Total other income (expense) |  |  | 0.7 | % |  |  | -1.5 | % |
| Earnings from continuing operations before income taxes |  |  | 10.5 | % |  |  | 7.2 | % |
| Income tax expense |  |  | 3.3 | % |  |  | 0.3 | % |
| Earnings from continuing operations |  |  | 7.2 | % |  |  | 6.9 | % |
| Earnings (loss) from discontinued operations, net of tax |  |  | -1.1 | % |  |  | 3.4 | % |
| Net earnings |  |  | 6.1 | % |  |  | 10.3 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | 0.0 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 6.1 | % |  |  | 10.3 | % |

[0001193125-15-173187:8k_2_02:83]
| * | Percentages may not add up due to rounding |

[0001193125-15-173187:8k_2_02:84]
GAAP-2

[0001193125-15-173187:8k_2_02:85]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:86]
Condensed Consolidated Balance Sheets

[0001193125-15-173187:8k_2_02:87]
(In millions)

[0001193125-15-173187:8k_2_02:88]
|  |  | April 4,2015 |  |  | December 31,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,353 |  |  | $ | 3,954 |  |
| Accounts receivable, net |  |  | 1,084 |  |  |  | 1,409 |  |
| Inventories, net |  |  | 381 |  |  |  | 345 |  |
| Deferred income taxes |  |  | 416 |  |  |  | 431 |  |
| Other current assets |  |  | 650 |  |  |  | 740 |  |
| Total current assets |  |  | 5,884 |  |  |  | 6,879 |  |
| Property, plant and equipment, net |  |  | 530 |  |  |  | 549 |  |
| Investments |  |  | 285 |  |  |  | 316 |  |
| Deferred income taxes |  |  | 2,179 |  |  |  | 2,151 |  |
| Goodwill |  |  | 390 |  |  |  | 383 |  |
| Other assets |  |  | 157 |  |  |  | 145 |  |
| Total assets |  | $ | 9,425 |  |  | $ | 10,423 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 437 |  |  |  | 540 |  |
| Accrued liabilities |  |  | 1,536 |  |  |  | 1,706 |  |
| Total current liabilities |  |  | 1,977 |  |  |  | 2,250 |  |
| Long-term debt |  |  | 3,392 |  |  |  | 3,396 |  |
| Other liabilities |  |  | 1,962 |  |  |  | 2,011 |  |
| Total Motorola Solutions, Inc. stockholders’ equity |  |  | 2,086 |  |  |  | 2,735 |  |
| Noncontrolling interests |  |  | 8 |  |  |  | 31 |  |
| Total liabilities and stockholders’ equity |  | $ | 9,425 |  |  | $ | 10,423 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (43 | ) |  | $ | 554 |  |

[0001193125-15-173187:8k_2_02:89]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-15-173187:8k_2_02:90]
GAAP-3

[0001193125-15-173187:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:92]
Condensed Consolidated Statements of Cash Flows

[0001193125-15-173187:8k_2_02:93]
(In millions)

[0001193125-15-173187:8k_2_02:94]
|  |  | Three Months Ended |  |
|  |  | April 4, 2015 |  |  | March 29, 2014 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 74 |  |  | $ | 127 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings |  |  | 75 |  |  |  | 127 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (13 | ) |  |  | 42 |  |
| Earnings from continuing operations, net of tax |  |  | 88 |  |  |  | 85 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 41 |  |  |  | 40 |  |
| Gain on sale of building and land |  |  | — |  |  |  | (21 | ) |
| Non-cash other charges (income) |  |  | 1 |  |  |  | (3 | ) |
| Share-based compensation expense |  |  | 21 |  |  |  | 28 |  |
| Gains on sales of investments and businesses, net |  |  | (46 | ) |  |  | (7 | ) |
| Deferred income taxes |  |  | 23 |  |  |  | 22 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 309 |  |  |  | 160 |  |
| Inventories |  |  | (44 | ) |  |  | (12 | ) |
| Other current assets |  |  | 26 |  |  |  | 16 |  |
| Accounts payable and accrued liabilities |  |  | (252 | ) |  |  | (175 | ) |
| Other assets and liabilities |  |  | (16 | ) |  |  | (121 | ) |
| Net cash provided by operating activities from continuing operations |  |  | 151 |  |  |  | 12 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (74 | ) |  |  | (4 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 88 |  |  |  | 11 |  |
| Capital expenditures |  |  | (33 | ) |  |  | (41 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 1 |  |  |  | 24 |  |
| Net cash used for investing activities from continuing operations |  |  | (18 | ) |  |  | (10 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (1 | ) |
| Net proceeds from issuance of debt |  |  | — |  |  |  | 4 |  |
| Issuance of common stock |  |  | 46 |  |  |  | 14 |  |
| Repurchase of common stock |  |  | (653 | ) |  |  | (57 | ) |
| Excess tax benefit from share-based compensation |  |  | 1 |  |  |  | 5 |  |
| Payments of dividends |  |  | (75 | ) |  |  | (79 | ) |
| Distributions from discontinued operations |  |  | — |  |  |  | 26 |  |
| Net cash used for financing activities from continuing operations |  |  | (682 | ) |  |  | (88 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | — |  |  |  | 34 |  |
| Net cash used for investing activities from discontinued operations |  |  | — |  |  |  | (8 | ) |
| Net cash used for financing activities from discontinued operations |  |  | — |  |  |  | (26 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (52 | ) |  |  | 2 |  |
| Net decrease in cash and cash equivalents |  |  | (601 | ) |  |  | (84 | ) |
| Cash and cash equivalents, beginning of period |  |  | 3,954 |  |  |  | 3,225 |  |
| Cash and cash equivalents, end of period |  | $ | 3,353 |  |  | $ | 3,141 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 118 |  |  | $ | (29 | ) |

[0001193125-15-173187:8k_2_02:95]
| * | Free cash flow = Net cash provided by operating activities - Capital expenditures |

[0001193125-15-173187:8k_2_02:96]
GAAP-4

[0001193125-15-173187:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:98]
Segment Information

[0001193125-15-173187:8k_2_02:99]
(In
millions)

[0001193125-15-173187:8k_2_02:100]
Net Sales

[0001193125-15-173187:8k_2_02:101]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 4,2015 |  |  | March 29,2014 |  |  | % Change |  |
| Products |  | $ | 758 |  |  | $ | 752 |  |  |  | 1 | % |
| Services |  |  | 465 |  |  |  | 476 |  |  |  | -2 | % |
| Total Motorola Solutions |  | $ | 1,223 |  |  | $ | 1,228 |  |  |  | 0 | % |

[0001193125-15-173187:8k_2_02:102]
Operating Earnings

[0001193125-15-173187:8k_2_02:103]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 4,2015 |  |  | March 29,2014 |  |  | % Change |  |
| Products |  | $ | 64 |  |  | $ | 39 |  |  |  | 64 | % |
| Services |  |  | 55 |  |  |  | 68 |  |  |  | -19 | % |
| Total Motorola Solutions |  | $ | 119 |  |  | $ | 107 |  |  |  | 11 | % |

[0001193125-15-173187:8k_2_02:104]
Operating Earnings %

[0001193125-15-173187:8k_2_02:105]
|  |  | Three Months Ended |  |
|  |  | April 4,2015 |  |  | March 29,2014 |  |
| Products |  |  | 8.4 | % |  |  | 5.2 | % |
| Services |  |  | 11.8 | % |  |  | 14.3 | % |
| Total Motorola Solutions |  |  | 9.7 | % |  |  | 8.7 | % |

[0001193125-15-173187:8k_2_02:106]
GAAP-5

[0001193125-15-173187:8k_2_02:107]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:108]
Regional Revenue Information

[0001193125-15-173187:8k_2_02:109]
(In millions)

[0001193125-15-173187:8k_2_02:110]
During the first quarter of
2015, we restructured our regions operationally separating the Asia Pacific and Middle East region into two regions which are now reflected as Asia Pacific (“AP”) and Middle East (“ME”). As a result of this change, our sales
force is better aligned and focused on the growth opportunities within each geographic region. Accordingly, we now report net sales in the following five geographic regions: North America, Latin America, Europe and Africa (“EA”), AP, and
ME.

[0001193125-15-173187:8k_2_02:111]
The Company’s regional net sales under the new regional alignment and as previously reported were as follows:

[0001193125-15-173187:8k_2_02:112]
|  |  | Revised regional sales |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |  | FY |  |  | FY |  |  | FY |  |
|  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| North America |  |  | 727 |  |  |  | 841 |  |  |  | 880 |  |  |  | 1,151 |  |  |  | 3,599 |  |  |  | 3,894 |  |  |  | 3,905 |  |
| Latin America |  |  | 125 |  |  |  | 134 |  |  |  | 109 |  |  |  | 140 |  |  |  | 508 |  |  |  | 518 |  |  |  | 577 |  |
| EA |  |  | 214 |  |  |  | 231 |  |  |  | 277 |  |  |  | 312 |  |  |  | 1,034 |  |  |  | 988 |  |  |  | 858 |  |
| AP |  |  | 141 |  |  |  | 168 |  |  |  | 151 |  |  |  | 185 |  |  |  | 645 |  |  |  | 749 |  |  |  | 816 |  |
| ME |  |  | 21 |  |  |  | 19 |  |  |  | 19 |  |  |  | 36 |  |  |  | 95 |  |  |  | 78 |  |  |  | 113 |  |
|  |  | $ | 1,228 |  |  | $ | 1,393 |  |  | $ | 1,436 |  |  | $ | 1,824 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |  | $ | 6,269 |  |
|  |  | Regional sales as previously reported |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |  | FY |  |  | FY |  |  | FY |  |
|  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| North America |  |  | 727 |  |  |  | 841 |  |  |  | 880 |  |  |  | 1,151 |  |  |  | 3,599 |  |  |  | 3,894 |  |  |  | 3,905 |  |
| Latin America |  |  | 125 |  |  |  | 134 |  |  |  | 109 |  |  |  | 140 |  |  |  | 508 |  |  |  | 518 |  |  |  | 577 |  |
| EA |  |  | 214 |  |  |  | 231 |  |  |  | 277 |  |  |  | 312 |  |  |  | 1,034 |  |  |  | 988 |  |  |  | 858 |  |
| APME |  |  | 162 |  |  |  | 187 |  |  |  | 170 |  |  |  | 221 |  |  |  | 740 |  |  |  | 827 |  |  |  | 929 |  |
|  |  | $ | 1,228 |  |  | $ | 1,393 |  |  | $ | 1,436 |  |  | $ | 1,824 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |  | $ | 6,269 |  |

[0001193125-15-173187:8k_2_02:113]
Non-GAAP-1

[0001193125-15-173187:8k_2_02:114]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:115]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-15-173187:8k_2_02:116]
Q1 2015

[0001193125-15-173187:8k_2_02:117]
| Highlighted Items |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 21 |  |  | $ | 7 |  |  | $ | 14 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 14 |  |  |  | 4 |  |  |  | 10 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of equity investment |  | Gains on sales of investments and businesses, net |  |  | (46 | ) |  |  | (17 | ) |  |  | (29 | ) |  |  | (0.13 | ) |
| Total impact on Net earnings |  |  |  | $ | (9 | ) |  | $ | (5 | ) |  | $ | (4 | ) |  | $ | (0.02 | ) |

[0001193125-15-173187:8k_2_02:118]
Non-GAAP-2

[0001193125-15-173187:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:120]
Non-GAAP Segment Information

[0001193125-15-173187:8k_2_02:121]
(In millions)

[0001193125-15-173187:8k_2_02:122]
Net
Sales

[0001193125-15-173187:8k_2_02:123]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 4,2015 |  |  | March 29,2014 |  |  | % Change |  |
| Products |  | $ | 758 |  |  | $ | 752 |  |  |  | 1 | % |
| Services |  |  | 465 |  |  |  | 476 |  |  |  | -2 | % |
| Total Motorola Solutions |  | $ | 1,223 |  |  | $ | 1,228 |  |  |  | 0 | % |

[0001193125-15-173187:8k_2_02:124]
Non-GAAP Operating Earnings

[0001193125-15-173187:8k_2_02:125]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 4,2015 |  |  | March 29,2014 |  |  | % Change |  |
| Products |  | $ | 90 |  |  | $ | 52 |  |  |  | 73 | % |
| Services |  |  | 66 |  |  |  | 74 |  |  |  | -11 | % |
| Total Motorola Solutions |  | $ | 156 |  |  | $ | 126 |  |  |  | 24 | % |

[0001193125-15-173187:8k_2_02:126]
Non-GAAP Operating Earnings %

[0001193125-15-173187:8k_2_02:127]
|  |  | Three Months Ended |  |
|  |  | April 4, |  |  | March 29, |  |
|  |  | 2015 |  |  | 2014 |  |
| Products |  |  | 11.9 | % |  |  | 6.9 | % |
| Services |  |  | 14.2 | % |  |  | 15.5 | % |
| Total Motorola Solutions |  |  | 12.8 | % |  |  | 10.3 | % |

[0001193125-15-173187:8k_2_02:128]
Non-GAAP-3

[0001193125-15-173187:8k_2_02:129]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-173187:8k_2_02:130]
Operating Earnings after Non-GAAP Adjustments

[0001193125-15-173187:8k_2_02:131]
Q1 2015

[0001193125-15-173187:8k_2_02:132]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,223 |  |  | $ | 758 |  |  | $ | 465 |  |
| Operating earnings (“OE”) |  | $ | 119 |  |  | $ | 64 |  |  | $ | 55 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21 |  |  |  | 14 |  |  |  | 7 |  |
| Reorganization of business charges |  |  | 14 |  |  |  | 10 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Total above-OE non-GAAP adjustments |  |  | 37 |  |  |  | 26 |  |  |  | 11 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 156 |  |  | $ | 90 |  |  | $ | 66 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 9.7 | % |  |  | 8.4 | % |  |  | 11.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 12.8 | % |  |  | 11.9 | % |  |  | 14.2 | % |
