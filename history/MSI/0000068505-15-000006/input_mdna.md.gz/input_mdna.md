# MSI MD&A — 0000068505-15-000006


## mdna

[0000068505-15-000006:mdna:1]
[same as prior period, unchanged from 0000068505-14-000016:mdna:1]

[0000068505-15-000006:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three months ended April 4, 2015 and March 29, 2014, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2014.

[0000068505-15-000006:mdna:3]
[same as prior period, unchanged from 0000068505-14-000016:mdna:3]

[0000068505-15-000006:mdna:4]
[same as prior period, unchanged from 0000068505-14-000016:mdna:6]

[0000068505-15-000006:mdna:5]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 14,000 employees worldwide, based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-15-000006:mdna:6]
We conduct our business globally and manage it by two segments:

[0000068505-15-000006:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the first quarter of 2015, the segment’s net sales were $758 million, representing 62% of our consolidated net sales.

[0000068505-15-000006:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Lifecycle Support services, (iii) Managed services, (iv) Smart Public Safety Solutions, and (v) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications.  Lifecycle Support services includes lifecycle planning, software and hardware maintenance, security patches and upgrades, call center support, network monitoring, and repair services.  Managed services includes managing and operating customer systems and devices at defined services levels. Smart Public Safety Solutions includes software and hardware solutions for our customers' "Command & Control" centers providing video monitoring support, data analytics, and content management with the objective of enabling smart policing. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the first quarter of 2015, the segment’s net sales were $465 million, representing 38% of our consolidated net sales.

[0000068505-15-000006:mdna:9]
Trends Affecting Our Business

[0000068505-15-000006:mdna:10]
Impact of Foreign Exchange Rate Fluctuations: Although we are a global corporation and our net sales are impacted by the strengthening of the U.S. dollar in relation to foreign currencies, primarily the Euro, we expect the overall impact of foreign exchange rate fluctuations on our net earnings to be minimal. The impact of foreign exchange rate fluctuations on net earnings is mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sale, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion of our operating expenses are derived in foreign currencies as a result of our offshore research and development and selling, general, and administrative footprint.

[0000068505-15-000006:mdna:11]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce selling, general, and administrative and research and development expenses during 2015 by approximately $150 million in comparison to 2014.

[0000068505-15-000006:mdna:12]
Growth of Our Services Portfolio: Within the the Services segment we expect to grow software maintenance services, in our Lifecycle Support services portfolio, Managed services, and Smart Public Safety at a higher rate than the rest of the Services portfolio. Overall, the Services segment has a lower gross margin percentage than the Products segment; however, we expect operating margins to be relatively comparable between the Products and Services segments with consolidated operating margins continuing to expand.

[0000068505-15-000006:mdna:13]
iDEN: We have experienced a downward trend in iDEN product and services sales over the last three years due to decreased demand as a result of the dated nature of the technology.  We expect the downward trend to continue as service contracts expire and new technology replaces iDEN equipment in the marketplace.  This trend primarily relates to our Services segment as the majority of iDEN sales are hardware and software maintenance services. The impact of the decline in iDEN sales will impact both revenues and gross margins within the Services segment as iDEN services’ gross margins are generally higher than the remainder of our services portfolio.

[0000068505-15-000006:mdna:14]
Geographic Market Sales

[0000068505-15-000006:mdna:15]
During the first quarter of 2015, we restructured our regions operationally separating the Asia Pacific and Middle East region into two regions which are now reflected as Asia Pacific ("AP") and Middle East ("ME"). As a result of this change, our sales force is better aligned and focused on the growth opportunities within each geographic region. Accordingly, we now report net sales in the following five geographic regions: North America, Latin America, Europe and Africa ("EA"), AP, and ME.  We have updated all periods presented to reflect this change in presentation.

[0000068505-15-000006:mdna:16]
Geographic market sales measured by the locale of the end customer as a percent of total net sales are as follows:

[0000068505-15-000006:mdna:17]
|  | Three Months Ended |  | Year Ended December 31 |
|  | April 4, 2015 |  | March 29, 2014 |  | 2014 |  | 2013 |  | 2012 |
| North America | 63 | % |  | 59 | % |  | 61 | % |  | 63 | % |  | 62 | % |
| Latin America | 8 | % |  | 10 | % |  | 9 | % |  | 8 | % |  | 9 | % |
| EA | 16 | % |  | 18 | % |  | 17 | % |  | 16 | % |  | 14 | % |
| AP | 11 | % |  | 11 | % |  | 11 | % |  | 12 | % |  | 13 | % |
| ME | 2 | % |  | 2 | % |  | 2 | % |  | 1 | % |  | 2 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-15-000006:mdna:18]
First Quarter Summary

[0000068505-15-000006:mdna:19]
| • | Net sales were flat at $1.2 billion in the first quarter of 2015, compared to the first quarter of 2014, reflecting growth of $43 million in North America offset by unfavorable foreign currency fluctuations of $40 million, primarily within EA and AP. |

[0000068505-15-000006:mdna:20]
| • | We generated operating earnings of $119 million, or 10% of net sales, in the first quarter of 2015, compared to $107 million, or 9% of net sales, in the first quarter of 2014. |

[0000068505-15-000006:mdna:21]
| • | We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $87 million, or $0.40 per diluted common share, in the first quarter of 2015, compared to $85 million, or $0.33 per diluted common share, in the first quarter of 2014. The unfavorable impact of foreign currency fluctuations on net sales, was largely offset by foreign exchange rate favorability within cost of sales and operating expenses, resulting in minimal impact to earnings from continuing operations attributable to Motorola Solutions, Inc. |

[0000068505-15-000006:mdna:22]
| • | We generated net cash from operating activities of $151 million during the first quarter of 2015, compared to $12 million of net cash provided by operating activities in the first quarter of 2014. |

[0000068505-15-000006:mdna:23]
| • | We returned $728 million in capital to shareholders through dividends and share repurchases during the first quarter of 2015. |

[0000068505-15-000006:mdna:24]
Highlights for our segments are as follows:

[0000068505-15-000006:mdna:25]
| • | Products: Net sales were $758 million in the first quarter of 2015, an increase of $6 million, or 1%, compared to net sales of $752 million during the first quarter of 2014. On a geographic basis, net sales increased in North America and ME, and decreased in Latin America, EA and AP, compared to the year-ago quarter. |

[0000068505-15-000006:mdna:26]
| • | Services: Net sales were $465 million in the first quarter of 2015, a decrease of $11 million, or 2%, compared to net sales of $476 million in the first quarter of 2014. On a geographic basis, net sales declined in EA, Latin America, and AP and increased in ME, while remaining flat in North America, compared to the year-ago quarter. |

[0000068505-15-000006:mdna:27]
22

[0000068505-15-000006:mdna:28]
[same as prior period, unchanged from 0000068505-14-000016:mdna:22]

[0000068505-15-000006:mdna:29]
|  | Three Months Ended |
| (Dollars in millions, except per share amounts) | April 4, 2015 |  | % ofSales** |  | March 29, 2014 |  | % ofSales** |
| Net sales from products | $ | 758 |  |  |  |  | $ | 752 |  |  |  |
| Net sales from services | 465 |  |  |  |  | 476 |  |  |  |
| Net sales | 1,223 |  |  |  |  | 1,228 |  |  |  |
| Costs of product sales | 359 |  |  | 47.4 | % |  | 350 |  |  | 46.5 | % |
| Costs of services sales | 316 |  |  | 68.0 | % |  | 301 |  |  | 63.2 | % |
| Costs of sales | 675 |  |  |  |  | 651 |  |  |  |
| Gross margin | 548 |  |  | 44.8 | % |  | 577 |  |  | 47.0 | % |
| Selling, general and administrative expenses | 256 |  |  | 20.9 | % |  | 307 |  |  | 25.0 | % |
| Research and development expenditures | 159 |  |  | 13.0 | % |  | 174 |  |  | 14.2 | % |
| Other charges (income) | 14 |  |  | 1.1 | % |  | (11 | ) |  | (0.9 | )% |
| Operating earnings | 119 |  |  | 9.7 | % |  | 107 |  |  | 8.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net | (40 | ) |  | (3.3 | )% |  | (25 | ) |  | (2.0 | )% |
| Gains on sales of investments and businesses, net | 46 |  |  | 3.8 | % |  | 7 |  |  | 0.6 | % |
| Other | 3 |  |  | 0.2 | % |  | — |  |  | — | % |
| Total other income (expense) | 9 |  |  | 0.7 | % |  | (18 | ) |  | (1.5 | )% |
| Earnings from continuing operations before income taxes | 128 |  |  | 10.5 | % |  | 89 |  |  | 7.2 | % |
| Income tax expense | 40 |  |  | 3.3 | % |  | 4 |  |  | 0.3 | % |
| Earnings from continuing operations | 88 |  |  | 7.2 | % |  | 85 |  |  | 6.9 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | — |  |  | — | % |
| Earnings from continuing operations* | 87 |  |  | 7.1 | % |  | 85 |  |  | 6.9 | % |
| Earnings (loss) from discontinued operations, net of tax | (13 | ) |  | (1.1 | )% |  | 42 |  |  | 3.4 | % |
| Net earnings* | $ | 74 |  |  | 6.1 | % |  | $ | 127 |  |  | 10.3 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.40 |  |  |  |  | $ | 0.33 |  |  |  |
| Discontinued operations | (0.06 | ) |  |  |  | 0.16 |  |  |  |
| Earnings per diluted common share* | $ | 0.34 |  |  |  |  | $ | 0.49 |  |  |  |

[0000068505-15-000006:mdna:30]
[same as prior period, unchanged from 0000068505-14-000016:mdna:24]

[0000068505-15-000006:mdna:31]
[same as prior period, unchanged from 0000068505-14-000016:mdna:25]

[0000068505-15-000006:mdna:32]
Results of Operations—Three months ended April 4, 2015 compared to three months ended March 29, 2014

[0000068505-15-000006:mdna:33]
The results of operations for the first quarter of 2015 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-15-000006:mdna:34]
[same as prior period, unchanged from 0000068505-14-000016:mdna:28]

[0000068505-15-000006:mdna:35]
Net sales were $1.2 billion in the first quarter of 2015, a $5 million decrease from the first quarter of 2014. The slight decline in net sales is reflective of growth in North America offset by a decrease in EA and AP primarily as a result of foreign exchange rate unfavorability with a strengthening U.S. dollar. During the first quarter of 2015, net sales in the Products segment increased $6 million and decreased in the Services segment $11 million, compared to the first quarter of 2014.

[0000068505-15-000006:mdna:36]
The $6 million, or 1%, increase in net sales in the Products segment was driven by growth in North America and ME, as a result of higher devices sales, partially offset by a decline in: (i) Latin America, as a result of lower devices and systems sales, (ii) EA, reflecting foreign exchange rate unfavorability and a decrease in systems sales, and (iii) AP, driven by foreign exchange rate fluctuations and lower devices sales. The $11 million, or 2%, decrease in net sales in the Services segment was driven by declines in: (i) EA and AP, primarily as a result of foreign exchange rate unfavorability and, (ii) Latin America, as a result of iDEN services declines, partially offset by an increase in ME, as a result of increased Integration services and Managed services sales, while North America remained flat.

[0000068505-15-000006:mdna:37]
[same as prior period, unchanged from 0000068505-14-000016:mdna:30]

[0000068505-15-000006:mdna:38]
Gross margin was $548 million, or 44.8% of net sales, in the first quarter of 2015, compared to $577 million, or 47.0% of net sales, in the first quarter of 2014. The decrease in gross margin percentage is driven primarily by a decrease in margins within the Services segment while gross margin of the Products segment remained relatively flat.  The decrease in gross margin in the Services segment was primarily driven by: (i) a decrease in Integration services margins as a result of the deployment of certain large projects at lower gross margins and (ii) lower net sales in iDEN services which have a higher gross margin percentage compared to the rest of the services portfolio. Over time we expect Services gross margins in the mid-30% range.

[0000068505-15-000006:mdna:39]
[same as prior period, unchanged from 0000068505-14-000016:mdna:32]

[0000068505-15-000006:mdna:40]
SG&A expenses decreased $51 million to $256 million, or 20.9% of net sales, in the first quarter of 2015, compared to $307 million, or 25.0% of net sales, in the first quarter of 2014. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) the favorable impact of foreign currency exchange rates, and (iii) lower pension expenses.

[0000068505-15-000006:mdna:41]
Research and Development Expenses

[0000068505-15-000006:mdna:42]
R&D expenditures decreased $15 million to $159 million, or 13.0% of net sales, in the first quarter of 2015, compared to $174 million, or 14.2% of net sales, in the first quarter of 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and the movement of employees to lower cost work sites, and (ii) the favorable impact of foreign currency exchange rates.

[0000068505-15-000006:mdna:43]
Other Charges (income)

[0000068505-15-000006:mdna:44]
We recorded net charges of $14 million in Other charges in the first quarter of 2015, compared to net income of $11 million in the first quarter of 2014. The net charges in the first quarter of 2015 included: (i) $12 million of net reorganization of business charges and (ii) $2 million of charges relating to the amortization of intangibles. The net Other income in the first quarter of 2014 of $11 million included: (i) $9 million of net reorganization of business charges and (ii) $1 million of charges relating to the amortization of intangibles, offset by a $21 million gain on the sale of a building and land. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-15-000006:mdna:45]
[same as prior period, unchanged from 0000068505-14-000016:mdna:38]

[0000068505-15-000006:mdna:46]
Net interest expense was $40 million in the first quarter of 2015 and $25 million in the first quarter of 2014. Net interest expense in the first quarter of 2015 includes interest expense of $43 million, partially offset by interest income of $3 million.  Net interest expense in the first quarter of 2014 includes interest expense of $30 million, partially offset by interest income of $5 million. The increase of $15 million in net interest expense in the first quarter of 2015 as compared to the first quarter of 2014 was a result of higher outstanding debt balances.

[0000068505-15-000006:mdna:47]
[same as prior period, unchanged from 0000068505-14-000016:mdna:40]

[0000068505-15-000006:mdna:48]
Net gains on sales of investments and businesses were $46 million in the first quarter of 2015 and $7 million in the first quarter of 2014. The net gain in the first quarter of 2015 consisted of a gain on the sale of an equity investment. The net gains in the first quarter of 2014 consisted of gains on the sales of multiple equity investments.

[0000068505-15-000006:mdna:49]
[same as prior period, unchanged from 0000068505-14-000016:mdna:42]

[0000068505-15-000006:mdna:50]
Net Other income was $3 million in the first quarter of 2015, compared to no net Other income in the first quarter of 2014. The net Other income in the first quarter of 2015 was comprised of: (i) an $18 million foreign currency gain and (ii) $2 million of other non-operating gains, partially offset by a $17 million loss on derivative instruments.

[0000068505-15-000006:mdna:51]
[same as prior period, unchanged from 0000068505-14-000016:mdna:44]

[0000068505-15-000006:mdna:52]
We recorded $40 million of net tax expense in the first quarter of 2015, resulting in an effective tax rate of 31%, compared to $4 million of net tax expense, resulting in an effective tax rate of 4% in the first quarter of 2014. Our effective tax rate in 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the U.S. domestic production tax deduction and rate differential for foreign affiliates.

[0000068505-15-000006:mdna:53]
Our effective tax rate in the first quarter of 2014 was lower than the U.S. statutory tax rate of 35% due to a $30 million net tax benefit associated with the net reduction in unrecognized tax benefits for facts that indicated the extent to which certain tax positions were more-likely-than-not of being sustained.

[0000068505-15-000006:mdna:54]
[same as prior period, unchanged from 0000068505-14-000016:mdna:47]

[0000068505-15-000006:mdna:55]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $87 million, or $0.40 per diluted share, in the first quarter of 2015, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $85 million, or $0.33 per diluted share, in the first quarter of 2014.

[0000068505-15-000006:mdna:56]
The increase in earnings from continuing operations in the first quarter of 2015, as compared to the first quarter of 2014, was primarily driven by: (i) a $51 million decrease in SG&A spend, (ii) an increase in Gains on sales of investments and businesses of $39 million and (iii) a $15 million decrease in R&D, partially offset by: (i) a $36 million increase in income tax expenses, (ii) a $29 million decrease in gross margin, and (iii) a $25 million increase in net Other charges as a result of a $21 million gain on sale of buildings and land in the first quarter of 2014. Earnings from continuing operations attributable to Motorola Solutions, Inc. was not significantly impacted by the overall strengthening of the U.S. dollar in relation to other currencies in the first quarter of 2015. The unfavorable impact of foreign currency fluctuations on net sales was largely offset by foreign exchange rate favorability within cost of sales and operating expenses. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding as a result of our share repurchase program and increase in earnings from continuing operations.

[0000068505-15-000006:mdna:57]
[same as prior period, unchanged from 0000068505-14-000016:mdna:50]

[0000068505-15-000006:mdna:58]
After taxes, we had a $13 million, or $0.06 per diluted share, loss from discontinued operations in the first quarter of 2015, compared to earnings from discontinued operations of $42 million, or $0.16 per diluted share, in the first quarter of 2014.

[0000068505-15-000006:mdna:59]
[same as prior period, unchanged from 0000068505-14-000016:mdna:77]

[0000068505-15-000006:mdna:60]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three months ended April 4, 2015 and March 29, 2014, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-15-000006:mdna:61]
[same as prior period, unchanged from 0000068505-14-000016:mdna:79]

[0000068505-15-000006:mdna:62]
For the first quarter of 2015, the segment’s net sales represented 62% of our consolidated net sales, compared to 61% of our consolidated net sales for the first quarter of 2014.

[0000068505-15-000006:mdna:63]
|  | Three Months Ended |  |  |
|  | April 4, 2015 |  | March 29, 2014 |  | % Change |
| Segment net sales | $ | 758 |  |  | $ | 752 |  |  | 1 | % |
| Operating earnings | 64 |  |  | 39 |  |  | 64 | % |

[0000068505-15-000006:mdna:64]
Three months ended April 4, 2015 compared to three months ended March 29, 2014

[0000068505-15-000006:mdna:65]
The segment’s net sales increased $6 million, to $758 million in the first quarter of 2015, as compared to $752 million in the first quarter of 2014. The increase in net sales in the Products segment reflects an increase in devices sales, partially offset by a decrease of system sales. On a geographic basis, net sales increased in North America and ME and decreased in Latin America, EA, and AP for the first quarter of 2015, compared to the first quarter of 2014. The increase in the segment's net sales was primarily driven by: (i) an increase in devices sales in North America and ME, partially offset by (i) a decrease in devices and systems sales in Latin America and (ii) unfavorable foreign exchange rates with a strengthening U.S. dollar in EA and AP.

[0000068505-15-000006:mdna:66]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 63% of the segment’s net sales in the first quarter of 2015 and 59% of the segment’s net sales in the first quarter of 2014.

[0000068505-15-000006:mdna:67]
The segment had operating earnings of $64 million in the first quarter of 2015, compared to $39 million in the first quarter of 2014. The increase in operating earnings in the first quarter of 2015 compared to the first quarter of 2014, was primarily driven by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign currency exchange rates, and reduced pension expenses and (ii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign currency exchange rates, partially offset by an increase in Other charges as a result of a gain on sale of buildings and land in the first quarter of 2014.

[0000068505-15-000006:mdna:68]
[same as prior period, unchanged from 0000068505-14-000016:mdna:88]

[0000068505-15-000006:mdna:69]
For the first quarter of 2015, the segment’s net sales represented 38% of our consolidated net sales, compared to 39% of our consolidated net sales for the first quarter of 2014.

[0000068505-15-000006:mdna:70]
|  | Three Months Ended |  |  |
|  | April 4, 2015 |  | March 29, 2014 |  | % Change |
| Segment net sales | $ | 465 |  |  | $ | 476 |  |  | (2 | )% |
| Operating earnings | 55 |  |  | 68 |  |  | (19 | )% |

[0000068505-15-000006:mdna:71]
Three months ended April 4, 2015 compared to three months ended March 29, 2014

[0000068505-15-000006:mdna:72]
The segment’s net sales decreased $11 million, or 2%, to $465 million in the first quarter of 2015, as compared to net sales of $476 million in the first quarter of 2014. The 2% decrease in net sales in the Services segment reflects a decrease in sales of: (i) Integration services and (ii) iDEN services, partially offset by a slight increase in: (i) Lifecycle Support services and (ii) Managed services. On a geographic basis, net sales declined in EA, Latin America, and AP and increased in ME, while remaining flat in North America for the first quarter of 2015, compared to the first quarter of 2014. The decrease in the segment's net sales was driven by: (i) unfavorable foreign exchange rates with a strengthening U.S. dollar in EA and AP and (ii) declining iDEN services sales in Latin America.

[0000068505-15-000006:mdna:73]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 61% of the segment’s net sales in the first quarter of 2015 and 60% of the segment’s net sales in the first quarter of 2014.

[0000068505-15-000006:mdna:74]
The segment had operating earnings of $55 million in the first quarter of 2015, compared to operating earnings of $68 million in the first quarter of 2014. The decrease in operating earnings in the first quarter of 2015 as compared to the first quarter of 2014 was driven by: (i) a decrease in gross margin, driven by Integration services on large system deployments and (ii) an increase in Other charges as a result of a gain on sale of buildings and land in the first quarter of 2014, partially offset by: (i) a reduction in SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign currency exchange rates, and lower pension expenses and (ii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign currency exchange rates.

[0000068505-15-000006:mdna:75]
Reorganization of Business

[0000068505-15-000006:mdna:76]
During the first quarter of 2015, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first quarter of 2015, we recorded net reorganization of business charges of $14 million including charges of $12 million recorded in Other charges and $2 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $14 million are charges of $10 million for employee separation costs and $4 million for exit costs.

[0000068505-15-000006:mdna:77]
During the first quarter of 2014, we recorded net reorganization of business charges of $10 million including charges of $9 million recorded in Other charges and $1 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $10 million are charges of $8 million for employee separation costs and $3 million of exit costs,  partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-15-000006:mdna:78]
We expect to realize cost-saving benefits of approximately $8 million during the remaining nine months of 2015 from the plans that were initiated during the first quarter of 2015. Beyond 2015, we expect the reorganization plans initiated during the first three months of 2015 to provide annualized cost savings of approximately $13 million, consisting of: (i) $11 million of savings in operating expenses and (ii) $2 million of savings in Cost of Sales.

[0000068505-15-000006:mdna:79]
[same as prior period, unchanged from 0000068505-14-000016:mdna:104]

[0000068505-15-000006:mdna:80]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Products | $ | 10 |  |  | $ | 6 |  |
| Services | 4 |  |  | 4 |  |
|  | $ | 14 |  |  | $ | 10 |  |

[0000068505-15-000006:mdna:81]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $28 million in the first quarter of 2015 and $40 million in the first quarter of 2014. The cash payments related to discontinued operations included in the first quarter of 2014 were $13 million. The reorganization of business accruals at April 4, 2015 were $44 million, of which $39 million relate to employee separation costs that are expected to be paid within one year and $5 million of accruals primarily related to lease termination obligations that are expected to be paid over a number of years.

[0000068505-15-000006:mdna:82]
[same as prior period, unchanged from 0000068505-14-000016:mdna:107]

[0000068505-15-000006:mdna:83]
We decreased the aggregate of our cash and cash equivalent balances by $601 million from $4.0 billion as of December 31, 2014 to $3.4 billion as of April 4, 2015.  The decrease is primarily due to $728 million of capital returned to shareholders through share repurchases and dividends paid, partially offset by $151 million of cash provided by operating activities, primarily driven by improved accounts receivable collections and proceeds from the sale of long-term receivables.

[0000068505-15-000006:mdna:84]
[same as prior period, unchanged from 0000068505-14-000016:mdna:109]

[0000068505-15-000006:mdna:85]
[same as prior period, unchanged from 0000068505-14-000016:mdna:110]

[0000068505-15-000006:mdna:86]
Our cash and cash equivalents were $3.4 billion at April 4, 2015 and $4.0 billion at December 31, 2014. At April 4, 2015, $2.5 billion of this amount was held in the U.S. and approximately $835 million was held by the Company or its subsidiaries in other countries (including $346 million in the United Kingdom). During the first quarter of 2015, we transferred $423 million of cash proceeds from the sale of the Enterprise business from the U.S. to our foreign subsidiaries. At both April 4, 2015 and December 31, 2014, restricted cash was $63 million.

[0000068505-15-000006:mdna:87]
During the first quarter of 2015, we repatriated $134 million in funds to the U.S. from international jurisdictions. We have approximately $400 million of foreign earnings that are not permanently reinvested and may be repatriated without an additional income tax charge given the U.S. federal and foreign tax accrued on undistributed earnings and the utilization of available foreign tax credits. Undistributed earnings that we intend to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.5 billion at April 4, 2015. We currently have no plans to repatriate the foreign earnings permanently reinvested.  If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-15-000006:mdna:88]
[same as prior period, unchanged from 0000068505-14-000016:mdna:115]

[0000068505-15-000006:mdna:89]
Net cash provided by operating activities in the first quarter of 2015 was $151 million, as compared to $12 million in the first quarter of 2014. Operating cash flows in the first quarter of 2015, as compared to the first quarter of 2014, were positively impacted by: (i) improved accounts receivable collections, (ii) proceeds from the sale of long-term receivables, (iii) lower incentive compensation payments, and (iv) reduced pension contributions, partially offset by increased cash payments for accounts payable and accrued liabilities.

[0000068505-15-000006:mdna:90]
We made no contributions to our U.S. pension plans during the first quarter of 2015, compared to $26 million contributed in the first quarter of 2014. We contributed $3 million to our non-U.S. pension plans during the first quarter of 2015, compared to $17 million contributed in the first quarter of 2014.

[0000068505-15-000006:mdna:91]
[same as prior period, unchanged from 0000068505-14-000016:mdna:121]

[0000068505-15-000006:mdna:92]
Net cash used by investing activities was $18 million in the first quarter of 2015, compared to $10 million in the first quarter of 2014. The $18 million cash used in the first quarter of 2015 included $74 million cash used for acquisitions and investments and $33 million in capital expenditures, partially offset by $88 million of proceeds from sales of investments and businesses. The cash usage in the first quarter of 2014 consisted primarily of $41 million in capital expenditures, partially offset by $11 million of proceeds from the sale of investments and businesses and $24 million of proceeds from the sale of property, plant and equipment.

[0000068505-15-000006:mdna:93]
Acquisition and Investments: We used net cash for acquisitions and investments of $74 million during the first quarter of 2015 compared to $4 million in the first quarter of 2014. The cash used during the first quarter of 2015 consisted of $49 million related to the acquisition of two public safety software solution providers and several debt and equity investments. The cash used during the first quarter of 2014 relates to a number of small equity investments.

[0000068505-15-000006:mdna:94]
Sales of Investments and Businesses: We had $88 million of proceeds related to the sales of investments and businesses in the first quarter of 2015 compared to $11 million in the first quarter of 2014. The proceeds in the first quarter of 2015 primarily consists of: (i) $49 million reimbursement from Zebra Technologies for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale; (ii) $47 million from the sale of an equity investment, and (iii) $16 million net cash received from Zebra Technologies for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest. The proceeds in the first quarter of 2014 were comprised of sales of equity investments.

[0000068505-15-000006:mdna:95]
Capital Expenditures: Capital expenditures decreased in the first quarter of 2015 to $33 million, compared to $41 million in the first quarter of 2014.  The decrease in capital expenditures was primarily driven by a decrease in information technology-related spend due to the timing of ERP implementation costs, partially offset by an increase in revenue-generating network expenditures.

[0000068505-15-000006:mdna:96]
Sales of Property, Plant, and Equipment:  We had $1 million of proceeds related to the sale of property, plant, and equipment in the first quarter of 2015 compared to $24 million in the first quarter of 2014. The proceeds in the first quarter of 2014 were comprised of proceeds from the sale of buildings and land.

[0000068505-15-000006:mdna:97]
[same as prior period, unchanged from 0000068505-14-000016:mdna:127]

[0000068505-15-000006:mdna:98]
Net cash used for financing activities was $682 million in the first quarter of 2015, compared to $88 million in the first quarter of 2014. Cash used for financing activities in the first quarter of 2015 was primarily comprised of: (i) $653 million used for purchases of our common stock under our share repurchase program and (ii) $75 million of cash used for the payment of dividends, partially offset by $46 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first quarter of 2014 was primarily comprised of: (i) $79 million of cash used for the payment of dividends and (ii) $57 million used for purchases of our common stock under our share repurchase program, partially offset by: (i) $26 million of distributions from discontinued operations and (ii) $14 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-15-000006:mdna:99]
Long-Term Debt: We had outstanding long-term debt of $3.4 billion at both April 4, 2015 and December 31, 2014, including the current portions of $4 million at both April 4, 2015 and December 31, 2014.

[0000068505-15-000006:mdna:100]
[same as prior period, unchanged from 0000068505-14-000016:mdna:132]

[0000068505-15-000006:mdna:101]
Share Repurchase Program: We paid an aggregate of $653 million during the first quarter of 2015, including transaction costs, to repurchase approximately 9.9 million shares at an average price of $66.12 per share.  All repurchased shares have been retired.

[0000068505-15-000006:mdna:102]
The Board of Directors has authorized a share repurchase program for an aggregate amount of $12.0 billion of outstanding shares of common stock. As of April 4, 2015, we have used approximately $8.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $3.6 billion of authority available for future repurchases.

[0000068505-15-000006:mdna:103]
Payment of Dividends: During the first quarter of 2015, we paid $75 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid $72 million in cash dividends to holders of our common stock.

[0000068505-15-000006:mdna:104]
[same as prior period, unchanged from 0000068505-14-000016:mdna:136]

[0000068505-15-000006:mdna:105]
As of April 4, 2015, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of April 4, 2015. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first quarter of 2015.

[0000068505-15-000006:mdna:106]
[same as prior period, unchanged from 0000068505-14-000016:mdna:139]

[0000068505-15-000006:mdna:107]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $65 million at April 4, 2015, compared to $293 million at December 31, 2014.  Outstanding commitments decreased during the first quarter of 2015 primarily as a result of two large customer contracts one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-15-000006:mdna:108]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $26 million at April 4, 2015, compared to $31 million at December 31, 2014.

[0000068505-15-000006:mdna:109]
[same as prior period, unchanged from 0000068505-14-000016:mdna:142]

[0000068505-15-000006:mdna:110]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the first quarter of 2015 and 2014:

[0000068505-15-000006:mdna:111]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Accounts receivable sales proceeds | $ | 6 |  |  | $ | 7 |  |
| Long-term receivables sales proceeds | 65 |  |  | 1 |  |
| Total proceeds from sales of accounts receivable | $ | 71 |  |  | $ | 8 |  |

[0000068505-15-000006:mdna:112]
As of April 4, 2015, we had retained servicing obligations for $596 million of sold long-term receivables, compared to $496 million of sold long-term receivables at December 31, 2014. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-15-000006:mdna:113]
Other Contingencies

[0000068505-15-000006:mdna:114]
[same as prior period, unchanged from 0000068505-14-000016:mdna:147]

[0000068505-15-000006:mdna:115]
[same as prior period, unchanged from 0000068505-14-000016:mdna:148]

[0000068505-15-000006:mdna:116]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  We had no accruals for any such obligations at April 4, 2015.

[0000068505-15-000006:mdna:117]
Legal Matters:  We are a defendant in various lawsuits, claims and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our condensed consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on our condensed consolidated financial position, liquidity or results of operations in the periods in which the matters are ultimately resolved.

[0000068505-15-000006:mdna:118]
[same as prior period, unchanged from 0000068505-14-000016:mdna:152]

[0000068505-15-000006:mdna:119]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of this ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for us beginning January 1, 2017; however, in April 2015, the FASB proposed a one year delay in the effective date of the standard. This ASU allows for both retrospective and modified-retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-15-000006:mdna:120]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU 2015-02 changes the consolidation analysis required for limited partnerships and other variable interest entities. This ASU will be effective for us beginning January 1, 2016, with early adoption permitted. This ASU allows for either retrospective or modified retrospective application.  We do not expect this ASU will have a material impact on our consolidated financial statements.

[0000068505-15-000006:mdna:121]
In April 2015, the FASB issued ASU No. 2015-03, "Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.” Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of April 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $19 million.

[0000068505-15-000006:mdna:122]
In April 2015, the FASB issued ASU No. 2015-05, "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Arrangement." Under this guidance, if it is determined that a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses; however, if it is determined that a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. This ASU allows for the option of applying either a full retrospective approach to all periods presented or a prospective approach to all arrangements entered into or materially modified after the effective date of January 1, 2016. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.
