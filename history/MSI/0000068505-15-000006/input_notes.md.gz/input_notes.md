# MSI notes — 0000068505-15-000006


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-15-000006:notes:1]
Investments consist of the following:

[0000068505-15-000006:notes:2]
| April 4, 2015 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |
| Corporate bonds | 9 |  |  | — |  |  | 9 |  |
| Common stock | — |  |  | 17 |  |  | 17 |  |
|  | 46 |  |  | 17 |  |  | 63 |  |
| Other investments, at cost | 200 |  |  | — |  |  | 200 |  |
| Equity method investments | 22 |  |  | — |  |  | 22 |  |
|  | $ | 268 |  |  | $ | 17 |  |  | $ | 285 |  |

[0000068505-15-000006:notes:3]
| December 31, 2014 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Corporate bonds | 16 |  |  | — |  |  | 16 |  |
| Mutual funds | 2 |  |  | — |  |  | 2 |  |
| Common stock | 1 |  |  | 70 |  |  | 71 |  |
|  | 33 |  |  | 70 |  |  | 103 |  |
| Other investments, at cost | 191 |  |  | — |  |  | 191 |  |
| Equity method investments | 22 |  |  | — |  |  | 22 |  |
|  | $ | 246 |  |  | $ | 70 |  |  | $ | 316 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-15-000006:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 4, 2015 and December 31, 2014 were as follows:

[0000068505-15-000006:notes:5]
| April 4, 2015 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 37 |  |  | 37 |  |
| Corporate bonds | — |  |  | 9 |  |  | 9 |  |
| Common stock | 17 |  |  | — |  |  | 17 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest rate swap | — |  |  | 2 |  |  | 2 |  |

[0000068505-15-000006:notes:6]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 14 |  |  | 14 |  |
| Corporate bonds | — |  |  | 16 |  |  | 16 |  |
| Mutual funds | — |  |  | 2 |  |  | 2 |  |
| Common stock | 71 |  |  | — |  |  | 71 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Interest rate swap | — |  |  | 2 |  |  | 2 |  |


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-15-000006:notes:7]
[same as prior period, unchanged from 0000068505-14-000016:notes:176]

[0000068505-15-000006:notes:8]
|  | April 4, 2015 |  | December 31, 2014 |
| Long-term receivables | $ | 51 |  |  | $ | 49 |  |
| Less current portion | (25 | ) |  | (18 | ) |
| Non-current long-term receivables, net | $ | 26 |  |  | $ | 31 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-15-000006:notes:9]
[same as prior period, unchanged from 0000068505-14-000016:notes:178]

[0000068505-15-000006:notes:10]
[same as prior period, unchanged from 0000068505-14-000016:notes:179]

[0000068505-15-000006:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $65 million at April 4, 2015, compared to $293 million at December 31, 2014. Outstanding commitments decreased during the first quarter of 2015 primarily as a result of two large customer contracts one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-15-000006:notes:12]
[same as prior period, unchanged from 0000068505-14-000016:notes:181]

[0000068505-15-000006:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended April 4, 2015 and March 29, 2014:

[0000068505-15-000006:notes:14]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Accounts receivable sales proceeds | $ | 6 |  |  | $ | 7 |  |
| Long-term receivables sales proceeds | 65 |  |  | 1 |  |
| Total proceeds from receivable sales | $ | 71 |  |  | $ | 8 |  |

[0000068505-15-000006:notes:15]
At April 4, 2015, the Company had retained servicing obligations for $596 million of long-term receivables, compared to $496 million of long-term receivables at December 31, 2014.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-15-000006:notes:16]
[same as prior period, unchanged from 0000068505-14-000016:notes:185]

[0000068505-15-000006:notes:17]
An aging analysis of financing receivables at April 4, 2015 and December 31, 2014 is as follows:

[0000068505-15-000006:notes:18]
| April 4, 2015 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 40 |  |  | 4 |  |  | 1 |  |  | 11 |  |
| Total gross long-term receivables, including current portion | $ | 51 |  |  | $ | 4 |  |  | $ | 1 |  |  | $ | 11 |  |

[0000068505-15-000006:notes:19]
| December 31, 2014 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 35 |  |  | — |  |  | — |  |  | 12 |  |
| Total gross long-term receivables, including current portion | $ | 49 |  |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |

[0000068505-15-000006:notes:20]
The Company had a total of $11 million of financing receivables past due over 90 days as of April 4, 2015 in relation to two loans. The Company did not accrue interest on these loans, which are fully reserved, during the three months ended April 4, 2015 or March 29, 2014.


## msi:OtherChargesTableTextBlock

[0000068505-15-000006:notes:21]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-15-000006:notes:22]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Other charges (income): |  |  |  |
| Intangibles amortization | $ | 2 |  |  | $ | 1 |  |
| Reorganization of business | 12 |  |  | 9 |  |
| Gain on sale of building and land | — |  |  | (21 | ) |
|  | $ | 14 |  |  | $ | (11 | ) |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-15-000006:notes:23]
The following table displays the net charges incurred by segment:

[0000068505-15-000006:notes:24]
| April 4, 2015 | Three Months Ended |
| Products | $ | 10 |  |
| Services | 4 |  |
|  | $ | 14 |  |

[0000068505-15-000006:notes:25]
| March 29, 2014 | Three Months Ended |
| Products | $ | 6 |  |
| Services | 4 |  |
|  | $ | 10 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-15-000006:notes:26]
Compensation expense for the Company’s employee stock options, stock appreciation rights, employee stock purchase plan, restricted stock and restricted stock units (“RSUs”) was as follows:

[0000068505-15-000006:notes:27]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Share-based compensation expense included in: |  |  |  |
| Costs of sales | $ | 3 |  |  | $ | 3 |  |
| Selling, general and administrative expenses | 13 |  |  | 17 |  |
| Research and development expenditures | 5 |  |  | 8 |  |
| Share-based compensation expense included in Operating earnings | 21 |  |  | 28 |  |
| Tax benefit | 7 |  |  | 9 |  |
| Share-based compensation expense, net of tax | $ | 14 |  |  | $ | 19 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |
| Decrease in diluted earnings per share | $ | (0.06 | ) |  | $ | (0.07 | ) |
| Share-based compensation expense in discontinued operations | $ | — |  |  | $ | 8 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-15-000006:notes:28]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-15-000006:notes:29]
|  | April 4, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 89 |  |  | $ | 56 |  |  | $ | 77 |  |  | $ | 54 |  |
| Services | 5 |  |  | — |  |  | — |  |  | — |  |
|  | $ | 94 |  |  | $ | 56 |  |  | $ | 77 |  |  | $ | 54 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-15-000006:notes:30]
Other liabilities consist of the following:

[0000068505-15-000006:notes:31]
|  | April 4, 2015 |  | December 31, 2014 |
| Defined benefit plans | $ | 1,563 |  |  | $ | 1,611 |  |
| Postretirement Health Care Benefit Plan | 42 |  |  | 49 |  |
| Deferred revenue | 141 |  |  | 139 |  |
| Unrecognized tax benefits | 51 |  |  | 54 |  |
| Other | 165 |  |  | 158 |  |
|  | $ | 1,962 |  |  | $ | 2,011 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-15-000006:notes:32]
[same as prior period, unchanged from 0000068505-14-000016:notes:1]

[0000068505-15-000006:notes:33]
Statements of Operations Information

[0000068505-15-000006:notes:34]
Other Charges (Income)

[0000068505-15-000006:notes:35]
[same as prior period, unchanged from 0000068505-14-000016:notes:8]

[0000068505-15-000006:notes:36]
[same as prior period, unchanged from 0000068505-14-000016:notes:9]

[0000068505-15-000006:notes:37]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Interest income (expense), net: |  |  |  |
| Interest expense | $ | (43 | ) |  | $ | (30 | ) |
| Interest income | 3 |  |  | 5 |  |
|  | $ | (40 | ) |  | $ | (25 | ) |
| Other: |  |  |  |
| Foreign currency gain (loss) | $ | 18 |  |  | $ | (1 | ) |
| Loss on derivative instruments | (17 | ) |  | (1 | ) |
| Other | 2 |  |  | 2 |  |
|  | $ | 3 |  |  | $ | — |  |

[0000068505-15-000006:notes:38]
[same as prior period, unchanged from 0000068505-14-000016:notes:11]

[0000068505-15-000006:notes:39]
[same as prior period, unchanged from 0000068505-14-000016:notes:12]

[0000068505-15-000006:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Three Months Ended | April 4, 2015 |  | March 29, 2014 |  | April 4, 2015 |  | March 29, 2014 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 87 |  |  | $ | 85 |  |  | $ | 74 |  |  | $ | 127 |  |
| Weighted average common shares outstanding | 215.3 |  |  | 254.1 |  |  | 215.3 |  |  | 254.1 |  |
| Per share amount | $ | 0.40 |  |  | $ | 0.33 |  |  | $ | 0.34 |  |  | $ | 0.50 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 87 |  |  | $ | 85 |  |  | $ | 74 |  |  | $ | 127 |  |
| Weighted average common shares outstanding | 215.3 |  |  | 254.1 |  |  | 215.3 |  |  | 254.1 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.5 |  |  | 4.2 |  |  | 2.5 |  |  | 4.2 |  |
| Diluted weighted average common shares outstanding | 217.8 |  |  | 258.3 |  |  | 217.8 |  |  | 258.3 |  |
| Per share amount | $ | 0.40 |  |  | $ | 0.33 |  |  | $ | 0.34 |  |  | $ | 0.49 |  |

[0000068505-15-000006:notes:41]
In the computation of diluted earnings per common share for the three months ended April 4, 2015 and March 29, 2014, the assumed exercise of 2.2 million and 5.0 million stock options, respectively, were excluded because their inclusion would have been antidilutive.

[0000068505-15-000006:notes:42]
[same as prior period, unchanged from 0000068505-14-000016:notes:16]

[0000068505-15-000006:notes:43]
[same as prior period, unchanged from 0000068505-14-000016:notes:17]

[0000068505-15-000006:notes:44]
The Company’s cash and cash equivalents were $3.4 billion at April 4, 2015 and $4.0 billion at December 31, 2014. Of these amounts, $63 million was restricted at both April 4, 2015 and December 31, 2014.

[0000068505-15-000006:notes:45]
[same as prior period, unchanged from 0000068505-14-000016:notes:19]

[0000068505-15-000006:notes:46]
During the three months ended April 4, 2015, the Company sold shares of an equity investment realizing cash proceeds of $47 million and a previously unrecognized gain of $46 million.

[0000068505-15-000006:notes:47]
[same as prior period, unchanged from 0000068505-14-000016:notes:22]

[0000068505-15-000006:notes:48]
[same as prior period, unchanged from 0000068505-14-000016:notes:23]

[0000068505-15-000006:notes:49]
|  | April 4, 2015 |  | December 31, 2014 |
| Accounts receivable | $ | 1,120 |  |  | $ | 1,444 |  |
| Less allowance for doubtful accounts | (36 | ) |  | (35 | ) |
|  | $ | 1,084 |  |  | $ | 1,409 |  |

[0000068505-15-000006:notes:50]
[same as prior period, unchanged from 0000068505-14-000016:notes:25]

[0000068505-15-000006:notes:51]
[same as prior period, unchanged from 0000068505-14-000016:notes:26]

[0000068505-15-000006:notes:52]
|  | April 4, 2015 |  | December 31, 2014 |
| Finished goods | $ | 178 |  |  | $ | 163 |  |
| Work-in-process and production materials | 336 |  |  | 313 |  |
|  | 514 |  |  | 476 |  |
| Less inventory reserves | (133 | ) |  | (131 | ) |
|  | $ | 381 |  |  | $ | 345 |  |

[0000068505-15-000006:notes:53]
[same as prior period, unchanged from 0000068505-14-000016:notes:28]

[0000068505-15-000006:notes:54]
[same as prior period, unchanged from 0000068505-14-000016:notes:29]

[0000068505-15-000006:notes:55]
|  | April 4, 2015 |  | December 31, 2014 |
| Costs and earnings in excess of billings | $ | 367 |  |  | $ | 417 |  |
| Tax-related refunds receivable | 90 |  |  | 103 |  |
| Zebra receivable for cash transferred | — |  |  | 49 |  |
| Other | 193 |  |  | 171 |  |
|  | $ | 650 |  |  | $ | 740 |  |

[0000068505-15-000006:notes:56]
In conjunction with the sale of the Enterprise business to Zebra Technologies, the Company transferred legal entities which maintained cash balances. During the three months ended April 4, 2015, approximately $49 million of transferred cash balances were reimbursed by Zebra in accordance with the Master Acquisition Agreement.

[0000068505-15-000006:notes:57]
[same as prior period, unchanged from 0000068505-14-000016:notes:31]

[0000068505-15-000006:notes:58]
[same as prior period, unchanged from 0000068505-14-000016:notes:32]

[0000068505-15-000006:notes:59]
|  | April 4, 2015 |  | December 31, 2014 |
| Land | $ | 17 |  |  | $ | 18 |  |
| Building | 557 |  |  | 559 |  |
| Machinery and equipment | 1,658 |  |  | 1,672 |  |
|  | 2,232 |  |  | 2,249 |  |
| Less accumulated depreciation | (1,702 | ) |  | (1,700 | ) |
|  | $ | 530 |  |  | $ | 549 |  |

[0000068505-15-000006:notes:60]
Depreciation expense was $39 million for both the three months ended April 4, 2015 and March 29, 2014.

[0000068505-15-000006:notes:61]
[same as prior period, unchanged from 0000068505-14-000016:notes:35]

[0000068505-15-000006:notes:62]
[same as prior period, unchanged from 0000068505-14-000016:notes:36]

[0000068505-15-000006:notes:63]
|  | April 4, 2015 |  | December 31, 2014 |
| Intangible assets, net | $ | 38 |  |  | $ | 23 |  |
| Long-term receivables | 26 |  |  | 31 |  |
| Other | 93 |  |  | 91 |  |
|  | $ | 157 |  |  | $ | 145 |  |

[0000068505-15-000006:notes:64]
[same as prior period, unchanged from 0000068505-14-000016:notes:38]

[0000068505-15-000006:notes:65]
[same as prior period, unchanged from 0000068505-14-000016:notes:39]

[0000068505-15-000006:notes:66]
|  | April 4, 2015 |  | December 31, 2014 |
| Deferred revenue | $ | 339 |  |  | $ | 355 |  |
| Compensation | 158 |  |  | 190 |  |
| Billings in excess of costs and earnings | 344 |  |  | 358 |  |
| Tax liabilities | 49 |  |  | 91 |  |
| Dividend payable | 72 |  |  | 75 |  |
| Other | 574 |  |  | 637 |  |
|  | $ | 1,536 |  |  | $ | 1,706 |  |

[0000068505-15-000006:notes:67]
[same as prior period, unchanged from 0000068505-14-000016:notes:41]

[0000068505-15-000006:notes:68]
[same as prior period, unchanged from 0000068505-14-000016:notes:44]

[0000068505-15-000006:notes:69]
[same as prior period, unchanged from 0000068505-14-000016:notes:45]

[0000068505-15-000006:notes:70]
The Company paid an aggregate of $653 million during the first quarter of 2015, including transaction costs, to repurchase approximately 9.9 million shares at an average price of $66.12 per share. As of April 4, 2015, the Company had used approximately $8.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $3.6 billion of authority available for future repurchases.

[0000068505-15-000006:notes:71]
Payment of Dividends:  During the three months ended April 4, 2015 and March 29, 2014, the Company paid $75 million and $79 million, respectively, in cash dividends to holders of its common stock.

[0000068505-15-000006:notes:72]
[same as prior period, unchanged from 0000068505-14-000016:notes:48]

[0000068505-15-000006:notes:73]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three months ended April 4, 2015 and March 29, 2014:

[0000068505-15-000006:notes:74]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Foreign Currency Translation Adjustments |  |  |  |
| Balance at beginning of period | $ | (204 | ) |  | $ | (96 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (27 | ) |  | 3 |  |
| Tax expense (benefit) | 1 |  |  | (1 | ) |
| Other comprehensive income (loss), net of tax | (26 | ) |  | 2 |  |
| Balance at end of period | $ | (230 | ) |  | $ | (94 | ) |
| Net loss on derivative instruments |  |  |  |
| Balance at beginning and end of period | $ | — |  |  | $ | (1 | ) |
| Unrealized Gains and Losses on Available-for-Sale Securities: |  |  |  |
| Balance at beginning of period | $ | 44 |  |  | $ | (2 | ) |
| Other comprehensive loss before reclassification adjustment | (7 | ) |  | — |  |
| Tax expense | 3 |  |  | 2 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (4 | ) |  | 2 |  |
| Reclassification adjustment into Gains on Sales of investments and businesses, net | (46 | ) |  | — |  |
| Tax expense | 17 |  |  | — |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net of tax | (29 | ) |  | — |  |
| Other comprehensive income (loss), net of tax | (33 | ) |  | 2 |  |
| Balance at end of period | $ | 11 |  |  | $ | — |  |
| Defined Benefit Plans |  |  |  |
| Balance at beginning of period | (1,695 | ) |  | (2,188 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 19 |  |  | 29 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (17 | ) |  | (10 | ) |
| Tax benefit | (1 | ) |  | (6 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | 1 |  |  | 13 |  |
| Balance at end of period | $ | (1,694 | ) |  | $ | (2,175 | ) |
| Total Accumulated other comprehensive loss | $ | (1,913 | ) |  | $ | (2,270 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-15-000006:notes:75]
Commitments and Contingencies

[0000068505-15-000006:notes:76]
Legal Matters

[0000068505-15-000006:notes:77]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s condensed consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s: (i) results of operations in the periods in which an adverse outcome becomes both probable and estimable or (ii) financial position or liquidity in the periods in which the matters are ultimately resolved.

[0000068505-15-000006:notes:78]
Other Indemnifications

[0000068505-15-000006:notes:79]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-15-000006:notes:80]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at April 4, 2015.

[0000068505-15-000006:notes:81]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-15-000006:notes:82]
Debt and Credit Facilities

[0000068505-15-000006:notes:83]
As of April 4, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 4, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the three months ended April 4, 2015.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-15-000006:notes:84]
[same as prior period, unchanged from 0000068505-14-000016:notes:66]

[0000068505-15-000006:notes:85]
[same as prior period, unchanged from 0000068505-14-000016:notes:67]

[0000068505-15-000006:notes:86]
As of April 4, 2015, the Company had outstanding foreign exchange contracts with notional amounts totaling $694 million, compared to $628 million outstanding at December 31, 2014.  The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-15-000006:notes:87]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 4, 2015, and the corresponding positions as of December 31, 2014:

[0000068505-15-000006:notes:88]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 4, 2015 |  | December 31, 2014 |
| British Pound | $ | 166 |  |  | $ | 34 |  |
| Euro | 154 |  |  | 214 |  |
| Chinese Renminbi | (146 | ) |  | (161 | ) |
| Norwegian Krone | (86 | ) |  | (90 | ) |
| Brazilian Real | (38 | ) |  | (28 | ) |

[0000068505-15-000006:notes:89]
[same as prior period, unchanged from 0000068505-14-000016:notes:71]

[0000068505-15-000006:notes:90]
As of April 4, 2015, the Company had $3.4 billion of long-term debt, including the current portion, which is primarily priced at long-term, fixed interest rates.

[0000068505-15-000006:notes:91]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable and the Company has an interest rate swap in place which is not designated as a hedge. As such, the changes in the fair value of the interest rate swap is included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swap was in a liability position of $2 million at April 4, 2015 and December 31, 2014.

[0000068505-15-000006:notes:92]
[same as prior period, unchanged from 0000068505-14-000016:notes:74]

[0000068505-15-000006:notes:93]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 4, 2015, all of the counterparties have investment grade credit ratings. As of April 4, 2015, the Company had $2 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-15-000006:notes:94]
The following tables summarize the fair values and location in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of April 4, 2015 and December 31, 2014:

[0000068505-15-000006:notes:95]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| April 4, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 2 |  |  | Other assets |  | $ | 1 |  |  | Other liabilities |
| Interest rate swap | — |  |  | Other assets |  | 2 |  |  | Other liabilities |
| Total derivatives | $ | 2 |  |  |  |  | $ | 3 |  |  |  |

[0000068505-15-000006:notes:96]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2014 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 1 |  |  | Other assets |  | 5 |  |  | Other liabilities |
| Interest rate swap | — |  |  | Other assets |  | 2 |  |  | Other liabilities |
| Total derivatives | 1 |  |  |  |  | 7 |  |  |  |

[0000068505-15-000006:notes:97]
The following table summarizes the effect of derivative instruments on the Company's condensed consolidated statements of operations for the three months ended April 4, 2015 and March 29, 2014:

[0000068505-15-000006:notes:98]
|  | Three Months Ended |  | Statements ofOperations Location |
| Loss on Derivative Instruments | April 4, 2015 |  | March 29, 2014 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |
| Interest rate swap | $ | (1 | ) |  | $ | — |  |  | Other income (expense) |
| Foreign exchange contracts | (16 | ) |  | (1 | ) |  | Other income (expense) |
| Total derivatives | $ | (17 | ) |  | $ | (1 | ) |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-15-000006:notes:99]
[same as prior period, unchanged from 0000068505-14-000016:notes:83]

[0000068505-15-000006:notes:100]
For the three months ended April 4, 2015, the Company granted 0.7 million RSUs and 0.8 million stock options. The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and stock options was $39 million and $9 million, respectively, which will be recognized over a weighted average vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-15-000006:notes:101]
[same as prior period, unchanged from 0000068505-14-000016:notes:87]

[0000068505-15-000006:notes:102]
On October 27, 2014, the Company completed the sale of its Enterprise business to Zebra Technologies Corporation for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by the Company, including the Company’s iDEN business, and other assets and certain liabilities as specified in the Master Acquisition Agreement. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's condensed consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-15-000006:notes:103]
The following table displays summarized activity in the Company's condensed consolidated statements of operations for discontinued operations during the three months ended April 4, 2015 and March 29, 2014:

[0000068505-15-000006:notes:104]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Net sales | $ | — |  |  | $ | 573 |  |
| Operating earnings | — |  |  | 63 |  |
| Losses on sales of investments and businesses, net | (20 | ) |  | — |  |
| Earnings (loss) before income taxes | (20 | ) |  | 62 |  |
| Income tax expense (benefit) | (7 | ) |  | 20 |  |
| Earnings (loss) from discontinued operations, net of tax | $ | (13 | ) |  | $ | 42 |  |

[0000068505-15-000006:notes:105]
During the three months ended April 4, 2015, the Company recorded $20 million in adjustments and a $7 million tax benefit related to the sale of the Enterprise business.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-15-000006:notes:106]
[same as prior period, unchanged from 0000068505-14-000016:notes:94]

[0000068505-15-000006:notes:107]
[same as prior period, unchanged from 0000068505-14-000016:notes:95]

[0000068505-15-000006:notes:108]
[same as prior period, unchanged from 0000068505-14-000016:notes:96]

[0000068505-15-000006:notes:109]
[same as prior period, unchanged from 0000068505-14-000016:notes:97]

[0000068505-15-000006:notes:110]
[same as prior period, unchanged from 0000068505-14-000016:notes:98]

[0000068505-15-000006:notes:111]
[same as prior period, unchanged from 0000068505-14-000016:notes:99]

[0000068505-15-000006:notes:112]
The Company had no Level 3 holdings as of April 4, 2015 or December 31, 2014.

[0000068505-15-000006:notes:113]
At April 4, 2015 and December 31, 2014, the Company had $2.5 billion and $3.3 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-15-000006:notes:114]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at April 4, 2015 was $3.6 billion (Level 2).

[0000068505-15-000006:notes:115]
[same as prior period, unchanged from 0000068505-14-000016:notes:106]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-15-000006:notes:116]
[same as prior period, unchanged from 0000068505-14-000016:notes:107]

[0000068505-15-000006:notes:117]
[same as prior period, unchanged from 0000068505-14-000016:notes:108]

[0000068505-15-000006:notes:118]
[same as prior period, unchanged from 0000068505-14-000016:notes:109]

[0000068505-15-000006:notes:119]
|  | April 4, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 54 |  |  | $ | 29 |  |  | $ | 37 |  |  | $ | 27 |  |
| Patents | 8 |  |  | 4 |  |  | 8 |  |  | 4 |  |
| Customer-related | 15 |  |  | 8 |  |  | 15 |  |  | 8 |  |
| Other intangibles | 17 |  |  | 15 |  |  | 17 |  |  | 15 |  |
|  | $ | 94 |  |  | $ | 56 |  |  | $ | 77 |  |  | $ | 54 |  |

[0000068505-15-000006:notes:120]
Amortization expense on intangible assets was $2 million for the three months ended April 4, 2015 and $1 million for the three months ended March 29, 2014. As of April 4, 2015, annual amortization expense is estimated to be $7 million in 2015, 2016, and 2017, $6 million in 2018, $5 million in 2019, and $2 million in 2020.

[0000068505-15-000006:notes:121]
[same as prior period, unchanged from 0000068505-14-000016:notes:114]

[0000068505-15-000006:notes:122]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2015 to April 4, 2015:

[0000068505-15-000006:notes:123]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Goodwill acquired | 7 |  |  | — |  |  | 7 |  |
| Balance as of April 4, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 271 |  |  | $ | 119 |  |  | $ | 390 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 271 |  |  | $ | 119 |  |  | $ | 390 |  |

[0000068505-15-000006:notes:124]
On November 18, 2014, the Company completed the acquisition of an equipment provider for a purchase price of $22 million. During the three months ended April 4, 2015, the Company completed the purchase accounting for this acquisition, recognizing $7 million of goodwill and $12 million of identifiable intangible assets.

[0000068505-15-000006:notes:125]
During the quarter ended April 4, 2015 the Company completed the acquisitions of two providers of public safety software-based solutions for an aggregate purchase price of $50 million. During the three months ended April 4, 2015, the Company recognized an additional $5 million of identifiable intangible assets related to one of the acquisitions. As of April 4, 2015, $44 million is included in Other assets in the Company's condensed consolidated balance sheet pending finalization of the purchase price allocation for the second acquisition.

[0000068505-15-000006:notes:126]
The results of operations for these acquisitions have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-15-000006:notes:127]
[same as prior period, unchanged from 0000068505-14-000016:notes:119]

[0000068505-15-000006:notes:128]
At the end of each interim reporting period, the Company makes an estimate of the annual effective income tax rate.  Tax items included in the annual effective income tax rate are pro-rated for the full year and tax items discrete to a specific quarter are included in the effective income tax rate for that quarter.  The estimate used in providing for income taxes on a year-to-date basis may change in subsequent interim periods.

[0000068505-15-000006:notes:129]
The following table provides details of income taxes:

[0000068505-15-000006:notes:130]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Earnings before income taxes | $ | 128 |  |  | $ | 89 |  |
| Income tax expense | 40 |  |  | 4 |  |
| Effective tax rate | 31 | % |  | 4 | % |

[0000068505-15-000006:notes:131]
The Company recorded $40 million of net income tax expense in the first quarter of 2015, resulting in an effective tax rate of 31%, compared to $4 million of net tax expense, resulting in an effective tax rate of 4% in the first quarter of 2014. The effective tax rate in 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the U.S. domestic production tax deduction and rate differential for foreign affiliates. The effective tax rate in the first quarter of 2014 was lower than the U.S. statutory tax rate of 35% due to a $30 million net tax benefit associated with the net reduction in unrecognized tax benefits for facts that indicated the extent to which certain tax positions were more-likely-than-not of being sustained.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-15-000006:notes:132]
Recent Accounting Pronouncements

[0000068505-15-000006:notes:133]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for the Company beginning January 1, 2017; however, in April 2015, the FASB proposed a one year delay in the effective date of the standard. This ASU allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-15-000006:notes:134]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU 2015-02 changes the consolidation analysis required for limited partnerships and other variable interest entities. This ASU will be effective for the Company beginning January 1, 2016, with early adoption permitted. This ASU allows for either retrospective or modified retrospective application.  The Company does not expect this ASU will have a material impact on its consolidated financial statements.

[0000068505-15-000006:notes:135]
In April 2015, the FASB issued ASU No. 2015-03, "Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.” Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. The Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of April 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $19 million.

[0000068505-15-000006:notes:136]
In April 2015, the FASB issued ASU No. 2015-05, "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Arrangement." Under this guidance, if it is determined that a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses; however, if it is determined that a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. This ASU allows for the option of applying either a full retrospective approach to all periods presented or a prospective approach to all arrangements entered into or materially modified after the effective date of January 1, 2016. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-15-000006:notes:137]
[same as prior period, unchanged from 0000068505-14-000016:notes:129]

[0000068505-15-000006:notes:138]
The condensed consolidated financial statements as of April 4, 2015 and for the three months ended April 4, 2015 and March 29, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-15-000006:notes:139]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three months ended April 4, 2015 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-15-000006:notes:140]
[same as prior period, unchanged from 0000068505-14-000016:notes:132]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-15-000006:notes:141]
[same as prior period, unchanged from 0000068505-14-000016:notes:139]

[0000068505-15-000006:notes:142]
[same as prior period, unchanged from 0000068505-14-000016:notes:140]

[0000068505-15-000006:notes:143]
[same as prior period, unchanged from 0000068505-14-000016:notes:141]

[0000068505-15-000006:notes:144]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 4, 2015 |  | March 29, 2014 |  | April 4, 2015 |  | March 29, 2014 |  | April 4, 2015 |  | March 29, 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 49 |  |  | 93 |  |  | 16 |  |  | 20 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (54 | ) |  | (98 | ) |  | (26 | ) |  | (23 | ) |  | (2 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 12 |  |  | 22 |  |  | 4 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (2 | ) |  | 2 |  |  | (15 | ) |  | (12 | ) |
| Net periodic pension cost (benefit) | $ | 7 |  |  | $ | 17 |  |  | $ | (5 | ) |  | $ | 6 |  |  | $ | (12 | ) |  | $ | (7 | ) |

[0000068505-15-000006:notes:145]
The Company made no contributions to its U.S. Pension Benefit Plans during the three months ended April 4, 2015 and $26 million of contributions to its U.S. Pension Benefit Plans for the three months ended March 29, 2014. During the three months ended April 4, 2015 and March 29, 2014, contributions of $3 million and $17 million were made to the Company’s Non U.S. Pension Benefit Plans, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-15-000006:notes:146]
Reorganization of Business

[0000068505-15-000006:notes:147]
2015 Charges

[0000068505-15-000006:notes:148]
During the three months ended April 4, 2015, the Company recorded net reorganization of business charges of $14 million including $12 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $14 million were charges of $10 million for employee separation costs and $4 million for exit costs.

[0000068505-15-000006:notes:149]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2015 to April 4, 2015, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business:

[0000068505-15-000006:notes:150]
|  | January 1, 2015 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | April 4, 2015 |
| Exit costs | $ | — |  |  | $ | 4 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 5 |  |
| Employee separation costs | 57 |  |  | 10 |  |  | — |  |  | (28 | ) |  | 39 |  |
|  | $ | 57 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | (28 | ) |  | $ | 44 |  |

[0000068505-15-000006:notes:151]
[same as prior period, unchanged from 0000068505-14-000016:notes:160]

[0000068505-15-000006:notes:152]
At January 1, 2015, the Company had no accruals for exit costs. During the three months ended April 4, 2015, there were $4 million of additional charges related to the exit of leased facilities. The remaining accrual of $5 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at April 4, 2015, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-15-000006:notes:153]
[same as prior period, unchanged from 0000068505-14-000016:notes:162]

[0000068505-15-000006:notes:154]
At January 1, 2015, the Company had an accrual of $57 million for employee separation costs. The 2015 additional charges of $10 million represent severance costs for approximately 100 employees. The $28 million used reflects cash payments to severed employees. The remaining accrual of $39 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at April 4, 2015, is expected to be paid, primarily within one year, to approximately 450 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-15-000006:notes:155]
[same as prior period, unchanged from 0000068505-14-000016:notes:153]

[0000068505-15-000006:notes:156]
During the three months ended March 29, 2014, the Company recorded net reorganization of business charges of $10 million, including $9 million of charges in Other charges and $1 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $10 million were charges of $8 million related to employee separation costs and $3 million related to exit costs, partially offset by $1 million of reversals for accruals no longer needed.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-15-000006:notes:157]
The following table summarizes Net sales by segment:

[0000068505-15-000006:notes:158]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Products | $ | 758 |  |  | $ | 752 |  |
| Services | 465 |  |  | 476 |  |
|  | $ | 1,223 |  |  | $ | 1,228 |  |

[0000068505-15-000006:notes:159]
[same as prior period, unchanged from 0000068505-14-000016:notes:170]

[0000068505-15-000006:notes:160]
|  | Three Months Ended |
|  | April 4, 2015 |  | March 29, 2014 |
| Products | $ | 64 |  |  | $ | 39 |  |
| Services | 55 |  |  | 68 |  |
| Operating earnings | 119 |  |  | 107 |  |
| Total other income (expense) | 9 |  |  | (18 | ) |
| Earnings from continuing operations before income taxes | $ | 128 |  |  | $ | 89 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-15-000006:notes:161]
[same as prior period, unchanged from 0000068505-14-000016:notes:172]

[0000068505-15-000006:notes:162]
The Company conducts its business globally and manages it through the following two segments:

[0000068505-15-000006:notes:163]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce.

[0000068505-15-000006:notes:164]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Lifecycle Support services, (iii) Managed services, (iv) Smart Public Safety Solutions, and (v) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications.
