# MSI note change history — 0000068505-14-000016 → 0000068505-15-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000068505-15-000006:note_history:1]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s condensed consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s: (i) results of operations in the periods in which an adverse outcome becomes both probable and estimable or (ii) financial position or liquidity in the periods in which the matters are ultimately resolved.
  (was, 2014-11-04, similarity 0.8333):
[0000068505-14-000016:note_history:1]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s results of operations in the periods in which the matters are ultimately resolved.

- changed (2015-05-06):
[0000068505-15-000006:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at April 4, 2015.
  (was, 2014-11-04, similarity 0.897):
[0000068505-14-000016:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representation and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at September 27, 2014.

- removed (2015-05-06):
[0000068505-14-000016:note_history:3]
Also, pursuant to the Master Separation and Distribution Agreement and certain other agreements entered into in connection with the separation of Motorola Mobility Holdings, Inc. ("Motorola Mobility"),  Motorola Mobility agreed to indemnify the Company for certain liabilities, and the Company agreed to indemnify Motorola Mobility for certain liabilities, in each case for uncapped amounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000068505-15-000006:note_history:4]
The condensed consolidated financial statements as of April 4, 2015 and for the three months ended April 4, 2015 and March 29, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2014-11-04, similarity 0.929):
[0000068505-14-000016:note_history:4]
The condensed consolidated financial statements as of September 27, 2014 and for the three and nine months ended September 27, 2014 and September 28, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2015-05-06):
[0000068505-15-000006:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three months ended April 4, 2015 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2014-11-04, similarity 0.8627):
[0000068505-14-000016:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013 and Form 8-K filed on August 7, 2014.  The results of operations for the three and nine months ended September 27, 2014 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2015-05-06):
[0000068505-15-000006:note_history:6]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for the Company beginning January 1, 2017; however, in April 2015, the FASB proposed a one year delay in the effective date of the standard. This ASU allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.
  (was, 2014-11-04, similarity 0.6266):
[0000068505-14-000016:note_history:6]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for the Company beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- added (2015-05-06):
[0000068505-15-000006:note_history:7]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU 2015-02 changes the consolidation analysis required for limited partnerships and other variable interest entities. This ASU will be effective for the Company beginning January 1, 2016, with early adoption permitted. This ASU allows for either retrospective or modified retrospective application.  The Company does not expect this ASU will have a material impact on its consolidated financial statements.

- added (2015-05-06):
[0000068505-15-000006:note_history:8]
In April 2015, the FASB issued ASU No. 2015-03, "Interest—Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs.” Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. The Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of April 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $19 million.

- added (2015-05-06):
[0000068505-15-000006:note_history:9]
In April 2015, the FASB issued ASU No. 2015-05, "Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Arrangement." Under this guidance, if it is determined that a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses; however, if it is determined that a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. This ASU allows for the option of applying either a full retrospective approach to all periods presented or a prospective approach to all arrangements entered into or materially modified after the effective date of January 1, 2016. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- removed (2015-05-06):
[0000068505-14-000016:note_history:10]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company does not believe this ASU will have a material impact to its consolidated its financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-05-06):
[0000068505-15-000006:note_history:11]
As of April 4, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 4, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the three months ended April 4, 2015.

- removed (2015-05-06):
[0000068505-14-000016:note_history:12]
During the third quarter of 2014, the Company redeemed $400 million aggregate principal amount outstanding of its 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, the Company recognized a loss of $37 million related to the redemption within Other income (expense) in the condensed consolidated statement of operations. The Company issued an aggregate face principal amount of $1.4 billion including: (i) $600 million of 4.000% Senior notes due 2024, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior notes due 2021, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior notes due 2044, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $394 million.

- removed (2015-05-06):
[0000068505-14-000016:note_history:13]
As of September 27, 2014, the Company had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of September 27, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the three and nine months ended September 27, 2014.

- removed (2015-05-06):
[0000068505-14-000016:note_history:14]
As of September 27, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of September 27, 2014.

- removed (2015-05-06):
[0000068505-14-000016:note_history:15]
During the first quarter of 2013, the Company issued an aggregate face principal amount of $600 million of 3.500% Senior Notes due 2023, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds from issuance of this debt of $588 million.
