# MSI note change history — 0000068505-21-000015 → 0000068505-21-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0000068505-21-000021:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As of the second quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.
  (was, 2021-05-06, similarity 0.8713):
[0000068505-21-000015:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. The royalty rate is yet to be determined, and will be set by the Court absent agreement of the parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0000068505-21-000021:note_history:2]
Basis of Presentation
The condensed consolidated financial statements as of July 3, 2021 and for the three and six months ended July 3, 2021 and June 27, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2021-05-06, similarity 0.9461):
[0000068505-21-000015:note_history:2]
Basis of Presentation
The condensed consolidated financial statements as of April 3, 2021 and for the three months ended April 3, 2021 and March 28, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2021-08-05):
[0000068505-21-000021:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three and six months ended July 3, 2021 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2021-05-06, similarity 0.8167):
[0000068505-21-000015:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three months ended April 3, 2021 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2021-08-05):
[0000068505-21-000021:note_history:4]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control, and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) subsequent to quarter end on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended July 3, 2021.
  (was, 2021-05-06, similarity 0.7084):
[0000068505-21-000015:note_history:4]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Analytics, and Command Center Software.

- changed (2021-08-05):
[0000068505-21-000021:note_history:5]
•Video Security and Access Control: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.
  (was, 2021-05-06, similarity 0.9584):
[0000068505-21-000015:note_history:5]
•Video Security and Analytics: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

- added (2021-08-05):
[0000068505-21-000021:note_history:6]
Subsequent to quarter end, on July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete.

- changed (2021-08-05):
[0000068505-21-000021:note_history:7]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2021-05-06, similarity 0.9808):
[0000068505-21-000015:note_history:7]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2021-08-05):
[0000068505-21-000021:note_history:8]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Access Control technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2021-05-06, similarity 0.9776):
[0000068505-21-000015:note_history:8]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Analytics technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2021-08-05):
[0000068505-21-000021:note_history:9]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.
  (was, 2021-05-06, similarity 0.7828):
[0000068505-21-000015:note_history:9]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with

- changed (2021-08-05):
[0000068505-21-000021:note_history:10]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statements and disclosures.
  (was, 2021-05-06, similarity 0.9951):
[0000068505-21-000015:note_history:10]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statement disclosures.

- removed (2021-08-05):
[0000068505-21-000015:note_history:11]
cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-08-05):
[0000068505-21-000021:note_history:12]
Debt and Credit Facilities

- added (2021-08-05):
[0000068505-21-000021:note_history:13]
|  | July 3, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 999 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 11 |  |  | 18 |  |
|  | 5,697 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (9) |  |  | (12) |  |
| Long-term debt | $ | 5,686 |  |  | $ | 5,163 |  |

- added (2021-08-05):
[0000068505-21-000021:note_history:14]
On May 24, 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of its outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. 
After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- changed (2021-08-05):
[0000068505-21-000021:note_history:15]
As of July 3, 2021, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 3, 2021.
  (was, 2021-05-06, similarity 0.8653):
[0000068505-21-000015:note_history:15]
Debt and Credit Facilities
On March 24, 2021, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in March 2026, which can be used for general corporate purposes and letters of credit (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement replaces the Company’s $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022. The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 3, 2021.

- changed (2021-08-05):
[0000068505-21-000021:note_history:16]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 3, 2021 the Company had no outstanding debt under the commercial paper program.
  (was, 2021-05-06, similarity 0.9934):
[0000068505-21-000015:note_history:16]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 3, 2021 the Company had no outstanding debt under the commercial paper program.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-08-05):
[0000068505-21-000021:note_history:17]
|  | July 3, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 999 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 11 |  |  | 18 |  |
|  | 5,697 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (9) |  |  | (12) |  |
| Long-term debt | $ | 5,686 |  |  | $ | 5,163 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0000068505-21-000021:note_history:18]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 3, 2021 and June 27, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2021-05-06, similarity 0.8082):
[0000068505-21-000015:note_history:18]
The following table summarizes the disaggregation of the Company's revenue by segment, geography, major product and service type and customer type for the three months ended April 3, 2021 and March 28, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- added (2021-08-05):
[0000068505-21-000021:note_history:19]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |  | $ | 719 |  |  | $ | 374 |  |  | $ | 1,093 |  |
| International | 329 |  |  | 330 |  |  | 659 |  |  | 249 |  |  | 276 |  |  | 525 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |  | $ | 836 |  |  | $ | 481 |  |  | $ | 1,317 |  |
| Video Security and Access Control | 212 |  |  | 94 |  |  | 306 |  |  | 132 |  |  | 52 |  |  | 184 |  |
| Command Center Software | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 117 |  |  | 117 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |  | $ | 634 |  |  | $ | 611 |  |  | $ | 1,245 |  |
| Indirect | 492 |  |  | 67 |  |  | 559 |  |  | 334 |  |  | 39 |  |  | 373 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |

- added (2021-08-05):
[0000068505-21-000021:note_history:20]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |  | $ | 1,467 |  |  | $ | 742 |  |  | $ | 2,209 |  |
| International | 602 |  |  | 645 |  |  | 1,247 |  |  | 494 |  |  | 570 |  |  | 1,064 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |  | $ | 1,696 |  |  | $ | 970 |  |  | $ | 2,666 |  |
| Video Security and Access Control | 377 |  |  | 182 |  |  | 559 |  |  | 265 |  |  | 119 |  |  | 384 |  |
| Command Center Software | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 223 |  |  | 223 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |  | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 2,507 |  |
| Indirect | 903 |  |  | 135 |  |  | 1,038 |  |  | 686 |  |  | 80 |  |  | 766 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |

- removed (2021-08-05):
[0000068505-21-000015:note_history:21]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |  | $ | 748 |  |  | $ | 368 |  |  | $ | 1,116 |  |
| International | 273 |  |  | 315 |  |  | 588 |  |  | 245 |  |  | 294 |  |  | 539 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |  | $ | 860 |  |  | $ | 490 |  |  | $ | 1,350 |  |
| Video Security and Analytics | 165 |  |  | 88 |  |  | 253 |  |  | 133 |  |  | 67 |  |  | 200 |  |
| Command Center Software | — |  |  | 119 |  |  | 119 |  |  | — |  |  | 105 |  |  | 105 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Customer Type: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |  | $ | 641 |  |  | $ | 621 |  |  | $ | 1,262 |  |
| Indirect | 411 |  |  | 68 |  |  | 479 |  |  | 352 |  |  | 41 |  |  | 393 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0000068505-21-000021:note_history:22]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 3, 2021 and June 27, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2021-05-06, similarity 0.8082):
[0000068505-21-000015:note_history:22]
The following table summarizes the disaggregation of the Company's revenue by segment, geography, major product and service type and customer type for the three months ended April 3, 2021 and March 28, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- added (2021-08-05):
[0000068505-21-000021:note_history:23]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |  | $ | 719 |  |  | $ | 374 |  |  | $ | 1,093 |  |
| International | 329 |  |  | 330 |  |  | 659 |  |  | 249 |  |  | 276 |  |  | 525 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |  | $ | 836 |  |  | $ | 481 |  |  | $ | 1,317 |  |
| Video Security and Access Control | 212 |  |  | 94 |  |  | 306 |  |  | 132 |  |  | 52 |  |  | 184 |  |
| Command Center Software | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 117 |  |  | 117 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |  | $ | 634 |  |  | $ | 611 |  |  | $ | 1,245 |  |
| Indirect | 492 |  |  | 67 |  |  | 559 |  |  | 334 |  |  | 39 |  |  | 373 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |

- added (2021-08-05):
[0000068505-21-000021:note_history:24]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |  | $ | 1,467 |  |  | $ | 742 |  |  | $ | 2,209 |  |
| International | 602 |  |  | 645 |  |  | 1,247 |  |  | 494 |  |  | 570 |  |  | 1,064 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |  | $ | 1,696 |  |  | $ | 970 |  |  | $ | 2,666 |  |
| Video Security and Access Control | 377 |  |  | 182 |  |  | 559 |  |  | 265 |  |  | 119 |  |  | 384 |  |
| Command Center Software | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 223 |  |  | 223 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |  | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 2,507 |  |
| Indirect | 903 |  |  | 135 |  |  | 1,038 |  |  | 686 |  |  | 80 |  |  | 766 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |

- changed (2021-08-05):
[0000068505-21-000021:note_history:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 3, 2021 was $7.1 billion. A total of $3.3 billion was from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion was from Software and Services performance obligations that were not yet satisfied as of July 3, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2021-05-06, similarity 0.9937):
[0000068505-21-000015:note_history:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 3, 2021 was $7.2 billion. A total of $3.3 billion was from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.6 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion was from Software and Services performance obligations that were not yet satisfied as of April 3, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2021-08-05):
[0000068505-21-000021:note_history:26]
| (In millions) | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,169 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 757 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,416 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 296 |  |  | 283 |  |  |  |  |  |
  (was, 2021-05-06, similarity 0.6514):
[0000068505-21-000015:note_history:26]
| (In millions) | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 36 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 105 |  |  |  |  |  |

- added (2021-08-05):
[0000068505-21-000021:note_history:27]
Revenue recognized during the three months ended July 3, 2021 which was previously included in Contract liabilities as of April 3, 2021 was $483 million, compared to $370 million of revenue recognized during the three months ended June 27, 2020 which was previously included in Contract liabilities as of March 28, 2020. Revenue recognized during the six months ended July 3, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $705 million, compared to $631 million recognized during the six months ended June 27, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $10 million and $15 million was reversed during the three and six months ended July 3, 2021, respectively, related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $12 million and $34 million of reversals for the three and six months ended June 27, 2020, respectively.

- changed (2021-08-05):
[0000068505-21-000021:note_history:28]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 3, 2021 and June 27, 2020.
  (was, 2021-05-06, similarity 0.8921):
[0000068505-21-000015:note_history:28]
There were no material expected credit losses recognized on contract assets during each of the three months ended April 3, 2021 and March 28, 2020.

- added (2021-08-05):
[0000068505-21-000021:note_history:29]
| (In millions) | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 30 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 110 |  |  | 105 |  |  |  |  |  |

- changed (2021-08-05):
[0000068505-21-000021:note_history:30]
Amortization of non-current contract cost assets was $12 million and $25 million for the three and six months ended July 3, 2021, respectively, and $11 million and $22 million for the three and six months ended June 27, 2020, respectively
  (was, 2021-05-06, similarity 0.7627):
[0000068505-21-000015:note_history:30]
Amortization of non-current contract cost assets was $13 million for the three months ended April 3, 2021 and $11 million for the three months ended March 28, 2020

- removed (2021-08-05):
[0000068505-21-000015:note_history:31]
|  | Three Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |  | $ | 748 |  |  | $ | 368 |  |  | $ | 1,116 |  |
| International | 273 |  |  | 315 |  |  | 588 |  |  | 245 |  |  | 294 |  |  | 539 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |  | $ | 860 |  |  | $ | 490 |  |  | $ | 1,350 |  |
| Video Security and Analytics | 165 |  |  | 88 |  |  | 253 |  |  | 133 |  |  | 67 |  |  | 200 |  |
| Command Center Software | — |  |  | 119 |  |  | 119 |  |  | — |  |  | 105 |  |  | 105 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |
| Customer Type: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |  | $ | 641 |  |  | $ | 621 |  |  | $ | 1,262 |  |
| Indirect | 411 |  |  | 68 |  |  | 479 |  |  | 352 |  |  | 41 |  |  | 393 |  |
|  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,655 |  |

- removed (2021-08-05):
[0000068505-21-000015:note_history:32]
| (In millions) | April 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,090 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 767 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,419 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 280 |  |  | 283 |  |  |  |  |  |

- removed (2021-08-05):
[0000068505-21-000015:note_history:33]
Revenue recognized during the three months ended April 3, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $396 million, compared to $382 million of revenue recognized during the three months ended March 28, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $4 million was reversed during the three months ended April 3, 2021 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $19 million of reversals for the three months ended March 28, 2020.
