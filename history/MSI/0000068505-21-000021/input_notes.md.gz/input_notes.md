# MSI notes — 0000068505-21-000021


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-21-000021:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of July 3, 2021 and for the three and six months ended July 3, 2021 and June 27, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-21-000021:notes:2]
[same as prior period, unchanged from 0000068505-21-000015:notes:2]

[0000068505-21-000021:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three and six months ended July 3, 2021 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-21-000021:notes:4]
[same as prior period, unchanged from 0000068505-21-000015:notes:4]

[0000068505-21-000021:notes:5]
[same as prior period, unchanged from 0000068505-21-000015:notes:5]

[0000068505-21-000021:notes:6]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control, and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) subsequent to quarter end on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended July 3, 2021.

[0000068505-21-000021:notes:7]
[same as prior period, unchanged from 0000068505-21-000015:notes:7]

[0000068505-21-000021:notes:8]
•Video Security and Access Control: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

[0000068505-21-000021:notes:9]
[same as prior period, unchanged from 0000068505-21-000015:notes:9]

[0000068505-21-000021:notes:10]
[same as prior period, unchanged from 0000068505-21-000015:notes:10]

[0000068505-21-000021:notes:11]
Subsequent to quarter end, on July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete.

[0000068505-21-000021:notes:12]
[same as prior period, unchanged from 0000068505-21-000015:notes:11]

[0000068505-21-000021:notes:13]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000021:notes:14]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Access Control technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000021:notes:15]
[same as prior period, unchanged from 0000068505-21-000015:notes:14]

[0000068505-21-000021:notes:16]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-21-000021:notes:17]
[same as prior period, unchanged from 0000068505-21-000015:notes:17]

[0000068505-21-000021:notes:18]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-21-000021:notes:19]
Recently Adopted Accounting Pronouncements

[0000068505-21-000021:notes:20]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-21-000021:notes:21]
[same as prior period, unchanged from 0000068505-21-000015:notes:21]

[0000068505-21-000021:notes:22]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 3, 2021 and June 27, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-21-000021:notes:23]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |  | $ | 719 |  |  | $ | 374 |  |  | $ | 1,093 |  |
| International | 329 |  |  | 330 |  |  | 659 |  |  | 249 |  |  | 276 |  |  | 525 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |  | $ | 836 |  |  | $ | 481 |  |  | $ | 1,317 |  |
| Video Security and Access Control | 212 |  |  | 94 |  |  | 306 |  |  | 132 |  |  | 52 |  |  | 184 |  |
| Command Center Software | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 117 |  |  | 117 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |  | $ | 634 |  |  | $ | 611 |  |  | $ | 1,245 |  |
| Indirect | 492 |  |  | 67 |  |  | 559 |  |  | 334 |  |  | 39 |  |  | 373 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |

[0000068505-21-000021:notes:24]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |  | $ | 1,467 |  |  | $ | 742 |  |  | $ | 2,209 |  |
| International | 602 |  |  | 645 |  |  | 1,247 |  |  | 494 |  |  | 570 |  |  | 1,064 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |  | $ | 1,696 |  |  | $ | 970 |  |  | $ | 2,666 |  |
| Video Security and Access Control | 377 |  |  | 182 |  |  | 559 |  |  | 265 |  |  | 119 |  |  | 384 |  |
| Command Center Software | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 223 |  |  | 223 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |  | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 2,507 |  |
| Indirect | 903 |  |  | 135 |  |  | 1,038 |  |  | 686 |  |  | 80 |  |  | 766 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |

[0000068505-21-000021:notes:25]
[same as prior period, unchanged from 0000068505-21-000015:notes:24]

[0000068505-21-000021:notes:26]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 3, 2021 was $7.1 billion. A total of $3.3 billion was from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion was from Software and Services performance obligations that were not yet satisfied as of July 3, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-21-000021:notes:27]
[same as prior period, unchanged from 0000068505-21-000015:notes:26]

[0000068505-21-000021:notes:28]
| (In millions) | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,169 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 757 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,416 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 296 |  |  | 283 |  |  |  |  |  |

[0000068505-21-000021:notes:29]
Revenue recognized during the three months ended July 3, 2021 which was previously included in Contract liabilities as of April 3, 2021 was $483 million, compared to $370 million of revenue recognized during the three months ended June 27, 2020 which was previously included in Contract liabilities as of March 28, 2020. Revenue recognized during the six months ended July 3, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $705 million, compared to $631 million recognized during the six months ended June 27, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $10 million and $15 million was reversed during the three and six months ended July 3, 2021, respectively, related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $12 million and $34 million of reversals for the three and six months ended June 27, 2020, respectively.

[0000068505-21-000021:notes:30]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 3, 2021 and June 27, 2020.

[0000068505-21-000021:notes:31]
[same as prior period, unchanged from 0000068505-21-000015:notes:30]

[0000068505-21-000021:notes:32]
| (In millions) | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 30 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 110 |  |  | 105 |  |  |  |  |  |

[0000068505-21-000021:notes:33]
Amortization of non-current contract cost assets was $12 million and $25 million for the three and six months ended July 3, 2021, respectively, and $11 million and $22 million for the three and six months ended June 27, 2020, respectively


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-21-000021:notes:34]
[same as prior period, unchanged from 0000068505-21-000015:notes:33]

[0000068505-21-000021:notes:35]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 34 |  |  | $ | 33 |  |  | $ | 67 |  |  | $ | 67 |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | 3 |  |  | 3 |  |  | 6 |  |  | 6 |  |
| Interest on lease liabilities | — |  |  | — |  |  | — |  |  | 1 |  |
| Total finance lease cost | 3 |  |  | 3 |  |  | 6 |  |  | 7 |  |
| Short-term lease cost | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Variable cost | 9 |  |  | 9 |  |  | 18 |  |  | 17 |  |
| Sublease income | (1) |  |  | (1) |  |  | (2) |  |  | (2) |  |
| Net lease expense | $ | 46 |  |  | $ | 45 |  |  | $ | 91 |  |  | $ | 90 |  |

[0000068505-21-000021:notes:36]
[same as prior period, unchanged from 0000068505-21-000015:notes:35]

[0000068505-21-000021:notes:37]
| (in millions) |  | Statement Line Classification |  | July 3, 2021 |  | December 31, 2020 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 430 |  |  | $ | 468 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 24 |  |  | 30 |  |  |  |
|  |  |  |  | $ | 454 |  |  | $ | 498 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 129 |  |  | $ | 126 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 8 |  |  | 11 |  |  |  |
|  |  |  |  | $ | 137 |  |  | $ | 137 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 340 |  |  | $ | 402 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 2 |  |  | 5 |  |  |  |
|  |  |  |  | $ | 342 |  |  | $ | 407 |  |  |  |

[0000068505-21-000021:notes:38]
[same as prior period, unchanged from 0000068505-21-000015:notes:37]

[0000068505-21-000021:notes:39]
|  | Six Months Ended |  |  |
| (in millions) | July 3, 2021 |  | June 27, 2020 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 95 |  |  | $ | 84 |  |  |  |
| Net cash used for operating activities related to finance leases | — |  |  | 1 |  |  |  |
| Net cash used for financing activities related to finance leases | 7 |  |  | 6 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 22 |  |  | $ | 24 |  |  |  |

[0000068505-21-000021:notes:40]
|  | July 3, 2021 |  | December 31, 2020 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 6 |
| Finance leases | 1 |  | 2 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.16 | % |  | 3.30 | % |
| Finance leases | 4.14 | % |  | 4.21 | % |

[0000068505-21-000021:notes:41]
[same as prior period, unchanged from 0000068505-21-000015:notes:40]

[0000068505-21-000021:notes:42]
|  | July 3, 2021 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2021 | $ | 50 |  |  | $ | 5 |  |  | $ | 55 |  |
| 2022 | 135 |  |  | 5 |  |  | 140 |  |
| 2023 | 79 |  |  | 1 |  |  | 80 |  |
| 2024 | 64 |  |  | — |  |  | 64 |  |
| 2025 | 51 |  |  | — |  |  | 51 |  |
| Thereafter | 140 |  |  | — |  |  | 140 |  |
| Total lease payments | 519 |  |  | 11 |  |  | 530 |  |
| Less: interest | 50 |  |  | 1 |  |  | 51 |  |
| Present value of lease liabilities | $ | 469 |  |  | $ | 10 |  |  | $ | 479 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-21-000021:notes:43]
[same as prior period, unchanged from 0000068505-21-000015:notes:42]

[0000068505-21-000021:notes:44]
[same as prior period, unchanged from 0000068505-21-000015:notes:43]

[0000068505-21-000021:notes:45]
[same as prior period, unchanged from 0000068505-21-000015:notes:44]

[0000068505-21-000021:notes:46]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 58 |  |  | $ | 51 |  |  | $ | 116 |  |  | $ | 104 |  |
| Reorganization of business (Note 14) | 6 |  |  | 26 |  |  | 20 |  |  | 38 |  |
| Operating lease asset impairments | — |  |  | — |  |  | 7 |  |  | — |  |
| Acquisition-related transaction fees | 3 |  |  | 1 |  |  | 4 |  |  | 3 |  |
| Losses on legal settlements | 3 |  |  | 7 |  |  | 3 |  |  | 9 |  |
| Fixed asset impairment | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Gain on sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | (50) |  |
|  | $ | 70 |  |  | $ | 90 |  |  | $ | 150 |  |  | $ | 109 |  |

[0000068505-21-000021:notes:47]
During the six months ended July 3, 2021, the Company recognized $7 million of operating lease asset impairments relating to the consolidation of acquired U.S. manufacturing and distribution facilities. This loss has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-21-000021:notes:48]
During the six months ended June 27, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe. This gain has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-21-000021:notes:49]
[same as prior period, unchanged from 0000068505-21-000015:notes:48]

[0000068505-21-000021:notes:50]
[same as prior period, unchanged from 0000068505-21-000015:notes:49]

[0000068505-21-000021:notes:51]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (46) |  |  | $ | (60) |  |  | $ | (102) |  |  | $ | (114) |  |
| Interest income | 2 |  |  | 2 |  |  | 4 |  |  | 5 |  |
|  | $ | (44) |  |  | $ | (58) |  |  | $ | (98) |  |  | (109) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 31 |  |  | $ | 19 |  |  | $ | 60 |  |  | $ | 39 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (18) |  |  | — |  |  | (18) |  |  | — |  |
| Foreign currency gain (loss) | (6) |  |  | (21) |  |  | 8 |  |  | (3) |  |
| Gain (loss) on derivative instruments | (1) |  |  | 12 |  |  | (9) |  |  | (4) |  |
| Gains on equity method investments | 2 |  |  | — |  |  | 3 |  |  | — |  |
| Fair value adjustments to equity investments | 8 |  |  | 4 |  |  | 13 |  |  | 5 |  |
| Other | (2) |  |  | 2 |  |  | 3 |  |  | (3) |  |
|  | $ | 14 |  |  | $ | 16 |  |  | $ | 60 |  |  | $ | 34 |  |

[0000068505-21-000021:notes:52]
[same as prior period, unchanged from 0000068505-21-000015:notes:51]

[0000068505-21-000021:notes:53]
[same as prior period, unchanged from 0000068505-21-000015:notes:52]

[0000068505-21-000021:notes:54]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 293 |  |  | $ | 135 |  |  | $ | 537 |  |  | $ | 332 |  |
| Weighted average common shares outstanding | 169.6 |  |  | 170.0 |  |  | 169.4 |  |  | 170.3 |  |
| Per share amount | $ | 1.73 |  |  | $ | 0.79 |  |  | $ | 3.17 |  |  | $ | 1.95 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 293 |  |  | $ | 135 |  |  | $ | 537 |  |  | $ | 332 |  |
| Weighted average common shares outstanding | 169.6 |  |  | 170.0 |  |  | 169.4 |  |  | 170.3 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.5 |  |  | 3.6 |  |  | 3.7 |  |  | 4.5 |  |
| 1.75% senior convertible notes | — |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 173.1 |  |  | 173.6 |  |  | 173.1 |  |  | 174.8 |  |
| Per share amount | $ | 1.69 |  |  | $ | 0.78 |  |  | $ | 3.10 |  |  | $ | 1.90 |  |

[0000068505-21-000021:notes:55]
In the computation of diluted earnings per common share for the three months ended July 3, 2021, the assumed exercise of 0.4 million options, including 0.2 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the six months ended July 3, 2021, the assumed exercise of 0.4 options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-21-000021:notes:56]
In the computation of diluted earnings per common share for the three months ended June 27, 2020, 0.6 million options, including 0.2 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the six months ended June 27, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-21-000021:notes:57]
As of July 3, 2021, the Company had $1.0 billion of 1.75% Senior Convertible Notes outstanding which mature on September 15, 2024 ("Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the Senior

[0000068505-21-000021:notes:58]
Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price for the period exceeds the conversion price of $203.50. The conversion price is adjusted for dividends declared through the date of settlement. For the period ended July 3, 2021, there was no dilutive effect of the Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price.

[0000068505-21-000021:notes:59]
[same as prior period, unchanged from 0000068505-21-000015:notes:56]

[0000068505-21-000021:notes:60]
[same as prior period, unchanged from 0000068505-21-000015:notes:57]

[0000068505-21-000021:notes:61]
[same as prior period, unchanged from 0000068505-21-000015:notes:58]

[0000068505-21-000021:notes:62]
|  | July 3, 2021 |  | December 31, 2020 |
| Accounts receivable | $ | 1,244 |  |  | $ | 1,465 |  |
| Less allowance for credit losses | (75) |  |  | (75) |  |
|  | $ | 1,169 |  |  | $ | 1,390 |  |

[0000068505-21-000021:notes:63]
[same as prior period, unchanged from 0000068505-21-000015:notes:60]

[0000068505-21-000021:notes:64]
[same as prior period, unchanged from 0000068505-21-000015:notes:61]

[0000068505-21-000021:notes:65]
|  | July 3, 2021 |  | December 31, 2020 |
| Finished goods | $ | 261 |  |  | $ | 271 |  |
| Work-in-process and production materials | 429 |  |  | 360 |  |
|  | 690 |  |  | 631 |  |
| Less inventory reserves | (131) |  |  | (123) |  |
|  | $ | 559 |  |  | $ | 508 |  |

[0000068505-21-000021:notes:66]
[same as prior period, unchanged from 0000068505-21-000015:notes:63]

[0000068505-21-000021:notes:67]
[same as prior period, unchanged from 0000068505-21-000015:notes:64]

[0000068505-21-000021:notes:68]
|  | July 3, 2021 |  | December 31, 2020 |
| Current contract cost assets (Note 2) | $ | 30 |  |  | $ | 23 |  |
| Tax-related deposits | 44 |  |  | 52 |  |
| Other | 180 |  |  | 167 |  |
|  | $ | 254 |  |  | $ | 242 |  |

[0000068505-21-000021:notes:69]
[same as prior period, unchanged from 0000068505-21-000015:notes:66]

[0000068505-21-000021:notes:70]
[same as prior period, unchanged from 0000068505-21-000015:notes:67]

[0000068505-21-000021:notes:71]
|  | July 3, 2021 |  | December 31, 2020 |
| Land | $ | 4 |  |  | $ | 6 |  |
| Leasehold improvements | 473 |  |  | 439 |  |
| Machinery and equipment | 2,378 |  |  | 2,276 |  |
|  | 2,855 |  |  | 2,721 |  |
| Less accumulated depreciation | (1,827) |  |  | (1,699) |  |
|  | $ | 1,028 |  |  | $ | 1,022 |  |

[0000068505-21-000021:notes:72]
Depreciation expense for the three months ended July 3, 2021 and June 27, 2020 was $52 million and $47 million, respectively. Depreciation expense for the six months ended July 3, 2021 and June 27, 2020 was $104 million and $93 million, respectively.

[0000068505-21-000021:notes:73]
[same as prior period, unchanged from 0000068505-21-000015:notes:70]

[0000068505-21-000021:notes:74]
[same as prior period, unchanged from 0000068505-21-000015:notes:71]

[0000068505-21-000021:notes:75]
|  | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Common stock | $ | 30 |  |  | $ | 19 |  |  |  |  |  |
| Strategic investments, at cost | 54 |  |  | 46 |  |  |  |  |  |
| Company-owned life insurance policies | 79 |  |  | 77 |  |  |  |  |  |
| Equity method investments | 18 |  |  | 16 |  |  |  |  |  |
|  | $ | 181 |  |  | $ | 158 |  |  |  |  |  |

[0000068505-21-000021:notes:76]
Subsequent to quarter end, on July 16, 2021, the Company invested $50 million in equity securities of NewHold Investment Corp., which completed a business combination with Evolv Technologies, Inc. The equity securities will be carried at fair value with changes in fair value recorded in Other, net within Other income (expense).

[0000068505-21-000021:notes:77]
[same as prior period, unchanged from 0000068505-21-000015:notes:73]

[0000068505-21-000021:notes:78]
[same as prior period, unchanged from 0000068505-21-000015:notes:74]

[0000068505-21-000021:notes:79]
|  | July 3, 2021 |  | December 31, 2020 |
| Defined benefit plan assets | $ | 332 |  |  | $ | 283 |  |
| Non-current contract cost assets (Note 2) | 110 |  |  | 105 |  |
| Other | 67 |  |  | 94 |  |
|  | $ | 509 |  |  | $ | 482 |  |

[0000068505-21-000021:notes:80]
[same as prior period, unchanged from 0000068505-21-000015:notes:76]

[0000068505-21-000021:notes:81]
[same as prior period, unchanged from 0000068505-21-000015:notes:77]

[0000068505-21-000021:notes:82]
|  | July 3, 2021 |  | December 31, 2020 |
| Compensation | $ | 235 |  |  | $ | 291 |  |
| Tax liabilities | 81 |  |  | 147 |  |
| Dividend payable | 120 |  |  | 120 |  |
| Trade liabilities | 157 |  |  | 164 |  |
| Operating lease liabilities (Note 3) | 129 |  |  | 126 |  |
| Other | 490 |  |  | 463 |  |
|  | $ | 1,212 |  |  | $ | 1,311 |  |

[0000068505-21-000021:notes:83]
[same as prior period, unchanged from 0000068505-21-000015:notes:79]

[0000068505-21-000021:notes:84]
[same as prior period, unchanged from 0000068505-21-000015:notes:80]

[0000068505-21-000021:notes:85]
|  | July 3, 2021 |  | December 31, 2020 |
| Defined benefit plans | $ | 1,504 |  |  | $ | 1,578 |  |
| Non-current contract liabilities (Note 2) | 296 |  |  | 283 |  |
| Deferred income taxes | 178 |  |  | 180 |  |
| Other | 287 |  |  | 322 |  |
|  | $ | 2,265 |  |  | $ | 2,363 |  |

[0000068505-21-000021:notes:86]
[same as prior period, unchanged from 0000068505-21-000015:notes:82]

[0000068505-21-000021:notes:87]
Share Repurchase Program: During the three and six months ended July 3, 2021, the Company paid an aggregate of $102 million and $272 million, including transaction costs, to repurchase approximately 0.5 million and 1.5 million shares at an average price of $206.85 and $186.08 per share, respectively. During the three months ended July 3, 2021, the Board of Directors approved a $2.0 billion increase to the share repurchase program. As of July 3, 2021, the Company had $2.4 billion of authority available for future repurchases.

[0000068505-21-000021:notes:88]
Payment of Dividends: During the three months ended July 3, 2021 and June 27, 2020, the Company paid $121 million and $109 million, respectively, in cash dividends to holders of its common stock. During the six months ended July 3, 2021 and June 27, 2020, the Company paid $242 million and $218 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $120 million in cash dividends to holders of its common stock.

[0000068505-21-000021:notes:89]
[same as prior period, unchanged from 0000068505-21-000015:notes:85]

[0000068505-21-000021:notes:90]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended July 3, 2021 and June 27, 2020:

[0000068505-21-000021:notes:91]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (341) |  |  | $ | (548) |  |  | $ | (360) |  |  | $ | (410) |  |
| Other comprehensive income (loss) before reclassification adjustment | 6 |  |  | 75 |  |  | 23 |  |  | (61) |  |
| Tax benefit | — |  |  | 3 |  |  | 2 |  |  | 1 |  |
| Other comprehensive income (loss), net of tax | 6 |  |  | 78 |  |  | 25 |  |  | (60) |  |
| Balance at end of period | $ | (335) |  |  | $ | (470) |  |  | $ | (335) |  |  | $ | (470) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,069) |  |  | $ | (2,018) |  |  | $ | (2,086) |  |  | $ | (2,030) |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 21 |  |  | 19 |  |  | 43 |  |  | 38 |  |
| Reclassification adjustment - Prior service benefits into Other expense (Note 8) | (2) |  |  | (4) |  |  | (4) |  |  | (8) |  |
| Tax benefit | (3) |  |  | (2) |  |  | (6) |  |  | (5) |  |
| Other comprehensive income, net of tax | 16 |  |  | 13 |  |  | 33 |  |  | 25 |  |
| Balance at end of period | $ | (2,053) |  |  | $ | (2,005) |  |  | $ | (2,053) |  |  | $ | (2,005) |  |
| Total Accumulated other comprehensive loss | $ | (2,388) |  |  | $ | (2,475) |  |  | $ | (2,388) |  |  | $ | (2,475) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-21-000021:notes:92]
Debt and Credit Facilities

[0000068505-21-000021:notes:93]
|  | July 3, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 999 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 11 |  |  | 18 |  |
|  | 5,697 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (9) |  |  | (12) |  |
| Long-term debt | $ | 5,686 |  |  | $ | 5,163 |  |

[0000068505-21-000021:notes:94]
On May 24, 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of its outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. 
After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-21-000021:notes:95]
As of July 3, 2021, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 3, 2021.

[0000068505-21-000021:notes:96]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 3, 2021 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-21-000021:notes:97]
[same as prior period, unchanged from 0000068505-21-000015:notes:90]

[0000068505-21-000021:notes:98]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.2 billion for each of the periods ended July 3, 2021 and December 31, 2020. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-21-000021:notes:99]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of July 3, 2021, and the corresponding positions as of December 31, 2020:

[0000068505-21-000021:notes:100]
|  | Notional Amount |
| Net Buy (Sell) by Currency | July 3, 2021 |  | December 31, 2020 |
| Euro | $ | 173 |  |  | $ | 177 |  |
| Canadian dollar | 54 |  |  | 61 |  |
| British pound | 48 |  |  | 86 |  |
| Chinese renminbi | (99) |  |  | (90) |  |
| Australian dollar | (89) |  |  | (88) |  |

[0000068505-21-000021:notes:101]
[same as prior period, unchanged from 0000068505-21-000015:notes:94]

[0000068505-21-000021:notes:102]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of July 3, 2021, all of the counterparties had investment grade credit ratings. As of July 3, 2021, the Company had $5 million of exposure to aggregate credit risk with all counterparties.

[0000068505-21-000021:notes:103]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of July 3, 2021 and December 31, 2020:

[0000068505-21-000021:notes:104]
|  | Fair Values of Derivative Instruments |
| July 3, 2021 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 4 |  |  | $ | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 1 |  |  | 10 |  |
| Total derivatives | $ | 5 |  |  | $ | 11 |  |

[0000068505-21-000021:notes:105]
[same as prior period, unchanged from 0000068505-21-000015:notes:98]

[0000068505-21-000021:notes:106]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended July 3, 2021 and June 27, 2020:

[0000068505-21-000021:notes:107]
|  | Financial Statement Location | Three Months Ended |  | Six Months Ended |
| Foreign Exchange Contracts | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Effective portion | Accumulated othercomprehensive income | $ | (1) |  |  | $ | (11) |  |  | $ | 3 |  |  | $ | 8 |  |
| Forward points recognized | Other income (expense) | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Undesignated derivatives recognized | Other income (expense) | (1) |  |  | 12 |  |  | (9) |  |  | (4) |  |

[0000068505-21-000021:notes:108]
[same as prior period, unchanged from 0000068505-21-000015:notes:101]

[0000068505-21-000021:notes:109]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of July 3, 2021, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £125 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-21-000021:notes:110]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. During the six months ended July 3, 2021, the Company amortized $1 million of income from the excluded components through interest expense. During the three and six months ended June 27, 2020, the Company amortized $1 million and $2 million, respectively, of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-21-000021:notes:111]
[same as prior period, unchanged from 0000068505-21-000015:notes:103]

[0000068505-21-000021:notes:112]
[same as prior period, unchanged from 0000068505-21-000015:notes:104]

[0000068505-21-000021:notes:113]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Net earnings before income taxes | $ | 340 |  |  | $ | 176 |  |  | $ | 630 |  |  | $ | 401 |  |
| Income tax expense | 46 |  |  | 40 |  |  | 90 |  |  | 67 |  |
| Effective tax rate | 14 | % |  | 23 | % |  | 14 | % |  | 17 | % |

[0000068505-21-000021:notes:114]
The effective tax rate for the three months ended July 3, 2021 of 14% was different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset by a tax benefit related to a partial release of $33 million of a valuation allowance recorded on the U.S. foreign tax credit carryforward. The effective tax rate for the six months ended July 3, 2021 of 14% was different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset by a tax benefit related to a partial release of $33 million of a valuation allowance recorded on the U.S foreign tax credit carryforward and the recognition of excess tax benefits of share-based compensation.

[0000068505-21-000021:notes:115]
The effective tax rates for the three and six months ended June 27, 2020 of 23% and 17%, respectively, were different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset by excess tax benefits on share-based compensation.

[0000068505-21-000021:notes:116]
The effective tax rate for the three and six months ended July 3, 2021 of 14% was lower than the effective tax rates for the three and six months ended June 27, 2020 of 23% and 17%, respectively, primarily due to a tax benefit of $33 million related to a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-21-000021:notes:117]
[same as prior period, unchanged from 0000068505-21-000015:notes:107]

[0000068505-21-000021:notes:118]
[same as prior period, unchanged from 0000068505-21-000015:notes:108]

[0000068505-21-000021:notes:119]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 29 |  |  | 36 |  |  | 5 |  |  | 7 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (59) |  |  | (56) |  |  | (25) |  |  | (22) |  |  | (2) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 17 |  |  | 14 |  |  | 4 |  |  | 4 |  |  | — |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (2) |  |  | (4) |  |
| Net periodic pension benefits | $ | (13) |  |  | $ | (6) |  |  | $ | (16) |  |  | $ | (10) |  |  | $ | (3) |  |  | $ | (5) |  |

[0000068505-21-000021:notes:120]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 58 |  |  | 72 |  |  | 10 |  |  | 14 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (118) |  |  | (112) |  |  | (50) |  |  | (42) |  |  | (5) |  |  | (5) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 34 |  |  | 29 |  |  | 8 |  |  | 7 |  |  | 1 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | (1) |  |  | (3) |  |  | (7) |  |
| Net periodic pension benefits | $ | (26) |  |  | $ | (11) |  |  | $ | (32) |  |  | $ | (21) |  |  | $ | (6) |  |  | $ | (9) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-21-000021:notes:121]
[same as prior period, unchanged from 0000068505-21-000015:notes:110]

[0000068505-21-000021:notes:122]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 9 |  |
| Selling, general and administrative expenses | 19 |  |  | 18 |  |  | 36 |  |  | 39 |  |
| Research and development expenditures | 8 |  |  | 9 |  |  | 16 |  |  | 21 |  |
| Share-based compensation expense included in Operating earnings | 31 |  |  | 31 |  |  | 60 |  |  | 69 |  |
| Tax benefit | (2) |  |  | (5) |  |  | (8) |  |  | (11) |  |
| Share-based compensation expense, net of tax | $ | 29 |  |  | $ | 26 |  |  | $ | 52 |  |  | $ | 58 |  |
| Decrease in basic earnings per share | $ | (0.17) |  |  | $ | (0.15) |  |  | $ | (0.31) |  |  | $ | (0.34) |  |
| Decrease in diluted earnings per share | $ | (0.17) |  |  | $ | (0.15) |  |  | $ | (0.30) |  |  | $ | (0.33) |  |

[0000068505-21-000021:notes:123]
During the six months ended July 3, 2021, the Company granted 0.4 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $64 million, $15 million, and $10 million, respectively, and 0.2 million stock options and 0.2 million performance options (POs) with an aggregate grant-date fair value of $8 million and $10 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-21-000021:notes:124]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of July 3, 2021 and December 31, 2020 were as follows:

[0000068505-21-000021:notes:125]
| July 3, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |
| Common stock | 30 |  |  | — |  |  |  |  | 30 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 11 |  |  |  |  | $ | 11 |  |

[0000068505-21-000021:notes:126]
[same as prior period, unchanged from 0000068505-21-000015:notes:115]

[0000068505-21-000021:notes:127]
The Company had no Level 3 holdings as of July 3, 2021 or December 31, 2020.

[0000068505-21-000021:notes:128]
At July 3, 2021 and December 31, 2020, the Company had $811 million and $448 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-21-000021:notes:129]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at July 3, 2021 and December 31, 2020 was $6.3 billion and $5.8 billion (Level 2), respectively.

[0000068505-21-000021:notes:130]
[same as prior period, unchanged from 0000068505-21-000015:notes:119]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-21-000021:notes:131]
[same as prior period, unchanged from 0000068505-21-000015:notes:120]

[0000068505-21-000021:notes:132]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended July 3, 2021 and June 27, 2020:

[0000068505-21-000021:notes:133]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Contract-specific discounting facility | $ | 36 |  |  | $ | 54 |  |  | $ | 107 |  |  | $ | 98 |  |
| Accounts receivable sales proceeds | 8 |  |  | 34 |  |  | 8 |  |  | 58 |  |
| Long-term receivables sales proceeds | 30 |  |  | 29 |  |  | 84 |  |  | 70 |  |
| Total proceeds from receivable sales | $ | 74 |  |  | $ | 117 |  |  | $ | 199 |  |  | $ | 226 |  |

[0000068505-21-000021:notes:134]
At July 3, 2021, the Company had retained servicing obligations for $931 million of long-term receivables, compared to $983 million at December 31, 2020. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $99 million at July 3, 2021, compared to $78 million at December 31, 2020.

[0000068505-21-000021:notes:135]
During the three and six months ended July 3, 2021, the Company utilized a contract-specific receivable discounting facility which began during the six months ended June 27, 2020, resulting in accounts receivable sales of $36 million and $107 million, respectively. The proceeds of the Company's receivable sales are included in Operating activities within the Company's Condensed Consolidated Statements of Cash Flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-21-000021:notes:136]
Commitments and Contingencies
Legal Matters

[0000068505-21-000021:notes:137]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As of the second quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.

[0000068505-21-000021:notes:138]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest, although the precise amount of interest owed to the Company by Hytera is still to be determined by the Court. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award.
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-21-000021:notes:139]
Segment Information
Net Sales by Segment

[0000068505-21-000021:notes:140]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Products and Systems Integration | $ | 1,198 |  |  | $ | 968 |  |  | $ | 2,213 |  |  | $ | 1,961 |  |
| Software and Services | 773 |  |  | 650 |  |  | 1,531 |  |  | 1,312 |  |
|  | $ | 1,971 |  |  | $ | 1,618 |  |  | $ | 3,744 |  |  | $ | 3,273 |  |

[0000068505-21-000021:notes:141]
Operating Earnings by Segment

[0000068505-21-000021:notes:142]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Products and Systems Integration | $ | 139 |  |  | $ | 49 |  |  | $ | 216 |  |  | $ | 141 |  |
| Software and Services | 231 |  |  | 169 |  |  | 452 |  |  | 335 |  |
| Operating earnings | 370 |  |  | 218 |  |  | 668 |  |  | 476 |  |
| Total other expense | (30) |  |  | (42) |  |  | (38) |  |  | (75) |  |
| Earnings before income taxes | $ | 340 |  |  | $ | 176 |  |  | $ | 630 |  |  | $ | 401 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-21-000021:notes:143]
[same as prior period, unchanged from 0000068505-21-000015:notes:132]

[0000068505-21-000021:notes:144]
During the three months ended July 3, 2021, the Company recorded net reorganization of business charges of $9 million, including $6 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $9 million were charges of $12 million related to employee separation, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-21-000021:notes:145]
During the six months ended July 3, 2021, the Company recorded net reorganization of business charges of $25 million, including $20 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $30 million related to employee separation, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-21-000021:notes:146]
[same as prior period, unchanged from 0000068505-21-000015:notes:134]

[0000068505-21-000021:notes:147]
| July 3, 2021 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 7 |  |  | $ | 19 |  |
| Software and Services | 2 |  |  | 6 |  |
|  | $ | 9 |  |  | $ | 25 |  |

[0000068505-21-000021:notes:148]
[same as prior period, unchanged from 0000068505-21-000015:notes:136]

[0000068505-21-000021:notes:149]
| January 1, 2021 |  | Additional Charges |  | Adjustments |  | Amount Used |  | July 3, 2021 |
| $ | 79 |  |  | $ | 30 |  |  | $ | (5) |  |  | $ | (56) |  |  | $ | 48 |  |

[0000068505-21-000021:notes:150]
[same as prior period, unchanged from 0000068505-21-000015:notes:138]

[0000068505-21-000021:notes:151]
At January 1, 2021, the Company had an accrual of $79 million for employee separation costs. The 2021 additional charges of $30 million represent severance costs for approximately 400 employees. The adjustment of $5 million reflects reversals for accruals no longer needed. The $56 million used reflects cash payments to severed employees. The remaining accrual of $48 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at July 3, 2021, is expected to be paid, primarily within one year, to approximately 1,000 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-21-000021:notes:152]
[same as prior period, unchanged from 0000068505-21-000015:notes:140]

[0000068505-21-000021:notes:153]
During the three months ended June 27, 2020, the Company recorded net reorganization of business charges of $41 million, including $26 million of charges in Other charges and $15 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $41 million were charges of $46 million related to employee separation, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-21-000021:notes:154]
During the six months ended June 27, 2020, the Company recorded net reorganization of business charges of $59 million, including $38 million of charges in Other charges and $21 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $59 million were charges of $68 million related to employee separation costs and $9 million of reversals for accruals no longer needed.

[0000068505-21-000021:notes:155]
| June 27, 2020 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 33 |  |  | $ | 47 |  |
| Software and Services | 8 |  |  | 12 |  |
|  | $ | 41 |  |  | $ | 59 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-21-000021:notes:156]
Intangible Assets and Goodwill
Subsequent to quarter end, on July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-21-000021:notes:157]
On August 28, 2020, the Company acquired Callyo, a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing Command Center Software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The Company recognized $38 million of goodwill, $31 million of identifiable intangible assets, and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $27 million of customer relationships and $4 million of developed technology that will be amortized over a period of fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-21-000021:notes:158]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $35 million of goodwill, $30 million of identifiable intangible assets, and $42 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000021:notes:159]
On June 16, 2020, the Company acquired IndigoVision for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Access Control technology, providing enhanced geographical reach across a wider customer base. The Company recognized $18 million of goodwill, $22 million of identifiable intangible assets and $5 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting was completed as of the second quarter of 2021.

[0000068505-21-000021:notes:160]
[same as prior period, unchanged from 0000068505-21-000015:notes:147]

[0000068505-21-000021:notes:161]
[same as prior period, unchanged from 0000068505-21-000015:notes:148]

[0000068505-21-000021:notes:162]
[same as prior period, unchanged from 0000068505-21-000015:notes:149]

[0000068505-21-000021:notes:163]
[same as prior period, unchanged from 0000068505-21-000015:notes:150]

[0000068505-21-000021:notes:164]
|  | July 3, 2021 |  | December 31, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 766 |  |  | $ | 245 |  |  | $ | 766 |  |  | $ | 210 |  |
| Customer-related | 1,354 |  |  | 777 |  |  | 1,335 |  |  | 685 |  |
| Other intangibles | 81 |  |  | 56 |  |  | 80 |  |  | 52 |  |
|  | $ | 2,201 |  |  | $ | 1,078 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-21-000021:notes:165]
Amortization expense on intangible assets was $58 million and $116 million for the three and six months ended July 3, 2021, respectively. Amortization expense on intangible assets was $51 million and $104 million for the three and six months ended June 27, 2020, respectively. As of July 3, 2021, annual amortization expense is estimated to be $209 million in 2021, $206 million in 2022, $108 million in 2023, $83 million in 2024, $73 million in 2025, and $69 million in 2026.

[0000068505-21-000021:notes:166]
[same as prior period, unchanged from 0000068505-21-000015:notes:153]

[0000068505-21-000021:notes:167]
|  | July 3, 2021 |  | December 31, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 694 |  |  | $ | 154 |  |  | $ | 692 |  |  | $ | 129 |  |
| Software and Services | 1,507 |  |  | 924 |  |  | 1,489 |  |  | 818 |  |
|  | $ | 2,201 |  |  | $ | 1,078 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-21-000021:notes:168]
[same as prior period, unchanged from 0000068505-21-000015:notes:155]

[0000068505-21-000021:notes:169]
The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2021 to July 3, 2021:

[0000068505-21-000021:notes:170]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2021 | $ | 1,019 |  |  | $ | 1,200 |  |  | $ | 2,219 |  |
| Purchase accounting adjustments | (3) |  |  | (1) |  |  | (4) |  |
| Foreign currency | — |  |  | 4 |  |  | 4 |  |
| Balance as of July 3, 2021 | $ | 1,016 |  |  | $ | 1,203 |  |  | $ | 2,219 |  |
