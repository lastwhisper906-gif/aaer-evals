# MSI 8-K — 0000068505-21-000019 filed 2021-08-05

## item codes, every 8-K on or before 2021-08-05

- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2021-08-05

- none on or before 2021-08-05

## item 2.02 — earnings release, exhibit 99.1

[0000068505-21-000019:8k_2_02:1]
EX-99.1
2
msiq22021pressrelease.htm
EX-99.1

[0000068505-21-000019:8k_2_02:2]
Document

[0000068505-21-000019:8k_2_02:3]
Exhibit 99.1

[0000068505-21-000019:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2021 Financial Results

[0000068505-21-000019:8k_2_02:5]
Company raises full-year revenue and EPS guidance again following record Q2 revenue and earnings

[0000068505-21-000019:8k_2_02:6]
•Sales of $2.0 billion, up 22% versus a year ago

[0000068505-21-000019:8k_2_02:7]
◦Products and Systems Integration sales up 24%

[0000068505-21-000019:8k_2_02:8]
◦Software and Services sales up 19%

[0000068505-21-000019:8k_2_02:9]
•GAAP earnings per share (EPS) of $1.69

[0000068505-21-000019:8k_2_02:10]
•Non-GAAP EPS* of $2.07, up 49% versus a year ago

[0000068505-21-000019:8k_2_02:11]
•Backlog of $11.2 billion, up 7% versus a year ago

[0000068505-21-000019:8k_2_02:12]
•Generated $388 million of operating cash flow, up 86% versus a year ago

[0000068505-21-000019:8k_2_02:13]
•Subsequent to quarter end, acquired Openpath, a leader in cloud-based access control solutions for $297 million

[0000068505-21-000019:8k_2_02:14]
CHICAGO – August 5, 2021 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2021.

[0000068505-21-000019:8k_2_02:15]
“Our Q2 results were outstanding, highlighted by strong double-digit growth in both segments," said Greg Brown, chairman and CEO, Motorola Solutions. “The continued strong demand for our mission-critical technologies is driving our increased expectations for the full year.”

[0000068505-21-000019:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-21-000019:8k_2_02:17]
|  | Q2 2021 |  | Q2 2020 | % Change |
| Sales | $1,971 |  | $1,618 | 22 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $370 |  | $218 | 70 | % |
| % of Sales | 18.8 | % |  | 13.5 | % |  |
| EPS | $1.69 |  | $0.78 | 117 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $482 |  | $359 | 34 | % |
| % of Sales | 24.4 | % |  | 22.2 | % |  |
| EPS | $2.07 |  | $1.39 | 49 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,198 |  | $968 | 24 | % |
| GAAP Operating Earnings | $139 |  | $49 | 184 | % |
| % of Sales | 11.6 | % |  | 5.1 | % |  |
| Non-GAAP Operating Earnings* | $194 |  | $131 | 48 | % |
| % of Sales | 16.2 | % |  | 13.5 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $773 |  | $650 | 19 | % |
| GAAP Operating Earnings | $231 |  | $169 | 37 | % |
| % of Sales | 29.9 | % |  | 26.0 | % |  |
| Non-GAAP Operating Earnings* | $288 |  | $228 | 26 | % |
| % of Sales | 37.2 | % |  | 35.1 | % |  |

[0000068505-21-000019:8k_2_02:18]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.38 per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-21-000019:8k_2_02:19]
1

[0000068505-21-000019:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-21-000019:8k_2_02:21]
•Revenue - Sales were $2.0 billion, up 22% from the year-ago quarter driven by growth in both North America and International. Revenue from acquisitions was $47 million and currency tailwinds were $66 million in the quarter. The Products and Systems Integration segment grew 24% driven by growth in land mobile radio (LMR) and video security. The Software and Services segment grew 19%, driven by growth in LMR services, video security and command center software.

[0000068505-21-000019:8k_2_02:22]
•Operating margin - GAAP operating margin was 18.8% of sales, up from 13.5% in the year-ago quarter. Non-GAAP operating margin was 24.4% of sales, up from 22.2% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margins was primarily due to higher sales and improved operating leverage in both segments, including higher costs related to incentive compensation. GAAP operating margin was also positively impacted by lower reorganization charges in the current quarter as compared to the year-ago quarter.

[0000068505-21-000019:8k_2_02:23]
•Taxes - The GAAP effective tax rate was 13.5%, compared to 22.7% in the year-ago quarter, primarily driven by a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward. The non-GAAP effective tax rate was 20.5%, compared to 22.8% in the year-ago quarter driven by discrete items, including benefits from stock-based compensation.

[0000068505-21-000019:8k_2_02:24]
•Cash flow - Operating cash flow was $388 million, compared to $209 million in the year-ago quarter. Free cash flow was $326 million, compared to $155 million in the year-ago quarter. Cash flow for the quarter increased primarily due to higher earnings and improved working capital, partially offset by higher cash taxes.

[0000068505-21-000019:8k_2_02:25]
•Capital allocation - During the quarter, the company repurchased $102 million of shares, paid $121 million in cash dividends and incurred $62 million of capital expenditures. Additionally, during the quarter the company issued $850 million of new long-term debt and redeemed $324 million outstanding of its senior notes due 2023. Subsequent to the quarter end, the company acquired Openpath for $297 million, net of cash acquired, and invested $50 million in equity securities of Evolv Technologies.

[0000068505-21-000019:8k_2_02:26]
•Backlog - The company ended the quarter with backlog of $11.2 billion, up 7%, or $741 million, from the year-ago quarter. Products and Systems Integration segment backlog was up 17%, or $484 million. The growth was primarily driven by strong LMR demand in North America and International. Software and Services segment backlog was up 3% or $257 million. The growth was primarily driven by multi-year services and software agreements in North America.

[0000068505-21-000019:8k_2_02:27]
2

[0000068505-21-000019:8k_2_02:28]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-21-000019:8k_2_02:29]
Software and Services

[0000068505-21-000019:8k_2_02:30]
•$18 million French MOI body-worn camera frame agreement

[0000068505-21-000019:8k_2_02:31]
•$15 million license plate recognition software extension with a U.S. customer

[0000068505-21-000019:8k_2_02:32]
•$10 million P25 multi-year services extension for the state of Ohio

[0000068505-21-000019:8k_2_02:33]
•$10 million P25 maintenance renewal with a U.S. federal customer

[0000068505-21-000019:8k_2_02:34]
•Launched CommandCentral suite, public safety’s first cloud-native 911 call to case closure solution

[0000068505-21-000019:8k_2_02:35]
Products and Systems Integration

[0000068505-21-000019:8k_2_02:36]
•$37 million P25 upgrade order for the Kentucky State Police

[0000068505-21-000019:8k_2_02:37]
•$36 million P25 upgrade for a state in the U.S.

[0000068505-21-000019:8k_2_02:38]
•$30 million P25 order for Metro Atlantic Rapid Transit Authority

[0000068505-21-000019:8k_2_02:39]
•$29 million P25 devices order for a large U.S. state and local customer

[0000068505-21-000019:8k_2_02:40]
•$5 million video security order, the largest single fixed video order for a U.S. federal government customer

[0000068505-21-000019:8k_2_02:41]
BUSINESS OUTLOOK

[0000068505-21-000019:8k_2_02:42]
•Third-quarter 2021 - Motorola Solutions expects revenue growth of approximately 10% compared to the third quarter of 2020. The company expects non-GAAP EPS in the range of $2.09 to $2.14. This assumes current foreign exchange rates, approximately 174 million fully diluted shares, and an effective tax rate of 23% to 24%.

[0000068505-21-000019:8k_2_02:43]
•Full-year 2021 - Motorola Solutions now expects revenue growth of 9.5% to 10%, up from the prior guidance of growth of 8% to 9%, and non-GAAP EPS in the range of $8.88 to $8.98, up from the prior guidance of $8.70 to $8.80. This assumes current foreign exchange rates, approximately 173 million fully diluted shares, and an effective tax rate of approximately 22%.

[0000068505-21-000019:8k_2_02:44]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-21-000019:8k_2_02:45]
COVID-19

[0000068505-21-000019:8k_2_02:46]
In response to the COVID-19 pandemic, the company continues to monitor the daily evolution of the pandemic, including the spread of the delta variant, and adhere to its plans to keep its employees and customers healthy and safe, including encouraging office workers to work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings and using thermal scanning. The company has continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service its mission-critical networks on-site as needed to ensure seamless operations.

[0000068505-21-000019:8k_2_02:47]
The sales teams have continued to improve virtual engagement with the company's customers. Additionally, the company’s engineering teams have adapted its solutions offerings to equip customers with the latest technology in an effort to protect their workplaces from the spread of COVID-19. The company has adapted its software and hardware offerings to provide analytics for occupancy counting, face mask detection and thermal detection capabilities.

[0000068505-21-000019:8k_2_02:48]
3

[0000068505-21-000019:8k_2_02:49]
Although the COVID-19 pandemic continued to influence the company's activities in the second quarter of 2021, the negative impacts on the business from COVID-19 have begun to ease. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 (the "ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. The company continues to evaluate the potential impact of the ARPA on its business and results of operations, although the company anticipates that the ARPA will have a positive impact on its business and results of operations during the remainder of 2021 and beyond as the company expects its governmental customers to receive funding from the ARPA.

[0000068505-21-000019:8k_2_02:50]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, August 5. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-21-000019:8k_2_02:51]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-21-000019:8k_2_02:52]
A comparison of results from operations is as follows:

[0000068505-21-000019:8k_2_02:53]
|  | Q2 2021 | Q2 2020 |
| Net sales | $1,971 | $1,618 |
| Gross margin | $952 | $766 |
| Operating earnings | $370 | $218 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $293 | $135 |
| Diluted EPS | $1.69 | $0.78 |
| Weighted average diluted common shares outstanding | 173.1 |  | 173.6 |  |

[0000068505-21-000019:8k_2_02:54]
HIGHLIGHTED ITEMS

[0000068505-21-000019:8k_2_02:55]
The table below includes highlighted items, including share-based compensation expenses and intangible assets amortization expense, for the second quarter of 2021.

[0000068505-21-000019:8k_2_02:56]
| (per diluted common share) | Q2 2021 |
| GAAP EPS | $1.69 |
| Highlighted Items: |  |
| Intangible assets amortization expense | $0.28 |
| Share-based compensation expenses | 0.17 |  |
| Loss from extinguishment of long-term debt | 0.08 |  |
| Reorganization of business charges | 0.04 |  |
| Hytera-related legal expenses | 0.04 |  |
| Acquisition-related transaction fees | 0.02 |  |
| Legal settlements | 0.01 |  |
| Impact of tax law changes on deferred tax balances | 0.01 |  |
| Fair value adjustments to equity investments | (0.03) |  |
| Adjustments to uncertain tax positions | (0.05) |  |
| Release of valuation allowance on deferred tax assets | (0.19) |  |
| Non-GAAP EPS | $2.07 |

[0000068505-21-000019:8k_2_02:57]
4

[0000068505-21-000019:8k_2_02:58]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-21-000019:8k_2_02:59]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-21-000019:8k_2_02:60]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-21-000019:8k_2_02:61]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is also useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-21-000019:8k_2_02:62]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes non-GAAP organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-21-000019:8k_2_02:63]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-21-000019:8k_2_02:64]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-21-000019:8k_2_02:65]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement

[0000068505-21-000019:8k_2_02:66]
5

[0000068505-21-000019:8k_2_02:67]
case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. As of the second quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.

[0000068505-21-000019:8k_2_02:68]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for pre-judgment interest, although the precise amount of interest owed to the company by Hytera is still to be determined by the Court. On March 25, 2021, the Court entered rulings favorable to the company with respect to several of the company's post-trial motions, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award.

[0000068505-21-000019:8k_2_02:69]
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property.

[0000068505-21-000019:8k_2_02:70]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, if any contingent or actual gain associated with the Hytera litigation is recognized in the future, it will be similarly excluded from the company's non-GAAP operating income. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-21-000019:8k_2_02:71]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-21-000019:8k_2_02:72]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-21-000019:8k_2_02:73]
6

[0000068505-21-000019:8k_2_02:74]
FORWARD LOOKING STATEMENTS

[0000068505-21-000019:8k_2_02:75]
ABOUT MOTOROLA SOLUTIONS

[0000068505-21-000019:8k_2_02:76]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio mission-critical communications, video security & access control and command center software, bolstered by managed & support services, create the most integrated technology ecosystem to make communities safer and help businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-21-000019:8k_2_02:77]
7

[0000068505-21-000019:8k_2_02:78]
MEDIA CONTACT

[0000068505-21-000019:8k_2_02:79]
Alexandra Reynolds

[0000068505-21-000019:8k_2_02:80]
Motorola Solutions

[0000068505-21-000019:8k_2_02:81]
+1 312-965-3968

[0000068505-21-000019:8k_2_02:82]
alexandra.reynolds@motorolasolutions.com

[0000068505-21-000019:8k_2_02:83]
INVESTOR CONTACT

[0000068505-21-000019:8k_2_02:84]
Tim Yocum

[0000068505-21-000019:8k_2_02:85]
Motorola Solutions

[0000068505-21-000019:8k_2_02:86]
+1 847-576-6899

[0000068505-21-000019:8k_2_02:87]
Tim.Yocum@motorolasolutions.com

[0000068505-21-000019:8k_2_02:88]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2021 Motorola Solutions, Inc. All rights reserved.

[0000068505-21-000019:8k_2_02:89]
8

[0000068505-21-000019:8k_2_02:90]
GAAP-1

[0000068505-21-000019:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:92]
Condensed Consolidated Statements of Operations

[0000068505-21-000019:8k_2_02:93]
(In millions, except per share amounts)

[0000068505-21-000019:8k_2_02:94]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| Net sales from products | $ | 1,094 |  |  | $ | 877 |  |
| Net sales from services | 877 |  |  | 741 |  |
| Net sales | 1,971 |  |  | 1,618 |  |
| Costs of products sales | 511 |  |  | 413 |  |
| Costs of services sales | 508 |  |  | 439 |  |
| Costs of sales | 1,019 |  |  | 852 |  |
| Gross margin | 952 |  |  | 766 |  |
| Selling, general and administrative expenses | 331 |  |  | 297 |  |
| Research and development expenditures | 181 |  |  | 161 |  |
| Other charges | 12 |  |  | 39 |  |
| Intangibles amortization | 58 |  |  | 51 |  |
| Operating earnings | 370 |  |  | 218 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (44) |  |  | (58) |  |
| Other, net | 14 |  |  | 16 |  |
| Total other expense | (30) |  |  | (42) |  |
| Net earnings before income taxes | 340 |  |  | 176 |  |
| Income tax expense | 46 |  |  | 40 |  |
| Net earnings | 294 |  |  | 136 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 293 |  |  | $ | 135 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.73 |  |  | $ | 0.79 |  |
| Diluted | $ | 1.69 |  |  | $ | 0.78 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 169.6 |  |  | 170.0 |  |
| Diluted | 173.1 |  |  | 173.6 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 55.5 | % |  | 54.2 | % |
| Net sales from services | 44.5 | % |  | 45.8 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 46.7 | % |  | 47.1 | % |
| Costs of services sales | 57.9 | % |  | 59.2 | % |
| Costs of sales | 51.7 | % |  | 52.7 | % |
| Gross margin | 48.3 | % |  | 47.3 | % |
| Selling, general and administrative expenses | 16.8 | % |  | 18.4 | % |
| Research and development expenditures | 9.2 | % |  | 10.0 | % |
| Other charges | 0.6 | % |  | 2.4 | % |
| Intangibles amortization | 2.9 | % |  | 3.2 | % |
| Operating earnings | 18.8 | % |  | 13.5 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.2) | % |  | (3.6) | % |
| Other, net | 0.7 | % |  | 1.0 | % |
| Total other expense | (1.5) | % |  | (2.6) | % |
| Net earnings before income taxes | 17.3 | % |  | 10.9 | % |
| Income tax expense | 2.3 | % |  | 2.5 | % |
| Net earnings | 14.9 | % |  | 8.4 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 14.9 | % |  | 8.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-21-000019:8k_2_02:95]
9

[0000068505-21-000019:8k_2_02:96]
GAAP-2

[0000068505-21-000019:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:98]
Condensed Consolidated Statements of Operations

[0000068505-21-000019:8k_2_02:99]
(In millions, except per share amounts)

[0000068505-21-000019:8k_2_02:100]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| Net sales from products | $ | 2,027 |  |  | $ | 1,764 |  |
| Net sales from services | 1,717 |  |  | 1,509 |  |
| Net sales | 3,744 |  |  | 3,273 |  |
| Costs of products sales | 952 |  |  | 812 |  |
| Costs of services sales | 980 |  |  | 908 |  |
| Costs of sales | 1,932 |  |  | 1,720 |  |
| Gross margin | 1,812 |  |  | 1,553 |  |
| Selling, general and administrative expenses | 633 |  |  | 638 |  |
| Research and development expenditures | 361 |  |  | 330 |  |
| Other charges | 34 |  |  | 5 |  |
| Intangibles amortization | 116 |  |  | 104 |  |
| Operating earnings | 668 |  |  | 476 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (98) |  |  | (109) |  |
| Other, net | 60 |  |  | 34 |  |
| Total other expense | (38) |  |  | (75) |  |
| Net earnings before income taxes | 630 |  |  | 401 |  |
| Income tax expense | 90 |  |  | 67 |  |
| Net earnings | 540 |  |  | 334 |  |
| Less: Earnings attributable to non-controlling interests | 3 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 537 |  |  | $ | 332 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.17 |  |  | $ | 1.95 |  |
| Diluted | $ | 3.10 |  |  | $ | 1.90 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 169.4 |  |  | 170.3 |  |
| Diluted | 173.1 |  |  | 174.8 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 54.1 | % |  | 53.9 | % |
| Net sales from services | 45.9 | % |  | 46.1 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.0 | % |  | 46.0 | % |
| Costs of services sales | 57.1 | % |  | 60.2 | % |
| Costs of sales | 51.6 | % |  | 52.6 | % |
| Gross margin | 48.4 | % |  | 47.4 | % |
| Selling, general and administrative expenses | 16.9 | % |  | 19.5 | % |
| Research and development expenditures | 9.6 | % |  | 10.1 | % |
| Other charges | 0.9 | % |  | 0.2 | % |
| Intangibles amortization | 3.1 | % |  | 3.2 | % |
| Operating earnings | 17.8 | % |  | 14.5 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.6) | % |  | (3.3) | % |
| Other, net | 1.6 | % |  | 1.0 | % |
| Total other expense | (1.0) | % |  | (2.3) | % |
| Net earnings before income taxes | 16.8 | % |  | 12.3 | % |
| Income tax expense | 2.4 | % |  | 2.0 | % |
| Net earnings | 14.4 | % |  | 10.2 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 14.3 | % |  | 10.1 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-21-000019:8k_2_02:101]
GAAP-3

[0000068505-21-000019:8k_2_02:102]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:103]
Condensed Consolidated Balance Sheets

[0000068505-21-000019:8k_2_02:104]
(In millions)

[0000068505-21-000019:8k_2_02:105]
|  | July 3, 2021 |  | December 31, 2020 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,921 |  |  | $ | 1,254 |  |
| Accounts receivable, net | 1,169 |  |  | 1,390 |  |
| Contract assets | 757 |  |  | 933 |  |
| Inventories, net | 559 |  |  | 508 |  |
| Other current assets | 254 |  |  | 242 |  |
| Total current assets | 4,660 |  |  | 4,327 |  |
| Property, plant and equipment, net | 1,028 |  |  | 1,022 |  |
| Operating lease assets | 430 |  |  | 468 |  |
| Investments | 181 |  |  | 158 |  |
| Deferred income taxes | 981 |  |  | 966 |  |
| Goodwill | 2,219 |  |  | 2,219 |  |
| Intangible assets, net | 1,123 |  |  | 1,234 |  |
| Other assets | 509 |  |  | 482 |  |
| Total assets | $ | 11,131 |  |  | $ | 10,876 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |
| Current portion of long-term debt | $ | 9 |  |  | $ | 12 |  |
| Accounts payable | 547 |  |  | 612 |  |
| Contract liabilities | 1,416 |  |  | 1,554 |  |
| Accrued liabilities | 1,212 |  |  | 1,311 |  |
| Total current liabilities | 3,184 |  |  | 3,489 |  |
| Long-term debt | 5,686 |  |  | 5,163 |  |
| Operating lease liabilities | 340 |  |  | 402 |  |
| Other liabilities | 2,265 |  |  | 2,363 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) | (358) |  |  | (558) |  |
| Non-controlling interests | 14 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 11,131 |  |  | $ | 10,876 |  |

[0000068505-21-000019:8k_2_02:106]
11

[0000068505-21-000019:8k_2_02:107]
GAAP-4

[0000068505-21-000019:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:109]
Condensed Consolidated Statements of Cash Flows

[0000068505-21-000019:8k_2_02:110]
(In millions)

[0000068505-21-000019:8k_2_02:111]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| Operating |  |  |  |
| Net earnings | $ | 294 |  |  | $ | 136 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 110 |  |  | 98 |  |
| Non-cash other charges (income) | (17) |  |  | 11 |  |
| Share-based compensation expenses | 31 |  |  | 31 |  |
| Loss from the extinguishment of long-term debt | 18 |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (77) |  |  | 11 |  |
| Inventories | (29) |  |  | 1 |  |
| Other current assets and contract assets | (14) |  |  | 88 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 128 |  |  | (153) |  |
| Other assets and liabilities | (32) |  |  | (11) |  |
| Deferred income taxes | (24) |  |  | (3) |  |
| Net cash provided by operating activities | 388 |  |  | 209 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (7) |  |  | (65) |  |
| Proceeds from sales of investments and businesses, net | 1 |  |  | 4 |  |
| Capital expenditures | (62) |  |  | (54) |  |
| Proceeds from sale of property, plant and equipment | 6 |  |  | — |  |
| Net cash used for investing activities | (62) |  |  | (115) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | 844 |  |  | — |  |
| Repayments of debt | (345) |  |  | (4) |  |
| Repayment of revolving credit facility draw | — |  |  | (300) |  |
| Issuances of common stock | 15 |  |  | 44 |  |
| Purchases of common stock | (102) |  |  | (83) |  |
| Payments of dividends | (121) |  |  | (109) |  |
| Payments of dividends to non-controlling interests | (5) |  |  | (4) |  |
| Net cash provided by (used for) financing activities | 286 |  |  | (456) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (11) |  |  | 31 |  |
| Net increase (decrease) in total cash and cash equivalents | 601 |  |  | (331) |  |
| Cash and cash equivalents, beginning of period | 1,320 |  |  | 1,672 |  |
| Cash and cash equivalents, end of period | $ | 1,921 |  |  | $ | 1,341 |  |
| Reconciliation of Net cash provided by operating activities to Free cash flow |
| Net cash provided by operating activities | $ | 388 |  |  | $ | 209 |  |
| Capital expenditures | (62) |  |  | (54) |  |
| Free cash flow* | $ | 326 |  |  | $ | 155 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-21-000019:8k_2_02:112]
12

[0000068505-21-000019:8k_2_02:113]
GAAP-5

[0000068505-21-000019:8k_2_02:114]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:115]
Condensed Consolidated Statements of Cash Flows

[0000068505-21-000019:8k_2_02:116]
(In millions)

[0000068505-21-000019:8k_2_02:117]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| Operating |  |  |  |
| Net earnings | $ | 540 |  |  | $ | 334 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 220 |  |  | 197 |  |
| Non-cash other income | (24) |  |  | (40) |  |
| Share-based compensation expenses | 60 |  |  | 69 |  |
| Loss from the extinguishment of long-term debt | 18 |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 221 |  |  | 286 |  |
| Inventories | (53) |  |  | 3 |  |
| Other current assets and contract assets | 134 |  |  | 136 |  |
| Accounts payable, accrued liabilities, and contract liabilities | (298) |  |  | (454) |  |
| Other assets and liabilities | (37) |  |  | (15) |  |
| Deferred income taxes | (23) |  |  | 1 |  |
| Net cash provided by operating activities | 758 |  |  | 517 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (9) |  |  | (102) |  |
| Proceeds from sales of investments and businesses, net | 3 |  |  | 7 |  |
| Capital expenditures | (114) |  |  | (102) |  |
| Proceeds from sales of property, plant and equipment | 6 |  |  | 56 |  |
| Net cash used for investing activities | (114) |  |  | (141) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | 844 |  |  | — |  |
| Proceeds from revolving credit facility draw | — |  |  | 800 |  |
| Repayments of debt | (348) |  |  | (8) |  |
| Repayment of revolving credit facility draw | — |  |  | (300) |  |
| Revolving credit facility renewal fees | (7) |  |  | — |  |
| Issuances of common stock | 60 |  |  | 49 |  |
| Purchases of common stock | (272) |  |  | (336) |  |
| Payments of dividends | (242) |  |  | (218) |  |
| Payments of dividends to non-controlling interests | (5) |  |  | (4) |  |
| Net cash provided by (used for) financing activities | 30 |  |  | (17) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (7) |  |  | (19) |  |
| Net increase in total cash and cash equivalents | 667 |  |  | 340 |  |
| Cash and cash equivalents, beginning of period | 1,254 |  |  | 1,001 |  |
| Cash and cash equivalents, end of period | $ | 1,921 |  |  | $ | 1,341 |  |
| Reconciliation of Net cash provided by operating activities to Free cash flow |
| Net cash provided by operating activities | $ | 758 |  |  | $ | 517 |  |
| Capital expenditures | (114) |  |  | (102) |  |
| Free cash flow* | $ | 644 |  |  | $ | 415 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-21-000019:8k_2_02:118]
13

[0000068505-21-000019:8k_2_02:119]
GAAP-6

[0000068505-21-000019:8k_2_02:120]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:121]
Segment Information

[0000068505-21-000019:8k_2_02:122]
(In millions)

[0000068505-21-000019:8k_2_02:123]
| Net Sales |  |  |
|  | Three Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 1,198 |  |  | $ | 968 |  |  | 24 | % |  |  |
| Software and Services | 773 |  |  | 650 |  |  | 19 | % |  |  |
| Total Motorola Solutions | $ | 1,971 |  |  | $ | 1,618 |  |  | 22 | % |  |  |
|  | Six Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 2,213 |  |  | $ | 1,961 |  |  | 13 | % |  |  |
| Software and Services | 1,531 |  |  | 1,312 |  |  | 17 | % |  |  |
| Total Motorola Solutions | $ | 3,744 |  |  | $ | 3,273 |  |  | 14 | % |  |  |
| Operating Earnings |
|  | Three Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 139 |  |  | $ | 49 |  |  | 184 | % |  |  |
| Software and Services | 231 |  |  | 169 |  |  | 37 | % |  |  |
| Total Motorola Solutions | $ | 370 |  |  | $ | 218 |  |  | 70 | % |  |  |
|  | Six Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 216 |  |  | $ | 141 |  |  | 53 | % |  |  |
| Software and Services | 452 |  |  | 335 |  |  | 35 | % |  |  |
| Total Motorola Solutions | $ | 668 |  |  | $ | 476 |  |  | 40 | % |  |  |

[0000068505-21-000019:8k_2_02:124]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  |  |
| Products and Systems Integration | 11.6 | % |  | 5.1 | % |  |  |
| Software and Services | 29.9 | % |  | 26.0 | % |  |  |
| Total Motorola Solutions | 18.8 | % |  | 13.5 | % |  |  |
|  | Six Months Ended |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  |  |
| Products and Systems Integration | 9.8 | % |  | 7.2 | % |  |  |
| Software and Services | 29.5 | % |  | 25.5 | % |  |  |
| Total Motorola Solutions | 17.8 | % |  | 14.5 | % |  |  |

[0000068505-21-000019:8k_2_02:125]
14

[0000068505-21-000019:8k_2_02:126]
Non-GAAP-1

[0000068505-21-000019:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:128]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expenses, and Other Highlighted Items)

[0000068505-21-000019:8k_2_02:129]
(In millions)

[0000068505-21-000019:8k_2_02:130]
| Q1 2021 |  |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | TaxInc/(Exp) |  | PAT(Inc)/Exp |  | EPS Impact |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 58 |  |  | $ | 13 |  |  | $ | 45 |  |  | $ | 0.26 |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 29 |  |  | 6 |  |  | 23 |  |  | 0.13 |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 16 |  |  | 3 |  |  | 13 |  |  | 0.07 |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 7 |  |  | 1 |  |  | 6 |  |  | 0.03 |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 2 |  |  | 1 |  |  | 1 |  |  | 0.01 |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |  |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | (5) |  |  | (1) |  |  | (4) |  |  | (0.02) |  |  |  |
| Release of uncertain tax positions |  | Other income (expense) |  | (1) |  |  | 4 |  |  | (5) |  |  | (0.03) |  |  |  |
| Total impact on Net earnings |  |  |  | $ | 107 |  |  | $ | 27 |  |  | $ | 80 |  |  | $ | 0.46 |  |  |  |
| Q2 2021 |  |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | TaxInc/(Exp) |  | PAT(Inc)/Exp |  | EPS Impact |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 58 |  |  | $ | 9 |  |  | $ | 49 |  |  | $ | 0.28 |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 31 |  |  | 2 |  |  | 29 |  |  | 0.17 |  |  |  |
| Loss from extinguishment of long-term debt |  | Other expense |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 9 |  |  | 2 |  |  | 7 |  |  | 0.04 |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 8 |  |  | 1 |  |  | 7 |  |  | 0.04 |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 3 |  |  | — |  |  | 3 |  |  | 0.02 |  |  |  |
| Legal settlements |  | Other charges (income) |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |  |  |
| Impact of tax law changes on deferred tax balances |  | Income tax expense |  | — |  |  | (2) |  |  | 2 |  |  | 0.01 |  |  |  |
| Fair value adjustments to equity investments |  | Other income |  | (8) |  |  | (2) |  |  | (6) |  |  | (0.03) |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net and Income tax expense |  | (9) |  |  | (1) |  |  | (8) |  |  | (0.05) |  |  |  |
| Release of valuation allowance on deferred tax assets |  | Income tax expense |  | — |  |  | 33 |  |  | (33) |  |  | (0.19) |  |  |  |
| Total impact on Net earnings |  |  |  | $ | 113 |  |  | $ | 47 |  |  | $ | 66 |  |  | $ | 0.38 |  |  |  |

[0000068505-21-000019:8k_2_02:131]
15

[0000068505-21-000019:8k_2_02:132]
Non-GAAP-2

[0000068505-21-000019:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:134]
Non-GAAP Segment Information

[0000068505-21-000019:8k_2_02:135]
(In millions)

[0000068505-21-000019:8k_2_02:136]
| Net Sales |  |  |
|  | Three Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 1,198 |  |  | $ | 968 |  |  | 24 | % |  |  |
| Software and Services | 773 |  |  | 650 |  |  | 19 | % |  |  |
| Total Motorola Solutions | $ | 1,971 |  |  | $ | 1,618 |  |  | 22 | % |  |  |
|  | Six Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 2,213 |  |  | $ | 1,961 |  |  | 13 | % |  |  |
| Software and Services | 1,531 |  |  | 1,312 |  |  | 17 | % |  |  |
| Total Motorola Solutions | $ | 3,744 |  |  | $ | 3,273 |  |  | 14 | % |  |  |
| Non-GAAP Operating Earnings |  |  |
|  | Three Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 194 |  |  | $ | 131 |  |  | 48 | % |  |  |
| Software and Services | 288 |  |  | 228 |  |  | 26 | % |  |  |
| Total Motorola Solutions | $ | 482 |  |  | $ | 359 |  |  | 34 | % |  |  |
|  | Six Months Ended |  |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | % Change |  |  |
| Products and Systems Integration | $ | 325 |  |  | $ | 253 |  |  | 28 | % |  |  |
| Software and Services | 568 |  |  | 452 |  |  | 26 | % |  |  |
| Total Motorola Solutions | $ | 893 |  |  | $ | 705 |  |  | 27 | % |  |  |

[0000068505-21-000019:8k_2_02:137]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  |  |
| Products and Systems Integration | 16.2 | % |  | 13.5 | % |  |  |
| Software and Services | 37.2 | % |  | 35.1 | % |  |  |
| Total Motorola Solutions | 24.4 | % |  | 22.2 | % |  |  |
|  | Six Months Ended |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  |  |
| Products and Systems Integration | 14.7 | % |  | 12.9 | % |  |  |
| Software and Services | 37.1 | % |  | 34.5 | % |  |  |
| Total Motorola Solutions | 23.8 | % |  | 21.5 | % |  |  |

[0000068505-21-000019:8k_2_02:138]
16

[0000068505-21-000019:8k_2_02:139]
Non-GAAP-3

[0000068505-21-000019:8k_2_02:140]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:141]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-21-000019:8k_2_02:142]
(In millions)

[0000068505-21-000019:8k_2_02:143]
| Q1 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,773 |  |  | $ | 1,015 |  |  | $ | 758 |  |
| Operating earnings ("OE") |  | $ | 298 |  |  | $ | 77 |  |  | $ | 221 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 58 |  |  | 13 |  |  | 45 |  |
| Share-based compensation expenses |  | 29 |  |  | 22 |  |  | 7 |  |
| Reorganization of business charges |  | 16 |  |  | 12 |  |  | 4 |  |
| Operating lease asset impairment |  | 7 |  |  | 5 |  |  | 2 |  |
| Hytera-related legal expenses |  | 2 |  |  | 2 |  |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 113 |  |  | 54 |  |  | 59 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 411 |  |  | $ | 131 |  |  | $ | 280 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 16.8 | % |  | 7.6 | % |  | 29.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 23.2 | % |  | 12.9 | % |  | 36.9 | % |
| Q2 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,971 |  |  | $ | 1,198 |  |  | $ | 773 |  |
| Operating earnings ("OE") |  | $ | 370 |  |  | $ | 139 |  |  | $ | 231 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 58 |  |  | 13 |  |  | 45 |  |
| Share-based compensation expenses |  | 31 |  |  | 24 |  |  | 7 |  |
| Reorganization of business charges |  | 9 |  |  | 7 |  |  | 2 |  |
| Hytera-related legal expenses |  | 8 |  |  | 8 |  |  | — |  |
| Legal settlements |  | 3 |  |  | 2 |  |  | 1 |  |
| Acquisition-related transaction fees |  | 3 |  |  | 1 |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  | 112 |  |  | 55 |  |  | 57 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 482 |  |  | $ | 194 |  |  | $ | 288 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 18.8 | % |  | 11.6 | % |  | 29.9 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.4 | % |  | 16.2 | % |  | 37.2 | % |

[0000068505-21-000019:8k_2_02:144]
17

[0000068505-21-000019:8k_2_02:145]
Non-GAAP-4

[0000068505-21-000019:8k_2_02:146]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000019:8k_2_02:147]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-21-000019:8k_2_02:148]
(In millions)

[0000068505-21-000019:8k_2_02:149]
|  |  | Three Months Ended |  |  |
|  |  | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Net sales |  | $ | 1,971 |  |  | $ | 1,618 |  |  | 22 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 50 |  |  | 3 |  |  |  |
| Organic revenue |  | $ | 1,921 |  |  | $ | 1,615 |  |  | 19 | % |
|  |  | Six Months Ended |  |  |
|  |  | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Net sales |  | $ | 3,744 |  |  | $ | 3,273 |  |  | 14 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 100 |  |  | 4 |  |  |  |
| Organic revenue |  | $ | 3,644 |  |  | $ | 3,269 |  |  | 11 | % |

[0000068505-21-000019:8k_2_02:150]
18
