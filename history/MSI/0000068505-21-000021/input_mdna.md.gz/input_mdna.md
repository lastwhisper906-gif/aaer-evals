# MSI MD&A — 0000068505-21-000021


## mdna

[0000068505-21-000021:mdna:1]
[same as prior period, unchanged from 0000068505-21-000015:mdna:1]

[0000068505-21-000021:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and six months ended July 3, 2021 and June 27, 2020, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2020 (the "Form 10-K").

[0000068505-21-000021:mdna:3]
[same as prior period, unchanged from 0000068505-21-000015:mdna:3]

[0000068505-21-000021:mdna:4]
[same as prior period, unchanged from 0000068505-21-000015:mdna:4]

[0000068505-21-000021:mdna:5]
[same as prior period, unchanged from 0000068505-21-000015:mdna:5]

[0000068505-21-000021:mdna:6]
During the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within our reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which we refer to as “technologies” in this Form 10-Q): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) subsequent to quarter end on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended July 3, 2021.

[0000068505-21-000021:mdna:7]
[same as prior period, unchanged from 0000068505-21-000015:mdna:7]

[0000068505-21-000021:mdna:8]
•Video Security and Access Control: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

[0000068505-21-000021:mdna:9]
[same as prior period, unchanged from 0000068505-21-000015:mdna:9]

[0000068505-21-000021:mdna:10]
25

[0000068505-21-000021:mdna:11]
Second Quarter Financial Results

[0000068505-21-000021:mdna:12]
•Net sales were $2.0 billion in the second quarter of 2021 compared to $1.6 billion in the second quarter of 2020.

[0000068505-21-000021:mdna:13]
•Operating earnings were $370 million in the second quarter of 2021 compared to $218 million in the second quarter of 2020.

[0000068505-21-000021:mdna:14]
•Net earnings attributable to Motorola Solutions, Inc. were $293 million, or $1.69 per diluted common share, in the second quarter of 2021, compared to $135 million, or $0.78 per diluted common share, in the second quarter of 2020.

[0000068505-21-000021:mdna:15]
•Operating cash flow increased $241 million to $758 million in the first half of 2021 compared to $517 million in the first half of 2020.

[0000068505-21-000021:mdna:16]
•We repurchased $272 million of common stock and paid $242 million in dividends in the first half of 2021.

[0000068505-21-000021:mdna:17]
[same as prior period, unchanged from 0000068505-21-000015:mdna:17]

[0000068505-21-000021:mdna:18]
In response to the COVID-19 pandemic, there have been a broad number of governmental and commercial actions taken to limit the spread of the virus, including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns. The COVID-19 pandemic continues to be dynamic, and near-term challenges across the economy remain. Although vaccines are now being distributed and administered across many parts of the world, new variants of the virus have emerged and may continue to emerge that have shown to be more contagious. We continue to adhere to applicable governmental and commercial restrictions and to work to mitigate the impact of COVID-19 on our employees, customers, communities, liquidity and financial position.

[0000068505-21-000021:mdna:19]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including encouraging office workers to work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings, and using thermal scanning. During the second quarter of 2021, we began to allow certain essential business travel to resume; however, we continue to carefully assess conditions on a geographical basis to determine when employees can safely return to our offices. We also facilitated the process for our employees in certain locations to receive the COVID-19 vaccine during the second quarter of 2021, as vaccines are distributed and administered throughout the U.S. and the global community. As conditions continue to fluctuate around the world, with both vaccine administration and the rates of new variants of COVID-19 (particularly the "delta variant") rising in certain regions, governments and organizations have responded by adjusting their restrictions and guidelines accordingly. We continue to monitor the daily evolution of the pandemic, including the spread of the delta variant, in order to ensure the health and safety of our employees remains our top priority. As of the date of this filing, we are following the U.S. Centers for Disease Control and Prevention guidance and state and location restrictions with respect to our U.S. employees, as well as guidance from corresponding international authorities with respect to our non-U.S. employees. With respect to our customers, we have continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service our mission-critical networks on-site as needed to ensure seamless operations. Our sales teams have also continued to improve virtual engagement with our customers. Additionally, our engineering teams have adapted our solutions offerings to equip our customers with the latest technology in an effort to protect their workplaces from the spread of COVID-19. Specifically, in Video Security and Access Control, we have adapted our software and hardware offerings to provide analytics addressing occupancy counting, face mask detection, and thermal detection capabilities.

[0000068505-21-000021:mdna:20]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of July 3, 2021. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint. In addition, our supply chain partners have been supportive and continue to work to fulfill the necessary service levels to the Company and its customers.

[0000068505-21-000021:mdna:21]
Although the COVID-19 pandemic continued to influence our activities in the second quarter of 2021, as described above, the negative impacts on our business from COVID-19 have begun to ease. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impacts on net sales and operating margin will be limited for the remainder of 2021. Within the Products and Systems Integration segment, we are encouraged by strong LMR backlog, and the resiliency of the Video Security and Access Control technology that experienced growth in the second quarter of 2021 and which we expect to continue to grow for the remainder of 2021. In addition, in March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 (the "ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We continue to evaluate the potential impact of the ARPA on our business and results of operations, although we anticipate that the ARPA will have a positive impact on our business and results of operations during the remainder of 2021 and beyond as we expect our governmental customers to receive funding from the ARPA.

[0000068505-21-000021:mdna:22]
Lastly, we evaluated whether there were any impairment indicators as of July 3, 2021, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the second quarter of 2021, we concluded our assets were fairly stated and recoverable.

[0000068505-21-000021:mdna:23]
[same as prior period, unchanged from 0000068505-21-000015:mdna:23]

[0000068505-21-000021:mdna:24]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Command Center Software | Software and Services | Callyo | Provider of cloud-based mobile applications for law enforcement in North America, including critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. | $63 million, inclusive of share-based compensation of $3 million | August 28, 2020 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Pelco, Inc. | Global provider of video security solutions, adding a broad range of products for a variety of commercial and industrial environments and use cases. | $110 million | July 31, 2020 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | IndigoVision Group plc | Provider of video security solutions to enhance geographical reach across a wider customer base. | $37 million | June 16, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, and managed services, including security monitoring of network operations. | $32 million | April 30, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, managed services, and remediation and response capabilities. | $40 million, inclusive of share-based compensation of $6 million | March 3, 2020 |

[0000068505-21-000021:mdna:25]
[same as prior period, unchanged from 0000068505-21-000015:mdna:29]

[0000068505-21-000021:mdna:26]
[same as prior period, unchanged from 0000068505-21-000015:mdna:26]

[0000068505-21-000021:mdna:27]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | July 3, 2021 |  | % ofSales* |  | June 27, 2020 |  | % ofSales* |  | July 3, 2021 |  | % ofSales* |  | June 27, 2020 |  | % ofSales* |
| Net sales from products | $ | 1,094 |  |  |  |  | $ | 877 |  |  |  |  | $ | 2,027 |  |  |  |  | $ | 1,764 |  |  |  |
| Net sales from services | 877 |  |  |  |  | 741 |  |  |  |  | 1,717 |  |  |  |  | 1,509 |  |  |  |
| Net sales | 1,971 |  |  |  |  | 1,618 |  |  |  |  | 3,744 |  |  |  |  | 3,273 |  |  |  |
| Costs of products sales | 511 |  |  | 46.7 | % |  | 413 |  |  | 47.1 | % |  | 952 |  |  | 47.0 | % |  | 812 |  |  | 46.0 | % |
| Costs of services sales | 508 |  |  | 57.9 | % |  | 439 |  |  | 59.2 | % |  | 980 |  |  | 57.1 | % |  | 908 |  |  | 60.2 | % |
| Costs of sales | 1,019 |  |  |  |  | 852 |  |  |  |  | 1,932 |  |  |  |  | 1,720 |  |  |  |
| Gross margin | 952 |  |  | 48.3 | % |  | 766 |  |  | 47.3 | % |  | 1,812 |  |  | 48.4 | % |  | 1,553 |  |  | 47.4 | % |
| Selling, general and administrative expenses | 331 |  |  | 16.8 | % |  | 297 |  |  | 18.4 | % |  | 633 |  |  | 16.9 | % |  | 638 |  |  | 19.5 | % |
| Research and development expenditures | 181 |  |  | 9.2 | % |  | 161 |  |  | 10.0 | % |  | 361 |  |  | 9.6 | % |  | 330 |  |  | 10.1 | % |
| Other charges | 70 |  |  | 3.5 | % |  | 90 |  |  | 5.6 | % |  | 150 |  |  | 4.0 | % |  | 109 |  |  | 3.3 | % |
| Operating earnings | 370 |  |  | 18.8 | % |  | 218 |  |  | 13.5 | % |  | 668 |  |  | 17.8 | % |  | 476 |  |  | 14.5 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (44) |  |  | (2.2) | % |  | (58) |  |  | (3.6) | % |  | (98) |  |  | (2.6) | % |  | (109) |  |  | (3.3) | % |
| Other, net | 14 |  |  | 0.7 | % |  | 16 |  |  | 1.0 | % |  | 60 |  |  | 1.6 | % |  | 34 |  |  | 1.0 | % |
| Total other expense | (30) |  |  | (1.5) | % |  | (42) |  |  | (2.6) | % |  | (38) |  |  | (1.0) | % |  | (75) |  |  | (2.3) | % |
| Net earnings before income taxes | 340 |  |  | 17.3 | % |  | 176 |  |  | 10.9 | % |  | 630 |  |  | 16.8 | % |  | 401 |  |  | 12.3 | % |
| Income tax expense | 46 |  |  | 2.3 | % |  | 40 |  |  | 2.5 | % |  | 90 |  |  | 2.4 | % |  | 67 |  |  | 2.0 | % |
| Net earnings | 294 |  |  | 14.9 | % |  | 136 |  |  | 8.4 | % |  | 540 |  |  | 14.4 | % |  | 334 |  |  | 10.2 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 293 |  |  | 14.9 | % |  | $ | 135 |  |  | 8.3 | % |  | $ | 537 |  |  | 14.3 | % |  | $ | 332 |  |  | 10.1 | % |
| Earnings per diluted common share | $ | 1.69 |  |  |  |  | $ | 0.78 |  |  |  |  | $ | 3.10 |  |  |  |  | $ | 1.90 |  |  |  |

[0000068505-21-000021:mdna:28]
[same as prior period, unchanged from 0000068505-21-000015:mdna:28]

[0000068505-21-000021:mdna:29]
28

[0000068505-21-000021:mdna:30]
Results of Operations—Three months ended July 3, 2021 compared to three months ended June 27, 2020

[0000068505-21-000021:mdna:31]
The results of operations for the second quarter of 2021 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-21-000021:mdna:32]
[same as prior period, unchanged from 0000068505-21-000015:mdna:32]

[0000068505-21-000021:mdna:33]
•Net sales: a measure of our revenue for the current period.

[0000068505-21-000021:mdna:34]
•Operating earnings: a measure of our earnings from operations, before non-operating expenses and income taxes.

[0000068505-21-000021:mdna:35]
•Operating margins: a measure of our operating earnings as a percentage of total net sales.

[0000068505-21-000021:mdna:36]
[same as prior period, unchanged from 0000068505-21-000015:mdna:36]

[0000068505-21-000021:mdna:37]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |  | $ | 719 |  |  | $ | 374 |  |  | $ | 1,093 |  |
| International | 329 |  |  | 330 |  |  | 659 |  |  | 249 |  |  | 276 |  |  | 525 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |  | $ | 836 |  |  | $ | 481 |  |  | $ | 1,317 |  |
| Video Security and Access Control | 212 |  |  | 94 |  |  | 306 |  |  | 132 |  |  | 52 |  |  | 184 |  |
| Command Center Software | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 117 |  |  | 117 |  |
| Total | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Operating earnings | $ | 139 |  |  | $ | 231 |  |  | $ | 370 |  |  | $ | 49 |  |  | $ | 169 |  |  | $ | 218 |  |
| Operating margins | 11.6 | % |  | 29.9 | % |  | 18.8 | % |  | 5.1 | % |  | 26.0 | % |  | 13.5 | % |

[0000068505-21-000021:mdna:38]
[same as prior period, unchanged from 0000068505-21-000015:mdna:38]

[0000068505-21-000021:mdna:39]
The Products and Systems Integration segment’s net sales represented 61% of our net sales in the second quarter of 2021 and 60% in the second quarter of 2020. The Software and Services segment’s net sales represented 39% of our net sales in the second quarter of 2021 and 40% in the second quarter of 2020.

[0000068505-21-000021:mdna:40]
Net sales increased $353 million, or 22%, in the second quarter of 2021 compared to the second quarter of 2020. The $230 million, or 24%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 21% in the North America region and an increase of 32% in the International region. The $123 million, or 19%, increase in net sales within the Software and Services segment was driven by an increase of 18% in the North America region and an increase of 20% in the International region. Net sales includes:

[0000068505-21-000021:mdna:41]
•an increase in the Products and Systems Integration segment, inclusive of $38 million of revenue from acquisitions, driven by an increase in PCR, Video Security and Access Control and public safety LMR;

[0000068505-21-000021:mdna:42]
•an increase in the Software and Services segment, inclusive of $9 million of revenue from acquisitions, driven by an increase in LMR services, Video Security and Access Control and Command Center Software; and

[0000068505-21-000021:mdna:43]
•$66 million from favorable currency rates.

[0000068505-21-000021:mdna:44]
[same as prior period, unchanged from 0000068505-21-000015:mdna:44]

[0000068505-21-000021:mdna:45]
•a 20% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software; and

[0000068505-21-000021:mdna:46]
•a 25% increase in the International region, inclusive of revenue from acquisitions, primarily driven by an increase in LMR, Video Security and Access Control and Command Center Software.

[0000068505-21-000021:mdna:47]
[same as prior period, unchanged from 0000068505-21-000015:mdna:47]

[0000068505-21-000021:mdna:48]
The 24% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-21-000021:mdna:49]
29

[0000068505-21-000021:mdna:50]
•$150 million, or 18% growth in LMR, driven by both the North America and International regions;

[0000068505-21-000021:mdna:51]
•$80 million, or 60% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000021:mdna:52]
[same as prior period, unchanged from 0000068505-21-000015:mdna:43]

[0000068505-21-000021:mdna:53]
[same as prior period, unchanged from 0000068505-21-000015:mdna:52]

[0000068505-21-000021:mdna:54]
The 19% increase in the Software and Services segment was driven by the following:

[0000068505-21-000021:mdna:55]
•$64 million, or 13% growth in LMR services, driven by both the International and North America regions;

[0000068505-21-000021:mdna:56]
•$42 million, or 81% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000021:mdna:57]
•$17 million, or 15% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000021:mdna:58]
•$34 million from favorable currency rates.

[0000068505-21-000021:mdna:59]
[same as prior period, unchanged from 0000068505-21-000015:mdna:58]

[0000068505-21-000021:mdna:60]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Gross margin | $ | 952 |  |  | $ | 766 |  |  | 24 | % |

[0000068505-21-000021:mdna:61]
Gross margin was 48.3% of net sales in the second quarter of 2021 compared to 47.3% in the second quarter of 2020. The primary drivers of this increase were:

[0000068505-21-000021:mdna:62]
•higher gross margin in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales volume and reduced reorganization of business charges, partially offset by an increase in employee incentive costs; and

[0000068505-21-000021:mdna:63]
•higher gross margin within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth and improved mix of service offerings, partially offset by an increase in employee incentive costs.

[0000068505-21-000021:mdna:64]
[same as prior period, unchanged from 0000068505-21-000015:mdna:63]

[0000068505-21-000021:mdna:65]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Selling, general and administrative expenses | $ | 331 |  |  | $ | 297 |  |  | 11 | % |

[0000068505-21-000021:mdna:66]
SG&A expenses increased 11% in the second quarter of 2021 compared to the second quarter of 2020. SG&A expenses were 16.8% of net sales in the second quarter of 2021 compared to 18.4% of net sales in the second quarter of 2020. The increase in SG&A expenses was primarily due to higher employee incentive costs, higher expenses associated with acquired businesses and higher travel expenses.

[0000068505-21-000021:mdna:67]
[same as prior period, unchanged from 0000068505-21-000015:mdna:66]

[0000068505-21-000021:mdna:68]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Research and development expenditures | $ | 181 |  |  | $ | 161 |  |  | 12 | % |

[0000068505-21-000021:mdna:69]
R&D expenditures increased 12% in the second quarter of 2021 compared to the second quarter of 2020 primarily due to higher employee incentive costs and higher expenses associated with acquired businesses. R&D expenditures decreased to 9.2% of net sales in the second quarter of 2021 compared to 10.0% of net sales in the second quarter of 2020.

[0000068505-21-000021:mdna:70]
[same as prior period, unchanged from 0000068505-21-000015:mdna:69]

[0000068505-21-000021:mdna:71]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Other charges | $ | 70 |  |  | $ | 90 |  |

[0000068505-21-000021:mdna:72]
Other charges decreased by $20 million in the second quarter of 2021 compared to the second quarter of 2020. The change was driven primarily by the following:

[0000068505-21-000021:mdna:73]
30

[0000068505-21-000021:mdna:74]
•$6 million of net reorganization business charges in the second quarter of 2021 compared to $26 million of net reorganization business charges in the second quarter of 2020 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q);

[0000068505-21-000021:mdna:75]
•no fixed asset impairments in the second quarter of 2021 compared to $5 million of fixed asset impairments in the second quarter of 2020;

[0000068505-21-000021:mdna:76]
•$3 million of losses on legal settlements in the second quarter of 2021 compared to $7 million of losses on legal settlements in the second quarter of 2020; and

[0000068505-21-000021:mdna:77]
•partially offset by $58 million of intangible asset amortization expense in the second quarter of 2021 compared to $51 million of intangible asset amortization expense in the second quarter of 2020.

[0000068505-21-000021:mdna:78]
[same as prior period, unchanged from 0000068505-21-000015:mdna:74]

[0000068505-21-000021:mdna:79]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Operating earnings from Products and Systems Integration | $ | 139 |  |  | $ | 49 |  |
| Operating earnings from Software and Services | 231 |  |  | 169 |  |
| Operating earnings | $ | 370 |  |  | $ | 218 |  |

[0000068505-21-000021:mdna:80]
Operating earnings increased $152 million, or 70%, in the second quarter of 2021 compared to the second quarter of 2020. The increase in Operating earnings was due to:

[0000068505-21-000021:mdna:81]
•$90 million increase in the Products and Systems Integration segment, driven by higher sales and gross margin, lower reorganization of business charges and improved operating leverage, partially offset by higher employee incentive costs and higher expenses associated with acquired businesses; and

[0000068505-21-000021:mdna:82]
•$62 million increase in the Software and Services segment, driven by higher sales and gross margin contribution, lower reorganization of business charges and improved operating leverage, partially offset by higher employee incentive costs and higher expenses associated with acquired businesses.

[0000068505-21-000021:mdna:83]
[same as prior period, unchanged from 0000068505-21-000015:mdna:79]

[0000068505-21-000021:mdna:84]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Interest expense, net | $ | (44) |  |  | $ | (58) |  |

[0000068505-21-000021:mdna:85]
The $14 million decrease in interest expense, net in the second quarter of 2021 compared to the second quarter of 2020 was a result of the reversal of a non-cash interest accrual related to an international tax audit and lower interest rates on debt outstanding for the three months ended July 3, 2021 compared to the three months ended June 27, 2020.

[0000068505-21-000021:mdna:86]
[same as prior period, unchanged from 0000068505-21-000015:mdna:82]

[0000068505-21-000021:mdna:87]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Other, net | $ | 14 |  |  | $ | 16 |  |

[0000068505-21-000021:mdna:88]
The $2 million decrease in Other, net in the second quarter of 2021 compared to the second quarter of 2020 was primarily driven by:

[0000068505-21-000021:mdna:89]
•$18 million loss on extinguishment of long-term debt in the second quarter of 2021;

[0000068505-21-000021:mdna:90]
•$1 million loss on derivatives in the second quarter of 2021 compared to a $12 million gain on derivatives in the second quarter of 2020; partially offset by

[0000068505-21-000021:mdna:91]
•$31 million of net periodic pension and postretirement benefit in the second quarter of 2021 compared to $19 million of net periodic pension and postretirement benefit in the second quarter of 2020; and

[0000068505-21-000021:mdna:92]
•$6 million of foreign currency losses in the second quarter of 2021 compared to $21 million of foreign currency losses in the second quarter of 2020.

[0000068505-21-000021:mdna:93]
[same as prior period, unchanged from 0000068505-21-000015:mdna:89]

[0000068505-21-000021:mdna:94]
|  | Three Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Income tax expense | $ | 46 |  |  | $ | 40 |  |

[0000068505-21-000021:mdna:95]
Income tax expense increased by $6 million in the second quarter of 2021 compared to the second quarter of 2020, primarily due to an increase in pretax earnings offset by a tax benefit of $33 million due to a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward, resulting in an effective tax rate of 14%. Our effective tax rate for the three months ended July 3, 2021 was lower than the effective tax rate for the three months ended June 27, 2020 of 23%, primarily due to a tax benefit of $33 million related to a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward.

[0000068505-21-000021:mdna:96]
Results of Operations—Six months ended July 3, 2021 compared to Six months ended June 27, 2020

[0000068505-21-000021:mdna:97]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |  | $ | 1,467 |  |  | $ | 742 |  |  | $ | 2,209 |  |
| International | 602 |  |  | 645 |  |  | 1,247 |  |  | 494 |  |  | 570 |  |  | 1,064 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |  | $ | 1,696 |  |  | $ | 970 |  |  | $ | 2,666 |  |
| Video Security and Access Control | 377 |  |  | 182 |  |  | 559 |  |  | 265 |  |  | 119 |  |  | 384 |  |
| Command Center Software | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 223 |  |  | 223 |  |
| Total | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Operating earnings | 216 |  |  | 452 |  |  | 668 |  |  | 141 |  |  | 335 |  |  | 476 |  |
| Operating margins | 9.8 | % |  | 29.5 | % |  | 17.8 | % |  | 7.2 | % |  | 25.5 | % |  | 14.5 | % |

[0000068505-21-000021:mdna:98]
Net Sales

[0000068505-21-000021:mdna:99]
The Products and Systems Integration segment's net sales represented 59% of our net sales in the first half of 2021 and 60% in the first half of 2020. Net sales from the Software and Services segment represented 41% of our net sales in the first half of 2021 and 40% in the first half of 2020.

[0000068505-21-000021:mdna:100]
Net sales increased $471 million, or 14%, in the first half of 2021 compared to the first half of 2020. The $252 million, or 13%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 10% in the North America region and an increase of 22% in the International region. The $219 million, or 17%, increase in net sales within the Software and Services segment was driven by an increase of 19% in the North America region and an increase of 13% in the International region. Net sales includes:

[0000068505-21-000021:mdna:101]
•an increase in the Products and Systems Integration segment, inclusive of $73 million of revenue from acquisitions, driven by an increase in Video Security and Access Control, PCR and public safety LMR;

[0000068505-21-000021:mdna:102]
•an increase in Software and Services, inclusive of $23 million of revenue from acquisitions, driven by an increase in LMR services, Video Security and Access Control and Command Center Software; and

[0000068505-21-000021:mdna:103]
•$98 million from favorable currency rates.

[0000068505-21-000021:mdna:104]
Regional results include:

[0000068505-21-000021:mdna:105]
•a 13% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software; and

[0000068505-21-000021:mdna:106]
•a 17% increase in the International region, inclusive of revenue from acquisitions, primarily driven by an increase in LMR, Video Security and Access Control and Command Center Software.

[0000068505-21-000021:mdna:107]
Products and Systems Integration

[0000068505-21-000021:mdna:108]
The 13% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-21-000021:mdna:109]
•$140 million, or 8% growth in LMR as well as revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000021:mdna:110]
•$112 million, or 42% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000021:mdna:111]
•$47 million from favorable currency rates.

[0000068505-21-000021:mdna:112]
Software and Services

[0000068505-21-000021:mdna:113]
The 17% increase in the Software and Services segment was driven by the following:

[0000068505-21-000021:mdna:114]
•$125 million, or 13% growth in LMR services, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000021:mdna:115]
•$63 million, or 53% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000021:mdna:116]
•$31 million, or 14% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000021:mdna:117]
•$51 million from favorable currency rates.

[0000068505-21-000021:mdna:118]
Gross Margin

[0000068505-21-000021:mdna:119]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Gross margin | $ | 1,812 |  |  | $ | 1,553 |  |  | 17 | % |

[0000068505-21-000021:mdna:120]
Gross margin was 48.4% of net sales in the first half of 2021 compared to 47.4% in the first half of 2020. The primary drivers of this increase were:

[0000068505-21-000021:mdna:121]
•higher gross margin within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth and improved mix of service offerings, partially offset by higher employee incentive costs; and

[0000068505-21-000021:mdna:122]
•higher gross margin in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales volume and reduced reorganization of business charges, partially offset by an increase in employee incentive costs.

[0000068505-21-000021:mdna:123]
Selling, General and Administrative Expenses

[0000068505-21-000021:mdna:124]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Selling, general and administrative expenses | $ | 633 |  |  | $ | 638 |  |  | (1) | % |

[0000068505-21-000021:mdna:125]
SG&A expenses decreased 1% in the first half of 2021 compared to the first half of 2020. SG&A expenses were 16.9% of net sales in the first half of 2021 compared to 19.5% of net sales in the first half of 2020. The decrease in SG&A expenses was primarily due to lower third party expenses, lower Hytera-related legal expenses, lower share-based compensation expenses and lower travel expenses. The overall reduction in SG&A expenses was partially offset by higher employee incentive costs and higher expenses associated with acquired businesses.

[0000068505-21-000021:mdna:126]
Research and Development Expenditures

[0000068505-21-000021:mdna:127]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |  | % Change |
| Research and development expenditures | $ | 361 |  |  | $ | 330 |  |  | 9 | % |

[0000068505-21-000021:mdna:128]
R&D expenditures increased 9% in the first half of 2021 compared to the first half of 2020 primarily due to higher employee incentive costs and higher expenses associated with acquired businesses. R&D expenditures decreased to 9.6% of net sales in the first half of 2021 compared to 10.1% of net sales in the first half of 2020.

[0000068505-21-000021:mdna:129]
Other Charges

[0000068505-21-000021:mdna:130]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Other charges | $ | 150 |  |  | $ | 109 |  |

[0000068505-21-000021:mdna:131]
33

[0000068505-21-000021:mdna:132]
Other charges increased by $41 million in the first half of 2021 compared to the first half of 2020. The change was driven primarily by the following:

[0000068505-21-000021:mdna:133]
•a $50 million gain on the sale of property, plant and equipment in the first half of 2020 that did not recur in the first half of 2021;

[0000068505-21-000021:mdna:134]
•$116 million of intangible asset amortization expense in the first half of 2021 compared to $104 million of intangible asset amortization expense in the first half of 2020;

[0000068505-21-000021:mdna:135]
•$7 million of operating lease asset impairments in the first half of 2021; partially offset by

[0000068505-21-000021:mdna:136]
•$20 million of net reorganization business charges in the first half of 2021 compared to $38 million in the first half of 2020 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q); and

[0000068505-21-000021:mdna:137]
•$3 million of losses on legal settlements in the first half of 2021 compared to $9 million of losses on legal settlements in the first half of 2020.

[0000068505-21-000021:mdna:138]
Operating Earnings

[0000068505-21-000021:mdna:139]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Operating earnings from Products and Systems Integration | $ | 216 |  |  | $ | 141 |  |
| Operating earnings from Software and Services | 452 |  |  | 335 |  |
| Operating earnings | $ | 668 |  |  | $ | 476 |  |

[0000068505-21-000021:mdna:140]
Operating earnings increased $192 million, or 40%, in the first half of 2021 compared to the first half of 2020. The increase in Operating earnings was due to:

[0000068505-21-000021:mdna:141]
•$117 million increase in the Software and Services segment, driven by higher sales and gross margin contribution due to improved mix of service offerings, lower reorganization of business charges, lower share-based compensation expenses and improved operating leverage, partially offset by higher employee incentive costs and higher expenses associated with acquired businesses; and

[0000068505-21-000021:mdna:142]
•$75 million increase in the Products and Systems Integration segment, primarily driven by higher gross margin due to increased sales volume, lower reorganization of business charges, lower third party expenses, lower Hytera-related legal expenses and lower travel expenses, partially offset by a $50 million gain on the sale of property, plant and equipment in the first half of 2020 that did not recur in the first half of 2021 and higher employee incentive costs and higher expenses associated with acquired businesses.

[0000068505-21-000021:mdna:143]
Interest Expense, net

[0000068505-21-000021:mdna:144]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Interest expense, net | $ | (98) |  |  | $ | (109) |  |

[0000068505-21-000021:mdna:145]
The $11 million decrease in net interest expense in the first half of 2021 compared to the first half of 2020 was a result of the reversal of a non-cash interest accrual related to an international tax audit, lower interest rates on debt outstanding and lower average debt outstanding for the six months ended July 3, 2021 compared to the six months ended June 27, 2020.

[0000068505-21-000021:mdna:146]
Other, net

[0000068505-21-000021:mdna:147]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Other, net | $ | 60 |  |  | $ | 34 |  |

[0000068505-21-000021:mdna:148]
The $26 million increase in Other, net in the first half of 2021 compared to the first half of 2020 was primarily driven by:

[0000068505-21-000021:mdna:149]
•$60 million of net periodic pension and postretirement benefit in the first half of 2021 compared to $39 million of net periodic pension and postretirement benefit in the first half of 2020;

[0000068505-21-000021:mdna:150]
•$8 million of foreign currency gains in the first half of 2021 compared to $3 million of foreign currency losses in the first half of 2020;

[0000068505-21-000021:mdna:151]
•$13 million of gains related to fair value adjustments to equity investments in the first half of 2021 compared to $5 million of gains related to fair value adjustments to equity investments in the first half of 2020; and

[0000068505-21-000021:mdna:152]
•partially offset by an $18 million loss on the extinguishment of long-term debt in the first half of 2021.

[0000068505-21-000021:mdna:153]
34

[0000068505-21-000021:mdna:154]
Effective Tax Rate

[0000068505-21-000021:mdna:155]
|  | Six Months Ended |
| (In millions) | July 3, 2021 |  | June 27, 2020 |
| Income tax expense | $ | 90 |  |  | $ | 67 |  |

[0000068505-21-000021:mdna:156]
Income tax expense increased by $23 million in the first half of 2021 compared to first half of 2020, primarily due to an increase in pretax earnings offset by a $33 million tax benefit due to a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward, resulting in an effective tax rate of 14%. Our effective tax rate for the six months ended July 3, 2021 was lower than the effective tax rate for the six months ended June 27, 2020 of 17%, primarily due to a tax benefit of $33 million related to a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward.

[0000068505-21-000021:mdna:157]
[same as prior period, unchanged from 0000068505-21-000015:mdna:92]

[0000068505-21-000021:mdna:158]
During the second quarter of 2021, we recorded net reorganization of business charges of $9 million, including $6 million of charges recorded within Other charges and $3 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $9 million were charges of $12 million related to employee separation costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-21-000021:mdna:159]
During the first half of 2021, we recorded net reorganization of business charges of $25 million, including $20 million of charges recorded within Other charges and $5 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $30 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-21-000021:mdna:160]
During the second quarter of 2020, we recorded net reorganization of business charges of $41 million, including $26 million of charges in Other charges and $15 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $41 million were charges of $46 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-21-000021:mdna:161]
During the first half of 2020, we recorded net reorganization of business charges of $59 million, including $38 million of charges in Other charges and $21 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $59 million were charges of $68 million related to employee separation costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-21-000021:mdna:162]
[same as prior period, unchanged from 0000068505-21-000015:mdna:95]

[0000068505-21-000021:mdna:163]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Products and Systems Integration | $ | 7 |  |  | $ | 33 |  |  | $ | 19 |  |  | $ | 47 |  |
| Software and Services | 2 |  |  | 8 |  |  | 6 |  |  | 12 |  |
|  | $ | 9 |  |  | $ | 41 |  |  | $ | 25 |  |  | $ | 59 |  |

[0000068505-21-000021:mdna:164]
Cash payments for employee severance in connection with the reorganization of business plans were $56 million in the first half of 2021 and $41 million in the first half of 2020. The reorganization of business accrual at July 3, 2021 was $48 million related to employee separation costs that are expected to be paid within one year.

[0000068505-21-000021:mdna:165]
[same as prior period, unchanged from 0000068505-21-000015:mdna:98]

[0000068505-21-000021:mdna:166]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 758 |  |  | $ | 517 |  |
| Investing activities | (114) |  |  | (141) |  |
| Financing activities | 30 |  |  | (17) |  |
| Effect of exchange rates on cash and cash equivalents | (7) |  |  | (19) |  |
| Increase (decrease) in cash and cash equivalents | $ | 667 |  |  | $ | 340 |  |

[0000068505-21-000021:mdna:167]
[same as prior period, unchanged from 0000068505-21-000015:mdna:100]

[0000068505-21-000021:mdna:168]
At July 3, 2021, $1.3 billion of the $1.9 billion cash and cash equivalents balance was held in the U.S. and $567 million was held in other countries, with $228 million held in the United Kingdom.

[0000068505-21-000021:mdna:169]
[same as prior period, unchanged from 0000068505-21-000015:mdna:102]

[0000068505-21-000021:mdna:170]
The increase in cash flows provided by operating activities from the first half of 2020 to the first half of 2021 was driven primarily by an increase in earnings as a result of increased sales volume and improved working capital, partially offset by higher income tax payments.

[0000068505-21-000021:mdna:171]
[same as prior period, unchanged from 0000068505-21-000015:mdna:104]

[0000068505-21-000021:mdna:172]
The decrease in cash flows used for investing activities from the first half of 2020 to the first half of 2021 was primarily due to:

[0000068505-21-000021:mdna:173]
•$93 million decrease in cash used for acquisitions and investments; partially offset by a

[0000068505-21-000021:mdna:174]
•$50 million decrease in the proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in the first half of 2020; and

[0000068505-21-000021:mdna:175]
•$12 million increase in capital expenditures due to higher payments for the Airwave and ESN networks.

[0000068505-21-000021:mdna:176]
[same as prior period, unchanged from 0000068505-21-000015:mdna:108]

[0000068505-21-000021:mdna:177]
The increase in cash flows provided by financing activities in the first half of 2021 as compared to the cash used for financing activities in the first half of 2020 was primarily driven by (also see further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-21-000021:mdna:178]
•$64 million decrease in share repurchases in the first half of 2021 compared to the first half of 2020;

[0000068505-21-000021:mdna:179]
•$844 million of net proceeds from the issuance of debt in the first half of 2021 compared to $800 million of proceeds received from the draw on our revolving credit facility during the first half of 2020;

[0000068505-21-000021:mdna:180]
•partially offset by $348 million of repayments of debt in the first half of 2021 compared to $300 million of repayments on the revolving credit facility and $8 million of repayments of debt in the first half of 2020; and

[0000068505-21-000021:mdna:181]
•$24 million increase in the payment of dividends in the first half of 2021 compared to the first half of 2020.

[0000068505-21-000021:mdna:182]
[same as prior period, unchanged from 0000068505-21-000015:mdna:115]

[0000068505-21-000021:mdna:183]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended July 3, 2021 and June 27, 2020:

[0000068505-21-000021:mdna:184]
|  | Three Months Ended |  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Contract-specific discounting facility | $ | 36 |  |  | $ | 54 |  |  | $ | 107 |  |  | $ | 98 |  |
| Accounts receivable sales proceeds | 8 |  |  | 34 |  |  | $ | 8 |  |  | $ | 58 |  |
| Long-term receivables sales proceeds | 30 |  |  | 29 |  |  | 84 |  |  | 70 |  |
| Total proceeds from receivable sales | $ | 74 |  |  | $ | 117 |  |  | $ | 199 |  |  | $ | 226 |  |

[0000068505-21-000021:mdna:185]
During the three and six months ended July 3, 2021, we utilized a contract-specific receivable discounting facility which began during the six months ended June 27, 2020, resulting in accounts receivable sales of $36 million and $107 million, respectively. The proceeds of our receivable sales are included in Operating activities within our Condensed Consolidated Statements of Cash Flows.

[0000068505-21-000021:mdna:186]
[same as prior period, unchanged from 0000068505-21-000015:mdna:119]

[0000068505-21-000021:mdna:187]
We had outstanding debt of $5.7 billion and $5.2 billion, including the current portions of $9 million and $12 million, at July 3, 2021 and December 31, 2020, respectively.

[0000068505-21-000021:mdna:188]
On May 24, 2021, we issued $850 million of 2.75% senior notes due 2031. We recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of our outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, we recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in our Condensed Consolidated Statements of Operations.

[0000068505-21-000021:mdna:189]
On March 24, 2021, we entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of July 3, 2021.

[0000068505-21-000021:mdna:190]
36

[0000068505-21-000021:mdna:191]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, we intend to settle the principal amount of the Senior Convertible Notes in cash. We recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, we calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital.

[0000068505-21-000021:mdna:192]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of July 3, 2021 we had no outstanding debt under the commercial paper program.

[0000068505-21-000021:mdna:193]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements, contractual obligations, debt service requirements and other liquidity requirements associated with our operations for at least the next twelve months and the reasonably foreseeable future thereafter, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement. Refer also to the “COVID-19” section in this Part I, Item 2 of this Form 10-Q for a discussion of the impact of COVID-19 on our liquidity.

[0000068505-21-000021:mdna:194]
[same as prior period, unchanged from 0000068505-21-000015:mdna:126]

[0000068505-21-000021:mdna:195]
During the three and six months ended July 3, 2021, we paid an aggregate of $102 million and $272 million, respectively, including transaction costs, to repurchase approximately 0.5 million and 1.5 million shares at an average price of $206.85 and $186.08 per share. During the three months ended July 3, 2021, the Board of Directors approved a $2.0 billion increase to the share repurchase program. As of July 3, 2021, the Company had used approximately $13.6 billion of the share repurchase authority to repurchase shares, leaving $2.4 billion of authority available for future repurchases.

[0000068505-21-000021:mdna:196]
[same as prior period, unchanged from 0000068505-21-000015:mdna:128]

[0000068505-21-000021:mdna:197]
During the second quarter of 2021 we paid $121 million in cash dividends to holders of our common stock. During the first half of 2021 we paid $242 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $120 million in cash dividends to holders of our common stock.

[0000068505-21-000021:mdna:198]
[same as prior period, unchanged from 0000068505-21-000015:mdna:130]

[0000068505-21-000021:mdna:199]
We had outstanding commitments to provide long-term financing to third parties totaling $99 million at July 3, 2021, compared to $78 million at December 31, 2020.

[0000068505-21-000021:mdna:200]
[same as prior period, unchanged from 0000068505-21-000015:mdna:132]

[0000068505-21-000021:mdna:201]
See “Recent Accounting Pronouncements” and “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
