# MSI notes — 0000068505-14-000016


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-14-000016:notes:1]
[same as prior period, unchanged from 0000068505-14-000010:notes:1]

[0000068505-14-000016:notes:2]
[same as prior period, unchanged from 0000068505-14-000010:notes:2]

[0000068505-14-000016:notes:3]
[same as prior period, unchanged from 0000068505-14-000010:notes:3]

[0000068505-14-000016:notes:4]
[same as prior period, unchanged from 0000068505-14-000010:notes:4]

[0000068505-14-000016:notes:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization | $ | 1 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 1 |  |
| Reorganization of businesses | 13 |  |  | 16 |  |  | 48 |  |  | 36 |  |
| Legal settlement | — |  |  | — |  |  | 8 |  |  | — |  |
| Pension-related transaction fees | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Gain on sale of building and land | — |  |  | — |  |  | (21 | ) |  | — |  |
|  | $ | 25 |  |  | $ | 16 |  |  | $ | 49 |  |  | $ | 37 |  |

[0000068505-14-000016:notes:6]
During the nine months ended September 27, 2014, the Company completed the sale of a building and parcel of land on its Schaumburg, IL campus with a net book value of $3 million for net cash proceeds of $24 million resulting in a gain on sale of $21 million.

[0000068505-14-000016:notes:7]
During the three months ended September 27, 2014, the Company incurred transaction fees, primarily consisting of fees incurred by outside advisors, related to certain transactions announced with respect to our U.S. Pension Benefit Plans (see footnote 7).

[0000068505-14-000016:notes:8]
[same as prior period, unchanged from 0000068505-14-000010:notes:7]

[0000068505-14-000016:notes:9]
[same as prior period, unchanged from 0000068505-14-000010:notes:8]

[0000068505-14-000016:notes:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (38 | ) |  | $ | (33 | ) |  | $ | (102 | ) |  | $ | (100 | ) |
| Interest income | 7 |  |  | 4 |  |  | 17 |  |  | 15 |  |
|  | $ | (31 | ) |  | $ | (29 | ) |  | $ | (85 | ) |  | $ | (85 | ) |
| Other: |  |  |  |  |  |  |  |
| Loss from the extinguishment of long-term debt | $ | (37 | ) |  | $ | — |  |  | $ | (37 | ) |  | $ | — |  |
| Investment impairments | — |  |  | (1 | ) |  | — |  |  | (3 | ) |
| Foreign currency gain (loss) | 4 |  |  | (1 | ) |  | $ | (6 | ) |  | $ | (8 | ) |
| Gains on equity method investments | 11 |  |  | 8 |  |  | 13 |  |  | 7 |  |
| Other | (4 | ) |  | 2 |  |  | (4 | ) |  | 7 |  |
|  | $ | (26 | ) |  | $ | 8 |  |  | $ | (34 | ) |  | $ | 3 |  |

[0000068505-14-000016:notes:11]
[same as prior period, unchanged from 0000068505-14-000010:notes:10]

[0000068505-14-000016:notes:12]
[same as prior period, unchanged from 0000068505-14-000010:notes:11]

[0000068505-14-000016:notes:13]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations |  | Net Earnings |
| Three Months Ended | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 66 |  |  | $ | 261 |  |  | $ | 147 |  |  | $ | 307 |  |
| Weighted average common shares outstanding | 246.3 |  |  | 262.2 |  |  | 246.3 |  |  | 262.2 |  |
| Per share amount | $ | 0.27 |  |  | $ | 1.00 |  |  | $ | 0.60 |  |  | $ | 1.17 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 66 |  |  | $ | 261 |  |  | $ | 147 |  |  | $ | 307 |  |
| Weighted average common shares outstanding | 246.3 |  |  | 262.2 |  |  | 246.3 |  |  | 262.2 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 1.9 |  |  | 3.1 |  |  | 1.9 |  |  | 3.1 |  |
| Diluted weighted average common shares outstanding | 248.2 |  |  | 265.3 |  |  | 248.2 |  |  | 265.3 |  |
| Per share amount | $ | 0.27 |  |  | $ | 0.98 |  |  | $ | 0.59 |  |  | $ | 1.16 |  |

[0000068505-14-000016:notes:14]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations |  | Net Earnings |
| Nine Months Ended | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 229 |  |  | $ | 641 |  |  | $ | 1,098 |  |  | $ | 757 |  |
| Weighted average common shares outstanding | 251.1 |  |  | 268.7 |  |  | 251.1 |  |  | 268.7 |  |
| Per share amount | $ | 0.91 |  |  | $ | 2.39 |  |  | $ | 4.37 |  |  | $ | 2.82 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 229 |  |  | $ | 641 |  |  | $ | 1,098 |  |  | $ | 757 |  |
| Weighted average common shares outstanding | 251.1 |  |  | 268.7 |  |  | 251.1 |  |  | 268.7 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.9 |  |  | 4.8 |  |  | 2.9 |  |  | 4.8 |  |
| Diluted weighted average common shares outstanding | 254.0 |  |  | 273.5 |  |  | 254.0 |  |  | 273.5 |  |
| Per share amount | $ | 0.90 |  |  | $ | 2.34 |  |  | $ | 4.32 |  |  | $ | 2.77 |  |

[0000068505-14-000016:notes:15]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three and nine months ended September 27, 2014, the assumed exercise of 4.9 million and 4.8 million stock options, respectively, were excluded because their inclusion would have been antidilutive.  In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three and nine months ended September 28, 2013, the assumed exercise of 5.6 million and 4.8 million stock options, respectively, were excluded because their inclusion would have been antidilutive.

[0000068505-14-000016:notes:16]
[same as prior period, unchanged from 0000068505-14-000010:notes:15]

[0000068505-14-000016:notes:17]
[same as prior period, unchanged from 0000068505-14-000010:notes:16]

[0000068505-14-000016:notes:18]
The Company’s cash and cash equivalents (which are highly-liquid investments with an original maturity of three months or less) were $2.8 billion at September 27, 2014 and $3.2 billion at December 31, 2013. Of these amounts, $63 million was restricted at both September 27, 2014 and December 31, 2013.

[0000068505-14-000016:notes:19]
[same as prior period, unchanged from 0000068505-14-000010:notes:18]

[0000068505-14-000016:notes:20]
[same as prior period, unchanged from 0000068505-14-000010:notes:19]

[0000068505-14-000016:notes:21]
|  | September 27, 2014 |  | December 31, 2013 |
| Available-for-sale securities: |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 15 |  |  | $ | 15 |  |
| Corporate bonds | 7 |  |  | 7 |  |
| Mutual funds | 11 |  |  | 11 |  |
| Common stock and equivalents | — |  |  | 2 |  |
|  | 33 |  |  | 35 |  |
| Other investments, at cost | 188 |  |  | 182 |  |
| Equity method investments | 19 |  |  | 15 |  |
|  | $ | 240 |  |  | $ | 232 |  |

[0000068505-14-000016:notes:22]
[same as prior period, unchanged from 0000068505-14-000010:notes:22]

[0000068505-14-000016:notes:23]
[same as prior period, unchanged from 0000068505-14-000010:notes:23]

[0000068505-14-000016:notes:24]
|  | September 27, 2014 |  | December 31, 2013 |
| Accounts receivable | $ | 1,189 |  |  | $ | 1,422 |  |
| Less allowance for doubtful accounts | (27 | ) |  | (53 | ) |
|  | $ | 1,162 |  |  | $ | 1,369 |  |

[0000068505-14-000016:notes:25]
[same as prior period, unchanged from 0000068505-14-000010:notes:25]

[0000068505-14-000016:notes:26]
[same as prior period, unchanged from 0000068505-14-000010:notes:26]

[0000068505-14-000016:notes:27]
|  | September 27, 2014 |  | December 31, 2013 |
| Finished goods | $ | 147 |  |  | $ | 157 |  |
| Work-in-process and production materials | 313 |  |  | 315 |  |
|  | 460 |  |  | 472 |  |
| Less inventory reserves | (129 | ) |  | (125 | ) |
|  | $ | 331 |  |  | $ | 347 |  |

[0000068505-14-000016:notes:28]
[same as prior period, unchanged from 0000068505-14-000010:notes:28]

[0000068505-14-000016:notes:29]
[same as prior period, unchanged from 0000068505-14-000010:notes:29]

[0000068505-14-000016:notes:30]
|  | September 27, 2014 |  | December 31, 2013 |
| Costs and earnings in excess of billings | $ | 456 |  |  | $ | 405 |  |
| Tax-related deposits and refunds receivable | 57 |  |  | 107 |  |
| Other | 91 |  |  | 123 |  |
|  | $ | 604 |  |  | $ | 635 |  |

[0000068505-14-000016:notes:31]
[same as prior period, unchanged from 0000068505-14-000010:notes:31]

[0000068505-14-000016:notes:32]
[same as prior period, unchanged from 0000068505-14-000010:notes:32]

[0000068505-14-000016:notes:33]
|  | September 27, 2014 |  | December 31, 2013 |
| Land | $ | 20 |  |  | $ | 22 |  |
| Building | 558 |  |  | 582 |  |
| Machinery and equipment | 1,833 |  |  | 1,760 |  |
|  | 2,411 |  |  | 2,364 |  |
| Less accumulated depreciation | (1,747 | ) |  | (1,669 | ) |
|  | $ | 664 |  |  | $ | 695 |  |

[0000068505-14-000016:notes:34]
Depreciation expense for the three months ended September 27, 2014 and September 28, 2013 was $44 million and $39 million, respectively. Depreciation expense for the nine months ended September 27, 2014 and September 28, 2013 was $128 million and $115 million, respectively.

[0000068505-14-000016:notes:35]
[same as prior period, unchanged from 0000068505-14-000010:notes:35]

[0000068505-14-000016:notes:36]
[same as prior period, unchanged from 0000068505-14-000010:notes:36]

[0000068505-14-000016:notes:37]
|  | September 27, 2014 |  | December 31, 2013 |
| Intangible assets, net | $ | 24 |  |  | $ | 6 |  |
| Long-term receivables | 21 |  |  | 1 |  |
| Other | 93 |  |  | 82 |  |
|  | $ | 138 |  |  | $ | 89 |  |

[0000068505-14-000016:notes:38]
[same as prior period, unchanged from 0000068505-14-000010:notes:38]

[0000068505-14-000016:notes:39]
[same as prior period, unchanged from 0000068505-14-000010:notes:39]

[0000068505-14-000016:notes:40]
|  | September 27, 2014 |  | December 31, 2013 |
| Deferred revenue | $ | 341 |  |  | $ | 359 |  |
| Compensation | 236 |  |  | 315 |  |
| Billings in excess of costs and earnings | 365 |  |  | 295 |  |
| Tax liabilities | 74 |  |  | 85 |  |
| Customer reserves | 53 |  |  | 52 |  |
| Dividend payable | 82 |  |  | 79 |  |
| Other | 522 |  |  | 578 |  |
|  | $ | 1,673 |  |  | $ | 1,763 |  |

[0000068505-14-000016:notes:41]
[same as prior period, unchanged from 0000068505-14-000010:notes:41]

[0000068505-14-000016:notes:42]
[same as prior period, unchanged from 0000068505-14-000010:notes:42]

[0000068505-14-000016:notes:43]
|  | September 27, 2014 |  | December 31, 2013 |
| Defined benefit plans | $ | 1,942 |  |  | $ | 1,751 |  |
| Postretirement Health Care Benefit Plan | 47 |  |  | 118 |  |
| Deferred revenue | 148 |  |  | 162 |  |
| Unrecognized tax benefits | 56 |  |  | 99 |  |
| Other | 171 |  |  | 184 |  |
|  | $ | 2,364 |  |  | $ | 2,314 |  |

[0000068505-14-000016:notes:44]
[same as prior period, unchanged from 0000068505-14-000010:notes:44]

[0000068505-14-000016:notes:45]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, and November 3, 2014, the Board of Directors has authorized the Company to repurchase an aggregate amount of up to $12.0 billion of its outstanding shares of common stock (the “share repurchase program”).  The share repurchase program does not have an expiration date.

[0000068505-14-000016:notes:46]
The Company paid an aggregate of $650 million during the third quarter of 2014, including transaction costs, to repurchase approximately 10.4 million shares at an average price of $62.63 per share. The Company paid an aggregate of $1.1 billion during the first nine months of 2014, including transaction costs, to repurchase approximately 17.4 million shares at an average price of $64.36 per share. As of September 27, 2014, the Company had used approximately $6.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $5.6 billion of authority available for future repurchases.

[0000068505-14-000016:notes:47]
Payment of Dividends:  During the three months ended September 27, 2014 and September 28, 2013, the Company paid $78 million and $69 million, respectively, in cash dividends to holders of its common stock. During the nine months ended September 27, 2014 and September 28, 2013, the Company paid $236 million and $212 million, respectively, in cash dividends to holders of its common stock.

[0000068505-14-000016:notes:48]
[same as prior period, unchanged from 0000068505-14-000010:notes:48]

[0000068505-14-000016:notes:49]
The following table displays the changes in Accumulated other comprehensive loss, net of tax, by component from January 1, 2014 to September 27, 2014:

[0000068505-14-000016:notes:50]
|  | Gains and Losses on Cash Flow Hedges |  | Unrealized Gains and Losses on Available-for-Sale Securities |  | Retirement Benefit Items |  | Foreign Currency Translation Adjustments |  | Total |
| Balance as of January 1, 2014 | $ | (1 | ) |  | $ | (2 | ) |  | $ | (2,188 | ) |  | $ | (96 | ) |  | $ | (2,287 | ) |
| Other comprehensive gain (loss) before reclassifications | — |  |  | 2 |  |  | (353 | ) |  | (19 | ) |  | (370 | ) |
| Amounts reclassified from accumulated other comprehensive loss | 1 |  |  | — |  |  | 31 |  |  | — |  |  | 32 |  |
| Current period change in Other comprehensive income | 1 |  |  | 2 |  |  | (322 | ) |  | (19 | ) |  | (338 | ) |
| Balance as of September 27, 2014 | $ | — |  |  | $ | — |  |  | $ | (2,510 | ) |  | $ | (115 | ) |  | $ | (2,625 | ) |

[0000068505-14-000016:notes:51]
The following table displays the amounts reclassified from Accumulated other comprehensive loss and the affected line items in the condensed consolidated statements of operations during the three and nine months ended September 27, 2014 and September 28, 2013:

[0000068505-14-000016:notes:52]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |  |  |
| Loss (gain) on cash flow hedges: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | (2 | ) |  | Cost of sales |
|  | — |  |  | — |  |  | 1 |  |  | (2 | ) |  | Net of tax |
| Amortization of retirement benefit items: |  |  |  |  |  |  |  |  |  |
| Prior service costs | $ | (15 | ) |  | (13 | ) |  | $ | (39 | ) |  | $ | (38 | ) |  | Selling, general, and administrative expenses |
| Actuarial net losses | 27 |  |  | 39 |  |  | 84 |  |  | 118 |  |  | Selling, general, and administrative expenses |
|  | 12 |  |  | 26 |  |  | 45 |  |  | 80 |  |  | Total before tax |
|  | (4 | ) |  | (9 | ) |  | (14 | ) |  | (28 | ) |  | Tax benefit |
|  | $ | 8 |  |  | $ | 17 |  |  | $ | 31 |  |  | $ | 52 |  |  | Net of tax |
| Total reclassifications for the period, net of tax | $ | 8 |  |  | $ | 17 |  |  | $ | 32 |  |  | $ | 50 |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-14-000016:notes:53]
Commitments and Contingencies

[0000068505-14-000016:notes:54]
Legal Matters

[0000068505-14-000016:notes:55]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s results of operations in the periods in which the matters are ultimately resolved.

[0000068505-14-000016:notes:56]
Other Indemnifications

[0000068505-14-000016:notes:57]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-14-000016:notes:58]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representation and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at September 27, 2014.

[0000068505-14-000016:notes:59]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.

[0000068505-14-000016:notes:60]
Also, pursuant to the Master Separation and Distribution Agreement and certain other agreements entered into in connection with the separation of Motorola Mobility Holdings, Inc. ("Motorola Mobility"),  Motorola Mobility agreed to indemnify the Company for certain liabilities, and the Company agreed to indemnify Motorola Mobility for certain liabilities, in each case for uncapped amounts.


## us-gaap:DebtDisclosureTextBlock

[0000068505-14-000016:notes:61]
Debt and Credit Facilities

[0000068505-14-000016:notes:62]
During the third quarter of 2014, the Company redeemed $400 million aggregate principal amount outstanding of its 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, the Company recognized a loss of $37 million related to the redemption within Other income (expense) in the condensed consolidated statement of operations. The Company issued an aggregate face principal amount of $1.4 billion including: (i) $600 million of 4.000% Senior notes due 2024, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior notes due 2021, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior notes due 2044, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $394 million.

[0000068505-14-000016:notes:63]
As of September 27, 2014, the Company had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of September 27, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the three and nine months ended September 27, 2014.

[0000068505-14-000016:notes:64]
As of September 27, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of September 27, 2014.

[0000068505-14-000016:notes:65]
During the first quarter of 2013, the Company issued an aggregate face principal amount of $600 million of 3.500% Senior Notes due 2023, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds from issuance of this debt of $588 million.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-14-000016:notes:66]
[same as prior period, unchanged from 0000068505-14-000010:notes:64]

[0000068505-14-000016:notes:67]
[same as prior period, unchanged from 0000068505-14-000010:notes:65]

[0000068505-14-000016:notes:68]
At September 27, 2014, the Company had outstanding foreign exchange contracts with notional amounts totaling $931 million, compared to $837 million outstanding at December 31, 2013.  The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions, except for the ineffective portion of the instruments, which are charged to Other within Other income (expense) in the Company’s condensed consolidated statements of operations.

[0000068505-14-000016:notes:69]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 27, 2014, and the corresponding positions as of December 31, 2013:

[0000068505-14-000016:notes:70]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 27, 2014 |  | December 31, 2013 |
| British Pound | $ | 331 |  |  | $ | 257 |  |
| Chinese Renminbi | (203 | ) |  | (181 | ) |
| Euro | 126 |  |  | (132 | ) |
| Norwegian Krone | (116 | ) |  | (95 | ) |
| Brazilian Real | (53 | ) |  | (44 | ) |

[0000068505-14-000016:notes:71]
[same as prior period, unchanged from 0000068505-14-000010:notes:69]

[0000068505-14-000016:notes:72]
At September 27, 2014, the Company had $3.4 billion of long-term debt, including the current portion, which is primarily priced at long-term, fixed interest rates.

[0000068505-14-000016:notes:73]
As part of its liability management program, one of the Company’s European subsidiaries has outstanding interest rate agreements (“Interest Agreements”) relating to Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Interest Agreements change the characteristics of interest payments from variable to maximum fixed-rate payments. The Interest Agreements are not accounted for as a part of a hedging relationship and, accordingly, the changes in the fair value of the Interest Agreements are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the Interest Agreements was in a liability position of $3 million at September 27, 2014 and  December 31, 2013.

[0000068505-14-000016:notes:74]
[same as prior period, unchanged from 0000068505-14-000010:notes:72]

[0000068505-14-000016:notes:75]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 27, 2014, all of the counterparties have investment grade credit ratings. As of September 27, 2014, the Company had $3 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-14-000016:notes:76]
The following tables summarize the fair values and location in the condensed consolidated balance sheets of all derivative financial instruments held by the Company at September 27, 2014 and December 31, 2013:

[0000068505-14-000016:notes:77]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| September 27, 2014 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other assets |  | $ | 9 |  |  | Other liabilities |
| Interest agreements | — |  |  | Other assets |  | 3 |  |  | Other liabilities |
| Total derivatives | $ | 5 |  |  |  |  | $ | 12 |  |  |  |

[0000068505-14-000016:notes:78]
[same as prior period, unchanged from 0000068505-14-000010:notes:76]

[0000068505-14-000016:notes:79]
The following table summarizes the effect of derivative instruments in the Company's condensed consolidated statements of operations for the three and nine months ended September 27, 2014 and September 28, 2013:

[0000068505-14-000016:notes:80]
|  | Three Months Ended |  | Nine Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | (6 | ) |  | 8 |  |  | (8 | ) |  | (1 | ) |  | Other income (expense) |

[0000068505-14-000016:notes:81]
The following table summarizes the gains and losses reclassified from Accumulated other comprehensive loss into Net earnings during the three and nine months ended September 27, 2014 and September 28, 2013:

[0000068505-14-000016:notes:82]
|  | Three Months Ended |  | Nine Months Ended |  | Financial StatementLocation |
| Foreign Exchange Contracts | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |  |
| Derivatives in cash flow hedging relationships: |  |  |  |  |  |  |  |  |  |
| Gains (losses) reclassified from Accumulated other comprehensive loss into Net earnings | $ | — |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 1 |  |  | Costs of sales |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-14-000016:notes:83]
[same as prior period, unchanged from 0000068505-14-000010:notes:81]

[0000068505-14-000016:notes:84]
[same as prior period, unchanged from 0000068505-14-000010:notes:82]

[0000068505-14-000016:notes:85]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 4 |  |  | $ | 9 |  |  | $ | 12 |  |
| Selling, general and administrative expenses | 14 |  |  | 18 |  |  | 47 |  |  | 56 |  |
| Research and development expenditures | 4 |  |  | 7 |  |  | 18 |  |  | 23 |  |
| Share-based compensation expense included in Operating earnings | 20 |  |  | 29 |  |  | 74 |  |  | 91 |  |
| Tax benefit | 6 |  |  | 9 |  |  | 23 |  |  | 28 |  |
| Share-based compensation expense, net of tax | $ | 14 |  |  | $ | 20 |  |  | $ | 51 |  |  | $ | 63 |  |
| Decrease in basic earnings per share | $ | (0.06 | ) |  | $ | (0.08 | ) |  | $ | (0.20 | ) |  | $ | (0.23 | ) |
| Decrease in diluted earnings per share | $ | (0.06 | ) |  | $ | (0.08 | ) |  | $ | (0.20 | ) |  | $ | (0.23 | ) |
| Share-based compensation expense in discontinued operations | $ | 5 |  |  | $ | 8 |  |  | $ | 18 |  |  | $ | 25 |  |

[0000068505-14-000016:notes:86]
For the nine months ended September 27, 2014, the Company granted 1.2 million RSUs and 1.3 million stock options.  The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and stock options, including those awards granted to employees of the Enterprise business, was $64 million and $14 million, respectively, which will be recognized over a weighted average vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-14-000016:notes:87]
[same as prior period, unchanged from 0000068505-14-000010:notes:85]

[0000068505-14-000016:notes:88]
On October 27, 2014, the Company closed on the sale of its Enterprise business with Zebra Technologies Corporation for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by the Company, including the Company’s iDEN business, and other assets and certain liabilities as specified in the Master Acquisition Agreement. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's condensed consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-14-000016:notes:89]
The following table displays summarized activity in the Company's condensed consolidated statements of operations for discontinued operations during the three and nine months ended September 27, 2014 and September 28, 2013:

[0000068505-14-000016:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Net sales | $ | 605 |  |  | $ | 595 |  |  | $ | 1,737 |  |  | $ | 1,782 |  |
| Operating earnings | 78 |  |  | 74 |  |  | 195 |  |  | 180 |  |
| Earnings before income taxes | 68 |  |  | 74 |  |  | 181 |  |  | 180 |  |
| Income tax expense (benefit) | (13 | ) |  | 28 |  |  | (688 | ) |  | 64 |  |
| Earnings from discontinued operations, net of tax | $ | 81 |  |  | $ | 46 |  |  | $ | 869 |  |  | $ | 116 |  |

[0000068505-14-000016:notes:91]
During the nine months ended September 27, 2014, the Company recorded a $748 million tax benefit to establish a deferred tax asset associated with an outside basis difference which we now expect to realize in the foreseeable future. The tax benefit represents the excess of the tax basis of our investment in the Enterprise subsidiaries over the financial statement carrying value (the deductible outside basis difference).

[0000068505-14-000016:notes:92]
The following table displays a summary of the assets and liabilities held for sale as of September 27, 2014 and December 31, 2013:

[0000068505-14-000016:notes:93]
|  | September 27, 2014 |  | December 31, 2013 |
| Assets: |  |  |  |
| Accounts receivable, net | $ | 514 |  |  | $ | 551 |  |
| Inventories, net | 223 |  |  | 175 |  |
| Deferred income taxes | 232 |  |  | 219 |  |
| Other current assets | 158 |  |  | 134 |  |
| Property, plant and equipment, net | 99 |  |  | 115 |  |
| Investments | 19 |  |  | 19 |  |
| Goodwill | 1,148 |  |  | 1,149 |  |
| Other assets | 102 |  |  | 95 |  |
|  | $ | 2,495 |  |  | $ | 2,457 |  |
| Liabilities: |  |  |  |
| Accounts payable | $ | 194 |  |  | $ | 231 |  |
| Accrued liabilities | 652 |  |  | 639 |  |
| Other liabilities | 164 |  |  | 171 |  |
|  | $ | 1,010 |  |  | $ | 1,041 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-14-000016:notes:94]
[same as prior period, unchanged from 0000068505-14-000010:notes:92]

[0000068505-14-000016:notes:95]
[same as prior period, unchanged from 0000068505-14-000010:notes:93]

[0000068505-14-000016:notes:96]
[same as prior period, unchanged from 0000068505-14-000010:notes:94]

[0000068505-14-000016:notes:97]
[same as prior period, unchanged from 0000068505-14-000010:notes:95]

[0000068505-14-000016:notes:98]
[same as prior period, unchanged from 0000068505-14-000010:notes:96]

[0000068505-14-000016:notes:99]
[same as prior period, unchanged from 0000068505-14-000010:notes:97]

[0000068505-14-000016:notes:100]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 27, 2014 and December 31, 2013 were as follows:

[0000068505-14-000016:notes:101]
| September 27, 2014 | Level 2 |
| Assets: |  |
| Foreign exchange derivative contracts | $ | 5 |  |
| Available-for-sale securities: |  |
| Government, agency, and government-sponsored enterprise obligations | 15 |  |
| Corporate bonds | 7 |  |
| Mutual funds | 11 |  |
| Liabilities: |  |
| Foreign exchange derivative contracts | $ | 9 |  |
| Interest agreement derivative contracts | 3 |  |

[0000068505-14-000016:notes:102]
[same as prior period, unchanged from 0000068505-14-000010:notes:100]

[0000068505-14-000016:notes:103]
The Company had no Level 3 holdings as of September 27, 2014 or December 31, 2013.

[0000068505-14-000016:notes:104]
At September 27, 2014 and December 31, 2013, the Company had $1.9 billion and $2.1 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-14-000016:notes:105]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at September 27, 2014 was $3.5 billion (Level 2). Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-14-000016:notes:106]
[same as prior period, unchanged from 0000068505-14-000010:notes:104]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-14-000016:notes:107]
[same as prior period, unchanged from 0000068505-14-000010:notes:105]

[0000068505-14-000016:notes:108]
[same as prior period, unchanged from 0000068505-14-000010:notes:106]

[0000068505-14-000016:notes:109]
[same as prior period, unchanged from 0000068505-14-000010:notes:107]

[0000068505-14-000016:notes:110]
|  | September 27, 2014 |  | December 31, 2013 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 37 |  |  | $ | 27 |  |  | $ | 24 |  |  | $ | 24 |  |
| Patents | 8 |  |  | 4 |  |  | 8 |  |  | 3 |  |
| Customer-related | 15 |  |  | 8 |  |  | 6 |  |  | 6 |  |
| Other intangibles | 17 |  |  | 14 |  |  | 15 |  |  | 14 |  |
|  | $ | 77 |  |  | $ | 53 |  |  | $ | 53 |  |  | $ | 47 |  |

[0000068505-14-000016:notes:111]
Amortization expense on intangible assets was $1 million for the three months ended September 27, 2014 and $3 million for the nine months ended September 27, 2014.  There was $1 million amortization expense incurred during the nine months ended September 28, 2013. As of September 27, 2014, annual amortization expense is estimated to be $4 million in 2014, 2015, and 2016, and $3 million in 2017 and 2018.

[0000068505-14-000016:notes:112]
[same as prior period, unchanged from 0000068505-14-000010:notes:110]

[0000068505-14-000016:notes:113]
|  | September 27, 2014 |  | December 31, 2013 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 74 |  |  | $ | 53 |  |  | $ | 53 |  |  | $ | 47 |  |
| Services | 3 |  |  | — |  |  | — |  |  | — |  |
|  | $ | 77 |  |  | $ | 53 |  |  | $ | 53 |  |  | $ | 47 |  |

[0000068505-14-000016:notes:114]
[same as prior period, unchanged from 0000068505-14-000010:notes:112]

[0000068505-14-000016:notes:115]
[same as prior period, unchanged from 0000068505-14-000010:notes:113]

[0000068505-14-000016:notes:116]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2014 to September 27, 2014:

[0000068505-14-000016:notes:117]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2014 |  |  |  |  |  |
| Aggregate goodwill | $ | 249 |  |  | $ | 112 |  |  | $ | 361 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 249 |  |  | $ | 112 |  |  | $ | 361 |  |
| Goodwill acquired | 15 |  |  | 7 |  |  | 22 |  |
| Balance as of September 27, 2014 |  |  |  |  |  |
| Aggregate goodwill | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |

[0000068505-14-000016:notes:118]
On December 31, 2013, the Company completed the acquisition of a communications software provider in push-to-talk-over-broadband applications for a gross purchase price of $48 million. During the nine months ended September 27, 2014, the Company completed the purchase accounting for this acquisition, recognizing $22 million of goodwill and $20 million of identifiable intangible assets. The results of operations for this acquisition have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date. The pro forma effects of this acquisition were not significant.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-14-000016:notes:119]
[same as prior period, unchanged from 0000068505-14-000010:notes:117]

[0000068505-14-000016:notes:120]
During the nine months ended September 27, 2014, the Company increased current deferred tax assets by $748 million related to an outside basis difference. The outside basis difference represents the excess of the tax basis of our investment in the

[0000068505-14-000016:notes:121]
Enterprise subsidiaries over the financial statement carrying value (the deductible outside basis difference).

[0000068505-14-000016:notes:122]
At September 27, 2014 and December 31, 2013, the Company had valuation allowances of $247 million and $200 million, respectively, including $214 million and $178 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company evaluates deferred  income taxes on a quarterly basis to determine if valuation allowances are required by considering available evidence, including historical and projected taxable income and tax planning strategies that are both prudent and feasible.  During the three months ended September 27, 2014, the Company recorded a $55 million tax charge to establish a valuation allowance against certain foreign deferred tax assets management believes are no longer more-likely-than-not realizable in future years. The Company believes the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-14-000016:notes:123]
Undistributed earnings the Company intends to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.6 billion at September 27, 2014 and $1.4 billion at December 31, 2013. The Company currently has no plans to repatriate the foreign earnings permanently reinvested and therefore, the time and manner of repatriation is uncertain. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-14-000016:notes:124]
[same as prior period, unchanged from 0000068505-14-000010:notes:121]

[0000068505-14-000016:notes:125]
As of September 27, 2014, the Company has approximately $700 million of foreign earnings not considered permanently reinvested and which may be repatriated without an additional tax charge, given the U.S. federal and foreign tax accrued on undistributed earnings and the utilization of available foreign tax credits.

[0000068505-14-000016:notes:126]
The Company had unrecognized tax benefits of $114 million and $147 million at September 27, 2014 and December 31, 2013, respectively, of which $93 million and $125 million, respectively, if recognized, would affect the effective tax rate, net of resulting changes to valuation allowances.  During the nine months ended September 27, 2014, the Company adjusted its unrecognized tax benefits for prior year tax positions for facts that now indicate the extent to which certain tax positions are more-likely-than-not of being sustained.  As a result, the Company recorded a gross increase of $21 million and a gross decrease of $53 million to unrecognized tax benefits for prior year tax positions resulting in a net tax benefit of $32 million.

[0000068505-14-000016:notes:127]
[same as prior period, unchanged from 0000068505-14-000010:notes:124]

[0000068505-14-000016:notes:128]
[same as prior period, unchanged from 0000068505-14-000010:notes:125]


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-14-000016:notes:129]
[same as prior period, unchanged from 0000068505-14-000010:notes:126]

[0000068505-14-000016:notes:130]
The condensed consolidated financial statements as of September 27, 2014 and for the three and nine months ended September 27, 2014 and September 28, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-14-000016:notes:131]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013 and Form 8-K filed on August 7, 2014.  The results of operations for the three and nine months ended September 27, 2014 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-14-000016:notes:132]
[same as prior period, unchanged from 0000068505-14-000010:notes:129]

[0000068505-14-000016:notes:133]
[same as prior period, unchanged from 0000068505-14-000010:notes:130]

[0000068505-14-000016:notes:134]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company does not believe this ASU will have a material impact to its consolidated its financial statements.

[0000068505-14-000016:notes:135]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for the Company beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:PastDueFinancingReceivablesTableTextBlock

[0000068505-14-000016:notes:136]
An aging analysis of financing receivables at September 27, 2014 and December 31, 2013 is as follows:

[0000068505-14-000016:notes:137]
| September 27, 2014 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 5 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Commercial loans and leases secured | 35 |  |  | 1 |  |  | — |  |  | 13 |  |
| Total gross long-term receivables, including current portion | $ | 40 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 13 |  |

[0000068505-14-000016:notes:138]
[same as prior period, unchanged from 0000068505-14-000010:notes:135]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-14-000016:notes:139]
[same as prior period, unchanged from 0000068505-14-000010:notes:136]

[0000068505-14-000016:notes:140]
[same as prior period, unchanged from 0000068505-14-000010:notes:137]

[0000068505-14-000016:notes:141]
The net periodic costs (benefits) for Pension and Postretirement Health Care Benefits Plans were as follows:

[0000068505-14-000016:notes:142]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 93 |  |  | 88 |  |  | 20 |  |  | 19 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (97 | ) |  | (91 | ) |  | (23 | ) |  | (21 | ) |  | (3 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 23 |  |  | 31 |  |  | 3 |  |  | 5 |  |  | 1 |  |  | 5 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (2 | ) |  | (1 | ) |  | (13 | ) |  | (11 | ) |
| Net periodic pension cost (benefit) | $ | 19 |  |  | $ | 28 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | (13 | ) |  | $ | (4 | ) |

[0000068505-14-000016:notes:143]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 11 |  |  | $ | 8 |  |  | $ | 1 |  |  | $ | 2 |  |
| Interest cost | 278 |  |  | 264 |  |  | 61 |  |  | 52 |  |  | 8 |  |  | 9 |  |
| Expected return on plan assets | (294 | ) |  | (273 | ) |  | (69 | ) |  | (58 | ) |  | (7 | ) |  | (7 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 68 |  |  | 95 |  |  | 9 |  |  | 11 |  |  | 7 |  |  | 12 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (5 | ) |  | (5 | ) |  | (35 | ) |  | (33 | ) |
| Net periodic pension cost (benefit) | $ | 52 |  |  | $ | 86 |  |  | $ | 7 |  |  | $ | 8 |  |  | $ | (26 | ) |  | $ | (17 | ) |

[0000068505-14-000016:notes:144]
During the three months ended September 27, 2014 and September 28, 2013, contributions of $397 million and $72 million were made to the Company’s U.S. Pension Benefit Plans, respectively.  During both the three months ended September 27, 2014 and September 28, 2013, contributions of $7 million were made to the Company’s Non U.S. Pension Benefit Plans.

[0000068505-14-000016:notes:145]
During the nine months ended September 27, 2014 and September 28, 2013, contributions of $463 million and $122 million were made to the Company’s U.S. Pension Benefit Plans, respectively.  During the nine months ended September 27, 2014 and September 28, 2013, contributions of $27 million and $24 million were made to the Company’s Non U.S. Pension Benefit Plans, respectively.

[0000068505-14-000016:notes:146]
On September 22, 2014, the Company entered into a Definitive Purchase Agreement (the “Agreement”) by and among the Company, The Prudential Insurance Company of America (“PICA”), Prudential Financial, Inc., and State Street Bank and Trust Company, as Independent Fiduciary of the Company's U.S. noncontributory pension plan (the "Regular Pension Plan"), pursuant to which the Regular Pension Plan will purchase from PICA a group annuity contract that requires PICA to pay and administer certain future annuity payments to certain of the Company’s retirees. Upon issuance of the group annuity contract by PICA, PICA will irrevocably assume the obligation to make future annuity payments to approximately 30,000 Company retirees who have been receiving pension payments from the Regular Pension Plan. During the three months ended September 27, 2014, in connection with the proposed transaction, the Company has established a new pension plan with substantially the same terms as the Regular Pension Plan (the “New Plan,” together with the Regular Pension Plan, “the Plans”), and it is expected that the Regular Pension Plan will ultimately be terminated.

[0000068505-14-000016:notes:147]
As a result of establishing the New Plan, the Company remeasured the Plans using a weighted average discount rate and expected long-term rates of return on assets of 4.53% and 5.80%, respectively, resulting in an aggregate funded status of $(1.5) billion, with unrecognized losses in Accumulated other comprehensive losses within the Company’s condensed consolidated balance sheet of $3.4 billion.

[0000068505-14-000016:notes:148]
On September 25, 2014, the Company announced that the New Plan is offering lump-sum distributions to certain New Plan participants who have accrued a pension benefit, have left the Company prior to June 30, 2014, and have not yet started receiving pension benefit payments. The maximum dollar amount of all lump-sum distributions to be paid under the offer is $1.0 billion, and lump-sum payments will be made to those who accept the lump-sum offer starting with the smallest amount of lump sums first and continuing in ascending order until the $1.0 billion threshold is met.

[0000068505-14-000016:notes:149]
During the three months ended September 27, 2014, the Company made an amendment to the Postretirement Health Care Benefits Plan (the “New Amendment”). As a result of the New Amendment, beginning March 1, 2015, all eligible retirees under the age of 65 will be able to use the annual subsidy they receive through their retiree health reimbursement account toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.  Additionally, the New Amendment eliminated dental benefits under the plan.

[0000068505-14-000016:notes:150]
The New Amendment to the Postretirement Health Care Benefits Plan required a remeasurement of the plan, resulting in a $45 million decrease in Accumulated other comprehensive loss, net of taxes.  A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the condensed consolidated statements of operations over almost three years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.

[0000068505-14-000016:notes:151]
The Company made no contributions to its Postretirement Health Care Benefits Plan during the three and nine months ended September 27, 2014 and September 28, 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-14-000016:notes:152]
[same as prior period, unchanged from 0000068505-14-000010:notes:144]

[0000068505-14-000016:notes:153]
[same as prior period, unchanged from 0000068505-14-000010:notes:145]

[0000068505-14-000016:notes:154]
During the three months ended September 27, 2014, the Company recorded net reorganization of business charges of $20 million including $13 million of charges in Other charges, and $7 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $20 million of charges were all related to employee separation costs.

[0000068505-14-000016:notes:155]
During the nine months ended September 27, 2014, the Company recorded net reorganization of business charges of $58 million including $48 million of charges in Other charges, and $10 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $58 million were charges of $54 million for employee separation costs and $4 million for exit costs.

[0000068505-14-000016:notes:156]
[same as prior period, unchanged from 0000068505-14-000010:notes:148]

[0000068505-14-000016:notes:157]
| September 27, 2014 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 13 |  |  | $ | 38 |  |
| Services | 7 |  |  | 20 |  |
|  | $ | 20 |  |  | $ | 58 |  |

[0000068505-14-000016:notes:158]
The following table displays a rollforward of the reorganization of businesses accruals established for lease exit costs and employee separation costs, including those related to discontinued operations which are maintained by the Company after the sale of the Enterprise business, from January 1, 2014 to September 27, 2014:

[0000068505-14-000016:notes:159]
|  | January 1, 2014 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | September 27, 2014 |
| Exit costs | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | (10 | ) |  | $ | 2 |  |
| Employee separation costs | 103 |  |  | 67 |  |  | (2 | ) |  | (106 | ) |  | 62 |  |
|  | $ | 109 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | (116 | ) |  | $ | 64 |  |

[0000068505-14-000016:notes:160]
[same as prior period, unchanged from 0000068505-14-000010:notes:152]

[0000068505-14-000016:notes:161]
At January 1, 2014, the Company had an accrual of $6 million for exit costs attributable to lease terminations. During the nine months ended September 27, 2014, there were $6 million of additional charges and $10 million of cash payments related to the exit of leased facilities, including $3 million paid for facilities related to discontinued operations. The remaining accrual of $2 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at September 27, 2014, primarily represents future cash payments for lease termination obligations that are expected to be paid over a number of years.

[0000068505-14-000016:notes:162]
[same as prior period, unchanged from 0000068505-14-000010:notes:154]

[0000068505-14-000016:notes:163]
At January 1, 2014, the Company had an accrual of $103 million for employee separation costs. The 2014 additional charges of $67 million represent severance costs for approximately 1,000 employees, all of which were indirect employees. The adjustment of $2 million reflects reversals of accruals no longer needed. The $106 million used reflects cash payments, including $37 million related to employees of discontinued operations. The remaining accrual of $62 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at September 27, 2014, is expected to be paid, primarily within one year, to approximately 750 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-14-000016:notes:164]
[same as prior period, unchanged from 0000068505-14-000010:notes:156]

[0000068505-14-000016:notes:165]
During the three months ended September 28, 2013, the Company recorded net reorganization of business charges of $21 million, including $16 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $21 million of charges were all related to employee separation costs.

[0000068505-14-000016:notes:166]
During the nine months ended September 28, 2013, the Company recorded net reorganization of business charges of $46 million, including $36 million of charges in Other charges and $10 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $46 million were charges of $50 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-14-000016:notes:167]
| September 28, 2013 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 14 |  |  | $ | 30 |  |
| Services | 7 |  |  | 16 |  |
|  | $ | 21 |  |  | $ | 46 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-14-000016:notes:168]
[same as prior period, unchanged from 0000068505-14-000010:notes:160]

[0000068505-14-000016:notes:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Products | $ | 921 |  |  | $ | 998 |  |  | $ | 2,561 |  |  | $ | 2,897 |  |
| Services | 515 |  |  | 519 |  |  | 1,497 |  |  | 1,513 |  |
|  | $ | 1,436 |  |  | $ | 1,517 |  |  | $ | 4,058 |  |  | $ | 4,410 |  |

[0000068505-14-000016:notes:170]
[same as prior period, unchanged from 0000068505-14-000010:notes:162]

[0000068505-14-000016:notes:171]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Products | $ | 141 |  |  | $ | 171 |  |  | $ | 276 |  |  | $ | 402 |  |
| Services | 66 |  |  | 75 |  |  | 176 |  |  | 220 |  |
| Operating earnings | 207 |  |  | 246 |  |  | 452 |  |  | 622 |  |
| Total other income (expense) | (56 | ) |  | 5 |  |  | (115 | ) |  | (48 | ) |
| Earnings from continuing operations before income taxes | $ | 151 |  |  | $ | 251 |  |  | $ | 337 |  |  | $ | 574 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-14-000016:notes:172]
[same as prior period, unchanged from 0000068505-14-000010:notes:164]

[0000068505-14-000016:notes:173]
The Company has the following two segments:

[0000068505-14-000016:notes:174]
[same as prior period, unchanged from 0000068505-14-000010:notes:166]

[0000068505-14-000016:notes:175]
Services: The Services segment has a full breadth of service offerings for both public safety and private communication networks including: (i) Integration services, (ii) Lifecycle Management and Support services, (iii) Managed services, and (iv) Smart Public Safety Solutions. Integration services includes implementation, optimization, and integration of networks, devices, and applications.  Lifecycle Management and Support services includes lifecycle planning, upgrades, call center, network monitoring, and repair services.  Managed services includes managing customer networks at defined services levels. Smart Public Safety Solutions includes integration of hardware and software to meet customer needs.


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-14-000016:notes:176]
Long-term customer financing receivables consist of trade receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term customer financing receivables consist of the following:

[0000068505-14-000016:notes:177]
|  | September 27, 2014 |  | December 31, 2013 |
| Long-term receivables | $ | 40 |  |  | $ | 27 |  |
| Less current portion | (19 | ) |  | (26 | ) |
| Non-current long-term receivables, net | $ | 21 |  |  | $ | 1 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-14-000016:notes:178]
Long-term Customer Financing and Sales of Receivables

[0000068505-14-000016:notes:179]
Long-term Customer Financing

[0000068505-14-000016:notes:180]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $128 million at September 27, 2014, compared to $50 million at December 31, 2013.

[0000068505-14-000016:notes:181]
Sales of Receivables

[0000068505-14-000016:notes:182]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 27, 2014 and September 28, 2013:

[0000068505-14-000016:notes:183]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Cumulative annual proceeds received from sales: |  |  |  |  |  |  |  |
| Accounts receivable sales proceeds | $ | 6 |  |  | $ | 4 |  |  | $ | 39 |  |  | $ | 6 |  |
| Long-term receivables sales proceeds | 37 |  |  | 37 |  |  | 91 |  |  | 90 |  |
| Total proceeds from receivable sales | $ | 43 |  |  | $ | 41 |  |  | $ | 130 |  |  | $ | 96 |  |

[0000068505-14-000016:notes:184]
At September 27, 2014, the Company had retained servicing obligations for $473 million of long-term receivables, compared to $434 million of long-term receivables at December 31, 2013.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-14-000016:notes:185]
Credit Quality of Customer Financing Receivables and Allowance for Credit Losses

[0000068505-14-000016:notes:186]
The Company had a total of $13 million of financing receivables past due over 90 days as of September 27, 2014 in relation to two loans. The Company has not accrued interest on these loans, which are adequately reserved, during the three and nine months ended September 27, 2014.
