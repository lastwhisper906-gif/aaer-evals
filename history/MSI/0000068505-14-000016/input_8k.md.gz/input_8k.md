# MSI 8-K — 0001193125-14-395045 filed 2014-11-04

## item codes, every 8-K on or before 2014-11-04

- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2014-11-04

- none on or before 2014-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-395045:8k_2_02:1]
EX-99.1
2
d815229dex991.htm
EX-99.1

[0001193125-14-395045:8k_2_02:2]
EX-99.1

[0001193125-14-395045:8k_2_02:3]
Exhibit 99.1

[0001193125-14-395045:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2014

[0001193125-14-395045:8k_2_02:5]
Financial Results

[0001193125-14-395045:8k_2_02:6]
Announces $5 billion increase to share repurchase program

[0001193125-14-395045:8k_2_02:7]
|  | • |  | Sales of $1.4 billion, down 5 percent from a year ago |

[0001193125-14-395045:8k_2_02:8]
|  | • |  | GAAP earnings per share (EPS) from continuing operations* of $0.27 |

[0001193125-14-395045:8k_2_02:9]
|  | • |  | Non-GAAP** EPS from continuing operations of $0.62 |

[0001193125-14-395045:8k_2_02:10]
|  | • |  | Returned $728 million to shareholders through share repurchases and cash dividends, including the repurchase of $650 million of stock in the third quarter |

[0001193125-14-395045:8k_2_02:11]
SCHAUMBURG, Ill. – Nov. 4, 2014 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of
2014. Click here for a printable news release and financial tables.

[0001193125-14-395045:8k_2_02:12]
SHARE REPURCHASE AUTHORIZATION

[0001193125-14-395045:8k_2_02:13]
Today, the company also announced that its board of directors has approved a $5 billion increase to the share repurchase program following receipt of $3.45
billion from the sale of its Enterprise business, raising the total authorization since July 2011 to $12 billion. Under the company’s previously authorized $7 billion share repurchase program, $600 million remained as of the end of the third
quarter of 2014. The company may continue to repurchase shares from time to time in the open market or in other privately negotiated transactions, subject to market conditions.

[0001193125-14-395045:8k_2_02:14]
SUPPORTING QUOTE

[0001193125-14-395045:8k_2_02:15]
“We are encouraged by
third-quarter revenues and earnings as the business continues to show signs of improvement,” said Greg Brown, chairman and CEO, Motorola Solutions. “Additionally, our actions to simplify our operations and remove costs continue to yield
sustainable operating expense reductions, which will further position us for long-term success.”

[0001193125-14-395045:8k_2_02:16]
KEY FINANCIAL RESULTS

[0001193125-14-395045:8k_2_02:17]
|  |  | Third Quarter |  |  | Change |  |
|  |  | 2014 |  |  | 2013 |  |  |
| Motorola Solutions, Inc. |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 1,436 |  |  | $ | 1,517 |  |  |  | -5 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings ($M) |  | $ | 207 |  |  | $ | 246 |  |  |  | -16 | % |
| Percent of sales |  |  | 14.4 | % |  |  | 16.2 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.27 |  |  | $ | 0.98 |  |  |  | -72 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings ($M) |  | $ | 259 |  |  | $ | 296 |  |  |  | -13 | % |
| Percent of sales |  |  | 18.0 | % |  |  | 19.5 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.62 |  |  | $ | 1.08 |  |  |  | -43 | % |
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 921 |  |  | $ | 998 |  |  |  | -8 | % |
| GAAP operating earnings ($M) |  | $ | 141 |  |  | $ | 171 |  |  |  | -18 | % |
| Percent of sales |  |  | 15.3 | % |  |  | 17.1 | % |  |  |  |  |

[0001193125-14-395045:8k_2_02:18]
| Non-GAAP operating earnings ($M) |  | $ | 175 |  |  | $ | 204 |  |  |  | -14 | % |
| Percent of sales |  |  | 19.0 | % |  |  | 20.4 | % |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 515 |  |  | $ | 519 |  |  |  | -1 | % |
| GAAP operating earnings ($M) |  | $ | 66 |  |  | $ | 75 |  |  |  | -12 | % |
| Percent of sales |  |  | 12.8 | % |  |  | 14.5 | % |  |  |  |  |
| Non-GAAP operating earnings ($M) |  | $ | 84 |  |  | $ | 92 |  |  |  | -9 | % |
| Percent of sales |  |  | 16.3 | % |  |  | 17.7 | % |  |  |  |  |

[0001193125-14-395045:8k_2_02:19]
Non-GAAP financial information excludes after-tax charges of approximately $0.35 per diluted share related to share-based
compensation and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0001193125-14-395045:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-14-395045:8k_2_02:21]
|  | • |  | Revenue – Sales declined 5 percent to $1.4 billion primarily reflecting lower sales in North America and Asia-Pacific. Product sales declined 8 percent driven primarily by lower devices revenues, while Services declined 1 percent. |

[0001193125-14-395045:8k_2_02:22]
|  | • |  | Operating margin – GAAP operating margin was 14.4 percent of sales; non-GAAP operating margin was 18.0 percent. These results include $43 million in lower operating expenses compared with the third quarter of 2013 primarily due to ongoing cost-reduction initiatives. |

[0001193125-14-395045:8k_2_02:23]
|  | • |  | Taxes – The 2014 GAAP effective tax rate was 56 percent driven by a one-time $55 million adjustment. This compares with a favorable tax rate of -4 percent in the third quarter of 2013. The 2014 non-GAAP tax rate was 33 percent, compared with a favorable tax rate of -3 percent in the third quarter of 2013. The GAAP and non-GAAP tax rates in the third quarter of 2013 were favorably impacted by benefits largely associated with excess foreign tax credits on undistributed foreign earnings in that quarter. |

[0001193125-14-395045:8k_2_02:24]
|  | • |  | Cash flow – The company used $115 million in operating cash from continuing operations during the quarter largely driven by a $397 million contribution related to the U.S. pension plan transactions announced on Sept. 25, 2014. |

[0001193125-14-395045:8k_2_02:25]
KEY HIGHLIGHTS

[0001193125-14-395045:8k_2_02:26]
|  | • |  | Reduced funding volatility associated with U.S. pension plan while preserving benefits for retirees through actions that cut pension liability by one-half, or $4.2 billion; the company expects no U.S. pension plan cash contribution requirements for the next five to six years |

[0001193125-14-395045:8k_2_02:27]
|  | • |  | Secured significant projects including a $33 million statewide public safety system expansion with the state of Maryland, and two command and control solutions that include multi-year lifecycle services: $16 million with Loudoun County, Virginia, and $8 million Spartanburg County, South Carolina |

[0001193125-14-395045:8k_2_02:28]
|  | • |  | Extended leadership in two key growth areas, including: |

[0001193125-14-395045:8k_2_02:29]
|  | • |  | Public safety long-term evolution (LTE): a $21 million services project for the Los Angeles Regional Interoperable Communications System Authority (LA-RICS) network, as well as a $10-15 million project resulting from an agreement that Harris County, Texas, reached with FirstNet to move forward with the expansion of its public safety LTE deployment |

[0001193125-14-395045:8k_2_02:30]
|  | • |  | Smart public safety: project with the city of Elgin, Illinois, for a Real-Time Crime Center solution that enables access to existing video feeds, computer-aided dispatch records and other systems to drive proactive policing and improve situational awareness at the command center |

[0001193125-14-395045:8k_2_02:31]
|  | • |  | Demonstrated commitment to U.S. national public safety broadband LTE network with introduction of enhanced VML750 LTE Vehicle Modem, which enables roaming between public and private networks for enhanced interoperability |

[0001193125-14-395045:8k_2_02:32]
BUSINESS OUTLOOK***

[0001193125-14-395045:8k_2_02:33]
|  | • |  | Fourth quarter 2014 – Motorola Solutions expects a revenue decline of 1 to 3 percent compared with the fourth quarter of 2013, with non-GAAP earnings per share from continuing operations in the range of $1.13 to $1.19 per share. This is consistent with the company’s prior full-year outlook of low- to mid-single digit revenue decline, excluding iDEN. |

[0001193125-14-395045:8k_2_02:34]
|  | • |  | Cost reductions – The company is ahead of schedule with operating cost reductions, expecting to achieve more than $200 million in savings in 2014 and on track to achieve approximately $300 million by the end of 2015. This will result in a total reduction in operating expenses from $2 billion in 2013 to approximately $1.7 billion for 2015. |

[0001193125-14-395045:8k_2_02:35]
RESULTS FROM DISCONTINUED OPERATIONS

[0001193125-14-395045:8k_2_02:36]
On Oct. 27,
Motorola Solutions closed the sale of its Enterprise business to Zebra Technologies, and the Enterprise business is reflected as discontinued operations. Sales from discontinued operations were $605 million in the third quarter of 2014 compared with
$595 million in the year-ago quarter. The sales increase reflects strength in both North America and Europe, while supply chain and IT execution issues that had an unfavorable impact on second-quarter 2014 sales were addressed during the quarter.

[0001193125-14-395045:8k_2_02:37]
CONFERENCE CALL AND WEBCAST

[0001193125-14-395045:8k_2_02:38]
Motorola Solutions will
host its quarterly conference call beginning at 7 a.m. U.S. Central Standard Time (8 a.m. U.S. Eastern Standard Time) Tuesday, Nov. 4. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-14-395045:8k_2_02:39]
CONSOLIDATED GAAP RESULTS

[0001193125-14-395045:8k_2_02:40]
A comparison of results from
operations is as follows:

[0001193125-14-395045:8k_2_02:41]
|  |  | Third Quarter |  |
|  |  | 2014 |  |  | 2013 |  |
| Net sales ($M) |  | $ | 1,436 |  |  | $ | 1,517 |  |
| Gross margin ($M) |  |  | 685 |  |  |  | 765 |  |
| Operating earnings ($M) |  |  | 207 |  |  |  | 246 |  |
| Earnings from continuing operations ($M) |  |  | 66 |  |  |  | 261 |  |
| Diluted EPS from continuing operations |  | $ | 0.27 |  |  | $ | 0.98 |  |
| Weighted average diluted common shares outstanding |  |  | 248.2 |  |  |  | 265.3 |  |

[0001193125-14-395045:8k_2_02:42]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-14-395045:8k_2_02:43]
The table below includes highlighted items and share-based compensation expense for the third quarter of 2014.

[0001193125-14-395045:8k_2_02:44]
|  |  | Third Quarter |  |
| (per diluted common share) |  | 2014 |  |
| GAAP Earnings from Continuing Operations |  | $ | 0.27 |  |
| Highlighted Items: |  |  |  |  |
| Tax expense to establish foreign valuation allowance |  |  | 0.22 |  |
| Loss from the extinguishment of long-term debt |  |  | 0.09 |  |
| Reorganization of business charges |  |  | 0.06 |  |
| Share-based compensation expense |  |  | 0.06 |  |
| Pension-related transaction fees |  |  | 0.03 |  |
| Gain on investment |  |  | (0.04 | ) |
| Revaluation of deferred taxes from change in effective state tax rates |  |  | (0.07 | ) |
| Total Highlighted Items |  |  | 0.35 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 0.62 |  |

[0001193125-14-395045:8k_2_02:45]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-14-395045:8k_2_02:46]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-14-395045:8k_2_02:47]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-14-395045:8k_2_02:48]
Share-based compensation expense: The company has excluded share-based compensation expense from its
non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods
presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense.
Share-based compensation expense will recur in future periods.

[0001193125-14-395045:8k_2_02:49]
Details of the above items and reconciliations of the non-GAAP measurements to the
corresponding GAAP measurements can be found at the end of this press release.

[0001193125-14-395045:8k_2_02:50]
BUSINESS RISKS

[0001193125-14-395045:8k_2_02:51]
(9) the impact on the company’s performance and financial results from strategic acquisitions or
divestitures; (10) risks related to the company’s manufacturing and business operations in foreign countries; (11) the creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure
systems; (12) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (13) the
ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (14) variability in income received from licensing the company’s intellectual property to others, as
well as expenses incurred when the company licenses intellectual property from others; (15) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings;
(16) the impact of the percentage of cash and cash equivalents held outside of the United States; (17) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s
cash flow; (18) the ability of the company to repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the impact of changes in governmental policies,
laws or regulations; (20) negative consequences from the company’s outsourcing of various activities, including certain business operations, information technology and administrative functions; (21) the impact of the company’s
multi-year phased upgrade and consolidation of its enterprise resource planning systems into a single global platform; and (22) the company’s ability to return proceeds of the sale of the Enterprise business to shareholders and the timing
thereof. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-14-395045:8k_2_02:52]
DEFINITIONS

[0001193125-14-395045:8k_2_02:53]
| * | Amounts attributable to Motorola Solutions, Inc. common shareholders. |

[0001193125-14-395045:8k_2_02:54]
| ** | Non-GAAP financial information excludes from GAAP results the effects of share-based compensation expense, intangible assets amortization expense and highlighted items. |

[0001193125-14-395045:8k_2_02:55]
| *** | Business outlook excludes share-based compensation, intangible amortization and charges associated with items typically highlighted by the company in its quarterly earnings releases. |

[0001193125-14-395045:8k_2_02:56]
ABOUT MOTOROLA SOLUTIONS

[0001193125-14-395045:8k_2_02:57]
Motorola Solutions is a leading
provider of mission-critical communication solutions and services for public safety and commercial customers. Through leading-edge innovation and communications technology, it is a global leader that enables its customers to be their best in the
moments that matter. Motorola Solutions trades on the New York Stock Exchange under the ticker “MSI.” To learn more, visit www.motorolasolutions.com. For ongoing news, please visit our newsroom or subscribe to our news
feed.

[0001193125-14-395045:8k_2_02:58]
MEDIA CONTACT

[0001193125-14-395045:8k_2_02:59]
Kurt Ebenhoch

[0001193125-14-395045:8k_2_02:60]
Motorola Solutions

[0001193125-14-395045:8k_2_02:61]
+1 847-576-1341

[0001193125-14-395045:8k_2_02:62]
kurt.ebenhoch@motorolasolutions.com

[0001193125-14-395045:8k_2_02:63]
INVESTOR CONTACTS

[0001193125-14-395045:8k_2_02:64]
Shep Dunlap

[0001193125-14-395045:8k_2_02:65]
Motorola Solutions

[0001193125-14-395045:8k_2_02:66]
+1 847-576-6899

[0001193125-14-395045:8k_2_02:67]
shep.dunlap@motorolasolutions.com

[0001193125-14-395045:8k_2_02:68]
Chris Kutsor

[0001193125-14-395045:8k_2_02:69]
Motorola Solutions

[0001193125-14-395045:8k_2_02:70]
+1 847-576-4995

[0001193125-14-395045:8k_2_02:71]
chris.kutsor@motorolasolutions.com

[0001193125-14-395045:8k_2_02:72]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license.
All other trademarks are the property of their respective owners. ©2014 Motorola Solutions, Inc. All rights reserved.

[0001193125-14-395045:8k_2_02:73]
GAAP-1

[0001193125-14-395045:8k_2_02:74]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:75]
Condensed Consolidated Statements of Operations

[0001193125-14-395045:8k_2_02:76]
(In millions, except per share amounts)

[0001193125-14-395045:8k_2_02:77]
|  |  | Three Months Ended |  |
|  |  | September 27, 2014 |  |  | September 28, 2013 |  |
| Net sales from products |  | $ | 921 |  |  | $ | 998 |  |
| Net sales from services |  |  | 515 |  |  |  | 519 |  |
| Net sales |  |  | 1,436 |  |  |  | 1,517 |  |
| Costs of products sales |  |  | 414 |  |  |  | 423 |  |
| Costs of services sales |  |  | 337 |  |  |  | 329 |  |
| Costs of sales |  |  | 751 |  |  |  | 752 |  |
| Gross margin |  |  | 685 |  |  |  | 765 |  |
| Selling, general and administrative expenses |  |  | 287 |  |  |  | 320 |  |
| Research and development expenditures |  |  | 166 |  |  |  | 183 |  |
| Other charges |  |  | 24 |  |  |  | 16 |  |
| Intangibles amortization |  |  | 1 |  |  |  | — |  |
| Operating earnings |  |  | 207 |  |  |  | 246 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (31 | ) |  |  | (29 | ) |
| Gains on sales of investments and businesses, net |  |  | 1 |  |  |  | 26 |  |
| Other |  |  | (26 | ) |  |  | 8 |  |
| Total other income (expense) |  |  | (56 | ) |  |  | 5 |  |
| Earnings from continuing operations before income taxes |  |  | 151 |  |  |  | 251 |  |
| Income tax expense (benefit) |  |  | 84 |  |  |  | (11 | ) |
| Earnings from continuing operations |  |  | 67 |  |  |  | 262 |  |
| Earnings from discontinued operations, net of tax |  |  | 81 |  |  |  | 46 |  |
| Net earnings |  |  | 148 |  |  |  | 308 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 147 |  |  | $ | 307 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 66 |  |  | $ | 261 |  |
| Earnings from discontinued operations, net of tax |  |  | 81 |  |  |  | 46 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 147 |  |  | $ | 307 |  |
| Earnings per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.27 |  |  | $ | 1.00 |  |
| Discontinued operations |  |  | 0.33 |  |  |  | 0.17 |  |
|  |  | $ | 0.60 |  |  | $ | 1.17 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.27 |  |  | $ | 0.98 |  |
| Discontinued operations |  |  | 0.32 |  |  |  | 0.18 |  |
|  |  | $ | 0.59 |  |  | $ | 1.16 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 246.3 |  |  |  | 262.2 |  |
| Diluted |  |  | 248.2 |  |  |  | 265.3 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 64.1 | % |  |  | 65.8 | % |
| Net sales from services |  |  | 35.9 | % |  |  | 34.2 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 45.0 | % |  |  | 42.4 | % |
| Costs of services sales |  |  | 65.4 | % |  |  | 63.4 | % |
| Costs of sales |  |  | 52.3 | % |  |  | 49.6 | % |
| Gross margin |  |  | 47.7 | % |  |  | 50.4 | % |
| Selling, general and administrative expenses |  |  | 20.0 | % |  |  | 21.1 | % |
| Research and development expenditures |  |  | 11.6 | % |  |  | 12.1 | % |
| Other charges |  |  | 1.7 | % |  |  | 1.1 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.0 | % |
| Operating earnings |  |  | 14.4 | % |  |  | 16.2 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -2.2 | % |  |  | -1.9 | % |
| Gains on sales of investments and businesses, net |  |  | 0.1 | % |  |  | 1.7 | % |
| Other |  |  | -1.8 | % |  |  | 0.5 | % |
| Total other income (expense) |  |  | -3.9 | % |  |  | 0.3 | % |
| Earnings from continuing operations before income taxes |  |  | 10.5 | % |  |  | 16.5 | % |
| Income tax expense (benefit) |  |  | 5.8 | % |  |  | -0.7 | % |
| Earnings from continuing operations |  |  | 4.7 | % |  |  | 17.3 | % |
| Earnings from discontinued operations, net of tax |  |  | 5.6 | % |  |  | 3.0 | % |
| Net earnings |  |  | 10.3 | % |  |  | 20.3 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 10.2 | % |  |  | 20.2 | % |

[0001193125-14-395045:8k_2_02:78]
| * | Percentages may not add up due to rounding |

[0001193125-14-395045:8k_2_02:79]
GAAP-2

[0001193125-14-395045:8k_2_02:80]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:81]
Condensed Consolidated Statements of Operations

[0001193125-14-395045:8k_2_02:82]
(In millions, except per share amounts)

[0001193125-14-395045:8k_2_02:83]
|  |  | Nine Months Ended |  |
|  |  | September 27, 2014 |  |  | September 28, 2013 |  |
| Net sales from products |  | $ | 2,561 |  |  | $ | 2,897 |  |
| Net sales from services |  |  | 1,497 |  |  |  | 1,513 |  |
| Net sales |  |  | 4,058 |  |  |  | 4,410 |  |
| Costs of products sales |  |  | 1,165 |  |  |  | 1,262 |  |
| Costs of services sales |  |  | 974 |  |  |  | 940 |  |
| Costs of sales |  |  | 2,139 |  |  |  | 2,202 |  |
| Gross margin |  |  | 1,919 |  |  |  | 2,208 |  |
| Selling, general and administrative expenses |  |  | 902 |  |  |  | 984 |  |
| Research and development expenditures |  |  | 516 |  |  |  | 565 |  |
| Other charges |  |  | 46 |  |  |  | 36 |  |
| Intangibles amortization |  |  | 3 |  |  |  | 1 |  |
| Operating earnings |  |  | 452 |  |  |  | 622 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (85 | ) |  |  | (85 | ) |
| Gains on sales of investments and businesses, net |  |  | 4 |  |  |  | 34 |  |
| Other |  |  | (34 | ) |  |  | 3 |  |
| Total other expense |  |  | (115 | ) |  |  | (48 | ) |
| Earnings from continuing operations before income taxes |  |  | 337 |  |  |  | 574 |  |
| Income tax expense (benefit) |  |  | 107 |  |  |  | (72 | ) |
| Earnings from continuing operations |  |  | 230 |  |  |  | 646 |  |
| Earnings from discontinued operations, net of tax |  |  | 869 |  |  |  | 116 |  |
| Net earnings |  |  | 1,099 |  |  |  | 762 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 5 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 1,098 |  |  | $ | 757 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 229 |  |  | $ | 641 |  |
| Earnings from discontinued operations, net of tax |  |  | 869 |  |  |  | 116 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 1,098 |  |  | $ | 757 |  |
| Earnings per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.91 |  |  | $ | 2.39 |  |
| Discontinued operations |  |  | 3.46 |  |  |  | 0.43 |  |
|  |  | $ | 4.37 |  |  | $ | 2.82 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.90 |  |  | $ | 2.34 |  |
| Discontinued operations |  |  | 3.42 |  |  |  | 0.43 |  |
|  |  | $ | 4.32 |  |  | $ | 2.77 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 251.1 |  |  |  | 268.7 |  |
| Diluted |  |  | 254.0 |  |  |  | 273.5 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 63.1 | % |  |  | 65.7 | % |
| Net sales from services |  |  | 36.9 | % |  |  | 34.3 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 45.5 | % |  |  | 43.6 | % |
| Costs of services sales |  |  | 65.1 | % |  |  | 62.1 | % |
| Costs of sales |  |  | 52.7 | % |  |  | 49.9 | % |
| Gross margin |  |  | 47.3 | % |  |  | 50.1 | % |
| Selling, general and administrative expenses |  |  | 22.2 | % |  |  | 22.3 | % |
| Research and development expenditures |  |  | 12.7 | % |  |  | 12.8 | % |
| Other charges |  |  | 1.1 | % |  |  | 0.8 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.0 | % |
| Operating earnings |  |  | 11.1 | % |  |  | 14.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -2.1 | % |  |  | -1.9 | % |
| Gains on sales of investments and businesses, net |  |  | 0.1 | % |  |  | 0.8 | % |
| Other |  |  | -0.8 | % |  |  | 0.1 | % |
| Total other expense |  |  | -2.8 | % |  |  | -1.1 | % |
| Earnings from continuing operations before income taxes |  |  | 8.3 | % |  |  | 13.0 | % |
| Income tax expense (benefit) |  |  | 2.6 | % |  |  | -1.6 | % |
| Earnings from continuing operations |  |  | 5.7 | % |  |  | 14.6 | % |
| Earnings from discontinued operations, net of tax |  |  | 21.4 | % |  |  | 2.6 | % |
| Net earnings |  |  | 27.1 | % |  |  | 17.3 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.0 | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 27.1 | % |  |  | 17.2 | % |

[0001193125-14-395045:8k_2_02:84]
| * | Percentages may not add up due to rounding |

[0001193125-14-395045:8k_2_02:85]
GAAP-3

[0001193125-14-395045:8k_2_02:86]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:87]
Condensed Consolidated Balance Sheets

[0001193125-14-395045:8k_2_02:88]
(In millions)

[0001193125-14-395045:8k_2_02:89]
|  |  | September 27, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,845 |  |  | $ | 3,225 |  |
| Accounts receivable, net |  |  | 1,162 |  |  |  | 1,369 |  |
| Inventories, net |  |  | 331 |  |  |  | 347 |  |
| Deferred income taxes |  |  | 1,192 |  |  |  | 451 |  |
| Other current assets |  |  | 604 |  |  |  | 635 |  |
| Current assets held for sale |  |  | 1,034 |  |  |  | 993 |  |
| Total current assets |  |  | 7,168 |  |  |  | 7,020 |  |
| Property, plant and equipment, net |  |  | 664 |  |  |  | 695 |  |
| Investments |  |  | 240 |  |  |  | 232 |  |
| Deferred income taxes |  |  | 2,141 |  |  |  | 1,990 |  |
| Goodwill |  |  | 383 |  |  |  | 361 |  |
| Other assets |  |  | 138 |  |  |  | 89 |  |
| Noncurrent assets held for sale |  |  | 1,461 |  |  |  | 1,464 |  |
| Total assets |  | $ | 12,195 |  |  | $ | 11,851 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 501 |  |  |  | 583 |  |
| Accrued liabilities |  |  | 1,673 |  |  |  | 1,763 |  |
| Current liabilities held for sale |  |  | 846 |  |  |  | 870 |  |
| Total current liabilities |  |  | 3,024 |  |  |  | 3,220 |  |
| Long-term debt |  |  | 3,401 |  |  |  | 2,457 |  |
| Other liabilities |  |  | 2,364 |  |  |  | 2,314 |  |
| Noncurrent liabilities held for sale |  |  | 164 |  |  |  | 171 |  |
| Total Motorola Solutions, Inc. stockholders’ equity |  |  | 3,211 |  |  |  | 3,659 |  |
| Noncontrolling interests |  |  | 31 |  |  |  | 30 |  |
| Total liabilities and stockholders’ equity |  | $ | 12,195 |  |  | $ | 11,851 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash* |  | $ | (560 | ) |  | $ | 764 |  |

[0001193125-14-395045:8k_2_02:90]
| * | Net cash = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-14-395045:8k_2_02:91]
GAAP-4

[0001193125-14-395045:8k_2_02:92]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:93]
Condensed Consolidated Statements of Cash Flows

[0001193125-14-395045:8k_2_02:94]
(In millions)

[0001193125-14-395045:8k_2_02:95]
|  |  | Three Months Ended |  |
|  |  | September 27, 2014 |  |  | September 28, 2013 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 147 |  |  | $ | 307 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings |  |  | 148 |  |  |  | 308 |  |
| Earnings from discontinued operations, net of tax |  |  | 81 |  |  |  | 46 |  |
| Earnings from continuing operations, net of tax |  |  | 67 |  |  |  | 262 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 45 |  |  |  | 40 |  |
| Loss on extinguishment of debt |  |  | 37 |  |  |  | — |  |
| Non-cash other charges (income) |  |  | 2 |  |  |  | (4 | ) |
| Share-based compensation expense |  |  | 20 |  |  |  | 29 |  |
| Gains on sales of investments and businesses, net |  |  | (1 | ) |  |  | (28 | ) |
| Deferred income taxes |  |  | 63 |  |  |  | (115 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 12 |  |  |  | (59 | ) |
| Inventories |  |  | (5 | ) |  |  | (23 | ) |
| Other current assets |  |  | (85 | ) |  |  | 35 |  |
| Accounts payable and accrued liabilities |  |  | 128 |  |  |  | (22 | ) |
| Other assets and liabilities |  |  | (398 | ) |  |  | (39 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | (115 | ) |  |  | 76 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (11 | ) |  |  | (12 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 2 |  |  |  | 27 |  |
| Capital expenditures |  |  | (47 | ) |  |  | (31 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 6 |  |  |  | — |  |
| Proceeds from sales of Sigma Fund and short-term investments, net |  |  | — |  |  |  | 590 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (50 | ) |  |  | 574 |  |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (458 | ) |  |  | (1 | ) |
| Net proceeds from issuance of debt |  |  | 1,370 |  |  |  | — |  |
| Issuance of common stock |  |  | 9 |  |  |  | 9 |  |
| Repurchase of common stock |  |  | (650 | ) |  |  | (425 | ) |
| Excess tax benefit from share-based compensation |  |  | 5 |  |  |  | 2 |  |
| Payments of dividends |  |  | (78 | ) |  |  | (69 | ) |
| Distributions from (to) discontinued operations |  |  | (32 | ) |  |  | 76 |  |
| Net cash provided by (used for) financing activities from continuing operations |  |  | 166 |  |  |  | (408 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by (used for) operating activities from discontinued operations |  |  | (25 | ) |  |  | 76 |  |
| Net cash provided by (used for) investing activities from discontinued operations |  |  | (5 | ) |  |  | 1 |  |
| Net cash provided by (used for) financing activities from discontinued operations |  |  | 32 |  |  |  | (76 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | (2 | ) |  |  | (1 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (32 | ) |  |  | 22 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (31 | ) |  |  | 264 |  |
| Cash and cash equivalents, beginning of period |  |  | 2,876 |  |  |  | 1,457 |  |
| Cash and cash equivalents, end of period |  | $ | 2,845 |  |  | $ | 1,721 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | (162 | ) |  | $ | 45 |  |

[0001193125-14-395045:8k_2_02:96]
| * | Free cash flow = Net cash provided by operating activities - Capital expenditures |

[0001193125-14-395045:8k_2_02:97]
GAAP-5

[0001193125-14-395045:8k_2_02:98]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:99]
Condensed Consolidated Statements of Cash Flows

[0001193125-14-395045:8k_2_02:100]
(In millions)

[0001193125-14-395045:8k_2_02:101]
|  |  | Nine Months Ended |  |
|  |  | September 27, 2014 |  |  | September 28, 2013 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 1,098 |  |  | $ | 757 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 5 |  |
| Net earnings |  |  | 1,099 |  |  |  | 762 |  |
| Earnings from discontinued operations, net of tax |  |  | 869 |  |  |  | 116 |  |
| Earnings from continuing operations, net of tax |  |  | 230 |  |  |  | 646 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 131 |  |  |  | 116 |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | — |  |
| Loss on extinguishment of debt |  |  | 37 |  |  |  | — |  |
| Non-cash other income |  |  | (2 | ) |  |  | (11 | ) |
| Share-based compensation expense |  |  | 74 |  |  |  | 91 |  |
| Gains on sales of investments and businesses, net |  |  | (4 | ) |  |  | (34 | ) |
| Deferred income taxes |  |  | 69 |  |  |  | (309 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 202 |  |  |  | 19 |  |
| Inventories |  |  | 12 |  |  |  | (9 | ) |
| Other current assets |  |  | (9 | ) |  |  | 11 |  |
| Accounts payable and accrued liabilities |  |  | (170 | ) |  |  | (501 | ) |
| Other assets and liabilities |  |  | (534 | ) |  |  | (44 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 15 |  |  |  | (25 | ) |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (21 | ) |  |  | (20 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 23 |  |  |  | 48 |  |
| Capital expenditures |  |  | (130 | ) |  |  | (110 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 30 |  |  |  | 15 |  |
| Proceeds from sales of Sigma Fund and short-term investments, net |  |  | — |  |  |  | 966 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (98 | ) |  |  | 899 |  |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (461 | ) |  |  | (3 | ) |
| Net proceeds from issuance of debt |  |  | 1,375 |  |  |  | 593 |  |
| Issuance of common stock |  |  | 94 |  |  |  | 108 |  |
| Repurchase of common stock |  |  | (1,123 | ) |  |  | (1,332 | ) |
| Excess tax benefit from share-based compensation |  |  | 11 |  |  |  | 20 |  |
| Payments of dividends |  |  | (236 | ) |  |  | (212 | ) |
| Distributions from discontinued operations |  |  | 66 |  |  |  | 214 |  |
| Net cash used for financing activities from continuing operations |  |  | (274 | ) |  |  | (612 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | 63 |  |  |  | 228 |  |
| Net cash provided by (used for) investing activities from discontinued operations |  |  | 5 |  |  |  | (16 | ) |
| Net cash used for financing activities from discontinued operations |  |  | (66 | ) |  |  | (214 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | (2 | ) |  |  | 2 |  |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (23 | ) |  |  | (9 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (380 | ) |  |  | 253 |  |
| Cash and cash equivalents, beginning of period |  |  | 3,225 |  |  |  | 1,468 |  |
| Cash and cash equivalents, end of period |  | $ | 2,845 |  |  | $ | 1,721 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | (115 | ) |  | $ | (135 | ) |

[0001193125-14-395045:8k_2_02:102]
| * | Free cash flow = Net cash provided by operating activities - Capital expenditures |

[0001193125-14-395045:8k_2_02:103]
GAAP-6

[0001193125-14-395045:8k_2_02:104]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:105]
Segment Information

[0001193125-14-395045:8k_2_02:106]
(In
millions)

[0001193125-14-395045:8k_2_02:107]
Net Sales

[0001193125-14-395045:8k_2_02:108]
|  |  | Three Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 921 |  |  | $ | 998 |  |  |  | -8 | % |
| Services |  |  | 515 |  |  |  | 519 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 1,436 |  |  | $ | 1,517 |  |  |  | -5 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 2,561 |  |  | $ | 2,897 |  |  |  | -12 | % |
| Services |  |  | 1,497 |  |  |  | 1,513 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 4,058 |  |  | $ | 4,410 |  |  |  | -8 | % |
| Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 141 |  |  | $ | 171 |  |  |  | -18 | % |
| Services |  |  | 66 |  |  |  | 75 |  |  |  | -12 | % |
| Total Motorola Solutions |  | $ | 207 |  |  | $ | 246 |  |  |  | -16 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 276 |  |  | $ | 402 |  |  |  | -31 | % |
| Services |  |  | 176 |  |  |  | 220 |  |  |  | -20 | % |
| Total Motorola Solutions |  | $ | 452 |  |  | $ | 622 |  |  |  | -27 | % |

[0001193125-14-395045:8k_2_02:109]
Operating Earnings %

[0001193125-14-395045:8k_2_02:110]
|  |  | Three Months Ended |  |
|  |  | September 27, |  |  | September 28, |  |
|  |  | 2014 |  |  | 2013 |  |
| Products |  |  | 15.3 | % |  |  | 17.1 | % |
| Services |  |  | 12.8 | % |  |  | 14.5 | % |
| Total Motorola Solutions |  |  | 14.4 | % |  |  | 16.2 | % |
|  |  | Nine Months Ended |  |
|  |  | September 27, |  |  | September 28, |  |
|  |  | 2014 |  |  | 2013 |  |
| Products |  |  | 10.8 | % |  |  | 13.9 | % |
| Services |  |  | 11.8 | % |  |  | 14.5 | % |
| Total Motorola Solutions |  |  | 11.1 | % |  |  | 14.1 | % |

[0001193125-14-395045:8k_2_02:111]
Non-GAAP-1

[0001193125-14-395045:8k_2_02:112]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:113]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-14-395045:8k_2_02:114]
Q1 2014

[0001193125-14-395045:8k_2_02:115]
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 29 |  |  |  | 9 |  |  |  | 20 |  |  |  | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 10 |  |  |  | 2 |  |  |  | 8 |  |  |  | 0.03 |  |
| Gain on sale of building and land |  | Other charges |  |  | (21 | ) |  |  | (8 | ) |  |  | (13 | ) |  |  | (0.05 | ) |
| Recognition of previously unrecognized income tax benefits |  | Income tax expense |  |  | — |  |  |  | 29 |  |  |  | (29 | ) |  |  | (0.11 | ) |
| Total impact on Net earnings |  |  |  | $ | 19 |  |  | $ | 32 |  |  | $ | (13 | ) |  | $ | (0.05 | ) |
| Q2 2014 |  |
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 26 |  |  |  | 9 |  |  |  | 17 |  |  |  | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 28 |  |  |  | 8 |  |  |  | 20 |  |  |  | 0.08 |  |
| Legal settlement |  | Other charges |  |  | 8 |  |  |  | 3 |  |  |  | 5 |  |  |  | 0.02 |  |
| Total impact on Net earnings |  |  |  | $ | 63 |  |  | $ | 20 |  |  | $ | 43 |  |  | $ | 0.17 |  |
| Q3 2014 |  |
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 20 |  |  |  | 6 |  |  |  | 14 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 20 |  |  |  | 6 |  |  |  | 14 |  |  |  | 0.06 |  |
| Pension-related transaction fees |  | Other charges |  |  | 11 |  |  |  | 4 |  |  |  | 7 |  |  |  | 0.03 |  |
| Loss from the extinguishment of long-term debt |  | Other expense (income) |  |  | 37 |  |  |  | 14 |  |  |  | 23 |  |  |  | 0.09 |  |
| Gain on investment |  | Other expense (income) |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |  |  | (0.04 | ) |
| Tax expense to establish foreign valuation allowance |  | Income tax expense |  |  | — |  |  |  | (55 | ) |  |  | 55 |  |  |  | 0.22 |  |
| Revaluation of deferred taxes for change in effective state tax rates |  | Income tax expense |  |  | — |  |  |  | 16 |  |  |  | (16 | ) |  |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 79 |  |  | $ | (9 | ) |  | $ | 88 |  |  | $ | 0.35 |  |

[0001193125-14-395045:8k_2_02:116]
Non-GAAP-2

[0001193125-14-395045:8k_2_02:117]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:118]
Non-GAAP Segment Information

[0001193125-14-395045:8k_2_02:119]
(In millions)

[0001193125-14-395045:8k_2_02:120]
Net Sales

[0001193125-14-395045:8k_2_02:121]
|  |  | Three Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 921 |  |  | $ | 998 |  |  |  | -8 | % |
| Services |  |  | 515 |  |  |  | 519 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 1,436 |  |  | $ | 1,517 |  |  |  | -5 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 2,561 |  |  | $ | 2,897 |  |  |  | -12 | % |
| Services |  |  | 1,497 |  |  |  | 1,513 |  |  |  | -1 | % |
| Total Motorola Solutions |  | $ | 4,058 |  |  | $ | 4,410 |  |  |  | -8 | % |
| Non-GAAP Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 175 |  |  | $ | 204 |  |  |  | -14 | % |
| Services |  |  | 84 |  |  |  | 92 |  |  |  | -9 | % |
| Total Motorola Solutions |  | $ | 259 |  |  | $ | 296 |  |  |  | -13 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | September 27, |  |  | September 28, |  |  |  |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Products |  | $ | 359 |  |  | $ | 492 |  |  |  | -27 | % |
| Services |  |  | 226 |  |  |  | 268 |  |  |  | -16 | % |
| Total Motorola Solutions |  | $ | 585 |  |  | $ | 760 |  |  |  | -23 | % |

[0001193125-14-395045:8k_2_02:122]
Non-GAAP Operating Earnings %

[0001193125-14-395045:8k_2_02:123]
|  |  | Three Months Ended |  |
|  |  | September 27, |  |  | September 28, |  |
|  |  | 2014 |  |  | 2013 |  |
| Products |  |  | 19.0 | % |  |  | 20.4 | % |
| Services |  |  | 16.3 | % |  |  | 17.7 | % |
| Total Motorola Solutions |  |  | 18.0 | % |  |  | 19.5 | % |
|  |  | Nine Months Ended |  |
|  |  | September 27, |  |  | September 28, |  |
|  |  | 2014 |  |  | 2013 |  |
| Products |  |  | 14.0 | % |  |  | 17.0 | % |
| Services |  |  | 15.1 | % |  |  | 17.7 | % |
| Total Motorola Solutions |  |  | 14.4 | % |  |  | 17.2 | % |

[0001193125-14-395045:8k_2_02:124]
Non-GAAP-3

[0001193125-14-395045:8k_2_02:125]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-14-395045:8k_2_02:126]
Operating Earnings after Non-GAAP Adjustments

[0001193125-14-395045:8k_2_02:127]
Q1 2014

[0001193125-14-395045:8k_2_02:128]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,228 |  |  | $ | 753 |  |  | $ | 475 |  |
| Operating earnings (“OE”) |  | $ | 107 |  |  | $ | 39 |  |  | $ | 68 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 29 |  |  |  | 19 |  |  |  | 10 |  |
| Reorganization of business charges |  |  | 10 |  |  |  | 6 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | (14 | ) |  |  | (7 | ) |
| Total above-OE non-GAAP adjustments |  |  | 19 |  |  |  | 12 |  |  |  | 7 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 126 |  |  | $ | 51 |  |  | $ | 75 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 8.7 | % |  |  | 5.2 | % |  |  | 14.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 10.3 | % |  |  | 6.8 | % |  |  | 15.8 | % |
| Q2 2014 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,393 |  |  | $ | 887 |  |  | $ | 506 |  |
| Operating earnings (“OE”) |  | $ | 138 |  |  | $ | 95 |  |  | $ | 43 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 26 |  |  |  | 14 |  |  |  | 12 |  |
| Reorganization of business charges |  |  | 28 |  |  |  | 18 |  |  |  | 10 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Legal settlement |  |  | 8 |  |  |  | 5 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 63 |  |  |  | 38 |  |  |  | 25 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 201 |  |  | $ | 133 |  |  | $ | 68 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 9.9 | % |  |  | 10.7 | % |  |  | 8.5 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 14.4 | % |  |  | 15.0 | % |  |  | 13.4 | % |
| Q3 2014 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,436 |  |  | $ | 921 |  |  | $ | 515 |  |
| Operating earnings (“OE”) |  | $ | 207 |  |  | $ | 141 |  |  | $ | 66 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 20 |  |  |  | 11 |  |  |  | 9 |  |
| Reorganization of business charges |  |  | 20 |  |  |  | 14 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Pension-related transaction fees |  |  | 11 |  |  |  | 8 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 52 |  |  |  | 34 |  |  |  | 18 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 259 |  |  | $ | 175 |  |  | $ | 84 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 14.4 | % |  |  | 15.3 | % |  |  | 12.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 18.8 | % |  |  | 19.4 | % |  |  | 17.7 | % |
