# MSI MD&A — 0000068505-14-000016


## mdna

[0000068505-14-000016:mdna:1]
[same as prior period, unchanged from 0000068505-14-000010:mdna:1]

[0000068505-14-000016:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 27, 2014 and September 28, 2013, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2013 and Form 8-K filed on August 7, 2014.

[0000068505-14-000016:mdna:3]
[same as prior period, unchanged from 0000068505-14-000010:mdna:3]

[0000068505-14-000016:mdna:4]
[same as prior period, unchanged from 0000068505-14-000010:mdna:4]

[0000068505-14-000016:mdna:5]
On October 27, 2014, we closed on the sale of the Enterprise business with Zebra Technologies Corporation for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by us, including our iDEN business, and other assets and certain liabilities as specified in the Master Acquisition Agreement. As a result of the sale, we have reported the Enterprise business as a discontinued operation in our condensed consolidated financial statements and footnotes for all periods presented.

[0000068505-14-000016:mdna:6]
[same as prior period, unchanged from 0000068505-14-000010:mdna:6]

[0000068505-14-000016:mdna:7]
[same as prior period, unchanged from 0000068505-14-000010:mdna:7]

[0000068505-14-000016:mdna:8]
We report financial results for the following two segments:

[0000068505-14-000016:mdna:9]
Products: The Products segment offers an extensive portfolio of network infrastructure, devices, system software and applications for the public safety, hospitality, education, manufacturing, transportation, utilities, mining and retail industries, including our: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) integrated digital enhanced network (“iDEN”) products, and (v) broadband technology products, such as Long-Term Evolution (“LTE”). In addition, the Products segment offers smart public safety solutions including computer-aided dispatch, records systems, data management systems and Real Time Crime Center solutions. In the third quarter of 2014, the segment’s net sales were $921 million, representing 64% of our consolidated net sales.

[0000068505-14-000016:mdna:10]
Services: The Services segment has a full breadth of service offerings for both public safety and private communication networks including: (i) Integration services, (ii) Lifecycle Management and Support services, (iii) Managed services, and (iv) Smart Public Safety Solutions. Integration services includes implementation, optimization, and integration of networks, devices, and applications.  Lifecycle Management and Support services includes lifecycle planning, upgrades, call center, network monitoring, and repair services.  Managed services includes managing customer networks at defined services levels. Smart Public Safety Solutions includes integration of hardware and software to meet customer needs. In the third quarter of 2014, the segment’s net sales were $515 million, representing 36% of our consolidated net sales.

[0000068505-14-000016:mdna:11]
Third Quarter Summary

[0000068505-14-000016:mdna:12]
| • | Net sales decreased by $81 million, or 5%, to $1.4 billion in the third quarter of 2014, compared to net sales of $1.5 billion in the third quarter of 2013. |

[0000068505-14-000016:mdna:13]
| • | We generated operating earnings of $207 million, or 14% of net sales, in the third quarter of 2014, compared to $246 million, or 16% of net sales, in the third quarter of 2013. |

[0000068505-14-000016:mdna:14]
| • | We had earnings from continuing operations* of $66 million, or $0.27 per diluted common share, in the third quarter of 2014, compared to earnings from continuing operations* of $261 million, or $0.98 per diluted common share, in the third quarter of 2013. |

[0000068505-14-000016:mdna:15]
| • | We generated net cash from operating activities of $15 million during the first nine months of 2014, compared to $25 million of net cash used for operating activities in the first nine months of 2013. |

[0000068505-14-000016:mdna:16]
| • | We returned $728 million and $1.4 billion in capital to shareholders through share repurchases and dividends during the third quarter and first nine months of 2014, respectively. |

[0000068505-14-000016:mdna:17]
[same as prior period, unchanged from 0000068505-14-000010:mdna:21]

[0000068505-14-000016:mdna:18]
[same as prior period, unchanged from 0000068505-14-000010:mdna:17]

[0000068505-14-000016:mdna:19]
| • | Products: Net sales were $921 million in the third quarter of 2014, a decrease of $77 million, or 8%, compared to net sales of $998 million during the third quarter of 2013. On a geographic basis, net sales declined in North America, Latin America, and Asia Pacific and Middle East ("APME") and increased in Europe and Africa ("EA"), compared to the year-ago quarter. |

[0000068505-14-000016:mdna:20]
| • | Services: Net sales were $515 million in the third quarter of 2014, a decrease of $4 million, or 1%, compared to net sales of $519 million in the third quarter of 2013. On a geographic basis, net sales declined in North America and increased in Latin America, EA, and APME, compared to the year-ago quarter. |

[0000068505-14-000016:mdna:21]
[same as prior period, unchanged from 0000068505-14-000010:mdna:26]

[0000068505-14-000016:mdna:22]
[same as prior period, unchanged from 0000068505-14-000010:mdna:22]

[0000068505-14-000016:mdna:23]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 27, 2014 |  | % ofSales** |  | September 28, 2013 |  | % ofSales** |  | September 27, 2014 |  | % ofSales** |  | September 28, 2013 |  | % ofSales** |
| Net sales from products | $ | 921 |  |  |  |  | $ | 998 |  |  |  |  | $ | 2,561 |  |  |  |  | $ | 2,897 |  |  |  |
| Net sales from services | 515 |  |  |  |  | 519 |  |  |  |  | 1,497 |  |  |  |  | 1,513 |  |  |  |
| Net sales | 1,436 |  |  |  |  | 1,517 |  |  |  |  | 4,058 |  |  |  |  | 4,410 |  |  |  |
| Costs of product sales | 414 |  |  | 45.0 | % |  | 423 |  |  | 42.4 | % |  | 1,165 |  |  | 45.5 | % |  | 1,262 |  |  | 43.6 | % |
| Costs of services sales | 337 |  |  | 65.4 | % |  | 329 |  |  | 63.4 | % |  | 974 |  |  | 65.1 | % |  | 940 |  |  | 62.1 | % |
| Costs of sales | 751 |  |  |  |  | 752 |  |  |  |  | 2,139 |  |  |  |  | 2,202 |  |  |  |
| Gross margin | 685 |  |  | 47.7 | % |  | 765 |  |  | 50.4 | % |  | 1,919 |  |  | 47.3 | % |  | 2,208 |  |  | 50.1 | % |
| Selling, general and administrative expenses | 287 |  |  | 20.0 | % |  | 320 |  |  | 21.1 | % |  | 902 |  |  | 22.2 | % |  | 984 |  |  | 22.3 | % |
| Research and development expenditures | 166 |  |  | 11.6 | % |  | 183 |  |  | 12.1 | % |  | 516 |  |  | 12.7 | % |  | 565 |  |  | 12.8 | % |
| Other charges | 25 |  |  | 1.7 | % |  | 16 |  |  | 1.1 | % |  | 49 |  |  | 1.2 | % |  | 37 |  |  | 0.8 | % |
| Operating earnings | 207 |  |  | 14.4 | % |  | 246 |  |  | 16.2 | % |  | 452 |  |  | 11.1 | % |  | 622 |  |  | 14.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (31 | ) |  | (2.2 | )% |  | (29 | ) |  | (1.9 | )% |  | (85 | ) |  | (2.1 | )% |  | (85 | ) |  | (1.9 | )% |
| Gains on sales of investments and businesses, net | 1 |  |  | 0.1 | % |  | 26 |  |  | 1.7 | % |  | 4 |  |  | 0.1 | % |  | 34 |  |  | 0.8 | % |
| Other | (26 | ) |  | (1.8 | )% |  | 8 |  |  | 0.5 | % |  | (34 | ) |  | (0.8 | )% |  | 3 |  |  | 0.1 | % |
| Total other income (expense) | (56 | ) |  | (3.9 | )% |  | 5 |  |  | 0.3 | % |  | (115 | ) |  | (2.8 | )% |  | (48 | ) |  | (1.1 | )% |
| Earnings from continuing operations before income taxes | 151 |  |  | 10.5 | % |  | 251 |  |  | 16.5 | % |  | 337 |  |  | 8.3 | % |  | 574 |  |  | 13.0 | % |
| Income tax expense (benefit) | 84 |  |  | 5.8 | % |  | (11 | ) |  | (0.7 | )% |  | 107 |  |  | 2.6 | % |  | (72 | ) |  | (1.6 | )% |
| Earnings from continuing operations | 67 |  |  | 4.7 | % |  | 262 |  |  | 17.3 | % |  | 230 |  |  | 5.7 | % |  | 646 |  |  | 14.6 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 1 |  |  | — | % |  | 5 |  |  | 0.1 | % |
| Earnings from continuing operations* | 66 |  |  | 4.6 | % |  | 261 |  |  | 17.2 | % |  | 229 |  |  | 5.6 | % |  | 641 |  |  | 14.5 | % |
| Earnings from discontinued operations, net of tax | 81 |  |  | 5.6 | % |  | 46 |  |  | 3.0 | % |  | 869 |  |  | 21.4 | % |  | 116 |  |  | 2.6 | % |
| Net earnings* | $ | 147 |  |  | 10.2 | % |  | $ | 307 |  |  | 20.2 | % |  | $ | 1,098 |  |  | 27.1 | % |  | $ | 757 |  |  | 17.2 | % |
| Earnings per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.27 |  |  |  |  | $ | 0.98 |  |  |  |  | $ | 0.90 |  |  |  |  | $ | 2.34 |  |  |  |
| Discontinued operations | 0.32 |  |  |  |  | 0.18 |  |  |  |  | 3.42 |  |  |  |  | 0.43 |  |  |  |
| Earnings per diluted common share* | $ | 0.59 |  |  |  |  |  | $ | 1.16 |  |  |  |  |  | $ | 4.32 |  |  |  |  | $ | 2.77 |  |  |  |

[0000068505-14-000016:mdna:24]
[same as prior period, unchanged from 0000068505-14-000010:mdna:24]

[0000068505-14-000016:mdna:25]
[same as prior period, unchanged from 0000068505-14-000010:mdna:25]

[0000068505-14-000016:mdna:26]
[same as prior period, unchanged from 0000068505-14-000010:mdna:46]

[0000068505-14-000016:mdna:27]
Results of Operations—Three months ended September 27, 2014 compared to three months ended September 28, 2013

[0000068505-14-000016:mdna:28]
[same as prior period, unchanged from 0000068505-14-000010:mdna:28]

[0000068505-14-000016:mdna:29]
Net sales were $1.4 billion in the third quarter of 2014, down $81 million, or 5%, compared to net sales of $1.5 billion in the third quarter of 2013. The decrease in net sales reflects a $77 million, or 8%, decrease in net sales in the Products segment, driven by declines in: (i) APME, reflecting lower devices and systems sales, (ii) North America, as a result of lower devices sales, and (iii) Latin America, reflecting lower devices and systems sales, partially offset by double-digit growth in systems sales and single-digit growth in devices sales within EA.  In addition, the decrease in net sales includes a $4 million, or 1%, decrease in net sales in the Services segment, driven by declines in North America as a result of iDEN services declines, partially offset by double-digit Services growth in EA in Integration and Managed services.

[0000068505-14-000016:mdna:30]
[same as prior period, unchanged from 0000068505-14-000010:mdna:30]

[0000068505-14-000016:mdna:31]
Gross margin was $685 million, or 47.7% of net sales, in the third quarter of 2014, compared to $765 million, or 50.4% of net sales, in the third quarter of 2013. The decrease in gross margin percentage is attributable to sales declines, driven primarily by: (i) a decline in gross margin as a percentage of sales in North America, as a result of a product mix change within the Products segment among devices and a shift from devices to systems, which include more third party equipment, (ii) overall sales mix between the Products and Services segments, and (iii) lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-14-000016:mdna:32]
[same as prior period, unchanged from 0000068505-14-000010:mdna:32]

[0000068505-14-000016:mdna:33]
Selling, general and administrative (“SG&A”) expenses decreased 10% to $287 million, or 20.0% of net sales, in the third quarter of 2014, compared to $320 million, or 21.1% of net sales, in the third quarter of 2013. The decrease in SG&A expenditures is primarily due to: (i) the reduction of sales support costs by lowering our overall non-quota carrying employee base and (ii) reduced costs created by increasing the use of centralized services.

[0000068505-14-000016:mdna:34]
[same as prior period, unchanged from 0000068505-14-000010:mdna:34]

[0000068505-14-000016:mdna:35]
Research and development (“R&D”) expenditures decreased 9% to $166 million, or 11.6% of net sales, in the third quarter of 2014, from $183 million, or 12.1% of net sales, in the third quarter of 2013. The decrease in R&D expenditures is primarily due to: (i) headcount reductions enacted during previous periods, (ii) the consolidation of testing processes and lab sites and (iii) the movement of employees to lower cost work sites.

[0000068505-14-000016:mdna:36]
[same as prior period, unchanged from 0000068505-14-000010:mdna:36]

[0000068505-14-000016:mdna:37]
We recorded net charges of $25 million in Other charges in the third quarter of 2014, compared to net charges of $16 million in the third quarter of 2013. The net charges in the third quarter of 2014 primarily included: (i) $13 million of net reorganization of business charges and (ii) $11 million for pension-related transaction fees. The net charges in the third quarter of 2013 of $16 million were all related to net reorganization of business charges. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-14-000016:mdna:38]
[same as prior period, unchanged from 0000068505-14-000010:mdna:38]

[0000068505-14-000016:mdna:39]
Net interest expense was $31 million in the third quarter of 2014, compared to net interest expense of $29 million in the third quarter of 2013. Net interest expense in the third quarter of 2014 included interest expense of $38 million, partially offset by interest income of $7 million. Net interest expense in the third quarter of 2013 included interest expense of $33 million, partially offset by interest income of $4 million. The increase in net interest expense in the third quarter of 2014 is primarily attributable to higher debt levels, compared to the third quarter of 2013.

[0000068505-14-000016:mdna:40]
[same as prior period, unchanged from 0000068505-14-000010:mdna:69]

[0000068505-14-000016:mdna:41]
Net gains on sales of investments and businesses were $1 million in the third quarter of 2014 and $26 million in the third quarter of 2013. The net gains in the third quarter of 2014 and 2013 consisted of gains on the sales of equity investments.

[0000068505-14-000016:mdna:42]
[same as prior period, unchanged from 0000068505-14-000010:mdna:42]

[0000068505-14-000016:mdna:43]
Net Other expense was $26 million in the third quarter of 2014, compared to net Other income of $8 million in the third quarter of 2013. The net Other expense in the third quarter of 2014 was primarily comprised of a $37 million loss from the extinguishment of debt, partially offset by $11 million of gains on equity method investments. The net Other income in the third quarter of 2013 was primarily comprised of $8 million of gains on equity method investments.

[0000068505-14-000016:mdna:44]
[same as prior period, unchanged from 0000068505-14-000010:mdna:44]

[0000068505-14-000016:mdna:45]
We recorded $84 million of net tax expense in the third quarter of 2014, resulting in an effective tax rate of 56%, compared to $11 million of net tax benefit in the third quarter of 2013, resulting in a negative effective tax rate. Our effective tax rate in the third quarter of 2014 was unfavorably impacted by $55 million of tax expense related to the recording of a valuation allowance on certain foreign deferred tax assets.  Our effective tax rate in the third quarter of 2013 was favorably

[0000068505-14-000016:mdna:46]
impacted by $96 million of net tax benefits associated with the recognition of excess foreign tax credits on undistributed foreign earnings.

[0000068505-14-000016:mdna:47]
[same as prior period, unchanged from 0000068505-14-000010:mdna:48]

[0000068505-14-000016:mdna:48]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $66 million, or $0.27 per diluted share, in the third quarter of 2014, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $261 million, or $0.98 per diluted share, in the third quarter of 2013.

[0000068505-14-000016:mdna:49]
The decrease in earnings from continuing operations in the third quarter of 2014, as compared to the third quarter of 2013, was primarily driven by: (i) a higher effective tax rate and (ii) an $80 million decrease in gross margin primarily due to sales declines and a change in sales mix, partially offset by a $33 million reduction in selling, general and administrative expenses.  The decrease in earnings from continuing operations per diluted share was driven by lower earnings from continuing operations, partially offset by a reduction in shares outstanding as a result of our share repurchase program.

[0000068505-14-000016:mdna:50]
[same as prior period, unchanged from 0000068505-14-000010:mdna:51]

[0000068505-14-000016:mdna:51]
After taxes, we had earnings from discontinued operations of $81 million, or $0.32 per diluted share, in the third quarter of 2014, compared to earnings from discontinued operations of $46 million, or $0.18 per diluted share, in the third quarter of 2013. The increase in earnings from discontinued operations in the third quarter of 2014, as compared to the third quarter of 2013, was primarily driven by a lower effective tax rate.

[0000068505-14-000016:mdna:52]
Results of Operations—Nine months ended September 27, 2014 compared to nine months ended September 28, 2013

[0000068505-14-000016:mdna:53]
[same as prior period, unchanged from 0000068505-14-000010:mdna:55]

[0000068505-14-000016:mdna:54]
Net sales were $4.1 billion in the first nine months of 2014, down $352 million, or 8%, compared to net sales of $4.4 billion in the first nine months of 2013. The decrease in net sales reflects a $336 million, or 12%, decrease in net sales in the Products segment driven by declines in: (i) North America, as a result of lower devices and systems sales, (ii) APME, reflecting declines in devices and systems sales, and (iii) Latin America, as a result of lower devices sales, partially offset by double-digit growth in systems sales and single-digit growth in devices sales within EA. In addition, the decrease in sales includes a $16 million, or 1%, decrease in net sales in the Services segment driven by declines in: (i) North America, as a result of iDEN services declines, and (ii) APME, reflecting lower sales in Integration services sales, partially offset by an increase in: (i) EA, as a result of increased Integration and Managed services sales, and (ii) Latin America, reflecting an increase in Integration services sales and Managed services sales, partially offset by iDEN services declines.

[0000068505-14-000016:mdna:55]
[same as prior period, unchanged from 0000068505-14-000010:mdna:57]

[0000068505-14-000016:mdna:56]
Gross margin was $1.9 billion, or 47.3% of net sales, in the first nine months of 2014, compared to $2.2 billion, or 50.1% of net sales, in the first nine months of 2013. The decrease in gross margin percentage is attributable to sales declines, driven primarily by: (i) a decline in gross margin as a percentage of sales in North America, as a result of a product mix within the Products segment between devices and systems, which include more third party equipment, (ii) overall sales mix between the Products and Services segments, and (iii) lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-14-000016:mdna:57]
[same as prior period, unchanged from 0000068505-14-000010:mdna:59]

[0000068505-14-000016:mdna:58]
SG&A expenses decreased 8% to $902 million, or 22.2% of net sales, in the first nine months of 2014, compared to $984 million, or 22.3% of net sales, in the first nine months of 2013. The decrease in SG&A expenditures is primarily due to: (i) the reduction of sales support costs by lowering our overall non-quota carrying employee base, (ii) reduced costs created by increasing the use of centralized services, and (iii) lower incentive compensation expenses.

[0000068505-14-000016:mdna:59]
R&D expenditures decreased $49 million to $516 million, or 12.7% of net sales, in the first nine months of 2014, compared to $565 million, or 12.8% of net sales, in the first nine months of 2013. The decrease in R&D expenditures is primarily due to: (i) headcount reductions enacted during previous periods, (ii) the consolidation of testing processes and lab sites, (iii) the movement of employees to lower cost work sites, and (iv) lower incentive compensation expenses.

[0000068505-14-000016:mdna:60]
[same as prior period, unchanged from 0000068505-14-000010:mdna:63]

[0000068505-14-000016:mdna:61]
We recorded net charges of $49 million in Other charges in the first nine months of 2014, compared to net charges of $37 million in the first nine months of 2013. The net charges in the first nine months of 2014 included: (i) $48 million of net reorganization of business charges, (ii) $11 million of pension-related transaction fees, (iii) $8 million of legal settlement charges, and (iv) $3 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land. The net charges in the first nine months of 2013 of $37 million were primarily comprised of net reorganization of business charges. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-14-000016:mdna:62]
[same as prior period, unchanged from 0000068505-14-000010:mdna:67]

[0000068505-14-000016:mdna:63]
Net interest expense was $85 million in the first nine months of 2014 and 2013. Net interest expense in the first nine months of 2014 includes interest expense of $102 million, partially offset by interest income of $17 million.  Net interest expense in the first nine months of 2013 includes interest expense of $100 million, partially offset by interest income of $15 million.

[0000068505-14-000016:mdna:64]
Net Gains on Sales of Investments and Businesses

[0000068505-14-000016:mdna:65]
Net gains on sales of investments and businesses were $4 million in the first nine months of 2014 and $34 million in the first nine months of 2013. The net gains in the first nine months of 2014 consisted primarily of gains on the sales of equity investments. The net gains in the first nine months of 2013 consisted primarily of a gain on the sale of one specific equity investment along with other equity investment sales.

[0000068505-14-000016:mdna:66]
[same as prior period, unchanged from 0000068505-14-000010:mdna:71]

[0000068505-14-000016:mdna:67]
Net Other expense was $34 million in the first nine months of 2014, compared to net Other income of $3 million in the first nine months of 2013. The net Other expense in the first nine months of 2014 was primarily comprised of a $37 million loss on the extinguishment of debt, a $6 million foreign currency loss, and $4 million of other non-operating losses, partially offset by $13 million of gains on equity method investments. The net Other income in the first nine months of 2013 was primarily comprised of $7 million of gains on equity method investments and $7 million of other non-operating gains, partially offset by an $8 million loss on foreign currency and $3 million of investment impairments.

[0000068505-14-000016:mdna:68]
[same as prior period, unchanged from 0000068505-14-000010:mdna:73]

[0000068505-14-000016:mdna:69]
We recorded $107 million of net tax expense in the first nine months of 2014, resulting in an effective tax rate of 32%, compared to $72 million of net tax benefit in the first nine months of 2013, resulting in a negative effective tax rate. Our effective tax rate in 2014 was lower than the U.S. statutory tax rate of 35% due to tax benefits associated with the net reduction in unrecognized tax benefits and revaluing of deferred tax assets for state effective rates. Our effective tax rate in the first nine months of 2013 was lower than the U.S. statutory tax rate of 35% due to: (i) $128 million of net tax benefits largely associated with excess foreign tax credits on undistributed foreign earnings, (ii) a $25 million reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions, and (iii) an $8 million tax benefit for R&D tax credits.

[0000068505-14-000016:mdna:70]
[same as prior period, unchanged from 0000068505-14-000010:mdna:75]

[0000068505-14-000016:mdna:71]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $229 million, or $0.90 per diluted share, in the first nine months of 2014, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $641 million, or $2.34 per diluted share, in the first nine months of 2013.

[0000068505-14-000016:mdna:72]
The decrease in earnings from continuing operations in the first nine months of 2014, as compared to the first nine months of 2013, was primarily driven by: (i) a $289 million decrease in gross margin primarily due to sales declines and a change in sales mix and (ii) a higher effective tax rate, partially offset by an $82 million decrease in SG&A and a $49 million decrease in R&D. The decrease in earnings from continuing operations per diluted share was driven by lower earnings from continuing operations, partially offset by a reduction in shares outstanding as a result of our share repurchase program.

[0000068505-14-000016:mdna:73]
[same as prior period, unchanged from 0000068505-14-000010:mdna:78]

[0000068505-14-000016:mdna:74]
After taxes, we had $869 million, or $3.42 per diluted share, earnings from discontinued operations in the first nine months of 2014, compared to earnings from discontinued operations of $116 million, or $0.43 per diluted share, in the first nine months of 2013.

[0000068505-14-000016:mdna:75]
The increase in earnings from discontinued operations in the first nine months of 2014, as compared to the first nine months of 2013, was primarily driven by a $748 million tax benefit associated with establishing a deferred tax asset for outside basis differences on the Enterprise business. Upon the closing of the sale of the Enterprise business in the fourth quarter of 2014, we will incur a tax expense which will substantially offset this $748 million tax benefit on a year-to-date basis.

[0000068505-14-000016:mdna:76]
30

[0000068505-14-000016:mdna:77]
[same as prior period, unchanged from 0000068505-14-000010:mdna:81]

[0000068505-14-000016:mdna:78]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and nine months ended September 27, 2014 and September 28, 2013 as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-14-000016:mdna:79]
[same as prior period, unchanged from 0000068505-14-000010:mdna:83]

[0000068505-14-000016:mdna:80]
For the third quarter of 2014, the segment’s net sales represented 64% of our consolidated net sales, compared to 66% of our consolidated net sales for the third quarter of 2013. For the first nine months of 2014, the segment’s net sales represented 63% of our consolidated net sales, compared to 66% of our consolidated net sales for the first nine months of 2013.

[0000068505-14-000016:mdna:81]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | September 27, 2014 |  | September 28, 2013 |  | % Change |  | September 27, 2014 |  | September 28, 2013 |  | % Change |
| Segment net sales | $ | 921 |  |  | $ | 998 |  |  | (8 | )% |  | $ | 2,561 |  |  | $ | 2,897 |  |  | (12 | )% |
| Operating earnings | 141 |  |  | 171 |  |  | (18 | )% |  | 276 |  |  | 402 |  |  | (31 | )% |

[0000068505-14-000016:mdna:82]
Three months ended September 27, 2014 compared to three months ended September 28, 2013

[0000068505-14-000016:mdna:83]
The segment’s net sales decreased $77 million, to $921 million in the third quarter of 2014, as compared to $998 million during the third quarter of 2013. The decrease in net sales in the Products segment reflects a decrease in sales of: (i) devices within North America, Latin America, and APME, offset by an increase in EA and (ii) systems within Latin America and APME, partially offset by an increase in system sales within North America and EA. On a geographic basis, net sales declined in North America, Latin America and APME, and increased in EA, compared to the third quarter of 2013. Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 63% of the segment’s net sales in the third quarter of 2014 and 62% of the segment’s net sales in the third quarter of 2013.

[0000068505-14-000016:mdna:84]
The segment had operating earnings of $141 million in the third quarter of 2014, compared to $171 million in the third quarter of 2013.  As a percentage of net sales in the third quarter of 2014 as compared to the third quarter of 2013, gross margin decreased, SG&A expenditures decreased, R&D expenditures decreased, and Other charges increased.  The decrease in operating earnings was primarily driven by a decrease in net sales and change in product mix, resulting in lower gross margin, and an increase in Other charges as a result of increased reorganization of business charges.

[0000068505-14-000016:mdna:85]
Nine months ended September 27, 2014 compared to nine months ended September 28, 2013

[0000068505-14-000016:mdna:86]
The segment’s net sales decreased $336 million, to $2.6 billion in the first nine months of 2014, as compared to $2.9 billion in the first nine months of 2013. The decrease in net sales in the Products segment reflects a decrease in: (i) devices sales in North America, Latin America, and APME, offset by an increase in sales within EA and (ii) system sales in North America and APME, offset by an increase within Latin America and EA. On a geographic basis, net sales declined in North America, Latin America and APME, and increased in EA for the nine months ended September 27, 2014 compared to the nine months ended September 28, 2013. Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 61% of the segment’s net sales in the first nine months of 2014 and 64% of the segment’s net sales in the first nine months of 2013.

[0000068505-14-000016:mdna:87]
The segment had operating earnings of $276 million in the first nine months of 2014, compared to $402 million in the first nine months of 2013. As a percentage of net sales in the first nine months of 2014 compared to net sales in the first nine months of 2013, gross margin decreased, SG&A expenditures decreased, R&D expenditures decreased, and Other charges increased.  The decrease in operating earnings was primarily driven by a decrease in net sales and change in product mix, resulting in lower gross margin, and an increase in Other charges as a result of increased reorganization of business charges.

[0000068505-14-000016:mdna:88]
[same as prior period, unchanged from 0000068505-14-000010:mdna:92]

[0000068505-14-000016:mdna:89]
For the third quarter of 2014, the segment’s net sales represented 36% of our consolidated net sales, compared to 34% of our consolidated net sales for the third quarter of 2013. For the first nine months of 2014, the segment’s net sales represented 37% of our consolidated net sales, compared to 34% of our consolidated net sales for the first nine months of 2013.

[0000068505-14-000016:mdna:90]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | September 27, 2014 |  | September 28, 2013 |  | % Change |  | September 27, 2014 |  | September 28, 2013 |  | % Change |
| Segment net sales | $ | 515 |  |  | $ | 519 |  |  | (1 | )% |  | $ | 1,497 |  |  | $ | 1,513 |  |  | (1 | )% |
| Operating earnings | 66 |  |  | 75 |  |  | (12 | )% |  | 176 |  |  | 220 |  |  | (20 | )% |

[0000068505-14-000016:mdna:91]
Three months ended September 27, 2014 compared to three months ended September 28, 2013

[0000068505-14-000016:mdna:92]
The segment’s net sales decreased $4 million, or 1%, to $515 million in the third quarter of 2014, as compared to $519 million in the third quarter of 2013. The 1% decrease in net sales in the Services segment reflects a decrease in sales of iDEN and Lifecycle services, partially offset by an increase in Managed services. On a geographic basis, net sales for the third quarter of 2014 declined in North America, increased in EA, and remained relatively constant in Latin America and APME, compared to the third quarter of 2013. The decline in North America was driven by the decline in iDEN and Integration service sales, while the increase in EA was primarily driven by higher Integration service sales.  Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the third quarter of 2014 and 63% of the segment’s net sales in the third quarter of 2013.

[0000068505-14-000016:mdna:93]
The segment had operating earnings of $66 million in the third quarter of 2014, compared to $75 million in the third quarter of 2013 as a result of lower gross margins related to long-term project mix. As a percentage of net sales in the third quarter of 2014 as compared to the third quarter of 2013, gross margin and SG&A expenditures decreased, and R&D expenditures and Other charges increased. The decrease in operating earnings was primarily driven by lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio and an increase in Other charges as a result of increased reorganization of business charges.

[0000068505-14-000016:mdna:94]
Nine months ended September 27, 2014 compared to nine months ended September 28, 2013

[0000068505-14-000016:mdna:95]
The segment’s net sales decreased $16 million, or 1%, to $1.5 billion in the first nine months of 2014, as compared to net sales of $1.5 billion in the first nine months of 2013. The 1% decrease in net sales in the Services segment reflects a decrease in sales of: (i) iDEN services and (ii) Lifecycle Management and Support services, partially offset by an increase in sales of: (i) Integration services and (ii) Managed services. On a geographic basis, net sales in the first nine months of 2014 declined in North America and APME, increased in EA, and remained constant in Latin America, compared to the first nine months of 2013.  The decline in North America was driven by lower sales in (i) iDEN services, (ii) Integration services, and (iii) Lifecycle Management and Support services. The decrease in APME was driven by lower Lifecycle Management and Support and Integration services, offset by an increase in Managed services.  The increase in EA was primarily driven by higher Integration and Managed services, partially offset by lower sales of Lifecycle Management and Support services.  Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 60% of the segment’s net sales as of September 27, 2014 and 62% of the segment’s net sales during the first nine months of 2013.

[0000068505-14-000016:mdna:96]
The segment had operating earnings of $176 million in the first nine months of 2014, compared to operating earnings of $220 million in the first nine months of 2013.  As a percentage of net sales in the first nine months of 2014 as compared to the first nine months of 2013, gross margin and SG&A expenditures decreased, and R&D expenditures and Other charges increased. The decrease in operating earnings was primarily driven by lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio and an increase in Other charges as a result of increased reorganization of business charges.

[0000068505-14-000016:mdna:97]
[same as prior period, unchanged from 0000068505-14-000010:mdna:101]

[0000068505-14-000016:mdna:98]
During the first nine months of 2014, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the third quarter of 2014, we recorded net reorganization of business charges of $20 million including $13 million of charges recorded within Other charges and $7 million in Cost of sales in our condensed consolidated statements of operations. The $20 million of charges were all related to employee separation costs.

[0000068505-14-000016:mdna:99]
During the first nine months of 2014, we recorded net reorganization of business charges of $58 million including charges of $48 million recorded in Other charges and $10 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $58 million are charges of $54 million for employee separation costs and $4 million for exit costs.

[0000068505-14-000016:mdna:100]
During the third quarter of 2013, we recorded net reorganization of business charges of $21 million including charges of $16 million recorded in Other charges and $5 million in Cost of sales in our condensed consolidated statements of operations. The $21 million of charges was all related to employee separation costs.

[0000068505-14-000016:mdna:101]
During the first nine months of 2013, we recorded net reorganization of business charges of $46 million including charges of $36 million recorded in Other charges and $10 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $46 million are charges of $50 million for employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-14-000016:mdna:102]
We expect to realize cost-saving benefits of approximately $15 million during the remaining three months of 2014 from the plans that were initiated during the first nine months of 2014. Beyond 2014, we expect the reorganization plans initiated

[0000068505-14-000016:mdna:103]
during the first nine months of 2014 to provide annualized cost savings of approximately $42 million, consisting of: (i) $37 million of savings in operating expenses and (ii) $5 million of savings in Cost of Sales.

[0000068505-14-000016:mdna:104]
[same as prior period, unchanged from 0000068505-14-000010:mdna:108]

[0000068505-14-000016:mdna:105]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Products | $ | 13 |  |  | $ | 14 |  |  | $ | 38 |  |  | $ | 30 |  |
| Services | 7 |  |  | 7 |  |  | 20 |  |  | 16 |  |
|  | $ | 20 |  |  | $ | 21 |  |  | $ | 58 |  |  | $ | 46 |  |

[0000068505-14-000016:mdna:106]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $116 million in the first nine months of 2014 and $45 million in the first nine months of 2013. The cash payments related to discontinued operations included in these totals were $40 million in the first nine months of 2014 and $16 million in the first nine months of 2013. The reorganization of businesses accruals at September 27, 2014 were $64 million, including those related to discontinued operations which will be maintained by us after the sale of our Enterprise business. Of the $64 million of accruals,  $62 million relate to employee separation costs that are expected to be paid within one year and $2 million of accruals are primarily related to lease termination obligations that are expected to be paid over a number of years.

[0000068505-14-000016:mdna:107]
[same as prior period, unchanged from 0000068505-14-000010:mdna:111]

[0000068505-14-000016:mdna:108]
We decreased the aggregate of our cash and cash equivalent balances by $380 million from $3.2 billion as of December 31, 2013 to $2.8 billion as of September 27, 2014.  The decrease is primarily due to: (i) $1.4 billion of capital returned to shareholders through share repurchases and dividends paid and (ii) $461 million of repayments for long-term debt during the first nine months of 2014, partially offset by $1.4 billion of proceeds from the issuance of debt.

[0000068505-14-000016:mdna:109]
[same as prior period, unchanged from 0000068505-14-000010:mdna:113]

[0000068505-14-000016:mdna:110]
[same as prior period, unchanged from 0000068505-14-000010:mdna:114]

[0000068505-14-000016:mdna:111]
Our cash and cash equivalents (which are highly-liquid investments with an original maturity of three months or less) were $2.8 billion at September 27, 2014 and $3.2 billion at December 31, 2013. At September 27, 2014, $1.7 billion of this amount was held in the U.S. and approximately $1.1 billion was held by the Company or its subsidiaries in other countries (including $428 million in the United Kingdom). At both September 27, 2014 and December 31, 2013, restricted cash was $63 million.

[0000068505-14-000016:mdna:112]
[same as prior period, unchanged from 0000068505-14-000010:mdna:116]

[0000068505-14-000016:mdna:113]
review various repatriation strategies to efficiently repatriate funds in the context of meeting our business needs in a tax efficient manner. During the first nine months of 2014, we repatriated $410 million in funds to the U.S. from international jurisdictions. We have approximately $700 million of foreign earnings that are not permanently reinvested and may be repatriated without an additional income tax charge given the U.S. federal and foreign tax accrued on undistributed earnings and the utilization of available foreign tax credits. Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-14-000016:mdna:114]
On October 27, 2014, we closed on the sale of our Enterprise business with Zebra Technologies Corporation for $3.45 billion in cash.

[0000068505-14-000016:mdna:115]
[same as prior period, unchanged from 0000068505-14-000010:mdna:119]

[0000068505-14-000016:mdna:116]
Net cash provided by operating activities in the first nine months of 2014 was $15 million, as compared to $25 million of cash used for operating activities in the first nine months of 2013. Operating cash flows in the first nine months of 2014, as compared to the first nine months of 2013, were positively impacted by: (i) improved accounts receivable collections, including long-term contracts, (ii) lower incentive compensation, and (iii) lower net tax payments associated with repatriation activities, partially offset by an additional $344 million of global pension contributions.

[0000068505-14-000016:mdna:117]
We contributed $463 million to our U.S. pension plans during the first nine months of 2014, compared to $122 million contributed in the first nine months of 2013. We contributed $27 million to our non-U.S. pension plans during the first nine months of 2014, compared to $24 million contributed in the first nine months of 2013.

[0000068505-14-000016:mdna:118]
During the third quarter of 2014, we entered into a Definitive Purchase Agreement (the “Agreement”) by and among Motorola Solutions Inc., The Prudential Insurance Company of America (“PICA”), Prudential Financial, Inc., and State Street Bank and Trust Company, as Independent Fiduciary of the U.S. noncontributory pension plan (the "Regular Pension Plan"), pursuant to which the Regular Pension Plan will purchase from PICA a group annuity contract that requires PICA to pay and administer certain future annuity payments to certain of our retirees. Upon issuance of the group annuity contract by PICA, PICA will irrevocably assume the obligation to make future annuity payments to approximately 30,000 retirees who have been receiving pension payments from the Regular Pension Plan. In connection with the proposed transaction, we have established a new pension plan with substantially the same terms as the Regular Pension Plan (the “New Plan,” together with the Regular Pension Plan, “the Plans”), and it is expected that the Regular Pension Plan will ultimately be terminated.  Assuming all of the closing conditions are satisfied, we expect the purchase of the group annuity contract, and a corresponding plan termination expense, to occur in the fourth quarter of 2014.

[0000068505-14-000016:mdna:119]
Also during the third quarter of 2014, we announced that the New Plan is offering lump-sum distributions to New Plan participants who have accrued a pension benefit, have left Motorola Solutions, Inc. prior to June 30, 2014, and have not yet started receiving pension benefit payments. The maximum dollar amount of all lump-sum distributions to be paid under the offer is $1.0 billion, and lump-sum payments will be made to those who accept the lump-sum offer starting with the smallest amount of lump sums first and continuing in ascending order until the $1.0 billion threshold is met.

[0000068505-14-000016:mdna:120]
In conjunction with the pension-related events announced during the third quarter of 2014, we now expect our contributions to our pension plans to total approximately $1.1 billion for fiscal year 2014.

[0000068505-14-000016:mdna:121]
[same as prior period, unchanged from 0000068505-14-000010:mdna:125]

[0000068505-14-000016:mdna:122]
Net cash used for investing activities was $98 million in the first nine months of 2014, compared to net cash provided by investing activities of $899 million in the first nine months of 2013. This $997 million decline was primarily due to $966 million of proceeds from sales of Sigma Fund investments in the first nine months of 2013 with no comparable activity in the first nine months of 2014.

[0000068505-14-000016:mdna:123]
Acquisition and Investments: We used net cash for acquisitions and investments of $21 million during the first nine months of 2014 compared to $20 million in the first nine months of 2013. The cash used for investments in both periods relates to a number of equity investments.

[0000068505-14-000016:mdna:124]
Sales of Investments and Businesses: We had $23 million of proceeds related to the sales of investments and businesses in the first nine months of 2014 compared to $48 million in the first nine months of 2013. The proceeds in both periods were comprised of sales of certain equity investments.

[0000068505-14-000016:mdna:125]
Capital Expenditures: Capital expenditures increased in the first nine months of 2014 to $130 million, compared to $110 million in the first nine months of 2013.  The increase in capital expenditures was primarily driven by increased revenue-generating network expenditures.

[0000068505-14-000016:mdna:126]
Sales of Property, Plant, and Equipment:  We had $30 million of proceeds related to the sale of property, plant, and equipment in the first nine months of 2014 compared to $15 million in the first nine months of 2013.  The proceeds in both periods were comprised of sales of buildings and land.

[0000068505-14-000016:mdna:127]
[same as prior period, unchanged from 0000068505-14-000010:mdna:131]

[0000068505-14-000016:mdna:128]
Net cash used for financing activities was $274 million in the first nine months of 2014, compared to $612 million in the first nine months of 2013. Cash used for financing activities in the first nine months of 2014 was primarily comprised of: (i) $1.1 billion used for purchases of our common stock under our share repurchase program, (ii) $461 million of repayments for long-term debt, and (iii) $236 million of cash used for the payment of dividends, partially offset by: (i) $1.4 billion of proceeds from issuance of debt, (ii) $94 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, and (iii) $66 million of distributions from discontinued operations.  Net cash used for financing activities in the first nine months of 2013 was primarily comprised of: (i) $1.3 billion used for purchases of our common stock under our share repurchase program and (ii) $212 million of cash used for the payment of dividends, partially offset by: (i) $593 million of net proceeds from the issuance of debt, (ii) $214 million of distributions from discontinued operations, and (iii) $108 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-14-000016:mdna:129]
Long-Term Debt: We had outstanding long-term debt of $3.4 billion at September 27, 2014 and $2.5 billion December 31, 2013, including the current portions of $4 million at both September 27, 2014 and December 31, 2013.

[0000068505-14-000016:mdna:130]
[same as prior period, unchanged from 0000068505-14-000010:mdna:153]

[0000068505-14-000016:mdna:131]
During the third quarter of 2014, we redeemed $400 million aggregate principal amount outstanding of our 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. We issued an aggregate face principal amount of $1.4 billion including: (i) $600 million of 4.000% Senior notes due 2024, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior notes due 2021, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior notes due 2044, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $394 million.

[0000068505-14-000016:mdna:132]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. We believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty or volatility in the capital markets may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-14-000016:mdna:133]
Share Repurchase Program: We paid an aggregate of $650 million during the third quarter of 2014, including transaction costs, to repurchase 10.4 million shares at an average price of $62.63 per share. We paid an aggregate of $1.1 billion during the first nine months of 2014, including transaction costs, to repurchase approximately 17.4 million shares at an average price of $64.36 per share.  All repurchased shares have been retired.

[0000068505-14-000016:mdna:134]
On November 3, 2014, the Board of Directors has authorized us to repurchase additional shares, bringing the aggregate amount under the program to $12.0 billion of outstanding shares of common stock. The share repurchase program does not have an expiration date. As of September 27, 2014, we have used approximately $6.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $5.6 billion of authority available for future repurchases.

[0000068505-14-000016:mdna:135]
Payment of Dividends: During the third quarter of 2014, we paid $78 million in cash dividends to holders of our common stock. During the first nine months of 2014, we paid $236 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid $82 million in cash dividends to holders of our common stock.

[0000068505-14-000016:mdna:136]
[same as prior period, unchanged from 0000068505-14-000010:mdna:140]

[0000068505-14-000016:mdna:137]
As of September 27, 2014, we had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We are no longer subject to a minimum interest coverage covenant under the new facility. We were in compliance with our financial covenants as of September 27, 2014. We did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the nine months ended September 27, 2014.

[0000068505-14-000016:mdna:138]
As of September 27, 2014, we had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of September 27, 2014.

[0000068505-14-000016:mdna:139]
[same as prior period, unchanged from 0000068505-14-000010:mdna:143]

[0000068505-14-000016:mdna:140]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $128 million at September 27, 2014, compared to $50 million at December 31, 2013.

[0000068505-14-000016:mdna:141]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $21 million at September 27, 2014, compared to $1 million at December 31, 2013. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 13%.

[0000068505-14-000016:mdna:142]
[same as prior period, unchanged from 0000068505-14-000010:mdna:146]

[0000068505-14-000016:mdna:143]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 27, 2014 and September 28, 2013:

[0000068505-14-000016:mdna:144]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Proceeds received: |  |  |  |  |  |  |  |
| Accounts receivable sales proceeds | $ | 6 |  |  | $ | 4 |  |  | $ | 39 |  |  | $ | 6 |  |
| Long-term receivables sales proceeds | 37 |  |  | 37 |  |  | 91 |  |  | 90 |  |
| Total proceeds from sales of accounts receivable | $ | 43 |  |  | $ | 41 |  |  | $ | 130 |  |  | $ | 96 |  |

[0000068505-14-000016:mdna:145]
At September 27, 2014, we had retained servicing obligations for $473 million of sold long-term receivables, compared to $434 million of sold long-term receivables at December 31, 2013.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-14-000016:mdna:146]
Other Contingencies

[0000068505-14-000016:mdna:147]
[same as prior period, unchanged from 0000068505-14-000010:mdna:151]

[0000068505-14-000016:mdna:148]
Indemnification Provisions:  We are a party to a variety of agreements pursuant to which we are obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party's claims.  In some instances, we may have recourse against third parties for certain payments made by us.

[0000068505-14-000016:mdna:149]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representation and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  We had no accruals for any such obligations at September 27, 2014.

[0000068505-14-000016:mdna:150]
[same as prior period, unchanged from 0000068505-14-000010:mdna:155]

[0000068505-14-000016:mdna:151]
[same as prior period, unchanged from 0000068505-14-000010:mdna:154]

[0000068505-14-000016:mdna:152]
[same as prior period, unchanged from 0000068505-14-000010:mdna:156]

[0000068505-14-000016:mdna:153]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for us beginning January 1, 2015. We do not believe this ASU will have a material impact on our financial statements.

[0000068505-14-000016:mdna:154]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for us beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.
