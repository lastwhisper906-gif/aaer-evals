# MSI 8-K — 0000068505-22-000030 filed 2022-11-03

## item codes, every 8-K on or before 2022-11-03

- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2022-11-03

- none on or before 2022-11-03

## item 2.02 — earnings release, exhibit 99.1

[0000068505-22-000030:8k_2_02:1]
EX-99.1
2
msiq32022pressrelease.htm
EX-99.1

[0000068505-22-000030:8k_2_02:2]
Document

[0000068505-22-000030:8k_2_02:3]
Exhibit 99.1

[0000068505-22-000030:8k_2_02:4]
Motorola Solutions Reports Third Quarter 2022 Financial Results

[0000068505-22-000030:8k_2_02:5]
Company raises full-year revenue and earnings outlook on strong Q3 results

[0000068505-22-000030:8k_2_02:6]
•Sales of $2.4 billion, up 13% versus a year ago

[0000068505-22-000030:8k_2_02:7]
◦Products and Systems Integration sales up 15%

[0000068505-22-000030:8k_2_02:8]
◦Software and Services sales up 8%

[0000068505-22-000030:8k_2_02:9]
•GAAP earnings per share (EPS) of $1.63, down 7% from a year ago, inclusive of a $147 million fixed asset impairment for the now expected exit from the ESN contract

[0000068505-22-000030:8k_2_02:10]
•Non-GAAP EPS* of $3.00, up 28% versus a year ago

[0000068505-22-000030:8k_2_02:11]
•Generated $388 million of operating cash flow, up $12M versus a year ago

[0000068505-22-000030:8k_2_02:12]
•Record Q3 ending backlog of $13.5 billion, up 19% versus a year ago

[0000068505-22-000030:8k_2_02:13]
CHICAGO – November 3, 2022 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of 2022.

[0000068505-22-000030:8k_2_02:14]
“Q3 was another outstanding quarter, with record sales in both segments,” said Greg Brown, chairman and CEO of Motorola Solutions. “We continue to see exceptionally strong demand for our solutions and a robust funding environment. I’m particularly pleased that the investments we’re making in video security and access control continue to drive outstanding growth. Our momentum is strong, and we’re again raising our revenue and earnings expectations for the full year.”

[0000068505-22-000030:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-22-000030:8k_2_02:16]
|  | Q3 2022 |  | Q3 2021 | % Change |
| Sales | $2,373 |  | $2,107 | 13 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $373 |  | $451 | (17) | % |
| % of Sales | 15.7 | % |  | 21.4 | % |  |
| EPS | $1.63 |  | $1.76 | (7) | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $676 |  | $555 | 22 | % |
| % of Sales | 28.5 | % |  | 26.3 | % |  |
| EPS | $3.00 |  | $2.35 | 28 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,529 |  | $1,325 | 15 | % |
| GAAP Operating Earnings | $303 |  | $224 | 35 | % |
| % of Sales | 19.8 | % |  | 16.9 | % |  |
| Non-GAAP Operating Earnings* | $375 |  | $273 | 37 | % |
| % of Sales | 24.5 | % |  | 20.6 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $844 |  | $782 | 8 | % |
| GAAP Operating Earnings | $70 |  | $227 | (69) | % |
| % of Sales | 8.3 | % |  | 29.1 | % |  |
| Non-GAAP Operating Earnings* | $301 |  | $282 | 7 | % |
| % of Sales | 35.7 | % |  | 36.0 | % |  |

[0000068505-22-000030:8k_2_02:17]
*Non-GAAP financial information excludes the after-tax impact of approximately $1.37 per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-22-000030:8k_2_02:18]
1

[0000068505-22-000030:8k_2_02:19]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-22-000030:8k_2_02:20]
•Revenue - Sales were $2.4 billion, up 13% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $32 million and currency headwinds were $66 million in the quarter. The Products and Systems Integration segment grew 15%, driven by growth in land mobile radio (LMR) and video security and access control (video). The Software and Services segment grew 8%, driven by growth in video, LMR services and command center software.

[0000068505-22-000030:8k_2_02:21]
•Operating margin - GAAP operating margin was 15.7% of sales, down from 21.4% in the year-ago quarter, primarily driven by a fixed asset impairment charge in the amount of $147 million related to the now expected exit from the Emergency Services Network (ESN) contract in the U.K. Non-GAAP operating margin was 28.5% of sales, up 220 basis points from 26.3% in the year-ago quarter, driven by higher sales, higher gross margin and improved operating leverage, primarily in the Products and Systems Integration segment.

[0000068505-22-000030:8k_2_02:22]
•Taxes - The GAAP effective tax rate was 15.9%, down from 24.0% in the year-ago quarter. The non-GAAP effective tax rate was 19.7%, down from 22.4% in the year-ago quarter. Both the GAAP and non-GAAP tax rates declined primarily due to higher benefits from stock-based compensation recognized in the current year.

[0000068505-22-000030:8k_2_02:23]
•Cash flow - Operating cash flow was $388 million, compared to $376 million in the year-ago quarter. Free cash flow was $318 million, compared to $315 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings (adjusted for non-cash charges), partially offset by an increase in working capital, driven primarily by higher inventory.

[0000068505-22-000030:8k_2_02:24]
•Capital allocation - During the quarter, the company paid $132 million in cash dividends, repurchased $94 million of shares and incurred $70 million of capital expenditures. Additionally, the company closed the acquisition of Barrett Communications for $18 million, net of cash acquired.

[0000068505-22-000030:8k_2_02:25]
•Backlog - The company ended the quarter with record Q3 backlog of $13.5 billion, up 19% or $2.1 billion from the year-ago quarter, inclusive of $826 million of unfavorable currency. Products and SI segment backlog was up 35%, or $1.2 billion. The growth was primarily driven by strong LMR and video demand. Software and Services segment backlog was up 11% or $876 million, driven by the extension of the Airwave contract in the fourth quarter of 2021 and an increase in multi-year software and services contracts in North America, partially offset by $722 million of unfavorable currency and a $99 million reduction for the now expected exit from the ESN contract.

[0000068505-22-000030:8k_2_02:26]
2

[0000068505-22-000030:8k_2_02:27]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-22-000030:8k_2_02:28]
Software and Services

[0000068505-22-000030:8k_2_02:29]
•$43M services renewal for the state of Maryland

[0000068505-22-000030:8k_2_02:30]
•$17M PTT over broadband order for a customer in the Middle East

[0000068505-22-000030:8k_2_02:31]
•$15M services renewal for the city of Phoenix, AZ

[0000068505-22-000030:8k_2_02:32]
•$7M command center software renewal for Will County, IL

[0000068505-22-000030:8k_2_02:33]
•$4M body-worn camera order for the Texas Department of Public Safety

[0000068505-22-000030:8k_2_02:34]
•$4M command center software suite order for Ellis County, TX

[0000068505-22-000030:8k_2_02:35]
Products and Systems Integration

[0000068505-22-000030:8k_2_02:36]
•$400M+ 25 year Systems Integration agreement in Israel

[0000068505-22-000030:8k_2_02:37]
•$165M P25 System and APX NEXT devices award for Miami-Dade County, FL

[0000068505-22-000030:8k_2_02:38]
•$67M P25 order for Southeastern Pennsylvania Transportation Authority

[0000068505-22-000030:8k_2_02:39]
•$45M P25 order for a customer in Africa

[0000068505-22-000030:8k_2_02:40]
•$29M P25 subscriber order for a U.S. Federal customer

[0000068505-22-000030:8k_2_02:41]
•$18M TETRA order for a customer in Europe

[0000068505-22-000030:8k_2_02:42]
•$5M fixed video order for a major transportation company in the North Africa

[0000068505-22-000030:8k_2_02:43]
BUSINESS OUTLOOK

[0000068505-22-000030:8k_2_02:44]
•Fourth quarter 2022 - The company expects revenue growth of approximately 9%, compared to the fourth quarter of 2021. The company expects non-GAAP EPS in the range of $3.40 to $3.45 per share. This assumes approximately $90 million in foreign exchange headwinds, approximately 172 million fully diluted shares, and an effective tax rate of approximately 23%.

[0000068505-22-000030:8k_2_02:45]
•Full-year 2022 - The company now expects revenue growth of between 9.25% and 9.5%, up from its prior guidance of approximately 8%, and non-GAAP EPS of between $10.17 and $10.22 per share, up from its prior guidance of between $10.03 and $10.13 per share. This outlook assumes approximately $220 million in foreign exchange headwinds, approximately 172 million fully diluted shares and an effective tax rate of approximately 20.5%.

[0000068505-22-000030:8k_2_02:46]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-22-000030:8k_2_02:47]
RECENT EVENTS

[0000068505-22-000030:8k_2_02:48]
CMA UPDATE

[0000068505-22-000030:8k_2_02:49]
In October 2021, the United Kingdom’s Competition and Markets Authority (the CMA) announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, the company’s private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain. In October 2022, the CMA published a provisional decision with its findings regarding competition and proposed remedies. The company disagrees with the CMA’s

[0000068505-22-000030:8k_2_02:50]
3

[0000068505-22-000030:8k_2_02:51]
provisional decision and will continue to work with the CMA to demonstrate the value of the Airwave network and pursue its legal avenues to protect Airwave’s contractual position.

[0000068505-22-000030:8k_2_02:52]
ESN MATTERS

[0000068505-22-000030:8k_2_02:53]
During the third quarter of 2022, the company made a business decision to begin negotiations regarding an early exit from its ESN contract with the Home Office of the United Kingdom. As a result, the company now believes the future service potential of the assets is limited, and accordingly has recognized a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN contract.

[0000068505-22-000030:8k_2_02:54]
MACROECONOMIC EVENTS

[0000068505-22-000030:8k_2_02:55]
During the third quarter of 2022, the company continued to operate under challenging market conditions, influenced by events such as those discussed below.

[0000068505-22-000030:8k_2_02:56]
Russia-Ukraine Conflict

[0000068505-22-000030:8k_2_02:57]
During the first quarter of 2022, in response to Russia's invasion of Ukraine, the company suspended all sales, provision of services and shipments of its products to Russia and Belarus. Russia, Ukraine and Belarus do not constitute a material portion of the company's business. For the year ended December 31, 2021, the company's net sales in Russia and Belarus were less than $25 million. While the company does not anticipate that the current posture of the Russia-Ukraine conflict will materially and adversely affect its results of operations, the conflict is still ongoing and future impacts, including those relating to an escalation of the conflict's current scope or expansion of the conflict's economic disruption, could materially and adversely affect the company's results of operations. During the first nine months of 2022, the company indirectly experienced impacts from the Russia-Ukraine conflict (as further described below). The conflict has and may continue to have a significant impact on the global macroeconomic and geopolitical environments, including increased volatility in capital and commodity markets, rapid changes to regulatory conditions (including the use of sanctions), supply chain and operational challenges for multinational corporations, inflationary pressures and an increased risk of cybersecurity incidents. For a more complete discussion of the risks the company encounters in its business, please refer to Part I, Item 1A, "Risk Factors" in the company's Annual Report on Form 10-K for the fiscal year ended December 31, 2021 and Part II, Item 1A, "Risk Factors" in the company's Quarterly Report on Form 10-Q for the fiscal quarter ended July 2, 2022.

[0000068505-22-000030:8k_2_02:58]
COVID-19, Supply Chain Disruptions & Inflationary Cost Environment

[0000068505-22-000030:8k_2_02:59]
The company's supply chain has been impacted by global issues related to the effects of the COVID-19 pandemic, the Russia-Ukraine conflict and the inflationary cost environment throughout the first nine months of 2022, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in the company's supply chain, as well as difficulties and delays in procuring certain semiconductor components. Since the latter part of the fourth quarter of 2021, cost increases have been driven by elevated lead times and increased material costs, in particular the need to purchase semiconductor components from alternative sources, including brokers. The company anticipates increased costs to procure materials within the semiconductor market to continue throughout 2022. Further, the company anticipates the broader impact of inflationary pressures and increased material and supply chain costs and disruptions to continue throughout 2022. The company is closely monitoring its supply chain, including impacts from manufacturing lockdowns related to the spread of COVID-19 in China which continue to disrupt the semiconductor supply market. Accordingly, in the first nine months of 2022 the company focused on improving its supplier network, engineering alternative designs and working to reduce supply shortages. The company is actively managing its inventory in an effort to

[0000068505-22-000030:8k_2_02:60]
4

[0000068505-22-000030:8k_2_02:61]
minimize supply chain disruptions and enable continuity of supply and services to its customers, and it expects to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-22-000030:8k_2_02:62]
In order to combat rising inflation in the U.S., the Federal Reserve has raised interest rates multiple times since the beginning of 2022. The increase in U.S. dollar interest rates and overall market conditions have led to significant strengthening of the U.S. dollar against other global currencies in 2022. The strong U.S. dollar reduced the impact of cash generated from the company's foreign operations during the first nine months of 2022, driven by revenues and costs that are denominated in foreign currencies, which has negatively impacted, and which the company expects to continue to impact, its operating cash flows and net earnings throughout 2022.

[0000068505-22-000030:8k_2_02:63]
Although the macroeconomic environment continued to introduce challenges in the first nine months of 2022, the company is encouraged by customer demand for its products and services. Specifically, in the Software and Services segment, with the largely recurring nature of the business and the strong backlog position, the company continues to expect that the impact to operating margin will be limited throughout 2022. While the company is encouraged by strong backlog and growth in its Products and Systems Integration segment in the first nine months of 2022, which the company expects to continue to grow for the remainder of 2022, supply constraints continue to impact the business and the company expects demand for its products will continue to out-pace its ability to obtain semiconductor component supply throughout 2022. Where appropriate, the company has taken pricing actions around its product and service offerings to mitigate its exposure to inflationary pressures on its businesses and benefited from these adjustments during the third quarter of 2022. The company expects to further benefit from such adjustments during the fourth quarter of 2022. Further, demand continues to be supported with ongoing sources of government funding. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. The company experienced the positive impact of the ARPA funding on its business and results of operations during the first nine months of 2022 and anticipates that the ARPA will continue to have a positive impact throughout the remainder of 2022.

[0000068505-22-000030:8k_2_02:64]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, November 3. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-22-000030:8k_2_02:65]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-22-000030:8k_2_02:66]
A comparison of results from operations is as follows:

[0000068505-22-000030:8k_2_02:67]
|  | Q3 2022 | Q3 2021 |
| Net sales | $2,373 | $2,107 |
| Gross margin | $1,031 | $1,045 |
| Operating earnings | $373 | $451 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $279 | $307 |
| Diluted EPS | $1.63 | $1.76 |
| Weighted average diluted common shares outstanding | 171.5 |  | 174.1 |  |

[0000068505-22-000030:8k_2_02:68]
5

[0000068505-22-000030:8k_2_02:69]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-22-000030:8k_2_02:70]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-22-000030:8k_2_02:71]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-22-000030:8k_2_02:72]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-22-000030:8k_2_02:73]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-22-000030:8k_2_02:74]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-22-000030:8k_2_02:75]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-22-000030:8k_2_02:76]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things,

[0000068505-22-000030:8k_2_02:77]
6

[0000068505-22-000030:8k_2_02:78]
injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the company on December 15, 2021, and, consistent with the company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court’s previous July 5, 2022 royalty order. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment.

[0000068505-22-000030:8k_2_02:79]
In response to the Court's decision to award the company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the company with respect to several of the company's post-trial motions, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award. On October 15, 2021, the Court granted the company’s request for $34.2 million in attorneys’ fees against Hytera.  On September 29, 2021, the company filed two additional motions with the Court, requesting the Court to reconsider its order denying the company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions.

[0000068505-22-000030:8k_2_02:80]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals").  The Court of Appeals dismissed the notice of appeal on February 16, 2022 after determining that such appeal was premature. On August 2, 2022, after the Court denied the motions described on July 5, 2022, Hytera filed a renewed notice of appeal in the Court of Appeals. The company filed its cross-appeal on August 5, 2022.

[0000068505-22-000030:8k_2_02:81]
Separate from the company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including $13 million to the company. The gain was recorded to Other charges (income).

[0000068505-22-000030:8k_2_02:82]
7

[0000068505-22-000030:8k_2_02:83]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $13 million of proceeds realized in Q1 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-22-000030:8k_2_02:84]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-22-000030:8k_2_02:85]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-22-000030:8k_2_02:86]
8

[0000068505-22-000030:8k_2_02:87]
FORWARD LOOKING STATEMENTS

[0000068505-22-000030:8k_2_02:88]
9

[0000068505-22-000030:8k_2_02:89]
inability to attract and retain senior management and key employees; (xxvi) impact of the ARPA on our business; and (xxvii) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-22-000030:8k_2_02:90]
ABOUT MOTOROLA SOLUTIONS

[0000068505-22-000030:8k_2_02:91]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio communications, video security and access control and command center software, bolstered by managed & support services, create an integrated technology ecosystem to help make communities safer and businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-22-000030:8k_2_02:92]
MEDIA CONTACT

[0000068505-22-000030:8k_2_02:93]
Alexandra Reynolds

[0000068505-22-000030:8k_2_02:94]
Motorola Solutions

[0000068505-22-000030:8k_2_02:95]
+1 312-965-3968

[0000068505-22-000030:8k_2_02:96]
alexandra.reynolds@motorolasolutions.com

[0000068505-22-000030:8k_2_02:97]
INVESTOR CONTACT

[0000068505-22-000030:8k_2_02:98]
Tim Yocum

[0000068505-22-000030:8k_2_02:99]
Motorola Solutions

[0000068505-22-000030:8k_2_02:100]
+1 847-576-6899

[0000068505-22-000030:8k_2_02:101]
Tim.Yocum@motorolasolutions.com

[0000068505-22-000030:8k_2_02:102]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2022 Motorola Solutions, Inc. All rights reserved.

[0000068505-22-000030:8k_2_02:103]
10

[0000068505-22-000030:8k_2_02:104]
GAAP-1

[0000068505-22-000030:8k_2_02:105]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:106]
Condensed Consolidated Statements of Operations

[0000068505-22-000030:8k_2_02:107]
(In millions, except per share amounts)

[0000068505-22-000030:8k_2_02:108]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| Net sales from products | $ | 1,439 |  |  | $ | 1,221 |  |
| Net sales from services | 934 |  |  | 886 |  |
| Net sales | 2,373 |  |  | 2,107 |  |
| Costs of products sales | 659 |  |  | 559 |  |
| Costs of services sales | 683 |  |  | 503 |  |
| Costs of sales | 1,342 |  |  | 1,062 |  |
| Gross margin | 1,031 |  |  | 1,045 |  |
| Selling, general and administrative expenses | 378 |  |  | 351 |  |
| Research and development expenditures | 197 |  |  | 183 |  |
| Other charges | 20 |  |  | 4 |  |
| Intangibles amortization | 63 |  |  | 56 |  |
| Operating earnings | 373 |  |  | 451 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (60) |  |  | (56) |  |
| Gain on sales of investments and businesses, net | 1 |  |  | — |  |
| Other, net | 19 |  |  | 10 |  |
| Total other expense | (40) |  |  | (46) |  |
| Net earnings before income taxes | 333 |  |  | 405 |  |
| Income tax expense | 53 |  |  | 97 |  |
| Net earnings | 280 |  |  | 308 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 279 |  |  | $ | 307 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.67 |  |  | $ | 1.81 |  |
| Diluted | $ | 1.63 |  |  | $ | 1.76 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.2 |  |  | 169.2 |  |
| Diluted | 171.5 |  |  | 174.1 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 60.6 | % |  | 57.9 | % |
| Net sales from services | 39.4 | % |  | 42.1 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 45.8 | % |  | 45.8 | % |
| Costs of services sales | 73.1 | % |  | 56.8 | % |
| Costs of sales | 56.6 | % |  | 50.4 | % |
| Gross margin | 43.4 | % |  | 49.6 | % |
| Selling, general and administrative expenses | 15.9 | % |  | 16.7 | % |
| Research and development expenditures | 8.3 | % |  | 8.7 | % |
| Other charges | 0.8 | % |  | 0.2 | % |
| Intangibles amortization | 2.7 | % |  | 2.7 | % |
| Operating earnings | 15.7 | % |  | 21.4 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.5) | % |  | (2.7) | % |
| Gain on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 0.8 | % |  | 0.5 | % |
| Total other expense | (1.7) | % |  | (2.2) | % |
| Net earnings before income taxes | 14.0 | % |  | 19.2 | % |
| Income tax expense | 2.2 | % |  | 4.6 | % |
| Net earnings | 11.8 | % |  | 14.6 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 11.8 | % |  | 14.6 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-22-000030:8k_2_02:109]
11

[0000068505-22-000030:8k_2_02:110]
GAAP-2

[0000068505-22-000030:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:112]
Condensed Consolidated Statements of Operations

[0000068505-22-000030:8k_2_02:113]
(In millions, except per share amounts)

[0000068505-22-000030:8k_2_02:114]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| Net sales from products | $ | 3,697 |  |  | $ | 3,250 |  |
| Net sales from services | 2,708 |  |  | 2,601 |  |
| Net sales | 6,405 |  |  | 5,851 |  |
| Costs of products sales | 1,844 |  |  | 1,516 |  |
| Costs of services sales | 1,683 |  |  | 1,478 |  |
| Costs of sales | 3,527 |  |  | 2,994 |  |
| Gross margin | 2,878 |  |  | 2,857 |  |
| Selling, general and administrative expenses | 1,069 |  |  | 985 |  |
| Research and development expenditures | 577 |  |  | 545 |  |
| Other charges | 68 |  |  | 37 |  |
| Intangibles amortization | 194 |  |  | 172 |  |
| Operating earnings | 970 |  |  | 1,118 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (171) |  |  | (154) |  |
| Gain on sales of investments and businesses, net | 3 |  |  | — |  |
| Other, net | 50 |  |  | 70 |  |
| Total other expense | (118) |  |  | (84) |  |
| Net earnings before income taxes | 852 |  |  | 1,034 |  |
| Income tax expense | 75 |  |  | 186 |  |
| Net earnings | 777 |  |  | 848 |  |
| Less: Earnings attributable to non-controlling interests | 3 |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 774 |  |  | $ | 844 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 4.62 |  |  | $ | 4.98 |  |
| Diluted | $ | 4.50 |  |  | $ | 4.87 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.5 |  |  | 169.3 |  |
| Diluted | 171.9 |  |  | 173.4 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 57.7 | % |  | 55.5 | % |
| Net sales from services | 42.3 | % |  | 44.5 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 49.9 | % |  | 46.6 | % |
| Costs of services sales | 62.1 | % |  | 56.8 | % |
| Costs of sales | 55.1 | % |  | 51.2 | % |
| Gross margin | 44.9 | % |  | 48.8 | % |
| Selling, general and administrative expenses | 16.7 | % |  | 16.8 | % |
| Research and development expenditures | 9.0 | % |  | 9.3 | % |
| Other charges | 1.1 | % |  | 0.6 | % |
| Intangibles amortization | 3.0 | % |  | 2.9 | % |
| Operating earnings | 15.1 | % |  | 19.1 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.7) | % |  | (2.6) | % |
| Gain on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 0.8 | % |  | 1.2 | % |
| Total other expense | (1.8) | % |  | (1.4) | % |
| Net earnings before income taxes | 13.3 | % |  | 17.7 | % |
| Income tax expense | 1.2 | % |  | 3.2 | % |
| Net earnings | 12.1 | % |  | 14.5 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 12.1 | % |  | 14.4 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-22-000030:8k_2_02:115]
12

[0000068505-22-000030:8k_2_02:116]
GAAP-3

[0000068505-22-000030:8k_2_02:117]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:118]
Condensed Consolidated Balance Sheets

[0000068505-22-000030:8k_2_02:119]
(In millions)

[0000068505-22-000030:8k_2_02:120]
|  | October 1, 2022 |  | December 31, 2021 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 822 |  |  | $ | 1,874 |  |
| Accounts receivable, net | 1,368 |  |  | 1,386 |  |
| Contract assets | 1,033 |  |  | 1,105 |  |
| Inventories, net | 1,157 |  |  | 788 |  |
| Other current assets | 327 |  |  | 259 |  |
| Total current assets | 4,707 |  |  | 5,412 |  |
| Property, plant and equipment, net | 866 |  |  | 1,042 |  |
| Operating lease assets | 338 |  |  | 382 |  |
| Investments | 146 |  |  | 209 |  |
| Deferred income taxes | 988 |  |  | 916 |  |
| Goodwill | 2,851 |  |  | 2,565 |  |
| Intangible assets, net | 1,177 |  |  | 1,105 |  |
| Other assets | 552 |  |  | 558 |  |
| Total assets | $ | 11,625 |  |  | $ | 12,189 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |
| Current portion of long-term debt | $ | 1 |  |  | $ | 5 |  |
| Accounts payable | 885 |  |  | 851 |  |
| Contract liabilities | 1,549 |  |  | 1,650 |  |
| Accrued liabilities | 1,333 |  |  | 1,557 |  |
| Total current liabilities | 3,768 |  |  | 4,063 |  |
| Long-term debt | 6,012 |  |  | 5,688 |  |
| Operating lease liabilities | 302 |  |  | 313 |  |
| Other liabilities | 1,937 |  |  | 2,148 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) | (408) |  |  | (40) |  |
| Non-controlling interests | 14 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 11,625 |  |  | $ | 12,189 |  |

[0000068505-22-000030:8k_2_02:121]
13

[0000068505-22-000030:8k_2_02:122]
GAAP-4

[0000068505-22-000030:8k_2_02:123]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:124]
Condensed Consolidated Statements of Cash Flows

[0000068505-22-000030:8k_2_02:125]
(In millions)

[0000068505-22-000030:8k_2_02:126]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| Operating |  |  |  |
| Net earnings | $ | 280 |  |  | $ | 308 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 108 |  |  | 105 |  |
| Non-cash other charges | 1 |  |  | 18 |  |
| Loss on ESN fixed asset impairment | 147 |  |  | — |  |
| Share-based compensation expenses | 45 |  |  | 34 |  |
| Gain on sales of investments and businesses, net | (1) |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (101) |  |  | (32) |  |
| Inventories | (83) |  |  | (46) |  |
| Other current assets and contract assets | (24) |  |  | (270) |  |
| Accounts payable, accrued liabilities and contract liabilities | 116 |  |  | 259 |  |
| Other assets and liabilities | (9) |  |  | (25) |  |
| Deferred income taxes | (91) |  |  | 25 |  |
| Net cash provided by operating activities | 388 |  |  | 376 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (19) |  |  | (351) |  |
| Proceeds from sales of investments and businesses, net | 27 |  |  | 1 |  |
| Capital expenditures | (70) |  |  | (61) |  |
| Net cash used for investing activities | (62) |  |  | (411) |  |
| Financing |  |  |  |
| Repayments of debt | — |  |  | (3) |  |
| Issuances of common stock | 86 |  |  | 39 |  |
| Purchases of common stock | (94) |  |  | (125) |  |
| Payments of dividends | (132) |  |  | (120) |  |
| Net cash used for financing activities | (140) |  |  | (209) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (81) |  |  | (24) |  |
| Net increase (decrease) in total cash and cash equivalents | 105 |  |  | (268) |  |
| Cash and cash equivalents, beginning of period | 717 |  |  | 1,921 |  |
| Cash and cash equivalents, end of period | $ | 822 |  |  | $ | 1,653 |  |

[0000068505-22-000030:8k_2_02:127]
14

[0000068505-22-000030:8k_2_02:128]
GAAP-5

[0000068505-22-000030:8k_2_02:129]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:130]
Condensed Consolidated Statements of Cash Flows

[0000068505-22-000030:8k_2_02:131]
(In millions)

[0000068505-22-000030:8k_2_02:132]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| Operating |  |  |  |
| Net earnings | $ | 777 |  |  | $ | 848 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 331 |  |  | 325 |  |
| Non-cash other charges (income) | 20 |  |  | (6) |  |
| Loss on ESN fixed asset impairment | 147 |  |  | — |  |
| Share-based compensation expenses | 126 |  |  | 94 |  |
| Gain on sales of investments and businesses, net | (3) |  |  | — |  |
| Loss from the extinguishment of long-term debt | 6 |  |  | 18 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 5 |  |  | 189 |  |
| Inventories | (360) |  |  | (99) |  |
| Other current assets and contract assets | (38) |  |  | (136) |  |
| Accounts payable, accrued liabilities and contract liabilities | (183) |  |  | (39) |  |
| Other assets and liabilities | (66) |  |  | (62) |  |
| Deferred income taxes | (212) |  |  | 2 |  |
| Net cash provided by operating activities | 550 |  |  | 1,134 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (590) |  |  | (360) |  |
| Proceeds from sales of investments and businesses, net | 38 |  |  | 4 |  |
| Capital expenditures | (183) |  |  | (175) |  |
| Proceeds from sales of property, plant and equipment | — |  |  | 6 |  |
| Net cash used for investing activities | (735) |  |  | (525) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | 595 |  |  | 844 |  |
| Repayments of debt | (283) |  |  | (351) |  |
| Revolving credit facility renewal fees | — |  |  | (7) |  |
| Issuances of common stock | 137 |  |  | 99 |  |
| Purchases of common stock | (749) |  |  | (397) |  |
| Payments of dividends | (398) |  |  | (362) |  |
| Payments of dividends to non-controlling interests | (6) |  |  | (5) |  |
| Net cash used for financing activities | (704) |  |  | (179) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (163) |  |  | (31) |  |
| Net increase (decrease) in total cash and cash equivalents | (1,052) |  |  | 399 |  |
| Cash and cash equivalents, beginning of period | 1,874 |  |  | 1,254 |  |
| Cash and cash equivalents, end of period | $ | 822 |  |  | $ | 1,653 |  |

[0000068505-22-000030:8k_2_02:133]
15

[0000068505-22-000030:8k_2_02:134]
Non-GAAP-1

[0000068505-22-000030:8k_2_02:135]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:136]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-22-000030:8k_2_02:137]
(In millions)

[0000068505-22-000030:8k_2_02:138]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  |  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 388 |  |  | $ | 376 |  |  | $ | 550 |  |  | $ | 1,134 |  |  |  |  |  |  |  |
| Capital expenditures |  | (70) |  |  | (61) |  |  | (183) |  |  | (175) |  |  |  |  |  |  |  |
| Free cash flow |  | $ | 318 |  |  | $ | 315 |  |  | $ | 367 |  |  | $ | 959 |  |  |  |  |  |  |  |

[0000068505-22-000030:8k_2_02:139]
16

[0000068505-22-000030:8k_2_02:140]
Non-GAAP-2

[0000068505-22-000030:8k_2_02:141]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:142]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-22-000030:8k_2_02:143]
(In millions)

[0000068505-22-000030:8k_2_02:144]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |  |  |  |
|  |  | Statement Line |  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 279 |  |  | $ | 307 |  |  | $ | 774 |  |  | $ | 844 |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss on ESN fixed asset impairment |  | Cost of sales |  | $ | 147 |  |  | $ | — |  |  | $ | 147 |  |  | $ | — |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 63 |  |  | 56 |  |  | 194 |  |  | 172 |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 45 |  |  | 34 |  |  | 126 |  |  | 94 |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 15 |  |  | 8 |  |  | 25 |  |  | 18 |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 14 |  |  | 4 |  |  | 31 |  |  | 29 |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (Income) |  | 12 |  |  | — |  |  | 23 |  |  | 3 |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 5 |  |  | 18 |  |  | 35 |  |  | 5 |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 4 |  |  | — |  |  | 16 |  |  | 7 |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 2 |  |  | 2 |  |  | 16 |  |  | 6 |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | 1 |  |  | — |  |  | 12 |  |  | — |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | 1 |  |  | 1 |  |  | (1) |  |  | (9) |  |  |  |  |  |  |  |
| Loss from extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | — |  |  | 6 |  |  | 18 |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | — |  |  | 1 |  |  | — |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | — |  |  | (13) |  |  | — |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | (21) |  |  | — |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (1) |  |  | — |  |  | (3) |  |  | — |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 308 |  |  | $ | 123 |  |  | $ | 594 |  |  | $ | 343 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 73 |  | 21 |  | 206 |  | 95 |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 235 |  | 102 |  | 388 |  | 248 |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 514 |  |  | $ | 408 |  |  | $ | 1,162 |  |  | $ | 1,092 |  |  |  |  |  |  |  |

[0000068505-22-000030:8k_2_02:145]
Calculation of Non-GAAP Tax Rate

[0000068505-22-000030:8k_2_02:146]
(In millions)

[0000068505-22-000030:8k_2_02:147]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |  |
|  |  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |  |  |
| Net earnings before income taxes |  | $ | 333 |  |  | $ | 405 |  |  | $ | 852 |  |  | $ | 1,034 |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 308 |  |  | 123 |  |  | 594 |  |  | 343 |  |  |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 641 |  |  | 528 |  |  | 1,446 |  |  | 1,377 |  |  |  |  |  |  |  |
| Income tax expense |  | 53 |  |  | 97 |  |  | 75 |  |  | 186 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 73 |  |  | 21 |  |  | 206 |  |  | 95 |  |  |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | 126 |  |  | 118 |  |  | 281 |  |  | 281 |  |  |  |  |  |  |  |
| Non-GAAP Tax rate |  | 19.7 | % |  | 22.4 | % |  | 19.4 | % |  | 20.4 | % |  |  |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |  |  |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-22-000030:8k_2_02:148]
17

[0000068505-22-000030:8k_2_02:149]
Non-GAAP-2

[0000068505-22-000030:8k_2_02:150]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-22-000030:8k_2_02:151]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |  |  |  |
|  |  | Statement Line |  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 1.63 |  |  | $ | 1.76 |  |  | $ | 4.50 |  |  | $ | 4.87 |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss on ESN fixed asset impairment |  | Cost of sales |  | $ | 0.86 |  |  | $ | — |  |  | $ | 0.86 |  |  | $ | — |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.37 |  |  | 0.32 |  |  | 1.13 |  |  | 0.99 |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 0.26 |  |  | 0.20 |  |  | 0.73 |  |  | 0.54 |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.09 |  |  | 0.05 |  |  | 0.15 |  |  | 0.10 |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.08 |  |  | 0.02 |  |  | 0.18 |  |  | 0.17 |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (Income) |  | 0.07 |  |  | — |  |  | 0.14 |  |  | 0.02 |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 0.03 |  |  | 0.10 |  |  | 0.21 |  |  | 0.03 |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.02 |  |  | — |  |  | 0.09 |  |  | 0.04 |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.01 |  |  | 0.01 |  |  | 0.09 |  |  | 0.03 |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | 0.01 |  |  | — |  |  | 0.07 |  |  | — |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | 0.01 |  |  | 0.01 |  |  | (0.01) |  |  | (0.05) |  |  |  |  |  |  |  |
| Loss from extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | — |  |  | 0.03 |  |  | 0.10 |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | — |  |  | (0.08) |  |  | — |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | (0.12) |  |  | — |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (0.01) |  |  | — |  |  | (0.02) |  |  | — |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 1.80 |  |  | $ | 0.71 |  |  | $ | 3.46 |  |  | $ | 1.97 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.43 |  | 0.12 |  | 1.20 |  | 0.55 |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 1.37 |  | 0.59 |  | 2.26 |  | 1.42 |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 3.00 |  |  | $ | 2.35 |  |  | $ | 6.76 |  |  | $ | 6.29 |  |  |  |  |  |  |  |
| Diluted Weighted Average Common Shares |  |  |  | 171.5 |  |  | 174.1 |  |  | 171.9 |  |  | 173.4 |  |  |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-22-000030:8k_2_02:152]
18

[0000068505-22-000030:8k_2_02:153]
Non-GAAP-3

[0000068505-22-000030:8k_2_02:154]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:155]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-22-000030:8k_2_02:156]
(In millions)

[0000068505-22-000030:8k_2_02:157]
|  |  | Three Months Ended |
|  |  | October 1, 2022 |  | October 2, 2021 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Operating earnings ("OE") |  | $ | 303 |  |  | $ | 70 |  |  | $ | 373 |  |  | $ | 224 |  |  | $ | 227 |  |  | $ | 451 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss on ESN fixed asset impairment |  | — |  |  | 147 |  |  | 147 |  |  | — |  |  | — |  |  | — |  |
| Intangible assets amortization expense |  | 15 |  |  | 48 |  |  | 63 |  |  | 13 |  |  | 43 |  |  | 56 |  |
| Share-based compensation expenses |  | 33 |  |  | 12 |  |  | 45 |  |  | 25 |  |  | 9 |  |  | 34 |  |
| Hytera-related legal expenses |  | 15 |  |  | — |  |  | 15 |  |  | 8 |  |  | — |  |  | 8 |  |
| Reorganization of business charges |  | 3 |  |  | 11 |  |  | 14 |  |  | 3 |  |  | 1 |  |  | 4 |  |
| Legal settlements |  | 3 |  |  | 9 |  |  | 12 |  |  | — |  |  | — |  |  | — |  |
| Operating lease asset impairments |  | 2 |  |  | 2 |  |  | 4 |  |  | — |  |  | — |  |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | 1 |  |  | 2 |  |  | — |  |  | 2 |  |  | 2 |  |
| Fixed asset impairments |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 72 |  |  | 231 |  |  | 303 |  |  | 49 |  |  | 55 |  |  | 104 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 375 |  |  | $ | 301 |  |  | $ | 676 |  |  | $ | 273 |  |  | $ | 282 |  |  | $ | 555 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 19.8 | % |  | 8.3 | % |  | 15.7 | % |  | 16.9 | % |  | 29.1 | % |  | 21.4 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.5 | % |  | 35.7 | % |  | 28.5 | % |  | 20.6 | % |  | 36.0 | % |  | 26.3 | % |

[0000068505-22-000030:8k_2_02:158]
19

[0000068505-22-000030:8k_2_02:159]
Non-GAAP-4

[0000068505-22-000030:8k_2_02:160]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:161]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-22-000030:8k_2_02:162]
(In millions)

[0000068505-22-000030:8k_2_02:163]
|  |  | Nine Months Ended |
|  |  | October 1, 2022 |  | October 2, 2021 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Operating earnings ("OE") |  | $ | 460 |  |  | $ | 510 |  |  | $ | 970 |  |  | $ | 440 |  |  | $ | 678 |  |  | $ | 1,118 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 45 |  |  | 149 |  |  | 194 |  |  | 39 |  |  | 133 |  |  | 172 |  |
| Loss on ESN fixed asset impairment |  | — |  |  | 147 |  |  | 147 |  |  | — |  |  | — |  |  | — |  |
| Share-based compensation expenses |  | 92 |  |  | 34 |  |  | 126 |  |  | 71 |  |  | 23 |  |  | 94 |  |
| Reorganization of business charges |  | 17 |  |  | 14 |  |  | 31 |  |  | 23 |  |  | 6 |  |  | 29 |  |
| Hytera-related legal expenses |  | 25 |  |  | — |  |  | 25 |  |  | 18 |  |  | — |  |  | 18 |  |
| Legal settlements |  | 3 |  |  | 20 |  |  | 23 |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Operating lease asset impairments |  | 13 |  |  | 3 |  |  | 16 |  |  | 5 |  |  | 2 |  |  | 7 |  |
| Acquisition-related transaction fees |  | 8 |  |  | 8 |  |  | 16 |  |  | 1 |  |  | 5 |  |  | 6 |  |
| Fixed asset impairments |  | 9 |  |  | 3 |  |  | 12 |  |  | — |  |  | — |  |  | — |  |
| Gain on Hytera legal settlement |  | (13) |  |  | — |  |  | (13) |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 199 |  |  | 378 |  |  | 577 |  |  | 159 |  |  | 170 |  |  | 329 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 659 |  |  | $ | 888 |  |  | $ | 1,547 |  |  | $ | 599 |  |  | $ | 848 |  |  | $ | 1,447 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 11.7 | % |  | 20.5 | % |  | 15.1 | % |  | 12.4 | % |  | 29.3 | % |  | 19.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 16.8 | % |  | 35.7 | % |  | 24.2 | % |  | 16.9 | % |  | 36.7 | % |  | 24.7 | % |

[0000068505-22-000030:8k_2_02:164]
20

[0000068505-22-000030:8k_2_02:165]
Non-GAAP-5

[0000068505-22-000030:8k_2_02:166]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000030:8k_2_02:167]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-22-000030:8k_2_02:168]
(In millions)

[0000068505-22-000030:8k_2_02:169]
|  |  | Three Months Ended |  |  |
|  |  | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Net sales |  | $ | 2,373 |  |  | $ | 2,107 |  |  | 13 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 32 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,341 |  |  | $ | 2,107 |  |  | 11 | % |

[0000068505-22-000030:8k_2_02:170]
|  |  | Nine Months Ended |  |  |
|  |  | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Net sales |  | $ | 6,405 |  |  | $ | 5,851 |  |  | 9 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 82 |  |  | — |  |  |  |
| Organic revenue |  | $ | 6,323 |  |  | $ | 5,851 |  |  | 8 | % |

[0000068505-22-000030:8k_2_02:171]
21
