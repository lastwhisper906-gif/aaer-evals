# MSI notes — 0000068505-22-000031


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-22-000031:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of October 1, 2022 and for the three and nine months ended October 1, 2022 and October 2, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-22-000031:notes:2]
[same as prior period, unchanged from 0000068505-22-000025:notes:2]

[0000068505-22-000031:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three and nine months ended October 1, 2022 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-22-000031:notes:4]
[same as prior period, unchanged from 0000068505-22-000025:notes:4]

[0000068505-22-000031:notes:5]
[same as prior period, unchanged from 0000068505-22-000025:notes:5]

[0000068505-22-000031:notes:6]
[same as prior period, unchanged from 0000068505-22-000025:notes:6]

[0000068505-22-000031:notes:7]
[same as prior period, unchanged from 0000068505-22-000025:notes:7]

[0000068505-22-000031:notes:8]
[same as prior period, unchanged from 0000068505-22-000025:notes:8]

[0000068505-22-000031:notes:9]
[same as prior period, unchanged from 0000068505-22-000025:notes:9]

[0000068505-22-000031:notes:10]
[same as prior period, unchanged from 0000068505-22-000025:notes:10]

[0000068505-22-000031:notes:11]
Subsequent to quarter end, on October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part the Products and Systems Integration segment.

[0000068505-22-000031:notes:12]
On August 8, 2022, the Company acquired Barrett Communications Pty Ltd ("Barrett Communications"), a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The business is a part of the Products and Systems Integration segment.

[0000068505-22-000031:notes:13]
On May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of the Products and Systems Integration segment.

[0000068505-22-000031:notes:14]
On April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

[0000068505-22-000031:notes:15]
[same as prior period, unchanged from 0000068505-22-000025:notes:13]

[0000068505-22-000031:notes:16]
[same as prior period, unchanged from 0000068505-22-000025:notes:14]

[0000068505-22-000031:notes:17]
[same as prior period, unchanged from 0000068505-22-000025:notes:15]

[0000068505-22-000031:notes:18]
[same as prior period, unchanged from 0000068505-22-000025:notes:16]

[0000068505-22-000031:notes:19]
[same as prior period, unchanged from 0000068505-22-000025:notes:17]

[0000068505-22-000031:notes:20]
Recent Accounting Pronouncements

[0000068505-22-000031:notes:21]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is continuing to evaluate the impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-22-000031:notes:22]
Recently Adopted Accounting Pronouncements

[0000068505-22-000031:notes:23]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the Senior Convertible Notes on diluted earnings per common share.

[0000068505-22-000031:notes:24]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers," which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and

[0000068505-22-000031:notes:25]
disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

[0000068505-22-000031:notes:26]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-22-000031:notes:27]
[same as prior period, unchanged from 0000068505-22-000025:notes:22]

[0000068505-22-000031:notes:28]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 1, 2022 and October 2, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-22-000031:notes:29]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |  | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |
| International | 363 |  |  | 323 |  |  | 686 |  |  | 333 |  |  | 325 |  |  | 658 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |  | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |
| Video Security and Access Control | 286 |  |  | 133 |  |  | 419 |  |  | 214 |  |  | 102 |  |  | 316 |  |
| Command Center Software | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 133 |  |  | 133 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |  | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |
| Indirect | 627 |  |  | 75 |  |  | 702 |  |  | 487 |  |  | 79 |  |  | 566 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |

[0000068505-22-000031:notes:30]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |  | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |
| International | 957 |  |  | 973 |  |  | 1,930 |  |  | 935 |  |  | 970 |  |  | 1,905 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |  | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |
| Video Security and Access Control | 728 |  |  | 368 |  |  | 1,096 |  |  | 590 |  |  | 284 |  |  | 874 |  |
| Command Center Software | — |  |  | 435 |  |  | 435 |  |  | — |  |  | 387 |  |  | 387 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |  | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |
| Indirect | 1,647 |  |  | 228 |  |  | 1,875 |  |  | 1,390 |  |  | 214 |  |  | 1,604 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |

[0000068505-22-000031:notes:31]
[same as prior period, unchanged from 0000068505-22-000025:notes:26]

[0000068505-22-000031:notes:32]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of October 1, 2022 was $9.1 billion. A total of $4.8 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of October 1, 2022, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.3 billion was from Software and Services performance obligations that were not yet satisfied as of October 1, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.4 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-22-000031:notes:33]
[same as prior period, unchanged from 0000068505-22-000025:notes:28]

[0000068505-22-000031:notes:34]
| (In millions) | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,368 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 1,033 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,549 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 327 |  |  | 306 |  |  |  |  |  |

[0000068505-22-000031:notes:35]
Revenue recognized during the three months ended October 1, 2022 which was previously included in Contract liabilities as of July 2, 2022 was $437 million, compared to $472 million of revenue recognized during the three months ended October 2, 2021 which was previously included in Contract liabilities as of July 3, 2021. Revenue recognized during the nine months ended October 1, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $939 million, compared to $946 million recognized during the nine months ended October 2, 2021 which was previously included in Contract liabilities as of December 31, 2020. The Company reversed $3 million of revenue during the three months ended October 1, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $2 million of reversals for the three months ended October 2, 2021, primarily driven by changes in the estimates of progress on system contracts. Revenue of $23 million was reversed during the nine months ended October 1, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the nine months ended October 2, 2021.

[0000068505-22-000031:notes:36]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended October 1, 2022 and October 2, 2021.
Contract Cost Balances

[0000068505-22-000031:notes:37]
| (In millions) | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 52 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 120 |  |  | 124 |  |  |  |  |  |

[0000068505-22-000031:notes:38]
Amortization of non-current contract cost assets was $14 million and $41 million for the three and nine months ended October 1, 2022, respectively, and $12 million and $37 million for the three and nine months ended October 2, 2021, respectively


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-22-000031:notes:39]
Leases
Components of Lease Expense

[0000068505-22-000031:notes:40]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 32 |  |  | $ | 34 |  |  | $ | 98 |  |  | $ | 101 |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 1 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 8 |  |
| Short-term lease cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |
| Variable cost | 9 |  |  | 9 |  |  | 26 |  |  | 27 |  |
| Sublease income | (1) |  |  | (2) |  |  | (4) |  |  | (4) |  |
| Net lease expense | $ | 41 |  |  | $ | 43 |  |  | $ | 126 |  |  | $ | 134 |  |

[0000068505-22-000031:notes:41]
[same as prior period, unchanged from 0000068505-22-000025:notes:37]

[0000068505-22-000031:notes:42]
| (in millions) |  | Statement Line Classification |  | October 1, 2022 |  | December 31, 2021 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 338 |  |  | $ | 382 |  |  |  |
| Finance lease assets |  | Property, plant and equipment, net |  | 10 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 348 |  |  | $ | 398 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 77 |  |  | $ | 124 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 1 |  |  | 4 |  |  |  |
|  |  |  |  | $ | 78 |  |  | $ | 128 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 302 |  |  | $ | 313 |  |  |  |
|  |  |  |  | $ | 302 |  |  | $ | 313 |  |  |  |

[0000068505-22-000031:notes:43]
[same as prior period, unchanged from 0000068505-22-000025:notes:39]

[0000068505-22-000031:notes:44]
|  | Nine Months Ended |  |  |
| (in millions) | October 1, 2022 |  | October 2, 2021 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 124 |  |  | $ | 124 |  |  |  |
| Net cash used for financing activities related to finance leases | 4 |  |  | 9 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 77 |  |  | $ | 31 |  |  |  |

[0000068505-22-000031:notes:45]
The increase in assets obtained in exchange for lease liabilities for the nine months ended October 1, 2022 compared to the nine months ended October 2, 2021 was primarily due to $34 million of additional leases acquired in connection with the Company's acquisition of TETRA Ireland on March 23, 2022.

[0000068505-22-000031:notes:46]
|  | October 1, 2022 |  | December 31, 2021 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 6 |
| Finance leases | 1 |  | 1 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.13 | % |  | 3.11 | % |
| Finance leases | 3.84 | % |  | 3.99 | % |

[0000068505-22-000031:notes:47]
[same as prior period, unchanged from 0000068505-22-000025:notes:43]

[0000068505-22-000031:notes:48]
|  | October 1, 2022 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2022 | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |
| 2023 | 91 |  |  | 1 |  |  | 92 |  |
| 2024 | 77 |  |  | — |  |  | 77 |  |
| 2025 | 63 |  |  | — |  |  | 63 |  |
| 2026 | 50 |  |  | — |  |  | 50 |  |
| Thereafter | 118 |  |  | — |  |  | 118 |  |
| Total lease payments | $ | 417 |  |  | $ | 1 |  |  | $ | 418 |  |
| Less: Interest | 38 |  |  | — |  |  | 38 |  |
| Present value of lease liabilities | $ | 379 |  |  | $ | 1 |  |  | $ | 380 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-22-000031:notes:49]
[same as prior period, unchanged from 0000068505-22-000025:notes:45]

[0000068505-22-000031:notes:50]
[same as prior period, unchanged from 0000068505-22-000025:notes:46]

[0000068505-22-000031:notes:51]
[same as prior period, unchanged from 0000068505-22-000025:notes:47]

[0000068505-22-000031:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 63 |  |  | $ | 56 |  |  | $ | 194 |  |  | $ | 172 |  |
| Legal settlements | 12 |  |  | — |  |  | 23 |  |  | 3 |  |
| Operating lease asset impairments | 4 |  |  | — |  |  | 16 |  |  | 7 |  |
| Acquisition-related transaction fees | 2 |  |  | 2 |  |  | 16 |  |  | 6 |  |
| Reorganization of business (Note 14) | 2 |  |  | 2 |  |  | 14 |  |  | 22 |  |
| Fixed asset impairments | 1 |  |  | — |  |  | 12 |  |  | — |  |
| Gain on Hytera legal settlement | — |  |  | — |  |  | (13) |  |  | — |  |
| Other | (1) |  |  | — |  |  | — |  |  | (1) |  |
|  | $ | 83 |  |  | $ | 60 |  |  | $ | 262 |  |  | $ | 209 |  |

[0000068505-22-000031:notes:53]
In February 2022, the Company recognized a gain of $13 million related to the recovery, through legal proceedings to seize and liquidate assets, of financial receivables owed to the Company by the bankruptcy estate of the two U.S. subsidiaries of Hytera Communications Corporation Limited of Shenzhen, China. Refer also to "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for additional information related to these proceedings.

[0000068505-22-000031:notes:54]
[same as prior period, unchanged from 0000068505-22-000025:notes:50]

[0000068505-22-000031:notes:55]
[same as prior period, unchanged from 0000068505-22-000025:notes:51]

[0000068505-22-000031:notes:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (62) |  |  | $ | (58) |  |  | $ | (179) |  |  | $ | (160) |  |
| Interest income | 2 |  |  | 2 |  |  | 8 |  |  | 6 |  |
|  | $ | (60) |  |  | $ | (56) |  |  | $ | (171) |  |  | (154) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 28 |  |  | $ | 31 |  |  | $ | 91 |  |  | $ | 91 |  |
| Loss from the extinguishment of long-term debt (Note 5) | — |  |  | — |  |  | (6) |  |  | (18) |  |
| Investment impairments | — |  |  | — |  |  | (1) |  |  | — |  |
| Foreign currency gain | 45 |  |  | 5 |  |  | 95 |  |  | 13 |  |
| Loss on derivative instruments (Note 6) | (54) |  |  | (10) |  |  | (111) |  |  | (19) |  |
| Gain (loss) on equity method investments | — |  |  | 1 |  |  | (2) |  |  | 5 |  |
| Fair value adjustments to equity investments | (5) |  |  | (18) |  |  | (35) |  |  | (5) |  |
| Gain on TETRA Ireland equity method investment | — |  |  | — |  |  | 21 |  |  | — |  |
| Other | 5 |  |  | 1 |  |  | (2) |  |  | 3 |  |
|  | $ | 19 |  |  | $ | 10 |  |  | $ | 50 |  |  | $ | 70 |  |

[0000068505-22-000031:notes:57]
The Company previously held a minority ownership interest in TETRA Ireland, and, upon acquisition of 100% of the equity of TETRA Ireland on March 23, 2022, recorded a $21 million gain to adjust the Company's initial equity method investment to fair value during the nine months ended October 1, 2022. Refer to Note 15, "Intangible Assets and Goodwill" to the Company's condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for further information related to this acquisition.

[0000068505-22-000031:notes:58]
[same as prior period, unchanged from 0000068505-22-000025:notes:54]

[0000068505-22-000031:notes:59]
[same as prior period, unchanged from 0000068505-22-000025:notes:55]

[0000068505-22-000031:notes:60]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 279 |  |  | $ | 307 |  |  | $ | 774 |  |  | $ | 844 |  |
| Weighted average common shares outstanding | 167.2 |  |  | 169.2 |  |  | 167.5 |  |  | 169.3 |  |
| Per share amount | $ | 1.67 |  |  | $ | 1.81 |  |  | $ | 4.62 |  |  | $ | 4.98 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 279 |  |  | $ | 307 |  |  | $ | 774 |  |  | $ | 844 |  |
| Weighted average common shares outstanding | 167.2 |  |  | 169.2 |  |  | 167.5 |  |  | 169.3 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.6 |  |  | 4.3 |  |  | 3.8 |  |  | 3.9 |  |
| 1.75% senior convertible notes | 0.7 |  |  | 0.6 |  |  | 0.6 |  |  | 0.2 |  |
| Diluted weighted average common shares outstanding | 171.5 |  |  | 174.1 |  |  | 171.9 |  |  | 173.4 |  |
| Per share amount | $ | 1.63 |  |  | $ | 1.76 |  |  | $ | 4.50 |  |  | $ | 4.87 |  |

[0000068505-22-000031:notes:61]
In the computation of diluted earnings per common share for the three months ended October 1, 2022, the assumed exercise of 0.4 million options, including 0.2 million subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the nine months ended October 1, 2022, the assumed exercise of 0.2 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-22-000031:notes:62]
In the computation of diluted earnings per common share for the three months ended October 2, 2021, no shares were considered anti-dilutive. In the computation of diluted earnings per common share for the nine months ended October 2, 2021, the assumed exercise of 0.2 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-22-000031:notes:63]
As of October 1, 2022, the Company had $1.0 billion of the Senior Convertible Notes outstanding, which mature on September 15, 2024. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, when the average stock price exceeded the contractual conversion price, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the quarter ended October 2, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended October 1, 2022. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of October 1, 2022 was $189 million.

[0000068505-22-000031:notes:64]
[same as prior period, unchanged from 0000068505-22-000025:notes:60]

[0000068505-22-000031:notes:65]
[same as prior period, unchanged from 0000068505-22-000025:notes:61]

[0000068505-22-000031:notes:66]
[same as prior period, unchanged from 0000068505-22-000025:notes:62]

[0000068505-22-000031:notes:67]
|  | October 1, 2022 |  | December 31, 2021 |
| Accounts receivable | $ | 1,433 |  |  | $ | 1,456 |  |
| Less allowance for credit losses | (65) |  |  | (70) |  |
|  | $ | 1,368 |  |  | $ | 1,386 |  |

[0000068505-22-000031:notes:68]
[same as prior period, unchanged from 0000068505-22-000025:notes:64]

[0000068505-22-000031:notes:69]
[same as prior period, unchanged from 0000068505-22-000025:notes:65]

[0000068505-22-000031:notes:70]
|  | October 1, 2022 |  | December 31, 2021 |
| Finished goods | $ | 352 |  |  | $ | 268 |  |
| Work-in-process and production materials | 924 |  |  | 643 |  |
|  | 1,276 |  |  | 911 |  |
| Less inventory reserves | (119) |  |  | (123) |  |
|  | $ | 1,157 |  |  | $ | 788 |  |

[0000068505-22-000031:notes:71]
[same as prior period, unchanged from 0000068505-22-000025:notes:67]

[0000068505-22-000031:notes:72]
[same as prior period, unchanged from 0000068505-22-000025:notes:68]

[0000068505-22-000031:notes:73]
|  | October 1, 2022 |  | December 31, 2021 |
| Current contract cost assets (Note 2) | $ | 52 |  |  | $ | 30 |  |
| Tax-related deposits | 35 |  |  | 41 |  |
| Other | 240 |  |  | 188 |  |
|  | $ | 327 |  |  | $ | 259 |  |

[0000068505-22-000031:notes:74]
[same as prior period, unchanged from 0000068505-22-000025:notes:70]

[0000068505-22-000031:notes:75]
[same as prior period, unchanged from 0000068505-22-000025:notes:71]

[0000068505-22-000031:notes:76]
|  | October 1, 2022 |  | December 31, 2021 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 445 |  |  | 474 |  |
| Machinery and equipment | 2,232 |  |  | 2,439 |  |
|  | 2,682 |  |  | 2,918 |  |
| Less accumulated depreciation | (1,816) |  |  | (1,876) |  |
|  | $ | 866 |  |  | $ | 1,042 |  |

[0000068505-22-000031:notes:77]
During the third quarter of 2022, the Company began negotiations with the Home Office of the United Kingdom (the "Home Office") regarding an early exit by the Company from the Emergency Services Network ("ESN") communications systems contract, inclusive of twelve months of transition services. As a result of the negotiations, the Company determined that the future service potential of the asset is limited, based on the Company's intention to terminate the contract in advance of the contracted service term. During the three months ended October 1, 2022, the Company recorded a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN service contract with the Home Office based on its current expectation that, more likely than not, the ESN long-lived asset group will be disposed of significantly before the end of its previously estimated useful life. The recognized impairment loss represents the amount by which the carrying amount of the asset group exceeded the fair value as of October 1, 2022, under a measurement of discounted cash flows. The impairment loss was recorded in the Software and Services segment within cost of sales in the Condensed Consolidated Statements of Operations.

[0000068505-22-000031:notes:78]
Depreciation expense for the three months ended October 1, 2022 and October 2, 2021 was $45 million and $49 million, respectively. Depreciation expense for the nine months ended October 1, 2022 and October 2, 2021 was $137 million and $153 million, respectively.

[0000068505-22-000031:notes:79]
[same as prior period, unchanged from 0000068505-22-000025:notes:74]

[0000068505-22-000031:notes:80]
[same as prior period, unchanged from 0000068505-22-000025:notes:75]

[0000068505-22-000031:notes:81]
|  | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Common stock | $ | 23 |  |  | $ | 69 |  |  |  |  |  |
| Strategic investments | 43 |  |  | 35 |  |  |  |  |  |
| Company-owned life insurance policies | 67 |  |  | 81 |  |  |  |  |  |
| Equity method investments | 13 |  |  | 24 |  |  |  |  |  |
|  | $ | 146 |  |  | $ | 209 |  |  |  |  |  |

[0000068505-22-000031:notes:82]
On July 16, 2021, the Company paid $50 million for equity securities of NewHold Investment Corp. ("NHIC"), a special purpose acquisition company (SPAC) that completed a business combination with Evolv Technologies, Inc. After the business combination, NHIC was renamed “Evolv Technologies Holdings, Inc.” (together with its subsidiaries, “Evolv”). During the nine months ended October 1, 2022, the Company recognized a loss of $14 million in Other income (expense) within the Condensed Consolidated Statements of Operations related to a decrease in the fair value of the investment.

[0000068505-22-000031:notes:83]
During the nine months ended October 1, 2022, the Company sold $12 million of equity securities and recognized a loss of $10 million in Other income (expense) within the Condensed Consolidated Statements of Operations, related to a decrease in the fair value related to an investment in a business operating in the critical infrastructure market.

[0000068505-22-000031:notes:84]
[same as prior period, unchanged from 0000068505-22-000025:notes:78]

[0000068505-22-000031:notes:85]
[same as prior period, unchanged from 0000068505-22-000025:notes:79]

[0000068505-22-000031:notes:86]
|  | October 1, 2022 |  | December 31, 2021 |
| Defined benefit plan assets | $ | 370 |  |  | $ | 365 |  |
| Non-current contract cost assets (Note 2) | 120 |  |  | 124 |  |
| Other | 62 |  |  | 69 |  |
|  | $ | 552 |  |  | $ | 558 |  |

[0000068505-22-000031:notes:87]
[same as prior period, unchanged from 0000068505-22-000025:notes:81]

[0000068505-22-000031:notes:88]
[same as prior period, unchanged from 0000068505-22-000025:notes:82]

[0000068505-22-000031:notes:89]
|  | October 1, 2022 |  | December 31, 2021 |
| Compensation | $ | 257 |  |  | $ | 360 |  |
| Tax liabilities | 176 |  |  | 183 |  |
| Dividend payable | 132 |  |  | 134 |  |
| Trade liabilities | 162 |  |  | 235 |  |
| Operating lease liabilities (Note 3) | 77 |  |  | 124 |  |
| Other | 529 |  |  | 521 |  |
|  | $ | 1,333 |  |  | $ | 1,557 |  |

[0000068505-22-000031:notes:90]
[same as prior period, unchanged from 0000068505-22-000025:notes:84]

[0000068505-22-000031:notes:91]
[same as prior period, unchanged from 0000068505-22-000025:notes:85]

[0000068505-22-000031:notes:92]
|  | October 1, 2022 |  | December 31, 2021 |
| Defined benefit plans | $ | 1,219 |  |  | $ | 1,390 |  |
| Non-current contract liabilities (Note 2) | 327 |  |  | 306 |  |
| Unrecognized tax benefits (Note 7) | 35 |  |  | 36 |  |
| Deferred income taxes (Note 7) | 129 |  |  | 183 |  |
| Environmental reserve | 108 |  |  | 108 |  |
| Other | 119 |  |  | 125 |  |
|  | $ | 1,937 |  |  | $ | 2,148 |  |

[0000068505-22-000031:notes:93]
[same as prior period, unchanged from 0000068505-22-000025:notes:87]

[0000068505-22-000031:notes:94]
Share Repurchase Program: During the three and nine months ended October 1, 2022, the Company paid an aggregate of $94 million, and $749 million, including transaction costs, to repurchase approximately 0.4 million and 3.3 million shares at an average price of $236.46 and $224.35 per share, respectively. As of October 1, 2022, the Company had $1.4 billion of authority available for future repurchases.

[0000068505-22-000031:notes:95]
Payment of Dividends: During the three months ended October 1, 2022 and October 2, 2021, the Company paid $132 million and $120 million, respectively, in cash dividends to holders of its common stock. During the nine months ended October 1, 2022 and October 2, 2021, the Company paid $398 and $362 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $132 million in cash dividends to holders of its common stock.

[0000068505-22-000031:notes:96]
[same as prior period, unchanged from 0000068505-22-000025:notes:90]

[0000068505-22-000031:notes:97]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended October 1, 2022 and October 2, 2021:

[0000068505-22-000031:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (539) |  |  | $ | (335) |  |  | $ | (384) |  |  | $ | (360) |  |
| Other comprehensive income (loss) before reclassification adjustment | (153) |  |  | (47) |  |  | (304) |  |  | (24) |  |
| Tax benefit (expense) | (9) |  |  | 3 |  |  | (13) |  |  | 5 |  |
| Other comprehensive income (loss), net of tax | (162) |  |  | (44) |  |  | (317) |  |  | (19) |  |
| Balance at end of period | $ | (701) |  |  | $ | (379) |  |  | $ | (701) |  |  | $ | (379) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,952) |  |  | $ | (2,053) |  |  | $ | (1,995) |  |  | $ | (2,086) |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | 17 |  |  | — |  |
| Tax expense | — |  |  | — |  |  | (3) |  |  | — |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | 14 |  |  | — |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 20 |  |  | 22 |  |  | 60 |  |  | 65 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | (1) |  |  | (2) |  |  | (3) |  |  | (6) |  |
| Tax expense | (4) |  |  | (4) |  |  | (13) |  |  | (10) |  |
| Reclassification adjustment into Net earnings, net of tax | 15 |  |  | 16 |  |  | 44 |  |  | 49 |  |
| Other comprehensive income, net of tax | 15 |  |  | 16 |  |  | 58 |  |  | 49 |  |
| Balance at end of period | $ | (1,937) |  |  | $ | (2,037) |  |  | $ | (1,937) |  |  | $ | (2,037) |  |
| Total Accumulated other comprehensive loss | $ | (2,638) |  |  | $ | (2,416) |  |  | $ | (2,638) |  |  | $ | (2,416) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-22-000031:notes:99]
Debt and Credit Facilities

[0000068505-22-000031:notes:100]
|  | October 1, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 694 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 1 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (1) |  |  | (5) |  |
| Long-term debt | $ | 6,012 |  |  | $ | 5,688 |  |

[0000068505-22-000031:notes:101]
On May 31, 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the Company's 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-22-000031:notes:102]
As of October 1, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 1, 2022.

[0000068505-22-000031:notes:103]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of October 1, 2022 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-22-000031:notes:104]
[same as prior period, unchanged from 0000068505-22-000025:notes:98]

[0000068505-22-000031:notes:105]
The Company had outstanding foreign exchange contracts with notional amounts totaling $887 million and $1.1 billion for the periods ended October 1, 2022 and December 31, 2021, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-22-000031:notes:106]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of October 1, 2022, and the corresponding positions as of December 31, 2021:

[0000068505-22-000031:notes:107]
|  | Notional Amount |
| Net Buy (Sell) by Currency | October 1, 2022 |  | December 31, 2021 |
| British pound | $ | 202 |  |  | $ | 128 |  |
| Euro | 181 |  |  | 164 |  |
| Australian dollar | (101) |  |  | (76) |  |
| Chinese renminbi | (67) |  |  | (89) |  |
| Brazilian real | (34) |  |  | (23) |  |

[0000068505-22-000031:notes:108]
[same as prior period, unchanged from 0000068505-22-000025:notes:102]

[0000068505-22-000031:notes:109]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of October 1, 2022, all of the counterparties had investment grade credit ratings. As of October 1, 2022, the Company had $17 million of exposure to aggregate credit risk with all counterparties.

[0000068505-22-000031:notes:110]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of October 1, 2022 and December 31, 2021:

[0000068505-22-000031:notes:111]
|  | Fair Values of Derivative Instruments |
| October 1, 2022 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 11 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 6 |  |  | 32 |  |
| Total derivatives | $ | 17 |  |  | $ | 32 |  |

[0000068505-22-000031:notes:112]
[same as prior period, unchanged from 0000068505-22-000025:notes:106]

[0000068505-22-000031:notes:113]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended October 1, 2022 and October 2, 2021:

[0000068505-22-000031:notes:114]
|  | Financial Statement Location | Three Months Ended |  | Nine Months Ended |
| Foreign Exchange Contracts | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Effective portion | Accumulated othercomprehensive gain (loss) | $ | 12 |  |  | $ | 7 |  |  | $ | 24 |  |  | $ | 10 |  |
| Forward points recognized | Other income (expense) | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Undesignated derivatives recognized | Other income (expense) | (54) |  |  | (10) |  |  | (111) |  |  | (19) |  |

[0000068505-22-000031:notes:115]
[same as prior period, unchanged from 0000068505-22-000025:notes:109]

[0000068505-22-000031:notes:116]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of October 1, 2022, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £15 million of net investment hedges in a British pound functional subsidiary.

[0000068505-22-000031:notes:117]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. During the nine months ended October 1, 2022 and October 2, 2021, the Company amortized $1 million of income from the excluded components through interest expense, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-22-000031:notes:118]
[same as prior period, unchanged from 0000068505-22-000025:notes:112]

[0000068505-22-000031:notes:119]
[same as prior period, unchanged from 0000068505-22-000025:notes:113]

[0000068505-22-000031:notes:120]
[same as prior period, unchanged from 0000068505-22-000025:notes:114]

[0000068505-22-000031:notes:121]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Net earnings before income taxes | $ | 333 |  |  | $ | 405 |  |  | $ | 852 |  |  | $ | 1,034 |  |
| Income tax expense | 53 |  |  | 97 |  |  | 75 |  |  | 186 |  |
| Effective tax rate | 16 | % |  | 24 | % |  | 9 | % |  | 18 | % |

[0000068505-22-000031:notes:122]
The effective tax rate for the three months ended October 1, 2022 of 16% was lower than the U.S. federal statutory tax rate of 21% primarily due to higher excess tax benefits of share-based compensation. The effective tax rate for the nine months ended October 1, 2022 of 9% was lower than the U.S. federal statutory tax rate of 21% primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights (as described above) and the excess tax benefits of share-based compensation.

[0000068505-22-000031:notes:123]
The effective tax rate for the three months ended October 2, 2021 of 24% was higher than the U.S. federal statutory tax rate of 21% due to state tax expense, offset by the excess tax benefits of share-based compensation. The effective tax rate for the nine months ended October 2, 2021 of 18% was lower than the U.S. federal statutory tax rate of 21% primarily due to a tax benefit related to a partial release of $33 million of a valuation allowance recorded on the U.S. foreign tax credit carryforward and the excess tax benefits of share-based compensation.

[0000068505-22-000031:notes:124]
The effective tax rate for the three months ended October 1, 2022 of 16% was lower than the effective tax rate for the three months ended October 2, 2021 of 24%, primarily due to higher excess tax benefits of share-based compensation in 2022. The effective tax rate for the nine months ended October 1, 2022 of 9% was lower than the effective tax rate for the nine months ended October 2, 2021 of 18%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights 
(as described above) and higher excess tax benefits of share-based compensation in 2022, offset by a tax benefit due to a partial release of a valuation allowance in 2021.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-22-000031:notes:125]
[same as prior period, unchanged from 0000068505-22-000025:notes:118]

[0000068505-22-000031:notes:126]
[same as prior period, unchanged from 0000068505-22-000025:notes:119]

[0000068505-22-000031:notes:127]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 32 |  |  | 29 |  |  | 8 |  |  | 5 |  |  | — |  |  | — |  |
| Expected return on plan assets | (64) |  |  | (59) |  |  | (26) |  |  | (25) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 17 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | (1) |  |  | — |  |  | (1) |  |
| Net periodic pension benefits | $ | (17) |  |  | $ | (13) |  |  | $ | (14) |  |  | $ | (17) |  |  | $ | (2) |  |  | $ | (3) |  |

[0000068505-22-000031:notes:128]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 96 |  |  | 87 |  |  | 24 |  |  | 16 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (191) |  |  | (177) |  |  | (77) |  |  | (75) |  |  | (9) |  |  | (8) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 46 |  |  | 51 |  |  | 11 |  |  | 12 |  |  | 3 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (3) |  |  | (2) |  |  | — |  |  | (4) |  |
| Net periodic pension benefits | $ | (49) |  |  | $ | (39) |  |  | $ | (42) |  |  | $ | (48) |  |  | $ | (5) |  |  | $ | (9) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-22-000031:notes:129]
[same as prior period, unchanged from 0000068505-22-000025:notes:122]

[0000068505-22-000031:notes:130]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 7 |  |  | $ | 4 |  |  | $ | 20 |  |  | $ | 12 |  |
| Selling, general and administrative expenses | 26 |  |  | 22 |  |  | 72 |  |  | 58 |  |
| Research and development expenditures | 12 |  |  | 8 |  |  | 34 |  |  | 24 |  |
| Share-based compensation expense included in Operating earnings | 45 |  |  | 34 |  |  | 126 |  |  | 94 |  |
| Tax benefit | (9) |  |  | (6) |  |  | (26) |  |  | (14) |  |
| Share-based compensation expense, net of tax | $ | 36 |  |  | $ | 28 |  |  | $ | 100 |  |  | $ | 80 |  |
| Decrease in basic earnings per share | $ | (0.22) |  |  | $ | (0.17) |  |  | $ | (0.60) |  |  | $ | (0.47) |  |
| Decrease in diluted earnings per share | $ | (0.21) |  |  | $ | (0.16) |  |  | $ | (0.58) |  |  | $ | (0.46) |  |

[0000068505-22-000031:notes:131]
During the nine months ended October 1, 2022, the Company granted 0.7 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $156

[0000068505-22-000031:notes:132]
million, $17 million and $10 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $8 million and $10 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-22-000031:notes:133]
During the nine months ended October 1, 2022, the Company granted 0.1 million shares of restricted stock with an aggregate grant-date fair value of $10 million to certain key employees of Ava, Calipsa and Videotec in connection with the acquisitions of such entities. The share-based compensation for Ava and Calipsa will each be expensed over an average service period of two years, while the share-based compensation for Videotec will be expensed over an average service period of one year.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-22-000031:notes:134]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of October 1, 2022 and December 31, 2021 were as follows:

[0000068505-22-000031:notes:135]
| October 1, 2022 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 17 |  |  |  |  | $ | 17 |  |
| Common stock | 23 |  |  | — |  |  |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 32 |  |  |  |  | $ | 32 |  |

[0000068505-22-000031:notes:136]
[same as prior period, unchanged from 0000068505-22-000025:notes:128]

[0000068505-22-000031:notes:137]
The Company had no foreign exchange derivative contracts or common stock investments in Level 3 holdings as of October 1, 2022 or December 31, 2021.

[0000068505-22-000031:notes:138]
At October 1, 2022 and December 31, 2021, the Company had $237 million and $685 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-22-000031:notes:139]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of October 1, 2022 was $5.7 billion, of which the Senior Convertible Notes were $1.2 billion (Level 2). The fair value of long-term debt at December 31, 2021 was $6.2 billion (Level 2).

[0000068505-22-000031:notes:140]
[same as prior period, unchanged from 0000068505-22-000025:notes:132]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-22-000031:notes:141]
[same as prior period, unchanged from 0000068505-22-000025:notes:133]

[0000068505-22-000031:notes:142]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended October 1, 2022 and October 2, 2021:

[0000068505-22-000031:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Contract-specific discounting facility | $ | — |  |  | $ | 66 |  |  | $ | 49 |  |  | $ | 173 |  |
| Accounts receivable sales proceeds | — |  |  | 15 |  |  | 62 |  |  | 23 |  |
| Long-term receivables sales proceeds | 42 |  |  | 56 |  |  | 64 |  |  | 140 |  |
| Total proceeds from receivable sales | $ | 42 |  |  | $ | 137 |  |  | $ | 175 |  |  | $ | 336 |  |

[0000068505-22-000031:notes:144]
At October 1, 2022, the Company had retained servicing obligations for $860 million of long-term receivables, compared to $940 million at December 31, 2021. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $127 million at October 1, 2022, compared to $56 million at December 31, 2021. 
During the nine months ended October 1, 2022, the Company completed its final draw against a cost-efficient receivables discounting facility, implemented in 2020 to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe. The proceeds of the Company's receivable sales are included in Operating activities within the Company's Condensed Consolidated Statements of Cash Flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-22-000031:notes:145]
Commitments and Contingencies
Legal Matters

[0000068505-22-000031:notes:146]
Hytera Litigation

[0000068505-22-000031:notes:147]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment.

[0000068505-22-000031:notes:148]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions.

[0000068505-22-000031:notes:149]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Court of Appeals dismissed the notice of appeal on February 16, 2022 after determining that such appeal was premature. On August 2, 2022, after the Court denied the motions described above on July 5, 2022, Hytera filed a renewed notice of appeal in the Court of Appeals. The Company filed its cross-appeal on August 5, 2022.

[0000068505-22-000031:notes:150]
Hytera Bankruptcy Proceedings

[0000068505-22-000031:notes:151]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. The gain was recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-22-000031:notes:152]
[same as prior period, unchanged from 0000068505-22-000025:notes:145]

[0000068505-22-000031:notes:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Products and Systems Integration | $ | 1,529 |  |  | $ | 1,325 |  |  | $ | 3,918 |  |  | $ | 3,538 |  |
| Software and Services | 844 |  |  | 782 |  |  | 2,487 |  |  | 2,313 |  |
|  | $ | 2,373 |  |  | $ | 2,107 |  |  | $ | 6,405 |  |  | $ | 5,851 |  |

[0000068505-22-000031:notes:154]
[same as prior period, unchanged from 0000068505-22-000025:notes:147]

[0000068505-22-000031:notes:155]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Products and Systems Integration | $ | 303 |  |  | $ | 224 |  |  | $ | 460 |  |  | $ | 440 |  |
| Software and Services | 70 |  |  | 227 |  |  | 510 |  |  | 678 |  |
| Operating earnings | 373 |  |  | 451 |  |  | 970 |  |  | 1,118 |  |
| Total other expense | (40) |  |  | (46) |  |  | (118) |  |  | (84) |  |
| Earnings before income taxes | $ | 333 |  |  | $ | 405 |  |  | $ | 852 |  |  | $ | 1,034 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-22-000031:notes:156]
[same as prior period, unchanged from 0000068505-22-000025:notes:149]

[0000068505-22-000031:notes:157]
During the three months ended October 1, 2022, the Company recorded net reorganization of business charges of $14 million, including $2 million of charges in Other charges and $12 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $7 million related to employee separation costs and $10 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-22-000031:notes:158]
During the nine months ended October 1, 2022, the Company recorded net reorganization of business charges of $31 million, including $14 million of charges in Other charges and $17 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $31 million were charges of $30 million related to employee separation costs and $10 million related to exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-22-000031:notes:159]
[same as prior period, unchanged from 0000068505-22-000025:notes:152]

[0000068505-22-000031:notes:160]
| October 1, 2022 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 3 |  |  | $ | 17 |  |
| Software and Services | 11 |  |  | 14 |  |
|  | $ | 14 |  |  | $ | 31 |  |

[0000068505-22-000031:notes:161]
[same as prior period, unchanged from 0000068505-22-000025:notes:154]

[0000068505-22-000031:notes:162]
|  | January 1, 2022 |  | Additional Charges |  | Adjustments |  | Amount Used |  | October 1, 2022 |
| Employee separation costs | $ | 34 |  |  | $ | 30 |  |  | $ | (9) |  |  | $ | (27) |  |  | $ | 28 |  |
| Exit costs | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
|  | $ | 34 |  |  | $ | 40 |  |  | $ | (9) |  |  | $ | (27) |  |  | $ | 38 |  |

[0000068505-22-000031:notes:163]
[same as prior period, unchanged from 0000068505-22-000025:notes:156]

[0000068505-22-000031:notes:164]
At January 1, 2022, the Company had an accrual of $34 million for employee separation costs. The 2022 additional charges of $30 million represent severance costs for approximately 380 employees. The adjustment of $9 million reflects reversals for accruals no longer needed. The $27 million used reflects cash payments to severed employees. The remaining accrual of $28 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at October 1, 2022, is expected to be paid, primarily within one year, to approximately 450 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-22-000031:notes:165]
[same as prior period, unchanged from 0000068505-22-000025:notes:158]

[0000068505-22-000031:notes:166]
During the three months ended October 2, 2021, the Company recorded net reorganization of business charges of $4 million, including $2 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $6 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-22-000031:notes:167]
During the nine months ended October 2, 2021, the Company recorded net reorganization of business charges of $29 million, including $22 million of charges in Other charges and $7 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $29 million were charges of $36 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-22-000031:notes:168]
| October 2, 2021 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 3 |  |  | $ | 23 |  |
| Software and Services | 1 |  |  | 6 |  |
|  | $ | 4 |  |  | $ | 29 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-22-000031:notes:169]
Intangible Assets and Goodwill
Subsequent to quarter end, on October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part of the Products and Systems Integration segment. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-22-000031:notes:170]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The Company recognized $6 million of goodwill and $12 million of net assets. The goodwill is not deductible for tax purposes. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-22-000031:notes:171]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $9 million of goodwill, $6 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-22-000031:notes:172]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The Company recognized $24 million of goodwill, $21 million of identifiable intangible assets, and $6 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $20 million of developed technology and $1 million of customer relationships that will be amortized over a period of fifteen and three years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-22-000031:notes:173]
[same as prior period, unchanged from 0000068505-22-000025:notes:164]

[0000068505-22-000031:notes:174]
[same as prior period, unchanged from 0000068505-22-000025:notes:165]

[0000068505-22-000031:notes:175]
On December 16, 2021, the Company acquired 911 Datamaster, an NG911 data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces Motorola Solutions’ commitment to being a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The Company recognized $21 million of goodwill, $16 million of identifiable intangible assets, and $2 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $9 million of customer relationships and $7 million of developed technology that will be amortized over a period of fourteen years and nine years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts and goodwill may be subject to change.

[0000068505-22-000031:notes:176]
[same as prior period, unchanged from 0000068505-22-000025:notes:167]

[0000068505-22-000031:notes:177]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments of up to $40 million based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. The Company estimated there will be no payout related to the earn-out payments. This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The Company recognized $232 million of goodwill, $73 million of identifiable intangible assets, and $7 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $57 million of developed technology and $16 million of customer relationships that will be amortized over a period of sixteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the third quarter of 2022.

[0000068505-22-000031:notes:178]
[same as prior period, unchanged from 0000068505-22-000025:notes:169]

[0000068505-22-000031:notes:179]
[same as prior period, unchanged from 0000068505-22-000025:notes:170]

[0000068505-22-000031:notes:180]
|  | October 1, 2022 |  | December 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 997 |  |  | $ | 336 |  |  | $ | 828 |  |  | $ | 278 |  |
| Customer-related | 1,299 |  |  | 807 |  |  | 1,367 |  |  | 836 |  |
| Other intangibles | 84 |  |  | 60 |  |  | 84 |  |  | 60 |  |
|  | $ | 2,380 |  |  | $ | 1,203 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-22-000031:notes:181]
Amortization expense on intangible assets was $63 million and $194 million for the three and nine months ended October 1, 2022, respectively. Amortization expense on intangible assets was $56 million and $172 million for the three and nine months ended October 2, 2021, respectively. As of October 1, 2022, annual amortization expense is estimated to be $255 million in 2022, $156 million in 2023, $122 million in 2024, $109 million in 2025, $101 million in 2026, and $92 million in 2027.

[0000068505-22-000031:notes:182]
[same as prior period, unchanged from 0000068505-22-000025:notes:173]

[0000068505-22-000031:notes:183]
|  | October 1, 2022 |  | December 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 898 |  |  | $ | 241 |  |  | $ | 766 |  |  | $ | 184 |  |
| Software and Services | 1,482 |  |  | 962 |  |  | 1,513 |  |  | 990 |  |
|  | $ | 2,380 |  |  | $ | 1,203 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-22-000031:notes:184]
[same as prior period, unchanged from 0000068505-22-000025:notes:175]

[0000068505-22-000031:notes:185]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2022 to October 1, 2022:

[0000068505-22-000031:notes:186]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2022 | $ | 1,236 |  |  | $ | 1,329 |  |  | $ | 2,565 |  |
| Goodwill acquired | 215 |  |  | 143 |  |  | 358 |  |
| Purchase accounting adjustments | 4 |  |  | (26) |  |  | (22) |  |
| Foreign currency | (1) |  |  | (49) |  |  | (50) |  |
| Balance as of October 1, 2022 | $ | 1,454 |  |  | $ | 1,397 |  |  | $ | 2,851 |  |
