# MSI MD&A — 0000068505-22-000031


## mdna

[0000068505-22-000031:mdna:1]
[same as prior period, unchanged from 0000068505-22-000025:mdna:1]

[0000068505-22-000031:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and nine months ended October 1, 2022 and October 2, 2021, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2021 (the "Form 10-K").

[0000068505-22-000031:mdna:3]
[same as prior period, unchanged from 0000068505-22-000025:mdna:3]

[0000068505-22-000031:mdna:4]
[same as prior period, unchanged from 0000068505-22-000025:mdna:4]

[0000068505-22-000031:mdna:5]
[same as prior period, unchanged from 0000068505-22-000025:mdna:5]

[0000068505-22-000031:mdna:6]
[same as prior period, unchanged from 0000068505-22-000025:mdna:6]

[0000068505-22-000031:mdna:7]
[same as prior period, unchanged from 0000068505-22-000025:mdna:7]

[0000068505-22-000031:mdna:8]
[same as prior period, unchanged from 0000068505-22-000025:mdna:8]

[0000068505-22-000031:mdna:9]
[same as prior period, unchanged from 0000068505-22-000025:mdna:9]

[0000068505-22-000031:mdna:10]
[same as prior period, unchanged from 0000068505-22-000025:mdna:28]

[0000068505-22-000031:mdna:11]
Third Quarter Financial Results

[0000068505-22-000031:mdna:12]
•Net sales were $2.4 billion in the third quarter of 2022 compared to $2.1 billion in the third quarter of 2021.

[0000068505-22-000031:mdna:13]
•Operating earnings were $373 million in the third quarter of 2022 compared to $451 million in the third quarter of 2021.

[0000068505-22-000031:mdna:14]
•Net earnings attributable to Motorola Solutions, Inc. were $279 million, or $1.63 per diluted common share, in the third quarter of 2022, compared to $307 million, or $1.76 per diluted common share, in the third quarter of 2021.

[0000068505-22-000031:mdna:15]
•Operating cash flow decreased $584 million to $550 million in the first nine months of 2022 compared to $1.1 billion in the first nine months of 2021.

[0000068505-22-000031:mdna:16]
•We repurchased $749 million of common stock and paid $398 million in dividends in the first nine months of 2022.

[0000068505-22-000031:mdna:17]
[same as prior period, unchanged from 0000068505-22-000025:mdna:16]

[0000068505-22-000031:mdna:18]
During the third quarter of 2022, we continued to operate under challenging market conditions, influenced by events such as those discussed below.

[0000068505-22-000031:mdna:19]
[same as prior period, unchanged from 0000068505-22-000025:mdna:18]

[0000068505-22-000031:mdna:20]
During the first quarter of 2022, in response to Russia's invasion of Ukraine, we suspended all sales, provision of services and shipments of our products to Russia and Belarus. Russia, Ukraine and Belarus do not constitute a material portion of our business. For the year ended December 31, 2021, our net sales in Russia and Belarus were less than $25 million. While we do not anticipate that the current posture of the Russia-Ukraine conflict will materially and adversely affect our results of operations, the conflict is still ongoing and future impacts, including those relating to an escalation of the conflict’s current scope or expansion of the conflict’s economic disruption, could materially and adversely affect our results of operations. During the first nine months of 2022, we indirectly experienced impacts from the Russia-Ukraine conflict (as further described below). The conflict has and may continue to have a significant impact on the global macroeconomic and geopolitical environments, including increased volatility in capital and commodity markets, rapid changes to regulatory conditions (including the use of sanctions), supply chain and operational challenges for multinational corporations, inflationary pressures and an increased risk of cybersecurity incidents. For a more complete discussion of the risks we encounter in our business, please refer to Part I, Item 1A, "Risk Factors" in the Form 10-K and Part II, Item 1A, "Risk Factors" in this Form 10-Q.

[0000068505-22-000031:mdna:21]
[same as prior period, unchanged from 0000068505-22-000025:mdna:20]

[0000068505-22-000031:mdna:22]
Our supply chain has been impacted by global issues related to the effects of the COVID-19 pandemic, the Russia-Ukraine conflict and the inflationary cost environment throughout the first nine months of 2022, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in our supply chain, as well as difficulties and delays in procuring certain semiconductor components. Since the latter part of the fourth quarter of 2021, cost increases have been driven by elevated lead times and increased material costs, in particular the need to purchase semiconductor components from alternative sources, including brokers. We anticipate increased costs to procure materials within the semiconductor market to continue throughout 2022. Further, we anticipate the broader impact of inflationary pressures and increased material and supply chain costs and disruptions to continue throughout 2022. We are closely monitoring our supply chain, including impacts from manufacturing lockdowns related to the spread of COVID-19 in China which continue to disrupt the semiconductor supply market. Accordingly, in the first nine months of 2022 we focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages. We are actively managing our inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to our customers, and we expect to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-22-000031:mdna:23]
In order to combat rising inflation in the U.S., the Federal Reserve has raised interest rates multiple times since the beginning of 2022. The increase in U.S. dollar interest rates and overall market conditions have led to significant strengthening of the U.S. dollar against other global currencies in 2022. The strong U.S. dollar reduced the impact of cash generated from our foreign operations during the first nine months of 2022, driven by revenues and costs that are denominated in foreign currencies, which has negatively impacted, and which we expect to continue to impact, our operating cash flows and net earnings throughout 2022.

[0000068505-22-000031:mdna:24]
Although the macroeconomic environment continued to introduce challenges in the first nine months of 2022, we are encouraged by customer demand for our products and services. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impact to operating margin will be limited throughout 2022. While we are encouraged by strong backlog and growth in our Products and Systems Integration segment in the first nine months of 2022, which we expect to continue to grow for the remainder of 2022, supply constraints continue to impact our business and we expect demand for our products will continue to out-pace our ability to obtain semiconductor component supply throughout 2022. Where appropriate, we have taken pricing actions around our product and service offerings to mitigate our exposure to inflationary pressures on our businesses and benefited from these adjustments during the third quarter of 2022. We expect to further benefit from such adjustments during the fourth quarter of 2022. Further, demand continues to be supported with ongoing sources of government funding. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We experienced the positive impact of the ARPA funding

[0000068505-22-000031:mdna:25]
on our business and results of operations during the first nine months of 2022 and anticipate that the ARPA will continue to have a positive impact throughout the remainder of 2022.

[0000068505-22-000031:mdna:26]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of October 1, 2022. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-22-000031:mdna:27]
Lastly, as a result of the challenging market conditions described above, we evaluated whether there were any impairment indicators as of October 1, 2022, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the third quarter of 2022, we concluded our assets were fairly stated and recoverable.

[0000068505-22-000031:mdna:28]
Recent Events

[0000068505-22-000031:mdna:29]
CMA Update

[0000068505-22-000031:mdna:30]
In October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, our private mobile radio communications network that we acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain. In October 2022, the CMA published a provisional decision with its findings regarding competition and proposed remedies. We disagree with the CMA’s provisional decision and will continue to work with the CMA to demonstrate the value of the Airwave network and protect Airwave’s contractual position.

[0000068505-22-000031:mdna:31]
ESN Matters

[0000068505-22-000031:mdna:32]
During the third quarter of 2022, we began negotiations with the Home Office of the United Kingdom (the "Home Office") regarding an early exit by us from the Emergency Services Network ("ESN") communications systems contract, inclusive of twelve months of transition services. As a result of the negotiations, we determined that the future service potential of the asset is limited, based on our intention to terminate the contract in advance of the contracted service term. During the three months ended October 1, 2022, we recorded a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN service contract with the Home Office based on our current expectation that, more likely than not, the ESN long-lived asset group will be disposed of significantly before the end of its previously estimated useful life. The recognized impairment loss represents the amount by which the carrying amount of the asset group exceeded the fair value as of October 1, 2022, under a measurement of discounted cash flows. The impairment loss was recorded in the Software and Services segment within cost of sales in the Condensed Consolidated Statements of Operations.

[0000068505-22-000031:mdna:33]
Inflation Reduction Act

[0000068505-22-000031:mdna:34]
On August 16, 2022, the Inflation Reduction Act of 2022 ("IRA") was enacted into law in the United States. Included in the IRA is a provision to implement a 15% corporate alternative minimum tax on corporations based on "adjusted financial statement income," which would be effective for tax years beginning after December 31, 2022. We are continuing to evaluate the provisions of the IRA, but we do not believe the IRA will have a material impact on our financial results, including the effective tax rate.

[0000068505-22-000031:mdna:35]
31

[0000068505-22-000031:mdna:36]
[same as prior period, unchanged from 0000068505-22-000025:mdna:26]

[0000068505-22-000031:mdna:37]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| LMR Communications | Products and Systems Integration | Barrett Communications Pty Ltd | Provider of specialized radio communications. | $18 million | August 8, 2022 |
| Video Security and Access Control | Products and Systems Integration | Videotec S.p.A. | Provider of ruggedized video security solutions. | $23 million and share-based compensation of $4 million | May 12, 2022 |
| Video Security and Access Control | Software and Services | Calipsa, Inc. | Provider of cloud-native advanced video analytics. | $39 million and share-based compensation of $4 million | April 19, 2022 |
| LMR Communications | Software and Services | TETRA Ireland Communications Limited | Provider of Ireland's National Digital Radio Service. | $120 million | March 23, 2022 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Ava Security Limited | Provider of cloud-native video security and analytics. | $388 million and share-based awards of $7 million | March 3, 2022 |
| Command Center Software | Software and Services | 911 Datamaster, Inc. | Provider of Next Generation 911 data solutions that help to ensure emergency calls are accurately located and routed based on the caller's location. | $35 million and share-based compensation of $3 million | December 16, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Envysion, Inc. | Provider of enterprise video security and business analytics. | $124 million and share-based compensation of $1 million | October 29, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Openpath Security, Inc. | Provider of cloud-based mobile access control. | $298 million and share-based compensation of $29 million | July 15, 2021 |

[0000068505-22-000031:mdna:38]
32

[0000068505-22-000031:mdna:39]
[same as prior period, unchanged from 0000068505-22-000025:mdna:29]

[0000068505-22-000031:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | October 1, 2022 |  | % ofSales* |  | October 2, 2021 |  | % ofSales* |  | October 1, 2022 |  | % ofSales* |  | October 2, 2021 |  | % ofSales* |
| Net sales from products | $ | 1,439 |  |  |  |  | $ | 1,221 |  |  |  |  | $ | 3,697 |  |  |  |  | $ | 3,250 |  |  |  |
| Net sales from services | 934 |  |  |  |  | 886 |  |  |  |  | 2,708 |  |  |  |  | 2,601 |  |  |  |
| Net sales | 2,373 |  |  |  |  | 2,107 |  |  |  |  | 6,405 |  |  |  |  | 5,851 |  |  |  |
| Costs of products sales | 659 |  |  | 45.8 | % |  | 559 |  |  | 45.8 | % |  | 1,844 |  |  | 49.9 | % |  | 1,516 |  |  | 46.6 | % |
| Costs of services sales | 683 |  |  | 73.1 | % |  | 503 |  |  | 56.8 | % |  | 1,683 |  |  | 62.1 | % |  | 1,478 |  |  | 56.8 | % |
| Costs of sales | 1,342 |  |  |  |  | 1,062 |  |  |  |  | 3,527 |  |  |  |  | 2,994 |  |  |  |
| Gross margin | 1,031 |  |  | 43.4 | % |  | 1,045 |  |  | 49.6 | % |  | 2,878 |  |  | 44.9 | % |  | 2,857 |  |  | 48.8 | % |
| Selling, general and administrative expenses | 378 |  |  | 15.9 | % |  | 351 |  |  | 16.7 | % |  | 1,069 |  |  | 16.7 | % |  | 985 |  |  | 16.8 | % |
| Research and development expenditures | 197 |  |  | 8.3 | % |  | 183 |  |  | 8.7 | % |  | 577 |  |  | 9.0 | % |  | 545 |  |  | 9.3 | % |
| Other charges | 83 |  |  | 3.5 | % |  | 60 |  |  | 2.8 | % |  | 262 |  |  | 4.1 | % |  | 209 |  |  | 3.6 | % |
| Operating earnings | 373 |  |  | 15.7 | % |  | 451 |  |  | 21.4 | % |  | 970 |  |  | 15.1 | % |  | 1,118 |  |  | 19.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (60) |  |  | (2.5) | % |  | (56) |  |  | (2.7) | % |  | (171) |  |  | (2.7) | % |  | (154) |  |  | (2.6) | % |
| Gains on sales of investments and businesses, net | 1 |  |  | — | % |  | — |  |  | — | % |  | 3 |  |  | — | % |  | — |  |  | — | % |
| Other, net | 19 |  |  | 0.8 | % |  | 10 |  |  | 0.5 | % |  | 50 |  |  | 0.8 | % |  | 70 |  |  | 1.2 | % |
| Total other expense | (40) |  |  | (1.7) | % |  | (46) |  |  | (2.2) | % |  | (118) |  |  | (1.8) | % |  | (84) |  |  | (1.4) | % |
| Net earnings before income taxes | 333 |  |  | 14.0 | % |  | 405 |  |  | 19.2 | % |  | 852 |  |  | 13.3 | % |  | 1,034 |  |  | 17.7 | % |
| Income tax expense | 53 |  |  | 2.2 | % |  | 97 |  |  | 4.6 | % |  | 75 |  |  | 1.2 | % |  | 186 |  |  | 3.2 | % |
| Net earnings | 280 |  |  | 11.8 | % |  | 308 |  |  | 14.6 | % |  | 777 |  |  | 12.1 | % |  | 848 |  |  | 14.5 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | — | % |  | 3 |  |  | — | % |  | 4 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 279 |  |  | 11.8 | % |  | $ | 307 |  |  | 14.6 | % |  | $ | 774 |  |  | 12.1 | % |  | $ | 844 |  |  | 14.4 | % |
| Earnings per diluted common share | $ | 1.63 |  |  |  |  | $ | 1.76 |  |  |  |  | $ | 4.50 |  |  |  |  | $ | 4.87 |  |  |  |

[0000068505-22-000031:mdna:41]
[same as prior period, unchanged from 0000068505-22-000025:mdna:31]

[0000068505-22-000031:mdna:42]
[same as prior period, unchanged from 0000068505-22-000025:mdna:98]

[0000068505-22-000031:mdna:43]
Results of Operations—Three months ended October 1, 2022 compared to three months ended October 2, 2021

[0000068505-22-000031:mdna:44]
The results of operations for the third quarter of 2022 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-22-000031:mdna:45]
[same as prior period, unchanged from 0000068505-22-000025:mdna:35]

[0000068505-22-000031:mdna:46]
[same as prior period, unchanged from 0000068505-22-000025:mdna:36]

[0000068505-22-000031:mdna:47]
[same as prior period, unchanged from 0000068505-22-000025:mdna:37]

[0000068505-22-000031:mdna:48]
[same as prior period, unchanged from 0000068505-22-000025:mdna:38]

[0000068505-22-000031:mdna:49]
[same as prior period, unchanged from 0000068505-22-000025:mdna:39]

[0000068505-22-000031:mdna:50]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |  | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |
| International | 363 |  |  | 323 |  |  | 686 |  |  | 333 |  |  | 325 |  |  | 658 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |  | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |
| Video Security and Access Control | 286 |  |  | 133 |  |  | 419 |  |  | 214 |  |  | 102 |  |  | 316 |  |
| Command Center Software | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 133 |  |  | 133 |  |
| Total | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Operating earnings | $ | 303 |  |  | $ | 70 |  |  | $ | 373 |  |  | $ | 224 |  |  | $ | 227 |  |  | $ | 451 |  |
| Operating margins | 19.8 | % |  | 8.3 | % |  | 15.7 | % |  | 16.9 | % |  | 29.1 | % |  | 21.4 | % |

[0000068505-22-000031:mdna:51]
[same as prior period, unchanged from 0000068505-22-000025:mdna:41]

[0000068505-22-000031:mdna:52]
The Products and Systems Integration segment’s net sales represented 64% of our net sales in the third quarter of 2022 and 63% in the third quarter of 2021. The Software and Services segment’s net sales represented 36% of our net sales in the third quarter of 2022 and 37% in the third quarter of 2021.

[0000068505-22-000031:mdna:53]
Net sales increased $266 million, or 13%, in the third quarter of 2022 compared to the third quarter of 2021. The $204 million, or 15%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 18% in the North America region and an increase of 9% in the International region. The $62 million, or 8%, increase in net sales within the Software and Services segment was driven by an increase of 14% in the North America region and consistent net sales in the International region. Net sales includes:

[0000068505-22-000031:mdna:54]
•an increase in the Products and Systems Integration segment, inclusive of $13 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-22-000031:mdna:55]
•an increase in the Software and Services segment, inclusive of $19 million of revenue from acquisitions, driven by an increase in Video, LMR Services and Command Center Software;

[0000068505-22-000031:mdna:56]
•inclusive of $66 million from unfavorable currency rates.

[0000068505-22-000031:mdna:57]
[same as prior period, unchanged from 0000068505-22-000025:mdna:47]

[0000068505-22-000031:mdna:58]
•a 16% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center Software; and

[0000068505-22-000031:mdna:59]
•a 4%  increase in the International region, inclusive of revenue from acquisitions, driven by an increase in Video, LMR and Command Center Software.

[0000068505-22-000031:mdna:60]
[same as prior period, unchanged from 0000068505-22-000025:mdna:50]

[0000068505-22-000031:mdna:61]
The 15% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000031:mdna:62]
•$132 million, or 12% growth in LMR, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-22-000031:mdna:63]
•$72 million, or 34% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-22-000031:mdna:64]
•inclusive of $28 million from unfavorable currency rates.

[0000068505-22-000031:mdna:65]
[same as prior period, unchanged from 0000068505-22-000025:mdna:55]

[0000068505-22-000031:mdna:66]
The 8% increase in the Software and Services segment was driven by the following:

[0000068505-22-000031:mdna:67]
•$31 million, or 30% growth in Video, inclusive of revenue from acquisitions, driven primarily by the North America region;

[0000068505-22-000031:mdna:68]
•$22 million, or 4% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region and partially offset by the International region; and

[0000068505-22-000031:mdna:69]
•$9 million, or 7% growth in Command Center Software, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-22-000031:mdna:70]
•inclusive of $38 million from unfavorable currency rates.

[0000068505-22-000031:mdna:71]
[same as prior period, unchanged from 0000068505-22-000025:mdna:61]

[0000068505-22-000031:mdna:72]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Gross margin | $ | 1,031 |  |  | $ | 1,045 |  |  | (1) | % |

[0000068505-22-000031:mdna:73]
Gross margin was 43.4% of net sales in the third quarter of 2022 compared to 49.6% in the third quarter of 2021. The primary drivers of this decrease in gross margin as a percentage of net sales were:

[0000068505-22-000031:mdna:74]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN service contract with the Home Office and higher reorganization costs; partially offset by

[0000068505-22-000031:mdna:75]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by pricing actions and volume leverage, partially offset by increased direct material costs.

[0000068505-22-000031:mdna:76]
[same as prior period, unchanged from 0000068505-22-000025:mdna:66]

[0000068505-22-000031:mdna:77]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Selling, general and administrative expenses | $ | 378 |  |  | $ | 351 |  |  | 8 | % |

[0000068505-22-000031:mdna:78]
SG&A expenses increased 8% in the third quarter of 2022 compared to the third quarter of 2021. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses and higher Hytera-related legal expenses. SG&A expenses were 15.9% of net sales in the third quarter of 2022 compared to 16.7% of net sales in the third quarter of 2021.

[0000068505-22-000031:mdna:79]
[same as prior period, unchanged from 0000068505-22-000025:mdna:69]

[0000068505-22-000031:mdna:80]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Research and development expenditures | $ | 197 |  |  | $ | 183 |  |  | 8 | % |

[0000068505-22-000031:mdna:81]
R&D expenditures increased 8% in the third quarter of 2022 compared to the third quarter of 2021 primarily due to an investment in R&D and higher expenses associated with acquired businesses. R&D expenditures decreased to 8.3% of net sales in the third quarter of 2022 compared to 8.7% of net sales in the third quarter of 2021.

[0000068505-22-000031:mdna:82]
[same as prior period, unchanged from 0000068505-22-000025:mdna:72]

[0000068505-22-000031:mdna:83]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Other charges | $ | 83 |  |  | $ | 60 |  |

[0000068505-22-000031:mdna:84]
Other charges increased by $23 million in the third quarter of 2022 compared to the third quarter of 2021. The change was driven primarily by the following:

[0000068505-22-000031:mdna:85]
•$12 million of legal settlement charges in the third quarter of 2022 that did not occur in the third quarter of 2021;

[0000068505-22-000031:mdna:86]
•$63 million of intangible asset amortization expense in the third quarter of 2022 compared to $56 million of intangible asset amortization expense in the third quarter of 2021;

[0000068505-22-000031:mdna:87]
•$4 million of operating lease asset impairments in the third quarter of 2022 that did not occur in the third quarter of 2021; and

[0000068505-22-000031:mdna:88]
•$1 million of fixed asset impairments in the third quarter of 2022 that did not occur in the third quarter of 2021.

[0000068505-22-000031:mdna:89]
[same as prior period, unchanged from 0000068505-22-000025:mdna:81]

[0000068505-22-000031:mdna:90]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Operating earnings from Products and Systems Integration | $ | 303 |  |  | $ | 224 |  |
| Operating earnings from Software and Services | 70 |  |  | 227 |  |
| Operating earnings | $ | 373 |  |  | $ | 451 |  |

[0000068505-22-000031:mdna:91]
Operating earnings decreased $78 million, or 17%, in the third quarter of 2022 compared to the third quarter of 2021. The decrease in Operating earnings was due to:

[0000068505-22-000031:mdna:92]
•$157 million decrease in the Software and Services segment, primarily driven by a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN service contract with the Home Office, higher reorganization costs and higher legal settlement costs; partially offset by

[0000068505-22-000031:mdna:93]
•$79 million increase in the Products and Systems Integration segment, driven by higher gross margin contribution and partially offset by higher expenses associated with acquired businesses, higher share-based compensation and higher Hytera-related legal expenses.

[0000068505-22-000031:mdna:94]
[same as prior period, unchanged from 0000068505-22-000025:mdna:86]

[0000068505-22-000031:mdna:95]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Interest expense, net | $ | (60) |  |  | $ | (56) |  |

[0000068505-22-000031:mdna:96]
The $4 million increase in Interest expense, net in the third quarter of 2022 compared to the third quarter of 2021 was primarily driven by higher outstanding debt.

[0000068505-22-000031:mdna:97]
[same as prior period, unchanged from 0000068505-22-000025:mdna:89]

[0000068505-22-000031:mdna:98]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Other, net | $ | 19 |  |  | $ | 10 |  |

[0000068505-22-000031:mdna:99]
The $9 million increase in Other, net in the third quarter of 2022 compared to the third quarter of 2021 was primarily driven by:

[0000068505-22-000031:mdna:100]
•$45 million of foreign currency gains in the third quarter of 2022 compared to $5 million of foreign currency gains in the third quarter of 2021;

[0000068505-22-000031:mdna:101]
•$5 million loss on fair value adjustments to equity investments in the third quarter of 2022 compared to a $18 million loss on fair value adjustments to equity investments in the third quarter of 2021; and

[0000068505-22-000031:mdna:102]
•$5 million gain in other income in the third quarter of 2022 compared to a $1 million gain in other income in the third quarter of 2021; partially offset by

[0000068505-22-000031:mdna:103]
•$54 million loss on derivatives in the third quarter of 2022 compared to a $10 million loss on derivatives in the third quarter of 2021;

[0000068505-22-000031:mdna:104]
•$28 million of net periodic pension and postretirement benefit in the third quarter of 2022 compared to $31 million of net periodic pension and postretirement benefit in the third quarter of 2021; and

[0000068505-22-000031:mdna:105]
•$1 million gain on equity method investments in the third quarter of 2021 that did not occur in the third quarter of 2022.

[0000068505-22-000031:mdna:106]
[same as prior period, unchanged from 0000068505-22-000025:mdna:100]

[0000068505-22-000031:mdna:107]
|  | Three Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Income tax expense | $ | 53 |  |  | $ | 97 |  |

[0000068505-22-000031:mdna:108]
Income tax expense decreased by $44 million in the third quarter of 2022 compared to the third quarter of 2021, resulting in an effective tax rate of 16%. Our effective tax rate for the three months ended October 1, 2022 of 16% was lower than the effective tax rate for the three months ended October 2, 2021 of 24%, primarily due to higher excess tax benefits of share-based compensation in 2022.

[0000068505-22-000031:mdna:109]
Results of Operations—Nine months ended October 1, 2022 compared to Nine months ended October 2, 2021

[0000068505-22-000031:mdna:110]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |  | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |
| International | 957 |  |  | 973 |  |  | 1,930 |  |  | 935 |  |  | 970 |  |  | 1,905 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |  | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |
| Video Security and Access Control | 728 |  |  | 368 |  |  | 1,096 |  |  | 590 |  |  | 284 |  |  | 874 |  |
| Command Center Software | — |  |  | 435 |  |  | 435 |  |  | — |  |  | 387 |  |  | 387 |  |
| Total | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Operating earnings | 460 |  |  | 510 |  |  | 970 |  |  | 440 |  |  | 678 |  |  | 1,118 |  |
| Operating margins | 11.7 | % |  | 20.5 | % |  | 15.1 | % |  | 12.4 | % |  | 29.3 | % |  | 19.1 | % |

[0000068505-22-000031:mdna:111]
[same as prior period, unchanged from 0000068505-22-000025:mdna:105]

[0000068505-22-000031:mdna:112]
The Products and Systems Integration segment's net sales represented 61% of our net sales in the first nine months of 2022 and 60% in the first nine months of 2021. Net sales from the Software and Services segment represented 39% of our net sales in the first nine months of 2022 and 40% in the first nine months of 2021.

[0000068505-22-000031:mdna:113]
Net sales increased $554 million, or 9%, in the first nine months of 2022 compared to the first nine months of 2021. The $380 million, or 11%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 14% in the North America region and an increase of 2% in the International region. The $174 million, or 8%, increase in net sales within the Software and Services segment was driven by an increase of 13% in the North America region and consistent net sales in the International region. Net sales includes:

[0000068505-22-000031:mdna:114]
•an increase in the Products and Systems Integration segment, inclusive of $33 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-22-000031:mdna:115]
•an increase in Software and Services, inclusive of $49 million of revenue from acquisitions, driven by an increase in Video, Command Center Software and LMR services;

[0000068505-22-000031:mdna:116]
•inclusive of $128 million from unfavorable currency rates.

[0000068505-22-000031:mdna:117]
[same as prior period, unchanged from 0000068505-22-000025:mdna:111]

[0000068505-22-000031:mdna:118]
[same as prior period, unchanged from 0000068505-22-000025:mdna:48]

[0000068505-22-000031:mdna:119]
•a 1% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in Video and Command Center Software.

[0000068505-22-000031:mdna:120]
[same as prior period, unchanged from 0000068505-22-000025:mdna:114]

[0000068505-22-000031:mdna:121]
The 11% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000031:mdna:122]
•$242 million, or 8% growth in LMR, inclusive of revenue from acquisitions, primarily driven by the North America region; and

[0000068505-22-000031:mdna:123]
•$138 million, or 23% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-22-000031:mdna:124]
•inclusive of $54 million from unfavorable currency rates.

[0000068505-22-000031:mdna:125]
[same as prior period, unchanged from 0000068505-22-000025:mdna:119]

[0000068505-22-000031:mdna:126]
The 8% increase in the Software and Services segment was driven by the following:

[0000068505-22-000031:mdna:127]
•$84 million, or 30% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-22-000031:mdna:128]
•$48 million, or 12% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-22-000031:mdna:129]
•$42 million, or 3% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-22-000031:mdna:130]
•inclusive of $74 million from unfavorable currency rates.

[0000068505-22-000031:mdna:131]
[same as prior period, unchanged from 0000068505-22-000025:mdna:125]

[0000068505-22-000031:mdna:132]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Gross margin | $ | 2,878 |  |  | $ | 2,857 |  |  | 1 | % |

[0000068505-22-000031:mdna:133]
Gross margin was 44.9% of net sales in the first nine months of 2022 compared to 48.8% in the first nine months of 2021. The primary drivers of this decrease in gross margin as a percentage of net sales were:

[0000068505-22-000031:mdna:134]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN service contract with the Home Office and a change in year-over-year mix; and

[0000068505-22-000031:mdna:135]
•lower gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by an increase in material and freight costs and partially offset by price increases and volume leverage.

[0000068505-22-000031:mdna:136]
[same as prior period, unchanged from 0000068505-22-000025:mdna:130]

[0000068505-22-000031:mdna:137]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Selling, general and administrative expenses | $ | 1,069 |  |  | $ | 985 |  |  | 9 | % |

[0000068505-22-000031:mdna:138]
SG&A expenses increased 9% in the first nine months of 2022 compared to the first nine months of 2021. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses, higher travel expenses and higher share-based compensation. SG&A expenses were 16.7% of net sales in the first nine months of 2022 compared to 16.8% of net sales in the first nine months of 2021.

[0000068505-22-000031:mdna:139]
[same as prior period, unchanged from 0000068505-22-000025:mdna:133]

[0000068505-22-000031:mdna:140]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |  | % Change |
| Research and development expenditures | $ | 577 |  |  | $ | 545 |  |  | 6 | % |

[0000068505-22-000031:mdna:141]
R&D expenditures increased 6% in the first nine months of 2022 compared to the first nine months of 2021 primarily due to higher expenses associated with acquired businesses, an investment in R&D and higher share-based compensation. R&D expenditures decreased to 9.0% of net sales in the first nine months of 2022 compared to 9.3% of net sales in the first nine months of 2021.

[0000068505-22-000031:mdna:142]
[same as prior period, unchanged from 0000068505-22-000025:mdna:136]

[0000068505-22-000031:mdna:143]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Other charges | $ | 262 |  |  | $ | 209 |  |

[0000068505-22-000031:mdna:144]
Other charges increased by $53 million in the first nine months of 2022 compared to the first nine months of 2021. The change was driven primarily by the following:

[0000068505-22-000031:mdna:145]
•$194 million of intangible asset amortization expense in the first nine months of 2022 compared to $172 million of intangible asset amortization expense in the first nine months of 2021;

[0000068505-22-000031:mdna:146]
•$23 million of losses on legal settlements in the first nine months of 2022 compared to $3 million of losses on legal settlements in the first nine months of 2021;

[0000068505-22-000031:mdna:147]
•$12 million of fixed asset impairments in the first nine months of 2022 that did not occur in the first nine months of 2021;

[0000068505-22-000031:mdna:148]
•$16 million of acquisition-related transaction fees in the first nine months of 2022 compared to $6 million of acquisition-related transaction fees in the first nine months of 2021; and

[0000068505-22-000031:mdna:149]
•$16 million of operating lease asset impairments in the first nine months of 2022 compared to $7 million of operating lease asset impairments in the first nine months of 2021; partially offset by

[0000068505-22-000031:mdna:150]
•$13 million gain on recoveries from the legal settlement under the Hytera bankruptcy proceedings in the first nine months of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q), that did not occur in the first nine months of 2021; and

[0000068505-22-000031:mdna:151]
•$14 million of net reorganization business charges in the first nine months of 2022 compared to $22 million of net reorganization business charges in the first nine months of 2021 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q).

[0000068505-22-000031:mdna:152]
[same as prior period, unchanged from 0000068505-22-000025:mdna:146]

[0000068505-22-000031:mdna:153]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Operating earnings from Products and Systems Integration | $ | 460 |  |  | $ | 440 |  |
| Operating earnings from Software and Services | 510 |  |  | 678 |  |
| Operating earnings | $ | 970 |  |  | $ | 1,118 |  |

[0000068505-22-000031:mdna:154]
Operating earnings decreased $148 million, or 13%, in the first nine months of 2022 compared to the first nine months of 2021. The decrease in Operating earnings was due to:

[0000068505-22-000031:mdna:155]
•$168 million decrease in the Software and Services segment, primarily driven by a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN service contract with the Home Office, higher expenses associated with acquired businesses, higher expenses related to legal settlements and a change in year-over-year mix; partially offset by

[0000068505-22-000031:mdna:156]
•$20 million increase in the Products and Systems Integration segment, primarily driven by pricing actions, and partially offset by higher expenses related to material and freight costs, higher expenses associated with acquired businesses, higher share-based compensation and higher travel expenses.

[0000068505-22-000031:mdna:157]
[same as prior period, unchanged from 0000068505-22-000025:mdna:151]

[0000068505-22-000031:mdna:158]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Interest expense, net | $ | (171) |  |  | $ | (154) |  |

[0000068505-22-000031:mdna:159]
The $17 million increase in net interest expense in the first nine months of 2022 compared to the first nine months of 2021 was a result of the reversal of a non-cash interest accrual related to an international tax audit recorded in the first nine months of 2021 and higher outstanding debt.

[0000068505-22-000031:mdna:160]
[same as prior period, unchanged from 0000068505-22-000025:mdna:155]

[0000068505-22-000031:mdna:161]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Other, net | $ | 50 |  |  | $ | 70 |  |

[0000068505-22-000031:mdna:162]
The $20 million decrease in Other, net in the first nine months of 2022 compared to the first nine months of 2021 was primarily driven by:

[0000068505-22-000031:mdna:163]
•$111 million of losses on derivative instruments in the first nine months of 2022 compared to $19 million of losses on derivative instruments in the first nine months of 2021;

[0000068505-22-000031:mdna:164]
•$35 million loss on fair value adjustments to equity investments in the first nine months of 2022 compared to a $5 million loss on fair value adjustments to equity investments in the first nine months of 2021;

[0000068505-22-000031:mdna:165]
•$2 million loss in other income in the first nine months of 2022 compared to a $3 million gain in other income in the first nine months of 2021; and

[0000068505-22-000031:mdna:166]
•$1 million of investment impairments in the first nine months of 2022 that did not occur in the first nine months of 2021; partially offset by

[0000068505-22-000031:mdna:167]
•$95 million of foreign currency gains in the first nine months of 2022 compared to $13 million of foreign currency gains in the first nine months of 2021;

[0000068505-22-000031:mdna:168]
• $19 million gain on equity method investments in the first nine months of 2022, primarily driven by a $21 million gain on the TETRA Ireland equity method investment, compared to a $5 million gain on equity method investments in the third quarter of 2021 (see further detail in "Other Charges" in Note 4, "Other Financial Data" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q); and

[0000068505-22-000031:mdna:169]
•$6 million loss on the extinguishment of long-term debt in the first nine months of 2022 compared to a $18 million loss on the extinguishment of long-term debt in the first nine months of 2021.

[0000068505-22-000031:mdna:170]
[same as prior period, unchanged from 0000068505-22-000025:mdna:166]

[0000068505-22-000031:mdna:171]
|  | Nine Months Ended |
| (In millions) | October 1, 2022 |  | October 2, 2021 |
| Income tax expense | $ | 75 |  |  | $ | 186 |  |

[0000068505-22-000031:mdna:172]
Income tax expense decreased by $111 million in the first nine months of 2022 compared to the first nine months of 2021, resulting in an effective tax rate of 9%. Our effective tax rate of 9% for the nine months ended October 1, 2022 was lower than the effective tax rate for the nine months ended October 2, 2021 of 18%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain intellectual property rights and higher excess tax benefits of share-based compensation in 2022, offset by a tax benefit due to a partial release of a valuation allowance in 2021 (see Note 7, "Income Taxes" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for further information).

[0000068505-22-000031:mdna:173]
[same as prior period, unchanged from 0000068505-22-000025:mdna:169]

[0000068505-22-000031:mdna:174]
During the third quarter of 2022, we recorded net reorganization of business charges of $14 million, including $2 million of charges recorded within Other charges and $12 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $7 million related to employee separation costs and $10 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-22-000031:mdna:175]
During the first nine months of 2022, we recorded net reorganization of business charges of $31 million, including $14 million of charges recorded within Other charges and $17 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $31 million were charges of $30 million related to employee separation costs and $10 million related to exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-22-000031:mdna:176]
During the third quarter of 2021, we recorded net reorganization of business charges of $4 million, including $2 million of charges in Other charges and $2 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $6 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-22-000031:mdna:177]
During the first nine months of 2021, we recorded net reorganization of business charges of $29 million, including $22 million of charges in Other charges and $7 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $29 million were charges of $36 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-22-000031:mdna:178]
[same as prior period, unchanged from 0000068505-22-000025:mdna:174]

[0000068505-22-000031:mdna:179]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Products and Systems Integration | $ | 3 |  |  | $ | 3 |  |  | $ | 17 |  |  | $ | 23 |  |
| Software and Services | 11 |  |  | 1 |  |  | 14 |  |  | 6 |  |
|  | $ | 14 |  |  | $ | 4 |  |  | $ | 31 |  |  | $ | 29 |  |

[0000068505-22-000031:mdna:180]
Cash payments for employee severance in connection with the reorganization of business plans were $27 million in the first nine months of 2022 and $70 million in the first nine months of 2021. The reorganization of business accrual at October 1, 2022 was $28 million related to employee separation costs that are expected to be paid within one year.

[0000068505-22-000031:mdna:181]
[same as prior period, unchanged from 0000068505-22-000025:mdna:177]

[0000068505-22-000031:mdna:182]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 550 |  |  | $ | 1,134 |  |
| Investing activities | (735) |  |  | (525) |  |
| Financing activities | (704) |  |  | (179) |  |
| Effect of exchange rates on cash and cash equivalents | (163) |  |  | (31) |  |
| Increase (decrease) in cash and cash equivalents | $ | (1,052) |  |  | $ | 399 |  |

[0000068505-22-000031:mdna:183]
[same as prior period, unchanged from 0000068505-22-000025:mdna:179]

[0000068505-22-000031:mdna:184]
At October 1, 2022, $469 million of the $822 million cash and cash equivalents balance was held in the U.S. and $353 million was held in other countries, with $62 million held in the United Kingdom.

[0000068505-22-000031:mdna:185]
[same as prior period, unchanged from 0000068505-22-000025:mdna:181]

[0000068505-22-000031:mdna:186]
The decrease in cash flows provided by operating activities from the first nine months of 2021 to the first nine months of 2022 was driven primarily by higher working capital due to an increase in inventory, higher employee incentive payments and higher cash taxes.

[0000068505-22-000031:mdna:187]
[same as prior period, unchanged from 0000068505-22-000025:mdna:183]

[0000068505-22-000031:mdna:188]
The increase in cash flows used for investing activities in the first nine months of 2022 compared to the first nine months of 2021 was primarily due to a $230 million increase in cash used for acquisitions and investments.

[0000068505-22-000031:mdna:189]
[same as prior period, unchanged from 0000068505-22-000025:mdna:185]

[0000068505-22-000031:mdna:190]
The increase in cash flows used for financing activities in the first nine months of 2022 compared to the first nine months of 2021 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-22-000031:mdna:191]
•$352 million increase in share repurchases in the first nine months of 2022 compared to the first nine months of 2021;

[0000068505-22-000031:mdna:192]
•$249 million decrease in net proceeds from issuance of debt in the first nine months of 2022 compared to the first nine months of 2021; and

[0000068505-22-000031:mdna:193]
•$36 million increase in the payment of dividends in the first nine months of 2022 compared to the first nine months of 2021; partially offset by

[0000068505-22-000031:mdna:194]
•$68 million decrease in repayments of debt in the first nine months of 2022 compared to the first nine months of 2021;

[0000068505-22-000031:mdna:195]
•$38 million increase in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first nine months of 2022 compared to the first nine months of 2021; and

[0000068505-22-000031:mdna:196]
•$7 million related to the payment of revolving credit facility renewal fees in the first nine months of 2021 that did not occur in the first nine months of 2022.

[0000068505-22-000031:mdna:197]
[same as prior period, unchanged from 0000068505-22-000025:mdna:193]

[0000068505-22-000031:mdna:198]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended October 1, 2022 and October 2, 2021:

[0000068505-22-000031:mdna:199]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |
| Contract-specific discounting facility | $ | — |  |  | $ | 66 |  |  | $ | 49 |  |  | $ | 173 |  |
| Accounts receivable sales proceeds | — |  |  | 15 |  |  | $ | 62 |  |  | $ | 23 |  |
| Long-term receivables sales proceeds | 42 |  |  | 56 |  |  | 64 |  |  | 140 |  |
| Total proceeds from receivable sales | $ | 42 |  |  | $ | 137 |  |  | $ | 175 |  |  | $ | 336 |  |

[0000068505-22-000031:mdna:200]
During the nine months ended October 1, 2022, we completed the final draw against a cost-efficient receivables discounting facility, implemented in 2020 to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe. The proceeds of our receivable sales are included in Operating activities within our Condensed Consolidated Statements of Cash Flows.

[0000068505-22-000031:mdna:201]
[same as prior period, unchanged from 0000068505-22-000025:mdna:197]

[0000068505-22-000031:mdna:202]
We had outstanding debt of $6.0 billion and $5.7 billion at October 1, 2022 and December 31, 2021, including the current portions of $1 million and $5 million, at October 1, 2022 and December 31, 2021, respectively.

[0000068505-22-000031:mdna:203]
On May 31, 2022, we issued $600 million of 5.6% senior notes due 2032. We recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of our 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, we recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-22-000031:mdna:204]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of October 1, 2022.

[0000068505-22-000031:mdna:205]
[same as prior period, unchanged from 0000068505-22-000025:mdna:201]

[0000068505-22-000031:mdna:206]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of October 1, 2022 we had no outstanding debt under the commercial paper program.

[0000068505-22-000031:mdna:207]
[same as prior period, unchanged from 0000068505-22-000025:mdna:203]

[0000068505-22-000031:mdna:208]
During the three and nine months ended October 1, 2022, we paid an aggregate of $94 million and $749 million, respectively, including transaction costs, to repurchase approximately 0.4 million and 3.3 million shares at an average price of $236.46 and $224.35 per share. As of October 1, 2022, we had used approximately $14.6 billion of the share repurchase authority to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-22-000031:mdna:209]
[same as prior period, unchanged from 0000068505-22-000025:mdna:205]

[0000068505-22-000031:mdna:210]
During the third quarter of 2022 we paid $132 million in cash dividends to holders of our common stock. During the first nine months of 2022 we paid $398 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $132 million in cash dividends to holders of our common stock.

[0000068505-22-000031:mdna:211]
[same as prior period, unchanged from 0000068505-22-000025:mdna:207]

[0000068505-22-000031:mdna:212]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash

[0000068505-22-000031:mdna:213]
42

[0000068505-22-000031:mdna:214]
provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement.

[0000068505-22-000031:mdna:215]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer also to the “Macroeconomic Events” section in this Part I, Item 2 of this Form 10-Q for a discussion of the impact of macroeconomic events on our liquidity.

[0000068505-22-000031:mdna:216]
[same as prior period, unchanged from 0000068505-22-000025:mdna:211]

[0000068505-22-000031:mdna:217]
We had outstanding commitments to provide long-term financing to third parties totaling $127 million at October 1, 2022, compared to $56 million at December 31, 2021.

[0000068505-22-000031:mdna:218]
[same as prior period, unchanged from 0000068505-22-000025:mdna:213]

[0000068505-22-000031:mdna:219]
See "Recent Accounting Pronouncements" and “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
