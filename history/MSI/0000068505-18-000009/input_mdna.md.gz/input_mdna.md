# MSI MD&A — 0000068505-18-000009


## mdna

[0000068505-18-000009:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-18-000009:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2017 and 2016 and results of operations for each of the three years in the period ended December 31, 2017. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-18-000009:mdna:3]
Executive Overview

[0000068505-18-000009:mdna:4]
Our Business

[0000068505-18-000009:mdna:5]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety, and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 15,000 employees worldwide based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-18-000009:mdna:6]
We conduct our business globally and manage it by two segments:

[0000068505-18-000009:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In 2017, the segment’s net sales were $3.8 billion, representing 59% of our consolidated net sales.

[0000068505-18-000009:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services and SaaS offerings are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2017, the segment’s net sales were $2.6 billion, representing 41% of our consolidated net sales.

[0000068505-18-000009:mdna:9]
Trends Affecting Our Business

[0000068505-18-000009:mdna:10]
Impact of Macroeconomic Conditions: The stronger U.S. dollar and weakening economic conditions had a negative impact on sales throughout 2015 and 2016, particularly in Latin America, parts of Europe, and China. During that time, the strengthening dollar reduced the purchasing power of our customers, and economic challenges negatively impacted government and commercial budgets in these regions. While economic conditions in parts of the world stabilized in 2017 in contrast to the prior year, we expect continued political and economic uncertainty, in particular with the United Kingdom’s planned exit from the European Union (commonly referred to as “Brexit”), and in parts of Latin America and Europe.

[0000068505-18-000009:mdna:11]
Focus on Managed & Support Services and Software: Services continues to grow at a faster rate than the Products segment, driven by acquisitions as well as growth in Managed & Support services absent of acquisitions. While Services generally have lower gross margins than our Products segment, we expect revenue growth will continue to drive operating margin expansion. During the year ended December 31, 2017, our Services segment grew by 9%.

[0000068505-18-000009:mdna:12]
In addition, we continue to invest in software through internal development and strategic acquisitions, as our customers increasingly demand expanded technology solutions that are delivered via software and related services. This includes mobile applications and software in the Command Center that provide enhanced capabilities such as analytics and predictive intelligence. In some cases, government funding or mandates help drive this software expansion, such as Next Generation 9-1-1 funding in the United States, and Public Safety LTE investment in the United States, United Kingdom, and other countries. This evolving trend provides a growth opportunity for us.

[0000068505-18-000009:mdna:13]
Recent Developments

[0000068505-18-000009:mdna:14]
On February 1, 2018, we announced our intention to purchase Avigilon Corporation, a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of approximately $1.3 billion Canadian dollars. The acquisition is expected to be completed in the second quarter of 2018.

[0000068505-18-000009:mdna:15]
On July 28, 2017, we announced our intention to purchase Plant Holdings, Inc., the parent company of Airbus DS Communications. This acquisition will expand our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1. The acquisition is expected to be completed in the first quarter of 2018.

[0000068505-18-000009:mdna:16]
25

[0000068505-18-000009:mdna:17]
Recent Changes to U.S. Tax Law

[0000068505-18-000009:mdna:18]
On December 22, 2017, the U.S. Tax Cuts and Jobs Act (the “Tax Act”) was enacted into law. The Tax Act contains broad and complex provisions including, but not limited to: (i) the reduction of corporate income tax rate from 35% to 21%, (ii) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries, (iii) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries, (iv) modifying limitation on excessive employee remuneration, (v) requiring current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations, (vi) repeal of corporate alternative minimum tax (“AMT”) and changing how AMT credits can be realized, (vii) creating a new minimum tax, (viii) creating a new limitation on deductible interest expense, (ix) changing rules related to uses and limitations of net operating loss carryforwards and foreign tax credits created in tax years beginning after December 31, 2017, and (x) eliminating the deduction for income attributable to domestic production activities.

[0000068505-18-000009:mdna:19]
As required under U.S. GAAP, the effects of tax law changes are recognized in the period of enactment. Accordingly, we have recorded incremental income tax expense in the amount of $874 million associated with the Tax Act during the year ended December 31, 2017.

[0000068505-18-000009:mdna:20]
Change in Presentation

[0000068505-18-000009:mdna:21]
During the first quarter of 2017, we restructured our regions to combine the North America and Latin America regions into one region which is now reflected as the Americas. Accordingly, we now report net sales in the following three geographic regions: the Americas, Europe, Middle East and Africa ("EMEA"), and Asia Pacific ("AP"). We have updated all periods presented to reflect this change in presentation.

[0000068505-18-000009:mdna:22]
2017 financial results

[0000068505-18-000009:mdna:23]
| • | Ended 2017 with a record backlog position of $9.6 billion, up 15% compared to 2016 |

[0000068505-18-000009:mdna:24]
| • | Net sales were $6.4 billion in 2017 compared to $6.0 billion in 2016 and grew in every region |

[0000068505-18-000009:mdna:25]
| • | Operating earnings were $1.3 billion in 2017, compared to $1.1 billion in 2016 |

[0000068505-18-000009:mdna:26]
| • | Recorded an $874 million tax expense due to U.S. tax reform |

[0000068505-18-000009:mdna:27]
| • | Loss from continuing operations was $155 million, or $0.95 per diluted common share in 2017, compared to earnings of $560 million, or $3.24 per diluted common share in 2016 |

[0000068505-18-000009:mdna:28]
| • | Operating cash flow increased $181 million to $1.3 billion in 2017 |

[0000068505-18-000009:mdna:29]
| • | Returned $790 million of capital in the form of $483 million in share repurchases and $307 million in dividends in 2017 and invested $298 million in acquisitions |

[0000068505-18-000009:mdna:30]
| • | Increased our quarterly dividend by 11% to $0.52 per share in November 2017 |

[0000068505-18-000009:mdna:31]
Financial results for our two segments in 2017

[0000068505-18-000009:mdna:32]
| • | In the Products segment, net sales were $3.8 billion in 2017, an increase of $123 million, or 3%, compared to $3.6 billion in 2016. On a geographic basis, net sales increased in every region, compared to 2016. Operating earnings were $914 million in 2017, compared to $734 million in 2016. Operating margin increased in 2017 to 24.2% from 20.1% in 2016. |

[0000068505-18-000009:mdna:33]
| • | In the Services segment, net sales were $2.6 billion in 2017, an increase of $219 million, or 9%, compared to $2.4 billion in 2016. On a geographic basis, net sales increased in every region, compared to 2016. Managed & Support services grew 12% primarily driven by the acquisitions of Airwave, Spillman Technologies, Interexport and Kodiak Networks. Operating earnings were $368 million in 2017, compared to $333 million in 2016. Operating margin increased in 2017 to 14.1% from 13.9% in 2016. |

[0000068505-18-000009:mdna:34]
Looking Forward

[0000068505-18-000009:mdna:35]
Entering 2018, we believe we are well-positioned to compete moving forward. We have a broad, compelling products and services portfolio specifically tailored for our mission-critical communications customer base that spans many layers of governments, public safety, and first responders, as well as commercial and industrial customers in a number of key verticals. As we add new products, features, and software upgrades, we ensure our solutions are interoperable and backward-compatible, enabling customers to confidently invest for their future needs while allowing them to utilize their prior investment in our technology.

[0000068505-18-000009:mdna:36]
Supplementing our traditional core business is our investment in our Managed & Support services business and software solutions in the Command Center. As communication networks have become increasingly complex, software-centric, and data-driven, we have shifted our offerings to align with this technology trend in serving our customers. We expect to continue to see growing demand for our Managed & Support services going forward. These services offerings help customers manage, support, and upgrade their networks as well as utilize features, applications, and data in new ways, including predictive policing, proactive support, or smarter response strategies. We expect our overall revenue mix to continue to shift towards software and services over time. We expanded our software solutions and services portfolios in 2017 with the acquisitions of Kodiak Networks and Interexport, respectively.

[0000068505-18-000009:mdna:37]
Another key technology trend complementing our existing business is the expanded use of broadband LTE by our customers. We have been proactively investing in next-generation public safety broadband solutions for years, as we believe public safety LTE solutions are the next-generation tool for our public safety first-responder customers. We believe our expertise in both public and private networks makes us uniquely qualified to provide these public safety broadband solutions to this customer base. We have now won the four largest public safety LTE network installations awarded to date and expect LTE sales to represent a larger portion of our revenue in the coming years.

[0000068505-18-000009:mdna:38]
We remain committed to driving shareholder value with revenue growth, operating leverage, cash flow generation, and efficient capital deployment. Our framework for efficient capital deployment of cash flow from operations consists of approximately: (i) 50% for acquisitions or share repurchases, (ii) 30% for dividends, and (iii) 20% for investments in the business through capital expenditures. We expect to continue a balanced approach in allocating capital through this framework. Our share repurchase program has approximately $1.7 billion of authority available as of December 31, 2017.

[0000068505-18-000009:mdna:39]
27

[0000068505-18-000009:mdna:40]
Results of Operations

[0000068505-18-000009:mdna:41]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2017 |  | % ofSales ** |  | 2016 |  | % ofSales ** |  | 2015 |  | % ofSales ** |
| Net sales from products | $ | 3,772 |  |  |  |  | $ | 3,649 |  |  |  |  | $ | 3,676 |  |  |  |
| Net sales from services | 2,608 |  |  |  |  | 2,389 |  |  |  |  | 2,019 |  |  |  |
| Net sales | 6,380 |  |  |  |  | 6,038 |  |  |  |  | 5,695 |  |  |  |
| Costs of product sales | 1,686 |  |  | 44.7 | % |  | 1,649 |  |  | 45.2 | % |  | 1,625 |  |  | 44.2 | % |
| Costs of services sales | 1,670 |  |  | 64.0 | % |  | 1,520 |  |  | 63.6 | % |  | 1,351 |  |  | 66.9 | % |
| Costs of sales | 3,356 |  |  | 52.6 | % |  | 3,169 |  |  | 52.5 | % |  | 2,976 |  |  | 52.3 | % |
| Gross margin | 3,024 |  |  | 47.4 | % |  | 2,869 |  |  | 47.5 | % |  | 2,719 |  |  | 47.7 | % |
| Selling, general and administrative expenses | 979 |  |  | 15.3 | % |  | 1,000 |  |  | 16.6 | % |  | 1,021 |  |  | 17.9 | % |
| Research and development expenditures | 568 |  |  | 8.9 | % |  | 553 |  |  | 9.2 | % |  | 620 |  |  | 10.9 | % |
| Other charges | 195 |  |  | 3.1 | % |  | 249 |  |  | 4.1 | % |  | 84 |  |  | 1.5 | % |
| Operating earnings | 1,282 |  |  | 20.1 | % |  | 1,067 |  |  | 17.7 | % |  | 994 |  |  | 17.5 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (201 | ) |  | (3.2 | )% |  | (205 | ) |  | (3.4 | )% |  | (173 | ) |  | (3.0 | )% |
| Gains (losses) on sales of investments and businesses, net | 3 |  |  | — | % |  | (6 | ) |  | (0.1 | )% |  | 107 |  |  | 1.9 | % |
| Other | (8 | ) |  | (0.1 | )% |  | (12 | ) |  | (0.2 | )% |  | (11 | ) |  | (0.2 | )% |
| Total other expense | (206 | ) |  | (3.2 | )% |  | (223 | ) |  | (3.7 | )% |  | (77 | ) |  | (1.4 | )% |
| Earnings from continuing operations before income taxes | 1,076 |  |  | 16.9 | % |  | 844 |  |  | 14.0 | % |  | 917 |  |  | 16.1 | % |
| Income tax expense | 1,227 |  |  | 19.2 | % |  | 282 |  |  | 4.7 | % |  | 274 |  |  | 4.8 | % |
| Earnings (loss) from continuing operations | (151 | ) |  | (2.4 | )% |  | 562 |  |  | 9.3 | % |  | 643 |  |  | 11.3 | % |
| Less: Earnings attributable to noncontrolling interests | 4 |  |  | 0.1 | % |  | 2 |  |  | — | % |  | 3 |  |  | 0.1 | % |
| Earnings (loss) from continuing operations* | (155 | ) |  | (2.4 | )% |  | 560 |  |  | 9.3 | % |  | 640 |  |  | 11.2 | % |
| Loss from discontinued operations, net of tax | — |  |  | — | % |  | — |  |  | — | % |  | (30 | ) |  | (0.5 | )% |
| Net earnings (loss)* | $ | (155 | ) |  | (2.4 | )% |  | $ | 560 |  |  | 9.3 | % |  | $ | 610 |  |  | 10.7 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.95 | ) |  |  |  | $ | 3.24 |  |  |  |  | $ | 3.17 |  |  |  |
| Discontinued operations | — |  |  |  |  | — |  |  |  |  | (0.15 | ) |  |  |
| Earnings per diluted common share* | $ | (0.95 | ) |  |  |  | $ | 3.24 |  |  |  |  | $ | 3.02 |  |  |  |

[0000068505-18-000009:mdna:42]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-18-000009:mdna:43]
**    Percentages may not add due to rounding.

[0000068505-18-000009:mdna:44]
Geographic Market Sales by Locale of End Customer

[0000068505-18-000009:mdna:45]
|  | 2017 |  | 2016 |  | 2015 |
| Americas | 68 | % |  | 68 | % |  | 71 | % |
| EMEA | 21 | % |  | 21 | % |  | 17 | % |
| AP | 11 | % |  | 11 | % |  | 12 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-18-000009:mdna:46]
Results of Operations—2017 Compared to 2016

[0000068505-18-000009:mdna:47]
Net Sales

[0000068505-18-000009:mdna:48]
Net sales were $6.4 billion in 2017, up $342 million, or 6%, compared to $6.0 billion in 2016, reflecting solid demand across the globe for our products and services. The increase in net sales is reflective of Products and Services growth in every region. Within the Products segment, Systems net sales increased in the Americas, while Devices net sales increased in every region. Services net sales increased, driven by the acquisitions of Airwave, Interexport, Spillman Technologies and Kodiak Networks and growth in Managed & Support and Integration services, absent of acquisitions.

[0000068505-18-000009:mdna:49]
Gross Margin

[0000068505-18-000009:mdna:50]
Gross margin was $3.0 billion, or 47.4% of net sales in 2017, compared to $2.9 billion, or 47.5% of net sales in 2016.

[0000068505-18-000009:mdna:51]
Selling, General and Administrative Expenses

[0000068505-18-000009:mdna:52]
SG&A expenses decreased 2% to $979 million, or 15.3% of net sales in 2017, compared to $1.0 billion, or 16.6% of net sales in 2016. The decrease in SG&A expenditures is primarily due to cost saving initiatives, partially offset by expenses associated with acquired businesses.

[0000068505-18-000009:mdna:53]
Research and Development Expenditures

[0000068505-18-000009:mdna:54]
R&D expenditures increased 3% to $568 million, or 8.9% of net sales in 2017, compared to $553 million, or 9.2% of net sales in 2016. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-18-000009:mdna:55]
Other Charges

[0000068505-18-000009:mdna:56]
We recorded net other charges of $195 million in 2017, compared to net charges of $249 million in 2016. The charges in 2017 included: (i) $151 million of charges relating to the amortization of intangibles, (ii) $48 million of losses on settlements within a non-U.S. pension plan, (iii) $33 million of net reorganization of business charges, (iv) $9 million of asset impairments, and (v) $1 million of charges for acquisition related transaction fees, partially offset by a $47 million gain on legal settlements. The charges in 2016 included: (i) $113 million of charges relating to the amortization of intangibles, (ii) $97 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment of our corporate aircraft, (iii) $26 million of losses on settlements within a non-U.S. pension plan, and (iv) $13 million of transaction fees on the acquisition of Airwave. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-18-000009:mdna:57]
Net Interest Expense

[0000068505-18-000009:mdna:58]
Net interest expense was $201 million in 2017 compared to $205 million in 2016. The decrease in net interest expense in 2017 compared to 2016 was a result of lower outstanding debt throughout 2017, due to the $675 million term loan outstanding throughout 2016, which was repaid at the end of 2016.

[0000068505-18-000009:mdna:59]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-18-000009:mdna:60]
Net gains on sales of investments and businesses were $3 million in 2017, compared to net losses on sales of investments and businesses of $6 million in 2016. The net gains in 2017 were primarily related to the sales of various equity investments. The net losses in 2016 consisted primarily of a $19 million loss on the sale of an investment in United Kingdom treasury securities and a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $20 million of gains on the sales of equity investments.

[0000068505-18-000009:mdna:61]
Other

[0000068505-18-000009:mdna:62]
Net Other expense was $8 million in 2017, compared to $12 million in 2016. The net Other expense in 2017 was primarily comprised of a $31 million foreign currency loss, partially offset by: (i) a $15 million gain on derivative instruments, (ii) $7 million of other non-operating gains and (iii) a $1 million gain on equity method investments. The net Other expense in 2016 was primarily comprised of: (i) a $56 million loss on derivative instruments, (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave, (iii) a $4 million investment impairment, and (iv) a $2 million loss on the extinguishment of long-term debt, partially offset by: (i) a $46 million foreign currency gain, (ii) $9 million of other non-operating gains, and (iii) $5 million gain on equity method investments.

[0000068505-18-000009:mdna:63]
Effective Tax Rate

[0000068505-18-000009:mdna:64]
We recorded $1.2 billion of net tax expense in 2017, an increase of $945 million compared to $282 million of net tax expense in 2016, or an effective tax rate of 33%. As a result of the Tax Act, we recorded $874 million of non-recurring charges during 2017, primarily related to a valuation allowance of $471 million against U.S. foreign tax credit carryforwards and income tax expense of $366 million from the remeasurement of our deferred tax balances at the lower federal tax rate of 21%. Excluding the income tax effects from the Tax Act, our effective tax rate was lower than the current U.S. federal statutory rate of 35%.

[0000068505-18-000009:mdna:65]
Our effective tax rate in 2016 was lower than the U.S. statutory tax rate of 35% primarily due to lower tax rates on non-U.S. income.

[0000068505-18-000009:mdna:66]
Our effective tax rate will change from period to period based on non-recurring events, such as the settlement of income tax audits, changes in valuation allowances, changes in tax laws, and the tax impact of significant unusual or extraordinary items, as well as recurring factors including changes in the geographic mix of income and effects of various global income tax strategies.

[0000068505-18-000009:mdna:67]
29

[0000068505-18-000009:mdna:68]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-18-000009:mdna:69]
After taxes, we had a loss from continuing operations attributable to Motorola Solutions, Inc. of $155 million, or $0.95 per diluted share, in 2017, compared to earnings of $560 million, or $3.24 per diluted share, in 2016.

[0000068505-18-000009:mdna:70]
The decrease in earnings from continuing operations in 2017, as compared to 2016, was driven by an increase in income tax expense primarily related to an $874 million charge for the implementation of the Tax Act.

[0000068505-18-000009:mdna:71]
Results of Operations—2016 Compared to 2015

[0000068505-18-000009:mdna:72]
Net Sales

[0000068505-18-000009:mdna:73]
Net sales were $6.0 billion in 2016, up $343 million, or 6%, compared to $5.7 billion in 2015. The increase in net sales is reflective of growth in every region. EMEA grew on Services sales, partially offset by lower Products sales. The increase in EMEA Services sales was due to expansion of our Managed & Support services, primarily from the acquisition of Airwave which provided $462 million of net sales during the year ended December 31, 2016. The Americas grew on Products sales, partially offset by lower Services sales. The decrease in the Americas Services sales was primarily due to macroeconomic pressures in Latin America. AP grew on both Services and Products sales.

[0000068505-18-000009:mdna:74]
Gross Margin

[0000068505-18-000009:mdna:75]
Gross margin was $2.9 billion, or 47.5% of net sales in 2016, compared to $2.7 billion, or 47.7% of net sales in 2015.

[0000068505-18-000009:mdna:76]
Selling, General and Administrative Expenses

[0000068505-18-000009:mdna:77]
SG&A expenses decreased 2% to $1.0 billion, or 16.6% of net sales in 2016, compared to $1.0 billion, or 17.9% of net sales in 2015. The decrease in SG&A expenditures is primarily due to cost savings initiatives, including headcount reductions, partially offset by higher incentive compensation and acquisitions costs.

[0000068505-18-000009:mdna:78]
Research and Development Expenditures

[0000068505-18-000009:mdna:79]
R&D expenditures decreased 11% to $553 million, or 9.2% of net sales in 2016, compared to $620 million, or 10.9% of net sales in 2015. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, and (ii) the movement of employees to lower cost work sites.

[0000068505-18-000009:mdna:80]
Other Charges

[0000068505-18-000009:mdna:81]
We recorded net other charges of $249 million in 2016, compared to net charges of $84 million in 2015. The charges in 2016 included: (i) $113 million of charges relating to the amortization of intangibles, (ii) $97 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment on our corporate aircraft, (iii) $26 million of losses on settlements within a non-U.S. pension plan, and (iv) $13 million of transaction fees on the acquisition of Airwave. The charges in 2015 included: (i) $108 million of net reorganization of business charges, including a $31 million impairment of our corporate aircraft which was sold and (ii) $8 million of charges relating to the amortization of intangibles, partially offset by a $32 million non-U.S. pension curtailment gain. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-18-000009:mdna:82]
Net Interest Expense

[0000068505-18-000009:mdna:83]
Net interest expense was $205 million in 2016 compared to $173 million in 2015. The increase in net interest expense in 2016 compared to 2015 was a result of higher outstanding debt balances throughout 2016.

[0000068505-18-000009:mdna:84]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-18-000009:mdna:85]
Net losses on sales of investments and businesses were $6 million in 2016, compared to net gains on sales of investments and businesses of $107 million in 2015. The net losses in 2016 consisted primarily of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities and (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $20 million of gains on the sales of equity investments. The net gains in 2015 were related to the sales of equity investments.

[0000068505-18-000009:mdna:86]
Other

[0000068505-18-000009:mdna:87]
Net Other expense was $12 million in 2016, compared to $11 million in 2015. The net Other expense in 2016 was primarily comprised of: (i) a $56 million loss on derivative instruments, (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave, (iii) a $4 million investment impairment, and (iv) a $2 million loss on the extinguishment of long-term debt, partially offset by: (i) a $46 million foreign currency gain, (ii) $9 million of other non-operating gains, and (iii) a $5 million gain on equity method investments. The net Other expense in 2015 was primarily comprised of: (i) a $23 million foreign currency loss and (ii) a $6 million investment impairment, partially offset by: (i) a $7 million gain on derivative instruments, (ii) a $6 million gain on equity method investments, and (iii) $5 million of other non-operating gains.

[0000068505-18-000009:mdna:88]
Effective Tax Rate

[0000068505-18-000009:mdna:89]
We recorded $282 million of net tax expense in 2016, resulting in an effective tax rate of 33%, compared to $274 million of net tax expense in 2015, resulting in an effective tax rate of 30%. Our effective tax rate in 2016 and 2015 were lower than the U.S. statutory tax rate of 35% primarily due to lower tax rates on non-U.S. income.

[0000068505-18-000009:mdna:90]
Our effective tax rate will change from period to period based on non-recurring events, such as the settlement of income tax audits, changes in valuation allowances, and the tax impact of significant unusual or extraordinary items, as well as recurring factors including changes in the geographic mix of income and effects of various global income tax strategies.

[0000068505-18-000009:mdna:91]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-18-000009:mdna:92]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $560 million, or $3.24 per diluted share, in 2016, compared to $640 million, or $3.17 per diluted share, in 2015.

[0000068505-18-000009:mdna:93]
The decrease in earnings from continuing operations in 2016, as compared to 2015, was primarily driven by: (i) a $165 million increase in Other charges primarily due to the increase in intangible amortization expense and (ii) a $113 million decrease in Gains on sales of investments and businesses, partially offset by: (i) a $150 million increase in Gross margin, (ii) a $67 million decrease in R&D, and (iii) a $21 million decrease in SG&A. The increase in earnings from continuing operations per diluted share was driven by lower shares outstanding as a result of repurchases made through our ongoing share repurchase program, offset by a decrease in earnings from continuing operations.

[0000068505-18-000009:mdna:94]
Earnings from Discontinued Operations

[0000068505-18-000009:mdna:95]
In 2016, we reported no earnings from discontinued operations, compared to a loss from discontinued operations of $30 million, or $0.15 per diluted share, in 2015. The loss from discontinued operations in 2015 was related to the sale of the Enterprise business.

[0000068505-18-000009:mdna:96]
Segment Information

[0000068505-18-000009:mdna:97]
The following commentary should be read in conjunction with the financial results of each operating business segment as detailed in Note 12, “Information by Segment and Geographic Region,” of our consolidated financial statements. Net sales and operating results for our two segments for 2017, 2016, and 2015 are presented below.

[0000068505-18-000009:mdna:98]
Products Segment

[0000068505-18-000009:mdna:99]
The Products segment’s net sales represented 59% of our consolidated net sales in 2017, compared to 60% in 2016 and 65% in 2015.

[0000068505-18-000009:mdna:100]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2017 |  | 2016 |  | 2015 |  | 2017—2016 |  | 2016—2015 |
| Segment net sales | $ | 3,772 |  |  | $ | 3,649 |  |  | $ | 3,676 |  |  | 3 | % |  | (1 | )% |
| Operating earnings (loss) | 914 |  |  | 734 |  |  | 704 |  |  | 25 | % |  | 4 | % |

[0000068505-18-000009:mdna:101]
Segment Results—2017 Compared to 2016

[0000068505-18-000009:mdna:102]
The segment’s net sales increased $123 million, or 3%, to $3.8 billion in 2017, as compared to $3.6 billion in 2016. On a geographic basis, net sales increased in every region in 2017, compared to 2016. Devices net sales increased in every region while Systems net sales increased in the Americas partially offset by decreases in EMEA and AP. The segment's backlog was $1.9 billion at December 31, 2017 and $1.5 billion at December 31, 2016.

[0000068505-18-000009:mdna:103]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in both 2017 and 2016.

[0000068505-18-000009:mdna:104]
The segment had operating earnings of $914 million in 2017, compared to $734 million in 2016. The increase in operating earnings in 2017 compared to 2016 was driven primarily by higher net sales and lower SG&A expenses, R&D expenditures, and Other charges.

[0000068505-18-000009:mdna:105]
Segment Results—2016 Compared to 2015

[0000068505-18-000009:mdna:106]
The segment’s net sales decreased $27 million, or 1%, to $3.6 billion in 2016, as compared to $3.7 billion in 2015. The decrease in the segment's net sales was primarily driven by a decrease in global Systems sales and unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP, partially offset by growth in Devices in the Americas and AP. On a geographic basis, net sales decreased in EMEA and increased in the Americas and AP in 2016, compared to 2015. The segment's backlog was $1.5 billion at December 31, 2016 and $1.2 billion at December 31, 2015.

[0000068505-18-000009:mdna:107]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in 2016, up from 73% of the segment’s net sales in 2015.

[0000068505-18-000009:mdna:108]
The segment had operating earnings of $734 million in 2016, compared to $704 million in 2015. The increase in operating earnings in 2016 compared to 2015 was driven primarily by: (i) lower SG&A and R&D expenditures as a result of cost savings initiatives including headcount reductions, partially offset by an increase in Other charges.

[0000068505-18-000009:mdna:109]
31

[0000068505-18-000009:mdna:110]
Services Segment

[0000068505-18-000009:mdna:111]
The Services segment’s net sales represented 41% of our consolidated net sales in 2017, compared to 40% in 2016 and 35% in 2015.

[0000068505-18-000009:mdna:112]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2017 |  | 2016 |  | 2015 |  | 2017—2016 |  | 2016—2015 |
| Segment net sales | $ | 2,608 |  |  | $ | 2,389 |  |  | $ | 2,019 |  |  | 9 | % |  | 18 | % |
| Operating earnings (loss) | 368 |  |  | 333 |  |  | 290 |  |  | 11 | % |  | 15 | % |

[0000068505-18-000009:mdna:113]
Segment Results—2017 Compared to 2016

[0000068505-18-000009:mdna:114]
The segment’s net sales increased $219 million, or 9%, to $2.6 billion in 2017, as compared to $2.4 billion in 2016. The increase in the segment's net sales was driven by growth in Managed & Support services and Integration services absent of acquisitions and the acquisitions of Interexport, Airwave, Spillman Technologies and Kodiak Networks. The net sales increase in the Americas was driven by Managed & Support services absent of acquisitions and the acquisitions of Interexport, Spillman Technologies and Kodiak Networks. The net sales increase in EMEA was driven by the acquisition of Airwave and growth in both Managed & Support services and Integration services absent of acquisitions. The net sales increase in AP was driven by growth in Integration services. The segment's backlog was $7.7 billion at December 31, 2017 and $6.9 billion at December 31, 2016.

[0000068505-18-000009:mdna:115]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 59% of the segment’s net sales in 2017, up from 58% of the segment’s net sales in 2016.

[0000068505-18-000009:mdna:116]
The segment had operating earnings of $368 million in 2017 compared to $333 million in 2016. The increase in operating earnings in 2017 compared to 2016 was driven primarily by higher net sales, partially offset by operating expenses related to acquisitions.

[0000068505-18-000009:mdna:117]
Segment Results—2016 Compared to 2015

[0000068505-18-000009:mdna:118]
The segment’s net sales increased $370 million, or 18%, to $2.4 billion in 2016, as compared to $2.0 billion in 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both the acquisition of Airwave and absent of acquisitions. The acquisition of Airwave provided $462 million of net sales within EMEA during the year ended December 31, 2016, while the Managed & Support services business absent of acquisitions grew in the Americas and AP. This sales growth was partially offset by: (i) a decrease in Integration services sales, with a significant decrease in EMEA related to the winding down of a large system implementation, (ii) declining iDEN services sales in the Americas, and (iii) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales increased in EMEA and AP and decreased in the Americas in 2016, compared to 2015. The segment's backlog was $6.9 billion at December 31, 2016 and $5.2 billion at December 31, 2015. The increase in the segment's backlog in 2016 compared to 2015 was driven in part by $1.2 billion from the acquisition of Airwave.

[0000068505-18-000009:mdna:119]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in 2016, down from 69% of the segment’s net sales in 2015.

[0000068505-18-000009:mdna:120]
The segment had operating earnings of $333 million in 2016 compared to $290 million in 2015. The increase in operating earnings in 2016 compared to 2015 was driven primarily by: (i) increased sales volume generating higher gross margin on our Managed & Support services, primarily in EMEA due to the acquisition of Airwave, and (ii) lower SG&A expenditures due to cost savings initiatives, including headcount reductions, partially offset by an increase in Other charges, including $105 million of intangible amortization expense, primarily associated with the Airwave acquisition.

[0000068505-18-000009:mdna:121]
Reorganization of Businesses

[0000068505-18-000009:mdna:122]
In 2017, we recorded net reorganization of business charges of $42 million relating to the separation of 400 employees, of which 300 were indirect employees and 100 were direct employees. The $42 million of charges included $9 million recorded to Cost of sales and $33 million recorded to Other charges. Included in the aggregate $42 million are charges of $43 million for employee separation costs and $8 million for exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-18-000009:mdna:123]
During 2016, we recorded net reorganization of business charges of $140 million relating to the separation of 1,300 employees, of which 900 were indirect employees and 400 were direct employees. The $140 million of charges included $43 million recorded to Cost of sales and $97 million recorded to Other charges. Included in the aggregate $140 million are charges of: (i) $120 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-18-000009:mdna:124]
During 2015, we recorded net reorganization of business charges of $117 million relating to the separation of 1,100 employees, of which 900 were indirect employees and 200 were direct employees. The $117 million of charges in earnings from continuing operations included $9 million recorded to Cost of sales and $108 million recorded to Other charges. Included in the aggregate $117 million are charges of: (i) $74 million for employee separation costs, (ii) $31 million for the impairment of

[0000068505-18-000009:mdna:125]
corporate aircraft, (iii) $10 million for exit costs, and (iv) a $6 million building impairment charge, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-18-000009:mdna:126]
The following table displays the net charges incurred by business segment:

[0000068505-18-000009:mdna:127]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Products | $ | 31 |  |  | $ | 106 |  |  | $ | 84 |  |
| Services | 11 |  |  | 34 |  |  | 33 |  |
|  | $ | 42 |  |  | $ | 140 |  |  | $ | 117 |  |

[0000068505-18-000009:mdna:128]
Cash payments for exit costs and employee severance in connection with the reorganization of business plans were $93 million, $79 million, and $71 million in 2017, 2016, and 2015, respectively. The reorganization of business accruals at December 31, 2017 were $50 million, of which $41 million relates to employee separation costs that are expected to be paid within one year and $9 million relates primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-18-000009:mdna:129]
Liquidity and Capital Resources

[0000068505-18-000009:mdna:130]
We increased the aggregate of our cash and cash equivalent balances from $1.0 billion as of December 31, 2016 to $1.3 billion as of December 31, 2017.  As highlighted in the consolidated statements of cash flows, our liquidity and available capital resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0000068505-18-000009:mdna:131]
Cash and Cash Equivalents

[0000068505-18-000009:mdna:132]
At December 31, 2017, $757 million of the $1.3 billion cash and cash equivalents balance was held in the U.S. and $511 million was held outside of the U.S. Restricted cash was approximately $63 million at both December 31, 2017 and December 31, 2016.

[0000068505-18-000009:mdna:133]
In 2017, we repatriated approximately $606 million in cash to the U.S. from international jurisdictions. Under the Tax Act, federal income taxes on dividends from foreign subsidiaries have been generally eliminated after December 31, 2017. The change in tax law will allow the Company to more simply repatriate foreign income in a tax exempt manner. However, we do not anticipate significant changes in liquidity or our ability to repatriate foreign earnings more efficiently in the future as a result of the Tax Act.

[0000068505-18-000009:mdna:134]
Undistributed earnings that we intend to reinvest indefinitely, and for which no U.S. income taxes have been provided, aggregate to $1.8 billion at December 31, 2017. We currently have no plans to repatriate the foreign earnings permanently reinvested. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-18-000009:mdna:135]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy.  While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-18-000009:mdna:136]
Operating Activities

[0000068505-18-000009:mdna:137]
Net cash provided by operating activities from continuing operations in 2017 was $1.3 billion, compared to cash provided by operating activities from continuing operations of $1.2 billion in 2016 and cash provided by operating activities from continuing operations of $1.0 billion in 2015. Operating cash flows in 2017, as compared to 2016, were positively impacted by higher revenue from continuing operations and resulting operating earnings. Operating cash flows in 2016, as compared to 2015, were positively impacted by higher earnings from continuing operations, offset by higher employee incentive compensation payments.

[0000068505-18-000009:mdna:138]
We expect to make a $500 million debt funded contribution to our U.S. Pension Plans in 2018. As a result, we will generate a tax benefit under the current U.S. federal tax rate of 35% for the plan year 2017, before the enacted rate lowers to 21% as a result of the Tax Act. We expect to make approximately $7 million of cash contributions to our Non-U.S. Pension Plans in 2018.

[0000068505-18-000009:mdna:139]
Investing Activities

[0000068505-18-000009:mdna:140]
Net cash used by investing activities from continuing operations was $448 million in 2017, compared to net cash used by investing activities from continuing operations of $1.0 billion in 2016 and net cash used by investing activities from continuing operations of $528 million in 2015. The decrease in net cash used by investing activities from 2016 to 2017 was primarily due to a decrease in acquisitions and investments, partially offset by lower proceeds from sales of investments and businesses. The increase in net cash used by investing activities from 2015 to 2016 was primarily due to the acquisition of Airwave, offset by the sale of an investment used to fund the acquisition.

[0000068505-18-000009:mdna:141]
Acquisitions and Investments:  We used net cash of $404 million for acquisitions and new investment activities in 2017, compared to $1.5 billion in 2016, and $586 million in 2015. The cash used during 2017 was used for investment in short-term government securities, and the acquisitions (net of acquired cash) of Kodiak Networks for $225 million and Interexport for $55 million. In 2016, we paid cash of $1.0 billion related to the acquisition of Airwave, $217 million for the acquisition of Spillman, and

[0000068505-18-000009:mdna:142]
33

[0000068505-18-000009:mdna:143]
$26 million related to the acquisition of other software and services related businesses. The remainder of the cash was used for several debt and equity investments. In 2015, we invested $401 million in order to partially offset our foreign currency risk associated with the purchase of Airwave. We liquidated these investments in February 2016 to partially fund the acquisition. Additionally, we paid $49 million for the acquisition of two public safety software solution providers, as well as several debt and equity investments.

[0000068505-18-000009:mdna:144]
Sales of Investments and Businesses:  We received $183 million of proceeds in 2017, compared to $670 million in 2016, and $230 million in 2015. The $183 million of cash provided by investments in 2017 primarily consisted of the sales of short-term government securities. The $670 million of cash received in 2016 was primarily comprised of: (i) $382 million from the sale of an investment used to finance the acquisition of Airwave, (ii) $242 million from the sales of various debt and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations. The $230 million of cash received in 2015 was primarily comprised of: (i) $49 million reimbursement from Zebra for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale, (ii) $107 million from the sale of two equity investments, (iii) $13 million net cash received from Zebra for the final purchase price adjustment, as well as for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest.

[0000068505-18-000009:mdna:145]
Capital Expenditures:  Capital expenditures were $227 million in 2017, compared to $271 million in 2016, and $175 million in 2015. The decrease in capital spending in 2017, as compared to 2016, was primarily driven by lower facilities spend and lower expenditures on networks that we build and operate on behalf of our customers, partially offset by an increase in information technology spend. The increase in capital spending in 2016, as compared to 2015, was primarily driven by an increase in expenditures on networks that we build and operate on behalf of our customers, information technology spend and facilities expenditures.

[0000068505-18-000009:mdna:146]
Sales of Property, Plant, and Equipment:  We had no proceeds related to the sale of property, plant, and equipment in 2017, compared to $73 million in 2016 and $3 million in 2015. The proceeds in 2016 were driven by the sale of buildings and land on the Schaumburg, IL campus and the sale of the corporate aircraft. The proceeds in 2015 were primarily comprised of sales of buildings and land.

[0000068505-18-000009:mdna:147]
Financing Activities

[0000068505-18-000009:mdna:148]
Net cash used for financing activities was $722 million in 2017, compared to $1.0 billion in 2016, and $2.4 billion in 2015.  Cash used for financing activities in 2017 was primarily comprised of: (i) $483 million used for purchases under our share repurchase program and (ii) $307 million of cash used for the payment of dividends, partially offset by $82 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-18-000009:mdna:149]
Cash used for financing activities in 2016 was primarily comprised of: (i) $842 million used for purchases under our share repurchase program and (ii) $280 million of cash used for the payment of dividends, partially offset by $93 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-18-000009:mdna:150]
Cash used for financing activities in 2015 was primarily comprised of: (i) $3.2 billion used for purchases under our share repurchase program and (ii) $277 million of cash used for the payment of dividends, partially offset by: (i) $971 million of net proceeds from the issuance of the Senior Convertible Notes and (ii) $84 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-18-000009:mdna:151]
Current and Long-Term Debt:  We had outstanding long-term debt of $4.5 billion and $4.4 billion, including the current portions of $52 million and $4 million, at December 31, 2017 and December 31, 2016, respectively. In the acquisition of Interexport, we assumed $92 million of debt, including a current portion of $40 million, primarily related to capital leases.

[0000068505-18-000009:mdna:152]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a published conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-18-000009:mdna:153]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. We believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty, volatility in the capital markets, or deterioration in our credit ratings may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-18-000009:mdna:154]
We may, from time to time, seek to retire certain outstanding debt of ours through open market cash purchases, privately-negotiated transactions or otherwise. Such repurchases, if any, will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors.

[0000068505-18-000009:mdna:155]
Share Repurchase Program:  Through a series of actions, the Board of Directors has authorized an aggregate share repurchase amount of up to $14.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2017, we have used approximately $12.3 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $1.7 billion of authority available for future repurchases.

[0000068505-18-000009:mdna:156]
34

[0000068505-18-000009:mdna:157]
During 2017, we paid an aggregate of $483 million, including transaction costs, to repurchase 5.7 million shares at an average price of $85.32 per share. During 2016, we paid an aggregate of $842 million, including transaction costs, to repurchase 12.0 million shares at an average price of $70.28. During 2015, we paid an aggregate of $3.2 billion, including transaction costs, to repurchase 48.0 million shares at an average price of $66.22. Shares repurchased in 2015 include 30.1 million shares repurchased under a modified "Dutch auction" tender offer at a tender price of $66.50 for an aggregate of $2.0 billion, including transaction costs.

[0000068505-18-000009:mdna:158]
Payment of Dividends:  We paid cash dividends to holders of our common stock of $307 million in 2017, $280 million in 2016, and $277 million in 2015. Subsequent to quarter end, we paid an additional $84 million in cash dividends to holders of our common stock.

[0000068505-18-000009:mdna:159]
Credit Facilities

[0000068505-18-000009:mdna:160]
As of December 31, 2017, we had a $2.2 billion unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2017. During the twelve months ended December 31, 2017, we had borrowings and repayments of $150 million under the 2017 Motorola Solutions Credit Agreement. Such borrowings were used to purchase Kodiak Networks in April of 2017, and were repaid using cash from operations in June of 2017. No letters of credit were issued under the revolving credit facility as of December 31, 2017.

[0000068505-18-000009:mdna:161]
Contractual Obligations and Other Purchase Commitments

[0000068505-18-000009:mdna:162]
Summarized in the table and text below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2017.

[0000068505-18-000009:mdna:163]
|  | Payments Due by Period |
| (in millions) | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations | $ | 4,528 |  |  | $ | 52 |  |  | $ | 6 |  |  | $ | 1,007 |  |  | $ | 417 |  |  | $ | 770 |  |  | $ | — |  |  | $ | 2,276 |  |
| Lease obligations | 661 |  |  | 121 |  |  | 107 |  |  | 82 |  |  | 64 |  |  | 53 |  |  | — |  |  | 234 |  |
| Purchase obligations* | 237 |  |  | 173 |  |  | 41 |  |  | 15 |  |  | 7 |  |  | 1 |  |  | — |  |  | — |  |
| Tax obligations | 76 |  |  | 14 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |
| Total contractual obligations | $ | 5,502 |  |  | $ | 360 |  |  | $ | 154 |  |  | $ | 1,104 |  |  | $ | 488 |  |  | $ | 824 |  |  | $ | 62 |  |  | $ | 2,510 |  |

[0000068505-18-000009:mdna:164]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-18-000009:mdna:165]
Lease Obligations:  We lease certain office, factory and warehouse space, land, information technology and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations, net of minimum sublease rentals, totaled $661 million. Rental expense, net of sublease income, was $94 million in 2017, $84 million in 2016, and $42 million in 2015.

[0000068505-18-000009:mdna:166]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. We had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2022. The total payments expected to be made under these agreements are $237 million, of which $220 million relate to take or pay obligations from arrangements with suppliers for the sourcing of inventory supplies and materials. We do not anticipate the cancellation of any of our take or pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-18-000009:mdna:167]
Tax Obligations:  We have approximately $76 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $10 million tax charge to a $30 million tax benefit, with cash payments not expected to exceed $20 million.

[0000068505-18-000009:mdna:168]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take or pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-18-000009:mdna:169]
We outsource certain corporate functions, such as benefit administration and information technology-related services, under third-party contracts, the longest of which is expected to expire in 2022. Our remaining payments under these contracts are approximately $97 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-18-000009:mdna:170]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance bonds, bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. At December 31, 2017, outstanding Performance Bonds totaled approximately $2.4 billion, compared to $2.2 billion at December 31, 2016. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-18-000009:mdna:171]
Off-Balance Sheet Arrangements:  At December 31, 2017, we had no significant off-balance sheet arrangements other than operating leases and guarantees to third parties as described in Note 11 to the consolidated financial statements and our obligation to settle the embedded conversion option under the Senior Convertible Notes described in Note 4 to the consolidated financial statements.

[0000068505-18-000009:mdna:172]
Long-term Customer Financing Commitments

[0000068505-18-000009:mdna:173]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $93 million at December 31, 2017, compared to $125 million at December 31, 2016.

[0000068505-18-000009:mdna:174]
Outstanding Long-Term Receivables:  We had non-current long-term receivables of $19 million at December 31, 2017, compared to $49 million at December 31, 2016. There were no allowances for losses in 2017 and $2 million of allowances for losses in 2016. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 11%.

[0000068505-18-000009:mdna:175]
Sales of Receivables

[0000068505-18-000009:mdna:176]
From time to time, we sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables. Servicing obligations are limited to collection activities for sold accounts receivables and long-term receivables.

[0000068505-18-000009:mdna:177]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2017, 2016, and 2015:

[0000068505-18-000009:mdna:178]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Accounts receivable sales proceeds | $ | 193 |  |  | $ | 51 |  |  | $ | 29 |  |
| Long-term receivables sales proceeds | 284 |  |  | 289 |  |  | 196 |  |
| Total proceeds from receivable sales | $ | 477 |  |  | $ | 340 |  |  | $ | 225 |  |

[0000068505-18-000009:mdna:179]
At December 31, 2017, the Company had retained servicing obligations for $873 million of long-term receivables, compared to $774 million of long-term receivables at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000009:mdna:180]
Adequate Internal Funding Resources

[0000068505-18-000009:mdna:181]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our $2.2 billion revolving credit facility.

[0000068505-18-000009:mdna:182]
Other Contingencies

[0000068505-18-000009:mdna:183]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-18-000009:mdna:184]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us. Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 18 months, and for amounts not in excess of a percentage of the contract value.

[0000068505-18-000009:mdna:185]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on our consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-18-000009:mdna:186]
Critical Accounting Policies

[0000068505-18-000009:mdna:187]
Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-18-000009:mdna:188]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-18-000009:mdna:189]
Revenue Recognition

[0000068505-18-000009:mdna:190]
Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. We enter into revenue arrangements that may consist of multiple deliverables of our products and services due to the needs of our customers, including any combination of products, services and software. For multiple-element arrangements, deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in our control.

[0000068505-18-000009:mdna:191]
In these arrangements, we generally allocate revenue to all deliverables based on their relative selling prices, applying an estimated selling price (“ESP”) as our best estimate of fair value. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or service, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service type, type of customer, geographic market, and sales volume. Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above. Our arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. In limited circumstances, we have established vendor specific objective evidence ("VSOE") of fair value on certain post-contract service offerings. Where the contract contains more than one software deliverable and VSOE does not exist for the undelivered software elements, revenue is deferred until the undelivered element is delivered. When the final undelivered software element is post contract support, revenue is recognized on a ratable basis over the remaining service period.

[0000068505-18-000009:mdna:192]
For long-term contracts that involve customization of equipment and/or software, we generally recognize revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the work required to be performed under many of our long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts.

[0000068505-18-000009:mdna:193]
The impact on operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2017, 2016, and 2015. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-18-000009:mdna:194]
Retirement Benefits

[0000068505-18-000009:mdna:195]
Our benefit obligations and net periodic pension cost (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions.  The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-18-000009:mdna:196]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-18-000009:mdna:197]
There are various assumptions used in calculating the net periodic cost (benefit) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.   We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-18-000009:mdna:198]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost and the net retirement health care expense. Our investment return assumption for the U.S. Pension Benefit Plans was 6.95% in 2017 and 7.00% in 2016. Our investment return assumption for the Postretirement Health Care Benefits Plan was 7.00% in 2017 and 2016. Our weighted average investment return assumption for the Non-U.S. Plans was 5.20% in 2017 and 5.90% in 2016. At December 31, 2017, the pension plans, including the U.S. Pension Benefit Plans and Non-U.S. Plans investment portfolios were comprised of approximately 29% equity investments, while the Postretirement Health Care Benefits Plan was all comprised of approximately 34% equity investments.

[0000068505-18-000009:mdna:199]
A second key assumption is the discount rate. The discount rate assumptions used for pension benefits and Postretirement Health Care Benefits Plan reflects, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 3.79% and 4.42% at December 2017 and 2016, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 2.34% and 2.54% at December 2017 and 2016, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 3.62% and 4.11% at December 31, 2017 and 2016, respectively.

[0000068505-18-000009:mdna:200]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from eleven to thirty-four years. Prior service costs are being amortized over periods ranging from one to five years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-18-000009:mdna:201]
Effective January 1, 2016, we began to use a full yield curve approach in the estimation of our interest and service cost components of our net periodic cost, which uses a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. This method was elected to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. Prior to January 1, 2016, estimates of interest and service cost components used a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the year.

[0000068505-18-000009:mdna:202]
Valuation and Recoverability of Goodwill

[0000068505-18-000009:mdna:203]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: adverse changes in macroeconomic conditions, adverse changes in the industry or market in which we transact, changes in cost factors negatively impacting earnings and cash flows, negative or declining overall financial performance, events affecting the carrying value or composition of a reporting unit, or a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-18-000009:mdna:204]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a

[0000068505-18-000009:mdna:205]
single component. Based on this guidance, we have determined that our Products and Services segments each meet the definition of a reporting unit. We performed a qualitative assessment of goodwill and determined that it was not more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2017, 2016, and 2015. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal years 2017, 2016, and 2015, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-18-000009:mdna:206]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-18-000009:mdna:207]
We record deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on the currently enacted tax laws. As a result of the enactment of the Tax Act, we have reflected our best estimates and assumptions regarding: (i) the value of deferred income tax assets and liabilities based on the enacted corporate federal tax rate of 21%, (ii) the value of foreign tax credit carryforwards based on our ability to utilize foreign tax credits to offset future income tax liabilities and (iii) the accounting impact of new rules such as Global Intangible Low-Taxed Income ("GILTI") and Base Erosion Anti-abuse Tax ("BEAT"). We will continue to evaluate the valuation of our deferred tax positions on a quarterly basis to determine if valuation allowances are appropriately estimated by considering available evidence, including historical and projected taxable income and tax planning strategies that are both prudent and feasible. As our understanding of the application of certain rules under the Tax Act becomes clarified, we will further refine our estimates throughout 2018.

[0000068505-18-000009:mdna:208]
Recent Accounting Pronouncements

[0000068505-18-000009:mdna:209]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU No. 2014-09 by one year to January 1, 2018, as our annual reporting period begins after December 15, 2017.

[0000068505-18-000009:mdna:210]
We have analyzed the impact of the new standard on our financial results based on an inventory of our current contracts with customers. We have obtained an understanding of the new standard and currently believe that we will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of our contracts is currently recognized under percentage of completion accounting applying a cost-to-cost method, including contracts for radio network deployments based on the APCO P25, TETRA, and DMR technologies, as well as certain offerings within our Smart Public Safety Solutions requiring significant integration (collectively "network integration contracts").

[0000068505-18-000009:mdna:211]
Under the new standard, we must identify the distinct promises to transfer goods and/or services within our contracts using certain factors. For network integration contracts, we have considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard will impact our network integration contracts that include devices and accessories, with the resulting impact being revenue recognized earlier as control of the devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within our network integration contracts, we will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in our contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-18-000009:mdna:212]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While we have contracts which fall under these rules in the current standard, we have not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, we do not anticipate a significant acceleration of revenue upon applying the new standard to our current contracts under these fact patterns.

[0000068505-18-000009:mdna:213]
The new standard also requires the concept of transfer of control to determine whether an entity must present revenue from providing goods or services at the gross amount billed to a customer (as a principal) or at the net amount retained (as an agent). Therefore, an entity must assess whether it controls the goods or services provided to a customer before they are transferred. The new standard provides three indicators to assist entities in determining control. Under the current standard, eight indicators (including the three indicators under the new standard) exist to evaluate whether an entity should present revenue gross as a principal or net as an agent. Historically, we have presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and remaining three indicators under the new standard, we have determined that we are the principal in contracts that involve a third-party sales representative. Thus, upon adoption of the new standard we will present associated revenues on a gross basis, recording third-party sales commissions within selling, general and administrative expenses.

[0000068505-18-000009:mdna:214]
Under current accounting standards, we expense sales commissions as incurred. However, under ASU No. 2014-09, we will capitalize sales commissions as incremental costs to obtain a contract. Such costs will be classified as a contract asset and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000009:mdna:215]
We have evaluated the impact of ASU No. 2014-09 on our financial results and determined to adopt this standard using the modified retrospective method, which requires the recognition of the cumulative effect of the transition as an adjustment to retained earnings for open contracts as of January 1, 2018. Based on the application of the changes described above to our contracts open as of January 1, 2018, we expect to recognize a transition adjustment in the range of $120 million to $140 million, net of deferred tax effects, which will increase our opening retained earnings. Based on our existing operations, ASU No. 2014-09 is not expected to have a material impact to net earnings for the year ended December 31, 2018.

[0000068505-18-000009:mdna:216]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us on January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-18-000009:mdna:217]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for us on January 1, 2018 with early adoption permitted. We intend to adopt this ASU on January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, we do not anticipate significant changes to our existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-18-000009:mdna:218]
In October 2016, the FASB issued ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption permitted. We intend to adopt the ASU on January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. We expect to record a $30 million cumulative-effect adjustment to beginning retained earnings in the first quarter of 2018 for the remaining unrecognized deferred tax expense related to the intra-entity transfers of property, plant, and equipment.

[0000068505-18-000009:mdna:219]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in the total cash, which is inclusive of cash and cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for us on January 1, 2018 with early adoption permitted. We intend to adopt the ASU on January 1, 2018. Upon adoption, the ASU requires retrospective application. We do not anticipate significant changes to our financial statements and related disclosures from adoption of the ASU.

[0000068505-18-000009:mdna:220]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. We intend to adopt this ASU on January 1, 2018. Upon adoption, we plan to update the presentation of net periodic cost (benefit) accordingly, noting all components of our net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of approximately $8 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.

[0000068505-18-000009:mdna:221]
In August 2017, the FASB issued ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for us on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). We are currently assessing the impact of this ASU, including transition elections and required elections, on our consolidated financial statements and the timing of adoption.

[0000068505-18-000009:mdna:222]
Recently Adopted Accounting Pronouncements

[0000068505-18-000009:mdna:223]
We have elected to early adopt ASU No. 2018-2, "Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income," as of January 1, 2017. The ASU, which was issued by the FASB in February 2018, allows for a reclassification from Accumulated other comprehensive income to Retained earnings for stranded tax effects resulting from the newly enacted federal corporate income tax rate and other stranded tax amounts related to the Tax Act. As a result of adoption of the ASU, we reclassified $270 million of stranded tax effects related to our U.S. Pension Plans out of Accumulated other comprehensive loss and into Retained earnings for the year ended December 31, 2017.

[0000068505-18-000009:mdna:224]
Forward-Looking Statements

[0000068505-18-000009:mdna:225]
Some of the risk factors that affect our business and financial results are discussed in “Item 1A: Risk Factors.” We caution the reader that the risk factors discussed in “Item 1A: Risk Factors,” and those described elsewhere in this report or in our other Securities and Exchange Commission filings, could cause our actual results to differ materially from those stated in the forward-looking statements.

[0000068505-18-000009:mdna:226]
41
