# MSI 8-K — 0000068505-18-000004 filed 2018-02-01

## item codes, every 8-K on or before 2018-02-16

- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2018-02-16

- none on or before 2018-02-16

## item 2.02 — earnings release, exhibit 99.1

[0000068505-18-000004:8k_2_02:1]
EX-99.1
2
msiq42017pressrelease.htm
EXHIBIT 99.1

[0000068505-18-000004:8k_2_02:2]
Exhibit

[0000068505-18-000004:8k_2_02:3]
Exhibit 99.1

[0000068505-18-000004:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-18-000004:8k_2_02:5]
Record 2017 sales, cash flow and backlog supported by strong fourth-quarter results

[0000068505-18-000004:8k_2_02:6]
| • | Revenue of $2 billion, up 4 percent from year ago; up 6 percent for full year |

[0000068505-18-000004:8k_2_02:7]
| • | Organic1 revenue growth of 2 percent; 3 percent for full year |

[0000068505-18-000004:8k_2_02:8]
| • | Record backlog of $9.6 billion, up $1.2 billion or 15 percent from a year ago |

[0000068505-18-000004:8k_2_02:9]
| • | GAAP earnings per share (EPS) of ($3.56); ($0.95) for full year, on charges related to tax reform2 |

[0000068505-18-000004:8k_2_02:10]
| • | Non-GAAP EPS* of $2.10, up 3 percent; $5.46 for full year, up 11 percent |

[0000068505-18-000004:8k_2_02:11]
| • | Generated $761 million in operating cash flow; $1.3 billion for full year |

[0000068505-18-000004:8k_2_02:12]
CHICAGO - Feb. 1, 2018 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2017. Click here for a printable news release and financial tables.

[0000068505-18-000004:8k_2_02:13]
“We finished the year with a very strong fourth quarter, capping a record year for revenue, operating earnings, cash flow and backlog driven by continued organic growth on strength in land-mobile radio (LMR) solutions," said Greg Brown, chairman and CEO of Motorola Solutions. “We are poised for continued growth in LMR and software and services."

[0000068505-18-000004:8k_2_02:14]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-18-000004:8k_2_02:15]
|  | Fourth Quarter | Full Year |
|  | 2017 |  | 2016 |  | % Change | 2017 |  | 2016 |  | % Change |
| Sales | $1,957 | $1,883 | 4 | % | $6,380 | $6,038 | 6 | % |
| GAAP |  |  |  |  |  |  |
| Operating earnings | $511 | $403 | 27 | % | $1,282 | $1,067 | 20 | % |
| % of Sales | 26.1 | % | 21.4 | % |  | 20.1 | % | 17.7 | % |  |
| EPS from continuing operations | $(3.56) | $1.43 | N/M** |  | $(0.95) | $3.24 | N/M |  |
| Non-GAAP |  |  |  |  |  |  |
| Operating earnings | $576 | $541 | 6 | % | $1,552 | $1,427 | 9 | % |
| % of Sales | 29.4 | % | 28.7 | % |  | 24.3 | % | 23.6 | % |  |
| EPS from continuing operations | $2.10 | $2.03 | 3 | % | $5.46 | $4.92 | 11 | % |
| Product Segment |  |  |  |  |  |  |
| Sales | $1,233 | $1,226 | 1 | % | $3,772 | $3,649 | 3 | % |
| GAAP Operating earnings | $404 | $330 | 22 | % | $914 | $734 | 25 | % |
| % of Sales | 32.8 | % | 26.9 | % |  | 24.2 | % | 20.1 | % |  |
| Non-GAAP Operating earnings | $425 | $407 | 4 | % | $1,006 | $910 | 11 | % |
| % of Sales | 34.5 | % | 33.2 | % |  | 26.7 | % | 24.9 | % |  |
| Services Segment |  |  |  |  |  |  |
| Sales | $724 | $657 | 10 | % | $2,608 | $2,389 | 9 | % |
| GAAP Operating earnings | $107 | $73 | 47 | % | $368 | $333 | 11 | % |
| % of Sales | 14.8 | % | 11.1 | % |  | 14.1 | % | 13.9 | % |  |
| Non-GAAP Operating earnings | $151 | $134 | 13 | % | $546 | $517 | 6 | % |
| % of Sales | 20.9 | % | 20.4 | % |  | 20.9 | % | 21.6 | % |  |

[0000068505-18-000004:8k_2_02:16]
*Q4 Non-GAAP financial information excludes the after-tax impact of approximately $5.50 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items for the fourth-quarter. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-18-000004:8k_2_02:17]
** N/M = Percent Change is not meaningful due to the current year net loss related to tax reform

[0000068505-18-000004:8k_2_02:18]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-18-000004:8k_2_02:19]
| • | Revenue - Revenue increased 4 percent on strength in the Americas. Products segment revenue grew 1 percent. Services segment revenue grew 10 percent with growth in every region. Managed and Support Services grew 17 percent. |

[0000068505-18-000004:8k_2_02:20]
| • | Operating margin - GAAP operating margin was 26.1 percent of revenue compared with 21.4 percent in the year-ago quarter driven by higher revenue in the current quarter as well as higher restructuring charges in the year-ago quarter. Non-GAAP operating margin was 29.4 percent of revenue, compared with 28.7 percent in the year-ago quarter. Improved non-GAAP results reflect higher revenue and associated earnings. |

[0000068505-18-000004:8k_2_02:21]
| • | Taxes - The GAAP effective tax rate was 223.4 percent, compared to 32.6 percent in the year-ago quarter. Charges related to tax reform accounted for $874 million of GAAP tax expense for the quarter. The non-GAAP effective tax rate was 32.8 percent compared with 30.7 percent in the year-ago quarter, resulting in higher non-GAAP tax expense of $11 million. |

[0000068505-18-000004:8k_2_02:22]
| • | Cash flow - The company generated $761 million in operating cash, up $248 million from the year-ago quarter. Free cash flow3 was $740 million, up $287 million. The cash flow was driven by higher operating earnings and improved working capital performance. |

[0000068505-18-000004:8k_2_02:23]
| • | Capital Allocation - The company repurchased $125 million of its common stock and paid $76 million in cash dividends. |

[0000068505-18-000004:8k_2_02:24]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-18-000004:8k_2_02:25]
| • | Revenue - Revenue increased 6 percent including acquisitions. Organic revenue growth was 3 percent led by North America organic growth of 3 percent. Products segment revenue grew 3 percent led by higher North America system revenue, while the Services segment grew 9 percent on Managed and Support Services growth in all regions. |

[0000068505-18-000004:8k_2_02:26]
| • | Operating margin - For the full year, GAAP operating margin was 20.1 percent of revenue, compared with 17.7 percent for the prior year. The increase was primarily driven by higher revenue. Non-GAAP operating margin was 24.3 percent of revenue, compared with 23.6 percent for the prior year, driven by higher revenue and lower operating expenses. |

[0000068505-18-000004:8k_2_02:27]
| • | Taxes - The 2017 GAAP effective tax rate was 114.1 percent, compared to 33.5 percent for the prior year. Charges related to tax reform accounted for $874 million of GAAP tax expense for the year. The non-GAAP effective tax rate was 31.0 percent, compared with 31.2 percent in the prior year. |

[0000068505-18-000004:8k_2_02:28]
| • | Cash flow - The company generated $1.3 billion in operating cash, up $181 million from the prior year. Free cash flow3 was $1.1 billion, up $225 million from the prior year. The increase was driven by higher revenue and associated earnings. |

[0000068505-18-000004:8k_2_02:29]
| • | Capital Allocation - The company repurchased $483 million of its common stock, paid $307 million in cash dividends and invested $298 million in acquisitions. |

[0000068505-18-000004:8k_2_02:30]
| • | Backlog - The company ended the year with record backlog of $9.6 billion, up $1.2 billion from the year-ago quarter. Products segment backlog was up 25 percent or $382 million, and Services was up 13 percent or $860 million. LMR demand led by the Americas continues to drive the backlog growth. |

[0000068505-18-000004:8k_2_02:31]
STRATEGIC WINS

[0000068505-18-000004:8k_2_02:32]
| • | $290 million LMR system in Middle Eastern country that recently deployed a private Public Safety LTE system |

[0000068505-18-000004:8k_2_02:33]
| • | $197 million seven-year LMR managed services contract extension for the Melbourne Metropolitan Radio Network in Australia |

[0000068505-18-000004:8k_2_02:34]
| • | $76 million P25 order from city of Dallas |

[0000068505-18-000004:8k_2_02:35]
| • | $53 million P25 order from city of Los Angeles |

[0000068505-18-000004:8k_2_02:36]
| • | $39 million P25 order from city of Toronto |

[0000068505-18-000004:8k_2_02:37]
| • | $18 million P25 upgrade and seven-year managed services agreement with Dow Chemical |

[0000068505-18-000004:8k_2_02:38]
BUSINESS OUTLOOK

[0000068505-18-000004:8k_2_02:39]
| • | First-quarter 2018 - Motorola Solutions expects revenue growth of approximately 7 percent compared with the first quarter of 2017. The company expects non-GAAP earnings per share in the range of $0.83 to $0.88 per share. |

[0000068505-18-000004:8k_2_02:40]
| • | Full-year 2018 - The company expects revenue growth of approximately 5 percent and non-GAAP earnings per share in the range of $6.50 to $6.65 per share. This assumes current foreign exchange rates and a non-GAAP effective tax rate of approximately 25 percent. |

[0000068505-18-000004:8k_2_02:41]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) Thursday, Feb 1. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0000068505-18-000004:8k_2_02:42]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-18-000004:8k_2_02:43]
A comparison of results from operations is as follows:

[0000068505-18-000004:8k_2_02:44]
|  | Fourth Quarter | Full Year |
|  | 2017 | 2016 | 2017 | 2016 |
| Net sales | $1,957 | $1,883 | $6,380 | $6,038 |
| Gross margin | 970 |  | 928 |  | 3,024 |  | 2,869 |  |
| Operating earnings | 511 |  | 403 |  | 1,282 |  | 1,067 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | (575 | ) | 243 |  | (155 | ) | 560 |  |
| Diluted EPS from continuing operations | $(3.56) | $1.43 | $(0.95) | $3.24 |
| Weighted average diluted common shares outstanding | 161.7 |  | 170.4 |  | 162.9 |  | 173.1 |  |

[0000068505-18-000004:8k_2_02:45]
COMPONENTS OF TAX REFORM HIGHLIGHTED ITEMS (presented in millions)

[0000068505-18-000004:8k_2_02:46]
|  | Q4 2017 |
| Remeasurement of U.S. deferred tax assets at enacted tax rate | $366 |
| Valuation allowance on foreign tax credits | $471 |
| Repatriation tax and others | $37 |
| Total | $874 |

[0000068505-18-000004:8k_2_02:47]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-18-000004:8k_2_02:48]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the fourth-quarter of 2017.

[0000068505-18-000004:8k_2_02:49]
| (per diluted common share) | Q4 2017 |  |
| Basic GAAP Loss from Continuing Operations | $(3.56) |  |
| Adjust for dilution* | $0.16 |
| Diluted Loss from Continuing Operations | $(3.40) |  |
| Highlighted Items: |  |
| Share-based compensation expense | 0.07 |  |
| Reorganization of business charges | 0.05 |  |
| Intangibles amortization expense | 0.18 |  |
| Gain on legal settlements | (0.02 | ) |
| Non-US pension settlement loss | 0.01 |  |
| Tax reform | 5.18 |  |
| Release of FIN 48 reserve | (0.01 | ) |
| Valuation allowance on non-U.S. deferred tax assets | 0.05 |  |
| Tax benefit on U.S. capital loss | (0.01 | ) |
| Total Highlighted Items | $5.50 |
| Non-GAAP Diluted EPS from Continuing Operations | $2.10 |

[0000068505-18-000004:8k_2_02:50]
* Under U.S. GAAP, the accounting for a net loss from continuing operations results in the presentation of dilutive earnings per share equal to basic earnings per share, as any increase in basic shares would be anti-dilutive to earnings per share. As a result of the highlighted items identified during Q4 2017, the Company reported a net loss from continuing operations within our GAAP Consolidated Statement of Operations, while reporting income on a non-GAAP basis. An adjustment is shown to reflect the dilution of 7.2 million dilutive shares outstanding in Q4 2017.

[0000068505-18-000004:8k_2_02:51]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-18-000004:8k_2_02:52]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-18-000004:8k_2_02:53]
Organic Revenue:  Reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. Management believes organic revenue helps it and investors better identify the underlying trends of established and ongoing operations by excluding the effects of acquisitions which can obscure period to period comparisons.

[0000068505-18-000004:8k_2_02:54]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments, significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, including recently enacted tax reform legislation, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-18-000004:8k_2_02:55]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-18-000004:8k_2_02:56]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-18-000004:8k_2_02:57]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-18-000004:8k_2_02:58]
BUSINESS RISKS

[0000068505-18-000004:8k_2_02:59]
technologies in a timely manner; (5) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (6) negative impact on the company's business from global economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company's products; (iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company's suppliers that may no longer have access to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company's pension plan and other defined benefit plans, which could impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (7) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or those it sells to or operates or maintains for its customers; (8) the outcome of ongoing and future tax matters; (9) the company's ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (10) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (11) the impact on the company's performance and financial results from strategic acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; (22) the impact of implementing a new enterprise resource planning (ERP) system; and (23) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-18-000004:8k_2_02:60]
DEFINITIONS

[0000068505-18-000004:8k_2_02:61]
1 Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.

[0000068505-18-000004:8k_2_02:62]
2 On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act or "tax reform".  Details of the fourth-quarter charges related to tax reform are included in this news release.

[0000068505-18-000004:8k_2_02:63]
3 Free cash flow represents operating cash flow less capital expenditures

[0000068505-18-000004:8k_2_02:64]
ABOUT MOTOROLA SOLUTIONS

[0000068505-18-000004:8k_2_02:65]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0000068505-18-000004:8k_2_02:66]
MEDIA CONTACT

[0000068505-18-000004:8k_2_02:67]
Tama McWhinney

[0000068505-18-000004:8k_2_02:68]
Motorola Solutions

[0000068505-18-000004:8k_2_02:69]
+1 847-538-1865

[0000068505-18-000004:8k_2_02:70]
tama.mcwhinney@motorolasolutions.com

[0000068505-18-000004:8k_2_02:71]
INVESTOR CONTACT

[0000068505-18-000004:8k_2_02:72]
Chris Kutsor

[0000068505-18-000004:8k_2_02:73]
Motorola Solutions

[0000068505-18-000004:8k_2_02:74]
+1 847-576-4995

[0000068505-18-000004:8k_2_02:75]
chris.kutsor@motorolasolutions.com

[0000068505-18-000004:8k_2_02:76]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2018 Motorola Solutions, Inc. All rights reserved.

[0000068505-18-000004:8k_2_02:77]
GAAP-1

[0000068505-18-000004:8k_2_02:78]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:79]
Consolidated Statements of Operations

[0000068505-18-000004:8k_2_02:80]
(In millions, except per share amount)

[0000068505-18-000004:8k_2_02:81]
|  | Three Months Ended |
|  | December 31, 2017 |  | December 31, 2016 |
| Net sales from products | $ | 1,233 |  |  | $ | 1,226 |  |
| Net sales from services | 724 |  |  | 657 |  |
| Net sales | 1,957 |  |  | 1,883 |  |
| Costs of products sales | 519 |  |  | 525 |  |
| Costs of services sales | 468 |  |  | 430 |  |
| Costs of sales | 987 |  |  | 955 |  |
| Gross margin | 970 |  |  | 928 |  |
| Selling, general and administrative expenses | 257 |  |  | 277 |  |
| Research and development expenditures | 154 |  |  | 142 |  |
| Other charges | 9 |  |  | 76 |  |
| Intangibles amortization | 39 |  |  | 30 |  |
| Operating earnings | 511 |  |  | 403 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (47 | ) |  | (48 | ) |
| Gains on sales of investments and businesses, net | — |  |  | 7 |  |
| Other | 1 |  |  | — |  |
| Total other expense | (46 | ) |  | (41 | ) |
| Net earnings before income taxes | 465 |  |  | 362 |  |
| Income tax expense | 1,039 |  |  | 118 |  |
| Net earnings (loss) | (574 | ) |  | 244 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (575 | ) |  | $ | 243 |  |
| Earnings (loss) per common share: |  |  |  |
| Basic: | $ | (3.56 | ) |  | $ | 1.47 |  |
| Diluted: | $ | (3.56 | ) |  | $ | 1.43 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 161.7 |  |  | 165.4 |  |
| Diluted | 161.7 |  |  | 170.4 |  |

[0000068505-18-000004:8k_2_02:82]
|  | Percentage of Net Sales* |
| Net sales from products | 63.0 | % |  | 65.1 | % |
| Net sales from services | 37.0 | % |  | 34.9 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 42.1 | % |  | 42.8 | % |
| Costs of services sales | 64.6 | % |  | 65.4 | % |
| Costs of sales | 50.4 | % |  | 50.7 | % |
| Gross margin | 49.6 | % |  | 49.3 | % |
| Selling, general and administrative expenses | 13.1 | % |  | 14.7 | % |
| Research and development expenditures | 7.9 | % |  | 7.5 | % |
| Other charges | 0.5 | % |  | 4.0 | % |
| Intangibles amortization | 2.0 | % |  | 1.6 | % |
| Operating earnings | 26.1 | % |  | 21.4 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.4 | )% |  | (2.5 | )% |
| Gains on sales of investments and businesses, net | — | % |  | 0.4 | % |
| Other | 0.1 | % |  | — | % |
| Total other expense | (2.4 | )% |  | (2.2 | )% |
| Net earnings before income taxes | 23.8 | % |  | 19.2 | % |
| Income tax expense | 53.1 | % |  | 6.3 | % |
| Net earnings (loss) | (29.3 | )% |  | 13.0 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | 0.1 | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | (29.4 | )% |  | 12.9 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-18-000004:8k_2_02:83]
GAAP-2

[0000068505-18-000004:8k_2_02:84]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:85]
Consolidated Statements of Operations

[0000068505-18-000004:8k_2_02:86]
(In millions, except per share amounts)

[0000068505-18-000004:8k_2_02:87]
|  | Years Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2015 |
| Net sales from products | $ | 3,772 |  |  | $ | 3,649 |  |  | $ | 3,676 |  |
| Net sales from services | 2,608 |  |  | 2,389 |  |  | 2,019 |  |
| Net sales | 6,380 |  |  | 6,038 |  |  | 5,695 |  |
| Costs of products sales | 1,686 |  |  | 1,649 |  |  | 1,625 |  |
| Costs of services sales | 1,670 |  |  | 1,520 |  |  | 1,351 |  |
| Costs of sales | 3,356 |  |  | 3,169 |  |  | 2,976 |  |
| Gross margin | 3,024 |  |  | 2,869 |  |  | 2,719 |  |
| Selling, general and administrative expenses | 979 |  |  | 1,000 |  |  | 1,021 |  |
| Research and development expenditures | 568 |  |  | 553 |  |  | 620 |  |
| Other charges | 44 |  |  | 136 |  |  | 76 |  |
| Intangibles amortization | 151 |  |  | 113 |  |  | 8 |  |
| Operating earnings | 1,282 |  |  | 1,067 |  |  | 994 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (201 | ) |  | (205 | ) |  | (173 | ) |
| Gains (losses) on sales of investments and businesses, net | 3 |  |  | (6 | ) |  | 107 |  |
| Other | (8 | ) |  | (12 | ) |  | (11 | ) |
| Total other expense | (206 | ) |  | (223 | ) |  | (77 | ) |
| Earnings from continuing operations before income taxes | 1,076 |  |  | 844 |  |  | 917 |  |
| Income tax expense | 1,227 |  |  | 282 |  |  | 274 |  |
| Earnings (loss) from continuing operations | (151 | ) |  | 562 |  |  | 643 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (30 | ) |
| Net earnings (loss) | (151 | ) |  | 562 |  |  | 613 |  |
| Less: Earnings attributable to noncontrolling interests | 4 |  |  | 2 |  |  | 3 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (155 | ) |  | $ | 560 |  |  | $ | 610 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax | $ | (155 | ) |  | $ | 560 |  |  | $ | 640 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (30 | ) |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (155 | ) |  | $ | 560 |  |  | $ | 610 |  |
| Earnings (loss) per common share: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Continuing operations | $ | (0.95 | ) |  | $ | 3.30 |  |  | $ | 3.21 |  |
| Discontinued operations | — |  |  | — |  |  | (0.15 | ) |
|  | $ | (0.95 | ) |  | $ | 3.30 |  |  | $ | 3.06 |  |
| Diluted: |  |  |  |  |  |
| Continuing operations | $ | (0.95 | ) |  | $ | 3.24 |  |  | $ | 3.17 |  |
| Discontinued operations | — |  |  | — |  |  | (0.15 | ) |
|  | $ | (0.95 | ) |  | $ | 3.24 |  |  | $ | 3.02 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 162.9 |  |  | 169.6 |  |  | 199.6 |  |
| Diluted | 162.9 |  |  | 173.1 |  |  | 201.8 |  |

[0000068505-18-000004:8k_2_02:88]
|  | Percentage of Net Sales* |
| Net sales from products | 59.1 | % |  | 60.4 | % |  | 64.5 | % |
| Net sales from services | 40.9 | % |  | 39.6 | % |  | 35.5 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 44.7 | % |  | 45.2 | % |  | 44.2 | % |
| Costs of services sales | 64.0 | % |  | 63.6 | % |  | 66.9 | % |
| Costs of sales | 52.6 | % |  | 52.5 | % |  | 52.3 | % |
| Gross margin | 47.4 | % |  | 47.5 | % |  | 47.7 | % |
| Selling, general and administrative expenses | 15.3 | % |  | 16.6 | % |  | 17.9 | % |
| Research and development expenditures | 8.9 | % |  | 9.2 | % |  | 10.9 | % |
| Other charges | 0.7 | % |  | 2.3 | % |  | 1.3 | % |
| Intangibles amortization | 2.4 | % |  | 1.9 | % |  | 0.1 | % |
| Operating earnings | 20.1 | % |  | 17.7 | % |  | 17.5 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (3.2 | )% |  | (3.4 | )% |  | (3.0 | )% |
| Gains (losses) on sales of investments and businesses, net | — | % |  | (0.1 | )% |  | 1.9 | % |
| Other | (0.1 | )% |  | (0.2 | )% |  | (0.2 | )% |
| Total other expense | (3.2 | )% |  | (3.7 | )% |  | (1.4 | )% |
| Earnings from continuing operations before income taxes | 16.9 | % |  | 14.0 | % |  | 16.1 | % |
| Income tax expense | 19.2 | % |  | 4.7 | % |  | 4.8 | % |
| Earnings (loss) from continuing operations | (2.4 | )% |  | 9.3 | % |  | 11.3 | % |
| Loss from discontinued operations, net of tax | — | % |  | — | % |  | (0.5 | )% |
| Net earnings (loss) | (2.4 | )% |  | 9.3 | % |  | 10.8 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | — | % |  | 0.1 | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | (2.4 | )% |  | 9.3 | % |  | 10.7 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-18-000004:8k_2_02:89]
GAAP-3

[0000068505-18-000004:8k_2_02:90]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:91]
Consolidated Balance Sheets

[0000068505-18-000004:8k_2_02:92]
(In millions)

[0000068505-18-000004:8k_2_02:93]
|  |  | December 31, 2017 |  | December 31, 2016 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,205 |  |  | $ | 967 |  |
| Restricted cash |  | 63 |  |  | 63 |  |
| Total cash and cash equivalents |  | 1,268 |  |  | 1,030 |  |
| Accounts receivable, net |  | 1,523 |  |  | 1,410 |  |
| Inventories, net |  | 327 |  |  | 273 |  |
| Other current assets |  | 832 |  |  | 755 |  |
| Total current assets |  | 3,950 |  |  | 3,468 |  |
| Property, plant and equipment, net |  | 856 |  |  | 789 |  |
| Investments |  | 247 |  |  | 238 |  |
| Deferred income taxes |  | 1,023 |  |  | 2,219 |  |
| Goodwill |  | 938 |  |  | 728 |  |
| Intangible assets, net |  | 861 |  |  | 821 |  |
| Other assets |  | 333 |  |  | 200 |  |
| Total assets |  | $ | 8,208 |  |  | $ | 8,463 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 52 |  |  | $ | 4 |  |
| Accounts payable |  | 593 |  |  | 553 |  |
| Accrued liabilities |  | 2,286 |  |  | 2,111 |  |
| Total current liabilities |  | 2,931 |  |  | 2,668 |  |
| Long-term debt |  | 4,419 |  |  | 4,392 |  |
| Other liabilities |  | 2,585 |  |  | 2,355 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,742 | ) |  | (964 | ) |
| Noncontrolling interests |  | 15 |  |  | 12 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,208 |  |  | $ | 8,463 |  |
| Financial Ratios: |  |  |  |  |
| Net cash (debt)* |  | $ | (3,203 | ) |  | $ | (3,366 | ) |
| *Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |  |  |

[0000068505-18-000004:8k_2_02:94]
GAAP-4

[0000068505-18-000004:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:96]
Consolidated Statements of Cash Flows

[0000068505-18-000004:8k_2_02:97]
(In millions)

[0000068505-18-000004:8k_2_02:98]
|  | Three Months Ended |
|  | December 31, 2017 |  | December 31, 2016 |
| Operating |  |  |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (575 | ) |  | $ | 243 |  |
| Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings (loss) | (574 | ) |  | 244 |  |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 89 |  |  | 75 |  |
| Non-cash other charges | 3 |  |  | 11 |  |
| Non-U.S. pension settlement loss | 2 |  |  | 26 |  |
| Share-based compensation expense | 17 |  |  | 16 |  |
| Gains on sales of investments and businesses, net | — |  |  | (7 | ) |
| Loss from the extinguishment of long-term debt | — |  |  | 2 |  |
| Deferred income taxes | 1,002 |  |  | 71 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (141 | ) |  | (250 | ) |
| Inventories | 37 |  |  | 6 |  |
| Other current assets | 42 |  |  | (81 | ) |
| Accounts payable and accrued liabilities | 338 |  |  | 464 |  |
| Other assets and liabilities | (54 | ) |  | (64 | ) |
| Net cash provided by operating activities | 761 |  |  | 513 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (21 | ) |  | (259 | ) |
| Proceeds from sales of investments and businesses, net | 9 |  |  | 33 |  |
| Capital expenditures | (21 | ) |  | (60 | ) |
| Proceeds from sales of property, plant and equipment | — |  |  | 4 |  |
| Net cash used for investing activities | (33 | ) |  | (282 | ) |
| Financing |  |  |  |
| Repayment of debt | (7 | ) |  | (683 | ) |
| Net proceeds from issuance of debt | 3 |  |  | — |  |
| Issuance of common stock | 21 |  |  | 14 |  |
| Purchase of common stock | (125 | ) |  | (114 | ) |
| Payment of dividends | (76 | ) |  | (68 | ) |
| Deferred acquisition costs | (2 | ) |  | — |  |
| Net cash used for financing activities | (186 | ) |  | (851 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 9 |  |  | (37 | ) |
| Net increase (decrease) in cash and cash equivalents | 551 |  |  | (657 | ) |
| Cash and cash equivalents, beginning of period | 717 |  |  | 1,687 |  |
| Cash and cash equivalents, end of period | $ | 1,268 |  |  | $ | 1,030 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 740 |  |  | $ | 453 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-18-000004:8k_2_02:99]
GAAP-5

[0000068505-18-000004:8k_2_02:100]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:101]
Consolidated Statements of Cash Flows

[0000068505-18-000004:8k_2_02:102]
(In millions)

[0000068505-18-000004:8k_2_02:103]
|  | Years Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2015 |
| Operating |  |  |  |  |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (155 | ) |  | $ | 560 |  |  | $ | 610 |  |
| Earnings attributable to noncontrolling interests | 4 |  |  | 2 |  |  | 3 |  |
| Net earnings (loss) | (151 | ) |  | 562 |  |  | 613 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | (30 | ) |
| Earnings (loss) from continuing operations, net of tax | (151 | ) |  | 562 |  |  | 643 |  |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 343 |  |  | 295 |  |  | 150 |  |
| Non-cash other charges | 32 |  |  | 54 |  |  | 52 |  |
| Non-U.S. pension curtailment gain | — |  |  | — |  |  | (32 | ) |
| Non-U.S. pension settlement loss | 48 |  |  | 26 |  |  | — |  |
| Share-based compensation expense | 66 |  |  | 68 |  |  | 78 |  |
| Loss (gains) on sales of investments and businesses, net | (3 | ) |  | 6 |  |  | (107 | ) |
| Loss from the extinguishment of long-term debt | — |  |  | 2 |  |  | — |  |
| Deferred income taxes | 1,100 |  |  | 213 |  |  | 160 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | (60 | ) |  | (6 | ) |  | 21 |  |
| Inventories | (46 | ) |  | 6 |  |  | 16 |  |
| Other current assets | (99 | ) |  | (185 | ) |  | 92 |  |
| Accounts payable and accrued liabilities | 160 |  |  | 241 |  |  | 26 |  |
| Other assets and liabilities | (44 | ) |  | (117 | ) |  | (78 | ) |
| Net cash provided by operating activities from continuing operations | 1,346 |  |  | 1,165 |  |  | 1,021 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (404 | ) |  | (1,474 | ) |  | (586 | ) |
| Proceeds from sales of investments and businesses, net | 183 |  |  | 670 |  |  | 230 |  |
| Capital expenditures | (227 | ) |  | (271 | ) |  | (175 | ) |
| Proceeds from sales of property, plant and equipment | — |  |  | 73 |  |  | 3 |  |
| Net cash used for investing activities from continuing operations | (448 | ) |  | (1,002 | ) |  | (528 | ) |
| Financing |  |  |  |  |  |
| Repayment of debt | (21 | ) |  | (686 | ) |  | (4 | ) |
| Net proceeds from issuance of debt | 10 |  |  | 673 |  |  | 971 |  |
| Issuance of common stock | 82 |  |  | 93 |  |  | 84 |  |
| Purchase of common stock | (483 | ) |  | (842 | ) |  | (3,177 | ) |
| Excess tax benefit from share-based compensation | — |  |  | — |  |  | 5 |  |
| Payment of dividends | (307 | ) |  | (280 | ) |  | (277 | ) |
| Payment of dividends to non-controlling interest | (1 | ) |  | — |  |  | — |  |
| Deferred acquisition costs | (2 | ) |  | — |  |  | — |  |
| Net cash used for financing activities from continuing operations | (722 | ) |  | (1,042 | ) |  | (2,398 | ) |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations | 62 |  |  | (71 | ) |  | (69 | ) |
| Net increase (decrease) in cash and cash equivalents | 238 |  |  | (950 | ) |  | (1,974 | ) |
| Cash and cash equivalents, beginning of period | 1,030 |  |  | 1,980 |  |  | 3,954 |  |
| Cash and cash equivalents, end of period | $ | 1,268 |  |  | $ | 1,030 |  |  | $ | 1,980 |  |
| Financial Ratios: |  |  |  |  |  |
| Free cash flow* | 1,119 |  |  | 894 |  |  | 846 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |  |  |

[0000068505-18-000004:8k_2_02:104]
GAAP-6

[0000068505-18-000004:8k_2_02:105]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:106]
Segment Information

[0000068505-18-000004:8k_2_02:107]
(In millions)

[0000068505-18-000004:8k_2_02:108]
| Net Sales |
|  | Three Months Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 1,233 |  |  | $ | 1,226 |  |  | 1 | % |  |  |
| Services | 724 |  |  | 657 |  |  | 10 | % |  |  |
| Total Motorola Solutions | $ | 1,957 |  |  | $ | 1,883 |  |  | 4 | % |  |  |
|  | Years Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 3,772 |  |  | $ | 3,649 |  |  | 3 | % |  |  |
| Services | 2,608 |  |  | 2,389 |  |  | 9 | % |  |  |
| Total Motorola Solutions | $ | 6,380 |  |  | $ | 6,038 |  |  | 6 | % |  |  |
| Operating Earnings |
|  | Three Months Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 404 |  |  | $ | 330 |  |  | 22 | % |  |  |
| Services | 107 |  |  | 73 |  |  | 47 | % |  |  |
| Total Motorola Solutions | $ | 511 |  |  | $ | 403 |  |  | 27 | % |  |  |
|  | Years Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 914 |  |  | $ | 734 |  |  | 25 | % |  |  |
| Services | 368 |  |  | 333 |  |  | 11 | % |  |  |
| Total Motorola Solutions | $ | 1,282 |  |  | $ | 1,067 |  |  | 20 | % |  |  |

[0000068505-18-000004:8k_2_02:109]
| Operating Earnings % |
|  | Three Months Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  |  |  |  |
| Products | 32.8 | % |  | 26.9 | % |  |  |  |  |
| Services | 14.8 | % |  | 11.1 | % |  |  |  |  |
| Total Motorola Solutions | 26.1 | % |  | 21.4 | % |  |  |  |  |
|  | Years Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  |  |  |  |
| Products | 24.2 | % |  | 20.1 | % |  |  |  |  |
| Services | 14.1 | % |  | 13.9 | % |  |  |  |  |
| Total Motorola Solutions | 20.1 | % |  | 17.7 | % |  |  |  |  |

[0000068505-18-000004:8k_2_02:110]
Non-GAAP-1

[0000068505-18-000004:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:112]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-18-000004:8k_2_02:113]
| Q1 2017 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 19 |  |  | 4 |  |  | 15 |  |  | 0.09 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 36 |  |  | 9 |  |  | 27 |  |  | 0.16 |  |
| Gain on legal settlement |  | Other charges |  | (42 | ) |  | (16 | ) |  | (26 | ) |  | (0.15 | ) |
| Building impairment |  | Other charges |  | 8 |  |  | — |  |  | 8 |  |  | 0.05 |  |
| Non-US pension settlement loss |  | Other charges |  | 9 |  |  | — |  |  | 9 |  |  | 0.05 |  |
| Sale of investments |  | Sale of Investment or Business (Gain) or Loss |  | (3 | ) |  | (1 | ) |  | (2 | ) |  | (0.01 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Total impact on Net earnings |  |  |  | $ | 45 |  |  | $ | 2 |  |  | $ | 43 |  |  | $ | 0.26 |  |
| Q2 2017 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 16 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 3 |  |  | — |  |  | 3 |  |  | 0.02 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 37 |  |  | 9 |  |  | 28 |  |  | 0.17 |  |
| Non-US pension settlement loss |  | Other charges |  | 16 |  |  | — |  |  | 16 |  |  | 0.08 |  |
| Gain on legal settlement |  | Other charges |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Sale of business |  | Sale of Investment or Business (Gain) or Loss |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Total impact on Net earnings |  |  |  | $ | 72 |  |  | $ | 14 |  |  | $ | 58 |  |  | $ | 0.34 |  |
| Q3 2017 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 16 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 39 |  |  | 10 |  |  | 29 |  |  | 0.17 |  |
| Non-US pension settlement loss |  | Other charges |  | 21 |  |  | — |  |  | 21 |  |  | 0.11 |  |
| Asset impairment |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Tax benefit on U.S. capital loss |  | Income tax benefit |  | — |  |  | 22 |  |  | (22 | ) |  | (0.13 | ) |
| Reserve on unrecognized tax benefit |  | Income tax expense |  | — |  |  | (1 | ) |  | 1 |  |  | 0.01 |  |
| Total impact on Net earnings |  |  |  | $ | 85 |  |  | $ | 38 |  |  | $ | 47 |  |  | $ | 0.28 |  |
| Q4 2017 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 12 |  |  | 3 |  |  | 9 |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 39 |  |  | 9 |  |  | 30 |  |  | 0.18 |  |
| Non-US pension settlement loss |  | Other charges |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Gain on legal settlements |  | Other charges |  | (5 | ) |  | (2 | ) |  | (3 | ) |  | (0.02 | ) |
| Tax benefit on U.S. capital loss |  | Income tax benefit |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Tax reform |  | Income tax expense |  | — |  |  | (874 | ) |  | 874 |  |  | 5.18 |  |
| Release of FIN 48 reserve |  | Income tax benefit |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Valuation allowance on non-U.S. deferred tax assets |  | Income tax expense |  | — |  |  | (9 | ) |  | 9 |  |  | 0.05 |  |
| Total impact on Net earnings |  |  |  | $ | 65 |  |  | $ | (865 | ) |  | $ | 930 |  |  | $ | 5.50 |  |
| FY 2017 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 66 |  |  | $ | 22 |  |  | $ | 44 |  |  | $ | 0.26 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 42 |  |  | 9 |  |  | 33 |  |  | 0.20 |  |

[0000068505-18-000004:8k_2_02:114]
| Intangibles amortization expense |  | Intangibles amortization |  | 151 |  |  | 37 |  |  | 114 |  |  | 0.67 |  |
| Gain on legal settlements |  | Other charges |  | (47 | ) |  | (17 | ) |  | (30 | ) |  | (0.18 | ) |
| Building impairment |  | Other charges |  | 8 |  |  | — |  |  | 8 |  |  | 0.05 |  |
| Non-US pension settlement loss |  | Other charges |  | 48 |  |  | — |  |  | 48 |  |  | 0.28 |  |
| Sale of investments or business |  | Sale of Investment or Business (Gain) or Loss |  | (2 | ) |  | (1 | ) |  | (1 | ) |  | (0.01 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Asset impairment |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Tax benefit on U.S. capital loss |  | Income tax benefit |  | — |  |  | 23 |  |  | (23 | ) |  | (0.14 | ) |
| Reserve on unrecognized tax benefit |  | Income tax expense |  | — |  |  | (1 | ) |  | 1 |  |  | 0.01 |  |
| Tax reform |  | Income tax expense |  | — |  |  | (874 | ) |  | 874 |  |  | 5.18 |  |
| Release of FIN 48 reserve |  | Income tax benefit |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Valuation allowance on non-U.S. deferred tax assets |  | Income tax expense |  | — |  |  | (9 | ) |  | 9 |  |  | 0.05 |  |
| Total impact on Net earnings |  |  |  | $ | 268 |  |  | $ | (810 | ) |  | $ | 1,078 |  |  | $ | 6.38 |  |

[0000068505-18-000004:8k_2_02:115]
Non-GAAP-2

[0000068505-18-000004:8k_2_02:116]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:117]
Non-GAAP Segment Information

[0000068505-18-000004:8k_2_02:118]
(In millions)

[0000068505-18-000004:8k_2_02:119]
| Net Sales |
|  | Three Months Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 1,233 |  |  | $ | 1,226 |  |  | 1 | % |  |  |
| Services | 724 |  |  | 657 |  |  | 10 | % |  |  |
| Total Motorola Solutions | $ | 1,957 |  |  | $ | 1,883 |  |  | 4 | % |  |  |
|  | Years Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 3,772 |  |  | $ | 3,649 |  |  | 3 | % |  |  |
| Services | 2,608 |  |  | 2,389 |  |  | 9 | % |  |  |
| Total Motorola Solutions | $ | 6,380 |  |  | $ | 6,038 |  |  | 6 | % |  |  |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 425 |  |  | $ | 407 |  |  | 4 | % |  |  |
| Services | 151 |  |  | 134 |  |  | 13 | % |  |  |
| Total Motorola Solutions | $ | 576 |  |  | $ | 541 |  |  | 6 | % |  |  |
|  | Years Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |  |
| Products | $ | 1,006 |  |  | $ | 910 |  |  | 11 | % |  |  |
| Services | 546 |  |  | 517 |  |  | 6 | % |  |  |
| Total Motorola Solutions | $ | 1,552 |  |  | $ | 1,427 |  |  | 9 | % |  |  |

[0000068505-18-000004:8k_2_02:120]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  |  |  |  |
| Products | 34.5 | % |  | 33.2 | % |  |  |  |  |
| Services | 20.9 | % |  | 20.4 | % |  |  |  |  |
| Total Motorola Solutions | 29.4 | % |  | 28.7 | % |  |  |  |  |
|  | Years Ended |  |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |  |  |  |  |
| Products | 26.7 | % |  | 24.9 | % |  |  |  |  |
| Services | 20.9 | % |  | 21.6 | % |  |  |  |  |
| Total Motorola Solutions | 24.3 | % |  | 23.6 | % |  |  |  |  |

[0000068505-18-000004:8k_2_02:121]
Non-GAAP-3

[0000068505-18-000004:8k_2_02:122]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:123]
Operating Earnings after Non-GAAP Adjustments

[0000068505-18-000004:8k_2_02:124]
| Q1 2017 |
|  |  | TOTAL |  | Products |  | Services |
| Net sales |  | $ | 1,281 |  |  | $ | 703 |  |  | $ | 578 |  |
| Operating earnings ("OE") |  | $ | 176 |  |  | $ | 89 |  |  | $ | 87 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 11 |  |  | 6 |  |
| Reorganization of business charges |  | 19 |  |  | 13 |  |  | 6 |  |
| Intangibles amortization expense |  | 36 |  |  | 6 |  |  | 30 |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Gain on legal settlement |  | (42 | ) |  | (30 | ) |  | (12 | ) |
| Building impairment |  | 8 |  |  | 6 |  |  | 2 |  |
| Non-US pension settlement loss |  | 9 |  |  | 6 |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  | 48 |  |  | 12 |  |  | 36 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 224 |  |  | $ | 101 |  |  | $ | 123 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 13.7 | % |  | 12.7 | % |  | 15.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 17.5 | % |  | 14.4 | % |  | 21.3 | % |

[0000068505-18-000004:8k_2_02:125]
| Q2 2017 |
|  |  | TOTAL |  | Products |  | Services |
| Net sales |  | $ | 1,497 |  |  | $ | 848 |  |  | $ | 649 |  |
| Operating earnings ("OE") |  | $ | 257 |  |  | $ | 168 |  |  | $ | 89 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 16 |  |  | 11 |  |  | 5 |  |
| Reorganization of business charges |  | 3 |  |  | 3 |  |  | — |  |
| Intangibles amortization expense |  | 37 |  |  | 1 |  |  | 36 |  |
| Gain on legal settlement |  | (1 | ) |  | (1 | ) |  | — |  |
| Non-US pension settlement loss |  | 16 |  |  | 11 |  |  | 5 |  |
| Total above-OE non-GAAP adjustments |  | 71 |  |  | 25 |  |  | 46 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 328 |  |  | $ | 193 |  |  | $ | 135 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 17.2 | % |  | 19.8 | % |  | 13.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 21.9 | % |  | 22.8 | % |  | 20.8 | % |

[0000068505-18-000004:8k_2_02:126]
| Q3 2017 |
|  |  | TOTAL |  | Products |  | Services |
| Net sales |  | $ | 1,645 |  |  | $ | 989 |  |  | $ | 656 |  |
| Operating earnings ("OE") |  | $ | 338 |  |  | $ | 253 |  |  | $ | 85 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 16 |  |  | 10 |  |  | 6 |  |
| Reorganization of business charges |  | 8 |  |  | 6 |  |  | 2 |  |
| Intangibles amortization expense |  | 39 |  |  | 2 |  |  | 37 |  |
| Non-US pension settlement loss |  | 21 |  |  | 15 |  |  | 6 |  |
| Asset impairment |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 85 |  |  | 34 |  |  | 51 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 423 |  |  | $ | 287 |  |  | $ | 136 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 20.5 | % |  | 25.6 | % |  | 13.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 25.7 | % |  | 29.0 | % |  | 20.7 | % |

[0000068505-18-000004:8k_2_02:127]
| Q4 2017 |
|  |  | TOTAL |  | Products |  | Services |
| Net sales |  | $ | 1,957 |  |  | $ | 1,233 |  |  | $ | 724 |  |
| Operating earnings ("OE") |  | $ | 511 |  |  | $ | 404 |  |  | $ | 107 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 11 |  |  | 6 |  |
| Reorganization of business charges |  | 12 |  |  | 9 |  |  | 3 |  |
| Non-U.S. pension settlement loss |  | 2 |  |  | 1 |  |  | 1 |  |
| Gain on legal settlements |  | (5 | ) |  | (3 | ) |  | (2 | ) |
| Intangibles amortization expense |  | 39 |  |  | 3 |  |  | 36 |  |
| Total above-OE non-GAAP adjustments |  | 65 |  |  | 21 |  |  | 44 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 576 |  |  | $ | 425 |  |  | $ | 151 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 26.1 | % |  | 32.8 | % |  | 14.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 29.4 | % |  | 34.5 | % |  | 20.9 | % |

[0000068505-18-000004:8k_2_02:128]
| FY 2017 |
|  |  | TOTAL |  | Products |  | Services |
| Net sales |  | $ | 6,380 |  |  | $ | 3,772 |  |  | $ | 2,608 |  |
| Operating earnings ("OE") |  | $ | 1,282 |  |  | $ | 914 |  |  | $ | 368 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 66 |  |  | 43 |  |  | 23 |  |
| Reorganization of business charges |  | 42 |  |  | 31 |  |  | 11 |  |
| Intangibles amortization expense |  | 151 |  |  | 12 |  |  | 139 |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Gain on legal settlements |  | (47 | ) |  | (34 | ) |  | (13 | ) |
| Building impairment |  | 8 |  |  | 6 |  |  | 2 |  |
| Non-US pension settlement loss |  | 48 |  |  | 33 |  |  | 15 |  |
| Asset impairment |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 270 |  |  | 92 |  |  | 178 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,552 |  |  | $ | 1,006 |  |  | $ | 546 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 20.1 | % |  | 24.2 | % |  | 14.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.3 | % |  | 26.7 | % |  | 20.9 | % |

[0000068505-18-000004:8k_2_02:129]
Non-GAAP-4

[0000068505-18-000004:8k_2_02:130]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:131]
Non-GAAP Organic Revenue

[0000068505-18-000004:8k_2_02:132]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |  |
|  |  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |
| Net sales |  | $ | 1,957 |  |  | $ | 1,883 |  |  | 4 | % |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Acquisitions |  | (48 | ) |  | (8 | ) |  |  |  |
| Organic revenue |  | 1,909 |  |  | $ | 1,875 |  |  | 2 | % |  |

[0000068505-18-000004:8k_2_02:133]
|  |  | Years Ended |  |  |  |
|  |  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |
| Net sales |  | 6,380 |  |  | 6,038 |  |  | 6 | % |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Acquisitions |  | (261 | ) |  | (69 | ) |  |  |  |
| Organic revenue |  | $ | 6,119 |  |  | $ | 5,969 |  |  | 3 | % |  |

[0000068505-18-000004:8k_2_02:134]
| North America |
|  |  | Three Months Ended |  |  |  |
|  |  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |
| Americas net sales |  | 1,351 |  |  | 1,269 |  |  | 6 | % |  |
| Adjustments: |  |  |  |  |  |  |  |
| Latin America net sales |  | (103 | ) |  | (99 | ) |  |  |  |  |
| North America acquisitions |  | (26 | ) |  | (8 | ) |  |  |  |
| North America organic revenue |  | 1,222 |  |  | 1,162 |  |  | 5 | % |  |

[0000068505-18-000004:8k_2_02:135]
|  |  | Years Ended |  |  |  |
|  |  | December 31, 2017 |  | December 31, 2016 |  | % Change |  |
| Americas net sales |  | 4,341 |  |  | 4,074 |  |  | 7 | % |  |
| Adjustments: |  |  |  |  |  |  |  |
| Latin America net sales |  | (365 | ) |  | (285 | ) |  |  |  |
| North America acquisitions |  | (67 | ) |  | (8 | ) |  |  |  |
| North America organic revenue |  | 3,909 |  |  | 3,781 |  |  | 3 | % |  |

[0000068505-18-000004:8k_2_02:136]
Non-GAAP-5

[0000068505-18-000004:8k_2_02:137]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000004:8k_2_02:138]
Non-GAAP Earnings Per Share

[0000068505-18-000004:8k_2_02:139]
| (per diluted common share) | Q4 2017 |  | 2017 |  |
| Basic GAAP Loss from Continuing Operations | $(3.56) |  | $(0.95) |  |
| Adjust for dilution* | $0.16 | $0.03 |
| Diluted Loss from Continuing Operations | $(3.40) |  | $(0.92) |  |
| Highlighted Items: |  |  |
| Share-based compensation expense | 0.07 |  | 0.26 |  |
| Reorganization of business charges | 0.05 |  | 0.20 |  |
| Intangibles amortization expense | 0.18 |  | 0.67 |  |
| Gain on legal settlements | (0.02 | ) | (0.18 | ) |
| Non-US pension settlement loss | 0.01 |  | 0.28 |  |
| Tax reform | 5.18 |  | 5.18 |  |
| Release of FIN 48 reserve | (0.01 | ) | (0.01 | ) |
| Valuation allowance on non-U.S. deferred tax assets | 0.05 |  | 0.05 |  |
| Tax benefit on U.S. capital loss | (0.01 | ) | (0.14 | ) |
| Reserve on unrecognized tax benefit | — |  | 0.01 |  |
| Acquisition-related transaction fees | — |  | 0.01 |  |
| Asset impairment | — |  | 0.01 |  |
| Sale of investments or business | — |  | (0.01 | ) |
| Building impairment | — |  | 0.05 |  |
| Total Highlighted Items | $5.50 | $6.38 |
| Non-GAAP Diluted EPS from Continuing Operations | $2.10 | $5.46 |

[0000068505-18-000004:8k_2_02:140]
* Under U.S. GAAP, the accounting for a net loss from continuing operations results in the presentation of dilutive earnings per share equal to basic earnings per share, as any increase in basic shares would be anti-dilutive to earnings per share. As a result of the highlighted items identified during Q4 2017, the Company reported a net loss from continuing operations for the three months and year ended December 31, 2017 within our GAAP Consolidated Statement of Operations, while reporting income on a non-GAAP basis over the same periods. An adjustment is reflected to correct for the dilution of 7.2 million dilutive shares outstanding in Q4 2017 and 6.4 million dilutive shares outstanding for the full-year 2017.
