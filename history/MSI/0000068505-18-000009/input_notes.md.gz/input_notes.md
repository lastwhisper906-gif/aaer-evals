# MSI notes — 0000068505-18-000009


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-18-000009:notes:1]
Investments consist of the following:

[0000068505-18-000009:notes:2]
| December 31, 2017 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Common stock | 5 |  |  | 8 |  |  | 13 |  |
|  | 7 |  |  | 8 |  |  | 15 |  |
| Other investments | 219 |  |  | — |  |  | 219 |  |
| Equity method investments | 13 |  |  | — |  |  | 13 |  |
|  | $ | 239 |  |  | $ | 8 |  |  | $ | 247 |  |

[0000068505-18-000009:notes:3]
| December 31, 2016 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |
| Corporate bonds | 5 |  |  | — |  |  | 5 |  |
|  | 56 |  |  | — |  |  | 56 |  |
| Other investments | 211 |  |  | — |  |  | 211 |  |
| Equity method investments | 17 |  |  | — |  |  | 17 |  |
|  | 284 |  |  | — |  |  | 284 |  |
| Less: current portion of available-for-sale securities |  |  |  |  | 46 |  |
|  |  |  |  |  | $ | 238 |  |


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-18-000009:notes:4]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-18-000009:notes:5]
| December 31 | 2017 |  | 2016 |
| Long-term receivables | $ | 37 |  |  | $ | 63 |  |
| Less current portion | (18 | ) |  | (14 | ) |
| Non-current long-term receivables | $ | 19 |  |  | $ | 49 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-18-000009:notes:6]
Long-term Financing and Sales of Receivables

[0000068505-18-000009:notes:7]
Long-term Financing

[0000068505-18-000009:notes:8]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s consolidated balance sheets. The Company recognized Interest income on long-term receivables of $1 million, $2 million, and $2 million for the years ended December 31, 2017, 2016 and 2015.

[0000068505-18-000009:notes:9]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $93 million at December 31, 2017, compared to $125 million at December 31, 2016.

[0000068505-18-000009:notes:10]
Sales of Receivables

[0000068505-18-000009:notes:11]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements. The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-18-000009:notes:12]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2017, 2016 and 2015.

[0000068505-18-000009:notes:13]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Accounts receivable sales proceeds | $ | 193 |  |  | $ | 51 |  |  | $ | 29 |  |
| Long-term receivables sales proceeds | 284 |  |  | 289 |  |  | 196 |  |
| Total proceeds from receivable sales | $ | 477 |  |  | $ | 340 |  |  | $ | 225 |  |

[0000068505-18-000009:notes:14]
At December 31, 2017, the Company had retained servicing obligations for $873 million of long-term receivables, compared to $774 million of long-term receivables at December 31, 2016. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-18-000009:notes:15]
Credit Quality of Financing Receivables and Allowance for Credit Losses

[0000068505-18-000009:notes:16]
An aging analysis of financing receivables at December 31, 2017 and December 31, 2016 is as follows:

[0000068505-18-000009:notes:17]
| December 31, 2017 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 21 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |
| Commercial loans and leases secured | 16 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 37 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 3 |  |

[0000068505-18-000009:notes:18]
| December 31, 2016 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 20 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 43 |  |  | — |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 63 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |

[0000068505-18-000009:notes:19]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.

[0000068505-18-000009:notes:20]
The Company’s policy for valuing the allowance for credit losses is to review all customer financing receivables for collectability on an individual receivable basis. For those receivables where collection risk is probable, the Company calculates the value of impairment based on the net present value of expected future cash flows from the customer.


## msi:OtherChargesTableTextBlock

[0000068505-18-000009:notes:21]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-18-000009:notes:22]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 14) | $ | 151 |  |  | $ | 113 |  |  | $ | 8 |  |
| Reorganization of businesses (Note 13) | 33 |  |  | 77 |  |  | 71 |  |
| Gain on legal settlement | (47 | ) |  | — |  |  | — |  |
| Asset impairments | 9 |  |  | 20 |  |  | 37 |  |
| Non-U.S. pension curtailment gain (Note 7) | — |  |  | — |  |  | (32 | ) |
| Non-U.S. pension plan settlement loss (Note 7) | 48 |  |  | 26 |  |  | — |  |
| Acquisition-related transaction fees | 1 |  |  | 13 |  |  | — |  |
|  | $ | 195 |  |  | $ | 249 |  |  | $ | 84 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-18-000009:notes:23]
The following table displays the net charges incurred by segment:

[0000068505-18-000009:notes:24]
| Year ended December 31 | 2015 |
| Products | $ | 84 |  |
| Services | 33 |  |
|  | $ | 117 |  |

[0000068505-18-000009:notes:25]
| Year ended December 31 | 2016 |
| Products | $ | 106 |  |
| Services | 34 |  |
|  | $ | 140 |  |

[0000068505-18-000009:notes:26]
| Year ended December 31 | 2017 |
| Products | $ | 31 |  |
| Services | 11 |  |
|  | $ | 42 |  |


## msi:RetirementBenefitsPolicyPolicyTextBlock

[0000068505-18-000009:notes:27]
The Company records annual expenses relating to its pension benefit and postretirement plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s consolidated balance sheets using a December 31 measurement date.


## msi:SalesAndUseTaxesPolicyTextBlock

[0000068505-18-000009:notes:28]
The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes, on a net basis with such taxes excluded from revenue.


## msi:ScheduleOfAccumulatedBenefitObligationsForPlansTableTextBlock

[0000068505-18-000009:notes:29]
The accumulated benefit obligations for the plans were as follows:

[0000068505-18-000009:notes:30]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |
| December 31 | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Accumulated benefit obligation | $ | 5,235 |  |  | $ | 4,644 |  |  | $ | 1,838 |  |  | $ | 1,785 |  |


## msi:ScheduleOfCorporateRelatedExpensesAndAssetsTableTextBlock

[0000068505-18-000009:notes:31]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-18-000009:notes:32]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Products | $ | 116 |  |  | $ | 104 |  |  | $ | 76 |  |  | $ | 102 |  |  | $ | 68 |  |  | $ | 82 |  |
| Services | 111 |  |  | 167 |  |  | 99 |  |  | 90 |  |  | 114 |  |  | 60 |  |
|  | $ | 227 |  |  | $ | 271 |  |  | $ | 175 |  |  | $ | 192 |  |  | $ | 182 |  |  | $ | 142 |  |


## msi:ScheduleOfDefinedBenefitPlanTargetandActualAssetAllocationTableTextBlock

[0000068505-18-000009:notes:33]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-18-000009:notes:34]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 31 | % |  | 33 | % |  | 35 | % |  | 37 | % |
| Fixed income securities | 49 | % |  | 46 | % |  | 44 | % |  | 43 | % |
| Cash and other investments | 20 | % |  | 21 | % |  | 21 | % |  | 20 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 29 | % |  | 34 | % |  | 34 | % |  | 37 | % |
| Fixed income securities | 49 | % |  | 47 | % |  | 44 | % |  | 43 | % |
| Cash and other investments | 22 | % |  | 19 | % |  | 22 | % |  | 20 | % |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-18-000009:notes:35]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-18-000009:notes:36]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 9 |  |  | $ | 9 |  |  | $ | 9 |  |
| Selling, general and administrative expenses | 43 |  |  | 45 |  |  | 52 |  |
| Research and development expenditures | 14 |  |  | 14 |  |  | 17 |  |
| Share-based compensation expense included in Operating earnings | 66 |  |  | 68 |  |  | 78 |  |
| Tax benefit | 22 |  |  | 21 |  |  | 24 |  |
| Share-based compensation expense, net of tax | $ | 44 |  |  | $ | 47 |  |  | $ | 54 |  |
| Decrease in basic earnings per share | $ | (0.27 | ) |  | $ | (0.28 | ) |  | $ | (0.25 | ) |
| Decrease in diluted earnings per share | $ | (0.27 | ) |  | $ | (0.27 | ) |  | $ | (0.25 | ) |


## msi:ScheduleOfExpectedFutureServiceBenefitPaymentsTableTextBlock

[0000068505-18-000009:notes:37]
The following benefit payments are expected to be paid:

[0000068505-18-000009:notes:38]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2018 | $ | 135 |  |  | $ | 43 |  |  | $ | 8 |  |
| 2019 | 151 |  |  | 45 |  |  | 7 |  |
| 2020 | 168 |  |  | 46 |  |  | 7 |  |
| 2021 | 190 |  |  | 47 |  |  | 6 |  |
| 2022 | 213 |  |  | 49 |  |  | 6 |  |
| 2023-2027 | 1,338 |  |  | 261 |  |  | 26 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-18-000009:notes:39]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-18-000009:notes:40]
|  | 2017 |  | 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 173 |  |  | $ | 76 |  |  | $ | 178 |  |  | $ | 63 |  |
| Services | 1,010 |  |  | 246 |  |  | 805 |  |  | 99 |  |
|  | $ | 1,183 |  |  | $ | 322 |  |  | $ | 983 |  |  | $ | 162 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-18-000009:notes:41]
Other liabilities consist of the following:

[0000068505-18-000009:notes:42]
| December 31 | 2017 |  | 2016 |
| Defined benefit plans | $ | 2,019 |  |  | $ | 1,799 |  |
| Deferred revenue | 169 |  |  | 115 |  |
| Unrecognized tax benefits | 54 |  |  | 39 |  |
| Deferred income taxes | 115 |  |  | 121 |  |
| Deferred consideration (Note 14) | — |  |  | 72 |  |
| Other | 228 |  |  | 209 |  |
|  | $ | 2,585 |  |  | $ | 2,355 |  |


## msi:ScheduleOfPensionAndPostretirementHealthCarePlanAssetsTextBlockTableTextBlock

[0000068505-18-000009:notes:43]
Non-U.S. Pension Benefit Plans

[0000068505-18-000009:notes:44]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 136 |  |  | $ | — |  |  | $ | 136 |  |
| Commingled funds | 431 |  |  | 38 |  |  | 469 |  |
| Government fixed income securities | 3 |  |  | 779 |  |  | 782 |  |
| Short-term investment funds | 92 |  |  | — |  |  | 92 |  |
| Total investment securities | $ | 662 |  |  | $ | 817 |  |  | $ | 1,479 |  |
| Cash |  |  |  |  | 3 |  |
| Accrued income receivable |  |  |  |  | 55 |  |
| Insurance contracts |  |  |  |  | 53 |  |
| Fair value plan assets |  |  |  |  | $ | 1,590 |  |

[0000068505-18-000009:notes:45]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 161 |  |  | $ | — |  |  | $ | 161 |  |
| Commingled funds | 279 |  |  | 209 |  |  | 488 |  |
| Government fixed income securities | — |  |  | 823 |  |  | 823 |  |
| Short-term investment funds | — |  |  | 1 |  |  | 1 |  |
| Total investment securities | $ | 440 |  |  | $ | 1,033 |  |  | $ | 1,473 |  |
| Cash |  |  |  |  | 45 |  |
| Insurance contracts |  |  |  |  | 47 |  |
| Fair value plan assets |  |  |  |  | $ | 1,565 |  |

[0000068505-18-000009:notes:46]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2017 and 2016 were as follows:

[0000068505-18-000009:notes:47]
U.S. Pension Benefit Plans

[0000068505-18-000009:notes:48]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Commingled funds | 2,198 |  |  | — |  |  | 2,198 |  |
| Government fixed income securities | 10 |  |  | 285 |  |  | 295 |  |
| Corporate fixed income securities | — |  |  | 900 |  |  | 900 |  |
| Short-term investment funds | 186 |  |  | — |  |  | 186 |  |
| Total investment securities | $ | 2,404 |  |  | $ | 1,185 |  |  | $ | 3,589 |  |
| Accrued income receivable |  |  |  |  | 12 |  |
| Cash |  |  |  |  | 13 |  |
| Fair value plan assets |  |  |  |  | $ | 3,614 |  |

[0000068505-18-000009:notes:49]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 95 |  |  | $ | — |  |  | $ | 95 |  |
| Commingled funds | 1,357 |  |  | 551 |  |  | 1,908 |  |
| Government fixed income securities | — |  |  | 179 |  |  | 179 |  |
| Corporate fixed income securities | — |  |  | 825 |  |  | 825 |  |
| Short-term investment funds | 183 |  |  | — |  |  | 183 |  |
| Total investment securities | $ | 1,635 |  |  | $ | 1,555 |  |  | $ | 3,190 |  |
| Cash |  |  |  |  | 5 |  |
| Fair value plan assets |  |  |  |  | $ | 3,195 |  |

[0000068505-18-000009:notes:50]
Postretirement Health Care Benefits Plan

[0000068505-18-000009:notes:51]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Commingled funds | 92 |  |  | — |  |  | 92 |  |
| Government fixed income securities | — |  |  | 12 |  |  | 12 |  |
| Corporate fixed income securities | — |  |  | 38 |  |  | 38 |  |
| Short-term investment funds | 8 |  |  | — |  |  | 8 |  |
| Fair value plan assets | $ | 101 |  |  | $ | 50 |  |  | $ | 151 |  |

[0000068505-18-000009:notes:52]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Commingled funds | 58 |  |  | 24 |  |  | 82 |  |
| Government fixed income securities | — |  |  | 7 |  |  | 7 |  |
| Corporate fixed income securities | — |  |  | 35 |  |  | 35 |  |
| Short-term investment funds | 8 |  |  | — |  |  | 8 |  |
| Fair value plan assets | $ | 70 |  |  | $ | 66 |  |  | $ | 136 |  |


## msi:ScheduleOfStatusOfCompanyPensionPlansTableTextBlock

[0000068505-18-000009:notes:53]
The status of the Company’s plans is as follows:

[0000068505-18-000009:notes:54]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 4,644 |  |  | $ | 4,304 |  |  | $ | 1,791 |  |  | $ | 1,815 |  |  | $ | 83 |  |  | $ | 192 |  |
| Service cost | — |  |  | — |  |  | 3 |  |  | 11 |  |  | — |  |  | — |  |
| Interest cost | 185 |  |  | 182 |  |  | 40 |  |  | 55 |  |  | 3 |  |  | 4 |  |
| Plan amendments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (70 | ) |
| Settlements | — |  |  | — |  |  | (201 | ) |  | (103 | ) |  | — |  |  | — |  |
| Actuarial loss (gain) | 502 |  |  | 256 |  |  | 52 |  |  | 359 |  |  | 6 |  |  | (27 | ) |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 193 |  |  | (293 | ) |  | — |  |  | — |  |
| Expenses and tax payments | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | — |  |
| Benefit payments | (96 | ) |  | (98 | ) |  | (34 | ) |  | (46 | ) |  | (7 | ) |  | (16 | ) |
| Benefit obligation at December 31 | $ | 5,235 |  |  | $ | 4,644 |  |  | $ | 1,844 |  |  | $ | 1,791 |  |  | $ | 85 |  |  | $ | 83 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,195 |  |  | $ | 3,130 |  |  | $ | 1,565 |  |  | $ | 1,696 |  |  | $ | 136 |  |  | $ | 143 |  |
| Return on plan assets | 512 |  |  | 160 |  |  | 96 |  |  | 309 |  |  | 21 |  |  | 6 |  |
| Company contributions | 3 |  |  | 3 |  |  | 7 |  |  | 8 |  |  | — |  |  | — |  |
| Settlements | — |  |  | — |  |  | (201 | ) |  | (103 | ) |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 157 |  |  | (292 | ) |  | — |  |  | — |  |
| Expenses and tax payments | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | — |  |
| Benefit payments | (96 | ) |  | (98 | ) |  | (34 | ) |  | (46 | ) |  | (6 | ) |  | (13 | ) |
| Fair value at December 31 | $ | 3,614 |  |  | $ | 3,195 |  |  | $ | 1,590 |  |  | $ | 1,565 |  |  | $ | 151 |  |  | $ | 136 |  |
| Funded status of the plan | $ | (1,621 | ) |  | $ | (1,449 | ) |  | $ | (254 | ) |  | $ | (226 | ) |  | $ | 66 |  |  | $ | 53 |  |
| Unrecognized net loss | 2,229 |  |  | 2,054 |  |  | 518 |  |  | 559 |  |  | 64 |  |  | 75 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (49 | ) |  | (67 | ) |
| Prepaid pension cost | $ | 608 |  |  | $ | 605 |  |  | $ | 264 |  |  | $ | 333 |  |  | $ | 81 |  |  | $ | 61 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | (3 | ) |  | (3 | ) |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |
| Non-current benefit liability | (1,618 | ) |  | (1,446 | ) |  | (294 | ) |  | (251 | ) |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 40 |  |  | 25 |  |  | 66 |  |  | 53 |  |
| Deferred income taxes | 544 |  |  | 762 |  |  | 58 |  |  | 57 |  |  | 6 |  |  | 4 |  |
| Accumulated other comprehensive loss | 1,685 |  |  | 1,292 |  |  | 460 |  |  | 502 |  |  | 9 |  |  | 4 |  |
| Prepaid pension cost | $ | 608 |  |  | $ | 605 |  |  | $ | 264 |  |  | $ | 333 |  |  | $ | 81 |  |  | $ | 61 |  |


## msi:ScheduleOfSummaryOfOpenTaxYearsByMajorJurisdictionTableTextBlock

[0000068505-18-000009:notes:55]
A summary of open tax years by major jurisdiction is presented below:

[0000068505-18-000009:notes:56]
| Jurisdiction | Tax Years |
| United States | 2008-2017 |
| Australia | 2014-2017 |
| Brazil | 2013-2017 |
| Canada | 2014-2017 |
| China | 2013-2017 |
| Mexico | 2012-2017 |
| Germany | 2011-2017 |
| India | 1997-2017 |
| Israel | 2012-2017 |
| Poland | 2014-2017 |
| Malaysia | 2010-2017 |
| United Kingdom | 2016-2017 |


## msi:ScheduleOfTaxCutsAndJobsActof2017IncompleteAccountingProvisionalIncomeTaxExpenseBenefitTableTextBlock

[0000068505-18-000009:notes:57]
As required under U.S. GAAP, the effects of tax law changes are recognized in the period of enactment. Accordingly, the Company has recorded incremental income tax expense in the amount of $874 million associated with the Tax Act during the year ended December 31, 2017, which is summarized as follows:

[0000068505-18-000009:notes:58]
| Year ended December 31, 2017 |  | Financial Statement Location |
| Valuation allowance on foreign tax credit carryforward | $ | 471 |  | Deferred tax expense |
| Re-measurement of U.S. deferred tax balances at 21% | 366 |  | Deferred tax expense |
| Transition tax on repatriation of foreign earnings | 16 |  | Current tax expense |
| Uncertain tax positions on foreign operations | 21 |  | Current tax expense |
| Total | $ | 874 |  |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineBenefitObligationsForPlansTableTextBlock

[0000068505-18-000009:notes:59]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-18-000009:notes:60]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Discount rate | 3.79 | % |  | 4.42 | % |  | 2.34 | % |  | 2.54 | % |  | 3.62 | % |  | 4.11 | % |
| Future compensation increase rate | n/a |  |  | n/a |  |  | 0.52 | % |  | 0.46 | % |  | n/a |  |  | n/a |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineCostsForPlansTableTextBlock

[0000068505-18-000009:notes:61]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-18-000009:notes:62]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Discount rate | 4.43 | % |  | 4.27 | % |  | 2.51 | % |  | 3.22 | % |  | 3.29 | % |  | 3.14 | % |
| Investment return assumption | 6.95 | % |  | 7.00 | % |  | 5.20 | % |  | 5.90 | % |  | 7.00 | % |  | 7.00 | % |


## msi:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanEmployeeStockOptionsValuationAssumptionsTableTextBlock

[0000068505-18-000009:notes:63]
The following assumptions were used for the calculations.

[0000068505-18-000009:notes:64]
|  | 2017Performance Options |  | 2016Performance Options |  | 2015Performance Options |
| Expected volatility of common stock | 24.1 | % |  | 25.3 | % |  | 21.0 | % |
| Expected volatility of the S&P 500 | 25.6 | % |  | 19.8 | % |  | 23.3 | % |
| Risk-free interest rate | 2.4 | % |  | 1.7 | % |  | 1.8 | % |
| Dividend yield | 3.7 | % |  | 2.8 | % |  | 2.9 | % |
| Expected life (years) | 6.5 |  |  | 6.5 |  |  | 6.5 |  |

[0000068505-18-000009:notes:65]
|  | 2017Market Stock Units |  | 2016Market Stock Units |  | 2015Market Stock Units |
| Expected volatility of common stock | 24.1 | % |  | 24.2 | % |  | 19.3 | % |
| Risk-free interest rate | 1.7 | % |  | 1.1 | % |  | 1.1 | % |
| Dividend yield | 2.9 | % |  | 2.8 | % |  | 2.9 | % |

[0000068505-18-000009:notes:66]
|  | 2017 PCSOs |  | 2015 PCSOs |
| Expected volatility of common stock | 24.1 | % |  | 26.0 | % |
| Risk-free interest rate | 1.8 | % |  | 1.5 | % |
| Dividend yield | 3.0 | % |  | 3.1 | % |
| Expected life (years) | 3.5 |  |  | 5 |  |


## msi:ShareBasedCompensationCostsPolicyTextBlock

[0000068505-18-000009:notes:67]
The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.


## msi:ValuationAndQualifyingAccountsTableTextBlock

[0000068505-18-000009:notes:68]
The following table presents the valuation and qualifying account activity for the years ended December 31, 2017, 2016, and 2015:

[0000068505-18-000009:notes:69]
|  | Balance atJanuary 1 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31 |
| 2017 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 44 |  |  | $ | 16 |  |  | $ | (16 | ) |  | $ | 1 |  |  | $ | 45 |  |
| Inventory reserves | 131 |  |  | 21 |  |  | (19 | ) |  | — |  |  | 133 |  |
| 2016 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 28 |  |  | 44 |  |  | (26 | ) |  | (2 | ) |  | 44 |  |
| Inventory reserves | 142 |  |  | 20 |  |  | (33 | ) |  | 2 |  |  | 131 |  |
| 2015 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 35 |  |  | 9 |  |  | (17 | ) |  | 1 |  |  | 28 |  |
| Inventory reserves | 131 |  |  | 24 |  |  | (13 | ) |  | — |  |  | 142 |  |

[0000068505-18-000009:notes:70]
* Adjustments include translation adjustments


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-18-000009:notes:71]
Other Financial Data

[0000068505-18-000009:notes:72]
Statement of Operations Information

[0000068505-18-000009:notes:73]
Other Charges (Income)

[0000068505-18-000009:notes:74]
During the year ended December 31, 2017, the Company recognized a net gain of $47 million related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business. The net gain of $47 million was based on $57 million of proceeds received, net $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-18-000009:notes:75]
During the years ended December 31, 2017, December 31, 2016 and December 31, 2015, the Company recognized $9 million, $20 million and $37 million, respectively, of asset impairments. During the years ended December 31, 2017 and December 31, 2016, the impairments were primarily related to building impairments from the sale of various corporate and manufacturing facilities. During the year ended December 31, 2015, the impairments were primarily driven by the sale of the Company's corporate aircraft.

[0000068505-18-000009:notes:76]
During the year ended December 31, 2017, the Company expensed $1 million of acquisition-related transaction fees compared to $13 million of transaction fees related to the acquisition of Airwave during the year ended December 31, 2016.

[0000068505-18-000009:notes:77]
Other Income (Expense)

[0000068505-18-000009:notes:78]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-18-000009:notes:79]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (215 | ) |  | $ | (225 | ) |  | $ | (186 | ) |
| Interest income | 14 |  |  | 20 |  |  | 13 |  |
|  | $ | (201 | ) |  | $ | (205 | ) |  | $ | (173 | ) |
| Other: |  |  |  |  |  |
| Loss from the extinguishment of long-term debt | $ | — |  |  | $ | (2 | ) |  | $ | — |  |
| Investment impairments | — |  |  | (4 | ) |  | (6 | ) |
| Foreign currency gain (loss) | (31 | ) |  | 46 |  |  | (23 | ) |
| Gain (loss) on derivative instruments | 15 |  |  | (56 | ) |  | 7 |  |
| Gains on equity method investments | 1 |  |  | 5 |  |  | 6 |  |
| Realized foreign currency loss on acquisition | — |  |  | (10 | ) |  | — |  |
| Other | 7 |  |  | 9 |  |  | 5 |  |
|  | $ | (8 | ) |  | $ | (12 | ) |  | $ | (11 | ) |

[0000068505-18-000009:notes:80]
During the year ended December 31, 2017, the Company recognized a foreign currency loss of $31 million, primarily driven by the Euro and British pound, partially offset by a gain of $15 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-18-000009:notes:81]
During the year ended December 31, 2016, the Company recognized a foreign currency gain of $46 million, primarily driven by the British pound, offset by a loss of $56 million, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations. The Company also realized a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave during the year ended December 31, 2016.

[0000068505-18-000009:notes:82]
During the year ended December 31, 2015, the Company recognized foreign currency loss of $23 million, primarily driven by the Euro and Brazilian real, partially offset by a gain of $7 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-18-000009:notes:83]
Earnings Per Common Share

[0000068505-18-000009:notes:84]
Basic and diluted earnings per common share from both continuing operations and net earnings attributable to Motorola Solutions, Inc. is computed as follows:

[0000068505-18-000009:notes:85]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings (loss) from Continuing Operations |  | Net Earnings (loss) |
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | (155 | ) |  | $ | 560 |  |  | $ | 640 |  |  | $ | (155 | ) |  | $ | 560 |  |  | $ | 610 |  |
| Weighted average common shares outstanding | 162.9 |  |  | 169.6 |  |  | 199.6 |  |  | 162.9 |  |  | 169.6 |  |  | 199.6 |  |
| Per share amount | $ | (0.95 | ) |  | $ | 3.30 |  |  | $ | 3.21 |  |  | $ | (0.95 | ) |  | $ | 3.30 |  |  | $ | 3.06 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | (155 | ) |  | $ | 560 |  |  | $ | 640 |  |  | $ | (155 | ) |  | $ | 560 |  |  | $ | 610 |  |
| Weighted average common shares outstanding | 162.9 |  |  | 169.6 |  |  | 199.6 |  |  | 162.9 |  |  | 169.6 |  |  | 199.6 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards | — |  |  | 2.7 |  |  | 2.1 |  |  | — |  |  | 2.7 |  |  | 2.1 |  |
| Senior Convertible Notes | — |  |  | 0.8 |  |  | 0.1 |  |  | — |  |  | 0.8 |  |  | 0.1 |  |
| Diluted weighted average common shares outstanding | 162.9 |  |  | 173.1 |  |  | 201.8 |  |  | 162.9 |  |  | 173.1 |  |  | 201.8 |  |
| Per share amount | $ | (0.95 | ) |  | $ | 3.24 |  |  | $ | 3.17 |  |  | $ | (0.95 | ) |  | $ | 3.24 |  |  | $ | 3.02 |  |

[0000068505-18-000009:notes:86]
In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2017, the Company recorded a net loss from continuing operations and, accordingly, the basic and diluted weighted average shares outstanding are equal because any increase to the basic shares would be antidilutive, including the assumed exercise of 8.7 million options, the assumed vesting of 1.4 million RSUs, and 3.1 million shares related to the Senior Convertible Notes. In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2016, the assumed exercise of 2.8 million stock options and the assumed vesting of 0.3 million RSUs, including 2.0 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2015, the assumed exercise of 2.7 million stock options and the assumed vesting of 0.3 million RSUs, including 1.2 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-18-000009:notes:87]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-18-000009:notes:88]
Balance Sheet Information

[0000068505-18-000009:notes:89]
Accounts Receivable, Net

[0000068505-18-000009:notes:90]
Accounts receivable, net, consists of the following:

[0000068505-18-000009:notes:91]
| December 31 | 2017 |  | 2016 |
| Accounts receivable | $ | 1,568 |  |  | $ | 1,454 |  |
| Less allowance for doubtful accounts | (45 | ) |  | (44 | ) |
|  | $ | 1,523 |  |  | $ | 1,410 |  |

[0000068505-18-000009:notes:92]
Inventories, Net

[0000068505-18-000009:notes:93]
Inventories, net, consist of the following:

[0000068505-18-000009:notes:94]
| December 31 | 2017 |  | 2016 |
| Finished goods | $ | 178 |  |  | $ | 151 |  |
| Work-in-process and production materials | 282 |  |  | 253 |  |
|  | 460 |  |  | 404 |  |
| Less inventory reserves | (133 | ) |  | (131 | ) |
|  | $ | 327 |  |  | $ | 273 |  |

[0000068505-18-000009:notes:95]
Other Current Assets

[0000068505-18-000009:notes:96]
Other current assets consist of the following:

[0000068505-18-000009:notes:97]
| December 31 | 2017 |  | 2016 |
| Available-for-sale securities | $ | — |  |  | $ | 46 |  |
| Costs and earnings in excess of billings | 549 |  |  | 476 |  |
| Contract-related deferred costs | 62 |  |  | 19 |  |
| Tax-related refunds receivable | 90 |  |  | 90 |  |
| Other | 131 |  |  | 124 |  |
|  | $ | 832 |  |  | $ | 755 |  |

[0000068505-18-000009:notes:98]
Property, Plant and Equipment, Net

[0000068505-18-000009:notes:99]
Property, plant and equipment, net, consist of the following:

[0000068505-18-000009:notes:100]
| December 31 | 2017 |  | 2016 |
| Land | $ | 11 |  |  | $ | 12 |  |
| Building | 316 |  |  | 306 |  |
| Machinery and equipment | 2,122 |  |  | 1,921 |  |
|  | 2,449 |  |  | 2,239 |  |
| Less accumulated depreciation | (1,593 | ) |  | (1,450 | ) |
|  | $ | 856 |  |  | $ | 789 |  |

[0000068505-18-000009:notes:101]
Depreciation expense for the years ended December 31, 2017, 2016, and 2015 was $192 million, $182 million and $142 million, respectively.

[0000068505-18-000009:notes:102]
Property, plant and equipment, net includes capital leases of $73 million, net of accumulated depreciation of $11 million, as of December 31, 2017.

[0000068505-18-000009:notes:103]
Investments

[0000068505-18-000009:notes:104]
Other investments include strategic investments in non-public technology-driven startup companies recorded at cost of $78 million and $76 million, and insurance policies recorded at their cash surrender value of $141 million and $135 million, at December 31, 2017 and December 31, 2016, respectively.

[0000068505-18-000009:notes:105]
The Company recognized gains on the sale of investments and businesses of $3 million for the year ended December 31, 2017, compared to losses on the sale of investments and business of $6 million for the year ended December 31, 2016 and gains on the sale of investments and business of $107 million for the year ended December 31, 2015. During the years ended, December 31, 2016 and 2015 the Company recorded investment impairment charges of $4 million and $6 million, respectively, representing other-than-temporary declines in the value of the Company’s equity investment portfolio. There were no investment impairments recorded during the year ended December 31, 2017. Investment impairment charges are included in Other within Other income (expense) in the Company’s consolidated statements of operations.

[0000068505-18-000009:notes:106]
Other Assets

[0000068505-18-000009:notes:107]
Other assets consist of the following:

[0000068505-18-000009:notes:108]
| December 31 | 2017 |  | 2016 |
| Long-term receivables | $ | 19 |  |  | $ | 49 |  |
| Defined benefit plan assets | 133 |  |  | 102 |  |
| Tax receivable (Note 6) | 101 |  |  | — |  |
| Other | 80 |  |  | 49 |  |
|  | $ | 333 |  |  | $ | 200 |  |

[0000068505-18-000009:notes:109]
Accrued Liabilities

[0000068505-18-000009:notes:110]
Accrued liabilities consist of the following:

[0000068505-18-000009:notes:111]
| December 31 | 2017 |  | 2016 |
| Deferred revenue | $ | 613 |  |  | $ | 439 |  |
| Compensation | 273 |  |  | 250 |  |
| Billings in excess of costs and earnings | 428 |  |  | 434 |  |
| Tax liabilities | 107 |  |  | 111 |  |
| Deferred consideration (Note 14) | 83 |  |  | — |  |
| Dividend payable | 84 |  |  | 77 |  |
| Trade liabilities | 151 |  |  | 180 |  |
| Other | 547 |  |  | 620 |  |
|  | $ | 2,286 |  |  | $ | 2,111 |  |

[0000068505-18-000009:notes:112]
Other Liabilities

[0000068505-18-000009:notes:113]
Stockholders’ Equity Information

[0000068505-18-000009:notes:114]
Share Repurchase Program:  Through a series of actions, the Board of Directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2017, the Company had used approximately $12.3 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.7 billion of authority available for future repurchases.

[0000068505-18-000009:notes:115]
During 2017, the Company paid an aggregate of $483 million, including transaction costs, to repurchase 5.7 million shares at an average price of $85.32 per share. During 2016, the Company paid an aggregate of $842 million, including transaction costs, to repurchase 12.0 million shares at an average price of $70.28. During 2015, the Company paid an aggregate of $3.2 billion, including transaction costs, to repurchase 48.0 million shares at an average price of $66.22. Shares repurchased in 2015 include 30.1 million shares repurchased under a modified "Dutch auction" tender offer at a tender price of $66.50 for an aggregate of $2.0 billion, including transaction costs.

[0000068505-18-000009:notes:116]
Payment of Dividends:  On November 2, 2017, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.47 per share to $0.52 per share of common stock. During the years ended December 31, 2017, 2016, and 2015 the Company paid $307 million, $280 million, and $277 million, respectively, in cash dividends to holders of its common stock.

[0000068505-18-000009:notes:117]
Accumulated Other Comprehensive Loss

[0000068505-18-000009:notes:118]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the consolidated statements of operations during the years ended December 31, 2017, 2016, and 2015:

[0000068505-18-000009:notes:119]
|  | Years ended December 31 |
|  | 2017 |  | 2016 |  | 2015 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (494 | ) |  | $ | (266 | ) |  | $ | (204 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 133 |  |  | (227 | ) |  | (82 | ) |
| Tax benefit (expense) | 8 |  |  | (1 | ) |  | 20 |  |
| Other comprehensive income (loss), net of tax | 141 |  |  | (228 | ) |  | (62 | ) |
| Balance at end of period | $ | (353 | ) |  | $ | (494 | ) |  | $ | (266 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | (3 | ) |  | $ | 44 |  |
| Other comprehensive income (loss) before reclassification adjustment | 8 |  |  | — |  |  | (15 | ) |
| Tax benefit (expense) | (2 | ) |  | — |  |  | 5 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 6 |  |  | — |  |  | (10 | ) |
| Reclassification adjustment into Losses (Gains) on sales of investments and businesses | — |  |  | 5 |  |  | (61 | ) |
| Tax expense (benefit) | — |  |  | (2 | ) |  | 24 |  |
| Reclassification adjustment into Earnings from continuing operations, net of tax | — |  |  | 3 |  |  | (37 | ) |
| Other comprehensive income (loss), net of tax | 6 |  |  | 3 |  |  | (47 | ) |
| Balance at end of period | $ | 6 |  |  | $ | — |  |  | $ | (3 | ) |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (1,823 | ) |  | $ | (1,597 | ) |  | $ | (1,695 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (260 | ) |  | (368 | ) |  | 108 |  |
| Tax benefit (expense) | (213 | ) |  | 98 |  |  | 12 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (473 | ) |  | (270 | ) |  | 120 |  |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 65 |  |  | 53 |  |  | 71 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (18 | ) |  | (27 | ) |  | (62 | ) |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Other charges | — |  |  | — |  |  | (32 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other charges | 48 |  |  | 26 |  |  | — |  |
| Tax expense (benefit) | (14 | ) |  | (8 | ) |  | 1 |  |
| Reclassification adjustment into Earnings from continuing operations, net of tax | 81 |  |  | 44 |  |  | (22 | ) |
| Other comprehensive income (loss), net of tax | (392 | ) |  | (226 | ) |  | 98 |  |
| Balance at end of period | $ | (2,215 | ) |  | $ | (1,823 | ) |  | $ | (1,597 | ) |
| Total Accumulated other comprehensive loss | $ | (2,562 | ) |  | $ | (2,317 | ) |  | $ | (1,866 | ) |

[0000068505-18-000009:notes:120]
During the year ended December 31, 2017, the Company reclassified $270 million of stranded tax effects out of Accumulated other comprehensive loss and into Retained earnings. The stranded tax effects remained a component of Accumulated other comprehensive loss as a result of the remeasurement of our deferred tax assets related to our U.S. Pension Plans through the statement of operations, to the new U.S. federal tax rate of 21%. As a result, stranded tax effects within Accumulated other comprehensive loss which would not be realized at the established historical tax rates have now been adjusted through equity.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000068505-18-000009:notes:121]
The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-18-000009:notes:122]
Commitments and Contingencies

[0000068505-18-000009:notes:123]
Lease Obligations

[0000068505-18-000009:notes:124]
The Company leases certain office, factory and warehouse space, land, and information technology and other equipment under principally non-cancelable operating leases. Rental expense, net of sublease income, for the years ended December 31, 2017, 2016 and 2015 was $94 million, $84 million, and $42 million, respectively.

[0000068505-18-000009:notes:125]
At December 31, 2017, future minimum lease obligations, net of minimum sublease rentals, for the next five years and beyond are as follows:

[0000068505-18-000009:notes:126]
| (in millions) | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Beyond |  |
|  | $ | 121 |  | $ | 107 |  | $ | 82 |  | $ | 64 |  | $ | 53 |  | $ | 234 |  |

[0000068505-18-000009:notes:127]
Purchase Obligations

[0000068505-18-000009:notes:128]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. As of December 31, 2017, the Company had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2022. The Company expects to make total payments of $237 million under these arrangements as follows: $173 million in 2018, $41 million in 2019, $15 million in 2020, $7 million in 2021, and $1 million in 2022.

[0000068505-18-000009:notes:129]
The Company outsources certain corporate functions, such as benefit administration and information technology-related services, under various contracts, the longest of which is expected to expire in 2022. The remaining payments under these contracts are approximately $97 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-18-000009:notes:130]
Legal Matters

[0000068505-18-000009:notes:131]
The Company is a defendant in various lawsuits, claims, and actions that arise in the normal course of business. While the outcome of these matters is currently not determinable, the Company does not expect the ultimate disposition of these matters to have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-18-000009:notes:132]
Indemnifications

[0000068505-18-000009:notes:133]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-18-000009:notes:134]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at December 31, 2017.

[0000068505-18-000009:notes:135]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:ConsolidationPolicyTextBlock

[0000068505-18-000009:notes:136]
The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-18-000009:notes:137]
The consolidated financial statements as of December 31, 2017 and 2016 and for the years ended December 31, 2017, 2016 and 2015, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.


## us-gaap:DebtDisclosureTextBlock

[0000068505-18-000009:notes:138]
Debt and Credit Facilities

[0000068505-18-000009:notes:139]
Long-Term Debt

[0000068505-18-000009:notes:140]
| December 31 | 2017 |  | 2016 |
| 2.0% Senior Convertible Notes due 2020 | $ | 1,000 |  |  | $ | 988 |  |
| 3.5% senior notes due 2021 | 396 |  |  | 395 |  |
| 3.75% senior notes due 2022 | 747 |  |  | 746 |  |
| 3.5% senior notes due 2023 | 594 |  |  | 593 |  |
| 4.0% senior notes due 2024 | 590 |  |  | 588 |  |
| 6.5% debentures due 2025 | 118 |  |  | 117 |  |
| 7.5% debentures due 2025 | 346 |  |  | 345 |  |
| 6.5% debentures due 2028 | 36 |  |  | 36 |  |
| 6.625% senior notes due 2037 | 54 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 108 |  |  | 52 |  |
|  | 4,476 |  |  | 4,401 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (5 | ) |  | (5 | ) |
| Less: current portion | (52 | ) |  | (4 | ) |
| Long-term debt | $ | 4,419 |  |  | $ | 4,392 |  |

[0000068505-18-000009:notes:141]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.0% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017 based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a published conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of December 31, 2017 was $366 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-18-000009:notes:142]
The Company recorded a long-term debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company calculated the fair value of the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. As of December 31, 2017, the remaining unamortized debt discount has been fully amortized as a component of interest expense compared to $3 million as of December 31, 2016. For the year ended December 31, 2017, total interest expense relating to both the contractual interest coupon and amortization of the debt discount was $23 million, compared to $24 million for the year December 31, 2016 and $8 million for the year ended December 31, 2015.

[0000068505-18-000009:notes:143]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2018—$52 million; 2019—$6 million; 2020—$1,007 million; 2021—$417 million; and 2022—$770 million.

[0000068505-18-000009:notes:144]
Credit Facilities

[0000068505-18-000009:notes:145]
As of December 31, 2017,  the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2017. During the year ended December 31, 2017, the Company had borrowings and repayments of $150 million under the 2017 Motorola Solutions Credit Agreement. Such borrowings were used to purchase Kodiak Networks in April of 2017, and were repaid using cash from operations in June of 2017. No letters of credit were issued under the revolving credit facility as of December 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-18-000009:notes:146]
Risk Management

[0000068505-18-000009:notes:147]
Foreign Currency Risk

[0000068505-18-000009:notes:148]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure. Instruments that are designated as part of a hedging relationship must be effective at reducing the risk associated with the exposure being hedged and are designated as part of a hedging relationship at the inception of the contract. Accordingly, changes in the market values of hedge instruments must be highly correlated with changes in market values of the underlying hedged items both at the inception of the hedge and over the life of the hedge contract.

[0000068505-18-000009:notes:149]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows or investments based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-18-000009:notes:150]
At December 31, 2017, the Company had outstanding foreign exchange contracts with notional amounts totaling $507 million, compared to $717 million outstanding at December 31, 2016. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-18-000009:notes:151]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2017 and the corresponding positions as of December 31, 2016:

[0000068505-18-000009:notes:152]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2017 |  | 2016 |
| Euro | $ | 149 |  |  | $ | 122 |  |
| British Pound | 72 |  |  | 246 |  |
| Chinese Renminbi | (73 | ) |  | (108 | ) |
| Australian Dollar | (64 | ) |  | (51 | ) |
| Brazilian Real | (45 | ) |  | (56 | ) |

[0000068505-18-000009:notes:153]
During the year ended December 31, 2017, the Company entered into forward contracts to sell £50 million, which expired in December 2017. The Company also entered into forward contracts to sell £25 million, expiring in June 2018, as well as to sell £25 million, expiring in September 2018. The forward contracts have been designated as a net investment hedge which is in place to partially hedge the Company's British pound foreign currency exposure on its net investment in Airwave Solutions Limited. The gains and losses on the Company's net investment in British pound-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive loss. As of December 31, 2017, the fair value of the derivative contracts was a $3 million liability.

[0000068505-18-000009:notes:154]
Interest Rate Risk

[0000068505-18-000009:notes:155]
The Company's subsidiaries have variable interest loans denominated in the Euro and Chilean Peso. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as hedges. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s consolidated statements of operations. The fair value of the interest rate swaps was de minimus at December 31, 2017 and December 31, 2016.

[0000068505-18-000009:notes:156]
Counterparty Risk

[0000068505-18-000009:notes:157]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2017, all of the counterparties have investment grade credit ratings. As of December 31, 2017, the credit risk with all counterparties was approximately $5 million.

[0000068505-18-000009:notes:158]
Derivative Financial Instruments

[0000068505-18-000009:notes:159]
The following tables summarize the fair values and location in the consolidated balance sheets of all derivative financial instruments held by the Company at December 31, 2017 and 2016:

[0000068505-18-000009:notes:160]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2017 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 3 |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other assets |  | $ | 2 |  |  | Accrued liabilities |
| Total derivatives | $ | 5 |  |  |  |  | $ | 5 |  |  |  |

[0000068505-18-000009:notes:161]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2016 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 9 |  |  | Other assets |  | $ | 32 |  |  | Accrued liabilities |

[0000068505-18-000009:notes:162]
The following table summarizes the effect of derivatives designated as hedging instruments, for the years ended December 31, 2017, 2016 and 2015:

[0000068505-18-000009:notes:163]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2017 |  | 2016 |  | 2015 |
| Foreign exchange contracts | $ | (3 | ) |  | $ | — |  |  | $ | — |  | Other comprehensive income (loss) |

[0000068505-18-000009:notes:164]
The following table summarizes the effect of derivatives not designated as hedging instruments, for the years ended December 31, 2017, 2016 and 2015:

[0000068505-18-000009:notes:165]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2017 |  | 2016 |  | 2015 |
| Interest agreements | $ | — |  |  | $ | 1 |  |  | $ | 1 |  | Other income (expense) |
| Foreign exchange contracts | 15 |  |  | (57 | ) |  | 6 |  | Other income (expense) |
| Total derivatives | $ | 15 |  |  | $ | (56 | ) |  | $ | 7 |  |  |


## us-gaap:DerivativesPolicyTextBlock

[0000068505-18-000009:notes:166]
Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the consolidated statements of operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated comprehensive income.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-18-000009:notes:167]
Share-Based Compensation Plans and Other Incentive Plans

[0000068505-18-000009:notes:168]
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option granted and stock appreciation right has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-18-000009:notes:169]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-18-000009:notes:170]
Performance-based stock options (“performance options”) and market stock units ("MSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years.

[0000068505-18-000009:notes:171]
On August 25, 2015, in conjunction with the issuance of the Senior Convertible Notes, and on March 9, 2017, the Company approved grants of performance-contingent stock options (“PCSOs”) to certain executive officers. The PCSOs vest upon satisfaction of the following stock price hurdles which must be maintained for 10-consecutive trading days within the performance period ending August 25, 2018 and continuous employment over the vesting period. For PCSOs granted on August 25, 2015, 20% of the total award will vest at an $85 stock price, an additional 30% of the total award will vest at a $102.50 stock price, and the final 50% of the total award will vest at a $120 stock price. For options granted March 9, 2017, 44% of the total award will vest at an $85 stock price, an additional 24% of the total award will vest at a $102.50 stock price, and the 32% of the award will vest at a $120 stock price. If any stock price hurdles are not met during the performance period, the corresponding portion of the options will not vest and will be forfeited. The August 25, 2015 awards have a seven-year term and a per share exercise price of $68.50. The March 9, 2017 awards have a five and a half year term and a per share exercise price of $81.37.

[0000068505-18-000009:notes:172]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2017, 2016 and 2015, employees purchased 0.8 million, 0.9 million and 1.0 million shares, respectively, at purchase prices of $63.96 and $72.11, $57.60 and $64.69, and $52.99 and $56.67, respectively.

[0000068505-18-000009:notes:173]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-18-000009:notes:174]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2017, 2016 and 2015 was $15.16, $13.09 and $10.21, respectively, using the following weighted-average assumptions:

[0000068505-18-000009:notes:175]
|  | 2017 |  | 2016 |  | 2015 |
| Expected volatility | 24.0 | % |  | 23.7 | % |  | 20.0 | % |
| Risk-free interest rate | 2.1 | % |  | 1.4 | % |  | 1.6 | % |
| Dividend yield | 3.5 | % |  | 2.9 | % |  | 2.9 | % |
| Expected life (years) | 5.9 |  |  | 6.0 |  |  | 6.0 |  |

[0000068505-18-000009:notes:176]
The Company calculates the value of each performance option, MSU, and PCSO using the Monte Carlo Simulation, estimated on the date of grant. The fair value of performance options, MSUs, and PCSOs granted during 2017 was $21.47, $85.74 and $7.76, respectively. The fair value of performance options and MSUs granted during 2016 was $19.80 and $76.48, respectively. The fair value of performance options, MSUs, and PCSOs granted during 2015 was $17.42, $60.37 and $3.97, respectively. The following assumptions were used for the calculations.

[0000068505-18-000009:notes:177]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PCSOs.  The selection of the implied volatility approach was based upon the availability of actively traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. The Company uses the historical volatility as the expected volatility assumption in the valuation of performance options in order to calculate the correlation coefficients between the S&P 500 and the Company's stock, which can only be calculated using historical data.

[0000068505-18-000009:notes:178]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-18-000009:notes:179]
The Company has applied forfeiture rates, estimated based on historical data, of 10%-35% to the stock option fair values calculated by the Black-Scholes option pricing model. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-18-000009:notes:180]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, including performance options and PCSOs, at December 31, 2017 (in thousands, except exercise price and years):

[0000068505-18-000009:notes:181]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| Under $30 | 537 |  |  | $ | 27 |  |  | 2 |  | 537 |  |  | $ | 27 |  |  | 2 |
| $30-$40 | 1,557 |  |  | 39 |  |  | 3 |  | 1,557 |  |  | 39 |  |  | 3 |
| $41-$50 | 8 |  |  | 45 |  |  | 3 |  | 8 |  |  | 45 |  |  | 3 |
| $51-$60 | 842 |  |  | 55 |  |  | 5 |  | 834 |  |  | 55 |  |  | 5 |
| $61-$70 | 2,790 |  |  | 68 |  |  | 5 |  | 799 |  |  | 66 |  |  | 6 |
| $71-$80 | 596 |  |  | 72 |  |  | 8 |  | 86 |  |  | 72 |  |  | 8 |
| $81 and over | 952 |  |  | 82 |  |  | 8 |  | 3 |  |  | 81 |  |  | 9 |
|  | 7,282 |  |  |  |  |  |  | 3,824 |  |  |  |  |  |

[0000068505-18-000009:notes:182]
As of December 31, 2017, the weighted average contractual life for options outstanding and exercisable was five and four years, respectively.

[0000068505-18-000009:notes:183]
Current Year Activity

[0000068505-18-000009:notes:184]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-18-000009:notes:185]
|  | Stock Options |  | Performance Options* |  | Restricted Stock Units |  | Market Stock Units |
| Shares Outstanding in Thousands | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2017 | 5,218 |  |  | $ | 50 |  |  | 2,066 |  |  | $ | 69 |  |  | 1,333 |  |  | $ | 63 |  |  | 116 |  |  | $ | 69 |  |
| Granted | 385 |  |  | 82 |  |  | 612 |  |  | 81 |  |  | 650 |  |  | 78 |  |  | 71 |  |  | 86 |  |
| Releases/Exercised | (935 | ) |  | 53 |  |  | — |  |  | — |  |  | (656 | ) |  | 64 |  |  | (54 | ) |  | 68 |  |
| Adjustment for payout factor | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 69 |  |
| Forfeited/Canceled | (64 | ) |  | 76 |  |  | — |  |  | — |  |  | (70 | ) |  | 71 |  |  | — |  |  | — |  |
| Balance as of December 31, 2017 | 4,604 |  |  | $ | 52 |  |  | 2,678 |  |  | $ | 72 |  |  | 1,257 |  |  | $ | 70 |  |  | 139 |  |  | $ | 78 |  |
| Vested or expected to vest | 4,283 |  |  | 48 |  |  | 464 |  |  | 73 |  |  | 519 |  |  | 64 |  |  | 79 |  |  | 65 |  |

[0000068505-18-000009:notes:186]
* Inclusive of PCSO awards

[0000068505-18-000009:notes:187]
At December 31, 2017 and 2016, 9.6 million and 11.2 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-18-000009:notes:188]
Total Share-Based Compensation Expense

[0000068505-18-000009:notes:189]
At December 31, 2017, the Company had unrecognized compensation expense related to RS, RSUs, and MSUs of $56 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately two years. The total fair value of RS, RSU and MSU shares vested during the years ended December 31, 2017, 2016, and 2015 was $39 million, $54 million, and $55 million, respectively. The aggregate fair value of outstanding RS, RSUs, and MSUs as of December 31, 2017 was $98 million.

[0000068505-18-000009:notes:190]
At December 31, 2017, the Company had $15 million of total unrecognized compensation expense, net of estimated forfeitures, related to stock option plans including performance options and PCSO's that will be recognized over the weighted average period of approximately two years, and $4 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. Cash received from stock option exercises and the employee stock purchase plan was $82 million, $93 million, and $84 million for the years ended December 31, 2017, 2016, and 2015, respectively. The total intrinsic value of options exercised during the years ended December 31, 2017, 2016, and 2015 was $31 million, $16 million, and $15 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2017 was $227 million and $165 million, respectively, based on a December 31, 2017 stock price of $90.34 per share.

[0000068505-18-000009:notes:191]
Motorola Solutions Incentive Plans

[0000068505-18-000009:notes:192]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2017, 2016 and 2015 was $122 million, $114 million and $119 million, respectively.

[0000068505-18-000009:notes:193]
Long-Range Incentive Plan

[0000068505-18-000009:notes:194]
The Long-Range Incentive Plan (“LRIP”) rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. The expense for LRIP for the years ended December 31, 2017, 2016 and 2015 was $9 million, $12 million and $12 million, respectively.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-18-000009:notes:195]
Discontinued Operations

[0000068505-18-000009:notes:196]
On October 27, 2014, the Company completed the sale of its Enterprise business to Zebra Technologies Corporation ("Zebra") for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by the Company, including the Company’s iDEN business. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's consolidated financial statements and footnotes as discontinued operations for all periods presented. During the year ended December 31, 2015, the Company recognized a $30 million loss for discontinued operations related to the sale of its Enterprise business.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000068505-18-000009:notes:197]
The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for earnings (loss) from continuing operations and net earnings attributable to Motorola Solutions, Inc. for all periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-18-000009:notes:198]
Fair Value Measurements

[0000068505-18-000009:notes:199]
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-18-000009:notes:200]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-18-000009:notes:201]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-18-000009:notes:202]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-18-000009:notes:203]
Investments and Derivatives

[0000068505-18-000009:notes:204]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2017 and December 31, 2016 were as follows:

[0000068505-18-000009:notes:205]
| December 31, 2017 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | — |  |  | 2 |  |  | 2 |  |
| Common stock and equivalents | 13 |  |  | — |  |  | 13 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |

[0000068505-18-000009:notes:206]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  | $ | 9 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 51 |  |  | 51 |  |
| Corporate bonds | — |  |  | 5 |  |  | 5 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 32 |  |  | $ | 32 |  |

[0000068505-18-000009:notes:207]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-18-000009:notes:208]
The following is a description of the categories of investments:

[0000068505-18-000009:notes:209]
Equities — A diversified portfolio of corporate common stock and preferred stock.

[0000068505-18-000009:notes:210]
Commingled funds — Investments primarily in investment grade corporate and government related securities. This class     also includes investments in mortgage-backed securities, futures and options.

[0000068505-18-000009:notes:211]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, as well as index-linked government bonds.

[0000068505-18-000009:notes:212]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-18-000009:notes:213]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-18-000009:notes:214]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-18-000009:notes:215]
At December 31, 2017, the Company had $633 million of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its consolidated balance sheet, compared to $309 million at December 31, 2016. The money market funds had quoted market prices that are approximately at par.

[0000068505-18-000009:notes:216]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2017 was $4.6 billion (Level 2), compared to a face value of $4.5 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-18-000009:notes:217]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000068505-18-000009:notes:218]
Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s consolidated balance sheets. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-18-000009:notes:219]
Intangible Assets and Goodwill

[0000068505-18-000009:notes:220]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-18-000009:notes:221]
Recent Developments

[0000068505-18-000009:notes:222]
On February 1, 2018, we announced our intention to purchase Avigilon Corporation, a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of approximately $1.3 billion Canadian dollars.

[0000068505-18-000009:notes:223]
On July 28, 2017, we announced our intention to purchase Plant Holdings, Inc., the parent company of Airbus DS Communications. This acquisition will expand our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

[0000068505-18-000009:notes:224]
Guardian Digital Communications Limited Acquisition

[0000068505-18-000009:notes:225]
On February 19, 2016, the Company completed the acquisition of GDCL, a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of Airwave was acquired for the sum of £1, after which the Company invested into Airwave £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018.

[0000068505-18-000009:notes:226]
The acquisition of Airwave enables the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers.

[0000068505-18-000009:notes:227]
The acquisition of Airwave has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value.

[0000068505-18-000009:notes:228]
The total consideration for the acquisition of Airwave was approximately $1.1 billion, consisting of cash payments of $1.0 billion, net of cash acquired, and deferred consideration valued at fair value on the date of the acquisition of $82 million. The fair value of deferred consideration has been determined based on its net present value, calculated using a discount rate of 4.2%, which is reflective of the credit standing of the combined entity. The following table summarizes fair values of assets acquired and liabilities assumed as of the February 19, 2016 acquisition date:

[0000068505-18-000009:notes:229]
| Cash |  | $ | 86 |  |
| Accounts receivable, net |  | 55 |  |
| Other current assets |  | 36 |  |
| Property, plant and equipment, net |  | 245 |  |
| Deferred income taxes |  | 82 |  |
| Accounts payable |  | (18 | ) |
| Accrued liabilities |  | (181 | ) |
| Other liabilities |  | (289 | ) |
| Goodwill |  | 191 |  |
| Intangible assets |  | 875 |  |
| Total consideration |  | $ | 1,082 |  |
| Net present value of deferred consideration payment to former owners |  | (82 | ) |
| Net cash consideration at purchase |  | $ | 1,000 |  |

[0000068505-18-000009:notes:230]
Acquired intangible assets consist of $846 million of customer relationships and $29 million of trade names. All intangibles have a useful life of seven years, over which amortization expense will be recognized on a straight line basis.

[0000068505-18-000009:notes:231]
The fair values of trade names and customer relationships were estimated using the income approach. Customer relationships were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-18-000009:notes:232]
The fair value of acquired Property, plant and equipment, primarily network-related assets, was valued under the replacement cost method, which determines fair value based on the replacement cost of new property with similar capacity, adjusted for physical deterioration over the remaining useful life.

[0000068505-18-000009:notes:233]
Goodwill is calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. Goodwill is not deductible for tax purposes.

[0000068505-18-000009:notes:234]
Other Acquisitions

[0000068505-18-000009:notes:235]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers, for a gross purchase price of $225 million. As a result of the acquisition, the Company recognized $191 million of goodwill, $44 million of identifiable intangible assets and $10 million of acquired liabilities. The identifiable intangible assets were classified as $25 million of customer-related intangibles and $19 million of completed technology and will be amortized over a period of 13 to 16 years.

[0000068505-18-000009:notes:236]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides Managed & Support services for communications systems to public safety and commercial customers in Chile, for a gross purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $16 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-18-000009:notes:237]
On November 10, 2016, the Company completed the acquisition of Spillman Technologies, Inc., a provider of comprehensive law enforcement and public safety software solutions, for a gross purchase price of $221 million. As a result of the acquisition, the Company recognized $144 million of goodwill, $115 million of identifiable intangible assets, and $38 million of acquired liabilities. The identifiable intangible assets were classified as $49 million of completed technology, $59 million of customer-related intangibles, and $7 million of other intangibles and will be amortized over a period of seven to ten years.

[0000068505-18-000009:notes:238]
During the year ended December 31, 2016, the Company completed the acquisition of several software and service-based providers for a total of $30 million, recognizing $6 million of goodwill, $15 million of intangible assets, and $9 million of tangible net assets related to these acquisitions. Under the preliminary purchase accounting, the $15 million of identifiable intangible assets were classified as: (i) $7 million of completed technology and (ii) $8 million of customer-related intangibles and will be amortized over a period of five years. During the first quarter of 2017, the Company completed the purchase accounting and recorded an additional $11 million completed technology intangible asset that will be amortized over a period of eight years.

[0000068505-18-000009:notes:239]
The results of operations for these acquisitions have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-18-000009:notes:240]
Intangible Assets

[0000068505-18-000009:notes:241]
Amortized intangible assets are comprised of the following:

[0000068505-18-000009:notes:242]
|  | 2017 |  | 2016 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 148 |  |  | $ | 55 |  |  | $ | 116 |  |  | $ | 38 |  |
| Patents | 2 |  |  | 2 |  |  | 8 |  |  | 6 |  |
| Customer-related | 977 |  |  | 242 |  |  | 810 |  |  | 101 |  |
| Other intangibles | 56 |  |  | 23 |  |  | 49 |  |  | 17 |  |
|  | $ | 1,183 |  |  | $ | 322 |  |  | $ | 983 |  |  | $ | 162 |  |

[0000068505-18-000009:notes:243]
Amortization expense on intangible assets, which is included within Other charges in the consolidated statements of operations, was $151 million, $113 million, and $8 million for the years ended December 31, 2017, 2016, and 2015, respectively.  As of December 31, 2017, future amortization expense is estimated to be $155 million in 2018, $154 million in 2019, $152 million in 2020, $151 million in 2021, and $148 million in 2022.

[0000068505-18-000009:notes:244]
Goodwill

[0000068505-18-000009:notes:245]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2016 to December 31, 2017:

[0000068505-18-000009:notes:246]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2016 | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Goodwill acquired | 46 |  |  | 291 |  |  | 337 |  |
| Foreign currency translation | — |  |  | (29 | ) |  | (29 | ) |
| Balance as of December 31, 2016 | $ | 316 |  |  | $ | 412 |  |  | $ | 728 |  |
| Goodwill acquired | — |  |  | 191 |  |  | 191 |  |
| Purchase accounting adjustments | — |  |  | 2 |  |  | 2 |  |
| Foreign currency translation | — |  |  | 17 |  |  | 17 |  |
| Balance as of December 31, 2017 | $ | 316 |  |  | $ | 622 |  |  | $ | 938 |  |

[0000068505-18-000009:notes:247]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment. The Company has determined that the Products segment and Services segment each meet the definition of a reporting unit.

[0000068505-18-000009:notes:248]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2017, 2016, and 2015. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2017, 2016, and 2015, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000068505-18-000009:notes:249]
Goodwill is assessed for impairment at least annually at the reporting unit level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year. The annual assessment is performed using the two-step goodwill test which may also include the optional qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount prior to performing the two-step goodwill impairment test. If this is the case, the two-step goodwill impairment test is required. If it is more-likely-than-not that the fair value of a reporting unit is greater than its carrying amount, the two-step goodwill impairment test is not required.

[0000068505-18-000009:notes:250]
If the two-step goodwill impairment test is performed, first, the fair value of each reporting unit is compared to its book value. Second, if the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-18-000009:notes:251]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to sixteen years. The Company has no intangible assets with indefinite useful lives.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000068505-18-000009:notes:252]
Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-18-000009:notes:253]
Income Taxes

[0000068505-18-000009:notes:254]
Enactment of the U.S. Tax Cuts and Jobs Act

[0000068505-18-000009:notes:255]
On December 22, 2017, the U.S. Tax Cuts and Jobs Act (the “Tax Act”) was enacted into law. The Tax Act contains broad and complex provisions including, but not limited to: (i) the reduction of corporate income tax rate from 35% to 21%, (ii) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries, (iii) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries, (iv) modifying limitation on excessive employee remuneration, (v) requiring current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations, (vi) repeal of corporate alternative minimum tax (“AMT”) and changing how AMT credits can be realized, (vii) creating the Base Erosion Anti-abuse Tax ("BEAT"), a new minimum tax, (viii) creating a new limitation on deductible interest expense, (ix) changing rules related to uses and limitations of net operating loss carryforwards and foreign tax credits created in tax years beginning after December 31, 2017, and (x) eliminating the deduction for income attributable to domestic production activities.

[0000068505-18-000009:notes:256]
In addition to the provisional amounts recognized within current and deferred tax expense during the year ended December 31, 2017, the Company also recorded significant changes within the statement of financial position as of December 31, 2017 as a result of the Tax Act including: (i) the reclassification of $270 million of stranded tax effects within Accumulated other comprehensive loss to Retained earnings, primarily associated with our U.S. post-retirement plans and (ii) the presentation of $101 million of credits associated with previous payments under AMT from deferred tax assets to other non-current assets.

[0000068505-18-000009:notes:257]
In response to the enactment of the Tax Act in late 2017, the U.S. Securities and Exchange Commission issued Staff Accounting Bulletin No. 118 (“SAB 118”) to address situations where the accounting is incomplete for certain income tax effects of the Tax Act upon issuance of an entity’s financial statements for the reporting period in which the Tax Act was enacted. Under SAB 118, a company may record provisional amounts during a measurement period for specific income tax effects of the Tax Act for which the accounting is incomplete but a reasonable estimate can be determined, and when unable to determine a reasonable estimate for any income tax effects, report provisional amounts in the first reporting period in which a reasonable estimate can be determined. The Company has recorded the impact of the tax effects of the Tax Act, relying on estimates where the accounting is incomplete as of December 31, 2017. As guidance and technical corrections are issued in the upcoming quarters, the Company will record updates to its original provisional estimates.

[0000068505-18-000009:notes:258]
The Act reduces the corporate tax rate to 21 percent, effective January 1, 2018. Accordingly, we have recorded a provisional decrease of $366 million to deferred tax assets for the year ended December 31, 2017. While we are able to make a reasonable estimate of the impact of the reduction in corporate rate, it may be affected by other analyses related to the Tax Act, including, but not limited to, our calculation of subsequent payments and economic performance analyses. The analyses will continue throughout 2018 and will be completed when the Company files its income tax returns in late 2018.

[0000068505-18-000009:notes:259]
The Tax Act creates a new requirement that certain income earned by controlled foreign corporations must be included currently in the gross income of the U.S. shareholder under the Global Intangible Low-Taxed Income ("GILTI") provision. Because of the complexity of the new GILTI tax rules, the Company is continuing to evaluate this provision of the Tax Act and the application within the Company’s financial statements. Under U.S. GAAP, the Company may make an accounting policy choice to: (i) record taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (ii) factor such amounts into its measurement of deferred taxes (the “deferred method”). The Company’s selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing its global income to determine whether it expects to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be. Because whether the Company expects to have future U.S. inclusions in taxable income related to GILTI depends on not only its current structure and estimated future results of global operations but also its intent and ability to modify its structure and/or business, it is not yet able to reasonably estimate the effect of this provision of the Tax Act. Therefore, the Company has not made any adjustments related to potential GILTI tax in its financial statements and has not made a policy decision regarding how to record the tax effects of GILTI as of December 31, 2017. The Company will continue to analyze the impact of GILTI as more guidance is issued and a decision will be made during 2018 on whether to treat the GILTI as a period cost or a deferred tax item.

[0000068505-18-000009:notes:260]
The Tax Act includes a transition tax on the deemed distribution of previously untaxed accumulated and current earnings and profits of certain of foreign subsidiaries. To determine the amount of the transition tax, the Company must determine, in addition to other factors, the amount of post-1986 earnings and profits of relevant subsidiaries, as well as the amount of non-U.S. income taxes paid on such earnings. An estimate of the transition tax of $16 million has been recorded as of December 31, 2017. This amount is the net impact after considering the utilization of existing foreign tax credit carryforwards against the deemed repatriation liability of $60 million and the benefit of $44 million from additional tax credits generated from actual distributions made during 2017 in anticipation of the tax reform. The Company is continuing to gather additional information to more precisely compute the amount of the transition tax, any related impacts to the deferred tax liability on unremitted earnings of foreign subsidiaries that are not reinvested indefinitely, and the state income tax impact of the deemed distributions.

[0000068505-18-000009:notes:261]
Provisions under the Tax Act drive significant changes to the Company’s ability to utilize foreign tax credit carryforwards to offset taxable income from foreign sourced operations. Prior to the enactment of the Tax Act, the Company planned to put in place certain tax planning strategies which would maximize its ability to utilize foreign tax credits against U.S. corporate income tax. As a result of the Tax Act, such strategies are no longer prudent or feasible. The Company has recorded a valuation allowance of $471 million against its U.S. foreign tax credit carryforwards, representing a reasonable estimate of its inability to utilize remaining tax credits under the Tax Act. The valuation allowance estimate is effected by various aspects of the Tax Act, such as the deemed repatriation of deferred foreign income, GILTI inclusions, and new foreign tax credit limitations. Therefore, this estimate is subject to change as the IRS and Treasury clarify the application of these provisions under the Tax Act and the Company evaluates its structure for foreign operations in light of the changes made by the Tax Act and considers tax planning opportunities which may be available and management is willing to implement.

[0000068505-18-000009:notes:262]
Components of Income Tax Expense

[0000068505-18-000009:notes:263]
Components of earnings (loss) from continuing operations before income taxes are as follows:

[0000068505-18-000009:notes:264]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| United States | $ | 959 |  |  | $ | 651 |  |  | $ | 725 |  |
| Other nations | 117 |  |  | 193 |  |  | 192 |  |
|  | $ | 1,076 |  |  | $ | 844 |  |  | $ | 917 |  |

[0000068505-18-000009:notes:265]
Components of income tax expense (benefit) are as follows:

[0000068505-18-000009:notes:266]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| United States | $ | 43 |  |  | $ | 20 |  |  | $ | 71 |  |
| Other nations | 75 |  |  | 31 |  |  | 30 |  |
| States (U.S.) | 9 |  |  | 18 |  |  | 13 |  |
| Current income tax expense | 127 |  |  | 69 |  |  | 114 |  |
| United States | 1,078 |  |  | 180 |  |  | 154 |  |
| Other nations | (8 | ) |  | 36 |  |  | (13 | ) |
| States (U.S.) | 30 |  |  | (3 | ) |  | 19 |  |
| Deferred income tax expense | 1,100 |  |  | 213 |  |  | 160 |  |
| Total income tax expense (benefit) | $ | 1,227 |  |  | $ | 282 |  |  | $ | 274 |  |

[0000068505-18-000009:notes:267]
Differences between income tax expense (benefit) computed at the U.S. federal statutory tax rate of 35% and income tax expense (benefit) as reflected in the consolidated statements of operations are as follows:

[0000068505-18-000009:notes:268]
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |
| Income tax expense (benefit) at statutory rate | $ | 377 |  | 35.0 | % |  | $ | 295 |  | 35.0 | % |  | $ | 321 |  | 35.0 | % |
| Non-U.S. tax on non-U.S. earnings | (28 | ) | (2.6 | )% |  | (25 | ) | (3.0 | )% |  | (46 | ) | (5.0 | )% |
| State income taxes, net of federal benefit | 39 |  | 3.6 | % |  | 26 |  | 3.1 | % |  | 24 |  | 2.6 | % |
| Reserve for uncertain tax positions | 3 |  | 0.3 | % |  | (13 | ) | (1.6 | )% |  | 1 |  | 0.1 | % |
| Other provisions | (7 | ) | (0.6 | )% |  | (2 | ) | (0.4 | )% |  | 14 |  | 1.6 | % |
| Valuation allowances | (8 | ) | (0.7 | )% |  | (7 | ) | (0.8 | )% |  | (9 | ) | (1.0 | )% |
| Section 199 deduction | (18 | ) | (1.7 | )% |  | (15 | ) | (1.7 | )% |  | (19 | ) | (2.1 | )% |
| U.S. tax on undistributed non-U.S. earnings | 20 |  | 1.9 | % |  | 25 |  | 3.0 | % |  | (7 | ) | (0.8 | )% |
| Research credits | (4 | ) | (0.4 | )% |  | (2 | ) | (0.2 | )% |  | (5 | ) | (0.5 | )% |
| Loss on sale of investment | (21 | ) | (2.0 | )% |  | — |  | — | % |  | — |  | — | % |
| U.S. tax reform | 874 |  | 81.2 | % |  | — |  | — | % |  | — |  | — | % |
|  | $ | 1,227 |  | 114.0 | % |  | $ | 282 |  | 33.4 | % |  | $ | 274 |  | 29.9 | % |

[0000068505-18-000009:notes:269]
Income tax expense for the year ended December 31, 2017 was $1.2 billion, an increase of $945 million, driven by $874 million of non-recurring charges during the year related to the enactment of the Tax Act which drove an effective tax rate in excess of the current U.S. federal statutory rate of 35%.

[0000068505-18-000009:notes:270]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s consolidated balance sheets, rather than Income tax expense, are a result of retirement benefit adjustments, currency translation adjustments, and fair value adjustments to available-for-sale securities. The adjustments were benefits of $49 million, $87 million, and $62 million for the years ended December 31, 2017, 2016, and 2015, respectively.

[0000068505-18-000009:notes:271]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the Tax Act, dividends from foreign subsidiaries are now exempt, and the U.S. tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested.

[0000068505-18-000009:notes:272]
Undistributed earnings that the Company intends to reinvest indefinitely, and for which no U.S. income taxes have been provided, aggregate to $1.8 billion at December 31, 2017. However, the Company believes that the additional income tax charge with respect to such earnings, if distributed, would be immaterial. On a cash basis, these repatriations from the Company's non-U.S. subsidiaries could require the payment of additional taxes. The portion of earnings not reinvested indefinitely may be distributed without an additional charge given the U.S. federal and foreign income tax accrued on undistributed earnings.

[0000068505-18-000009:notes:273]
Gross deferred tax assets were $2.1 billion and $3.1 billion at December 31, 2017 and 2016, respectively. Deferred tax assets, net of valuation allowances, were $1.5 billion at December 31, 2017 and $3.0 billion at December 31, 2016, respectively. Gross deferred tax liabilities were $546 million and $900 million at December 31, 2017 and 2016, respectively.

[0000068505-18-000009:notes:274]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-18-000009:notes:275]
| December 31 | 2017 |  | 2016 |
| Inventory | $ | 46 |  |  | $ | 29 |  |
| Accrued liabilities and allowances | 74 |  |  | 136 |  |
| Employee benefits | 374 |  |  | 693 |  |
| Capitalized items | 18 |  |  | 169 |  |
| Tax basis differences on investments | — |  |  | 7 |  |
| Depreciation tax basis differences on fixed assets | 72 |  |  | 74 |  |
| Undistributed non-U.S. earnings | (26 | ) |  | (27 | ) |
| Tax carryforwards | 778 |  |  | 927 |  |
| Business reorganization | 16 |  |  | 36 |  |
| Warranty and customer liabilities | 21 |  |  | 21 |  |
| Deferred revenue and costs | 142 |  |  | 122 |  |
| Valuation allowances | (604 | ) |  | (118 | ) |
| Deferred charges | — |  |  | 37 |  |
| Other | (3 | ) |  | (8 | ) |
|  | $ | 908 |  |  | $ | 2,098 |  |

[0000068505-18-000009:notes:276]
At December 31, 2017 and 2016, the Company had valuation allowances of $604 million and $118 million, respectively, against its deferred tax assets, including $90 million and $85 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance increased $481 million during 2017 primarily related to the $471 million valuation allowance on foreign tax credits due to new limitations imposed on the utilization of such credits under the Tax Act. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-18-000009:notes:277]
Tax carryforwards are as follows:

[0000068505-18-000009:notes:278]
| December 31, 2017 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 56 |  |  | $ | 12 |  |  | 2022-2036 |
| Foreign tax credits | — |  |  | 471 |  |  | 2018-2023 |
| General business credits | — |  |  | 98 |  |  | 2026-2037 |
| State tax losses | — |  |  | 39 |  |  | 2018-2030 |
| State tax credits | — |  |  | 28 |  |  | 2018-2031 |
| Non-U.S. Subsidiaries: |  |  |  |  |  |
| Japan tax losses | 100 |  |  | 31 |  |  | 2018-2025 |
| Germany tax losses | 35 |  |  | 11 |  |  | Unlimited |
| United Kingdom tax losses | 88 |  |  | 16 |  |  | Unlimited |
| Singapore tax losses | 33 |  |  | 6 |  |  | Unlimited |
| Other subsidiaries tax losses | 129 |  |  | 31 |  |  | Various |
| Spain tax credits | — |  |  | 26 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 9 |  |  | Various |
|  |  |  | $ | 778 |  |  |  |

[0000068505-18-000009:notes:279]
The Company had unrecognized tax benefits of $76 million and $68 million at December 31, 2017 and December 31, 2016, respectively, of which approximately $30 million, if recognized, would affect the effective tax rate for both 2017 and 2016, net of resulting changes to valuation allowances.

[0000068505-18-000009:notes:280]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-18-000009:notes:281]
|  | 2017 |  | 2016 |
| Balance at January 1 | $ | 68 |  |  | $ | 88 |  |
| Additions based on tax positions related to current year | 10 |  |  | — |  |
| Additions for tax positions of prior years | 22 |  |  | 2 |  |
| Reductions for tax positions of prior years | (1 | ) |  | (15 | ) |
| Settlements and agreements | (20 | ) |  | (3 | ) |
| Lapse of statute of limitations | (3 | ) |  | (4 | ) |
| Balance at December 31 | $ | 76 |  |  | $ | 68 |  |

[0000068505-18-000009:notes:282]
The IRS has completed its examination of the Company's 2012 and 2013 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-18-000009:notes:283]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s consolidated financial position, liquidity, or results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-18-000009:notes:284]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $10 million tax charge to a $30 million tax benefit, with cash payments not to exceed $20 million.

[0000068505-18-000009:notes:285]
At December 31, 2017, the Company had $31 million accrued for interest and $19 million accrued for penalties on unrecognized tax benefits. At December 31, 2016, the Company had $26 million and $18 million accrued for interest and penalties, respectively, on unrecognized tax benefits.


## us-gaap:IncomeTaxPolicyTextBlock

[0000068505-18-000009:notes:286]
The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.


## us-gaap:InventoryPolicyTextBlock

[0000068505-18-000009:notes:287]
Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or net realizable value.


## us-gaap:InvestmentPolicyTextBlock

[0000068505-18-000009:notes:288]
Investments in equity and debt securities classified as available-for-sale are carried at fair value. Equity securities that are not publicly traded are carried at cost. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-18-000009:notes:289]
The Company assesses declines in the fair value of investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s consolidated statements of operations in the period in which they become impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-18-000009:notes:290]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU No. 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

[0000068505-18-000009:notes:291]
The Company has analyzed the impact of the new standard on its financial results based on an inventory of the Company's current contracts with customers. The Company has obtained an understanding of the new standard and currently believes that it will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of the Company's contracts is currently recognized under percentage of completion accounting applying a cost-to-cost method, including contracts for radio network deployments based on the APCO P25, TETRA, and DMR technologies, as well as certain offerings within its Smart Public Safety Solutions requiring significant integration (collectively "network integration contracts").

[0000068505-18-000009:notes:292]
Under the new standard, the Company must identify the distinct promises to transfer goods and/or services within its contracts using certain factors. For network integration contracts, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard will impact the Company's network integration contracts that include devices and accessories, with the resulting impact being revenue recognized earlier as control of the devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's network integration contracts, it will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in the Company's contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-18-000009:notes:293]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While the Company has contracts which fall under these rules in the current standard, it has not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, the Company does not anticipate a significant acceleration of revenue upon applying the new standard to its current contracts under these fact patterns.

[0000068505-18-000009:notes:294]
The new standard also requires the concept of transfer of control to determine whether an entity must present revenue from providing goods or services at the gross amount billed to a customer (as a principal) or at the net amount retained (as an agent). Therefore, an entity must assess whether it controls the goods or services provided to a customer before they are transferred. The new standard provides three indicators to assist entities in determining control. Under the current standard, eight indicators (including the three indicators under the new standard) exist to evaluate whether an entity should present revenue gross as a principal or net as an agent. Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and remaining three indicators under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, upon adoption of the new standard the Company will present associated revenues on a gross basis, recording third-party sales commissions within selling, general and administrative expenses.

[0000068505-18-000009:notes:295]
Under current accounting standards, the Company expenses sales commissions as incurred. However, under ASU No. 2014-09, the Company will capitalize sales commissions as incremental costs to obtain a contract. Such costs will be classified as a contract asset and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000009:notes:296]
The Company has evaluated the impact of ASU No. 2014-09 on its financial results and determined to adopt this standard using the modified retrospective method, which requires the recognition of the cumulative effect of the transition as an adjustment to retained earnings for open contracts as of January 1, 2018. Based on the application of the changes described above to our contracts open as of January 1, 2018, the Company expects to recognize a transition adjustment in the range of $120 million to $140 million, net of deferred tax effects, which will increase its opening retained earnings. Based on the Company's existing operations, ASU No. 2014-09 is not expected to have a material impact to net earnings for the year ended December 31, 2018.

[0000068505-18-000009:notes:297]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-18-000009:notes:298]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company on January 1, 2018 with early adoption permitted. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-18-000009:notes:299]
In October 2016, the FASB issued ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The Company intends to adopt the ASU on January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company expects to record a $30 million cumulative-effect adjustment to beginning retained earnings in the first quarter of 2018 for the remaining unrecognized deferred tax expense related to intra-entity transfers of property, plant, and equipment.

[0000068505-18-000009:notes:300]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in total cash, which is inclusive of cash and cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for the Company on January 1, 2018 with early adoption permitted. The Company intends to adopt the ASU on January 1, 2018. Upon adoption, the ASU requires retrospective application. The Company does not anticipate significant changes to the Company's financial statements and related disclosures from adoption of the ASU.

[0000068505-18-000009:notes:301]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the Company plans to update the presentation of net periodic cost (benefit) accordingly, noting all components of the Company's net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of approximately $8 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.

[0000068505-18-000009:notes:302]
In August 2017, the FASB issued ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and the timing of adoption.

[0000068505-18-000009:notes:303]
Recently Adopted Accounting Pronouncements: The Company has elected to early adopt ASU No. 2018-2, "Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income," as of January 1, 2017. The ASU, which was issued by the FASB in February 2018, allows for a reclassification from Accumulated other comprehensive income to Retained earnings for stranded tax effects resulting from the newly enacted federal corporate income tax rate and other stranded tax amounts related to the Tax Act. As a result of adoption of the ASU, the Company reclassified $270 million of stranded tax effects related to our U.S. Pension Plans out of Accumulated other comprehensive loss and into Retained earnings for the year ended December 31, 2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-18-000009:notes:304]
Retirement Benefits

[0000068505-18-000009:notes:305]
Pension and Postretirement Health Care Benefits Plans

[0000068505-18-000009:notes:306]
The Company’s noncontributory U.S. pension plan (the "U.S. Pension Plan") provides benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional noncontributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. Effective January 1, 2007, eligible compensation was capped at the IRS limit plus $175,000 (the "Cap") or, for those already in excess of the Cap as of January 1, 2007, the eligible compensation used to compute such employee's MSPP benefit for all future years is the greater of: (i) such employee's eligible compensation as of January 1, 2007 (frozen at that amount) or (ii) the relevant Cap for the given year. In December 2008, the Company amended the U.S. Pension Plan and MSSP (together the "U.S. Pension Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-18-000009:notes:307]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants.

[0000068505-18-000009:notes:308]
During 2012, the Postretirement Health Care Benefits Plan was amended ("the Original Amendment") such that, as of January 1, 2013, retirees over the age of 65 are provided an annual subsidy to use toward the purchase of their own health care coverage from private insurance companies or for reimbursement of eligible health care expenses. During 2014, the Postretirement Health Care Benefits Plan was then further amended ("The New Amendment") to provide the annual subsidy discussed as part of the Original Amendment to all participants remaining under the plan effective March 1, 2015. Additionally, the New Amendment eliminated dental benefits that were previously provided under the plan.

[0000068505-18-000009:notes:309]
During the year ended December 31, 2016, the Company made two amendments to the Postretirement Health Care Benefits Plan (the “Amendments”). As a result of the first Amendment, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. The second amendment modified the annual subsidy such that all retirees over the age of 65 were entitled to one fixed rate subsidy, capped at $560 per participant.

[0000068505-18-000009:notes:310]
The Amendments to the Postretirement Health Care Benefits Plan required remeasurement of the plan, resulting in a reduction in the Postretirement Benefit Obligation. A substantial portion of the decrease related to prior service credits and will be amortized as a credit to the condensed consolidated statements of operations over approximately five years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan.

[0000068505-18-000009:notes:311]
Non U.S. Pension Benefit Plans

[0000068505-18-000009:notes:312]
The Company also provides defined benefit plans which cover non U.S. employees in certain jurisdictions, principally the United Kingdom and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-18-000009:notes:313]
In June 2015, the Company amended its Non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015. As a result, the Company recorded a curtailment gain of $32 million to Other Charges within the Company's consolidated statement of operations during 2015.

[0000068505-18-000009:notes:314]
During the years ended December 31, 2017 and 2016, the Company offered lump-sum settlements to certain participants in the Non-U.S. defined benefit plan within the United Kingdom. The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments. As a result of the actions taken, the Company recorded settlement losses of $48 million and $26 million in 2017 and 2016, respectively, which are recorded within Other charges within the consolidated statement of operations.

[0000068505-18-000009:notes:315]
Net Periodic Cost (Benefit)

[0000068505-18-000009:notes:316]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-18-000009:notes:317]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 12 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 185 |  |  | 182 |  |  | 193 |  |  | 40 |  |  | 55 |  |  | 66 |  |  | 3 |  |  | 4 |  |  | 8 |  |
| Expected return on plan assets | (229 | ) |  | (220 | ) |  | (212 | ) |  | (92 | ) |  | (93 | ) |  | (103 | ) |  | (10 | ) |  | (9 | ) |  | (9 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 44 |  |  | 37 |  |  | 46 |  |  | 16 |  |  | 11 |  |  | 17 |  |  | 5 |  |  | 5 |  |  | 8 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |  | (18 | ) |  | (27 | ) |  | (59 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |  | — |  |
| Settlement loss | — |  |  | — |  |  | — |  |  | 48 |  |  | 26 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | — |  |  | $ | (1 | ) |  | $ | 27 |  |  | $ | 15 |  |  | $ | 10 |  |  | $ | (43 | ) |  | $ | (20 | ) |  | $ | (27 | ) |  | $ | (51 | ) |

[0000068505-18-000009:notes:318]
The benefit obligation and plan assets for the Company's U.S. Pension Benefit Plan and Postretirement Health Care Benefit Plan are measured as of December 31, 2017. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-18-000009:notes:319]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from eleven to thirty-four years. Prior service costs will be amortized over periods ranging from one to five years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-18-000009:notes:320]
The net periodic cost for 2018 will include amortization of the unrecognized net loss for the U.S. Pension Benefit Plans and Non U.S. Pension Benefit Plans, currently included in Accumulated other comprehensive loss, of $56 million and $12 million, respectively. It is estimated that the 2018 net periodic expense for the Postretirement Health Care Benefits Plan will include amortization of net periodic benefits of $10 million, comprised of unrecognized net losses and prior service benefits, currently included in Accumulated other comprehensive loss.

[0000068505-18-000009:notes:321]
Actuarial Assumptions

[0000068505-18-000009:notes:322]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-18-000009:notes:323]
Effective January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, therefore, has accounted for it prospectively beginning January 1, 2016. Based on the change in estimate, the Company experienced a $28 million reduction in interest costs for the year ended December 31, 2016 compared to the prior approach. The overall reduction in the interest cost for the year ended December 31, 2016 is comprised of $18 million related to the U.S. Pension Benefit Plans, $4 million related to the Postretirement Health Care Benefit Plan, and $6 million related to the Non U.S. Pension Benefits Plans.

[0000068505-18-000009:notes:324]
In 2014, the Society of Actuaries ("SOA") released the “RP-2014 White Collar” mortality table which was utilized in calculating the 2014 projected benefit obligation. During 2016, the SOA issued an update, Mortality Improvement Scale MP-2016, which includes two additional years of mortality data and was utilized to calculate the 2017 and 2016 projected benefit obligations.

[0000068505-18-000009:notes:325]
Investment Policy

[0000068505-18-000009:notes:326]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-18-000009:notes:327]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-18-000009:notes:328]
Cash Funding

[0000068505-18-000009:notes:329]
The Company made $3 million of contributions to its U.S. Pension Benefit Plans during 2017 and 2016. The Company contributed $7 million to its Non U.S. Pension Benefit Plans during 2017, compared to $8 million contributed in 2016. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2017 or 2016.

[0000068505-18-000009:notes:330]
We expect to make a $500 million contribution to our U.S. Pension Plans in 2018, taking advantage of the recently enacted tax reform. As a result, we will generate a tax benefit under the current U.S. federal tax rate of 35% for the plan year 2017, before the enacted rate lowers to 21% as a result of the Tax Act.

[0000068505-18-000009:notes:331]
Expected Future Benefit Payments

[0000068505-18-000009:notes:332]
Other Benefit Plans

[0000068505-18-000009:notes:333]
Split-Dollar Life Insurance Arrangements

[0000068505-18-000009:notes:334]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-18-000009:notes:335]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2017, 2016 and 2015. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $62 million and $58 million as of December 31, 2017 and December 31, 2016, respectively.

[0000068505-18-000009:notes:336]
Deferred Compensation Plan

[0000068505-18-000009:notes:337]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the Board of Directors.

[0000068505-18-000009:notes:338]
Defined Contribution Plan

[0000068505-18-000009:notes:339]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the 401(k) plan is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2017, 2016 and 2015 were $28 million, $26 million and $28 million, respectively.

[0000068505-18-000009:notes:340]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2017, 2016, and 2015 the Company made no discretionary contributions.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000068505-18-000009:notes:341]
Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (buildings and building equipment, five to forty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-18-000009:notes:342]
Quarterly and Other Financial Data (unaudited)

[0000068505-18-000009:notes:343]
|  | 2017 |  | 2016 |
|  | 1st |  | 2nd |  | 3rd |  | 4th |  | 1st |  | 2nd |  | 3rd |  | 4th |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,281 |  |  | $ | 1,497 |  |  | $ | 1,645 |  |  | $ | 1,957 |  |  | $ | 1,193 |  |  | $ | 1,430 |  |  | $ | 1,532 |  |  | $ | 1,883 |  |
| Costs of sales | 711 |  |  | 807 |  |  | 851 |  |  | 987 |  |  | 691 |  |  | 754 |  |  | 770 |  |  | 955 |  |
| Gross margin | 570 |  |  | 690 |  |  | 794 |  |  | 970 |  |  | 502 |  |  | 676 |  |  | 762 |  |  | 928 |  |
| Selling, general and administrative expenses | 232 |  |  | 242 |  |  | 248 |  |  | 257 |  |  | 234 |  |  | 240 |  |  | 247 |  |  | 277 |  |
| Research and development expenditures | 135 |  |  | 138 |  |  | 141 |  |  | 154 |  |  | 135 |  |  | 138 |  |  | 137 |  |  | 142 |  |
| Other charges | 27 |  |  | 53 |  |  | 67 |  |  | 48 |  |  | 33 |  |  | 74 |  |  | 37 |  |  | 106 |  |
| Operating earnings | 176 |  |  | 257 |  |  | 338 |  |  | 511 |  |  | 100 |  |  | 224 |  |  | 341 |  |  | 403 |  |
| Net earnings (loss)* | 77 |  |  | 131 |  |  | 212 |  |  | (575 | ) |  | 17 |  |  | 107 |  |  | 192 |  |  | 243 |  |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings (loss)*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 0.47 |  |  | $ | 0.80 |  |  | $ | 1.30 |  |  | $ | (3.56 | ) |  | $ | 0.10 |  |  | $ | 0.62 |  |  | $ | 1.15 |  |  | $ | 1.47 |  |
| Diluted earnings per common share | 0.45 |  |  | 0.78 |  |  | 1.25 |  |  | (3.56 | ) |  | 0.10 |  |  | 0.61 |  |  | 1.13 |  |  | 1.43 |  |
| Dividends declared | $ | 0.47 |  |  | $ | 0.47 |  |  | $ | 0.47 |  |  | $ | 0.52 |  |  | $ | 0.41 |  |  | $ | 0.41 |  |  | $ | 0.41 |  |  | $ | 0.47 |  |
| Dividends paid | 0.47 |  |  | 0.47 |  |  | 0.47 |  |  | 0.47 |  |  | 0.41 |  |  | 0.41 |  |  | 0.41 |  |  | 0.41 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 87.00 |  |  | $ | 89.15 |  |  | $ | 93.75 |  |  | $ | 95.30 |  |  | $ | 76.11 |  |  | $ | 76.32 |  |  | $ | 78.32 |  |  | $ | 84.00 |  |
| Low | $ | 76.92 |  |  | $ | 79.63 |  |  | $ | 82.86 |  |  | $ | 84.56 |  |  | $ | 60.36 |  |  | $ | 63.08 |  |  | $ | 64.77 |  |  | $ | 71.29 |  |

[0000068505-18-000009:notes:344]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.


## us-gaap:ReceivablesPolicyTextBlock

[0000068505-18-000009:notes:345]
Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-18-000009:notes:346]
Reorganization of Businesses

[0000068505-18-000009:notes:347]
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits. In addition to the Involuntary Severance Plan, during the year ended December 31, 2016, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at six months of salary, were equalized for all employment level grades and capped at a full year’s salary.

[0000068505-18-000009:notes:348]
The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the consolidated statements of operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-18-000009:notes:349]
During 2017, 2016, and 2015 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. Both of the Company’s segments were impacted by these plans. The employees affected were located in all geographic regions.

[0000068505-18-000009:notes:350]
2017 Charges

[0000068505-18-000009:notes:351]
During 2017, the Company recorded net reorganization of business charges of $42 million, including $9 million of charges in Costs of sales and $33 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the $42 million were charges of $43 million for employee separation costs and $8 million for exit costs, partially offset by $9 million of reversals of accruals no longer needed.

[0000068505-18-000009:notes:352]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2017 to December 31, 2017:

[0000068505-18-000009:notes:353]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 7 |  |  | $ | 8 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 9 |  |
| Employee separation costs | 94 |  |  | 43 |  |  | (9 | ) |  | (87 | ) |  | 41 |  |
|  | $ | 101 |  |  | $ | 51 |  |  | $ | (9 | ) |  | $ | (93 | ) |  | $ | 50 |  |

[0000068505-18-000009:notes:354]
Exit Costs

[0000068505-18-000009:notes:355]
At January 1, 2017, the Company had $7 million accrual for exit costs. There were $8 million of additional charges in 2017. The $6 million used in 2017 reflects cash payments. The remaining accrual of $9 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2017, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-18-000009:notes:356]
Employee Separation Costs

[0000068505-18-000009:notes:357]
At January 1, 2017, the Company had an accrual of $94 million for employee separation costs. The 2017 additional charges of $43 million represent severance costs for approximately an additional 400 employees, of which 100 were direct employees and 300 were indirect employees. The adjustments of $9 million reflect reversals of accruals no longer needed. The $87 million used in 2017 reflects cash payments to severed employees. The remaining accrual of $41 million, which is included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2017, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 100 employees to be separated in 2018.

[0000068505-18-000009:notes:358]
2016 Charges

[0000068505-18-000009:notes:359]
During 2016, the Company recorded net reorganization of business charges of $140 million, including $43 million of charges in Costs of sales and $97 million of charges under Other charges in the Company’s consolidated statements of operations. Included in the aggregate $140 million are charges of: (i) $120 million for employee separation costs, (ii) a $17 million building impairment charge, (iii) $5 million for exit costs, and (iv) $3 million for the impairment of the corporate aircraft, partially offset by $5 million of reversals of accruals no longer needed.

[0000068505-18-000009:notes:360]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2016 to December 31, 2016:

[0000068505-18-000009:notes:361]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 9 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | (6 | ) |  | $ | 7 |  |
| Employee separation costs | 51 |  |  | 120 |  |  | (4 | ) |  | (73 | ) |  | 94 |  |
|  | $ | 60 |  |  | $ | 125 |  |  | $ | (5 | ) |  | $ | (79 | ) |  | $ | 101 |  |

[0000068505-18-000009:notes:362]
At January 1, 2016, the Company had $9 million accrual for exit costs. There were $5 million of additional charges in 2016. The $6 million used in 2016 reflects cash payments. The remaining accrual of $7 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2016, primarily represented future cash payments for lease obligations.

[0000068505-18-000009:notes:363]
At January 1, 2016, the Company had an accrual of $51 million for employee separation costs. The additional 2016 charges of $120 million represent severance costs for approximately an additional 1,300 employees, of which 400 were direct employees and 900 were indirect employees. The adjustments of $4 million reflect reversals of accruals no longer needed. The $73 million used in 2016 reflects cash payments to severed employees. The remaining accrual of $94 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2016.

[0000068505-18-000009:notes:364]
2015 Charges

[0000068505-18-000009:notes:365]
During 2015, the Company recorded net reorganization of business charges of $117 million, including $9 million of charges in Costs of sales and $108 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the aggregate $117 million are charges of: (i) $74 million for employee separation costs, (ii) $31 million for the impairment of the corporate aircraft, (iii) $10 million of charges for exit costs, and (iv) a $6 million building impairment charge, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-18-000009:notes:366]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2015 to December 31, 2015:

[0000068505-18-000009:notes:367]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 9 |  |
| Employee separation costs | 57 |  |  | 74 |  |  | (10 | ) |  | (70 | ) |  | 51 |  |
|  | $ | 57 |  |  | $ | 84 |  |  | $ | (10 | ) |  | $ | (71 | ) |  | $ | 60 |  |

[0000068505-18-000009:notes:368]
At January 1, 2015, the Company had no accrual for exit costs. There were $10 million of additional charges in 2015. The $1 million used in 2015 reflects cash payments. The remaining accrual of $9 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at as of December 31, 2015, primarily represented future cash payments for lease obligations.

[0000068505-18-000009:notes:369]
At January 1, 2015, the Company had an accrual of $57 million for employee separation costs. The additional 2015 charges of $74 million represent severance costs for approximately an additional 1,100 employees, of which 200 were direct employees and 900 were indirect employees. The adjustments of $10 million reflect $4 million of reversals of accruals no longer needed and $6 million of reversals of accruals held for employees separated from discontinued operations. The $70 million used in 2015 reflects cash payments to these severed employees. The remaining accrual of $51 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2015.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000068505-18-000009:notes:370]
Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its products and services due to the needs of its customers. Such revenue arrangements may be a result of the combination of multiple contracts with our customers. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. The Company recognizes revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  The Company recognizes revenue in accordance with software accounting guidance for the following types of sales transactions: (i) stand alone sales of software products or software upgrades and (ii) stand alone sales of software maintenance agreements.

[0000068505-18-000009:notes:371]
Products

[0000068505-18-000009:notes:372]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. The Company bases its estimates of these allowances on historical experience. The Company includes shipping charges billed to customers in revenue and includes the related shipping costs in cost of sales.

[0000068505-18-000009:notes:373]
The Company sells software and equipment obtained from other companies. The Company establishes its own pricing and retains related inventory risk, is the primary obligor in sales transactions with customers, and assumes the credit risk for amounts billed to customers. Accordingly, the Company generally recognizes revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-18-000009:notes:374]
Long-Term Contracts

[0000068505-18-000009:notes:375]
For long-term contracts that involve customization of equipment and/or software, the Company generally recognizes revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”).

[0000068505-18-000009:notes:376]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the work required to be performed under many of the Company’s long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables. The Company has a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts including the related Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on Operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2017, 2016, and 2015. When estimates of total costs to be incurred on a contract exceed total estimates of revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-18-000009:notes:377]
Hardware and Software Services Support

[0000068505-18-000009:notes:378]
Revenue under equipment and software support and maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term.

[0000068505-18-000009:notes:379]
Software and Licenses

[0000068505-18-000009:notes:380]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other revenue recognition criteria are met.

[0000068505-18-000009:notes:381]
Multiple-Element Arrangements

[0000068505-18-000009:notes:382]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements, deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in the control of the Company.

[0000068505-18-000009:notes:383]
In these arrangements, the Company generally allocates revenue to all deliverables based on their relative selling prices, applying an estimated selling price (“ESP”) as our best estimate of fair value. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or service, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume. Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above. The Company's arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. In limited circumstances, the Company has established vendor specific objective evidence ("VSOE") of fair value on certain post-contract service offerings. Where the contract contains more than one deliverable and VSOE does not exist for the undelivered software elements, revenue is deferred until the undelivered element is delivered. When the final undelivered software element is post contract support services, revenue is recognized on a ratable basis over the remaining service period.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000068505-18-000009:notes:384]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| United States | $ | 3,725 |  |  | $ | 3,566 |  |  | $ | 3,473 |  |  | $ | 5,138 |  |  | $ | 5,653 |  |  | $ | 6,213 |  |
| United Kingdom | 558 |  |  | 528 |  |  | 96 |  |  | 2,329 |  |  | 2,300 |  |  | 1,127 |  |
| Other, net of eliminations | 2,097 |  |  | 1,944 |  |  | 2,126 |  |  | 741 |  |  | 510 |  |  | 1,006 |  |
|  | $ | 6,380 |  |  | $ | 6,038 |  |  | $ | 5,695 |  |  | $ | 8,208 |  |  | $ | 8,463 |  |  | $ | 8,346 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-18-000009:notes:385]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-18-000009:notes:386]
|  | Net Sales |  | Operating Earnings |
| Years ended December 31 | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Products | $ | 3,772 |  |  | $ | 3,649 |  |  | $ | 3,676 |  |  | $ | 914 |  |  | $ | 734 |  |  | $ | 704 |  |
| Services | 2,608 |  |  | 2,389 |  |  | 2,019 |  |  | 368 |  |  | 333 |  |  | 290 |  |
|  | $ | 6,380 |  |  | $ | 6,038 |  |  | $ | 5,695 |  |  | 1,282 |  |  | 1,067 |  |  | 994 |  |
| Total other expense |  |  |  |  |  |  | (206 | ) |  | (223 | ) |  | (77 | ) |
| Earnings from continuing operations before income taxes |  |  |  |  |  |  | $ | 1,076 |  |  | $ | 844 |  |  | $ | 917 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-18-000009:notes:387]
Valuation and Qualifying Accounts


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-18-000009:notes:388]
Information by Segment and Geographic Region

[0000068505-18-000009:notes:389]
The Company conducts its business globally and manages it through the following two segments:

[0000068505-18-000009:notes:390]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In 2017, the segment’s net sales were $3.8 billion, representing 59% of the Company's consolidated net sales.

[0000068505-18-000009:notes:391]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services and SaaS offerings are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2017, the segment’s net sales were $2.6 billion, representing 41% of the Company's consolidated net sales.

[0000068505-18-000009:notes:392]
For the years ended December 31, 2017, 2016 and 2015, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-18-000009:notes:393]
Segment Information

[0000068505-18-000009:notes:394]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-18-000009:notes:395]
Geographic Area Information

[0000068505-18-000009:notes:396]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-18-000009:notes:397]
Summary of Significant Accounting Policies

[0000068505-18-000009:notes:398]
Principles of Consolidation:  The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-18-000009:notes:399]
Use of Estimates:   The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-18-000009:notes:400]
Revenue Recognition:   Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its products and services due to the needs of its customers. Such revenue arrangements may be a result of the combination of multiple contracts with our customers. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. The Company recognizes revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  The Company recognizes revenue in accordance with software accounting guidance for the following types of sales transactions: (i) stand alone sales of software products or software upgrades and (ii) stand alone sales of software maintenance agreements.

[0000068505-18-000009:notes:401]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $63 million at both December 31, 2017 and December 31, 2016.

[0000068505-18-000009:notes:402]
Investments: Investments in equity and debt securities classified as available-for-sale are carried at fair value. Equity securities that are not publicly traded are carried at cost. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-18-000009:notes:403]
Inventories: Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or net realizable value.

[0000068505-18-000009:notes:404]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (buildings and building equipment, five to forty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use.

[0000068505-18-000009:notes:405]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year. The annual assessment is performed using the two-step goodwill test which may also include the optional qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount prior to performing the two-step goodwill impairment test. If this is the case, the two-step goodwill impairment test is required. If it is more-likely-than-not that the fair value of a reporting unit is greater than its carrying amount, the two-step goodwill impairment test is not required.

[0000068505-18-000009:notes:406]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-18-000009:notes:407]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-18-000009:notes:408]
Sales and Use Taxes: The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes, on a net basis with such taxes excluded from revenue.

[0000068505-18-000009:notes:409]
Long-term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-18-000009:notes:410]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s consolidated balance sheets. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s consolidated statements of operations.

[0000068505-18-000009:notes:411]
Derivative Instruments: Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the consolidated statements of operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated comprehensive income.

[0000068505-18-000009:notes:412]
Earnings Per Share: The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for earnings (loss) from continuing operations and net earnings attributable to Motorola Solutions, Inc. for all periods presented.

[0000068505-18-000009:notes:413]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-18-000009:notes:414]
Retirement Benefits: The Company records annual expenses relating to its pension benefit and postretirement plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s consolidated balance sheets using a December 31 measurement date.

[0000068505-18-000009:notes:415]
Recent Accounting Pronouncements: In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU No. 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.


## us-gaap:SubsequentEventsTextBlock

[0000068505-18-000009:notes:416]
Subsequent Events
