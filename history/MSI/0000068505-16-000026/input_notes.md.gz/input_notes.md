# MSI notes — 0000068505-16-000026


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-16-000026:notes:1]
[same as prior period, unchanged from 0000068505-16-000020:notes:1]

[0000068505-16-000026:notes:2]
[same as prior period, unchanged from 0000068505-16-000020:notes:2]

[0000068505-16-000026:notes:3]
| July 2, 2016 | Cost Basis |  | Unrealized Gains |  | Unrealized Losses |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 52 |  |  | $ | — |  |  | $ | — |  |  | $ | 52 |  |
| Corporate bonds | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Common stock | — |  |  | — |  |  | — |  |  | — |  |
|  | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Other investments, at cost | 200 |  |  | — |  |  | — |  |  | 200 |  |
| Equity method investments | 10 |  |  | — |  |  | — |  |  | 10 |  |
|  | $ | 270 |  |  | $ | — |  |  | $ | — |  |  | $ | 270 |  |
| Less: current portion of available-for-sale securities |  |  |  |  |  |  | 47 |  |
|  |  |  |  |  |  |  | $ | 223 |  |

[0000068505-16-000026:notes:4]
[same as prior period, unchanged from 0000068505-16-000020:notes:4]


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-16-000026:notes:5]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of July 2, 2016 and December 31, 2015 were as follows:

[0000068505-16-000026:notes:6]
| July 2, 2016 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | — |  |  | $ | 52 |  |  | $ | 52 |  |
| Corporate bonds | — |  |  | 8 |  |  | 8 |  |
| Common stock | — |  |  | — |  |  | — |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |
| Interest rate swap | — |  |  | 1 |  |  | 1 |  |

[0000068505-16-000026:notes:7]
[same as prior period, unchanged from 0000068505-16-000020:notes:7]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-16-000026:notes:8]
[same as prior period, unchanged from 0000068505-16-000020:notes:8]

[0000068505-16-000026:notes:9]
[same as prior period, unchanged from 0000068505-16-000020:notes:9]

[0000068505-16-000026:notes:10]
[same as prior period, unchanged from 0000068505-16-000020:notes:10]

[0000068505-16-000026:notes:11]
|  | July 2, 2016 |  | December 31, 2015 |
| Long-term receivables | $ | 54 |  |  | $ | 60 |  |
| Less current portion | (12 | ) |  | (13 | ) |
| Gross non-current long-term receivables | $ | 42 |  |  | $ | 47 |  |

[0000068505-16-000026:notes:12]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $131 million at July 2, 2016, compared to $112 million at December 31, 2015.

[0000068505-16-000026:notes:13]
[same as prior period, unchanged from 0000068505-16-000020:notes:13]

[0000068505-16-000026:notes:14]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended July 2, 2016 and July 4, 2015:

[0000068505-16-000026:notes:15]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Accounts receivable sales proceeds | $ | 5 |  |  | $ | 5 |  |  | $ | 7 |  |  | $ | 11 |  |
| Long-term receivables sales proceeds | 70 |  |  | 43 |  |  | 134 |  |  | 108 |  |
| Total proceeds from receivable sales | $ | 75 |  |  | $ | 48 |  |  | $ | 141 |  |  | $ | 119 |  |

[0000068505-16-000026:notes:16]
At July 2, 2016, the Company had retained servicing obligations for $699 million of long-term receivables, compared to $668 million of long-term receivables at December 31, 2015. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-16-000026:notes:17]
[same as prior period, unchanged from 0000068505-16-000020:notes:17]

[0000068505-16-000026:notes:18]
An aging analysis of financing receivables at July 2, 2016 and December 31, 2015 is as follows:

[0000068505-16-000026:notes:19]
| July 2, 2016 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 12 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 43 |  |  | — |  |  | — |  |  | 1 |  |
| Total gross long-term receivables, including current portion | $ | 55 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |

[0000068505-16-000026:notes:20]
[same as prior period, unchanged from 0000068505-16-000020:notes:20]


## msi:OtherChargesTableTextBlock

[0000068505-16-000026:notes:21]
[same as prior period, unchanged from 0000068505-16-000020:notes:21]

[0000068505-16-000026:notes:22]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization | $ | 38 |  |  | $ | 3 |  |  | $ | 52 |  |  | $ | 4 |  |
| Reorganization of business | 19 |  |  | 13 |  |  | 25 |  |  | 26 |  |
| Building impairment | 17 |  |  | — |  |  | 17 |  |  | — |  |
| Non-U.S. pension curtailment gain | — |  |  | (32 | ) |  | — |  |  | (32 | ) |
| Acquisition-related transaction fees | — |  |  | — |  |  | 13 |  |  | — |  |
|  | $ | 74 |  |  | $ | (16 | ) |  | $ | 107 |  |  | $ | (2 | ) |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-16-000026:notes:23]
[same as prior period, unchanged from 0000068505-16-000020:notes:23]

[0000068505-16-000026:notes:24]
| July 2, 2016 | Three Months Ended |  | Six Months Ended |
| Products | $ | 33 |  |  | $ | 54 |  |
| Services | 11 |  |  | 13 |  |
|  | $ | 44 |  |  | $ | 67 |  |

[0000068505-16-000026:notes:25]
| July 4, 2015 | Three Months Ended |  | Six Months Ended |
| Products | $ | 12 |  |  | $ | 22 |  |
| Services | 4 |  |  | 8 |  |
|  | $ | 16 |  |  | $ | 30 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-16-000026:notes:26]
[same as prior period, unchanged from 0000068505-16-000020:notes:26]

[0000068505-16-000026:notes:27]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 5 |  |
| Selling, general and administrative expenses | 12 |  |  | 12 |  |  | 24 |  |  | 25 |  |
| Research and development expenditures | 4 |  |  | 5 |  |  | 7 |  |  | 10 |  |
| Share-based compensation expense included in Operating earnings | 18 |  |  | 19 |  |  | 35 |  |  | 40 |  |
| Tax benefit | 6 |  |  | 6 |  |  | 11 |  |  | 13 |  |
| Share-based compensation expense, net of tax | $ | 12 |  |  | $ | 13 |  |  | $ | 24 |  |  | $ | 27 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.06 | ) |  | $ | (0.14 | ) |  | $ | (0.13 | ) |
| Decrease in diluted earnings per share | $ | (0.07 | ) |  | $ | (0.06 | ) |  | $ | (0.14 | ) |  | $ | (0.13 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-16-000026:notes:28]
[same as prior period, unchanged from 0000068505-16-000020:notes:28]

[0000068505-16-000026:notes:29]
|  | July 2, 2016 |  | December 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 86 |  |  | $ | 61 |  |  | $ | 89 |  |  | $ | 60 |  |
| Services | 847 |  |  | 48 |  |  | 22 |  |  | 2 |  |
|  | $ | 933 |  |  | $ | 109 |  |  | $ | 111 |  |  | $ | 62 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-16-000026:notes:30]
[same as prior period, unchanged from 0000068505-16-000020:notes:30]

[0000068505-16-000026:notes:31]
|  | July 2, 2016 |  | December 31, 2015 |
| Defined benefit plans | $ | 1,493 |  |  | $ | 1,512 |  |
| Postretirement Health Care Benefit Plan | — |  |  | 49 |  |
| Deferred revenue | 149 |  |  | 113 |  |
| Unrecognized tax benefits | 42 |  |  | 50 |  |
| Deferred income taxes | 120 |  |  | — |  |
| Deferred consideration (Note 14) | 78 |  |  | — |  |
| Other | 190 |  |  | 180 |  |
|  | $ | 2,072 |  |  | $ | 1,904 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-16-000026:notes:32]
[same as prior period, unchanged from 0000068505-16-000020:notes:32]

[0000068505-16-000026:notes:33]
[same as prior period, unchanged from 0000068505-16-000020:notes:33]

[0000068505-16-000026:notes:34]
[same as prior period, unchanged from 0000068505-16-000020:notes:34]

[0000068505-16-000026:notes:35]
[same as prior period, unchanged from 0000068505-16-000020:notes:35]

[0000068505-16-000026:notes:36]
[same as prior period, unchanged from 0000068505-16-000020:notes:36]

[0000068505-16-000026:notes:37]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (59 | ) |  | $ | (42 | ) |  | $ | (111 | ) |  | $ | (86 | ) |
| Interest income | 5 |  |  | 3 |  |  | 8 |  |  | 7 |  |
|  | $ | (54 | ) |  | $ | (39 | ) |  | $ | (103 | ) |  | $ | (79 | ) |
| Other: |  |  |  |  |  |  |  |
| Investment impairments | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Foreign currency gain (loss) | 14 |  |  | (11 | ) |  | $ | 27 |  |  | $ | 7 |  |
| Gain (loss) on derivative instruments | (18 | ) |  | 4 |  |  | (30 | ) |  | (12 | ) |
| Gains on equity method investments | — |  |  | 4 |  |  | 2 |  |  | 4 |  |
| Realized foreign currency loss on acquisition | — |  |  | — |  |  | (10 | ) |  | — |  |
| Other | — |  |  | 2 |  |  | — |  |  | 3 |  |
|  | $ | (4 | ) |  | $ | (4 | ) |  | $ | (11 | ) |  | $ | (1 | ) |

[0000068505-16-000026:notes:38]
[same as prior period, unchanged from 0000068505-16-000020:notes:38]

[0000068505-16-000026:notes:39]
[same as prior period, unchanged from 0000068505-16-000020:notes:39]

[0000068505-16-000026:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Three Months Ended | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 107 |  |  | $ | 150 |  |  | $ | 107 |  |  | $ | 142 |  |
| Weighted average common shares outstanding | 171.9 |  |  | 208.0 |  |  | 171.9 |  |  | 208.0 |  |
| Per share amount | $ | 0.62 |  |  | $ | 0.72 |  |  | $ | 0.62 |  |  | $ | 0.68 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 107 |  |  | $ | 150 |  |  | $ | 107 |  |  | $ | 142 |  |
| Weighted average common shares outstanding | 171.9 |  |  | 208.0 |  |  | 171.9 |  |  | 208.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.4 |  |  | 1.5 |  |  | 2.4 |  |  | 1.5 |  |
| Senior Convertible Notes | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |
| Diluted weighted average common shares outstanding | 174.8 |  |  | 209.5 |  |  | 174.8 |  |  | 209.5 |  |
| Per share amount | $ | 0.61 |  |  | $ | 0.72 |  |  | $ | 0.61 |  |  | $ | 0.68 |  |

[0000068505-16-000026:notes:41]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Six Months Ended | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 124 |  |  | $ | 238 |  |  | $ | 124 |  |  | $ | 217 |  |
| Weighted average common shares outstanding | 173.0 |  |  | 211.7 |  |  | 173.0 |  |  | 211.7 |  |
| Per share amount | $ | 0.72 |  |  | $ | 1.12 |  |  | $ | 0.72 |  |  | $ | 1.03 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 124 |  |  | $ | 238 |  |  | $ | 124 |  |  | $ | 217 |  |
| Weighted average common shares outstanding | 173.0 |  |  | 211.7 |  |  | 173.0 |  |  | 211.7 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.4 |  |  | 2.1 |  |  | 2.4 |  |  | 2.1 |  |
| Senior Convertible Notes | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Diluted weighted average common shares outstanding | 175.7 |  |  | 213.8 |  |  | 175.7 |  |  | 213.8 |  |
| Per share amount | $ | 0.71 |  |  | $ | 1.11 |  |  | $ | 0.71 |  |  | $ | 1.01 |  |

[0000068505-16-000026:notes:42]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three months ended July 2, 2016, the assumed exercise of 2.3 million options and the assumed vesting of 0.6 million restricted stock units ("RSUs") were excluded because their inclusion would have been antidilutive. For the six months ended July 2, 2016, the assumed exercise of 3.2 million options and the assumed vesting of 0.6 million restricted stock units ("RSUs") were excluded because their inclusion would have been antidilutive.

[0000068505-16-000026:notes:43]
For the three months ended July 4, 2015, the assumed exercise of 1.7 million stock options and the assumed vesting of 0.7 million RSUs were excluded because their inclusion would have been antidilutive. For the six months ended July 4, 2015, the assumed exercise of 3.9 million options and the assumed vesting of 1.2 million RSUs were excluded because their inclusion would have been antidilutive.

[0000068505-16-000026:notes:44]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-16-000026:notes:45]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the three and six months ended July 2, 2016, the dilutive impact of the Senior Convertible Notes was 0.5 million shares and 0.3 million shares, respectively.

[0000068505-16-000026:notes:46]
[same as prior period, unchanged from 0000068505-16-000020:notes:44]

[0000068505-16-000026:notes:47]
[same as prior period, unchanged from 0000068505-16-000020:notes:45]

[0000068505-16-000026:notes:48]
The Company’s cash and cash equivalents were $1.5 billion at July 2, 2016 and $2.0 billion at December 31, 2015. Of these amounts, $64 million was restricted at July 2, 2016 and $63 million was restricted at December 31, 2015.

[0000068505-16-000026:notes:49]
[same as prior period, unchanged from 0000068505-16-000020:notes:47]

[0000068505-16-000026:notes:50]
[same as prior period, unchanged from 0000068505-16-000020:notes:48]

[0000068505-16-000026:notes:51]
|  | July 2, 2016 |  | December 31, 2015 |
| Accounts receivable | $ | 1,122 |  |  | $ | 1,390 |  |
| Less allowance for doubtful accounts | (39 | ) |  | (28 | ) |
|  | $ | 1,083 |  |  | $ | 1,362 |  |

[0000068505-16-000026:notes:52]
[same as prior period, unchanged from 0000068505-16-000020:notes:50]

[0000068505-16-000026:notes:53]
[same as prior period, unchanged from 0000068505-16-000020:notes:51]

[0000068505-16-000026:notes:54]
|  | July 2, 2016 |  | December 31, 2015 |
| Finished goods | $ | 160 |  |  | $ | 151 |  |
| Work-in-process and production materials | 261 |  |  | 287 |  |
|  | 421 |  |  | 438 |  |
| Less inventory reserves | (137 | ) |  | (142 | ) |
|  | $ | 284 |  |  | $ | 296 |  |

[0000068505-16-000026:notes:55]
[same as prior period, unchanged from 0000068505-16-000020:notes:53]

[0000068505-16-000026:notes:56]
[same as prior period, unchanged from 0000068505-16-000020:notes:54]

[0000068505-16-000026:notes:57]
|  | July 2, 2016 |  | December 31, 2015 |
| Available-for-sale securities | $ | 47 |  |  | $ | 438 |  |
| Costs and earnings in excess of billings | 350 |  |  | 374 |  |
| Tax-related refunds receivable | 107 |  |  | 44 |  |
| Other | 131 |  |  | 98 |  |
|  | $ | 635 |  |  | $ | 954 |  |

[0000068505-16-000026:notes:58]
[same as prior period, unchanged from 0000068505-16-000020:notes:56]

[0000068505-16-000026:notes:59]
[same as prior period, unchanged from 0000068505-16-000020:notes:57]

[0000068505-16-000026:notes:60]
|  | July 2, 2016 |  | December 31, 2015 |
| Land | $ | 16 |  |  | $ | 17 |  |
| Building | 543 |  |  | 523 |  |
| Machinery and equipment | 1,897 |  |  | 1,585 |  |
|  | 2,456 |  |  | 2,125 |  |
| Less accumulated depreciation | (1,678 | ) |  | (1,638 | ) |
|  | $ | 778 |  |  | $ | 487 |  |

[0000068505-16-000026:notes:61]
Depreciation expense for the three months ended July 2, 2016 and July 4, 2015 was $44 million and $38 million, respectively. Depreciation expense for the six months ended July 2, 2016 and July 4, 2015 was $92 million and $77 million, respectively.

[0000068505-16-000026:notes:62]
On February 1, 2016, the Company completed the sale of its Penang, Malaysia manufacturing operations, including the land, building, equipment, and inventory, as well as the transfer of employees to a contract manufacturer. During the six months ended July 2, 2016, the Company incurred a loss of $7 million on the sale of its Penang, Malaysia facility and manufacturing operations, which is included within Gains (losses) on sales of investments and businesses, net.

[0000068505-16-000026:notes:63]
The Company acquired property, plant and equipment, including network-related assets, with a fair value of $245 million in the acquisition of GDCL on February 19, 2016. The valuation of acquired property, plant and equipment has been finalized during the three months ended July 2, 2016. See discussion in Note 14.

[0000068505-16-000026:notes:64]
During the three months ended July 2, 2016, the Company sold parcels of its Schaumburg, IL headquarters campus and entered into an agreement to sell the remaining buildings and parcels. A building impairment loss of $17 million has been recognized in Other charges during the three months ended July 2, 2016 related to the excess carrying value of the long-lived assets in relation to the selling price. All of the buildings on the Schaumburg campus are classified as assets held and used as of July 2, 2016.

[0000068505-16-000026:notes:65]
In December 2015, the Company invested $401 million in United Kingdom treasury securities in order to partially offset the risk associated with fluctuations in the British Pound Sterling in the period before the closing of the purchase of GDCL. The investments were recorded within Other current assets in the Company's consolidated balance sheets. The Company liquidated these investments in February 2016 to partially fund the acquisition of GDCL. During the six months ended July 2, 2016, the Company realized a loss of $19 million associated with the sale of the treasury securities, of which, $11 million was unrealized as of December 31, 2015.

[0000068505-16-000026:notes:66]
[same as prior period, unchanged from 0000068505-16-000020:notes:64]

[0000068505-16-000026:notes:67]
[same as prior period, unchanged from 0000068505-16-000020:notes:65]

[0000068505-16-000026:notes:68]
|  | July 2, 2016 |  | December 31, 2015 |
| Intangible assets, net (Note 14) | $ | 824 |  |  | $ | 49 |  |
| Long-term receivables | 42 |  |  | 47 |  |
| Defined benefit plan assets | 143 |  |  | 128 |  |
| Other | 52 |  |  | 47 |  |
|  | $ | 1,061 |  |  | $ | 271 |  |

[0000068505-16-000026:notes:69]
[same as prior period, unchanged from 0000068505-16-000020:notes:67]

[0000068505-16-000026:notes:70]
[same as prior period, unchanged from 0000068505-16-000020:notes:68]

[0000068505-16-000026:notes:71]
|  | July 2, 2016 |  | December 31, 2015 |
| Deferred revenue | $ | 361 |  |  | $ | 390 |  |
| Compensation | 166 |  |  | 241 |  |
| Billings in excess of costs and earnings | 291 |  |  | 337 |  |
| Tax liabilities | 65 |  |  | 48 |  |
| Dividend payable | 70 |  |  | 71 |  |
| Trade liabilities | 137 |  |  | 135 |  |
| Other | 541 |  |  | 449 |  |
|  | $ | 1,631 |  |  | $ | 1,671 |  |

[0000068505-16-000026:notes:72]
[same as prior period, unchanged from 0000068505-16-000020:notes:70]

[0000068505-16-000026:notes:73]
[same as prior period, unchanged from 0000068505-16-000020:notes:72]

[0000068505-16-000026:notes:74]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, November 3, 2014, and August 3, 2016, the Board of Directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date.

[0000068505-16-000026:notes:75]
During the six months ended July 2, 2016, the Company paid an aggregate of $619 million, including transaction costs, to repurchase approximately 9.0 million shares at an average price of $68.68 per share. As of July 2, 2016, the Company had used approximately $11.6 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $415 million of authority available for future repurchases. Subsequent to quarter end, the Board of Directors approved a $2.0 billion increase to the share repurchase program, raising the remaining authority available for future repurchases to $2.4 billion.

[0000068505-16-000026:notes:76]
Payment of Dividends:  During both the three months ended July 2, 2016 and July 4, 2015, the Company paid $72 million  in cash dividends to holders of its common stock. During the six months ended July 2, 2016 and July 4, 2015, the Company paid $143 million and $148 million, respectively, in cash dividends to holders of its common stock.

[0000068505-16-000026:notes:77]
[same as prior period, unchanged from 0000068505-16-000020:notes:76]

[0000068505-16-000026:notes:78]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and six months ended July 2, 2016 and July 4, 2015:

[0000068505-16-000026:notes:79]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (253 | ) |  | $ | (230 | ) |  | $ | (266 | ) |  | $ | (204 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (98 | ) |  | 7 |  |  | (84 | ) |  | (18 | ) |
| Tax expense | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Other comprehensive income (loss), net of tax | (98 | ) |  | 7 |  |  | (85 | ) |  | (19 | ) |
| Balance at end of period | $ | (351 | ) |  | $ | (223 | ) |  | $ | (351 | ) |  | $ | (223 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | 1 |  |  | $ | 11 |  |  | $ | (3 | ) |  | $ | 44 |  |
| Other comprehensive income (loss) before reclassification adjustment | (2 | ) |  | 6 |  |  | (2 | ) |  | (1 | ) |
| Tax (expense) benefit | 1 |  |  | (2 | ) |  | 1 |  |  | 1 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (1 | ) |  | 4 |  |  | (1 | ) |  | — |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net | — |  |  | — |  |  | 6 |  |  | (46 | ) |
| Tax expense (benefit) | — |  |  | — |  |  | (2 | ) |  | 17 |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | — |  |  | — |  |  | 4 |  |  | (29 | ) |
| Other comprehensive income (loss), net of tax | (1 | ) |  | 4 |  |  | 3 |  |  | (29 | ) |
| Balance at end of period | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | (1,593 | ) |  | (1,694 | ) |  | $ | (1,597 | ) |  | $ | (1,695 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 53 |  |  | (53 | ) |  | 53 |  |  | (53 | ) |
| Tax expense | (16 | ) |  | — |  |  | (16 | ) |  | — |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 37 |  |  | (53 | ) |  | 37 |  |  | (53 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 18 |  |  | 18 |  |  | 28 |  |  | 36 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (7 | ) |  | (16 | ) |  | (13 | ) |  | (32 | ) |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Other charges | — |  |  | (32 | ) |  | — |  |  | (32 | ) |
| Tax expense (benefit) | 8 |  |  | — |  |  | 8 |  |  | (1 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | 19 |  |  | (30 | ) |  | 23 |  |  | (29 | ) |
| Other comprehensive income (loss), net of tax | 56 |  |  | (83 | ) |  | 60 |  |  | (82 | ) |
| Balance at end of period | $ | (1,537 | ) |  | $ | (1,777 | ) |  | $ | (1,537 | ) |  | $ | (1,777 | ) |
| Total Accumulated other comprehensive loss | $ | (1,888 | ) |  | $ | (1,985 | ) |  | $ | (1,888 | ) |  | $ | (1,985 | ) |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000068505-16-000026:notes:80]
The following table presents the unaudited pro forma combined results of operations of the Company and GDCL for the three and six months ended July 2, 2016 and July 4, 2015 as if the acquisition of GDCL had occurred on January 1, 2016 and January 1, 2015, respectively, (in millions, except per share amounts):

[0000068505-16-000026:notes:81]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Revenues | $ | 1,430 |  |  | $ | 1,515 |  |  | $ | 2,694 |  |  | $ | 2,880 |  |
| Earnings from continuing operations | 104 |  |  | (727 | ) |  | 148 |  |  | (616 | ) |
| Basic earnings per share | 0.62 |  |  | (3.49 | ) |  | 0.86 |  |  | (2.91 | ) |
| Diluted earnings per share | 0.61 |  |  | (3.49 | ) |  | 0.84 |  |  | (2.88 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-16-000026:notes:82]
Commitments and Contingencies

[0000068505-16-000026:notes:83]
Legal Matters

[0000068505-16-000026:notes:84]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-16-000026:notes:85]
Other Indemnifications

[0000068505-16-000026:notes:86]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-16-000026:notes:87]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at July 2, 2016.

[0000068505-16-000026:notes:88]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-16-000026:notes:89]
Debt and Credit Facilities

[0000068505-16-000026:notes:90]
As of July 2, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 2, 2016. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the six months ended July 2, 2016.

[0000068505-16-000026:notes:91]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a term loan with an initial principal amount of $675 million and a maturity date of February 18, 2019 (the "Term Loan"). Interest on the Term Loan is variable and indexed to LIBOR. Interest expense on the Term Loan is payable quarterly in February, May, August, and November. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. The Company's borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited during the third quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan.

[0000068505-16-000026:notes:92]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, we have revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of July 2, 2016 and December 31, 2015, $35 million and $41 million, respectively, have been reclassified to be presented as a component of long-term debt.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-16-000026:notes:93]
[same as prior period, unchanged from 0000068505-16-000020:notes:94]

[0000068505-16-000026:notes:94]
[same as prior period, unchanged from 0000068505-16-000020:notes:95]

[0000068505-16-000026:notes:95]
As of July 2, 2016, the Company had outstanding foreign exchange contracts with notional amounts totaling $700 million, compared to $494 million outstanding at December 31, 2015. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-16-000026:notes:96]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of July 2, 2016, and the corresponding positions as of December 31, 2015:

[0000068505-16-000026:notes:97]
|  | Notional Amount |
| Net Buy (Sell) by Currency | July 2, 2016 |  | December 31, 2015 |
| Euro | $ | 210 |  |  | $ | 99 |  |
| British Pound | 168 |  |  | 62 |  |
| Chinese Renminbi | (87 | ) |  | (114 | ) |
| Australian Dollar | (57 | ) |  | (60 | ) |
| Brazilian Real | (57 | ) |  | (44 | ) |

[0000068505-16-000026:notes:98]
[same as prior period, unchanged from 0000068505-16-000020:notes:99]

[0000068505-16-000026:notes:99]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swap was in a liability position of $1 million at both July 2, 2016 and  December 31, 2015.

[0000068505-16-000026:notes:100]
[same as prior period, unchanged from 0000068505-16-000020:notes:101]

[0000068505-16-000026:notes:101]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of July 2, 2016, all of the counterparties have investment grade credit ratings. As of July 2, 2016, the Company had $1 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-16-000026:notes:102]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of July 2, 2016 and December 31, 2015:

[0000068505-16-000026:notes:103]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| July 2, 2016 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | Other current assets |  | $ | 15 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | 1 |  |  |  |  | $ | 16 |  |  |  |

[0000068505-16-000026:notes:104]
[same as prior period, unchanged from 0000068505-16-000020:notes:105]

[0000068505-16-000026:notes:105]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated statements of operations for the three and six months ended July 2, 2016 and July 4, 2015:

[0000068505-16-000026:notes:106]
|  | Three Months Ended |  | Six Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |  |
| Interest rate swap | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | Other income (expense) |
| Foreign exchange contracts | (18 | ) |  | 4 |  |  | (30 | ) |  | (13 | ) |  | Other income (expense) |
| Total derivatives | $ | (18 | ) |  | $ | 4 |  |  | $ | (30 | ) |  | $ | (12 | ) |  |  |

[0000068505-16-000026:notes:107]
The Company had no instruments designated as hedging instruments for the three and six months ended July 2, 2016 and July 4, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-16-000026:notes:108]
[same as prior period, unchanged from 0000068505-16-000020:notes:109]

[0000068505-16-000026:notes:109]
During the six months ended July 2, 2016, the Company granted 0.7 million RSUs and market stock units ("MSUs") and 0.7 million stock options and performance options ("POs"). The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and MSUs was $40 million and stock options and POs was $10 million, respectively, which will generally be recognized over the vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-16-000026:notes:110]
[same as prior period, unchanged from 0000068505-16-000020:notes:111]

[0000068505-16-000026:notes:111]
[same as prior period, unchanged from 0000068505-16-000020:notes:112]

[0000068505-16-000026:notes:112]
During the three and six months ended July 2, 2016, the Company had no activity in the condensed consolidated statements of operations for discontinued operations. During the three and six months ended July 4, 2015, the Company recorded losses from discontinued operations of $8 million and $21 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-16-000026:notes:113]
[same as prior period, unchanged from 0000068505-16-000020:notes:114]

[0000068505-16-000026:notes:114]
[same as prior period, unchanged from 0000068505-16-000020:notes:115]

[0000068505-16-000026:notes:115]
[same as prior period, unchanged from 0000068505-16-000020:notes:116]

[0000068505-16-000026:notes:116]
[same as prior period, unchanged from 0000068505-16-000020:notes:117]

[0000068505-16-000026:notes:117]
[same as prior period, unchanged from 0000068505-16-000020:notes:118]

[0000068505-16-000026:notes:118]
[same as prior period, unchanged from 0000068505-16-000020:notes:119]

[0000068505-16-000026:notes:119]
The Company had no Level 3 holdings as of July 2, 2016 or December 31, 2015.

[0000068505-16-000026:notes:120]
At July 2, 2016 and December 31, 2015, the Company had $936 million and $1.3 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-16-000026:notes:121]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at July 2, 2016 and December 31, 2015 was $5.1 billion and $4.1 billion (Level 2), respectively.

[0000068505-16-000026:notes:122]
[same as prior period, unchanged from 0000068505-16-000020:notes:123]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-16-000026:notes:123]
[same as prior period, unchanged from 0000068505-16-000020:notes:124]

[0000068505-16-000026:notes:124]
[same as prior period, unchanged from 0000068505-16-000020:notes:125]

[0000068505-16-000026:notes:125]
[same as prior period, unchanged from 0000068505-16-000020:notes:126]

[0000068505-16-000026:notes:126]
[same as prior period, unchanged from 0000068505-16-000020:notes:127]

[0000068505-16-000026:notes:127]
The acquisition of GDCL enables the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. During the six months ended July 2, 2016, the Company recorded $207 million within Net sales and $45 million within Net earnings from the operations of Airwave.

[0000068505-16-000026:notes:128]
The acquisition of GDCL has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value. During the three months ended July 2, 2016, the Company finalized its valuation of acquired Property, plant and equipment, recording an adjustment of $236 million to record acquired network-related assets at fair value. As a result, the Company has recorded additional purchase accounting adjustments during the three months ended July 2, 2016, primarily related to the fair value of acquired intangibles and goodwill.

[0000068505-16-000026:notes:129]
The total consideration for the acquisition of GDCL was approximately $1.1 billion, consisting of cash payments of $1.0 billion, net of cash acquired, and deferred consideration valued at fair value on the date of the acquisition of $82 million. The fair value of deferred consideration has been determined based on its net present value, calculated using a discount rate of 4.2%, which is reflective of the credit standing of the combined entity. The following table summarizes fair values of assets acquired and liabilities assumed as of the February 19, 2016 acquisition date:

[0000068505-16-000026:notes:130]
| Cash |  | $ | 86 |  |
| Accounts receivable, net |  | 55 |  |
| Other current assets |  | 36 |  |
| Property, plant and equipment, net |  | 245 |  |
| Deferred income taxes |  | 78 |  |
| Accounts payable |  | (18 | ) |
| Accrued liabilities |  | (181 | ) |
| Other liabilities |  | (283 | ) |
| Goodwill |  | 189 |  |
| Intangible assets |  | 875 |  |
| Total consideration |  | $ | 1,082 |  |
| Net present value of deferred consideration payment to former owners |  | (82 | ) |
| Net cash consideration at purchase |  | $ | 1,000 |  |

[0000068505-16-000026:notes:131]
Acquired intangible assets consist of $846 million of customer relationships and $29 million of trade names. All intangibles have a useful life of 7 years, over which amortization expense will be recognized on a straight line basis.

[0000068505-16-000026:notes:132]
[same as prior period, unchanged from 0000068505-16-000020:notes:133]

[0000068505-16-000026:notes:133]
The fair value of acquired Property, plant and equipment, primarily network-related assets, was valued under the replacement cost method, which determines fair value based on the replacement cost of new property with similar capacity, adjusted for physical deterioration over the remaining useful life.

[0000068505-16-000026:notes:134]
[same as prior period, unchanged from 0000068505-16-000020:notes:134]

[0000068505-16-000026:notes:135]
[same as prior period, unchanged from 0000068505-16-000020:notes:135]

[0000068505-16-000026:notes:136]
The Company did not adjust the effects of an $884 million goodwill impairment charge reported in the historic results of GDCL for the three and six months ended July 4, 2015 on the basis that the goodwill impairment charge was not directly attributable to the acquisition of GDCL by the Company. However, this goodwill impairment charge should be highlighted as unusual and non-recurring.

[0000068505-16-000026:notes:137]
The pro forma results are based on estimates and assumptions, which the Company believes are reasonable. They are not necessarily indicative of its consolidated results of operations in future periods or the results that actually would have been realized had we been a combined company during the periods presented. The pro forma results include adjustments primarily related to amortization of acquired intangible assets, depreciation, interest expense, and transaction costs expensed during the period.

[0000068505-16-000026:notes:138]
[same as prior period, unchanged from 0000068505-16-000020:notes:137]

[0000068505-16-000026:notes:139]
[same as prior period, unchanged from 0000068505-16-000020:notes:138]

[0000068505-16-000026:notes:140]
|  | July 2, 2016 |  | December 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 60 |  |  | $ | 35 |  |  | $ | 60 |  |  | $ | 32 |  |
| Patents | 8 |  |  | 6 |  |  | 8 |  |  | 5 |  |
| Customer-related | 821 |  |  | 53 |  |  | 23 |  |  | 10 |  |
| Other intangibles | 44 |  |  | 15 |  |  | 20 |  |  | 15 |  |
|  | $ | 933 |  |  | $ | 109 |  |  | $ | 111 |  |  | $ | 62 |  |

[0000068505-16-000026:notes:141]
Amortization expense on intangible assets was $38 million for the three months ended July 2, 2016 and $52 million for the six months ended July 2, 2016. Amortization expense on intangible assets was $3 million for the three months ended July 4, 2015 and $4 million for the six months ended July 4, 2015. The increase in amortization expense is due to the acquisition of GDCL, including a cumulative adjustment during the six months ended July 2, 2016 to record incremental intangible amortization expense associated with the final fair value adjustment of intangible assets under purchase accounting. As of July 2, 2016, annual amortization expense is estimated to be $112 million in 2016, $126 million in 2017 and 2018, $125 million in 2019, and $122 million in 2020 and 2021.

[0000068505-16-000026:notes:142]
[same as prior period, unchanged from 0000068505-16-000020:notes:141]

[0000068505-16-000026:notes:143]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2016 to July 2, 2016:

[0000068505-16-000026:notes:144]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2016 |  |  |  |  |  |
| Aggregate goodwill | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Goodwill acquired | — |  |  | 170 |  |  | 170 |  |
| Purchase accounting adjustments | — |  |  | 19 |  |  | 19 |  |
| Foreign currency | — |  |  | (12 | ) |  | (12 | ) |
| Balance as of July 2, 2016 |  |  |  |  |  |
| Aggregate goodwill | $ | 270 |  |  | $ | 327 |  |  | $ | 597 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 327 |  |  | $ | 597 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-16-000026:notes:145]
[same as prior period, unchanged from 0000068505-16-000020:notes:144]

[0000068505-16-000026:notes:146]
[same as prior period, unchanged from 0000068505-16-000020:notes:145]

[0000068505-16-000026:notes:147]
[same as prior period, unchanged from 0000068505-16-000020:notes:146]

[0000068505-16-000026:notes:148]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Earnings from continuing operations before income taxes | $ | 167 |  |  | $ | 215 |  |  | $ | 189 |  |  | $ | 343 |  |
| Income tax expense | 59 |  |  | 64 |  |  | 64 |  |  | 104 |  |
| Effective tax rate | 35 | % |  | 30 | % |  | 34 | % |  | 30 | % |

[0000068505-16-000026:notes:149]
The Company recorded $59 million of net tax expense in the second quarter of 2016 resulting in an effective tax rate of 35%, compared to $64 million of net tax expense in the second quarter of 2015 resulting in an effective tax rate of 30%. The effective tax rate in the second quarter of 2016 was equal to the U.S. statutory tax rate of 35% and was impacted by discrete adjustments to deferred tax assets of foreign subsidiaries, offset by excess tax benefits on share-based compensation. The effective tax rate in the second quarter of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S. domestic production tax deduction.

[0000068505-16-000026:notes:150]
The Company recorded $64 million of net tax expense in the first half of 2016 resulting in an effective tax rate of 34%, compared to $104 million of net tax expense resulting in an effective tax rate of 30% in the first half of 2015. The effective tax rate for the first half of 2016 was lower than the U.S. statutory tax rate of 35% partly due to the recognition of excess tax benefits on share-based compensation. The effective tax rate in the first half of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S. domestic production tax deduction.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-16-000026:notes:151]
Recent Accounting Pronouncements

[0000068505-16-000026:notes:152]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, "Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)" which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. In April of 2016, the FASB issued ASU 2016-10, "Revenue from Contracts with Customers (Topic 606) - Identifying Performance Obligations and Licensing,” which reduces the complexity when applying the guidance for identifying performance obligations and improves the operability and understandability of the license implementation guidance. In May 2016, the FASB issued ASU 2016-12 “Revenue from Contracts with Customers (Topic 606) - Narrow-Scope Improvements and Practical Expedients,” which amends the guidance on transition, collectability, non-cash consideration, and the presentation of sales and other similar taxes. ASU 2016-12 clarifies that, for a contract to be considered completed at transition, all (or substantially all) of the revenue must have been recognized under legacy GAAP. In addition, ASU 2016-12 clarifies how an entity should evaluate the collectability threshold and when an entity can recognize nonrefundable consideration received as revenue if an arrangement does not meet the standard’s contract criteria. The standard allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-16-000026:notes:153]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0000068505-16-000026:notes:154]
In March 2016, the FASB issued ASU 2016-07, "Investments - Equity Method and Joint Ventures: Simplifying the Transition to the Equity Method of Accounting," which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. ASU 2016-07 is effective for the Company January 1, 2017 and interim periods within that reporting period. The adoption of ASU 2016-07 is not expected to have a material effect on the Company’s consolidated financial statements.

[0000068505-16-000026:notes:155]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurements of Credit Losses on Financial Instruments," which requires measurement and recognition of expected credit losses for financial assets held.  The ASU is effective for the Company January 1, 2020 and interim periods within that reporting period. The adoption of ASU 2016-13 is not expected to have a material effect on the Company’s consolidated financial statements.

[0000068505-16-000026:notes:156]
The Company elected to adopt ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” as of January 1, 2016. ASU 2016-09, which was issued by the FASB in March 2016, simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $3 million income tax benefit during the six months ended July 2, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $14 million for both the six months ended July 2, 2016 and July 4, 2015. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $3 million for the six months ended July 2, 2016.

[0000068505-16-000026:notes:157]
The Company adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs," effective January 1, 2016. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We have retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of July 2, 2016 and December 31, 2015, $35 million and $41 million, respectively, have been presented as a component of long-term debt.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-16-000026:notes:158]
[same as prior period, unchanged from 0000068505-16-000020:notes:155]

[0000068505-16-000026:notes:159]
The condensed consolidated financial statements as of July 2, 2016 and for the three and six months ended July 2, 2016 and July 4, 2015 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-16-000026:notes:160]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2015. The results of operations for the three and six months ended July 2, 2016 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-16-000026:notes:161]
[same as prior period, unchanged from 0000068505-16-000020:notes:158]

[0000068505-16-000026:notes:162]
[same as prior period, unchanged from 0000068505-16-000020:notes:159]

[0000068505-16-000026:notes:163]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018. The Company funded the investment with a $675 million term loan (the “Term Loan”) and approximately $400 million of international cash on hand. The acquisition has been reported within our Services segment, enabling the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. See discussion in Note 14.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-16-000026:notes:164]
[same as prior period, unchanged from 0000068505-16-000020:notes:161]

[0000068505-16-000026:notes:165]
[same as prior period, unchanged from 0000068505-16-000020:notes:162]

[0000068505-16-000026:notes:166]
[same as prior period, unchanged from 0000068505-16-000020:notes:163]

[0000068505-16-000026:notes:167]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 46 |  |  | 47 |  |  | 14 |  |  | 19 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (55 | ) |  | (52 | ) |  | (24 | ) |  | (31 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 9 |  |  | 11 |  |  | 3 |  |  | 5 |  |  | 2 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (1 | ) |  | (7 | ) |  | (15 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | — |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | (36 | ) |  | $ | (7 | ) |  | $ | (13 | ) |

[0000068505-16-000026:notes:168]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 91 |  |  | 96 |  |  | 28 |  |  | 35 |  |  | 2 |  |  | 4 |  |
| Expected return on plan assets | (110 | ) |  | (106 | ) |  | (48 | ) |  | (57 | ) |  | (5 | ) |  | (5 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 19 |  |  | 23 |  |  | 6 |  |  | 9 |  |  | 3 |  |  | 5 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (2 | ) |  | (13 | ) |  | (30 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | — |  |  | $ | 13 |  |  | $ | (10 | ) |  | $ | (40 | ) |  | $ | (13 | ) |  | $ | (25 | ) |

[0000068505-16-000026:notes:169]
During the six months ended July 2, 2016, the Company made an amendment to the Postretirement Health Care Benefits Plan (the “Amendment”). As a result of the Amendment, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.

[0000068505-16-000026:notes:170]
The Amendment to the Postretirement Health Care Benefits Plan required a remeasurement of the plan, resulting in a $53 million reduction in the accumulated Postretirement Benefit Obligation. A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the condensed consolidated statements of operations over approximately 5 years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.

[0000068505-16-000026:notes:171]
During the six months ended July 4, 2015, the Company amended its Non U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.  As a result, the Company recorded a curtailment gain of $32 million to Other charges in the Company’s condensed consolidated statements of operations.

[0000068505-16-000026:notes:172]
Effective January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, therefore, has accounted for it prospectively beginning January 1, 2016. Based on the change in estimate, the Company experienced no reduction in service costs and a $14 million reduction in interest costs for the six months ended July 2, 2016 compared to the prior approach. The overall reduction in the interest cost for the six months ended July 2, 2016 is comprised of $9 million related to the U.S. Pension Benefit Plans, $2 million related to the Postretirement Health Care Benefit Plans, and $3 million related to the Non U.S. Pension Benefits Plan.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-16-000026:notes:173]
[same as prior period, unchanged from 0000068505-16-000020:notes:166]

[0000068505-16-000026:notes:174]
[same as prior period, unchanged from 0000068505-16-000020:notes:167]

[0000068505-16-000026:notes:175]
During the three months ended July 2, 2016, the Company recorded net reorganization of business charges of $44 million including $36 million of charges in Other charges and $8 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $44 million were charges of: (i) $22 million of charges related to employee separation costs, (ii) $17 million for a building impairment, and (iii) $5 million for exit costs.

[0000068505-16-000026:notes:176]
During the six months ended July 2, 2016, the Company recorded net reorganization of business charges of $67 million including $42 million of charges in Other charges and $25 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $67 million were charges of: (i) $46 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-16-000026:notes:177]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2016 to July 2, 2016:

[0000068505-16-000026:notes:178]
|  | January 1, 2016 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | July 2, 2016 |
| Exit costs | $ | 9 |  |  | $ | 5 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | 11 |  |
| Employee separation costs | 51 |  |  | 46 |  |  | (4 | ) |  | (39 | ) |  | 54 |  |
|  | $ | 60 |  |  | $ | 51 |  |  | $ | (4 | ) |  | $ | (42 | ) |  | $ | 65 |  |

[0000068505-16-000026:notes:179]
[same as prior period, unchanged from 0000068505-16-000020:notes:171]

[0000068505-16-000026:notes:180]
At January 1, 2016, the Company had $9 million of accruals for exit costs. During the six months ended July 2, 2016, there were $5 million additional charges and $3 million of cash payments related to the exit of leased facilities. The remaining accrual of $11 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at July 2, 2016, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-16-000026:notes:181]
[same as prior period, unchanged from 0000068505-16-000020:notes:173]

[0000068505-16-000026:notes:182]
At January 1, 2016, the Company had an accrual of $51 million for employee separation costs. The 2016 additional charges of $46 million represent severance costs for approximately 300 employees. The adjustment of $4 million reflects  reversals for accruals no longer needed. The $39 million used reflects cash payments to severed employees. The remaining accrual of $54 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at July 2, 2016, is expected to be paid, primarily within one year, to approximately 400 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-16-000026:notes:183]
[same as prior period, unchanged from 0000068505-16-000020:notes:175]

[0000068505-16-000026:notes:184]
During the three months ended July 4, 2015, the Company recorded net reorganization of business charges of $16 million, including $13 million of charges in Other charges and $3 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $16 million of charges were all related to employee separation costs.

[0000068505-16-000026:notes:185]
During the six months ended July 4, 2015, the Company recorded net reorganization of business charges of $30 million, including $26 million of charges in Other charges and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $30 million were charges of $26 million related to employee separation costs and $4 million related to exit costs.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-16-000026:notes:186]
[same as prior period, unchanged from 0000068505-16-000020:notes:177]

[0000068505-16-000026:notes:187]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Products | $ | 801 |  |  | $ | 867 |  |  | $ | 1,503 |  |  | $ | 1,626 |  |
| Services | 629 |  |  | 501 |  |  | 1,120 |  |  | 965 |  |
|  | $ | 1,430 |  |  | $ | 1,368 |  |  | $ | 2,623 |  |  | $ | 2,591 |  |

[0000068505-16-000026:notes:188]
[same as prior period, unchanged from 0000068505-16-000020:notes:179]

[0000068505-16-000026:notes:189]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Products | $ | 129 |  |  | $ | 171 |  |  | $ | 179 |  |  | $ | 235 |  |
| Services | 95 |  |  | 83 |  |  | 144 |  |  | 138 |  |
| Operating earnings | 224 |  |  | 254 |  |  | 323 |  |  | 373 |  |
| Total other expense | (57 | ) |  | (39 | ) |  | (134 | ) |  | (30 | ) |
| Earnings from continuing operations before income taxes | $ | 167 |  |  | $ | 215 |  |  | $ | 189 |  |  | $ | 343 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-16-000026:notes:190]
[same as prior period, unchanged from 0000068505-16-000020:notes:181]

[0000068505-16-000026:notes:191]
[same as prior period, unchanged from 0000068505-16-000020:notes:182]

[0000068505-16-000026:notes:192]
[same as prior period, unchanged from 0000068505-16-000020:notes:183]

[0000068505-16-000026:notes:193]
[same as prior period, unchanged from 0000068505-16-000020:notes:184]
