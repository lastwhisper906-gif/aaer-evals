# MSI 8-K — 0001193125-16-671842 filed 2016-08-04

## item codes, every 8-K on or before 2016-08-05

- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2016-08-05

- none on or before 2016-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-671842:8k_2_02:1]
EX-99.1
2
d220181dex991.htm
EX-99.1

[0001193125-16-671842:8k_2_02:2]
EX-99.1

[0001193125-16-671842:8k_2_02:3]
Exhibit 99.1

[0001193125-16-671842:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2016 Financial Results

[0001193125-16-671842:8k_2_02:5]
Announces $2 billion increase to share repurchase program

[0001193125-16-671842:8k_2_02:6]
|  | • |  | Sales of $1.4 billion, up 5 percent from a year ago |

[0001193125-16-671842:8k_2_02:7]
|  | • |  | Backlog ended at $8.2 billion, up 37 percent including $1.6 billion from Airwave |

[0001193125-16-671842:8k_2_02:8]
|  | • |  | Operating cash flow of $292 million, up $143 million |

[0001193125-16-671842:8k_2_02:9]
|  | • |  | GAAP earnings per share (EPS) from continuing operations1 of $0.61, down 15 percent |

[0001193125-16-671842:8k_2_02:10]
|  | • |  | Non-GAAP EPS from continuing operations* of $1.03, up 51 percent |

[0001193125-16-671842:8k_2_02:11]
|  | • |  | Received unconditional clearance for acquisition of Airwave from United Kingdom’s Competition and Markets Authority |

[0001193125-16-671842:8k_2_02:12]
SCHAUMBURG, Ill. – Aug. 4, 2016 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of
2016. Click here for a printable news release and financial tables.

[0001193125-16-671842:8k_2_02:13]
“Q2 was a strong quarter demonstrated by our growth in earnings, cash
flow and backlog,” said Greg Brown, chairman and CEO of Motorola Solutions. “I am pleased with our progress heading into the second half of the year.”

[0001193125-16-671842:8k_2_02:14]
The company also announced that its board of directors has approved a $2 billion increase to the share repurchase program, raising the total authorization
since July 2011 to $14 billion. Under the company’s previously authorized $12 billion share repurchase program, approximately $400 million remained at the end of the second quarter of 2016. The company may continue to repurchase shares from
time to time in the open market or in other privately negotiated transactions, subject to market conditions.

[0001193125-16-671842:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in
millions, except per share data and percentages)

[0001193125-16-671842:8k_2_02:16]
|  |  | Q2 2016 |  |  | Q2 2015 |  |  | % Change |  |
| Sales |  | $ | 1,430 |  |  | $ | 1,368 |  |  |  | 5 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 224 |  |  | $ | 254 |  |  |  | (12 | )% |
| % of Sales |  |  | 15.7 | % |  |  | 18.6 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.61 |  |  | $ | 0.72 |  |  |  | (15 | )% |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 324 |  |  | $ | 260 |  |  |  | 25 | % |
| % of Sales |  |  | 22.7 | % |  |  | 19.0 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 1.03 |  |  | $ | 0.68 |  |  |  | 51 | % |
| Product Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 801 |  |  | $ | 867 |  |  |  | (8 | )% |
| GAAP Operating Earnings |  | $ | 129 |  |  | $ | 171 |  |  |  | (25 | )% |
| % of Sales |  |  | 16.1 | % |  |  | 19.7 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 176 |  |  | $ | 176 |  |  |  | — | % |
| % of Sales |  |  | 22.0 | % |  |  | 20.3 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 629 |  |  | $ | 501 |  |  |  | 26 | % |
| GAAP Operating Earnings |  | $ | 95 |  |  | $ | 83 |  |  |  | 14 | % |
| % of Sales |  |  | 15.1 | % |  |  | 16.6 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 148 |  |  | $ | 84 |  |  |  | 76 | % |
| % of Sales |  |  | 23.5 | % |  |  | 16.8 | % |  |  |  |  |

[0001193125-16-671842:8k_2_02:17]
| * | Non-GAAP financial information excludes the after-tax impact of approximately $0.42 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-16-671842:8k_2_02:18]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-16-671842:8k_2_02:19]
|  | • |  | Revenue – Sales increased 5 percent, including $146 million in sales associated with the Airwave acquisition. As expected, Products segment sales declined 8 percent primarily driven by weakness in Latin America, Europe and China. The Services segment grew 26 percent with the addition of Airwave, and posted growth of 4 percent in organic managed and support services. Excluding Airwave, the Services segment declined 4 percent due to lower systems integration revenues associated with the completion of a large project in Europe. |

[0001193125-16-671842:8k_2_02:20]
|  | • |  | Operating margin – GAAP operating margin was 15.7 percent of sales, compared with 18.6 percent in the year-ago quarter, reflecting higher amortization and restructuring charges. Non-GAAP operating margin was 22.7 percent of sales, compared with 19.0 percent in the year-ago quarter, driven by higher sales and $31 million in lower operating expenses compared with the second quarter of 2015. |

[0001193125-16-671842:8k_2_02:21]
|  | • |  | Taxes – The GAAP effective tax rate was 35 percent, compared with 30 percent in the year-ago quarter. The non-GAAP tax rate was 32 percent, compared with 35 percent in the year-ago quarter. The full-year non-GAAP tax rate is expected to be approximately 33 percent. |

[0001193125-16-671842:8k_2_02:22]
|  | • |  | Cash flow – The company generated $292 million in operating cash from continuing operations, reflecting an increase of $143 million over the prior year, driven by higher earnings and improved working capital. Free cash flow2 was $201 million. |

[0001193125-16-671842:8k_2_02:23]
|  | • |  | Cash and cash equivalents – The company ended the quarter with cash and cash equivalents of $1.5 billion and a net debt position of $3.5 billion3. The company repurchased approximately $555 million of its common stock in the quarter and paid approximately $72 million in cash dividends. |

[0001193125-16-671842:8k_2_02:24]
|  | • |  | Backlog – Ending backlog is $8.2 billion, up $2.2 billion from the year ago period, driven by the addition of $1.6 billion from Airwave and approximately $600 million of organic managed and support services. Products backlog was up $64 million from the year-ago period. |

[0001193125-16-671842:8k_2_02:25]
KEY HIGHLIGHTS

[0001193125-16-671842:8k_2_02:26]
Strategic sales

[0001193125-16-671842:8k_2_02:27]
|  | • |  | $200 million award for a multi-county, P25 ASTRO system in the Richmond, Virginia, region |

[0001193125-16-671842:8k_2_02:28]
|  | • |  | $44 million contract for P25 ASTRO system and subscribers with a large U.S. utility |

[0001193125-16-671842:8k_2_02:29]
|  | • |  | $19 million service extension with an Australian customer |

[0001193125-16-671842:8k_2_02:30]
Innovation and investments in growth

[0001193125-16-671842:8k_2_02:31]
|  | • |  | Introduced WAVE™ 7000 system that enhances work group communications with a redundant, high-availability push-to-talk capability that links millions of users regardless of device |

[0001193125-16-671842:8k_2_02:32]
|  | • |  | Facilitated TETRA Interop field trial with police in Belgium, the Netherlands and Germany to test cross-border, multi-network interoperability |

[0001193125-16-671842:8k_2_02:33]
|  | • |  | Introduced ST7000 small TETRA radio with high-quality audio and a touch screen that appeals to customer-facing staff and executives |

[0001193125-16-671842:8k_2_02:34]
|  | • |  | Announced partnership with Singapore Technologies Electronics to accelerate development of specialized technologies for high-security, mission-critical broadband, cybersecurity solutions and purpose-built applications |

[0001193125-16-671842:8k_2_02:35]
|  | • |  | Received unconditional clearance for acquisition of Airwave from the United Kingdom’s Competition and Markets Authority |

[0001193125-16-671842:8k_2_02:36]
BUSINESS OUTLOOK

[0001193125-16-671842:8k_2_02:37]
|  | • |  | Third-quarter 2016 - Motorola Solutions expects a revenue increase of 6 to 7 percent compared with the third quarter of 2015, which assumes approximately $130 million in revenues associated with the Airwave acquisition. The company expects non-GAAP earnings per share from continuing operations in the range of $1.17 to $1.22 per share. |

[0001193125-16-671842:8k_2_02:38]
|  | • |  | Full-year 2016 - The company continues to expect revenue to increase 5 to 7 percent and non-GAAP earnings per share from continuing operations in the range of $4.45 to $4.65 per share. |

[0001193125-16-671842:8k_2_02:39]
CONFERENCE CALL AND WEBCAST

[0001193125-16-671842:8k_2_02:40]
Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, Aug.
4. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-16-671842:8k_2_02:41]
CONSOLIDATED GAAP RESULTS (presented
in millions, except per share data)

[0001193125-16-671842:8k_2_02:42]
A comparison of results from operations is as follows:

[0001193125-16-671842:8k_2_02:43]
|  |  | Q2 2016 |  |  | Q2 2015 |  |
| Net sales |  | $ | 1,430 |  |  | $ | 1,368 |  |
| Gross margin |  |  | 676 |  |  |  | 648 |  |
| Operating earnings |  |  | 224 |  |  |  | 254 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  |  | 107 |  |  |  | 150 |  |
| Net earnings |  |  | 107 |  |  |  | 142 |  |
| Diluted EPS from continuing operations |  | $ | 0.61 |  |  | $ | 0.72 |  |
| Weighted average diluted common shares outstanding |  |  | 174.8 |  |  |  | 209.5 |  |

[0001193125-16-671842:8k_2_02:44]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-16-671842:8k_2_02:45]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the second quarter of 2016.

[0001193125-16-671842:8k_2_02:46]
| (per diluted common share) |  | Q2 2016 |  |
| GAAP Earnings from Continuing Operations |  | $ | 0.61 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.07 |  |
| Reorganization of business charges |  |  | 0.12 |  |
| Intangibles amortization expense |  |  | 0.17 |  |
| Building impairment |  |  | 0.06 |  |
| Total Highlighted Items |  |  | 0.42 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 1.03 |  |

[0001193125-16-671842:8k_2_02:47]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-16-671842:8k_2_02:48]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-16-671842:8k_2_02:49]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-16-671842:8k_2_02:50]
Share-based compensation expense: The company has excluded share-based compensation expense from its
non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods
presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense.
Share-based compensation expense will recur in future periods.

[0001193125-16-671842:8k_2_02:51]
Intangible assets amortization expense: The company has excluded intangible assets
amortization expense from its Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense.
Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the
company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-16-671842:8k_2_02:52]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press
release.

[0001193125-16-671842:8k_2_02:53]
BUSINESS RISKS

[0001193125-16-671842:8k_2_02:54]
economic conditions and reductions in the company’s purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other
representatives; (10) the impact on the company’s performance and financial results from strategic acquisitions or divestitures, including the acquisition of Airwave; (11) risks related to the company’s manufacturing and business
operations in foreign countries; (12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems; (13) exposure under large systems and managed services contracts, including risks
related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA”
by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected
liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of
the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market
conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company’s outsourcing of various activities, including certain
manufacturing operations, information technology and administrative functions; (22) the impact of the sale of the company’s legacy information systems, including components of the enterprise resource planning (ERP) system and the implementation
of a new ERP system; and (23) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a
result of new information, future events or otherwise.

[0001193125-16-671842:8k_2_02:55]
DEFINITIONS

[0001193125-16-671842:8k_2_02:56]
| 1 | Amounts attributable to Motorola Solutions, Inc. common shareholders |

[0001193125-16-671842:8k_2_02:57]
| 2 | Free cash flow represents operating cash flow less capital expenditures |

[0001193125-16-671842:8k_2_02:58]
| 3 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-16-671842:8k_2_02:59]
ABOUT
MOTOROLA SOLUTIONS

[0001193125-16-671842:8k_2_02:60]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety
and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-16-671842:8k_2_02:61]
MEDIA CONTACT

[0001193125-16-671842:8k_2_02:62]
Tama McWhinney

[0001193125-16-671842:8k_2_02:63]
Motorola Solutions

[0001193125-16-671842:8k_2_02:64]
+1 847-538-1865

[0001193125-16-671842:8k_2_02:65]
tama.mcwhinney@motorolasolutions.com

[0001193125-16-671842:8k_2_02:66]
INVESTOR CONTACT

[0001193125-16-671842:8k_2_02:67]
Chris Kutsor

[0001193125-16-671842:8k_2_02:68]
Motorola Solutions

[0001193125-16-671842:8k_2_02:69]
+1 847-576-4995

[0001193125-16-671842:8k_2_02:70]
chris.kutsor@motorolasolutions.com

[0001193125-16-671842:8k_2_02:71]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license.
All other trademarks are the property of their respective owners. ©2015 Motorola Solutions, Inc. All rights reserved.

[0001193125-16-671842:8k_2_02:72]
GAAP-1

[0001193125-16-671842:8k_2_02:73]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:74]
Condensed Consolidated Statements of Operations

[0001193125-16-671842:8k_2_02:75]
(In millions, except per share amounts)

[0001193125-16-671842:8k_2_02:76]
|  |  | Three Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Net sales from products |  | $ | 801 |  |  | $ | 867 |  |
| Net sales from services |  |  | 629 |  |  |  | 501 |  |
| Net sales |  |  | 1,430 |  |  |  | 1,368 |  |
| Costs of products sales |  |  | 361 |  |  |  | 385 |  |
| Costs of services sales |  |  | 393 |  |  |  | 335 |  |
| Costs of sales |  |  | 754 |  |  |  | 720 |  |
| Gross margin |  |  | 676 |  |  |  | 648 |  |
| Selling, general and administrative expenses |  |  | 240 |  |  |  | 254 |  |
| Research and development expenditures |  |  | 138 |  |  |  | 156 |  |
| Other charges (income) |  |  | 36 |  |  |  | (19 | ) |
| Intangibles amortization |  |  | 38 |  |  |  | 3 |  |
| Operating earnings |  |  | 224 |  |  |  | 254 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (54 | ) |  |  | (39 | ) |
| Gains on sales of investments and businesses, net |  |  | 1 |  |  |  | 4 |  |
| Other |  |  | (4 | ) |  |  | (4 | ) |
| Total other expense |  |  | (57 | ) |  |  | (39 | ) |
| Earnings from continuing operations before income taxes |  |  | 167 |  |  |  | 215 |  |
| Income tax expense |  |  | 59 |  |  |  | 64 |  |
| Earnings from continuing operations |  |  | 108 |  |  |  | 151 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (8 | ) |
| Net earnings |  |  | 108 |  |  |  | 143 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 107 |  |  | $ | 142 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 107 |  |  | $ | 150 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (8 | ) |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 107 |  |  | $ | 142 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.62 |  |  | $ | 0.72 |  |
| Discontinued operations |  |  | — |  |  |  | (0.04 | ) |
|  |  | $ | 0.62 |  |  | $ | 0.68 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.61 |  |  | $ | 0.72 |  |
| Discontinued operations |  |  | — |  |  |  | (0.04 | ) |
|  |  | $ | 0.61 |  |  | $ | 0.68 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 171.9 |  |  |  | 208.0 |  |
| Diluted |  |  | 174.8 |  |  |  | 209.5 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 56.0 | % |  |  | 63.4 | % |
| Net sales from services |  |  | 44.0 | % |  |  | 36.6 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 45.1 | % |  |  | 44.4 | % |
| Costs of services sales |  |  | 62.5 | % |  |  | 66.9 | % |
| Costs of sales |  |  | 52.7 | % |  |  | 52.6 | % |
| Gross margin |  |  | 47.3 | % |  |  | 47.4 | % |
| Selling, general and administrative expenses |  |  | 16.8 | % |  |  | 18.6 | % |
| Research and development expenditures |  |  | 9.7 | % |  |  | 11.4 | % |
| Other charges (income) |  |  | 2.5 | % |  |  | (1.4 | )% |
| Intangibles amortization |  |  | 2.7 | % |  |  | 0.2 | % |
| Operating earnings |  |  | 15.7 | % |  |  | 18.6 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.8 | )% |  |  | (2.9 | )% |
| Gains on sales of investments and businesses, net |  |  | 0.1 | % |  |  | 0.3 | % |
| Other |  |  | (0.3 | )% |  |  | (0.3 | )% |
| Total other expense |  |  | (4.0 | )% |  |  | (2.9 | )% |
| Earnings from continuing operations before income taxes |  |  | 11.7 | % |  |  | 15.7 | % |
| Income tax expense |  |  | 4.1 | % |  |  | 4.7 | % |
| Earnings from continuing operations |  |  | 7.6 | % |  |  | 11.0 | % |
| Loss from discontinued operations, net of tax |  |  | — | % |  |  | (0.6 | )% |
| Net earnings |  |  | 7.6 | % |  |  | 10.5 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 7.5 | % |  |  | 10.4 | % |

[0001193125-16-671842:8k_2_02:77]
| * | Percentages may not add up due to rounding |

[0001193125-16-671842:8k_2_02:78]
GAAP-2

[0001193125-16-671842:8k_2_02:79]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:80]
Condensed Consolidated Statements of Operations

[0001193125-16-671842:8k_2_02:81]
(In millions, except per share amounts)

[0001193125-16-671842:8k_2_02:82]
|  |  | Six Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Net sales from products |  | $ | 1,503 |  |  | $ | 1,626 |  |
| Net sales from services |  |  | 1,120 |  |  |  | 965 |  |
| Net sales |  |  | 2,623 |  |  |  | 2,591 |  |
| Costs of products sales |  |  | 726 |  |  |  | 745 |  |
| Costs of services sales |  |  | 718 |  |  |  | 650 |  |
| Costs of sales |  |  | 1,444 |  |  |  | 1,395 |  |
| Gross margin |  |  | 1,179 |  |  |  | 1,196 |  |
| Selling, general and administrative expenses |  |  | 475 |  |  |  | 510 |  |
| Research and development expenditures |  |  | 274 |  |  |  | 315 |  |
| Other charges (income) |  |  | 55 |  |  |  | (6 | ) |
| Intangibles amortization |  |  | 52 |  |  |  | 4 |  |
| Operating earnings |  |  | 323 |  |  |  | 373 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (103 | ) |  |  | (79 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | (20 | ) |  |  | 50 |  |
| Other |  |  | (11 | ) |  |  | (1 | ) |
| Total other expense |  |  | (134 | ) |  |  | (30 | ) |
| Earnings from continuing operations before income taxes |  |  | 189 |  |  |  | 343 |  |
| Income tax expense |  |  | 64 |  |  |  | 104 |  |
| Earnings from continuing operations |  |  | 125 |  |  |  | 239 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (21 | ) |
| Net earnings |  |  | 125 |  |  |  | 218 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 124 |  |  | $ | 217 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 124 |  |  | $ | 238 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (21 | ) |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 124 |  |  | $ | 217 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.72 |  |  | $ | 1.12 |  |
| Discontinued operations |  |  | — |  |  |  | (0.09 | ) |
|  |  | $ | 0.72 |  |  | $ | 1.03 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.71 |  |  | $ | 1.11 |  |
| Discontinued operations |  |  | — |  |  |  | (0.10 | ) |
|  |  | $ | 0.71 |  |  | $ | 1.01 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 173.0 |  |  |  | 211.7 |  |
| Diluted |  |  | 175.7 |  |  |  | 213.8 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 57.3 | % |  |  | 62.8 | % |
| Net sales from services |  |  | 42.7 | % |  |  | 37.2 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 48.3 | % |  |  | 45.8 | % |
| Costs of services sales |  |  | 64.1 | % |  |  | 67.4 | % |
| Costs of sales |  |  | 55.1 | % |  |  | 53.8 | % |
| Gross margin |  |  | 44.9 | % |  |  | 46.2 | % |
| Selling, general and administrative expenses |  |  | 18.1 | % |  |  | 19.7 | % |
| Research and development expenditures |  |  | 10.4 | % |  |  | 12.2 | % |
| Other charges (income) |  |  | 2.1 | % |  |  | (0.2 | )% |
| Intangibles amortization |  |  | 2.0 | % |  |  | 0.2 | % |
| Operating earnings |  |  | 12.3 | % |  |  | 14.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.9 | )% |  |  | (3.0 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | (0.8 | )% |  |  | 1.9 | % |
| Other |  |  | (0.4 | )% |  |  | — | % |
| Total other expense |  |  | (5.1 | )% |  |  | (1.2 | )% |
| Earnings from continuing operations before income taxes |  |  | 7.2 | % |  |  | 13.2 | % |
| Income tax expense |  |  | 2.4 | % |  |  | 4.0 | % |
| Earnings from continuing operations |  |  | 4.8 | % |  |  | 9.2 | % |
| Loss from discontinued operations, net of tax |  |  | — | % |  |  | (0.8 | )% |
| Net earnings |  |  | 4.8 | % |  |  | 8.4 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | — | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 4.7 | % |  |  | 8.4 | % |

[0001193125-16-671842:8k_2_02:83]
| * | Percentages may not add up due to rounding |

[0001193125-16-671842:8k_2_02:84]
GAAP-3

[0001193125-16-671842:8k_2_02:85]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:86]
Condensed Consolidated Balance Sheets

[0001193125-16-671842:8k_2_02:87]
(In millions)

[0001193125-16-671842:8k_2_02:88]
|  |  | July 2, 2016 |  |  | December 31, 2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,545 |  |  | $ | 1,980 |  |
| Accounts receivable, net |  |  | 1,083 |  |  |  | 1,362 |  |
| Inventories, net |  |  | 284 |  |  |  | 296 |  |
| Other current assets |  |  | 635 |  |  |  | 954 |  |
| Current assets held for disposition |  |  | — |  |  |  | 27 |  |
| Total current assets |  |  | 3,547 |  |  |  | 4,619 |  |
| Property, plant and equipment, net |  |  | 778 |  |  |  | 487 |  |
| Investments |  |  | 223 |  |  |  | 231 |  |
| Deferred income taxes |  |  | 2,261 |  |  |  | 2,278 |  |
| Goodwill |  |  | 597 |  |  |  | 420 |  |
| Other assets |  |  | 1,061 |  |  |  | 271 |  |
| Non-current assets held for disposition |  |  | — |  |  |  | 40 |  |
| Total assets |  | $ | 8,467 |  |  | $ | 8,346 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 5 |  |  | $ | 4 |  |
| Accounts payable |  |  | 409 |  |  |  | 518 |  |
| Accrued liabilities |  |  | 1,631 |  |  |  | 1,671 |  |
| Total current liabilities |  |  | 2,045 |  |  |  | 2,193 |  |
| Long-term debt |  |  | 5,028 |  |  |  | 4,345 |  |
| Other liabilities |  |  | 2,072 |  |  |  | 1,904 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (689 | ) |  |  | (106 | ) |
| Noncontrolling interests |  |  | 11 |  |  |  | 10 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,467 |  |  | $ | 8,346 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (3,488 | ) |  | $ | (2,369 | ) |

[0001193125-16-671842:8k_2_02:89]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-16-671842:8k_2_02:90]
GAAP-4

[0001193125-16-671842:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:92]
Condensed Consolidated Statements of Cash Flows

[0001193125-16-671842:8k_2_02:93]
(In millions)

[0001193125-16-671842:8k_2_02:94]
|  |  | Three Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 107 |  |  | $ | 142 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings |  |  | 108 |  |  |  | 143 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (8 | ) |
| Earnings from continuing operations, net of tax |  |  | 108 |  |  |  | 151 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 82 |  |  |  | 40 |  |
| Non-cash other charges |  |  | 24 |  |  |  | 4 |  |
| Non-U.S. pension curtailment gain |  |  | — |  |  |  | (32 | ) |
| Share-based compensation expense |  |  | 18 |  |  |  | 19 |  |
| Gains on sales of investments and businesses, net |  |  | (1 | ) |  |  | (4 | ) |
| Deferred income taxes |  |  | 35 |  |  |  | 32 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 50 |  |  |  | (54 | ) |
| Inventories |  |  | 2 |  |  |  | 19 |  |
| Other current assets |  |  | (22 | ) |  |  | 3 |  |
| Accounts payable and accrued liabilities |  |  | 1 |  |  |  | (2 | ) |
| Other assets and liabilities |  |  | (5 | ) |  |  | (27 | ) |
| Net cash provided by operating activities |  |  | 292 |  |  |  | 149 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (67 | ) |  |  | (19 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 72 |  |  |  | 23 |  |
| Capital expenditures |  |  | (91 | ) |  |  | (48 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 46 |  |  |  | — |  |
| Net cash used for investing activities |  |  | (40 | ) |  |  | (44 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (1 | ) |
| Issuance of common stock |  |  | (1 | ) |  |  | (5 | ) |
| Purchase of common stock |  |  | (555 | ) |  |  | (285 | ) |
| Payment of dividends |  |  | (72 | ) |  |  | (72 | ) |
| Net cash used for financing activities |  |  | (629 | ) |  |  | (363 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (18 | ) |  |  | 17 |  |
| Net decrease in cash and cash equivalents |  |  | (395 | ) |  |  | (241 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,940 |  |  |  | 3,353 |  |
| Cash and cash equivalents, end of period |  | $ | 1,545 |  |  | $ | 3,112 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 201 |  |  | $ | 101 |  |

[0001193125-16-671842:8k_2_02:95]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-671842:8k_2_02:96]
GAAP-5

[0001193125-16-671842:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:98]
Condensed Consolidated Statements of Cash Flows

[0001193125-16-671842:8k_2_02:99]
(In millions)

[0001193125-16-671842:8k_2_02:100]
|  |  | Six Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 124 |  |  | $ | 217 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings |  |  | 125 |  |  |  | 218 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (21 | ) |
| Earnings from continuing operations, net of tax |  |  | 125 |  |  |  | 239 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 144 |  |  |  | 81 |  |
| Non-cash other charges |  |  | 35 |  |  |  | 5 |  |
| Non-U.S. pension curtailment gain |  |  | — |  |  |  | (32 | ) |
| Share-based compensation expense |  |  | 35 |  |  |  | 40 |  |
| Losses (gains) on sales of investments and businesses, net |  |  | 20 |  |  |  | (50 | ) |
| Deferred income taxes |  |  | 71 |  |  |  | 55 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 327 |  |  |  | 255 |  |
| Inventories |  |  | (2 | ) |  |  | (25 | ) |
| Other current assets |  |  | (65 | ) |  |  | 28 |  |
| Accounts payable and accrued liabilities |  |  | (362 | ) |  |  | (248 | ) |
| Other assets and liabilities |  |  | (24 | ) |  |  | (42 | ) |
| Net cash provided by operating activities |  |  | 304 |  |  |  | 306 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (1,120 | ) |  |  | (93 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 553 |  |  |  | 111 |  |
| Capital expenditures |  |  | (143 | ) |  |  | (81 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 46 |  |  |  | 1 |  |
| Net cash used for investing activities |  |  | (664 | ) |  |  | (62 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (2 | ) |  |  | (2 | ) |
| Net proceeds from issuance of debt |  |  | 673 |  |  |  | — |  |
| Issuance of common stock |  |  | 40 |  |  |  | 37 |  |
| Purchase of common stock |  |  | (619 | ) |  |  | (939 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 1 |  |
| Payment of dividends |  |  | (143 | ) |  |  | (148 | ) |
| Net cash used for financing activities |  |  | (51 | ) |  |  | (1,051 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (24 | ) |  |  | (35 | ) |
| Net decrease in cash and cash equivalents |  |  | (435 | ) |  |  | (842 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,980 |  |  |  | 3,954 |  |
| Cash and cash equivalents, end of period |  | $ | 1,545 |  |  | $ | 3,112 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 161 |  |  | $ | 225 |  |

[0001193125-16-671842:8k_2_02:101]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-671842:8k_2_02:102]
GAAP-6

[0001193125-16-671842:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:104]
Segment Information

[0001193125-16-671842:8k_2_02:105]
(In
millions)

[0001193125-16-671842:8k_2_02:106]
Net Sales

[0001193125-16-671842:8k_2_02:107]
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 801 |  |  | $ | 867 |  |  |  | (8 | )% |
| Services |  |  | 629 |  |  |  | 501 |  |  |  | 26 | % |
| Total Motorola Solutions |  | $ | 1,430 |  |  | $ | 1,368 |  |  |  | 5 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 1,503 |  |  | $ | 1,626 |  |  |  | (8 | )% |
| Services |  |  | 1,120 |  |  |  | 965 |  |  |  | 16 | % |
| Total Motorola Solutions |  | $ | 2,623 |  |  | $ | 2,591 |  |  |  | 1 | % |

[0001193125-16-671842:8k_2_02:108]
Operating Earnings

[0001193125-16-671842:8k_2_02:109]
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 129 |  |  | $ | 171 |  |  |  | (25 | )% |
| Services |  |  | 95 |  |  |  | 83 |  |  |  | 14 | % |
| Total Motorola Solutions |  | $ | 224 |  |  | $ | 254 |  |  |  | (12 | )% |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 179 |  |  | $ | 235 |  |  |  | (24 | )% |
| Services |  |  | 144 |  |  |  | 138 |  |  |  | 4 | % |
| Total Motorola Solutions |  | $ | 323 |  |  | $ | 373 |  |  |  | (13 | )% |

[0001193125-16-671842:8k_2_02:110]
Operating Earnings %

[0001193125-16-671842:8k_2_02:111]
|  |  | Three Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Products |  |  | 16.1 | % |  |  | 19.7 | % |
| Services |  |  | 15.1 | % |  |  | 16.6 | % |
| Total Motorola Solutions |  |  | 15.7 | % |  |  | 18.6 | % |
|  |  | Six Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Products |  |  | 11.9 | % |  |  | 14.5 | % |
| Services |  |  | 12.9 | % |  |  | 14.3 | % |
| Total Motorola Solutions |  |  | 12.3 | % |  |  | 14.4 | % |

[0001193125-16-671842:8k_2_02:112]
Non-GAAP-1

[0001193125-16-671842:8k_2_02:113]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:114]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-16-671842:8k_2_02:115]
Q1 2016

[0001193125-16-671842:8k_2_02:116]
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 23 |  |  |  | 8 |  |  |  | 15 |  |  |  | 0.08 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 13 |  |  |  | 3 |  |  |  | 10 |  |  |  | 0.06 |  |
| Acquisition related transaction fees |  | Other charges |  |  | 13 |  |  |  | — |  |  |  | 13 |  |  |  | 0.07 |  |
| Loss on investment in United Kingdom treasuries |  | Other expense (income) |  |  | 19 |  |  |  | 7 |  |  |  | 12 |  |  |  | 0.07 |  |
| Realized foreign currency loss on acquisition |  | Other expense (income) |  |  | 10 |  |  |  | 3 |  |  |  | 7 |  |  |  | 0.04 |  |
| Loss on sale of Malaysia facility and operations |  | Other expense (income) |  |  | 7 |  |  |  | — |  |  |  | 7 |  |  |  | 0.04 |  |
| Total impact on Net earnings |  |  |  | $ | 102 |  |  | $ | 27 |  |  | $ | 75 |  |  | $ | 0.42 |  |

[0001193125-16-671842:8k_2_02:117]
Q2 2016

[0001193125-16-671842:8k_2_02:118]
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 18 |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 27 |  |  |  | 7 |  |  |  | 20 |  |  |  | 0.12 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 38 |  |  |  | 8 |  |  |  | 30 |  |  |  | 0.17 |  |
| Building impairment |  | Other charges |  |  | 17 |  |  |  | 6 |  |  |  | 11 |  |  |  | 0.06 |  |
| Total impact on Net earnings |  |  |  | $ | 100 |  |  | $ | 27 |  |  | $ | 73 |  |  | $ | 0.42 |  |

[0001193125-16-671842:8k_2_02:119]
Non-GAAP-2

[0001193125-16-671842:8k_2_02:120]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:121]
Non-GAAP Segment Information

[0001193125-16-671842:8k_2_02:122]
(In millions)

[0001193125-16-671842:8k_2_02:123]
Net Sales

[0001193125-16-671842:8k_2_02:124]
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 801 |  |  | $ | 867 |  |  |  | (8 | )% |
| Services |  |  | 629 |  |  |  | 501 |  |  |  | 26 | % |
| Total Motorola Solutions |  | $ | 1,430 |  |  | $ | 1,368 |  |  |  | 5 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 1,503 |  |  | $ | 1,626 |  |  |  | (8 | )% |
| Services |  |  | 1,120 |  |  |  | 965 |  |  |  | 16 | % |
| Total Motorola Solutions |  | $ | 2,623 |  |  | $ | 2,591 |  |  |  | 1 | % |

[0001193125-16-671842:8k_2_02:125]
Non-GAAP Operating Earnings

[0001193125-16-671842:8k_2_02:126]
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 176 |  |  | $ | 176 |  |  |  | — | % |
| Services |  |  | 148 |  |  |  | 84 |  |  |  | 76 | % |
| Total Motorola Solutions |  | $ | 324 |  |  | $ | 260 |  |  |  | 25 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |  | % Change |  |
| Products |  | $ | 260 |  |  | $ | 266 |  |  |  | (2 | )% |
| Services |  |  | 230 |  |  |  | 150 |  |  |  | 53 | % |
| Total Motorola Solutions |  | $ | 490 |  |  | $ | 416 |  |  |  | 18 | % |

[0001193125-16-671842:8k_2_02:127]
Non-GAAP Operating Earnings %

[0001193125-16-671842:8k_2_02:128]
|  |  | Three Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Products |  |  | 22.0 | % |  |  | 20.3 | % |
| Services |  |  | 23.5 | % |  |  | 16.8 | % |
| Total Motorola Solutions |  |  | 22.7 | % |  |  | 19.0 | % |
|  |  | Six Months Ended |  |
|  |  | July 2, 2016 |  |  | July 4, 2015 |  |
| Products |  |  | 17.3 | % |  |  | 16.4 | % |
| Services |  |  | 20.5 | % |  |  | 15.5 | % |
| Total Motorola Solutions |  |  | 18.7 | % |  |  | 16.1 | % |

[0001193125-16-671842:8k_2_02:129]
Non-GAAP-3

[0001193125-16-671842:8k_2_02:130]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-671842:8k_2_02:131]
Operating Earnings after Non-GAAP Adjustments

[0001193125-16-671842:8k_2_02:132]
Q1 2016

[0001193125-16-671842:8k_2_02:133]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,193 |  |  | $ | 702 |  |  | $ | 491 |  |
| Operating earnings (“OE”) |  | $ | 100 |  |  | $ | 51 |  |  | $ | 49 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 23 |  |  |  | 21 |  |  |  | 2 |  |
| Intangibles amortization expense |  |  | 13 |  |  |  | 1 |  |  |  | 12 |  |
| Acquisition related transaction fees |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Total above-OE non-GAAP adjustments |  |  | 66 |  |  |  | 33 |  |  |  | 33 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 166 |  |  | $ | 84 |  |  | $ | 82 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 8.4 | % |  |  | 7.3 | % |  |  | 10.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 13.9 | % |  |  | 12.0 | % |  |  | 16.7 | % |

[0001193125-16-671842:8k_2_02:134]
Q2 2016

[0001193125-16-671842:8k_2_02:135]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,430 |  |  | $ | 801 |  |  | $ | 629 |  |
| Operating earnings (“OE”) |  | $ | 224 |  |  | $ | 129 |  |  | $ | 95 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 18 |  |  |  | 12 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 27 |  |  |  | 21 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 38 |  |  |  | 2 |  |  |  | 36 |  |
| Building impairment |  |  | 17 |  |  |  | 12 |  |  |  | 5 |  |
| Total above-OE non-GAAP adjustments |  |  | 100 |  |  |  | 47 |  |  |  | 53 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 324 |  |  | $ | 176 |  |  | $ | 148 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 15.7 | % |  |  | 16.1 | % |  |  | 15.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 22.7 | % |  |  | 22.0 | % |  |  | 23.5 | % |
