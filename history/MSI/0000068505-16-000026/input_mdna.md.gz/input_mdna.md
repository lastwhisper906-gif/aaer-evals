# MSI MD&A — 0000068505-16-000026


## mdna

[0000068505-16-000026:mdna:1]
[same as prior period, unchanged from 0000068505-16-000020:mdna:1]

[0000068505-16-000026:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended July 2, 2016 and July 4, 2015, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0000068505-16-000026:mdna:3]
[same as prior period, unchanged from 0000068505-16-000020:mdna:3]

[0000068505-16-000026:mdna:4]
[same as prior period, unchanged from 0000068505-16-000020:mdna:4]

[0000068505-16-000026:mdna:5]
On February 19, 2016, we completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which we invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. We will make a deferred cash payment of £64 million on November 15, 2018. We funded the investment with a $675 million term loan (the “Term Loan”) and approximately $400 million of international cash on hand. The acquisition of GDCL enables us to geographically diversify our global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers.

[0000068505-16-000026:mdna:6]
[same as prior period, unchanged from 0000068505-16-000020:mdna:6]

[0000068505-16-000026:mdna:7]
[same as prior period, unchanged from 0000068505-16-000020:mdna:7]

[0000068505-16-000026:mdna:8]
[same as prior period, unchanged from 0000068505-16-000020:mdna:8]

[0000068505-16-000026:mdna:9]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the second quarter of 2016, the segment’s net sales were $801 million, representing 56% of our consolidated net sales.

[0000068505-16-000026:mdna:10]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the second quarter of 2016, the segment’s net sales were $629 million, representing 44% of our consolidated net sales.

[0000068505-16-000026:mdna:11]
[same as prior period, unchanged from 0000068505-16-000020:mdna:11]

[0000068505-16-000026:mdna:12]
[same as prior period, unchanged from 0000068505-16-000020:mdna:12]

[0000068505-16-000026:mdna:13]
[same as prior period, unchanged from 0000068505-16-000020:mdna:13]

[0000068505-16-000026:mdna:14]
On June 23, 2016, the United Kingdom via referendum (known as “Brexit”) voted to leave the European Union. While there is still uncertainty as to the impact of Brexit, including the terms of the United Kingdom's separation from the European Union, the British Pound Sterling has weakened and the U.S. dollar has strengthened. Our backlog has been reduced by $170 million since April 2, 2016 as a result of the weakening in the British Pound Sterling. We do not believe the weakening of the British

[0000068505-16-000026:mdna:15]
Pound Sterling will have a material impact to our operations as it is mitigated by the cost of sales for delivery of our services, which are also denominated in the British Pound Sterling.

[0000068505-16-000026:mdna:16]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce SG&A and R&D expenses during 2016 by approximately $120 million in comparison to 2015. In the first half of 2016, we incurred $73 million of SG&A and R&D cost savings.

[0000068505-16-000026:mdna:17]
Growth of Our Services Portfolio: Our Services segment is expected to grow at a higher rate than our Products segment. Overall, the Services segment has a lower gross margin percentage than the Products segment, but we expect consolidated operating margins to continue to expand. In the second quarter of 2016 and first half of 2016, we grew our Services segment 26% and 16%, respectively, including the acquisition of GDCL, compared to the second quarter of 2015 and first half of 2015.

[0000068505-16-000026:mdna:18]
[same as prior period, unchanged from 0000068505-16-000020:mdna:17]

[0000068505-16-000026:mdna:19]
Second Quarter Summary

[0000068505-16-000026:mdna:20]
| • | Net sales were $1.4 billion in the second quarter of 2016 and 2015, a $62 million, or 5% increase from the second quarter of 2015. |

[0000068505-16-000026:mdna:21]
| • | We generated operating earnings of $224 million, or 16% of net sales, in the second quarter of 2016, compared to $254 million, or 19% of net sales, in the second quarter of 2015. Profitability declined primarily as a result of: (i) increased intangible amortization expense as a result of the GDCL acquisition, (ii) a building impairment, and (iii) a gain recorded in the second quarter of 2015 related to a non-U.S. pension curtailment. |

[0000068505-16-000026:mdna:22]
| • | We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $107 million, or $0.61 per diluted common share, in the second quarter of 2016, compared to $150 million, or $0.72 per diluted common share, in the second quarter of 2015. |

[0000068505-16-000026:mdna:23]
| • | We generated net cash from operating activities of $304 million during the first half of 2016, compared to $306 million in the first half of 2015. |

[0000068505-16-000026:mdna:24]
| • | We returned $762 million in capital to shareholders through dividends and share repurchases during the first half of 2016. |

[0000068505-16-000026:mdna:25]
[same as prior period, unchanged from 0000068505-16-000020:mdna:28]

[0000068505-16-000026:mdna:26]
| • | Products: Net sales were $801 million in the second quarter of 2016, a decrease of $66 million, or 8% compared to net sales of $867 million during the second quarter of 2015. On a geographic basis, net sales decreased in all regions compared to the year-ago quarter. |

[0000068505-16-000026:mdna:27]
| • | Services: Net sales were $629 million in the second quarter of 2016, an increase of $128 million, or 26% compared to net sales of $501 million in the second quarter of 2015. On a geographic basis, net sales increased in EMEA, North America, and AP and decreased in Latin America, compared to the year-ago quarter. |

[0000068505-16-000026:mdna:28]
26

[0000068505-16-000026:mdna:29]
[same as prior period, unchanged from 0000068505-16-000020:mdna:31]

[0000068505-16-000026:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | July 2, 2016 |  | % ofSales** |  | July 4, 2015 |  | % ofSales** |  | July 2, 2016 |  | % ofSales** |  | July 4, 2015 |  | % ofSales** |
| Net sales from products | $ | 801 |  |  |  |  | $ | 867 |  |  |  |  | $ | 1,503 |  |  |  |  | $ | 1,626 |  |  |  |
| Net sales from services | 629 |  |  |  |  | 501 |  |  |  |  | 1,120 |  |  |  |  | 965 |  |  |  |
| Net sales | 1,430 |  |  |  |  | 1,368 |  |  |  |  | 2,623 |  |  |  |  | 2,591 |  |  |  |
| Costs of product sales | 361 |  |  | 45.1 | % |  | 385 |  |  | 44.4 | % |  | 726 |  |  | 48.3 | % |  | 745 |  |  | 45.8 | % |
| Costs of services sales | 393 |  |  | 62.5 | % |  | 335 |  |  | 66.9 | % |  | 718 |  |  | 64.1 | % |  | 650 |  |  | 67.4 | % |
| Costs of sales | 754 |  |  |  |  | 720 |  |  |  |  | 1,444 |  |  |  |  | 1,395 |  |  |  |
| Gross margin | 676 |  |  | 47.3 | % |  | 648 |  |  | 47.4 | % |  | 1,179 |  |  | 44.9 | % |  | 1,196 |  |  | 46.2 | % |
| Selling, general and administrative expenses | 240 |  |  | 16.8 | % |  | 254 |  |  | 18.6 | % |  | 475 |  |  | 18.1 | % |  | 510 |  |  | 19.7 | % |
| Research and development expenditures | 138 |  |  | 9.7 | % |  | 156 |  |  | 11.4 | % |  | 274 |  |  | 10.4 | % |  | 315 |  |  | 12.2 | % |
| Other charges (income) | 74 |  |  | 5.2 | % |  | (16 | ) |  | (1.2 | )% |  | 107 |  |  | 4.1 | % |  | (2 | ) |  | (0.1 | )% |
| Operating earnings | 224 |  |  | 15.7 | % |  | 254 |  |  | 18.6 | % |  | 323 |  |  | 12.3 | % |  | 373 |  |  | 14.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (54 | ) |  | (3.8 | )% |  | (39 | ) |  | (2.9 | )% |  | (103 | ) |  | (3.9 | )% |  | (79 | ) |  | (3.0 | )% |
| Gain (loss) on sales of investments and businesses, net | 1 |  |  | 0.1 | % |  | 4 |  |  | 0.3 | % |  | (20 | ) |  | (0.8 | )% |  | 50 |  |  | 1.9 | % |
| Other | (4 | ) |  | (0.3 | )% |  | (4 | ) |  | (0.3 | )% |  | (11 | ) |  | (0.4 | )% |  | (1 | ) |  | — | % |
| Total other expense | (57 | ) |  | (4.0 | )% |  | (39 | ) |  | (2.9 | )% |  | (134 | ) |  | (5.1 | )% |  | (30 | ) |  | (1.2 | )% |
| Earnings from continuing operations before income taxes | 167 |  |  | 11.7 | % |  | 215 |  |  | 15.7 | % |  | 189 |  |  | 7.2 | % |  | 343 |  |  | 13.2 | % |
| Income tax expense | 59 |  |  | 4.1 | % |  | 64 |  |  | 4.7 | % |  | 64 |  |  | 2.4 | % |  | 104 |  |  | 4.0 | % |
| Earnings from continuing operations | 108 |  |  | 7.6 | % |  | 151 |  |  | 11.0 | % |  | 125 |  |  | 4.8 | % |  | 239 |  |  | 9.2 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 1 |  |  | — | % |  | 1 |  |  | — | % |
| Earnings from continuing operations* | 107 |  |  | 7.5 | % |  | 150 |  |  | 11.0 | % |  | 124 |  |  | 4.7 | % |  | 238 |  |  | 9.2 | % |
| Loss from discontinued operations, net of tax | — |  |  | — | % |  | (8 | ) |  | (0.6 | )% |  | — |  |  | — | % |  | (21 | ) |  | (0.8 | )% |
| Net earnings* | $ | 107 |  |  | 7.5 | % |  | $ | 142 |  |  | 10.4 | % |  | $ | 124 |  |  | 4.7 | % |  | $ | 217 |  |  | 8.4 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.61 |  |  |  |  | $ | 0.72 |  |  |  |  | $ | 0.71 |  |  |  |  | $ | 1.11 |  |  |  |
| Discontinued operations | — |  |  |  |  | (0.04 | ) |  |  |  | — |  |  |  |  | (0.10 | ) |  |  |
| Earnings per diluted common share* | $ | 0.61 |  |  |  |  |  | $ | 0.68 |  |  |  |  |  | $ | 0.71 |  |  |  |  | $ | 1.01 |  |  |  |

[0000068505-16-000026:mdna:31]
[same as prior period, unchanged from 0000068505-16-000020:mdna:33]

[0000068505-16-000026:mdna:32]
[same as prior period, unchanged from 0000068505-16-000020:mdna:34]

[0000068505-16-000026:mdna:33]
Results of Operations—Three months ended July 2, 2016 compared to three months ended July 4, 2015

[0000068505-16-000026:mdna:34]
The results of operations for the second quarter of 2016 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-16-000026:mdna:35]
[same as prior period, unchanged from 0000068505-16-000020:mdna:37]

[0000068505-16-000026:mdna:36]
Net sales were $1.4 billion in the second quarter of 2016, a $62 million, or 5%, increase compared to the second quarter of 2015. The increase in net sales is reflective of growth in EMEA, partially offset by decreases in Latin America, North America, and AP. The increase in EMEA was due to growth in Services sales, primarily due to the acquisition of GDCL, partially offset by lower Products sales. The decrease in Latin America was primarily the result of lower Products and Services sales due to macroeconomic pressures. The decrease in North America and AP was due to lower Products sales, partially offset by growth in the Services segment.

[0000068505-16-000026:mdna:37]
[same as prior period, unchanged from 0000068505-16-000020:mdna:39]

[0000068505-16-000026:mdna:38]
Gross margin was $676 million, or 47.3% of net sales, in the second quarter of 2016, compared to $648 million, or 47.4% of net sales, in the second quarter of 2015. The decrease in gross margin percentage was driven by the Products segment while the gross margin percentage of the Services segment increased. The decrease in gross margin percentage in the Products segment was primarily driven by: (i) a decrease in volume and (ii) lower margins on systems sales, primarily within North America. The Services segment gross margin percentage improved with the expansion of our Managed & Support services portfolio, primarily due to the acquisition of GDCL.

[0000068505-16-000026:mdna:39]
[same as prior period, unchanged from 0000068505-16-000020:mdna:41]

[0000068505-16-000026:mdna:40]
Selling, general and administrative (“SG&A”) expenses decreased 6% to $240 million, or 16.8% of net sales, in the second quarter of 2016, compared to $254 million, or 18.6% of net sales, in the second quarter of 2015. The decrease in SG&A expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-16-000026:mdna:41]
Research and Development Expenditures

[0000068505-16-000026:mdna:42]
Research and development (“R&D”) expenditures decreased 12% to $138 million, or 9.7% of net sales, in the second quarter of 2016, from $156 million, or 11.4% of net sales, in the second quarter of 2015. The decrease in R&D expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-16-000026:mdna:43]
[same as prior period, unchanged from 0000068505-16-000020:mdna:45]

[0000068505-16-000026:mdna:44]
We recorded net charges of $74 million in Other charges in the second quarter of 2016, compared to net income of $16 million in the second quarter of 2015. The net Other charges in the second quarter of 2016 included: (i) $38 million of charges relating to the amortization of intangibles, and (ii) $36 million of net reorganization of business charges, including a $17 million building impairment. The net income in the second quarter of 2015 of $16 million included a $32 million non-U.S. pension curtailment gain, partially offset by: (i) $13 million of net reorganization of business charges and (ii) $3 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-16-000026:mdna:45]
[same as prior period, unchanged from 0000068505-16-000020:mdna:47]

[0000068505-16-000026:mdna:46]
Net interest expense was $54 million in the second quarter of 2016 and $39 million in the second quarter of 2015. The increase in net interest expense in the second quarter of 2016 as compared to the second quarter of 2015 was a result of higher outstanding debt balances and lower cash balances.

[0000068505-16-000026:mdna:47]
[same as prior period, unchanged from 0000068505-16-000020:mdna:49]

[0000068505-16-000026:mdna:48]
Net gains on sales of investments and businesses were $1 million in the second quarter of 2016 compared to $4 million in the second quarter of 2015. The net gains in the second quarter of 2016 and the second quarter of 2015 were related to the sales of equity investments.

[0000068505-16-000026:mdna:49]
[same as prior period, unchanged from 0000068505-16-000020:mdna:51]

[0000068505-16-000026:mdna:50]
Net Other expense was $4 million in both the second quarter of 2016 and 2015. The net Other expense in the second quarter of 2016 was comprised of an $18 million loss on derivative investments offset by a $14 million foreign currency gain. The net Other expense in the second quarter of 2015 was comprised of: (i) an $11 million foreign currency loss and (ii) a $3 million investment impairment, partially offset by: (i) a $4 million gain on derivative instruments, (ii) a $4 million gain on equity method investments, and (iii) $2 million of other non-operating gains.

[0000068505-16-000026:mdna:51]
[same as prior period, unchanged from 0000068505-16-000020:mdna:53]

[0000068505-16-000026:mdna:52]
We recorded $59 million of net tax expense in the second quarter of 2016, resulting in an effective tax rate of 35%, compared to $64 million of net tax expense in the second quarter of 2015, resulting in an effective tax rate of 30%. Our effective tax rate in the second quarter of 2016 was equal to the U.S. statutory tax rate of 35% and was impacted by discrete adjustments to deferred tax assets of foreign subsidiaries, offset by excess tax benefits on share-based compensation. Our effective tax rate in the second quarter of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the U.S. domestic production tax deduction and rate differential for foreign affiliates.

[0000068505-16-000026:mdna:53]
[same as prior period, unchanged from 0000068505-16-000020:mdna:55]

[0000068505-16-000026:mdna:54]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $107 million, or $0.61 per diluted share, in the second quarter of 2016, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $150 million, or $0.72 per diluted share, in the second quarter of 2015.

[0000068505-16-000026:mdna:55]
The decrease in earnings from continuing operations in the second quarter of 2016, as compared to the second quarter of 2015, was primarily driven by a $90 million increase in Other charges, partially offset by: (i) a $14 million decrease in SG&A spend and (ii) an $18 million decrease in R&D. The decrease in earnings from continuing operations per diluted share was driven by a decrease in earnings from continuing operations offset by lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-16-000026:mdna:56]
Earnings from Discontinued Operations

[0000068505-16-000026:mdna:57]
In the second quarter of 2016, we reported no earnings from discontinued operations, compared to a loss from discontinued operations of $8 million, or $0.04 per diluted share, in the second quarter of 2015.

[0000068505-16-000026:mdna:58]
Results of Operations—Six months ended July 2, 2016 compared to six months ended July 4, 2015

[0000068505-16-000026:mdna:59]
Net Sales

[0000068505-16-000026:mdna:60]
Net sales were $2.6 billion in the first half of 2016, a $32 million, or 1% increase from the first half of 2015. The increase in net sales is reflective of growth in EMEA and North America, partially offset by decreases in Latin America and AP. EMEA and North America grew on Services sales, partially offset by lower Products sales. The increase in EMEA Services sales was due to an increase in Managed and Support services, primarily due to the acquisition of GDCL. The decrease in Latin America was primarily the result of lower Products and Services sales due to macroeconomic pressures. The decrease in AP was due to lower Products sales, partially offset by growth in the Services segment.

[0000068505-16-000026:mdna:61]
Gross Margin

[0000068505-16-000026:mdna:62]
Gross margin was $1.2 billion, or 44.9% of net sales, in the first half of 2016, compared to $1.2 billion, or 46.2% of net sales, in the first half of 2015. The decrease in gross margin percentage was driven by the Products segment while the gross margin percentage of the Services segment increased. The decrease in gross margin percentage in the Products segment was primarily driven by: (i) a decrease in volume, (ii) lower devices sales outside of North America, and (iii) lower margins on systems sales, primarily within North America. The Services segment gross margin percentage improved with the expansion of our Managed & Support services portfolio, primarily due to the acquisition of GDCL.

[0000068505-16-000026:mdna:63]
Selling, General and Administrative Expenses

[0000068505-16-000026:mdna:64]
SG&A expenses decreased $35 million to $475 million, or 18.1% of net sales, in the first half of 2016, compared to $510 million, or 19.7% of net sales, in the first half of 2015. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and (ii) lower pension expenses.

[0000068505-16-000026:mdna:65]
[same as prior period, unchanged from 0000068505-16-000020:mdna:43]

[0000068505-16-000026:mdna:66]
R&D expenditures decreased $41 million to $274 million, or 10.4% of net sales, in the first half of 2016, compared to $315 million, or 12.2% of net sales, in the first half of 2015. The decrease in R&D expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-16-000026:mdna:67]
Other Charges

[0000068505-16-000026:mdna:68]
We recorded net charges of $107 million in Other charges in the first half of 2016, compared to net income of $2 million in the first half of 2015. The net charges in the first half of 2016 included: (i) $52 million of charges relating to the amortization of intangibles, (ii) $42 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment of the corporate aircraft, and (iii) $13 million of transaction fees on the acquisition of GDCL. The net Other income in the first half of 2015 of $2 million included a $32 million gain related to the curtailment of a non-U.S. pension plan, partially offset by: (i) $26 million of net reorganization of business charges and (ii) $4 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-16-000026:mdna:69]
Net Interest Expense

[0000068505-16-000026:mdna:70]
Net interest expense was $103 million in the first half of 2016 and $79 million in the first half of 2015. The increase in net interest expense in the first half of 2016 as compared to the first half of 2015 was a result of higher outstanding debt balances and lower cash balances.

[0000068505-16-000026:mdna:71]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-16-000026:mdna:72]
Net losses on sales of investments and businesses were $20 million in the first half of 2016 compared to net gains on sales of investments and businesses of $50 million in the first half of 2015. The net losses in the first half of 2016 consisted of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities, (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $6 million of gains on the sales of equity investments. The net gain in the first half of 2015 consisted of a gain on the sale of an equity investment.

[0000068505-16-000026:mdna:73]
Other

[0000068505-16-000026:mdna:74]
Net Other expense was $11 million in the first half of 2016, compared to net Other expense of $1 million in the first half of 2015. The net Other expense in the first half of 2016 was comprised of: (i) a $30 million loss on derivative instruments and (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of GDCL, partially offset by: (i) a $27 million foreign currency gain and (ii) a $2 million gain on equity method investments. The net Other expense in the first half of 2015 was comprised of: (i) a $12 million loss on derivative instruments and (ii) a $3 million investment impairment, partially offset by: (i) a $7 million foreign currency gain, (ii) a $4 million gain on equity method investments, and (iii) $3 million of other non-operating gains.

[0000068505-16-000026:mdna:75]
Effective Tax Rate

[0000068505-16-000026:mdna:76]
We recorded $64 million of net tax expense in the first half of 2016, resulting in an effective tax rate of 34%, compared to $104 million of net tax expense, resulting in an effective tax rate of 30% in the first half of 2015. Our effective tax rate in 2016 was lower than the U.S. statutory tax rate of 35% primarily due to the recognition of excess tax benefits on share-based compensation. Our effective tax rate in the first half of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the U.S. domestic production tax deduction and rate differential for foreign affiliates.

[0000068505-16-000026:mdna:77]
Earnings from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-16-000026:mdna:78]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $124 million, or $0.71 per diluted share, in the first half of 2016, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $238 million, or $1.11 per diluted share, in the first half of 2015.

[0000068505-16-000026:mdna:79]
The decrease in earnings from continuing operations in the first half of 2016, as compared to the first half of 2015, was primarily driven by: (i) a $109 million increase in Other charges, (ii) a decrease in Gains on sales of investments and businesses of $70 million, and (iii) an overall decline in Gross margin of $17 million, partially offset by: (i) a $41 million decrease in R&D expenses and (ii) a $35 million decrease in SG&A spend. The decrease in earnings from continuing operations per diluted share was driven by a decrease in earnings from continuing operations offset by lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-16-000026:mdna:80]
[same as prior period, unchanged from 0000068505-16-000020:mdna:58]

[0000068505-16-000026:mdna:81]
In the first half of 2016, we reported no earnings from discontinued operations, compared to a loss from discontinued operations of $21 million, or $0.10 per diluted share, in the first half of 2015.

[0000068505-16-000026:mdna:82]
[same as prior period, unchanged from 0000068505-16-000020:mdna:60]

[0000068505-16-000026:mdna:83]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and six months ended July 2, 2016 and July 4, 2015, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-16-000026:mdna:84]
[same as prior period, unchanged from 0000068505-16-000020:mdna:62]

[0000068505-16-000026:mdna:85]
For the second quarter of 2016, the segment’s net sales represented 56% of our consolidated net sales, compared to 63% of our consolidated net sales for the second quarter of 2015. For the first half of 2016, the segment's net sales represented 57% of our consolidated net sales, compared to 63% of our consolidated net sales for the second quarter of 2015.

[0000068505-16-000026:mdna:86]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 2, 2016 |  | July 4, 2015 |  | % Change |  | July 2, 2016 |  | July 4, 2015 |  | % Change |
| Segment net sales | $ | 801 |  |  | $ | 867 |  |  | (8 | )% |  | $ | 1,503 |  |  | $ | 1,626 |  |  | (8 | )% |
| Operating earnings | 129 |  |  | 171 |  |  | (25 | )% |  | 179 |  |  | 235 |  |  | (24 | )% |

[0000068505-16-000026:mdna:87]
Three months ended July 2, 2016 compared to three months ended July 4, 2015

[0000068505-16-000026:mdna:88]
The segment’s net sales decreased $66 million, to $801 million in the second quarter of 2016, as compared to $867 million during the second quarter of 2015. The decrease in the segment's net sales was primarily driven by: (i) a decrease in global systems sales, (ii) lower volumes, including decreased devices sales outside of North America, and (iii) decreases in both devices and systems sales in Latin America primarily due to macroeconomic conditions. On a geographic basis, net sales decreased in all regions for the second quarter of 2016, compared to the second quarter of 2015.

[0000068505-16-000026:mdna:89]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 70% of the segment’s net sales in the second quarter of 2016, up from 66% of the segment’s net sales in the second quarter of 2015.

[0000068505-16-000026:mdna:90]
The segment had operating earnings of $129 million in the second quarter of 2016, compared to $171 million in the second quarter of 2015. The decrease in operating earnings was primarily driven by: (i) lower volume of systems sales and (ii) an increase in Other charges as a result of a $22 million gain recorded in the second quarter of 2015 related to a non-U.S. pension

[0000068505-16-000026:mdna:91]
30

[0000068505-16-000026:mdna:92]
curtailment and a $12 million building impairment charge recorded in the second quarter of 2016, partially offset by lower SG&A expenditures and R&D expenditures as a result of cost savings initiatives, including headcount reductions.

[0000068505-16-000026:mdna:93]
Six months ended July 2, 2016 compared to six months ended July 4, 2015

[0000068505-16-000026:mdna:94]
The segment’s net sales decreased $123 million, or 8%, to $1.5 billion in the first half of 2016, as compared to $1.6 billion during the first half of 2015. The decrease in the segment's net sales was primarily driven by: (i) lower volumes, including decreased devices sales outside of North America, (ii) a decrease in global systems sales, (iii) decreases in both devices and systems sales in Latin America primarily due to macroeconomic conditions, and (iv) unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales decreased in all regions for the first half of 2016, compared to the first half of 2015.

[0000068505-16-000026:mdna:95]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 70% of the segment’s net sales in the first half of 2016, up from 65% of the segment's net sales in the first half of 2015.

[0000068505-16-000026:mdna:96]
The segment had operating earnings of $179 million in the first half of 2016, compared to $235 million in the first half of 2015. The decrease in operating earnings in the first half of 2016 compared to the first half of 2015, was primarily driven by: (i) lower volume of systems and devices sales and (ii) an increase in Other charges as a result of a $22 million gain recorded in the first half of 2015 related to a  non-U.S. pension curtailment and a $12 million building impairment recorded in the first half of 2016, partially offset by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, and lower pension expenses and (ii) lower R&D expenditures as a result of cost savings initiatives, including headcount reductions.

[0000068505-16-000026:mdna:97]
[same as prior period, unchanged from 0000068505-16-000020:mdna:69]

[0000068505-16-000026:mdna:98]
For the second quarter of 2016, the segment’s net sales represented 44% of our consolidated net sales, compared to 37% of our consolidated net sales for the second quarter of 2015. For the first half of 2016 and 2015, the segment’s net sales represented 43% of our consolidated net sales, compared to 37% of our consolidated net sales for the second quarter of 2015.

[0000068505-16-000026:mdna:99]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 2, 2016 |  | July 4, 2015 |  | % Change |  | July 2, 2016 |  | July 4, 2015 |  | % Change |
| Segment net sales | $ | 629 |  |  | $ | 501 |  |  | 26 | % |  | $ | 1,120 |  |  | $ | 965 |  |  | 16 | % |
| Operating earnings | 95 |  |  | 83 |  |  | 14 | % |  | 144 |  |  | 138 |  |  | 4 | % |

[0000068505-16-000026:mdna:100]
Three months ended July 2, 2016 compared to three months ended July 4, 2015

[0000068505-16-000026:mdna:101]
The segment’s net sales increased $128 million, or 26%, to $629 million in the second quarter of 2016, as compared to $501 million in the second quarter of 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both organic growth as well as the GDCL acquisition. The acquisition of GDCL provided $146 million of net sales within EMEA during the quarter, while the organic Managed & Support services business grew in North America and AP. This sales growth was partially offset by: (i) a decrease in Integration services sales primarily in EMEA related to the winding down of a large system implementation and (ii) declining iDEN services sales in Latin America. On a geographic basis, net sales for the second quarter of 2016 increased in EMEA, North America, and AP and decreased in Latin America, compared to the second quarter of 2015.

[0000068505-16-000026:mdna:102]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 51% of the segment’s net sales in the second quarter of 2016, compared to 62% of the segment’s net sales in the second quarter of 2015.

[0000068505-16-000026:mdna:103]
The segment had operating earnings of $95 million in the second quarter of 2016, compared to $83 million in the second quarter of 2015. The increase in operating earnings in the second quarter of 2016 compared to the second quarter of 2015 was primarily driven by increased sales volume generating higher gross margin on our Managed & Support services in EMEA, primarily due to the GDCL acquisition, partially offset by an increase in Other charges, including: (i) $36 million of intangible amortization expense associated with the GDCL acquisition, (ii) a $10 million gain recorded in the second quarter of 2015 related to a non-U.S. pension curtailment, and (iii) a $5 million building impairment charge.

[0000068505-16-000026:mdna:104]
Six months ended July 2, 2016 compared to six months ended July 4, 2015

[0000068505-16-000026:mdna:105]
The segment’s net sales increased $155 million, or 16%, to $1.1 billion in the first half of 2016, as compared to net sales of $965 million in the first half of 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both organic growth as well as the Airwave acquisition. The acquisition of Airwave provided $207 million of net sales within EMEA during the first half of 2016, while the organic Managed & Support services business grew in North America and AP. This sales growth was partially offset by: (i) a decrease in global Integration services sales, with significant decrease in EMEA related to the winding down of a large system implementation, (ii) declining iDEN services sales in Latin America, and (iii) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales for the first half of 2016 increased in EMEA, North America, and AP and decreased in Latin America, compared to the first half of 2015.

[0000068505-16-000026:mdna:106]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 54% of the segment’s net sales in the first half of 2016, compared to 61% of the segment’s net sales in the first half of 2015.

[0000068505-16-000026:mdna:107]
The segment had operating earnings of $144 million in the first half of 2016, compared to operating earnings of $138 million in the first half of 2015. The increase in operating earnings in the first half of 2016 as compared to the first half of 2015 was driven by increased sales volume generating higher gross margin on our Managed & Support services, primarily in EMEA, partially offset by an increase in Other charges, including: (i) $48 million of intangible amortization expense associated with the GDCL acquisition, (ii) $13 million of acquisition related transaction fees, (iii) a $10 million gain recorded in the first half of 2015 related to a non-U.S. pension curtailment, and (iv) a $5 million building impairment charge.

[0000068505-16-000026:mdna:108]
[same as prior period, unchanged from 0000068505-16-000020:mdna:76]

[0000068505-16-000026:mdna:109]
During the second quarter of 2016, we recorded net reorganization of business charges of $44 million including $36 million of charges recorded within Other charges and $8 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $44 million were charges of: (i) $22 million of charges related to employee separation costs, (ii) a $17 million  charge related to a building impairment, and (iii) $5 million for exit costs.

[0000068505-16-000026:mdna:110]
During the first half of 2016, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first half of 2016, we recorded net reorganization of business charges of $67 million including charges of $42 million recorded in Other charges and $25 million in Cost of sales in our condensed consolidated statements of operations. Included in the $67 million were charges of: (i) $46 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-16-000026:mdna:111]
During the second quarter of 2015, we recorded net reorganization of business charges of $16 million including charges of $13 million recorded in Other charges and $3 million in Cost of sales in our condensed consolidated statements of operations. The $16 million of charges was all related to employee separation costs.

[0000068505-16-000026:mdna:112]
During the first half of 2015, we recorded net reorganization of business charges of $30 million including charges of $26 million recorded in Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $30 million are charges of $26 million for employee separation costs and $4 million of exit costs.

[0000068505-16-000026:mdna:113]
[same as prior period, unchanged from 0000068505-16-000020:mdna:79]

[0000068505-16-000026:mdna:114]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Products | $ | 33 |  |  | $ | 12 |  |  | $ | 54 |  |  | $ | 22 |  |
| Services | 11 |  |  | 4 |  |  | 13 |  |  | 8 |  |
|  | $ | 44 |  |  | $ | 16 |  |  | $ | 67 |  |  | $ | 30 |  |

[0000068505-16-000026:mdna:115]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $42 million in the first half of 2016 and $40 million in the first half of 2015. The reorganization of business accruals at July 2, 2016 were $65 million, of which $54 million relate to employee separation costs that are expected to be paid within one year and $11 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-16-000026:mdna:116]
[same as prior period, unchanged from 0000068505-16-000020:mdna:82]

[0000068505-16-000026:mdna:117]
We decreased the aggregate of our cash and cash equivalent balances by $435 million from $2.0 billion as of December 31, 2015 to $1.5 billion as of July 2, 2016. The decrease is primarily due to $1.0 billion paid in the acquisition of GDCL, as well as $762 million of capital returned to shareholders through share repurchases and dividends paid, offset by $673 million of net proceeds raised by the issuance of the Term Loan (net of $2 million of issuance costs paid), $382 million of proceeds received from the sale of United Kingdom treasury securities used to partially fund the acquisition of GDCL, and $304 million of cash generated by operating activities.

[0000068505-16-000026:mdna:118]
[same as prior period, unchanged from 0000068505-16-000020:mdna:84]

[0000068505-16-000026:mdna:119]
[same as prior period, unchanged from 0000068505-16-000020:mdna:85]

[0000068505-16-000026:mdna:120]
At July 2, 2016, $956 million of the $1.5 billion cash and cash equivalents balance was held in the U.S. and approximately $589 million was held by the Company or its subsidiaries in other countries, with approximately $279 million held in the United Kingdom. Restricted cash was $64 million at July 2, 2016 and $63 million at December 31, 2015.

[0000068505-16-000026:mdna:121]
[same as prior period, unchanged from 0000068505-16-000020:mdna:88]

[0000068505-16-000026:mdna:122]
Net cash provided by operating activities in the first half of 2016 was $304 million, as compared to $306 million in the first half of 2015. Operating cash flows in the first half of 2016, as compared to the first half of 2015, were negatively impacted by higher employee incentive payments, offset by higher earnings from continuing operations (adjusted for net non-cash charges).

[0000068505-16-000026:mdna:123]
[same as prior period, unchanged from 0000068505-16-000020:mdna:90]

[0000068505-16-000026:mdna:124]
Net cash used by investing activities was $664 million in the first half of 2016, compared to $62 million in the first half of 2015. The $664 million cash used in the first half of 2016 included $1.1 billion cash used for acquisitions and investments, including $1.0 billion paid for the acquisition of GDCL, and $143 million in capital expenditures, partially offset by $553 million of proceeds from sales of investments and businesses and $46 million of proceeds from the sale of property, plant and equipment. The cash usage of $62 million in the first half of 2015 consisted primarily of $93 million cash used for acquisitions and investments and $81 million in capital expenditures, partially offset by $111 million of proceeds from the sale of investments and businesses.

[0000068505-16-000026:mdna:125]
Acquisition and Investments:  We used net cash for acquisitions and investments of $1.1 billion during the first half of 2016 compared to $93 million in the first half of 2015. We paid cash of $1.0 billion during the first half of 2016 related to the acquisition of GDCL. The remainder of the cash was used for several debt and equity investments. The cash used during the first half of 2015 consisted of $49 million related to the acquisition of two public safety software solution providers and several debt and equity investments.

[0000068505-16-000026:mdna:126]
Sales of Investments and Businesses:  We had $553 million of proceeds related to the sales of investments and businesses in the first half of 2016 compared to $111 million in the first half of 2015. The proceeds in the first half of 2016 primarily consisted of: (i) $382 million from the sale of United Kingdom treasury securities used to finance the acquisition of GDCL, (ii) $125 million from the sales of various debt and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations. The proceeds in the first half of 2015 were comprised of: (i) $49 million reimbursement from Zebra Technologies for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale, (ii) $47 million from the sale of an equity investment, (iii) $21 million net cash received from Zebra Technologies for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest.

[0000068505-16-000026:mdna:127]
Capital Expenditures:  Capital expenditures increased in the first half of 2016 to $143 million, compared to $81 million in the first half of 2015. The increase in capital expenditures was primarily related to revenue-generating network expenditures, information technology spend, and facility expenditures.

[0000068505-16-000026:mdna:128]
Sales of Property, Plant, and Equipment:  We had $46 million of proceeds related to the sale of property, plant, and equipment in the first half of 2016 compared to $1 million in the first half of 2015. The proceeds in the first half of 2016 were comprised of $27 million from the sale of buildings and land on the Schaumburg, IL headquarters campus and $19 million received from the sale of the corporate aircraft.

[0000068505-16-000026:mdna:129]
33

[0000068505-16-000026:mdna:130]
[same as prior period, unchanged from 0000068505-16-000020:mdna:95]

[0000068505-16-000026:mdna:131]
Net cash used for financing activities was $51 million in the first half of 2016, compared to $1.1 billion in the first half of 2015. Cash used for financing activities in the first half of 2016 was primarily comprised of: (i) $619 million used for purchases of our common stock under our share repurchase program and (ii) $143 million of cash used for the payment of dividends, partially offset by: (i) $673 million of net proceeds from the issuance of the Term Loan and (ii) $40 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first half of 2015 was primarily comprised of: (i) $939 million used for purchases of our common stock under our share repurchase program and (ii) $148 million of cash used for the payment of dividends, partially offset by $37 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-16-000026:mdna:132]
Long-Term Debt:  We had outstanding long-term debt of $5.0 billion and $4.3 billion, including the current portions of $5 million at July 2, 2016 and $4 million at December 31, 2015, respectively.

[0000068505-16-000026:mdna:133]
In connection with the completion of the acquisition of GDCL, we entered into a new term loan credit agreement (the “Term Loan Agreement”), under which we borrowed a Term Loan with an initial principal amount of $675 million. We received net proceeds of $673 million, net of $2 million of issuance costs. Interest on the Term Loan is variable and indexed to LIBOR. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. Our borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited during the third quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan. However, we believe we will continue to have sufficient liquidity to operate our business.

[0000068505-16-000026:mdna:134]
[same as prior period, unchanged from 0000068505-16-000020:mdna:99]

[0000068505-16-000026:mdna:135]
Share Repurchase Program: During the six months ended July 2, 2016, the Company paid an aggregate of $619 million, including transaction costs, to repurchase approximately 9.0 million shares at an average price of $68.68 per share. As of July 2, 2016, the Company had used approximately $11.6 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $415 million of authority available for future repurchases. Subsequent to quarter end, the Board of Directors approved a $2.0 billion increase to the share repurchase program, raising the remaining authority available for future repurchases to $2.4 billion.

[0000068505-16-000026:mdna:136]
Payment of Dividends: During the second quarter of 2016, we paid $72 million in cash dividends to holders of our common stock. During the first half of 2016, we paid $143 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $70 million in cash dividends to holders of our common stock.

[0000068505-16-000026:mdna:137]
[same as prior period, unchanged from 0000068505-16-000020:mdna:102]

[0000068505-16-000026:mdna:138]
As of July 2, 2016, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of July 2, 2016. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first half of 2016.

[0000068505-16-000026:mdna:139]
[same as prior period, unchanged from 0000068505-16-000020:mdna:104]

[0000068505-16-000026:mdna:140]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $131 million at July 2, 2016, compared to $112 million at December 31, 2015.

[0000068505-16-000026:mdna:141]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $42 million at July 2, 2016, compared to $47 million at December 31, 2015.

[0000068505-16-000026:mdna:142]
[same as prior period, unchanged from 0000068505-16-000020:mdna:107]

[0000068505-16-000026:mdna:143]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended July 2, 2016 and July 4, 2015:

[0000068505-16-000026:mdna:144]
|  | Three Months Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Accounts receivable sales proceeds | $ | 5 |  |  | $ | 5 |  |  | $ | 7 |  |  | $ | 11 |  |
| Long-term receivables sales proceeds | 70 |  |  | 43 |  |  | 134 |  |  | 108 |  |
| Total proceeds from sales of accounts receivable | $ | 75 |  |  | $ | 48 |  |  | $ | 141 |  |  | $ | 119 |  |

[0000068505-16-000026:mdna:145]
At July 2, 2016, the Company had retained servicing obligations for $699 million of long-term receivables, compared to $668 million of long-term receivables at December 31, 2015. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-16-000026:mdna:146]
Other Contingencies

[0000068505-16-000026:mdna:147]
[same as prior period, unchanged from 0000068505-16-000020:mdna:112]

[0000068505-16-000026:mdna:148]
[same as prior period, unchanged from 0000068505-16-000020:mdna:113]

[0000068505-16-000026:mdna:149]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at July 2, 2016.

[0000068505-16-000026:mdna:150]
[same as prior period, unchanged from 0000068505-16-000020:mdna:115]

[0000068505-16-000026:mdna:151]
[same as prior period, unchanged from 0000068505-16-000020:mdna:116]

[0000068505-16-000026:mdna:152]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the our annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, “"Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)” which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. In April of 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606) - Identifying Performance Obligations and Licensing,” which reduces the complexity when applying the guidance for identifying performance obligations and improves the operability and understandability of the license implementation guidance. In May 2016, the FASB issued ASU 2016-12 “Revenue from Contracts with Customers (Topic 606) - Narrow-Scope Improvements and Practical Expedients,” which amends the guidance on transition, collectability, non-cash consideration and the presentation of sales and other similar taxes. ASU 2016-12 clarifies that, for a contract to be considered completed at transition, all (or substantially all) of the revenue must have been recognized under legacy GAAP. In addition, ASU 2016-12 clarifies how an entity should evaluate the collectability threshold and when an entity can recognize nonrefundable consideration received as revenue if an arrangement does not meet the standard’s contract criteria. The standard allows for both retrospective and modified retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-16-000026:mdna:153]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us January 1, 2019 and interim periods within that reporting period.  The ASU requires a modified retrospective method upon adoption. We are in the process of assessing the impact of this ASU on our Consolidated Financial Statements.

[0000068505-16-000026:mdna:154]
In March 2016, the FASB issued ASU 2016-07, "Investments - Equity Method and Joint Ventures: Simplifying the Transition to the Equity Method of Accounting," which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. ASU 2016-07 is effective for us January 1, 2017 and interim periods within that reporting period. The adoption of ASU 2016-07 is not expected to have a material effect on our condensed consolidated financial statements.

[0000068505-16-000026:mdna:155]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurements of Credit Losses on Financial Instruments," which requires measurement and recognition of expected credit losses for financial assets

[0000068505-16-000026:mdna:156]
held.  The ASU is effective for the Company January 1, 2020 and interim periods within that reporting period. The adoption of ASU 2016-13 is not expected to have a material effect on our consolidated financial statements.

[0000068505-16-000026:mdna:157]
36
