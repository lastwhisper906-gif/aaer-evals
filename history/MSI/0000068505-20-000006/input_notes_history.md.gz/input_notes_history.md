# MSI note change history — 0000068505-19-000019 → 0000068505-19-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- removed (2019-10-31):
[0000068505-19-000019:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at June 29, 2019.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0000068505-19-000025:note_history:2]
The condensed consolidated financial statements as of September 28, 2019 and for the three and nine months ended September 28, 2019 and September 29, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2019-08-02, similarity 0.9322):
[0000068505-19-000019:note_history:2]
The condensed consolidated financial statements as of June 29, 2019 and for the three and six months ended June 29, 2019 and June 30, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2019-10-31):
[0000068505-19-000025:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three and nine months ended September 28, 2019 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2019-08-02, similarity 0.8106):
[0000068505-19-000019:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three and six months ended June 29, 2019 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2019-10-31):
[0000068505-19-000025:note_history:4]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020 and requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.
  (was, 2019-08-02, similarity 0.9949):
[0000068505-19-000019:note_history:4]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020. The ASU requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0000068505-19-000025:note_history:5]
|  | September 28, 2019 |  | December 31, 2018 |
| Term Loan due 2021 | $ | — |  |  | $ | 399 |  |
| 3.5% senior notes due 2021 | — |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 1.75% senior convertible notes due 2024 | 987 |  |  | — |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 804 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 638 |  |  | 862 |  |
|  | 5,732 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3 | ) |  | (4 | ) |
| Less: current portion | (617 | ) |  | (31 | ) |
| Long-term debt | $ | 5,112 |  |  | $ | 5,289 |  |
  (was, 2019-08-02, similarity 0.7256):
[0000068505-19-000019:note_history:5]
|  | June 29, 2019 |  | December 31, 2018 |
| 2.0% Senior Convertible Notes due 2020 | $ | 800 |  |  | $ | 800 |  |
| Term Loan due 2021 | 399 |  |  | 399 |  |
| 3.5% senior notes due 2021 | 149 |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 690 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 645 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 52 |  |  | 62 |  |
|  | 5,347 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (4 | ) |  | (4 | ) |
| Less: current portion | (28 | ) |  | (31 | ) |
| Long-term debt | $ | 5,315 |  |  | $ | 5,289 |  |

- changed (2019-10-31):
[0000068505-19-000025:note_history:6]
As of September 28, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 28, 2019. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2018 and September 28, 2019.
  (was, 2019-08-02, similarity 0.8964):
[0000068505-19-000019:note_history:6]
As of June 29, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 29, 2019. During the first quarter of 2018, the Company borrowed $400 million to facilitate the Avigilon acquisition which was re-paid by December 31, 2018. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2018 and June 29, 2019.

- changed (2019-10-31):
[0000068505-19-000025:note_history:7]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the three and nine months ended September 28, 2019 were 3.53% and 3.68%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed. During the three months ended September 28, 2019, the Company repaid all amounts borrowed under the Term Loan.
  (was, 2019-08-02, similarity 0.8597):
[0000068505-19-000019:note_history:7]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 29, 2019 were 3.72% and 3.74%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- added (2019-10-31):
[0000068505-19-000025:note_history:8]
In May of 2019, the Company issued $650 million of 4.60% senior notes due 2029, receiving proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $43 million related to this repurchase in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.

- added (2019-10-31):
[0000068505-19-000025:note_history:9]
In August of 2019, the Company issued a follow-on $150 million to the outstanding 4.60% senior notes due 2029, bringing the total outstanding principal to $800 million. The Company recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount outstanding of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding approximately $2 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $7 million related to this repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- added (2019-10-31):
[0000068505-19-000025:note_history:10]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% senior convertible notes ("Senior Convertible Notes") which were scheduled to mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes were convertible based on a conversion rate adjusted for dividends declared which automatically adjusts the exercise price. During the third quarter of 2018, the Company settled $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium.

- added (2019-10-31):
[0000068505-19-000025:note_history:11]
During the third quarter of 2019, the remaining notes were convertible based on a conversion rate of 14.9186, adjusted for dividends declared, per $1,000 principal amount (equal to a conversion price of $67.03 per share). On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to settle the remaining $800 million in principal amount of the Senior Convertible Notes in two installments: (i) $200 million of principal notes were repurchased during the third quarter for an aggregate consideration of $526 million in cash, inclusive of the conversion premium and (ii) $600 million of principal paid in cash on October 7, 2019, subsequent to the quarter, with 5.5 million shares converted into common stock on September 5, 2019.  As of September 28, 2019, the Company reflected the principal amount of $600 million paid subsequent to the quarter as short term debt and recognized a gain of $4 million from the extinguishment of the 2.00% senior convertible notes in Other, net within Other income (expense) in the Condensed Consolidated Statement of Operations.

- added (2019-10-31):
[0000068505-19-000025:note_history:12]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
During the third quarter of 2019, the Company established an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 28, 2019 the Company had no outstanding debt under the commercial paper program. Subsequent to the end of the quarter, the Company issued $265 million commercial paper under the program.

- removed (2019-10-31):
[0000068505-19-000019:note_history:13]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan. During the second half of 2018, the Company issued an additional $200 million on the outstanding notes. The Company recognized net proceeds of $196 million after debt issuance costs and debt discounts.

- removed (2019-10-31):
[0000068505-19-000019:note_history:14]
In May of 2019, the Company issued $650 million of 4.60% Senior notes due 2029. The Company recognized net proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to fund a tender offer which resulted in the repurchase of $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest, all of which occurred during the three months ended June 29, 2019. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $43 million related to this debt tender in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.
As of June 29, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of June 29, 2019 was $1.1 billion. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0000068505-19-000025:note_history:15]
|  | September 28, 2019 |  | December 31, 2018 |
| Term Loan due 2021 | $ | — |  |  | $ | 399 |  |
| 3.5% senior notes due 2021 | — |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 1.75% senior convertible notes due 2024 | 987 |  |  | — |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 804 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 638 |  |  | 862 |  |
|  | 5,732 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3 | ) |  | (4 | ) |
| Less: current portion | (617 | ) |  | (31 | ) |
| Long-term debt | $ | 5,112 |  |  | $ | 5,289 |  |
  (was, 2019-08-02, similarity 0.7256):
[0000068505-19-000019:note_history:15]
|  | June 29, 2019 |  | December 31, 2018 |
| 2.0% Senior Convertible Notes due 2020 | $ | 800 |  |  | $ | 800 |  |
| Term Loan due 2021 | 399 |  |  | 399 |  |
| 3.5% senior notes due 2021 | 149 |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 690 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 645 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 52 |  |  | 62 |  |
|  | 5,347 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (4 | ) |  | (4 | ) |
| Less: current portion | (28 | ) |  | (31 | ) |
| Long-term debt | $ | 5,315 |  |  | $ | 5,289 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0000068505-19-000025:note_history:16]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 28, 2019 and September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2019-08-02, similarity 0.6296):
[0000068505-19-000019:note_history:16]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 29, 2019 and June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2019-10-31):
[0000068505-19-000025:note_history:17]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,050 |  |  | $ | 403 |  |  | $ | 957 |  |  | $ | 343 |  |
| EMEA | 182 |  |  | 201 |  |  | 199 |  |  | 189 |  |
| Asia Pacific | 117 |  |  | 41 |  |  | 132 |  |  | 42 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 896 |  |  | $ | — |  |  | $ | 828 |  |  | $ | — |  |
| Systems and Systems Integration | 453 |  |  | — |  |  | 460 |  |  | — |  |
| Services | — |  |  | 479 |  |  | — |  |  | 455 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 119 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 602 |  |  | $ | 811 |  |  | $ | 543 |  |
| Indirect | 489 |  |  | 43 |  |  | 477 |  |  | 31 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
  (was, 2019-08-02, similarity 0.9755):
[0000068505-19-000019:note_history:17]
|  | Three Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 969 |  |  | $ | 378 |  |  | $ | 878 |  |  | $ | 331 |  |
| EMEA | 152 |  |  | 204 |  |  | 188 |  |  | 194 |  |
| Asia Pacific | 117 |  |  | 40 |  |  | 123 |  |  | 46 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 809 |  |  | $ | — |  |  | $ | 725 |  |  | $ | — |  |
| Systems and Systems Integration | 429 |  |  | — |  |  | 464 |  |  | — |  |
| Services | — |  |  | 469 |  |  | — |  |  | 456 |  |
| Software | — |  |  | 153 |  |  | — |  |  | 115 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 771 |  |  | $ | 582 |  |  | $ | 740 |  |  | $ | 537 |  |
| Indirect | 467 |  |  | 40 |  |  | 449 |  |  | 34 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |

- changed (2019-10-31):
[0000068505-19-000025:note_history:18]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 2,832 |  |  | $ | 1,133 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 499 |  |  | 603 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 325 |  |  | 119 |  |  | 353 |  |  | 126 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 2,391 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 1,265 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 1,400 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 455 |  |  | — |  |  | 303 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,289 |  |  | $ | 1,737 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 1,367 |  |  | 118 |  |  | 1,261 |  |  | 74 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
  (was, 2019-08-02, similarity 0.9715):
[0000068505-19-000019:note_history:18]
|  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,782 |  |  | $ | 730 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 317 |  |  | 402 |  |  | 345 |  |  | 375 |  |
| Asia Pacific | 208 |  |  | 78 |  |  | 220 |  |  | 84 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,495 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 812 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 921 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 289 |  |  | — |  |  | 184 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,429 |  |  | $ | 1,135 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 878 |  |  | 75 |  |  | 784 |  |  | 44 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0000068505-19-000025:note_history:19]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 28, 2019 and September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2019-08-02, similarity 0.6296):
[0000068505-19-000019:note_history:19]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 29, 2019 and June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2019-10-31):
[0000068505-19-000025:note_history:20]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,050 |  |  | $ | 403 |  |  | $ | 957 |  |  | $ | 343 |  |
| EMEA | 182 |  |  | 201 |  |  | 199 |  |  | 189 |  |
| Asia Pacific | 117 |  |  | 41 |  |  | 132 |  |  | 42 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 896 |  |  | $ | — |  |  | $ | 828 |  |  | $ | — |  |
| Systems and Systems Integration | 453 |  |  | — |  |  | 460 |  |  | — |  |
| Services | — |  |  | 479 |  |  | — |  |  | 455 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 119 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 602 |  |  | $ | 811 |  |  | $ | 543 |  |
| Indirect | 489 |  |  | 43 |  |  | 477 |  |  | 31 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
  (was, 2019-08-02, similarity 0.9755):
[0000068505-19-000019:note_history:20]
|  | Three Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 969 |  |  | $ | 378 |  |  | $ | 878 |  |  | $ | 331 |  |
| EMEA | 152 |  |  | 204 |  |  | 188 |  |  | 194 |  |
| Asia Pacific | 117 |  |  | 40 |  |  | 123 |  |  | 46 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 809 |  |  | $ | — |  |  | $ | 725 |  |  | $ | — |  |
| Systems and Systems Integration | 429 |  |  | — |  |  | 464 |  |  | — |  |
| Services | — |  |  | 469 |  |  | — |  |  | 456 |  |
| Software | — |  |  | 153 |  |  | — |  |  | 115 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 771 |  |  | $ | 582 |  |  | $ | 740 |  |  | $ | 537 |  |
| Indirect | 467 |  |  | 40 |  |  | 449 |  |  | 34 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |

- changed (2019-10-31):
[0000068505-19-000025:note_history:21]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 2,832 |  |  | $ | 1,133 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 499 |  |  | 603 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 325 |  |  | 119 |  |  | 353 |  |  | 126 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 2,391 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 1,265 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 1,400 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 455 |  |  | — |  |  | 303 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,289 |  |  | $ | 1,737 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 1,367 |  |  | 118 |  |  | 1,261 |  |  | 74 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
  (was, 2019-08-02, similarity 0.9715):
[0000068505-19-000019:note_history:21]
|  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,782 |  |  | $ | 730 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 317 |  |  | 402 |  |  | 345 |  |  | 375 |  |
| Asia Pacific | 208 |  |  | 78 |  |  | 220 |  |  | 84 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,495 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 812 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 921 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 289 |  |  | — |  |  | 184 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,429 |  |  | $ | 1,135 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 878 |  |  | 75 |  |  | 784 |  |  | 44 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

- changed (2019-10-31):
[0000068505-19-000025:note_history:22]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of September 28, 2019 is $7.1 billion. A total of $3.2 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion is from Services and Software performance obligations that are not yet satisfied as of September 28, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2019-08-02, similarity 0.9079):
[0000068505-19-000019:note_history:22]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 29, 2019 is $7.3 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.2 billion is from Services and Software performance obligations that are not yet satisfied as of June 29, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2019-10-31):
[0000068505-19-000025:note_history:23]
|  | September 28, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,295 |  |  | $ | 1,293 |  |
| Contract assets | 921 |  |  | 1,012 |  |
| Contract liabilities | 1,223 |  |  | 1,263 |  |
| Non-current contract liabilities | 253 |  |  | 214 |  |
  (was, 2019-08-02, similarity 0.9113):
[0000068505-19-000019:note_history:23]
|  | June 29, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,206 |  |  | $ | 1,293 |  |
| Contract assets | 913 |  |  | 1,012 |  |
| Contract liabilities | 1,187 |  |  | 1,263 |  |
| Non-current contract liabilities | 263 |  |  | 214 |  |

- added (2019-10-31):
[0000068505-19-000025:note_history:24]
Revenue recognized during the three months ended September 28, 2019 which was previously included in Contract liabilities as of June 29, 2019 is $342 million, compared to $327 million of revenue recognized during the three months ended September 29, 2018 which was previously included in Contract liabilities as of July 1, 2018. Revenue recognized during the nine months ended September 28, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $783 million, compared to $777 million of revenue recognized during the nine months ended September 29, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $26 million and $42 million was reversed during the three and nine months ended September 28, 2019, respectively, which were primarily driven by changes in the estimates of progress on two Americas system contracts, compared to $7 million and $4 million of reversals for the three and nine months ended September 29, 2018, respectively.

- changed (2019-10-31):
[0000068505-19-000025:note_history:25]
There were no material impairment losses recognized on contract assets during the three and nine months ended September 28, 2019 and September 29, 2018.
  (was, 2019-08-02, similarity 0.9004):
[0000068505-19-000019:note_history:25]
There were no material impairment losses recognized on contract assets during the three and six months ended June 29, 2019 and June 30, 2018.

- changed (2019-10-31):
[0000068505-19-000025:note_history:26]
|  | September 28, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 28 |  |  | $ | 30 |  |
| Non-current contract cost assets | 102 |  |  | 98 |  |
  (was, 2019-08-02, similarity 0.9606):
[0000068505-19-000019:note_history:26]
|  | June 29, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 37 |  |  | $ | 30 |  |
| Non-current contract cost assets | 98 |  |  | 98 |  |

- changed (2019-10-31):
[0000068505-19-000025:note_history:27]
Amortization of non-current contract cost assets was $10 million and $11 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $32 million and $34 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.
  (was, 2019-08-02, similarity 0.6725):
[0000068505-19-000019:note_history:27]
Amortization of contract cost assets was $11 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and $22 million and $23 million for the six months ended June 29, 2019 and June 30, 2018, respectively.

- removed (2019-10-31):
[0000068505-19-000019:note_history:28]
Revenue recognized during the three months ended June 29, 2019 which was previously included in Contract liabilities as of March 30, 2019 is $340 million, compared to $365 million of revenue recognized during the three months ended June 30, 2018 which was previously included in Contract liabilities as of April 1, 2018. Revenue recognized during the six months ended June 29, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $600 million, compared to $541 million of revenue recognized during the six months ended June 30, 2018 which was previously included in Contract liabilities as of January 1, 2018. Adjustments to revenue for the three and six months ended June 29, 2019 and June 30, 2018 driven by changes in the estimates of progress on system contracts was immaterial.
