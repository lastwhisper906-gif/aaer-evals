# MSI MD&A — 0000068505-20-000006


## mdna

[0000068505-20-000006:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-20-000006:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2019 and 2018 and results of operations for each of the three years in the period ended December 31, 2019. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-20-000006:mdna:3]
Executive Overview

[0000068505-20-000006:mdna:4]
Our Business

[0000068505-20-000006:mdna:5]
Motorola Solutions is a leading global provider of mission critical communications and analytics. Our technology platforms in communications, software, video, and services make cities safer and help communities and businesses thrive. We serve our customers with a global footprint of sales in more than 100 countries and 17,000 employees worldwide utilizing our industry leading innovation and a deep portfolio of products and services.

[0000068505-20-000006:mdna:6]
We conduct our business globally and manage it by two segments (as mentioned, we changed the name order of the segment to Software and Services):

[0000068505-20-000006:mdna:7]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security devices and infrastructure, and the implementation, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio (“TETRA”) standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, such as video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions typically managing a mobile workforce. In 2019, the segment’s net sales were $5.3 billion, representing 68% of our consolidated net sales.

[0000068505-20-000006:mdna:8]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and commercial customers. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on-premise and “as a service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. In 2019, the segment’s net sales were $2.6 billion, representing 32% of our consolidated net sales.

[0000068505-20-000006:mdna:9]
2019 Financial Results

[0000068505-20-000006:mdna:10]
| • | Net sales were $7.9 billion in 2019 compared to $7.3 billion in 2018 and driven by growth in the Americas. |

[0000068505-20-000006:mdna:11]
| • | Operating earnings were $1.6 billion in 2019 compared to $1.3 billion in 2018. |

[0000068505-20-000006:mdna:12]
| • | Earnings attributable to Motorola Solutions, Inc. were $868 million, or $4.95 per diluted common share in 2019, compared to earnings of $966 million, or $5.62 per diluted common share in 2018. |

[0000068505-20-000006:mdna:13]
| • | Our operating cash flow increased $748 million to $1.8 billion in 2019. |

[0000068505-20-000006:mdna:14]
| • | We returned $694 million of capital in the form of $315 million in share repurchases and $379 million in dividends in 2019. |

[0000068505-20-000006:mdna:15]
| • | We increased our quarterly dividend by 12% to $0.64 per share in November 2019. |

[0000068505-20-000006:mdna:16]
| • | Ended 2019 with a backlog position of $11.3 billion, up $659 million compared to 2018. |

[0000068505-20-000006:mdna:17]
Segment Financial Highlights

[0000068505-20-000006:mdna:18]
| • | In the Products and Systems Integration segment, net sales were $5.3 billion in 2019, an increase of $229 million, or 5%, compared to $5.1 billion in 2018. On a geographic basis, net sales increased in the Americas, partially offset by declines in EMEA and AP. Operating earnings were $994 million in 2019, compared to $854 million in 2018. Operating margin increased in 2019 to 18.7% from 16.7% in 2018 driven by higher sales and gross margin, as well as an environmental reserve charge of $40 million taken in 2018. |

[0000068505-20-000006:mdna:19]
| • | In the Software and Services segment, net sales were $2.6 billion in 2019, an increase of $315 million, or 14%, compared to $2.2 billion in 2018. On a geographic basis, net sales increased in the Americas and EMEA, partially offset by declines in AP. Operating earnings were $587 million in 2019, compared to $401 million in 2018. Operating margin increased in 2019 to 22.9% from 17.9% in 2018 driven by higher sales and gross margin, as well as an environmental reserve charge of $17 million taken in 2018. |

[0000068505-20-000006:mdna:20]
Recent Acquisitions and Developments

[0000068505-20-000006:mdna:21]
On October 16, 2019, we acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired.  The acquisition enhances our video security platform by adding data to our existing license plate recognition (“LPR”) database within our Software and Services segment.

[0000068505-20-000006:mdna:22]
On July 11, 2019, we acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:mdna:23]
On March 11, 2019, we acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands our commercial portfolio with new capabilities, allowing us to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:mdna:24]
On January 7, 2019, we announced that we acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:mdna:25]
On March 28, 2018, we completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million. The acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:mdna:26]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the command center with additional solutions for Next Generation 9-1-1 within our Software and Services segment.

[0000068505-20-000006:mdna:27]
On August 28, 2017, we completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk for commercial customers, for a purchase price of $225 million. The business is part of our Software and Services segment.

[0000068505-20-000006:mdna:28]
On March 13, 2017, we completed the acquisition of Interexport, a managed service provider of communications systems to public safety and commercial customers in Chile, for a purchase price of 98 billion Chilean pesos, or approximately $147 million. The business is part of our Software and Services segment.

[0000068505-20-000006:mdna:29]
Looking Forward

[0000068505-20-000006:mdna:30]
We continue to further leverage our position as a leader in mission critical communications into additional growth opportunities in our video security and command center software platforms.  Specifically, we view drivers of these growth opportunities as follows: (i) video cross-selling opportunities, where we have traditionally sold video into commercial verticals, we are now seeking opportunities into the government and public safety verticals; (ii) potential share gains in video from customers seeking domestic vendors; (iii) accelerating traction with command center software suite sales; and (iv) a deeper penetration of service into existing LMR customers as communication networks become more complex, software-centric and data-driven.

[0000068505-20-000006:mdna:31]
As the Company pursues these growth opportunities, we continue to expect to gain operating leverage as we scale our businesses.  Specifically, we’ve made go-to-market investments in both video security and our command center software platforms with growth in mind.  We’ve made a number of acquisitions since 2016 and we see opportunity to continue to rationalize costs within both segments of our business, further driving gains in the operating margins of our businesses.

[0000068505-20-000006:mdna:32]
Lastly, we remain committed to our capital deployment model, which is a framework in which we allocate cash flow from operations as follows: (i) 50% for acquisitions and share repurchases, (ii) 30% for dividends, and (iii) 20% for investments in capital expenditures.  We expect to continue a balanced approach in capital allocation through this framework.

[0000068505-20-000006:mdna:33]
Results of Operations

[0000068505-20-000006:mdna:34]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2019 |  | % ofSales ** |  | 2018 |  | % ofSales ** |  | 2017 |  | % ofSales ** |
| Net sales from products | $ | 4,746 |  |  |  |  | $ | 4,463 |  |  |  |  | $ | 3,772 |  |  |  |
| Net sales from services | 3,141 |  |  |  |  | 2,880 |  |  |  |  | 2,608 |  |  |  |
| Net sales | 7,887 |  |  |  |  | 7,343 |  |  |  |  | 6,380 |  |  |  |
| Costs of product sales | 2,049 |  |  | 43.2 | % |  | 2,035 |  |  | 45.6 | % |  | 1,686 |  |  | 44.7 | % |
| Costs of services sales | 1,907 |  |  | 60.7 | % |  | 1,828 |  |  | 63.5 | % |  | 1,670 |  |  | 64.0 | % |
| Costs of sales | 3,956 |  |  | 50.2 | % |  | 3,863 |  |  | 52.6 | % |  | 3,356 |  |  | 52.6 | % |
| Gross margin | 3,931 |  |  | 49.8 | % |  | 3,480 |  |  | 47.4 | % |  | 3,024 |  |  | 47.4 | % |
| Selling, general and administrative expenses | 1,403 |  |  | 17.8 | % |  | 1,254 |  |  | 17.1 | % |  | 1,025 |  |  | 16.1 | % |
| Research and development expenditures | 687 |  |  | 8.7 | % |  | 637 |  |  | 8.7 | % |  | 568 |  |  | 8.9 | % |
| Other charges | 260 |  |  | 3.3 | % |  | 334 |  |  | 4.5 | % |  | 147 |  |  | 2.3 | % |
| Operating earnings | 1,581 |  |  | 20.0 | % |  | 1,255 |  |  | 17.1 | % |  | 1,284 |  |  | 20.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (220 | ) |  | (2.8 | )% |  | (222 | ) |  | (3.0 | )% |  | (201 | ) |  | (3.2 | )% |
| Gains on sales of investments and businesses, net | 5 |  |  | 0.1 | % |  | 16 |  |  | 0.2 | % |  | 3 |  |  | — | % |
| Other | (365 | ) |  | (4.6 | )% |  | 53 |  |  | 0.7 | % |  | (10 | ) |  | (0.2 | )% |
| Total other expense | (580 | ) |  | (7.4 | )% |  | (153 | ) |  | (2.1 | )% |  | (208 | ) |  | (3.3 | )% |
| Net earnings before income taxes | 1,001 |  |  | 12.7 | % |  | 1,102 |  |  | 15.0 | % |  | 1,076 |  |  | 16.9 | % |
| Income tax expense | 130 |  |  | 1.6 | % |  | 133 |  |  | 1.8 | % |  | 1,227 |  |  | 19.2 | % |
| Net earnings (loss) | 871 |  |  | 11.0 | % |  | 969 |  |  | 13.2 | % |  | (151 | ) |  | (2.4 | )% |
| Less: Earnings attributable to noncontrolling interests | 3 |  |  | — | % |  | 3 |  |  | — | % |  | 4 |  |  | 0.1 | % |
| Net earnings (loss)* | $ | 868 |  |  | 11.0 | % |  | $ | 966 |  |  | 13.2 | % |  | $ | (155 | ) |  | (2.4 | )% |
| Earnings (loss) per diluted common share* | $ | 4.95 |  |  |  |  | $ | 5.62 |  |  |  |  | $ | (0.95 | ) |  |  |

[0000068505-20-000006:mdna:35]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-20-000006:mdna:36]
**    Percentages may not add due to rounding.

[0000068505-20-000006:mdna:37]
Geographic Market Sales by Locale of End Customer

[0000068505-20-000006:mdna:38]
|  | 2019 |  | 2018 |  | 2017 |
| Americas | 72 | % |  | 69 | % |  | 68 | % |
| EMEA | 20 | % |  | 22 | % |  | 21 | % |
| AP | 8 | % |  | 9 | % |  | 11 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-20-000006:mdna:39]
29

[0000068505-20-000006:mdna:40]
Results of Operations—2019 Compared to 2018

[0000068505-20-000006:mdna:41]
Net Sales

[0000068505-20-000006:mdna:42]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 5,329 |  |  | $ | 5,100 |  |  | 5 | % |
| Net sales from Software and Services | 2,558 |  |  | 2,243 |  |  | 14 | % |
| Net sales | $ | 7,887 |  |  | $ | 7,343 |  |  | 7 | % |

[0000068505-20-000006:mdna:43]
The Products and Systems Integration segment’s net sales represented 68% of our consolidated net sales in 2019, compared to 69% in 2018. The Software and Services segment’s net sales represented 32% of our consolidated net sales in 2019, compared to 31% in 2018.

[0000068505-20-000006:mdna:44]
Net sales were up $544 million, or 7%, compared to 2018. The increase in net sales was driven by the Americas, partially offset by sales declines in EMEA and AP, with a 14% increase in the Software and Services segment and a 5% increase in the Products and Systems Integration segment. Net sales includes:

[0000068505-20-000006:mdna:45]
| • | growth in Devices, Software, and Services due to strong demand in Americas, inclusive of acquisitions; |

[0000068505-20-000006:mdna:46]
| • | $312 million of incremental revenue from acquisitions; and |

[0000068505-20-000006:mdna:47]
| • | partially offset by $113 million from unfavorable currency rates. |

[0000068505-20-000006:mdna:48]
Regional results include:

[0000068505-20-000006:mdna:49]
| • | the Americas grew 12% across video security, LMR and command center software within both the Products and Systems Integration and the Software and Services segments, inclusive of incremental revenue from acquisitions; |

[0000068505-20-000006:mdna:50]
| • | EMEA was down 3%, with a 14% decrease in Products and Systems Integration, partially offset by a 9% growth in the Software and Services segments, inclusive of incremental revenue from acquisitions. EMEA experienced $61 million of unfavorable foreign currency effects in 2019 compared to 2018; and |

[0000068505-20-000006:mdna:51]
| • | AP was down 3% with declines of 4% in the Products and Systems Integration segment and 2% in the Software and Services segment. AP experienced $28 million of unfavorable foreign currency effects in 2019 compared to 2018. |

[0000068505-20-000006:mdna:52]
Products and Systems Integration

[0000068505-20-000006:mdna:53]
The 5% growth in the Products and Systems Integration segment was driven by:

[0000068505-20-000006:mdna:54]
| • | $157 million of incremental revenue from acquisitions; and |

[0000068505-20-000006:mdna:55]
| • | partially offset by $54 million foreign currency headwinds; |

[0000068505-20-000006:mdna:56]
| • | Devices were up $251 million reflecting strong demand for both LMR and video security devices; and |

[0000068505-20-000006:mdna:57]
| • | Systems and Systems Integration decreased 1% driven primarily by EMEA, which had two large system deployments completed in the Middle East and Africa in 2018. |

[0000068505-20-000006:mdna:58]
Software and Services

[0000068505-20-000006:mdna:59]
The 14% growth in the Software and Services segment was driven by the following:

[0000068505-20-000006:mdna:60]
| • | $155 million of incremental revenue from acquisitions; and |

[0000068505-20-000006:mdna:61]
| • | partially offset by $59 million of foreign currency headwinds; |

[0000068505-20-000006:mdna:62]
| • | Software was up $234 million, or 55%, driven by growth in both our video software solutions portfolio and command center software sales, inclusive of acquisitions; and |

[0000068505-20-000006:mdna:63]
| • | Services were up $81 million, or 4%, driven by growth in both maintenance and managed service revenues, inclusive of acquisitions. |

[0000068505-20-000006:mdna:64]
Gross Margin

[0000068505-20-000006:mdna:65]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Gross margin | $ | 3,931 |  |  | $ | 3,480 |  |  | 13 | % |

[0000068505-20-000006:mdna:66]
Gross margin was 49.8% of net sales in 2019 and 47.4% in 2018. The increase was driven by:

[0000068505-20-000006:mdna:67]
| • | higher margins in the Products and Systems Integration segment primarily driven by a favorable mix in Devices; and |

[0000068505-20-000006:mdna:68]
| • | higher margins within the Software and Services segment primarily driven by higher Software sales, inclusive of acquisitions. |

[0000068505-20-000006:mdna:69]
Selling, General and Administrative Expenses

[0000068505-20-000006:mdna:70]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 1,403 |  |  | $ | 1,254 |  |  | 12 | % |

[0000068505-20-000006:mdna:71]
SG&A expenses increased 12% compared to 2018. SG&A expenses were 17.8% of net sales compared to 17.1% of net sales in 2018. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses, including the deployment of additional sales resources to support video security growth initiatives.

[0000068505-20-000006:mdna:72]
Research and Development Expenditures

[0000068505-20-000006:mdna:73]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Research and development expenditures | $ | 687 |  |  | $ | 637 |  |  | 8 | % |

[0000068505-20-000006:mdna:74]
R&D expenditures increased 8%. R&D expenditures were 8.7% of net sales in 2019 and 2018. The increase in R&D is primarily due to acquired businesses, specifically in our video security platform, as well as new product launches.

[0000068505-20-000006:mdna:75]
Other Charges

[0000068505-20-000006:mdna:76]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |
| Other charges | $ | 260 |  |  | $ | 334 |  |

[0000068505-20-000006:mdna:77]
The decrease in Other charges in 2019 as compared to 2018 can be summarized as follows:

[0000068505-20-000006:mdna:78]
| • | a $57 million charge in 2018 related to ongoing remediation efforts for an environmental clean-up incurred by a legacy business (see Note 4 of our consolidated financial statements); |

[0000068505-20-000006:mdna:79]
| • | $40 million of net reorganization of business charges in 2019 as compared to $61 million in 2018 (See Note 14 of our consolidated financial statements); |

[0000068505-20-000006:mdna:80]
| • | $3 million of charges for acquisition-related transaction fees in 2019 as compared to $24 million in 2018; partially offset by |

[0000068505-20-000006:mdna:81]
| • | $208 million of amortization of intangibles in 2019 compared to $188 million in 2018. |

[0000068505-20-000006:mdna:82]
Operating Earnings

[0000068505-20-000006:mdna:83]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |
| Operating earnings from Products and Systems Integration | $ | 994 |  |  | $ | 854 |  |
| Operating earnings from Software and Services | 587 |  |  | 401 |  |
| Operating earnings | $ | 1,581 |  |  | $ | 1,255 |  |

[0000068505-20-000006:mdna:84]
Operating earnings were up $326 million, or 26%, compared to 2018. The increase in Operating earnings was due to:

[0000068505-20-000006:mdna:85]
| • | Software and Services segment was up $186 million from 2018 to 2019 due to higher sales and gross margin, as well as lower operating expenses driven by: (i) $17 million lower environmental reserve expenses, (ii) $11 million lower acquisition-related transaction fees, (iii) $5 million lower reorganization of business expenses, and partially offset by (iv) $4 million higher intangible amortization driven by acquisitions. |

[0000068505-20-000006:mdna:86]
| • | Products and Systems Integration was up $140 million from 2018 to 2019 due to higher sales and gross margin, as well as lower operating expenses driven by: (i) $40 million lower environmental reserve expenses, (ii) $15 million lower reorganization of business expenses, (iii) $10 million lower acquisition-related transaction fees, and partially offset by (iv) $16 million higher intangible amortization driven by acquisitions. |

[0000068505-20-000006:mdna:87]
Net Interest Expense

[0000068505-20-000006:mdna:88]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |
| Interest expense, net | $ | (220 | ) |  | $ | (222 | ) |

[0000068505-20-000006:mdna:89]
Interest expense, net in 2019 compared to 2018 remained relatively consistent given the similar average outstanding debt balance.

[0000068505-20-000006:mdna:90]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-20-000006:mdna:91]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |
| Gains on sales of investments and businesses, net | $ | 5 |  |  | $ | 16 |  |

[0000068505-20-000006:mdna:92]
The net gains in 2019 and 2018 were primarily related to the sales of various equity investments.

[0000068505-20-000006:mdna:93]
Other

[0000068505-20-000006:mdna:94]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |
| Other income (expense) | $ | (365 | ) |  | $ | 53 |  |

[0000068505-20-000006:mdna:95]
The change in net Other expense in 2019 as compared to 2018 was primarily comprised of:

[0000068505-20-000006:mdna:96]
| • | $359 million U.S. pension settlement loss in 2019 (See Note 8 of our consolidated financial statements); |

[0000068505-20-000006:mdna:97]
| • | $46 million of net losses from repurchases of long term debt as compared to a gain of $6 million in 2018 (See Note 5 of our consolidated financial statements). |

[0000068505-20-000006:mdna:98]
Effective Tax Rate

[0000068505-20-000006:mdna:99]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |
| Income tax expense | $ | 130 |  |  | $ | 133 |  |

[0000068505-20-000006:mdna:100]
Income tax expense decreased by $3 million for an effective tax rate of 13.0%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-20-000006:mdna:101]
32

[0000068505-20-000006:mdna:102]
| • | a $77 million benefit due to the partial release of a valuation allowance to our U.S. foreign tax credit carryforward (see Note 7 of our consolidated financial statements); and |

[0000068505-20-000006:mdna:103]
| • | $27 million of benefits due to the recognition of excess tax benefits on share-based compensation. |

[0000068505-20-000006:mdna:104]
Our effective tax rate in 2018 was 12.1% primarily related to:

[0000068505-20-000006:mdna:105]
•$79 million benefit related to updates of the provisional amounts on the impact of the Tax Act; and

[0000068505-20-000006:mdna:106]
•$30 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-20-000006:mdna:107]
Results of Operations—2018 Compared to 2017

[0000068505-20-000006:mdna:108]
Net Sales

[0000068505-20-000006:mdna:109]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Net sales from Products and Systems Integration | $ | 5,100 |  |  | $ | 4,513 |  |  | 13 | % |
| Net sales from Software and Services | 2,243 |  |  | 1,867 |  |  | 20 | % |
| Net sales | $ | 7,343 |  |  | $ | 6,380 |  |  | 15 | % |

[0000068505-20-000006:mdna:110]
The Products and Systems Integration segment’s net sales represented 69% of our consolidated net sales in 2018, compared to 71% in 2017. The Software and Services segment’s net sales represented 31% of our consolidated net sales in 2018, compared to 29% in 2017.

[0000068505-20-000006:mdna:111]
Net sales were up $963 million, or 15%, compared to 2017. The increase in net sales was driven by the Americas and EMEA with a 13% increase in the Products and Systems Integration segment and a 20% increase in the Software and Services segment. The growth includes:

[0000068505-20-000006:mdna:112]
| • | $507 million of incremental revenue from the acquisitions of Avigilon and Plant in 2018 and Kodiak Networks and Interexport which were acquired during 2017; |

[0000068505-20-000006:mdna:113]
| • | $83 million from the adoption of Accounting Standards Codification ("ASC") 606 (see Note 1 of our consolidated financial statements); and |

[0000068505-20-000006:mdna:114]
| • | $32 million from favorable currency rates. |

[0000068505-20-000006:mdna:115]
Regional results include:

[0000068505-20-000006:mdna:116]
| • | the Americas grew 17% across major categories within both the Products and Systems Integration and the Software and Services segments, inclusive of incremental revenue from acquisitions; |

[0000068505-20-000006:mdna:117]
| • | EMEA grew 18% on broad-based growth within all offerings within our Products and Systems Integration and Software and Services segments, inclusive of incremental revenue from acquisitions; and |

[0000068505-20-000006:mdna:118]
| • | AP was relatively flat with growth in the Software and Services segment offset by lower Products and Systems Integration revenue. |

[0000068505-20-000006:mdna:119]
Products and Systems Integration

[0000068505-20-000006:mdna:120]
The 13% growth in the Products and Systems Integration segment was driven by the following:

[0000068505-20-000006:mdna:121]
| • | $318 million of incremental revenue from the acquisitions of Avigilon in 2018 and Interexport during 2017; |

[0000068505-20-000006:mdna:122]
| • | $78 million from the adoption of ASC 606; |

[0000068505-20-000006:mdna:123]
| • | Devices revenues were up significantly due to the acquisition of Avigilon along with strong demand in the Americas and EMEA; and |

[0000068505-20-000006:mdna:124]
| • | Systems and Systems Integration revenues increased 10% in 2018, as compared to 2017 driven by incremental revenue from Avigilon, as well as system deployments in EMEA and AP. |

[0000068505-20-000006:mdna:125]
Software and Services

[0000068505-20-000006:mdna:126]
The 20% growth in the Software and Services segment was driven by the following:

[0000068505-20-000006:mdna:127]
| • | $189 million of incremental revenue primarily from the acquisitions of Plant and Avigilon in 2018 and Kodiak Networks and Interexport during 2017; |

[0000068505-20-000006:mdna:128]
| • | $5 million from the adoption of ASC 606; |

[0000068505-20-000006:mdna:129]
| • | Services were up $174 million, or 9%, driven by growth in both maintenance and managed service revenues, and incremental revenue from the acquisitions of Interexport and Plant; and |

[0000068505-20-000006:mdna:130]
| • | Software was up $202 million, or 89%, driven primarily by incremental revenue from the acquisitions of Plant, Avigilon, and Kodiak Networks, and growth in our command center software suite. |

[0000068505-20-000006:mdna:131]
Gross Margin

[0000068505-20-000006:mdna:132]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Gross margin | $ | 3,480 |  |  | $ | 3,024 |  |  | 15 | % |

[0000068505-20-000006:mdna:133]
Gross margin was 47.4% of net sales in both 2018 and 2017 due to:

[0000068505-20-000006:mdna:134]
| • | higher margins within the Software and Services segment primarily driven by operational improvements and efficiencies in service delivery costs of our Services portfolio and higher margin contribution within our Software portfolio from acquisitions; |

[0000068505-20-000006:mdna:135]
| • | lower margins in the Products and Systems Integration segment primarily driven by lower margin in Systems and Systems Integration due to certain large projects where we have taken an integrator role, partially offset by higher Devices volumes; and |

[0000068505-20-000006:mdna:136]
| • | $50 million of additional reorganization of business charges (see further detail in “Reorganization of Businesses” section) primarily associated with costs related to the closure of certain supply chain operations in Europe in 2018 as compared to 2017. |

[0000068505-20-000006:mdna:137]
Selling, General and Administrative Expenses

[0000068505-20-000006:mdna:138]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Selling, general and administrative expenses | $ | 1,254 |  |  | $ | 1,025 |  |  | 22 | % |

[0000068505-20-000006:mdna:139]
SG&A expenses increased 22% compared to 2017. SG&A expenses were 17.1% of net sales compared to 16.1% of net sales in 2017.

[0000068505-20-000006:mdna:140]
The increase in SG&A expenses is primarily due to increased expenses associated with acquired businesses, $72 million related to the change in classification of our third-party sales commissions from the adoption of ASC 606, and higher incentive compensation.

[0000068505-20-000006:mdna:141]
Research and Development Expenditures

[0000068505-20-000006:mdna:142]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |  | % Change |
| Research and development expenditures | $ | 637 |  |  | $ | 568 |  |  | 12 | % |

[0000068505-20-000006:mdna:143]
R&D expenditures increased 12%. R&D expenditures were 8.7% of net sales compared to 8.9% of net sales in 2017. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-20-000006:mdna:144]
Other Charges

[0000068505-20-000006:mdna:145]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Other charges | $ | 334 |  |  | $ | 147 |  |

[0000068505-20-000006:mdna:146]
The Other charges in 2018 as compared to 2017 can be summarized as follows:

[0000068505-20-000006:mdna:147]
| • | $188 million of amortization of intangibles in 2018 compared to $151 million in 2017, driven by 2018 acquisitions; |

[0000068505-20-000006:mdna:148]
| • | $61 million of reorganization of business charges in 2018 as compared to $33 million in 2017, driven by acquisitions (see further detail in "Reorganization of Businesses" section); |

[0000068505-20-000006:mdna:149]
| • | a $57 million charge in 2018 related to ongoing remediation efforts for an environmental clean-up incurred by a legacy business; |

[0000068505-20-000006:mdna:150]
| • | a gain of $47 million in 2017 related to the recovery of receivables owed to us by a former customer of a legacy business; |

[0000068505-20-000006:mdna:151]
| • | $24 million of charges for acquisition related transaction fees in 2018 as compared to $1 million in 2017. |

[0000068505-20-000006:mdna:152]
34

[0000068505-20-000006:mdna:153]
Operating Earnings

[0000068505-20-000006:mdna:154]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Operating earnings from Products and Systems Integration | $ | 854 |  |  | $ | 969 |  |
| Operating earnings from Software and Services | 401 |  |  | 315 |  |
| Operating earnings | $ | 1,255 |  |  | $ | 1,284 |  |

[0000068505-20-000006:mdna:155]
Operating earnings were down $29 million, or 2%, compared to 2017. The decrease in Operating earnings was due to the following:

[0000068505-20-000006:mdna:156]
| • | Products and Systems Integration was down $115 million from 2017 to 2018, driven by: (i) $69 million more reorganization of business expenses, (ii) environmental reserve expenses of $40 million in 2018, (iii) $28 million more intangible amortization driven by acquisitions, and (iv) $12 million of acquisition-related transaction fees; and |

[0000068505-20-000006:mdna:157]
| • | partially offset by the Software and Services segment, which was up $86 million from 2017 to 2018, driven by higher sales and partially offset by: (i) environmental reserve expenses of $17 million in 2018, (ii) $9 million more reorganization of business expenses, (iii) $9 million more intangible amortization from 2018 acquisitions, and (iv) $11 million more of acquisition-related transactions fees. |

[0000068505-20-000006:mdna:158]
Net Interest Expense

[0000068505-20-000006:mdna:159]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Interest expense, net | $ | (222 | ) |  | $ | (201 | ) |

[0000068505-20-000006:mdna:160]
The increase in net interest expense in 2018 compared to 2017 was a result of increases in outstanding debt:

[0000068505-20-000006:mdna:161]
| • | $500 million of senior notes due in 2028, that were used to make a voluntary contribution to the U.S. pension plan, issued during the first quarter of 2018; |

[0000068505-20-000006:mdna:162]
| • | $400 million term loan due in 2021 ("the Term Loan") that was issued during the first quarter of 2018 and was used to complete the acquisition of Avigilon; |

[0000068505-20-000006:mdna:163]
| • | $400 million borrowed under our revolving credit facility at the end of the first quarter of 2018 and repaid throughout the year; and |

[0000068505-20-000006:mdna:164]
| • | $200 million of follow-on senior notes due in 2028, issued in the third quarter of 2018, which were used to repurchase $200 million of 2.00% senior convertible notes. |

[0000068505-20-000006:mdna:165]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-20-000006:mdna:166]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Gains on sales of investments and businesses, net | $ | 16 |  |  | $ | 3 |  |

[0000068505-20-000006:mdna:167]
The net gains in 2018 and 2017 were primarily related to the sales of various equity investments.

[0000068505-20-000006:mdna:168]
Other

[0000068505-20-000006:mdna:169]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Other income (expense) | $ | 53 |  |  | $ | (10 | ) |

[0000068505-20-000006:mdna:170]
The net Other income in 2018 as compared to 2017 was primarily comprised of:

[0000068505-20-000006:mdna:171]
| • | $75 million of net periodic pension and postretirement benefit in 2018 as compared to $46 million in 2017; |

[0000068505-20-000006:mdna:172]
| • | $48 million of losses on settlements within our U.K. defined benefit plan during 2017 with no activity in 2018; |

[0000068505-20-000006:mdna:173]
| • | $11 million of favorable fair value adjustments to investments; |

[0000068505-20-000006:mdna:174]
| • | a $6 million gain from the repurchase of $200 million of our 2.00% senior convertible notes in 2018; |

[0000068505-20-000006:mdna:175]
| • | foreign currency losses of $24 million in 2018 as compared to $31 million of losses in 2017; and |

[0000068505-20-000006:mdna:176]
| • | a $14 million loss on derivative instruments in 2018 compared to a $15 million gain in 2017. |

[0000068505-20-000006:mdna:177]
Effective Tax Rate

[0000068505-20-000006:mdna:178]
|  | Years ended December 31 |
| (In millions) | 2018 |  | 2017 |
| Income tax expense | $ | 133 |  |  | $ | 1,227 |  |

[0000068505-20-000006:mdna:179]
Income tax expense decreased by $1.1 billion compared to 2017, for an effective tax rate of 12%.  Our effective tax rate for 2018 was lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-20-000006:mdna:180]
| • | a $79 million benefit related to updates of the provisional amounts on the impact of the Tax Act; and |

[0000068505-20-000006:mdna:181]
| • | a $30 million benefit due to the recognition of excess tax benefits on share-based compensation. |

[0000068505-20-000006:mdna:182]
Our effective tax rate in 2017 was 114% primarily due to the implementation of Tax Act. As a result of the Tax Act we recorded $874 million of non-recurring charges, primarily related to:

[0000068505-20-000006:mdna:183]
| • | a $471 million valuation allowance against U.S. foreign tax credit carryforwards; and |

[0000068505-20-000006:mdna:184]
| • | income tax expense of $366 million from the remeasurement of our deferred tax balances at the lower federal tax rate of 21%. |

[0000068505-20-000006:mdna:185]
Excluding the income tax effects from the Tax Act, our effective tax rate was lower than the 2017 U.S. statutory tax rate of 35% (see Note 7 of our consolidated financial statements).

[0000068505-20-000006:mdna:186]
Reorganization of Businesses

[0000068505-20-000006:mdna:187]
In 2019, we recorded net reorganization of business charges of $57 million relating to the separation of 700 employees, of which 500 were indirect employees and 200 were direct employees. The $57 million of charges included $17 million recorded to Cost of sales and $40 million recorded to Other charges. Included in the aggregate $57 million are charges of $64 million for employee separation costs, $5 million for exit costs, partially offset by $12 million of reversals for accruals no longer needed.

[0000068505-20-000006:mdna:188]
During 2018, we recorded net reorganization of business charges of $120 million relating to the separation of 1,200 employees, of which 700 were indirect employees and 500 were direct employees. The $120 million of charges included $59 million recorded to Cost of sales and $61 million recorded to Other charges. Included in the aggregate $120 million are charges of $122 million for employee separation costs and $16 million for exit costs, partially offset by $18 million of reversals for accruals no longer needed. Also, included in the $120 million of charges for 2018 was a $44 million charge that related to the announcement of our plan to close our Europe manufacturing facility which impacted 165 employees primarily within the Products and Systems Integration segment. The remainder of the initiatives impacted both of our segments and affected employees located in all geographic regions.

[0000068505-20-000006:mdna:189]
During 2017, we recorded net reorganization of business charges of $42 million relating to the separation of 400 employees, of which 300 were indirect employees and 100 were direct employees. The $42 million of charges included $9 million recorded to Cost of sales and $33 million recorded to Other charges. Included in the aggregate $42 million are charges of: (i) $43 million for employee separation costs and (ii) $8 million for exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-20-000006:mdna:190]
The following table displays the net charges incurred by business segment:

[0000068505-20-000006:mdna:191]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| Products and Systems Integration | $ | 45 |  |  | $ | 101 |  |  | $ | 32 |  |
| Software and Services | 12 |  |  | 19 |  |  | 10 |  |
|  | $ | 57 |  |  | $ | 120 |  |  | $ | 42 |  |

[0000068505-20-000006:mdna:192]
Cash payments for employee severance in connection with the reorganization of business plans were $63 million, $65 million, and $93 million in 2019, 2018, and 2017, respectively. The reorganization of business accruals for employee separation costs at December 31, 2019 were $78 million that are expected to be paid within one year.

[0000068505-20-000006:mdna:193]
Liquidity and Capital Resources

[0000068505-20-000006:mdna:194]
|  | Years Ended December 31 |
|  | 2019 |  | 2018 |  | 2017 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 1,823 |  |  | $ | 1,075 |  |  | $ | 1,346 |  |
| Investing activities | (934 | ) |  | (1,266 | ) |  | (448 | ) |
| Financing activities | (1,144 | ) |  | 220 |  |  | (722 | ) |
| Effect of exchange rates on cash and cash equivalents | (1 | ) |  | (40 | ) |  | 62 |  |
| Increase (decrease) in cash and cash equivalents | $ | (256 | ) |  | $ | (11 | ) |  | $ | 238 |  |

[0000068505-20-000006:mdna:195]
Cash and Cash Equivalents

[0000068505-20-000006:mdna:196]
At December 31, 2019, $495 million of the $1.0 billion cash and cash equivalents balance was held in the U.S. and $506 million was held in other countries, with $143 million held in the United Kingdom. Restricted cash was $2 million at December 31, 2019 and $11 million at December 31, 2018.

[0000068505-20-000006:mdna:197]
In 2019, we repatriated $434 million in cash to the U.S. from international jurisdictions. We routinely repatriate a portion of non-U.S. earnings each year.  We have recorded income tax expense for foreign withholding tax and distribution taxes on such earnings and, under current U.S. tax laws, do not expect to incur material incremental U.S. tax on repatriation.

[0000068505-20-000006:mdna:198]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy.  While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay due to local country approvals.

[0000068505-20-000006:mdna:199]
Operating Activities

[0000068505-20-000006:mdna:200]
The increase in operating cash flows from 2018 to 2019 was driven by:

[0000068505-20-000006:mdna:201]
| • | a $500 million debt-funded voluntary contribution to our U.S. pension plan in 2018 compared to no material contributions to our U.S. pension plan in 2019; |

[0000068505-20-000006:mdna:202]
| • | higher operating earnings in 2019 as compared to 2018; |

[0000068505-20-000006:mdna:203]
| • | a $51 million settlement arising from a legacy business in 2018; and |

[0000068505-20-000006:mdna:204]
| • | partially offset by $19 million of higher tax payments and $17 million of higher interest payments in 2019 compared to 2018. |

[0000068505-20-000006:mdna:205]
The decrease in operating cash flows from 2017 to 2018 was driven by:

[0000068505-20-000006:mdna:206]
| • | a $500 million debt-funded voluntary contribution to our U.S. pension plan in the first quarter of 2018, compared to no material contributions to our U.S. pension plans in 2017; |

[0000068505-20-000006:mdna:207]
| • | a $51 million payment out of restricted cash related to a settlement arising from a legacy business in 2018, as compared to the recovery of $47 million of receivables owed to us by a former customer of a legacy business in 2017; |

[0000068505-20-000006:mdna:208]
| • | $28 million of higher interest payments driven by additional debt issued in 2018 as compared to 2017; and |

[0000068505-20-000006:mdna:209]
| • | partially offset by higher earnings in 2018 as compared to 2017. |

[0000068505-20-000006:mdna:210]
We do not expect to make any material contributions to our pension plans in 2020.

[0000068505-20-000006:mdna:211]
Investing Activities

[0000068505-20-000006:mdna:212]
The decrease in net cash used by investing activities from 2018 to 2019 was primarily due to:

[0000068505-20-000006:mdna:213]
| • | $455 million decrease in acquisitions and investments, primarily driven by acquisitions of $709 million in 2019 as compared to $1.2 billion in 2018; |

[0000068505-20-000006:mdna:214]
| • | $79 million of lower proceeds from sales of investments and businesses, driven by $60 million of excess cash received from company-sponsored life insurance investments in 2018; and |

[0000068505-20-000006:mdna:215]
| • | partially offset by $51 million higher capital expenditures in 2019 as compared 2018, due to higher spend associated with revenue-generating networks within our Software and Services segment. |

[0000068505-20-000006:mdna:216]
The increase in net cash used by investing activities from 2017 to 2018 was primarily due to:

[0000068505-20-000006:mdna:217]
| • | a $760 million increase in acquisitions and investments, primarily driven by acquisitions of $1.2 billion in 2018 as compared to $404 million in 2017; and |

[0000068505-20-000006:mdna:218]
| • | $88 million of lower proceeds from sales of investments and businesses, driven by the $60 million of excess cash withdrawn from company-sponsored life insurance investments in 2018, as compared to $183 million of cash received from short-term government securities that were previously maintained in foreign countries in 2017; and |

[0000068505-20-000006:mdna:219]
| • | partially offset by $30 million lower capital expenditures in 2018 as compared 2017, due to lower information technology ("IT") spend as we completed our ERP implementation in 2017, as well as lower facilities spend. |

[0000068505-20-000006:mdna:220]
Financing Activities

[0000068505-20-000006:mdna:221]
The increase in cash used by financing activities in 2019 as compared to cash from financing activities in 2018 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" below):

[0000068505-20-000006:mdna:222]
| • | $1.1 billion used for the settlement of the 2.00% senior convertible notes, inclusive of the $326 million conversion premium compared to the settlement of $369 million during 2018, inclusive of the $169 million conversion premium; |

[0000068505-20-000006:mdna:223]
| • | $400 million used in 2019 for the repayment of the term loan, compared to the $400 million of proceeds received from the issuance of the term loan in 2018; |

[0000068505-20-000006:mdna:224]
| • | $379 million of cash used for the payment of dividends in 2019 as compared to $337 million in 2018; |

[0000068505-20-000006:mdna:225]
| • | $315 million used for purchases under our share repurchase program in 2019 as compared to $132 million in 2018; and partially offset by |

[0000068505-20-000006:mdna:226]
| • | $1.0 billion received from the issuance of 1.75% senior convertible notes due 2024 in 2019; |

[0000068505-20-000006:mdna:227]
| • | $700 million of proceeds received from the issuance of 4.6% senior notes due 2028 in 2018; |

[0000068505-20-000006:mdna:228]
| • | $645 net proceeds from the issuance of $650 million of 4.6% senior notes due 2029 in the second quarter of 2019, of which proceeds were used to repurchase $654 million of outstanding long term debt; |

[0000068505-20-000006:mdna:229]
| • | $159 net proceeds from the issuance of $150 million of 4.6% senior notes due 2029 in the third quarter of 2019, which was subsequently used to repurchase $155 million of the 3.5% senior notes due in 2021; and |

[0000068505-20-000006:mdna:230]
| • | $114 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2019, as compared to $168 million in 2018. |

[0000068505-20-000006:mdna:231]
The increase in cash from financing activities in 2018, as compared to cash used in 2017 was driven by:

[0000068505-20-000006:mdna:232]
| • | the issuance of $500 million of 4.60% senior notes due 2028 in the first quarter of 2018, of which the proceeds were contributed to our U.S. pension plan; |

[0000068505-20-000006:mdna:233]
| • | we entered into a term loan for $400 million in the first quarter of 2018 with a maturity date of March 26, 2021 to complete the acquisition of Avigilon; |

[0000068505-20-000006:mdna:234]
| • | $400 million borrowing from our revolving credit facility in the first quarter of 2018 to complete the acquisition of Avigilon, repaying the full $400 million throughout 2018; |

[0000068505-20-000006:mdna:235]
| • | in the third quarter of 2018, we issued an additional $200 million on the outstanding 4.60% Senior notes due in 2028, of which the proceeds were used to repurchase $200 million of our outstanding 2.00% senior convertible note with Silver Lake Partners; |

[0000068505-20-000006:mdna:236]
| • | $169 million of cash was used during the third quarter of 2018 to pay the conversion premium on the repurchase of our 2.00% senior convertible note with Silver Lake Partners; |

[0000068505-20-000006:mdna:237]
| • | $76 million used in the fourth quarter of 2018 to pay a contractually-defined deferred purchase price of Airwave; |

[0000068505-20-000006:mdna:238]
| • | $168 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2018, as compared to $82 million in 2017; |

[0000068505-20-000006:mdna:239]
| • | $337 million of cash used for the payment of dividends in 2018 as compared to $307 million in 2017; and |

[0000068505-20-000006:mdna:240]
| • | partially offset by $132 million used for purchases under our share repurchase program in 2018 as compared to $483 million in 2017. |

[0000068505-20-000006:mdna:241]
38

[0000068505-20-000006:mdna:242]
Sales of Receivables

[0000068505-20-000006:mdna:243]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-20-000006:mdna:244]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2019, 2018, and 2017:

[0000068505-20-000006:mdna:245]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| Accounts receivable sales proceeds | $ | 34 |  |  | $ | 77 |  |  | $ | 193 |  |
| Long-term receivables sales proceeds | 265 |  |  | 270 |  |  | 284 |  |
| Total proceeds from receivable sales | $ | 299 |  |  | $ | 347 |  |  | $ | 477 |  |

[0000068505-20-000006:mdna:246]
The proceeds of our receivable sales are included in "Operating Activities" within our Consolidated Statements of Cash Flows.

[0000068505-20-000006:mdna:247]
At December 31, 2019, the Company had retained servicing obligations for $984 million of long-term receivables, compared to $970 million of long-term receivables at December 31, 2018. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-20-000006:mdna:248]
Debt

[0000068505-20-000006:mdna:249]
We had outstanding long-term debt of $5.1 billion and $5.3 billion, including the current portions of $16 million and $31 million, at December 31, 2019 and December 31, 2018, respectively.

[0000068505-20-000006:mdna:250]
In February of 2018, we issued $500 million of 4.60% senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan. In October of 2018, we issued an additional $200 million on the outstanding 4.6% senior notes bringing the total outstanding principal to $700 million. We recognized net proceeds of $196 million after debt issuance costs and debt discounts.

[0000068505-20-000006:mdna:251]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million with a maturity date of March 26, 2021 (the "Term Loan"). The interest on the Term Loan was variable, indexed to the London Inter-bank Offered Rate ("LIBOR"), and paid monthly. The weighted average borrowing rate for amounts outstanding during the year ended December 31, 2019 was 3.68%.  We repaid all amounts borrowed under the Term Loan during the year ended December 31, 2019.

[0000068505-20-000006:mdna:252]
In May of 2019, we issued $650 million of 4.60% senior notes due 2029. We received proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of our outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of approximately $43 million related to this repurchase in Other within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-20-000006:mdna:253]
In August of 2019, we issued a follow-on $150 million to the outstanding 4.60% senior notes due 2029 bringing the total outstanding principal to $800 million. We recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding approximately $2 million of accrued interest. After accelerating the amortization of debt issuance costs, we recognized a loss of approximately $7 million related to this repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-20-000006:mdna:254]
In 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% senior convertible notes which mature in September 2020 ("Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. The notes were convertible based on a conversion rate that may be adjusted for dividends declared and automatically adjusts the exercise price. In October of 2018, we repurchased $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium.

[0000068505-20-000006:mdna:255]
As of the third quarter of 2019, the remaining notes were convertible based on a conversion rate of rate of 14.9186, adjusted for dividends declared, per $1,000 principal amount (equal to a conversion price of $67.03 per share). On September 5, 2019, we entered into an agreement with Silver Lake Partners to settle the remaining $800 million in principal amount of the Senior Convertible Notes in two installments: (i) $200 million of notes were repurchased during the third quarter for an aggregate consideration of $526 million in cash, inclusive of the conversion premium and (ii) $600 million of principal paid in cash on October 7, 2019, and delivered 5.5 million shares of common stock on September 5, 2019 to settle the conversion premium. We recognized a gain of $4 million from the extinguishment of the 2.00% senior convertible notes in Other, net within other income (expense) in the Consolidated Statement of Operations.

[0000068505-20-000006:mdna:256]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, we intend to settle the principal amount of the New Senior Convertible Notes in cash. We recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was

[0000068505-20-000006:mdna:257]
determined based on a review of relevant market data, we calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital.

[0000068505-20-000006:mdna:258]
During the third quarter of 2019, we established an unsecured commercial paper program, backed by the revolving credit facility, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time.  Proceeds from the issuances of the notes are expected to be used for general corporate purposes.  As of December 31, 2019 we had no outstanding debt under the commercial paper program.

[0000068505-20-000006:mdna:259]
We believe that we hold sufficient liquidity to cover the day-to-day operations of our business as well as any future volatility or uncertainty that may arise in the capital markets.

[0000068505-20-000006:mdna:260]
Credit Facilities

[0000068505-20-000006:mdna:261]
As of December 31, 2019, we had a $2.2 billion unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, we borrowed $400 million under the facility to complete the Avigilon acquisition. The entire $400 million was re-paid during the year ended December 31, 2018. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2019. No letters of credit were issued under the revolving credit facility as of December 31, 2019.

[0000068505-20-000006:mdna:262]
Share Repurchase Program

[0000068505-20-000006:mdna:263]
Through a series of actions, the board of directors has authorized an aggregate share repurchase amount of up to $14.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2019, we have used approximately $12.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $1.3 billion of authority available for future repurchases.

[0000068505-20-000006:mdna:264]
Our share repurchases, including transaction costs, for 2019, 2018, and 2017 can be summarized as follows:

[0000068505-20-000006:mdna:265]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Aggregate Amount (in millions) |
| 2019 | 2.3 |  |  | $ | 137.35 |  |  | $ | 315 |  |
| 2018 | 1.2 |  |  | 112.42 |  |  | 132 |  |
| 2017 | 5.7 |  |  | 85.32 |  |  | 483 |  |

[0000068505-20-000006:mdna:266]
Dividends

[0000068505-20-000006:mdna:267]
We paid cash dividends to holders of our common stock of $379 million in 2019, $337 million in 2018, and $307 million in 2017. On January 15, 2020, we paid an additional $109 million in cash dividends to holders of our common stock.

[0000068505-20-000006:mdna:268]
Adequate Internal Funding Resources

[0000068505-20-000006:mdna:269]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the $2.2 billion revolving credit facility.

[0000068505-20-000006:mdna:270]
Contractual Obligations and Other Purchase Commitments

[0000068505-20-000006:mdna:271]
Summarized in the table and text below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2019.

[0000068505-20-000006:mdna:272]
|  | Payments Due by Period |
| (in millions) | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations, gross | $ | 5,189 |  |  | $ | 16 |  |  | $ | 4 |  |  | $ | 562 |  |  | $ | 603 |  |  | $ | 1,600 |  |  | $ | — |  |  | $ | 2,404 |  |
| Lease obligations | 713 |  |  | 143 |  |  | 129 |  |  | 114 |  |  | 62 |  |  | 55 |  |  | — |  |  | 210 |  |
| Purchase obligations* | 142 |  |  | 95 |  |  | 32 |  |  | 8 |  |  | 5 |  |  | 2 |  |  | — |  |  | — |  |
| Tax obligations | 70 |  |  | 7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 63 |  |  | — |  |
| Total contractual obligations | $ | 6,114 |  |  | $ | 261 |  |  | $ | 165 |  |  | $ | 684 |  |  | $ | 670 |  |  | $ | 1,657 |  |  | $ | 63 |  |  | $ | 2,614 |  |

[0000068505-20-000006:mdna:273]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-20-000006:mdna:274]
Lease Obligations:  We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations totaled $713 million. Rental expense, net of sublease income, was $133 million in 2019, $108 million in 2018, and $94 million in 2017.

[0000068505-20-000006:mdna:275]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. In addition, we have entered into license agreements which are firm commitments and are not cancelable. We had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2024. The total payments expected to be made under these agreements are $142 million. We do not anticipate the cancellation of any of our take-or-pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-20-000006:mdna:276]
Tax Obligations:  We have approximately $70 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $7 million tax charge to a $27 million tax benefit, with cash payments not expected to exceed $20 million.

[0000068505-20-000006:mdna:277]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take-or-pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-20-000006:mdna:278]
We outsource certain corporate functions, such as benefit administration and information technology-related services, under third-party contracts, the longest of which is expected to expire in 2023. Our remaining payments under these contracts are approximately $48 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in penalties substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-20-000006:mdna:279]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance bonds, bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. Outstanding Performance Bonds totaled approximately $2.5 billion as of December 31, 2019 and December 31, 2018. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-20-000006:mdna:280]
Off-Balance Sheet Arrangements:  At December 31, 2019, we had no significant off-balance sheet arrangements other than our obligation to settle the conversion option under the New Senior Convertible Notes described in Note 5 to the consolidated financial statements.

[0000068505-20-000006:mdna:281]
Other Contingencies

[0000068505-20-000006:mdna:282]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-20-000006:mdna:283]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us. Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 18 months, and for amounts not in excess of a percentage of the contract value.

[0000068505-20-000006:mdna:284]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on our results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-20-000006:mdna:285]
Long-term Customer Financing Commitments

[0000068505-20-000006:mdna:286]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $78 million at December 31, 2019, compared to $62 million at December 31, 2018.

[0000068505-20-000006:mdna:287]
Critical Accounting Policies

[0000068505-20-000006:mdna:288]
Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-20-000006:mdna:289]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-20-000006:mdna:290]
Revenue Recognition

[0000068505-20-000006:mdna:291]
We enter into arrangements which consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we generally allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-20-000006:mdna:292]
We account for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, we have determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on our customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-20-000006:mdna:293]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of

[0000068505-20-000006:mdna:294]
42

[0000068505-20-000006:mdna:295]
open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-20-000006:mdna:296]
Retirement Benefits

[0000068505-20-000006:mdna:297]
Our benefit obligations and net periodic pension costs (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions.  The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-20-000006:mdna:298]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-20-000006:mdna:299]
There are various assumptions used in calculating the net periodic costs (benefits) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.   We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-20-000006:mdna:300]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost and the net retirement health care expense. Our investment return assumption for the U.S. Pension Benefit Plans was 6.85% in 2019 and 6.95% 2018. Our investment return assumption for the Postretirement Health Care Benefits Plan was 6.90% in 2019 and 7.00% 2018. Our weighted average investment return assumption for the Non-U.S. Plans was 5.23% in 2019 and 5.18% in 2018.

[0000068505-20-000006:mdna:301]
A second key assumption is the discount rate. The discount rate assumptions used for pension benefits and Postretirement Health Care Benefits Plan reflects, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 3.32% and 4.47% at December 2019 and 2018, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 1.82% and 2.67% at December 2019 and 2018, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 3.15% and 4.29% at December 31, 2019 and 2018, respectively.

[0000068505-20-000006:mdna:302]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from ten to thirty-one years. Prior service costs are being amortized over periods ranging from two to five years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-20-000006:mdna:303]
Valuation and Recoverability of Goodwill

[0000068505-20-000006:mdna:304]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: adverse changes in macroeconomic conditions, adverse changes in the industry or market in which we transact, changes in cost factors negatively impacting earnings and cash flows, negative or declining overall financial performance, events affecting the carrying value or composition of a reporting unit, or a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-20-000006:mdna:305]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Software and Services segments are comprised of three and two reporting units, respectively. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors,

[0000068505-20-000006:mdna:306]
overall financial performance, changes in enterprise value, and entity-specific events. For fiscal years 2019, 2018, and 2017, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-20-000006:mdna:307]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-20-000006:mdna:308]
We use the asset and liability method of accounting for income taxes. Under this method, income tax expense is recognized for the amount of taxes payable or refundable for the current year.  In addition, deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Management makes assumptions, judgments and estimates to determine our current and deferred tax provision and also the deferred tax assets and liabilities. We evaluate our deferred tax assets quarterly to determine if adjustments to our valuation allowance are required based on the consideration of all available positive and negative evidence.

[0000068505-20-000006:mdna:309]
Our assumptions, judgments and estimates for computing the income tax provision takes into account current tax laws, our interpretation of current tax law and possible outcomes of current and future audits conducted by foreign and domestic tax authorities. We believe such estimates to be reasonable; however, the final determination of certain audits could significantly impact the amounts provided for income taxes in our financial statements.

[0000068505-20-000006:mdna:310]
Recent Accounting Pronouncements

[0000068505-20-000006:mdna:311]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and simplifying other areas of accounting for income taxes.  The ASU is effective for the Company on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  We are still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-20-000006:mdna:312]
In August 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-20-000006:mdna:313]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” ASU No. 2019-05, “Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” and ASU No. 2019-11, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for us on January 1, 2020.  We do not believe there will be a material impact to the financial statements as a result of adoption.

[0000068505-20-000006:mdna:314]
Recently Adopted Accounting Pronouncements

[0000068505-20-000006:mdna:315]
We adopted ASU No. 2016-02, “Leases,” and all the related amendments (collectively “ASC 842”) on January 1, 2019.  ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases are classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-20-000006:mdna:316]
ASC 842 provides for a number of optional practical expedients in transition. We elected the practical expedients, which permit us to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. We did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing us to carry forward the lease term as determined prior to adoption of ASC 842. Finally, we also elected the practical expedient related to land easements, which enabled us to continue our accounting treatment for land easements on existing agreements as of January 1, 2019.

[0000068505-20-000006:mdna:317]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. We elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows us to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with our prior accounting. We also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

[0000068505-20-000006:mdna:318]
As of January 1, 2019, we recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition.

[0000068505-20-000006:mdna:319]
For arrangements where we are the lessor, the adoption of ASC 842 did not have a material impact on our financial statements as the majority of our leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease

[0000068505-20-000006:mdna:320]
components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. We have elected the above practical expedient and determined that non-lease components are predominant and, accordingly, are accounting for the single components as managed service contracts under ASC Topic 606.

[0000068505-20-000006:mdna:321]
We adopted ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" on December 1, 2018, using the modified retrospective method of adoption. The ASU requires a cumulative effect adjustment to the opening balance of retained earnings as of the beginning of the fiscal year of adoption for the previously recorded ineffectiveness included in retained earnings related to existing net investment hedges as of the date of adoption. We did not record a cumulative effect adjustment to retained earnings as no net investment hedges existed as of the ASU adoption date. New hedging relationships entered after the adoption date have been presented in the financial statements using the guidance of the ASU. There were no material changes to our financial statements from the adoption of the ASU.

[0000068505-20-000006:mdna:322]
We adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, we recognize tax expense when intra-entity transfers of assets other than inventory occur.  We recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to our opening retained earnings balance. During the three months ended December 31, 2019, we identified an error in the amounts originally recorded when adopting ASU 2016-16.  We recorded an out-of-period correction of $30 million to deferred income tax assets in the Consolidated Balance Sheets and retained earnings in the Consolidated Statements of Stockholders' Equity. The adjustment did not have a material impact on the Consolidated Balance Sheets or Consolidated Statements of Stockholders’ Equity for any period presented.

[0000068505-20-000006:mdna:323]
We adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. We have restated our comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of our net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. We reclassified $78 million of benefits, $75 million of benefit, and $2 million of expense in the years ended December 31, 2019, 2018 and 2017, respectively, within Other in Other income (expense) accordingly.

[0000068505-20-000006:mdna:324]
We adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to our opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-20-000006:mdna:325]
We have retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of our Systems and Systems Integration contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as we stand ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-20-000006:mdna:326]
Under the new standard, we identified distinct promises to transfer goods and services within our contracts. For system contracts that are recognized under percentage-of-completion accounting, we have considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, the adoption of the new standard impacts our system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within our system contracts, we continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-20-000006:mdna:327]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings in 2018.

[0000068505-20-000006:mdna:328]
In 2017, we presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, we have determined that we are the principal in contracts that involve a third-party sales representative. Thus, under the new standard, we present associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for our cost of third-party commissions.

[0000068505-20-000006:mdna:329]
45

[0000068505-20-000006:mdna:330]
Under prior accounting standards, we expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, we capitalize sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-20-000006:mdna:331]
The new standard clarified the definition of a receivable and requires us to present our net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which we have received, or are due, consideration from a customer. We reclassified our customer positions to align with the new definitions and presentation guidance.

[0000068505-20-000006:mdna:332]
Forward-Looking Statements

[0000068505-20-000006:mdna:333]
Some of the risk factors that affect our business and financial results are discussed in “Item 1A: Risk Factors.” We caution the reader that the risk factors discussed in “Item 1A: Risk Factors,” and those described elsewhere in this report or in our other Securities and Exchange Commission filings, could cause our actual results to differ materially from those stated in the forward-looking statements.

[0000068505-20-000006:mdna:334]
46
