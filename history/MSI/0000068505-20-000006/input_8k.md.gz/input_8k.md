# MSI 8-K — 0000068505-20-000003 filed 2020-02-06

## item codes, every 8-K on or before 2020-02-14

- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2020-02-14

- none on or before 2020-02-14

## item 2.02 — earnings release, exhibit 99.1

[0000068505-20-000003:8k_2_02:1]
EX-99.1
2
msiq42019pressrelease.htm
EXHIBIT 99.1

[0000068505-20-000003:8k_2_02:2]
Exhibit

[0000068505-20-000003:8k_2_02:3]
Exhibit 99.1

[0000068505-20-000003:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-20-000003:8k_2_02:5]
Record 2019 sales, cash flow and backlog bolstered by strong fourth-quarter results

[0000068505-20-000003:8k_2_02:6]
| • | Revenue of $2.4 billion, up 5% from Q4 in the prior year; up 7% for full year |

[0000068505-20-000003:8k_2_02:7]
| • | Record backlog of $11.3 billion, up $659 million or 6% from a year ago |

[0000068505-20-000003:8k_2_02:8]
| • | GAAP earnings per share (EPS) of $1.39, inclusive of a $1.53 per share non-cash charge related to US pension de-risking; $4.95 for full year |

[0000068505-20-000003:8k_2_02:9]
| • | Non-GAAP EPS* of $2.94, up 12%; $7.96 for full year, up 11% |

[0000068505-20-000003:8k_2_02:10]
| • | Generated $795 million in operating cash flow in the quarter; $1.8 billion for full year |

[0000068505-20-000003:8k_2_02:11]
CHICAGO - Feb. 6, 2020 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2019. Click here for a printable news release and financial tables.

[0000068505-20-000003:8k_2_02:12]
“Our strong Q4 results capped another year of record sales, cash flow and backlog," said Greg Brown, chairman and CEO of Motorola Solutions. “Our momentum, particularly in video security and software & services, positions us well for another strong year."

[0000068505-20-000003:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-20-000003:8k_2_02:14]
|  | Fourth Quarter | Full Year |
|  | Q4 2019 |  | Q4 2018 |  | % Change | 2019 |  | 2018 |  | % Change |
| Sales | $2,377 | $2,254 | 5 | % | $7,887 | $7,343 | 7 | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $590 | $516 | 14 | % | $1,581 | $1,255 | 26 | % |
| % of Sales | 24.8 | % | 22.9 | % |  | 20.0 | % | 17.1 | % |  |
| EPS | $1.39 | $2.44 | (43 | )% | $4.95 | $5.62 | (12 | )% |
| Non-GAAP* |  |  |  |  |  |  |
| Operating Earnings | $707 | $650 | 9 | % | $1,975 | $1,740 | 14 | % |
| % of Sales | 29.7 | % | 28.8 | % |  | 25.0 | % | 23.7 | % |  |
| EPS | $2.94 | $2.63 | 12 | % | $7.96 | $7.15 | 11 | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $1,673 | $1,670 | — | % | $5,329 | $5,100 | 5 | % |
| GAAP Operating Earnings | $426 | $405 | 5 | % | $994 | $854 | 16 | % |
| % of Sales | 25.5 | % | 24.3 | % |  | 18.7 | % | 16.7 | % |  |
| Non-GAAP Operating Earnings* | $484 | $483 | — | % | $1,173 | $1,109 | 6 | % |
| % of Sales | 28.9 | % | 28.9 | % |  | 22.0 | % | 21.7 | % |  |
| Software and Services Segment |  |  |  |  |  |  |
| Sales | $704 | $584 | 21 | % | $2,558 | $2,243 | 14 | % |
| GAAP Operating Earnings | $164 | $111 | 48 | % | $587 | $401 | 46 | % |
| % of Sales | 23.3 | % | 19.0 | % |  | 22.9 | % | 17.9 | % |  |
| Non-GAAP Operating Earnings* | $223 | $167 | 34 | % | $802 | $631 | 27 | % |
| % of Sales | 31.7 | % | 28.6 | % |  | 31.4 | % | 28.1 | % |  |

[0000068505-20-000003:8k_2_02:15]
*Q4 Non-GAAP financial information excludes the after-tax impact of approximately $1.55 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-20-000003:8k_2_02:16]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-20-000003:8k_2_02:17]
| • | Revenue - Fourth-quarter revenue was $2.4 billion, up $123 million or 5% primarily on strength in the Americas. Revenue from acquisitions was $82 million and currency headwinds were $17 million. The Products and Systems Integration segment was flat with growth in the Americas and AsiaPac offset by declines in EMEA related to large LMR deployments in the Middle East and Africa in the prior year. The Software and Services segment grew 21% with growth in all regions. |

[0000068505-20-000003:8k_2_02:18]
| • | Operating earnings - GAAP operating margin was 24.8% of sales compared with 22.9% in the year-ago quarter driven by higher sales and gross margin in the current quarter and higher costs related to the closure of certain supply chain operations in Europe in the prior year, partially offset by higher operating expenses related to acquisitions. Non-GAAP operating margin was 29.7% of sales, up from 28.8% in the year-ago quarter due to higher sales and gross margins, partially offset by higher operating expenses related to acquisitions. |

[0000068505-20-000003:8k_2_02:19]
| • | Other charges - The company de-risked $1 billion in pension obligations through a lump-sum window offered to certain participants of the U.S. Pension Plan. Approximately $836 million was paid out of pension plan assets to the participants who elected lump sums as part of this offer. The Company recorded a non-cash GAAP charge of $359 million in 2019 as a result of this initiative, representing the write-off of pension losses previously deferred within equity. |

[0000068505-20-000003:8k_2_02:20]
| • | Taxes - The GAAP effective tax rate was (26.4)%, compared to 8.8% in the year-ago quarter. The year over year decline in the GAAP rate was primarily due to lower profit before tax as a result of the $359 million U.S. pension settlement charge taken in the current quarter. The Non-GAAP effective tax rate was 22%, compared to 23.5% in the year-ago quarter. |

[0000068505-20-000003:8k_2_02:21]
| • | Cash flow - The company generated $795 million in operating cash, compared with $812 million in the year-ago quarter. Free cash flow was $736 million, compared with $743 million in the year-ago quarter. The year over year decline in cash flow was primarily driven by changes in working capital in the current quarter, partially offset by higher operating earnings in the current quarter. |

[0000068505-20-000003:8k_2_02:22]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-20-000003:8k_2_02:23]
| • | Revenue - Full-year revenue was $7.9 billion, up $544 million, or 7% driven by growth in the Americas. Revenue from acquisitions was $312 million and currency headwinds were $113 million. The Products and Systems Integration segment grew 5% driven by the Americas. The Software and Services segment grew 14% driven by growth in the Americas and EMEA. |

[0000068505-20-000003:8k_2_02:24]
| • | Operating earnings - For the full year, GAAP operating margin was 20% of revenue, compared with 17.1% for the prior year. The increase was primarily driven by higher revenue and gross margin in the current year as well as an increase to an existing environmental reserve related to a legacy business booked in the prior year, partially offset by higher operating expenses related to acquisitions in the current year. Non-GAAP operating margin was 25% of revenue, compared with 23.7% for the prior year, driven by higher revenue and gross margin, partially offset by higher operating expenses related to acquisitions. |

[0000068505-20-000003:8k_2_02:25]
| • | Taxes - The 2019 GAAP effective tax rate was 13%, compared to 12% for the prior year. The Non-GAAP effective tax rate was 22.4% compared with 21.7% in the previous year. |

[0000068505-20-000003:8k_2_02:26]
| • | Cash flow - The company generated $1.8 billion in operating cash, up $748 million from the prior year. Free cash flow was $1.6 billion, up $697 million from the prior year. The increase in cash flow was driven by the impact of the $500 million debt funded pension contribution made in Q1 2018 and higher revenue and associated operating earnings in the current year. |

[0000068505-20-000003:8k_2_02:27]
| • | Backlog - The company ended the quarter with record backlog of $11.3 billion, up $659 million from the year-ago quarter. Software and Services segment backlog was up 9% or $699 million, primarily driven by growth in the Americas and the extension of the ESN contract. Products and |

[0000068505-20-000003:8k_2_02:28]
System Integrations segment backlog was down 1% or $40 million due to declines in EMEA and AsiaPac, partially offset by growth in the Americas.

[0000068505-20-000003:8k_2_02:29]
| • | Capital Allocation - The company invested $709 million in acquisitions, paid $379 million in dividends, and repurchased $315 million of its common stock at an average price of $137.35 per share. |

[0000068505-20-000003:8k_2_02:30]
NOTABLE WINS & ACHIEVEMENTS

[0000068505-20-000003:8k_2_02:31]
Software and Services

[0000068505-20-000003:8k_2_02:32]
| • | $68 million P25 multi-year service contract with State of Victoria, Australia |

[0000068505-20-000003:8k_2_02:33]
| • | $29 million P25 multi-year service contract with the state of Connecticut |

[0000068505-20-000003:8k_2_02:34]
| • | $24 million P25 multi-year service contract with the U.S. Navy |

[0000068505-20-000003:8k_2_02:35]
| • | $8 million for a Command Center Software suite order from Tulare County, California |

[0000068505-20-000003:8k_2_02:36]
| • | $6 million for a Command Center Software suite order from Irvine, California |

[0000068505-20-000003:8k_2_02:37]
| • | $6 million for a Computer Aided Dispatch system for city of Atlanta, Georgia |

[0000068505-20-000003:8k_2_02:38]
Products and Systems Integration

[0000068505-20-000003:8k_2_02:39]
| • | $64 million P25 order for the State of Arkansas |

[0000068505-20-000003:8k_2_02:40]
| • | $36 million P25 order for Thurston County, Washington |

[0000068505-20-000003:8k_2_02:41]
| • | $24 million P25 order for Luzerne County, Pennsylvania |

[0000068505-20-000003:8k_2_02:42]
| • | $5 million in fixed video security wins for government customers |

[0000068505-20-000003:8k_2_02:43]
| • | Launched APX Next, our next-generation P25 radio |

[0000068505-20-000003:8k_2_02:44]
| • | Launched Avigilon AI-powered H5 camera line |

[0000068505-20-000003:8k_2_02:45]
BUSINESS OUTLOOK

[0000068505-20-000003:8k_2_02:46]
| • | First-quarter 2020 - The Company expects revenue growth of approximately 2% compared with the first quarter of 2019. The company expects non-GAAP earnings per share in the range of $1.30 to $1.35 per share. This assumes current foreign exchange rates, approximately 176 million fully diluted shares, and a 20% effective tax rate. |

[0000068505-20-000003:8k_2_02:47]
| • | Full-year 2020 - The company expects revenue growth of approximately 4% and non-GAAP earnings per share in the range of $8.65 to $8.80 per share. This assumes current foreign exchange rates, between 176 and 177 million fully diluted shares and a non-GAAP effective tax rate of approximately 23%. |

[0000068505-20-000003:8k_2_02:48]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) Thursday, Feb 6. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0000068505-20-000003:8k_2_02:49]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-20-000003:8k_2_02:50]
A comparison of results from operations is as follows:

[0000068505-20-000003:8k_2_02:51]
|  | Fourth Quarter | Full Year |
|  | 2019 | 2018 | 2019 | 2018 |
| Net sales | $2,377 | $2,254 | $7,887 | $7,343 |
| Gross margin | 1,220 |  | 1,088 |  | 3,931 |  | 3,480 |  |
| Operating earnings | 590 |  | 516 |  | 1,581 |  | 1,255 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | 244 |  | 423 |  | 868 |  | 966 |  |
| Diluted EPS from continuing operations | $1.39 | $2.44 | $4.95 | $5.62 |
| Weighted average diluted common shares outstanding | 175.6 |  | 173.4 |  | 175.6 |  | 172.0 |  |

[0000068505-20-000003:8k_2_02:52]
HIGHLIGHTED ITEMS

[0000068505-20-000003:8k_2_02:53]
The table below includes specific share-based compensation expense, intangible amortization, and other highlighted items for the fourth-quarter of 2019.

[0000068505-20-000003:8k_2_02:54]
| (per diluted common share) | Q4 2019 |  |
| GAAP Earnings | $1.39 |
| Highlighted Items: |  |
| US pension settlement loss | 1.53 |  |
| Intangibles amortization expense | 0.24 |  |
| Share-based compensation expense | 0.14 |  |
| Reorganization of business charges | 0.08 |  |
| Legal settlements | 0.04 |  |
| Operating lease asset impairment | 0.02 |  |
| Investment impairments | 0.01 |  |
| Sale of investments | (0.01 | ) |
| Release of uncertain tax positions | (0.03 | ) |
| Fair value adjustments to equity investments | (0.03 | ) |
| Release of valuation allowance on deferred tax assets | (0.44 | ) |
| Non-GAAP Diluted EPS | $2.94 |

[0000068505-20-000003:8k_2_02:55]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-20-000003:8k_2_02:56]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-20-000003:8k_2_02:57]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-20-000003:8k_2_02:58]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-20-000003:8k_2_02:59]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-20-000003:8k_2_02:60]
Free cash flow:  Free cash flow represents operating cash flow less capital expenditures. We believe that free cash flow is also useful to investors as the basis for comparing our performance and coverage ratios with other companies in our industries, although our measure of free cash flow may not be directly comparable to similar measures used by other companies.

[0000068505-20-000003:8k_2_02:61]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes non-GAAP organic revenue growth provides useful information for evaluating the periodic growth of the business on a

[0000068505-20-000003:8k_2_02:62]
consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-20-000003:8k_2_02:63]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-20-000003:8k_2_02:64]
The company has not quantitatively reconciled its guidance for non-GAAP metrics to their most comparable GAAP measure because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-20-000003:8k_2_02:65]
BUSINESS RISKS

[0000068505-20-000003:8k_2_02:66]
representatives; (11) the impact on the company's performance and financial results from strategic acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its 1.75% senior convertible notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-20-000003:8k_2_02:67]
ABOUT MOTOROLA SOLUTIONS

[0000068505-20-000003:8k_2_02:68]
Motorola Solutions is a global leader in mission-critical communications and analytics. Our technology platforms in mission-critical communications, command center software, video security & analytics, bolstered by managed & support services, make cities safer and help communities and businesses thrive. At Motorola Solutions, we are ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com

[0000068505-20-000003:8k_2_02:69]
MEDIA CONTACT

[0000068505-20-000003:8k_2_02:70]
Kate Dyer

[0000068505-20-000003:8k_2_02:71]
Motorola Solutions

[0000068505-20-000003:8k_2_02:72]
+1 224-374-3124

[0000068505-20-000003:8k_2_02:73]
Kate.Dyer@motorolasolutions.com

[0000068505-20-000003:8k_2_02:74]
INVESTOR CONTACT

[0000068505-20-000003:8k_2_02:75]
Tim Yocum

[0000068505-20-000003:8k_2_02:76]
Motorola Solutions

[0000068505-20-000003:8k_2_02:77]
+1 847-576-6899

[0000068505-20-000003:8k_2_02:78]
Tim.Yocum@motorolasolutions.com

[0000068505-20-000003:8k_2_02:79]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2020 Motorola Solutions, Inc. All rights reserved.

[0000068505-20-000003:8k_2_02:80]
GAAP-1

[0000068505-20-000003:8k_2_02:81]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:82]
Consolidated Statements of Operations

[0000068505-20-000003:8k_2_02:83]
(In millions, except per share amount)

[0000068505-20-000003:8k_2_02:84]
|  | Three Months Ended |
|  | December 31, 2019 |  | December 31, 2018 |
| Net sales from products | $ | 1,507 |  |  | $ | 1,470 |  |
| Net sales from services | 870 |  |  | 784 |  |
| Net sales | 2,377 |  |  | 2,254 |  |
| Costs of products sales | 621 |  |  | 652 |  |
| Costs of services sales | 536 |  |  | 514 |  |
| Costs of sales | 1,157 |  |  | 1,166 |  |
| Gross margin | 1,220 |  |  | 1,088 |  |
| Selling, general and administrative expenses | 368 |  |  | 337 |  |
| Research and development expenditures | 182 |  |  | 165 |  |
| Other charges | 26 |  |  | 22 |  |
| Intangibles amortization | 54 |  |  | 48 |  |
| Operating earnings | 590 |  |  | 516 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (55 | ) |  | (59 | ) |
| Gains on sales of investments and businesses, net | 1 |  |  | — |  |
| Other | (343 | ) |  | 7 |  |
| Total other expense | (397 | ) |  | (52 | ) |
| Net earnings before income taxes | 193 |  |  | 464 |  |
| Income tax expense (benefit) | (51 | ) |  | 40 |  |
| Net earnings | 244 |  |  | 424 |  |
| Less: Earnings attributable to noncontrolling interests | — |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 244 |  |  | $ | 423 |  |
| Earnings per common share: |  |  |  |
| Basic: | $ | 1.43 |  |  | $ | 2.58 |  |
| Diluted: | $ | 1.39 |  |  | $ | 2.44 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 170.9 |  |  | 163.5 |  |
| Diluted | 175.6 |  |  | 173.4 |  |

[0000068505-20-000003:8k_2_02:85]
|  | Percentage of Net Sales* |
| Net sales from products | 63.4 | % |  | 65.2 | % |
| Net sales from services | 36.6 | % |  | 34.8 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.2 | % |  | 44.4 | % |
| Costs of services sales | 61.6 | % |  | 65.6 | % |
| Costs of sales | 48.7 | % |  | 51.7 | % |
| Gross margin | 51.3 | % |  | 48.3 | % |
| Selling, general and administrative expenses | 15.5 | % |  | 15.0 | % |
| Research and development expenditures | 7.7 | % |  | 7.3 | % |
| Other charges | 1.1 | % |  | 1.0 | % |
| Intangibles amortization | 2.3 | % |  | 2.1 | % |
| Operating earnings | 24.8 | % |  | 22.9 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.3 | )% |  | (2.6 | )% |
| Gains on sales of investments and businesses, net | — | % |  | — | % |
| Other | (14.4 | )% |  | 0.3 | % |
| Total other expense | (16.7 | )% |  | (2.3 | )% |
| Net earnings before income taxes | 8.1 | % |  | 20.6 | % |
| Income tax expense (benefit) | (2.1 | )% |  | 1.8 | % |
| Net earnings | 10.3 | % |  | 18.8 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 10.3 | % |  | 18.8 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-20-000003:8k_2_02:86]
GAAP-2

[0000068505-20-000003:8k_2_02:87]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:88]
Consolidated Statements of Operations

[0000068505-20-000003:8k_2_02:89]
(In millions, except per share amounts)

[0000068505-20-000003:8k_2_02:90]
|  | Years Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2017 |
| Net sales from products | $ | 4,746 |  |  | $ | 4,463 |  |  | $ | 3,772 |  |
| Net sales from services | 3,141 |  |  | 2,880 |  |  | 2,608 |  |
| Net sales | 7,887 |  |  | 7,343 |  |  | 6,380 |  |
| Costs of products sales | 2,049 |  |  | 2,035 |  |  | 1,686 |  |
| Costs of services sales | 1,907 |  |  | 1,828 |  |  | 1,670 |  |
| Costs of sales | 3,956 |  |  | 3,863 |  |  | 3,356 |  |
| Gross margin | 3,931 |  |  | 3,480 |  |  | 3,024 |  |
| Selling, general and administrative expenses | 1,403 |  |  | 1,254 |  |  | 1,025 |  |
| Research and development expenditures | 687 |  |  | 637 |  |  | 568 |  |
| Other charges (income) | 52 |  |  | 146 |  |  | (4 | ) |
| Intangibles amortization | 208 |  |  | 188 |  |  | 151 |  |
| Operating earnings | 1,581 |  |  | 1,255 |  |  | 1,284 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (220 | ) |  | (222 | ) |  | (201 | ) |
| Gains on sales of investments and businesses, net | 5 |  |  | 16 |  |  | 3 |  |
| Other | (365 | ) |  | 53 |  |  | (10 | ) |
| Total other expense | (580 | ) |  | (153 | ) |  | (208 | ) |
| Net earnings before income taxes | 1,001 |  |  | 1,102 |  |  | 1,076 |  |
| Income tax expense | 130 |  |  | 133 |  |  | 1,227 |  |
| Net earnings (loss) | 871 |  |  | 969 |  |  | (151 | ) |
| Less: Earnings attributable to noncontrolling interests | 3 |  |  | 3 |  |  | 4 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 868 |  |  | $ | 966 |  |  | $ | (155 | ) |
| Earnings (loss) per common share: |  |  |  |  |  |
| Basic: | 5.21 |  |  | 5.95 |  |  | (0.95 | ) |
| Diluted: | 4.95 |  |  | 5.62 |  |  | (0.95 | ) |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 166.6 |  |  | 162.4 |  |  | 162.9 |  |
| Diluted | 175.6 |  |  | 172.0 |  |  | 162.9 |  |

[0000068505-20-000003:8k_2_02:91]
|  | Percentage of Net Sales* |
| Net sales from products | 60.2 | % |  | 60.8 | % |  | 59.1 | % |
| Net sales from services | 39.8 | % |  | 39.2 | % |  | 40.9 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 43.2 | % |  | 45.6 | % |  | 44.7 | % |
| Costs of services sales | 60.7 | % |  | 63.5 | % |  | 64.0 | % |
| Costs of sales | 50.2 | % |  | 52.6 | % |  | 52.6 | % |
| Gross margin | 49.8 | % |  | 47.4 | % |  | 47.4 | % |
| Selling, general and administrative expenses | 17.8 | % |  | 17.1 | % |  | 16.1 | % |
| Research and development expenditures | 8.7 | % |  | 8.7 | % |  | 8.9 | % |
| Other charges | 0.7 | % |  | 2.0 | % |  | (0.1 | )% |
| Intangibles amortization | 2.6 | % |  | 2.6 | % |  | 2.4 | % |
| Operating earnings | 20.0 | % |  | 17.1 | % |  | 20.1 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (2.8 | )% |  | (3.0 | )% |  | (3.2 | )% |
| Gains on sales of investments and businesses, net | 0.1 | % |  | 0.2 | % |  | — | % |
| Other | (4.6 | )% |  | 0.7 | % |  | (0.2 | )% |
| Total other expense | (7.4 | )% |  | (2.1 | )% |  | (3.3 | )% |
| Net earnings before income taxes | 12.7 | % |  | 15.0 | % |  | 16.9 | % |
| Income tax expense | 1.6 | % |  | 1.8 | % |  | 19.2 | % |
| Net earnings (loss) | 11.0 | % |  | 13.2 | % |  | (2.4 | )% |
| Less: Earnings attributable to noncontrolling interests | — | % |  | — | % |  | 0.1 | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | 11.0 | % |  | 13.2 | % |  | (2.4 | )% |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-20-000003:8k_2_02:92]
GAAP-3

[0000068505-20-000003:8k_2_02:93]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:94]
Consolidated Balance Sheets

[0000068505-20-000003:8k_2_02:95]
(In millions)

[0000068505-20-000003:8k_2_02:96]
|  |  | December 31, 2019 |  | December 31, 2018 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,001 |  |  | $ | 1,257 |  |
| Accounts receivable, net |  | 1,412 |  |  | 1,293 |  |
| Contract assets |  | 1,046 |  |  | 1,012 |  |
| Inventories, net |  | 447 |  |  | 356 |  |
| Other current assets |  | 272 |  |  | 354 |  |
| Total current assets |  | 4,178 |  |  | 4,272 |  |
| Property, plant and equipment, net |  | 992 |  |  | 895 |  |
| Operating lease assets |  | 554 |  |  | — |  |
| Investments |  | 159 |  |  | 169 |  |
| Deferred income taxes |  | 943 |  |  | 985 |  |
| Goodwill |  | 2,067 |  |  | 1,514 |  |
| Intangible assets, net |  | 1,327 |  |  | 1,230 |  |
| Other assets |  | 422 |  |  | 344 |  |
| Total assets |  | $ | 10,642 |  |  | $ | 9,409 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 16 |  |  | $ | 31 |  |
| Accounts payable |  | 618 |  |  | 592 |  |
| Contract liabilities |  | 1,449 |  |  | 1,263 |  |
| Accrued liabilities |  | 1,356 |  |  | 1,210 |  |
| Total current liabilities |  | 3,439 |  |  | 3,096 |  |
| Long-term debt |  | 5,113 |  |  | 5,289 |  |
| Operating lease liabilities |  | 497 |  |  | — |  |
| Other liabilities |  | 2,276 |  |  | 2,300 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (700 | ) |  | (1,293 | ) |
| Noncontrolling interests |  | 17 |  |  | 17 |  |
| Total liabilities and stockholders’ equity |  | $ | 10,642 |  |  | $ | 9,409 |  |

[0000068505-20-000003:8k_2_02:97]
GAAP-4

[0000068505-20-000003:8k_2_02:98]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:99]
Consolidated Statements of Cash Flows

[0000068505-20-000003:8k_2_02:100]
(In millions)

[0000068505-20-000003:8k_2_02:101]
|  | Three Months Ended |
|  | December 31, 2019 |  | December 31, 2018 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 244 |  |  | $ | 423 |  |
| Earnings attributable to noncontrolling interests | — |  |  | 1 |  |
| Net earnings | 244 |  |  | 424 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 104 |  |  | 93 |  |
| Non-cash other charges | 8 |  |  | — |  |
| U.S. pension settlement loss | 359 |  |  | — |  |
| Share-based compensation expense | 31 |  |  | 20 |  |
| Gains on sales of investments and businesses, net | (1 | ) |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (109 | ) |  | (124 | ) |
| Inventories | 14 |  |  | 10 |  |
| Other current assets and contract assets | (55 | ) |  | (114 | ) |
| Accounts payable, accrued liabilities, and contract liabilities | 341 |  |  | 441 |  |
| Other assets and liabilities | (16 | ) |  | 72 |  |
| Deferred income taxes | (125 | ) |  | (10 | ) |
| Net cash provided by operating activities | 795 |  |  | 812 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (86 | ) |  | (6 | ) |
| Proceeds from sales of investments | 6 |  |  | 5 |  |
| Capital expenditures | (59 | ) |  | (69 | ) |
| Proceeds from sales of property, plant and equipment | 7 |  |  | — |  |
| Net cash used for investing activities | (132 | ) |  | (70 | ) |
| Financing |  |  |  |
| Repayment of debt | (604 | ) |  | (311 | ) |
| Net proceeds from issuance of debt | — |  |  | 195 |  |
| Issuance of common stock | 32 |  |  | 29 |  |
| Purchase of common stock | (145 | ) |  | (66 | ) |
| Payment of dividends | (98 | ) |  | (85 | ) |
| Deferred acquisition costs | — |  |  | (76 | ) |
| Net cash used for financing activities | (815 | ) |  | (314 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 13 |  |  | (22 | ) |
| Net increase (decrease) in cash and cash equivalents | (139 | ) |  | 406 |  |
| Cash and cash equivalents, beginning of period | 1,140 |  |  | 851 |  |
| Cash and cash equivalents, end of period | $ | 1,001 |  |  | $ | 1,257 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 736 |  |  | $ | 743 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-20-000003:8k_2_02:102]
GAAP-5

[0000068505-20-000003:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:104]
Consolidated Statements of Cash Flows

[0000068505-20-000003:8k_2_02:105]
(In millions)

[0000068505-20-000003:8k_2_02:106]
|  | Years Ended |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2017 |
| Operating |  |  |  |  |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | 868 |  |  | $ | 966 |  |  | $ | (155 | ) |
| Earnings attributable to noncontrolling interests | 3 |  |  | 3 |  |  | 4 |  |
| Net earnings (loss) | 871 |  |  | 969 |  |  | (151 | ) |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 394 |  |  | 360 |  |  | 343 |  |
| Non-cash other charges | 35 |  |  | 56 |  |  | 32 |  |
| Pension settlement losses | 359 |  |  | — |  |  | 48 |  |
| Share-based compensation expense | 118 |  |  | 73 |  |  | 66 |  |
| Gains on sales of investments and businesses, net | (5 | ) |  | (16 | ) |  | (3 | ) |
| Losses from the extinguishment of long-term debt | 50 |  |  | — |  |  | — |  |
| Gain from the extinguishment of 2.00% senior convertible notes | (4 | ) |  | (6 | ) |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | (79 | ) |  | 62 |  |  | (60 | ) |
| Inventories | (74 | ) |  | 71 |  |  | (46 | ) |
| Other current assets and contract assets | 49 |  |  | (251 | ) |  | (99 | ) |
| Accounts payable, accrued liabilities, and contract liabilities | 198 |  |  | 271 |  |  | 160 |  |
| Other assets and liabilities | (5 | ) |  | (523 | ) |  | (44 | ) |
| Deferred income taxes | (84 | ) |  | 9 |  |  | 1,100 |  |
| Net cash provided by operating activities | 1,823 |  |  | 1,075 |  |  | 1,346 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (709 | ) |  | (1,164 | ) |  | (404 | ) |
| Proceeds from sales of investments | 16 |  |  | 95 |  |  | 183 |  |
| Capital expenditures | (248 | ) |  | (197 | ) |  | (227 | ) |
| Proceeds from sales of property, plant and equipment | 7 |  |  | — |  |  | — |  |
| Net cash used for investing activities | (934 | ) |  | (1,266 | ) |  | (448 | ) |
| Financing |  |  |  |  |  |
| Repayment of debt | (2,039 | ) |  | (723 | ) |  | (21 | ) |
| Net proceeds from issuance of debt | 1,804 |  |  | 1,490 |  |  | 10 |  |
| Issuances of common stock | 114 |  |  | 168 |  |  | 82 |  |
| Purchases of common stock | (315 | ) |  | (132 | ) |  | (483 | ) |
| Settlement of conversion premium on 2.00% senior convertible notes | (326 | ) |  | (169 | ) |  | — |  |
| Payment of dividends | (379 | ) |  | (337 | ) |  | (307 | ) |
| Payment of dividends to noncontrolling interest | (3 | ) |  | (1 | ) |  | (1 | ) |
| Deferred acquisition costs | — |  |  | (76 | ) |  | (2 | ) |
| Net cash provided by (used for) financing activities | (1,144 | ) |  | 220 |  |  | (722 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1 | ) |  | (40 | ) |  | 62 |  |
| Net increase (decrease) in cash and cash equivalents | (256 | ) |  | (11 | ) |  | 238 |  |
| Cash and cash equivalents, beginning of period | 1,257 |  |  | 1,268 |  |  | 1,030 |  |
| Cash and cash equivalents, end of period | $ | 1,001 |  |  | $ | 1,257 |  |  | $ | 1,268 |  |
| Financial Ratios: |  |  |  |  |  |
| Free cash flow* | 1,575 |  |  | 878 |  |  | 1,119 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |  |  |

[0000068505-20-000003:8k_2_02:107]
GAAP-6

[0000068505-20-000003:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:109]
Segment Information

[0000068505-20-000003:8k_2_02:110]
(In millions)

[0000068505-20-000003:8k_2_02:111]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 1,673 |  |  | $ | 1,670 |  |  | — | % |
| Software and Services | 704 |  |  | 584 |  |  | 21 | % |
| Total Motorola Solutions | $ | 2,377 |  |  | $ | 2,254 |  |  | 5 | % |
|  | Years Ended |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 5,329 |  |  | $ | 5,100 |  |  | 5 | % |
| Software and Services | 2,558 |  |  | 2,243 |  |  | 14 | % |
| Total Motorola Solutions | $ | 7,887 |  |  | $ | 7,343 |  |  | 7 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 426 |  |  | $ | 405 |  |  | 5 | % |
| Software and Services | 164 |  |  | 111 |  |  | 48 | % |
| Total Motorola Solutions | $ | 590 |  |  | $ | 516 |  |  | 14 | % |
|  | Years Ended |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 994 |  |  | $ | 854 |  |  | 16 | % |
| Software and Services | 587 |  |  | 401 |  |  | 46 | % |
| Total Motorola Solutions | $ | 1,581 |  |  | $ | 1,255 |  |  | 26 | % |

[0000068505-20-000003:8k_2_02:112]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  |  |
| Products and Systems Integration | 25.5 | % |  | 24.3 | % |  |  |
| Software and Services | 23.3 | % |  | 19.0 | % |  |  |
| Total Motorola Solutions | 24.8 | % |  | 22.9 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  |  |
| Products and Systems Integration | 18.7 | % |  | 16.7 | % |  |  |
| Software and Services | 22.9 | % |  | 17.9 | % |  |  |
| Total Motorola Solutions | 20.0 | % |  | 17.1 | % |  |  |

[0000068505-20-000003:8k_2_02:113]
Non-GAAP-1

[0000068505-20-000003:8k_2_02:114]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:115]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-20-000003:8k_2_02:116]
| Q1 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 50 |  |  | $ | 11 |  |  | $ | 39 |  |  | $ | 0.23 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 27 |  |  | 6 |  |  | 21 |  |  | 0.12 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Investment impairments |  | Investment impairments |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Acquisition-related transaction fees |  | Other charges |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Release of uncertain tax positions |  | Income tax expense |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Legal settlement |  | Other charges |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Total impact on Net earnings |  |  |  | $ | 94 |  |  | $ | 22 |  |  | $ | 72 |  |  | $ | 0.42 |  |
| Q2 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 52 |  |  | $ | 11 |  |  | $ | 41 |  |  | $ | 0.23 |  |
| Loss from the extinguishment of long-term debt |  | Other expense |  | 43 |  |  | 11 |  |  | 32 |  |  | 0.18 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 30 |  |  | 7 |  |  | 23 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 12 |  |  | 3 |  |  | 9 |  |  | 0.05 |  |
| Investment impairments |  | Investment impairments |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Legal settlements |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Sale of a business |  | (Gain) or loss on sales of investments and businesses, net |  | (3 | ) |  | (1 | ) |  | (2 | ) |  | (0.01 | ) |
| Release of uncertain tax positions |  | Other income, Income tax expense |  | (4 | ) |  | (1 | ) |  | (3 | ) |  | (0.02 | ) |
| Fair value adjustments to equity investments |  | Other income |  | (16 | ) |  | (4 | ) |  | (12 | ) |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 118 |  |  | $ | 27 |  |  | $ | 91 |  |  | $ | 0.51 |  |
| Q3 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 52 |  |  | $ | 12 |  |  | $ | 40 |  |  | $ | 0.22 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 30 |  |  | 7 |  |  | 23 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Fair value adjustments to equity investments |  | Other income |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Loss from the extinguishment of long-term debt |  | Other expense |  | 7 |  |  | 2 |  |  | 5 |  |  | 0.03 |  |
| Investment impairments |  | Other expense |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Acquisition-related transaction fees |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Gain from the extinguishment of 2.00% senior convertible notes |  | Other income |  | (4 | ) |  | (1 | ) |  | (3 | ) |  | (0.02 | ) |
| Gain on legal settlement |  | Other charges |  | (5 | ) |  | (1 | ) |  | (4 | ) |  | (0.02 | ) |
| Total impact on Net earnings |  |  |  | $ | 122 |  |  | $ | 28 |  |  | $ | 94 |  |  | $ | 0.53 |  |

[0000068505-20-000003:8k_2_02:117]
| Q4 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| US pension settlement loss |  | Other expense |  | $ | 359 |  |  | $ | 90 |  |  | $ | 269 |  |  | $ | 1.53 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 54 |  |  | 12 |  |  | 42 |  |  | 0.24 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 31 |  |  | 7 |  |  | 24 |  |  | 0.14 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 19 |  |  | 5 |  |  | 14 |  |  | 0.08 |  |
| Legal settlements |  | Other charges |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Operating lease asset impairment |  | Other charges |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Investment impairments |  | Other expense |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Release of uncertain tax positions |  | Other income, Income tax expense |  | (1 | ) |  | 4 |  |  | (5 | ) |  | (0.03 | ) |
| Fair value adjustments to equity investments |  | Other income |  | (6 | ) |  | (1 | ) |  | (5 | ) |  | (0.03 | ) |
| Release of valuation allowance on deferred tax assets |  | Income tax expense |  | — |  |  | 77 |  |  | (77 | ) |  | (0.44 | ) |
| Total impact on Net earnings |  |  |  | $ | 470 |  |  | $ | 197 |  |  | $ | 273 |  |  | $ | 1.55 |  |
| FY 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| US pension settlement loss |  | Other expense |  | $ | 359 |  |  | $ | 90 |  |  | $ | 269 |  |  | $ | 1.53 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 208 |  |  | 46 |  |  | 162 |  |  | 0.92 |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | 118 |  |  | 27 |  |  | 91 |  |  | 0.52 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 57 |  |  | 14 |  |  | 43 |  |  | 0.24 |  |
| Loss from the extinguishment of long-term debt |  | Other expense |  | 50 |  |  | 13 |  |  | 37 |  |  | 0.21 |  |
| Investment impairments |  | Investment impairments |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Operating lease asset impairment |  | Other charges |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Legal settlements |  | Other charges |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Acquisition-related transaction fees |  | Other charges |  | 3 |  |  | — |  |  | 3 |  |  | 0.02 |  |
| Sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (2 | ) |  | — |  |  | (2 | ) |  | (0.01 | ) |
| Sale of a business |  | (Gain) or loss on sales of investments and businesses, net |  | (3 | ) |  | (1 | ) |  | (2 | ) |  | (0.01 | ) |
| Fair value adjustments to equity investments |  | Other expense |  | (3 | ) |  | (1 | ) |  | (2 | ) |  | (0.01 | ) |
| Gain from the extinguishment of 2.00% senior convertible notes |  | Other income |  | (4 | ) |  | (1 | ) |  | (3 | ) |  | (0.02 | ) |
| Release of uncertain tax positions |  | Other income, Income tax expense |  | (5 | ) |  | 4 |  |  | (9 | ) |  | (0.05 | ) |
| Release of valuation allowance on deferred tax assets |  | Income tax expense |  | — |  |  | 77 |  |  | (77 | ) |  | (0.44 | ) |
| Total impact on Net earnings |  |  |  | $ | 804 |  |  | $ | 274 |  |  | $ | 530 |  |  | $ | 3.01 |  |

[0000068505-20-000003:8k_2_02:118]
Non-GAAP-2

[0000068505-20-000003:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:120]
Non-GAAP Segment Information

[0000068505-20-000003:8k_2_02:121]
(In millions)

[0000068505-20-000003:8k_2_02:122]
| Net Sales |
|  | Three Months Ended |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |  |
| Products and Systems Integration | $ | 1,673 |  |  | $ | 1,670 |  |  | — | % |  |
| Software and Services | 704 |  |  | 584 |  |  | 21 | % |  |
| Total Motorola Solutions | $ | 2,377 |  |  | $ | 2,254 |  |  | 5 | % |  |
|  | Years Ended |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |  |
| Products and Systems Integration | $ | 5,329 |  |  | $ | 5,100 |  |  | 5 | % |  |
| Software and Services | 2,558 |  |  | 2,243 |  |  | 14 | % |  |
| Total Motorola Solutions | $ | 7,887 |  |  | $ | 7,343 |  |  | 7 | % |  |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |  |
| Products and Systems Integration | $ | 484 |  |  | $ | 483 |  |  | — | % |  |
| Software and Services | 223 |  |  | 167 |  |  | 34 | % |  |
| Total Motorola Solutions | $ | 707 |  |  | $ | 650 |  |  | 9 | % |  |
|  | Years Ended |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | % Change |  |
| Products and Systems Integration | $ | 1,173 |  |  | $ | 1,109 |  |  | 6 | % |  |
| Software and Services | 802 |  |  | 631 |  |  | 27 | % |  |
| Total Motorola Solutions | $ | 1,975 |  |  | $ | 1,740 |  |  | 14 | % |  |

[0000068505-20-000003:8k_2_02:123]
| Non-GAAP Operating Earnings % |  |
|  | Three Months Ended |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  |  |  |
| Products and Systems Integration | 28.9 | % |  | 28.9 | % |  |  |  |
| Software and Services | 31.7 | % |  | 28.6 | % |  |  |  |
| Total Motorola Solutions | 29.7 | % |  | 28.8 | % |  |  |  |
|  | Years Ended |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  |  |  |
| Products and Systems Integration | 22.0 | % |  | 21.7 | % |  |  |  |
| Software and Services | 31.4 | % |  | 28.1 | % |  |  |  |
| Total Motorola Solutions | 25.0 | % |  | 23.7 | % |  |  |  |

[0000068505-20-000003:8k_2_02:124]
Non-GAAP-3

[0000068505-20-000003:8k_2_02:125]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:126]
Operating Earnings after Non-GAAP Adjustments

[0000068505-20-000003:8k_2_02:127]
| Q1 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,657 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Operating earnings ("OE") |  | $ | 229 |  |  | $ | 108 |  |  | $ | 121 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 27 |  |  | 21 |  |  | 6 |  |
| Reorganization of business charges |  | 8 |  |  | 7 |  |  | 1 |  |
| Intangibles amortization expense |  | 50 |  |  | 11 |  |  | 39 |  |
| Legal settlement |  | (1 | ) |  | (1 | ) |  | — |  |
| Acquisition-related transaction fees |  | 2 |  |  | 1 |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 86 |  |  | 39 |  |  | 47 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 315 |  |  | $ | 147 |  |  | $ | 168 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 13.8 | % |  | 10.1 | % |  | 20.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 19.0 | % |  | 13.8 | % |  | 28.6 | % |

[0000068505-20-000003:8k_2_02:128]
| Q2 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,860 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Operating earnings ("OE") |  | $ | 349 |  |  | $ | 201 |  |  | $ | 148 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 30 |  |  | 19 |  |  | 11 |  |
| Reorganization of business charges |  | 12 |  |  | 9 |  |  | 3 |  |
| Intangibles amortization expense |  | 52 |  |  | 12 |  |  | 40 |  |
| Legal settlements |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 95 |  |  | 41 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 444 |  |  | $ | 242 |  |  | $ | 202 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 18.8 | % |  | 16.2 | % |  | 23.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 23.9 | % |  | 19.5 | % |  | 32.5 | % |

[0000068505-20-000003:8k_2_02:129]
| Q3 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,994 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Operating earnings ("OE") |  | $ | 413 |  |  | $ | 258 |  |  | $ | 155 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 30 |  |  | 20 |  |  | 10 |  |
| Reorganization of business charges |  | 18 |  |  | 14 |  |  | 4 |  |
| Intangibles amortization expense |  | 52 |  |  | 12 |  |  | 40 |  |
| Acquisition-related transaction fees |  | 1 |  |  | 1 |  |  | — |  |
| Gain on legal settlements |  | (5 | ) |  | (5 | ) |  | — |  |
| Total above-OE non-GAAP adjustments |  | 96 |  |  | 42 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 509 |  |  | $ | 300 |  |  | $ | 209 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 20.7 | % |  | 19.1 | % |  | 24.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 25.5 | % |  | 22.2 | % |  | 32.4 | % |

[0000068505-20-000003:8k_2_02:130]
| Q4 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 2,377 |  |  | $ | 1,673 |  |  | $ | 704 |  |
| Operating earnings ("OE") |  | $ | 590 |  |  | $ | 426 |  |  | $ | 164 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Reorganization of business charges |  | 19 |  |  | 16 |  |  | 3 |  |
| Share-based compensation expense |  | 31 |  |  | 21 |  |  | 10 |  |
| Intangibles amortization expense |  | 54 |  |  | 12 |  |  | 42 |  |
| Operating lease asset impairment |  | 5 |  |  | 3 |  |  | 2 |  |
| Legal settlements |  | 8 |  |  | 6 |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  | 117 |  |  | 58 |  |  | 59 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 707 |  |  | $ | 484 |  |  | $ | 223 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 24.8 | % |  | 25.5 | % |  | 23.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 29.7 | % |  | 28.9 | % |  | 31.7 | % |

[0000068505-20-000003:8k_2_02:131]
| FY 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 7,887 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |
| Operating earnings ("OE") |  | $ | 1,581 |  |  | $ | 994 |  |  | $ | 587 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 208 |  |  | 47 |  |  | 161 |  |
| Share-based compensation expense |  | 118 |  |  | 81 |  |  | 37 |  |
| Reorganization of business charges |  | 57 |  |  | 45 |  |  | 12 |  |
| Legal settlement |  | 3 |  |  | 1 |  |  | 2 |  |
| Acquisition-related transaction fees |  | 3 |  |  | 2 |  |  | 1 |  |
| Operating lease asset impairment |  | 5 |  |  | 3 |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  | 394 |  |  | 179 |  |  | 215 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,975 |  |  | $ | 1,173 |  |  | $ | 802 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 20.0 | % |  | 18.7 | % |  | 22.9 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 25.0 | % |  | 22.0 | % |  | 31.4 | % |

[0000068505-20-000003:8k_2_02:132]
Non-GAAP-4

[0000068505-20-000003:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000003:8k_2_02:134]
Non-GAAP Organic Revenue

[0000068505-20-000003:8k_2_02:135]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |  |
|  |  | December 31, 2019 |  | December 31, 2018 |  | % Change |  |
| Net sales |  | $ | 2,377 |  |  | $ | 2,254 |  |  | 5 | % |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Acquisitions |  | (82 | ) |  | — |  |  |  |  |
| Organic revenue |  | $ | 2,295 |  |  | $ | 2,254 |  |  | 2 | % |  |

[0000068505-20-000003:8k_2_02:136]
|  |  | Years Ended |  |  |  |
|  |  | December 31, 2019 |  | December 31, 2018 |  | % Change |  |
| Net sales |  | $ | 7,887 |  |  | $ | 7,343 |  |  | 7 | % |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Acquisitions |  | (337 | ) |  | (26 | ) |  |  |  |
| Organic revenue |  | $ | 7,550 |  |  | $ | 7,317 |  |  | 3 | % |  |
