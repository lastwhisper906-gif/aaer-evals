# MSI notes — 0000068505-20-000006


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000068505-20-000006:notes:1]
Portions of the registrant’s definitive Proxy Statement to be delivered to stockholders in connection with its Annual Meeting of Stockholders to be held on May 11, 2020, are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-20-000006:notes:2]
Summary of Significant Accounting Policies
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-20-000006:notes:3]
The consolidated financial statements as of December 31, 2019 and 2018 and for the years ended December 31, 2019, 2018 and 2017, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.

[0000068505-20-000006:notes:4]
As of December 31, 2019, the Company changed the name of the "Services and Software" segment to "Software and Services." The change is to the name only and no other financial information has been reclassified from previous periods presented or for the year ended December 31, 2019.

[0000068505-20-000006:notes:5]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-20-000006:notes:6]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of devices, systems and system integration and a full set of software and service offerings. The Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services.

[0000068505-20-000006:notes:7]
The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government, public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and video security, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video security are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. For Products and Systems Integration sales, the Company records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-20-000006:notes:8]
Devices includes two-way portable and vehicle-mounted radios, fixed and mobile video cameras and accessories. Devices are considered capable of being distinct and distinct within the context of our contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-20-000006:notes:9]
Systems and Systems Integration include customized radio network, video solutions and implementation, and integration of networks, devices, software, and applications. The radio network includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, and repeaters. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Systems and Systems Integration revenue is recognized over an average duration of approximately one to two years.

[0000068505-20-000006:notes:10]
Systems also include video security including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Video security solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-20-000006:notes:11]
The Software and Services segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Software and Services segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-20-000006:notes:12]
Software offerings include public safety and enterprise command solutions, unified communications applications, and video security software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is

[0000068505-20-000006:notes:13]
not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-20-000006:notes:14]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis.

[0000068505-20-000006:notes:15]
Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer or Motorola Solutions-owned networks. Services are provided across all radio network technologies. Services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-20-000006:notes:16]
Significant Judgments

[0000068505-20-000006:notes:17]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-20-000006:notes:18]
The Company accounts for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-20-000006:notes:19]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. The Company has a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-20-000006:notes:20]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $2 million at December 31, 2019 and $11 million at December 31, 2018.

[0000068505-20-000006:notes:21]
Investments: Investments in debt securities classified as available-for-sale are carried at fair value with changes in fair value recorded in other comprehensive income. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-20-000006:notes:22]
The Company assesses declines in the fair value of debt securities and equity method investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value

[0000068505-20-000006:notes:23]
has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s Consolidated Statements of Operations in the period in which they become impaired.

[0000068505-20-000006:notes:24]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded in Other within Other income (expense).

[0000068505-20-000006:notes:25]
Inventories: Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or net realizable value.

[0000068505-20-000006:notes:26]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, five to twenty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-20-000006:notes:27]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and SG&A costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it is determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform the first step of the impairment process, which compares the fair value of the reporting unit to its book value. If the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-20-000006:notes:28]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.

[0000068505-20-000006:notes:29]
Leases: The Company recognizes if an arrangement is a lease at the inception of the contract.  The Company determines which party has the right to control an asset during the contract term and recognizes a Right of Use ("ROU") asset and operating lease liability based on the present value of the future minimum lease payments over the term of the lease.  Refer to Note 3 for further discussion of the Company’s accounting policy for leases.

[0000068505-20-000006:notes:30]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-20-000006:notes:31]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expenses and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-20-000006:notes:32]
Long-Term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-20-000006:notes:33]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the

[0000068505-20-000006:notes:34]
Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the “Accrued liabilities” statement line and the non-current portion is included in the “Other liabilities” statement line within the Company’s Consolidated Balance Sheet.

[0000068505-20-000006:notes:35]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-20-000006:notes:36]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-20-000006:notes:37]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-20-000006:notes:38]
Derivative Instruments: Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income (loss). Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income (loss) at their initial value and amortized into Interest expense, net on a straight-line basis.

[0000068505-20-000006:notes:39]
Earnings Per Share: The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted-average number of common shares used in the basic earnings (loss) per share calculation and the weighted-average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for net earnings attributable to Motorola Solutions, Inc. for all periods presented.

[0000068505-20-000006:notes:40]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk-free rate, dividend yield, and expected life. Performance-based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-20-000006:notes:41]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s Consolidated Balance Sheets using a December 31 measurement date.

[0000068505-20-000006:notes:42]
Recent Acquisitions:

[0000068505-20-000006:notes:43]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired.  The acquisition enhances the Company's video security platform by adding data to the Company’s existing license plate recognition (“LPR”) database within the Software and Services segment.

[0000068505-20-000006:notes:44]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:notes:45]
On March 11, 2019, the Company acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:notes:46]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:notes:47]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million. The acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000006:notes:48]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1 within our Software and Services segment.

[0000068505-20-000006:notes:49]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk for commercial customers, for a purchase price of $225 million. The business is part of the Software and Services segment.

[0000068505-20-000006:notes:50]
On March 13, 2017, the Company completed the acquisition of Interexport, a managed service provider of communications systems to public safety and commercial customers in Chile, for a purchase price of 98 billion Chilean pesos, or approximately $147 million. The business is part of the Software and Services segment.

[0000068505-20-000006:notes:51]
Recent Accounting Pronouncements:

[0000068505-20-000006:notes:52]
In December 2019, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes.  The ASU is effective for the Company on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  The Company is still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-20-000006:notes:53]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-20-000006:notes:54]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” and “ASU No. 2019-11, Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020.  The Company does not believe there will be a material impact on its financial statements as a result of the adoption.

[0000068505-20-000006:notes:55]
Recently Adopted Accounting Pronouncements:

[0000068505-20-000006:notes:56]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to

[0000068505-20-000006:notes:57]
Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases are classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-20-000006:notes:58]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1, 2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

[0000068505-20-000006:notes:59]
ASC 842 provides for a number of optional practical expedients in transition. The Company elected the practical expedients, which permit the Company to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. The Company did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing it to carry forward the lease term as determined prior to adoption of ASC 842. Finally, the Company also elected the practical expedient related to land easements, which enabled it to continue its accounting treatment for land easements on existing agreements as of January 1, 2019.

[0000068505-20-000006:notes:60]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. The Company elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of twelve months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows the Company to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with the Company’s prior accounting. The Company also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

[0000068505-20-000006:notes:61]
As of January 1, 2019, the Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition. In future periods such balances will not be presented separately.

[0000068505-20-000006:notes:62]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606, "Revenue from Contract with Customers" and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.

[0000068505-20-000006:notes:63]
The Company adopted ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" on December 1, 2018, using the modified retrospective method of adoption. The ASU requires a cumulative effect adjustment to the opening balance of retained earnings as of the beginning of the fiscal year of adoption for the previously recorded ineffectiveness included in retained earnings related to existing net investment hedges as of the date of adoption. The Company did not record a cumulative effect adjustment to retained earnings as no net investment hedges existed as of the ASU adoption date. New hedging relationships entered after the adoption date have been presented in the financial statements using the guidance of the ASU. There were no material changes to the Company’s financial statements from the adoption of the ASU.

[0000068505-20-000006:notes:64]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company recognizes tax expense when intra-entity transfers of assets other than inventory occur.  The Company recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance as of January 1, 2018. During the three months ended December 31, 2019, the Company identified an error in the amounts originally recorded when adopting ASU 2016-16.  The Company recorded an out-of-period correction of $30 million to deferred income tax assets in the Consolidated Balance Sheets and retained earnings in the Consolidated Statements of Stockholders' Equity. The adjustment did not have a material impact on the Consolidated Balance Sheets or Consolidated Statements of Stockholders’ Equity for any period presented.

[0000068505-20-000006:notes:65]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s

[0000068505-20-000006:notes:66]
net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. Accordingly, the Company reclassified $78 million of benefits, $75 million of benefit, and $2 million of expense in the years ended 2019, 2018 and 2017, respectively, within Other in Other income (expense).

[0000068505-20-000006:notes:67]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-20-000006:notes:68]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its Systems and Systems Integration contracts continues to be recognized under percentage-of-completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-20-000006:notes:69]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-20-000006:notes:70]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence recognized an adjustment through opening retained earnings as of January 1, 2018.

[0000068505-20-000006:notes:71]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

[0000068505-20-000006:notes:72]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-20-000006:notes:73]
Revenue from Contracts with Customers

[0000068505-20-000006:notes:74]
Disaggregation of Revenue

[0000068505-20-000006:notes:75]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the year ended December 31, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of reportable segments:

[0000068505-20-000006:notes:76]
|  | Years Ended |
|  | 2019 |  | 2018 |
| (in millions) | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 4,107 |  |  | $ | 1,572 |  |  | $ | 3,743 |  |  | $ | 1,320 |  |
| EMEA | 730 |  |  | 821 |  |  | 845 |  |  | 755 |  |
| Asia Pacific | 492 |  |  | 165 |  |  | 512 |  |  | 168 |  |
|  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 3,467 |  |  | $ | — |  |  | $ | 3,216 |  |  | $ | — |  |
| Systems and Systems Integration | 1,862 |  |  | — |  |  | 1,884 |  |  | — |  |
| Services | — |  |  | 1,896 |  |  | — |  |  | 1,815 |  |
| Software | — |  |  | 662 |  |  | — |  |  | 428 |  |
|  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 3,441 |  |  | $ | 2,395 |  |  | $ | 3,317 |  |  | $ | 2,134 |  |
| Indirect | 1,888 |  |  | 163 |  |  | 1,783 |  |  | 109 |  |
|  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |

[0000068505-20-000006:notes:77]
Remaining Performance Obligations

[0000068505-20-000006:notes:78]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which are not yet satisfied as of December 31, 2019 is $7.3 billion. A total of $3.2 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.1 billion is from Software and Services performance obligations that are not yet satisfied as of December 31, 2019. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-20-000006:notes:79]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-20-000006:notes:80]
Contract Balances

[0000068505-20-000006:notes:81]
| (in millions) | 2019 |  | 2018 |
| Accounts receivable, net | $ | 1,412 |  |  | $ | 1,293 |  |
| Contract assets | 1,046 |  |  | 1,012 |  |
| Contract liabilities | 1,449 |  |  | 1,263 |  |
| Non-current contract liabilities | 274 |  |  | 214 |  |

[0000068505-20-000006:notes:82]
Revenue recognized during the year ended December 31, 2019 which was previously included in Contract liabilities as of January 1, 2019 is $854 million, compared to $836 million of revenue recognized during the year ended December 31, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $50 million was reversed during the year ended December 31, 2019 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million during the year ended December 31, 2018.

[0000068505-20-000006:notes:83]
There have been no material impairment losses recognized on contract assets during the year ended December 31, 2019.

[0000068505-20-000006:notes:84]
Contract Cost Balances

[0000068505-20-000006:notes:85]
| (in millions) | 2019 |  | 2018 |
| Current contract cost assets | 24 |  |  | 30 |  |
| Non-current contract cost assets | 107 |  |  | 98 |  |

[0000068505-20-000006:notes:86]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $42 million for the year ended December 31, 2019, compared to $44 million as of the year ended December 31, 2018.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-20-000006:notes:87]
Leases
The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-20-000006:notes:88]
The Company determines if an arrangement is a lease at inception of the contract. The Company’s key considerations in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company’s contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the right to operate the asset at its discretion during the term of the contract.

[0000068505-20-000006:notes:89]
ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company’s lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in lease payments. For the Company’s leases consisting of land and other equipment (i.e. “communication network sites”), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage.  ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-20-000006:notes:90]
As the majority of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company’s incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-20-000006:notes:91]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of

[0000068505-20-000006:notes:92]
the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communication network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-20-000006:notes:93]
The components of lease expense are as follows:

[0000068505-20-000006:notes:94]
| (in millions) | December 31, 2019 |
| Lease expense: |  |
| Operating lease cost | $ | 133 |  |
| Finance lease cost |  |
| Amortization of right-of-use assets | 12 |  |
| Interest on lease liabilities | 2 |  |
| Total finance lease cost | 14 |  |
| Short-term lease cost | 4 |  |
| Variable cost | 35 |  |
| Sublease income | (4 | ) |
| Net lease expense | $ | 182 |  |

[0000068505-20-000006:notes:95]
Rental expense, net of sublease income, for the year ended December 31, 2019, 2018 and 2017 were $133 million, $108 million and $93 million, respectively.

[0000068505-20-000006:notes:96]
Lease assets and liabilities consist of the following:

[0000068505-20-000006:notes:97]
| (in millions) |  | Statement Line Classification |  | December 31, 2019 |
| Assets: |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 554 |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 41 |  |
|  |  |  |  | $ | 595 |  |
| Current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 122 |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 13 |  |
|  |  |  |  | $ | 135 |  |
| Non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 497 |  |
| Finance lease liabilities |  | Long-term debt |  | 16 |  |
|  |  |  |  | $ | 513 |  |

[0000068505-20-000006:notes:98]
Other information related to leases is as follows:

[0000068505-20-000006:notes:99]
| (in millions) | December 31, 2019 |
| Supplemental cash flow information: |  |
| Net cash used for operating activities related to operating leases | $ | 140 |  |
| Net cash used for operating activities related to finance leases | 2 |  |
| Net cash used for financing activities related to finance leases | 14 |  |
| Assets obtained in exchange for lease liabilities: |  |
| Operating leases | $ | 86 |  |

[0000068505-20-000006:notes:100]
| (in millions) | December 31, 2019 |
| Weighted average remaining lease terms (years): |  |
| Operating leases | 7 |  |
| Finance leases | 2 |  |
| Weighted average discount rate: |  |
| Operating leases | 3.61 | % |
| Finance leases | 4.28 | % |

[0000068505-20-000006:notes:101]
Future lease payments as of December 31, 2019 are as follows:

[0000068505-20-000006:notes:102]
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| 2020 | $ | 143 |  |  | $ | 14 |  |  | $ | 157 |  |
| 2021 | 129 |  |  | 12 |  |  | 141 |  |
| 2022 | 114 |  |  | 5 |  |  | 119 |  |
| 2023 | 62 |  |  | 1 |  |  | 63 |  |
| 2024 | 55 |  |  | — |  |  | 55 |  |
| Thereafter | 210 |  |  | — |  |  | 210 |  |
| Total lease payments | $ | 713 |  |  | $ | 32 |  |  | $ | 745 |  |
| Less: Interest | 94 |  |  | 3 |  |  | 97 |  |
| Present value of lease liabilities | $ | 619 |  |  | $ | 29 |  |  | $ | 648 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-20-000006:notes:103]
Other Financial Data
Statement of Operations Information

[0000068505-20-000006:notes:104]
Other Charges (Income)

[0000068505-20-000006:notes:105]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-20-000006:notes:106]
| Years ended December 31 (in millions) | 2019 |  | 2018 |  | 2017 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 208 |  |  | $ | 188 |  |  | $ | 151 |  |
| Reorganization of businesses (Note 14) | 40 |  |  | 61 |  |  | 33 |  |
| Loss (gain) on legal settlements | 3 |  |  | 3 |  |  | (1 | ) |
| Asset impairments | — |  |  | 1 |  |  | 10 |  |
| Environmental reserve expense | — |  |  | 57 |  |  | — |  |
| Gain on the recovery of long-term receivables | — |  |  | — |  |  | (47 | ) |
| Operating lease ROU asset impairment | 5 |  |  | — |  |  | — |  |
| Acquisition-related transaction fees | 3 |  |  | 24 |  |  | 1 |  |
| Other | 1 |  |  | — |  |  | — |  |
|  | $ | 260 |  |  | $ | 334 |  |  | $ | 147 |  |

[0000068505-20-000006:notes:107]
During 2018, the Company recorded an environmental reserve charge of $57 million due to: (i) changing the expected timeline of the remediation activities to 30 years and (ii) additional costs for further remediation efforts, increasing the reserve to $107 million.

[0000068505-20-000006:notes:108]
During the year ended December 31, 2017, the Company recognized a net gain of $47 million related to the recovery, through legal procedures to seize and liquidate assets, of long-term receivables owed to the Company by a former customer of its legacy Networks business. The net gain of $47 million was based on $57 million of proceeds received, net of $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-20-000006:notes:109]
Other Income (Expense)

[0000068505-20-000006:notes:110]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-20-000006:notes:111]
| Years ended December 31 (in millions) | 2019 |  | 2018 |  | 2017 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (237 | ) |  | $ | (240 | ) |  | $ | (215 | ) |
| Interest income | 17 |  |  | 18 |  |  | 14 |  |
|  | $ | (220 | ) |  | $ | (222 | ) |  | $ | (201 | ) |
| Other: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 78 |  |  | $ | 75 |  |  | $ | 46 |  |
| Non-U.S. pension settlement loss (Note 8) | — |  |  | — |  |  | (48 | ) |
| Losses from the extinguishment of long-term debt (Note 5) | (50 | ) |  | — |  |  | — |  |
| Gain from the extinguishment of 2.00% senior convertible notes (Note 5) | 4 |  |  | 6 |  |  | — |  |
| Investment impairments | (18 | ) |  | (5 | ) |  | — |  |
| Foreign currency loss | (22 | ) |  | (24 | ) |  | (31 | ) |
| Gain (loss) on derivative instruments | (8 | ) |  | (14 | ) |  | 15 |  |
| Gains on equity method investments | 3 |  |  | 1 |  |  | 1 |  |
| Fair value adjustments to equity investments | (3 | ) |  | 11 |  |  | — |  |
| U.S. pension settlement (Note 8) | (359 | ) |  | — |  |  | — |  |
| Other | 10 |  |  | 3 |  |  | 7 |  |
|  | $ | (365 | ) |  | $ | 53 |  |  | $ | (10 | ) |

[0000068505-20-000006:notes:112]
Earnings Per Common Share

[0000068505-20-000006:notes:113]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-20-000006:notes:114]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Net Earnings (loss) |
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| Basic earnings per common share: |  |  |  |  |  |
| Earnings (loss) | $ | 868 |  |  | $ | 966 |  |  | $ | (155 | ) |
| Weighted average common shares outstanding | 166.6 |  |  | 162.4 |  |  | 162.9 |  |
| Per share amount | $ | 5.21 |  |  | $ | 5.95 |  |  | $ | (0.95 | ) |
| Diluted earnings per common share: |  |  |  |  |  |
| Earnings (loss) | $ | 868 |  |  | $ | 966 |  |  | $ | (155 | ) |
| Weighted average common shares outstanding | 166.6 |  |  | 162.4 |  |  | 162.9 |  |
| Add effect of dilutive securities: |  |  |  |  |  |
| Share-based awards | 4.7 |  |  | 4.2 |  |  | — |  |
| 2.00% senior convertible notes | 4.3 |  |  | 5.4 |  |  | — |  |
| 1.75% senior convertible notes | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 175.6 |  |  | 172.0 |  |  | 162.9 |  |
| Per share amount | $ | 4.95 |  |  | $ | 5.62 |  |  | $ | (0.95 | ) |

[0000068505-20-000006:notes:115]
In the computation of diluted earnings per common share for the year ended December 31, 2019, the assumed exercise of 0.3 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2018, the assumed exercise of 0.8 million options, including 0.6 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2017, the Company recorded a net loss and, accordingly, the basic and diluted weighted average shares outstanding are equal because any increase to the basic shares would be antidilutive, including the assumed exercise 8.7 million stock options and the assumed vesting of 1.4 million RSUs, and 3.1 million shares related to the 2.00% senior convertible notes.

[0000068505-20-000006:notes:116]
On September 5, 2019, the Company issued $1.0 billion of 1.75% senior convertible notes which mature on September 15, 2024 ("New Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the New Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the New Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. For the period ended December 31, 2019, there was no dilutive effect of the New Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price. See further discussion in Note 5.

[0000068505-20-000006:notes:117]
Balance Sheet Information

[0000068505-20-000006:notes:118]
Accounts Receivable, Net

[0000068505-20-000006:notes:119]
Accounts receivable, net, consists of the following:

[0000068505-20-000006:notes:120]
| December 31 | 2019 |  | 2018 |
| Accounts receivable | $ | 1,475 |  |  | $ | 1,344 |  |
| Less allowance for doubtful accounts | (63 | ) |  | (51 | ) |
|  | $ | 1,412 |  |  | $ | 1,293 |  |

[0000068505-20-000006:notes:121]
Inventories, Net

[0000068505-20-000006:notes:122]
Inventories, net, consist of the following:

[0000068505-20-000006:notes:123]
| December 31 | 2019 |  | 2018 |
| Finished goods | $ | 209 |  |  | $ | 206 |  |
| Work-in-process and production materials | 374 |  |  | 293 |  |
|  | 583 |  |  | 499 |  |
| Less inventory reserves | (136 | ) |  | (143 | ) |
|  | $ | 447 |  |  | $ | 356 |  |

[0000068505-20-000006:notes:124]
Other Current Assets

[0000068505-20-000006:notes:125]
Other current assets consist of the following:

[0000068505-20-000006:notes:126]
| December 31 | 2019 |  | 2018 |
| Current contract cost assets (Note 2) | $ | 24 |  |  | $ | 30 |  |
| Tax-related deposits | 77 |  |  | 138 |  |
| Other | 171 |  |  | 186 |  |
|  | $ | 272 |  |  | $ | 354 |  |

[0000068505-20-000006:notes:127]
Property, Plant and Equipment, Net

[0000068505-20-000006:notes:128]
Property, plant and equipment, net, consist of the following:

[0000068505-20-000006:notes:129]
| December 31 | 2019 |  | 2018 |
| Land | $ | 15 |  |  | $ | 10 |  |
| Leasehold improvements | 410 |  |  | 362 |  |
| Machinery and equipment | 2,051 |  |  | 1,886 |  |
|  | 2,476 |  |  | 2,258 |  |
| Less accumulated depreciation | (1,484 | ) |  | (1,363 | ) |
|  | $ | 992 |  |  | $ | 895 |  |

[0000068505-20-000006:notes:130]
Depreciation expense for the years ended December 31, 2019, 2018, and 2017 was $186 million, $172 million and $192 million, respectively.

[0000068505-20-000006:notes:131]
Investments

[0000068505-20-000006:notes:132]
Investments consist of the following:

[0000068505-20-000006:notes:133]
| December 31 | 2019 |  | 2018 |
| Corporate bonds | $ | — |  |  | $ | 1 |  |
| Common stock | 25 |  |  | 19 |  |
| Strategic investments, at cost | 40 |  |  | 62 |  |
| Company-owned life insurance policies | 74 |  |  | 75 |  |
| Equity method investments | 20 |  |  | 12 |  |
|  | $ | 159 |  |  | $ | 169 |  |

[0000068505-20-000006:notes:134]
The Company’s common stock portfolio reflects investments in publicly-traded companies within the communications services sector and is valued utilizing active market prices for similar instruments. During the year ended December 31, 2019, the Company recognized $3 million in Other income (expense) related to a decrease in the fair value of the investments.

[0000068505-20-000006:notes:135]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the year ended December 31, 2019.

[0000068505-20-000006:notes:136]
Gains on the sale of investments and businesses were $5 million, $16 million and $3 million for the years ended 2019, 2018, 2017, respectively. During the year ended December 31, 2019, the Company received $6 million in cash for the sale of $3 million of net assets related to a two-way communications rental business, resulting in the gain on sale of a business of $3 million. During the year ended December 31, 2019, the Company recorded investment impairment charges of $18 million, compared to $5 million during the year ended December 31, 2018, representing other-than-temporary declines in the value of the Company’s strategic equity investment portfolio. There were no investment impairments recorded during the year ended December 31, 2017. Investment impairment charges are included in Other within Other income (expense) in the Company’s Consolidated Statements of Operations.

[0000068505-20-000006:notes:137]
Other Assets

[0000068505-20-000006:notes:138]
Other assets consist of the following:

[0000068505-20-000006:notes:139]
| December 31 | 2019 |  | 2018 |
| Defined benefit plan assets (Note 8) | $ | 223 |  |  | $ | 135 |  |
| Tax receivable | — |  |  | 39 |  |
| Non-current contract cost assets (Note 2) | 107 |  |  | 98 |  |
| Other | 92 |  |  | 72 |  |
|  | $ | 422 |  |  | $ | 344 |  |

[0000068505-20-000006:notes:140]
Accrued Liabilities

[0000068505-20-000006:notes:141]
Accrued liabilities consist of the following:

[0000068505-20-000006:notes:142]
| December 31 | 2019 |  | 2018 |
| Compensation | 347 |  |  | 324 |  |
| Tax liabilities (Note 7) | 95 |  |  | 111 |  |
| Dividend payable | 110 |  |  | 93 |  |
| Trade liabilities | 161 |  |  | 185 |  |
| Operating lease liabilities (Note 3) | 122 |  |  | — |  |
| Other | 521 |  |  | 497 |  |
|  | $ | 1,356 |  |  | $ | 1,210 |  |

[0000068505-20-000006:notes:143]
Other Liabilities

[0000068505-20-000006:notes:144]
Other liabilities consist of the following:

[0000068505-20-000006:notes:145]
| December 31 | 2019 |  | 2018 |
| Defined benefit plans (Note 8) | $ | 1,524 |  |  | $ | 1,557 |  |
| Non-current contract liabilities (Note 2) | 274 |  |  | 214 |  |
| Unrecognized tax benefits (Note 7) | 53 |  |  | 51 |  |
| Deferred income taxes (Note 7) | 184 |  |  | 201 |  |
| Other | 241 |  |  | 277 |  |
|  | $ | 2,276 |  |  | $ | 2,300 |  |

[0000068505-20-000006:notes:146]
Stockholders’ Equity Information

[0000068505-20-000006:notes:147]
Share Repurchase Program:  Through a series of actions, the board of directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2019, the Company had used approximately $12.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.3 billion of authority available for future repurchases.

[0000068505-20-000006:notes:148]
The Company's share repurchases, including transaction costs, for 2019, 2018, and 2017 can be summarized as follows:

[0000068505-20-000006:notes:149]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Aggregate Amount (in millions) |
| 2019 | 2.3 |  |  | $ | 137.35 |  |  | $ | 315 |  |
| 2018 | 1.2 |  |  | 112.42 |  |  | 132 |  |
| 2017 | 5.7 |  |  | 85.32 |  |  | 483 |  |

[0000068505-20-000006:notes:150]
Payment of Dividends:  On November 14, 2019, the Company announced that its board of directors approved an increase in the quarterly cash dividend from $0.57 per share to $0.64 per share of common stock. During the years ended December 31, 2019, 2018, and 2017 the Company paid $379 million, $337 million, and $307 million, respectively, in cash dividends to holders of its common stock. On January 15, 2020, we paid an additional $109 million in cash dividends to holders of our common stock.

[0000068505-20-000006:notes:151]
Accumulated Other Comprehensive Loss

[0000068505-20-000006:notes:152]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2019, 2018, and 2017:

[0000068505-20-000006:notes:153]
|  | Years ended December 31 |
|  | 2019 |  | 2018 |  | 2017 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (444 | ) |  | $ | (353 | ) |  | $ | (494 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 35 |  |  | (94 | ) |  | 133 |  |
| Tax benefit (expense) | (1 | ) |  | 3 |  |  | 8 |  |
| Other comprehensive income (loss), net of tax | 34 |  |  | (91 | ) |  | 141 |  |
| Balance at end of period | $ | (410 | ) |  | $ | (444 | ) |  | $ | (353 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | 6 |  |  | $ | — |  |
| Other comprehensive income (loss) before reclassification adjustment | — |  |  | (8 | ) |  | 8 |  |
| Tax benefit (expense) | — |  |  | 2 |  |  | (2 | ) |
| Other comprehensive income (loss), net of tax | — |  |  | (6 | ) |  | 6 |  |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (2,321 | ) |  | $ | (2,215 | ) |  | $ | (1,823 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 337 |  |  | (200 | ) |  | (260 | ) |
| Tax benefit (expense) | (85 | ) |  | 46 |  |  | (213 | ) |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 252 |  |  | (154 | ) |  | (473 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 65 |  |  | 76 |  |  | 65 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (15 | ) |  | (15 | ) |  | (18 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other income (expense) | — |  |  | — |  |  | 48 |  |
| Tax benefit | (11 | ) |  | (13 | ) |  | (14 | ) |
| Reclassification adjustments into Net earnings, net of tax | 39 |  |  | 48 |  |  | 81 |  |
| Other comprehensive income (loss), net of tax | 291 |  |  | (106 | ) |  | (392 | ) |
| Balance at end of period | $ | (2,030 | ) |  | $ | (2,321 | ) |  | $ | (2,215 | ) |
| Total Accumulated other comprehensive loss | $ | (2,440 | ) |  | $ | (2,765 | ) |  | $ | (2,562 | ) |

[0000068505-20-000006:notes:154]
During the year ended December 31, 2017, the Company reclassified $270 million of stranded tax effects out of Accumulated other comprehensive loss and into Retained earnings. The stranded tax effects remained a component of Accumulated other comprehensive loss as a result of the remeasurement of our deferred tax assets related to our U.S. Pension Plans through the statement of operations, to the U.S. federal tax rate of 21%. As a result, stranded tax effects within Accumulated other comprehensive loss which would not be realized at the established historical tax rates have been adjusted through equity.


## us-gaap:DebtDisclosureTextBlock

[0000068505-20-000006:notes:155]
Debt and Credit Facilities
Long-Term Debt

[0000068505-20-000006:notes:156]
| December 31 | 2019 |  | 2018 |
| 2.0% senior convertible notes due 2020 | $ | — |  |  | $ | 800 |  |
| Term Loan due 2021 | — |  |  | 399 |  |
| 3.5% senior notes due 2021 | — |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 597 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 593 |  |  | 591 |  |
| 1.75% senior convertible notes due 2024 | 988 |  |  | — |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 804 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 35 |  |  | 62 |  |
|  | 5,132 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3 | ) |  | (4 | ) |
| Less: current portion | (16 | ) |  | (31 | ) |
| Long-term debt | $ | 5,113 |  |  | $ | 5,289 |  |

[0000068505-20-000006:notes:157]
In February of 2018, the Company issued $500 million of 4.60% senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan. In October of 2018, the Company issued an additional $200 million on the outstanding 4.6% senior notes bringing the total outstanding principal to $700 million. The Company recognized net proceeds of $196 million after debt issuance costs and debt discounts.

[0000068505-20-000006:notes:158]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the "Term Loan"). The interest on the Term Loan was variable, indexed to the London Inter-bank Offered Rate ("LIBOR"), and paid monthly. The weighted average borrowing rate for amounts outstanding during the year ended December 31, 2019 was 3.68%.  The Company repaid all amounts borrowed under the Term Loan during the year ended December 31, 2019.

[0000068505-20-000006:notes:159]
In May of 2019, the Company issued $650 million of 4.60% senior notes due 2029.  The Company received proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts,  the Company recognized a loss of approximately $43 million related to this repurchase in Other within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-20-000006:notes:160]
In August of 2019, the Company issued a follow-on $150 million to the outstanding 4.60% senior notes due 2029 bringing the total outstanding principal to $800 million. The Company recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding approximately $2 million of accrued interest. After accelerating the amortization of debt issuance costs,  the Company recognized a loss of approximately $7 million related to this repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-20-000006:notes:161]
In 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% senior convertible notes which were scheduled to mature in September 2020 ("Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. The notes were convertible based on a conversion rate that may be adjusted for dividends declared and automatically adjusts the exercise price. In October of 2018,  the Company settled $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium.

[0000068505-20-000006:notes:162]
During the third quarter of 2019, the remaining notes were convertible based on a conversion rate of rate of 14.9186, adjusted for dividends declared, per $1,000 principal amount (equal to a conversion price of $67.03 per share). On September 5, 2019,  the Company entered into an agreement with Silver Lake Partners to settle the remaining $800 million in principal amount of the Senior Convertible Notes in two installments: (i) $200 million of notes were repurchased during the third quarter for an

[0000068505-20-000006:notes:163]
aggregate consideration of $526 million in cash, inclusive of the conversion premium and (ii) $600 million of principal paid in cash on October 7, 2019, and 5.5 million shares of common stock delivered on September 5, 2019 to settle the conversion premium. The Company recognized a gain of $4 million from the extinguishment of the 2.00% senior convertible notes in Other, net within other income (expense) in the Consolidated Statement of Operations.

[0000068505-20-000006:notes:164]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion,  the Company intends to settle the principal amount of the New Senior Convertible Notes in cash.  The Company recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital.

[0000068505-20-000006:notes:165]
During the year ended December 31, 2019,  the Company established an unsecured commercial paper program, backed by the revolving credit facility, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity.  As of December 31, 2019, the Company had no outstanding debt under the commercial paper program. During the year ended December 31, 2019, the average borrowing rate was 2.54%.

[0000068505-20-000006:notes:166]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2020—$16 million; 2021—$4 million; 2022—$562 million; 2023—$603 million; and 2024—$1.6 billion.

[0000068505-20-000006:notes:167]
Credit Facilities

[0000068505-20-000006:notes:168]
As of December 31, 2019,  the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, the Company borrowed $400 million under the facility to complete the Avigilon acquisition. The entire $400 million was re-paid during the year ended December 31, 2018. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Inter-bank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2019. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-20-000006:notes:169]
Risk Management
Foreign Currency Risk

[0000068505-20-000006:notes:170]
At December 31, 2019, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.1 billion, compared to $819 million outstanding at December 31, 2018. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-20-000006:notes:171]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2019 and the corresponding positions as of December 31, 2018:

[0000068505-20-000006:notes:172]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2019 |  | 2018 |
| Euro | $ | 134 |  |  | $ | 89 |  |
| British pound | 107 |  |  | 139 |  |
| Australian dollar | (123 | ) |  | (105 | ) |
| Chinese renminbi | (79 | ) |  | (55 | ) |
| Brazilian real | (47 | ) |  | (41 | ) |

[0000068505-20-000006:notes:173]
Net Investment Hedges

[0000068505-20-000006:notes:174]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. The Company has elected to exclude the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The

[0000068505-20-000006:notes:175]
effect of the excluded components will be amortized on a straight-line basis and recognized through interest expense. As of December 31, 2019, the Company had €94 million of net investment hedges in certain Euro functional subsidiaries and £100 million of net investment hedges in certain British pound functional subsidiaries. During the year ended December 31, 2019, the Company amortized $6 million of income from the excluded components through interest expense.

[0000068505-20-000006:notes:176]
Counterparty Risk

[0000068505-20-000006:notes:177]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2019, all of the counterparties have investment grade credit ratings. As of December 31, 2019, the credit risk with all counterparties was approximately $4 million.

[0000068505-20-000006:notes:178]
Derivative Financial Instruments

[0000068505-20-000006:notes:179]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2019 and 2018:

[0000068505-20-000006:notes:180]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2019 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | Other assets |  | $ | — |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | Other assets |  | $ | 5 |  |  | Accrued liabilities |

[0000068505-20-000006:notes:181]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2018 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other assets |  | $ | 4 |  |  | Accrued liabilities |

[0000068505-20-000006:notes:182]
The following table summarizes the effect of derivatives designated as hedging instruments, for the years ended December 31, 2019, 2018 and 2017:

[0000068505-20-000006:notes:183]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2019 |  | 2018 |  | 2017 |
| Foreign exchange contracts | $ | 8 |  |  | $ | — |  |  | $ | (3 | ) | Other comprehensive income (loss) |

[0000068505-20-000006:notes:184]
The following table summarizes the effect of derivatives not designated as hedging instruments, for the years ended December 31, 2019, 2018 and 2017:

[0000068505-20-000006:notes:185]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2019 |  | 2018 |  | 2017 |
| Foreign exchange contracts | (8 | ) |  | (14 | ) |  | 15 |  | Other income (expense) |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-20-000006:notes:186]
Income Taxes
Components of Income Tax Expense

[0000068505-20-000006:notes:187]
Components of earnings before income taxes are as follows:

[0000068505-20-000006:notes:188]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| United States | $ | 714 |  |  | $ | 980 |  |  | $ | 959 |  |
| Other nations | 287 |  |  | 122 |  |  | 117 |  |
|  | $ | 1,001 |  |  | $ | 1,102 |  |  | $ | 1,076 |  |

[0000068505-20-000006:notes:189]
Components of income tax expense (benefit) are as follows:

[0000068505-20-000006:notes:190]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| United States | $ | 94 |  |  | $ | 16 |  |  | $ | 43 |  |
| Other nations | 93 |  |  | 88 |  |  | 75 |  |
| States (U.S.) | 27 |  |  | 20 |  |  | 9 |  |
| Current income tax expense | 214 |  |  | 124 |  |  | 127 |  |
| United States | (61 | ) |  | 39 |  |  | 1,078 |  |
| Other nations | (22 | ) |  | (18 | ) |  | (8 | ) |
| States (U.S.) | (1 | ) |  | (12 | ) |  | 30 |  |
| Deferred income tax expense (benefit) | (84 | ) |  | 9 |  |  | 1,100 |  |
| Total income tax expense | $ | 130 |  |  | $ | 133 |  |  | $ | 1,227 |  |

[0000068505-20-000006:notes:191]
Differences between income tax expense computed at the U.S. federal statutory tax rate of 21% and income tax expense as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-20-000006:notes:192]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| Income tax expense at statutory rate | $ | 210 |  | 21.0 | % |  | $ | 231 |  | 21.0 | % |  | $ | 377 |  | 35.0 | % |
| State income taxes, net of federal benefit | 32 |  | 3.2 | % |  | 11 |  | 1.0 | % |  | 39 |  | 3.6 | % |
| U.S. tax on undistributed non-U.S. earnings | 6 |  | 0.6 | % |  | 6 |  | 0.5 | % |  | 20 |  | 1.9 | % |
| Non-U.S. tax expense (benefit) on non-U.S. earnings | 4 |  | 0.4 | % |  | 7 |  | 0.6 | % |  | (28 | ) | (2.6 | )% |
| U.S. tax reform | — |  | — | % |  | (79 | ) | (7.2 | )% |  | 874 |  | 81.2 | % |
| Section 199 deduction | — |  | — | % |  | — |  | — | % |  | (18 | ) | (1.7 | )% |
| Loss on the sale of investment | — |  | — | % |  | — |  | — | % |  | (21 | ) | (2.0 | )% |
| Reserve for uncertain tax positions | (3 | ) | (0.3 | )% |  | 2 |  | 0.2 | % |  | 3 |  | 0.3 | % |
| Other provisions | (3 | ) | (0.3 | )% |  | 8 |  | 0.7 | % |  | 7 |  | 0.7 | % |
| Research credits | (10 | ) | (1.0 | )% |  | (9 | ) | (0.8 | )% |  | (4 | ) | (0.4 | )% |
| Stock compensation | (27 | ) | (2.7 | )% |  | (30 | ) | (2.7 | )% |  | (14 | ) | (1.3 | )% |
| Valuation allowances | (79 | ) | (7.9 | )% |  | (14 | ) | (1.3 | )% |  | (8 | ) | (0.7 | )% |
|  | $ | 130 |  | 13.0 | % |  | $ | 133 |  | 12.0 | % |  | $ | 1,227 |  | 114.0 | % |

[0000068505-20-000006:notes:193]
The effective tax rate for 2019 is below the current U.S. federal statutory rate of 21% primarily due to the partial release of the valuation allowance recorded on the U.S. foreign tax credit carryforward and the recognition of excess tax benefits of share-based compensation.

[0000068505-20-000006:notes:194]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are the result of retirement benefit adjustments, currency translation adjustments, and fair value adjustments to available-for-sale securities. The adjustments were charges of $97 million for the year ended December 31, 2019, charges of $38 million for the year ended December 31, 2018 and benefits of $49 million for the years ended December 31, 2017.

[0000068505-20-000006:notes:195]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the 2017 U.S. Tax Cuts and Jobs Act ("the Tax Act"), dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited

[0000068505-20-000006:notes:196]
primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-20-000006:notes:197]
Undistributed foreign earnings that the Company intends to reinvest indefinitely, aggregate to $1.7 billion at December 31, 2019. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-20-000006:notes:198]
Under the Tax Act, the Company is now subjected to the global intangible low-taxed income ("GILTI") provision which requires an incremental U.S. tax on foreign income. The Company is allowed to make an accounting policy election of either recognizing deferred taxes for temporary differences expected to reverse as GILTI in future years or recognizing such taxes as a current period expense when incurred. The Company has elected to treat the tax effect of GILTI as a current period expense when incurred. As such, there are no deferred tax assets or liabilities with respect to the GILTI provisions.

[0000068505-20-000006:notes:199]
Gross deferred tax assets were $2.0 billion for both December 31, 2019 and December 31, 2018. Deferred tax assets, net of valuation allowances, were $1.6 billion at December 31, 2019 and December 31, 2018. Gross deferred tax liabilities were $854 million and $771 million at December 31, 2019 and 2018, respectively.

[0000068505-20-000006:notes:200]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-20-000006:notes:201]
| December 31 | 2019 |  | 2018 |
| Inventory | $ | 45 |  |  | $ | 28 |  |
| Accrued liabilities and allowances | 65 |  |  | 84 |  |
| Employee benefits | 392 |  |  | 402 |  |
| Capitalized items | (129 | ) |  | (68 | ) |
| Tax basis differences on investments | 2 |  |  | (2 | ) |
| Depreciation tax basis differences on fixed assets | 68 |  |  | 47 |  |
| Undistributed non-U.S. earnings | (27 | ) |  | (26 | ) |
| Tax attribute carryforwards | 471 |  |  | 613 |  |
| Business reorganization | 10 |  |  | 10 |  |
| Warranty and customer liabilities | 33 |  |  | 19 |  |
| Deferred revenue and costs | 165 |  |  | 147 |  |
| Valuation allowances | (349 | ) |  | (461 | ) |
| Operating lease assets | (125 | ) |  | — |  |
| Operating lease liabilities | 139 |  |  | — |  |
| Other | (1 | ) |  | (9 | ) |
|  | $ | 759 |  |  | $ | 784 |  |

[0000068505-20-000006:notes:202]
At December 31, 2019, 2018, and 2017 the Company had valuation allowances of $349 million, $461 million and $604 million, respectively, against its deferred tax assets, including $85 million, $86 million and $90 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance decreased $111 million during 2019 primarily due to a change in the Company's ability to utilize U.S. foreign tax credits and the expiration of tax attributes. The Company’s U.S. valuation allowance decreased $139 million during 2018 as a result of changes to the 2017 Tax Act enactment-date provision amounts and foreign tax credits expiring in 2018. The Company’s U.S. valuation increased $481 million during 2017 primarily related to the new limitations imposed on the utilization of foreign tax credits under the Tax Act. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-20-000006:notes:203]
Tax attribute carryforwards are as follows:

[0000068505-20-000006:notes:204]
| December 31, 2019 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 73 |  |  | $ | 15 |  |  | 2022-2036 |
| Foreign tax credits | — |  |  | 300 |  |  | 2020-2023 |
| General business credits | — |  |  | 1 |  |  | 2026-2037 |
| State tax losses | — |  |  | 28 |  |  | 2019-2030 |
| State tax credits | — |  |  | 20 |  |  | 2019-2031 |
| Non-U.S. subsidiaries: |  |  |  |  |  |
| Japan tax losses | 104 |  |  | 32 |  |  | 2020-2027 |
| Germany tax losses | 10 |  |  | 3 |  |  | Unlimited |
| United Kingdom tax losses | 84 |  |  | 14 |  |  | Unlimited |
| Singapore tax losses | 17 |  |  | 3 |  |  | Unlimited |
| Canada tax losses | 16 |  |  | 4 |  |  | 2034-2038 |
| Other subsidiaries tax losses | 102 |  |  | 17 |  |  | Various |
| Spain tax credits | — |  |  | 24 |  |  | 2020-2028 |
| Other subsidiaries tax credits | — |  |  | 10 |  |  | Various |
|  |  |  | $ | 471 |  |  |  |

[0000068505-20-000006:notes:205]
The Company had unrecognized tax benefits of $70 million and $76 million at December 31, 2019 and December 31, 2018, respectively, of which approximately $66 million and $30 million, if recognized, would have affected the effective tax rate for 2019 and 2018, respectively.

[0000068505-20-000006:notes:206]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-20-000006:notes:207]
|  | 2019 |  | 2018 |
| Balance at January 1 | $ | 76 |  |  | $ | 76 |  |
| Additions based on tax positions related to current year | 4 |  |  | 4 |  |
| Additions for tax positions of prior years | 3 |  |  | 1 |  |
| Reductions for tax positions of prior years | (8 | ) |  | — |  |
| Settlements and agreements | (1 | ) |  | (2 | ) |
| Lapse of statute of limitations | (4 | ) |  | (3 | ) |
| Balance at December 31 | $ | 70 |  |  | $ | 76 |  |

[0000068505-20-000006:notes:208]
The Company recorded $53 million and $51 million of unrecognized tax benefits in other liabilities at December 31, 2019 and December 31, 2018, respectively.

[0000068505-20-000006:notes:209]
The Internal Revenue Service ("IRS") is currently examining the Company's 2014 and 2015 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-20-000006:notes:210]
| Jurisdiction | Tax Years |
| United States | 2014-2019 |
| Australia | 2015-2019 |
| Canada | 2015-2019 |
| Germany | 2014-2019 |
| India | 1997-2019 |
| Israel | 2016-2019 |
| Poland | 2015-2019 |
| Malaysia | 2012-2019 |
| United Kingdom | 2018-2019 |

[0000068505-20-000006:notes:211]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-20-000006:notes:212]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $7 million tax charge to a $27 million tax benefit, with cash payments not to exceed $20 million.

[0000068505-20-000006:notes:213]
At December 31, 2019, the Company had $29 million accrued for interest and $16 million accrued for penalties on unrecognized tax benefits. At December 31, 2018, the Company had $30 million and $17 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-20-000006:notes:214]
Retirement Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-20-000006:notes:215]
U.S. Pension Benefit Plans

[0000068505-20-000006:notes:216]
The Company’s non-contributory U.S. defined benefit plan (the "U.S. Pension Plan") provides benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. In December 2008, the Company amended the U.S. Pension Plan and MSSP (together the "U.S. Pension Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-20-000006:notes:217]
In December 2019, the Company completed a voluntary lump-sum election window offered to certain participants of the U.S. Pension Plan. The aggregate dollar amount of lump-sum elections by approximately 6,300 participants was $836 million, and accordingly, this amount was paid out of plan assets prior to December 31, 2019.  These actions resulted in a reduction of our projected benefit obligation, absent of actuarial losses experienced from decreases in interest rates, of $1.0 billion and a settlement loss of $359 million recorded within “Other charges” on the Consolidated Statement of Operations.

[0000068505-20-000006:notes:218]
Postretirement Health Care Benefits Plan

[0000068505-20-000006:notes:219]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of amendments, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-20-000006:notes:220]
These series of amendments to the Postretirement Health Care Benefits Plan resulted in a reduction in the postretirement benefit obligation. A substantial portion of the decrease related to prior service credits and will be amortized as a credit to the Consolidated Statements of Operations over approximately five years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan.

[0000068505-20-000006:notes:221]
Non U.S. Pension Benefit Plans

[0000068505-20-000006:notes:222]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-20-000006:notes:223]
In June 2015, the Company amended its Non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-20-000006:notes:224]
During the years ended December 31, 2017, the Company offered lump-sum settlements to certain participants in the Non-U.S. defined benefit plan within the United Kingdom. The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments. As a result of the actions taken, the Company recorded settlement losses of $48 million in 2017, respectively, which are recorded within Other income (expense) within the Consolidated Statement of Operations.

[0000068505-20-000006:notes:225]
During 2019, the Motorola Solutions United Kingdom defined benefit plan trustees decided to exercise their discretion on early retirement benefit reductions. This action resulted in a reduction of the projected benefit obligation of approximately $83 million related to prior service credits that will be amortized as a credit to the Consolidated Statements of Operations over approximately twenty-nine years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan.

[0000068505-20-000006:notes:226]
Net Periodic Cost (Benefit)

[0000068505-20-000006:notes:227]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-20-000006:notes:228]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 202 |  |  | 186 |  |  | 185 |  |  | 36 |  |  | 38 |  |  | 40 |  |  | 3 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (275 | ) |  | (270 | ) |  | (229 | ) |  | (85 | ) |  | (92 | ) |  | (92 | ) |  | (10 | ) |  | (10 | ) |  | (10 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 46 |  |  | 57 |  |  | 44 |  |  | 15 |  |  | 15 |  |  | 16 |  |  | 4 |  |  | 4 |  |  | 5 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (15 | ) |  | (15 | ) |  | (18 | ) |
| Settlement loss | 359 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 48 |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | 332 |  |  | $ | (27 | ) |  | $ | — |  |  | $ | (32 | ) |  | $ | (36 | ) |  | $ | 15 |  |  | $ | (18 | ) |  | $ | (19 | ) |  | $ | (20 | ) |

[0000068505-20-000006:notes:229]
The status of the Company’s plans is as follows:

[0000068505-20-000006:notes:230]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 4,864 |  |  | $ | 5,235 |  |  | $ | 1,654 |  |  | $ | 1,844 |  |  | $ | 72 |  |  | $ | 85 |  |
| Service cost | — |  |  | — |  |  | 2 |  |  | 3 |  |  | — |  |  | — |  |
| Interest cost | 202 |  |  | 186 |  |  | 36 |  |  | 38 |  |  | 3 |  |  | 2 |  |
| Plan amendments | — |  |  | — |  |  | (83 | ) |  | 10 |  |  | — |  |  | — |  |
| Actuarial loss (gain) | 609 |  |  | (452 | ) |  | 207 |  |  | (97 | ) |  | 4 |  |  | (8 | ) |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 44 |  |  | (98 | ) |  | — |  |  | — |  |
| Benefit payments | (948 | ) |  | (105 | ) |  | (46 | ) |  | (46 | ) |  | (6 | ) |  | (7 | ) |
| Benefit obligation at December 31 | $ | 4,727 |  |  | $ | 4,864 |  |  | $ | 1,814 |  |  | $ | 1,654 |  |  | $ | 73 |  |  | $ | 72 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,673 |  |  | $ | 3,614 |  |  | $ | 1,438 |  |  | $ | 1,590 |  |  | $ | 133 |  |  | $ | 151 |  |
| Return on plan assets | 873 |  |  | (339 | ) |  | 188 |  |  | (28 | ) |  | 33 |  |  | (12 | ) |
| Company contributions | 3 |  |  | 503 |  |  | 8 |  |  | 8 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 53 |  |  | (88 | ) |  | — |  |  | — |  |
| Benefit payments | (948 | ) |  | (105 | ) |  | (46 | ) |  | (44 | ) |  | (6 | ) |  | (6 | ) |
| Fair value at December 31 | $ | 3,601 |  |  | $ | 3,673 |  |  | $ | 1,641 |  |  | $ | 1,438 |  |  | $ | 160 |  |  | $ | 133 |  |
| Funded status of the plan | $ | (1,126 | ) |  | $ | (1,191 | ) |  | $ | (173 | ) |  | $ | (216 | ) |  | $ | 87 |  |  | $ | 61 |  |
| Unrecognized net loss | 1,935 |  |  | 2,329 |  |  | 648 |  |  | 543 |  |  | 42 |  |  | 74 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (84 | ) |  | 11 |  |  | (20 | ) |  | (35 | ) |
| Prepaid pension cost | $ | 809 |  |  | $ | 1,138 |  |  | $ | 391 |  |  | $ | 338 |  |  | $ | 109 |  |  | $ | 100 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3 | ) |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (1,123 | ) |  | (1,188 | ) |  | (299 | ) |  | (265 | ) |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 126 |  |  | 49 |  |  | 87 |  |  | 61 |  |
| Deferred income taxes | 463 |  |  | 561 |  |  | 60 |  |  | 55 |  |  | 9 |  |  | 10 |  |
| Accumulated other comprehensive loss | 1,472 |  |  | 1,768 |  |  | 504 |  |  | 499 |  |  | 13 |  |  | 29 |  |
| Prepaid pension cost | $ | 809 |  |  | $ | 1,138 |  |  | $ | 391 |  |  | $ | 338 |  |  | $ | 109 |  |  | $ | 100 |  |

[0000068505-20-000006:notes:231]
The benefit obligation and plan assets for the Company's U.S. Pension Benefit Plan and Postretirement Health Care Benefit Plan are measured as of December 31, 2019. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-20-000006:notes:232]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, the Company amortizes gains and losses over periods ranging from ten to thirty-one years. Prior service costs will be amortized over periods ranging from two to five years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-20-000006:notes:233]
The net periodic cost for 2020 will include amortization of the unrecognized net loss for the U.S. Pension Benefit Plans and Non U.S. Pension Benefit Plans, currently included in Accumulated other comprehensive loss, of $58 million and $12 million, respectively. It is estimated that the 2020 net periodic expense for the Postretirement Health Care Benefits Plan will include amortization of net periodic benefits of $11 million, comprised of unrecognized net losses and prior service benefits, currently included in Accumulated other comprehensive loss.

[0000068505-20-000006:notes:234]
Actuarial Assumptions

[0000068505-20-000006:notes:235]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-20-000006:notes:236]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined pension benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-20-000006:notes:237]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-20-000006:notes:238]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Discount rate | 4.25 | % |  | 3.57 | % |  | 2.37 | % |  | 2.08 | % |  | 3.85 | % |  | 3.16 | % |
| Investment return assumption | 6.85 | % |  | 6.95 | % |  | 5.23 | % |  | 5.18 | % |  | 6.90 | % |  | 7.00 | % |

[0000068505-20-000006:notes:239]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-20-000006:notes:240]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Discount rate | 3.32 | % |  | 4.47 | % |  | 1.82 | % |  | 2.67 | % |  | 3.15 | % |  | 4.29 | % |
| Future compensation increase rate | n/a |  |  | n/a |  |  | 0.52 | % |  | 0.52 | % |  | n/a |  |  | n/a |  |

[0000068505-20-000006:notes:241]
The accumulated benefit obligations for the plans were as follows:

[0000068505-20-000006:notes:242]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |
| December 31 | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Accumulated benefit obligation | $ | 4,727 |  |  | $ | 4,864 |  |  | $ | 1,809 |  |  | $ | 1,649 |  |

[0000068505-20-000006:notes:243]
The Company used "Mortality Improvement Scale MP-2018" to calculate the 2019 U.S. projected benefit obligations and the "Mortality Improvement Scale MP-2017" to calculate the 2018 U.S. projected benefit obligations.

[0000068505-20-000006:notes:244]
Investment Policy

[0000068505-20-000006:notes:245]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-20-000006:notes:246]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-20-000006:notes:247]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 25 | % |  | 30 | % |  | 28 | % |  | 32 | % |
| Fixed income securities | 56 | % |  | 51 | % |  | 52 | % |  | 49 | % |
| Cash and other investments | 19 | % |  | 19 | % |  | 20 | % |  | 19 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 24 | % |  | 28 | % |  | 29 | % |  | 31 | % |
| Fixed income securities | 57 | % |  | 50 | % |  | 54 | % |  | 48 | % |
| Cash and other investments | 19 | % |  | 22 | % |  | 17 | % |  | 21 | % |

[0000068505-20-000006:notes:248]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-20-000006:notes:249]
Cash Funding

[0000068505-20-000006:notes:250]
The Company made $3 million and $503 million of contributions to its U.S. Pension Benefit Plans during 2019 and 2018, respectively. The Company contributed $8 million to its Non U.S. Pension Benefit Plans during 2019 and 2018. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2019 or 2018.

[0000068505-20-000006:notes:251]
Expected Future Benefit Payments

[0000068505-20-000006:notes:252]
The following benefit payments are expected to be paid:

[0000068505-20-000006:notes:253]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2020 | $ | 133 |  |  | $ | 48 |  |  | $ | 7 |  |
| 2021 | 150 |  |  | 48 |  |  | 6 |  |
| 2022 | 169 |  |  | 49 |  |  | 6 |  |
| 2023 | 184 |  |  | 51 |  |  | 5 |  |
| 2024 | 201 |  |  | 52 |  |  | 5 |  |
| 2025-2029 | 1,261 |  |  | 276 |  |  | 22 |  |

[0000068505-20-000006:notes:254]
Other Benefit Plans

[0000068505-20-000006:notes:255]
Split-Dollar Life Insurance Arrangements

[0000068505-20-000006:notes:256]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-20-000006:notes:257]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2019, 2018 and 2017. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $67 million and $61 million as of December 31, 2019 and December 31, 2018, respectively.

[0000068505-20-000006:notes:258]
Deferred Compensation Plan

[0000068505-20-000006:notes:259]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-20-000006:notes:260]
Defined Contribution Plan

[0000068505-20-000006:notes:261]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the 401(k) plan is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2019, 2018 and 2017 were $32 million, $31 million and $28 million, respectively.

[0000068505-20-000006:notes:262]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2019, 2018, and 2017 the Company made no discretionary contributions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-20-000006:notes:263]
Share-Based Compensation and Other Incentive Plans
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option and stock appreciation right granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-20-000006:notes:264]
Restricted stock (“RS”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees. The grants are restricted in such that they are subject to vesting conditions; however, restricted stock holders have voting rights, and the rights to earn dividends on unvested shares.

[0000068505-20-000006:notes:265]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-20-000006:notes:266]
Performance-based stock options (“performance options”), market stock units ("MSUs"), and performance stock units ("PSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years. PSUs have been granted as a portion of the Long Range Incentive Plan (“LRIP”) awards issued to certain Company executive officers. The PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual total shareholder return ("TSR") compared to the S&P 500 over the three-year performance period.

[0000068505-20-000006:notes:267]
On August 25, 2015, in conjunction with the issuance of the Senior Convertible Notes, and on March 9, 2017, the Company approved grants of performance-contingent stock options (“PCSOs”) to certain executive officers which were fully vested as of December 31, 2019. The August 25, 2015 awards have a seven-year term and a per share exercise price of $68.50. The March 9, 2017 awards have a five-and-a-half-year term and a per share exercise price of $81.37.

[0000068505-20-000006:notes:268]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2019, 2018 and 2017, employees purchased 0.6 million, 0.8 million and 0.8 million shares, respectively, at purchase prices of $108.96 and $120.12, $72.96 and $88.84, and $63.96 and $72.11, respectively.

[0000068505-20-000006:notes:269]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-20-000006:notes:270]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2019, 2018 and 2017 was $29.14, $23.31 and $15.16, respectively, using the following weighted-average assumptions:

[0000068505-20-000006:notes:271]
|  | 2019 |  | 2018 |  | 2017 |
| Expected volatility | 23.8 | % |  | 24.7 | % |  | 24.0 | % |
| Risk-free interest rate | 2.3 | % |  | 2.7 | % |  | 2.1 | % |
| Dividend yield | 2.5 | % |  | 2.4 | % |  | 3.5 | % |
| Expected life (years) | 6.0 |  |  | 5.9 |  |  | 5.9 |  |

[0000068505-20-000006:notes:272]
The Company calculates the value of each performance option, MSU, PSU, and PCSO using a Monte Carlo simulation option pricing model, estimated on the date of grant. The fair values of performance options, MSUs, and PSUs granted during 2019 were $46.15, $138.00 and $203.61, respectively. The fair values of performance options and MSUs granted during 2018 were $42.19 and $125.33, respectively. The fair value of performance options, MSUs, and PCSOs granted during 2017 was $21.47, $85.74 and $7.76, respectively. The following assumptions were used for the calculations.

[0000068505-20-000006:notes:273]
|  | 2019Performance Options |  | 2018Performance Options |  | 2017Performance Options |
| Expected volatility of common stock | 22.4 | % |  | 25.0 | % |  | 24.1 | % |
| Expected volatility of the S&P 500 | 25.1 | % |  | 25.3 | % |  | 25.6 | % |
| Risk-free interest rate | 2.3 | % |  | 2.7 | % |  | 2.4 | % |
| Dividend yield | 2.7 | % |  | 3.1 | % |  | 3.7 | % |
| Expected life (years) | 6.5 |  |  | 6.5 |  |  | 6.5 |  |

[0000068505-20-000006:notes:274]
|  | 2019Market Stock Units |  | 2018Market Stock Units |  | 2017Market Stock Units |
| Expected volatility of common stock | 22.4 | % |  | 25.0 | % |  | 24.1 | % |
| Risk-free interest rate | 2.2 | % |  | 2.4 | % |  | 1.7 | % |
| Dividend yield | 2.0 | % |  | 2.2 | % |  | 2.9 | % |

[0000068505-20-000006:notes:275]
|  | 2019PSUs |
| Expected volatility of common stock | 20.6 | % |
| Expected volatility of the S&P 500 | 25.0 | % |
| Risk-free interest rate | 2.2 | % |
| Dividend yield | 1.6 | % |
| Expected life (years) | 3 |  |

[0000068505-20-000006:notes:276]
|  | 2017PCSOs | 2015PCSOs |
| Expected volatility | 24.1 | % | 26.0 | % |
| Risk-free interest rate | 1.8 | % | 1.5 | % |
| Dividend yield | 3.0 | % | 3.1 | % |
| Expected life (years) | 3.5 |  | 5 |  |

[0000068505-20-000006:notes:277]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, PSUs, and PCSOs. The selection of the implied volatility approach was based upon the availability of actively-traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. At the conclusion of each three-year PSU and performance option cycle, the Company uses the historical volatility as the expected volatility to calculate the actual TSR compared to the S&P 500.

[0000068505-20-000006:notes:278]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-20-000006:notes:279]
The Company has applied forfeiture rates, estimated based on historical data, of 10% to the stock option fair values calculated by the Black-Scholes option pricing model and 15% to RSUs. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-20-000006:notes:280]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, at December 31, 2019 (in thousands, except exercise price and years):

[0000068505-20-000006:notes:281]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| Under $50 | 1,192 |  |  | $ | 38 |  |  | 1 |  | 1,186 |  |  | $ | 39 |  |  | 1 |
| $51-$60 | 646 |  |  | 54 |  |  | 3 |  | 646 |  |  | 54 |  |  | 3 |
| $61-$70 | 1,610 |  |  | 68 |  |  | 3 |  | 1,610 |  |  | 68 |  |  | 3 |
| $71-$80 | 489 |  |  | 72 |  |  | 6 |  | 480 |  |  | 71 |  |  | 6 |
| $81-$90 | 433 |  |  | 82 |  |  | 7 |  | 70 |  |  | 83 |  |  | 7 |
| $91-$100 | 8 |  |  | 93 |  |  | 7 |  | 5 |  |  | 93 |  |  | 8 |
| $101 and over | 773 |  |  | 126 |  |  | 9 |  | 53 |  |  | 114 |  |  | 8 |
|  | 5,151 |  |  |  |  |  |  | 4,050 |  |  |  |  |  |

[0000068505-20-000006:notes:282]
As of December 31, 2019, the weighted average contractual life for options outstanding and exercisable was four and three years, respectively.

[0000068505-20-000006:notes:283]
Current Year Activity

[0000068505-20-000006:notes:284]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-20-000006:notes:285]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2019 | 3,411 |  |  | $ | 57 |  |  | 1,097 |  |  | $ | 84 |  |  | — |  |  | $ | — |  |
| Granted | 266 |  |  | 137 |  |  | 591 |  |  | 132 |  |  | 440 |  |  | 119 |  |
| Releases/Exercised | (650 | ) |  | 56 |  |  | (566 | ) |  | 82 |  |  | — |  |  | — |  |
| Forfeited/Canceled | (44 | ) |  | 107 |  |  | (75 | ) |  | 104 |  |  | — |  |  | — |  |
| Balance as of December 31, 2019 | 2,983 |  |  | $ | 63 |  |  | 1,047 |  |  | $ | 111 |  |  | 440 |  |  | $ | 119 |  |
| Awards exercisable | 2,460 |  |  | 52 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-20-000006:notes:286]
|  | Performance Options* |  | Market Stock Units |  | Performance Stock Units |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2019 | 2,159 |  |  | $ | 74 |  |  | 122 |  |  | $ | 102 |  |  | — |  |  | $ | — |  |
| Granted | 158 |  |  | 139 |  |  | 53 |  |  | 138 |  |  | 84 |  |  | 204 |  |
| Releases/Exercised | (512 | ) |  | 74 |  |  | (105 | ) |  | 91 |  |  | (57 | ) |  | 137 |  |
| Adjustment for payout factor | 363 |  |  | 71 |  |  | 42 |  |  | 86 |  |  | — |  |  | — |  |
| Balance as of December 31, 2019 | 2,168 |  |  | $ | 78 |  |  | 112 |  |  | $ | 123 |  |  | 27 |  |  | $ | 204 |  |
| Awards exercisable | 1,590 |  |  | 69 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-20-000006:notes:287]
* Inclusive of PCSO awards

[0000068505-20-000006:notes:288]
At December 31, 2019 and 2018, 7.2 million and 8.6 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-20-000006:notes:289]
Total Share-Based Compensation Expense

[0000068505-20-000006:notes:290]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-20-000006:notes:291]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 14 |  |  | $ | 11 |  |  | $ | 9 |  |
| Selling, general and administrative expenses | 62 |  |  | 45 |  |  | 43 |  |
| Research and development expenditures | 42 |  |  | 17 |  |  | 14 |  |
| Share-based compensation expense included in Operating earnings | 118 |  |  | 73 |  |  | 66 |  |
| Tax benefit | 22 |  |  | 18 |  |  | 22 |  |
| Share-based compensation expense, net of tax | $ | 96 |  |  | $ | 55 |  |  | $ | 44 |  |
| Decrease in basic earnings per share | $ | (0.57 | ) |  | $ | (0.34 | ) |  | $ | (0.27 | ) |
| Decrease in diluted earnings per share | $ | (0.55 | ) |  | $ | (0.32 | ) |  | $ | (0.27 | ) |

[0000068505-20-000006:notes:292]
At December 31, 2019, the Company had unrecognized compensation expense related to all share based awards of $122 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately three years and $5 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. The aggregate fair value of outstanding share based awards as of December 31, 2019 was $264 million.

[0000068505-20-000006:notes:293]
Cash received from stock option exercises and the employee stock purchase plan was $114 million, $168 million, and $82 million for the years ended December 31, 2019, 2018, and 2017, respectively. The total intrinsic value of options exercised during the years ended December 31, 2019, 2018, and 2017 was $113 million, $125 million, and $31 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2019 was $471 million and $415 million, respectively, based on a December 31, 2019 stock price of $160.96 per share.

[0000068505-20-000006:notes:294]
Motorola Solutions Incentive Plans

[0000068505-20-000006:notes:295]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2019, 2018 and 2017 was $146 million, $143 million and $122 million, respectively.

[0000068505-20-000006:notes:296]
Long-Range Incentive Plan

[0000068505-20-000006:notes:297]
The Long-Range Incentive Plan (“LRIP”) rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. The expense for LRIP for the years ended December 31, 2019, 2018 and 2017 was $21 million, $31 million and $9 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-20-000006:notes:298]
Fair Value Measurements
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-20-000006:notes:299]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-20-000006:notes:300]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-20-000006:notes:301]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-20-000006:notes:302]
Investments and Derivatives

[0000068505-20-000006:notes:303]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2019 and December 31, 2018 were as follows:

[0000068505-20-000006:notes:304]
| December 31, 2019 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |
| Common stock and equivalents | 25 |  |  | — |  |  | 25 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |

[0000068505-20-000006:notes:305]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | 1 |  |  | — |  |  | 1 |  |
| Common stock and equivalents | 19 |  |  | — |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |

[0000068505-20-000006:notes:306]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-20-000006:notes:307]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2019 and 2018 were as follows:

[0000068505-20-000006:notes:308]
| December 31, 2019 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Commingled funds | 1,320 |  |  | 555 |  |  | 1,875 |  |
| Government fixed income securities | — |  |  | 529 |  |  | 529 |  |
| Corporate fixed income securities | — |  |  | 959 |  |  | 959 |  |
| Short-term investment funds | 179 |  |  | — |  |  | 179 |  |
| Total investment securities | $ | 1,511 |  |  | $ | 2,043 |  |  | $ | 3,554 |  |
| Accrued income receivable |  |  |  |  | 20 |  |
| Cash |  |  |  |  | 27 |  |
| Fair value plan assets |  |  |  |  | $ | 3,601 |  |

[0000068505-20-000006:notes:309]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Commingled funds | 2,074 |  |  | — |  |  | 2,074 |  |
| Government fixed income securities | 13 |  |  | 340 |  |  | 353 |  |
| Corporate fixed income securities | — |  |  | 964 |  |  | 964 |  |
| Short-term investment funds | 243 |  |  | — |  |  | 243 |  |
| Total investment securities | $ | 2,340 |  |  | $ | 1,304 |  |  | $ | 3,644 |  |
| Accrued income receivable |  |  |  |  | 16 |  |
| Cash |  |  |  |  | 13 |  |
| Fair value plan assets |  |  |  |  | $ | 3,673 |  |

[0000068505-20-000006:notes:310]
Non-U.S. Pension Benefit Plans

[0000068505-20-000006:notes:311]
| December 31, 2019 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 69 |  |  | $ | — |  |  | $ | 69 |  |
| Commingled funds | 217 |  |  | 181 |  |  | 398 |  |
| Government fixed income securities | 4 |  |  | 899 |  |  | 903 |  |
| Short-term investment funds | 170 |  |  | — |  |  | 170 |  |
| Total investment securities | $ | 460 |  |  | $ | 1,080 |  |  | $ | 1,540 |  |
| Cash |  |  |  |  | 4 |  |
| Accrued income receivable |  |  |  |  | 48 |  |
| Insurance contracts |  |  |  |  | 49 |  |
| Fair value plan assets |  |  |  |  | $ | 1,641 |  |

[0000068505-20-000006:notes:312]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Equities | $ | 140 |  |  | $ | — |  |  | $ | 140 |  |
| Commingled funds | 476 |  |  | 16 |  |  | 492 |  |
| Government fixed income securities | 4 |  |  | 647 |  |  | 651 |  |
| Short-term investment funds | 60 |  |  | — |  |  | 60 |  |
| Total investment securities | $ | 680 |  |  | $ | 663 |  |  | $ | 1,343 |  |
| Cash |  |  |  |  | 3 |  |
| Accrued income receivable |  |  |  |  | 42 |  |
| Insurance contracts |  |  |  |  | 50 |  |
| Fair value plan assets |  |  |  |  | $ | 1,438 |  |

[0000068505-20-000006:notes:313]
| December 31, 2019 | Level 1 |  | Level 2 |  | Total |
| Commingled funds | $ | 59 |  |  | $ | 25 |  |  | $ | 84 |  |
| Government fixed income securities | — |  |  | 24 |  |  | 24 |  |
| Corporate fixed income securities | — |  |  | 43 |  |  | 43 |  |
| Short-term investment funds | 8 |  |  | — |  |  | 8 |  |
| Total investment securities | $ | 67 |  |  | $ | 92 |  |  | $ | 159 |  |
| Accrued income receivable |  |  |  |  | $ | 1 |  |
| Fair value plan assets |  |  |  |  | $ | 160 |  |

[0000068505-20-000006:notes:314]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Commingled funds | 74 |  |  | — |  |  | 74 |  |
| Government fixed income securities | — |  |  | 12 |  |  | 12 |  |
| Corporate fixed income securities | — |  |  | 34 |  |  | 34 |  |
| Short-term investment funds | 9 |  |  | — |  |  | 9 |  |
| Total investment securities | $ | 83 |  |  | $ | 46 |  |  | $ | 129 |  |
| Cash |  |  |  |  | 4 |  |
| Fair value plan assets |  |  |  |  | $ | 133 |  |

[0000068505-20-000006:notes:315]
The following is a description of the categories of investments:

[0000068505-20-000006:notes:316]
Equities — A diversified portfolio of corporate common stock and preferred stock.

[0000068505-20-000006:notes:317]
Commingled funds — A diversified portfolio of assets that includes corporate common stock, preferred stock, emerging market and high-yield fixed income securities among others.

[0000068505-20-000006:notes:318]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-20-000006:notes:319]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-20-000006:notes:320]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-20-000006:notes:321]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-20-000006:notes:322]
At December 31, 2019, the Company had $322 million of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $734 million at December 31, 2018. The money market funds had quoted market prices that are approximately at par.

[0000068505-20-000006:notes:323]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2019 was $5.5 billion (Level 2), compared to a face value of $5.1 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-20-000006:notes:324]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-20-000006:notes:325]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-20-000006:notes:326]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-20-000006:notes:327]
| December 31 | 2019 |  | 2018 |
| Long-term receivables, gross | $ | 62 |  |  | $ | 33 |  |
| Less allowance for losses | (2 | ) |  | (2 | ) |
| Long-term receivables | $ | 60 |  |  | $ | 31 |  |
| Less current portion | (19 | ) |  | (7 | ) |
| Non-current long-term receivables | $ | 41 |  |  | $ | 24 |  |

[0000068505-20-000006:notes:328]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized Interest income on long-term receivables of $1 million for each of the years ended December 31, 2019, 2018 and 2017.

[0000068505-20-000006:notes:329]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company.

[0000068505-20-000006:notes:330]
The Company had outstanding commitments to provide long-term financing to third-parties totaling $78 million at December 31, 2019, compared to $62 million at December 31, 2018.

[0000068505-20-000006:notes:331]
Sales of Receivables

[0000068505-20-000006:notes:332]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements.

[0000068505-20-000006:notes:333]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2019, 2018 and 2017.

[0000068505-20-000006:notes:334]
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |
| Accounts receivable sales proceeds | $ | 34 |  |  | $ | 77 |  |  | $ | 193 |  |
| Long-term receivables sales proceeds | 265 |  |  | 270 |  |  | 284 |  |
| Total proceeds from receivable sales | $ | 299 |  |  | $ | 347 |  |  | $ | 477 |  |

[0000068505-20-000006:notes:335]
The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-20-000006:notes:336]
At December 31, 2019, the Company had retained servicing obligations for $984 million of long-term receivables, compared to $970 million of long-term receivables at December 31, 2018. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-20-000006:notes:337]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-20-000006:notes:338]
An aging analysis of financing receivables at December 31, 2019 and December 31, 2018 is as follows:

[0000068505-20-000006:notes:339]
| December 31, 2019 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 31 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |
| Commercial loans and leases secured | 31 |  |  | 3 |  |  | — |  |  | 5 |  |
| Long-term receivables, including current portion | $ | 62 |  |  | $ | 4 |  |  | $ | 1 |  |  | $ | 5 |  |

[0000068505-20-000006:notes:340]
| December 31, 2018 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 22 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 11 |  |  | — |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 33 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |

[0000068505-20-000006:notes:341]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.

[0000068505-20-000006:notes:342]
The Company’s policy for valuing the allowance for credit losses is to review all customer financing receivables for collectability on an individual receivable basis. For those receivables where collection risk is probable, the Company calculates the value of impairment based on the net present value of expected future cash flows from the customer.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-20-000006:notes:343]
Commitments and Contingencies
Purchase Obligations

[0000068505-20-000006:notes:344]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow it to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable.

[0000068505-20-000006:notes:345]
As of December 31, 2019, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2024. The Company expects to make total payments of $142 million under these arrangements as follows: $95 million in 2020, $32 million in 2021, $8 million in 2022, $5 million in 2022, and $2 million in 2024.

[0000068505-20-000006:notes:346]
The Company outsources certain corporate functions, such as benefit administration and information technology-related services, under various contracts, the longest of which is expected to expire in 2023. The remaining payments under these contracts are approximately $48 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-20-000006:notes:347]
Legal Matters

[0000068505-20-000006:notes:348]
The Company is a defendant in various lawsuits, claims, and actions that arise in the normal course of business. While the outcome of these matters is currently not determinable, the Company does not expect the ultimate disposition of these matters to have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on the Company's results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-20-000006:notes:349]
Indemnifications

[0000068505-20-000006:notes:350]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-20-000006:notes:351]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at December 31, 2019.

[0000068505-20-000006:notes:352]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-20-000006:notes:353]
Information by Segment and Geographic Region
The Company conducts its business globally and manages it through the following two segments:

[0000068505-20-000006:notes:354]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security devices and infrastructure, and the implementation and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video security solutions, including video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video security solutions and typically managing a mobile workforce. In 2019, the segment’s net sales were $5.3 billion, representing 68% of the Company's consolidated net sales.

[0000068505-20-000006:notes:355]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and commercial customers. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on-premise and “as a service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced platforms include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. In 2019, the segment’s net sales were $2.6 billion, representing 32% of the Company's consolidated net sales.

[0000068505-20-000006:notes:356]
For the years ended December 31, 2019, 2018 and 2017, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-20-000006:notes:357]
Segment Information

[0000068505-20-000006:notes:358]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-20-000006:notes:359]
|  | Net Sales |  | Operating Earnings |
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Products and Systems Integration | $ | 5,329 |  |  | $ | 5,100 |  |  | $ | 4,513 |  |  | $ | 994 |  |  | $ | 854 |  |  | $ | 969 |  |
| Software and Services | 2,558 |  |  | 2,243 |  |  | 1,867 |  |  | 587 |  |  | 401 |  |  | 315 |  |
|  | $ | 7,887 |  |  | $ | 7,343 |  |  | $ | 6,380 |  |  | 1,581 |  |  | 1,255 |  |  | 1,284 |  |
| Total other expense |  |  |  |  |  |  | (580 | ) |  | (153 | ) |  | (208 | ) |
| Net earnings before income taxes |  |  |  |  |  |  | $ | 1,001 |  |  | $ | 1,102 |  |  | $ | 1,076 |  |

[0000068505-20-000006:notes:360]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-20-000006:notes:361]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Products and Systems Integration | $ | 98 |  |  | $ | 72 |  |  | $ | 113 |  |  | $ | 82 |  |  | $ | 71 |  |  | $ | 69 |  |
| Software and Services | 150 |  |  | 125 |  |  | 114 |  |  | 104 |  |  | 101 |  |  | 123 |  |
|  | $ | 248 |  |  | $ | 197 |  |  | $ | 227 |  |  | $ | 186 |  |  | $ | 172 |  |  | $ | 192 |  |

[0000068505-20-000006:notes:362]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-20-000006:notes:363]
Geographic Area Information

[0000068505-20-000006:notes:364]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 5,006 |  |  | $ | 4,361 |  |  | $ | 3,725 |  |  | $ | 6,749 |  |  | $ | 5,441 |  |  | $ | 5,138 |  |
| United Kingdom | 692 |  |  | 638 |  |  | 558 |  |  | 2,460 |  |  | 2,284 |  |  | 2,329 |  |
| Canada | 270 |  |  | 303 |  |  | 251 |  |  | 1,040 |  |  | 1,014 |  |  | 97 |  |
| Other, net of eliminations | 1,919 |  |  | 2,041 |  |  | 1,846 |  |  | 393 |  |  | 670 |  |  | 644 |  |
|  | $ | 7,887 |  |  | $ | 7,343 |  |  | $ | 6,380 |  |  | $ | 10,642 |  |  | $ | 9,409 |  |  | $ | 8,208 |  |

[0000068505-20-000006:notes:365]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-20-000006:notes:366]
Reorganization of Businesses
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-20-000006:notes:367]
During 2019, 2018, and 2017 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. As a result, the Company communicated its plan to close one of its manufacturing facilities in Europe during the fourth quarter of 2018 resulting in a charge of $44 million and impacting 165 employees, primarily within the Products and Systems Integration segment. The remainder of the initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-20-000006:notes:368]
2019 Charges

[0000068505-20-000006:notes:369]
During 2019, the Company recorded net reorganization of business charges of $57 million, including $17 million of charges in Costs of sales and $40 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $57 million were charges of $64 million for employee separation costs, $5 million for exit costs, partially offset by $12 million of reversals of accruals no longer needed.

[0000068505-20-000006:notes:370]
The following table displays the net charges incurred by segment:

[0000068505-20-000006:notes:371]
| Year ended December 31 | 2019 |
| Products and Systems Integration | $ | 45 |  |
| Software and Services | 12 |  |
|  | $ | 57 |  |

[0000068505-20-000006:notes:372]
The following table displays a rollforward of the reorganization of businesses accruals established January 1, 2019 to December 31, 2019:

[0000068505-20-000006:notes:373]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Reorganization costs | 84 |  |  | 69 |  |  | (12 | ) |  | (63 | ) |  | 78 |  |

[0000068505-20-000006:notes:374]
Employee Separation Costs

[0000068505-20-000006:notes:375]
At January 1, 2019, the Company had an accrual of $84 million for employee separation costs. The 2019 additional charges of $69 million include severance costs for approximately 700 employees, of which 200 were direct employees and 500 were indirect employees. The adjustments of $12 million reflect reversals of accruals no longer needed. The $63 million used in 2019 reflects cash payments to severed employees. The remaining accrual of $78 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2019, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 100 employees to be separated in 2020.

[0000068505-20-000006:notes:376]
As of January 1, 2019, accruals for exit costs are included in Operating lease liabilities with an offsetting impairment to the Company's ROU assets (see Note 3).

[0000068505-20-000006:notes:377]
2018 Charges

[0000068505-20-000006:notes:378]
During 2018, the Company recorded net reorganization of business charges of $120 million, including $59 million of charges in Costs of sales and $61 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $120 million were charges of $122 million for employee separation costs and $16 million for exit costs, partially offset by $18 million of reversals of accruals no longer needed.

[0000068505-20-000006:notes:379]
| Year ended December 31 | 2018 |
| Products and Systems Integration | $ | 101 |  |
| Software and Services | 19 |  |
|  | $ | 120 |  |

[0000068505-20-000006:notes:380]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2018 to December 31, 2018:

[0000068505-20-000006:notes:381]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 9 |  |  | $ | 16 |  |  | $ | — |  |  | $ | (4 | ) |  | $ | 21 |  |
| Employee separation costs | 41 |  |  | 122 |  |  | (18 | ) |  | (61 | ) |  | 84 |  |
|  | $ | 50 |  |  | $ | 138 |  |  | $ | (18 | ) |  | $ | (65 | ) |  | $ | 105 |  |

[0000068505-20-000006:notes:382]
Exit Costs

[0000068505-20-000006:notes:383]
At January 1, 2018, the Company had $9 million accrual for exit costs. There were $16 million of additional charges in 2018. The $4 million used in 2018 reflects cash payments. The remaining accrual of $21 million, which the current portion was included in Accrued liabilities and the non-current portion was included in Other liabilities in the Company’s Consolidated Balance Sheet at December 31, 2018, primarily represented future cash payments for lease obligations.

[0000068505-20-000006:notes:384]
At January 1, 2018, the Company had an accrual of $41 million for employee separation costs. The additional 2018 charges of $122 million represent severance costs for approximately an additional 1,200 employees, of which 500 were direct employees and 700 were indirect employees. The adjustments of $18 million reflect reversals of accruals no longer needed. The $61 million used in 2018 reflects cash payments to severed employees. The remaining accrual of $84 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2018.

[0000068505-20-000006:notes:385]
2017 Charges

[0000068505-20-000006:notes:386]
During 2017, the Company recorded net reorganization of business charges of $42 million, including $9 million of charges in Costs of sales and $33 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $42 million are charges of $43 million for employee separation costs and $8 million of charges for exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-20-000006:notes:387]
| Year ended December 31 | 2017 |
| Products and Systems integration | $ | 32 |  |
| Software and Services | 10 |  |
|  | $ | 42 |  |

[0000068505-20-000006:notes:388]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2017 to December 31, 2017:

[0000068505-20-000006:notes:389]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 7 |  |  | $ | 8 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 9 |  |
| Employee separation costs | 94 |  |  | 43 |  |  | (9 | ) |  | (87 | ) |  | 41 |  |
|  | $ | 101 |  |  | $ | 51 |  |  | $ | (9 | ) |  | $ | (93 | ) |  | $ | 50 |  |

[0000068505-20-000006:notes:390]
At January 1, 2017, the Company had $7 million accrual for exit costs. There were $8 million of additional charges in 2017. The $6 million used in 2017 reflects cash payments. The remaining accrual of $9 million, which the current portion was included in Accrued liabilities and the non-current portion was included in Other liabilities in the Company’s Consolidated Balance Sheet at December 31, 2017, primarily represented future cash payments for lease obligations.

[0000068505-20-000006:notes:391]
At January 1, 2017, the Company had an accrual of $94 million for employee separation costs. The additional 2017 charges of $43 million represent severance costs for approximately an additional 400 employees, of which 100 were direct employees and 300 were indirect employees. The adjustments of $9 million reflect of reversals of accruals no longer needed. The $87 million used in 2017 reflects cash payments to these severed employees. The remaining accrual of $41 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-20-000006:notes:392]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-20-000006:notes:393]
Recent Acquisitions

[0000068505-20-000006:notes:394]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million in cash, net of cash acquired.  The acquisition enhances the Company's video security platform by adding data to the Company’s existing license plate recognition ("LPR") database within the Software and Services segment. The Company recognized $54 million of goodwill, $28 million of identifiable intangible assets, and $3 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $22 million of customer relationships and $6 million of developed technology and will be amortized over a period of sixteen years and five years, respectively. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000006:notes:395]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's video security platform. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $156 million of goodwill, $63 million of identifiable intangible assets, and $31 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of completed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change.

[0000068505-20-000006:notes:396]
On March 11, 2019, the Company acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of fifteen years. The purchase accounting has been completed as of the third quarter of 2019.

[0000068505-20-000006:notes:397]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of fifteen years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change.

[0000068505-20-000006:notes:398]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions. The business is part of both the Product and Systems Integration segment and the Software and Services segment. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. The Company recognized $498 million of identifiable intangible assets, $434 million of goodwill, and $42 million of net assets.  Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to twenty years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them. The goodwill is not deductible for tax purposes.

[0000068505-20-000006:notes:399]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million, net of cash acquired. This acquisition expands the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1. The business is part of the Software and Services segment. As of December 31, 2018, the Company recognized $151 million of goodwill, $80 million of identifiable intangible assets and $6 million of net assets. During 2019, the Company recorded an adjustment related to the allocation between goodwill and deferred income taxes of approximately $9 million, bringing the total goodwill acquired to $160 million. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of ten to twenty years.

[0000068505-20-000006:notes:400]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk for commercial customers, for a purchase price of $225 million. The business is part of the Software and Services segment. As a result of the acquisition, the Company recognized $191 million of goodwill, $44 million of identifiable intangible assets and $10 million of acquired liabilities. The identifiable intangible assets were classified as $25 million of customer-related intangibles and $19 million of completed technology and will be amortized over a period of thirteen to sixteen years.

[0000068505-20-000006:notes:401]
On March 13, 2017, the Company completed the acquisition of Interexport, a managed service provider for communications systems to public safety and commercial customers in Chile, for a purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $16 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years. The business is part of the Software and Services segment.

[0000068505-20-000006:notes:402]
The results of operations for these acquisitions have been included in the Company’s Consolidated Statements of Operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-20-000006:notes:403]
Intangible Assets

[0000068505-20-000006:notes:404]
Amortized intangible assets are comprised of the following:

[0000068505-20-000006:notes:405]
|  | 2019 |  | 2018 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 738 |  |  | $ | 148 |  |  | $ | 558 |  |  | $ | 92 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,222 |  |  | 518 |  |  | 1,085 |  |  | 364 |  |
| Other intangibles | 75 |  |  | 42 |  |  | 74 |  |  | 31 |  |
|  | $ | 2,037 |  |  | $ | 710 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-20-000006:notes:406]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $208 million, $188 million, and $151 million for the years ended December 31, 2019, 2018, and 2017, respectively.  As of December 31, 2019, future amortization expense is estimated to be $212 million in 2020, $210 million in 2021, $207 million in 2022, $107 million in 2023, and $82 million in 2024.

[0000068505-20-000006:notes:407]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-20-000006:notes:408]
|  | 2019 |  | 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 652 |  |  | $ | 82 |  |  | $ | 510 |  |  | $ | 38 |  |
| Software and Services | 1,385 |  |  | 628 |  |  | 1,209 |  |  | 451 |  |
|  | $ | 2,037 |  |  | $ | 710 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-20-000006:notes:409]
Goodwill

[0000068505-20-000006:notes:410]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2018 to December 31, 2019:

[0000068505-20-000006:notes:411]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2018 | $ | 362 |  |  | $ | 576 |  |  | $ | 938 |  |
| Goodwill acquired | 360 |  |  | 225 |  |  | 585 |  |
| Purchase accounting adjustments | — |  |  | 1 |  |  | 1 |  |
| Foreign currency translation | — |  |  | (10 | ) |  | (10 | ) |
| Balance as of December 31, 2018 | $ | 722 |  |  | $ | 792 |  |  | $ | 1,514 |  |
| Goodwill acquired | 251 |  |  | 288 |  |  | 539 |  |
| Purchase accounting adjustments | — |  |  | 9 |  |  | 9 |  |
| Foreign currency translation | — |  |  | 5 |  |  | 5 |  |
| Balance as of December 31, 2019 | $ | 973 |  |  | $ | 1,094 |  |  | $ | 2,067 |  |

[0000068505-20-000006:notes:412]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level which is an operating segment or one level below an operating segment.

[0000068505-20-000006:notes:413]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2019, 2018, and 2017. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2019, 2018, and 2017, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-20-000006:notes:414]
Valuation and Qualifying Accounts
The following table presents the valuation and qualifying account activity for the years ended December 31, 2019, 2018, and 2017:

[0000068505-20-000006:notes:415]
|  | Balance atJanuary 1 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31 |
| 2019 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 51 |  |  | $ | 39 |  |  | $ | (26 | ) |  | $ | (1 | ) |  | $ | 63 |  |
| 2018 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 45 |  |  | 37 |  |  | (30 | ) |  | (1 | ) |  | 51 |  |
| 2017 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 44 |  |  | 16 |  |  | (16 | ) |  | 1 |  |  | 45 |  |

[0000068505-20-000006:notes:416]
* Adjustments include translation adjustments


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-20-000006:notes:417]
Quarterly and Other Financial Data (unaudited)

[0000068505-20-000006:notes:418]
|  | 2019 |  | 2018 |
|  | 1st |  | 2nd |  | 3rd |  | 4th |  | 1st |  | 2nd |  | 3rd |  | 4th |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,657 |  |  | $ | 1,860 |  |  | $ | 1,994 |  |  | $ | 2,377 |  |  | $ | 1,468 |  |  | $ | 1,760 |  |  | $ | 1,862 |  |  | $ | 2,254 |  |
| Costs of sales | 884 |  |  | 929 |  |  | 987 |  |  | 1,157 |  |  | 799 |  |  | 938 |  |  | 961 |  |  | 1,166 |  |
| Gross margin | $ | 773 |  |  | $ | 931 |  |  | $ | 1,007 |  |  | $ | 1,220 |  |  | $ | 669 |  |  | $ | 822 |  |  | $ | 901 |  |  | $ | 1,088 |  |
| Selling, general and administrative expenses | 327 |  |  | 351 |  |  | 359 |  |  | 368 |  |  | 279 |  |  | 316 |  |  | 323 |  |  | 337 |  |
| Research and development expenditures | 162 |  |  | 170 |  |  | 172 |  |  | 182 |  |  | 152 |  |  | 162 |  |  | 158 |  |  | 165 |  |
| Other charges | 55 |  |  | 61 |  |  | 63 |  |  | 80 |  |  | 67 |  |  | 71 |  |  | 126 |  |  | 70 |  |
| Operating earnings | $ | 229 |  |  | $ | 349 |  |  | $ | 413 |  |  | $ | 590 |  |  | $ | 171 |  |  | $ | 273 |  |  | $ | 294 |  |  | $ | 516 |  |
| Net earnings* | 151 |  |  | 207 |  |  | 267 |  |  | 244 |  |  | 117 |  |  | 180 |  |  | 247 |  |  | 423 |  |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 0.92 |  |  | $ | 1.25 |  |  | $ | 1.60 |  |  | $ | 1.43 |  |  | $ | 0.73 |  |  | $ | 1.11 |  |  | $ | 1.52 |  |  | $ | 2.58 |  |
| Diluted earnings per common share | 0.86 |  |  | 1.18 |  |  | 1.51 |  |  | 1.39 |  |  | 0.69 |  |  | 1.05 |  |  | 1.43 |  |  | 2.44 |  |
| Dividends declared | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 0.64 |  |  | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 0.57 |  |
| Dividends paid | 0.57 |  |  | 0.57 |  |  | 0.57 |  |  | 0.57 |  |  | 0.52 |  |  | 0.52 |  |  | 0.52 |  |  | 0.52 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 144.94 |  |  | $ | 169.30 |  |  | $ | 182.28 |  |  | $ | 176.95 |  |  | $ | 110.29 |  |  | $ | 118.37 |  |  | $ | 130.34 |  |  | $ | 133.97 |  |
| Low | $ | 110.61 |  |  | $ | 139.21 |  |  | $ | 160.81 |  |  | $ | 154.02 |  |  | $ | 89.18 |  |  | $ | 103.18 |  |  | $ | 114.95 |  |  | $ | 108.25 |  |

[0000068505-20-000006:notes:419]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.
