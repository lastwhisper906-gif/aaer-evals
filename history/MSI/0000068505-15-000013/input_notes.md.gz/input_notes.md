# MSI notes — 0000068505-15-000013


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-15-000013:notes:1]
[same as prior period, unchanged from 0000068505-15-000010:notes:1]

[0000068505-15-000013:notes:2]
| October 3, 2015 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 58 |  |  | $ | 1 |  |  | $ | 59 |  |
| Corporate bonds | 9 |  |  | — |  |  | 9 |  |
| Common stock | — |  |  | 15 |  |  | 15 |  |
|  | 67 |  |  | 16 |  |  | 83 |  |
| Other investments, at cost | 201 |  |  | — |  |  | 201 |  |
| Equity method investments | 8 |  |  | — |  |  | 8 |  |
|  | $ | 276 |  |  | $ | 16 |  |  | $ | 292 |  |

[0000068505-15-000013:notes:3]
[same as prior period, unchanged from 0000068505-15-000010:notes:3]


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-15-000013:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of October 3, 2015 and December 31, 2014 were as follows:

[0000068505-15-000013:notes:5]
| October 3, 2015 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | — |  |  | $ | 59 |  |  | $ | 59 |  |
| Corporate bonds | — |  |  | 9 |  |  | 9 |  |
| Common stock | 15 |  |  | — |  |  | 15 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest rate swap | — |  |  | 1 |  |  | 1 |  |

[0000068505-15-000013:notes:6]
[same as prior period, unchanged from 0000068505-15-000010:notes:6]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-15-000013:notes:7]
[same as prior period, unchanged from 0000068505-15-000010:notes:9]

[0000068505-15-000013:notes:8]
[same as prior period, unchanged from 0000068505-15-000010:notes:10]

[0000068505-15-000013:notes:9]
Long-term customer financing receivables consist of trade receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term customer financing receivables consist of the following:

[0000068505-15-000013:notes:10]
|  | October 3, 2015 |  | December 31, 2014 |
| Long-term receivables | $ | 28 |  |  | $ | 49 |  |
| Less current portion | (12 | ) |  | (18 | ) |
| Gross non-current long-term receivables | $ | 16 |  |  | $ | 31 |  |

[0000068505-15-000013:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $136 million at October 3, 2015, compared to $293 million at December 31, 2014. Outstanding commitments decreased during the nine months ended October 3, 2015 primarily as a result of two large customer contracts, one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-15-000013:notes:12]
[same as prior period, unchanged from 0000068505-15-000010:notes:12]

[0000068505-15-000013:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended October 3, 2015 and September 27, 2014:

[0000068505-15-000013:notes:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Accounts receivable sales proceeds | $ | 5 |  |  | $ | 6 |  |  | $ | 16 |  |  | $ | 39 |  |
| Long-term receivables sales proceeds | 24 |  |  | 37 |  |  | 132 |  |  | 91 |  |
| Total proceeds from receivable sales | $ | 29 |  |  | $ | 43 |  |  | $ | 148 |  |  | $ | 130 |  |

[0000068505-15-000013:notes:15]
At October 3, 2015, the Company had retained servicing obligations for $615 million of long-term receivables, compared to $496 million of long-term receivables at December 31, 2014.  Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-15-000013:notes:16]
[same as prior period, unchanged from 0000068505-15-000010:notes:16]

[0000068505-15-000013:notes:17]
An aging analysis of financing receivables at October 3, 2015 and December 31, 2014 is as follows:

[0000068505-15-000013:notes:18]
| October 3, 2015 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 23 |  |  | — |  |  | 1 |  |  | — |  |
| Total gross long-term receivables, including current portion | $ | 28 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |

[0000068505-15-000013:notes:19]
[same as prior period, unchanged from 0000068505-15-000010:notes:19]


## msi:OtherChargesTableTextBlock

[0000068505-15-000013:notes:20]
[same as prior period, unchanged from 0000068505-15-000010:notes:20]

[0000068505-15-000013:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization | $ | 2 |  |  | $ | 1 |  |  | $ | 6 |  |  | $ | 3 |  |
| Reorganization of business | 14 |  |  | 13 |  |  | 39 |  |  | 48 |  |
| Legal settlement | — |  |  | — |  |  | — |  |  | 8 |  |
| Non-U.S. pension curtailment gain | — |  |  | — |  |  | (32 | ) |  | — |  |
| Pension-related transaction fees | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Impairment of corporate aircraft | 26 |  |  | — |  |  | 26 |  |  | — |  |
| Gain on sale of building and land | — |  |  | — |  |  | — |  |  | (21 | ) |
|  | $ | 42 |  |  | $ | 25 |  |  | $ | 39 |  |  | $ | 49 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-15-000013:notes:22]
[same as prior period, unchanged from 0000068505-15-000010:notes:22]

[0000068505-15-000013:notes:23]
| October 3, 2015 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 29 |  |  | $ | 51 |  |
| Services | 12 |  |  | 19 |  |
|  | $ | 41 |  |  | $ | 70 |  |

[0000068505-15-000013:notes:24]
| September 27, 2014 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 13 |  |  | $ | 38 |  |
| Services | 7 |  |  | 20 |  |
|  | $ | 20 |  |  | $ | 58 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-15-000013:notes:25]
[same as prior period, unchanged from 0000068505-15-000010:notes:25]

[0000068505-15-000013:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 9 |  |
| Selling, general and administrative expenses | 13 |  |  | 14 |  |  | 38 |  |  | 47 |  |
| Research and development expenditures | 3 |  |  | 4 |  |  | 13 |  |  | 18 |  |
| Share-based compensation expense included in Operating earnings | 18 |  |  | 20 |  |  | 58 |  |  | 74 |  |
| Tax benefit | 6 |  |  | 6 |  |  | 19 |  |  | 23 |  |
| Share-based compensation expense, net of tax | $ | 12 |  |  | $ | 14 |  |  | $ | 39 |  |  | $ | 51 |  |
| Decrease in basic earnings per share | $ | (0.06 | ) |  | $ | (0.06 | ) |  | $ | (0.19 | ) |  | $ | (0.20 | ) |
| Decrease in diluted earnings per share | $ | (0.06 | ) |  | $ | (0.06 | ) |  | $ | (0.19 | ) |  | $ | (0.20 | ) |
| Share-based compensation expense in discontinued operations | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 18 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-15-000013:notes:27]
[same as prior period, unchanged from 0000068505-15-000010:notes:27]

[0000068505-15-000013:notes:28]
|  | October 3, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 89 |  |  | $ | 58 |  |  | $ | 77 |  |  | $ | 54 |  |
| Services | 21 |  |  | 2 |  |  | — |  |  | — |  |
|  | $ | 110 |  |  | $ | 60 |  |  | $ | 77 |  |  | $ | 54 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-15-000013:notes:29]
[same as prior period, unchanged from 0000068505-15-000010:notes:29]

[0000068505-15-000013:notes:30]
|  | October 3, 2015 |  | December 31, 2014 |
| Defined benefit plans | $ | 1,590 |  |  | $ | 1,611 |  |
| Postretirement Health Care Benefit Plan | 47 |  |  | 49 |  |
| Deferred revenue | 116 |  |  | 139 |  |
| Unrecognized tax benefits | 50 |  |  | 54 |  |
| Other | 166 |  |  | 158 |  |
|  | $ | 1,969 |  |  | $ | 2,011 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-15-000013:notes:31]
[same as prior period, unchanged from 0000068505-15-000010:notes:31]

[0000068505-15-000013:notes:32]
[same as prior period, unchanged from 0000068505-15-000010:notes:32]

[0000068505-15-000013:notes:33]
[same as prior period, unchanged from 0000068505-15-000010:notes:33]

[0000068505-15-000013:notes:34]
[same as prior period, unchanged from 0000068505-15-000010:notes:34]

[0000068505-15-000013:notes:35]
[same as prior period, unchanged from 0000068505-15-000010:notes:35]

[0000068505-15-000013:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (47 | ) |  | $ | (38 | ) |  | $ | (132 | ) |  | $ | (102 | ) |
| Interest income | 4 |  |  | 7 |  |  | 10 |  |  | 17 |  |
|  | $ | (43 | ) |  | $ | (31 | ) |  | $ | (122 | ) |  | $ | (85 | ) |
| Other: |  |  |  |  |  |  |  |
| Loss from the extinguishment of long-term debt | $ | — |  |  | $ | (37 | ) |  | $ | — |  |  | $ | (37 | ) |
| Investment impairments | — |  |  | — |  |  | (3 | ) |  | — |  |
| Foreign currency gain (loss) | (29 | ) |  | 10 |  |  | $ | (23 | ) |  | $ | 2 |  |
| Gain (loss) on derivative instruments | 25 |  |  | (6 | ) |  | 13 |  |  | (8 | ) |
| Gains on equity method investments | 2 |  |  | 11 |  |  | 6 |  |  | 13 |  |
| Other | 1 |  |  | (4 | ) |  | 4 |  |  | (4 | ) |
|  | $ | (1 | ) |  | $ | (26 | ) |  | $ | (3 | ) |  | $ | (34 | ) |

[0000068505-15-000013:notes:37]
[same as prior period, unchanged from 0000068505-15-000010:notes:37]

[0000068505-15-000013:notes:38]
[same as prior period, unchanged from 0000068505-15-000010:notes:38]

[0000068505-15-000013:notes:39]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Three Months Ended | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 126 |  |  | $ | 66 |  |  | $ | 115 |  |  | $ | 147 |  |
| Weighted average common shares outstanding | 199.2 |  |  | 246.3 |  |  | 199.2 |  |  | 246.3 |  |
| Per share amount | $ | 0.63 |  |  | $ | 0.27 |  |  | $ | 0.58 |  |  | $ | 0.60 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 126 |  |  | $ | 66 |  |  | $ | 115 |  |  | $ | 147 |  |
| Weighted average common shares outstanding | 199.2 |  |  | 246.3 |  |  | 199.2 |  |  | 246.3 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.1 |  |  | 1.9 |  |  | 2.1 |  |  | 1.9 |  |
| Diluted weighted average common shares outstanding | 201.3 |  |  | 248.2 |  |  | 201.3 |  |  | 248.2 |  |
| Per share amount | $ | 0.63 |  |  | $ | 0.27 |  |  | $ | 0.57 |  |  | $ | 0.59 |  |

[0000068505-15-000013:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Nine Months Ended | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 363 |  |  | $ | 229 |  |  | $ | 331 |  |  | $ | 1,098 |  |
| Weighted average common shares outstanding | 207.2 |  |  | 251.1 |  |  | 207.2 |  |  | 251.1 |  |
| Per share amount | $ | 1.75 |  |  | $ | 0.91 |  |  | $ | 1.60 |  |  | $ | 4.37 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 363 |  |  | $ | 229 |  |  | $ | 331 |  |  | $ | 1,098 |  |
| Weighted average common shares outstanding | 207.2 |  |  | 251.1 |  |  | 207.2 |  |  | 251.1 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.0 |  |  | 2.9 |  |  | 2.0 |  |  | 2.9 |  |
| Diluted weighted average common shares outstanding | 209.2 |  |  | 254.0 |  |  | 209.2 |  |  | 254.0 |  |
| Per share amount | $ | 1.74 |  |  | $ | 0.90 |  |  | $ | 1.58 |  |  | $ | 4.32 |  |

[0000068505-15-000013:notes:41]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three months ended October 3, 2015, the assumed exercise of 3.9 million options were excluded because their inclusion would have been antidilutive. For the nine months ended October 3, 2015, the assumed exercise of 2.6 million options were excluded because their inclusion would have been antidilutive.

[0000068505-15-000013:notes:42]
For the three and nine months ended September 27, 2014, the assumed exercise of 4.9 million and 4.8 million stock options, respectively, were excluded because their inclusion would have been antidilutive.

[0000068505-15-000013:notes:43]
On August 25, 2015, the Company issued $1 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). See discussion in Note 4. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-15-000013:notes:44]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the period ended October 3, 2015, there was no dilutive effect of the Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price.

[0000068505-15-000013:notes:45]
[same as prior period, unchanged from 0000068505-15-000010:notes:43]

[0000068505-15-000013:notes:46]
[same as prior period, unchanged from 0000068505-15-000010:notes:44]

[0000068505-15-000013:notes:47]
The Company’s cash and cash equivalents were $2.2 billion at October 3, 2015 and $4.0 billion at December 31, 2014. Of these amounts, $63 million was restricted at both October 3, 2015 and December 31, 2014.

[0000068505-15-000013:notes:48]
[same as prior period, unchanged from 0000068505-15-000010:notes:46]

[0000068505-15-000013:notes:49]
During the three months ended October 3, 2015, the Company sold various cost method investments recognizing a gain of $10 million. During the nine months ended October 3, 2015, the Company recorded Gains on sales of investments, net of $60 million, primarily related to the sale of one individual investment which represented $54 million of the total gain.

[0000068505-15-000013:notes:50]
[same as prior period, unchanged from 0000068505-15-000010:notes:48]

[0000068505-15-000013:notes:51]
[same as prior period, unchanged from 0000068505-15-000010:notes:49]

[0000068505-15-000013:notes:52]
|  | October 3, 2015 |  | December 31, 2014 |
| Accounts receivable | $ | 1,247 |  |  | $ | 1,444 |  |
| Less allowance for doubtful accounts | (25 | ) |  | (35 | ) |
|  | $ | 1,222 |  |  | $ | 1,409 |  |

[0000068505-15-000013:notes:53]
[same as prior period, unchanged from 0000068505-15-000010:notes:51]

[0000068505-15-000013:notes:54]
[same as prior period, unchanged from 0000068505-15-000010:notes:52]

[0000068505-15-000013:notes:55]
|  | October 3, 2015 |  | December 31, 2014 |
| Finished goods | $ | 153 |  |  | $ | 163 |  |
| Work-in-process and production materials | 323 |  |  | 313 |  |
|  | 476 |  |  | 476 |  |
| Less inventory reserves | (142 | ) |  | (131 | ) |
|  | $ | 334 |  |  | $ | 345 |  |

[0000068505-15-000013:notes:56]
[same as prior period, unchanged from 0000068505-15-000010:notes:54]

[0000068505-15-000013:notes:57]
[same as prior period, unchanged from 0000068505-15-000010:notes:55]

[0000068505-15-000013:notes:58]
|  | October 3, 2015 |  | December 31, 2014 |
| Costs and earnings in excess of billings | $ | 397 |  |  | $ | 417 |  |
| Tax-related refunds receivable | 77 |  |  | 103 |  |
| Zebra receivable for cash transferred | — |  |  | 49 |  |
| Other | 100 |  |  | 171 |  |
|  | $ | 574 |  |  | $ | 740 |  |

[0000068505-15-000013:notes:59]
In conjunction with the sale of the Enterprise business to Zebra Technologies, the Company transferred legal entities which maintained cash balances. During the nine months ended October 3, 2015, approximately $49 million of transferred cash balances were reimbursed by Zebra in accordance with the sales agreement.

[0000068505-15-000013:notes:60]
[same as prior period, unchanged from 0000068505-15-000010:notes:58]

[0000068505-15-000013:notes:61]
[same as prior period, unchanged from 0000068505-15-000010:notes:59]

[0000068505-15-000013:notes:62]
|  | October 3, 2015 |  | December 31, 2014 |
| Land | $ | 18 |  |  | $ | 18 |  |
| Building | 528 |  |  | 559 |  |
| Machinery and equipment | 1,536 |  |  | 1,672 |  |
|  | 2,082 |  |  | 2,249 |  |
| Less accumulated depreciation | (1,615 | ) |  | (1,700 | ) |
|  | $ | 467 |  |  | $ | 549 |  |

[0000068505-15-000013:notes:63]
Depreciation expense for the three months ended October 3, 2015 and September 27, 2014 was $30 million and $44 million, respectively. Depreciation expense for the nine months ended October 3, 2015 and September 27, 2014 was $107 million and $128 million, respectively.

[0000068505-15-000013:notes:64]
Subsequent to the three months ended October 3, 2015, the Company entered into an arrangement to transfer its Penang, Malaysia manufacturing operations, including the land, building, equipment, inventory, and employees to a contract manufacturer. In the three months ended October 3, 2015, the Company recognized an impairment loss of $6 million on the building that is held for sale within Other charges, in its condensed consolidated statements of operations, and presented the assets as held for sale in its condensed consolidated balance sheets.

[0000068505-15-000013:notes:65]
During the three months ended October 3, 2015, the Company entered into an agreement to broker the sale of its corporate aircraft. In the three months ended October 3, 2015, the Company recognized an impairment loss of $26 million within Other charges based on the indicated market value of the aircraft held for sale and has presented the aircraft as assets held for sale in its condensed consolidated balance sheets.

[0000068505-15-000013:notes:66]
[same as prior period, unchanged from 0000068505-15-000010:notes:62]

[0000068505-15-000013:notes:67]
[same as prior period, unchanged from 0000068505-15-000010:notes:63]

[0000068505-15-000013:notes:68]
|  | October 3, 2015 |  | December 31, 2014 |
| Intangible assets, net | $ | 50 |  |  | $ | 23 |  |
| Long-term receivables | 16 |  |  | 31 |  |
| Other | 117 |  |  | 91 |  |
|  | $ | 183 |  |  | $ | 145 |  |

[0000068505-15-000013:notes:69]
[same as prior period, unchanged from 0000068505-15-000010:notes:65]

[0000068505-15-000013:notes:70]
[same as prior period, unchanged from 0000068505-15-000010:notes:66]

[0000068505-15-000013:notes:71]
|  | October 3, 2015 |  | December 31, 2014 |
| Deferred revenue | $ | 363 |  |  | $ | 355 |  |
| Compensation | 216 |  |  | 190 |  |
| Billings in excess of costs and earnings | 357 |  |  | 358 |  |
| Tax liabilities | 59 |  |  | 91 |  |
| Dividend payable | 60 |  |  | 75 |  |
| Other | 527 |  |  | 637 |  |
|  | $ | 1,582 |  |  | $ | 1,706 |  |

[0000068505-15-000013:notes:72]
[same as prior period, unchanged from 0000068505-15-000010:notes:68]

[0000068505-15-000013:notes:73]
[same as prior period, unchanged from 0000068505-15-000010:notes:69]

[0000068505-15-000013:notes:74]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, and November 3, 2014, the Board of Directors has authorized the Company to repurchase in the aggregate up to $12.0 billion of its outstanding shares of common stock (the “share repurchase program”).  The share repurchase program does not have an expiration date.

[0000068505-15-000013:notes:75]
On August 4, 2015, the Board of Directors authorized the Company to commence a modified "Dutch auction" tender offer to repurchase up to $2 billion of its outstanding shares of common stock. The repurchase of these shares was authorized under the existing share repurchase authority, as outlined above. The tender offer commenced on August 7, 2015 and expired on September 3, 2015. The Company paid $2 billion, including transaction costs, to repurchase approximately 30.1 million shares at a tender price of $66.50 per share.

[0000068505-15-000013:notes:76]
In addition, excluding shares repurchased under the tender offer mentioned above, the Company paid an aggregate of $55 million during the three months ended October 3, 2015, including transaction costs, to repurchase approximately 0.8 million shares at an average price of $67.62 per share.

[0000068505-15-000013:notes:77]
During the nine months ended October 3, 2015, the Company paid an aggregate of $3.0 billion, including transaction costs, to repurchase approximately 45.4 million shares at an average price of $66.04 per share. As of October 3, 2015, the Company had used approximately $10.8 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.2 billion of authority available for future repurchases.

[0000068505-15-000013:notes:78]
Payment of Dividends:  During the three months ended October 3, 2015 and September 27, 2014, the Company paid $70 million and $78 million, respectively, in cash dividends to holders of its common stock. During the nine months ended October 3, 2015 and September 27, 2014, the Company paid $218 million and $236 million, respectively, in cash dividends to holders of its common stock.

[0000068505-15-000013:notes:79]
[same as prior period, unchanged from 0000068505-15-000010:notes:74]

[0000068505-15-000013:notes:80]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and nine months ended October 3, 2015 and September 27, 2014:

[0000068505-15-000013:notes:81]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (223 | ) |  | $ | (81 | ) |  | $ | (204 | ) |  | $ | (96 | ) |
| Other comprehensive loss before reclassification adjustment | (17 | ) |  | (35 | ) |  | (35 | ) |  | (24 | ) |
| Tax benefit | 1 |  |  | 1 |  |  | — |  |  | 5 |  |
| Other comprehensive loss, net of tax | (16 | ) |  | (34 | ) |  | (35 | ) |  | (19 | ) |
| Balance at end of period | $ | (239 | ) |  | $ | (115 | ) |  | $ | (239 | ) |  | $ | (115 | ) |
| Derivative instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
| Reclassification adjustment into Cost of sales | — |  |  | — |  |  | — |  |  | 1 |  |
| Tax expense | — |  |  | — |  |  | — |  |  | — |  |
| Reclassification adjustment into Cost of sales, net of tax | — |  |  | — |  |  | — |  |  | 1 |  |
| Other comprehensive income, net of tax | — |  |  | — |  |  | — |  |  | 1 |  |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Unrealized Gains and Losses on Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | 15 |  |  | $ | — |  |  | $ | 44 |  |  | $ | (2 | ) |
| Other comprehensive loss before reclassification adjustment | — |  |  | — |  |  | (2 | ) |  | — |  |
| Tax benefit | — |  |  | — |  |  | 1 |  |  | 2 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | — |  |  | — |  |  | (1 | ) |  | 2 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | (8 | ) |  | — |  |  | (54 | ) |  | — |  |
| Tax expense | 3 |  |  | — |  |  | 21 |  |  | — |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net of tax | (5 | ) |  | — |  |  | (33 | ) |  | — |  |
| Other comprehensive income (loss), net of tax | (5 | ) |  | — |  |  | (34 | ) |  | 2 |  |
| Balance at end of period | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | (1,777 | ) |  | (2,164 | ) |  | (1,695 | ) |  | (2,188 | ) |
| Other comprehensive loss before reclassification adjustment | — |  |  | (647 | ) |  | (53 | ) |  | (647 | ) |
| Tax benefit | — |  |  | 294 |  |  | — |  |  | 294 |  |
| Other comprehensive loss before reclassification adjustment, net of tax | — |  |  | (353 | ) |  | (53 | ) |  | (353 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 20 |  |  | 27 |  |  | 56 |  |  | 84 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (20 | ) |  | (16 | ) |  | (52 | ) |  | (39 | ) |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Selling, general, and administrative expenses | — |  |  | — |  |  | (32 | ) |  | — |  |
| Tax benefit | — |  |  | (4 | ) |  | (1 | ) |  | (14 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | — |  |  | 7 |  |  | (29 | ) |  | 31 |  |
| Other comprehensive loss, net of tax | — |  |  | (346 | ) |  | (82 | ) |  | (322 | ) |
| Balance at end of period | $ | (1,777 | ) |  | $ | (2,510 | ) |  | $ | (1,777 | ) |  | $ | (2,510 | ) |
| Total Accumulated other comprehensive loss | $ | (2,006 | ) |  | $ | (2,625 | ) |  | $ | (2,006 | ) |  | $ | (2,625 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-15-000013:notes:82]
Commitments and Contingencies

[0000068505-15-000013:notes:83]
Legal Matters

[0000068505-15-000013:notes:84]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s condensed consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company’s: (i) results of operations in the periods in which an adverse outcome becomes both probable and estimable or (ii) financial position or liquidity in the periods in which the matters are ultimately resolved.

[0000068505-15-000013:notes:85]
Other Indemnifications

[0000068505-15-000013:notes:86]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-15-000013:notes:87]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at October 3, 2015.

[0000068505-15-000013:notes:88]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-15-000013:notes:89]
Debt and Credit Facilities

[0000068505-15-000013:notes:90]
As of October 3, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 3, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the nine months ended October 3, 2015.

[0000068505-15-000013:notes:91]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-15-000013:notes:92]
The Company has recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. The total of proceeds received in excess of the fair value of the debt liability of $8 million has been recorded within Additional paid-in capital.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-15-000013:notes:93]
[same as prior period, unchanged from 0000068505-15-000010:notes:87]

[0000068505-15-000013:notes:94]
[same as prior period, unchanged from 0000068505-15-000010:notes:88]

[0000068505-15-000013:notes:95]
As of October 3, 2015, the Company had outstanding foreign exchange contracts with notional amounts totaling $521 million, compared to $628 million outstanding at December 31, 2014.  The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-15-000013:notes:96]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of October 3, 2015, and the corresponding positions as of December 31, 2014:

[0000068505-15-000013:notes:97]
|  | Notional Amount |
| Net Buy (Sell) by Currency | October 3, 2015 |  | December 31, 2014 |
| Euro | $ | 142 |  |  | $ | 214 |  |
| Chinese Renminbi | (131 | ) |  | (161 | ) |
| Australian Dollar | (44 | ) |  | (42 | ) |
| Brazilian Real | (39 | ) |  | (28 | ) |
| Norwegian Krone | (38 | ) |  | (90 | ) |

[0000068505-15-000013:notes:98]
[same as prior period, unchanged from 0000068505-15-000010:notes:92]

[0000068505-15-000013:notes:99]
As of October 3, 2015, the Company had $4.4 billion of long-term debt, including the current portion, which is priced at fixed interest rates.

[0000068505-15-000013:notes:100]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable and the Company has an interest rate swap in place which is not designated as a hedge. As such, the changes in the fair value of the interest rate swap are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swap was in a liability position of $1 million at October 3, 2015 and a liability position of $2 million December 31, 2014.

[0000068505-15-000013:notes:101]
[same as prior period, unchanged from 0000068505-15-000010:notes:95]

[0000068505-15-000013:notes:102]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of October 3, 2015, all of the counterparties have investment grade credit ratings. As of October 3, 2015, the Company had de minimis exposure to aggregate net credit risk with all counterparties.

[0000068505-15-000013:notes:103]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of October 3, 2015 and December 31, 2014:

[0000068505-15-000013:notes:104]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| October 3, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other current assets |  | $ | 2 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | — |  |  |  |  | $ | 3 |  |  |  |

[0000068505-15-000013:notes:105]
[same as prior period, unchanged from 0000068505-15-000010:notes:99]

[0000068505-15-000013:notes:106]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated statements of operations for the three and nine months ended October 3, 2015 and September 27, 2014:

[0000068505-15-000013:notes:107]
|  | Three Months Ended |  | Nine Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |  |
| Interest rate swap | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | Other income (expense) |
| Foreign exchange contracts | 25 |  |  | (6 | ) |  | 12 |  |  | (8 | ) |  | Other income (expense) |
| Total derivatives | $ | 25 |  |  | $ | (6 | ) |  | $ | 13 |  |  | $ | (8 | ) |  |  |

[0000068505-15-000013:notes:108]
The following table summarizes the gains and losses reclassified from Accumulated other comprehensive loss into Net earnings during the three and nine months ended October 3, 2015 and September 27, 2014:

[0000068505-15-000013:notes:109]
|  | Three Months Ended |  | Nine Months Ended |  | Financial StatementLocation |
| Foreign Exchange Contracts | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |  |
| Derivatives in cash flow hedging relationships: |  |  |  |  |  |  |  |  |  |
| Losses reclassified from Accumulated other comprehensive loss into Net earnings | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |  | Cost of sales |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-15-000013:notes:110]
[same as prior period, unchanged from 0000068505-15-000010:notes:102]

[0000068505-15-000013:notes:111]
During the nine months ended October 3, 2015, the Company granted 0.8 million RSUs and 2.6 million stock options. The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and stock options was $44 million and $17 million, respectively, which will generally be recognized over the vesting period of three years.

[0000068505-15-000013:notes:112]
During the third quarter of 2015, the Company approved a one-time grant of performance-contingent stock options (the “PCSOs”) to certain officers under the Motorola Solutions Omnibus Incentive Plan of 2015 (the “Omnibus Plan”). The PCSOs have a seven-year term and a per share exercise price of $68.50. The PCSOs would vest upon satisfaction of the following Company stock price hurdles which must be maintained for 10-consecutive trading days during the three-year period following the grant date: 20% of the total award would vest at an $85 stock price; an additional 30% of the total award would vest at a $102.50 stock price; and the final 50% of the total award would vest at a $120 stock price. If any stock price hurdles are not met during the three-year period, the corresponding portion of the PCSOs would not vest and would be forfeited. PCSOs are generally not exercisable prior to the end of the three-year performance period.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-15-000013:notes:113]
[same as prior period, unchanged from 0000068505-15-000010:notes:104]

[0000068505-15-000013:notes:114]
[same as prior period, unchanged from 0000068505-15-000010:notes:105]

[0000068505-15-000013:notes:115]
The following table displays summarized activity in the Company's condensed consolidated statements of operations for discontinued operations during the three and nine months ended October 3, 2015 and September 27, 2014:

[0000068505-15-000013:notes:116]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Net sales | $ | — |  |  | $ | 605 |  |  | $ | — |  |  | $ | 1,737 |  |
| Operating earnings | — |  |  | 78 |  |  | — |  |  | 195 |  |
| Losses on sales of investments and businesses, net | — |  |  | — |  |  | (28 | ) |  | — |  |
| Earnings (loss) before income taxes | — |  |  | 68 |  |  | (28 | ) |  | 181 |  |
| Income tax expense (benefit) | 11 |  |  | (13 | ) |  | 4 |  |  | (688 | ) |
| Earnings (loss) from discontinued operations, net of tax | $ | (11 | ) |  | $ | 81 |  |  | $ | (32 | ) |  | $ | 869 |  |

[0000068505-15-000013:notes:117]
During the three months ended October 3, 2015, the Company recorded $11 million of tax expense on the gain on the sale of the Enterprise business to reflect actual amounts filed in the income tax return.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-15-000013:notes:118]
[same as prior period, unchanged from 0000068505-15-000010:notes:108]

[0000068505-15-000013:notes:119]
[same as prior period, unchanged from 0000068505-15-000010:notes:109]

[0000068505-15-000013:notes:120]
[same as prior period, unchanged from 0000068505-15-000010:notes:110]

[0000068505-15-000013:notes:121]
[same as prior period, unchanged from 0000068505-15-000010:notes:111]

[0000068505-15-000013:notes:122]
[same as prior period, unchanged from 0000068505-15-000010:notes:112]

[0000068505-15-000013:notes:123]
[same as prior period, unchanged from 0000068505-15-000010:notes:113]

[0000068505-15-000013:notes:124]
The Company had no Level 3 holdings as of October 3, 2015 or December 31, 2014.

[0000068505-15-000013:notes:125]
At October 3, 2015 and December 31, 2014, the Company had $1.5 billion and $3.3 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-15-000013:notes:126]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at October 3, 2015 and December 31, 2014 was $4.2 billion and $3.6 billion (Level 2), respectively.

[0000068505-15-000013:notes:127]
[same as prior period, unchanged from 0000068505-15-000010:notes:117]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-15-000013:notes:128]
[same as prior period, unchanged from 0000068505-15-000010:notes:118]

[0000068505-15-000013:notes:129]
[same as prior period, unchanged from 0000068505-15-000010:notes:119]

[0000068505-15-000013:notes:130]
[same as prior period, unchanged from 0000068505-15-000010:notes:120]

[0000068505-15-000013:notes:131]
|  | October 3, 2015 |  | December 31, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 59 |  |  | $ | 31 |  |  | $ | 37 |  |  | $ | 27 |  |
| Patents | 8 |  |  | 5 |  |  | 8 |  |  | 4 |  |
| Customer-related | 23 |  |  | 9 |  |  | 15 |  |  | 8 |  |
| Other intangibles | 20 |  |  | 15 |  |  | 17 |  |  | 15 |  |
|  | $ | 110 |  |  | $ | 60 |  |  | $ | 77 |  |  | $ | 54 |  |

[0000068505-15-000013:notes:132]
Amortization expense on intangible assets was $2 million for the three months ended October 3, 2015 and $6 million for the nine months ended October 3, 2015. Amortization expense on intangible assets was $1 million for the three months ended September 27, 2014 and $3 million for the nine months ended September 27, 2014. As of October 3, 2015, annual amortization expense is estimated to be $8 million in 2015, $9 million in 2016 and 2017, $8 million in 2018, $7 million in 2019, and $4 million in 2020.

[0000068505-15-000013:notes:133]
[same as prior period, unchanged from 0000068505-15-000010:notes:123]

[0000068505-15-000013:notes:134]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2015 to October 3, 2015:

[0000068505-15-000013:notes:135]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Goodwill acquired | 7 |  |  | 32 |  |  | 39 |  |
| Purchase accounting adjustments | 1 |  |  | — |  |  | 1 |  |
| Balance as of October 3, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 272 |  |  | $ | 151 |  |  | $ | 423 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 272 |  |  | $ | 151 |  |  | $ | 423 |  |

[0000068505-15-000013:notes:136]
[same as prior period, unchanged from 0000068505-15-000010:notes:126]

[0000068505-15-000013:notes:137]
On November 18, 2014, the Company completed the acquisition of an equipment provider for a purchase price of $22 million. During the nine months ended October 3, 2015, the Company completed the purchase accounting for this acquisition, recognizing $8 million of goodwill and $12 million of identifiable intangible assets. These identifiable intangible assets were classified as completed technology to be amortized over five years.

[0000068505-15-000013:notes:138]
During the quarter ended April 4, 2015 the Company completed the acquisitions of two providers of public safety software-based solutions for an aggregate purchase price of $50 million. During the nine months ended October 3, 2015, the Company recognized an additional $32 million of goodwill, $21 million of identifiable intangible assets, and $4 million of acquired liabilities related to these acquisitions. The $21 million of identifiable intangible assets were classified as: (i) $10 million completed technology, (ii) $8 million customer-related, and (iii) $3 million of other intangibles. These intangible assets will be amortized over periods ranging from five to ten years.

[0000068505-15-000013:notes:139]
[same as prior period, unchanged from 0000068505-15-000010:notes:129]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-15-000013:notes:140]
[same as prior period, unchanged from 0000068505-15-000010:notes:130]

[0000068505-15-000013:notes:141]
[same as prior period, unchanged from 0000068505-15-000010:notes:131]

[0000068505-15-000013:notes:142]
[same as prior period, unchanged from 0000068505-15-000010:notes:132]

[0000068505-15-000013:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Earnings from continuing operations before income taxes | $ | 197 |  |  | $ | 151 |  |  | $ | 540 |  |  | $ | 337 |  |
| Income tax expense | 71 |  |  | 84 |  |  | 175 |  |  | 107 |  |
| Effective tax rate | 36 | % |  | 56 | % |  | 32 | % |  | 32 | % |

[0000068505-15-000013:notes:144]
The Company recorded $71 million of net tax expense in the third quarter of 2015 resulting in an effective tax rate of 36%, compared to $84 million of net tax expense in the third quarter of 2014 resulting in an effective tax rate of 56%. The effective tax rate in the third quarter of 2015 was higher than the U.S. statutory tax rate of 35% primarily due to higher income in the U.S. relative to foreign operations. The effective tax rate in the third quarter of 2014 was unfavorably impacted by $55 million of tax expense related to the recording of a valuation allowance on certain foreign deferred tax assets.

[0000068505-15-000013:notes:145]
The Company recorded $175 million of net tax expense in the first nine months of 2015 resulting in an effective tax rate of 32%, compared to $107 million of net tax expense resulting in an effective tax rate of 32% in the first nine months of 2014. The effective tax rate for the first nine months of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S domestic production tax deduction. The effective tax rate in the first nine months of 2014 was lower than the U.S. statutory tax rate of 35% due to tax benefits associated with the net reduction in unrecognized tax benefits and revaluing of deferred tax assets for state effective rates.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-15-000013:notes:146]
Recent Accounting Pronouncements

[0000068505-15-000013:notes:147]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers: Deferral of the Effective Date that delayed the effective date of ASU 2014-09 by one year to January 1, 2018 as the Company’s annual reporting period begins after December 15, 2017. ASU 2014-09 allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-15-000013:notes:148]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of October 3, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $44 million.

[0000068505-15-000013:notes:149]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, where net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for the Company beginning January 1, 2017 with early adoption permitted. The Company does not expect this ASU will have a material impact on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-15-000013:notes:150]
[same as prior period, unchanged from 0000068505-15-000010:notes:142]

[0000068505-15-000013:notes:151]
The condensed consolidated financial statements as of October 3, 2015 and for the three and nine months ended October 3, 2015 and September 27, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-15-000013:notes:152]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three and nine months ended October 3, 2015 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-15-000013:notes:153]
[same as prior period, unchanged from 0000068505-15-000010:notes:145]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-15-000013:notes:154]
[same as prior period, unchanged from 0000068505-15-000010:notes:146]

[0000068505-15-000013:notes:155]
[same as prior period, unchanged from 0000068505-15-000010:notes:147]

[0000068505-15-000013:notes:156]
[same as prior period, unchanged from 0000068505-15-000010:notes:148]

[0000068505-15-000013:notes:157]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 48 |  |  | 93 |  |  | 14 |  |  | 20 |  |  | 2 |  |  | 2 |  |
| Expected return on plan assets | (53 | ) |  | (97 | ) |  | (23 | ) |  | (23 | ) |  | (2 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 12 |  |  | 23 |  |  | 5 |  |  | 3 |  |  | 3 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1 | ) |  | (2 | ) |  | (15 | ) |  | (13 | ) |
| Net periodic pension cost (benefit) | $ | 7 |  |  | $ | 19 |  |  | $ | (2 | ) |  | $ | 2 |  |  | $ | (12 | ) |  | $ | (13 | ) |

[0000068505-15-000013:notes:158]
The Company made no contributions to its U.S. Pension Benefit Plans during the three months ended October 3, 2015 and $397 million of contributions to its U.S. Pension Benefit plans for the three months ended September 27, 2014. During the three months ended October 3, 2015 and September 27, 2014, contributions of $2 million and $7 million were made to the Company’s Non U.S. Pension Benefit Plans, respectively.

[0000068505-15-000013:notes:159]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 10 |  |  | $ | 11 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 144 |  |  | 278 |  |  | 49 |  |  | 61 |  |  | 6 |  |  | 8 |  |
| Expected return on plan assets | (159 | ) |  | (294 | ) |  | (79 | ) |  | (69 | ) |  | (7 | ) |  | (7 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 35 |  |  | 68 |  |  | 13 |  |  | 9 |  |  | 8 |  |  | 7 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (3 | ) |  | (5 | ) |  | (45 | ) |  | (35 | ) |
| Curtailment gain | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | 20 |  |  | $ | 52 |  |  | $ | (42 | ) |  | $ | 7 |  |  | $ | (37 | ) |  | $ | (26 | ) |

[0000068505-15-000013:notes:160]
During the nine months ended October 3, 2015, the Company amended its Non U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.  As a result, the Company recorded a curtailment gain of $32 million to Other charges in the Company’s condensed consolidated statements of operations.

[0000068505-15-000013:notes:161]
The Company made no contributions to its U.S. Pension Benefit Plans during the nine months ended October 3, 2015 and $463 million of contributions to its U.S. Pension Benefit Plans for the nine months ended September 27, 2014. During the nine months ended October 3, 2015 and September 27, 2014, contributions of $8 million and $27 million were made to the Company’s Non U.S. Pension Benefit Plans, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-15-000013:notes:162]
[same as prior period, unchanged from 0000068505-15-000010:notes:154]

[0000068505-15-000013:notes:163]
[same as prior period, unchanged from 0000068505-15-000010:notes:155]

[0000068505-15-000013:notes:164]
During the three months ended October 3, 2015, the Company recorded net reorganization of business charges of $41 million including $40 million of charges in Other charges, and $1 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $41 million were charges of: (i) $26 million for the impairment of corporate aircraft, (ii) $11 million of charges related to employee separation costs, (iii) a $6 million building impairment charge, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-15-000013:notes:165]
During the nine months ended October 3, 2015, the Company recorded net reorganization of business charges of $70 million including $65 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $70 million were charges of: (i) $36 million for employee separation costs, (ii) $26 million for the impairment of the corporate aircraft, (iii) a $6 million building impairment charge, and (iv) $4 million for exit costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-15-000013:notes:166]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2015 to October 3, 2015, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business:

[0000068505-15-000013:notes:167]
|  | January 1, 2015 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | October 3, 2015 |
| Exit costs | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 3 |  |
| Employee separation costs | 57 |  |  | 36 |  |  | (5 | ) |  | (52 | ) |  | 36 |  |
|  | $ | 57 |  |  | $ | 40 |  |  | $ | (5 | ) |  | $ | (53 | ) |  | $ | 39 |  |

[0000068505-15-000013:notes:168]
[same as prior period, unchanged from 0000068505-15-000010:notes:160]

[0000068505-15-000013:notes:169]
At January 1, 2015, the Company had no accruals for exit costs. During the nine months ended October 3, 2015, there were $4 million of additional charges and $1 million of cash payments related to the exit of leased facilities. The remaining accrual of $3 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at October 3, 2015, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-15-000013:notes:170]
[same as prior period, unchanged from 0000068505-15-000010:notes:162]

[0000068505-15-000013:notes:171]
At January 1, 2015, the Company had an accrual of $57 million for employee separation costs. The 2015 additional charges of $36 million represent severance costs for approximately 400 employees. The adjustment of $5 million reflects $2 million of reversals for accruals no longer needed and $3 million of reversals of accruals held for employees separated from discontinued operations. The $52 million used reflects cash payments to severed employees. The remaining accrual of $36 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at October 3, 2015, is expected to be paid, primarily within one year, to approximately 400 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-15-000013:notes:172]
[same as prior period, unchanged from 0000068505-15-000010:notes:164]

[0000068505-15-000013:notes:173]
During the three months ended September 27, 2014, the Company recorded net reorganization of business charges of $20 million, including $13 million of charges in Other charges and $7 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. The $20 million of charges were all related to employee separation costs.

[0000068505-15-000013:notes:174]
During the nine months ended September 27, 2014, the Company recorded net reorganization of business charges of $58 million, including $48 million of charges in Other charges and $10 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the aggregate $58 million were charges of $54 million related to employee separation costs and $4 million related to exit costs.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-15-000013:notes:175]
[same as prior period, unchanged from 0000068505-15-000010:notes:167]

[0000068505-15-000013:notes:176]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Products | $ | 925 |  |  | $ | 921 |  |  | $ | 2,550 |  |  | $ | 2,561 |  |
| Services | 497 |  |  | 515 |  |  | 1,463 |  |  | 1,497 |  |
|  | $ | 1,422 |  |  | $ | 1,436 |  |  | $ | 4,013 |  |  | $ | 4,058 |  |

[0000068505-15-000013:notes:177]
[same as prior period, unchanged from 0000068505-15-000010:notes:169]

[0000068505-15-000013:notes:178]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Products | $ | 178 |  |  | $ | 141 |  |  | $ | 413 |  |  | $ | 276 |  |
| Services | 53 |  |  | 66 |  |  | 192 |  |  | 176 |  |
| Operating earnings | 231 |  |  | 207 |  |  | 605 |  |  | 452 |  |
| Total other expense | (34 | ) |  | (56 | ) |  | (65 | ) |  | (115 | ) |
| Earnings from continuing operations before income taxes | $ | 197 |  |  | $ | 151 |  |  | $ | 540 |  |  | $ | 337 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-15-000013:notes:179]
[same as prior period, unchanged from 0000068505-15-000010:notes:171]

[0000068505-15-000013:notes:180]
[same as prior period, unchanged from 0000068505-15-000010:notes:172]

[0000068505-15-000013:notes:181]
[same as prior period, unchanged from 0000068505-15-000010:notes:173]

[0000068505-15-000013:notes:182]
[same as prior period, unchanged from 0000068505-15-000010:notes:174]
