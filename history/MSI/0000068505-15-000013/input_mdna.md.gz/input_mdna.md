# MSI MD&A — 0000068505-15-000013


## mdna

[0000068505-15-000013:mdna:1]
[same as prior period, unchanged from 0000068505-15-000010:mdna:1]

[0000068505-15-000013:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended October 3, 2015 and September 27, 2014, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2014.

[0000068505-15-000013:mdna:3]
[same as prior period, unchanged from 0000068505-15-000010:mdna:3]

[0000068505-15-000013:mdna:4]
[same as prior period, unchanged from 0000068505-15-000010:mdna:4]

[0000068505-15-000013:mdna:5]
[same as prior period, unchanged from 0000068505-15-000010:mdna:5]

[0000068505-15-000013:mdna:6]
[same as prior period, unchanged from 0000068505-15-000010:mdna:6]

[0000068505-15-000013:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the third quarter of 2015, the segment’s net sales were $925 million, representing 65% of our consolidated net sales.

[0000068505-15-000013:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Lifecycle Support services, (iii) Managed services, (iv) Smart Public Safety Solutions, and (v) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications.  Lifecycle Support services includes lifecycle planning, software and hardware maintenance, security patches and upgrades, call center support, network monitoring, and repair services.  Managed services includes managing and operating customer systems and devices at defined services levels. Smart Public Safety Solutions includes software and hardware solutions for our customers' "Command & Control" centers providing video monitoring support, data analytics, and content management with the objective of enabling smart policing. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the third quarter of 2015, the segment’s net sales were $497 million, representing 35% of our consolidated net sales.

[0000068505-15-000013:mdna:9]
[same as prior period, unchanged from 0000068505-15-000010:mdna:9]

[0000068505-15-000013:mdna:10]
Impact of Macroeconomic Conditions: The Company is experiencing a decline in sales, in particular in the Latin American region, related to challenging macroeconomic conditions causing deterioration in local economies, and exacerbated by the strengthening of the U.S. dollar. Most of the Company’s contracts and sales are transacted in U.S. dollar within Latin America and Eastern Europe, so the currency impact to our customers reduces purchasing power caused by the devaluation of their local currency. This reduced purchasing power and macroeconomic headwinds are impacting available funding under government budgets and ultimately leading to procurement delays and reduced scoping of expected orders.

[0000068505-15-000013:mdna:11]
Impact of Foreign Exchange Rate Fluctuations: Although we are a global corporation and our net sales are impacted by the strengthening of the U.S. dollar in relation to foreign currencies, primarily the Euro, Norwegian Kroner, Australian Dollar, Canadian Dollar, and Brazilian Real, we do not expect the overall impact of foreign exchange rate fluctuations on our net earnings to be as significant. The impact of foreign exchange rate fluctuations on net earnings is mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sale, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion of our operating expenses are denominated in foreign currencies as a result of our offshore research and development and selling, general, and administrative footprint.

[0000068505-15-000013:mdna:12]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce selling, general, and administrative and research and development expenses during 2015 by approximately $200 million in comparison to 2014.

[0000068505-15-000013:mdna:13]
Growth of Our Services Portfolio: Within the the Services segment we expect to grow software maintenance services in our Lifecycle Support services portfolio, Managed services, and Smart Public Safety at a higher rate than the rest of the Services portfolio. Overall, the Services segment has a lower gross margin percentage than the Products segment; however, we expect consolidated operating margins to continue to expand.

[0000068505-15-000013:mdna:14]
iDEN: We have experienced a downward trend in iDEN product and services sales over the last three years due to decreased demand as a result of the dated nature of the technology. We expect the downward trend to continue as service

[0000068505-15-000013:mdna:15]
25

[0000068505-15-000013:mdna:16]
contracts expire and new technology replaces iDEN equipment in the marketplace. This trend primarily relates to our Services segment as the majority of iDEN sales are hardware and software maintenance services. The expected decline in iDEN sales will impact both revenues and gross margins within the Services segment as iDEN services’ gross margins are generally higher than the remainder of our services portfolio.

[0000068505-15-000013:mdna:17]
Third Quarter Summary

[0000068505-15-000013:mdna:18]
| • | Net sales were $1.4 billion in both the third quarter of 2015 and 2014. Net sales in the third quarter of 2015 included the unfavorable impact of foreign currency fluctuations of $54 million, primarily within Europe and Africa ("EA"), Asia Pacific ("AP"), and Latin America, partially offset by growth of $42 million in North America. |

[0000068505-15-000013:mdna:19]
| • | We generated operating earnings of $231 million, or 16% of net sales, in the third quarter of 2015, compared to $207 million, or 14% of net sales, in the third quarter of 2014. Profitability improvements were primarily driven by lower operating expenses as a result of: (i) cost savings initiatives and (ii) lower pension expense. |

[0000068505-15-000013:mdna:20]
| • | We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $126 million, or $0.63 per diluted common share, in the third quarter of 2015, compared to $66 million, or $0.27 per diluted common share, in the third quarter of 2014. The unfavorable impact of foreign currency fluctuations on net sales was largely offset by foreign exchange rate favorability within Costs of sales and operating expenses reducing the impact on earnings from continuing operations attributable to Motorola Solutions, Inc. |

[0000068505-15-000013:mdna:21]
| • | We generated net cash from operating activities of $591 million during the first nine months of 2015, compared to $15 million of net cash provided by operating activities in the first nine months of 2014. Operating cash flows improved primarily as a result of increased earnings from continuing operations, reduced pension contributions, and proceeds from the sale of long-term receivables. |

[0000068505-15-000013:mdna:22]
| • | We returned $2.1 billion and $3.2 billion in capital to shareholders through dividends and share repurchases during the third quarter of 2015 and first nine months of 2015, respectively. |

[0000068505-15-000013:mdna:23]
Summary for our segment results are as follows:

[0000068505-15-000013:mdna:24]
| • | Products: Net sales were $925 million in the third quarter of 2015, an increase of $4 million, compared to net sales of $921 million during the third quarter of 2014. On a geographic basis, net sales increased in North America, AP and Middle East ("ME") and decreased in EA and Latin America, compared to the year-ago quarter. |

[0000068505-15-000013:mdna:25]
| • | Services: Net sales were $497 million in the third quarter of 2015, a decrease of $18 million, or 3%, compared to net sales of $515 million in the third quarter of 2014. On a geographic basis, net sales decreased in EA, Latin America, and AP and increased in North America and ME, compared to the year-ago quarter. |

[0000068505-15-000013:mdna:26]
[same as prior period, unchanged from 0000068505-15-000010:mdna:53]

[0000068505-15-000013:mdna:27]
[same as prior period, unchanged from 0000068505-15-000010:mdna:29]

[0000068505-15-000013:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | October 3, 2015 |  | % ofSales** |  | September 27, 2014 |  | % ofSales** |  | October 3, 2015 |  | % ofSales** |  | September 27, 2014 |  | % ofSales** |
| Net sales from products | $ | 925 |  |  |  |  | $ | 921 |  |  |  |  | $ | 2,550 |  |  |  |  | $ | 2,561 |  |  |  |
| Net sales from services | 497 |  |  |  |  | 515 |  |  |  |  | 1,463 |  |  |  |  | 1,497 |  |  |  |
| Net sales | 1,422 |  |  |  |  | 1,436 |  |  |  |  | 4,013 |  |  |  |  | 4,058 |  |  |  |
| Costs of product sales | 395 |  |  | 42.7 | % |  | 414 |  |  | 45.0 | % |  | 1,139 |  |  | 44.7 | % |  | 1,165 |  |  | 45.5 | % |
| Costs of services sales | 342 |  |  | 68.8 | % |  | 337 |  |  | 65.4 | % |  | 993 |  |  | 67.9 | % |  | 974 |  |  | 65.1 | % |
| Costs of sales | 737 |  |  |  |  | 751 |  |  |  |  | 2,132 |  |  |  |  | 2,139 |  |  |  |
| Gross margin | 685 |  |  | 48.2 | % |  | 685 |  |  | 47.7 | % |  | 1,881 |  |  | 46.9 | % |  | 1,919 |  |  | 47.3 | % |
| Selling, general and administrative expenses | 259 |  |  | 18.2 | % |  | 287 |  |  | 20.0 | % |  | 769 |  |  | 19.2 | % |  | 902 |  |  | 22.2 | % |
| Research and development expenditures | 153 |  |  | 10.8 | % |  | 166 |  |  | 11.6 | % |  | 468 |  |  | 11.7 | % |  | 516 |  |  | 12.7 | % |
| Other charges | 42 |  |  | 3.0 | % |  | 25 |  |  | 1.7 | % |  | 39 |  |  | 1.0 | % |  | 49 |  |  | 1.2 | % |
| Operating earnings | 231 |  |  | 16.2 | % |  | 207 |  |  | 14.4 | % |  | 605 |  |  | 15.1 | % |  | 452 |  |  | 11.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (43 | ) |  | (3.0 | )% |  | (31 | ) |  | (2.2 | )% |  | (122 | ) |  | (3.0 | )% |  | (85 | ) |  | (2.1 | )% |
| Gains on sales of investments and businesses, net | 10 |  |  | 0.7 | % |  | 1 |  |  | 0.1 | % |  | 60 |  |  | 1.5 | % |  | 4 |  |  | 0.1 | % |
| Other | (1 | ) |  | (0.1 | )% |  | (26 | ) |  | (1.8 | )% |  | (3 | ) |  | (0.1 | )% |  | (34 | ) |  | (0.8 | )% |
| Total other expense | (34 | ) |  | (2.4 | )% |  | (56 | ) |  | (3.9 | )% |  | (65 | ) |  | (1.6 | )% |  | (115 | ) |  | (2.8 | )% |
| Earnings from continuing operations before income taxes | 197 |  |  | 13.9 | % |  | 151 |  |  | 10.5 | % |  | 540 |  |  | 13.5 | % |  | 337 |  |  | 8.3 | % |
| Income tax expense | 71 |  |  | 5.0 | % |  | 84 |  |  | 5.8 | % |  | 175 |  |  | 4.4 | % |  | 107 |  |  | 2.6 | % |
| Earnings from continuing operations | 126 |  |  | 8.9 | % |  | 67 |  |  | 4.7 | % |  | 365 |  |  | 9.1 | % |  | 230 |  |  | 5.7 | % |
| Less: Earnings attributable to noncontrolling interests | — |  |  | — | % |  | 1 |  |  | 0.1 | % |  | 2 |  |  | — | % |  | 1 |  |  | — | % |
| Earnings from continuing operations* | 126 |  |  | 8.9 | % |  | 66 |  |  | 4.6 | % |  | 363 |  |  | 9.0 | % |  | 229 |  |  | 5.6 | % |
| Earnings (loss) from discontinued operations, net of tax | (11 | ) |  | (0.8 | )% |  | 81 |  |  | 5.6 | % |  | (32 | ) |  | (0.8 | )% |  | 869 |  |  | 21.4 | % |
| Net earnings* | $ | 115 |  |  | 8.1 | % |  | $ | 147 |  |  | 10.2 | % |  | $ | 331 |  |  | 8.2 | % |  | $ | 1,098 |  |  | 27.1 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.63 |  |  |  |  | $ | 0.27 |  |  |  |  | $ | 1.74 |  |  |  |  | $ | 0.90 |  |  |  |
| Discontinued operations | (0.06 | ) |  |  |  | 0.32 |  |  |  |  | (0.16 | ) |  |  |  | 3.42 |  |  |  |
| Earnings per diluted common share* | $ | 0.57 |  |  |  |  |  | $ | 0.59 |  |  |  |  |  | $ | 1.58 |  |  |  |  | $ | 4.32 |  |  |  |

[0000068505-15-000013:mdna:29]
[same as prior period, unchanged from 0000068505-15-000010:mdna:31]

[0000068505-15-000013:mdna:30]
[same as prior period, unchanged from 0000068505-15-000010:mdna:32]

[0000068505-15-000013:mdna:31]
Results of Operations—Three months ended October 3, 2015 compared to three months ended September 27, 2014

[0000068505-15-000013:mdna:32]
The results of operations for the third quarter of 2015 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-15-000013:mdna:33]
[same as prior period, unchanged from 0000068505-15-000010:mdna:35]

[0000068505-15-000013:mdna:34]
Net sales were $1.4 billion in the third quarter of 2015, a $14 million, or 1%, decrease compared to the third quarter of 2014. The slight decline in net sales is reflective of decreases in EA and Latin America, partially offset by growth in North America, AP, and ME. The decrease in EA was primarily the result of foreign exchange rate unfavorability and a decrease in Products and Services sales. The decrease in Latin America was primarily the result of foreign exchange rate unfavorability and lower Products and Services sales, driven by challenging macroeconomic conditions. North America grew on strong Products and Services sales, AP grew on strong Products sales, and ME realized an increase in Services sales.

[0000068505-15-000013:mdna:35]
[same as prior period, unchanged from 0000068505-15-000010:mdna:37]

[0000068505-15-000013:mdna:36]
Gross margin was $685 million, or 48.2% of net sales, in the third quarter of 2015, compared to $685 million, or 47.7% of net sales, in the third quarter of 2014. The slight increase in gross margin percentage is attributable to an increase in devices sales within North America, partially offset by increased Integration services costs for large projects in North America and EA and  lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-15-000013:mdna:37]
[same as prior period, unchanged from 0000068505-15-000010:mdna:39]

[0000068505-15-000013:mdna:38]
Selling, general and administrative (“SG&A”) expenses decreased 10% to $259 million, or 18.2% of net sales, in the third quarter of 2015, compared to $287 million, or 20.0% of net sales, in the third quarter of 2014. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) lower pension expenses, and (iii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000013:mdna:39]
[same as prior period, unchanged from 0000068505-15-000010:mdna:41]

[0000068505-15-000013:mdna:40]
Research and development (“R&D”) expenditures decreased 8% to $153 million, or 10.8% of net sales, in the third quarter of 2015, from $166 million, or 11.6% of net sales, in the third quarter of 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, and (ii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000013:mdna:41]
Other Charges

[0000068505-15-000013:mdna:42]
We recorded net charges of $42 million in Other charges in the third quarter of 2015, compared to net charges of $25 million in the third quarter of 2014. The net Other charges in the third quarter of 2015 included: (i) $40 million of net reorganization of business charges, including a $26 million impairment of the corporate aircraft, and (ii) $2 million of charges relating to the amortization of intangibles. The net charges in the third quarter of 2014 of $25 million included: (i) $13 million of net reorganization of business charges, (ii) $11 million for pension-related transaction fees, and (iii) $1 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-15-000013:mdna:43]
[same as prior period, unchanged from 0000068505-15-000010:mdna:45]

[0000068505-15-000013:mdna:44]
Net interest expense was $43 million in the third quarter of 2015, compared to net interest expense of $31 million in the third quarter of 2014. Net interest expense in the third quarter of 2015 included interest expense of $47 million, partially offset by interest income of $4 million. Net interest expense in the third quarter of 2014 included interest expense of $38 million, partially offset by interest income of $7 million. The increase of $12 million in net interest expense in the third quarter of 2015 as compared to the third quarter of 2014 was a result of higher average debt balances.

[0000068505-15-000013:mdna:45]
[same as prior period, unchanged from 0000068505-15-000010:mdna:47]

[0000068505-15-000013:mdna:46]
Net Gains on sales of investments and businesses were $10 million in the third quarter of 2015 compared to $1 million in the third quarter of 2014. The net gains in the third quarter of 2015 and the third quarter of 2014 were related to the sales of equity investments.

[0000068505-15-000013:mdna:47]
[same as prior period, unchanged from 0000068505-15-000010:mdna:49]

[0000068505-15-000013:mdna:48]
Net Other expense was $1 million in the third quarter of 2015, compared to $26 million in the third quarter of 2014. The net Other expense in the third quarter of 2015 was comprised of a $29 million foreign currency loss, partially offset by: (i) a $25 million gain on derivative investments, (ii) a $2 million gain on equity method investments, and (iii) $1 million of other non-operating gains. The net Other expense in the third quarter of 2014 was comprised of: (i) a $37 million loss from the extinguishment of debt, (ii) a $6 million loss on derivative instruments, and (iii) $4 million of other non-operating losses, partially offset by: (i) a $11 million of gain on equity method investments and (ii) a $10 million foreign currency gain.

[0000068505-15-000013:mdna:49]
[same as prior period, unchanged from 0000068505-15-000010:mdna:51]

[0000068505-15-000013:mdna:50]
We recorded $71 million of net tax expense in the third quarter of 2015, resulting in an effective tax rate of 36%, compared to $84 million of net tax expense in the third quarter of 2014, resulting in an effective tax rate of 56%. Our effective tax rate in the third quarter of 2015 was higher than the U.S. statutory tax rate of 35% primarily due to higher income in the U.S. relative to foreign operations. Our effective tax rate in the third quarter of 2014 was unfavorably impacted by $55 million of tax expense related to the recording of a valuation allowance on certain foreign deferred tax assets.

[0000068505-15-000013:mdna:51]
[same as prior period, unchanged from 0000068505-15-000010:mdna:55]

[0000068505-15-000013:mdna:52]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $126 million, or $0.63 per diluted share, in the third quarter of 2015, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $66 million, or $0.27 per diluted share, in the third quarter of 2014.

[0000068505-15-000013:mdna:53]
The increase in earnings from continuing operations in the third quarter of 2015, as compared to the third quarter of 2014, was primarily driven by: (i) a $28 million decrease in SG&A spend, (ii) a $13 million decrease in R&D, and (iii) a $13 million decrease in income tax expense, partially offset by a $26 million impairment of the corporate aircraft. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding, primarily as a result of our "Dutch auction" tender offer, as well as repurchases made through our ongoing share repurchase program, and an increase in earnings from continuing operations.

[0000068505-15-000013:mdna:54]
[same as prior period, unchanged from 0000068505-15-000010:mdna:58]

[0000068505-15-000013:mdna:55]
After taxes, we had an $11 million, or $0.06 per diluted share, loss from discontinued operations in the third quarter of 2015, compared to earnings from discontinued operations of $81 million, or $0.32 per diluted share, in the third quarter of 2014.

[0000068505-15-000013:mdna:56]
Results of Operations—Nine months ended October 3, 2015 compared to nine months ended September 27, 2014

[0000068505-15-000013:mdna:57]
[same as prior period, unchanged from 0000068505-15-000010:mdna:61]

[0000068505-15-000013:mdna:58]
Net sales were $4.0 billion in the first nine months of 2015, a $45 million, or 1% decrease from the first nine months of 2014. The decline in net sales is reflective of decreases in EA and Latin America, partially offset by growth in North America, ME, and AP. The decrease in EA was primarily the result of foreign exchange rate unfavorability and a decrease in Services sales. The decrease in Latin America was primarily the result of foreign exchange rate unfavorability, lower Products sales, and declines in iDen services. North America and AP grew on strong Products sales while ME realized an increase in both Products and Services sales.

[0000068505-15-000013:mdna:59]
[same as prior period, unchanged from 0000068505-15-000010:mdna:63]

[0000068505-15-000013:mdna:60]
Gross margin was $1.9 billion, or 46.9% of net sales, in the first nine months of 2015, compared to $1.9 billion, or 47.3% of net sales, in the first nine months of 2014. The decrease in gross margin percentage was driven primarily by a decrease in margins within the Services segment while gross margin of the Products segment increased slightly. The decrease in gross margin in the Services segment was primarily driven by: (i) a decrease in North America and EA as a result of the deployment of certain large projects at lower gross margins and (ii) lower net sales in iDEN services which have a higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-15-000013:mdna:61]
[same as prior period, unchanged from 0000068505-15-000010:mdna:65]

[0000068505-15-000013:mdna:62]
SG&A expenses decreased $133 million to $769 million, or 19.2% of net sales, in the first nine months of 2015, compared to $902 million, or 22.2% of net sales, in the first nine months of 2014. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) lower pension expenses, and (iii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000013:mdna:63]
[same as prior period, unchanged from 0000068505-15-000010:mdna:67]

[0000068505-15-000013:mdna:64]
R&D expenditures decreased $48 million to $468 million, or 11.7% of net sales, in the first nine months of 2015, compared to $516 million, or 12.7% of net sales, in the first nine months of 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions and the movement of employees to lower cost work sites, and (ii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-15-000013:mdna:65]
29

[0000068505-15-000013:mdna:66]
Other Charges

[0000068505-15-000013:mdna:67]
We recorded net charges of $39 million in Other charges in the first nine months of 2015, compared to net charges of $49 million in the first nine months of 2014. The net charges in the first nine months of 2015 included: (i) $65 million of net reorganization of business charges, including a $26 million impairment of the corporate aircraft, and (ii) $6 million of charges relating to the amortization of intangibles, partially offset by a $32 million gain related to the curtailment of a non-U.S. pension plan. The net Other charges in the first nine months of 2014 of $49 million included: (i) $48 million of net reorganization of business charges, (ii) $11 million of pension-related transaction fees, (iii) $8 million of legal settlement charges, and (iv) $3 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-15-000013:mdna:68]
[same as prior period, unchanged from 0000068505-15-000010:mdna:71]

[0000068505-15-000013:mdna:69]
Net interest expense was $122 million in the first nine months of 2015 and $85 million in the first nine months of 2014. Net interest expense in the first nine months of 2015 includes interest expense of $132 million, partially offset by interest income of $10 million. Net interest expense in the first nine months of 2014 includes interest expense of $102 million, partially offset by interest income of $17 million. The increase of $37 million in net interest expense in the first nine months of 2015 as compared to the first nine months of 2014 was a result of higher outstanding debt balances.

[0000068505-15-000013:mdna:70]
[same as prior period, unchanged from 0000068505-15-000010:mdna:73]

[0000068505-15-000013:mdna:71]
Net gains on sales of investments and businesses were $60 million in the first nine months of 2015 and $4 million in the first nine months of 2014. The net gains in the first nine months of 2015 and 2014 consisted of gains on the sales of equity investments.

[0000068505-15-000013:mdna:72]
[same as prior period, unchanged from 0000068505-15-000010:mdna:75]

[0000068505-15-000013:mdna:73]
Net Other expense was $3 million in the first nine months of 2015, compared to $34 million in the first nine months of 2014. The net Other expense in the first nine months of 2015 was comprised of: (i) a $23 million foreign currency loss and (ii) a $3 million investment impairment, partially offset by (i) $13 million gain on derivative instruments, (ii) $6 million gain on equity method investments, and (iii) $4 million of other non-operating gains. The net Other expense in the first nine months of 2014 was  comprised of: (i) a $37 million loss on the extinguishment of debt, (ii) $8 million loss on derivative instruments, and (iii) $4 million of other non-operating losses, partially offset by (i) a $13 million gain on equity method investments and (ii) a $2 million foreign currency gain.

[0000068505-15-000013:mdna:74]
[same as prior period, unchanged from 0000068505-15-000010:mdna:77]

[0000068505-15-000013:mdna:75]
We recorded $175 million of net tax expense in the first nine months of 2015, resulting in an effective tax rate of 32%, compared to $107 million of net tax expense, resulting in an effective tax rate of 32% in the first nine months of 2014. Our effective tax rate in 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S domestic production tax deduction. Our effective tax rate in the first nine months of 2014 was lower than the U.S. statutory tax rate of 35% due to tax benefits associated with the net reduction in unrecognized tax benefits and revaluing of deferred tax assets for state effective rates.

[0000068505-15-000013:mdna:76]
[same as prior period, unchanged from 0000068505-15-000010:mdna:80]

[0000068505-15-000013:mdna:77]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $363 million, or $1.74 per diluted share, in the first nine months of 2015, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $229 million, or $0.90 per diluted share, in the first nine months of 2014.

[0000068505-15-000013:mdna:78]
The increase in earnings from continuing operations in the first nine months of 2015, as compared to the first nine months of 2014, was primarily driven by: (i) a $133 million decrease in SG&A spend, (ii) an increase in Gains on sales of investments and businesses of $56 million and (iii) a $48 million decrease in R&D, partially offset by: (i) a $68 million increase in income tax expenses and (ii) a $38 million decrease in gross margin. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding primarily as a result of our "Dutch auction" tender offer, as well as repurchases made through our ongoing share repurchase program, and an increase in earnings from continuing operations.

[0000068505-15-000013:mdna:79]
[same as prior period, unchanged from 0000068505-15-000010:mdna:83]

[0000068505-15-000013:mdna:80]
After taxes, we had a $32 million, or $0.16 per diluted share, loss from discontinued operations in the first nine months of 2015, compared to earnings from discontinued operations of $869 million, or $3.42 per diluted share, in the first nine months of 2014.

[0000068505-15-000013:mdna:81]
[same as prior period, unchanged from 0000068505-15-000010:mdna:85]

[0000068505-15-000013:mdna:82]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and nine months ended October 3, 2015 and September 27, 2014, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-15-000013:mdna:83]
[same as prior period, unchanged from 0000068505-15-000010:mdna:88]

[0000068505-15-000013:mdna:84]
For the third quarter of 2015, the segment’s net sales represented 65% of our consolidated net sales, compared to 64% of our consolidated net sales for the third quarter of 2014. For the first nine months of 2015, the segment's net sales represented 64% of our consolidated net sales, compared to 63% of our consolidated net sales for the third quarter of 2014.

[0000068505-15-000013:mdna:85]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 3, 2015 |  | September 27, 2014 |  | % Change |  | October 3, 2015 |  | September 27, 2014 |  | % Change |
| Segment net sales | $ | 925 |  |  | $ | 921 |  |  | — | % |  | $ | 2,550 |  |  | $ | 2,561 |  |  | — | % |
| Operating earnings | 178 |  |  | 141 |  |  | 26 | % |  | 413 |  |  | 276 |  |  | 50 | % |

[0000068505-15-000013:mdna:86]
Three months ended October 3, 2015 compared to three months ended September 27, 2014

[0000068505-15-000013:mdna:87]
The segment’s net sales increased $4 million, to $925 million in the third quarter of 2015, as compared to $921 million during the third quarter of 2014. The increase in the segment's net sales was primarily driven by: (i) an increase in devices sales in North America, (ii) an increase in systems and devices sales in AP, and (iii) increased systems sales in ME, partially offset by (i) unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, Latin America, and AP, (ii) a decrease in systems sales in North America, (iii) a decrease in devices and systems sales in EA and Latin America based on the reduced purchasing power of our customers caused by the devaluation of their local currency and macroeconomic conditions. On a geographic basis, net sales increased in North America, AP, and ME and decreased in EA and Latin America for the third quarter of 2015, compared to the third quarter of 2014.

[0000068505-15-000013:mdna:88]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 66% of the segment’s net sales in the third quarter of 2015, up from 63% of the segment’s net sales in the third quarter of 2014.

[0000068505-15-000013:mdna:89]
The segment had operating earnings of $178 million in the third quarter of 2015, compared to $141 million in the third quarter of 2014. The increase in operating earnings was primarily driven by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses and (ii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates, offset by an $18 million impairment charge related to the corporate aircraft within Other charges.

[0000068505-15-000013:mdna:90]
Nine months ended October 3, 2015 compared to nine months ended September 27, 2014

[0000068505-15-000013:mdna:91]
The segment’s net sales decreased $11 million, to $2.6 billion in the first nine months of 2015, as compared to the first nine months of 2014. The decrease in the segment's net sales was primarily driven by: (i) unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, Latin America, and AP and (ii) decreases in devices and systems sales in EA and Latin America, and (iii) a decrease in systems sales in North America, partially offset by: (i) growth in devices sales in North America, (ii) increased systems sales in AP, and (iii) increased devices and systems sales in ME. On a geographic basis, net sales decreased in EA and Latin America and increased in North America, AP, and ME for the first nine months of 2015, compared to the first nine months of 2014.

[0000068505-15-000013:mdna:92]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 65% of the segment’s net sales in the first nine months of 2015, up from 61% of the segment's net sales in the first nine months of 2014.

[0000068505-15-000013:mdna:93]
The segment had operating earnings of $413 million in the first nine months of 2015, compared to $276 million in the first nine months of 2014. The increase in operating earnings in the first nine months of 2015 compared to the first nine months of 2014, was primarily driven by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses, (ii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates, and (iii) a $22 million non-U.S. pension curtailment gain within Other charges, partially offset by an $18 million impairment charge related to the corporate aircraft within Other charges.

[0000068505-15-000013:mdna:94]
[same as prior period, unchanged from 0000068505-15-000010:mdna:99]

[0000068505-15-000013:mdna:95]
For the third quarter of 2015, the segment’s net sales represented 35% of our consolidated net sales, compared to 36% of our consolidated net sales for the third quarter of 2014. For the first nine months of 2015 and 2014, the segment’s net sales represented 36% of our consolidated net sales, compared to 37% of our consolidated net sales for the third quarter of 2014.

[0000068505-15-000013:mdna:96]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 3, 2015 |  | September 27, 2014 |  | % Change |  | October 3, 2015 |  | September 27, 2014 |  | % Change |
| Segment net sales | $ | 497 |  |  | $ | 515 |  |  | (3 | )% |  | $ | 1,463 |  |  | $ | 1,497 |  |  | (2 | )% |
| Operating earnings | 53 |  |  | 66 |  |  | (20 | )% |  | 192 |  |  | 176 |  |  | 9 | % |

[0000068505-15-000013:mdna:97]
Three months ended October 3, 2015 compared to three months ended September 27, 2014

[0000068505-15-000013:mdna:98]
The segment’s net sales decreased $18 million, or 3%, to $497 million in the third quarter of 2015, as compared to $515 million in the third quarter of 2014. The decrease in the segment's net sales was driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, Latin America, and AP, (ii) a decrease in Integration services sales in EA, primarily related to the winding down of a large system implementation, and (iii) declining iDEN services sales in Latin America, partially offset by an increase in: (i) Integration services and Lifecycle Support services in North America and (ii) Integration services in ME. On a geographic basis, net sales for the third quarter of 2015 decreased in EA, Latin America, and AP and increased in North America and ME, compared to the third quarter of 2014.

[0000068505-15-000013:mdna:99]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 63% of the segment’s net sales in the third quarter of 2015, compared to 58% of the segment’s net sales in the third quarter of 2014.

[0000068505-15-000013:mdna:100]
The segment had operating earnings of $53 million in the third quarter of 2015, compared to $66 million in the third quarter of 2014. The decrease in operating earnings in the third quarter of 2015 compared to the third quarter of 2014 was driven by: (i) lower gross margin primarily due to the decrease in margin on our Integration services in North America and EA and (ii) an $8 million impairment charge related to the corporate aircraft within Other charges, offset by a reduction in SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and lower pension expenses.

[0000068505-15-000013:mdna:101]
Nine months ended October 3, 2015 compared to nine months ended September 27, 2014

[0000068505-15-000013:mdna:102]
The segment’s net sales decreased $34 million, or 2%, to $1,463 million in the first nine months of 2015, as compared to net sales of $1,497 million in the first nine months of 2014. The decrease in the segment's net sales was driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, Latin America, and AP, (ii) lower Integration services sales in North America as a result of the timing of delivery on larger projects, and (iii) declining iDEN services sales in Latin America, partially offset by an increase in: (i) Lifecycle Support services in North America and (ii) Integration services in ME. On a geographic basis, net sales for the first nine months of 2015 decreased in EA, Latin America, and AP and increased in ME and North America, compared to the first nine months of 2014.

[0000068505-15-000013:mdna:103]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 62% of the segment’s net sales in the first nine months of 2015, compared to 59% of the segment’s net sales in the first nine months of 2014.

[0000068505-15-000013:mdna:104]
The segment had operating earnings of $192 million in the first nine months of 2015, compared to operating earnings of $176 million in the first nine months of 2014. The increase in operating earnings in the first nine months of 2015 as compared to the first nine months of 2014 was driven by: (i) a reduction in SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and lower pension expenses and (ii) a $10 million non-U.S. pension curtailment gain within Other income, partially offset by: (i) a decrease in gross margin driven by Integration services on large system deployments and iDEN services and (ii) an $8 million impairment charge related to the corporate aircraft within Other charges.

[0000068505-15-000013:mdna:105]
[same as prior period, unchanged from 0000068505-15-000010:mdna:110]

[0000068505-15-000013:mdna:106]
During the third quarter of 2015, we recorded net reorganization of business charges of $41 million including $40 million of charges recorded within Other charges and $1 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $41 million were charges of: (i) $26 million for the impairment of corporate aircraft, (ii) $11 million of charges related to employee separation costs, (iii) a $6 million building impairment charge, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-15-000013:mdna:107]
During the first nine months of 2015, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first nine months of 2015, we recorded net reorganization of business charges of $70 million including charges of $65 million recorded in Other charges and $5 million in Cost of sales in our condensed consolidated statements of operations. Included in the $70 million were charges of: (i) $36 million for employee separation costs, (ii) $26 million for the impairment of the corporate aircraft, (iii) a $6 million building impairment charge, and (iv) $4 million for exit costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-15-000013:mdna:108]
During the third quarter of 2014, we recorded net reorganization of business charges of $20 million including charges of $13 million recorded in Other charges and $7 million in Cost of sales in our condensed consolidated statements of operations. The $20 million of charges was all related to employee separation costs.

[0000068505-15-000013:mdna:109]
During the first nine months of 2014, we recorded net reorganization of business charges of $58 million including charges of $48 million recorded in Other charges and $10 million in Cost of sales in our condensed consolidated statements of operations. Included in the aggregate $58 million are charges of $54 million for employee separation costs and $4 million of exit costs.

[0000068505-15-000013:mdna:110]
We expect to realize cost-saving benefits of approximately $11 million during the remaining three months of 2015 from the plans that were initiated during the third quarter of 2015. Beyond 2015, we expect the reorganization plans initiated during the

[0000068505-15-000013:mdna:111]
first nine months of 2015 to provide annualized cost savings of approximately $46 million, consisting of: (i) $39 million of savings in operating expenses and (ii) $7 million of savings in Cost of Sales.

[0000068505-15-000013:mdna:112]
[same as prior period, unchanged from 0000068505-15-000010:mdna:117]

[0000068505-15-000013:mdna:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Products | $ | 29 |  |  | $ | 13 |  |  | $ | 51 |  |  | $ | 38 |  |
| Services | 12 |  |  | 7 |  |  | 19 |  |  | 20 |  |
|  | $ | 41 |  |  | $ | 20 |  |  | $ | 70 |  |  | $ | 58 |  |

[0000068505-15-000013:mdna:114]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $53 million in the first nine months of 2015 and $116 million in the first nine months of 2014. The cash payments related to discontinued operations included in the first nine months of 2014 were $40 million. The reorganization of business accruals at October 3, 2015 were $39 million, of which $36 million relate to employee separation costs that are expected to be paid within one year and $3 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-15-000013:mdna:115]
[same as prior period, unchanged from 0000068505-15-000010:mdna:120]

[0000068505-15-000013:mdna:116]
We continue to manage our capital structure and are focused on maintaining a robust liquidity position and managing to an investment grade credit rating. We decreased the aggregate of our cash and cash equivalent balances by $1.8 billion from $4.0 billion as of December 31, 2014 to $2.2 billion as of October 3, 2015.  The decrease is primarily due to $3.2 billion of capital returned to shareholders through share repurchases and dividends paid, offset by $976 million of net proceeds raised by the issuance of the Senior Convertible Notes (net of issuance costs paid) and $591 million of cash provided by operating activities.

[0000068505-15-000013:mdna:117]
[same as prior period, unchanged from 0000068505-15-000010:mdna:122]

[0000068505-15-000013:mdna:118]
[same as prior period, unchanged from 0000068505-15-000010:mdna:123]

[0000068505-15-000013:mdna:119]
Our cash and cash equivalents were $2.2 billion at October 3, 2015 and $4.0 billion at December 31, 2014. At October 3, 2015, $1.4 billion of this amount was held in the U.S. and approximately $844 million was held by the Company or its subsidiaries in other countries, with approximately $436 million held in the United Kingdom. At both October 3, 2015 and December 31, 2014, restricted cash was $63 million.

[0000068505-15-000013:mdna:120]
Undistributed earnings that we intend to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.6 billion at October 3, 2015. We currently have no plans to repatriate these permanently reinvested foreign earnings. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-15-000013:mdna:121]
[same as prior period, unchanged from 0000068505-15-000010:mdna:126]

[0000068505-15-000013:mdna:122]
Net cash provided by operating activities in the first nine months of 2015 was $591 million, as compared to $15 million in the first nine months of 2014. Operating cash flows in the first nine months of 2015, as compared to the first nine months of 2014, were positively impacted by: (i) an increase in earnings from continuing operations, (ii) reduced pension contributions, and (iii) proceeds from the sale of long-term receivables.

[0000068505-15-000013:mdna:123]
We made no contributions to our U.S. pension plans during the first nine months of 2015, compared to $463 million contributed in the first nine months of 2014. We contributed $8 million to our non-U.S. pension plans during the first nine months of 2015, compared to $27 million contributed in the first nine months of 2014.

[0000068505-15-000013:mdna:124]
[same as prior period, unchanged from 0000068505-15-000010:mdna:129]

[0000068505-15-000013:mdna:125]
Net cash used by investing activities was $129 million in the first nine months of 2015, compared to $98 million in the first nine months of 2014. The $129 million cash used in the first nine months of 2015 included $150 million cash used for acquisitions and investments and $131 million in capital expenditures, partially offset by $150 million of proceeds from sales of investments and businesses and $2 million of proceeds from the sale of property, plant and equipment. The cash usage of $98 million in the first nine months of 2014 consisted primarily of $130 million in capital expenditures and $21 million cash used for acquisitions and investments, partially offset by $30 million of proceeds from the sale of property, plant and equipment and $23 million of proceeds from the sale of investments and businesses.

[0000068505-15-000013:mdna:126]
Acquisition and Investments:  We used net cash for acquisitions and investments of $150 million during the first nine months of 2015 compared to $21 million in the first nine months of 2014. The cash used during the first nine months of 2015 consisted of $49 million related to the acquisition of two public safety software solution providers and several debt and equity investments. The cash used during the first nine months of 2014 related to a number of small equity investments.

[0000068505-15-000013:mdna:127]
Sales of Investments and Businesses:  We had $150 million of proceeds related to the sales of investments and businesses in the first nine months of 2015 compared to $23 million in the first nine months of 2014. The proceeds in the first nine months of 2015 primarily consists of: (i) $49 million reimbursement from Zebra Technologies for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale; (ii) $54 million from the sale of an equity investment, (iii) $15 million net cash received from Zebra Technologies for the final purchase price adjustment, as well as for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest. The proceeds in the first nine months of 2014 were comprised of sales of equity investments.

[0000068505-15-000013:mdna:128]
Capital Expenditures:  Capital expenditures were relatively flat in the first nine months of 2015 as compared to the first nine months of 2014. Capital expenditures in both periods were primarily related to information technology-related spend and revenue-generating network expenditures.

[0000068505-15-000013:mdna:129]
Sales of Property, Plant, and Equipment:  We had $2 million of proceeds related to the sale of property, plant, and equipment in the first nine months of 2015 compared to $30 million in the first nine months of 2014. The proceeds in the first nine months of 2014 were comprised of proceeds from the sale of buildings and land.

[0000068505-15-000013:mdna:130]
[same as prior period, unchanged from 0000068505-15-000010:mdna:136]

[0000068505-15-000013:mdna:131]
Net cash used for financing activities was $2.2 billion in the first nine months of 2015, compared to $274 million in the first nine months of 2014. Cash used for financing activities in the first nine months of 2015 was primarily comprised of: (i) $3.0 billion used for purchases of our common stock under our share repurchase program and (ii) $218 million of cash used for the payment of dividends, partially offset by: (i) $976 million of net proceeds from the issuance of the Senior Convertible Notes (net of issuance costs paid) and (ii) $85 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first nine months of 2014 was primarily comprised of: (i) $1.1 billion used for purchases of our common stock under our share repurchase program, (ii) $461 million of cash used for the repayment of debt, and (iii) $236 million of cash used for the payment of dividends, partially offset by: (i) $1.4 billion of net proceeds from the issuance of debt, (ii) $94 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, and (iii) $66 million of distributions from discontinued operations

[0000068505-15-000013:mdna:132]
Long-Term Debt:  We had outstanding long-term debt of $4.4 billion and $3.4 billion, including the current portions of $4 million, at October 3, 2015 and December 31, 2014.

[0000068505-15-000013:mdna:133]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-15-000013:mdna:134]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. On August 5, 2015, our corporate credit and senior unsecured long-term debt ratings were downgraded by two of the three rating agencies in connection with our capital structure activities. Moody's Investors Service downgraded its Baa2 rating to Baa3 and changed its outlook from stable to negative. Standard & Poor’s Rating Services downgraded its BBB rating to BBB- and maintained its stable outlook. Fitch Ratings confirmed its BBB rating on August 5, 2015 but changed its outlook to negative from stable. We continue to believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty, or volatility in the capital markets or deterioration in our credit ratings may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-15-000013:mdna:135]
Share Repurchase Program:  On August 4, 2015, the Board of Directors authorized the Company to commence a modified "Dutch auction" tender offer to repurchase up to $2 billion of its outstanding shares of common stock. The repurchase of these shares was authorized under the existing share repurchase authority. The tender offer commenced on August 7, 2015 and expired on September 3, 2015. The Company paid $2 billion, including transaction costs, to repurchase approximately 30.1 million shares at a tender price of $66.50 per share.

[0000068505-15-000013:mdna:136]
In addition, excluding shares repurchased under the tender offer mentioned above, the Company paid an aggregate of $55 million during the three months ended October 3, 2015, including transaction costs, to repurchase approximately 0.8 million shares at an average price of $67.62 per share.

[0000068505-15-000013:mdna:137]
During the nine months ended October 3, 2015, the Company paid an aggregate of $3.0 billion, including transaction costs, to repurchase approximately 45.4 million shares at an average price of $66.04 per share. As of October 3, 2015, the Company had used approximately $10.8 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.2 billion of authority available for future repurchases.

[0000068505-15-000013:mdna:138]
Payment of Dividends:  During the third quarter of 2015, we paid $70 million in cash dividends to holders of our common stock. During the first nine months of 2015, we paid $218 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $60 million in cash dividends to holders of our common stock.

[0000068505-15-000013:mdna:139]
[same as prior period, unchanged from 0000068505-15-000010:mdna:145]

[0000068505-15-000013:mdna:140]
As of October 3, 2015, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of October 3, 2015. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first nine months of 2015.

[0000068505-15-000013:mdna:141]
[same as prior period, unchanged from 0000068505-15-000010:mdna:147]

[0000068505-15-000013:mdna:142]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $136 million at October 3, 2015, compared to $293 million at December 31, 2014.  Outstanding commitments decreased during the first nine months of 2015 primarily as a result of two large customer contracts, one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-15-000013:mdna:143]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $16 million at October 3, 2015, compared to $31 million at December 31, 2014.

[0000068505-15-000013:mdna:144]
[same as prior period, unchanged from 0000068505-15-000010:mdna:150]

[0000068505-15-000013:mdna:145]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended October 3, 2015 and September 27, 2014:

[0000068505-15-000013:mdna:146]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Accounts receivable sales proceeds | $ | 5 |  |  | $ | 6 |  |  | $ | 16 |  |  | $ | 39 |  |
| Long-term receivables sales proceeds | 24 |  |  | 37 |  |  | 132 |  |  | 91 |  |
| Total proceeds from sales of accounts receivable | $ | 29 |  |  | $ | 43 |  |  | $ | 148 |  |  | $ | 130 |  |

[0000068505-15-000013:mdna:147]
As of October 3, 2015, we had retained servicing obligations for $615 million of sold long-term receivables, compared to $496 million of sold long-term receivables at December 31, 2014. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-15-000013:mdna:148]
Other Contingencies

[0000068505-15-000013:mdna:149]
[same as prior period, unchanged from 0000068505-15-000010:mdna:155]

[0000068505-15-000013:mdna:150]
[same as prior period, unchanged from 0000068505-15-000010:mdna:156]

[0000068505-15-000013:mdna:151]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  We had no accruals for any such obligations at October 3, 2015.

[0000068505-15-000013:mdna:152]
[same as prior period, unchanged from 0000068505-15-000010:mdna:158]

[0000068505-15-000013:mdna:153]
[same as prior period, unchanged from 0000068505-15-000010:mdna:159]

[0000068505-15-000013:mdna:154]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of this ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with

[0000068505-15-000013:mdna:155]
Customers: Deferral of the Effective Date that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as our annual reporting period begins after December 15, 2017. ASU 2014-09 allows for both retrospective and modified-retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-15-000013:mdna:156]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, we will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of October 3, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $44 million.

[0000068505-15-000013:mdna:157]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, whereas net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for us beginning January 1, 2017 with early adoption permitted. We do not expect this ASU will have a material impact on our consolidated financial statements.

[0000068505-15-000013:mdna:158]
36
