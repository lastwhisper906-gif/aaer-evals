# MSI 8-K — 0001193125-15-365195 filed 2015-11-04

## item codes, every 8-K on or before 2015-11-04

- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2015-11-04

- none on or before 2015-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-365195:8k_2_02:1]
EX-99.1
2
d11191dex991.htm
EX-99.1

[0001193125-15-365195:8k_2_02:2]
EX-99.1

[0001193125-15-365195:8k_2_02:3]
Exhibit 99.1

[0001193125-15-365195:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2015 Financial Results

[0001193125-15-365195:8k_2_02:5]
|  | • |  | Sales of $1.4 billion, down 1 percent from a year ago, including $54 million of unfavorable foreign currency impact |

[0001193125-15-365195:8k_2_02:6]
|  | • |  | North America sales grew 5 percent, driven by both Products and Services segment sales |

[0001193125-15-365195:8k_2_02:7]
|  | • |  | GAAP earnings per share (EPS) from continuing operations1 of $0.63 |

[0001193125-15-365195:8k_2_02:8]
|  | • |  | Non-GAAP EPS from continuing operations* of $0.82, resulting in growth of 32 percent |

[0001193125-15-365195:8k_2_02:9]
|  | • |  | Generated $300 million in operating cash flow and $250 million in free cash flow2 |

[0001193125-15-365195:8k_2_02:10]
|  | • |  | Returned more than $2.1 billion to shareholders through share repurchases and cash dividends, including the repurchase of approximately $2.1 billion of stock in the quarter |

[0001193125-15-365195:8k_2_02:11]
SCHAUMBURG, Ill. - Nov. 4, 2015 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of
2015. Click here for a printable news release and financial tables.

[0001193125-15-365195:8k_2_02:12]
SUPPORTING QUOTE

[0001193125-15-365195:8k_2_02:13]
“Our business showed resilience in the third quarter despite a mixed global economic environment and significant currency headwinds,” said Greg
Brown, chairman and CEO of Motorola Solutions. “We delivered a strong quarter of 32 percent earnings per share growth, additional cost reductions and more than $2 billion of capital return. We believe we are well positioned for significant
growth in operating earnings and free cash flow per share.”

[0001193125-15-365195:8k_2_02:14]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0001193125-15-365195:8k_2_02:15]
|  |  | Q3 2015 |  |  | Q3 2014 |  |  | % Change |  |
| Sales |  | $ | 1,422 |  |  | $ | 1,436 |  |  |  | (1 | )% |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 231 |  |  | $ | 207 |  |  |  | 12 | % |
| % of Sales |  |  | 16.2 | % |  |  | 14.4 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.63 |  |  | $ | 0.27 |  |  |  | 133 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 292 |  |  | $ | 259 |  |  |  | 13 | % |
| % of Sales |  |  | 20.5 | % |  |  | 18.0 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 0.82 |  |  | $ | 0.62 |  |  |  | 32 | % |
| Products Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 925 |  |  | $ | 921 |  |  |  | — | % |
| GAAP Operating Earnings |  | $ | 178 |  |  | $ | 141 |  |  |  | 26 | % |
| % of Sales |  |  | 19.2 | % |  |  | 15.3 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 221 |  |  | $ | 175 |  |  |  | 26 | % |
| % of Sales |  |  | 23.9 | % |  |  | 19.0 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 497 |  |  | $ | 515 |  |  |  | (3 | )% |
| GAAP Operating Earnings |  | $ | 53 |  |  | $ | 66 |  |  |  | (20 | )% |
| % of Sales |  |  | 10.7 | % |  |  | 12.8 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 71 |  |  | $ | 84 |  |  |  | (15 | )% |
| % of Sales |  |  | 14.3 | % |  |  | 16.3 | % |  |  |  |  |

[0001193125-15-365195:8k_2_02:16]
| * | Non-GAAP financial information excludes the after-tax impact of approximately $0.19 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. |

[0001193125-15-365195:8k_2_02:17]
Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0001193125-15-365195:8k_2_02:18]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-15-365195:8k_2_02:19]
|  | • |  | Revenue - Sales decreased 1 percent, including $54 million of unfavorable foreign currency impact. Sales grew 3 percent in constant currency terms. These results reflect 5 percent growth in North America, which delivered improvements in both Products and Services sales in state and local governments along with strong performance in the U.S. Federal business. Overall company product sales were flat due to currency headwinds and weakness in the Latin America region. The Services business declined 3 percent primarily due to currency headwinds, lower iDEN revenue and a decline in systems integration revenues in Norway. |

[0001193125-15-365195:8k_2_02:20]
|  | • |  | Operating margin - GAAP operating margin was 16.2 percent of sales in the third quarter of 2015, compared with 14.4 percent in the third quarter of 2014; non-GAAP operating margin was 20.5 percent of sales, compared with 18.0 percent in the third quarter of 2014, reflecting $39 million in lower operating expenses compared with the third quarter of 2014, due to the company’s cost reduction initiatives, lower pension expense and a stronger dollar. |

[0001193125-15-365195:8k_2_02:21]
|  | • |  | Taxes - The third quarter of 2015 GAAP effective tax rate was 36 percent. This compares with a tax rate of 56 percent in the third quarter of 2014, which included a $55 million tax expense related to a valuation allowance. The third quarter of 2015 non-GAAP tax rate was 35 percent, compared with a tax rate of 33 percent in the third quarter of 2014. The full-year non-GAAP tax rate is expected to be approximately 33 percent. The full-year cash tax rate3 is expected to be approximately 15 percent. |

[0001193125-15-365195:8k_2_02:22]
|  | • |  | Cash flow - The company generated $300 million in operating cash from continuing operations during the quarter, reflecting an increase of $415 million over the prior year. Free cash flow was $250 million in the quarter. The increase was largely driven by $397 million in lower pension contributions and improved earnings performance. |

[0001193125-15-365195:8k_2_02:23]
|  | • |  | Cash and cash equivalents - The company ended the quarter with cash and cash equivalents of $2.2 billion and a net debt position of approximately $2.2 billion4. The company repurchased approximately $2.1 billion of its common stock in the third quarter of 2015 and paid approximately $70 million in cash dividends. |

[0001193125-15-365195:8k_2_02:24]
KEY HIGHLIGHTS

[0001193125-15-365195:8k_2_02:25]
Strategic wins

[0001193125-15-365195:8k_2_02:26]
|  | • |  | $50 million for a nationwide Project P25 digital land mobile radio (P25) system for the state police force in northern Africa covering approximately 50 sites and more than 5,000 subscribers |

[0001193125-15-365195:8k_2_02:27]
|  | • |  | $45 million extension to complete the build-out and final phase of a multiyear, statewide network upgrade in the eastern United States |

[0001193125-15-365195:8k_2_02:28]
|  | • |  | $24 million contract for a P25 system that provides a combined, inter-operable radio solution for the Texas cities of Mesquite, Garland, Rowlett and Sachse covering nearly 400,000 people |

[0001193125-15-365195:8k_2_02:29]
|  | • |  | Multiple U.S. Smart Public Safety Solutions wins including computer-aided dispatch, Next Gen 911, and expansion of Intelligence Led Public Safety solutions |

[0001193125-15-365195:8k_2_02:30]
Innovation and investments in growth

[0001193125-15-365195:8k_2_02:31]
|  | • |  | Launched the company’s first three-in-one combination body-worn video camera, radio speaker and microphone, and new, cloud-based content management system. The end-to-end video solution, the Si500/Si300 and CommandCentral Vault, combines the company’s secure, digital evidence management software with voice communications, body-worn video, voice recording and emergency alerting delivered in one compact device. |

[0001193125-15-365195:8k_2_02:32]
|  | • |  | Growing new product revenue well ahead of expectations with the launch of the APX 8000 radio. The enhanced functionality of being a multiband device with Wi-Fi and Bluetooth enables personal area networks that access the Internet of Things and serves as a platform for future APX devices. |

[0001193125-15-365195:8k_2_02:33]
|  | • |  | Leading public safety LTE trials with multiple international police forces in every region to provide high-speed broadband capabilities and securely distribute situational-aware content to and from officers on the front lines with command centers, utilizing interoperability between LTE and land-mobile radio (LMR) networks enabled by Motorola Solutions WAVE technology, third-party mobile applications, broadband devices and video. |

[0001193125-15-365195:8k_2_02:34]
BUSINESS OUTLOOK

[0001193125-15-365195:8k_2_02:35]
Fourth quarter 2015 - Motorola
Solutions expects a revenue decline of 6 to 8 percent compared with the fourth quarter of 2014. This assumes a $65 million5 unfavorable currency impact, which translates to a revenue decline of 3
to 5 percent in constant currency. The company expects non-GAAP earnings per share from continuing operations in the range of $1.45 to $1.50 per share. This outlook is driven primarily by further weakness in Latin America and incremental currency
pressure.

[0001193125-15-365195:8k_2_02:36]
CONFERENCE CALL AND WEBCAST

[0001193125-15-365195:8k_2_02:37]
Motorola
Solutions will host its quarterly conference call beginning at 7:30 a.m. U.S. Central Standard Time (8:30 a.m. U.S. Eastern Standard Time) Wednesday, Nov. 4. The conference call will be webcast live with audio and slides at
www.motorolasolutions.com/investor.

[0001193125-15-365195:8k_2_02:38]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0001193125-15-365195:8k_2_02:39]
A comparison of results from operations is as follows:

[0001193125-15-365195:8k_2_02:40]
|  |  | Q3 2015 |  |  | Q3 2014 |  |
| Net sales |  | $ | 1,422 |  |  | $ | 1,436 |  |
| Gross margin |  |  | 685 |  |  |  | 685 |  |
| Operating earnings |  |  | 231 |  |  |  | 207 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  |  | 126 |  |  |  | 66 |  |
| Net earnings |  |  | 115 |  |  |  | 147 |  |
| Diluted EPS from continuing operations |  | $ | 0.63 |  |  | $ | 0.27 |  |
| Weighted average diluted common shares outstanding (see footnote 6) |  |  | 201.3 |  |  |  | 248.2 |  |

[0001193125-15-365195:8k_2_02:41]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-15-365195:8k_2_02:42]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the third quarter of 2015.

[0001193125-15-365195:8k_2_02:43]
| (per diluted common share) |  | Q3 2015 |  |
| GAAP Earnings from Continuing Operations |  | $ | 0.63 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.06 |  |
| Reorganization of business charges |  |  | 0.05 |  |
| Intangibles amortization expense |  |  | — |  |
| Impairment of corporate aircraft |  |  | 0.08 |  |
| Total Highlighted Items |  | $ | 0.19 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 0.82 |  |

[0001193125-15-365195:8k_2_02:44]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-15-365195:8k_2_02:45]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-15-365195:8k_2_02:46]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-15-365195:8k_2_02:47]
Share-based compensation expense: The
company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such
compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation
expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-15-365195:8k_2_02:48]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense
from its Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible
assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during
the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-15-365195:8k_2_02:49]
Constant Currency: We evaluate our results of operations on both an as reported and a constant currency basis. The constant currency presentation,
which is a non-GAAP measure, excludes the impact of fluctuations in foreign currency exchange rates. We calculate constant currency percentages by converting our current period local currency results using prior-period exchange rates, and then
comparing these adjusted values to prior period reported results.

[0001193125-15-365195:8k_2_02:50]
Details of the above items and reconciliations of the non-GAAP measurements to
the corresponding GAAP measurements can be found at the end of this press release.

[0001193125-15-365195:8k_2_02:51]
BUSINESS RISKS

[0001193125-15-365195:8k_2_02:52]
the company’s ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s
purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (10) the impact on the company’s performance and financial results from strategic
acquisitions or divestitures; (11) risks related to the company’s manufacturing and business operations in foreign countries; (12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large
infrastructure systems; (13) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period;
(14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Trademark Holdings, LLC; (15) variability in income received from licensing the company’s intellectual property
to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar
proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the
company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in
governmental policies, laws or regulations; (21) negative consequences from the company’s outsourcing of various activities, including certain manufacturing operations, information technology and administrative functions; (22) the
impact of the sale of the company’s enterprise legacy information systems, including components of the enterprise resource planning (ERP) system and the implementation of a new ERP system; and (23) the company’s ability to settle the
par value of the Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-15-365195:8k_2_02:53]
DEFINITIONS

[0001193125-15-365195:8k_2_02:54]
| 1 | Amounts attributable to Motorola Solutions, Inc. common shareholders |

[0001193125-15-365195:8k_2_02:55]
| 2 | Free cash flow represents operating cash flow less capex |

[0001193125-15-365195:8k_2_02:56]
| 3 | Cash tax rate represents taxes paid divided by pre-tax income |

[0001193125-15-365195:8k_2_02:57]
| 4 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-15-365195:8k_2_02:58]
| 5 | Based on currency rates as of Nov. 2, 2015 |

[0001193125-15-365195:8k_2_02:59]
| 6 | $1B convertible notes issued in Q3 are expected to be settled in cash, and therefore the diluted shares are calculated on only the number of shares which would be issuable, based on the amount by which the average stock price exceeds the conversion price of $68.50 |

[0001193125-15-365195:8k_2_02:60]
ABOUT MOTOROLA SOLUTIONS

[0001193125-15-365195:8k_2_02:61]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build
safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-15-365195:8k_2_02:62]
MEDIA
CONTACT

[0001193125-15-365195:8k_2_02:63]
Kurt Ebenhoch

[0001193125-15-365195:8k_2_02:64]
Motorola Solutions

[0001193125-15-365195:8k_2_02:65]
+1 847-576-1341

[0001193125-15-365195:8k_2_02:66]
Kurt.ebenhoch@motorolasolutions.com

[0001193125-15-365195:8k_2_02:67]
INVESTOR CONTACTS

[0001193125-15-365195:8k_2_02:68]
Shep Dunlap

[0001193125-15-365195:8k_2_02:69]
Motorola Solutions

[0001193125-15-365195:8k_2_02:70]
+1 847-576-6899

[0001193125-15-365195:8k_2_02:71]
shep.dunlap@motorolasolutions.com

[0001193125-15-365195:8k_2_02:72]
Chris Kutsor

[0001193125-15-365195:8k_2_02:73]
Motorola Solutions

[0001193125-15-365195:8k_2_02:74]
+1 847-576-4995

[0001193125-15-365195:8k_2_02:75]
chris.kutsor@motorolasolutions.com

[0001193125-15-365195:8k_2_02:76]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license.
All other trademarks are the property of their respective owners. ©2015 Motorola Solutions, Inc. All rights reserved.

[0001193125-15-365195:8k_2_02:77]
GAAP-1

[0001193125-15-365195:8k_2_02:78]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:79]
Condensed Consolidated Statements of Operations

[0001193125-15-365195:8k_2_02:80]
(In millions, except per share amounts)

[0001193125-15-365195:8k_2_02:81]
|  |  | Three Months Ended |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |
| Net sales from products |  | $ | 925 |  |  | $ | 921 |  |
| Net sales from services |  |  | 497 |  |  |  | 515 |  |
| Net sales |  |  | 1,422 |  |  |  | 1,436 |  |
| Costs of products sales |  |  | 395 |  |  |  | 414 |  |
| Costs of services sales |  |  | 342 |  |  |  | 337 |  |
| Costs of sales |  |  | 737 |  |  |  | 751 |  |
| Gross margin |  |  | 685 |  |  |  | 685 |  |
| Selling, general and administrative expenses |  |  | 259 |  |  |  | 287 |  |
| Research and development expenditures |  |  | 153 |  |  |  | 166 |  |
| Other charges |  |  | 40 |  |  |  | 24 |  |
| Intangibles amortization |  |  | 2 |  |  |  | 1 |  |
| Operating earnings |  |  | 231 |  |  |  | 207 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (43 | ) |  |  | (31 | ) |
| Gains on sales of investments, net |  |  | 10 |  |  |  | 1 |  |
| Other |  |  | (1 | ) |  |  | (26 | ) |
| Total other expense |  |  | (34 | ) |  |  | (56 | ) |
| Earnings from continuing operations before income taxes |  |  | 197 |  |  |  | 151 |  |
| Income tax expense |  |  | 71 |  |  |  | 84 |  |
| Earnings from continuing operations |  |  | 126 |  |  |  | 67 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (11 | ) |  |  | 81 |  |
| Net earnings |  |  | 115 |  |  |  | 148 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 115 |  |  | $ | 147 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 126 |  |  | $ | 66 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (11 | ) |  |  | 81 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 115 |  |  | $ | 147 |  |
| Earnings (loss) per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.63 |  |  | $ | 0.27 |  |
| Discontinued operations |  |  | (0.05 | ) |  |  | 0.33 |  |
|  |  | $ | 0.58 |  |  | $ | 0.60 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.63 |  |  | $ | 0.27 |  |
| Discontinued operations |  |  | (0.06 | ) |  |  | 0.32 |  |
|  |  | $ | 0.57 |  |  | $ | 0.59 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 199.2 |  |  |  | 246.3 |  |
| Diluted |  |  | 201.3 |  |  |  | 248.2 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 65.0 | % |  |  | 64.1 | % |
| Net sales from services |  |  | 35.0 | % |  |  | 35.9 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 42.7 | % |  |  | 45.0 | % |
| Costs of services sales |  |  | 68.8 | % |  |  | 65.4 | % |
| Costs of sales |  |  | 51.8 | % |  |  | 52.3 | % |
| Gross margin |  |  | 48.2 | % |  |  | 47.7 | % |
| Selling, general and administrative expenses |  |  | 18.2 | % |  |  | 20.0 | % |
| Research and development expenditures |  |  | 10.8 | % |  |  | 11.6 | % |
| Other charges |  |  | 2.8 | % |  |  | 1.7 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.1 | % |
| Operating earnings |  |  | 16.2 | % |  |  | 14.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (3.0 | )% |  |  | (2.2 | )% |
| Gains on sales of investments, net |  |  | 0.7 | % |  |  | 0.1 | % |
| Other |  |  | (0.1 | )% |  |  | (1.8 | )% |
| Total other expense |  |  | (2.4 | )% |  |  | (3.9 | )% |
| Earnings from continuing operations before income taxes |  |  | 13.9 | % |  |  | 10.5 | % |
| Income tax expense |  |  | 5.0 | % |  |  | 5.8 | % |
| Earnings from continuing operations |  |  | 8.9 | % |  |  | 4.7 | % |
| Earnings (loss) from discontinued operations, net of tax |  |  | (0.8 | )% |  |  | 5.6 | % |
| Net earnings |  |  | 8.1 | % |  |  | 10.3 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | — | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 8.1 | % |  |  | 10.2 | % |

[0001193125-15-365195:8k_2_02:82]
| * | Percentages may not add up due to rounding |

[0001193125-15-365195:8k_2_02:83]
GAAP-2

[0001193125-15-365195:8k_2_02:84]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:85]
Condensed Consolidated Statements of Operations

[0001193125-15-365195:8k_2_02:86]
(In millions, except per share amounts)

[0001193125-15-365195:8k_2_02:87]
|  |  | Nine Months Ended |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |
| Net sales from products |  | $ | 2,550 |  |  | $ | 2,561 |  |
| Net sales from services |  |  | 1,463 |  |  |  | 1,497 |  |
| Net sales |  |  | 4,013 |  |  |  | 4,058 |  |
| Costs of products sales |  |  | 1,139 |  |  |  | 1,165 |  |
| Costs of services sales |  |  | 993 |  |  |  | 974 |  |
| Costs of sales |  |  | 2,132 |  |  |  | 2,139 |  |
| Gross margin |  |  | 1,881 |  |  |  | 1,919 |  |
| Selling, general and administrative expenses |  |  | 769 |  |  |  | 902 |  |
| Research and development expenditures |  |  | 468 |  |  |  | 516 |  |
| Other charges |  |  | 33 |  |  |  | 46 |  |
| Intangibles amortization |  |  | 6 |  |  |  | 3 |  |
| Operating earnings |  |  | 605 |  |  |  | 452 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (122 | ) |  |  | (85 | ) |
| Gains on sales of investments, net |  |  | 60 |  |  |  | 4 |  |
| Other |  |  | (3 | ) |  |  | (34 | ) |
| Total other expense |  |  | (65 | ) |  |  | (115 | ) |
| Earnings from continuing operations before income taxes |  |  | 540 |  |  |  | 337 |  |
| Income tax expense |  |  | 175 |  |  |  | 107 |  |
| Earnings from continuing operations |  |  | 365 |  |  |  | 230 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (32 | ) |  |  | 869 |  |
| Net earnings |  |  | 333 |  |  |  | 1,099 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 2 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 331 |  |  | $ | 1,098 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 363 |  |  | $ | 229 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (32 | ) |  |  | 869 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 331 |  |  | $ | 1,098 |  |
| Earnings (loss) per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.75 |  |  | $ | 0.91 |  |
| Discontinued operations |  |  | (0.15 | ) |  |  | 3.46 |  |
|  |  | $ | 1.60 |  |  | $ | 4.37 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.74 |  |  | $ | 0.90 |  |
| Discontinued operations |  |  | (0.16 | ) |  |  | 3.42 |  |
|  |  | $ | 1.58 |  |  | $ | 4.32 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 207.2 |  |  |  | 251.1 |  |
| Diluted |  |  | 209.2 |  |  |  | 254.0 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 63.5 | % |  |  | 63.1 | % |
| Net sales from services |  |  | 36.5 | % |  |  | 36.9 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 44.7 | % |  |  | 45.5 | % |
| Costs of services sales |  |  | 67.9 | % |  |  | 65.1 | % |
| Costs of sales |  |  | 53.1 | % |  |  | 52.7 | % |
| Gross margin |  |  | 46.9 | % |  |  | 47.3 | % |
| Selling, general and administrative expenses |  |  | 19.2 | % |  |  | 22.2 | % |
| Research and development expenditures |  |  | 11.7 | % |  |  | 12.7 | % |
| Other charges |  |  | 0.8 | % |  |  | 1.1 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.1 | % |
| Operating earnings |  |  | 15.1 | % |  |  | 11.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (3.0 | )% |  |  | (2.1 | )% |
| Gains on sales of investments, net |  |  | 1.5 | % |  |  | 0.1 | % |
| Other |  |  | (0.1 | )% |  |  | (0.8 | )% |
| Total other expense |  |  | (1.6 | )% |  |  | (2.8 | )% |
| Earnings from continuing operations before income taxes |  |  | 13.5 | % |  |  | 8.3 | % |
| Income tax expense |  |  | 4.4 | % |  |  | 2.6 | % |
| Earnings from continuing operations |  |  | 9.1 | % |  |  | 5.7 | % |
| Earnings (loss) from discontinued operations, net of tax |  |  | (0.8 | )% |  |  | 21.4 | % |
| Net earnings |  |  | 8.3 | % |  |  | 27.1 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | — | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 8.2 | % |  |  | 27.1 | % |

[0001193125-15-365195:8k_2_02:88]
| * | Percentages may not add up due to rounding |

[0001193125-15-365195:8k_2_02:89]
GAAP-3

[0001193125-15-365195:8k_2_02:90]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:91]
Condensed Consolidated Balance Sheets

[0001193125-15-365195:8k_2_02:92]
(In millions)

[0001193125-15-365195:8k_2_02:93]
|  |  | October 3, 2015 |  |  | December 31, 2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,200 |  |  | $ | 3,954 |  |
| Accounts receivable, net |  |  | 1,222 |  |  |  | 1,409 |  |
| Inventories, net |  |  | 334 |  |  |  | 345 |  |
| Deferred income taxes |  |  | 430 |  |  |  | 431 |  |
| Other current assets |  |  | 574 |  |  |  | 740 |  |
| Current assets held for disposition |  |  | 27 |  |  |  | — |  |
| Total current assets |  |  | 4,787 |  |  |  | 6,879 |  |
| Property, plant and equipment, net |  |  | 467 |  |  |  | 549 |  |
| Investments |  |  | 292 |  |  |  | 316 |  |
| Deferred income taxes |  |  | 1,889 |  |  |  | 2,151 |  |
| Goodwill |  |  | 423 |  |  |  | 383 |  |
| Other assets |  |  | 183 |  |  |  | 145 |  |
| Non-current assets held for disposition |  |  | 45 |  |  |  | — |  |
| Total assets |  | $ | 8,086 |  |  | $ | 10,423 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 443 |  |  |  | 540 |  |
| Accrued liabilities |  |  | 1,582 |  |  |  | 1,706 |  |
| Total current liabilities |  |  | 2,029 |  |  |  | 2,250 |  |
| Long-term debt |  |  | 4,386 |  |  |  | 3,396 |  |
| Other liabilities |  |  | 1,969 |  |  |  | 2,011 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (307 | ) |  |  | 2,735 |  |
| Noncontrolling interests |  |  | 9 |  |  |  | 31 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,086 |  |  | $ | 10,423 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (2,190 | ) |  | $ | 554 |  |

[0001193125-15-365195:8k_2_02:94]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-15-365195:8k_2_02:95]
GAAP-4

[0001193125-15-365195:8k_2_02:96]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:97]
Condensed Consolidated Statements of Cash Flows

[0001193125-15-365195:8k_2_02:98]
(In millions)

[0001193125-15-365195:8k_2_02:99]
|  |  | Three Months Ended |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 115 |  |  | $ | 147 |  |
| Earnings attributable to noncontrolling interests |  |  | — |  |  |  | 1 |  |
| Net earnings |  |  | 115 |  |  |  | 148 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (11 | ) |  |  | 81 |  |
| Earnings from continuing operations, net of tax |  |  | 126 |  |  |  | 67 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by (used for) operating activities from continuing operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 32 |  |  |  | 45 |  |
| Non-cash other charges |  |  | 38 |  |  |  | 2 |  |
| Share-based compensation expense |  |  | 18 |  |  |  | 20 |  |
| Gains on sales of investments and businesses, net |  |  | (10 | ) |  |  | (1 | ) |
| Loss from the extinguishment of long term debt |  |  | — |  |  |  | 37 |  |
| Deferred income taxes |  |  | 72 |  |  |  | 63 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (88 | ) |  |  | 12 |  |
| Inventories |  |  | 4 |  |  |  | (5 | ) |
| Other current assets |  |  | 10 |  |  |  | (85 | ) |
| Accounts payable and accrued liabilities |  |  | 95 |  |  |  | 128 |  |
| Other assets and liabilities |  |  | 3 |  |  |  | (398 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 300 |  |  |  | (115 | ) |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (57 | ) |  |  | (11 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 39 |  |  |  | 2 |  |
| Capital expenditures |  |  | (50 | ) |  |  | (47 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 1 |  |  |  | 6 |  |
| Net cash used for investing activities from continuing operations |  |  | (67 | ) |  |  | (50 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (458 | ) |
| Net proceeds from issuance of debt |  |  | 976 |  |  |  | 1,370 |  |
| Issuance of common stock |  |  | 34 |  |  |  | 9 |  |
| Purchase of common stock |  |  | (2,058 | ) |  |  | (650 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 5 |  |
| Payment of dividends |  |  | (70 | ) |  |  | (78 | ) |
| Distributions to discontinued operations |  |  | — |  |  |  | (32 | ) |
| Net cash provided by (used for) financing activities from continuing operations |  |  | (1,119 | ) |  |  | 166 |  |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash used for operating activities from discontinued operations |  |  | — |  |  |  | (25 | ) |
| Net cash used for investing activities from discontinued operations |  |  | — |  |  |  | (5 | ) |
| Net cash provided by financing activities from discontinued operations |  |  | — |  |  |  | 32 |  |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | (2 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (26 | ) |  |  | (32 | ) |
| Net decrease in cash and cash equivalents |  |  | (912 | ) |  |  | (31 | ) |
| Cash and cash equivalents, beginning of period |  |  | 3,112 |  |  |  | 2,876 |  |
| Cash and cash equivalents, end of period |  | $ | 2,200 |  |  | $ | 2,845 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 250 |  |  | $ | (162 | ) |

[0001193125-15-365195:8k_2_02:100]
| * | Free cash flow = Net cash provided by operating activities—Capital Expenditures |

[0001193125-15-365195:8k_2_02:101]
GAAP-5

[0001193125-15-365195:8k_2_02:102]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:103]
Condensed Consolidated Statements of Cash Flows

[0001193125-15-365195:8k_2_02:104]
(In millions)

[0001193125-15-365195:8k_2_02:105]
|  |  | Nine Months Ended |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 331 |  |  | $ | 1,098 |  |
| Earnings attributable to noncontrolling interests |  |  | 2 |  |  |  | 1 |  |
| Net earnings |  |  | 333 |  |  |  | 1,099 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (32 | ) |  |  | 869 |  |
| Earnings from continuing operations, net of tax |  |  | 365 |  |  |  | 230 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities from continuing operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 113 |  |  |  | 131 |  |
| Gain on sale of building and land |  |  | — |  |  |  | (21 | ) |
| Non-cash other charges (income) |  |  | 43 |  |  |  | (2 | ) |
| Non-U.S. pension curtailment gain |  |  | (32 | ) |  |  | — |  |
| Share-based compensation expense |  |  | 58 |  |  |  | 74 |  |
| Gains on sales of investments and businesses, net |  |  | (60 | ) |  |  | (4 | ) |
| Loss from the extinguishment of long term debt |  |  | — |  |  |  | 37 |  |
| Deferred income taxes |  |  | 127 |  |  |  | 69 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 167 |  |  |  | 202 |  |
| Inventories |  |  | (21 | ) |  |  | 12 |  |
| Other current assets |  |  | 38 |  |  |  | (9 | ) |
| Accounts payable and accrued liabilities |  |  | (168 | ) |  |  | (170 | ) |
| Other assets and liabilities |  |  | (39 | ) |  |  | (534 | ) |
| Net cash provided by operating activities from continuing operations |  |  | 591 |  |  |  | 15 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (150 | ) |  |  | (21 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 150 |  |  |  | 23 |  |
| Capital expenditures |  |  | (131 | ) |  |  | (130 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 2 |  |  |  | 30 |  |
| Net cash used for investing activities from continuing operations |  |  | (129 | ) |  |  | (98 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (3 | ) |  |  | (461 | ) |
| Net proceeds from issuance of debt |  |  | 976 |  |  |  | 1,375 |  |
| Issuance of common stock |  |  | 85 |  |  |  | 94 |  |
| Purchase of common stock |  |  | (2,996 | ) |  |  | (1,123 | ) |
| Excess tax benefit from share-based compensation |  |  | 1 |  |  |  | 11 |  |
| Payment of dividends |  |  | (218 | ) |  |  | (236 | ) |
| Distributions from discontinued operations |  |  | — |  |  |  | 66 |  |
| Net cash used for financing activities from continuing operations |  |  | (2,155 | ) |  |  | (274 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | — |  |  |  | 63 |  |
| Net cash provided by investing activities from discontinued operations |  |  | — |  |  |  | 5 |  |
| Net cash used for financing activities from discontinued operations |  |  | — |  |  |  | (66 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | (2 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (61 | ) |  |  | (23 | ) |
| Net decrease in cash and cash equivalents |  |  | (1,754 | ) |  |  | (380 | ) |
| Cash and cash equivalents, beginning of period |  |  | 3,954 |  |  |  | 3,225 |  |
| Cash and cash equivalents, end of period |  | $ | 2,200 |  |  | $ | 2,845 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 460 |  |  | $ | (115 | ) |

[0001193125-15-365195:8k_2_02:106]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-15-365195:8k_2_02:107]
GAAP-6

[0001193125-15-365195:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:109]
Segment Information

[0001193125-15-365195:8k_2_02:110]
(In
millions)

[0001193125-15-365195:8k_2_02:111]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 925 |  |  | $ | 921 |  |  |  | — | % |
| Services |  |  | 497 |  |  |  | 515 |  |  |  | (3 | )% |
| Total Motorola Solutions |  | $ | 1,422 |  |  | $ | 1,436 |  |  |  | (1 | )% |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 2,550 |  |  | $ | 2,561 |  |  |  | — | % |
| Services |  |  | 1,463 |  |  |  | 1,497 |  |  |  | (2 | )% |
| Total Motorola Solutions |  | $ | 4,013 |  |  | $ | 4,058 |  |  |  | (1 | )% |
| Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 178 |  |  | $ | 141 |  |  |  | 26 | % |
| Services |  |  | 53 |  |  |  | 66 |  |  |  | (20 | )% |
| Total Motorola Solutions |  | $ | 231 |  |  | $ | 207 |  |  |  | 12 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 413 |  |  | $ | 276 |  |  |  | 50 | % |
| Services |  |  | 192 |  |  |  | 176 |  |  |  | 9 | % |
| Total Motorola Solutions |  | $ | 605 |  |  | $ | 452 |  |  |  | 34 | % |
| Operating Earnings % |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  |  |  |
| Products |  |  | 19.2 | % |  |  | 15.3 | % |  |  |  |  |
| Services |  |  | 10.7 | % |  |  | 12.8 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 16.2 | % |  |  | 14.4 | % |  |  |  |  |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  |  |  |
| Products |  |  | 16.2 | % |  |  | 10.8 | % |  |  |  |  |
| Services |  |  | 13.1 | % |  |  | 11.8 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 15.1 | % |  |  | 11.1 | % |  |  |  |  |

[0001193125-15-365195:8k_2_02:112]
Non-GAAP-1

[0001193125-15-365195:8k_2_02:113]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:114]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-15-365195:8k_2_02:115]
Q1 2015

[0001193125-15-365195:8k_2_02:116]
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 21 |  |  |  | 7 |  |  | $ | 14 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 14 |  |  |  | 4 |  |  |  | 10 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of equity investment |  | Gains on sales of investments and businesses, net |  |  | (46 | ) |  |  | (17 | ) |  |  | (29 | ) |  |  | (0.13 | ) |
| Total impact on Net earnings |  |  |  | $ | (9 | ) |  | $ | (5 | ) |  | $ | (4 | ) |  | $ | (0.02 | ) |
| Q2 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 19 |  |  |  | 6 |  |  | $ | 13 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 16 |  |  |  | 6 |  |  | $ | 10 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 3 |  |  |  | 1 |  |  | $ | 2 |  |  |  | — |  |
| Non-U.S. pension curtailment gain |  | Other charges |  |  | (32 | ) |  |  | — |  |  | $ | (32 | ) |  |  | (0.15 | ) |
| Total impact on Net earnings |  |  |  | $ | 6 |  |  | $ | 13 |  |  | $ | (7 | ) |  | $ | (0.04 | ) |
| Q3 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPSimpact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 18 |  |  |  | 6 |  |  |  | 12 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 15 |  |  |  | 4 |  |  |  | 11 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Impairment of corporate aircraft |  | Other charges |  |  | 26 |  |  |  | 10 |  |  |  | 16 |  |  |  | 0.08 |  |
| Total impact on Net earnings |  |  |  | $ | 61 |  |  | $ | 21 |  |  | $ | 40 |  |  | $ | 0.19 |  |

[0001193125-15-365195:8k_2_02:117]
Non-GAAP-2

[0001193125-15-365195:8k_2_02:118]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:119]
Segment Information

[0001193125-15-365195:8k_2_02:120]
(In
millions)

[0001193125-15-365195:8k_2_02:121]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 925 |  |  | $ | 921 |  |  |  | — | % |
| Services |  |  | 497 |  |  |  | 515 |  |  |  | (3 | )% |
| Total Motorola Solutions |  | $ | 1,422 |  |  | $ | 1,436 |  |  |  | (1 | )% |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 2,550 |  |  | $ | 2,561 |  |  |  | — | % |
| Services |  |  | 1,463 |  |  |  | 1,497 |  |  |  | (2 | )% |
| Total Motorola Solutions |  | $ | 4,013 |  |  | $ | 4,058 |  |  |  | (1 | )% |
| Non-GAAP Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 221 |  |  | $ | 175 |  |  |  | 26 | % |
| Services |  |  | 71 |  |  |  | 84 |  |  |  | (15 | )% |
| Total Motorola Solutions |  | $ | 292 |  |  | $ | 259 |  |  |  | 13 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  | % Change |  |
| Products |  | $ | 487 |  |  | $ | 359 |  |  |  | 36 | % |
| Services |  |  | 221 |  |  |  | 226 |  |  |  | (2 | )% |
| Total Motorola Solutions |  | $ | 708 |  |  | $ | 585 |  |  |  | 21 | % |
| Non-GAAP Operating Earnings % |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  |  |  |
| Products |  |  | 23.9 | % |  |  | 19.0 | % |  |  |  |  |
| Services |  |  | 14.3 | % |  |  | 16.3 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 20.5 | % |  |  | 18.0 | % |  |  |  |  |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 3, 2015 |  |  | September 27, 2014 |  |  |  |  |
| Products |  |  | 19.1 | % |  |  | 14.0 | % |  |  |  |  |
| Services |  |  | 15.1 | % |  |  | 15.1 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 17.6 | % |  |  | 14.4 | % |  |  |  |  |

[0001193125-15-365195:8k_2_02:122]
Non-GAAP-3

[0001193125-15-365195:8k_2_02:123]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-365195:8k_2_02:124]
Operating Earnings after Non-GAAP Adjustments

[0001193125-15-365195:8k_2_02:125]
| Q1 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,223 |  |  | $ | 758 |  |  | $ | 465 |  |
| Operating earnings (“OE”) |  | $ | 119 |  |  | $ | 64 |  |  | $ | 55 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21 |  |  |  | 14 |  |  |  | 7 |  |
| Reorganization of business charges |  |  | 14 |  |  |  | 10 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Total above-OE non-GAAP adjustments |  |  | 37 |  |  |  | 26 |  |  |  | 11 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 156 |  |  | $ | 90 |  |  | $ | 66 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 9.7 | % |  |  | 8.4 | % |  |  | 11.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 12.8 | % |  |  | 11.9 | % |  |  | 14.2 | % |
| Q2 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,368 |  |  | $ | 867 |  |  | $ | 501 |  |
| Operating earnings (“OE”) |  | $ | 254 |  |  | $ | 171 |  |  | $ | 83 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 19 |  |  |  | 12 |  |  |  | 7 |  |
| Reorganization of business charges |  |  | 16 |  |  |  | 12 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Non-U.S. pension curtailment gain |  |  | (32 | ) |  |  | (22 | ) |  |  | (10 | ) |
| Total above-OE non-GAAP adjustments |  |  | 6 |  |  |  | 5 |  |  |  | 1 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 260 |  |  | $ | 176 |  |  | $ | 84 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 18.6 | % |  |  | 19.7 | % |  |  | 16.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 19.0 | % |  |  | 20.3 | % |  |  | 16.8 | % |
| Q3 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,422 |  |  | $ | 925 |  |  | $ | 497 |  |
| Operating earnings (“OE”) |  | $ | 231 |  |  | $ | 178 |  |  | $ | 53 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 18 |  |  |  | 12 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 15 |  |  |  | 11 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Impairment of corporate aircraft |  |  | 26 |  |  |  | 18 |  |  |  | 8 |  |
| Total above-OE non-GAAP adjustments |  |  | 61 |  |  |  | 43 |  |  |  | 18 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 292 |  |  | $ | 221 |  |  | $ | 71 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 16.2 | % |  |  | 19.2 | % |  |  | 10.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 20.5 | % |  |  | 23.9 | % |  |  | 14.3 | % |
