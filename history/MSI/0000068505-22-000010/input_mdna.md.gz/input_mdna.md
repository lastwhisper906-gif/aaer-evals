# MSI MD&A — 0000068505-22-000010


## mdna

[0000068505-22-000010:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-22-000010:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2021 and 2020 and results of operations and cash flows for each of the three years in the period ended December 31, 2021. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-22-000010:mdna:3]
Executive Overview

[0000068505-22-000010:mdna:4]
Our Business

[0000068505-22-000010:mdna:5]
Motorola Solutions is a global leader in mission-critical communications and analytics. Our technologies in Land Mobile Radio Communications ("LMR" or "LMR Communications"), Video Security and Access Control and Command Center Software, bolstered by managed and support services, make communities safer and help businesses stay productive and secure. We serve more than 100,000 public safety and commercial customers in over 100 countries, providing “purpose-built” solutions designed for their unique needs, and we have a rich heritage of innovation focusing on advancing global safety for more than 90 years.

[0000068505-22-000010:mdna:6]
We manage our business organizationally through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, the Company has principal product lines that also follow our three major technologies: LMR Communications, Video Security and Access Control and Command Center Software. In January 2022 we renamed one of our three major products and services technologies from LMR Mission Critical Communications to LMR Communications in an effort to more succinctly brand our LMR technology.  This change was to the name of the technology only and no financial information was reclassified from previous periods.

[0000068505-22-000010:mdna:7]
The Company has invested across these three technologies, evolving the Company’s LMR focus to purposefully integrate software, video security and access control solutions for public safety and enterprise customers globally.

[0000068505-22-000010:mdna:8]
Our strategy is to generate value through the integration of each technology into our ecosystem, uniting voice, software, video security, access control and analytics to interoperate. While each technology individually strives to make users safer and more productive, we believe we can enable better outcomes for individuals, businesses and agencies when we unite these technologies as one connected system. With our technology ecosystem, our goal is to help remove silos between systems, unify data, streamline workflows, simplify management and support evolving technologies. Across all three technologies, we offer cloud-based solutions, cybersecurity services and managed and support services.

[0000068505-22-000010:mdna:9]
An example of our integrated technology ecosystem in action is when our municipal governmental agency customers leverage communications, video security, analytics and cloud-based software to understand what is happening across their cities, which we believe helps to improve community collaboration and overall safety. Video Security and Access Control solutions help users identify and understand events, find lost people and protect property. Command Center Software informs and assists emergency response by unifying data across the 911 workflow, including call handling, dispatch, video analytics, field reporting, records, evidence and community input. Voice and data communications connect law enforcement, fire and emergency medical services from different agencies and jurisdictions in an effort to improve coordination and collaboration. The end-to-end integration of these technologies assists agencies in detecting, analyzing, communicating and responding to incidents.

[0000068505-22-000010:mdna:10]
The principal products within each segment, by technology, are described below:

[0000068505-22-000010:mdna:11]
Products and Systems Integration Segment

[0000068505-22-000010:mdna:12]
In 2021, the segment’s net sales were $5.0 billion, representing 62% of our consolidated net sales.

[0000068505-22-000010:mdna:13]
LMR Communications

[0000068505-22-000010:mdna:14]
Our LMR Communications technology includes infrastructure and devices for LMR, public safety Long Term Evolution (“LTE”) and enterprise-grade private LTE. We are a global leader in the two-way radio category, including Project 25 (“P25”), Terrestrial Trunked Radio (“TETRA”) and Digital Mobile Radio (“DMR”), as well as other PCR solutions. We also deliver LTE solutions for public safety, government and commercial users, including infrastructure and devices operating in 700 MHz, 900 MHz and Citizens’ Broadband Radio Service (“CBRS”) frequencies. Primary sources of revenue for this technology come from selling devices and building telecommunications networks, including infrastructure, installation and integration with our customers’ technology environments.

[0000068505-22-000010:mdna:15]
Our technology enables voice and multimedia collaborations across different two-way radio, WiFi or public LTE and private broadband networks. We believe that first responders continue to trust LMR communications because they are purpose-built and designed for reliability, availability, security and resiliency to withstand the most challenging conditions. By adding broadband data capabilities to our two-way radios, we strive to provide our customers with greater functionality and multimedia access to the information and data they need in their workflows. Examples include application services such as GPS location to better protect lone workers, job dispatch to share information and over-the-air programming to optimize device uptime.

[0000068505-22-000010:mdna:16]
The LMR technology within the Products and Systems Integration segment represented 84% of the net sales of the total segment in 2021.

[0000068505-22-000010:mdna:17]
Video Security and Access Control

[0000068505-22-000010:mdna:18]
Our Video Security and Access Control technology includes video management infrastructure, AI-powered security cameras including fixed and mobile (body-worn and in-vehicle) and access control solutions. We deploy video security and access control solutions to thousands of government and commercial customers around the world including school campuses, transportation systems, healthcare centers, public venues, utilities, prisons, factories, casinos, airports, financial institutions, government facilities, state and local law enforcement agencies and retailers. Organizations such as these utilize video security and access control to enable continuous monitoring that can improve situational awareness, verify critical events or incidents in real-time and provide data to investigate an event or incident after it happens.

[0000068505-22-000010:mdna:19]
Our view is that government and public safety customers in particular are increasingly turning to video security technologies, including fixed street cameras, in-vehicle cameras and body-worn cameras, to increase visibility, accountability and safety for citizens, communities and first responders alike. Additionally, our view is that government, public safety agencies and businesses are increasingly turning to scalable, cloud-based multi-factor authentication access control to make their facilities more secure.

[0000068505-22-000010:mdna:20]
Since 2018, we have developed our video security and access control business through investments in research and development and through acquisitions, directly contributing to our growth strategy to serve as a leader in end-to-end video security solutions. These activities have supported the expansion of our portfolio, which started with fixed video, access control and AI-enabled analytics solutions and has evolved to include mobile video (body-worn and in-vehicle cameras) for both public safety and commercial markets, a broader range of fixed video security technologies, business analytics and cloud-based access control solutions.

[0000068505-22-000010:mdna:21]
Software and Services Segment

[0000068505-22-000010:mdna:22]
In 2021, the segment’s net sales were $3.1 billion, representing 38% of our consolidated net sales.

[0000068505-22-000010:mdna:23]
LMR Communications

[0000068505-22-000010:mdna:24]
LMR Communications services include support and managed services, which offer a broad continuum of support for our customers. Support services include repair and replacement, technical support and preventative maintenance, and more advanced offerings such as system monitoring, software updates and cybersecurity services. Managed services range from partial to full operational support of customer-owned or Motorola Solutions-owned networks. Our customers’ systems often have multi-year or multi-decade lifespans that help drive demand for software upgrades, device and infrastructure refresh opportunities, as well as additional services to monitor, manage, maintain and secure these complex networks and solutions. We strive to deliver services to our customers that help improve performance across their systems, devices and applications for greater safety and productivity.

[0000068505-22-000010:mdna:25]
Given the mission-critical nature of our customers’ operational environments, we aim to design the LMR networks they rely on for availability, security and resiliency, as well as to keep pace with technological advancements. We have a comprehensive approach to system upgrades that addresses hardware, software and implementation services. As new system releases become available, we work with our customers to upgrade software, hardware, or both, with respect to site controllers, comparators, routers, LAN switches, servers, dispatch consoles, logging equipment, network management terminals, network security devices such as firewalls and intrusion detection sensors, and more, on-site or remotely.

[0000068505-22-000010:mdna:26]
The LMR technology within the Software and Services segment represented 70% of the net sales of the total segment in 2021.

[0000068505-22-000010:mdna:27]
Video Security and Access Control

[0000068505-22-000010:mdna:28]
Video Security and Access Control software includes video management software, decision and digital evidence management software and advanced vehicle location data analysis software, including license plate recognition. Our software is designed to complement video hardware systems, serving as an ecosystem that provides end-to-end video security to strive to keep people, property and assets safe.

[0000068505-22-000010:mdna:29]
Our video network management software is embedded with artificial intelligence (“AI”)-enabled analytics to deliver operational insights to our customers by bringing attention to important events within their video footage. Given the volume of video footage, we believe this is critical to monitor and manage to deliver meaningful, action-oriented insights.

[0000068505-22-000010:mdna:30]
For example, AI-enabled analytics can detect unusual behavior such as a person at a facility out of hours, locate a missing child at a theme park with Appearance Search, flag a denylisted vehicle at a school through license plate recognition, or send an alert through access control if doors are propped open at a hospital.

[0000068505-22-000010:mdna:31]
Video Security and Access Control services include our video-as-a-service offering for law enforcement, simplifying procurement by bundling hardware and software into a single subscription. Body-worn cameras and in-car video systems can be paired with either on-premises or cloud-based digital evidence management software and complementary command center software products. Additionally, Avigilon fixed video systems connected to Avigilon Cloud Services (“ACS”) provide our customers with the ability to securely access video across their sites from a remote central monitoring location and more easily integrate with their other systems.

[0000068505-22-000010:mdna:32]
The Video Security and Access Control technology within the Software and Services segment represented 13% of the net sales of the total segment in 2021.

[0000068505-22-000010:mdna:33]
Command Center Software

[0000068505-22-000010:mdna:34]
Our Command Center Software suite, CommandCentral, consists of native cloud and on-premises solutions that support the complex process of the public safety workflow from "911 call to case closure." The moment a citizen dials 911, an array of roles are involved in coordinating response and post-incident management, such as dispatchers who route calls to police, fire and emergency medical services, first responders in the field, intelligence analysts who manage real-time operations, records specialists who preserve the integrity of information and evidence, crime analysts who identify patterns and accelerate investigations, and corrections officers who oversee jail and inmate management.

[0000068505-22-000010:mdna:35]
CommandCentral software supports these roles through the three phases of incident response: incident awareness, incident management and post-incident resolution. Incident awareness software includes community engagement applications for tip submissions, crime mapping and evidence submission, and 911 call-handling software (including multimedia) and next-generation core services for 911 call routing. Incident management software includes computer aided dispatch (“CAD”) for dispatch and coordinating first response, situational awareness software that shows a single, real-time view of video feeds and other alerts on a map, and field response and reporting to help frontline personnel collaborate, manage incident activity and file reports from the field. Post-incident resolution software includes centralized records and evidence management for record-keeping and judicial sharing, analytics including license plate recognition, and jail and inmate management to streamline the process and enable secure inter-agency information sharing.

[0000068505-22-000010:mdna:36]
As the public safety market continues to evolve toward software offerings that more efficiently run their operations, reduce response times and increase officer availability, we have focused on providing cloud-based software-as-a service (“SaaS”) with ancillary implementation and managed services in addition to on-premises solutions. Our CommandCentral suite, hosted in Microsoft Azure Government, includes call handling, CAD, field reporting, records, evidence, investigations and jail in an integrated cloud-based offering. We believe that cloud deployment delivers agencies key benefits, including faster deployment, increased security, rapid scaling in the event of an emergency and a secure investment that keeps pace as technology advances. In addition to this native cloud suite, we offer a hybrid solution that delivers a migration path from on-premises software solutions to cloud-connected capabilities.

[0000068505-22-000010:mdna:37]
Another area of public safety evolution is increasing adoption of Next Generation 911 Core Services (“NGCS”), a group of products and services needed to create infrastructure connectivity in order to process a 911 call using Next Generation (“NG”) technology. The NG infrastructure is an Emergency Service IP Network ("ESInet"), which can carry voice, data and multimedia. ESInet enables 911 call takers at public safety answering points to respond to text, video and data. Our NGCS can be offered as a managed service and includes call routing, ESInet, location services, Geographic Information Services, cybersecurity and our continuous network and security operations center dedicated to public safety. We believe that our solution is differentiated through its integration with our CommandCentral software suite to simplify the agency’s workflow and ensure better incident management and real-time intelligence.

[0000068505-22-000010:mdna:38]
Additional Command Center Software includes interoperability software that ensures communication is not limited by coverage area, network technology or device type. Our solutions, including Kodiak, WAVE PTX and CriticalConnect, enable interoperability among devices across multiple networks. For example, a two-way radio network can connect with an LTE network making it possible for individuals to communicate securely and more easily across technologies.

[0000068505-22-000010:mdna:39]
The Command Center Software technology within the Software and Services segment represented 17% of the net sales of the total segment in 2021.

[0000068505-22-000010:mdna:40]
2021 Financial Results

[0000068505-22-000010:mdna:41]
•Net sales were $8.2 billion in 2021 compared to $7.4 billion in 2020.

[0000068505-22-000010:mdna:42]
•Operating earnings were $1.7 billion in 2021 compared to $1.4 billion in 2020.

[0000068505-22-000010:mdna:43]
•Net earnings attributable to Motorola Solutions, Inc. were $1.2 billion, or $7.17 per diluted common share in 2021, compared to earnings of $949 million, or $5.45 per diluted common share in 2020.

[0000068505-22-000010:mdna:44]
•Our operating cash flow was $1.8 billion in 2021 compared to $1.6 billion in 2020.

[0000068505-22-000010:mdna:45]
•We returned over $1.0 billion of capital to shareholders, in the form of $528 million in share repurchases and $482 million in dividends in 2021.

[0000068505-22-000010:mdna:46]
•We increased our quarterly dividend by 11% to $0.79 per share in November 2021.

[0000068505-22-000010:mdna:47]
•We ended 2021 with a backlog position of $13.6 billion, up $2.2 billion compared to 2020.

[0000068505-22-000010:mdna:48]
Segment Financial Highlights

[0000068505-22-000010:mdna:49]
•In the Products and Systems Integration segment, net sales were $5.0 billion in 2021, an increase of $399 million, or 9%, compared to $4.6 billion in 2020. On a geographic basis, net sales increased in both the North America region and the International regions. Operating earnings were $760 million in 2021, compared to $656 million in 2020. Operating margins increased in 2021 to 15.1% from 14.2% in 2020 primarily due to increased sales volume, partially offset by higher operating expenses driven by a $50 million gain on the sale of property, plant and equipment in 2020 that did not recur in 2021, higher employee incentive costs and higher expenses associated with acquired businesses. The overall increase in operating expenses was partially offset by $43 million lower reorganization of business charges and $16 million lower Hytera-related legal expenses.

[0000068505-22-000010:mdna:50]
•In the Software and Services segment, net sales were $3.1 billion in 2021, an increase of $358 million, or 13%, compared to $2.8 billion in 2020. On a geographic basis, net sales increased in both the North America and International regions. Operating earnings were $907 million in 2021, compared to $727 million in 2020. Operating margin increased in 2021 to 28.9% from 26.2% in 2020 due to higher sales and gross margin contribution, partially offset by higher operating expenses driven by expenses associated with acquired businesses, higher employee incentive costs and higher intangible assets amortization expense. The overall increase in operating expenses was partially offset by $11 million lower reorganization of business expenses and $7 million lower share-based compensation expenses.

[0000068505-22-000010:mdna:51]
COVID-19

[0000068505-22-000010:mdna:52]
In response to the COVID-19 pandemic, there have been a broad number of governmental and commercial actions taken to limit the spread of the virus, including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns. The COVID-19 pandemic continues to be dynamic, and near-term challenges across the economy remain. Although vaccines are now being distributed and administered across many parts of the world, new variants of the virus have emerged and may continue to emerge that have continued to create uncertainty regarding the impact of COVID-19. In particular, the recent acceleration of the "omicron variant" of the virus and the highly contagious “delta variant” of the virus have caused recent surges of COVID-19 cases in the U.S. and other countries around the world. We continue to adhere to applicable governmental and commercial restrictions and to work to mitigate the impact of COVID-19 on our employees, customers, communities, liquidity and financial position.

[0000068505-22-000010:mdna:53]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including encouraging office workers to work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings, and using thermal scanning. We have allowed essential business travel; however, we continue to carefully assess conditions on a geographical basis to determine when employees can safely return to our offices. We also facilitated the process for our employees in certain locations to receive the COVID-19 vaccine, as vaccines are distributed and administered throughout the U.S. and the global community.

[0000068505-22-000010:mdna:54]
As conditions continue to fluctuate around the world, with both vaccine administration and the rates of new variants of COVID-19 (particularly the omicron and delta variants) rising in certain regions, governments and organizations have responded by adjusting their restrictions and guidelines accordingly. The health and safety of our employees remains our top priority, and we continue to monitor the daily evolution of the pandemic, including the spread of the omicron and delta variants. As of the date of this filing, we are following the U.S. Centers for Disease Control and Prevention guidance and state and local restrictions with respect to our U.S. employees, as well as guidance from corresponding international authorities with respect to our non-U.S. employees.

[0000068505-22-000010:mdna:55]
Additionally, in September 2021, the President of the United States signed a series of executive orders, and related guidance was issued that, together, required certain employers to implement COVID-19 precautions, including mandatory COVID-19 vaccines for employees (subject to medical and religious exemptions). As a federal contractor, we were required to implement a mandatory vaccine policy. In January 2022, in response to various legal challenges to these orders, we suspended our requirement that our U.S. employees (subject to the exemptions described above) be vaccinated by February 9, 2022. We continue to evaluate our internal policy and the potential impact of the executive orders and legal responses to such executive orders on our business.

[0000068505-22-000010:mdna:56]
As we progressed through 2021, our supply chain has been increasingly impacted by global issues related to the effects of the COVID-19 pandemic, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in our supply chain, as well as difficulties and delays in procuring certain semiconductor components. During the latter part of the fourth quarter of 2021, costs increased driven by delivery delays and the need to purchase semiconductor components from alternative sources, including brokers. We anticipate increased costs to procure materials within the semiconductor market to continue into the first half of 2022.  We are closely monitoring our supply chain and have maintained an active dialogue, and in some cases developed plans, with key suppliers in an effort to mitigate supply chain risks or otherwise minimize the impact from those risks. We will continue to actively manage our supply chain in an effort to prevent major delays in selling our products and services.

[0000068505-22-000010:mdna:57]
Although the COVID-19 pandemic continued to introduce challenges throughout 2021, we are encouraged by customer demand for our products and services. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impacts on net sales and operating margin will be limited throughout 2022. Within the Products and Systems Integration segment, while we are encouraged by strong LMR backlog and the resiliency of the Video Security and Access Control technology that experienced growth in 2021, supply constraints continue to impact our LMR business and we expect demand for our products will continue to out-pace our ability to obtain

[0000068505-22-000010:mdna:58]
32

[0000068505-22-000010:mdna:59]
supply throughout 2022. In addition, in March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We experienced the positive impact of the ARPA funding on our business and results of operations during 2021 and anticipate that the ARPA will continue to have a positive impact throughout 2022.

[0000068505-22-000010:mdna:60]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of December 31, 2021. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost-reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-22-000010:mdna:61]
Lastly, we evaluated whether there were any impairment indicators as of December 31, 2021, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the fourth quarter of 2021, we concluded our assets were fairly stated and recoverable.

[0000068505-22-000010:mdna:62]
Recent Acquisitions

[0000068505-22-000010:mdna:63]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Command Center Software | Software and Services | 911 Datamaster | Provider of Next Generation 911 data solutions that helps to ensure emergency calls are accurately located and routed based on the caller's location. | $35 million and share-based compensation of $3 million | December 16, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Envysion | Provider of enterprise video security and business analytics. | $124 million and share-based compensation of $1 million | October 29, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Openpath | Provider of cloud-based mobile access control. | $298 million and share-based compensation of $29 million | July 15, 2021 |
| Command Center Software | Software and Services | Callyo | Provider of cloud-based mobile applications for law enforcement in North America, including critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. | $63 million, inclusive of share-based compensation of $3 million | August 28, 2020 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Pelco, Inc. | Global provider of video security solutions, adding a broad range of products for a variety of commercial and industrial environments and use cases. | $110 million | July 31, 2020 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | IndigoVision Group plc | Provider of video security solutions to enhance geographical reach across a wider customer base. | $37 million | June 16, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, and managed services, including security monitoring of network operations. | $32 million | April 30, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, managed services, and remediation and response capabilities. | $40 million, inclusive of share-based compensation of $6 million | March 3, 2020 |

[0000068505-22-000010:mdna:64]
33

[0000068505-22-000010:mdna:65]
| Video Security and Access Control | Software and Services | Unnamed data solutions business for vehicle location information | Provider of additional data to our existing license plate recognition database. | $85 million | October 16, 2019 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | WatchGuard, Inc. | Provider of in-car and body-worn video solutions. | $271 million, inclusive of share-based compensation of $16 million | July 11, 2019 |
| LMR | Products and Systems IntegrationSoftware and Services | Avtec, Inc. | Provider of dispatch communications for U.S. public safety and commercial customers to communicate, coordinate resources, and secure their facilities. | $136 million | March 11, 2019 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | VaaS International Holdings | Global provider of data and image analytics for vehicle location. | $445 million, inclusive of share-based compensation of $38 million | January 7, 2019 |

[0000068505-22-000010:mdna:66]
Climate Change

[0000068505-22-000010:mdna:67]
We expect that our operations and supply chain will become increasingly subject to federal, state, local and foreign laws, regulations and international treaties and industry standards relating to climate change. For example, in October 2021 the U.K.’s Cabinet Office began requiring companies bidding on contracts with the U.K. government that have a value of over £5m per year to have carbon reduction plans that contain a commitment to achieving net zero emissions by 2050 for U.K. operations. This requirement applies to our operations in the U.K. Although Motorola Solutions  UK Ltd. and Airwave Solutions Ltd., our U.K. subsidiaries, each committed to achieving net zero emissions by 2050 for such entities' U.K. operations, this requirement and any similar future requirements and other increased regulation of climate change concerns could subject us to additional costs and restrictions, impact our competitive position or require us to make certain changes to our manufacturing practices and/or product designs.

[0000068505-22-000010:mdna:68]
Looking Forward

[0000068505-22-000010:mdna:69]
We expect continued growth within our global LMR installed base as a number of events such as natural disasters and large-scale incidents continue to reinforce the importance of having secure, reliable LMR for public safety. We believe our augmentation of LMR with broadband solutions will also drive growth, as we expect our customers will look to integrate valuable data capabilities. We expect to provide additional services to existing LMR customers as communication networks become more complex, software-centric and data-driven.

[0000068505-22-000010:mdna:70]
As public safety needs continue to evolve, we anticipate growth opportunities within the command center as our Command Center Software suite covers the mission-critical workflow, from 911 intake to case closure and management. We expect increased growth in our integrated software next generation core services and our cloud-based solutions, such as the PremierOne Cloud suite, as well as hybrid cloud solutions that provide a migration path from on-premises software solutions to cloud-connected capabilities.

[0000068505-22-000010:mdna:71]
Within Video Security and Access Control, we expect growth across our portfolio of fixed and mobile security solutions embedded with advanced analytics and access control solutions. We believe drivers include expansion of traditional video sales beyond commercial customers to government and public safety customers. Additionally, we expect customers to continue to embrace analytics that convert video into data and the scalability of the cloud to run their operations, and we also expect continued expansion of offerings such as video-as-a-service and Avigilon Cloud Services.

[0000068505-22-000010:mdna:72]
Finally, we anticipate new opportunities from the investments we are making to integrate our LMR, Video Security and Access Control and Command Center Software technologies into one unified ecosystem. We have made go-to-market and research and development investments in both Video Security and Access Control and our Command Center Software technologies with growth in mind. We have made a number of acquisitions and we see opportunities to continue to rationalize costs within both segments of our business, further driving operating leverage in our businesses. We believe our integrated ecosystem for public and enterprise safety can enable strong collaboration by removing system silos, simplifying management and automating workflows.

[0000068505-22-000010:mdna:73]
We expect our growth within LMR may be limited by supply in 2022. Refer to “COVID-19” set forth in this “Part II. Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” of this Form 10-K for a further discussion of our outlook with respect to the continuing impact of COVID-19 on our financial condition, results of operations and cash flows.

[0000068505-22-000010:mdna:74]
34

[0000068505-22-000010:mdna:75]
Results of Operations

[0000068505-22-000010:mdna:76]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2021 |  | % ofSales ** |  | 2020 |  | % ofSales ** |  | 2019 |  | % ofSales ** |
| Net sales from products | $ | 4,606 |  |  |  |  | $ | 4,087 |  |  |  |  | $ | 4,746 |  |  |  |
| Net sales from services | 3,565 |  |  |  |  | 3,327 |  |  |  |  | 3,141 |  |  |  |
| Net sales | 8,171 |  |  |  |  | 7,414 |  |  |  |  | 7,887 |  |  |  |
| Costs of product sales | 2,104 |  |  | 45.7 | % |  | 1,872 |  |  | 45.8 | % |  | 2,049 |  |  | 43.2 | % |
| Costs of services sales | 2,027 |  |  | 56.9 | % |  | 1,934 |  |  | 58.1 | % |  | 1,907 |  |  | 60.7 | % |
| Costs of sales | 4,131 |  |  | 50.6 | % |  | 3,806 |  |  | 51.3 | % |  | 3,956 |  |  | 50.2 | % |
| Gross margin | 4,040 |  |  | 49.4 | % |  | 3,608 |  |  | 48.7 | % |  | 3,931 |  |  | 49.8 | % |
| Selling, general and administrative expenses | 1,353 |  |  | 16.6 | % |  | 1,293 |  |  | 17.4 | % |  | 1,403 |  |  | 17.8 | % |
| Research and development expenditures | 734 |  |  | 9.0 | % |  | 686 |  |  | 9.3 | % |  | 687 |  |  | 8.7 | % |
| Other charges | 286 |  |  | 3.5 | % |  | 246 |  |  | 3.3 | % |  | 260 |  |  | 3.3 | % |
| Operating earnings | 1,667 |  |  | 20.4 | % |  | 1,383 |  |  | 18.7 | % |  | 1,581 |  |  | 20.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (208) |  |  | (2.5) | % |  | (220) |  |  | (3.0) | % |  | (220) |  |  | (2.8) | % |
| Gains (losses) on sales of investments and businesses, net | 1 |  |  | — | % |  | (2) |  |  | — | % |  | 5 |  |  | 0.1 | % |
| Other | 92 |  |  | 1.1 | % |  | 13 |  |  | 0.2 | % |  | (365) |  |  | (4.6) | % |
| Total other expense | (115) |  |  | (1.4) | % |  | (209) |  |  | (2.8) | % |  | (580) |  |  | (7.4) | % |
| Net earnings before income taxes | 1,552 |  |  | 19.0 | % |  | 1,174 |  |  | 15.8 | % |  | 1,001 |  |  | 12.7 | % |
| Income tax expense | 302 |  |  | 3.7 | % |  | 221 |  |  | 3.0 | % |  | 130 |  |  | 1.6 | % |
| Net earnings | 1,250 |  |  | 15.3 | % |  | 953 |  |  | 12.9 | % |  | 871 |  |  | 11.0 | % |
| Less: Earnings attributable to noncontrolling interests | 5 |  |  | 0.1 | % |  | 4 |  |  | 0.1 | % |  | 3 |  |  | — | % |
| Net earnings* | $ | 1,245 |  |  | 15.2 | % |  | $ | 949 |  |  | 12.8 | % |  | $ | 868 |  |  | 11.0 | % |
| Earnings per diluted common share* | $ | 7.17 |  |  |  |  | $ | 5.45 |  |  |  |  | $ | 4.95 |  |  |  |

[0000068505-22-000010:mdna:77]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-22-000010:mdna:78]
**    Percentages may not add due to rounding.

[0000068505-22-000010:mdna:79]
Geographic Market Sales by Locale of End Customer

[0000068505-22-000010:mdna:80]
|  | 2021 |  | 2020 |  | 2019 |
| North America | 68 | % |  | 68 | % |  | 67 | % |
| International | 32 | % |  | 32 | % |  | 33 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-22-000010:mdna:81]
35

[0000068505-22-000010:mdna:82]
Results of Operations—2021 Compared to 2020

[0000068505-22-000010:mdna:83]
Net Sales

[0000068505-22-000010:mdna:84]
|  | Years ended December 31 |
| (In millions) | 2021 |  | 2020 |  | % Change |
| Net sales from Products and Systems Integration | $ | 5,033 |  |  | $ | 4,634 |  |  | 9 | % |
| Net sales from Software and Services | 3,138 |  |  | 2,780 |  |  | 13 | % |
| Net sales | $ | 8,171 |  |  | $ | 7,414 |  |  | 10 | % |

[0000068505-22-000010:mdna:85]
The Products and Systems Integration segment’s net sales represented 62% of our net sales in 2021, compared to 63% in 2020. The Software and Services segment’s net sales represented 38% of our net sales in 2021, compared to 37% in 2020.

[0000068505-22-000010:mdna:86]
Net sales increased by $757 million, or 10%, compared to 2020. The 9% increase in net sales within the Products and Systems Integration segment was driven by a 9% increase in the North America region and an 8% increase in the International region. The 13% increase in the Software and Services segment was driven by a 14% increase in the North America region and a 11% increase in the International region. The increase in net sales included:

[0000068505-22-000010:mdna:87]
•an increase in the Products and Systems Integration segment, inclusive of $89 million of revenue from acquisitions, driven by growth in LMR, inclusive of public safety LMR products and PCR, and Video Security and Access Control;

[0000068505-22-000010:mdna:88]
•growth in the Software and Services segment, inclusive of $31 million of revenue from acquisitions, driven by an increase in LMR services, Video Security and Access Control and Command Center Software; and

[0000068505-22-000010:mdna:89]
•$130 million from favorable currency rates.

[0000068505-22-000010:mdna:90]
Regional results included:

[0000068505-22-000010:mdna:91]
•an 11% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in LMR, Video Security and Access Control and Command Center Software; and

[0000068505-22-000010:mdna:92]
•a 9% increase in the International region, inclusive of revenue from acquisitions, driven by growth in LMR, Video Security and Access Control and Command Center Software.

[0000068505-22-000010:mdna:93]
Products and Systems Integration

[0000068505-22-000010:mdna:94]
The 9% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000010:mdna:95]
•$211 million, or 5% growth in public safety LMR products and PCR, driven by both the North America and International regions;

[0000068505-22-000010:mdna:96]
•$188 million, or 29% growth in Video Security and Access Control, inclusive of revenue from acquisitions, in both the North America and International regions; and

[0000068505-22-000010:mdna:97]
•$60 million from favorable currency rates.

[0000068505-22-000010:mdna:98]
Software and Services

[0000068505-22-000010:mdna:99]
The 13% increase in the Software and Services segment was driven by the following:

[0000068505-22-000010:mdna:100]
•$197 million, or 10% growth in LMR services, driven by both the North America and International regions;

[0000068505-22-000010:mdna:101]
•$112 million, or 39% growth in Video Security and Access Control software, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-22-000010:mdna:102]
•$49 million, or 10% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-22-000010:mdna:103]
•$70 million from favorable currency rates.

[0000068505-22-000010:mdna:104]
Gross Margin

[0000068505-22-000010:mdna:105]
|  | Years ended December 31 |
| (In millions) | 2021 |  | 2020 |  | % Change |
| Gross margin | $ | 4,040 |  |  | $ | 3,608 |  |  | 12 | % |

[0000068505-22-000010:mdna:106]
Gross margin was 49.4% of net sales in 2021 compared to 48.7% of net sales in 2020. The $432 million increase was driven by:

[0000068505-22-000010:mdna:107]
•higher gross margins within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth and improved mix of service offerings, partially offset by higher employee incentive costs; and

[0000068505-22-000010:mdna:108]
•consistent gross margin contribution in the Products and Systems Integration segment as a result of favorable product mix and reduced reorganization of business charges, offset by an increase in employee incentive costs.

[0000068505-22-000010:mdna:109]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-22-000010:mdna:110]
|  | Years ended December 31 |
| (In millions) | 2021 |  | 2020 |  | % Change |
| Selling, general and administrative expenses | $ | 1,353 |  |  | $ | 1,293 |  |  | 5 | % |

[0000068505-22-000010:mdna:111]
SG&A expenses increased $60 million, or 5% in 2021 compared to 2020. SG&A expenses were 16.6% of net sales in 2021 compared to 17.4% of net sales in 2020. The increase in SG&A expenses was primarily due to higher employee incentive costs, expenses associated with acquired businesses, higher travel expenses and increased share-based compensation expenses. The overall increase in SG&A expenses was partially offset by lower Hytera-related legal expenses.

[0000068505-22-000010:mdna:112]
Research and Development ("R&D") Expenditures

[0000068505-22-000010:mdna:113]
|  | Years ended December 31 |
| (In millions) | 2021 |  | 2020 |  | % Change |
| Research and development expenditures | $ | 734 |  |  | $ | 686 |  |  | 7 | % |

[0000068505-22-000010:mdna:114]
R&D expenditures increased $48 million, or 7% in 2021 compared to 2020 primarily due to higher employee incentive costs and higher expenses associated with acquired businesses, partially offset by lower share-based compensation expenses. R&D expenditures were 9.0% of net sales in 2021 and 9.3% of net sales in 2020.

[0000068505-22-000010:mdna:115]
Other Charges

[0000068505-22-000010:mdna:116]
|  | Years ended December 31 |  |  |
| (In millions) | 2021 |  | 2020 |  |  |
| Other charges | $ | 286 |  |  | $ | 246 |  |  |  |

[0000068505-22-000010:mdna:117]
Other charges increased $40 million, or 16% in 2021 compared to 2020 primarily due to the following:

[0000068505-22-000010:mdna:118]
•$50 million gain on the sale of property, plant and equipment in 2020 that did not recur in 2021;

[0000068505-22-000010:mdna:119]
•$236 million of intangible asset amortization expense in 2021 compared to $215 million in 2020;

[0000068505-22-000010:mdna:120]
•$10 million of operating lease asset impairments in 2021 that did not occur in 2020; and

[0000068505-22-000010:mdna:121]
•$15 million of charges for acquisition-related transaction fees in 2021 as compared to $9 million in 2020; partially offset by

[0000068505-22-000010:mdna:122]
•$24 million of net reorganization of business charges in 2021 compared to $57 million in 2020 (see "Note 14: Reorganization of Businesses" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-22-000010:mdna:123]
•$3 million of legal settlements in 2021 compared to $9 million in 2020; and

[0000068505-22-000010:mdna:124]
•$5 million of fixed asset impairments in 2020 that did not recur in 2021.

[0000068505-22-000010:mdna:125]
Operating Earnings

[0000068505-22-000010:mdna:126]
|  | Years ended December 31 |  |  |
| (In millions) | 2021 |  | 2020 |  |  |
| Operating earnings from Products and Systems Integration | $ | 760 |  |  | $ | 656 |  |  |  |
| Operating earnings from Software and Services | 907 |  |  | 727 |  |  |  |
| Operating earnings | $ | 1,667 |  |  | $ | 1,383 |  |  |  |

[0000068505-22-000010:mdna:127]
Operating earnings increased $284 million, or 21% in 2021 compared to 2020. The increase in Operating earnings was due to:

[0000068505-22-000010:mdna:128]
•Software and Services segment increased $180 million from 2020 to 2021 driven by higher sales and gross margin contribution and an improved mix of service offerings, offset by higher operating expenses.  The increase in operating expenses was driven by higher expenses associated with acquired businesses, higher employee incentive costs and higher intangible assets amortization expense, partially offset by $11 million lower reorganization of business expenses and $7 million lower share-based compensation expenses; and

[0000068505-22-000010:mdna:129]
•Products and Systems Integration increased $104 million from 2020 to 2021 primarily driven by increased sales volume, partially offset by higher operating expenses.  The increase in operating expenses was driven by a $50 million gain on the sale of property, plant and equipment in 2020 that did not recur in 2021, higher employee incentive costs and higher expenses associated with acquired businesses, partially offset by: $43 million lower reorganization of business charges and $16 million lower Hytera-related legal expenses.

[0000068505-22-000010:mdna:130]
Interest Expense, net

[0000068505-22-000010:mdna:131]
|  | Years ended December 31 |  |  |
| (In millions) | 2021 |  | 2020 |  |  |
| Interest expense, net | $ | (208) |  |  | $ | (220) |  |  |  |

[0000068505-22-000010:mdna:132]
The $12 million decrease in net interest expense in 2021 compared to 2020 was a result of the reversal of an $11 million non-cash interest accrual related to an international tax audit and lower interest rates on debt outstanding.

[0000068505-22-000010:mdna:133]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-22-000010:mdna:134]
|  | Years ended December 31 |  |
| (In millions) | 2021 |  | 2020 |  |
| Gains (losses) on sales of investments and businesses, net | $ | 1 |  |  | $ | (2) |  |  |

[0000068505-22-000010:mdna:135]
The net gains (losses) on sales of investments and businesses were primarily related to the sales of various equity investments.

[0000068505-22-000010:mdna:136]
Other, net

[0000068505-22-000010:mdna:137]
|  | Years ended December 31 |
| (In millions) | 2021 |  | 2020 |
| Other, net | $ | 92 |  |  | $ | 13 |  |

[0000068505-22-000010:mdna:138]
Net Other income increased $79 million in 2021 compared to 2020 primarily due to:

[0000068505-22-000010:mdna:139]
•$17 million of foreign currency gains in 2021 compared to $44 million of foreign currency losses in 2020;

[0000068505-22-000010:mdna:140]
•$123 million of net periodic pension and postretirement benefits in 2021 compared to $81 million of net periodic pension and postretirement benefits in 2020;

[0000068505-22-000010:mdna:141]
•an $18 million loss on the extinguishment of long term debt in 2021 compared to a $56 million loss on the extinguishment of long-term debt in 2020 (see "Note 5: Debt and Credit Facilities" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information); and

[0000068505-22-000010:mdna:142]
•$4 million of investment impairments in 2020 that did not occur in 2021; partially offset by

[0000068505-22-000010:mdna:143]
•$30 million loss on derivatives in 2021 compared to a $25 million gain on derivatives in 2020; and

[0000068505-22-000010:mdna:144]
•an $8 million loss on fair value adjustments to equity investments in 2021 compared to a $6 million gain on fair value adjustments to equity investments in 2020.

[0000068505-22-000010:mdna:145]
Effective Tax Rate

[0000068505-22-000010:mdna:146]
|  | Years ended December 31 |  |
| (In millions) | 2021 |  | 2020 |  |
| Income tax expense | $ | 302 |  |  | $ | 221 |  |  |

[0000068505-22-000010:mdna:147]
Income tax expense increased by $81 million in 2021 compared to 2020, for an effective tax rate of 19.5%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-22-000010:mdna:148]
•a $34 million benefit due to a change in the Company's ability to utilize tax attribute carryforwards resulting in the partial release of valuation allowances (see "Note 7:  Income Taxes" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information); and

[0000068505-22-000010:mdna:149]
•$32 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-22-000010:mdna:150]
Our effective tax rate in 2020 was 18.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-22-000010:mdna:151]
•$48 million of benefits due to the recognition of excess tax benefits on share-based compensation; and

[0000068505-22-000010:mdna:152]
•$28 million of benefits due to the recognition of increased prior and current R&D tax credits.

[0000068505-22-000010:mdna:153]
Results of Operations—2020 Compared to 2019

[0000068505-22-000010:mdna:154]
Net Sales

[0000068505-22-000010:mdna:155]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 4,634 |  |  | $ | 5,329 |  |  | (13) | % |
| Net sales from Software and Services | 2,780 |  |  | 2,558 |  |  | 9 | % |
| Net sales | $ | 7,414 |  |  | $ | 7,887 |  |  | (6) | % |

[0000068505-22-000010:mdna:156]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in 2020, compared to 68% in 2019. The Software and Services segment’s net sales represented 37% of our net sales in 2020, compared to 32% in 2019.

[0000068505-22-000010:mdna:157]
Net sales decreased by $473 million, or 6% in 2020 compared to 2019. The 13% decline in net sales within the Products and Systems Integration segment was driven by an 11% decline in the North America region and an 18% decline in the International region. The 9% increase in the Software and Services segment was driven by a 12% increase in the North America region and a 4% increase in the International region. The decrease in net sales included:

[0000068505-22-000010:mdna:158]
•a decline in the Products and Systems Integration segment, inclusive of $119 million of revenue from acquisitions, driven by a decline in public safety LMR and PCR, partially offset by growth in Video Security;

[0000068505-22-000010:mdna:159]
•growth in the Software and Services segment, inclusive of $84 million of revenue from acquisitions, driven by an increase in Video Security and Access Control, Command Center Software, and LMR services due to strong demand in the North America region; and

[0000068505-22-000010:mdna:160]
•$12 million from unfavorable currency rates.

[0000068505-22-000010:mdna:161]
Regional results include:

[0000068505-22-000010:mdna:162]
•a 5% decline in the North America region, inclusive of revenue from acquisitions, driven by declines in public safety LMR and PCR, partially offset by growth in Video Security and Access Control, LMR services, and Command Center Software; and

[0000068505-22-000010:mdna:163]
•a 9% decline in the International region, inclusive of revenue from acquisitions, driven by declines in public safety LMR and PCR, partially offset by growth in Video Security and Access Control, Command Center Software, and LMR public safety services.

[0000068505-22-000010:mdna:164]
Products and Systems Integration

[0000068505-22-000010:mdna:165]
The 13% decrease in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000010:mdna:166]
•$838 million, or 17% decline in public safety LMR and PCR, inclusive of revenue from acquisitions, in both the International and North America regions, primarily driven by a delay in customer engagement due to the COVID-19 pandemic; partially offset by

[0000068505-22-000010:mdna:167]
•$143 million, or 29% growth in Video Security and Access Control, inclusive of revenue from acquisitions, in both the International and North America regions; and

[0000068505-22-000010:mdna:168]
•$3 million from favorable currency rates.

[0000068505-22-000010:mdna:169]
Software and Services

[0000068505-22-000010:mdna:170]
The 9% increase in the Software and Services segment was driven by the following:

[0000068505-22-000010:mdna:171]
•$117 million, or 6% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-22-000010:mdna:172]
•$75 million, or 36% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-22-000010:mdna:173]
•$30 million, or 7% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; partially offset by

[0000068505-22-000010:mdna:174]
•$15 million from unfavorable currency rates.

[0000068505-22-000010:mdna:175]
Gross Margin

[0000068505-22-000010:mdna:176]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Gross margin | $ | 3,608 |  |  | $ | 3,931 |  |  | (8) | % |

[0000068505-22-000010:mdna:177]
Gross margin was 48.7% of net sales in 2020 and 49.8% of net sales in 2019. The $323 million decrease was driven by:

[0000068505-22-000010:mdna:178]
•lower gross margin contribution in the Products and Systems Integration segment as a result of the decline in public safety LMR and PCR sales, as well as lower margins on projects driven by a delay in engagements from COVID-19, partially offset by lower incentive costs; partially offset by

[0000068505-22-000010:mdna:179]
•higher gross margins within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth, driven by improved mix of service offerings and lower travel and incentive costs.

[0000068505-22-000010:mdna:180]
Selling, General and Administrative Expenses

[0000068505-22-000010:mdna:181]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 1,293 |  |  | $ | 1,403 |  |  | (8) | % |

[0000068505-22-000010:mdna:182]
SG&A expenses decreased $110 million, or 8% in 2020 compared to 2019. SG&A expenses were 17.4% of net sales in 2020 compared to 17.8% of net sales in 2019. The decrease in SG&A expenses was primarily due to reduced employee incentive costs, travel expenses, and indirect expenses. The overall reduction in SG&A expenses was partially offset by expenses associated with acquired businesses.

[0000068505-22-000010:mdna:183]
Research and Development Expenditures

[0000068505-22-000010:mdna:184]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Research and development expenditures | $ | 686 |  |  | $ | 687 |  |  | — | % |

[0000068505-22-000010:mdna:185]
R&D expenditures remained consistent in 2020 compared to 2019. R&D expenditures were 9.3% of net sales in 2020 and 8.7% of net sales in 2019.

[0000068505-22-000010:mdna:186]
Other Charges

[0000068505-22-000010:mdna:187]
|  | Years ended December 31 |  |
| (In millions) | 2020 |  | 2019 |  |
| Other charges | $ | 246 |  |  | $ | 260 |  |  |

[0000068505-22-000010:mdna:188]
Other charges decreased by $14 million in 2020 compared to 2019 primarily due to the following:

[0000068505-22-000010:mdna:189]
•$50 million gain on sale of a manufacturing facility in Europe in 2020; partially offset by

[0000068505-22-000010:mdna:190]
•$57 million of net reorganization of business charges in 2020 as compared to $40 million in 2019 (see "Note 14: Reorganization of Businesses" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-22-000010:mdna:191]
•$215 million of amortization of intangibles in 2020 compared to $208 million in 2019;

[0000068505-22-000010:mdna:192]
•$9 million of legal settlements in 2020 compared to $3 million in 2019;

[0000068505-22-000010:mdna:193]
•$9 million of charges for acquisition-related transaction fees in 2020 as compared to $3 million in 2019; and

[0000068505-22-000010:mdna:194]
•$5 million of fixed asset impairments.

[0000068505-22-000010:mdna:195]
Operating Earnings

[0000068505-22-000010:mdna:196]
|  | Years ended December 31 |  |  |
| (In millions) | 2020 |  | 2019 |  |  |
| Operating earnings from Products and Systems Integration | $ | 656 |  |  | $ | 994 |  |  |  |
| Operating earnings from Software and Services | 727 |  |  | 587 |  |  |  |
| Operating earnings | $ | 1,383 |  |  | $ | 1,581 |  |  |  |

[0000068505-22-000010:mdna:197]
Operating earnings decreased $198 million, or 13% in 2020 compared to 2019. The decrease in Operating earnings was due to:

[0000068505-22-000010:mdna:198]
•Products and Systems Integration decreased by $338 million from 2020 to 2019 driven by lower sales and gross margin contribution, partially offset by lower operating expenses driven by lower employee incentive costs, indirect expenses, and travel expenses. The overall reduction in operating expenses was offset by: $23 million higher reorganization of business expenses, $11 million higher share-based compensation expenses and higher operating expenses from acquisitions.

[0000068505-22-000010:mdna:199]
•Software and Services segment increased by $140 million from 2020 to 2019 driven by higher sales and gross margin contribution, along with reduced operating expenses due to operating leverage, inclusive of lower employee incentive costs and travel expenses. The overall reduction in operating expenses was partially offset by: $6 million higher reorganization of business expenses, $5 million higher intangible amortization driven by acquisitions and higher operating expenses from acquisitions.

[0000068505-22-000010:mdna:200]
Interest Expense, net

[0000068505-22-000010:mdna:201]
|  | Years ended December 31 |  |  |
| (In millions) | 2020 |  | 2019 |  |  |
| Interest expense, net | $ | (220) |  |  | $ | (220) |  |  |  |

[0000068505-22-000010:mdna:202]
Interest expense, net in 2020 compared to 2019 remained relatively consistent due to a one-time receipt of interest income related to a tax refund and lower interest rates on debt outstanding, offset by lower interest income earned on cash due to lower interest rates.

[0000068505-22-000010:mdna:203]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-22-000010:mdna:204]
|  | Years ended December 31 |  |
| (In millions) | 2020 |  | 2019 |  |
| Gains on sales of investments and businesses, net | $ | (2) |  |  | $ | 5 |  |  |

[0000068505-22-000010:mdna:205]
The net gains (losses) in 2020 and 2019 were primarily related to the sales of various equity investments.

[0000068505-22-000010:mdna:206]
Other, net

[0000068505-22-000010:mdna:207]
|  | Years ended December 31 |  |
| (In millions) | 2020 |  | 2019 |  |
| Other, net | $ | 13 |  |  | $ | (365) |  |  |

[0000068505-22-000010:mdna:208]
Net Other income (Loss) increased $378 million in 2020 compared to 2019 primarily due to:

[0000068505-22-000010:mdna:209]
•$359 million U.S pension settlement loss in 2019 (see "Note 8: Retirement Benefits" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-22-000010:mdna:210]
•$25 million gain on derivatives in 2020 compared to an $8 million loss on derivatives in 2019;

[0000068505-22-000010:mdna:211]
•$4 million of investment impairments in 2020 compared to $18 million in 2019; partially offset by

[0000068505-22-000010:mdna:212]
•$44 million of foreign currency losses in 2020 compared to $22 million in 2019; and

[0000068505-22-000010:mdna:213]
•$56 million of net losses from repurchases of long term debt in 2020 as compared to a loss of $46 million in 2019 (see "Note 5: Debt and Credit Facilities" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-22-000010:mdna:214]
Effective Tax Rate

[0000068505-22-000010:mdna:215]
|  | Years ended December 31 |  |  |
| (In millions) | 2020 |  | 2019 |  |  |
| Income tax expense | $ | 221 |  |  | $ | 130 |  |  |  |

[0000068505-22-000010:mdna:216]
Income tax expense increased by $91 million in 2020 compared to 2019, for an effective tax rate of 18.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-22-000010:mdna:217]
•$48 million of benefits due to the recognition of excess tax benefits on share-based compensation; and

[0000068505-22-000010:mdna:218]
•$28 million of benefits due to the recognition of increased prior and current R&D tax credits.

[0000068505-22-000010:mdna:219]
Our effective tax rate in 2019 was 13.0%, which is lower than the current U.S. federal statutory rate of 21% primarily related to:

[0000068505-22-000010:mdna:220]
•a $77 million benefit due to the partial release of a valuation allowance to our U.S. foreign tax credit carryforward (see "Note 7: Income Taxes" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information); and

[0000068505-22-000010:mdna:221]
•$27 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-22-000010:mdna:222]
Reorganization of Businesses

[0000068505-22-000010:mdna:223]
In 2021, we recorded net reorganization of business charges of $32 million relating to the separation of 600 employees, of which 200 were indirect employees and 400 were direct employees. The $32 million of charges included $8 million recorded to Cost of sales and $24 million recorded to Other charges. Included in the aggregate $32 million are charges of $42 million for employee separation costs partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-22-000010:mdna:224]
During 2020, we recorded net reorganization of business charges of $86 million relating to the separation of 1,200 employees, of which 400 were indirect employees and 800 were direct employees. The $86 million of charges included $29 million recorded to Cost of sales and $57 million recorded to Other charges. Included in the aggregate $86 million were charges of $100 million for employee separation costs and $2 million for exit costs, partially offset by $16 million of reversals for accruals no longer needed.

[0000068505-22-000010:mdna:225]
During 2019, we recorded net reorganization of business charges of $57 million relating to the separation of 700 employees, of which 500 were indirect employees and 200 were direct employees. The $57 million of charges included $17 million recorded to Cost of sales and $40 million recorded to Other charges. Included in the aggregate $57 million were charges of $64 million for employee separation costs and $5 million for exit costs, partially offset by $12 million of reversals for accruals no longer needed.

[0000068505-22-000010:mdna:226]
The following table displays the net charges incurred by business segment due to such reorganizations:

[0000068505-22-000010:mdna:227]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| Products and Systems Integration | $ | 25 |  |  | $ | 69 |  |  | $ | 45 |  |
| Software and Services | 7 |  |  | 17 |  |  | 12 |  |
|  | 32 |  |  | $ | 86 |  |  | $ | 57 |  |

[0000068505-22-000010:mdna:228]
Cash payments for employee severance in connection with the reorganization of business plans were $77 million, $85 million, and $63 million in 2021, 2020, and 2019, respectively. The reorganization of business accruals for employee separation costs at December 31, 2021 were $34 million which we expect to pay within one year.

[0000068505-22-000010:mdna:229]
Liquidity and Capital Resources

[0000068505-22-000010:mdna:230]
|  | Years Ended December 31 |
|  | 2021 |  | 2020 |  | 2019 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 1,837 |  |  | $ | 1,613 |  |  | $ | 1,823 |  |
| Investing activities | (742) |  |  | (437) |  |  | (934) |  |
| Financing activities | (429) |  |  | (966) |  |  | (1,144) |  |
| Effect of exchange rates on cash and cash equivalents | (46) |  |  | 43 |  |  | (1) |  |
| Increase (decrease) in cash and cash equivalents | $ | 620 |  |  | $ | 253 |  |  | $ | (256) |  |

[0000068505-22-000010:mdna:231]
Cash and Cash Equivalents

[0000068505-22-000010:mdna:232]
At December 31, 2021, $1.3 billion of our $1.9 billion cash and cash equivalents balance was held in the U.S. and $568 million was held in other countries, with $180 million held in the United Kingdom. Restricted cash was $2 million at December 31, 2021 and December 31, 2020.

[0000068505-22-000010:mdna:233]
In 2021, we repatriated $527 million in cash to the U.S. from international jurisdictions. We routinely repatriate a portion of non-U.S. earnings each year. We have recorded income tax expense for foreign withholding tax and distribution taxes on such earnings and, under current U.S. tax laws, do not expect to incur material incremental U.S. tax on repatriation.

[0000068505-22-000010:mdna:234]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay due to local country approvals.

[0000068505-22-000010:mdna:235]
Operating Activities

[0000068505-22-000010:mdna:236]
The increase in operating cash flows from 2020 to 2021 was driven by:

[0000068505-22-000010:mdna:237]
•an increase of operating earnings as a result of higher sales volume; partially offset by

[0000068505-22-000010:mdna:238]
•$76 million of higher income tax payments.

[0000068505-22-000010:mdna:239]
The decrease in operating cash flows from 2019 to 2020 was driven by:

[0000068505-22-000010:mdna:240]
•a reduction of operating earnings as a result of lower sales volume;

[0000068505-22-000010:mdna:241]
•$43 million of higher income tax payments; partially offset by

[0000068505-22-000010:mdna:242]
•improvements in working capital.

[0000068505-22-000010:mdna:243]
Investing Activities

[0000068505-22-000010:mdna:244]
The increase in net cash used by investing activities from 2020 to 2021 was primarily due to:

[0000068505-22-000010:mdna:245]
•$234 million increase in acquisitions and investments, driven by acquisitions of $521 million in 2021 compared to $287 million in 2020;

[0000068505-22-000010:mdna:246]
•$50 million decrease in proceeds from the sale of property, plant and equipment in 2020 that did not recur in 2021; and

[0000068505-22-000010:mdna:247]
•$26 million increase in capital expenditures in 2021 compared to 2020 due to higher expenditures for the Airwave and ESN networks.

[0000068505-22-000010:mdna:248]
The decrease in net cash used by investing activities from 2019 to 2020 was primarily due to:

[0000068505-22-000010:mdna:249]
•$422 million decrease in acquisitions and investments, driven by acquisitions of $287 million in 2020 compared to $709 million in 2019;

[0000068505-22-000010:mdna:250]
•$56 million increase in proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in 2020; and

[0000068505-22-000010:mdna:251]
•$31 million decrease in capital expenditures in 2020 compared 2019 due to lower expenditures for the Airwave and ESN networks.

[0000068505-22-000010:mdna:252]
Financing Activities

[0000068505-22-000010:mdna:253]
The decrease in cash used by financing activities in 2021 compared to cash used by financing activities in 2020 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" in this section below):

[0000068505-22-000010:mdna:254]
•$844 million net proceeds from the issuance of $850 million of 2.75% senior notes due 2031 in the second quarter of 2021, which was subsequently used to repurchase $324 million principal amount of our 3.5% senior notes due 2023 for a purchase price of $341 million, excluding $3 million of accrued interest; and

[0000068505-22-000010:mdna:255]
•$528 million used for purchases under our share repurchase program in 2021 as compared to $612 million in 2020; partially offset by

[0000068505-22-000010:mdna:256]
•$482 million cash used for the payment of dividends in 2021 as compared to $436 million in 2020.

[0000068505-22-000010:mdna:257]
The decrease in cash used by financing activities in 2020 compared to cash used by financing activities in 2019 was driven by:

[0000068505-22-000010:mdna:258]
•$400 million used for the repayment of the term loan in 2019;

[0000068505-22-000010:mdna:259]
•$1.0 billion received from the issuance of 1.75% senior convertible notes due 2024 in 2019 which was subsequently used for the settlement of $1.1 billion of the 2.00% senior convertible notes, inclusive of the $326 million conversion premium in 2019;

[0000068505-22-000010:mdna:260]
•$804 million net proceeds from the issuance of $800 million of 4.6% senior notes due 2029 in 2019, which was subsequently used to repurchase $614 million principal amount of long-term debt under a tender offer and

[0000068505-22-000010:mdna:261]
43

[0000068505-22-000010:mdna:262]
$150 million principal amount for the 3.5% senior notes due 2021 for a total purchase price of $809 million in 2019;

[0000068505-22-000010:mdna:263]
•$892 million net proceeds from the issuance of $900 million of 2.30% senior notes due 2030 in the third quarter of 2020, which was subsequently used to repurchase $552 million principal amount of 3.75% senior notes due 2022 and $293 million principal amount of long-term debt under a tender offer for a total purchase price of $897 million in 2020;

[0000068505-22-000010:mdna:264]
•$800 million net proceeds from the draw on our syndicated, unsecured revolving credit facility during 2020 which was subsequently repaid during the year; partially offset by

[0000068505-22-000010:mdna:265]
•$612 million used for purchases under our share repurchase program in 2020 as compared to $315 million in 2019; and

[0000068505-22-000010:mdna:266]
•$436 million cash used for the payment of dividends in 2020 as compared to $379 million in 2019.

[0000068505-22-000010:mdna:267]
Sales of Receivables

[0000068505-22-000010:mdna:268]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-22-000010:mdna:269]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2021, 2020, and 2019:

[0000068505-22-000010:mdna:270]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| Contract-specific discounting facility | $ | 211 |  |  | $ | 228 |  |  | $ | — |  |
| Accounts receivable sales proceeds | 56 |  |  | 74 |  |  | 34 |  |
| Long-term receivables sales proceeds | 248 |  |  | 181 |  |  | 265 |  |
| Total proceeds from receivable sales | $ | 515 |  |  | $ | 483 |  |  | $ | 299 |  |

[0000068505-22-000010:mdna:271]
During the year ended December 31, 2021, we utilized a cost-efficient receivable discounting facility, implemented in 2020, to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe resulting in accounts receivable sales of $211 million during the year ended December 31, 2021. The proceeds of our receivable sales are included in "Operating Activities" within our Consolidated Statements of Cash Flows.

[0000068505-22-000010:mdna:272]
At December 31, 2021, the Company had retained servicing obligations for $940 million of long-term receivables, compared to $983 million of long-term receivables at December 31, 2020. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-22-000010:mdna:273]
Debt

[0000068505-22-000010:mdna:274]
We had outstanding long-term debt of $5.7 billion and $5.2 billion, including the current portions of $5 million and $12 million, at December 31, 2021 and December 31, 2020, respectively.

[0000068505-22-000010:mdna:275]
On September 5, 2019, in connection with our repurchase and settlement of the outstanding principal amount of 2.00% senior convertible notes due 2020 issued to Silver Lake Partners, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 (the "Senior Convertible Notes"). Interest on these notes is payable semiannually. The Senior Notes became fully convertible on September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. We recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, we calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. As of December 31, 2021, the debt discount has been fully amortized as a component of interest expense. Our off-balance sheet arrangement of the obligation to settle the conversion option under the Senior Convertible Notes is more fully discussed in "Note 5: Debt and Credit Facilities" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K.

[0000068505-22-000010:mdna:276]
In August of 2020, we issued $900 million of 2.30% senior notes due 2030. We recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% senior notes due 2022 for a redemption price of $582 million, excluding $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of our long-term debt under a tender offer, for a purchase price of $315 million, excluding $5 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-22-000010:mdna:277]
In May of 2021, we issued $850 million of 2.75% senior notes due 2031. We recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds was then used to redeem $324 million in principal amount of our outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt issuance costs, we recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-22-000010:mdna:278]
We have an unsecured commercial paper program, backed by the revolving credit facility described below, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2021, we had no outstanding debt under the commercial paper program.

[0000068505-22-000010:mdna:279]
Credit Facilities

[0000068505-22-000010:mdna:280]
On March 24, 2021, we entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with the financial covenants as of December 31, 2021.

[0000068505-22-000010:mdna:281]
Share Repurchase Program

[0000068505-22-000010:mdna:282]
Through a series of actions, including approval in May 2021 to increase the authorized amount by $2.0 billion, the Board of Directors has authorized an aggregate share repurchase amount of up to $16.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2021, we used approximately $13.9 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $2.1 billion of authority available for future repurchases.

[0000068505-22-000010:mdna:283]
Our share repurchases, including transaction costs, for 2021, 2020, and 2019 are summarized as follows:

[0000068505-22-000010:mdna:284]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2021 | 2.5 |  |  | $ | 208.41 |  |  | $ | 528 |  |
| 2020 | 3.9 |  |  | 155.93 |  |  | 612 |  |
| 2019 | 2.3 |  |  | 137.35 |  |  | 315 |  |

[0000068505-22-000010:mdna:285]
Dividends

[0000068505-22-000010:mdna:286]
We paid cash dividends to holders of our common stock of $482 million in 2021, $436 million in 2020, and $379 million in 2019. On January 14, 2022, we paid an additional $134 million in cash dividends to holders of our common stock.

[0000068505-22-000010:mdna:287]
Adequate Internal Funding Resources

[0000068505-22-000010:mdna:288]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement.

[0000068505-22-000010:mdna:289]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer to “COVID-19” in this section of the Form 10-K for a discussion of the impact of COVID-19 on our liquidity, as well as "Part I. Item 1A. Risk Factors" for further discussion regarding access to the capital markets.

[0000068505-22-000010:mdna:290]
45

[0000068505-22-000010:mdna:291]
Material Cash Requirements from Contractual and Other Obligations

[0000068505-22-000010:mdna:292]
Summarized in the table and text below are our short-term (within the next twelve months) and long-term material cash requirements as of December 31, 2021, which we expect to fund with a combination of operating cash flows, existing cash balances or, as needed, borrowings under new or existing debt:

[0000068505-22-000010:mdna:293]
|  | Payments Due by Period |
| (in millions) |  | Short-term |  | Long-term |
| Long-term debt obligations, gross(1) |  | $ | 5 |  |  | $ | 5,737 |  |
| Lease obligations(2) |  | 136 |  |  | 345 |  |
| Purchase obligations(3) |  | 113 |  |  | 223 |  |
| Total obligations |  | $ | 254 |  |  | $ | 6,348 |  |

[0000068505-22-000010:mdna:294]
(1)Amounts included represent the estimated principal payments applicable to outstanding debt. Refer to "Note 5: Debt and Credit Facilities" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for discussion related to our long-term debt obligations.

[0000068505-22-000010:mdna:295]
(2)We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. In light of the uncertain COVID-19 environment, we are evaluating our needs for office space opportunities to reduce long-term cash requirements for office space where practicable. Refer to "Note 3: Leases" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further discussion of these material lease obligations.

[0000068505-22-000010:mdna:296]
(3)Amounts included represent firm, non-cancelable commitments. Such commitments include license agreements and  agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. We do not anticipate the cancellation of any of our take-or-pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-22-000010:mdna:297]
Other Contingencies

[0000068505-22-000010:mdna:298]
Potential Contractual Damage Claims in Excess of Underlying Contract Value: In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-22-000010:mdna:299]
Indemnification Provisions: We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us.

[0000068505-22-000010:mdna:300]
Legal Matters: We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on our results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-22-000010:mdna:301]
Long-term Customer Financing Commitments

[0000068505-22-000010:mdna:302]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $56 million at December 31, 2021 and at December 31, 2020.

[0000068505-22-000010:mdna:303]
Critical Accounting Policies and Estimates

[0000068505-22-000010:mdna:304]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-22-000010:mdna:305]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. The Company believes that the following discussion addresses the Company’s most critical accounting policies and estimates, which are those that are most important to the portrayal of the Company’s financial condition and results of operations and require management’s most difficult, subjective and complex judgments.

[0000068505-22-000010:mdna:306]
Revenue Recognition

[0000068505-22-000010:mdna:307]
We enter into arrangements which consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we generally allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-22-000010:mdna:308]
We account for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, we have determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on our customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-22-000010:mdna:309]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-22-000010:mdna:310]
Retirement Benefits

[0000068505-22-000010:mdna:311]
Our benefit obligations and net periodic pension costs (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions. The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-22-000010:mdna:312]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-22-000010:mdna:313]
There are various assumptions used in calculating the net periodic costs (benefits) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.  We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-22-000010:mdna:314]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost (benefit) and the net postretirement health care benefit. Our investment return assumption for the U.S. Pension Benefit Plans was 6.75% in 2021 and 6.85% in 2020. Our investment return assumption for the Postretirement Health Care Benefits Plan was 6.75% in 2021 and 6.90% in 2020. Our weighted average investment return assumption for the Non-U.S. Plans was 4.54% in 2021 and 4.66% in 2020. For the U.S. Pension Benefit Plans, a 25 bps increase in expected return on plan assets would result in $9 million of additional net periodic pension cost and a 25 bps decrease would result in a $9 million benefit to net periodic pension cost.  The impact of a similar increase or decrease on the Non-U.S. Plans and the Postretirement Health Care Benefits plan would be de minimis.

[0000068505-22-000010:mdna:315]
A second key assumption is the discount rate. The discount rate assumptions used for the U.S. Pension Benefit Plans, the Non-U.S. Plans and the Postretirement Health Care Benefits Plan reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 2.98% and 2.63% at December 31, 2021 and 2020, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 1.82% and 1.24% at December 31, 2021 and 2020, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 2.78% and 2.39% at December 31, 2021 and 2020, respectively.

[0000068505-22-000010:mdna:316]
A change in our discount rate on the Postretirement Health Care Benefits Plan would be de minimis. The effects of a change in the discount rate on the projected benefit obligation for both the U.S. and Non-U.S. Pension Benefit Plans are as follows:

[0000068505-22-000010:mdna:317]
|  |  | 2021 Projected Benefit Obligation |
| (in millions) |  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |
| Discount rate | 25 bps increase |  | $ | (184) |  |  | $ | (11) |  |
|  | 25 bps decrease |  | 195 |  |  | 12 |  |

[0000068505-22-000010:mdna:318]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from nine to thirty years. Prior service costs are being amortized over periods ranging from two to thirty years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-22-000010:mdna:319]
Valuation and Recoverability of Goodwill

[0000068505-22-000010:mdna:320]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: (i) adverse changes in macroeconomic conditions, (ii) adverse changes in the industry or market in which we transact, (iii) changes in cost factors negatively impacting earnings and cash flows, (iv) negative or declining overall financial performance, (v) events affecting the carrying value or composition of a reporting unit, or (vi) a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-22-000010:mdna:321]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Software and Services segments are comprised of three and two reporting units, respectively. The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2021, 2020, and 2019. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal years 2021, 2020, and 2019, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-22-000010:mdna:322]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-22-000010:mdna:323]
We use the asset and liability method of accounting for income taxes. Under this method, income tax expense is recognized for the amount of taxes payable or refundable for the current year. In addition, deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Management makes assumptions, judgments and estimates to determine our current and deferred tax provision and also the deferred tax assets and liabilities. We evaluate our deferred tax assets quarterly to determine if adjustments to our valuation allowance are required based on the consideration of all available positive and negative evidence.

[0000068505-22-000010:mdna:324]
Our assumptions, judgments and estimates for computing the income tax provision takes into account current tax laws, our interpretation of current tax law and possible outcomes of current and future audits conducted by foreign and domestic tax authorities. We believe such estimates to be reasonable; however, the final determination of certain audits could significantly impact the amounts provided for income taxes in our financial statements.

[0000068505-22-000010:mdna:325]
Recent Accounting Pronouncements

[0000068505-22-000010:mdna:326]
See “Note 1: Summary of Significant Accounting Policies” to our consolidated financial statements in “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-22-000010:mdna:327]
49
