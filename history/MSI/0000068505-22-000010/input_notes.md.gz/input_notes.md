# MSI notes — 0000068505-22-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000068505-22-000010:notes:1]
Portions of the registrant’s definitive Proxy Statement to be delivered to stockholders in connection with its Annual Meeting of Shareholders to be held on May 17, 2022 (the "Proxy Statement"), are incorporated by reference into Part III of this Annual Report on Form 10-K (this "Form 10-K").


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-22-000010:notes:2]
Summary of Significant Accounting Policies
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-22-000010:notes:3]
The consolidated financial statements as of December 31, 2021 and 2020 and for the years ended December 31, 2021, 2020 and 2019, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.

[0000068505-22-000010:notes:4]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-22-000010:notes:5]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of devices, systems and system integration and a full set of software and service offerings. The Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services.

[0000068505-22-000010:notes:6]
The Products and Systems Integration segment is comprised of devices, systems, and systems integration for our LMR and Video Security and Access Control technologies. Direct customers of the Products and Systems Integration segment are typically government, public safety agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional commercial radios and video security, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video security are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. For Products and Systems Integration sales, the Company records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-22-000010:notes:7]
LMR and Video Security and Access Control devices include two-way portable and vehicle-mounted radios, fixed and mobile video cameras and accessories. Devices are considered capable of being distinct and distinct within the context of the Company's contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-22-000010:notes:8]
The Products and Systems Integration segment includes both customized radio networks and video security solutions, including the integration of these networks with devices, software, and applications within both LMR and Video Security and Access Control technologies. For systems contracts, revenue for the year ended December 31, 2021 was $1.9 billion compared to $1.8 billion for the year ended December 31, 2020 and $1.9 billion for the year ended December 31, 2019. The networks include the aggregation of promises to the customer to provide i) a radio network core and central processing software, base stations, consoles, and repeaters or ii) a video security solution including video analytics, network video management hardware and software, and access control solutions. The individual promises of the radio network are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Products and Systems Integration revenue is recognized over an average duration of approximately one to two years. Individual promises of the video security solution are capable of being distinct and distinct in the context of the contract. Video security solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-22-000010:notes:9]
The Software and Services segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Software and Services segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-22-000010:notes:10]
Software offerings primarily include Command Center Software and Video Security and Access Control software and services which can be delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-22-000010:notes:11]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are generally each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is generally recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis. In certain situations when the software license is not distinct within the context of the contract, revenue for the software license is recognized over time following the transfer of control under the arrangement.

[0000068505-22-000010:notes:12]
Services include a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer-owned or Motorola Solutions-owned networks. Services are provided across all technologies and are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-22-000010:notes:13]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-22-000010:notes:14]
The Company accounts for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-22-000010:notes:15]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. The Company has a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-22-000010:notes:16]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $2 million at both December 31, 2021 and December 31, 2020.

[0000068505-22-000010:notes:17]
Investments: The Company generally invests in debt and equity securities of a strategic nature.

[0000068505-22-000010:notes:18]
The Company applies the equity method of accounting for equity investments if the Company has significant influence over the issuing entity. The Company’s share of the investee’s underlying net income or loss is recorded to Other within Other income (expense).

[0000068505-22-000010:notes:19]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other, net within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing

[0000068505-22-000010:notes:20]
entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded in Other, net within Other income (expense).

[0000068505-22-000010:notes:21]
Investments in debt securities are classified as available-for-sale and held-to-maturity on the basis of the Company’s intent and ability to hold the investments. Investments classified as available-for-sale are carried at fair value with changes reflected in other comprehensive income. Any credit-related impairment is recognized through an allowance for expected credit losses, and adjusted subsequently if conditions change, with a corresponding impact in earnings. Where there is an intention or a requirement to sell an impaired available-for-sale debt security, the entire impairment is recognized in earnings with a corresponding adjustment to the amortized cost basis of the security. Investments classified as held-to-maturity are carried at amortized cost less allowance for credit losses recorded through net income.

[0000068505-22-000010:notes:22]
Inventories: Inventories are valued at the lower of cost (which approximates cost on a first-in, first-out basis) and net realizable value.

[0000068505-22-000010:notes:23]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, one to twenty years; machinery and equipment, one to fifteen years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-22-000010:notes:24]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and selling, general and administrative costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it is determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform a quantitative goodwill impairment test, which compares the fair value of the reporting unit to its carrying value. If the carrying amount of a reporting unit exceeds its fair value, the Company would recognize an impairment loss in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-22-000010:notes:25]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.

[0000068505-22-000010:notes:26]
Leases: The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-22-000010:notes:27]
The Company determines if an arrangement is a lease at inception of the contract. The Company’s key considerations in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company’s contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the right to operate the asset at its discretion during the term of the contract.

[0000068505-22-000010:notes:28]
Right-of-use ("ROU") assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company’s lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in lease payments. For the Company’s leases consisting of land and other equipment (i.e. “communication network sites”), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage. ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-22-000010:notes:29]
As the majority of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company’s incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-22-000010:notes:30]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communication network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-22-000010:notes:31]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-22-000010:notes:32]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expenses and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-22-000010:notes:33]
Long-Term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. Long-term receivables are considered past due if payments have not been received according to the contractual terms of the note agreement, including principal and interest. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-22-000010:notes:34]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the Accrued liabilities statement line and the non-current portion is included in the Other liabilities statement line within the Company’s Consolidated Balance Sheet.

[0000068505-22-000010:notes:35]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-22-000010:notes:36]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-22-000010:notes:37]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-22-000010:notes:38]
Derivative Instruments: Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income. Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income at their initial value and amortized into Interest expense, net on a straight-line basis.

[0000068505-22-000010:notes:39]
Fair Value Measurements: The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-22-000010:notes:40]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-22-000010:notes:41]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-22-000010:notes:42]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-22-000010:notes:43]
Earnings Per Share: The Company calculates its basic earnings per share based on the weighted-average number of common shares issued and outstanding. Net earnings attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings per share. Diluted earnings per share is calculated by dividing net earnings attributable to Motorola Solutions, Inc. by the sum of the weighted-average number of common shares used in the basic earnings per share calculation and the weighted-average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings per share calculation. Both basic and diluted earnings per share amounts are calculated for net earnings attributable to Motorola Solutions, Inc. for all periods presented.

[0000068505-22-000010:notes:44]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk-free rate, dividend yield, and expected life. Performance-based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-22-000010:notes:45]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from nine to thirty years. Prior service costs will be amortized over periods ranging from two to thirty years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-22-000010:notes:46]
The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s Consolidated Balance Sheets using a December 31 measurement date.

[0000068505-22-000010:notes:47]
The benefit obligation and plan assets for the Company's U.S. Pension Benefit Plan and Postretirement Health Care Benefit Plan are measured as of December 31, 2021. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-22-000010:notes:48]
Recent Acquisitions:

[0000068505-22-000010:notes:49]
On December 16, 2021, the Company acquired 911 Datamaster, Inc. ("911 Datamaster"), a Next Generation 911 ("NG911") data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service of two years. This acquisition reinforces the Company's strategy to be a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The business is a part of the Software and Services segment.

[0000068505-22-000010:notes:50]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video Security and Access Control. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:51]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and

[0000068505-22-000010:notes:52]
access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:53]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to the Company's existing Command Center Software suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

[0000068505-22-000010:notes:54]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:55]
On June 16, 2020 the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Access Control technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:56]
On April 30, 2020, the Company acquired a cybersecurity services business for $32 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-22-000010:notes:57]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-22-000010:notes:58]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances the Company's Video Security and Access Control technology by adding data to its existing license plate recognition (“LPR”) database within the Software and Services segment.

[0000068505-22-000010:notes:59]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's Video Security and Access Control technology within both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:60]
On March 11, 2019, the Company acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources and secure their facilities. The business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:61]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands Video Security and Access Control within both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000010:notes:62]
Recent Accounting Pronouncements:

[0000068505-22-000010:notes:63]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU became effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company does not expect the adoption to have a material impact on its financial statements and disclosures.

[0000068505-22-000010:notes:64]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers," which will require companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC

[0000068505-22-000010:notes:65]
Topic 606. Under current GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 will result in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact of the new standard will depend on the magnitude of future acquisitions. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.

[0000068505-22-000010:notes:66]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and does not expect it to have a material impact on its financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-22-000010:notes:67]
Revenue from Contracts with Customers
Disaggregation of Revenue

[0000068505-22-000010:notes:68]
In January 2022 the Company began using LMR Communications, eliminating the "Mission Critical" descriptor from LMR Mission Critical Communications, to enhance investor understanding; this name change does not require any financial information to be reclassified from previous periods.

[0000068505-22-000010:notes:69]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the years ended December 31, 2021, 2020 and 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of reportable segments:

[0000068505-22-000010:notes:70]
|  | Years Ended |
|  | 2021 |  | 2020 |  | 2019 |
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions |
| North America | $ | 3,723 |  |  | $ | 1,838 |  |  | $ | 5,561 |  |  | $ | 3,418 |  |  | $ | 1,606 |  |  | $ | 5,024 |  |  | $ | 3,846 |  |  | $ | 1,430 |  |  | $ | 5,276 |  |
| International | 1,310 |  |  | 1,300 |  |  | 2,610 |  |  | 1,216 |  |  | 1,174 |  |  | 2,390 |  |  | 1,483 |  |  | 1,128 |  |  | 2,611 |  |
|  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 7,887 |  |
| Major Products and Services |
| LMR Communications | $ | 4,203 |  |  | $ | 2,205 |  |  | $ | 6,408 |  |  | $ | 3,992 |  |  | $ | 2,008 |  |  | $ | 6,000 |  |  | $ | 4,830 |  |  | $ | 1,891 |  |  | $ | 6,721 |  |
| Video Security and Access Control | 830 |  |  | 396 |  |  | 1,226 |  |  | 642 |  |  | 285 |  |  | 927 |  |  | 499 |  |  | 210 |  |  | 709 |  |
| Command Center Software | — |  |  | 537 |  |  | 537 |  |  | — |  |  | 487 |  |  | 487 |  |  | — |  |  | 457 |  |  | 457 |  |
|  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 7,887 |  |
| Customer Type |
| Direct | $ | 3,147 |  |  | $ | 2,842 |  |  | $ | 5,989 |  |  | $ | 2,991 |  |  | $ | 2,558 |  |  | $ | 5,549 |  |  | $ | 3,441 |  |  | $ | 2,395 |  |  | $ | 5,836 |  |
| Indirect | 1,886 |  |  | 296 |  |  | 2,182 |  |  | 1,643 |  |  | 222 |  |  | 1,865 |  |  | 1,888 |  |  | 163 |  |  | 2,051 |  |
|  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 7,887 |  |

[0000068505-22-000010:notes:71]
Remaining Performance Obligations

[0000068505-22-000010:notes:72]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of December 31, 2021 was $9.2 billion. A total of $4.0 billion was from Products and Systems Integration performance obligations that were not yet satisfied, of which $2.2 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $5.2 billion was from Software and Services performance obligations that were not yet satisfied as of December 31, 2021. The determination of Software and Services performance obligations that are not satisfied takes into

[0000068505-22-000010:notes:73]
account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-22-000010:notes:74]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-22-000010:notes:75]
Contract Balances

[0000068505-22-000010:notes:76]
| December 31 (in millions) | 2021 |  | 2020 |  | 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,386 |  |  | $ | 1,390 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 1,105 |  |  | 933 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,650 |  |  | 1,554 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 306 |  |  | 283 |  |  | 274 |  |  |  |  |  |

[0000068505-22-000010:notes:77]
Revenue recognized during the year ended December 31, 2021 which was previously included in Contract liabilities as of January 1, 2021 was $1.0 billion, compared to $946 million of revenue recognized during the year ended December 31, 2020 which was previously included in Contract liabilities as of January 1, 2020, and $854 million of revenue recognized during the year ended December 31, 2019 which was previously included in Contract liabilities as of January 1, 2019. Revenue of $4 million was reversed during the year ended December 31, 2021 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $53 million during the year ended December 31, 2020 and $50 million during the year ended December 31, 2019.

[0000068505-22-000010:notes:78]
There have been no material expected credit losses recognized on contract assets during the year ended December 31, 2021.

[0000068505-22-000010:notes:79]
Contract Cost Balances

[0000068505-22-000010:notes:80]
| December 31 (in millions) | 2021 |  | 2020 |  | 2019 |  |  |  |  |
| Current contract cost assets | $ | 30 |  |  | $ | 23 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 124 |  |  | 105 |  |  | 107 |  |  |  |  |  |

[0000068505-22-000010:notes:81]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one year to eight years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $52 million for the year ended December 31, 2021, compared to $49 million as of the year ended December 31, 2020 and $42 million as of the year ended December 31, 2019.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-22-000010:notes:82]
Leases
The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-22-000010:notes:83]
Components of Lease Expense

[0000068505-22-000010:notes:84]
| (in millions) | December 31, 2021 |  | December 31, 2020 |
| Lease expense: |  |  |  |
| Operating lease cost | $ | 133 |  |  | $ | 130 |  |
| Finance lease cost |  |  |  |
| Amortization of right-of-use assets | $ | 10 |  |  | $ | 11 |  |
| Interest on lease liabilities | — |  |  | 1 |  |
| Total finance lease cost | $ | 10 |  |  | $ | 12 |  |
| Short-term lease cost | $ | 2 |  |  | $ | 3 |  |
| Variable cost | 36 |  |  | 37 |  |
| Sublease income | (7) |  |  | (5) |  |
| Net lease expense | $ | 174 |  |  | $ | 177 |  |

[0000068505-22-000010:notes:85]
Lease Assets and Liabilities

[0000068505-22-000010:notes:86]
| (in millions) |  | Statement Line Classification |  | December 31, 2021 |  | December 31, 2020 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 382 |  |  | $ | 468 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 16 |  |  | 30 |  |  |  |
|  |  |  |  | $ | 398 |  |  | $ | 498 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 124 |  |  | $ | 126 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 4 |  |  | 11 |  |  |  |
|  |  |  |  | $ | 128 |  |  | $ | 137 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 313 |  |  | $ | 402 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | — |  |  | 5 |  |  |  |
|  |  |  |  | $ | 313 |  |  | $ | 407 |  |  |  |

[0000068505-22-000010:notes:87]
For the year ended December 31, 2020, the Company exercised a break option reducing the term of an International office lease by five years. This resulted in a reduction to both the Operating lease asset and Operating lease liabilities by approximately $47 million.

[0000068505-22-000010:notes:88]
Other Information Related to Leases

[0000068505-22-000010:notes:89]
| (in millions) | December 31, 2021 |  | December 31, 2020 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 145 |  |  | $ | 144 |  |  |  |
| Net cash used for operating activities related to finance leases | — |  |  | 1 |  |  |  |
| Net cash used for financing activities related to finance leases | 11 |  |  | 12 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 40 |  |  | $ | 84 |  |  |  |

[0000068505-22-000010:notes:90]
|  | December 31, 2021 |  | December 31, 2020 |  |  |
| Weighted average remaining lease terms (years): |  |  |  |  |  |
| Operating leases | 6 |  | 6 |  |  |
| Finance leases | 1 |  | 2 |  |  |
| Weighted average discount rate: |  |  |  |  |  |
| Operating leases | 3.11 | % |  | 3.30 | % |  |  |
| Finance leases | 3.99 | % |  | 4.21 | % |  |  |

[0000068505-22-000010:notes:91]
Future Lease Payments

[0000068505-22-000010:notes:92]
| December 31 (in millions) | Operating Leases |  | Finance Leases |  | Total |
| 2022 | $ | 136 |  |  | $ | 4 |  |  | $ | 140 |  |
| 2023 | 82 |  |  | — |  |  | 82 |  |
| 2024 | 67 |  |  | — |  |  | 67 |  |
| 2025 | 53 |  |  | — |  |  | 53 |  |
| 2026 | 41 |  |  | — |  |  | 41 |  |
| Thereafter | 102 |  |  | — |  |  | 102 |  |
| Total lease payments | $ | 481 |  |  | $ | 4 |  |  | $ | 485 |  |
| Less: Interest | 44 |  |  | — |  |  | 44 |  |
| Present value of lease liabilities | $ | 437 |  |  | $ | 4 |  |  | $ | 441 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-22-000010:notes:93]
Other Financial Data
Statement of Operations Information

[0000068505-22-000010:notes:94]
Other Charges (Income)

[0000068505-22-000010:notes:95]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-22-000010:notes:96]
| Years ended December 31 (in millions) | 2021 |  | 2020 |  | 2019 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 236 |  |  | $ | 215 |  |  | $ | 208 |  |
| Reorganization of businesses (Note 14) | 24 |  |  | 57 |  |  | 40 |  |
| Losses on legal settlements | 3 |  |  | 9 |  |  | 3 |  |
| Asset impairments | — |  |  | 5 |  |  | — |  |
| Gain on sale of property, plant, and equipment | — |  |  | (50) |  |  | — |  |
| Operating lease asset impairments | 10 |  |  | — |  |  | 5 |  |
| Acquisition-related transaction fees | 15 |  |  | 9 |  |  | 3 |  |
| Other | (2) |  |  | 1 |  |  | 1 |  |
|  | $ | 286 |  |  | $ | 246 |  |  | $ | 260 |  |

[0000068505-22-000010:notes:97]
During the year ended December 31, 2021, the Company recognized $10 million of operating lease impairments primarily relating to the consolidation of acquired U.S. manufacturing and distribution facilities. This loss has been recognized in Other charges in the Company's Consolidated Statements of Operations. During 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe.

[0000068505-22-000010:notes:98]
Other Income (Expense)

[0000068505-22-000010:notes:99]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-22-000010:notes:100]
| Years ended December 31 (in millions) | 2021 |  | 2020 |  | 2019 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (215) |  |  | $ | (233) |  |  | $ | (237) |  |
| Interest income | 7 |  |  | 13 |  |  | 17 |  |
|  | $ | (208) |  |  | $ | (220) |  |  | $ | (220) |  |
| Other, net: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 123 |  |  | $ | 81 |  |  | $ | 78 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (18) |  |  | (56) |  |  | (50) |  |
| Gains from the extinguishment of 2.00% senior convertible notes (Note 5) | — |  |  | — |  |  | 4 |  |
| Investment impairments | — |  |  | (4) |  |  | (18) |  |
| Foreign currency gain (loss) | 17 |  |  | (44) |  |  | (22) |  |
| Gain (loss) on derivative instruments | (30) |  |  | 25 |  |  | (8) |  |
| Gains on equity method investments | 5 |  |  | 3 |  |  | 3 |  |
| Fair value adjustments to equity investments | (8) |  |  | 6 |  |  | (3) |  |
| U.S. pension settlement (Note 8) | — |  |  | — |  |  | (359) |  |
| Other | 3 |  |  | 2 |  |  | 10 |  |
|  | $ | 92 |  |  | $ | 13 |  |  | $ | (365) |  |

[0000068505-22-000010:notes:101]
Earnings Per Common Share

[0000068505-22-000010:notes:102]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-22-000010:notes:103]
|  |  |  |  |  |  |  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  |  |  | Net Earnings |
| Years ended December 31 |  |  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 1,245 |  |  | $ | 949 |  |  | $ | 868 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 169.2 |  |  | 170.0 |  |  | 166.6 |  |
| Per share amount |  |  |  |  |  |  | $ | 7.36 |  |  | $ | 5.58 |  |  | $ | 5.21 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 1,245 |  |  | $ | 949 |  |  | $ | 868 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 169.2 |  |  | 170.0 |  |  | 166.6 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards |  |  |  |  |  |  | 4.0 |  |  | 4.1 |  |  | 4.7 |  |
| 2.00% senior convertible notes |  |  |  |  |  |  | — |  |  | — |  |  | 4.3 |  |
| 1.75% senior convertible notes |  |  |  |  |  |  | 0.4 |  |  | — |  |  |  |
| Diluted weighted average common shares outstanding |  |  |  |  |  |  | 173.6 |  |  | 174.1 |  |  | 175.6 |  |
| Per share amount |  |  |  |  |  |  | $ | 7.17 |  |  | $ | 5.45 |  |  | $ | 4.95 |  |

[0000068505-22-000010:notes:104]
In the computation of diluted earnings per common share for the year ended December 31, 2021, the assumed exercise of 0.2 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2019, the assumed exercise of 0.3 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-22-000010:notes:105]
As of December 31, 2021, the Company had $1.0 billion of 1.75% senior convertible notes outstanding which mature on September 15, 2024 ("Senior Convertible Notes"). The notes became fully convertible as of September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. In November 2021, the Company's Board of

[0000068505-22-000010:notes:106]
Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the year ended December 31, 2021. The Company included the number of shares that would be issuable upon conversion (under the treasury stock method of accounting for share dilution) in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended December 31, 2021. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of December 31, 2021 was $286 million. Refer to "Note 5: Debt and Credit Facilities" for a further discussion of the Senior Convertible Notes.

[0000068505-22-000010:notes:107]
Balance Sheet Information

[0000068505-22-000010:notes:108]
Accounts Receivable, Net

[0000068505-22-000010:notes:109]
Accounts receivable, net, consists of the following:

[0000068505-22-000010:notes:110]
| December 31 | 2021 |  | 2020 |
| Accounts receivable | $ | 1,456 |  |  | $ | 1,465 |  |
| Less allowance for credit losses | (70) |  |  | (75) |  |
|  | $ | 1,386 |  |  | $ | 1,390 |  |

[0000068505-22-000010:notes:111]
Inventories, Net

[0000068505-22-000010:notes:112]
Inventories, net, consist of the following:

[0000068505-22-000010:notes:113]
| December 31 | 2021 |  | 2020 |
| Finished goods | $ | 268 |  |  | $ | 271 |  |
| Work-in-process and production materials | 643 |  |  | 360 |  |
|  | 911 |  |  | 631 |  |
| Less inventory reserves | (123) |  |  | (123) |  |
|  | $ | 788 |  |  | $ | 508 |  |

[0000068505-22-000010:notes:114]
Other Current Assets

[0000068505-22-000010:notes:115]
Other current assets consist of the following:

[0000068505-22-000010:notes:116]
| December 31 | 2021 |  | 2020 |
| Current contract cost assets (Note 2) | $ | 30 |  |  | $ | 23 |  |
| Tax-related deposits (Note 7) | 41 |  |  | 52 |  |
| Other | 188 |  |  | 167 |  |
|  | $ | 259 |  |  | $ | 242 |  |

[0000068505-22-000010:notes:117]
Property, Plant and Equipment, Net

[0000068505-22-000010:notes:118]
Property, plant and equipment, net, consist of the following:

[0000068505-22-000010:notes:119]
| December 31 | 2021 |  | 2020 |
| Land | $ | 5 |  |  | $ | 6 |  |
| Leasehold improvements | 474 |  |  | 439 |  |
| Machinery and equipment | 2,439 |  |  | 2,276 |  |
|  | 2,918 |  |  | 2,721 |  |
| Less accumulated depreciation | (1,876) |  |  | (1,699) |  |
|  | $ | 1,042 |  |  | $ | 1,022 |  |

[0000068505-22-000010:notes:120]
Depreciation expense for the years ended December 31, 2021, 2020, and 2019 was $202 million, $194 million and $186 million, respectively.

[0000068505-22-000010:notes:121]
Investments

[0000068505-22-000010:notes:122]
Investments consist of the following:

[0000068505-22-000010:notes:123]
| December 31 | 2021 |  | 2020 |  |  |  |  |
| Common stock | $ | 69 |  |  | $ | 19 |  |  |  |  |  |
| Strategic investments, at cost | 35 |  |  | 46 |  |  |  |  |  |
| Company-owned life insurance policies | 81 |  |  | 77 |  |  |  |  |  |
| Equity method investments | 24 |  |  | 16 |  |  |  |  |  |
|  | $ | 209 |  |  | $ | 158 |  |  |  |  |  |

[0000068505-22-000010:notes:124]
The Company’s common stock portfolio reflects investments in publicly-traded companies within the communications services sector and is valued utilizing active market prices for similar instruments. During the year ended December 31, 2021, the Company paid $50 million for equity securities of NewHold Investment Corp. ("NHIC"), a special purpose acquisition company ("SPAC") that completed a business combination with Evolv Technologies, Inc. After the business combination, NHIC was renamed “Evolv Technologies Holdings, Inc.” (together with its subsidiaries, “Evolv”). During the year ended December 31, 2021, the Company recognized a loss of $30 million in Other income (expense) related to a decrease in the fair value of the investment.

[0000068505-22-000010:notes:125]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the year ended December 31, 2021.

[0000068505-22-000010:notes:126]
The Company recorded a gain on the sale of investments and businesses of $1 million during the year ended December 31, 2021, a loss on the sale of investments and businesses of $2 million for the year ended December 31, 2020 and a gain on sale of investments and businesses of $5 million during the year ended December 31, 2019.

[0000068505-22-000010:notes:127]
During the year ended December 31, 2021, the Company recorded no investment impairment charges, compared to $4 million during the year ended December 31, 2020 and $18 million during the year ended December 31, 2019, representing other-than-temporary declines in the value of the Company’s strategic equity investment portfolio.

[0000068505-22-000010:notes:128]
Other Assets

[0000068505-22-000010:notes:129]
Other assets consist of the following:

[0000068505-22-000010:notes:130]
| December 31 | 2021 |  | 2020 |
| Defined benefit plan assets (Note 8) | $ | 365 |  |  | $ | 283 |  |
| Non-current contract cost assets (Note 2) | 124 |  |  | 105 |  |
| Other | 69 |  |  | 94 |  |
|  | $ | 558 |  |  | $ | 482 |  |

[0000068505-22-000010:notes:131]
Accrued Liabilities

[0000068505-22-000010:notes:132]
Accrued liabilities consist of the following:

[0000068505-22-000010:notes:133]
| December 31 | 2021 |  | 2020 |
| Compensation | $ | 360 |  |  | $ | 291 |  |
| Tax liabilities (Note 7) | 183 |  |  | 147 |  |
| Dividend payable | 134 |  |  | 120 |  |
| Trade liabilities | 235 |  |  | 164 |  |
| Operating lease liabilities (Note 3) | 124 |  |  | 126 |  |
| Other | 521 |  |  | 463 |  |
|  | $ | 1,557 |  |  | $ | 1,311 |  |

[0000068505-22-000010:notes:134]
Other Liabilities

[0000068505-22-000010:notes:135]
Other liabilities consist of the following:

[0000068505-22-000010:notes:136]
| December 31 | 2021 |  | 2020 |
| Defined benefit plans (Note 8) | $ | 1,390 |  |  | $ | 1,578 |  |
| Non-current contract liabilities (Note 2) | 306 |  |  | 283 |  |
| Unrecognized tax benefits (Note 7) | 36 |  |  | 49 |  |
| Deferred income taxes (Note 7) | 183 |  |  | 180 |  |
| Other | 233 |  |  | 273 |  |
|  | $ | 2,148 |  |  | $ | 2,363 |  |

[0000068505-22-000010:notes:137]
Stockholders’ Equity Information

[0000068505-22-000010:notes:138]
Share Repurchase Program: Through a series of actions, including approval in May 2021 to increase the authorized amount by $2.0 billion, the Board of Directors has authorized the Company to repurchase in the aggregate up to $16.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2021, the Company had used approximately $13.9 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $2.1 billion of authority available for future repurchases.

[0000068505-22-000010:notes:139]
The Company's share repurchases, including transaction costs, for 2021, 2020, and 2019 can be summarized as follows:

[0000068505-22-000010:notes:140]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2021 | 2.5 |  |  | $ | 208.41 |  |  | $ | 528 |  |
| 2020 | 3.9 |  |  | 155.93 |  |  | 612 |  |
| 2019 | 2.3 |  |  | 137.35 |  |  | 315 |  |

[0000068505-22-000010:notes:141]
Payment of Dividends: On November 18, 2021, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.71 per share of common stock to $0.79 per share of common stock. During the years ended December 31, 2021, 2020, and 2019 the Company paid $482 million, $436 million, and $379 million, respectively, in cash dividends to holders of its common stock. On January 14, 2022, the Company paid an additional $134 million in cash dividends to holders of its common stock.

[0000068505-22-000010:notes:142]
Accumulated Other Comprehensive Loss

[0000068505-22-000010:notes:143]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2021, 2020, and 2019:

[0000068505-22-000010:notes:144]
|  | Years ended December 31 |
|  | 2021 |  | 2020 |  | 2019 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (360) |  |  | $ | (410) |  |  | $ | (444) |  |
| Other comprehensive income (loss) before reclassification adjustment | (30) |  |  | 55 |  |  | 35 |  |
| Tax benefit (expense) | 6 |  |  | (5) |  |  | (1) |  |
| Other comprehensive income (loss), net of tax | (24) |  |  | 50 |  |  | 34 |  |
| Balance at end of period | $ | (384) |  |  | $ | (360) |  |  | $ | (410) |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (2,086) |  |  | $ | (2,030) |  |  | $ | (2,321) |  |
| Other comprehensive income (loss) before reclassification adjustment | 37 |  |  | (130) |  |  | 337 |  |
| Tax benefit (expense) | (7) |  |  | 30 |  |  | (85) |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 30 |  |  | (100) |  |  | 252 |  |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 89 |  |  | 76 |  |  | 65 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (8) |  |  | (18) |  |  | (15) |  |
| Tax expense | (20) |  |  | (14) |  |  | (11) |  |
| Reclassification adjustments into Net earnings, net of tax | 61 |  |  | 44 |  |  | 39 |  |
| Other comprehensive income (loss), net of tax | 91 |  |  | (56) |  |  | 291 |  |
| Balance at end of period | $ | (1,995) |  |  | $ | (2,086) |  |  | $ | (2,030) |  |
| Total Accumulated other comprehensive loss | $ | (2,379) |  |  | $ | (2,446) |  |  | $ | (2,440) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-22-000010:notes:145]
Debt and Credit Facilities
Long-Term Debt

[0000068505-22-000010:notes:146]
| December 31 | 2021 |  | 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 585 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 5 |  |  | 18 |  |
|  | 5,695 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (5) |  |  | (12) |  |
| Long-term debt | $ | 5,688 |  |  | $ | 5,163 |  |

[0000068505-22-000010:notes:147]
On September 5, 2019, in connection with the Company's repurchase and settlement of the outstanding principal amount of 2.00% senior convertible notes due 2020 issued to Silver Lake Partners, the Company entered into an agreement with Silver Lake Partners to issue the Senior Convertible Notes. Interest on these notes is payable semiannually. The notes became fully convertible as of September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The Company recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. As of December 31, 2021, the debt discount had been fully amortized as a component of interest expense. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash.

[0000068505-22-000010:notes:148]
In August of 2020, the Company issued $900 million of 2.30% senior notes due 2030. The Company recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% senior notes due 2022 for a redemption price of $582 million, excluding $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of its long-term debt under a tender offer, for a purchase price of $315 million, excluding $5 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-22-000010:notes:149]
In May of 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of the 3.5% senior notes due 2023 for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-22-000010:notes:150]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement (defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2021, the Company had no outstanding debt under the commercial paper program.

[0000068505-22-000010:notes:151]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2022—$5 million; 2023—$1 million; 2024—$1.6 billion; 2025—$322 million; and 2026—the Company does not have any long-term debt maturities.

[0000068505-22-000010:notes:152]
Credit Facilities

[0000068505-22-000010:notes:153]
On March 24, 2021, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026, which can be used for borrowing and letters of credit (the "2021 Motorola Solutions Credit Agreement"). 
The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-22-000010:notes:154]
Risk Management
Foreign Currency Risk

[0000068505-22-000010:notes:155]
At December 31, 2021, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.1 billion, compared to $1.2 billion outstanding at December 31, 2020. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-22-000010:notes:156]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2021 and the corresponding positions as of December 31, 2020:

[0000068505-22-000010:notes:157]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2021 |  | 2020 |
| Euro | $ | 164 |  |  | $ | 177 |  |
| British pound | 128 |  |  | 86 |  |
| Norwegian krone | 28 |  |  | 32 |  |
| Chinese renminbi | (89) |  |  | (90) |  |
| Australian dollar | (76) |  |  | (88) |  |

[0000068505-22-000010:notes:158]
Net Investment Hedges

[0000068505-22-000010:notes:159]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. The Company has elected to exclude the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight-line basis and recognized through interest expense. As of December 31, 2021, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £100 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-22-000010:notes:160]
Counterparty Risk

[0000068505-22-000010:notes:161]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2021, all of the counterparties had investment grade credit ratings. As of December 31, 2021, the credit risk with all derivative counterparties was approximately $7 million.

[0000068505-22-000010:notes:162]
Derivative Financial Instruments

[0000068505-22-000010:notes:163]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2021 and 2020:

[0000068505-22-000010:notes:164]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2021 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | Other assets |  | $ | — |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 2 |  |  | Other assets |  | $ | 5 |  |  | Accrued liabilities |

[0000068505-22-000010:notes:165]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2020 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 5 |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 14 |  |  | Other assets |  | $ | 3 |  |  | Accrued liabilities |

[0000068505-22-000010:notes:166]
The following table summarizes the effect of derivatives designated as hedging instruments, for the years ended December 31, 2021, 2020 and 2019:

[0000068505-22-000010:notes:167]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2021 |  | 2020 |  | 2019 |
| Foreign exchange contracts | $ | 13 |  |  | $ | (7) |  |  | $ | 8 |  | Other comprehensive income (loss) |

[0000068505-22-000010:notes:168]
The following table summarizes the effect of derivatives not designated as hedging instruments, for the years ended December 31, 2021, 2020 and 2019:

[0000068505-22-000010:notes:169]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2021 |  | 2020 |  | 2019 |
| Foreign exchange contracts | $ | (30) |  |  | $ | 25 |  |  | $ | (8) |  | Other income (expense) |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-22-000010:notes:170]
Income Taxes
Components of Income Tax Expense

[0000068505-22-000010:notes:171]
Components of earnings before income taxes are as follows:

[0000068505-22-000010:notes:172]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| United States | $ | 1,030 |  |  | $ | 1,029 |  |  | $ | 714 |  |
| Other nations | 522 |  |  | 145 |  |  | 287 |  |
|  | $ | 1,552 |  |  | $ | 1,174 |  |  | $ | 1,001 |  |

[0000068505-22-000010:notes:173]
Components of income tax expense are as follows:

[0000068505-22-000010:notes:174]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| United States | $ | 134 |  |  | $ | 117 |  |  | $ | 94 |  |
| Other nations | 98 |  |  | 98 |  |  | 93 |  |
| States (U.S.) | 36 |  |  | 31 |  |  | 27 |  |
| Current income tax expense | 268 |  |  | 246 |  |  | 214 |  |
| United States | (2) |  |  | (21) |  |  | (61) |  |
| Other nations | 22 |  |  | 8 |  |  | (22) |  |
| States (U.S.) | 14 |  |  | (12) |  |  | (1) |  |
| Deferred income tax expense (benefit) | 34 |  |  | (25) |  |  | (84) |  |
| Total income tax expense | $ | 302 |  |  | $ | 221 |  |  | $ | 130 |  |

[0000068505-22-000010:notes:175]
Differences between income tax expense computed at the U.S. federal statutory tax rate of 21% and income tax expense as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-22-000010:notes:176]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| Income tax expense at statutory rate | $ | 326 |  | 21.0 | % |  | $ | 246 |  | 21.0 | % |  | $ | 210 |  | 21.0 | % |
| State income taxes, net of federal benefit | 55 |  | 3.5 | % |  | 39 |  | 3.3 | % |  | 32 |  | 3.2 | % |
| U.S. tax expense (benefit) on undistributed non-U.S. earnings | 6 |  | 0.4 | % |  | (2) |  | (0.2) | % |  | 6 |  | 0.6 | % |
| Non-U.S. tax expense on non-U.S. earnings | 8 |  | 0.5 | % |  | 5 |  | 0.5 | % |  | 4 |  | 0.4 | % |
| Reserve for uncertain tax positions | (10) |  | (0.6) | % |  | — |  | — | % |  | (3) |  | (0.3) | % |
| Other tax expense (benefit) | 3 |  | 0.2 | % |  | 5 |  | 0.4 | % |  | (3) |  | (0.3) | % |
| Research credits | (20) |  | (1.3) | % |  | (28) |  | (2.4) | % |  | (10) |  | (1.0) | % |
| Stock compensation | (32) |  | (2.1) | % |  | (48) |  | (4.1) | % |  | (27) |  | (2.7) | % |
| Valuation allowances | (34) |  | (2.2) | % |  | 4 |  | 0.3 | % |  | (79) |  | (7.9) | % |
|  | $ | 302 |  | 19.5 | % |  | $ | 221 |  | 18.8 | % |  | $ | 130 |  | 13.0 | % |

[0000068505-22-000010:notes:177]
The effective tax rate for 2021 was below the current U.S. federal statutory rate of 21% primarily due to the partial release of the valuation allowance recorded on the U.S. foreign tax credit carryforward and the recognition of excess tax benefits of share-based compensation.

[0000068505-22-000010:notes:178]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are the result of retirement benefit adjustments and currency translation adjustments. The adjustments were charges of $21 million for the year ended December 31, 2021, benefits of $11 million for the year ended December 31, 2020 and charges of $97 million for the year ended December 31, 2019.

[0000068505-22-000010:notes:179]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the 2017 U.S. Tax Cuts and Jobs Act ("the Tax Act"), dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-22-000010:notes:180]
Undistributed foreign earnings that the Company intends to reinvest indefinitely amounted to, in the aggregate, $1.5 billion at December 31, 2021. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-22-000010:notes:181]
Gross deferred tax assets were $2.0 billion and $2.1 billion for December 31, 2021 and December 31, 2020, respectively. Deferred tax assets, net of valuation allowances, were $1.8 billion and $1.7 billion at December 31, 2021 and December 31, 2020, respectively. Gross deferred tax liabilities were $1.0 billion and $926 million at December 31, 2021 and 2020, respectively.

[0000068505-22-000010:notes:182]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-22-000010:notes:183]
| December 31 | 2021 |  | 2020 |
| Inventory | $ | 29 |  |  | $ | 22 |  |
| Accrued liabilities and allowances | 86 |  |  | 67 |  |
| Employee benefits | 321 |  |  | 372 |  |
| Capitalized items | (86) |  |  | (61) |  |
| Tax basis differences on investments | (1) |  |  | (3) |  |
| Depreciation tax basis differences on fixed assets | 23 |  |  | 52 |  |
| Undistributed non-U.S. earnings | (36) |  |  | (33) |  |
| Tax attribute carryforwards | 410 |  |  | 449 |  |
| Business reorganization | 8 |  |  | 16 |  |
| Warranty and customer liabilities | 27 |  |  | 24 |  |
| Deferred revenue and costs | 213 |  |  | 203 |  |
| Valuation allowances | (275) |  |  | (341) |  |
| Operating lease assets | (95) |  |  | (103) |  |
| Operating lease liabilities | 108 |  |  | 119 |  |
| Other | 1 |  |  | 3 |  |
|  | $ | 733 |  |  | $ | 786 |  |

[0000068505-22-000010:notes:184]
At December 31, 2021 and 2020, the Company had valuation allowances of $275 million and $341 million, respectively, against its deferred tax assets, including $53 million and $81 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance decreased $38 million during 2021 primarily due to a change in the Company's ability to utilize U.S. foreign tax credits and the expiration of tax attributes. The Company's non-U.S. valuation allowance decreased $28 million during 2021 primarily due to the expiration of tax attributes. The Company's valuation  allowance for U.S. and non-U.S. decreased $5 million and $4 million, respectively, during 2020 primarily due to the expiration of tax attributes. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-22-000010:notes:185]
Tax attribute carryforwards are as follows:

[0000068505-22-000010:notes:186]
| December 31, 2021 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 144 |  |  | $ | 28 |  |  | 2028-2037 |
| Foreign tax credits | — |  |  | 264 |  |  | 2022-2023 |
| General business credits | — |  |  | 3 |  |  | 2030-2033 |
| State tax losses | — |  |  | 21 |  |  | 2022-2040 |
| State tax credits | — |  |  | 12 |  |  | 2022-2040 |
| Non-U.S. subsidiaries: |  |  |  |  |  |
| Japan tax losses | 11 |  |  | 3 |  |  | 2022-2029 |
| United Kingdom tax losses | 111 |  |  | 28 |  |  | Unlimited |
| Singapore tax losses | 7 |  |  | 1 |  |  | Unlimited |
| Canada tax losses | 19 |  |  | 5 |  |  | 2034-2040 |
| Spain tax credits | — |  |  | 19 |  |  | 2022-2029 |
| Other subsidiaries tax losses | 74 |  |  | 16 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 10 |  |  | Various |
|  |  |  | $ | 410 |  |  |  |

[0000068505-22-000010:notes:187]
The Company had unrecognized tax benefits of $43 million and $64 million at December 31, 2021 and December 31, 2020, respectively, of which approximately $36 million and $53 million, if recognized, would have affected the effective tax rate for 2021 and 2020, respectively.

[0000068505-22-000010:notes:188]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-22-000010:notes:189]
| (in millions) | 2021 |  | 2020 |
| Balance at January 1 | $ | 64 |  |  | $ | 70 |  |
| Additions based on tax positions related to current year | 1 |  |  | 8 |  |
| Additions for tax positions of prior years | 2 |  |  | 2 |  |
| Reductions for tax positions of prior years | — |  |  | (6) |  |
| Settlements and agreements | (18) |  |  | (8) |  |
| Lapse of statute of limitations | (6) |  |  | (2) |  |
| Balance at December 31 | $ | 43 |  |  | $ | 64 |  |

[0000068505-22-000010:notes:190]
The Company recorded $36 million and $49 million of unrecognized tax benefits in other liabilities at December 31, 2021 and December 31, 2020, respectively.

[0000068505-22-000010:notes:191]
The Internal Revenue Service ("IRS") has concluded the examination of the Company's 2014 and 2015 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-22-000010:notes:192]
| Jurisdiction | Tax Years |
| United States | 2018-2021 |
| Australia | 2017-2021 |
| Canada | 2017-2021 |
| Germany | 2017-2021 |
| India | 1997-2021 |
| Israel | 2019-2021 |
| Poland | 2018-2021 |
| Malaysia | 2014-2021 |
| United Kingdom | 2020-2021 |

[0000068505-22-000010:notes:193]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-22-000010:notes:194]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be up to a $7 million tax benefit.

[0000068505-22-000010:notes:195]
At December 31, 2021, the Company had $22 million accrued for interest and $15 million accrued for penalties on unrecognized tax benefits. At December 31, 2020, the Company had $33 million and $15 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-22-000010:notes:196]
Retirement Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-22-000010:notes:197]
U.S. Pension Benefit Plans

[0000068505-22-000010:notes:198]
The Company’s non-contributory U.S. defined benefit plan (the "U.S. Pension Plan") provide benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. In December 2008, the Company amended the U.S. Pension Plan and MSSP (together the "U.S. Pension Benefit Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-22-000010:notes:199]
In December 2019, the Company completed a voluntary lump-sum election window offered to certain participants of the U.S. Pension Plan. The aggregate dollar amount of lump-sum elections by approximately 6,300 participants was $836 million,

[0000068505-22-000010:notes:200]
and accordingly, this amount was paid out of plan assets prior to December 31, 2019. These actions resulted in a reduction of the Company's projected benefit obligation, absent of actuarial losses experienced from decreases in interest rates, of $1.0 billion and a settlement loss of $359 million recorded within “Other charges” on the Consolidated Statement of Operations.

[0000068505-22-000010:notes:201]
Postretirement Health Care Benefits Plan

[0000068505-22-000010:notes:202]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of amendments, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-22-000010:notes:203]
These series of amendments to the Postretirement Health Care Benefits Plan resulted in a reduction in the postretirement benefit obligation. A substantial portion of the decrease related to prior service credits and was amortized as a credit to the Consolidated Statements of Operations over approximately five years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan. These amendments were fully amortized during fiscal year 2021.

[0000068505-22-000010:notes:204]
Non-U.S. Pension Benefit Plans

[0000068505-22-000010:notes:205]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-22-000010:notes:206]
In June 2015, the Company amended its non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-22-000010:notes:207]
In 2019, the Motorola Solutions United Kingdom defined benefit plan trustees decided to exercise their discretion on early retirement benefit reductions. This action resulted in a reduction of the projected benefit obligation of approximately $83 million related to prior service credits that will be amortized as a credit to the Consolidated Statements of Operations over approximately twenty-nine years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan.

[0000068505-22-000010:notes:208]
Net Periodic Cost (Benefit)

[0000068505-22-000010:notes:209]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-22-000010:notes:210]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 115 |  |  | 144 |  |  | 202 |  |  | 21 |  |  | 29 |  |  | 36 |  |  | 1 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (235) |  |  | (225) |  |  | (275) |  |  | (99) |  |  | (85) |  |  | (85) |  |  | (11) |  |  | (10) |  |  | (10) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 70 |  |  | 58 |  |  | 46 |  |  | 16 |  |  | 15 |  |  | 15 |  |  | 3 |  |  | 3 |  |  | 4 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (3) |  |  | (3) |  |  | — |  |  | (5) |  |  | (15) |  |  | (15) |  |
| Settlement loss | — |  |  | — |  |  | 359 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (50) |  |  | $ | (23) |  |  | $ | 332 |  |  | $ | (64) |  |  | $ | (42) |  |  | $ | (32) |  |  | $ | (12) |  |  | $ | (20) |  |  | $ | (18) |  |

[0000068505-22-000010:notes:211]
The status of the Company’s plans is as follows:

[0000068505-22-000010:notes:212]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 5,226 |  |  | $ | 4,727 |  |  | $ | 2,058 |  |  | $ | 1,814 |  |  | $ | 71 |  |  | $ | 73 |  |
| Service cost | — |  |  | — |  |  | 1 |  |  | 2 |  |  | — |  |  | — |  |
| Interest cost | 115 |  |  | 144 |  |  | 21 |  |  | 29 |  |  | 1 |  |  | 2 |  |
| Plan amendments | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Actuarial loss (gain) | (71) |  |  | 480 |  |  | (61) |  |  | 171 |  |  | 10 |  |  | 1 |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (31) |  |  | 88 |  |  | — |  |  | — |  |
| Benefit payments | (130) |  |  | (125) |  |  | (53) |  |  | (47) |  |  | (4) |  |  | (5) |  |
| Benefit obligation at December 31 | $ | 5,140 |  |  | $ | 5,226 |  |  | $ | 1,935 |  |  | $ | 2,058 |  |  | $ | 78 |  |  | $ | 71 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 4,083 |  |  | $ | 3,601 |  |  | $ | 1,880 |  |  | $ | 1,641 |  |  | $ | 181 |  |  | $ | 160 |  |
| Return on plan assets | 201 |  |  | 604 |  |  | 43 |  |  | 214 |  |  | 9 |  |  | 26 |  |
| Company contributions | 3 |  |  | 3 |  |  | 9 |  |  | 9 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (9) |  |  | 63 |  |  | — |  |  | — |  |
| Benefit payments | (130) |  |  | (125) |  |  | (53) |  |  | (47) |  |  | (4) |  |  | (5) |  |
| Fair value at December 31 | $ | 4,157 |  |  | $ | 4,083 |  |  | $ | 1,870 |  |  | $ | 1,880 |  |  | $ | 186 |  |  | $ | 181 |  |
| Funded status of the plan | $ | (983) |  |  | $ | (1,143) |  |  | $ | (65) |  |  | $ | (178) |  |  | $ | 108 |  |  | $ | 110 |  |
| Unrecognized net loss | 1,871 |  |  | 1,977 |  |  | 655 |  |  | 675 |  |  | 31 |  |  | 23 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (77) |  |  | (80) |  |  | — |  |  | (5) |  |
| Prepaid pension cost | $ | 888 |  |  | $ | 834 |  |  | $ | 513 |  |  | $ | 417 |  |  | $ | 139 |  |  | $ | 128 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3) |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (980) |  |  | (1,140) |  |  | (297) |  |  | (330) |  |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 232 |  |  | 152 |  |  | 108 |  |  | 110 |  |
| Deferred income taxes | 454 |  |  | 480 |  |  | 61 |  |  | 65 |  |  | 11 |  |  | 7 |  |
| Accumulated other comprehensive loss | 1,417 |  |  | 1,497 |  |  | 517 |  |  | 530 |  |  | 20 |  |  | 11 |  |
| Prepaid pension cost | $ | 888 |  |  | $ | 834 |  |  | $ | 513 |  |  | $ | 417 |  |  | $ | 139 |  |  | $ | 128 |  |

[0000068505-22-000010:notes:213]
For the year ended December 31, 2021, the primary driver of the decrease in the U.S. Pension Benefit Plans benefit obligation was higher actuarial gains due to an increase in the discount rate from 2.63% as of December 31, 2020 to 2.98% as of December 31, 2021, partially offset by increases in the benefit obligation due to demographic assumption updates. For the year ended December 31, 2020, the primary driver of the increase in the U.S. Pension Benefit Plans benefit obligation was higher actuarial losses due to a decrease in the discount rate from 3.32% as of December 31, 2019 to 2.63% as of December 31, 2020.

[0000068505-22-000010:notes:214]
For the year ended December 31, 2021, the most significant drivers of the decrease in Non-U.S. Pension Benefit Plans benefit obligation were the higher actuarial gains coupled with favorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial gains primarily due to increases in the discount rates from 1.24% as of December 31, 2020 to 1.82% as of December 31, 2021. For the year ended December 31, 2020, the most significant drivers of the increase in Non-U.S. Pension Benefit Plans benefit obligation were the higher actuarial losses coupled with unfavorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial losses primarily due to decreases in the discount rates from 1.82% as of December 31, 2019 to 1.24% as of December 31, 2020.

[0000068505-22-000010:notes:215]
Actuarial Assumptions

[0000068505-22-000010:notes:216]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-22-000010:notes:217]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-22-000010:notes:218]
The Company used "Mortality Improvement Scale MP-2021" to calculate the 2021 U.S. projected benefit obligations and the "Mortality Improvement Scale MP-2018" to calculate the 2020 U.S. projected benefit obligations.

[0000068505-22-000010:notes:219]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-22-000010:notes:220]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Discount rate | 2.25 | % |  | 3.10 | % |  | 1.02 | % |  | 1.61 | % |  | 1.57 | % |  | 2.66 | % |
| Investment return assumption | 6.75 | % |  | 6.85 | % |  | 4.54 | % |  | 4.66 | % |  | 6.75 | % |  | 6.90 | % |

[0000068505-22-000010:notes:221]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-22-000010:notes:222]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Discount rate | 2.98 | % |  | 2.63 | % |  | 1.82 | % |  | 1.24 | % |  | 2.78 | % |  | 2.39 | % |
| Future compensation increase rate | n/a |  | n/a |  | 0.54 | % |  | 0.43 | % |  | n/a |  | n/a |

[0000068505-22-000010:notes:223]
The following table presents the accumulated benefit obligation, projected benefit obligation and fair value of plan assets for our plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets:

[0000068505-22-000010:notes:224]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  |
| December 31 | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |
| Accumulated benefit obligation | $ | 5,140 |  |  | $ | 5,226 |  |  | $ | 1,933 |  |  | $ | 2,055 |  |  |  |  |
| Projected benefit obligation | 5,140 |  |  | 5,226 |  |  | 1,935 |  |  | 2,058 |  |  |  |  |
| Fair value of plan assets | 4,157 |  |  | 4,083 |  |  | 1,870 |  |  | 1,880 |  |  |  |  |

[0000068505-22-000010:notes:225]
Investment Policy

[0000068505-22-000010:notes:226]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-22-000010:notes:227]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plan were as follows:

[0000068505-22-000010:notes:228]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 26 | % |  | 25 | % |  | 28 | % |  | 28 | % |
| Fixed income securities | 57 | % |  | 57 | % |  | 52 | % |  | 51 | % |
| Cash and other investments | 17 | % |  | 18 | % |  | 20 | % |  | 21 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 26 | % |  | 26 | % |  | 29 | % |  | 30 | % |
| Fixed income securities | 58 | % |  | 58 | % |  | 53 | % |  | 53 | % |
| Cash and other investments | 16 | % |  | 16 | % |  | 18 | % |  | 17 | % |

[0000068505-22-000010:notes:229]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-22-000010:notes:230]
Cash Funding

[0000068505-22-000010:notes:231]
The Company made $3 million of contributions to its U.S. Pension Benefit Plans during each of 2021 and 2020. The Company contributed $9 million to its Non U.S. Pension Benefit Plans during 2021 and 2020. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2021 or 2020.

[0000068505-22-000010:notes:232]
Expected Future Benefit Payments

[0000068505-22-000010:notes:233]
The following benefit payments are expected to be paid:

[0000068505-22-000010:notes:234]
| Year | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2022 | $ | 161 |  |  | $ | 53 |  |  | $ | 7 |  |
| 2023 | 178 |  |  | 54 |  |  | 6 |  |
| 2024 | 197 |  |  | 56 |  |  | 6 |  |
| 2025 | 217 |  |  | 57 |  |  | 6 |  |
| 2026 | 240 |  |  | 58 |  |  | 5 |  |
| 2027-2031 | 1,370 |  |  | 310 |  |  | 23 |  |

[0000068505-22-000010:notes:235]
Other Benefit Plans

[0000068505-22-000010:notes:236]
Split-Dollar Life Insurance Arrangements

[0000068505-22-000010:notes:237]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-22-000010:notes:238]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2021, 2020 and 2019. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $68 million and $73 million as of December 31, 2021 and December 31, 2020, respectively.

[0000068505-22-000010:notes:239]
Deferred Compensation Plan

[0000068505-22-000010:notes:240]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the 401(k) plan (as defined below). The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-22-000010:notes:241]
Defined Contribution Plan

[0000068505-22-000010:notes:242]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the Motorola Solutions 401(k) plan (the "401(k) plan") is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2021, 2020 and 2019 were $36 million, $15 million and $32 million, respectively.

[0000068505-22-000010:notes:243]
Due to the economic uncertainties caused by the COVID-19 pandemic, the Company took action in a number of areas to reduce its operating expenses, including by suspending all Company match contributions to the 401(k) plan for the period from May 15, 2020 through December 31, 2020, which were reinstated on January 1, 2021.

[0000068505-22-000010:notes:244]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2021, 2020, and 2019 the Company made no discretionary contributions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-22-000010:notes:245]
Share-Based Compensation and Other Incentive Plans
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option and stock appreciation right granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-22-000010:notes:246]
Restricted stock grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees. The grants are restricted in such that they are subject to vesting conditions; however, restricted stock holders have voting rights, and the rights to earn dividends on unvested shares.

[0000068505-22-000010:notes:247]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-22-000010:notes:248]
Performance-based stock options (“performance options”), market stock units ("MSUs"), and performance stock units ("PSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years. PSUs have been granted as a portion of the Long Range Incentive Plan (“LRIP”) awards issued to certain Company executive officers. The PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual TSR compared to the S&P 500 over the three-year performance period.

[0000068505-22-000010:notes:249]
On August 25, 2015 and on March 9, 2017, the Company approved grants of performance-contingent stock options (“PCSOs”) to certain executive officers which were fully vested as of December 31, 2021. The August 25, 2015 awards have a seven-year term and a per share exercise price of $68.50. The March 9, 2017 awards have a five-and-a-half-year term and a per share exercise price of $81.37.

[0000068505-22-000010:notes:250]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended

[0000068505-22-000010:notes:251]
December 31, 2021, 2020 and 2019, employees purchased 0.6 million, 0.7 million and 0.6 million shares, respectively, at purchase prices of $133.27 and $160.11, $112.98 and $107.18, and $108.96 and $120.12, respectively.

[0000068505-22-000010:notes:252]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-22-000010:notes:253]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2021, 2020 and 2019 was $41.57, $39.98 and $29.14, respectively, using the following weighted-average assumptions:

[0000068505-22-000010:notes:254]
|  | 2021 |  | 2020 |  | 2019 |
| Expected volatility | 27.3 | % |  | 33.7 | % |  | 23.8 | % |
| Risk-free interest rate | 0.8 | % |  | 0.6 | % |  | 2.3 | % |
| Dividend yield | 2.2 | % |  | 2.7 | % |  | 2.5 | % |
| Expected life (years) | 5.9 |  | 5.9 |  | 6.0 |

[0000068505-22-000010:notes:255]
The Company calculates the value of each performance option, MSU, and PSU using a Monte Carlo simulation option pricing model, estimated on the date of grant. The fair values of performance options, MSUs, and PSUs granted during 2021 were $60.42, $184.71 and $203.57, respectively. The fair values of performance options, MSUs, and PSUs granted during 2020 were $77.82, $112.17 and $233.96, respectively. The fair value of performance options, MSUs and PSUs granted during 2019 was $46.15, $138.00 and $203.61, respectively. The following assumptions were used for the calculations.

[0000068505-22-000010:notes:256]
|  | 2021 |  | 2020 |  | 2019 |
|  | Performance Options |  | Performance Options |  | Performance Options |
| Expected volatility of common stock | 28.5 | % |  | 34.7 | % |  | 22.4 | % |
| Expected volatility of the S&P 500 | 38.7 | % |  | 29.0 | % |  | 25.1 | % |
| Risk-free interest rate | 1.2 | % |  | 0.8 | % |  | 2.3 | % |
| Dividend yield | 2.3 | % |  | 2.6 | % |  | 2.7 | % |
| Expected life (years) | 6.5 |  | 6.5 |  | 6.5 |

[0000068505-22-000010:notes:257]
|  | 2021 |  | 2020 |  | 2019 |
|  | Market Stock Unit |  | Market Stock Unit |  | Market Stock Units |
| Expected volatility of common stock | 28.5 | % |  | 34.7 | % |  | 22.4 | % |
| Risk-free interest rate | 0.3 | % |  | 0.6 | % |  | 2.2 | % |
| Dividend yield | 1.8 | % |  | 1.7 | % |  | 2.0 | % |

[0000068505-22-000010:notes:258]
|  | 2021 |  |  | 2020 |
|  | Performance Stock Units |  |  | Performance Stock Units |
| Expected volatility of common stock | 28.5 | % |  |  | 34.7 | % |
| Expected volatility of the S&P 500 | 38.7 | % |  |  | 29.0 | % |
| Risk-free interest rate | 0.3 | % |  |  | 0.6 | % |
| Dividend yield | 1.8 | % |  |  | 1.7 | % |

[0000068505-22-000010:notes:259]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PSUs. The selection of the implied volatility approach was based upon the availability of actively-traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. At the conclusion of each three-year PSU and performance option cycle, the Company uses the historical volatility as the expected volatility to calculate the actual TSR compared to the S&P 500.

[0000068505-22-000010:notes:260]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-22-000010:notes:261]
The Company has applied forfeiture rates, estimated based on historical data, of 10% to the stock option fair values calculated by the Black-Scholes option pricing model and 15% to RSUs. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-22-000010:notes:262]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, at December 31, 2021 (in thousands, except exercise price and years):

[0000068505-22-000010:notes:263]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| $51-$70 | 1,982 |  |  | 63 |  |  | 1 |  | 1,982 |  |  | 63 |  |  | 1 |
| $71-$90 | 795 |  |  | 77 |  |  | 5 |  | 795 |  |  | 77 |  |  | 5 |
| $91-$110 | 276 |  |  | 108 |  |  | 6 |  | 276 |  |  | 108 |  |  | 6 |
| $111-$130 | 59 |  |  | 122 |  |  | 7 |  | 38 |  |  | 123 |  |  | 7 |
| $131-$150 | 251 |  |  | 139 |  |  | 7 |  | 46 |  |  | 139 |  |  | 7 |
| $151-$170 | 252 |  |  | 156 |  |  | 8 |  | 50 |  |  | 159 |  |  | 8 |
| $171-$190 | 306 |  |  | 180 |  |  | 9 |  | 1 |  |  | 175 |  |  | 8 |
| $191 and over | 34 |  |  | 223 |  |  | 10 |  | — |  |  | — |  |  | — |  |
|  | 3,955 |  |  |  |  |  |  | 3,188 |  |  |  |  |  |

[0000068505-22-000010:notes:264]
As of December 31, 2021, the weighted average contractual life for options outstanding and exercisable was four and three years, respectively.

[0000068505-22-000010:notes:265]
Current Year Activity

[0000068505-22-000010:notes:266]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-22-000010:notes:267]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2021 | 2,240 |  |  | $ | 74 |  |  | 987 |  |  | $ | 138 |  |  | 125 |  |  | $ | 132 |  |
| Granted | 203 |  |  | 187 |  |  | 471 |  |  | 186 |  |  | 147 |  |  | 227 |  |
| Releases/Exercised | (828) |  |  | 66 |  |  | (435) |  |  | 132 |  |  | (63) |  |  | 115 |  |
| Forfeited/Canceled | (28) |  |  | 169 |  |  | (99) |  |  | 137 |  |  | — |  |  | — |  |
| Balance as of December 31, 2021 | 1,587 |  |  | $ | 92 |  |  | 924 |  |  | $ | 199 |  |  | 209 |  |  | $ | 203 |  |
| Awards exercisable | 1,244 |  |  | 70 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-22-000010:notes:268]
|  | Performance Options* |  | Market Stock Units |  | Performance Stock Units |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2021 | 2,160 |  |  | $ | 84 |  |  | 131 |  |  | $ | 121 |  |  | 55 |  |  | $ | 219 |  |
| Granted | 160 |  |  | 179 |  |  | 52 |  |  | 185 |  |  | 123 |  |  | 204 |  |
| Releases/Exercised | (94) |  |  | 100 |  |  | (80) |  |  | 124 |  |  | (47) |  |  | 182 |  |
| Adjustment for payout factor | 142 |  |  | 108 |  |  | 18 |  |  | 127 |  |  | — |  |  | — |  |
| Forfeited/Canceled | — |  |  | — |  |  | (1) |  |  | 125 |  |  | (3) |  |  | 204 |  |
| Balance as of December 31, 2021 | 2,368 |  |  | $ | 91 |  |  | 120 |  |  | $ | 147 |  |  | 128 |  |  | $ | 210 |  |
| Awards exercisable | 1,944 |  |  | 76 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-22-000010:notes:269]
* Inclusive of PCSO awards

[0000068505-22-000010:notes:270]
At December 31, 2021 and 2020, 4.9 million and 5.9 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-22-000010:notes:271]
Total Share-Based Compensation Expense

[0000068505-22-000010:notes:272]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-22-000010:notes:273]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 16 |  |  | $ | 16 |  |  | $ | 14 |  |
| Selling, general and administrative expenses | 79 |  |  | 73 |  |  | 62 |  |
| Research and development expenditures | 34 |  |  | 40 |  |  | 42 |  |
| Share-based compensation expense included in Operating earnings | 129 |  |  | 129 |  |  | 118 |  |
| Tax benefit | 15 |  |  | 30 |  |  | 22 |  |
| Share-based compensation expense, net of tax | $ | 114 |  |  | $ | 99 |  |  | $ | 96 |  |
| Decrease in basic earnings per share | $ | (0.67) |  |  | $ | (0.58) |  |  | $ | (0.57) |  |
| Decrease in diluted earnings per share | $ | (0.66) |  |  | $ | (0.57) |  |  | $ | (0.55) |  |

[0000068505-22-000010:notes:274]
At December 31, 2021, the Company had unrecognized compensation expense related to all share based awards of $162 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately three years and $6 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. The aggregate fair value of outstanding share based awards as of December 31, 2021 was $315 million.

[0000068505-22-000010:notes:275]
Cash received from stock option exercises and the employee stock purchase plan was $102 million, $108 million, and $114 million for the years ended December 31, 2021, 2020, and 2019, respectively. The total intrinsic value of options exercised during the years ended December 31, 2021, 2020, and 2019 was $186 million, $149 million, and $113 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2021 was $712 million and $628 million, respectively, based on a December 31, 2021 stock price of $271.09 per share.

[0000068505-22-000010:notes:276]
Motorola Solutions Incentive Plans

[0000068505-22-000010:notes:277]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2021, 2020 and 2019 was $161 million, $78 million and $146 million, respectively.

[0000068505-22-000010:notes:278]
Long-Range Incentive Plan

[0000068505-22-000010:notes:279]
The LRIP rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. The expense for those LRIP awards with cash settlement terms was $8 million, $9 million and $21 million for the years ended December 31, 2021, 2020 and 2019 , respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-22-000010:notes:280]
Fair Value Measurements
Investments and Derivatives

[0000068505-22-000010:notes:281]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2021 and December 31, 2020 were as follows:

[0000068505-22-000010:notes:282]
| December 31, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |
| Common stock and equivalents | 69 |  |  | — |  |  |  |  | 69 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-22-000010:notes:283]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 14 |  |  |  |  | $ | 14 |  |
| Common stock and equivalents | 19 |  |  | — |  |  |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  |  |  | $ | 8 |  |

[0000068505-22-000010:notes:284]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-22-000010:notes:285]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2021 and 2020 were as follows:

[0000068505-22-000010:notes:286]
| December 31, 2021 | Level 1 |  | Level 2 |  | Level 3 |  |  |  | Total |
| Equities | $ | 41 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 41 |  |
| Commingled funds | 1,601 |  |  | 505 |  |  | — |  |  |  |  | 2,106 |  |
| Government fixed income securities | — |  |  | 412 |  |  | — |  |  |  |  | 412 |  |
| Corporate fixed income securities | — |  |  | 1,145 |  |  | — |  |  |  |  | 1,145 |  |
| Short-term investment funds | 338 |  |  | — |  |  | — |  |  |  |  | 338 |  |
| Private funds | — |  |  | — |  |  | 60 |  |  |  |  | 60 |  |
| Total investment securities | $ | 1,980 |  |  | $ | 2,062 |  |  | $ | 60 |  |  |  |  | $ | 4,102 |  |
| Accrued income receivable |  |  |  |  |  |  |  |  | 49 |  |
| Cash |  |  |  |  |  |  |  |  | 6 |  |
| Fair value plan assets |  |  |  |  |  |  |  |  | $ | 4,157 |  |

[0000068505-22-000010:notes:287]
The following table summarizes the changes in fair value of the Level 3 assets:

[0000068505-22-000010:notes:288]
|  | 2021 |
| Fair value at January 1, 2021 | — |  |
| Transfers from Level 2 | 17 |  |
| Actual return on plan assets | 5 |  |
| Purchases | 38 |  |
| Fair value at December 31, 2021 | 60 |  |

[0000068505-22-000010:notes:289]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 45 |  |  | $ | — |  |  |  |  | $ | 45 |  |
| Commingled funds | 1,603 |  |  | 463 |  |  |  |  | 2,066 |  |
| Government fixed income securities | — |  |  | 516 |  |  |  |  | 516 |  |
| Corporate fixed income securities | — |  |  | 1,070 |  |  |  |  | 1,070 |  |
| Short-term investment funds | 327 |  |  | — |  |  |  |  | 327 |  |
| Total investment securities | $ | 1,975 |  |  | $ | 2,049 |  |  |  |  | $ | 4,024 |  |
| Accrued income receivable |  |  |  |  |  |  | 44 |  |
| Cash |  |  |  |  |  |  | 15 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 4,083 |  |

[0000068505-22-000010:notes:290]
| December 31, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 94 |  |  | $ | — |  |  |  |  | $ | 94 |  |
| Commingled funds | 458 |  |  | 75 |  |  |  |  | 533 |  |
| Government fixed income securities | 2 |  |  | 1,004 |  |  |  |  | 1,006 |  |
| Short-term investment funds | 105 |  |  | — |  |  |  |  | 105 |  |
| Total investment securities | $ | 659 |  |  | $ | 1,079 |  |  |  |  | $ | 1,738 |  |
| Cash |  |  |  |  |  |  | 4 |  |
| Accrued income receivable |  |  |  |  |  |  | 78 |  |
| Insurance contracts |  |  |  |  |  |  | 50 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,870 |  |

[0000068505-22-000010:notes:291]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 78 |  |  | $ | — |  |  |  |  | $ | 78 |  |
| Commingled funds | 458 |  |  | 71 |  |  |  |  | 529 |  |
| Government fixed income securities | — |  |  | 1,076 |  |  |  |  | 1,076 |  |
| Short-term investment funds | 106 |  |  | — |  |  |  |  | 106 |  |
| Total investment securities | $ | 642 |  |  | $ | 1,147 |  |  |  |  | $ | 1,789 |  |
| Cash |  |  |  |  |  |  | 7 |  |
| Accrued income receivable |  |  |  |  |  |  | 30 |  |
| Insurance contracts |  |  |  |  |  |  | 54 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,880 |  |

[0000068505-22-000010:notes:292]
| December 31, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equities | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Commingled funds | 72 |  |  | 23 |  |  | — |  |  | 95 |  |
| Government fixed income securities | — |  |  | 18 |  |  | — |  |  | 18 |  |
| Corporate fixed income securities | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Short-term investment funds | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Private funds | — |  |  | — |  |  | 3 |  |  | 3 |  |
| Total investment securities | $ | 89 |  |  | $ | 92 |  |  | 3 |  |  | 184 |  |
| Accrued income receivable |  |  |  |  |  |  | 2 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 186 |  |

[0000068505-22-000010:notes:293]
|  | 2021 |
| Fair value at January 1, 2021 | — |  |
| Transfers from Level 2 | 1 |  |
| Purchases | 2 |  |
| Fair value at December 31, 2021 | 3 |  |

[0000068505-22-000010:notes:294]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 2 |  |  | $ | — |  |  |  |  | $ | 2 |  |
| Commingled funds | 71 |  |  | 20 |  |  |  |  | 91 |  |
| Government fixed income securities | — |  |  | 23 |  |  |  |  | 23 |  |
| Corporate fixed income securities | — |  |  | 48 |  |  |  |  | 48 |  |
| Short-term investment funds | 15 |  |  | — |  |  |  |  | 15 |  |
| Total investment securities | $ | 88 |  |  | $ | 91 |  |  |  |  | $ | 179 |  |
| Cash |  |  |  |  |  |  | 2 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 181 |  |

[0000068505-22-000010:notes:295]
The following is a description of the categories of investments:

[0000068505-22-000010:notes:296]
Equities — A diversified portfolio of corporate common and preferred stocks.

[0000068505-22-000010:notes:297]
Commingled funds — A diversified portfolio of assets that includes corporate common and preferred stocks, emerging market and high-yield fixed income securities among others.

[0000068505-22-000010:notes:298]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-22-000010:notes:299]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-22-000010:notes:300]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-22-000010:notes:301]
Private funds — A diversified portfolio of assets that includes private equity funds and private loans.

[0000068505-22-000010:notes:302]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. Level 3 investments include securities with valuations derived from valuation techniques, in which one or more significant inputs are unobservable.  A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-22-000010:notes:303]
At December 31, 2021, the Company had $685 million of investments in money market government and U.S. treasury funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $448 million at December 31, 2020. The money market funds had quoted market prices that are approximately at par.

[0000068505-22-000010:notes:304]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2021 was $6.2 billion (Level 2), compared to a face value of $5.7 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-22-000010:notes:305]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-22-000010:notes:306]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-22-000010:notes:307]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-22-000010:notes:308]
| December 31 | 2021 |  | 2020 |
| Long-term receivables, gross | $ | 49 |  |  | $ | 76 |  |
| Less allowance for losses | (2) |  |  | (3) |  |
| Long-term receivables | $ | 47 |  |  | $ | 73 |  |
| Less current portion | (20) |  |  | (19) |  |
| Non-current long-term receivables | $ | 27 |  |  | $ | 54 |  |

[0000068505-22-000010:notes:309]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized interest income on long-term receivables of $1 million for each of the years ended December 31, 2021, 2020 and 2019.

[0000068505-22-000010:notes:310]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $56 million at December 31, 2021 and $78 million at December 31, 2020.

[0000068505-22-000010:notes:311]
Sales of Receivables

[0000068505-22-000010:notes:312]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements.

[0000068505-22-000010:notes:313]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2021, 2020 and 2019.

[0000068505-22-000010:notes:314]
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |
| Contract-specific discounting facility | $ | 211 |  |  | $ | 228 |  |  | $ | — |  |
| Accounts receivable sales proceeds | 56 |  |  | 74 |  |  | 34 |  |
| Long-term receivables sales proceeds | 248 |  |  | 181 |  |  | 265 |  |
| Total proceeds from receivable sales | $ | 515 |  |  | $ | 483 |  |  | $ | 299 |  |

[0000068505-22-000010:notes:315]
The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-22-000010:notes:316]
At December 31, 2021, the Company had retained servicing obligations for $940 million of long-term receivables, compared to $983 million of long-term receivables at December 31, 2020. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-22-000010:notes:317]
During the year ended December 31, 2021, the Company utilized a cost-efficient receivable discounting facility, implemented in 2020, to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe resulting in accounts receivable sales of $211 million during the year ended December 31, 2021. The proceeds of the Company's receivable sales are included in "Operating Activities" within its Consolidated Statements of Cash Flows.

[0000068505-22-000010:notes:318]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-22-000010:notes:319]
An aging analysis of financing receivables at December 31, 2021 and December 31, 2020 is as follows:

[0000068505-22-000010:notes:320]
| December 31, 2021 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 28 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 21 |  |  | 1 |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 49 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |

[0000068505-22-000010:notes:321]
| December 31, 2020 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 50 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 26 |  |  | 2 |  |  | 1 |  |  | 4 |  |
| Long-term receivables, including current portion | $ | 76 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 4 |  |

[0000068505-22-000010:notes:322]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-22-000010:notes:323]
Commitments and Contingencies
Purchase Obligations

[0000068505-22-000010:notes:324]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow it to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancellable.

[0000068505-22-000010:notes:325]
As of December 31, 2021, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2026. The Company expects to make total payments of $336 million under these arrangements as follows: $113 million in 2022, $103 million in 2023, $91 million in 2024, $18 million in 2025, and $11 million in 2026.

[0000068505-22-000010:notes:326]
The Company outsources certain corporate functions, such as benefit administration and information technology-related services, under various contracts, the longest of which is expected to expire in 2025. The remaining payments under these contracts are approximately $24 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-22-000010:notes:327]
Legal Matters

[0000068505-22-000010:notes:328]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  The Court also ordered the parties to jointly file by February 22, 2022, a proposed royalty agreement for the Court's review and approval.

[0000068505-22-000010:notes:329]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief. On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

[0000068505-22-000010:notes:330]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities.

[0000068505-22-000010:notes:331]
Indemnifications

[0000068505-22-000010:notes:332]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-22-000010:notes:333]
The Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-22-000010:notes:334]
Information by Segment and Geographic Region
The Company conducts its business globally and manages it through the following two segments:

[0000068505-22-000010:notes:335]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security devices and infrastructure, and the implementation and integration of such systems, devices, and applications. Within LMR Communications, the Company is a global leader in the two-way radio category, including the Company’s Project 25 ("P25"), Terrestrial Trunked Radio ("TETRA"), Digital Mobile Radio ("DMR)", as well as other professional and commercial radio (“PCR”) solutions. The Company provides LTE solutions for public safety, government and commercial users, including infrastructure and devices operating in 700 MHz, 900 MHz and Citizens' Broadband Radio Service ("CBRS") frequencies. The Company's Video Security and Access Control technology includes network video management infrastructure, fixed security and mobile video cameras (body-worn and in-vehicle) and access control solutions. The primary customers of the Products and Systems Integration segment are government, public safety and commercial customers who operate private communications networks and video security solutions and typically manage a mobile workforce. In 2021, the segment’s net sales were $5.0 billion, representing 62% of the Company's consolidated net sales.

[0000068505-22-000010:notes:336]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and commercial customers. Software includes public safety and enterprise Command Center Software, unified communications applications, and video software solutions, delivered both on-premise and “as a service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced technologies include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer-owned or Motorola Solutions-owned networks. In 2021, the segment’s net sales were $3.1 billion, representing 38% of the Company's consolidated net sales.

[0000068505-22-000010:notes:337]
For the years ended December 31, 2021, 2020 and 2019, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-22-000010:notes:338]
Segment Information

[0000068505-22-000010:notes:339]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-22-000010:notes:340]
|  | Net Sales |  | Operating Earnings |
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| Products and Systems Integration | $ | 5,033 |  |  | $ | 4,634 |  |  | $ | 5,329 |  |  | $ | 760 |  |  | $ | 656 |  |  | $ | 994 |  |
| Software and Services | 3,138 |  |  | 2,780 |  |  | 2,558 |  |  | 907 |  |  | 727 |  |  | 587 |  |
|  | $ | 8,171 |  |  | $ | 7,414 |  |  | $ | 7,887 |  |  | $ | 1,667 |  |  | $ | 1,383 |  |  | $ | 1,581 |  |
| Total other expense |  |  |  |  |  |  | (115) |  |  | (209) |  |  | (580) |  |
| Net earnings before income taxes |  |  |  |  |  |  | $ | 1,552 |  |  | $ | 1,174 |  |  | $ | 1,001 |  |

[0000068505-22-000010:notes:341]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-22-000010:notes:342]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| Products and Systems Integration | $ | 90 |  |  | $ | 91 |  |  | $ | 98 |  |  | $ | 87 |  |  | $ | 90 |  |  | $ | 82 |  |
| Software and Services | 153 |  |  | 126 |  |  | 150 |  |  | 115 |  |  | 104 |  |  | 104 |  |
|  | $ | 243 |  |  | $ | 217 |  |  | $ | 248 |  |  | $ | 202 |  |  | $ | 194 |  |  | $ | 186 |  |

[0000068505-22-000010:notes:343]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-22-000010:notes:344]
Geographic Area Information

[0000068505-22-000010:notes:345]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| United States | $ | 5,236 |  |  | $ | 4,770 |  |  | $ | 5,006 |  |  | $ | 9,420 |  |  | $ | 7,009 |  |  | $ | 6,749 |  |
| United Kingdom | 849 |  |  | 740 |  |  | 692 |  |  | 1,588 |  |  | 2,460 |  |  | 2,460 |  |
| Canada | 324 |  |  | 254 |  |  | 270 |  |  | 950 |  |  | 1,016 |  |  | 1,040 |  |
| Other, net of eliminations | 1,762 |  |  | 1,650 |  |  | 1,919 |  |  | 231 |  |  | 391 |  |  | 393 |  |
|  | $ | 8,171 |  |  | $ | 7,414 |  |  | $ | 7,887 |  |  | $ | 12,189 |  |  | $ | 10,876 |  |  | $ | 10,642 |  |

[0000068505-22-000010:notes:346]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-22-000010:notes:347]
Reorganization of Businesses
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of contractual lease terminations costs. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-22-000010:notes:348]
During 2021, 2020, and 2019 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. During 2020, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits,

[0000068505-22-000010:notes:349]
which are normally different based on employment level grade and capped at nine months of salary, were equalized for all employment level grades and capped at a full year’s salary for the voluntary applicants. The remainder of the initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-22-000010:notes:350]
2021 Charges

[0000068505-22-000010:notes:351]
During 2021, the Company recorded net reorganization of business charges of $32 million, including $8 million of charges in Costs of sales and $24 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $32 million were charges of $42 million for employee separation costs, partially offset by $10 million of reversals of accruals no longer needed.

[0000068505-22-000010:notes:352]
The following table displays the net charges incurred by segment:

[0000068505-22-000010:notes:353]
| Year ended December 31 | 2021 |
| Products and Systems Integration | $ | 25 |  |
| Software and Services | 7 |  |
|  | $ | 32 |  |

[0000068505-22-000010:notes:354]
Reorganization of Businesses Accruals

[0000068505-22-000010:notes:355]
| Accruals atJanuary 1, 2021 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31, 2021 |
| $ | 79 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | (77) |  |  | $ | 34 |  |

[0000068505-22-000010:notes:356]
Employee Separation Costs

[0000068505-22-000010:notes:357]
At January 1, 2021, the Company had an accrual of $79 million for employee separation costs. The 2021 additional charges of $42 million include severance costs for approximately 600 employees, of which 400 were direct employees and 200 were indirect employees. The adjustments of $10 million reflect reversals of accruals no longer needed. The $77 million used in 2021 reflects cash payments to severed employees. The remaining accrual of $34 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2021, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 100 employees to be separated in 2022.

[0000068505-22-000010:notes:358]
2020 Charges

[0000068505-22-000010:notes:359]
During 2020, the Company recorded net reorganization of business charges of $86 million, including $29 million of charges in Costs of sales and $57 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $86 million were charges of $100 million for employee separation costs and $2 million for exit costs, partially offset by $16 million of reversals of accruals no longer needed.

[0000068505-22-000010:notes:360]
| Year ended December 31 | 2020 |
| Products and Systems Integration | $ | 69 |  |
| Software and Services | 17 |  |
|  | $ | 86 |  |

[0000068505-22-000010:notes:361]
| Accruals atJanuary 1, 2020 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31, 2020 |
| $ | 78 |  |  | $ | 102 |  |  | $ | (16) |  |  | $ | (85) |  |  | $ | 79 |  |

[0000068505-22-000010:notes:362]
At January 1, 2020, the Company had an accrual of $78 million for employee separation costs. The additional 2020 charges of $102 million represent severance costs for approximately an additional 1,200 employees, of which 800 were direct employees and 400 were indirect employees. The adjustments of $16 million reflect reversals of accruals no longer needed. The $85 million used in 2020 reflects cash payments to severed employees. The remaining accrual of $79 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2020.

[0000068505-22-000010:notes:363]
2019 Charges

[0000068505-22-000010:notes:364]
During 2019, the Company recorded net reorganization of business charges of $57 million, including $17 million of charges in Costs of sales and $40 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $57 million are charges of $64 million for employee separation costs and $5 million of charges for exit costs, partially offset by $12 million of reversals for accruals no longer needed.

[0000068505-22-000010:notes:365]
| Year ended December 31 | 2019 |
| Products and Systems integration | $ | 45 |  |
| Software and Services | 12 |  |
|  | $ | 57 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-22-000010:notes:366]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-22-000010:notes:367]
Recent Acquisitions

[0000068505-22-000010:notes:368]
On December 16, 2021, the Company acquired 911 Datamaster, an NG911 data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces Motorola Solutions’ commitment to being a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. As the purchase accounting is not yet complete, the Company recognized $36 million of goodwill, representing the excess of the purchase price over acquired net liabilities of $1 million as of December 31, 2021. The final allocation of purchase consideration among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change. The goodwill is deductible for tax purposes. The business is a part of the Software and Services segment.

[0000068505-22-000010:notes:369]
On October 29, 2021, the Company acquired Envysion, a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video Security and Access Control. The Company recognized $80 million of goodwill, $37 million of identifiable intangible assets, and $7 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $26 million of customer relationships, $6 million of developed technology, and $5 million of trade names that will be amortized over a period of fifteen, four, and nine years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-22-000010:notes:370]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments of up to $40 million based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. The Company estimated there will be no payout related to the earn-out payments. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The Company recognized $234 million of goodwill, $73 million of identifiable intangible assets, and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $57 million of developed technology and $16 million of customer relationships that will be amortized over a period of sixteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-22-000010:notes:371]
On August 28, 2020, the Company acquired Callyo, a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing Command Center Software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The Company recognized $38 million of goodwill, $31 million of identifiable intangible assets, and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $27 million of customer relationships and $4 million of developed technology that will be amortized over a period of fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-22-000010:notes:372]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $38 million of goodwill, $30 million of identifiable intangible assets, and $39 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the third quarter of 2021.

[0000068505-22-000010:notes:373]
On June 16, 2020, the Company acquired IndigoVision for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Access Control technology, providing enhanced geographical reach across a wider customer base. The Company recognized $18 million of goodwill, $22 million of identifiable intangible assets, and $5 million of net liabilities.  The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting was completed as of the second quarter of 2021.

[0000068505-22-000010:notes:374]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The Company recognized $23 million of goodwill, $10 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $8 million of customer relationships and $2 million of developed technology that will be amortized over a period of twelve years and three years, respectively. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-22-000010:notes:375]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The Company recognized $28 million of goodwill, $7 million of intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset of $7 million was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-22-000010:notes:376]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million in cash, net of cash acquired. The acquisition enhances the Company's Video Security and Access Control technology by adding data to the Company’s existing LPR database within the Software and Services segment. The Company recognized $54 million of goodwill, $28 million of identifiable intangible assets, and $3 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $22 million of customer relationships and $6 million of developed technology and will be amortized over a period of sixteen years and five years, respectively. The purchase accounting was completed as of the fourth quarter of 2020.

[0000068505-22-000010:notes:377]
On July 11, 2019, the Company acquired WatchGuard, a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's Video Security and Access Control technology. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $156 million of goodwill, $63 million of identifiable intangible assets, and $31 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of developed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting was completed as of the third quarter of 2020.

[0000068505-22-000010:notes:378]
On March 11, 2019, the Company acquired Avtec, a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of developed technology and $21 million of customer relationship intangibles and will be amortized over a period of fifteen years. The purchase accounting was completed as of the third quarter of 2019.

[0000068505-22-000010:notes:379]
On January 7, 2019, the Company announced that it acquired VaaS, a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of developed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of fifteen years. The purchase accounting was completed as of the first quarter of 2020.

[0000068505-22-000010:notes:380]
The results of operations for these acquisitions have been included in the Company’s Consolidated Statements of Operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-22-000010:notes:381]
Intangible Assets

[0000068505-22-000010:notes:382]
Amortized intangible assets are comprised of the following:

[0000068505-22-000010:notes:383]
|  | 2021 |  | 2020 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Developed technology | $ | 828 |  |  | $ | 278 |  |  | $ | 766 |  |  | $ | 210 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,367 |  |  | 836 |  |  | 1,335 |  |  | 685 |  |
| Other intangibles | 82 |  |  | 58 |  |  | 78 |  |  | 50 |  |
|  | $ | 2,279 |  |  | $ | 1,174 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-22-000010:notes:384]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $236 million, $215 million, and $208 million for the years ended December 31, 2021, 2020, and 2019, respectively. As of December 31, 2021, future amortization expense is estimated to be $238 million in 2022, $129 million in 2023, $99 million in 2024, $88 million in 2025, and $81 million in 2026.

[0000068505-22-000010:notes:385]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-22-000010:notes:386]
|  | 2021 |  | 2020 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 766 |  |  | $ | 184 |  |  | $ | 692 |  |  | $ | 129 |  |
| Software and Services | 1,513 |  |  | 990 |  |  | 1,489 |  |  | 818 |  |
|  | $ | 2,279 |  |  | $ | 1,174 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-22-000010:notes:387]
Goodwill

[0000068505-22-000010:notes:388]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2020 to December 31, 2021:

[0000068505-22-000010:notes:389]
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2020 | $ | 973 |  |  | $ | 1,094 |  |  | $ | 2,067 |  |
| Goodwill acquired | 46 |  |  | 100 |  |  | 146 |  |
| Foreign currency translation | — |  |  | 6 |  |  | 6 |  |
| Balance as of December 31, 2020 | $ | 1,019 |  |  | $ | 1,200 |  |  | $ | 2,219 |  |
| Goodwill acquired | 218 |  |  | 131 |  |  | 349 |  |
| Purchase accounting adjustments | (1) |  |  | (1) |  |  | (2) |  |
| Foreign currency translation | — |  |  | (1) |  |  | (1) |  |
| Balance as of December 31, 2021 | $ | 1,236 |  |  | $ | 1,329 |  |  | $ | 2,565 |  |

[0000068505-22-000010:notes:390]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level which is an operating segment or one level below an operating segment.

[0000068505-22-000010:notes:391]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2021, 2020, and 2019. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2021, 2020, and 2019, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, a quantitative goodwill impairment test was not required and there was no impairment of goodwill.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-22-000010:notes:392]
Valuation and Qualifying Accounts
The following table presents the valuation and qualifying account activity for the years ended December 31, 2021, 2020, and 2019:

[0000068505-22-000010:notes:393]
|  | Balance atBeginning of Period |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atEnd of Period |
| 2021 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | $ | 75 |  |  | $ | 22 |  |  | $ | (26) |  |  | $ | (1) |  |  | $ | 70 |  |
| 2020 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 63 |  |  | 47 |  |  | (34) |  |  | (1) |  |  | 75 |  |
| 2019 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 51 |  |  | 39 |  |  | (26) |  |  | (1) |  |  | 63 |  |

[0000068505-22-000010:notes:394]
* Adjustments include translation adjustments
