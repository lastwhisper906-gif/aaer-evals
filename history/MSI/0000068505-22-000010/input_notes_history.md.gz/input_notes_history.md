# MSI note change history — 0000068505-21-000021 → 0000068505-21-000027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000068505-21-000027:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As of the third quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.
  (was, 2021-08-05, similarity 0.9964):
[0000068505-21-000021:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As of the second quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.

- added (2021-11-04):
[0000068505-21-000027:note_history:2]
On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. Subsequent to quarter end, on October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

- added (2021-11-04):
[0000068505-21-000027:note_history:3]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties are briefing a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal.

- changed (2021-11-04):
[0000068505-21-000027:note_history:4]
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.
  (was, 2021-08-05, similarity 0.6476):
[0000068505-21-000021:note_history:4]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest, although the precise amount of interest owed to the Company by Hytera is still to be determined by the Court. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award.
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000068505-21-000027:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of October 2, 2021 and for the three and nine months ended October 2, 2021 and September 26, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2021-08-05, similarity 0.939):
[0000068505-21-000021:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of July 3, 2021 and for the three and six months ended July 3, 2021 and June 27, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2021-11-04):
[0000068505-21-000027:note_history:6]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three and nine months ended October 2, 2021 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2021-08-05, similarity 0.8176):
[0000068505-21-000021:note_history:6]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three and six months ended July 3, 2021 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2021-11-04):
[0000068505-21-000027:note_history:7]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control, and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended October 2, 2021.
  (was, 2021-08-05, similarity 0.983):
[0000068505-21-000021:note_history:7]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control, and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) subsequent to quarter end on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended July 3, 2021.

- added (2021-11-04):
[0000068505-21-000027:note_history:8]
Subsequent to quarter end, on October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video Security and Access Control. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete.

- changed (2021-11-04):
[0000068505-21-000027:note_history:9]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2021-08-05, similarity 0.8531):
[0000068505-21-000021:note_history:9]
Subsequent to quarter end, on July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000068505-21-000027:note_history:10]
|  | October 2, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 8 |  |  | 18 |  |
|  | 5,695 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (6) |  |  | (12) |  |
| Long-term debt | $ | 5,687 |  |  | $ | 5,163 |  |
  (was, 2021-08-05, similarity 0.9931):
[0000068505-21-000021:note_history:10]
|  | July 3, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 999 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 11 |  |  | 18 |  |
|  | 5,697 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (9) |  |  | (12) |  |
| Long-term debt | $ | 5,686 |  |  | $ | 5,163 |  |

- changed (2021-11-04):
[0000068505-21-000027:note_history:11]
In May of 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of its outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.
  (was, 2021-08-05, similarity 0.9957):
[0000068505-21-000021:note_history:11]
On May 24, 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of its outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. 
After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- changed (2021-11-04):
[0000068505-21-000027:note_history:12]
As of October 2, 2021, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 2, 2021.
  (was, 2021-08-05, similarity 0.9897):
[0000068505-21-000021:note_history:12]
As of July 3, 2021, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 3, 2021.

- changed (2021-11-04):
[0000068505-21-000027:note_history:13]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of October 2, 2021 the Company had no outstanding debt under the commercial paper program.
  (was, 2021-08-05, similarity 0.9364):
[0000068505-21-000021:note_history:13]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 3, 2021 the Company had no outstanding debt under the commercial paper program.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000068505-21-000027:note_history:14]
|  | October 2, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 8 |  |  | 18 |  |
|  | 5,695 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (6) |  |  | (12) |  |
| Long-term debt | $ | 5,687 |  |  | $ | 5,163 |  |
  (was, 2021-08-05, similarity 0.9931):
[0000068505-21-000021:note_history:14]
|  | July 3, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 999 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 11 |  |  | 18 |  |
|  | 5,697 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (9) |  |  | (12) |  |
| Long-term debt | $ | 5,686 |  |  | $ | 5,163 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0000068505-21-000027:note_history:15]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 2, 2021 and September 26, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2021-11-04):
[0000068505-21-000027:note_history:16]
|  | Three Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |  | $ | 863 |  |  | $ | 405 |  |  | $ | 1,268 |  |
| International | 333 |  |  | 325 |  |  | 658 |  |  | 300 |  |  | 300 |  |  | 600 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |  | $ | 989 |  |  | $ | 510 |  |  | $ | 1,499 |  |
| Video Security and Access Control | 214 |  |  | 102 |  |  | 316 |  |  | 174 |  |  | 77 |  |  | 251 |  |
| Command Center Software | — |  |  | 133 |  |  | 133 |  |  | — |  |  | 118 |  |  | 118 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |  | $ | 733 |  |  | $ | 637 |  |  | $ | 1,370 |  |
| Indirect | 487 |  |  | 79 |  |  | 566 |  |  | 430 |  |  | 68 |  |  | 498 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
  (was, 2021-08-05, similarity 0.9809):
[0000068505-21-000021:note_history:16]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |  | $ | 719 |  |  | $ | 374 |  |  | $ | 1,093 |  |
| International | 329 |  |  | 330 |  |  | 659 |  |  | 249 |  |  | 276 |  |  | 525 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |  | $ | 836 |  |  | $ | 481 |  |  | $ | 1,317 |  |
| Video Security and Access Control | 212 |  |  | 94 |  |  | 306 |  |  | 132 |  |  | 52 |  |  | 184 |  |
| Command Center Software | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 117 |  |  | 117 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |  | $ | 634 |  |  | $ | 611 |  |  | $ | 1,245 |  |
| Indirect | 492 |  |  | 67 |  |  | 559 |  |  | 334 |  |  | 39 |  |  | 373 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |

- changed (2021-11-04):
[0000068505-21-000027:note_history:17]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |  | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 3,476 |  |
| International | 935 |  |  | 970 |  |  | 1,905 |  |  | 794 |  |  | 871 |  |  | 1,665 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |  | $ | 2,685 |  |  | $ | 1,480 |  |  | $ | 4,165 |  |
| Video Security and Access Control | 590 |  |  | 284 |  |  | 874 |  |  | 439 |  |  | 196 |  |  | 635 |  |
| Command Center Software | — |  |  | 387 |  |  | 387 |  |  | — |  |  | 341 |  |  | 341 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |  | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 3,877 |  |
| Indirect | 1,390 |  |  | 214 |  |  | 1,604 |  |  | 1,116 |  |  | 148 |  |  | 1,264 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
  (was, 2021-08-05, similarity 0.9774):
[0000068505-21-000021:note_history:17]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |  | $ | 1,467 |  |  | $ | 742 |  |  | $ | 2,209 |  |
| International | 602 |  |  | 645 |  |  | 1,247 |  |  | 494 |  |  | 570 |  |  | 1,064 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |  | $ | 1,696 |  |  | $ | 970 |  |  | $ | 2,666 |  |
| Video Security and Access Control | 377 |  |  | 182 |  |  | 559 |  |  | 265 |  |  | 119 |  |  | 384 |  |
| Command Center Software | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 223 |  |  | 223 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |  | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 2,507 |  |
| Indirect | 903 |  |  | 135 |  |  | 1,038 |  |  | 686 |  |  | 80 |  |  | 766 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |

- removed (2021-11-04):
[0000068505-21-000021:note_history:18]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 3, 2021 and June 27, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0000068505-21-000027:note_history:19]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 2, 2021 and September 26, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2021-11-04):
[0000068505-21-000027:note_history:20]
|  | Three Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |  | $ | 863 |  |  | $ | 405 |  |  | $ | 1,268 |  |
| International | 333 |  |  | 325 |  |  | 658 |  |  | 300 |  |  | 300 |  |  | 600 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |  | $ | 989 |  |  | $ | 510 |  |  | $ | 1,499 |  |
| Video Security and Access Control | 214 |  |  | 102 |  |  | 316 |  |  | 174 |  |  | 77 |  |  | 251 |  |
| Command Center Software | — |  |  | 133 |  |  | 133 |  |  | — |  |  | 118 |  |  | 118 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |  | $ | 733 |  |  | $ | 637 |  |  | $ | 1,370 |  |
| Indirect | 487 |  |  | 79 |  |  | 566 |  |  | 430 |  |  | 68 |  |  | 498 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
  (was, 2021-08-05, similarity 0.9809):
[0000068505-21-000021:note_history:20]
|  | Three Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |  | $ | 719 |  |  | $ | 374 |  |  | $ | 1,093 |  |
| International | 329 |  |  | 330 |  |  | 659 |  |  | 249 |  |  | 276 |  |  | 525 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |  | $ | 836 |  |  | $ | 481 |  |  | $ | 1,317 |  |
| Video Security and Access Control | 212 |  |  | 94 |  |  | 306 |  |  | 132 |  |  | 52 |  |  | 184 |  |
| Command Center Software | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 117 |  |  | 117 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |  | $ | 634 |  |  | $ | 611 |  |  | $ | 1,245 |  |
| Indirect | 492 |  |  | 67 |  |  | 559 |  |  | 334 |  |  | 39 |  |  | 373 |  |
|  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,618 |  |

- changed (2021-11-04):
[0000068505-21-000027:note_history:21]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |  | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 3,476 |  |
| International | 935 |  |  | 970 |  |  | 1,905 |  |  | 794 |  |  | 871 |  |  | 1,665 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |  | $ | 2,685 |  |  | $ | 1,480 |  |  | $ | 4,165 |  |
| Video Security and Access Control | 590 |  |  | 284 |  |  | 874 |  |  | 439 |  |  | 196 |  |  | 635 |  |
| Command Center Software | — |  |  | 387 |  |  | 387 |  |  | — |  |  | 341 |  |  | 341 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |  | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 3,877 |  |
| Indirect | 1,390 |  |  | 214 |  |  | 1,604 |  |  | 1,116 |  |  | 148 |  |  | 1,264 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
  (was, 2021-08-05, similarity 0.9774):
[0000068505-21-000021:note_history:21]
|  | Six Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |  | $ | 1,467 |  |  | $ | 742 |  |  | $ | 2,209 |  |
| International | 602 |  |  | 645 |  |  | 1,247 |  |  | 494 |  |  | 570 |  |  | 1,064 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |  | $ | 1,696 |  |  | $ | 970 |  |  | $ | 2,666 |  |
| Video Security and Access Control | 377 |  |  | 182 |  |  | 559 |  |  | 265 |  |  | 119 |  |  | 384 |  |
| Command Center Software | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 223 |  |  | 223 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |  | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 2,507 |  |
| Indirect | 903 |  |  | 135 |  |  | 1,038 |  |  | 686 |  |  | 80 |  |  | 766 |  |
|  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 3,273 |  |

- changed (2021-11-04):
[0000068505-21-000027:note_history:22]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of October 2, 2021 was $7.1 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of October 2, 2021, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.5 billion was from Software and Services performance obligations that were not yet satisfied as of October 2, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2021-08-05, similarity 0.9846):
[0000068505-21-000021:note_history:22]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 3, 2021 was $7.1 billion. A total of $3.3 billion was from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion was from Software and Services performance obligations that were not yet satisfied as of July 3, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2021-11-04):
[0000068505-21-000027:note_history:23]
| (In millions) | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,196 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 1,030 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,538 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 309 |  |  | 283 |  |  |  |  |  |
  (was, 2021-08-05, similarity 0.979):
[0000068505-21-000021:note_history:23]
| (In millions) | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,169 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 757 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,416 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 296 |  |  | 283 |  |  |  |  |  |

- added (2021-11-04):
[0000068505-21-000027:note_history:24]
Revenue recognized during the three months ended October 2, 2021 which was previously included in Contract liabilities as of July 3, 2021 was $472 million, compared to $349 million of revenue recognized during the three months ended September 26, 2020 which was previously included in Contract liabilities as of June 27, 2020. Revenue recognized during the nine months ended October 2, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $946 million, compared to $807 million recognized during the nine months ended September 26, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $2 million and $15 million was reversed during the three and nine months ended October 2, 2021, respectively, related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $12 million and $48 million of reversals for the three and nine months ended September 26, 2020, respectively.

- changed (2021-11-04):
[0000068505-21-000027:note_history:25]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended October 2, 2021 and September 26, 2020.
  (was, 2021-08-05, similarity 0.9072):
[0000068505-21-000021:note_history:25]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 3, 2021 and June 27, 2020.

- changed (2021-11-04):
[0000068505-21-000027:note_history:26]
| (In millions) | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 26 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 113 |  |  | 105 |  |  |  |  |  |
  (was, 2021-08-05, similarity 0.9688):
[0000068505-21-000021:note_history:26]
| (In millions) | July 3, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 30 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 110 |  |  | 105 |  |  |  |  |  |

- changed (2021-11-04):
[0000068505-21-000027:note_history:27]
Amortization of non-current contract cost assets was $12 million and $37 million for the three and nine months ended October 2, 2021, respectively, and $13 million and $35 million for the three and nine months ended September 26, 2020, respectively
  (was, 2021-08-05, similarity 0.7588):
[0000068505-21-000021:note_history:27]
Amortization of non-current contract cost assets was $12 million and $25 million for the three and six months ended July 3, 2021, respectively, and $11 million and $22 million for the three and six months ended June 27, 2020, respectively

- removed (2021-11-04):
[0000068505-21-000021:note_history:28]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 3, 2021 and June 27, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- removed (2021-11-04):
[0000068505-21-000021:note_history:29]
Revenue recognized during the three months ended July 3, 2021 which was previously included in Contract liabilities as of April 3, 2021 was $483 million, compared to $370 million of revenue recognized during the three months ended June 27, 2020 which was previously included in Contract liabilities as of March 28, 2020. Revenue recognized during the six months ended July 3, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $705 million, compared to $631 million recognized during the six months ended June 27, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $10 million and $15 million was reversed during the three and six months ended July 3, 2021, respectively, related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $12 million and $34 million of reversals for the three and six months ended June 27, 2020, respectively.
