# MSI 8-K — 0000068505-22-000006 filed 2022-02-09

## item codes, every 8-K on or before 2022-02-16

- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2022-02-16

- none on or before 2022-02-16

## item 2.02 — earnings release, exhibit 99.1

[0000068505-22-000006:8k_2_02:1]
EX-99.1
2
msiq42021pressrelease.htm
EX-99.1

[0000068505-22-000006:8k_2_02:2]
Document

[0000068505-22-000006:8k_2_02:3]
Exhibit 99.1

[0000068505-22-000006:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-22-000006:8k_2_02:5]
Company Achieves Record Full-Year Sales, Earnings, Operating Cash Flow and Backlog

[0000068505-22-000006:8k_2_02:6]
•Sales of $2.3 billion, up 2% from Q4 in the prior year; up 10% for full year

[0000068505-22-000006:8k_2_02:7]
•Software and Services segment sales grew 8% in Q4; up 13% for full year

[0000068505-22-000006:8k_2_02:8]
•Record backlog of $13.6 billion, up $1.3 billion in Software and Services and up $886 million in Products and Systems Integration from a year ago

[0000068505-22-000006:8k_2_02:9]
•GAAP Q4 earnings per share (EPS) of $2.30; $7.17 for full year

[0000068505-22-000006:8k_2_02:10]
•Non-GAAP Q4 EPS* of $2.85; $9.15 for full year, up 19% from a year ago

[0000068505-22-000006:8k_2_02:11]
•Record full year operating cash flow of $1.8 billion

[0000068505-22-000006:8k_2_02:12]
CHICAGO - Feb. 9, 2022 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2021. Click here for a printable news release and financial tables.

[0000068505-22-000006:8k_2_02:13]
“Our 2021 results, highlighted by strong growth in both segments, reflect the criticality of our solutions and our team's unwavering execution in a challenging and fluid supply chain environment,” said Greg Brown, chairman and CEO, Motorola Solutions. “Our record backlog and continued robust demand positions us very well for sustained strong growth this year and beyond.”

[0000068505-22-000006:8k_2_02:14]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-22-000006:8k_2_02:15]
|  | Fourth Quarter | Full Year |
|  | Q4 2021 | Q4 2020 | % Change | 2021 | 2020 | % Change |
| Sales | $2,320 | $2,273 | 2 | % | $8,171 | $7,414 | 10 | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $549 | $555 | (1) | % | $1,667 | $1,383 | 21 | % |
| % of Sales | 23.7 | % | 24.4 | % |  | 20.4 | % | 18.7 | % |  |
| EPS | $2.30 | 2.37 |  | (3) | % | $7.17 | $5.45 | 32 | % |
| Non-GAAP* |  |  |  |  |  |  |
| Operating Earnings | $670 | $667 | — | % | $2,117 | $1,835 | 15 | % |
| % of Sales | 28.9 | % | 29.3 | % |  | 25.9 | % | 24.8 | % |  |
| EPS | $2.85 | $2.86 | — | % | $9.15 | $7.69 | 19 | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $1,495 | $1,510 | (1) | % | $5,033 | $4,634 | 9 | % |
| GAAP Operating Earnings | $320 | $351 | (9) | % | $760 | $656 | 16 | % |
| % of Sales | 21.4 | % | 23.2 | % |  | 15.1 | % | 14.2 | % |  |
| Non-GAAP Operating Earnings* | $378 | $408 | (7) | % | $976 | $880 | 11 | % |
| % of Sales | 25.3 | % | 27.0 | % |  | 19.4 | % | 19.0 | % |  |
| Software and Services Segment |  |  |  |  |  |  |
| Sales | $825 | $763 | 8 | % | $3,138 | $2,780 | 13 | % |
| GAAP Operating Earnings | $229 | $204 | 12 | % | $907 | $727 | 25 | % |
| % of Sales | 27.8 | % | 26.7 | % |  | 28.9 | % | 26.2 | % |  |
| Non-GAAP Operating Earnings* | $292 | $259 | 13 | % | $1,141 | $955 | 19 | % |
| % of Sales | 35.4 | % | 33.9 | % |  | 36.4 | % | 34.3 | % |  |

[0000068505-22-000006:8k_2_02:16]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.55 for Q4 and $1.98 for FY per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-22-000006:8k_2_02:17]
1

[0000068505-22-000006:8k_2_02:18]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-22-000006:8k_2_02:19]
•Revenue - Fourth-quarter sales were $2.3 billion, up 2% from the year-ago quarter driven by growth in North America. The Products and Systems Integration segment declined 1% primarily due to supply constraints. Growth in video security and public safety land mobile radio (LMR), was offset by a decline in professional and commercial radio (PCR). The Software and Services segment grew 8% driven by growth in LMR services, video security and command center software. Sales from acquisitions were $10 million, and the impact of favorable currency rates was $6 million.

[0000068505-22-000006:8k_2_02:20]
•Operating margin - GAAP operating margin was 23.7% of sales, down from 24.4% in the year-ago quarter. Non-GAAP operating margin was 28.9% of sales, down from 29.3% in the year-ago quarter. The decline in operating margin was primarily due to higher operating expenses related to incentive compensation and acquisitions as well as lower sales in the Products and Systems Integration segment, partially offset by higher sales and improved operating leverage in the Software and Services segment.

[0000068505-22-000006:8k_2_02:21]
•Taxes - The GAAP effective tax rate was 22.4%, compared to 20.9% in the year-ago quarter. The non-GAAP effective tax rate was 22.3%, compared to 21.0% in the year-ago quarter. The year-over-year increase in the tax rate was primarily due to higher benefits from stock-based compensation in the year-ago quarter.

[0000068505-22-000006:8k_2_02:22]
•Cash flow - The company generated $703 million in operating cash in both the current and year-ago quarters. Free cash flow was $635 million, compared with $637 million in the year-ago quarter.

[0000068505-22-000006:8k_2_02:23]
•Capital allocation - During the quarter, the company repurchased $119 million of its common stock, paid $120 million in dividends and incurred $68 million in capital expenditures. Additionally, the company closed the acquisitions of Envysion and 911 Datamaster for $124 million and $35 million, net of cash acquired, respectively.

[0000068505-22-000006:8k_2_02:24]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-22-000006:8k_2_02:25]
•Revenue - Full-year sales were $8.2 billion, up 10% driven by growth in North America and International. The Products and Systems Integration segment grew 9% primarily due to higher sales of video security, public safety LMR products and PCR. The Software and Services segment grew 13% driven by growth in LMR services, video security and command center software. The impact of favorable currency rates was $130 million and sales from acquisitions was $120 million.

[0000068505-22-000006:8k_2_02:26]
•Operating margin - For the full year, GAAP operating margin was 20.4% of sales, compared to 18.7% for the prior year. The increase was primarily driven by higher sales, improved operating leverage, inclusive of higher incentive compensation, and lower reorganization charges in both segments. Non-GAAP operating margin was 25.9% of sales, compared to 24.8% for the prior year, driven by higher sales and improved operating leverage, inclusive of higher incentive compensation, in both segments.

[0000068505-22-000006:8k_2_02:27]
•Taxes - The 2021 GAAP effective tax rate was 19.5%, compared to 18.8% for the prior year. The non-GAAP effective tax rate was 21.0% compared to 20.0% in the previous year. The year-over-year increase in the tax rate was primarily driven by the higher benefit of discrete items, including benefits from stock-based compensation, booked in the prior year.

[0000068505-22-000006:8k_2_02:28]
•Cash flow - The company generated $1.8 billion in operating cash, compared to $1.6 billion in the prior year. Free cash flow was $1.6 billion, compared to $1.4 billion in the prior year. The increase in cash flow was driven by higher sales and earnings in the current year, partially offset by higher cash taxes paid in the current year.

[0000068505-22-000006:8k_2_02:29]
•Backlog - The company ended the year with record backlog of $13.6 billion, up $2.2 billion from the prior year. Software and Services segment backlog was up 15% or $1.3 billion, primarily driven by the U.K. Home Office decision to extend the Airwave network through 2026 and

[0000068505-22-000006:8k_2_02:30]
2

[0000068505-22-000006:8k_2_02:31]
growth in software and services contracts in North America. Products and Systems Integrations segment backlog was up 28% or $886 million driven by record LMR orders.

[0000068505-22-000006:8k_2_02:32]
•Capital allocation - In 2021, the company repurchased $528 million of its common stock at an average price of $208.41, paid $482 million in dividends and used $457 million for acquisitions. Additionally during the year, the company issued $850 million of new long-term debt, redeemed $324 million outstanding of its senior notes due 2023, entered into a new upsized $2.25 billion revolving credit facility and announced a $2 billion increase to the share repurchase program.

[0000068505-22-000006:8k_2_02:33]
NOTABLE WINS & ACHIEVEMENTS IN Q4

[0000068505-22-000006:8k_2_02:34]
Software and Services

[0000068505-22-000006:8k_2_02:35]
•$25 million P25 multi-year services contract with Cook County, IL

[0000068505-22-000006:8k_2_02:36]
•$17 million P25 multi-year software upgrade agreement for ICI Systems Authority in California

[0000068505-22-000006:8k_2_02:37]
•$17 million body-worn camera as-a-service order for the City of Houston, TX police department

[0000068505-22-000006:8k_2_02:38]
•$15 million P25 multi-year software upgrade agreement for Orange County, CA

[0000068505-22-000006:8k_2_02:39]
•$14 million additional body-worn camera order for the French MOI

[0000068505-22-000006:8k_2_02:40]
•$11 million command center software hybrid cloud order for North Carolina Department of Public Safety

[0000068505-22-000006:8k_2_02:41]
•27% growth in video security and access control software

[0000068505-22-000006:8k_2_02:42]
Products and Systems Integration

[0000068505-22-000006:8k_2_02:43]
•$98 million P25 upgrade order for the Commonwealth of Massachusetts

[0000068505-22-000006:8k_2_02:44]
•$94 million of APX NEXT device orders in North America

[0000068505-22-000006:8k_2_02:45]
•$68 million P25 device upgrade for the District of Columbia

[0000068505-22-000006:8k_2_02:46]
•$28 million P25 upgrade order for a large U.S. customer

[0000068505-22-000006:8k_2_02:47]
•$21 million fixed video security order for a large North America utility customer

[0000068505-22-000006:8k_2_02:48]
•$19 million additional TETRA order from the German MOD

[0000068505-22-000006:8k_2_02:49]
•$17 million TETRA device upgrade for a customer in Asia Pacific

[0000068505-22-000006:8k_2_02:50]
BUSINESS OUTLOOK

[0000068505-22-000006:8k_2_02:51]
•First-quarter 2022 - The company expects revenue growth of approximately 3% compared with the first quarter of 2021. The company expects non-GAAP earnings per share in the range of $1.53 to $1.59 per share. This assumes current foreign exchange rates, between 173 million and 174 million fully diluted shares, and an effective tax rate of approximately 17%.

[0000068505-22-000006:8k_2_02:52]
•Full-year 2022 - The company expects revenue growth of approximately 7% and non-GAAP earnings per share in the range of $9.80 to $9.95 per share. This assumes current foreign exchange rates, approximately 174 million fully diluted shares and a non-GAAP effective tax rate of 21% to 22%.

[0000068505-22-000006:8k_2_02:53]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP measurements in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-22-000006:8k_2_02:54]
3

[0000068505-22-000006:8k_2_02:55]
COVID-19

[0000068505-22-000006:8k_2_02:56]
The company continues to monitor the daily evolution of the COVID-19 pandemic, including the spread of the omicron variant, and adhere to its plans to keep its employees and customers healthy and safe, including encouraging office workers to work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings and using thermal scanning.

[0000068505-22-000006:8k_2_02:57]
Additionally, in September 2021, the President of the United States signed a series of executive orders, and related guidance was issued that, together, required certain employers to implement COVID-19 precautions, including mandatory COVID-19 vaccines for employees (subject to medical and religious exemptions). As a federal contractor, the company was required to implement a mandatory vaccine policy. In January 2022, in response to various legal challenges to these orders, the company suspended its requirement that its U.S. employees (subject to the exemptions described above) be vaccinated by February 9, 2022. The company continues to evaluate its internal policy and the potential impact of the executive orders and legal responses to such executive orders on its business.

[0000068505-22-000006:8k_2_02:58]
As the company progressed through 2021, its supply chain has been increasingly impacted by global issues related to the effects of the COVID-19 pandemic, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in the company's supply chain, as well as difficulties and delays in procuring certain semiconductor components. During the latter part of the fourth quarter of 2021, costs increased driven by delivery delays and the need to purchase semiconductor components from alternative sources, including brokers. The company anticipates increased costs to procure materials within the semiconductor market to continue into 2022, and currently estimates that this will add an additional $120 million of costs to 2022, of which the company expects $50 million in the first quarter. The company is closely monitoring its supply chain and has maintained an active dialogue, and in some cases developed plans, with key suppliers in an effort to mitigate supply chain risks or otherwise minimize the impact from those risks. The company will continue to actively manage its supply chain in an effort to prevent major delays in selling its products and services.

[0000068505-22-000006:8k_2_02:59]
Although the COVID-19 pandemic continued to introduce challenges throughout 2021, the company is encouraged by customer demand for its products and services. Specifically, in the Software and Services segment, with the largely recurring nature of the business and the company's strong backlog position, the company continues to expect that the impacts on net sales and operating margin will be limited throughout 2022. Within the Products and Systems Integration segment, while the company is encouraged by strong LMR backlog and the resiliency of the Video Security and Access Control technology that experienced growth in 2021, supply constraints continue to impact the company's LMR business and the company expects demand for its products will continue to out-pace its ability to obtain supply throughout 2022. In addition, in March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. The company experienced the positive impact of the ARPA funding on its business and results of operations during 2021 and anticipates that the ARPA will continue to have a positive impact throughout 2022.

[0000068505-22-000006:8k_2_02:60]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) on Wednesday, February 9. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-22-000006:8k_2_02:61]
4

[0000068505-22-000006:8k_2_02:62]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-22-000006:8k_2_02:63]
A comparison of results from operations is as follows:

[0000068505-22-000006:8k_2_02:64]
|  | Fourth Quarter | Full Year |
|  | 2021 | 2020 | 2021 | 2020 |
| Net sales | $2,320 | $2,273 | $8,171 | $7,414 |
| Gross margin | 1,183 |  | 1,146 |  | 4,040 |  | 3,608 |  |
| Operating earnings | 549 |  | 555 |  | 1,667 |  | 1,383 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | 401 |  | 412 |  | 1,245 |  | 949 |  |
| Diluted EPS from continuing operations | $2.30 | $2.37 | $7.17 | $5.45 |
| Weighted average diluted common shares outstanding | 174.2 |  | 173.5 |  | 173.6 |  | 174.1 |  |

[0000068505-22-000006:8k_2_02:65]
HIGHLIGHTED ITEMS

[0000068505-22-000006:8k_2_02:66]
The table below includes highlighted items, including share-based compensation expenses and intangible assets amortization expense, for the fourth quarter and full year of 2021.

[0000068505-22-000006:8k_2_02:67]
| (per diluted common share) | Q4 2021 | FY21 |
| GAAP EPS | $2.30 | $7.17 |
| Highlighted Items: |  |  |
| Intangible assets amortization expense | 0.26 |  | 1.08 |  |
| Share-based compensation expenses | 0.20 |  | 0.66 |  |
| Reorganization of business charges | 0.01 |  | 0.14 |  |
| Hytera-related legal expenses | 0.02 |  | 0.11 |  |
| Acquisition-related transaction fees | 0.05 |  | 0.09 |  |
| Loss from extinguishment of long-term debt | — |  | 0.08 |  |
| Operating lease asset impairments | 0.01 |  | 0.05 |  |
| Fair value adjustments to equity investments | 0.01 |  | 0.03 |  |
| Legal settlements | — |  | 0.01 |  |
| Sale of investments | (0.01) |  | (0.01) |  |
| Adjustments to uncertain tax positions | (0.03) |  | (0.10) |  |
| Release of valuation allowance on deferred tax assets | — |  | (0.20) |  |
| Impact of tax rate changes on deferred tax balances | 0.01 |  | 0.02 |  |
| Undistributed foreign earnings from prior periods | 0.02 |  | 0.02 |  |
| Non-GAAP EPS | $2.85 | $9.15 |

[0000068505-22-000006:8k_2_02:68]
5

[0000068505-22-000006:8k_2_02:69]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-22-000006:8k_2_02:70]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with GAAP.

[0000068505-22-000006:8k_2_02:71]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-22-000006:8k_2_02:72]
Free cash flow:  Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is also useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although its measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-22-000006:8k_2_02:73]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes non-GAAP organic revenue growth provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-22-000006:8k_2_02:74]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-22-000006:8k_2_02:75]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-22-000006:8k_2_02:76]
6

[0000068505-22-000006:8k_2_02:77]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the company on December 15, 2021 and, consistent with the company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  The Court also ordered the parties to jointly file by February 22, 2022, a proposed royalty agreement for the Court's review and approval.

[0000068505-22-000006:8k_2_02:78]
On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the company with respect to several of the company's post-trial motions, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award. On September 29, 2021, the company filed two additional motions with the Court, requesting the Court to reconsider its order denying the company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the company's judgment award, or, in the alternative, hold Hytera in contempt. On October 15, 2021, the Court granted the company’s request for $34.2 million in attorneys’ fees against Hytera.

[0000068505-22-000006:8k_2_02:79]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination.

[0000068505-22-000006:8k_2_02:80]
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property.

[0000068505-22-000006:8k_2_02:81]
Management typically considers legal expenses associated with defending our intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both our GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. We anticipate further expenses associated with Hytera-related litigation; however, we believe that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate our business. In addition, if any contingent or actual gain associated with the Hytera litigation is recognized in the future, it will be similarly excluded from our non-GAAP operating income. We believe after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates our ongoing underlying business performance.

[0000068505-22-000006:8k_2_02:82]
For comparative purposes, $5 million, or $0.02 of earnings per share, net of tax, of Hytera-related legal expense was included in our fourth quarter 2019 non-GAAP operating earnings and $43 million, or $0.20 of earnings per share, net of tax, was included in 2019 non-GAAP operating earnings.

[0000068505-22-000006:8k_2_02:83]
7

[0000068505-22-000006:8k_2_02:84]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-22-000006:8k_2_02:85]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-22-000006:8k_2_02:86]
FORWARD LOOKING STATEMENTS

[0000068505-22-000006:8k_2_02:87]
8

[0000068505-22-000006:8k_2_02:88]
sufficient amount of materials, parts, and components, as well as software and services, to meet the demands of our customers; (xvi) risks related to our large, multi-year system and services contracts; (xvii) the inability of our products to meet our customers’ expectations or regulatory or industry standards; (xviii) impact of current global economic and political conditions in the markets in which we operate; (xix) impact of returns on pension and retirement plan assets and interest rate changes; (xx) inability to attract and retain senior management and key employees; (xxi) impact of product regulatory and safety, consumer, worker safety and environmental laws; (xxii) inability to access the capital markets for financing on acceptable terms and conditions; and (xxiii) impact of tax matters. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-22-000006:8k_2_02:89]
ABOUT MOTOROLA SOLUTIONS

[0000068505-22-000006:8k_2_02:90]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio communications, video security & access control and command center software, bolstered by managed & support services, create an integrated technology ecosystem to help make communities safer and help businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-22-000006:8k_2_02:91]
MEDIA CONTACT

[0000068505-22-000006:8k_2_02:92]
Alexandra Reynolds

[0000068505-22-000006:8k_2_02:93]
Motorola Solutions

[0000068505-22-000006:8k_2_02:94]
+1 312-965-3968

[0000068505-22-000006:8k_2_02:95]
alexandra.reynolds@motorolasolutions.com

[0000068505-22-000006:8k_2_02:96]
INVESTOR CONTACT

[0000068505-22-000006:8k_2_02:97]
Tim Yocum

[0000068505-22-000006:8k_2_02:98]
Motorola Solutions

[0000068505-22-000006:8k_2_02:99]
+1 847-576-6899

[0000068505-22-000006:8k_2_02:100]
Tim.Yocum@motorolasolutions.com

[0000068505-22-000006:8k_2_02:101]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2022 Motorola Solutions, Inc. All rights reserved.

[0000068505-22-000006:8k_2_02:102]
9

[0000068505-22-000006:8k_2_02:103]
GAAP-1

[0000068505-22-000006:8k_2_02:104]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:105]
Consolidated Statements of Operations

[0000068505-22-000006:8k_2_02:106]
(In millions, except per share amount)

[0000068505-22-000006:8k_2_02:107]
|  | Three Months Ended |
|  | December 31, 2021 |  | December 31, 2020 |
| Net sales from products | $ | 1,358 |  |  | $ | 1,326 |  |
| Net sales from services | 962 |  |  | 947 |  |
| Net sales | 2,320 |  |  | 2,273 |  |
| Costs of products sales | 589 |  |  | 568 |  |
| Costs of services sales | 548 |  |  | 559 |  |
| Costs of sales | 1,137 |  |  | 1,127 |  |
| Gross margin | 1,183 |  |  | 1,146 |  |
| Selling, general and administrative expenses | 368 |  |  | 343 |  |
| Research and development expenditures | 189 |  |  | 182 |  |
| Other charges | 13 |  |  | 9 |  |
| Intangibles amortization | 64 |  |  | 57 |  |
| Operating earnings | 549 |  |  | 555 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (54) |  |  | (53) |  |
| Gains (losses) on sales of investments and businesses, net | 1 |  |  | (1) |  |
| Other, net | 22 |  |  | 21 |  |
| Total other expense | (31) |  |  | (33) |  |
| Net earnings before income taxes | 518 |  |  | 522 |  |
| Income tax expense | 116 |  |  | 109 |  |
| Net earnings | 402 |  |  | 413 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 401 |  |  | $ | 412 |  |
| Earnings per common share: |  |  |  |
| Basic: | $ | 2.38 |  |  | $ | 2.43 |  |
| Diluted: | $ | 2.30 |  |  | $ | 2.37 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 168.8 |  | 169.5 |
| Diluted | 174.2 |  | 173.5 |

[0000068505-22-000006:8k_2_02:108]
|  | Percentage of Net Sales* |
| Net sales from products | 58.5 | % |  | 58.3 | % |
| Net sales from services | 41.5 | % |  | 41.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 43.4 | % |  | 42.8 | % |
| Costs of services sales | 57.0 | % |  | 59.0 | % |
| Costs of sales | 49.0 | % |  | 49.6 | % |
| Gross margin | 51.0 | % |  | 50.4 | % |
| Selling, general and administrative expenses | 15.9 | % |  | 15.1 | % |
| Research and development expenditures | 8.1 | % |  | 8.0 | % |
| Other charges | 0.6 | % |  | 0.4 | % |
| Intangibles amortization | 2.8 | % |  | 2.5 | % |
| Operating earnings | 23.7 | % |  | 24.4 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.3) | % |  | (2.3) | % |
| Gains (losses) on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 0.9 | % |  | 0.9 | % |
| Total other expense | (1.3) | % |  | (1.5) | % |
| Net earnings before income taxes | 22.3 | % |  | 23.0 | % |
| Income tax expense | 5.0 | % |  | 4.8 | % |
| Net earnings | 17.3 | % |  | 18.2 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 17.3 | % |  | 18.1 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-22-000006:8k_2_02:109]
10

[0000068505-22-000006:8k_2_02:110]
GAAP-2

[0000068505-22-000006:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:112]
Consolidated Statements of Operations

[0000068505-22-000006:8k_2_02:113]
(In millions, except per share amounts)

[0000068505-22-000006:8k_2_02:114]
|  | Years Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2019 |
| Net sales from products | $ | 4,606 |  |  | $ | 4,087 |  |  | $ | 4,746 |  |
| Net sales from services | 3,565 |  |  | 3,327 |  |  | 3,141 |  |
| Net sales | 8,171 |  |  | 7,414 |  |  | 7,887 |  |
| Costs of products sales | 2,104 |  |  | 1,872 |  |  | 2,049 |  |
| Costs of services sales | 2,027 |  |  | 1,934 |  |  | 1,907 |  |
| Costs of sales | 4,131 |  |  | 3,806 |  |  | 3,956 |  |
| Gross margin | 4,040 |  |  | 3,608 |  |  | 3,931 |  |
| Selling, general and administrative expenses | 1,353 |  |  | 1,293 |  |  | 1,403 |  |
| Research and development expenditures | 734 |  |  | 686 |  |  | 687 |  |
| Other charges | 50 |  |  | 31 |  |  | 52 |  |
| Intangibles amortization | 236 |  |  | 215 |  |  | 208 |  |
| Operating earnings | 1,667 |  |  | 1,383 |  |  | 1,581 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (208) |  |  | (220) |  |  | (220) |  |
| Gains (losses) on sales of investments and businesses, net | 1 |  |  | (2) |  |  | 5 |  |
| Other, net | 92 |  |  | 13 |  |  | (365) |  |
| Total other expense | (115) |  |  | (209) |  |  | (580) |  |
| Net earnings before income taxes | 1,552 |  |  | 1,174 |  |  | 1,001 |  |
| Income tax expense | 302 |  |  | 221 |  |  | 130 |  |
| Net earnings | 1,250 |  |  | 953 |  |  | 871 |  |
| Less: Earnings attributable to non-controlling interests | 5 |  |  | 4 |  |  | 3 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 1,245 |  |  | $ | 949 |  |  | $ | 868 |  |
| Earnings per common share: |  |  |  |  |  |
| Basic: | $ | 7.36 |  |  | $ | 5.58 |  |  | $ | 5.21 |  |
| Diluted: | $ | 7.17 |  |  | $ | 5.45 |  |  | $ | 4.95 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 169.2 |  |  | 170.0 |  |  | 166.6 |  |
| Diluted | 173.6 |  |  | 174.1 |  |  | 175.6 |  |

[0000068505-22-000006:8k_2_02:115]
|  | Percentage of Net Sales* |
| Net sales from products | 56.4 | % |  | 55.1 | % |  | 60.2 | % |
| Net sales from services | 43.6 | % |  | 44.9 | % |  | 39.8 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 45.7 | % |  | 45.8 | % |  | 43.2 | % |
| Costs of services sales | 56.9 | % |  | 58.1 | % |  | 60.7 | % |
| Costs of sales | 50.6 | % |  | 51.3 | % |  | 50.2 | % |
| Gross margin | 49.4 | % |  | 48.7 | % |  | 49.8 | % |
| Selling, general and administrative expenses | 16.6 | % |  | 17.4 | % |  | 17.8 | % |
| Research and development expenditures | 9.0 | % |  | 9.3 | % |  | 8.7 | % |
| Other charges | 0.6 | % |  | 0.4 | % |  | 0.7 | % |
| Intangibles amortization | 2.9 | % |  | 2.9 | % |  | 2.6 | % |
| Operating earnings | 20.4 | % |  | 18.7 | % |  | 20.0 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (2.5) | % |  | (3.0) | % |  | (2.8) | % |
| Gains (losses) on sales of investments and businesses, net | — | % |  | — | % |  | 0.1 | % |
| Other, net | 1.1 | % |  | 0.2 | % |  | (4.6) | % |
| Total other expense | (1.4) | % |  | (2.8) | % |  | (7.4) | % |
| Net earnings before income taxes | 19.0 | % |  | 15.8 | % |  | 12.7 | % |
| Income tax expense | 3.7 | % |  | 3.0 | % |  | 1.6 | % |
| Net earnings | 15.3 | % |  | 12.9 | % |  | 11.0 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 15.2 | % |  | 12.8 | % |  | 11.0 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-22-000006:8k_2_02:116]
11

[0000068505-22-000006:8k_2_02:117]
GAAP-3

[0000068505-22-000006:8k_2_02:118]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:119]
Consolidated Balance Sheets

[0000068505-22-000006:8k_2_02:120]
(In millions)

[0000068505-22-000006:8k_2_02:121]
|  |  | December 31, 2021 |  | December 31, 2020 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,874 |  |  | $ | 1,254 |  |
| Accounts receivable, net |  | 1,386 |  |  | 1,390 |  |
| Contract assets |  | 1,105 |  |  | 933 |  |
| Inventories, net |  | 788 |  |  | 508 |  |
| Other current assets |  | 259 |  |  | 242 |  |
| Total current assets |  | 5,412 |  |  | 4,327 |  |
| Property, plant and equipment, net |  | 1,042 |  |  | 1,022 |  |
| Operating lease assets |  | 382 |  |  | 468 |  |
| Investments |  | 209 |  |  | 158 |  |
| Deferred income taxes |  | 916 |  |  | 966 |  |
| Goodwill |  | 2,565 |  |  | 2,219 |  |
| Intangible assets, net |  | 1,105 |  |  | 1,234 |  |
| Other assets |  | 558 |  |  | 482 |  |
| Total assets |  | $ | 12,189 |  |  | $ | 10,876 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |  |
| Current portion of long-term debt |  | $ | 5 |  |  | $ | 12 |  |
| Accounts payable |  | 851 |  |  | 612 |  |
| Contract liabilities |  | 1,650 |  |  | 1,554 |  |
| Accrued liabilities |  | 1,557 |  |  | 1,311 |  |
| Total current liabilities |  | 4,063 |  |  | 3,489 |  |
| Long-term debt |  | 5,688 |  |  | 5,163 |  |
| Operating lease liabilities |  | 313 |  |  | 402 |  |
| Other liabilities |  | 2,148 |  |  | 2,363 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (40) |  |  | (558) |  |
| Non-controlling interests |  | 17 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) |  | $ | 12,189 |  |  | $ | 10,876 |  |

[0000068505-22-000006:8k_2_02:122]
12

[0000068505-22-000006:8k_2_02:123]
GAAP-4

[0000068505-22-000006:8k_2_02:124]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:125]
Consolidated Statements of Cash Flows

[0000068505-22-000006:8k_2_02:126]
(In millions)

[0000068505-22-000006:8k_2_02:127]
|  | Three Months Ended |
|  | December 31, 2021 |  | December 31, 2020 |
| Operating |  |  |  |
| Net earnings | $ | 402 |  |  | $ | 413 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 113 |  |  | 109 |  |
| Non-cash other charges (income) | 9 |  |  | 15 |  |
| Share-based compensation expense | 35 |  |  | 29 |  |
| Losses (gains) on sales of investments and businesses, net | (1) |  |  | 1 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (186) |  |  | (222) |  |
| Inventories | (185) |  |  | (16) |  |
| Other current assets and contract assets | (69) |  |  | 168 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 617 |  |  | 263 |  |
| Other assets and liabilities | (64) |  |  | (8) |  |
| Deferred income taxes | 32 |  |  | (49) |  |
| Net cash provided by operating activities | 703 |  |  | 703 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (161) |  |  | (4) |  |
| Proceeds from sales of investments | 12 |  |  | 3 |  |
| Capital expenditures | (68) |  |  | (66) |  |
| Net cash used for investing activities | (217) |  |  | (67) |  |
| Financing |  |  |  |
| Repayment of debt | (2) |  |  | (4) |  |
| Repayment of unsecured revolving credit facility draw | — |  |  | (200) |  |
| Issuances of common stock | 3 |  |  | 49 |  |
| Purchases of common stock | (131) |  |  | (171) |  |
| Payment of dividends | (120) |  |  | (109) |  |
| Net cash used for financing activities | (250) |  |  | (435) |  |
| Effect of exchange rate changes on cash and cash equivalents | (15) |  |  | 46 |  |
| Net increase in cash and cash equivalents | 221 |  |  | 247 |  |
| Cash and cash equivalents, beginning of period | 1,653 |  |  | 1,007 |  |
| Cash and cash equivalents, end of period | $ | 1,874 |  |  | $ | 1,254 |  |
| Reconciliation of Net cash provided by operating activities to Free cash flow |  |  |
| Net cash provided by operating activities | $ | 703 |  |  | $ | 703 |  |
| Capital expenditures | (68) |  |  | (66) |  |
| Free cash flow* | $ | 635 |  |  | $ | 637 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-22-000006:8k_2_02:128]
13

[0000068505-22-000006:8k_2_02:129]
GAAP-5

[0000068505-22-000006:8k_2_02:130]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:131]
Consolidated Statements of Cash Flows

[0000068505-22-000006:8k_2_02:132]
(In millions)

[0000068505-22-000006:8k_2_02:133]
|  | Years Ended |
|  | December 31, 2021 |  | December 31, 2020 |  | December 31, 2019 |
| Operating |  |  |  |  |  |
| Net earnings | $ | 1,250 |  |  | $ | 953 |  |  | $ | 871 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 438 |  |  | 409 |  |  | 394 |  |
| Non-cash other charges (income) | 3 |  |  | (13) |  |  | 35 |  |
| U.S. pension settlement loss | — |  |  | — |  |  | 359 |  |
| Gain from the extinguishment of 2.00% senior convertible notes | — |  |  | — |  |  | (4) |  |
| Share-based compensation expense | 129 |  |  | 129 |  |  | 118 |  |
| Losses (gains) on sales of investments and businesses, net | (1) |  |  | 2 |  |  | (5) |  |
| Losses from the extinguishment of long-term debt | 18 |  |  | 56 |  |  | 50 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | 3 |  |  | 90 |  |  | (79) |  |
| Inventories | (284) |  |  | (14) |  |  | (74) |  |
| Other current assets and contract assets | (205) |  |  | 167 |  |  | 49 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 578 |  |  | (116) |  |  | 198 |  |
| Other assets and liabilities | (126) |  |  | (25) |  |  | (5) |  |
| Deferred income taxes | 34 |  |  | (25) |  |  | (84) |  |
| Net cash provided by operating activities | 1,837 |  |  | 1,613 |  |  | 1,823 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (521) |  |  | (287) |  |  | (709) |  |
| Proceeds from sales of investments | 16 |  |  | 11 |  |  | 16 |  |
| Capital expenditures | (243) |  |  | (217) |  |  | (248) |  |
| Proceeds from sales of property, plant and equipment | 6 |  |  | 56 |  |  | 7 |  |
| Net cash used for investing activities | (742) |  |  | (437) |  |  | (934) |  |
| Financing |  |  |  |  |  |
| Net proceeds from issuance of debt | 844 |  |  | 892 |  |  | 1,804 |  |
| Repayment of debt | (353) |  |  | (914) |  |  | (2,039) |  |
| Proceeds from unsecured revolving credit facility draw | — |  |  | 800 |  |  | — |  |
| Repayment of unsecured revolving credit facility draw | — |  |  | (800) |  |  | — |  |
| Revolving credit facility renewal fees | (7) |  |  | — |  |  | — |  |
| Issuances of common stock | 102 |  |  | 108 |  |  | 114 |  |
| Purchases of common stock | (528) |  |  | (612) |  |  | (315) |  |
| Settlement of conversion premium on 2.00% senior convertible notes | — |  |  | — |  |  | (326) |  |
| Payment of dividends | (482) |  |  | (436) |  |  | (379) |  |
| Payment of dividends to non-controlling interest | (5) |  |  | (4) |  |  | (3) |  |
| Net cash used for financing activities | (429) |  |  | (966) |  |  | (1,144) |  |
| Effect of exchange rate changes on cash and cash equivalents | (46) |  |  | 43 |  |  | (1) |  |
| Net increase (decrease) in cash and cash equivalents | 620 |  |  | 253 |  |  | (256) |  |
| Cash and cash equivalents, beginning of period | 1,254 |  |  | 1,001 |  |  | 1,257 |  |
| Cash and cash equivalents, end of period | $ | 1,874 |  |  | $ | 1,254 |  |  | $ | 1,001 |  |
| Reconciliation of Net cash provided by operating activities to Free cash flow |  |  |  |  |
| Net cash provided by operating activities | $ | 1,837 |  |  | $ | 1,613 |  |  | $ | 1,823 |  |
| Capital expenditures | (243) |  |  | (217) |  |  | (248) |  |
| Free cash flow* | 1,594 |  |  | 1,396 |  |  | 1,575 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |  |  |

[0000068505-22-000006:8k_2_02:134]
14

[0000068505-22-000006:8k_2_02:135]
GAAP-6

[0000068505-22-000006:8k_2_02:136]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:137]
Segment Information

[0000068505-22-000006:8k_2_02:138]
(In millions)

[0000068505-22-000006:8k_2_02:139]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 1,495 |  |  | $ | 1,510 |  |  | (1) | % |
| Software and Services | 825 |  |  | 763 |  |  | 8 | % |
| Total Motorola Solutions | $ | 2,320 |  |  | $ | 2,273 |  |  | 2 | % |
|  | Years Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 5,033 |  |  | $ | 4,634 |  |  | 9 | % |
| Software and Services | 3,138 |  |  | 2,780 |  |  | 13 | % |
| Total Motorola Solutions | $ | 8,171 |  |  | $ | 7,414 |  |  | 10 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 320 |  |  | $ | 351 |  |  | (9) | % |
| Software and Services | 229 |  |  | 204 |  |  | 12 | % |
| Total Motorola Solutions | $ | 549 |  |  | $ | 555 |  |  | (1) | % |
|  | Years Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 760 |  |  | $ | 656 |  |  | 16 | % |
| Software and Services | 907 |  |  | 727 |  |  | 25 | % |
| Total Motorola Solutions | $ | 1,667 |  |  | $ | 1,383 |  |  | 21 | % |

[0000068505-22-000006:8k_2_02:140]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  |  |
| Products and Systems Integration | 21.4 | % |  | 23.2 | % |  |  |
| Software and Services | 27.8 | % |  | 26.7 | % |  |  |
| Total Motorola Solutions | 23.7 | % |  | 24.4 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  |  |
| Products and Systems Integration | 15.1 | % |  | 14.2 | % |  |  |
| Software and Services | 28.9 | % |  | 26.2 | % |  |  |
| Total Motorola Solutions | 20.4 | % |  | 18.7 | % |  |  |

[0000068505-22-000006:8k_2_02:141]
15

[0000068505-22-000006:8k_2_02:142]
Non-GAAP-1

[0000068505-22-000006:8k_2_02:143]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:144]
Non-GAAP Adjustments (Intangible Assets Amortization Expense, Share-Based Compensation Expenses, and Other Highlighted Items)

[0000068505-22-000006:8k_2_02:145]
(In millions)

[0000068505-22-000006:8k_2_02:146]
| Q1 2021 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 58 |  |  | $ | 13 |  |  | $ | 45 |  |  | $ | 0.26 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 29 |  |  | 6 |  |  | 23 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 16 |  |  | 3 |  |  | 13 |  |  | 0.07 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 7 |  |  | 1 |  |  | 6 |  |  | 0.03 |  |
| Hytera-related legal expenses |  | SG&A |  | 2 |  |  | 1 |  |  | 1 |  |  | 0.01 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | (5) |  |  | (1) |  |  | (4) |  |  | (0.02) |  |
| Adjustments to uncertain tax positions |  | Other income (expense) and Income tax expense |  | (1) |  |  | 4 |  |  | (5) |  |  | (0.03) |  |
| Total impact on Net earnings |  |  |  | $ | 107 |  |  | $ | 27 |  |  | $ | 80 |  |  | $ | 0.46 |  |
| Q2 2021 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 58 |  |  | $ | 9 |  |  | $ | 49 |  |  | $ | 0.28 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 31 |  |  | 2 |  |  | 29 |  |  | 0.17 |  |
| Loss from extinguishment of long-term debt |  | Other income (expense) |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 9 |  |  | 2 |  |  | 7 |  |  | 0.04 |  |
| Hytera-related legal expenses |  | SG&A |  | 8 |  |  | 1 |  |  | 7 |  |  | 0.04 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 3 |  |  | — |  |  | 3 |  |  | 0.02 |  |
| Legal settlements |  | Other charges (income) |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Impact of tax rate changes on deferred tax balances |  | Income tax expense |  | — |  |  | (2) |  |  | 2 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | (8) |  |  | (2) |  |  | (6) |  |  | (0.03) |  |
| Adjustments to uncertain tax positions |  | Other income (expense) and Income tax expense |  | $ | (9) |  |  | $ | (1) |  |  | $ | (8) |  |  | $ | (0.05) |  |
| Release of valuation allowance on deferred tax assets |  | Income tax expense |  | $ | — |  |  | $ | 33 |  |  | $ | (33) |  |  | $ | (0.19) |  |
| Total impact on Net earnings |  |  |  | $ | 113 |  |  | $ | 47 |  |  | $ | 66 |  |  | $ | 0.38 |  |
| Q3 2021 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 56 |  |  | $ | 9 |  |  | $ | 47 |  |  | $ | 0.27 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 34 |  |  | 6 |  |  | 28 |  |  | 0.16 |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Hytera-related legal expenses |  | SG&A |  | 8 |  |  | 1 |  |  | 7 |  |  | 0.04 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 4 |  |  | — |  |  | 4 |  |  | 0.02 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 2 |  |  | — |  |  | 2 |  |  | 0.02 |  |
| Adjustments to uncertain tax positions |  | Other income (expense) and Income tax expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Release of valuation allowance on deferred tax assets |  | Income tax expense |  | — |  |  | 1 |  |  | (1) |  |  | (0.01) |  |
| Total impact on Net earnings |  |  |  | $ | 123 |  |  | $ | 21 |  |  | $ | 102 |  |  | $ | 0.59 |  |

[0000068505-22-000006:8k_2_02:147]
16

[0000068505-22-000006:8k_2_02:148]
| Q4 2021 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 64 |  |  | $ | 18 |  |  | $ | 46 |  |  | $ | 0.26 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 35 |  |  | 1 |  |  | 34 |  |  | 0.20 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 9 |  |  | — |  |  | 9 |  |  | 0.05 |  |
| Hytera-related legal expenses |  | SG&A |  | 8 |  |  | 4 |  |  | 4 |  |  | 0.02 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 3 |  |  | 2 |  |  | 1 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | 3 |  |  | 2 |  |  | 1 |  |  | 0.01 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Sale of investments |  | (Gains) or losses on sales of investments and businesses, net |  | (1) |  |  | — |  |  | (1) |  |  | (0.01) |  |
| Adjustments to uncertain tax positions |  | Other income (expense) and Income tax expense |  | (1) |  |  | 4 |  |  | (5) |  |  | (0.03) |  |
| Impact of tax rate changes on deferred tax balances |  | Income tax expense |  | — |  |  | (2) |  |  | 2 |  |  | 0.01 |  |
| Undistributed foreign earnings from prior periods |  | Income tax expense |  | — |  |  | (3) |  |  | 3 |  |  | 0.02 |  |
| Total impact on Net earnings |  |  |  | $ | 123 |  |  | $ | 27 |  |  | $ | 96 |  |  | $ | 0.55 |  |
| FY 2021 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 236 |  |  | $ | 49 |  |  | $ | 187 |  |  | $ | 1.08 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 129 |  |  | 15 |  |  | 114 |  |  | 0.66 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 32 |  |  | 7 |  |  | 25 |  |  | 0.14 |  |
| Hytera-related legal expenses |  | SG&A |  | 26 |  |  | 7 |  |  | 19 |  |  | 0.11 |  |
| Loss from extinguishment of long-term debt |  | Other income (expense) |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 15 |  |  | — |  |  | 15 |  |  | 0.09 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 10 |  |  | 2 |  |  | 8 |  |  | 0.05 |  |
| Fair value adjustments to equity investments |  | Other income (expense) |  | 8 |  |  | 3 |  |  | 5 |  |  | 0.03 |  |
| Legal settlements |  | Other charges (income) |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Sale of investments |  | (Gains) or losses on sales of investments and businesses, net |  | (1) |  |  | — |  |  | (1) |  |  | (0.01) |  |
| Adjustments to uncertain tax positions |  | Other income (expense) and Income tax expense |  | (10) |  |  | 7 |  |  | (17) |  |  | (0.10) |  |
| Release of valuation allowance on deferred tax assets |  | Income tax expense |  | — |  |  | 34 |  |  | (34) |  |  | (0.20) |  |
| Impact of tax rate changes on deferred tax balances |  | Income tax expense |  | — |  |  | (4) |  |  | 4 |  |  | 0.02 |  |
| Undistributed foreign earnings from prior periods |  | Income tax expense |  | — |  |  | (3) |  |  | 3 |  |  | 0.02 |  |
| Total impact on Net earnings |  |  |  | $ | 466 |  |  | $ | 122 |  |  | $ | 344 |  |  | $ | 1.98 |  |

[0000068505-22-000006:8k_2_02:149]
17

[0000068505-22-000006:8k_2_02:150]
Non-GAAP-2

[0000068505-22-000006:8k_2_02:151]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:152]
Non-GAAP Segment Information

[0000068505-22-000006:8k_2_02:153]
(In millions)

[0000068505-22-000006:8k_2_02:154]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 1,495 |  |  | $ | 1,510 |  |  | (1) | % |
| Software and Services | 825 |  |  | 763 |  |  | 8 | % |
| Total Motorola Solutions | $ | 2,320 |  |  | $ | 2,273 |  |  | 2 | % |
|  | Years Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 5,033 |  |  | $ | 4,634 |  |  | 9 | % |
| Software and Services | 3,138 |  |  | 2,780 |  |  | 13 | % |
| Total Motorola Solutions | $ | 8,171 |  |  | $ | 7,414 |  |  | 10 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 378 |  |  | $ | 408 |  |  | (7) | % |
| Software and Services | 292 |  |  | 259 |  |  | 13 | % |
| Total Motorola Solutions | $ | 670 |  |  | $ | 667 |  |  | — | % |
|  | Years Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Products and Systems Integration | $ | 976 |  |  | $ | 880 |  |  | 11 | % |
| Software and Services | 1,141 |  |  | 955 |  |  | 19 | % |
| Total Motorola Solutions | $ | 2,117 |  |  | $ | 1,835 |  |  | 15 | % |

[0000068505-22-000006:8k_2_02:155]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  |  |
| Products and Systems Integration | 25.3 | % |  | 27.0 | % |  |  |
| Software and Services | 35.4 | % |  | 33.9 | % |  |  |
| Total Motorola Solutions | 28.9 | % |  | 29.3 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2021 |  | December 31, 2020 |  |  |
| Products and Systems Integration | 19.4 | % |  | 19.0 | % |  |  |
| Software and Services | 36.4 | % |  | 34.3 | % |  |  |
| Total Motorola Solutions | 25.9 | % |  | 24.8 | % |  |  |

[0000068505-22-000006:8k_2_02:156]
18

[0000068505-22-000006:8k_2_02:157]
Non-GAAP-3

[0000068505-22-000006:8k_2_02:158]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000006:8k_2_02:159]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-22-000006:8k_2_02:160]
(In millions)

[0000068505-22-000006:8k_2_02:161]
| Q1 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,773 |  |  | $ | 1,015 |  |  | $ | 758 |  |
| Operating earnings ("OE") |  | $ | 298 |  |  | $ | 77 |  |  | $ | 221 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 58 |  |  | 13 |  |  | 45 |  |
| Share-based compensation expenses |  | 29 |  |  | 22 |  |  | 7 |  |
| Reorganization of business charges |  | 16 |  |  | 12 |  |  | 4 |  |
| Operating lease asset impairment |  | 7 |  |  | 5 |  |  | 2 |  |
| Hytera-related legal expenses |  | 2 |  |  | 2 |  |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 113 |  |  | 54 |  |  | 59 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 411 |  |  | $ | 131 |  |  | $ | 280 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 16.8 | % |  | 7.6 | % |  | 29.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 23.2 | % |  | 12.9 | % |  | 36.9 | % |

[0000068505-22-000006:8k_2_02:162]
| Q2 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,971 |  |  | $ | 1,198 |  |  | $ | 773 |  |
| Operating earnings ("OE") |  | $ | 370 |  |  | $ | 139 |  |  | $ | 231 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 58 |  |  | 13 |  |  | 45 |  |
| Share-based compensation expenses |  | 31 |  |  | 24 |  |  | 7 |  |
| Reorganization of business charges |  | 9 |  |  | 7 |  |  | 2 |  |
| Hytera-related legal expenses |  | 8 |  |  | 8 |  |  | — |  |
| Legal settlements |  | 3 |  |  | 2 |  |  | 1 |  |
| Acquisition-related transaction fees |  | 3 |  |  | 1 |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  | 112 |  |  | 55 |  |  | 57 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 482 |  |  | $ | 194 |  |  | $ | 288 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 18.8 | % |  | 11.6 | % |  | 29.9 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.4 | % |  | 16.2 | % |  | 37.2 | % |

[0000068505-22-000006:8k_2_02:163]
19

[0000068505-22-000006:8k_2_02:164]
| Q3 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 2,107 |  |  | $ | 1,325 |  |  | $ | 782 |  |
| Operating earnings ("OE") |  | $ | 451 |  |  | $ | 224 |  |  | $ | 227 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 56 |  |  | 13 |  |  | 43 |  |
| Share-based compensation expenses |  | 34 |  |  | 25 |  |  | 9 |  |
| Hytera-related legal expenses |  | 8 |  |  | 8 |  |  | — |  |
| Reorganization of business charges |  | 4 |  |  | 3 |  |  | 1 |  |
| Acquisition-related transaction fees |  | 2 |  |  | — |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  | 104 |  |  | 49 |  |  | 55 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 555 |  |  | $ | 273 |  |  | $ | 282 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 21.4 | % |  | 16.9 | % |  | 29.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 26.3 | % |  | 20.6 | % |  | 36.0 | % |

[0000068505-22-000006:8k_2_02:165]
| Q4 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 2,320 |  |  | $ | 1,495 |  |  | $ | 825 |  |
| Operating earnings ("OE") |  | $ | 549 |  |  | $ | 320 |  |  | $ | 229 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 64 |  |  | 15 |  |  | 49 |  |
| Share-based compensation expenses |  | 35 |  |  | 28 |  |  | 7 |  |
| Acquisition-related transaction fees |  | 9 |  |  | 3 |  |  | 6 |  |
| Hytera-related legal expenses |  | 8 |  |  | 8 |  |  | — |  |
| Reorganization of business charges |  | 3 |  |  | 3 |  |  | — |  |
| Operating lease asset impairment |  | 3 |  |  | 2 |  |  | 1 |  |
| Sale of investments |  | (1) |  |  | (1) |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 121 |  |  | 58 |  |  | 63 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 670 |  |  | $ | 378 |  |  | $ | 292 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 23.7 | % |  | 21.4 | % |  | 27.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.9 | % |  | 25.3 | % |  | 35.4 | % |

[0000068505-22-000006:8k_2_02:166]
| FY 2021 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 8,171 |  |  | $ | 5,033 |  |  | $ | 3,138 |  |
| Operating earnings ("OE") |  | $ | 1,667 |  |  | $ | 760 |  |  | $ | 907 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 236 |  |  | 54 |  |  | 182 |  |
| Share-based compensation expenses |  | 129 |  |  | 99 |  |  | 30 |  |
| Reorganization of business charges |  | 32 |  |  | 25 |  |  | 7 |  |
| Hytera-related legal expenses |  | 26 |  |  | 26 |  |  | — |  |
| Acquisition-related transaction fees |  | 15 |  |  | 4 |  |  | 11 |  |
| Operating lease asset impairment |  | 10 |  |  | 7 |  |  | 3 |  |
| Legal settlements |  | 3 |  |  | 2 |  |  | 1 |  |
| Sale of investments |  | (1) |  |  | (1) |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 450 |  |  | 216 |  |  | 234 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 2,117 |  |  | $ | 976 |  |  | $ | 1,141 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 20.4 | % |  | 15.1 | % |  | 28.9 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 25.9 | % |  | 19.4 | % |  | 36.4 | % |

[0000068505-22-000006:8k_2_02:167]
20

[0000068505-22-000006:8k_2_02:168]
Non-GAAP-4

[0000068505-22-000006:8k_2_02:169]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Revenue to Non-GAAP Organic Revenue |
| (In millions) |

[0000068505-22-000006:8k_2_02:170]
|  |  | Three Months Ended |  |  |
|  |  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Net sales |  | $ | 2,320 |  |  | $ | 2,273 |  |  | 2 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 10 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,310 |  |  | $ | 2,273 |  |  | 2 | % |

[0000068505-22-000006:8k_2_02:171]
|  |  | Year Ended |  |  |
|  |  | December 31, 2021 |  | December 31, 2020 |  | % Change |
| Net sales |  | $ | 8,171 |  |  | $ | 7,414 |  |  | 10 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 152 |  |  | 32 |  |  |  |
| Organic revenue |  | $ | 8,019 |  |  | $ | 7,382 |  |  | 9 | % |

[0000068505-22-000006:8k_2_02:172]
21
