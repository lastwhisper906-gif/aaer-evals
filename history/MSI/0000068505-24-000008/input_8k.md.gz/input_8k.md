# MSI 8-K — 0000068505-24-000004 filed 2024-02-08

## item codes, every 8-K on or before 2024-02-15

- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2024-02-15

- none on or before 2024-02-15

## item 2.02 — earnings release, exhibit 99.1

[0000068505-24-000004:8k_2_02:1]
EX-99.1
2
msiq42023pressrelease.htm
EX-99.1

[0000068505-24-000004:8k_2_02:2]
Document

[0000068505-24-000004:8k_2_02:3]
Exhibit 99.1

[0000068505-24-000004:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-24-000004:8k_2_02:5]
Company Achieves Record Q4 and Full-Year Sales and Earnings Per Share

[0000068505-24-000004:8k_2_02:6]
•Sales of $2.8 billion, up 5% from Q4 in the prior year; up 10% for full year

[0000068505-24-000004:8k_2_02:7]
◦Products and Systems Integration sales grew 4% in Q4; up 9% for full year

[0000068505-24-000004:8k_2_02:8]
◦Software and Services sales grew 7% in Q4; up 10% for full year

[0000068505-24-000004:8k_2_02:9]
•Generated $1.2 billion of operating cash flow in Q4; $2.0 billion for full year, up 12%

[0000068505-24-000004:8k_2_02:10]
•GAAP Q4 earnings per share (EPS) of $3.47, up 1%; $9.93 for full year, up 25%

[0000068505-24-000004:8k_2_02:11]
•Non-GAAP Q4 EPS* of $3.90, up 8% versus a year ago; $11.95 for full year, up 15%

[0000068505-24-000004:8k_2_02:12]
•Ending backlog of $14.3 billion, inclusive of record Products and Systems Integration backlog

[0000068505-24-000004:8k_2_02:13]
•Announced $2.0 billion increase to the share repurchase authorization

[0000068505-24-000004:8k_2_02:14]
•Acquired IPVideo, creator of the HALO Smart Sensor

[0000068505-24-000004:8k_2_02:15]
CHICAGO - February 8, 2024 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2023.

[0000068505-24-000004:8k_2_02:16]
“2023 was an exceptional year, with record sales, earnings and operating cash flow,” said Greg Brown, Chairman and CEO of Motorola Solutions. “The strong growth we achieved reflects the continued robust demand for our safety and security solutions that help protect people, property and places.

[0000068505-24-000004:8k_2_02:17]
The momentum of our business is strong and I’m very pleased with our position for another year of revenue and earnings growth in 2024.”

[0000068505-24-000004:8k_2_02:18]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-24-000004:8k_2_02:19]
|  | Fourth Quarter | Full Year |
|  | Q4 2023 | Q4 2022 | % Change | 2023 | 2022 | % Change |
| Sales | $2,848 | $2,706 | 5 | % | $9,978 | $9,112 | 10 | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $738 | $692 | 7 | % | $2,294 | $1,661 | 38 | % |
| % of Sales | 25.9 | % | 25.6 | % |  | 23.0 | % | 18.2 | % |  |
| EPS | $3.47 | $3.43 | 1 | % | $9.93 | $7.93 | 25 | % |
| Non-GAAP* |  |  |  |  |  |  |
| Operating Earnings | $870 | $822 | 6 | % | $2,784 | $2,368 | 18 | % |
| % of Sales | 30.5 | % | 30.4 | % |  | 27.9 | % | 26.0 | % |  |
| EPS | $3.90 | $3.60 | 8 | % | $11.95 | $10.36 | 15 | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $1,890 | $1,810 | 4 | % | $6,242 | $5,728 | 9 | % |
| GAAP Operating Earnings | $492 | $454 | 8 | % | $1,244 | $913 | 36 | % |
| % of Sales | 26.0 | % | 25.1 | % |  | 19.9 | % | 15.9 | % |  |
| Non-GAAP Operating Earnings* | $567 | $514 | 10 | % | $1,518 | $1,172 | 30 | % |
| % of Sales | 30.0 | % | 28.4 | % |  | 24.3 | % | 20.5 | % |  |
| Software and Services Segment |  |  |  |  |  |  |
| Sales | $958 | $896 | 7 | % | $3,736 | $3,384 | 10 | % |
| GAAP Operating Earnings | $246 | $238 | 3 | % | $1,050 | $748 | 40 | % |
| % of Sales | 25.7 | % | 26.6 | % |  | 28.1 | % | 22.1 | % |  |
| Non-GAAP Operating Earnings* | $303 | $308 | (2) | % | $1,266 | $1,196 | 6 | % |
| % of Sales | 31.6 | % | 34.4 | % |  | 33.9 | % | 35.3 | % |  |

[0000068505-24-000004:8k_2_02:20]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.43 for Q4 and $2.02 for FY per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-24-000004:8k_2_02:21]
1

[0000068505-24-000004:8k_2_02:22]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-24-000004:8k_2_02:23]
•Revenue - Fourth-quarter sales were $2.8 billion, up 5% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $17 million and the impact of favorable foreign currency rates was $16 million. The Products and Systems Integration segment grew 4% due to growth in land mobile radio (LMR) and video security and access control (Video). The Software and Services segment grew 7% driven by growth in Video, command center and LMR, inclusive of the reduction in Airwave revenue related to the pricing control in the United Kingdom’s Competition and Markets Authority’s (the “CMA”) remedies order.

[0000068505-24-000004:8k_2_02:24]
•Operating margin - GAAP operating margin was 25.9% of sales, up from 25.6% in the year-ago quarter. Non-GAAP operating margin was 30.5% of sales, up from 30.4% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margin was primarily driven by higher sales and lower direct material costs, partially offset by the revenue reduction for Airwave.

[0000068505-24-000004:8k_2_02:25]
•Taxes - The GAAP effective tax rate was 15.7%, up from 11.0% in the year-ago quarter driven primarily by higher benefits in the prior year related to a partial release of a valuation allowance recorded on the U.S. foreign tax credits carryforward. The non-GAAP effective tax rate was 20.3%, down from 21.2% in the year-ago quarter, driven by higher benefits from stock-based compensation in the current year.

[0000068505-24-000004:8k_2_02:26]
•Cash flow - Operating and free cash flow were both $1.2 billion during the quarter driven by higher earnings and partially offset by higher cash taxes.

[0000068505-24-000004:8k_2_02:27]
•Capital allocation - During the quarter, the company paid $146 million in dividends, repurchased $117 million of its common stock and incurred $81 million in capital expenditures. Additionally, the company closed the acquisition of IPVideo, creator of the HALO Smart Sensor, for $170 million in cash, net of cash acquired.

[0000068505-24-000004:8k_2_02:28]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-24-000004:8k_2_02:29]
•Revenue - Full-year sales were $10.0 billion, up 10% driven by growth in North America and International. The Products and Systems Integration segment grew 9% driven by higher sales of LMR and Video. The Software and Services segment grew 10% driven by growth in LMR services, command center and Video, partially offset by the revenue reduction for Airwave. Revenue from acquisitions was $98 million and the impact of unfavorable foreign currency rates was $38 million.

[0000068505-24-000004:8k_2_02:30]
•Operating margin - For the full year, GAAP operating margin was 23.0% of sales, compared to 18.2% for the prior year. The increase was primarily driven by lower direct material costs, higher sales, the $147 million fixed asset impairment charge related to the exit from the Emergency Services Network ("ESN") services contract in the U.K. recorded in the prior year and lower intangible amortization expense in the current year, partially offset by the revenue reduction for Airwave. Non-GAAP operating margin was 27.9% of sales, up from 26.0% in the prior year, driven by lower direct material costs, higher sales and improved operating leverage, partially offset by the revenue reduction for Airwave, higher employee incentives, higher expenses associated with acquired businesses and mix.

[0000068505-24-000004:8k_2_02:31]
•Taxes - The 2023 GAAP effective tax rate was 20.1%, up from 9.8% in the prior year driven primarily by a discrete deferred tax benefit recognized in 2022 as a result of an intra-group transfer of certain intellectual property rights. In addition, the company generated higher benefits in the prior year from a partial release of the valuation allowance recorded on the U.S. foreign tax credit carryforward and higher stock-based compensation. The non-GAAP effective tax rate was 21.9%, up from 20.1% in the previous year, primarily driven by lower benefits from stock-based compensation in the current year.

[0000068505-24-000004:8k_2_02:32]
•Cash flow - The company generated $2.0 billion in operating cash flow, up 12% versus the prior year. Free cash flow was $1.8 billion, up 14% versus the prior year. The increase in both operating and free cash flow was primarily driven by higher earnings generated in the current year partially offset by higher cash taxes.

[0000068505-24-000004:8k_2_02:33]
2

[0000068505-24-000004:8k_2_02:34]
•Capital allocation - In 2023, the company repurchased $804 million of its common stock at an average price of $278.56 per share and paid $589 million in dividends. Additionally, the company closed the acquisition of IPVideo, creator of the HALO Smart Sensor, for $170 million in cash, net of cash acquired.

[0000068505-24-000004:8k_2_02:35]
•Backlog - The company ended the year with backlog of $14.3 billion, down $88 million from the prior year. Products and Systems Integrations segment backlog was up 2% or $93 million driven by continued strong demand in North America. Software and Services segment backlog was down 2% or $181 million, driven by the reduction related to the Airwave price control and revenue recognition for Airwave and ESN, partially offset by growth in multi-year software and services contracts in both North America and International and $113 million of favorable foreign currency rates.

[0000068505-24-000004:8k_2_02:36]
NOTABLE WINS & ACHIEVEMENTS IN Q4

[0000068505-24-000004:8k_2_02:37]
Software and Services

[0000068505-24-000004:8k_2_02:38]
•$330M+ LMR managed services renewal through 2034 for Denmark’s nationwide public safety communications network

[0000068505-24-000004:8k_2_02:39]
•$48M command center order for the City of Chicago Office of Public Safety Administration

[0000068505-24-000004:8k_2_02:40]
•$20M LMR service agreement for Spokane Regional Emergency Communications, WA

[0000068505-24-000004:8k_2_02:41]
•$19M mobile video order for a U.S. customer

[0000068505-24-000004:8k_2_02:42]
•$10M command center order for the City and County of San Francisco, CA

[0000068505-24-000004:8k_2_02:43]
Products and Systems Integration

[0000068505-24-000004:8k_2_02:44]
•$90M P25 system and devices order for a U.S. customer

[0000068505-24-000004:8k_2_02:45]
•$67M P25 device order for Emergency Services Telecommunications Authority (ESTA) in Australia

[0000068505-24-000004:8k_2_02:46]
•$57M P25 APX NEXT devices order for U.S. customer

[0000068505-24-000004:8k_2_02:47]
•$38M P25 system order for the State of Arizona Department of Public Safety

[0000068505-24-000004:8k_2_02:48]
•$31M TETRA system order for a European customer

[0000068505-24-000004:8k_2_02:49]
•$13M fixed video order for an International customer

[0000068505-24-000004:8k_2_02:50]
BUSINESS OUTLOOK

[0000068505-24-000004:8k_2_02:51]
•First-quarter 2024 - The company expects revenue growth of approximately 8% compared to the first quarter of 2023. The company expects non-GAAP earnings per share in the range of $2.50 to $2.55 per share. This assumes approximately 172 million fully diluted shares and a non-GAAP effective tax rate of approximately 23%.

[0000068505-24-000004:8k_2_02:52]
•Full-year 2024 - The company expects revenue growth of approximately 6% and non-GAAP earnings per share in the range of $12.62 to $12.72 per share. This assumes approximately 171 million fully diluted shares and a non-GAAP effective tax rate between 23% and 24%.

[0000068505-24-000004:8k_2_02:53]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP measurements in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-24-000004:8k_2_02:54]
3

[0000068505-24-000004:8k_2_02:55]
RECENT EVENTS

[0000068505-24-000004:8k_2_02:56]
CMA UPDATE

[0000068505-24-000004:8k_2_02:57]
In October 2021, the CMA announced that it had opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, the company’s private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-24-000004:8k_2_02:58]
In early 2023 the CMA issued its final decision which stated it will impose a prospective price control on Airwave. The company strongly disagreed with the CMA’s final decision and it filed an appeal with the Competition Appeal Tribunal ("CAT"). On July 31, 2023, the CMA adopted a remedies order which implemented the price control set out in its final decision, which was suspended until the CAT dismissed the company's appeal on December 22, 2023. The company has until February 14, 2024 to file an application with the United Kingdom Court of Appeal requesting that it hear the company's appeal.

[0000068505-24-000004:8k_2_02:59]
Based on the adoption of the remedies order, since August 1, 2023, revenue under the Airwave contract has been recognized in accordance with the prospective price control. As the company's appeal to the CAT has been dismissed, revenue will continue to be recognized according to the remedies order published by the CMA, unless the United Kingdom Court of Appeal were to reverse the remedies order. The company's backlog for Airwave services contracted with the United Kingdom Home Office through 2026, inclusive of the five month period beginning August 1, 2023, was reduced by $777 million to align with the remedies order as of December 31, 2023.

[0000068505-24-000004:8k_2_02:60]
MACROECONOMIC EVENTS

[0000068505-24-000004:8k_2_02:61]
During fiscal year 2023, the company operated under market conditions influenced by events such as those discussed below. For a further discussion of the risks the company encounters in its business, please refer to Part I. Item 1A. “Risk Factors” in the company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2022 and Part II. Item 1A. “Risk Factors” in the company’s Quarterly Report on Form 10-Q for the fiscal quarter ended September 30, 2023.

[0000068505-24-000004:8k_2_02:62]
In 2023, the company experienced improved conditions with respect to availability of materials in the semiconductor market. The company reduced its inventory carrying levels as compared to 2022 in response to the improved supply conditions. The company continues to remain focused on improving its supplier network, engineering alternative designs and working to reduce supply shortages and effectively manage costs. In addition, the company continues to actively manage its inventory by diversifying the footprint of its supply chain operations, including by finalizing a strategic agreement relating to the company's video manufacturing operations during the first quarter of 2024, and maintaining increased levels of inventory in targeted areas to support increased demand and customer requirements.

[0000068505-24-000004:8k_2_02:63]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) on Thursday, February 8. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investors. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-24-000004:8k_2_02:64]
4

[0000068505-24-000004:8k_2_02:65]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-24-000004:8k_2_02:66]
A comparison of results from operations is as follows:

[0000068505-24-000004:8k_2_02:67]
|  | Fourth Quarter | Full Year |
|  | 2023 | 2022 | 2023 | 2022 |
| Net sales | $2,848 | $2,706 | $9,978 | $9,112 |
| Gross margin | 1,455 |  | 1,351 |  | 4,970 |  | 4,229 |  |
| Operating earnings | 738 |  | 692 |  | 2,294 |  | 1,661 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | 595 |  | 589 |  | 1,709 |  | 1,363 |  |
| Diluted EPS from continuing operations | $3.47 | $3.43 | $9.93 | $7.93 |
| Weighted average diluted common shares outstanding | 171.5 |  | 171.9 |  | 172.1 |  | 171.9 |  |

[0000068505-24-000004:8k_2_02:68]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-24-000004:8k_2_02:69]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-24-000004:8k_2_02:70]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-24-000004:8k_2_02:71]
Free cash flow:  Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-24-000004:8k_2_02:72]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-24-000004:8k_2_02:73]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-24-000004:8k_2_02:74]
5

[0000068505-24-000004:8k_2_02:75]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-24-000004:8k_2_02:76]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-24-000004:8k_2_02:77]
On December 17, 2020, the Court held that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court’s previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31,2022. On August 26, 2023, the Court granted the company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis quarterly royalty payments into the third-party escrow from October 2022 through January 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-24-000004:8k_2_02:78]
Following the February 14, 2020 verdict and judgment in the company's favor, Hytera subsequently filed several notices of appeal to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), including a notice of appeal filed on August 2, 2022 which appealed the orders related to the jury's verdict as well as the Court's royalty order. The company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on the parties' appeals on December 5, 2023.

[0000068505-24-000004:8k_2_02:79]
Separate from the company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the company.  On December 22, 2022, an additional distribution of $2 million was made to the company as well as an

[0000068505-24-000004:8k_2_02:80]
6

[0000068505-24-000004:8k_2_02:81]
assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the company’s Consolidated Statements of Operations.

[0000068505-24-000004:8k_2_02:82]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the approximately $15 million of proceeds realized in 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-24-000004:8k_2_02:83]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-24-000004:8k_2_02:84]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-24-000004:8k_2_02:85]
FORWARD LOOKING STATEMENTS

[0000068505-24-000004:8k_2_02:86]
7

[0000068505-24-000004:8k_2_02:87]
associated with changes in laws and regulations regarding privacy, data protection, information security and cybersecurity; (ii) challenges relating to existing or future legislation and regulations pertaining to artificial intelligence (“AI”),  AI-enabled products and the use of biometrics and other video analytics; (iii) the impact of government regulation of radio frequencies; (iv) audits and regulations and laws applicable to our U.S. government customer contracts and grants; (v) the impact, including increased costs and additional compliance obligations, associated with existing or future telecommunications-related laws and regulations; (vi) the evolving state of environmental regulation relating to climate change, and the physical risks of climate change; (vii) impact of product regulatory and safety, consumer, worker safety and environmental laws; (viii) impact of tax matters; (ix) increased areas of risk, increased competition and additional compliance obligations associated with the expansion of our technologies within our Products and Systems Integration and Software and Services segments; (x) the effectiveness of our investments in new products and technologies; (xi) impact of catastrophic events on our business or our customers' or suppliers' business; (xii) social, ethical and competitive risks relating to the use of AI in our products and services; (xiii) the effectiveness of our strategic acquisitions, including the integrations of such acquired businesses; (xiv) increased cybersecurity threats, a security breach or other significant disruption of our IT systems or those of our outsource partners, suppliers or customers; (xv) our inability to protect our intellectual property or potential infringement of intellectual property rights of third parties; (xvi) risks relating to intellectual property licenses and intellectual property indemnities in our customer and supplier contracts; (xvii) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xviii) our inability to purchase at acceptable prices a sufficient amount of materials, parts, and components, as well as software and services, to meet the demands of our customers, and any disruption to our suppliers or significant increase in the price of supplies; (xix) risks related to our large, multi-year system and services contracts (including, but not limited to, with respect to the ESN and Airwave contracts); (xx) the global nature of our employees, customers, suppliers and outsource partners; (xxi) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xxii) the inability of our subcontractors to perform in a timely and compliant manner or adhere to our Human Rights Policy; (xxiii) the inability of our products to meet our customers’ expectations or regulatory or industry standards; (xxiv) increasing scrutiny and evolving expectations from investors, customers, lawmakers, regulators and other stakeholders regarding environmental, social and governance-related practices and disclosures; (xxv) inability to attract and retain senior management and key employees; (xxvi) impact of current global economic and political conditions in the markets in which we operate (including, but not limited to, inflation); (xxvii) impact of returns on pension and retirement plan assets and interest rate changes; (xxviii) inability to access the capital markets for financing on acceptable terms and conditions; (xxix) exposure to exchange rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; and (xxx) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-24-000004:8k_2_02:88]
ABOUT MOTOROLA SOLUTIONS

[0000068505-24-000004:8k_2_02:89]
Motorola Solutions is solving for safer. We build and connect technologies to help protect people, property and places. Our solutions enable the collaboration between public safety agencies and enterprises that’s critical for a proactive approach to safety and security. Learn more about how we’re solving for safer communities, safer schools, safer hospitals, safer businesses – safer everywhere – at www.motorolasolutions.com.

[0000068505-24-000004:8k_2_02:90]
MEDIA CONTACT

[0000068505-24-000004:8k_2_02:91]
Alexandra Reynolds

[0000068505-24-000004:8k_2_02:92]
Motorola Solutions

[0000068505-24-000004:8k_2_02:93]
+1 312-965-3968

[0000068505-24-000004:8k_2_02:94]
8

[0000068505-24-000004:8k_2_02:95]
alexandra.reynolds@motorolasolutions.com

[0000068505-24-000004:8k_2_02:96]
INVESTOR CONTACT

[0000068505-24-000004:8k_2_02:97]
Tim Yocum

[0000068505-24-000004:8k_2_02:98]
Motorola Solutions

[0000068505-24-000004:8k_2_02:99]
+1 847-576-6899

[0000068505-24-000004:8k_2_02:100]
Tim.Yocum@motorolasolutions.com

[0000068505-24-000004:8k_2_02:101]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2024 Motorola Solutions, Inc. All rights reserved.

[0000068505-24-000004:8k_2_02:102]
9

[0000068505-24-000004:8k_2_02:103]
GAAP-1

[0000068505-24-000004:8k_2_02:104]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:105]
Consolidated Statements of Operations

[0000068505-24-000004:8k_2_02:106]
(In millions, except per share amount)

[0000068505-24-000004:8k_2_02:107]
|  | Three Months Ended |
|  | December 31, 2023 |  | December 31, 2022 |
| Net sales from products | $ | 1,750 |  |  | $ | 1,671 |  |
| Net sales from services | 1,098 |  |  | 1,035 |  |
| Net sales | 2,848 |  |  | 2,706 |  |
| Costs of products sales | 724 |  |  | 751 |  |
| Costs of services sales | 669 |  |  | 604 |  |
| Costs of sales | 1,393 |  |  | 1,355 |  |
| Gross margin | 1,455 |  |  | 1,351 |  |
| Selling, general and administrative expenses | 424 |  |  | 381 |  |
| Research and development expenditures | 218 |  |  | 201 |  |
| Other charges | 35 |  |  | 14 |  |
| Intangibles amortization | 40 |  |  | 63 |  |
| Operating earnings | 738 |  |  | 692 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (52) |  |  | (54) |  |
| Other, net | 21 |  |  | 25 |  |
| Total other expense | (31) |  |  | (29) |  |
| Net earnings before income taxes | 707 |  |  | 663 |  |
| Income tax expense | 111 |  |  | 73 |  |
| Net earnings | 596 |  |  | 590 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 595 |  |  | $ | 589 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.58 |  |  | $ | 3.52 |  |
| Diluted | $ | 3.47 |  |  | $ | 3.43 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.1 |  | 167.4 |
| Diluted | 171.5 |  | 171.9 |

[0000068505-24-000004:8k_2_02:108]
|  | Percentage of Net Sales* |
| Net sales from products | 61.4 | % |  | 61.8 | % |
| Net sales from services | 38.6 | % |  | 38.2 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.4 | % |  | 44.9 | % |
| Costs of services sales | 60.9 | % |  | 58.4 | % |
| Costs of sales | 48.9 | % |  | 50.1 | % |
| Gross margin | 51.1 | % |  | 49.9 | % |
| Selling, general and administrative expenses | 14.9 | % |  | 14.1 | % |
| Research and development expenditures | 7.7 | % |  | 7.4 | % |
| Other charges | 1.2 | % |  | 0.5 | % |
| Intangibles amortization | 1.4 | % |  | 2.3 | % |
| Operating earnings | 25.9 | % |  | 25.6 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (1.8) | % |  | (2.0) | % |
| Other, net | 0.7 | % |  | 0.9 | % |
| Total other expense | (1.1) | % |  | (1.1) | % |
| Net earnings before income taxes | 24.8 | % |  | 24.5 | % |
| Income tax expense | 3.9 | % |  | 2.7 | % |
| Net earnings | 20.9 | % |  | 21.8 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 20.9 | % |  | 21.8 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-24-000004:8k_2_02:109]
10

[0000068505-24-000004:8k_2_02:110]
GAAP-2

[0000068505-24-000004:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:112]
Consolidated Statements of Operations

[0000068505-24-000004:8k_2_02:113]
(In millions, except per share amounts)

[0000068505-24-000004:8k_2_02:114]
|  | Years Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2021 |
| Net sales from products | $ | 5,814 |  |  | $ | 5,368 |  |  | $ | 4,606 |  |
| Net sales from services | 4,164 |  |  | 3,744 |  |  | 3,565 |  |
| Net sales | 9,978 |  |  | 9,112 |  |  | 8,171 |  |
| Costs of products sales | 2,591 |  |  | 2,595 |  |  | 2,104 |  |
| Costs of services sales | 2,417 |  |  | 2,288 |  |  | 2,027 |  |
| Costs of sales | 5,008 |  |  | 4,883 |  |  | 4,131 |  |
| Gross margin | 4,970 |  |  | 4,229 |  |  | 4,040 |  |
| Selling, general and administrative expenses | 1,561 |  |  | 1,450 |  |  | 1,353 |  |
| Research and development expenditures | 858 |  |  | 779 |  |  | 734 |  |
| Other charges | 80 |  |  | 82 |  |  | 50 |  |
| Intangibles amortization | 177 |  |  | 257 |  |  | 236 |  |
| Operating earnings | 2,294 |  |  | 1,661 |  |  | 1,667 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (216) |  |  | (226) |  |  | (208) |  |
| Gains on sales of investments and businesses, net | — |  |  | 3 |  |  | 1 |  |
| Other, net | 68 |  |  | 77 |  |  | 92 |  |
| Total other expense | (148) |  |  | (146) |  |  | (115) |  |
| Net earnings before income taxes | 2,146 |  |  | 1,515 |  |  | 1,552 |  |
| Income tax expense | 432 |  |  | 148 |  |  | 302 |  |
| Net earnings | 1,714 |  |  | 1,367 |  |  | 1,250 |  |
| Less: Earnings attributable to noncontrolling interests | 5 |  |  | 4 |  |  | 5 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 1,709 |  |  | $ | 1,363 |  |  | $ | 1,245 |  |
| Earnings per common share: |  |  |  |  |  |
| Basic | $ | 10.23 |  |  | $ | 8.14 |  |  | $ | 7.36 |  |
| Diluted | $ | 9.93 |  |  | $ | 7.93 |  |  | $ | 7.17 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 167.0 |  |  | 167.5 |  |  | 169.2 |  |
| Diluted | 172.1 |  |  | 171.9 |  |  | 173.6 |  |

[0000068505-24-000004:8k_2_02:115]
|  | Percentage of Net Sales* |
| Net sales from products | 58.3 | % |  | 58.9 | % |  | 56.4 | % |
| Net sales from services | 41.7 | % |  | 41.1 | % |  | 43.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 44.6 | % |  | 48.3 | % |  | 45.7 | % |
| Costs of services sales | 58.0 | % |  | 61.1 | % |  | 56.9 | % |
| Costs of sales | 50.2 | % |  | 53.6 | % |  | 50.6 | % |
| Gross margin | 49.8 | % |  | 46.4 | % |  | 49.4 | % |
| Selling, general and administrative expenses | 15.6 | % |  | 15.9 | % |  | 16.6 | % |
| Research and development expenditures | 8.6 | % |  | 8.5 | % |  | 9.0 | % |
| Other charges | 0.8 | % |  | 0.9 | % |  | 0.6 | % |
| Intangibles amortization | 1.8 | % |  | 2.8 | % |  | 2.9 | % |
| Operating earnings | 23.0 | % |  | 18.2 | % |  | 20.4 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (2.2) | % |  | (2.5) | % |  | (2.5) | % |
| Gains on sales of investments and businesses, net | — | % |  | — | % |  | — | % |
| Other, net | 0.7 | % |  | 0.8 | % |  | 1.1 | % |
| Total other expense | (1.5) | % |  | (1.6) | % |  | (1.4) | % |
| Net earnings before income taxes | 21.5 | % |  | 16.6 | % |  | 19.0 | % |
| Income tax expense | 4.3 | % |  | 1.6 | % |  | 3.7 | % |
| Net earnings | 17.2 | % |  | 15.0 | % |  | 15.3 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 17.1 | % |  | 15.0 | % |  | 15.2 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-24-000004:8k_2_02:116]
GAAP-3

[0000068505-24-000004:8k_2_02:117]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:118]
Consolidated Balance Sheets

[0000068505-24-000004:8k_2_02:119]
(In millions)

[0000068505-24-000004:8k_2_02:120]
|  |  | December 31, 2023 |  | December 31, 2022 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,705 |  |  | $ | 1,325 |  |
| Accounts receivable, net |  | 1,710 |  |  | 1,518 |  |
| Contract assets |  | 1,102 |  |  | 974 |  |
| Inventories, net |  | 827 |  |  | 1,055 |  |
| Other current assets |  | 357 |  |  | 383 |  |
| Current assets held for disposition |  | 24 |  |  | — |  |
| Total current assets |  | 5,725 |  |  | 5,255 |  |
| Property, plant and equipment, net |  | 964 |  |  | 927 |  |
| Operating lease assets |  | 495 |  |  | 485 |  |
| Investments |  | 143 |  |  | 147 |  |
| Deferred income taxes |  | 1,062 |  |  | 1,036 |  |
| Goodwill |  | 3,401 |  |  | 3,312 |  |
| Intangible assets, net |  | 1,255 |  |  | 1,342 |  |
| Other assets |  | 274 |  |  | 310 |  |
| Non-current assets held for disposition |  | 17 |  |  | — |  |
| Total assets |  | $ | 13,336 |  |  | $ | 12,814 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |  |
| Current portion of long-term debt |  | $ | 1,313 |  |  | $ | 1 |  |
| Accounts payable |  | 881 |  |  | 1,062 |  |
| Contract liabilities |  | 2,037 |  |  | 1,859 |  |
| Accrued liabilities |  | 1,504 |  |  | 1,638 |  |
| Current liabilities held for disposition |  | 1 |  |  | — |  |
| Total current liabilities |  | 5,736 |  |  | 4,560 |  |
| Long-term debt |  | 4,705 |  |  | 6,013 |  |
| Operating lease liabilities |  | 407 |  |  | 419 |  |
| Other liabilities |  | 1,741 |  |  | 1,691 |  |
| Non-current liabilities held for disposition |  | 8 |  |  | — |  |
| Total Motorola Solutions, Inc. stockholders’ equity |  | 724 |  |  | 116 |  |
| Noncontrolling interests |  | 15 |  |  | 15 |  |
| Total liabilities and stockholders’ equity |  | $ | 13,336 |  |  | $ | 12,814 |  |

[0000068505-24-000004:8k_2_02:121]
12

[0000068505-24-000004:8k_2_02:122]
GAAP-4

[0000068505-24-000004:8k_2_02:123]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:124]
Consolidated Statements of Cash Flows

[0000068505-24-000004:8k_2_02:125]
(In millions)

[0000068505-24-000004:8k_2_02:126]
|  | Three Months Ended |
|  | December 31, 2023 |  | December 31, 2022 |
| Operating |  |  |  |
| Net earnings | $ | 596 |  |  | $ | 590 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 85 |  |  | 109 |  |
| Non-cash other charges | 6 |  |  | 4 |  |
| Exit of video manufacturing operations | 24 |  |  | — |  |
| Share-based compensation expenses | 52 |  |  | 46 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (26) |  |  | (117) |  |
| Inventories | 106 |  |  | 118 |  |
| Other current assets and contract assets | 58 |  |  | 37 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 390 |  |  | 634 |  |
| Other assets and liabilities | (18) |  |  | (26) |  |
| Deferred income taxes | (28) |  |  | (122) |  |
| Net cash provided by operating activities | 1,245 |  |  | 1,273 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (168) |  |  | (587) |  |
| Proceeds from sales of investments | 7 |  |  | 8 |  |
| Capital expenditures | (81) |  |  | (73) |  |
| Net cash used for investing activities | (242) |  |  | (652) |  |
| Financing |  |  |  |
| Repayment of debt | — |  |  | (2) |  |
| Issuances of common stock | 28 |  |  | 19 |  |
| Purchases of common stock | (134) |  |  | (87) |  |
| Payment of dividends | (146) |  |  | (132) |  |
| Net cash used for financing activities | (252) |  |  | (202) |  |
| Effect of exchange rate changes on cash and cash equivalents | 44 |  |  | 84 |  |
| Net increase in cash and cash equivalents | 795 |  |  | 503 |  |
| Cash and cash equivalents, beginning of period | 910 |  |  | 822 |  |
| Cash and cash equivalents, end of period | $ | 1,705 |  |  | $ | 1,325 |  |

[0000068505-24-000004:8k_2_02:127]
13

[0000068505-24-000004:8k_2_02:128]
GAAP-5

[0000068505-24-000004:8k_2_02:129]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:130]
Consolidated Statements of Cash Flows

[0000068505-24-000004:8k_2_02:131]
(In millions)

[0000068505-24-000004:8k_2_02:132]
|  | Years Ended |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2021 |
| Operating |  |  |  |  |  |
| Net earnings | $ | 1,714 |  |  | $ | 1,367 |  |  | $ | 1,250 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 356 |  |  | 440 |  |  | 438 |  |
| Non-cash other charges | 14 |  |  | 23 |  |  | 3 |  |
| Exit of video manufacturing operations | 24 |  |  | — |  |  | — |  |
| Loss on ESN fixed asset impairment | — |  |  | 147 |  |  | — |  |
| Share-based compensation expenses | 212 |  |  | 172 |  |  | 129 |  |
| Gains on sales of investments and businesses, net | — |  |  | (3) |  |  | (1) |  |
| Losses from the extinguishment of long-term debt | — |  |  | 6 |  |  | 18 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | (180) |  |  | (112) |  |  | 3 |  |
| Inventories | 200 |  |  | (242) |  |  | (284) |  |
| Other current assets and contract assets | (82) |  |  | (1) |  |  | (205) |  |
| Accounts payable, accrued liabilities, and contract liabilities | (144) |  |  | 451 |  |  | 578 |  |
| Other assets and liabilities | (38) |  |  | (91) |  |  | (126) |  |
| Deferred income taxes | (32) |  |  | (334) |  |  | 34 |  |
| Net cash provided by operating activities | 2,044 |  |  | 1,823 |  |  | 1,837 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (180) |  |  | (1,177) |  |  | (521) |  |
| Proceeds from sales of investments | 19 |  |  | 46 |  |  | 16 |  |
| Capital expenditures | (253) |  |  | (256) |  |  | (243) |  |
| Proceeds from sales of property, plant and equipment | — |  |  | — |  |  | 6 |  |
| Net cash used for investing activities | (414) |  |  | (1,387) |  |  | (742) |  |
| Financing |  |  |  |  |  |
| Net proceeds from issuance of debt | — |  |  | 595 |  |  | 844 |  |
| Repayment of debt | (1) |  |  | (285) |  |  | (353) |  |
| Revolving credit facility renewal fees | — |  |  | — |  |  | (7) |  |
| Issuances of common stock | 104 |  |  | 156 |  |  | 102 |  |
| Purchases of common stock | (804) |  |  | (836) |  |  | (528) |  |
| Payment of dividends | (589) |  |  | (530) |  |  | (482) |  |
| Payment of dividends to noncontrolling interest | (5) |  |  | (6) |  |  | (5) |  |
| Net cash used for financing activities | (1,295) |  |  | (906) |  |  | (429) |  |
| Effect of exchange rate changes on cash and cash equivalents | 45 |  |  | (79) |  |  | (46) |  |
| Net increase (decrease) in cash and cash equivalents | 380 |  |  | (549) |  |  | 620 |  |
| Cash and cash equivalents, beginning of period | 1,325 |  |  | 1,874 |  |  | 1,254 |  |
| Cash and cash equivalents, end of period | $ | 1,705 |  |  | $ | 1,325 |  |  | $ | 1,874 |  |

[0000068505-24-000004:8k_2_02:133]
14

[0000068505-24-000004:8k_2_02:134]
Non-GAAP-1

[0000068505-24-000004:8k_2_02:135]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow |
| (In millions) |

[0000068505-24-000004:8k_2_02:136]
|  |  | Three Months Ended |  | Years Ended |  |  |  |  |
|  |  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 1,245 |  |  | $ | 1,273 |  |  | $ | 2,044 |  |  | $ | 1,823 |  |  |  |  |  |  |  |
| Capital expenditures |  | (81) |  |  | (73) |  |  | (253) |  |  | (256) |  |  |  |  |  |  |  |
| Free cash flow |  | $ | 1,164 |  |  | $ | 1,200 |  |  | $ | 1,791 |  |  | $ | 1,567 |  |  |  |  |  |  |  |

[0000068505-24-000004:8k_2_02:137]
15

[0000068505-24-000004:8k_2_02:138]
Non-GAAP-2

[0000068505-24-000004:8k_2_02:139]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:140]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-24-000004:8k_2_02:141]
(In millions)

[0000068505-24-000004:8k_2_02:142]
|  |  |  |  | Three Months Ended |  | Years Ended |
|  |  | Statement Line |  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Net earnings attributable to MSI |  |  |  | $ | 595 |  |  | $ | 589 |  |  | $ | 1,709 |  |  | $ | 1,363 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 52 |  |  | $ | 46 |  |  | $ | 212 |  |  | $ | 172 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 40 |  |  | 63 |  |  | 177 |  |  | 257 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 7 |  |  | 5 |  |  | 29 |  |  | 36 |  |
| Exit of video manufacturing operations |  | Other charges (income) |  | 24 |  |  | — |  |  | 24 |  |  | — |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | — |  |  | 16 |  |  | 1 |  |
| Environmental reserve expense |  | Other charges (income) |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Hytera-related legal expenses |  | SG&A |  | — |  |  | 3 |  |  | 13 |  |  | 28 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 4 |  |  | 7 |  |  | 7 |  |  | 23 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 2 |  |  | 8 |  |  | 6 |  |  | 24 |  |
| Legal settlements |  | Other charges (Income) |  | 3 |  |  | — |  |  | 4 |  |  | 23 |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | — |  |  | 3 |  |  | 12 |  |
| Loss on ESN fixed asset impairment |  | Cost of sales |  | — |  |  | — |  |  | — |  |  | 147 |  |
| Loss from the extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | 6 |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | — |  |  | (2) |  |  | — |  |  | (3) |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | — |  |  | — |  |  | (3) |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | (2) |  |  | — |  |  | (15) |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | — |  |  | (5) |  |  | (13) |  |  | 30 |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 132 |  |  | $ | 123 |  |  | $ | 493 |  |  | $ | 717 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 59 |  |  | 94 |  | 145 |  | 300 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 73 |  | 29 |  | 348 |  |  | 417 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 668 |  |  | $ | 618 |  |  | $ | 2,057 |  |  | $ | 1,780 |  |

[0000068505-24-000004:8k_2_02:143]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:144]
Calculation of Non-GAAP Tax Rate

[0000068505-24-000004:8k_2_02:145]
(In millions)

[0000068505-24-000004:8k_2_02:146]
|  |  | Three Months Ended |  | Years Ended |  |  |  |
|  |  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |  |  |  |  |  |  |
| Net earnings before income taxes |  | $ | 707 |  |  | $ | 663 |  |  | $ | 2,146 |  |  | $ | 1,515 |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 132 |  |  | 123 |  |  | 493 |  |  | 717 |  |  |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 839 |  |  | 786 |  |  | 2,639 |  |  | 2,232 |  |  |  |  |  |  |  |
| Income tax expense |  | 111 |  |  | 73 |  |  | 432 |  |  | 148 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 59 |  |  | 94 |  |  | 145 |  |  | 300 |  |  |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | 170 |  |  | 167 |  |  | 577 |  |  | 448 |  |  |  |  |  |  |  |
| Non-GAAP Tax rate |  | 20.3 | % |  | 21.2 | % |  | 21.9 | % |  | 20.1 | % |  |  |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |  |  |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-24-000004:8k_2_02:147]
16

[0000068505-24-000004:8k_2_02:148]
Non-GAAP-2

[0000068505-24-000004:8k_2_02:149]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:150]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-24-000004:8k_2_02:151]
|  |  |  |  | Three Months Ended |  | Years Ended |
|  |  | Statement Line |  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Net earnings attributable to MSI |  |  |  | $ | 3.47 |  |  | $ | 3.43 |  |  | $ | 9.93 |  |  | $ | 7.93 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.30 |  |  | $ | 0.27 |  |  | $ | 1.23 |  |  | $ | 1.00 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.24 |  |  | 0.36 |  |  | 1.03 |  |  | 1.50 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.04 |  |  | 0.03 |  |  | 0.17 |  |  | 0.21 |  |
| Exit of video manufacturing operations |  | Other charges (income) |  | 0.14 |  |  | — |  |  | 0.14 |  |  | — |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | — |  |  | 0.09 |  |  | 0.01 |  |
| Environmental reserve expense |  | Other charges (income) |  | — |  |  | — |  |  | 0.09 |  |  | — |  |
| Hytera-related legal expenses |  | SG&A |  | — |  |  | 0.02 |  |  | 0.08 |  |  | 0.16 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.02 |  |  | 0.04 |  |  | 0.04 |  |  | 0.13 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.01 |  |  | 0.05 |  |  | 0.03 |  |  | 0.14 |  |
| Legal settlements |  | Other charges (Income) |  | 0.02 |  |  | — |  |  | 0.02 |  |  | 0.14 |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | — |  |  | 0.02 |  |  | 0.07 |  |
| Loss on ESN fixed asset impairment |  | Cost of sales |  | — |  |  | — |  |  | — |  |  | 0.86 |  |
| Loss from the extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | 0.03 |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | — |  |  | (0.01) |  |  | — |  |  | (0.02) |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | — |  |  | — |  |  | (0.02) |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | (0.01) |  |  | — |  |  | (0.09) |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | (0.12) |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | — |  |  | (0.03) |  |  | (0.08) |  |  | 0.18 |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.77 |  |  | $ | 0.72 |  |  | $ | 2.86 |  |  | $ | 4.18 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.34 |  |  | 0.55 |  | 0.84 |  | 1.75 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.43 |  | 0.17 |  | 2.02 |  |  | 2.43 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 3.90 |  |  | $ | 3.60 |  |  | $ | 11.95 |  |  | $ | 10.36 |  |
| Diluted Weighted Average Common Shares |  |  |  | 171.5 |  |  | 171.9 |  |  | 172.1 |  |  | 171.9 |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |

[0000068505-24-000004:8k_2_02:152]
17

[0000068505-24-000004:8k_2_02:153]
Non-GAAP-3

[0000068505-24-000004:8k_2_02:154]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:155]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-24-000004:8k_2_02:156]
(In millions)

[0000068505-24-000004:8k_2_02:157]
|  |  | Three Months Ended |
|  |  | December 31, 2023 |  | December 31, 2022 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,890 |  |  | $ | 958 |  |  | $ | 2,848 |  |  | $ | 1,810 |  |  | $ | 896 |  |  | $ | 2,706 |  |
| Operating earnings |  | $ | 492 |  |  | $ | 246 |  |  | $ | 738 |  |  | $ | 454 |  |  | $ | 238 |  |  | $ | 692 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 38 |  |  | 14 |  |  | 52 |  |  | 34 |  |  | 12 |  |  | 46 |  |
| Intangible assets amortization expense |  | 9 |  |  | 31 |  |  | 40 |  |  | 15 |  |  | 48 |  |  | 63 |  |
| Exit of video manufacturing operations |  | 17 |  |  | 7 |  |  | 24 |  |  | — |  |  | — |  |  | — |  |
| Reorganization of business charges |  | 6 |  |  | 1 |  |  | 7 |  |  | 4 |  |  | 1 |  |  | 5 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 2 |  |  | 4 |  |  | 1 |  |  | 6 |  |  | 7 |  |
| Legal settlements |  | 2 |  |  | 1 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |
| Operating lease asset impairments |  | 1 |  |  | 1 |  |  | 2 |  |  | 5 |  |  | 3 |  |  | 8 |  |
| Hytera-related legal expenses |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Gain on Hytera legal settlement |  | — |  |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (2) |  |
| Total above-OE non-GAAP adjustments |  | 75 |  |  | 57 |  |  | 132 |  |  | 60 |  |  | 70 |  |  | 130 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 567 |  |  | $ | 303 |  |  | $ | 870 |  |  | $ | 514 |  |  | $ | 308 |  |  | $ | 822 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 26.0 | % |  | 25.7 | % |  | 25.9 | % |  | 25.1 | % |  | 26.6 | % |  | 25.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 30.0 | % |  | 31.6 | % |  | 30.5 | % |  | 28.4 | % |  | 34.4 | % |  | 30.4 | % |

[0000068505-24-000004:8k_2_02:158]
18

[0000068505-24-000004:8k_2_02:159]
Non-GAAP-4

[0000068505-24-000004:8k_2_02:160]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000004:8k_2_02:161]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-24-000004:8k_2_02:162]
(In millions)

[0000068505-24-000004:8k_2_02:163]
|  |  | Years Ended |
|  |  | December 31, 2023 |  | December 31, 2022 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |
| Operating earnings ("OE") |  | $ | 1,244 |  |  | $ | 1,050 |  |  | $ | 2,294 |  |  | $ | 913 |  |  | $ | 748 |  |  | $ | 1,661 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 154 |  |  | 58 |  |  | 212 |  |  | 126 |  |  | 46 |  |  | 172 |  |
| Intangible assets amortization expense |  | 41 |  |  | 136 |  |  | 177 |  |  | 60 |  |  | 197 |  |  | 257 |  |
| Reorganization of business charges |  | 28 |  |  | 1 |  |  | 29 |  |  | 21 |  |  | 15 |  |  | 36 |  |
| Exit of video manufacturing operations |  | 17 |  |  | 7 |  |  | 24 |  |  | — |  |  | — |  |  | — |  |
| Environmental reserve expense |  | 10 |  |  | 5 |  |  | 15 |  |  | — |  |  | — |  |  | — |  |
| Hytera-related legal expenses |  | 13 |  |  | — |  |  | 13 |  |  | 28 |  |  | — |  |  | 28 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 5 |  |  | 7 |  |  | 9 |  |  | 14 |  |  | 23 |  |
| Operating lease asset impairments |  | 4 |  |  | 2 |  |  | 6 |  |  | 18 |  |  | 6 |  |  | 24 |  |
| Legal settlements |  | 3 |  |  | 1 |  |  | 4 |  |  | 3 |  |  | 20 |  |  | 23 |  |
| Fixed asset impairments |  | 2 |  |  | 1 |  |  | 3 |  |  | 9 |  |  | 3 |  |  | 12 |  |
| Loss on ESN fixed asset impairment |  | — |  |  | — |  |  | — |  |  | — |  |  | 147 |  |  | 147 |  |
| Gain on Hytera legal settlement |  | — |  |  | — |  |  | — |  |  | (15) |  |  | — |  |  | (15) |  |
| Total above-OE non-GAAP adjustments |  | 274 |  |  | 216 |  |  | 490 |  |  | 259 |  |  | 448 |  |  | 707 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,518 |  |  | $ | 1,266 |  |  | $ | 2,784 |  |  | $ | 1,172 |  |  | $ | 1,196 |  |  | $ | 2,368 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 19.9 | % |  | 28.1 | % |  | 23.0 | % |  | 15.9 | % |  | 22.1 | % |  | 18.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.3 | % |  | 33.9 | % |  | 27.9 | % |  | 20.5 | % |  | 35.3 | % |  | 26.0 | % |

[0000068505-24-000004:8k_2_02:164]
19

[0000068505-24-000004:8k_2_02:165]
Non-GAAP-5

[0000068505-24-000004:8k_2_02:166]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Revenue to Non-GAAP Organic Revenue |
| (In millions) |

[0000068505-24-000004:8k_2_02:167]
|  |  | Three Months Ended |  |  |
|  |  | December 31, 2023 |  | December 31, 2022 |  | % Change |
| Net sales |  | $ | 2,848 |  |  | $ | 2,706 |  |  | 5 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 20 |  |  | 3 |  |  |  |
| Organic revenue |  | $ | 2,828 |  |  | $ | 2,703 |  |  | 5 | % |

[0000068505-24-000004:8k_2_02:168]
|  |  | Years Ended |  |  |
|  |  | December 31, 2023 |  | December 31, 2022 |  | % Change |
| Net sales |  | $ | 9,978 |  |  | $ | 9,112 |  |  | 10 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 107 |  |  | 9 |  |  |  |
| Organic revenue |  | $ | 9,871 |  |  | $ | 9,103 |  |  | 8 | % |

[0000068505-24-000004:8k_2_02:169]
20
