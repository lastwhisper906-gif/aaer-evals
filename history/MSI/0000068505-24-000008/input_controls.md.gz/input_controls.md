# MSI 10-K controls and the auditor's report


## auditors_report

[0000068505-24-000008:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000068505-24-000008:auditors_report:2]
To the Board of Directors and Stockholders of Motorola Solutions, Inc.

[0000068505-24-000008:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000068505-24-000008:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Motorola Solutions, Inc. and its subsidiaries (the “Company”) as of December 31, 2023 and 2022, and the related consolidated statements of operations, of comprehensive income (loss), of stockholders’ equity (deficit) and of cash flows for each of the three years in the period ended December 31, 2023, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000068505-24-000008:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2023 and 2022, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2023 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000068505-24-000008:auditors_report:6]
Basis for Opinions

[0000068505-24-000008:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management's Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000068505-24-000008:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000068505-24-000008:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000068505-24-000008:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0000068505-24-000008:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000068505-24-000008:auditors_report:12]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000068505-24-000008:auditors_report:13]
Critical Audit Matters

[0000068505-24-000008:auditors_report:14]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000068505-24-000008:auditors_report:15]
54

[0000068505-24-000008:auditors_report:16]
Revenue Recognition - Estimated Costs to Complete System Contracts

[0000068505-24-000008:auditors_report:17]
As described in Note 1 to the consolidated financial statements, $1.9 billion of the Company’s total net sales for the year ended December 31, 2023 was generated from system contracts. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. For system contracts accounted for over time using estimated costs as a measure of performance completed, management relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. Management reviews the progress and performance of open contracts in order to determine the estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and the cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known.

[0000068505-24-000008:auditors_report:18]
The principal considerations for our determination that performing procedures relating to revenue recognition - estimated costs to complete system contracts is a critical audit matter are (i) the significant judgment by management in developing the estimates of total net sales and Estimated Costs at Completion, including significant judgments and assumptions on a contract by contract basis and (ii) a high degree of auditor judgment, subjectivity and effort in performing procedures and evaluating audit evidence related to management’s estimates of total net sales and Estimated Costs at Completion for system contracts.

[0000068505-24-000008:auditors_report:19]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including controls over the estimates of total net sales and Estimated Costs at Completion for system contracts. These procedures also included, among others, testing management’s process for developing the estimates of total net sales and Estimated Costs at Completion, including evaluating, for a sample of contracts, the reasonableness of certain significant judgments and assumptions used by management. Evaluating the significant judgments and assumptions used by management in developing the estimates of total net sales and Estimated Costs at Completion involved evaluating whether the significant judgments and assumptions were reasonable considering (i) on a test basis, management’s historical forecasting accuracy; (ii) on a test basis, evidence to support the relevant judgments and assumptions; (iii) the consistent application of accounting policies; and (iv) the timely identification of circumstances which may require a modification to a previous estimate.

[0000068505-24-000008:auditors_report:20]
/s/ PricewaterhouseCoopers LLP

[0000068505-24-000008:auditors_report:21]
Chicago, Illinois

[0000068505-24-000008:auditors_report:22]
February 15, 2024

[0000068505-24-000008:auditors_report:23]
We have served as the Company’s auditor since 2018.

[0000068505-24-000008:auditors_report:24]
55


## item_9a

[0000068505-24-000008:item_9a:1]
Item 9A. Controls and Procedures

[0000068505-24-000008:item_9a:2]
Evaluation of Disclosure Controls and Procedures.

[0000068505-24-000008:item_9a:3]
Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) or 15d-15(e) under the Exchange Act, as of December 31, 2023 (the "Evaluation Date"), the end of the period covered by this Form 10-K. Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our SEC reports: (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-24-000008:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting.

[0000068505-24-000008:item_9a:5]
The Company's management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Rule 13a-15(f) of the Exchange Act. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we assessed the effectiveness of our internal control over financial reporting as of December 31, 2023, using the criteria set forth in the Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based on this assessment, management has concluded that our internal control over financial reporting was effective as of December 31, 2023.

[0000068505-24-000008:item_9a:6]
The Company’s independent registered public accounting firm, PricewaterhouseCoopers LLP, has issued an attestation report on the Company’s internal control over financial reporting. The report on the audit of internal control over financial reporting appears in "Part II, Item 8, Financial Statements and Supplementary Data" of this Form 10-K.

[0000068505-24-000008:item_9a:7]
Changes in Internal Control Over Financial Reporting.

[0000068505-24-000008:item_9a:8]
There have been no changes in our internal control over financial reporting that occurred during our most recent fiscal quarter that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.
