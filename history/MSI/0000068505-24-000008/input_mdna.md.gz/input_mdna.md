# MSI MD&A — 0000068505-24-000008


## mdna

[0000068505-24-000008:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-24-000008:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2023 and 2022 and results of operations and cash flows for each of the three years in the period ended December 31, 2023. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-24-000008:mdna:3]
Executive Overview

[0000068505-24-000008:mdna:4]
Our Business

[0000068505-24-000008:mdna:5]
Motorola Solutions is solving for safer. Every day we come to work solving for safer communities, safer schools, safer hospitals, safer businesses, safer everywhere. We are a global leader in public safety and enterprise security, grounded in nearly 100 years of close customer and community collaboration. We design and advance technology for more than 100,000 public safety and enterprise customers in over 100 countries. We are driven by our commitment to help make everywhere safer for all.

[0000068505-24-000008:mdna:6]
We manage our business organizationally through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, we have principal product lines that also follow our three major technologies: LMR Communications, Video and Command Center.

[0000068505-24-000008:mdna:7]
The Company has invested across these three technologies organically and through acquisitions to evolve its LMR focus and expand its safety and security products and services.

[0000068505-24-000008:mdna:8]
Our strategy is to generate value through our technologies that help meet the changing needs of our customers around the world in protecting people, property and places. While each technology individually strives to make users safer and more productive, we believe we can enable better outcomes for our customers when we unite these technologies to work together. Our goal is to help remove silos and barriers between people and technologies, so that data unifies, information flows, operations run and collaboration improves to help strengthen safety and security everywhere. Across all three technologies, we offer cloud-based and hybrid solutions, cybersecurity services, software and subscription services as well as managed and support services.

[0000068505-24-000008:mdna:9]
One example of this collaboration is highlighted by a school setting. When a teacher presses a panic button on a phone, this can automatically notify local law enforcement of an emergency, trigger a lockdown to secure all entries, share live video feeds with first responders and send mass notifications to key stakeholders inside and outside the school, helping schools to detect, respond and resolve safety and security threats.

[0000068505-24-000008:mdna:10]
The principal products within each segment, by technology, are described below:

[0000068505-24-000008:mdna:11]
Products and Systems Integration Segment

[0000068505-24-000008:mdna:12]
In 2023, the segment’s net sales were $6.2 billion, representing 63% of our consolidated net sales.

[0000068505-24-000008:mdna:13]
LMR Communications

[0000068505-24-000008:mdna:14]
Our LMR Communications technology includes infrastructure and devices for LMR, public safety Long Term Evolution (“LTE”) and enterprise-grade private LTE. Our technology enables voice and multimedia collaborations across two-way radio, WiFi and public and private broadband networks. We are a global leader in the two-way radio category, including Project 25 (P25), Terrestrial Trunked Radio ("TETRA") and Digital Mobile Radio (DMR), as well as other PCR solutions. We also deliver LTE solutions for public safety, government and commercial users, including devices operating in both low-band and mid-band frequencies, including Citizens’ Broadband Radio Service (CBRS) frequencies.

[0000068505-24-000008:mdna:15]
We believe that public safety agencies and enterprises continue to trust LMR communications systems and devices because they are purpose-built and designed for reliability, availability, security and resiliency to withstand the most challenging conditions.

[0000068505-24-000008:mdna:16]
By extending our two-way radios with broadband data capabilities, we strive to provide our customers with greater functionality and multimedia access to the information and data they need in their workflows. Examples include application services such as GPS location to better protect lone workers, job dispatch to share detailed information and over-the-air programming to optimize device uptime. Our view is that complementary data applications such as these enable government, public safety and enterprise customers to work more efficiently and safely, while maintaining their mission-critical voice communications to remain connected and working in collaboration with others.

[0000068505-24-000008:mdna:17]
Primary sources of revenue for this technology come from selling devices and building communications networks, including infrastructure, installation and integration with our customers’ technology environments. The LMR technology within the Products and Systems Integration segment represented 82% of the net sales of the total segment in 2023.

[0000068505-24-000008:mdna:18]
Video

[0000068505-24-000008:mdna:19]
Our Video technology includes video management infrastructure, AI-powered security cameras including fixed and certain mobile video equipment as well as on-premise and cloud-based access control solutions. We deploy video security and access control solutions to thousands of government and enterprise customers around the world, including schools, transportation systems, healthcare centers, public venues, commercial real estate, utilities, prisons, factories, casinos, airports, financial institutions, government facilities, state and local law enforcement agencies and retailers. Organizations such as these utilize

[0000068505-24-000008:mdna:20]
31

[0000068505-24-000008:mdna:21]
video security and access control to verify critical events or incidents in real-time and to provide data to investigate an event or incident after it happens.

[0000068505-24-000008:mdna:22]
Our view is that government and public safety customers in particular are increasingly turning to video security technologies, including fixed and mobile cameras, to increase visibility, accountability and safety for citizens, communities and first responders alike. Additionally, we believe that government, public safety agencies and enterprises are increasingly turning to scalable, cloud-based multi-factor authentication access control to make their facilities more secure.

[0000068505-24-000008:mdna:23]
The Video technology within the Products and Systems Integration segment represented 18% of the net sales of the total segment in 2023.

[0000068505-24-000008:mdna:24]
Software and Services Segment

[0000068505-24-000008:mdna:25]
In 2023, the segment’s net sales were $3.7 billion, representing 37% of our consolidated net sales.

[0000068505-24-000008:mdna:26]
LMR Communications

[0000068505-24-000008:mdna:27]
LMR Communications services include support and managed services, which offer a broad continuum of support for our customers. Support services include repair and replacement, technical support and preventative maintenance, and more advanced offerings such as system monitoring, software updates and cybersecurity services. Managed services range from partial to full operational support of customer-owned or Motorola Solutions-owned communications networks. Our customers’ systems often have multi-year or multi-decade lifespans that help drive demand for software upgrades, device and infrastructure refresh opportunities, as well as additional services to monitor, manage, maintain and secure these complex networks and solutions. We strive to deliver services to our customers that help improve performance across their systems, devices and applications for greater safety and productivity.

[0000068505-24-000008:mdna:28]
Given the mission-critical nature of our customers’ operational environments, we aim to design the LMR networks they rely on for availability, security and resiliency. We have a comprehensive approach to system upgrades that addresses hardware, software and implementation services. As new system releases become available, we work with our customers to upgrade software, hardware, or both, with respect to site controllers, comparators, routers, LAN switches, servers, dispatch consoles, logging equipment, network management terminals, network security devices such as firewalls and intrusion detection sensors, on-site or remotely.

[0000068505-24-000008:mdna:29]
The LMR technology within the Software and Services segment represented 64% of the net sales of the total segment in 2023.

[0000068505-24-000008:mdna:30]
Video

[0000068505-24-000008:mdna:31]
Video software includes video network management software, decision management and digital evidence management software, certain mobile video equipment, and advanced vehicle location data analysis software, including license plate recognition. Our software is designed to complement video hardware systems, proving end-to-end video security to help keep people, property and places safe.

[0000068505-24-000008:mdna:32]
Our video network management software is embedded with AI-powered analytics to deliver operational insights to our customers by bringing attention to important events within their video footage. Given the growing volume of video content, we believe that analytics are critical to deliver meaningful, action-oriented insights. Our view is that these insights can help to proactively detect an important event in real time as well as reactively search video content to detect an important event that occurred in the past. For example, AI-powered analytics can highlight unusual behavior such as a person at a facility out of hours, locate a missing child at a theme park with Appearance Search, flag a vehicle of interest at a school through license plate recognition, send an alert through access control if doors are propped open at a hospital, or trigger parallel workflows by activating a school's customized lockdown plan while simultaneously alerting first responders with video footage inside the school.

[0000068505-24-000008:mdna:33]
Our cloud technologies can offer organizations the ability to access, search and manage their video security and access control system from a centralized dashboard, accessible on remote devices such as smartphones and laptops. Additionally, our fixed video systems can be connected to the cloud, providing our customers with the ability to securely access video across their sites from a remote or central monitoring location.

[0000068505-24-000008:mdna:34]
Our Video services include our "video-as-a-service" subscription-based offerings for law enforcement, simplifying procurement by bundling hardware and software into a single subscription. For example, body cameras and in-car video systems can be paired with either on-premises or cloud-based digital evidence management software and complementary command center products. Our cloud solutions are also sold as-a-service, available as single-year to multi-year hosted services, supporting our customers with upgrades and software enhancements to help ensure system performance and technological advancement.

[0000068505-24-000008:mdna:35]
The Video technology within the Software and Services segment represented 16% of the net sales of the total segment in 2023.

[0000068505-24-000008:mdna:36]
Command Center

[0000068505-24-000008:mdna:37]
Our Command Center portfolio consists of native cloud, hybrid and on-premises software solutions that support the complex process of the public safety workflow from "911 call to case closure." From the moment a person contacts 911, an array of individuals engage to gather information to coordinate a response and manage the post-incident resolution. These individuals include dispatchers who route calls to police, fire and emergency medical services, first responders in the field, intelligence

[0000068505-24-000008:mdna:38]
32

[0000068505-24-000008:mdna:39]
analysts who manage real-time operations, records specialists who preserve the integrity of information and evidence, crime analysts who identify patterns and accelerate investigations, and corrections officers who oversee jail and inmate management.

[0000068505-24-000008:mdna:40]
Additionally, to help ensure that individuals within the public safety workflow can work as efficiently, effectively and safely as possible, we believe it’s important that individuals within enterprise settings and communities can communicate and collaborate directly with public safety agencies, particularly during emergencies. We remain focused on strengthening the intersection of public safety and enterprise security, offering solutions that are designed to help individuals, enterprises and public safety agencies work together and share the information in an effort to help prevent critical incidents from occurring and better inform an emergency response when an incident unfolds.

[0000068505-24-000008:mdna:41]
Our Command Center software supports all of these individuals through the three phases of incident or event: detection, response and resolution. Detection software includes community engagement and alert applications for tip submissions, crime mapping and evidence submission, mass notification, panic buttons that can share real-time incident details and location, 911 call management software (including multimedia and AI-powered language transcription) and next-generation core services for 911 call routing. Response software includes voice and computer aided dispatch (CAD) for dispatch and coordinating first response, collaboration software to share operational updates, real-time intelligence software that shows a single, real-time view of video feeds and other alerts on a map, and field response and reporting to help frontline personnel collaborate, manage incident activity and file reports from the field. Resolution software includes centralized records for streamlined reporting and record-keeping, evidence management for gathering, managing and sharing multimedia evidence throughout an incident's lifecycle, and investigative tools that uncover connections across records, vehicles and images in an effort to identify crime trends.

[0000068505-24-000008:mdna:42]
Another area of public safety evolution is the increasing adoption of Next Generation 911 Core Services (“NGCS”), a group of products and services needed to create infrastructure connectivity in order to process a 911 call using Next Generation (“NG”) technology. The NG infrastructure is an Emergency Service IP Network ("ESInet"), which can carry voice, data and multimedia. ESInet enables 911 call takers at public safety answering points to respond to text, video and data. Our NGCS can be offered as a managed service and includes call routing, ESInet, location services, geographic information services, cybersecurity and our continuous communications network and security operations center dedicated to public safety.

[0000068505-24-000008:mdna:43]
Command Center also includes interoperability solutions that provide connectivity across LMR and broadband networks to help ensure that communication is not limited by coverage area, network technology or device type. Additionally, Command Center includes push-to-talk ("PTT") devices that deliver voice communications over LTE and Wi-Fi, and advanced back-end systems that enable and manage interoperable communications, capable of scaling from small enterprises to nationwide cellular networks. For example, a two-way radio network can connect with an LTE network, assisting individuals in communicating securely and more easily across technologies. These solutions can provide our public safety customers with the critical interoperability between multiple agencies' networks, facilitating a coordinated response.

[0000068505-24-000008:mdna:44]
Finally, as the Command Center market continues to evolve from on-premises to hybrid and cloud "software-as-a-service" ("SaaS") technologies to improve their operations, reduce response times and increase officer availability, we offer both native cloud-based applications and cloud features that enhance on-premises applications. We believe this flexibility helps our customers to optimize their investments and enhance their systems with the technologies of their choice.

[0000068505-24-000008:mdna:45]
The Command Center technology within the Software and Services segment represented 20% of the net sales of the total segment in 2023.

[0000068505-24-000008:mdna:46]
2023 Financial Results

[0000068505-24-000008:mdna:47]
•Net sales were $10.0 billion in 2023 compared to $9.1 billion in 2022.

[0000068505-24-000008:mdna:48]
•Operating earnings were $2.3 billion in 2023 compared to $1.7 billion in 2022.

[0000068505-24-000008:mdna:49]
•Net earnings attributable to Motorola Solutions, Inc. were $1.7 billion, or $9.93 per diluted common share in 2023, compared to earnings of $1.4 billion, or $7.93 per diluted common share in 2022.

[0000068505-24-000008:mdna:50]
•Our operating cash flow was $2.0 billion in 2023 compared to $1.8 billion in 2022.

[0000068505-24-000008:mdna:51]
•We returned approximately $1.4 billion of capital to shareholders, in the form of $804 million in share repurchases and $589 million in dividends in 2023.

[0000068505-24-000008:mdna:52]
•We increased our quarterly dividend by 11% to $0.98 per share in November 2023.

[0000068505-24-000008:mdna:53]
•We ended 2023 with a backlog position of $14.3 billion, down $88 million compared to 2022.

[0000068505-24-000008:mdna:54]
Segment Financial Highlights

[0000068505-24-000008:mdna:55]
•In the Products and Systems Integration segment, net sales were $6.2 billion in 2023, an increase of $514 million, or 9%, compared to $5.7 billion in 2022. On a geographic basis, net sales increased in both the International and North America region. Operating earnings were $1.2 billion in 2023, compared to $913 million in 2022. Operating margins increased in 2023 to 19.9% from 15.9% in 2022 primarily due to higher sales and lower direct material costs, partially offset by higher employee incentive costs, including share-based compensation.

[0000068505-24-000008:mdna:56]
•In the Software and Services segment, net sales were $3.7 billion in 2023, an increase of $352 million, or 10%, compared to $3.4 billion in 2022. On a geographic basis, net sales increased in both the North America and International region. Operating earnings were $1.1 billion in 2023, compared to $748 million in 2022. Operating margins increased in 2023 to

[0000068505-24-000008:mdna:57]
28.1% from 22.1% in 2022 primarily driven by higher sales, a $147 million fixed asset impairment loss in 2022 that did not recur in 2023, related to assets constructed and used in the deployment of the Emergency Services Network ("ESN") services contract with the Home Office of the United Kingdom (the "Home Office") which we have executed an agreement to exit, and a reduction in intangible amortization expenses, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the United Kingdom's (the "U.K.") Competition and Markets Authority's ("CMA") remedies order and higher expenses associated with acquired businesses.

[0000068505-24-000008:mdna:58]
Macroeconomic Events

[0000068505-24-000008:mdna:59]
During fiscal year 2023, we operated under market conditions influenced by events such as those discussed below. For a further discussion of our business and the trends and risks that we encounter in our business, please refer to “Part I. Item 1. Business” and “Part I. Item 1A. Risk Factors” in this Form 10-K.

[0000068505-24-000008:mdna:60]
In 2023, we experienced improved conditions with respect to availability of materials in the semiconductor market. We reduced our inventory carrying levels as compared to 2022 in response to the improved supply conditions. We continue to remain focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages and effectively manage costs. In addition, we continue to actively manage our inventory by diversifying the footprint of our supply chain operations, including by finalizing a strategic agreement relating to our video manufacturing operations during the first quarter of 2024, and maintaining increased levels of inventory in targeted areas to support increased demand and customer requirements.

[0000068505-24-000008:mdna:61]
Recent Events

[0000068505-24-000008:mdna:62]
CMA Update

[0000068505-24-000008:mdna:63]
In October 2021, the CMA announced that it had opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, our private mobile radio communications network that we acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-24-000008:mdna:64]
In early 2023 the CMA issued its final decision which stated it will impose a prospective price control on Airwave. We strongly disagreed with the CMA's final decision and we filed an appeal with the Competition Appeal Tribunal ("CAT"). On July 31, 2023, the CMA adopted a remedies order which implemented the price control set out in its final decision, which was suspended until the CAT dismissed our appeal on December 22, 2023. On February 13, 2024, we filed an application with the United Kingdom Court of Appeal requesting that it hear our appeal.

[0000068505-24-000008:mdna:65]
Based on the adoption of the remedies order, since August 1, 2023, revenue under the Airwave contract has been recognized in accordance with the prospective price control. As our appeal to the CAT has been dismissed, revenue will continue to be recognized according to the remedies order published by the CMA, unless the United Kingdom Court of Appeal were to reverse the remedies order. Our backlog for Airwave services contracted with the Home Office through 2026, inclusive of the five month period beginning August 1, 2023, was reduced by $777 million to align with the remedies order in the fourth quarter of 2023.

[0000068505-24-000008:mdna:66]
Recent Acquisitions

[0000068505-24-000008:mdna:67]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Video Security and Access Control | Products and Systems Integration | IPVideo Corporation | Creator of a multifunctional safety and security device. | $170 million and share-based compensation of $5 million | December 15, 2023 |
| Command Center | Software and Services | Rave Mobile Safety, Inc. ("Rave Mobile") | Provider of mass notification and incident management services. | $553 million and share-based compensation of $2 million | December 14, 2022 |
| LMR Communications | Products and Systems Integration | Futurecom Systems Group, ULC | Provider of radio coverage extension solutions. | $30 million | October 25, 2022 |
| LMR Communications | Products and Systems Integration | Barrett Communications Pty Ltd | Provider of specialized radio communications. | $18 million | August 8, 2022 |
| Video Security and Access Control | Products and Systems Integration | Videotec S.p.A. | Provider of ruggedized video security solutions. | $23 million and share-based compensation of $4 million | May 12, 2022 |
| Video Security and Access Control | Software and Services | Calipsa, Inc. | Provider of cloud-native advanced video analytics. | $39 million and share-based compensation of $4 million | April 19, 2022 |
| LMR Communications | Software and Services | TETRA Ireland Communications Limited | Provider of Ireland's National Digital Radio Service. | $120 million | March 23, 2022 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Ava Security Limited | Provider of cloud-native video security and analytics. | $388 million and share-based awards and compensation of $7 million | March 3, 2022 |
| Command Center | Software and Services | 911 Datamaster, Inc. | Provider of Next Generation 911 data solutions that help to ensure emergency calls are accurately located and routed based on the caller's location. | $35 million and share-based compensation of $3 million | December 16, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Envysion, Inc. | Provider of enterprise video security and business analytics. | $124 million and share-based compensation of $1 million | October 29, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Openpath Security, Inc. | Provider of cloud-based mobile access control. | $298 million and share-based compensation of $29 million | July 15, 2021 |

[0000068505-24-000008:mdna:68]
35

[0000068505-24-000008:mdna:69]
Climate Change Regulations

[0000068505-24-000008:mdna:70]
We expect that our operations and supply chain will become increasingly subject to federal, state, local and foreign laws, regulations and international treaties and industry standards relating to climate change. For example, in the European Union (the “EU”), the EU Corporate Sustainability Reporting Directive, Corporate Sustainability Due Diligence Directive and EU taxonomy initiatives will introduce additional due diligence and disclosure requirements addressing sustainability that will apply or we expect will apply, as applicable, to us in the coming years.

[0000068505-24-000008:mdna:71]
Recently, in October 2021 the U.K.’s Cabinet Office began requiring companies bidding on contracts with the U.K. government that have a value of over £5m per year to have carbon reduction plans that contain a commitment to achieving net zero emissions by 2050 for U.K. operations. This requirement applies to our operations in the U.K. Although Motorola Solutions UK Ltd. and Airwave Solutions Ltd., our U.K. subsidiaries, each committed in early 2022 to achieving net zero emissions by 2050 for such entities' U.K. operations, this requirement and any similar future requirements and other increased regulation of climate change concerns could subject us to additional costs and restrictions, impact our competitive position or require us to make certain changes to our manufacturing practices and/or product designs.

[0000068505-24-000008:mdna:72]
Looking Forward

[0000068505-24-000008:mdna:73]
We expect continued growth within our global LMR installed base as a number of events such as natural disasters and large-scale incidents continue to reinforce the importance of having secure, reliable LMR for public safety. We believe our augmentation of LMR with broadband solutions will also drive growth, as we expect our customers will look to integrate valuable data capabilities. We expect to provide additional services to existing LMR customers as communications networks become more complex, software-centric and data-driven.

[0000068505-24-000008:mdna:74]
As public safety needs continue to evolve, we anticipate growth opportunities within the command center as our Command Center portfolio supports the complex process of the public safety workflow from "911 call to case closure." We expect increased growth across our portfolio that consists of native cloud, hybrid and on-premises software solutions that provide a migration path for our customers from on-premises solutions to cloud capabilities, as well as from the increasing adoption of NGCS.

[0000068505-24-000008:mdna:75]
Within Video, we expect growth across our portfolio of fixed and mobile video security solutions embedded with advanced analytics and access control solutions. We believe drivers include the expansion of traditional video sales beyond enterprise customers to government and public safety customers. Additionally, we believe that government, public safety agencies and enterprises are increasingly turning to scalable, cloud-based multi-factor authentication access control to make their facilities more secure with the ability to securely access, search and manage these systems across their sites from a remote or central monitoring location. We also expect customers to continue to embrace analytics that convert video data into actionable insights and offerings such as "video-as-a-service."

[0000068505-24-000008:mdna:76]
Finally, we anticipate new opportunities from the investments we are making to integrate our LMR, Video and Command Center technologies into one unified safety and security ecosystem. We have made go-to-market and research and development investments in both Video and our Command Center technologies with growth in mind. We have made a number of acquisitions and we see opportunities to continue to rationalize costs within both segments of our business, further driving operating leverage in our businesses.

[0000068505-24-000008:mdna:77]
We expect the continuing impact of revenue reduction on Airwave services in 2024 due to the implementation of the CMA's remedies order. Revenue will continue to be recognized according to the remedies order published by the CMA, unless the United Kingdom Court of Appeal were to reverse the remedies order. Refer to "Recent Events" set forth in this “Part II. Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” of this Form 10-K for a further discussion regarding the impact of the CMA's remedies order on our business.

[0000068505-24-000008:mdna:78]
36

[0000068505-24-000008:mdna:79]
Results of Operations

[0000068505-24-000008:mdna:80]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2023 |  | % ofSales ** |  | 2022 |  | % ofSales ** |  | 2021 |  | % ofSales ** |
| Net sales from products | $ | 5,814 |  |  |  |  | $ | 5,368 |  |  |  |  | $ | 4,606 |  |  |  |
| Net sales from services | 4,164 |  |  |  |  | 3,744 |  |  |  |  | 3,565 |  |  |  |
| Net sales | 9,978 |  |  |  |  | 9,112 |  |  |  |  | 8,171 |  |  |  |
| Costs of product sales | 2,591 |  |  | 44.6 | % |  | 2,595 |  |  | 48.3 | % |  | 2,104 |  |  | 45.7 | % |
| Costs of services sales | 2,417 |  |  | 58.0 | % |  | 2,288 |  |  | 61.1 | % |  | 2,027 |  |  | 56.9 | % |
| Costs of sales | 5,008 |  |  | 50.2 | % |  | 4,883 |  |  | 53.6 | % |  | 4,131 |  |  | 50.6 | % |
| Gross margin | 4,970 |  |  | 49.8 | % |  | 4,229 |  |  | 46.4 | % |  | 4,040 |  |  | 49.4 | % |
| Selling, general and administrative expenses | 1,561 |  |  | 15.6 | % |  | 1,450 |  |  | 15.9 | % |  | 1,353 |  |  | 16.6 | % |
| Research and development expenditures | 858 |  |  | 8.6 | % |  | 779 |  |  | 8.5 | % |  | 734 |  |  | 9.0 | % |
| Other charges | 257 |  |  | 2.6 | % |  | 339 |  |  | 3.7 | % |  | 286 |  |  | 3.5 | % |
| Operating earnings | 2,294 |  |  | 23.0 | % |  | 1,661 |  |  | 18.2 | % |  | 1,667 |  |  | 20.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (216) |  |  | (2.2) | % |  | (226) |  |  | (2.5) | % |  | (208) |  |  | (2.5) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | 3 |  |  | — | % |  | 1 |  |  | — | % |
| Other, net | 68 |  |  | 0.7 | % |  | 77 |  |  | 0.8 | % |  | 92 |  |  | 1.1 | % |
| Total other expense | (148) |  |  | (1.5) | % |  | (146) |  |  | (1.6) | % |  | (115) |  |  | (1.4) | % |
| Net earnings before income taxes | 2,146 |  |  | 21.5 | % |  | 1,515 |  |  | 16.6 | % |  | 1,552 |  |  | 19.0 | % |
| Income tax expense | 432 |  |  | 4.3 | % |  | 148 |  |  | 1.6 | % |  | 302 |  |  | 3.7 | % |
| Net earnings | 1,714 |  |  | 17.2 | % |  | 1,367 |  |  | 15.0 | % |  | 1,250 |  |  | 15.3 | % |
| Less: Earnings attributable to noncontrolling interests | 5 |  |  | 0.1 | % |  | 4 |  |  | — | % |  | 5 |  |  | 0.1 | % |
| Net earnings* | $ | 1,709 |  |  | 17.1 | % |  | $ | 1,363 |  |  | 15.0 | % |  | $ | 1,245 |  |  | 15.2 | % |
| Earnings per diluted common share* | $ | 9.93 |  |  |  |  | $ | 7.93 |  |  |  |  | $ | 7.17 |  |  |  |

[0000068505-24-000008:mdna:81]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-24-000008:mdna:82]
**    Percentages may not add due to rounding.

[0000068505-24-000008:mdna:83]
Geographic Market Sales by Locale of End Customer

[0000068505-24-000008:mdna:84]
|  | 2023 |  | 2022 |  | 2021 |
| North America | 69 | % |  | 70 | % |  | 68 | % |
| International | 31 | % |  | 30 | % |  | 32 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-24-000008:mdna:85]
37

[0000068505-24-000008:mdna:86]
Results of Operations—2023 Compared to 2022

[0000068505-24-000008:mdna:87]
Net Sales

[0000068505-24-000008:mdna:88]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| Net sales from Products and Systems Integration | $ | 6,242 |  |  | $ | 5,728 |  |  | 9 | % |
| Net sales from Software and Services | 3,736 |  |  | 3,384 |  |  | 10 | % |
| Net sales | $ | 9,978 |  |  | $ | 9,112 |  |  | 10 | % |

[0000068505-24-000008:mdna:89]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in both 2023 and 2022. The Software and Services segment’s net sales represented 37% of our net sales in both 2023 and 2022.

[0000068505-24-000008:mdna:90]
Net sales increased by $866 million, or 10%, compared to 2022. The 9% increase in net sales within the Products and Systems Integration segment was driven by a 20% increase in the International region and a 5% increase in the North America region. The 10% increase in the Software and Services segment was driven by a 16% increase in the North America region and a 1% increase within the International region. The increase in net sales included:

[0000068505-24-000008:mdna:91]
•an increase in the Products and Systems Integration segment, inclusive of $15 million of revenue from acquisitions, driven by growth in LMR and Video; and

[0000068505-24-000008:mdna:92]
•an increase in the Software and Services segment, inclusive of $83 million of revenue from acquisitions, driven by an increase in LMR services, Command Center and Video;

[0000068505-24-000008:mdna:93]
•inclusive of $38 million from unfavorable currency rates.

[0000068505-24-000008:mdna:94]
Regional results included:

[0000068505-24-000008:mdna:95]
•a 9% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in LMR, Video and Command Center; and

[0000068505-24-000008:mdna:96]
•a 11% increase in the International region, inclusive of revenue from acquisitions, driven by growth in LMR and Video, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the CMA's remedies order.

[0000068505-24-000008:mdna:97]
Products and Systems Integration

[0000068505-24-000008:mdna:98]
The 9% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000008:mdna:99]
•$414 million, or 9% growth in LMR, inclusive of revenue from acquisitions, driven by both the International and North America regions; and

[0000068505-24-000008:mdna:100]
•$100 million, or 10% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-24-000008:mdna:101]
•inclusive of $19 million from unfavorable currency rates.

[0000068505-24-000008:mdna:102]
Software and Services

[0000068505-24-000008:mdna:103]
The 10% increase in the Software and Services segment was driven by the following:

[0000068505-24-000008:mdna:104]
•$125 million, or 5% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America and International regions, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the CMA's remedies order;

[0000068505-24-000008:mdna:105]
•$124 million, or 21% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-24-000008:mdna:106]
•$103 million, or 20% growth in Video, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-24-000008:mdna:107]
•inclusive of $19 million from unfavorable currency rates.

[0000068505-24-000008:mdna:108]
Gross Margin

[0000068505-24-000008:mdna:109]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| Gross margin | $ | 4,970 |  |  | $ | 4,229 |  |  | 18 | % |

[0000068505-24-000008:mdna:110]
Gross margin was 49.8% of net sales in 2023 compared to 46.4% of net sales in 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-24-000008:mdna:111]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales and lower direct material costs; and

[0000068505-24-000008:mdna:112]
•higher gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales and a $147 million fixed asset impairment loss in 2022 that did not recur in 2023, related to assets constructed and used in the deployment of the ESN services contract with the Home Office which we have executed an agreement to exit, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the CMA's remedies order.

[0000068505-24-000008:mdna:113]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-24-000008:mdna:114]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| Selling, general and administrative expenses | $ | 1,561 |  |  | $ | 1,450 |  |  | 8 | % |

[0000068505-24-000008:mdna:115]
SG&A expenses increased $111 million, or 8% in 2023 compared to 2022. The increase in SG&A expenses was primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses, partially offset by lower Hytera-related legal expenses. SG&A expenses were 15.6% of net sales in 2023 compared to 15.9% of net sales in 2022.

[0000068505-24-000008:mdna:116]
Research and Development ("R&D") Expenditures

[0000068505-24-000008:mdna:117]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| Research and development expenditures | $ | 858 |  |  | $ | 779 |  |  | 10 | % |

[0000068505-24-000008:mdna:118]
R&D expenditures increased $79 million, or 10% in 2023 compared to 2022 primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses. R&D expenditures were 8.6% of net sales in 2023 and 8.5% of net sales in 2022.

[0000068505-24-000008:mdna:119]
Other Charges

[0000068505-24-000008:mdna:120]
|  | Years ended December 31 |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Other charges | $ | 257 |  |  | $ | 339 |  |  |  |

[0000068505-24-000008:mdna:121]
Other charges decreased $82 million, or 24% in 2023 compared to 2022 primarily due to the following:

[0000068505-24-000008:mdna:122]
•$177 million of intangible asset amortization expense in 2023 compared to $257 million in 2022;

[0000068505-24-000008:mdna:123]
•$4 million of legal settlements in 2023 compared to $23 million in 2022;

[0000068505-24-000008:mdna:124]
•$6 million of operating lease asset impairments in 2023 compared to $24 million in 2022;

[0000068505-24-000008:mdna:125]
•$7 million of charges for acquisition-related transaction fees in 2023 compared to $23 million in 2022; and

[0000068505-24-000008:mdna:126]
•$3 million of fixed asset impairments in 2023 compared to $12 million in 2022; partially offset by

[0000068505-24-000008:mdna:127]
•$24 million impairment loss related to the exit of video manufacturing operations in 2023 that did not occur in 2022 (see "Property, Plant and Equipment, Net" within "Note 4: Other Financial Data" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information);

[0000068505-24-000008:mdna:128]
•$15 million of environmental reserve expense in 2023 that did not occur in 2022;

[0000068505-24-000008:mdna:129]
•$15 million of gain recoveries from the legal settlement under the Hytera bankruptcy proceedings in 2022 that did not occur in 2023; and

[0000068505-24-000008:mdna:130]
•$22 million of net reorganization of business charges in 2023 compared to $18 million in 2022 (see "Note 14: Reorganization of Businesses" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-24-000008:mdna:131]
Operating Earnings

[0000068505-24-000008:mdna:132]
|  | Years ended December 31 |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Operating earnings from Products and Systems Integration | $ | 1,244 |  |  | $ | 913 |  |  |  |
| Operating earnings from Software and Services | 1,050 |  |  | 748 |  |  |  |
| Operating earnings | $ | 2,294 |  |  | $ | 1,661 |  |  |  |

[0000068505-24-000008:mdna:133]
Operating earnings increased $633 million, or 38% in 2023 compared to 2022. The increase in Operating earnings was due to:

[0000068505-24-000008:mdna:134]
•a $331 million increase in the Products and Systems Integration segment from 2022 to 2023, primarily driven by higher sales and lower direct material costs, partially offset by higher employee incentive costs, including share-based compensation; and

[0000068505-24-000008:mdna:135]
•a $302 million increase in the Software and Services segment from 2022 to 2023, primarily driven by higher sales, a $147 million fixed asset impairment loss in 2022 that did not recur in 2023, related to assets constructed and used in the deployment of the ESN services contract with the Home Office which we have executed an agreement to exit, and a reduction in intangible amortization expenses, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the CMA's remedies order, and higher expenses associated with acquired businesses.

[0000068505-24-000008:mdna:136]
Interest Expense, net

[0000068505-24-000008:mdna:137]
|  | Years ended December 31 |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Interest expense, net | $ | (216) |  |  | $ | (226) |  |  |  |

[0000068505-24-000008:mdna:138]
The $10 million decrease in net interest expense in 2023 compared to 2022 was a result of higher interest income earned on cash partially offset by higher debt outstanding.

[0000068505-24-000008:mdna:139]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-24-000008:mdna:140]
|  | Years ended December 31 |  |
| (In millions) | 2023 |  | 2022 |  |
| Gains on sales of investments and businesses, net | $ | — |  |  | $ | 3 |  |  |

[0000068505-24-000008:mdna:141]
The net gains on sales of investments and businesses were primarily related to the sales of various equity investments that occurred in 2022.

[0000068505-24-000008:mdna:142]
Other, net

[0000068505-24-000008:mdna:143]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |
| Other, net | $ | 68 |  |  | $ | 77 |  |

[0000068505-24-000008:mdna:144]
Other, net income decreased $9 million in 2023 compared to 2022 primarily due to:

[0000068505-24-000008:mdna:145]
•$53 million of foreign currency losses in 2023 compared to $37 million of foreign currency gains in 2022;

[0000068505-24-000008:mdna:146]
•$99 million of net periodic pension and postretirement benefit in 2023 compared to $123 million of net periodic pension and postretirement benefit in 2022;

[0000068505-24-000008:mdna:147]
•$21 million gain on TETRA Ireland equity method investment in 2022 that did not occur in 2023; and

[0000068505-24-000008:mdna:148]
•$16 million of investment impairments in 2023 compared to $1 million of investment impairments in 2022; partially offset by

[0000068505-24-000008:mdna:149]
•a $20 million gain on derivatives in 2023 compared to a $61 million loss on derivatives in 2022;

[0000068505-24-000008:mdna:150]
•a $13 million gain on fair value adjustments to equity investments in 2023 compared to an $30 million loss on fair value adjustments to equity investments in 2022;

[0000068505-24-000008:mdna:151]
•a $6 million loss on the extinguishment of long-term debt in 2022 that did not occur in 2023; and

[0000068505-24-000008:mdna:152]
•a $3 million loss on equity method investments in 2022 that did not occur in 2023.

[0000068505-24-000008:mdna:153]
Effective Tax Rate

[0000068505-24-000008:mdna:154]
|  | Years ended December 31 |  |
| (In millions) | 2023 |  | 2022 |  |
| Income tax expense | $ | 432 |  |  | $ | 148 |  |  |

[0000068505-24-000008:mdna:155]
Income tax expense increased by $284 million in 2023 compared to 2022, for an effective tax rate of 20.1%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-24-000008:mdna:156]
•$38 million benefit from the foreign derived intangible income deduction;

[0000068505-24-000008:mdna:157]
•$33 million of benefits due to the recognition of excess tax benefits on share-based compensation; and

[0000068505-24-000008:mdna:158]
•$19 million of benefits due to the generation of research and development tax credits, offset by:

[0000068505-24-000008:mdna:159]
•$71 million tax expense for estimated 2023 U.S. state income taxes.

[0000068505-24-000008:mdna:160]
Our effective tax rate in 2022 was 9.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-24-000008:mdna:161]
•$77 million of a non-recurring net deferred tax benefit as a result of an intra-group transfer of certain intellectual property rights;

[0000068505-24-000008:mdna:162]
•$68 million of benefits due to the recognition of excess tax benefits on share-based compensation;

[0000068505-24-000008:mdna:163]
•$59 million benefit from the foreign derived intangible income deduction; and

[0000068505-24-000008:mdna:164]
•$47 million benefit due to a change in the Company's ability to utilize tax attribute carryforwards resulting in the partial release of valuation allowances.

[0000068505-24-000008:mdna:165]
For further information, see "Note 7: Income Taxes" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-24-000008:mdna:166]
Results of Operations—2022 Compared to 2021

[0000068505-24-000008:mdna:167]
Net Sales

[0000068505-24-000008:mdna:168]
|  | Years ended December 31 |
| (In millions) | 2022 |  | 2021 |  | % Change |
| Net sales from Products and Systems Integration | $ | 5,728 |  |  | $ | 5,033 |  |  | 14 | % |
| Net sales from Software and Services | 3,384 |  |  | 3,138 |  |  | 8 | % |
| Net sales | $ | 9,112 |  |  | $ | 8,171 |  |  | 12 | % |

[0000068505-24-000008:mdna:169]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in 2022, compared to 62% in 2021. The Software and Services segment’s net sales represented 37% of our net sales in 2022, compared to 38% in 2021.

[0000068505-24-000008:mdna:170]
Net sales increased by $941 million, or 12%, in 2022 compared to 2021. The 14% increase in net sales within the Products and Systems Integration segment was driven by a 15% increase in the North America region and a 10% increase in the International region. The 8% increase in the Software and Services segment was driven by a 14% increase in the North America region and consistent net sales within the International region. The increase in net sales included:

[0000068505-24-000008:mdna:171]
•an increase in the Products and Systems Integration segment, inclusive of $53 million of revenue from acquisitions, driven by growth in LMR, inclusive of public safety LMR products and PCR, and Video; and

[0000068505-24-000008:mdna:172]
•an increase in the Software and Services segment, inclusive of $68 million of revenue from acquisitions, driven by an increase in Video, LMR services and Command Center;

[0000068505-24-000008:mdna:173]
•inclusive of $216 million from unfavorable currency rates.

[0000068505-24-000008:mdna:174]
Regional results include:

[0000068505-24-000008:mdna:175]
•a 15% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in LMR, Video and Command Center; and

[0000068505-24-000008:mdna:176]
•a 5% increase in the International region, inclusive of revenue from acquisitions, driven by growth in LMR, Video and Command Center.

[0000068505-24-000008:mdna:177]
Products and Systems Integration

[0000068505-24-000008:mdna:178]
The 14% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000008:mdna:179]
•$510 million, or 12% growth in public safety LMR products and PCR, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-24-000008:mdna:180]
•$185 million, or 22% growth in Video, inclusive of revenue from acquisitions, in both the North America and International regions;

[0000068505-24-000008:mdna:181]
•inclusive of $98 million from unfavorable currency rates.

[0000068505-24-000008:mdna:182]
Software and Services

[0000068505-24-000008:mdna:183]
The 8% increase in the Software and Services segment was driven by the following:

[0000068505-24-000008:mdna:184]
•$112 million, or 28% growth in Video, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-24-000008:mdna:185]
•$69 million, or 3% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region; and

[0000068505-24-000008:mdna:186]
•$65 million, or 12% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-24-000008:mdna:187]
•inclusive of $118 million from unfavorable currency rates.

[0000068505-24-000008:mdna:188]
Gross Margin

[0000068505-24-000008:mdna:189]
|  | Years ended December 31 |
| (In millions) | 2022 |  | 2021 |  | % Change |
| Gross margin | $ | 4,229 |  |  | $ | 4,040 |  |  | 5 | % |

[0000068505-24-000008:mdna:190]
Gross margin was 46.4% of net sales in 2022 compared to 49.4% of net sales in 2021. The primary drivers of this decrease in gross margin as a percentage of net sales were:

[0000068505-24-000008:mdna:191]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN services contract with the Home Office which we have executed an agreement to exit; and

[0000068505-24-000008:mdna:192]
•lower gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by increased direct material costs and freight costs, partially offset by pricing actions and higher sales volume.

[0000068505-24-000008:mdna:193]
Selling, General and Administrative Expenses

[0000068505-24-000008:mdna:194]
|  | Years ended December 31 |
| (In millions) | 2022 |  | 2021 |  | % Change |
| Selling, general and administrative expenses | $ | 1,450 |  |  | $ | 1,353 |  |  | 7 | % |

[0000068505-24-000008:mdna:195]
SG&A expenses increased $97 million, or 7% in 2022 compared to 2021. SG&A expenses were 15.9% of net sales in 2022 compared to 16.6% of net sales in 2021. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses, higher share-based compensation and higher travel expenses.

[0000068505-24-000008:mdna:196]
Research and Development Expenditures

[0000068505-24-000008:mdna:197]
|  | Years ended December 31 |
| (In millions) | 2022 |  | 2021 |  | % Change |
| Research and development expenditures | $ | 779 |  |  | $ | 734 |  |  | 6 | % |

[0000068505-24-000008:mdna:198]
R&D expenditures increased $45 million, or 6% in 2022 compared to 2021 primarily due to an investment in R&D, higher expenses associated with acquired businesses and higher share-based compensation. R&D expenditures were 8.5% of net sales in 2022 and 9.0% of net sales in 2021.

[0000068505-24-000008:mdna:199]
Other Charges

[0000068505-24-000008:mdna:200]
|  | Years ended December 31 |  |
| (In millions) | 2022 |  | 2021 |  |
| Other charges | $ | 339 |  |  | $ | 286 |  |  |

[0000068505-24-000008:mdna:201]
Other charges increased $53 million, or 19% in 2022 compared to 2021 primarily due to the following:

[0000068505-24-000008:mdna:202]
•$257 million of intangible asset amortization expense in 2022 compared to $236 million in 2021;

[0000068505-24-000008:mdna:203]
•$23 million of legal settlements in 2022 compared to $3 million in 2021;

[0000068505-24-000008:mdna:204]
•$24 million of operating lease asset impairments in 2022 compared to $10 million in 2021;

[0000068505-24-000008:mdna:205]
•$12 million of fixed asset impairments in 2022 that did not occur in 2021; and

[0000068505-24-000008:mdna:206]
•$23 million of charges for acquisition-related transaction fees in 2022 compared to $15 million in 2021; partially offset by

[0000068505-24-000008:mdna:207]
•$15 million of gain recoveries from the legal settlement under the Hytera bankruptcy proceedings in 2022 that did not occur in 2021; and

[0000068505-24-000008:mdna:208]
•$18 million of net reorganization of business charges in 2022 compared to $24 million in 2021 (see "Note 14: Reorganization of Businesses" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-24-000008:mdna:209]
Operating Earnings

[0000068505-24-000008:mdna:210]
|  | Years ended December 31 |  |  |
| (In millions) | 2022 |  | 2021 |  |  |
| Operating earnings from Products and Systems Integration | $ | 913 |  |  | $ | 760 |  |  |  |
| Operating earnings from Software and Services | 748 |  |  | 907 |  |  |  |
| Operating earnings | $ | 1,661 |  |  | $ | 1,667 |  |  |  |

[0000068505-24-000008:mdna:211]
Operating earnings decreased $6 million, or 0.4% in 2022 compared to 2021. The decrease in Operating earnings was due to:

[0000068505-24-000008:mdna:212]
•a $159 million decrease in the Software and Services segment from 2021 to 2022, primarily driven by a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the ESN services contract with the Home Office which we have executed an agreement to exit; partially offset by

[0000068505-24-000008:mdna:213]
•a $153 million increase in the Products and Systems Integration segment from 2021 to 2022, driven by higher sales volume and increased pricing, partially offset by higher direct material costs and higher operating expenses.  The increase in operating expenses was primarily driven by higher expenses associated with acquired businesses and $27 million higher share-based compensation expense, partially offset by a $15 million gain from Hytera legal recoveries.

[0000068505-24-000008:mdna:214]
Interest Expense, net

[0000068505-24-000008:mdna:215]
|  | Years ended December 31 |  |  |
| (In millions) | 2022 |  | 2021 |  |  |
| Interest expense, net | $ | (226) |  |  | $ | (208) |  |  |  |

[0000068505-24-000008:mdna:216]
The $18 million increase in net interest expense in 2022 compared to 2021 was a result of higher debt outstanding and the reversal of a non-cash interest accrual related to an international tax audit in 2021, partially offset by higher interest income earned on cash.

[0000068505-24-000008:mdna:217]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-24-000008:mdna:218]
|  | Years ended December 31 |  |
| (In millions) | 2022 |  | 2021 |  |
| Gains (Losses) on sales of investments and businesses, net | $ | 3 |  |  | $ | 1 |  |  |

[0000068505-24-000008:mdna:219]
The net gains on sales of investments and businesses were primarily related to the sales of various equity investments.

[0000068505-24-000008:mdna:220]
Other, net

[0000068505-24-000008:mdna:221]
|  | Years ended December 31 |  |
| (In millions) | 2022 |  | 2021 |  |
| Other, net | $ | 77 |  |  | $ | 92 |  |  |

[0000068505-24-000008:mdna:222]
Other, net income decreased $15 million in 2022 compared to 2021 primarily due to:

[0000068505-24-000008:mdna:223]
•a $61 million loss on derivatives in 2022 compared to a $30 million loss on derivatives in 2021;

[0000068505-24-000008:mdna:224]
•a $30 million loss on fair value adjustments to equity investments in 2022 compared to an $8 million loss on fair value adjustments to equity investments in 2021; and

[0000068505-24-000008:mdna:225]
•a $3 million loss on equity method investments in 2022 compared to a $5 million gain on equity method investments in 2021; partially offset by

[0000068505-24-000008:mdna:226]
•a $21 million gain on TETRA Ireland equity method investment in 2022 that did not occur in 2021;

[0000068505-24-000008:mdna:227]
•$37 million of foreign currency gains in 2022 compared to $17 million of foreign currency gains in 2021; and

[0000068505-24-000008:mdna:228]
•a $6 million loss on the extinguishment of long term debt in 2022 compared to an $18 million loss on the extinguishment of long-term debt in 2021 (see "Note 5: Debt and Credit Facilities" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-24-000008:mdna:229]
Effective Tax Rate

[0000068505-24-000008:mdna:230]
|  | Years ended December 31 |  |  |
| (In millions) | 2022 |  | 2021 |  |  |
| Income tax expense | $ | 148 |  |  | $ | 302 |  |  |  |

[0000068505-24-000008:mdna:231]
Income tax expense decreased by $154 million in 2022 compared to 2021, for an effective tax rate of 9.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-24-000008:mdna:232]
•a $77 million non-recurring net deferred tax benefit as a result of an intra-group transfer of certain intellectual property rights in 2022;

[0000068505-24-000008:mdna:233]
•$68 million of benefits due to the recognition of excess tax benefits on share-based compensation;

[0000068505-24-000008:mdna:234]
•a $59 million benefit from the foreign derived intangible income deduction; and

[0000068505-24-000008:mdna:235]
•a $47 million benefit due to a change in the Company's ability to utilize tax attribute carryforwards resulting in the partial release of valuation allowances.

[0000068505-24-000008:mdna:236]
Our effective tax rate in 2021 was 19.5%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-24-000008:mdna:237]
•a $34 million benefit due to a change in the Company's ability to utilize tax attribute carryforwards resulting in the partial release of valuation allowances; and

[0000068505-24-000008:mdna:238]
•$32 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-24-000008:mdna:239]
Reorganization of Businesses

[0000068505-24-000008:mdna:240]
In 2023, we recorded net reorganization of business charges of $53 million relating to the separation of 700 employees, of which 420 were direct employees and 280 were indirect employees. The $53 million of charges included $7 million recorded to Cost of sales and $46 million recorded to Other charges. Included in the aggregate $53 million were charges of $41 million related to employee separation costs and a $24 million impairment loss related to the exit of video manufacturing operations, partially offset by $7 million of reversals for employee separation accruals no longer needed and $5 million of reversals for exit cost accruals no longer needed.

[0000068505-24-000008:mdna:241]
During 2022, we recorded net reorganization of business charges of $36 million relating to the separation of 460 employees, of which 310 were direct employees and 150 were indirect employees. The $36 million of charges included $18 million recorded to Cost of sales and $18 million recorded to Other charges. Included in the aggregate $36 million were charges of $36 million for employee separation costs and $10 million for exit costs, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-24-000008:mdna:242]
During 2021, we recorded net reorganization of business charges of $32 million relating to the separation of 600 employees, of which 200 were indirect employees and 400 were direct employees. The $32 million of charges included $8 million recorded to Cost of sales and $24 million recorded to Other charges. Included in the aggregate $32 million were charges of $42 million for employee separation costs, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-24-000008:mdna:243]
The following table displays the net charges incurred by business segment due to such reorganizations:

[0000068505-24-000008:mdna:244]
| Years ended December 31 | 2023 |  | 2022 |  | 2021 |
| Products and Systems Integration | $ | 45 |  |  | $ | 21 |  |  | $ | 25 |  |
| Software and Services | 8 |  |  | 15 |  |  | 7 |  |
|  | 53 |  |  | $ | 36 |  |  | $ | 32 |  |

[0000068505-24-000008:mdna:245]
Cash payments for employee severance in connection with the reorganization of business plans were $37 million, $34 million, and $77 million in 2023, 2022, and 2021, respectively. The reorganization of business accruals for employee separation costs at December 31, 2023 were $23 million which we expect to pay within one year.

[0000068505-24-000008:mdna:246]
At January 1, 2023, we had an accrual of $10 million for exit costs related to our exit of the ESN contract with the Home Office. During the year, we recorded a $5 million reversal for accruals no longer needed. The remaining $5 million of exit costs are recorded in Accrued liabilities in our Consolidated Balance Sheet at December 31, 2023, and are expected to be paid within one year.

[0000068505-24-000008:mdna:247]
Liquidity and Capital Resources

[0000068505-24-000008:mdna:248]
|  | Years Ended December 31 |
|  | 2023 |  | 2022 |  | 2021 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 2,044 |  |  | $ | 1,823 |  |  | $ | 1,837 |  |
| Investing activities | (414) |  |  | (1,387) |  |  | (742) |  |
| Financing activities | (1,295) |  |  | (906) |  |  | (429) |  |
| Effect of exchange rates on cash and cash equivalents | 45 |  |  | (79) |  |  | (46) |  |
| Increase (decrease) in cash and cash equivalents | $ | 380 |  |  | $ | (549) |  |  | $ | 620 |  |

[0000068505-24-000008:mdna:249]
Cash and Cash Equivalents

[0000068505-24-000008:mdna:250]
At December 31, 2023, $1.4 billion of our $1.7 billion cash and cash equivalents balance was held in the U.S. and $347 million was held in other countries. Restricted cash was $2 million at each of December 31, 2023 and December 31, 2022.

[0000068505-24-000008:mdna:251]
In 2023, we repatriated $435 million in cash to the U.S. from international jurisdictions. We routinely repatriate a portion of non-U.S. earnings each year. We have recorded income tax expense for foreign withholding tax and distribution taxes on such earnings and, under current U.S. tax laws, do not expect to incur material incremental U.S. tax on repatriation.

[0000068505-24-000008:mdna:252]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay due to local country approvals.

[0000068505-24-000008:mdna:253]
Operating Activities

[0000068505-24-000008:mdna:254]
The increase in operating cash flows from 2022 to 2023 was driven by:

[0000068505-24-000008:mdna:255]
•higher earnings, net of non-cash charges; and

[0000068505-24-000008:mdna:256]
•improved working capital; partially offset by

[0000068505-24-000008:mdna:257]
•$280 million of higher income tax payments, including a one-time $70 million cash tax payment made in 2023 related to an intra-group transfer of certain IP rights that was completed in 2022 (see "Note 7: Income Taxes" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-24-000008:mdna:258]
The decrease in operating cash flows from 2021 to 2022 was driven by:

[0000068505-24-000008:mdna:259]
•an increase in working capital, inclusive of higher inventory;

[0000068505-24-000008:mdna:260]
•higher employee incentive costs; and

[0000068505-24-000008:mdna:261]
•$50 million of higher income tax payments; partially offset by

[0000068505-24-000008:mdna:262]
•higher earnings.

[0000068505-24-000008:mdna:263]
Investing Activities

[0000068505-24-000008:mdna:264]
The decrease in net cash used for investing activities from 2022 to 2023 was primarily due to:

[0000068505-24-000008:mdna:265]
•$997 million decrease in acquisitions and investments, driven by acquisitions and investments of $180 million in 2023 compared to $1.2 billion in 2022; and

[0000068505-24-000008:mdna:266]
45

[0000068505-24-000008:mdna:267]
•$3 million decrease in capital expenditures in 2023 compared to 2022; partially offset by

[0000068505-24-000008:mdna:268]
•$27 million decrease in proceeds from the sale of investments in 2023 compared to 2022.

[0000068505-24-000008:mdna:269]
The increase in net cash used for investing activities from 2021 to 2022 was primarily due to:

[0000068505-24-000008:mdna:270]
•$656 million increase in acquisitions and investments, driven by acquisitions of $1.2 billion in 2022 compared to $521 million in 2021;

[0000068505-24-000008:mdna:271]
•$30 million increase in proceeds from the sale of investments in 2022 compared to 2021; and

[0000068505-24-000008:mdna:272]
•$13 million increase in capital expenditures in 2022 compared to 2021.

[0000068505-24-000008:mdna:273]
Financing Activities

[0000068505-24-000008:mdna:274]
The increase in cash used for financing activities in 2023 compared to cash used for financing activities in 2022 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" in this section below):

[0000068505-24-000008:mdna:275]
•$589 million cash used for the payment of dividends in 2023 compared to $530 million in 2022; and

[0000068505-24-000008:mdna:276]
•$104 million in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2023 compared to $156 million in 2022; partially offset by

[0000068505-24-000008:mdna:277]
•$595 million in net proceeds in 2022 from the issuance of $600 million of 5.6% senior notes due 2032, of which a portion was subsequently used to repurchase $275 million principal amount of our 4.0% senior notes due 2024 for a purchase price of $279 million, excluding $3 million of accrued interest; and

[0000068505-24-000008:mdna:278]
•$804 million used for purchases under our share repurchase program in 2023 compared to $836 million in 2022.

[0000068505-24-000008:mdna:279]
The increase in cash used for financing activities in 2022 compared to cash used for financing activities in 2021 was driven by:

[0000068505-24-000008:mdna:280]
•$836 million used for purchases under our share repurchase program in 2022 compared to $528 million in 2021; and

[0000068505-24-000008:mdna:281]
•$530 million cash used for the payment of dividends in 2022 compared to $482 million in 2021; partially offset by

[0000068505-24-000008:mdna:282]
•$595 million net proceeds in 2022 from the issuance of $600 million of 5.6% senior notes due 2032, of which a portion was subsequently used to repurchase $275 million principal amount of our 4.0% senior notes due 2024 for a purchase price of $279 million, excluding $3 million of accrued interest.

[0000068505-24-000008:mdna:283]
Sales of Receivables

[0000068505-24-000008:mdna:284]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-24-000008:mdna:285]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2023, 2022, and 2021:

[0000068505-24-000008:mdna:286]
| Years ended December 31 | 2023 |  | 2022 |  | 2021 |
| Contract-specific discounting facility | — |  |  | $ | 49 |  |  | $ | 211 |  |
| Accounts receivable sales proceeds | 96 |  |  | 179 |  |  | 56 |  |
| Long-term receivables sales proceeds | 182 |  |  | 204 |  |  | 248 |  |
| Total proceeds from receivable sales | $ | 278 |  |  | $ | 432 |  |  | $ | 515 |  |

[0000068505-24-000008:mdna:287]
At December 31, 2023, the Company had retained servicing obligations for $813 million of long-term receivables, compared to $891 million of long-term receivables at December 31, 2022. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-24-000008:mdna:288]
Debt

[0000068505-24-000008:mdna:289]
We had outstanding long-term debt of $6.0 billion and $6.0 billion, including the current portions of $1.3 billion and $1 million, at December 31, 2023 and December 31, 2022, respectively.

[0000068505-24-000008:mdna:290]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 (the "Senior Convertible Notes"). Interest on these notes is payable semiannually. The Senior Notes became fully convertible on September 5, 2021. The notes are convertible based on a conversion rate of 4.9670 per $1,000 principal amount (which is equal to a conversion price of $201.33 per share), adjusted for dividends declared through the date of settlement. On February 14, 2024, we agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the 1.75% Senior Convertible Notes for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The cash consideration will be paid during the first quarter of 2024 and is expected to be paid from cash on the balance sheet and short-term borrowings including under the 2021 Motorola Solutions Credit Agreement.

[0000068505-24-000008:mdna:291]
In May of 2021, we issued $850 million of 2.75% senior notes due 2031. We recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds was then used to redeem $324 million in principal amount of our outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt issuance costs, we recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-24-000008:mdna:292]
In May of 2022, we issued $600 million of 5.6% senior notes due 2032. We recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the Company's 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, we recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-24-000008:mdna:293]
We have an unsecured commercial paper program, backed by the revolving credit facility described below, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2023, we had no outstanding debt under the commercial paper program.

[0000068505-24-000008:mdna:294]
Credit Facilities

[0000068505-24-000008:mdna:295]
As of December 31, 2023, we had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2023.

[0000068505-24-000008:mdna:296]
We have investment grade ratings on our senior unsecured long-term debt. During the year ended December 31, 2023, Moody's Investors Service upgraded our credit rating to Baa2 from Baa3. We continue to believe that we will be able to maintain sufficient access to the capital markets in the next twelve months and the foreseeable future.

[0000068505-24-000008:mdna:297]
Share Repurchase Program

[0000068505-24-000008:mdna:298]
Through a series of actions, including approval in November 2023 to increase the authorized amount by $2.0 billion, the Board of Directors has authorized an aggregate share repurchase amount of up to $18.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2023, we used approximately $15.5 billion of the share repurchase authority, excluding transaction costs and excise tax, to repurchase shares, leaving approximately $2.5 billion of authority available for future repurchases. As of January 1, 2023, our share repurchases in excess of issuances are subject to a 1% excise tax enacted by the Inflation Reduction Act of 2022, which was $4 million as of December 31, 2023.

[0000068505-24-000008:mdna:299]
Our share repurchases for 2023, 2022, and 2021 are summarized as follows:

[0000068505-24-000008:mdna:300]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2023 | 2.9 |  |  | $ | 278.56 |  |  | $ | 804 |  |
| 2022 | 3.7 |  |  | 225.00 |  |  | 836 |  |
| 2021 | 2.5 |  |  | 208.41 |  |  | 528 |  |

[0000068505-24-000008:mdna:301]
Dividends

[0000068505-24-000008:mdna:302]
We paid cash dividends to holders of our common stock of $589 million in 2023, $530 million in 2022, and $482 million in 2021. On January 12, 2024, we paid an additional $163 million in cash dividends to holders of our common stock.

[0000068505-24-000008:mdna:303]
Adequate Internal Funding Resources

[0000068505-24-000008:mdna:304]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement.

[0000068505-24-000008:mdna:305]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer also to "Part I. Item 1A. Risk Factors" for further discussion regarding access to the capital markets.

[0000068505-24-000008:mdna:306]
Material Cash Requirements from Contractual and Other Obligations

[0000068505-24-000008:mdna:307]
Summarized in the table and text below are our short-term (within the next twelve months) and long-term material cash requirements as of December 31, 2023, which we expect to fund with a combination of operating cash flows, existing cash balances or, as needed, borrowings under new or existing debt:

[0000068505-24-000008:mdna:308]
|  | Payments Due by Period |
| (in millions) |  | Short-term |  | Long-term |
| Long-term debt obligations, gross(1) |  | $ | 1,313 |  |  | $ | 4,748 |  |
| Lease obligations(2) |  | 145 |  |  | 446 |  |
| Purchase obligations(3) |  | 131 |  |  | 338 |  |
| Total obligations |  | $ | 1,589 |  |  | $ | 5,532 |  |

[0000068505-24-000008:mdna:309]
(1)Amounts included represent the estimated principal payments applicable to outstanding debt. Refer to "Note 5: Debt and Credit Facilities" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for discussion related to our long-term debt obligations.

[0000068505-24-000008:mdna:310]
(2)We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. We are evaluating our real estate needs in order to identify opportunities to reduce long-term cash requirements for office space where practicable. Refer to "Note 3: Leases" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further discussion of these material lease obligations.

[0000068505-24-000008:mdna:311]
(3)Amounts included represent firm, non-cancelable commitments. Such commitments include license agreements and agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. We do not anticipate the cancellation of any of our take-or-pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-24-000008:mdna:312]
Other Contingencies

[0000068505-24-000008:mdna:313]
Potential Contractual Damage Claims in Excess of Underlying Contract Value: In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-24-000008:mdna:314]
Indemnification Provisions: We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us.

[0000068505-24-000008:mdna:315]
Legal Matters: We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on our results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-24-000008:mdna:316]
Long-term Customer Financing Commitments

[0000068505-24-000008:mdna:317]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $103 million at December 31, 2023 and $65 million at December 31, 2022.

[0000068505-24-000008:mdna:318]
Critical Accounting Estimates

[0000068505-24-000008:mdna:319]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-24-000008:mdna:320]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. We believe that the following discussion addresses our most critical accounting estimates, which are those that are most important to the portrayal of our financial condition and results of operations and require management’s most difficult, subjective and complex judgments.

[0000068505-24-000008:mdna:321]
Revenue Recognition

[0000068505-24-000008:mdna:322]
We enter into arrangements which generally consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We use list price as the standalone selling price for sales sold through our channel partners. Given the unique nature of the goods and services we provide to direct customers, standalone sales of our products generally do not exist. Therefore, we determine ESP by: (i) collecting all reasonably available data points including historical sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points for similar customers and circumstances, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-24-000008:mdna:323]
We account for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-24-000008:mdna:324]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, equipment and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-24-000008:mdna:325]
Retirement Benefits

[0000068505-24-000008:mdna:326]
Our benefit obligations and net periodic pension costs (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits Plan”), are determined using actuarial assumptions. The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-24-000008:mdna:327]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases. As such, depending on the specific plan, we amortize gains and losses over periods ranging from nine to twenty-seven years. Prior service costs are being amortized over periods ranging from one to seventeen years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-24-000008:mdna:328]
There are various assumptions used in calculating the net periodic costs (benefits) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.  We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-24-000008:mdna:329]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost (benefit) and the net postretirement health care benefit. Our investment return assumption for the U.S. Pension Benefit Plans was 7.87% in 2023 and 6.76% in 2022. Our investment return assumption for the Postretirement Health Care Benefits Plan was 8.00% in 2023 and 6.90% in 2022. Our weighted average investment return assumption for the Non-U.S. Plans was 6.18% in 2023 and 4.78% in 2022. For the U.S. Pension Benefit Plans, a 25 bps increase in expected return on plan assets would result in $10 million of additional net periodic pension benefit and a 25 bps decrease would result in a $10 million reduction in net periodic pension benefit in 2023. For the Non-U.S. Pension Benefit Plans, a 25 bps increase in expected return on plan assets would result in $4 million of additional net periodic pension benefit and a 25 bps decrease would result in a

[0000068505-24-000008:mdna:330]
49

[0000068505-24-000008:mdna:331]
$4 million reduction in net periodic pension benefit in 2023. For the Postretirement Health Care Benefits Plan, a change in expected return on plan assets would have a de minimis impact to net periodic pension benefit in 2023.

[0000068505-24-000008:mdna:332]
A second key assumption is the discount rate. The discount rate assumptions used for the U.S. Pension Benefit Plans, the Non-U.S. Plans and the Postretirement Health Care Benefits Plan reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 5.01% and 5.20% at December 31, 2023 and 2022, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 4.3% and 4.6% at December 31, 2023 and 2022, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 4.92% and 5.10% at December 31, 2023 and 2022, respectively.

[0000068505-24-000008:mdna:333]
For the U.S. Pension Benefit Plans, a 25 bps increase in the discount rate on the projected benefit obligation would result in a $114 million reduction of the projected benefit obligation and a 25 bps decrease would result in $119 million of additional projected benefit obligation in 2023. For the Non-U.S. Pension Benefit Plans and the Postretirement Health Care Benefits Plan, a 25 bps change in our discount rate would be de minimis in 2023.

[0000068505-24-000008:mdna:334]
Valuation and Recoverability of Goodwill

[0000068505-24-000008:mdna:335]
We assess the recorded amount of goodwill for recovery on an annual basis as of the last day of the third quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: (i) adverse changes in macroeconomic conditions, (ii) adverse changes in the industry or market in which we transact, (iii) changes in cost factors negatively impacting earnings and cash flows, (iv) negative or declining overall financial performance, (v) events affecting the carrying value or composition of a reporting unit, or (vi) a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-24-000008:mdna:336]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Software and Services segments are comprised of three and two reporting units, respectively.

[0000068505-24-000008:mdna:337]
We performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2023. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value and entity-specific events. In the fiscal year 2022, we elected to perform a quantitative assessment of goodwill for impairment. For fiscal years 2023 and 2022, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-24-000008:mdna:338]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-24-000008:mdna:339]
We use the asset and liability method of accounting for income taxes. Under this method, income tax expense is recognized for the amount of taxes payable or refundable for the current year. In addition, deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Management makes assumptions, judgments and estimates to determine our current and deferred tax provision and also the deferred tax assets and liabilities. We evaluate our deferred tax assets quarterly to determine if adjustments to our valuation allowance are required based on the consideration of all available positive and negative evidence.

[0000068505-24-000008:mdna:340]
Our assumptions, judgments and estimates for computing the income tax provision takes into account current tax laws, our interpretation of current tax law and possible outcomes of current and future audits conducted by foreign and domestic tax authorities. We believe such estimates to be reasonable; however, the final determination of certain audits could significantly impact the amounts provided for income taxes in our financial statements.

[0000068505-24-000008:mdna:341]
Recent Accounting Pronouncements

[0000068505-24-000008:mdna:342]
See “Note 1: Summary of Significant Accounting Policies” to our consolidated financial statements in “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.
