# MSI notes — 0000068505-20-000028


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-20-000028:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of September 26, 2020 and for the three and nine months ended September 26, 2020 and September 28, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-20-000028:notes:2]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three and nine months ended September 26, 2020 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-20-000028:notes:3]
[same as prior period, unchanged from 0000068505-20-000020:notes:3]

[0000068505-20-000028:notes:4]
[same as prior period, unchanged from 0000068505-20-000020:notes:4]

[0000068505-20-000028:notes:5]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing command center software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

[0000068505-20-000028:notes:6]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-20-000028:notes:7]
[same as prior period, unchanged from 0000068505-20-000020:notes:6]

[0000068505-20-000028:notes:8]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-20-000028:notes:9]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-20-000028:notes:10]
[same as prior period, unchanged from 0000068505-20-000020:notes:9]

[0000068505-20-000028:notes:11]
[same as prior period, unchanged from 0000068505-20-000020:notes:10]

[0000068505-20-000028:notes:12]
[same as prior period, unchanged from 0000068505-20-000020:notes:11]

[0000068505-20-000028:notes:13]
[same as prior period, unchanged from 0000068505-20-000020:notes:12]

[0000068505-20-000028:notes:14]
[same as prior period, unchanged from 0000068505-20-000020:notes:13]

[0000068505-20-000028:notes:15]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share ("EPS"). The ASU clarifies that the average market price should be used to calculate the diluted EPS denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-20-000028:notes:16]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The adoption of the ASU will not have a significant impact on the financial statement disclosures.

[0000068505-20-000028:notes:17]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-20-000028:notes:18]
Recently Adopted Accounting Pronouncements

[0000068505-20-000028:notes:19]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information was not updated and disclosures required under ASC 326 are not provided for dates and periods before January 1, 2020.

[0000068505-20-000028:notes:20]
[same as prior period, unchanged from 0000068505-20-000020:notes:18]

[0000068505-20-000028:notes:21]
[same as prior period, unchanged from 0000068505-20-000020:notes:19]

[0000068505-20-000028:notes:22]
|  | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at September 26, 2020 |
| Allowance for credit losses | $ | 63 |  | $ | 38 |  | $ | (26) |  | $ | (2) |  | $ | 73 |  |

[0000068505-20-000028:notes:23]
[same as prior period, unchanged from 0000068505-20-000020:notes:21]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-20-000028:notes:24]
[same as prior period, unchanged from 0000068505-20-000020:notes:22]

[0000068505-20-000028:notes:25]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 26, 2020 and September 28, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:

[0000068505-20-000028:notes:26]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 863 |  |  | $ | 405 |  |  | $ | 980 |  |  | $ | 364 |  |
| International | 300 |  |  | 300 |  |  | 369 |  |  | 281 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 719 |  |  | $ | — |  |  | $ | 896 |  |  | $ | — |  |
| Systems and Systems Integration | 444 |  |  | — |  |  | 453 |  |  | — |  |
| Services | — |  |  | 514 |  |  | — |  |  | 479 |  |
| Software | — |  |  | 191 |  |  | — |  |  | 166 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 733 |  |  | $ | 637 |  |  | $ | 860 |  |  | $ | 602 |  |
| Indirect | 430 |  |  | 68 |  |  | 489 |  |  | 43 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |

[0000068505-20-000028:notes:27]
|  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 2,646 |  |  | $ | 1,026 |  |
| International | 794 |  |  | 871 |  |  | 1,010 |  |  | 829 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,921 |  |  | $ | — |  |  | $ | 2,391 |  |  | $ | — |  |
| Systems and Systems Integration | 1,203 |  |  | — |  |  | 1,265 |  |  | — |  |
| Services | — |  |  | 1,490 |  |  | — |  |  | 1,400 |  |
| Software | — |  |  | 527 |  |  | — |  |  | 455 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 2,289 |  |  | $ | 1,737 |  |
| Indirect | 1,116 |  |  | 148 |  |  | 1,367 |  |  | 118 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |

[0000068505-20-000028:notes:28]
[same as prior period, unchanged from 0000068505-20-000020:notes:26]

[0000068505-20-000028:notes:29]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction prices associated with remaining performance obligations which are not yet satisfied as of September 26, 2020 are $6.8 billion. A total of $2.9 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion is from Software and Services performance obligations that are not yet satisfied as of September 26, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.4 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-20-000028:notes:30]
[same as prior period, unchanged from 0000068505-20-000020:notes:28]

[0000068505-20-000028:notes:31]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,155 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 1,069 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,359 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 266 |  |  | 274 |  |  |  |  |  |

[0000068505-20-000028:notes:32]
Revenue recognized during the three months ended September 26, 2020 which was previously included in Contract liabilities as of June 27, 2020 is $349 million, compared to $342 million of revenue recognized during the three months ended September 28, 2019 which was previously included in Contract liabilities as of June 29, 2019. Revenue recognized during the nine months ended September 26, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $807 million, compared to $783 million of revenue recognized during the nine months ended September 28, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $12 million and $48 million was reversed during the three and nine months ended September 26, 2020 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. Revenue of $26 million and $42 million was reversed for the three and nine months ended September 28, 2019 driven by changes in the estimates of progress on system contracts.

[0000068505-20-000028:notes:33]
There were no material expected credit losses recognized on contract assets during the three and nine months ended September 26, 2020 and September 28, 2019.

[0000068505-20-000028:notes:34]
[same as prior period, unchanged from 0000068505-20-000020:notes:32]

[0000068505-20-000028:notes:35]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 25 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 101 |  |  | 107 |  |  |  |  |  |

[0000068505-20-000028:notes:36]
Amortization of non-current contract cost assets was $13 million and $35 million for the three and nine months ended September 26, 2020, respectively, and $10 million and $32 million for the three and nine months ended September 28, 2019, respectively


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-20-000028:notes:37]
Leases
The components of the Company's lease expense are as follows:

[0000068505-20-000028:notes:38]
|  |  |  |  | Three months ended |  | Nine Months Ended |
| (in millions) |  |  |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Lease expense: |  |  |  |  |  |  |  |  |  |  |
| Operating lease cost |  |  |  | $ | 34 |  |  | $ | 33 |  |  | $ | 101 |  |  | $ | 99 |  |
| Finance lease cost |  |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  |  | 3 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Interest on lease liabilities |  |  |  | — |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Total finance lease cost |  |  |  | 3 |  |  | 4 |  |  | 10 |  |  | 10 |  |
| Short-term lease cost |  |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 4 |  |
| Variable cost |  |  |  | 10 |  |  | 8 |  |  | 27 |  |  | 25 |  |
| Sublease income |  |  |  | (2) |  |  | (1) |  |  | (4) |  |  | (3) |  |
| Net lease expense |  |  |  | $ | 46 |  |  | $ | 45 |  |  | $ | 136 |  |  | $ | 135 |  |

[0000068505-20-000028:notes:39]
Lease assets and liabilities consist of the following:

[0000068505-20-000028:notes:40]
| (in millions) |  | Statement Line Classification |  | September 26, 2020 |  | December 31, 2019 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 472 |  |  | $ | 554 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 30 |  |  | 41 |  |  |  |
|  |  |  |  | $ | 502 |  |  | $ | 595 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 123 |  |  | $ | 122 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 11 |  |  | 13 |  |  |  |
|  |  |  |  | $ | 134 |  |  | $ | 135 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 401 |  |  | $ | 497 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 7 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 408 |  |  | $ | 513 |  |  |  |

[0000068505-20-000028:notes:41]
For the nine months ended September 26, 2020, the Company exercised a break option reducing the term of an International office lease by five years.  This resulted in a reduction to both the right of use ("ROU") asset and lease liabilities by approximately $47 million.

[0000068505-20-000028:notes:42]
Other information related to leases is as follows:

[0000068505-20-000028:notes:43]
|  | Nine Months Ended |  |  |
| (in millions) | September 26, 2020 |  | September 28, 2019 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 116 |  |  | $ | 110 |  |  |  |
| Net cash used for operating activities related to finance leases | 1 |  |  | 1 |  |  |  |
| Net cash used for financing activities related to finance leases | 9 |  |  | 11 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 64 |  |  | $ | 69 |  |  |  |

[0000068505-20-000028:notes:44]
| (in millions) | September 26, 2020 |  | December 31, 2019 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 7 |
| Finance leases | 2 |  | 2 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.31 | % |  | 3.61 | % |
| Finance leases | 4.23 | % |  | 4.28 | % |

[0000068505-20-000028:notes:45]
Future lease payments as of September 26, 2020 are as follows:

[0000068505-20-000028:notes:46]
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2020 | $ | 29 |  |  | $ | 3 |  |  | $ | 32 |  |
| 2021 | 136 |  |  | 11 |  |  | 147 |  |
| 2022 | 120 |  |  | 5 |  |  | 125 |  |
| 2023 | 67 |  |  | — |  |  | 67 |  |
| 2024 | 54 |  |  | — |  |  | 54 |  |
| Thereafter | 184 |  |  | — |  |  | 184 |  |
| Total lease payments | 590 |  |  | 19 |  |  | 609 |  |
| Less: interest | 66 |  |  | 1 |  |  | 67 |  |
| Present value of lease liabilities | $ | 524 |  |  | $ | 18 |  |  | $ | 542 |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-20-000028:notes:47]
[same as prior period, unchanged from 0000068505-20-000020:notes:45]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-20-000028:notes:48]
[same as prior period, unchanged from 0000068505-20-000020:notes:46]

[0000068505-20-000028:notes:49]
[same as prior period, unchanged from 0000068505-20-000020:notes:47]

[0000068505-20-000028:notes:50]
[same as prior period, unchanged from 0000068505-20-000020:notes:48]

[0000068505-20-000028:notes:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 54 |  |  | $ | 52 |  |  | $ | 158 |  |  | $ | 154 |  |
| Reorganization of business (Note 14) | 10 |  |  | 15 |  |  | 48 |  |  | 27 |  |
| Losses (gains) on legal settlements | — |  |  | (5) |  |  | 9 |  |  | (5) |  |
| Fixed asset impairment | — |  |  | — |  |  | 5 |  |  | — |  |
| Gain on sale of property, plant and equipment | — |  |  | — |  |  | (50) |  |  | — |  |
| Acquisition-related transaction fees | 5 |  |  | 1 |  |  | 8 |  |  | 4 |  |
|  | $ | 69 |  |  | $ | 63 |  |  | $ | 178 |  |  | $ | 180 |  |

[0000068505-20-000028:notes:52]
During the nine months ended September 26, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe.  This gain has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-20-000028:notes:53]
[same as prior period, unchanged from 0000068505-20-000020:notes:51]

[0000068505-20-000028:notes:54]
[same as prior period, unchanged from 0000068505-20-000020:notes:52]

[0000068505-20-000028:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (60) |  |  | $ | (60) |  |  | $ | (175) |  |  | $ | (178) |  |
| Interest income | 2 |  |  | 6 |  |  | 8 |  |  | 13 |  |
|  | $ | (58) |  |  | $ | (54) |  |  | $ | (167) |  |  | $ | (165) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 20 |  |  | $ | 17 |  |  | $ | 60 |  |  | $ | 50 |  |
| Gain from the extinguishment of 2.00% senior convertible notes (Note 5) | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Losses from the extinguishment of long-term debt (Note 5) | (56) |  |  | (7) |  |  | (56) |  |  | (50) |  |
| Investment impairments | — |  |  | (5) |  |  | — |  |  | (16) |  |
| Foreign currency gain (loss) | (15) |  |  | 3 |  |  | (19) |  |  | (7) |  |
| Gain (loss) on derivative instruments | 10 |  |  | (9) |  |  | 6 |  |  | (16) |  |
| Gains on equity method investments | 1 |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Fair value adjustments to equity investments | (4) |  |  | (18) |  |  | 1 |  |  | (3) |  |
| Other | 2 |  |  | 2 |  |  | (1) |  |  | 13 |  |
|  | $ | (42) |  |  | $ | (11) |  |  | $ | (8) |  |  | $ | (22) |  |

[0000068505-20-000028:notes:56]
During the three and nine months ended September 28, 2019, the Company recorded investment impairment charges of $5 million and $16 million, representing other-than-temporary declines in the value in the Company's strategic investment portfolio. Investment impairment charges are included in Other within Other income (expense) in the Company’s Condensed Consolidated Statements of Operations.

[0000068505-20-000028:notes:57]
[same as prior period, unchanged from 0000068505-20-000020:notes:55]

[0000068505-20-000028:notes:58]
[same as prior period, unchanged from 0000068505-20-000020:notes:56]

[0000068505-20-000028:notes:59]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 205 |  |  | $ | 267 |  |  | $ | 537 |  |  | $ | 625 |  |
| Weighted average common shares outstanding | 169.7 |  |  | 166.7 |  |  | 170.1 |  |  | 165.3 |  |
| Per share amount | $ | 1.21 |  |  | $ | 1.60 |  |  | $ | 3.16 |  |  | $ | 3.78 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 205 |  |  | $ | 267 |  |  | $ | 537 |  |  | $ | 625 |  |
| Weighted average common shares outstanding | 169.7 |  |  | 166.7 |  |  | 170.1 |  |  | 165.3 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.8 |  |  | 4.8 |  |  | 4.2 |  |  | 4.7 |  |
| 2.00% senior convertible notes | — |  |  | 4.9 |  |  | — |  |  | 5.7 |  |
| 1.75% senior convertible notes | — |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 173.5 |  |  | 176.4 |  |  | 174.3 |  |  | 175.7 |  |
| Per share amount | $ | 1.18 |  |  | $ | 1.51 |  |  | $ | 3.08 |  |  | $ | 3.56 |  |

[0000068505-20-000028:notes:60]
For the three months ended September 26, 2020, the assumed exercise of 0.5 million options, including 0.2 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the nine months ended September 26, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-20-000028:notes:61]
In the computation of diluted earnings per common share for the three months ended September 28, 2019 the assumed exercise of 0.01 million options were excluded because their inclusion would have been antidilutive. In the computation of the diluted earnings per common share for the nine months ended September 28, 2019, the assumed exercise of 0.3 million options were excluded because their inclusion would have been antidilutive.

[0000068505-20-000028:notes:62]
As of September 26, 2020, the Company had $1.0 billion of 1.75% senior convertible notes outstanding which mature in September 15, 2024 ("New Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the New Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the New Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. The conversion price is adjusted for dividends declared through the date of settlement. For the period ended September 26, 2020, there was no dilutive effect of the New Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price. See further discussion in Note 5.

[0000068505-20-000028:notes:63]
[same as prior period, unchanged from 0000068505-20-000020:notes:61]

[0000068505-20-000028:notes:64]
[same as prior period, unchanged from 0000068505-20-000020:notes:62]

[0000068505-20-000028:notes:65]
[same as prior period, unchanged from 0000068505-20-000020:notes:63]

[0000068505-20-000028:notes:66]
|  | September 26, 2020 |  | December 31, 2019 |
| Accounts receivable | $ | 1,228 |  |  | $ | 1,475 |  |
| Less allowance for credit losses | (73) |  |  | (63) |  |
|  | $ | 1,155 |  |  | $ | 1,412 |  |

[0000068505-20-000028:notes:67]
[same as prior period, unchanged from 0000068505-20-000020:notes:65]

[0000068505-20-000028:notes:68]
[same as prior period, unchanged from 0000068505-20-000020:notes:66]

[0000068505-20-000028:notes:69]
|  | September 26, 2020 |  | December 31, 2019 |
| Finished goods | $ | 279 |  |  | $ | 209 |  |
| Work-in-process and production materials | 340 |  |  | 374 |  |
|  | 619 |  |  | 583 |  |
| Less inventory reserves | (130) |  |  | (136) |  |
|  | $ | 489 |  |  | $ | 447 |  |

[0000068505-20-000028:notes:70]
[same as prior period, unchanged from 0000068505-20-000020:notes:68]

[0000068505-20-000028:notes:71]
[same as prior period, unchanged from 0000068505-20-000020:notes:69]

[0000068505-20-000028:notes:72]
|  | September 26, 2020 |  | December 31, 2019 |
| Current contract cost assets (Note 2) | $ | 25 |  |  | $ | 24 |  |
| Tax-related deposits | 65 |  |  | 77 |  |
| Other | 161 |  |  | 171 |  |
|  | $ | 251 |  |  | $ | 272 |  |

[0000068505-20-000028:notes:73]
[same as prior period, unchanged from 0000068505-20-000020:notes:71]

[0000068505-20-000028:notes:74]
[same as prior period, unchanged from 0000068505-20-000020:notes:72]

[0000068505-20-000028:notes:75]
|  | September 26, 2020 |  | December 31, 2019 |
| Land | $ | 6 |  |  | $ | 15 |  |
| Leasehold improvements | 415 |  |  | 410 |  |
| Machinery and equipment | 2,169 |  |  | 2,051 |  |
|  | 2,590 |  |  | 2,476 |  |
| Less accumulated depreciation | (1,614) |  |  | (1,484) |  |
|  | $ | 976 |  |  | $ | 992 |  |

[0000068505-20-000028:notes:76]
Depreciation expense for the three months ended September 26, 2020 and September 28, 2019 was $49 million and $47 million, respectively. Depreciation expense for the nine months ended September 26, 2020 and September 28, 2019 was $142 million and $136 million, respectively.

[0000068505-20-000028:notes:77]
[same as prior period, unchanged from 0000068505-20-000020:notes:75]

[0000068505-20-000028:notes:78]
[same as prior period, unchanged from 0000068505-20-000020:notes:76]

[0000068505-20-000028:notes:79]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Common stock | $ | 17 |  |  | $ | 25 |  |  |  |  |  |
| Strategic investments, at cost | 47 |  |  | 40 |  |  |  |  |  |
| Company-owned life insurance policies | 72 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 18 |  |  | 20 |  |  |  |  |  |
|  | $ | 154 |  |  | $ | 159 |  |  |  |  |  |

[0000068505-20-000028:notes:80]
[same as prior period, unchanged from 0000068505-20-000020:notes:78]

[0000068505-20-000028:notes:81]
[same as prior period, unchanged from 0000068505-20-000020:notes:79]

[0000068505-20-000028:notes:82]
|  | September 26, 2020 |  | December 31, 2019 |
| Defined benefit plan assets | $ | 279 |  |  | $ | 223 |  |
| Non-current contract cost assets (Note 2) | 101 |  |  | 107 |  |
| Other | 57 |  |  | 92 |  |
|  | $ | 437 |  |  | $ | 422 |  |

[0000068505-20-000028:notes:83]
[same as prior period, unchanged from 0000068505-20-000020:notes:81]

[0000068505-20-000028:notes:84]
[same as prior period, unchanged from 0000068505-20-000020:notes:82]

[0000068505-20-000028:notes:85]
|  | September 26, 2020 |  | December 31, 2019 |
| Compensation | $ | 266 |  |  | $ | 347 |  |
| Tax liabilities | 59 |  |  | 95 |  |
| Dividend payable | 109 |  |  | 110 |  |
| Trade liabilities | 143 |  |  | 161 |  |
| Operating lease liabilities (Note 3) | 123 |  |  | 122 |  |
| Other | 505 |  |  | 521 |  |
|  | $ | 1,205 |  |  | $ | 1,356 |  |

[0000068505-20-000028:notes:86]
[same as prior period, unchanged from 0000068505-20-000020:notes:84]

[0000068505-20-000028:notes:87]
[same as prior period, unchanged from 0000068505-20-000020:notes:85]

[0000068505-20-000028:notes:88]
|  | September 26, 2020 |  | December 31, 2019 |
| Defined benefit plans | $ | 1,472 |  |  | $ | 1,524 |  |
| Non-current contract liabilities (Note 2) | 266 |  |  | 274 |  |
| Unrecognized tax benefits | 54 |  |  | 53 |  |
| Deferred income taxes | 179 |  |  | 184 |  |
| Other | 255 |  |  | 241 |  |
|  | $ | 2,226 |  |  | $ | 2,276 |  |

[0000068505-20-000028:notes:89]
[same as prior period, unchanged from 0000068505-20-000020:notes:87]

[0000068505-20-000028:notes:90]
Share Repurchase Program: During the three and nine months ended September 26, 2020, the Company paid an aggregate of $105 million and $441 million, including transaction costs, to repurchase approximately 0.7 million and 2.9 million shares at an average price of $147.35 and $152.79 per share, respectively. As of September 26, 2020, the Company had $820 million of authority available for future repurchases.

[0000068505-20-000028:notes:91]
Payment of Dividends: During the three months ended September 26, 2020 and September 28, 2019, the Company paid $109 million and $94 million, respectively, in cash dividends to holders of its common stock. During the nine months ended September 26, 2020 and September 28, 2019, the Company paid $327 million and $281 million, respectively, in cash dividends to holders of its common stock.

[0000068505-20-000028:notes:92]
[same as prior period, unchanged from 0000068505-20-000020:notes:90]

[0000068505-20-000028:notes:93]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended September 26, 2020 and September 28, 2019:

[0000068505-20-000028:notes:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (470) |  |  | $ | (437) |  |  | $ | (410) |  |  | $ | (444) |  |
| Other comprehensive income (loss) before reclassification adjustment | 34 |  |  | (33) |  |  | (27) |  |  | (23) |  |
| Tax expense | (4) |  |  | — |  |  | (3) |  |  | (3) |  |
| Other comprehensive income (loss), net of tax | 30 |  |  | (33) |  |  | (30) |  |  | (26) |  |
| Balance at end of period | $ | (440) |  |  | $ | (470) |  |  | $ | (440) |  |  | $ | (470) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,005) |  |  | $ | (2,300) |  |  | $ | (2,030) |  |  | $ | (2,321) |  |
| Reclassification adjustment - Actuarial net losses into Other income | 20 |  |  | 16 |  |  | 58 |  |  | 50 |  |
| Reclassification adjustment - Prior service benefits into Other expense | (4) |  |  | (4) |  |  | (12) |  |  | (11) |  |
| Tax expense | (4) |  |  | (1) |  |  | (9) |  |  | (7) |  |
| Other comprehensive income, net of tax | 12 |  |  | 11 |  |  | 37 |  |  | 32 |  |
| Balance at end of period | $ | (1,993) |  |  | $ | (2,289) |  |  | $ | (1,993) |  |  | $ | (2,289) |  |
| Total Accumulated other comprehensive loss | $ | (2,433) |  |  | $ | (2,759) |  |  | $ | (2,433) |  |  | $ | (2,759) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-20-000028:notes:95]
Debt and Credit Facilities

[0000068505-20-000028:notes:96]
|  | September 26, 2020 |  | December 31, 2019 |
| $2.2 billion unsecured revolving credit facility due April 2022 | $ | 200 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | — |  |  | 550 |  |
| 3.5% senior notes due 2023 | 323 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 582 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 993 |  |  | 988 |  |
| 6.5% debentures due 2025 | 70 |  |  | 72 |  |
| 7.5% debentures due 2025 | 252 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 692 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 2.3% senior notes due 2030 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 19 |  |  | 35 |  |
|  | 5,376 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (3) |  |
| Less: current portion | (212) |  |  | (16) |  |
| Long-term debt | $ | 5,162 |  |  | $ | 5,113 |  |

[0000068505-20-000028:notes:97]
As of September 26, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020, of which $600 million was repaid during the nine months ended September 26, 2020. As of September 26, 2020, the outstanding loan amount was $200 million. Subsequent to the quarter, the company repaid an additional $100 million, bringing the outstanding loan amount to $100 million. The weighted average borrowing rate for amounts outstanding during the three and nine months ended September 26, 2020 were 1.50% and 1.71%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 26, 2020.

[0000068505-20-000028:notes:98]
In August of 2020, the Company issued $900 million of 2.30% Senior notes due 2030. The Company recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% Senior notes due 2022 for a redemption price of $582 million, excluding approximately $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of its long-term debt under a tender offer, for a purchase price of $315 million, excluding approximately $5 million of accrued interest, all of which occurred during the three months ended September 26, 2020. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-20-000028:notes:99]
As of September 26, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140, as may be adjusted for dividends declared, per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using 
a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. The Company has an unsecured commercial paper program, backed by the unsecured revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 26, 2020 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-20-000028:notes:100]
[same as prior period, unchanged from 0000068505-20-000020:notes:95]

[0000068505-20-000028:notes:101]
As of September 26, 2020, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.0 billion, compared to $1.1 billion outstanding at December 31, 2019. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-20-000028:notes:102]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 26, 2020, and the corresponding positions as of December 31, 2019:

[0000068505-20-000028:notes:103]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 26, 2020 |  | December 31, 2019 |
| Euro | $ | 196 |  |  | $ | 134 |  |
| British pound | 134 |  |  | 107 |  |
| Norwegian krone | 29 |  |  | 32 |  |
| Australian dollar | (93) |  |  | (123) |  |
| Chinese renminbi | (77) |  |  | (79) |  |

[0000068505-20-000028:notes:104]
[same as prior period, unchanged from 0000068505-20-000020:notes:99]

[0000068505-20-000028:notes:105]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 26, 2020, all of the counterparties have investment grade credit ratings. As of September 26, 2020, the Company had $1 million of exposure to aggregate credit risk with all counterparties.

[0000068505-20-000028:notes:106]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of September 26, 2020 and December 31, 2019:

[0000068505-20-000028:notes:107]
|  | Fair Values of Derivative Instruments |
| September 26, 2020 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 2 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 1 |  |  | 7 |  |
| Total derivatives | $ | 1 |  |  | $ | 9 |  |

[0000068505-20-000028:notes:108]
|  | Fair Values of Derivative Instruments |
| December 31, 2019 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 1 |  |  | 5 |  |
| Total derivatives | $ | 4 |  |  | $ | 5 |  |

[0000068505-20-000028:notes:109]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended September 26, 2020 and September 28, 2019:

[0000068505-20-000028:notes:110]
|  | Three Months Ended |  | Nine Months Ended |  | Financial Statement Location |
| Foreign Exchange Contracts | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |  |
| Effective portion | $ | (5) |  |  | $ | 8 |  |  | $ | 3 |  |  | $ | 16 |  |  | Accumulated othercomprehensive income |
| Forward points recognized | — |  |  | 2 |  |  | 2 |  |  | 5 |  |  | Other income |
| Undesignated derivatives recognized | 10 |  |  | (9) |  |  | 6 |  |  | (16) |  |  | Other expense |

[0000068505-20-000028:notes:111]
[same as prior period, unchanged from 0000068505-20-000020:notes:106]

[0000068505-20-000028:notes:112]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. As of September 26, 2020, the Company had €94 million of net investment hedges in certain Euro functional subsidiaries and £60 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-20-000028:notes:113]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense.  During the nine months ended September 26, 2020, the Company amortized $2 million of income from the excluded components through interest expense. During the three and nine months ended September 28, 2019, the Company amortized $2 million, and $5 million, respectively, of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-20-000028:notes:114]
[same as prior period, unchanged from 0000068505-20-000020:notes:109]

[0000068505-20-000028:notes:115]
[same as prior period, unchanged from 0000068505-20-000020:notes:110]

[0000068505-20-000028:notes:116]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Net earnings before income taxes | $ | 251 |  |  | $ | 348 |  |  | $ | 652 |  |  | $ | 808 |  |
| Income tax expense | 45 |  |  | 80 |  |  | 112 |  |  | 180 |  |
| Effective tax rate | 18 | % |  | 23 | % |  | 17 | % |  | 22 | % |

[0000068505-20-000028:notes:117]
During the three and nine months ended September 26, 2020, the Company recorded $45 million and $112 million of net tax expense, resulting in an effective tax rate of 18% and 17%, respectively. During the three and nine months ended September 28, 2019, the Company recorded $80 million and $180 million of net tax expense, resulting in an effective tax rate of 23% and 22%, respectively. The three and nine months ended September 26, 2020 and September 28, 2019 effective tax rates are different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset primarily by tax benefits related to stock compensation and favorable U.S. return-to-provision adjustments. The effective tax rate for the three and nine months ended September 26, 2020 of 18% and 17%, respectively, is lower than the effective tax rate for the three and nine months ended 
September 28, 2019 of 23% and 22%, respectively, primarily due to an increased benefit of forecasted research and development tax credit in the annual effective tax rate and favorable U.S. return-to-provision adjustments recorded in 2020.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-20-000028:notes:118]
[same as prior period, unchanged from 0000068505-20-000020:notes:113]

[0000068505-20-000028:notes:119]
[same as prior period, unchanged from 0000068505-20-000020:notes:114]

[0000068505-20-000028:notes:120]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 36 |  |  | 50 |  |  | 7 |  |  | 9 |  |  | — |  |  | 1 |  |
| Expected return on plan assets | (57) |  |  | (69) |  |  | (21) |  |  | (20) |  |  | (3) |  |  | (2) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 11 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | — |  |  | (3) |  |  | (4) |  |
| Net periodic pension benefits | $ | (6) |  |  | $ | (8) |  |  | $ | (11) |  |  | $ | (7) |  |  | $ | (5) |  |  | $ | (4) |  |

[0000068505-20-000028:notes:121]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 108 |  |  | 152 |  |  | 21 |  |  | 29 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (169) |  |  | (207) |  |  | (63) |  |  | (62) |  |  | (8) |  |  | (7) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 44 |  |  | 35 |  |  | 11 |  |  | 12 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | — |  |  | (11) |  |  | (11) |  |
| Net periodic pension benefits | $ | (17) |  |  | $ | (20) |  |  | $ | (31) |  |  | $ | (19) |  |  | $ | (15) |  |  | $ | (13) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-20-000028:notes:122]
[same as prior period, unchanged from 0000068505-20-000020:notes:117]

[0000068505-20-000028:notes:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 3 |  |  | $ | 3 |  |  | $ | 12 |  |  | $ | 11 |  |
| Selling, general and administrative expenses | 18 |  |  | 16 |  |  | 57 |  |  | 46 |  |
| Research and development expenditures | 10 |  |  | 11 |  |  | 31 |  |  | 30 |  |
| Share-based compensation expense included in Operating earnings | 31 |  |  | 30 |  |  | 100 |  |  | 87 |  |
| Tax benefit | (5) |  |  | (5) |  |  | (17) |  |  | (16) |  |
| Share-based compensation expense, net of tax | $ | 26 |  |  | $ | 25 |  |  | $ | 83 |  |  | $ | 71 |  |
| Decrease in basic earnings per share | $ | (0.15) |  |  | $ | (0.15) |  |  | $ | (0.49) |  |  | $ | (0.43) |  |
| Decrease in diluted earnings per share | $ | (0.15) |  |  | $ | (0.14) |  |  | $ | (0.48) |  |  | $ | (0.40) |  |

[0000068505-20-000028:notes:124]
During the nine months ended September 26, 2020, the Company granted 0.5 million restricted stock units ("RSUs"), 0.03 million performance stock units ("PSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $67 million, $7 million, and $9 million, respectively, and 0.2 million stock options and 0.1 million performance options ("POs") with an aggregate grant-date fair value of $6 million and $9 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-20-000028:notes:125]
During the nine months ended September 26, 2020, the Company granted 0.1 million shares of restricted stock in connection with acquisitions, for an aggregate grant-date fair value of $9 million related to compensation withheld from the purchase prices that will be expensed over an average service period of two years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-20-000028:notes:126]
[same as prior period, unchanged from 0000068505-20-000020:notes:121]

[0000068505-20-000028:notes:127]
[same as prior period, unchanged from 0000068505-20-000020:notes:122]

[0000068505-20-000028:notes:128]
[same as prior period, unchanged from 0000068505-20-000020:notes:123]

[0000068505-20-000028:notes:129]
[same as prior period, unchanged from 0000068505-20-000020:notes:124]

[0000068505-20-000028:notes:130]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 26, 2020 and December 31, 2019 were as follows:

[0000068505-20-000028:notes:131]
| September 26, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  |  |  | $ | 1 |  |
| Common stock | 17 |  |  | — |  |  |  |  | 17 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |

[0000068505-20-000028:notes:132]
[same as prior period, unchanged from 0000068505-20-000020:notes:127]

[0000068505-20-000028:notes:133]
The Company had no Level 3 holdings as of September 26, 2020 or December 31, 2019.

[0000068505-20-000028:notes:134]
At September 26, 2020 and December 31, 2019, the Company had $308 million and $322 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-20-000028:notes:135]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at September 26, 2020 and December 31, 2019 was $5.9 billion and $5.5 billion (Level 2), respectively.

[0000068505-20-000028:notes:136]
[same as prior period, unchanged from 0000068505-20-000020:notes:131]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-20-000028:notes:137]
[same as prior period, unchanged from 0000068505-20-000020:notes:132]

[0000068505-20-000028:notes:138]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 26, 2020 and September 28, 2019:

[0000068505-20-000028:notes:139]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Accounts receivable sales proceeds | $ | 82 |  |  | $ | 4 |  |  | $ | 238 |  |  | $ | 31 |  |
| Long-term receivables sales proceeds | 45 |  |  | 56 |  |  | 115 |  |  | 132 |  |
| Total proceeds from receivable sales | $ | 127 |  |  | $ | 60 |  |  | $ | 353 |  |  | $ | 163 |  |

[0000068505-20-000028:notes:140]
At September 26, 2020, the Company had retained servicing obligations for $1.0 billion of long-term receivables, compared to $984 million at December 31, 2019. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $59 million at September 26, 2020, compared to $78 million at December 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-20-000028:notes:141]
Commitments and ContingenciesLegal MattersOn February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in its trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. A motion for a new trial was filed by Hytera in April 2020. The Court denied the motion and upheld the damages awarded to the Company on October 20, 2020, subsequent to the quarter. Other post-trial motions are fully briefed and awaiting ruling, including the Company's motion for a permanent global injunction, as well as the Company's requests for attorneys' fees and increased damages to include post-trial amounts. Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in May 2020; the Company filed motions to dismiss the bankruptcy proceedings in July 2020. As of the third quarter of 2020, the United States Bankruptcy Court granted a continuance of Hytera’s sale motion and the Company’s motion to dismiss Hytera’s bankruptcy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-20-000028:notes:142]
[same as prior period, unchanged from 0000068505-20-000020:notes:138]

[0000068505-20-000028:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Products and Systems Integration | $ | 1,163 |  |  | $ | 1,349 |  |  | $ | 3,124 |  |  | $ | 3,656 |  |
| Software and Services | 705 |  |  | 645 |  |  | 2,017 |  |  | 1,855 |  |
|  | $ | 1,868 |  |  | $ | 1,994 |  |  | $ | 5,141 |  |  | $ | 5,511 |  |

[0000068505-20-000028:notes:144]
[same as prior period, unchanged from 0000068505-20-000020:notes:140]

[0000068505-20-000028:notes:145]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Products and Systems Integration | $ | 164 |  |  | $ | 258 |  |  | $ | 305 |  |  | $ | 568 |  |
| Software and Services | 188 |  |  | 155 |  |  | 523 |  |  | 423 |  |
| Operating earnings | 352 |  |  | 413 |  |  | 828 |  |  | 991 |  |
| Total other expense | (101) |  |  | (65) |  |  | (176) |  |  | (183) |  |
| Earnings before income taxes | $ | 251 |  |  | $ | 348 |  |  | $ | 652 |  |  | $ | 808 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-20-000028:notes:146]
Reorganization of Business
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits. In addition to the Involuntary Severance Plan, during the nine months ended September 26, 2020, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at nine months of salary, were equalized for all employment level grades and capped at a full year’s salary for the voluntary applicants.

[0000068505-20-000028:notes:147]
[same as prior period, unchanged from 0000068505-20-000020:notes:143]

[0000068505-20-000028:notes:148]
During the three months ended September 26, 2020, the Company recorded net reorganization of business charges of $13 million including $10 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $16 million related to employee separation, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-20-000028:notes:149]
During the nine months ended September 26, 2020, the Company recorded net reorganization of business charges of $72 million including $48 million of charges in Other charges and $24 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $72 million were charges of $85 million related to employee separation, partially offset by $13 million of reversals for accruals no longer needed.

[0000068505-20-000028:notes:150]
[same as prior period, unchanged from 0000068505-20-000020:notes:146]

[0000068505-20-000028:notes:151]
| September 26, 2020 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 10 |  |  | $ | 58 |  |
| Software and Services | 3 |  |  | 14 |  |
|  | $ | 13 |  |  | $ | 72 |  |

[0000068505-20-000028:notes:152]
The following table displays a rollforward of the reorganization of business accruals established for employee separation costs from January 1, 2020 to September 26, 2020:

[0000068505-20-000028:notes:153]
|  | January 1, 2020 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | September 26, 2020 |
| Employee separation costs | $ | 78 |  |  | $ | 85 |  |  | $ | (13) |  |  | $ | (63) |  |  | $ | 87 |  |

[0000068505-20-000028:notes:154]
[same as prior period, unchanged from 0000068505-20-000020:notes:150]

[0000068505-20-000028:notes:155]
At January 1, 2020, the Company had an accrual of $78 million for employee separation costs. The 2020 additional charges of $85 million represent severance costs for approximately 900 employees. The adjustment of $13 million reflects reversals for accruals no longer needed. The $63 million used reflects cash payments to severed employees. The remaining accrual of $87 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at September 26, 2020, is expected to be paid, primarily within one year, to approximately 1,000 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-20-000028:notes:156]
[same as prior period, unchanged from 0000068505-20-000020:notes:152]

[0000068505-20-000028:notes:157]
During the three months ended September 28, 2019, the Company recorded net reorganization of business charges of $18 million including $15 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $19 million related to employee separation costs and $1 million of reversals for accruals no longer needed.

[0000068505-20-000028:notes:158]
During the nine months ended September 28, 2019, the Company recorded net reorganization of business charges of $37 million including $27 million of charges in Other charges and $10 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $37 million were charges of $48 million related to employee separation costs and $11 million of reversals for accruals no longer needed.

[0000068505-20-000028:notes:159]
| September 28, 2019 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 14 |  |  | $ | 29 |  |
| Software and Services | 4 |  |  | 8 |  |
|  | $ | 18 |  |  | $ | 37 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-20-000028:notes:160]
Intangible Assets and Goodwill
On August 28, 2020, the Company acquired Callyo, a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing command center software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The Company recognized $38 million of goodwill, $31 million of identifiable intangible assets, and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $27 million of customer relationships and $4 million of developed technology that will be amortized over a period of fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-20-000028:notes:161]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $42 million of goodwill, $30 million of identifiable intangible assets, and $36 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-20-000028:notes:162]
On June 16, 2020, the Company acquired IndigoVision for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The Company recognized $14 million of goodwill, $22 million of identifiable intangible assets, and $1 million of net liabilities.  The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting is not yet complete and as such the final allocation between income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-20-000028:notes:163]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The Company recognized $23 million of goodwill, $10 million of identifiable intangible assets and $1 million of net liabilities.  The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $8 million of customer relationships and $2 million of developed technology that will be amortized over a period of twelve years and three years, respectively.  The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.  The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000028:notes:164]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The Company recognized $28 million of goodwill, $7 million of intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000028:notes:165]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million in cash, net of cash acquired. The acquisition enhances the Company's video security platform by adding data to the Company’s existing LPR database within the Software and Services segment. The Company recognized $54 million of goodwill, $28 million of identifiable intangible assets, and $3 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $22 million of customer relationships and $6 million of developed technology and will be amortized over a period of sixteen years and five years, respectively. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000028:notes:166]
On July 11, 2019, the Company acquired WatchGuard, a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's video security solutions platform. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $156 million of goodwill, $63 million of identifiable intangible assets, and $31 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of completed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting was completed as of the third quarter of 2020.

[0000068505-20-000028:notes:167]
On March 11, 2019, the Company announced that it acquired Avtec, a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Software and Services segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of 15 years. The purchase accounting was completed as of the third quarter of 2019.

[0000068505-20-000028:notes:168]
On January 7, 2019, the Company announced that it acquired VaaS, a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business will be part of both the Products and Systems Integration and Software and Services segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of 15 years. The purchase accounting was completed as of the first quarter of 2020.

[0000068505-20-000028:notes:169]
[same as prior period, unchanged from 0000068505-20-000020:notes:164]

[0000068505-20-000028:notes:170]
[same as prior period, unchanged from 0000068505-20-000020:notes:165]

[0000068505-20-000028:notes:171]
|  | September 26, 2020 |  | December 31, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 760 |  |  | $ | 193 |  |  | $ | 738 |  |  | $ | 148 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,284 |  |  | 613 |  |  | 1,222 |  |  | 518 |  |
| Other intangibles | 77 |  |  | 47 |  |  | 75 |  |  | 42 |  |
|  | $ | 2,123 |  |  | $ | 855 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-20-000028:notes:172]
Amortization expense on intangible assets was $54 million and $158 million for the three and nine months ended September 26, 2020, respectively.  Amortization expense on intangible assets was $52 million and $154 million for the three and nine months ended September 28, 2019, respectively.  As of September 26, 2020, annual amortization expense is estimated to be $210 million in 2020, $208 million 2021, $206 million in 2022, $108 million in 2023, $83 million in 2024, and $73 million in 2025.

[0000068505-20-000028:notes:173]
[same as prior period, unchanged from 0000068505-20-000020:notes:168]

[0000068505-20-000028:notes:174]
|  | September 26, 2020 |  | December 31, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 690 |  |  | $ | 116 |  |  | $ | 652 |  |  | $ | 82 |  |
| Software and Services | 1,433 |  |  | 739 |  |  | 1,385 |  |  | 628 |  |
|  | $ | 2,123 |  |  | $ | 855 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-20-000028:notes:175]
[same as prior period, unchanged from 0000068505-20-000020:notes:170]

[0000068505-20-000028:notes:176]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2020 to September 26, 2020:

[0000068505-20-000028:notes:177]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2020 | $ | 973 |  |  | $ | 1,094 |  |  | $ | 2,067 |  |
| Goodwill acquired | 46 |  |  | 99 |  |  | 145 |  |
| Foreign currency | — |  |  | (5) |  |  | (5) |  |
| Balance as of September 26, 2020 | $ | 1,019 |  |  | $ | 1,188 |  |  | $ | 2,207 |  |
