# MSI note change history — 0000068505-20-000020 → 0000068505-20-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000068505-20-000028:note_history:1]
Commitments and ContingenciesLegal MattersOn February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in its trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. A motion for a new trial was filed by Hytera in April 2020. The Court denied the motion and upheld the damages awarded to the Company on October 20, 2020, subsequent to the quarter. Other post-trial motions are fully briefed and awaiting ruling, including the Company's motion for a permanent global injunction, as well as the Company's requests for attorneys' fees and increased damages to include post-trial amounts. Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in May 2020; the Company filed motions to dismiss the bankruptcy proceedings in July 2020. As of the third quarter of 2020, the United States Bankruptcy Court granted a continuance of Hytera’s sale motion and the Company’s motion to dismiss Hytera’s bankruptcy.
  (was, 2020-08-07, similarity 0.6436):
[0000068505-20-000020:note_history:1]
As previously disclosed, on February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in it's trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million.  A motion for a new trial was filed by Hytera during the second quarter of 2020. In addition, during the second quarter of 2020 Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection; subsequent to the end of the second quarter, the Company filed motions to dismiss the bankruptcy proceedings.

- removed (2020-10-30):
[0000068505-20-000020:note_history:2]
Commitments and Contingencies
Legal Matters


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000068505-20-000028:note_history:3]
Basis of Presentation
The condensed consolidated financial statements as of September 26, 2020 and for the three and nine months ended September 26, 2020 and September 28, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2020-08-07, similarity 0.9255):
[0000068505-20-000020:note_history:3]
Basis of Presentation
The condensed consolidated financial statements as of June 27, 2020 and for the three and six months ended June 27, 2020 and June 29, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2020-10-30):
[0000068505-20-000028:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three and nine months ended September 26, 2020 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2020-08-07, similarity 0.8106):
[0000068505-20-000020:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three and six months ended June 27, 2020 are not necessarily indicative of the operating results to be expected for the full year.

- added (2020-10-30):
[0000068505-20-000028:note_history:5]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing command center software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

- added (2020-10-30):
[0000068505-20-000028:note_history:6]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2020-10-30):
[0000068505-20-000028:note_history:7]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share ("EPS"). The ASU clarifies that the average market price should be used to calculate the diluted EPS denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

- changed (2020-10-30):
[0000068505-20-000028:note_history:8]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The adoption of the ASU will not have a significant impact on the financial statement disclosures.
  (was, 2020-08-07, similarity 0.8354):
[0000068505-20-000020:note_history:8]
In December 2019, the FASB issued Accounting Standard Update ("ASU") No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company is still evaluating the impact of adoption on its disclosures.

- changed (2020-10-30):
[0000068505-20-000028:note_history:9]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information was not updated and disclosures required under ASC 326 are not provided for dates and periods before January 1, 2020.
  (was, 2020-08-07, similarity 0.9851):
[0000068505-20-000020:note_history:9]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.

- changed (2020-10-30):
[0000068505-20-000028:note_history:10]
|  | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at September 26, 2020 |
| Allowance for credit losses | $ | 63 |  | $ | 38 |  | $ | (26) |  | $ | (2) |  | $ | 73 |  |
  (was, 2020-08-07, similarity 0.9699):
[0000068505-20-000020:note_history:10]
|  | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at June 27, 2020 |
| Allowance for credit losses | $ | 63 |  | $ | 24 |  | $ | (8) |  | $ | (2) |  | $ | 77 |  |

- removed (2020-10-30):
[0000068505-20-000020:note_history:11]
On July 31, 2020, the Company acquired Pelco, Inc., a global provider of video security solutions for $110 million in cash. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, adding to its existing video portfolio a broad range of products that can be used in a variety of commercial and industrial environments and use cases.  The business will be part of both the Products and Systems Integration segment and the Software and Services segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-10-30):
[0000068505-20-000028:note_history:12]
Debt and Credit Facilities

- added (2020-10-30):
[0000068505-20-000028:note_history:13]
|  | September 26, 2020 |  | December 31, 2019 |
| $2.2 billion unsecured revolving credit facility due April 2022 | $ | 200 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | — |  |  | 550 |  |
| 3.5% senior notes due 2023 | 323 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 582 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 993 |  |  | 988 |  |
| 6.5% debentures due 2025 | 70 |  |  | 72 |  |
| 7.5% debentures due 2025 | 252 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 692 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 2.3% senior notes due 2030 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 19 |  |  | 35 |  |
|  | 5,376 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (3) |  |
| Less: current portion | (212) |  |  | (16) |  |
| Long-term debt | $ | 5,162 |  |  | $ | 5,113 |  |

- changed (2020-10-30):
[0000068505-20-000028:note_history:14]
As of September 26, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020, of which $600 million was repaid during the nine months ended September 26, 2020. As of September 26, 2020, the outstanding loan amount was $200 million. Subsequent to the quarter, the company repaid an additional $100 million, bringing the outstanding loan amount to $100 million. The weighted average borrowing rate for amounts outstanding during the three and nine months ended September 26, 2020 were 1.50% and 1.71%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 26, 2020.
  (was, 2020-08-07, similarity 0.9126):
[0000068505-20-000020:note_history:14]
Debt and Credit Facilities
As of June 27, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020, of which $300 million was repaid during the three months ended June 27, 2020. As of June 27, 2020, the outstanding loan amount was $500 million.  Subsequent to the quarter, the company repaid an additional $200 million. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 27, 2020 were 1.69% and 1.79%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 27, 2020.

- added (2020-10-30):
[0000068505-20-000028:note_history:15]
In August of 2020, the Company issued $900 million of 2.30% Senior notes due 2030. The Company recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% Senior notes due 2022 for a redemption price of $582 million, excluding approximately $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of its long-term debt under a tender offer, for a purchase price of $315 million, excluding approximately $5 million of accrued interest, all of which occurred during the three months ended September 26, 2020. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- changed (2020-10-30):
[0000068505-20-000028:note_history:16]
As of September 26, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140, as may be adjusted for dividends declared, per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using 
a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. The Company has an unsecured commercial paper program, backed by the unsecured revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 26, 2020 the Company had no outstanding debt under the commercial paper program.
  (was, 2020-08-07, similarity 0.9905):
[0000068505-20-000020:note_history:16]
As of June 27, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140, as may be adjusted for dividends declared, per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
The Company has an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 27, 2020 the Company had no outstanding debt under the commercial paper program.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-10-30):
[0000068505-20-000028:note_history:17]
|  | September 26, 2020 |  | December 31, 2019 |
| $2.2 billion unsecured revolving credit facility due April 2022 | $ | 200 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | — |  |  | 550 |  |
| 3.5% senior notes due 2023 | 323 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 582 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 993 |  |  | 988 |  |
| 6.5% debentures due 2025 | 70 |  |  | 72 |  |
| 7.5% debentures due 2025 | 252 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 692 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 2.3% senior notes due 2030 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 19 |  |  | 35 |  |
|  | 5,376 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (3) |  |
| Less: current portion | (212) |  |  | (16) |  |
| Long-term debt | $ | 5,162 |  |  | $ | 5,113 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000068505-20-000028:note_history:18]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 26, 2020 and September 28, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:
  (was, 2020-08-07, similarity 0.6339):
[0000068505-20-000020:note_history:18]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 27, 2020 and June 29, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:

- changed (2020-10-30):
[0000068505-20-000028:note_history:19]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 863 |  |  | $ | 405 |  |  | $ | 980 |  |  | $ | 364 |  |
| International | 300 |  |  | 300 |  |  | 369 |  |  | 281 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 719 |  |  | $ | — |  |  | $ | 896 |  |  | $ | — |  |
| Systems and Systems Integration | 444 |  |  | — |  |  | 453 |  |  | — |  |
| Services | — |  |  | 514 |  |  | — |  |  | 479 |  |
| Software | — |  |  | 191 |  |  | — |  |  | 166 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 733 |  |  | $ | 637 |  |  | $ | 860 |  |  | $ | 602 |  |
| Indirect | 430 |  |  | 68 |  |  | 489 |  |  | 43 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
  (was, 2020-08-07, similarity 0.9588):
[0000068505-20-000020:note_history:19]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 719 |  |  | $ | 374 |  |  | $ | 911 |  |  | $ | 342 |  |
| International | 249 |  |  | 276 |  |  | 327 |  |  | 280 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 582 |  |  | $ | — |  |  | $ | 809 |  |  | $ | — |  |
| Systems and Systems Integration | 386 |  |  | — |  |  | 429 |  |  | — |  |
| Services | — |  |  | 484 |  |  | — |  |  | 469 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 153 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 634 |  |  | $ | 611 |  |  | $ | 771 |  |  | $ | 582 |  |
| Indirect | 334 |  |  | 39 |  |  | 467 |  |  | 40 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |

- changed (2020-10-30):
[0000068505-20-000028:note_history:20]
|  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 2,646 |  |  | $ | 1,026 |  |
| International | 794 |  |  | 871 |  |  | 1,010 |  |  | 829 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,921 |  |  | $ | — |  |  | $ | 2,391 |  |  | $ | — |  |
| Systems and Systems Integration | 1,203 |  |  | — |  |  | 1,265 |  |  | — |  |
| Services | — |  |  | 1,490 |  |  | — |  |  | 1,400 |  |
| Software | — |  |  | 527 |  |  | — |  |  | 455 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 2,289 |  |  | $ | 1,737 |  |
| Indirect | 1,116 |  |  | 148 |  |  | 1,367 |  |  | 118 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
  (was, 2020-08-07, similarity 0.9547):
[0000068505-20-000020:note_history:20]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 1,467 |  |  | $ | 742 |  |  | $ | 1,666 |  |  | $ | 662 |  |
| International | 494 |  |  | 570 |  |  | 641 |  |  | 548 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,202 |  |  | $ | — |  |  | $ | 1,495 |  |  | $ | — |  |
| Systems and Systems Integration | 759 |  |  | — |  |  | 812 |  |  | — |  |
| Services | — |  |  | 976 |  |  | — |  |  | 921 |  |
| Software | — |  |  | 336 |  |  | — |  |  | 289 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 1,429 |  |  | $ | 1,135 |  |
| Indirect | 686 |  |  | 80 |  |  | 878 |  |  | 75 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000068505-20-000028:note_history:21]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 26, 2020 and September 28, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:
  (was, 2020-08-07, similarity 0.6339):
[0000068505-20-000020:note_history:21]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 27, 2020 and June 29, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:

- changed (2020-10-30):
[0000068505-20-000028:note_history:22]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 863 |  |  | $ | 405 |  |  | $ | 980 |  |  | $ | 364 |  |
| International | 300 |  |  | 300 |  |  | 369 |  |  | 281 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 719 |  |  | $ | — |  |  | $ | 896 |  |  | $ | — |  |
| Systems and Systems Integration | 444 |  |  | — |  |  | 453 |  |  | — |  |
| Services | — |  |  | 514 |  |  | — |  |  | 479 |  |
| Software | — |  |  | 191 |  |  | — |  |  | 166 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 733 |  |  | $ | 637 |  |  | $ | 860 |  |  | $ | 602 |  |
| Indirect | 430 |  |  | 68 |  |  | 489 |  |  | 43 |  |
|  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,349 |  |  | $ | 645 |  |
  (was, 2020-08-07, similarity 0.9588):
[0000068505-20-000020:note_history:22]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 719 |  |  | $ | 374 |  |  | $ | 911 |  |  | $ | 342 |  |
| International | 249 |  |  | 276 |  |  | 327 |  |  | 280 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 582 |  |  | $ | — |  |  | $ | 809 |  |  | $ | — |  |
| Systems and Systems Integration | 386 |  |  | — |  |  | 429 |  |  | — |  |
| Services | — |  |  | 484 |  |  | — |  |  | 469 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 153 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 634 |  |  | $ | 611 |  |  | $ | 771 |  |  | $ | 582 |  |
| Indirect | 334 |  |  | 39 |  |  | 467 |  |  | 40 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |

- changed (2020-10-30):
[0000068505-20-000028:note_history:23]
|  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 2,646 |  |  | $ | 1,026 |  |
| International | 794 |  |  | 871 |  |  | 1,010 |  |  | 829 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,921 |  |  | $ | — |  |  | $ | 2,391 |  |  | $ | — |  |
| Systems and Systems Integration | 1,203 |  |  | — |  |  | 1,265 |  |  | — |  |
| Services | — |  |  | 1,490 |  |  | — |  |  | 1,400 |  |
| Software | — |  |  | 527 |  |  | — |  |  | 455 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 2,289 |  |  | $ | 1,737 |  |
| Indirect | 1,116 |  |  | 148 |  |  | 1,367 |  |  | 118 |  |
|  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 3,656 |  |  | $ | 1,855 |  |
  (was, 2020-08-07, similarity 0.9547):
[0000068505-20-000020:note_history:23]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 1,467 |  |  | $ | 742 |  |  | $ | 1,666 |  |  | $ | 662 |  |
| International | 494 |  |  | 570 |  |  | 641 |  |  | 548 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,202 |  |  | $ | — |  |  | $ | 1,495 |  |  | $ | — |  |
| Systems and Systems Integration | 759 |  |  | — |  |  | 812 |  |  | — |  |
| Services | — |  |  | 976 |  |  | — |  |  | 921 |  |
| Software | — |  |  | 336 |  |  | — |  |  | 289 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 1,429 |  |  | $ | 1,135 |  |
| Indirect | 686 |  |  | 80 |  |  | 878 |  |  | 75 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |

- changed (2020-10-30):
[0000068505-20-000028:note_history:24]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction prices associated with remaining performance obligations which are not yet satisfied as of September 26, 2020 are $6.8 billion. A total of $2.9 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion is from Software and Services performance obligations that are not yet satisfied as of September 26, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.4 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2020-08-07, similarity 0.9887):
[0000068505-20-000020:note_history:24]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 27, 2020 is $6.6 billion. A total of $2.8 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion is from Software and Services performance obligations that are not yet satisfied as of June 27, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2020-10-30):
[0000068505-20-000028:note_history:25]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,155 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 1,069 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,359 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 266 |  |  | 274 |  |  |  |  |  |
  (was, 2020-08-07, similarity 0.9256):
[0000068505-20-000020:note_history:25]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,134 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 937 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,294 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 263 |  |  | 274 |  |  |  |  |  |

- added (2020-10-30):
[0000068505-20-000028:note_history:26]
Revenue recognized during the three months ended September 26, 2020 which was previously included in Contract liabilities as of June 27, 2020 is $349 million, compared to $342 million of revenue recognized during the three months ended September 28, 2019 which was previously included in Contract liabilities as of June 29, 2019. Revenue recognized during the nine months ended September 26, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $807 million, compared to $783 million of revenue recognized during the nine months ended September 28, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $12 million and $48 million was reversed during the three and nine months ended September 26, 2020 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. Revenue of $26 million and $42 million was reversed for the three and nine months ended September 28, 2019 driven by changes in the estimates of progress on system contracts.

- changed (2020-10-30):
[0000068505-20-000028:note_history:27]
There were no material expected credit losses recognized on contract assets during the three and nine months ended September 26, 2020 and September 28, 2019.
  (was, 2020-08-07, similarity 0.9039):
[0000068505-20-000020:note_history:27]
There were no material expected credit losses recognized on contract assets during the three and six months ended June 27, 2020 and June 29, 2019.

- changed (2020-10-30):
[0000068505-20-000028:note_history:28]
|  | September 26, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 25 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 101 |  |  | 107 |  |  |  |  |  |
  (was, 2020-08-07, similarity 0.9664):
[0000068505-20-000020:note_history:28]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 22 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 101 |  |  | 107 |  |  |  |  |  |

- changed (2020-10-30):
[0000068505-20-000028:note_history:29]
Amortization of non-current contract cost assets was $13 million and $35 million for the three and nine months ended September 26, 2020, respectively, and $10 million and $32 million for the three and nine months ended September 28, 2019, respectively
  (was, 2020-08-07, similarity 0.6735):
[0000068505-20-000020:note_history:29]
Amortization of non-current contract cost assets was $11 million and $22 million for both the three and six months ended June 27, 2020 and June 29, 2019, respectively.

- removed (2020-10-30):
[0000068505-20-000020:note_history:30]
Revenue recognized during the three months ended June 27, 2020 which was previously included in Contract liabilities as of March 28, 2020 is $370 million, compared to $340 million of revenue recognized during the three months ended June 29, 2019 which was previously included in Contract liabilities as of March 30, 2019. Revenue recognized during the six months ended June 27, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $631 million, compared to $600 million of revenue recognized during the six months ended June 29, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $12 million and $34 million was reversed during the three and six months ended June 27, 2020 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. Adjustments to revenue for the three and six months ended June 29, 2019 driven by changes in the estimates of progress on system contracts were immaterial.
