# MSI MD&A — 0000068505-20-000028


## mdna

[0000068505-20-000028:mdna:1]
[same as prior period, unchanged from 0000068505-20-000020:mdna:1]

[0000068505-20-000028:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 26, 2020 and September 28, 2019, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2019.

[0000068505-20-000028:mdna:3]
[same as prior period, unchanged from 0000068505-20-000020:mdna:3]

[0000068505-20-000028:mdna:4]
Third Quarter Financial Results

[0000068505-20-000028:mdna:5]
•Net sales were $1.9 billion in the third quarter of 2020 compared to $2.0 billion in the third quarter of 2019.

[0000068505-20-000028:mdna:6]
•Operating earnings were $352 million in the third quarter of 2020 compared to $413 million in the third quarter of 2019.

[0000068505-20-000028:mdna:7]
•Net earnings attributable to Motorola Solutions, Inc. were $205 million, or $1.18 per diluted common share, in the third quarter of 2020, compared to $267 million, or $1.51 per diluted common share, in the third quarter of 2019.

[0000068505-20-000028:mdna:8]
•Our operating cash flow decreased $119 million to $909 million in the first nine months of 2020 compared to the first nine months of 2019.

[0000068505-20-000028:mdna:9]
•We repurchased $441 million of common stock and paid $327 million in dividends in the first nine months of 2020.

[0000068505-20-000028:mdna:10]
[same as prior period, unchanged from 0000068505-20-000020:mdna:10]

[0000068505-20-000028:mdna:11]
In March 2020, the COVID-19 outbreak was declared a pandemic by the World Health Organization. In response, there have been a broad number of governmental and commercial actions including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns in an effort to limit the spread of COVID-19. These events have resulted in a significant decline in global economic activity, and accordingly, we have assessed the impact on our employees, customers, communities, liquidity and financial position.

[0000068505-20-000028:mdna:12]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including having office workers work remotely, suspending employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings and using thermal scanning. We have continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service our mission-critical networks on-site as needed to ensure seamless operations. Our sales teams have also continued to improve virtual engagement with our customers. Additionally, our engineering teams have adapted our solutions offerings to equip our customers with the latest technology in an effort to protect their workplaces from the spread of COVID-19. Specifically, in our video security business, we have adapted our software and hardware offerings to provide analytics over occupancy counting, face mask detection, and thermal detection capabilities.

[0000068505-20-000028:mdna:13]
We have assessed the adequacy of our liquidity as of the third quarter of 2020 and believe the measures taken over the past few years and months allow us the ability to operate under the current conditions. During the first quarter of 2020, we proactively withdrew $800 million from our unsecured revolving credit facility, of which $600 million was repaid during the nine months ended September 26, 2020 and $100 million was repaid subsequent to the quarter. This leaves $2.1 billion of capacity on the committed facility. Additionally, we have no bond maturities until 2023.

[0000068505-20-000028:mdna:14]
We continue to evaluate our financial position during this economic slowdown. Specifically, in our Software and Services segment, with the largely recurring nature of the business and strong backlog position, we continue to expect the impacts on revenue and operating margin will be limited. In our Products and Systems Integration segment, the impacts on revenue and operating margin were more significant during the first half of the year and are expected to have a reduced impact in the fourth quarter of 2020. Reduced demand, particularly in our professional and commercial radio business (“PCR”), as well as delays in engagements with our state and local customers in the near term, will most likely lead to year-over-year sales declines for the segment in 2020, as compared to 2019. Within the Products and Systems Integration segment, we are encouraged by the resiliency of the video security business and expect growth for fiscal year 2020. Given the prioritization of mission-critical communication solutions, we do not anticipate funding at the state and local levels to have a material, negative effect on expected revenues for the remainder of 2020. We have also taken actions in a number of areas to reduce our operating expenses, mostly driven by lower variable compensation, travel costs, contractor spend and reduced real estate footprint to limit the negative effect on operating margins for the year despite the expected reduction of revenue. In addition, our supply chain partners have been supportive and continue to do their part to ensure that service levels to the Company and its customers remain fulfilled.

[0000068505-20-000028:mdna:15]
Lastly, we evaluated whether there were any impairment indicators as of September 26, 2020, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. We concluded that as of the end of the third quarter of 2020, our assets were fairly stated and recoverable.

[0000068505-20-000028:mdna:16]
[same as prior period, unchanged from 0000068505-20-000020:mdna:16]

[0000068505-20-000028:mdna:17]
On August 28, 2020, we acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to our existing command center software suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

[0000068505-20-000028:mdna:18]
On July 31, 2020, we acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates our continued investment in video security and analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-20-000028:mdna:19]
On June 16, 2020 we acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements our video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The business is a part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000028:mdna:20]
On April 30, 2020, we acquired a cybersecurity services business for $32 million of cash, net of cash acquired.  The acquisition expands our ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-20-000028:mdna:21]
On March 3, 2020, we acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands our ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-20-000028:mdna:22]
On October 16, 2019, we acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances our video security platform by adding data to our existing license plate recognition (“LPR”) database within our Software and Services segment.

[0000068505-20-000028:mdna:23]
On July 11, 2019, we acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000028:mdna:24]
On March 11, 2019, we acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands our commercial portfolio with new capabilities, allowing us to offer an enhanced platform for customers to communicate, coordinate resources and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000028:mdna:25]
On January 7, 2019, we announced that we acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000028:mdna:26]
[same as prior period, unchanged from 0000068505-20-000020:mdna:25]

[0000068505-20-000028:mdna:27]
A summary of our segment results for the third quarter of 2020 is as follows:

[0000068505-20-000028:mdna:28]
•In the Products and Systems Integration segment, net sales were $1.2 billion in the third quarter of 2020, a decrease of $186 million, or 14%, compared to $1.3 billion in the third quarter of 2019. On a geographic basis, net sales decreased in both the North America and International regions compared to the year-ago quarter primarily driven by lower PCR and public safety land mobile radio ("LMR") sales, partially offset by growth in video security. Operating earnings were $164 million in the third quarter of 2020, compared to $258 million in the third quarter of 2019. Operating margins decreased in 2020 to 14.1% from 19.1% in 2019 primarily driven by lower sales and gross margin contribution, partially offset by lower operating expenses primarily driven by lower Hytera-related legal expenses, travel expenses, employee incentive costs, indirect expenses, and reorganization charges.

[0000068505-20-000028:mdna:29]
•In the Software and Services segment, net sales were $705 million in the third quarter of 2020, an increase of $60 million, or 9%, compared to net sales of $645 million in the third quarter of 2019. On a geographic basis, net sales increased in both the North America and International regions compared to the year-ago quarter. Operating earnings were $188 million in the third quarter of 2020, compared to $155 million in the third quarter of 2019. Operating margins increased in 2020 to 26.7% from 24.0% in 2019 driven by higher sales and gross margin contribution, along with reduced operating expenses primarily driven by operating leverage, inclusive of lower employee incentive costs and travel expenses.

[0000068505-20-000028:mdna:30]
[same as prior period, unchanged from 0000068505-20-000020:mdna:29]

[0000068505-20-000028:mdna:31]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 26, 2020 |  | % ofSales* |  | September 28, 2019 |  | % ofSales* |  | September 26, 2020 |  | % ofSales* |  | September 28, 2019 |  | % ofSales* |
| Net sales from products | $ | 1,044 |  |  |  |  | $ | 1,196 |  |  |  |  | $ | 2,807 |  |  |  |  | $ | 3,260 |  |  |  |
| Net sales from services | 824 |  |  |  |  | 798 |  |  |  |  | 2,334 |  |  |  |  | 2,251 |  |  |  |
| Net sales | 1,868 |  |  |  |  | 1,994 |  |  |  |  | 5,141 |  |  |  |  | 5,511 |  |  |  |
| Costs of products sales | 487 |  |  | 46.6 | % |  | 501 |  |  | 41.9 | % |  | 1,325 |  |  | 47.2 | % |  | 1,435 |  |  | 44.0 | % |
| Costs of services sales | 472 |  |  | 57.3 | % |  | 486 |  |  | 60.9 | % |  | 1,354 |  |  | 58.0 | % |  | 1,365 |  |  | 60.6 | % |
| Costs of sales | 959 |  |  |  |  | 987 |  |  |  |  | 2,679 |  |  |  |  | 2,800 |  |  |  |
| Gross margin | 909 |  |  | 48.7 | % |  | 1,007 |  |  | 50.5 | % |  | 2,462 |  |  | 47.9 | % |  | 2,711 |  |  | 49.2 | % |
| Selling, general and administrative expenses | 313 |  |  | 16.7 | % |  | 359 |  |  | 18.0 | % |  | 951 |  |  | 18.5 | % |  | 1,035 |  |  | 18.8 | % |
| Research and development expenditures | 175 |  |  | 9.4 | % |  | 172 |  |  | 8.6 | % |  | 505 |  |  | 9.8 | % |  | 505 |  |  | 9.2 | % |
| Other charges | 69 |  |  | 3.7 | % |  | 63 |  |  | 3.2 | % |  | 178 |  |  | 3.5 | % |  | 180 |  |  | 3.3 | % |
| Operating earnings | 352 |  |  | 18.9 | % |  | 413 |  |  | 20.7 | % |  | 828 |  |  | 16.1 | % |  | 991 |  |  | 18.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (58) |  |  | (3.1) | % |  | (54) |  |  | (2.7) | % |  | (167) |  |  | (3.3) | % |  | (165) |  |  | (3.0) | % |
| Gains (losses) on sales of investments and businesses, net | (1) |  |  | (0.1) | % |  | — |  |  | — | % |  | (1) |  |  | — | % |  | 4 |  |  | 0.1 | % |
| Other, net | (42) |  |  | (2.2) | % |  | (11) |  |  | (0.6) | % |  | (8) |  |  | (0.2) | % |  | (22) |  |  | (0.4) | % |
| Total other expense | (101) |  |  | (5.4) | % |  | (65) |  |  | (3.3) | % |  | (176) |  |  | (3.4) | % |  | (183) |  |  | (3.3) | % |
| Net earnings before income taxes | 251 |  |  | 13.4 | % |  | 348 |  |  | 17.5 | % |  | 652 |  |  | 12.7 | % |  | 808 |  |  | 14.7 | % |
| Income tax expense | 45 |  |  | 2.4 | % |  | 80 |  |  | 4.0 | % |  | 112 |  |  | 2.2 | % |  | 180 |  |  | 3.3 | % |
| Net earnings | 206 |  |  | 11.0 | % |  | 268 |  |  | 13.4 | % |  | 540 |  |  | 10.5 | % |  | 628 |  |  | 11.4 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 205 |  |  | 11.0 | % |  | $ | 267 |  |  | 13.4 | % |  | $ | 537 |  |  | 10.4 | % |  | $ | 625 |  |  | 11.3 | % |
| Earnings per diluted common share | $ | 1.18 |  |  |  |  | $ | 1.51 |  |  |  |  | $ | 3.08 |  |  |  |  | $ | 3.56 |  |  |  |

[0000068505-20-000028:mdna:32]
[same as prior period, unchanged from 0000068505-20-000020:mdna:31]

[0000068505-20-000028:mdna:33]
[same as prior period, unchanged from 0000068505-20-000020:mdna:78]

[0000068505-20-000028:mdna:34]
Results of Operations—Three months ended September 26, 2020 compared to three months ended September 28, 2019

[0000068505-20-000028:mdna:35]
The results of operations for the third quarter of 2020 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-20-000028:mdna:36]
[same as prior period, unchanged from 0000068505-20-000020:mdna:35]

[0000068505-20-000028:mdna:37]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 1,163 |  |  | $ | 1,349 |  |  | (14) | % |
| Net sales from Software and Services | 705 |  |  | 645 |  |  | 9 | % |
| Net sales | $ | 1,868 |  |  | $ | 1,994 |  |  | (6) | % |

[0000068505-20-000028:mdna:38]
The Products and Systems Integration segment’s net sales represented 62% of our net sales in the third quarter of 2020 and 68% in the third quarter of 2019. The Software and Services segment’s net sales represented 38% of our net sales in the third quarter of 2020 and 32% in the third quarter of 2019.

[0000068505-20-000028:mdna:39]
Net sales decreased in the third quarter of 2020 compared to the third quarter of 2019. The 14% decline in sales within the Products and Systems Integration segment was driven by a 19% decline in the International region and a 12% decline in the North America region. The 9% increase in sales within the Software and Services segment was driven by an 11% increase in the North America region and a 7% increase in the International region. Net sales includes:

[0000068505-20-000028:mdna:40]
•a decline in the Products and Systems Integration segment, inclusive of $31 million of revenue from acquisitions, driven by a decline in public safety LMR and PCR devices, partially offset by growth in video security;

[0000068505-20-000028:mdna:41]
•growth in the Software and Services segment, inclusive of $24 million of revenue from acquisitions, driven by services and software sales in both North America and International; and

[0000068505-20-000028:mdna:42]
•$6 million from favorable currency rates.

[0000068505-20-000028:mdna:43]
[same as prior period, unchanged from 0000068505-20-000020:mdna:43]

[0000068505-20-000028:mdna:44]
•a 6% decline in the North America region, inclusive of revenue from acquisitions, driven by declines in public safety LMR and PCR devices, partially offset by growth in services, video security and software; and

[0000068505-20-000028:mdna:45]
•an 8% decline in the International region, inclusive of revenue from acquisitions, driven by declines in PCR devices and public safety LMR, partially offset by growth in services, video security and software.

[0000068505-20-000028:mdna:46]
[same as prior period, unchanged from 0000068505-20-000020:mdna:46]

[0000068505-20-000028:mdna:47]
The 14% decrease in the Products and Systems Integration segment was driven by the following:

[0000068505-20-000028:mdna:48]
•20% decline in Devices revenue, inclusive of revenue from acquisitions, primarily driven by a decline in public safety LMR and PCR in both the North America and International regions;

[0000068505-20-000028:mdna:49]
•2% decline in Systems and Systems Integration revenue, inclusive of revenue from acquisitions, driven by a delay in customer engagement due to the COVID-19 pandemic; and

[0000068505-20-000028:mdna:50]
•$31 million of revenue from acquisitions.

[0000068505-20-000028:mdna:51]
[same as prior period, unchanged from 0000068505-20-000020:mdna:51]

[0000068505-20-000028:mdna:52]
The 9% increase in the Software and Services segment was driven by the following:

[0000068505-20-000028:mdna:53]
•7% growth in Services, inclusive of acquisitions, driven by North America;

[0000068505-20-000028:mdna:54]
•15% growth in Software, driven primarily by acquisitions and increases in both video security and command center software; and

[0000068505-20-000028:mdna:55]
•$24 million of revenue from acquisitions.

[0000068505-20-000028:mdna:56]
[same as prior period, unchanged from 0000068505-20-000020:mdna:56]

[0000068505-20-000028:mdna:57]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Gross margin | $ | 909 |  |  | $ | 1,007 |  |  | (10) | % |

[0000068505-20-000028:mdna:58]
Gross margin was 48.7% of net sales in the third quarter of 2020 compared to 50.5% in the third quarter of 2019. The primary drivers of the decrease are as follows:

[0000068505-20-000028:mdna:59]
•lower gross margin contribution in Products and Systems Integration primarily driven by lower sales in public safety LMR and PCR sales; and

[0000068505-20-000028:mdna:60]
•partially offset by higher margins within Software and Services, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth in both services and software and an improved mix of service offerings, along with lower travel and incentive costs within the Services business.

[0000068505-20-000028:mdna:61]
[same as prior period, unchanged from 0000068505-20-000020:mdna:61]

[0000068505-20-000028:mdna:62]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 313 |  |  | $ | 359 |  |  | (13) | % |

[0000068505-20-000028:mdna:63]
SG&A expenses decreased 13% compared to the third quarter of 2019. SG&A expenses were 16.7% of net sales compared to 18.0% of net sales in the third quarter of 2019. The decrease in SG&A expenditures is primarily due to reduced Hytera-related legal expenses, travel expenses, employee incentive costs, and indirect expenses. The overall reduction in SG&A expenses was partially offset by higher expenses associated with acquired businesses.

[0000068505-20-000028:mdna:64]
[same as prior period, unchanged from 0000068505-20-000020:mdna:64]

[0000068505-20-000028:mdna:65]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Research and development expenditures | $ | 175 |  |  | $ | 172 |  |  | 2 | % |

[0000068505-20-000028:mdna:66]
R&D expenditures increased 2% primarily due to higher operating expenses associated with acquired businesses, partially offset by lower employee incentive costs. R&D expenditures were 9.4% of net sales compared to 8.6% of net sales in the third quarter of 2019.

[0000068505-20-000028:mdna:67]
[same as prior period, unchanged from 0000068505-20-000020:mdna:67]

[0000068505-20-000028:mdna:68]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Other charges | $ | 69 |  |  | $ | 63 |  |

[0000068505-20-000028:mdna:69]
Other charges increased by $6 million in the third quarter of 2020 compared to the third quarter of 2019. The change is driven by the following:

[0000068505-20-000028:mdna:70]
•$5 million of acquisition-related transaction fees in the third quarter of 2020 compared to $1 million in the third quarter of 2019;

[0000068505-20-000028:mdna:71]
•No legal settlements in the third quarter of 2020 compared to a $5 million legal settlement gain in the third quarter of 2019; and

[0000068505-20-000028:mdna:72]
•partially offset by $10 million of net reorganization business charges in the third quarter of 2020 compared to $15 million in the third quarter of 2019 (see further detail in “Reorganization of Businesses” section).

[0000068505-20-000028:mdna:73]
31

[0000068505-20-000028:mdna:74]
[same as prior period, unchanged from 0000068505-20-000020:mdna:73]

[0000068505-20-000028:mdna:75]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Operating earnings from Products and Systems Integration | $ | 164 |  |  | $ | 258 |  |
| Operating earnings from Software and Services | 188 |  |  | 155 |  |
| Operating earnings | $ | 352 |  |  | $ | 413 |  |

[0000068505-20-000028:mdna:76]
Operating earnings were down $61 million, or 15%, compared to the third quarter of 2019. The decrease in Operating earnings was due to:

[0000068505-20-000028:mdna:77]
•Products and Systems Integration, which was down $94 million, primarily driven by lower sales and gross margin contribution, partially offset by lower operating expenses primarily driven by lower Hytera-related legal expenses, travel expenses, employee incentive costs, indirect expenses, and reorganization charges;

[0000068505-20-000028:mdna:78]
•partially offset by Software and Services, which was up $33 million, driven by higher sales and gross margin contribution, along with reduced operating expenses primarily driven by operating leverage, inclusive of lower employee incentive costs and travel expenses.

[0000068505-20-000028:mdna:79]
[same as prior period, unchanged from 0000068505-20-000020:mdna:79]

[0000068505-20-000028:mdna:80]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Interest expense, net | $ | (58) |  |  | $ | (54) |  |

[0000068505-20-000028:mdna:81]
The increase in net interest expense in the third quarter of 2020 compared to the third quarter of 2019 was a result of lower interest income earned on cash due to lower interest rates as of and for the period ending September 26, 2020 compared to the period ending September 28, 2019.

[0000068505-20-000028:mdna:82]
[same as prior period, unchanged from 0000068505-20-000020:mdna:82]

[0000068505-20-000028:mdna:83]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Other, net | $ | (42) |  |  | $ | (11) |  |

[0000068505-20-000028:mdna:84]
The increase in net Other expenses in the third quarter of 2020 as compared to the third quarter of 2019 was driven by:

[0000068505-20-000028:mdna:85]
•$56 million loss on extinguishment of long term debt in the third quarter of 2020 compared to $7 million loss in the third quarter of 2019;

[0000068505-20-000028:mdna:86]
•$15 million of foreign currency losses in the third quarter of 2020 compared to $3 million of foreign currency gains in the third quarter of 2019;

[0000068505-20-000028:mdna:87]
•partially offset by a $10 million gain on derivatives in the third quarter of 2020 compared to a $9 million loss on derivatives in the third quarter of 2019; and

[0000068505-20-000028:mdna:88]
•$4 million of losses related to fair value adjustments to equity investments in the third quarter of 2020 compared to $18 million of losses related to fair value adjustments to equity investments in the third quarter of 2019.

[0000068505-20-000028:mdna:89]
[same as prior period, unchanged from 0000068505-20-000020:mdna:90]

[0000068505-20-000028:mdna:90]
|  | Three Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Income tax expense | $ | 45 |  |  | $ | 80 |  |

[0000068505-20-000028:mdna:91]
Income tax expense decreased by $35 million compared to the third quarter of 2019, resulting in an effective tax rate of 18%. Our effective tax rate for the three months ended September 26, 2020 is lower than the effective tax rate for the three months ended September 28, 2019 of 23%, primarily due to an increased benefit of forecasted research and development tax credit in the annual effective tax rate and favorable U.S. return-to-provision adjustments recorded in 2020.

[0000068505-20-000028:mdna:92]
Results of Operations—Nine months ended September 26, 2020 compared to Nine months ended September 28, 2019

[0000068505-20-000028:mdna:93]
[same as prior period, unchanged from 0000068505-20-000020:mdna:94]

[0000068505-20-000028:mdna:94]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 3,124 |  |  | $ | 3,656 |  |  | (15) | % |
| Net sales from Software and Services | 2,017 |  |  | 1,855 |  |  | 9 | % |
| Net sales | $ | 5,141 |  |  | $ | 5,511 |  |  | (7) | % |

[0000068505-20-000028:mdna:95]
The Products and Systems Integration segment’s net sales represented 61% of our net sales in the first nine months of 2020 and 66% in the first nine months of 2019. The Software and Services segment’s net sales represented 39% of our net sales in the first nine months of 2020 and 34% in the first nine months quarter of 2019.

[0000068505-20-000028:mdna:96]
Net sales decreased in the first nine months of 2020 compared to the first nine months of 2019. The Products and Systems Integration segment declined approximately 15% which was comprised of a 21% decline in the International region and a 12% decline in the North America region. The Software and Services segment increased approximately 9% which is comprised of a 12% increase in the North America region and a 5% increase in the International region. Net sales includes:

[0000068505-20-000028:mdna:97]
•a decline in the Products and Systems Integration segment, inclusive of $75 million of revenue from acquisitions, driven by a decline in PCR and public safety LMR, partially offset by growth in video security;

[0000068505-20-000028:mdna:98]
•growth in Software and Services, inclusive of $68 million of revenue from acquisitions, driven by Services in North America and Software, driven by increases in both video security and command center software; and

[0000068505-20-000028:mdna:99]
•$6 million from favorable currency rates.

[0000068505-20-000028:mdna:100]
[same as prior period, unchanged from 0000068505-20-000020:mdna:102]

[0000068505-20-000028:mdna:101]
•a 9% decline in the International region, inclusive of acquisitions, driven by a decline in PCR within the Product and Systems Integration segment, partially offset by growth of video security and a 5% increase in the Software and Services segment; and

[0000068505-20-000028:mdna:102]
•a 5% decline in the North America region primarily driven by a decline in PCR and public safety LMR within the Products and System Integration segment, partially offset by growth of video security, and a 12% increase in the Software and Services segment driven by Services in North America and Software primarily from acquisitions.

[0000068505-20-000028:mdna:103]
[same as prior period, unchanged from 0000068505-20-000020:mdna:105]

[0000068505-20-000028:mdna:104]
[same as prior period, unchanged from 0000068505-20-000020:mdna:106]

[0000068505-20-000028:mdna:105]
•20% decline in Devices revenue, inclusive of acquisitions, primarily driven by a decline in PCR and public safety LMR, partially offset by growth of our video security business;

[0000068505-20-000028:mdna:106]
•5% decline in Systems and Systems Integration revenue, inclusive of acquisitions, driven by a decline in customer engagement due to the COVID-19 pandemic; and

[0000068505-20-000028:mdna:107]
•partially offset by $75 million of revenue from acquisitions.

[0000068505-20-000028:mdna:108]
[same as prior period, unchanged from 0000068505-20-000020:mdna:110]

[0000068505-20-000028:mdna:109]
The 9% increase in the Software and Services segment was driven by the following:

[0000068505-20-000028:mdna:110]
•7% growth in Services, inclusive of acquisitions, driven by North America;

[0000068505-20-000028:mdna:111]
•16% growth in Software, driven primarily by acquisitions and growth in both video security and command center software; and

[0000068505-20-000028:mdna:112]
•$68 million of revenue from acquisitions.

[0000068505-20-000028:mdna:113]
[same as prior period, unchanged from 0000068505-20-000020:mdna:115]

[0000068505-20-000028:mdna:114]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Gross margin | $ | 2,462 |  |  | $ | 2,711 |  |  | (9) | % |

[0000068505-20-000028:mdna:115]
Gross margin was 47.9% of net sales in the first nine months of 2020 compared to 49.2% in the first nine months of 2019. The primary drivers of the decrease are as follows:

[0000068505-20-000028:mdna:116]
[same as prior period, unchanged from 0000068505-20-000020:mdna:59]

[0000068505-20-000028:mdna:117]
•partially offset by higher margins within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth, driven by improved mix of service offerings and lower travel and incentive costs.

[0000068505-20-000028:mdna:118]
[same as prior period, unchanged from 0000068505-20-000020:mdna:120]

[0000068505-20-000028:mdna:119]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 951 |  |  | $ | 1,035 |  |  | (8) | % |

[0000068505-20-000028:mdna:120]
SG&A expenses decreased 8% compared to the first nine months of 2019. SG&A expenses were 18.5% of net sales compared to 18.8% of net sales in the first nine months of 2019. The decrease in SG&A expenditures is primarily due to reduced  travel expenses, employee incentive costs, and indirect expenses. The overall reduction in SG&A expenses was partially offset by expenses associated with acquired businesses.

[0000068505-20-000028:mdna:121]
[same as prior period, unchanged from 0000068505-20-000020:mdna:123]

[0000068505-20-000028:mdna:122]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |  | % Change |
| Research and development expenditures | $ | 505 |  |  | $ | 505 |  |  | — | % |

[0000068505-20-000028:mdna:123]
R&D expenditures remained consistent compared to the first nine months of 2019. R&D expenditures were 9.8% of net sales compared to 9.2% of net sales in the first nine months of 2019.

[0000068505-20-000028:mdna:124]
[same as prior period, unchanged from 0000068505-20-000020:mdna:126]

[0000068505-20-000028:mdna:125]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Other charges | $ | 178 |  |  | $ | 180 |  |

[0000068505-20-000028:mdna:126]
Other charges decreased by $2 million in the first nine months quarter of 2020 compared to the first nine months of 2019. The change is driven by the following:

[0000068505-20-000028:mdna:127]
•a $50 million gain on the sale of property, plant and equipment from the sale of a manufacturing facility in Europe in the first nine months of 2020.

[0000068505-20-000028:mdna:128]
•$48 million of net reorganization business charges in the first nine months of 2020 compared to $27 million in the first nine months of 2019 (see further detail in “Reorganization of Businesses” section);

[0000068505-20-000028:mdna:129]
•$9 million of losses on legal settlements in the first nine months of 2020 compared to a $5 million gain on a legal settlement in the first nine months of 2019;

[0000068505-20-000028:mdna:130]
•$8 million of acquisition-related transactions fees in the first nine months of 2020 compared to $4 million in the first nine months of 2019; and

[0000068505-20-000028:mdna:131]
•$5 million of fixed asset impairments in the first nine months of 2020.

[0000068505-20-000028:mdna:132]
[same as prior period, unchanged from 0000068505-20-000020:mdna:133]

[0000068505-20-000028:mdna:133]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Operating earnings from Products and Systems Integration | $ | 305 |  |  | $ | 568 |  |
| Operating earnings from Software and Services | 523 |  |  | 423 |  |
| Operating earnings | $ | 828 |  |  | $ | 991 |  |

[0000068505-20-000028:mdna:134]
Operating earnings were down $163 million, or 16%, compared to the first nine months of 2019. The decrease in Operating earnings was due to:

[0000068505-20-000028:mdna:135]
•Products and Systems Integration, which was down $263 million, driven by lower sales and gross margin contribution, partially offset by lower operating expenses primarily driven by a $50 million gain from the sale of a manufacturing facility in Europe and lower employee incentive costs, indirect expenses, and travel expenses. The overall reduction in operating expenses was offset by: i) $27 million higher reorganization of business charges, ii) $11 million higher share-based compensation expenses, and iii) higher operating expenses from acquisitions; and

[0000068505-20-000028:mdna:136]
•partially offset by Software and Services, which was up $100 million, primarily driven by higher sales and gross margin contribution, along with reduced operating expenses due to operating leverage, inclusive of lower employee incentive costs and travel expenses. The overall reduction in operating expenses was partially offset by: i) $7 million of higher reorganization of business charges and ii) higher operating expenses from acquisitions.

[0000068505-20-000028:mdna:137]
[same as prior period, unchanged from 0000068505-20-000020:mdna:138]

[0000068505-20-000028:mdna:138]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Interest expense, net | $ | (167) |  |  | $ | (165) |  |

[0000068505-20-000028:mdna:139]
The increase in net interest expense in the first nine months of 2020 compared to the first nine months of 2019 was primarily a result of lower interest income earned on cash due to lower interest rates, partially offset by lower interest rates on debt outstanding for the period ending September 26, 2020 compared to the period ending September 28, 2019.

[0000068505-20-000028:mdna:140]
[same as prior period, unchanged from 0000068505-20-000020:mdna:141]

[0000068505-20-000028:mdna:141]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Other, net | $ | (8) |  |  | $ | (22) |  |

[0000068505-20-000028:mdna:142]
The decrease in net Other expense in the first nine months of 2020 as compared to the first nine months of 2019 was driven by the following:

[0000068505-20-000028:mdna:143]
•$6 million gain on derivatives in the first nine months of 2020 compared to a $16 million loss on the derivatives in the first nine months of 2019;

[0000068505-20-000028:mdna:144]
•$16 million of investment impairments in the first nine months of 2019;

[0000068505-20-000028:mdna:145]
•partially offset by $19 million of foreign currency loss in the first nine months of 2020 compared to $7 million of foreign currency loss in the first nine months of 2019; and

[0000068505-20-000028:mdna:146]
•$56 million loss on extinguishment of long-term debt in the first nine months of 2020 compared to $50 million loss on extinguishment of long term debt in the first nine months of 2019.

[0000068505-20-000028:mdna:147]
[same as prior period, unchanged from 0000068505-20-000020:mdna:152]

[0000068505-20-000028:mdna:148]
|  | Nine Months Ended |
| (In millions) | September 26, 2020 |  | September 28, 2019 |
| Income tax expense | $ | 112 |  |  | $ | 180 |  |

[0000068505-20-000028:mdna:149]
Income tax expense decreased by $68 million compared to the first nine months of 2019, resulting in an effective tax rate of 17%. Our effective tax rate for the nine months ended September 26, 2020 is lower than the effective tax rate for the nine months ended September 28, 2019 of 22%, primarily due to an increased benefit of forecasted research and development tax credit in the annual effective tax rate and favorable U.S. return-to-provision adjustments recorded in 2020.

[0000068505-20-000028:mdna:150]
[same as prior period, unchanged from 0000068505-20-000020:mdna:155]

[0000068505-20-000028:mdna:151]
During the third quarter of 2020, we recorded net reorganization of business charges of $13 million including $10 million of charges recorded within Other charges and $3 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $16 million related to employee separation costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-20-000028:mdna:152]
During the first nine months of 2020, we recorded net reorganization of business charges of $72 million including $48 million of charges recorded within Other charges and $24 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $72 million were charges of $85 million related to employee separation costs, partially offset by $13 million of reversals for accruals no longer needed.

[0000068505-20-000028:mdna:153]
During the third quarter of 2019, we recorded net reorganization of business charges of $18 million including $15 million of charges in Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $19 million related to employee separation costs and $1 million reversals for accruals no longer needed.

[0000068505-20-000028:mdna:154]
During the first nine months of 2019, we recorded net reorganization of business charges of $37 million including $27 million of charges in Other charges and $10 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $37 million were charges of $48 million related to employee separation costs and $11 million reversals for accruals no longer needed.

[0000068505-20-000028:mdna:155]
[same as prior period, unchanged from 0000068505-20-000020:mdna:160]

[0000068505-20-000028:mdna:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Products and Systems Integration | $ | 10 |  |  | $ | 14 |  |  | $ | 58 |  |  | $ | 29 |  |
| Software and Services | 3 |  |  | 4 |  |  | 14 |  |  | 8 |  |
|  | $ | 13 |  |  | $ | 18 |  |  | $ | 72 |  |  | $ | 37 |  |

[0000068505-20-000028:mdna:157]
Cash payments for employee severance in connection with the reorganization of business plans were $63 million in the first nine months of 2020 and $44 million in the first nine months of 2019. The reorganization of business accrual at September 26, 2020 was $87 million related to employee separation costs that are expected to be paid within one year.

[0000068505-20-000028:mdna:158]
[same as prior period, unchanged from 0000068505-20-000020:mdna:164]

[0000068505-20-000028:mdna:159]
|  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 909 |  |  | $ | 1,028 |  |
| Investing activities | (369) |  |  | (802) |  |
| Financing activities | (532) |  |  | (329) |  |
| Effect of exchange rates on cash and cash equivalents | (2) |  |  | (14) |  |
| Increase (decrease) in cash and cash equivalents | $ | 6 |  |  | $ | (117) |  |

[0000068505-20-000028:mdna:160]
[same as prior period, unchanged from 0000068505-20-000020:mdna:166]

[0000068505-20-000028:mdna:161]
At September 26, 2020, $517 million of the $1.0 billion cash and cash equivalents balance was held in the U.S. and $490 million was held in other countries, with $142 million held in the United Kingdom.

[0000068505-20-000028:mdna:162]
[same as prior period, unchanged from 0000068505-20-000020:mdna:168]

[0000068505-20-000028:mdna:163]
The decrease in operating cash flows from the first nine months of 2019 to the first nine months of 2020 was driven primarily by a reduction in earnings as a result of lower sales volume.

[0000068505-20-000028:mdna:164]
[same as prior period, unchanged from 0000068505-20-000020:mdna:170]

[0000068505-20-000028:mdna:165]
The decrease in net cash used by investing activities from the first nine months of 2019 to the first nine months of 2020 was primarily due to:

[0000068505-20-000028:mdna:166]
•a $341 million decrease in acquisitions and investments;

[0000068505-20-000028:mdna:167]
•a $38 million decrease in capital expenditures due to lower payments for the Airwave and ESN networks; and

[0000068505-20-000028:mdna:168]
•a $56 million increase in the proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in the first nine months of 2020.

[0000068505-20-000028:mdna:169]
[same as prior period, unchanged from 0000068505-20-000020:mdna:175]

[0000068505-20-000028:mdna:170]
The increase in cash used by financing activities in the first nine months of 2020 as compared to the first nine months of 2019 was driven by (also see further discussion in "Debt,"  "Share Repurchase Program" and "Dividends" below):

[0000068505-20-000028:mdna:171]
•a $200 million net increase in short-term debt due to the draw on our syndicated, unsecured revolving credit facility during the first nine months of 2020;

[0000068505-20-000028:mdna:172]
•a $271 million increase in share repurchases in the first nine months of 2020 as compared to the first nine months of 2019;

[0000068505-20-000028:mdna:173]
•a $46 million increase in the payment of dividends in the first nine months of 2020 as compared to the first nine months of 2019;

[0000068505-20-000028:mdna:174]
•a $388 million decrease in net proceeds received from the issuance of long-term debt, inclusive of repayments, during the first nine months of 2020 compared to the first nine months of 2019; and

[0000068505-20-000028:mdna:175]
•a $326 million decrease in settlements of conversion premium on senior convertible notes in the first nine months of 2019.

[0000068505-20-000028:mdna:176]
[same as prior period, unchanged from 0000068505-20-000020:mdna:180]

[0000068505-20-000028:mdna:177]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 26, 2020 and September 28, 2019:

[0000068505-20-000028:mdna:178]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Accounts receivable sales proceeds | $ | 82 |  |  | $ | 4 |  |  | $ | 238 |  |  | $ | 31 |  |
| Long-term receivables sales proceeds | 45 |  |  | 56 |  |  | 115 |  |  | 132 |  |
| Total proceeds from sales of accounts receivable | $ | 127 |  |  | $ | 60 |  |  | $ | 353 |  |  | $ | 163 |  |

[0000068505-20-000028:mdna:179]
During the nine months ended September 26, 2020, we utilized a new cost-efficient receivable discounting facility to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe resulting in accounts receivable sales of $67 million and $165 million, during the three and nine months ended September 26, 2020, respectively.  The net benefit to our operating cash flow from the utilization of the new receivable discounting facility for the three and nine months ended September 26, 2020, was $13 million and $67 million, respectively, when adjusted for amounts that would still be collected from the customer within the periods in the absence of utilizing the discounting facility. The proceeds of our receivable sales are included in "Operating activities" within our Condensed Consolidated Statements of Cash Flows.

[0000068505-20-000028:mdna:180]
[same as prior period, unchanged from 0000068505-20-000020:mdna:185]

[0000068505-20-000028:mdna:181]
We had outstanding debt of $5.4 billion and $5.1 billion, including the current portions of $212 million and $16 million at September 26, 2020 and December 31, 2019, respectively.

[0000068505-20-000028:mdna:182]
We have a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, we borrowed $800 million under the facility to bolster our cash holdings out of precaution in the first quarter of 2020, of which, $600 million was repaid during the nine months ended September 26, 2020. As of September 26, 2020, the outstanding loan amount was $200 million. Subsequent to the quarter, we repaid an additional $100 million. The weighted average borrowing rate on outstanding amounts outstanding during the three and nine months ended September 26, 2020 were 1.50% and 1.71%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 26, 2020.

[0000068505-20-000028:mdna:183]
37

[0000068505-20-000028:mdna:184]
In August of 2020, we issued $900 million of 2.30% Senior notes due 2030. We recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% Senior notes due 2022 under the make-whole provisions, for a redemption price of $582 million, excluding approximately $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of our long-term debt under a tender offer, for a purchase price of $315 million, excluding approximately $5 million of accrued interest, all of which occurred during the three months ended September 26, 2020. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of approximately $56 related to the redemption and the repurchase in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-20-000028:mdna:185]
[same as prior period, unchanged from 0000068505-20-000020:mdna:188]

[0000068505-20-000028:mdna:186]
We have an unsecured commercial paper program, backed by the unsecured revolving credit facility, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time.  Proceeds from the issuances of the notes are expected to be used for general corporate purposes.  As of September 26, 2020 we had no outstanding debt under the commercial paper program.

[0000068505-20-000028:mdna:187]
[same as prior period, unchanged from 0000068505-20-000020:mdna:190]

[0000068505-20-000028:mdna:188]
[same as prior period, unchanged from 0000068505-20-000020:mdna:191]

[0000068505-20-000028:mdna:189]
During the three and nine months ended September 26, 2020, we paid an aggregate of $105 million and $441 million, including transaction costs, to repurchase approximately 0.7 million and 2.9 million shares at an average price of $147.35 and  $152.79 per share. As of September 26, 2020, the Company had used approximately $13.2 billion of the share repurchase authority to repurchase shares, leaving $820 million of authority available for future repurchases.

[0000068505-20-000028:mdna:190]
[same as prior period, unchanged from 0000068505-20-000020:mdna:193]

[0000068505-20-000028:mdna:191]
During the third quarter of 2020 we paid $109 million in cash dividends to holders of our common stock. During the nine months ended September 26, 2020 we paid $327 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $109 million in cash dividends to holders of our common stock.

[0000068505-20-000028:mdna:192]
[same as prior period, unchanged from 0000068505-20-000020:mdna:195]

[0000068505-20-000028:mdna:193]
We had outstanding commitments to provide long-term financing to third parties totaling $59 million at September 26, 2020, compared to $78 million at December 31, 2019.

[0000068505-20-000028:mdna:194]
[same as prior period, unchanged from 0000068505-20-000020:mdna:197]

[0000068505-20-000028:mdna:195]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging - Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share ("EPS"). The ASU clarifies that the average market price should be used to calculate the diluted EPS denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for us on January 1, 2022, including the interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. We are still evaluating the impact of adoption on our financial statements and disclosures.

[0000068505-20-000028:mdna:196]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and simplifying other areas of accounting for income taxes. The ASU is effective on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The adoption of the ASU will not have a significant impact on the financial statement disclosures.

[0000068505-20-000028:mdna:197]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-20-000028:mdna:198]
Recently Adopted Accounting Pronouncements

[0000068505-20-000028:mdna:199]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires us to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11," Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU.  We adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information was not updated and disclosures required under ASC 326 are not provided for dates and periods before January 1, 2020.

[0000068505-20-000028:mdna:200]
[same as prior period, unchanged from 0000068505-20-000020:mdna:203]

[0000068505-20-000028:mdna:201]
39
