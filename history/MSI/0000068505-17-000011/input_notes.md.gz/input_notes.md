# MSI notes — 0000068505-17-000011


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-17-000011:notes:1]
[same as prior period, unchanged from 0000068505-17-000005:notes:1]

[0000068505-17-000011:notes:2]
| July 1, 2017 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 56 |  |  | $ | — |  |  | $ | 56 |  |
| Corporate bonds | 5 |  |  | — |  |  | 5 |  |
| Common stock | 5 |  |  | 7 |  |  | 12 |  |
|  | 66 |  |  | 7 |  |  | 73 |  |
| Other investments | 210 |  |  | — |  |  | 210 |  |
| Equity method investments | 15 |  |  | — |  |  | 15 |  |
|  | $ | 291 |  |  | $ | 7 |  |  | $ | 298 |  |
| Less: current portion of available-for-sale securities |  |  |  |  | 50 |  |
|  |  |  |  |  | $ | 248 |  |

[0000068505-17-000011:notes:3]
| December 31, 2016 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |
| Corporate bonds | 5 |  |  | — |  |  | 5 |  |
|  | 56 |  |  | — |  |  | 56 |  |
| Other investments | 211 |  |  | — |  |  | 211 |  |
| Equity method investments | 17 |  |  | — |  |  | 17 |  |
|  | $ | 284 |  |  | $ | — |  |  | $ | 284 |  |
| Less: current portion of available-for-sale securities |  |  |  |  | 46 |  |
|  |  |  |  |  | $ | 238 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-17-000011:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of July 1, 2017 and December 31, 2016 were as follows:

[0000068505-17-000011:notes:5]
| July 1, 2017 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | — |  |  | $ | 56 |  |  | $ | 56 |  |
| Corporate bonds | — |  |  | 5 |  |  | 5 |  |
| Common stock | 12 |  |  | — |  |  | 12 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |

[0000068505-17-000011:notes:6]
| December 31, 2016 | Level 2 |  | Total |
| Assets: |  |  |  |
| Foreign exchange derivative contracts | $ | 9 |  |  | $ | 9 |  |
| Available-for-sale securities: |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | 51 |  |  | 51 |  |
| Corporate bonds | 5 |  |  | 5 |  |
| Liabilities: |  |  |  |
| Foreign exchange derivative contracts | $ | 32 |  |  | $ | 32 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-17-000011:notes:7]
[same as prior period, unchanged from 0000068505-17-000005:notes:7]

[0000068505-17-000011:notes:8]
[same as prior period, unchanged from 0000068505-17-000005:notes:8]

[0000068505-17-000011:notes:9]
[same as prior period, unchanged from 0000068505-17-000005:notes:9]

[0000068505-17-000011:notes:10]
|  | July 1, 2017 |  | December 31, 2016 |
| Long-term receivables | $ | 48 |  |  | $ | 63 |  |
| Less current portion | (13 | ) |  | (14 | ) |
| Non-current long-term receivables | $ | 35 |  |  | $ | 49 |  |

[0000068505-17-000011:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $209 million at July 1, 2017, compared to $125 million at December 31, 2016. During the six months ended July 1, 2017, the Company agreed to provide long-term financing to one customer in the amount of $75 million.

[0000068505-17-000011:notes:12]
[same as prior period, unchanged from 0000068505-17-000005:notes:12]

[0000068505-17-000011:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended July 1, 2017 and July 2, 2016:

[0000068505-17-000011:notes:14]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Accounts receivable sales proceeds | $ | 61 |  |  | $ | 5 |  |  | $ | 80 |  |  | $ | 7 |  |
| Long-term receivables sales proceeds | 22 |  |  | 70 |  |  | 68 |  |  | 134 |  |
| Total proceeds from receivable sales | $ | 83 |  |  | $ | 75 |  |  | $ | 148 |  |  | $ | 141 |  |

[0000068505-17-000011:notes:15]
At July 1, 2017, the Company had retained servicing obligations for $775 million of long-term receivables, compared to $774 million at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000011:notes:16]
[same as prior period, unchanged from 0000068505-17-000005:notes:16]

[0000068505-17-000011:notes:17]
An aging analysis of financing receivables at July 1, 2017 and December 31, 2016 is as follows:

[0000068505-17-000011:notes:18]
| July 1, 2017 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 21 |  |  | $ | 1 |  |  | $ | 2 |  |
| Commercial loans and leases secured | 27 |  |  | — |  |  | — |  |
| Long-term receivables, including current portion | $ | 48 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000068505-17-000011:notes:19]
| December 31, 2016 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 20 |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 43 |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 63 |  |  | $ | — |  |  | $ | 2 |  |


## msi:OtherChargesTableTextBlock

[0000068505-17-000011:notes:20]
[same as prior period, unchanged from 0000068505-17-000005:notes:20]

[0000068505-17-000011:notes:21]
|  | Three Months Ended | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 | July 1, 2017 |  | July 2, 2016 |
| Other charges: |  |  |  |  |  |  |
| Intangibles amortization | $ | 37 |  |  | $ | 38 |  | $ | 73 |  |  | $ | 52 |  |
| Reorganization of business | 1 |  |  | 19 |  | 16 |  |  | 25 |  |
| Building impairment | — |  |  | 17 |  | 8 |  |  | 17 |  |
| Non-U.S. pension settlement loss | 16 |  |  | — |  | 25 |  |  | — |  |
| Legal settlements | (1 | ) |  | — |  | (44 | ) |  | — |  |
| Acquisition-related transaction fees | — |  |  | — |  | 1 |  |  | 13 |  |
|  | $ | 53 |  |  | $ | 74 |  | $ | 79 |  |  | $ | 107 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-17-000011:notes:22]
[same as prior period, unchanged from 0000068505-17-000005:notes:22]

[0000068505-17-000011:notes:23]
| July 2, 2016 | Three Months Ended |  | Six Months Ended |
| Products | $ | 33 |  |  | $ | 54 |  |
| Services | 11 |  |  | 13 |  |
|  | $ | 44 |  |  | $ | 67 |  |

[0000068505-17-000011:notes:24]
| July 1, 2017 | Three Months Ended |  | Six Months Ended |
| Products | $ | 3 |  |  | $ | 16 |  |
| Services | — |  |  | 6 |  |
|  | $ | 3 |  |  | $ | 22 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-17-000011:notes:25]
[same as prior period, unchanged from 0000068505-17-000005:notes:25]

[0000068505-17-000011:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 4 |  |
| Selling, general and administrative expenses | 11 |  |  | 12 |  |  | 22 |  |  | 24 |  |
| Research and development expenditures | 3 |  |  | 4 |  |  | 7 |  |  | 7 |  |
| Share-based compensation expense included in Operating earnings | 16 |  |  | 18 |  |  | 33 |  |  | 35 |  |
| Tax benefit | 5 |  |  | 6 |  |  | 11 |  |  | 11 |  |
| Share-based compensation expense, net of tax | $ | 11 |  |  | $ | 12 |  |  | $ | 22 |  |  | $ | 24 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.14 | ) |
| Decrease in diluted earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |  | $ | (0.13 | ) |  | $ | (0.14 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-17-000011:notes:27]
[same as prior period, unchanged from 0000068505-17-000005:notes:27]

[0000068505-17-000011:notes:28]
|  | July 1, 2017 |  | December 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 178 |  |  | $ | 73 |  |  | $ | 178 |  |  | $ | 63 |  |
| Services | 930 |  |  | 167 |  |  | 805 |  |  | 99 |  |
|  | $ | 1,108 |  |  | $ | 240 |  |  | $ | 983 |  |  | $ | 162 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-17-000011:notes:29]
[same as prior period, unchanged from 0000068505-17-000005:notes:29]

[0000068505-17-000011:notes:30]
|  | July 1, 2017 |  | December 31, 2016 |
| Defined benefit plans | $ | 1,800 |  |  | $ | 1,799 |  |
| Deferred revenue | 164 |  |  | 115 |  |
| Unrecognized tax benefits | 39 |  |  | 39 |  |
| Deferred income taxes | 139 |  |  | 121 |  |
| Deferred consideration (Note 13) | 78 |  |  | 72 |  |
| Other | 220 |  |  | 209 |  |
|  | $ | 2,440 |  |  | $ | 2,355 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-17-000011:notes:31]
[same as prior period, unchanged from 0000068505-17-000005:notes:31]

[0000068505-17-000011:notes:32]
[same as prior period, unchanged from 0000068505-17-000005:notes:32]

[0000068505-17-000011:notes:33]
[same as prior period, unchanged from 0000068505-17-000005:notes:33]

[0000068505-17-000011:notes:34]
During the six months ended July 1, 2017, the Company recognized a net gain of $44 million related to legal settlements. Of this amount, $42 million relates to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business. The net gain of $42 million was based on $52 million of proceeds received, net $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-17-000011:notes:35]
[same as prior period, unchanged from 0000068505-17-000005:notes:35]

[0000068505-17-000011:notes:36]
[same as prior period, unchanged from 0000068505-17-000005:notes:36]

[0000068505-17-000011:notes:37]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (55 | ) |  | $ | (59 | ) |  | $ | (109 | ) |  | $ | (111 | ) |
| Interest income | 4 |  |  | 5 |  |  | 7 |  |  | 8 |  |
|  | $ | (51 | ) |  | $ | (54 | ) |  | $ | (102 | ) |  | $ | (103 | ) |
| Other: |  |  |  |  |  |  |  |
| Foreign currency gain (loss) | $ | (20 | ) |  | $ | 14 |  |  | $ | (22 | ) |  | $ | 27 |  |
| Gain (loss) on derivative instruments | 18 |  |  | (18 | ) |  | 11 |  |  | (30 | ) |
| Gains on equity method investments | 1 |  |  | — |  |  | — |  |  | 2 |  |
| Realized foreign currency loss on acquisition | — |  |  | — |  |  | — |  |  | (10 | ) |
| Other | 1 |  |  | — |  |  | 2 |  |  | — |  |
|  | $ | — |  |  | $ | (4 | ) |  | $ | (9 | ) |  | $ | (11 | ) |

[0000068505-17-000011:notes:38]
[same as prior period, unchanged from 0000068505-17-000005:notes:38]

[0000068505-17-000011:notes:39]
[same as prior period, unchanged from 0000068505-17-000005:notes:39]

[0000068505-17-000011:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 131 |  |  | $ | 107 |  |  | $ | 208 |  |  | $ | 124 |  |
| Weighted average common shares outstanding | 163.1 |  |  | 171.9 |  |  | 163.7 |  |  | 173.0 |  |
| Per share amount | $ | 0.80 |  |  | $ | 0.62 |  |  | $ | 1.27 |  |  | $ | 0.72 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 131 |  |  | $ | 107 |  |  | $ | 208 |  |  | $ | 124 |  |
| Weighted average common shares outstanding | 163.1 |  |  | 171.9 |  |  | 163.7 |  |  | 173.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.1 |  |  | 2.4 |  |  | 3.2 |  |  | 2.4 |  |
| Senior Convertible Notes | 2.8 |  |  | 0.5 |  |  | 2.6 |  |  | 0.3 |  |
| Diluted weighted average common shares outstanding | 169.0 |  |  | 174.8 |  |  | 169.5 |  |  | 175.7 |  |
| Per share amount | $ | 0.78 |  |  | $ | 0.61 |  |  | $ | 1.23 |  |  | $ | 0.71 |  |

[0000068505-17-000011:notes:41]
In the computation of diluted earnings per common share for the three months ended July 1, 2017, the assumed exercise of 2.1 million options, including 1.8 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive. For the six months ended July 1, 2017, the assumed exercise of 2.4 million options, including 2.0 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-17-000011:notes:42]
For the three months ended July 2, 2016, the assumed exercise of 2.3 million options, including 2.1 million subject to market-based contingent stock agreements, and the assumed vesting of 0.6 million restricted stock units ("RSUs") were excluded because their inclusion would have been antidilutive. For the six months ended July 2, 2016, the assumed exercise of 3.2 million options, including 2.1 million subject to market-based contingent stock agreements, and the assumed vesting of 0.6 million RSUs were excluded because their inclusion would have been antidilutive.

[0000068505-17-000011:notes:43]
[same as prior period, unchanged from 0000068505-17-000005:notes:42]

[0000068505-17-000011:notes:44]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, the Company does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the three and six months ended July 1, 2017, the dilutive impact of the Senior Convertible Notes was 2.8 million shares and 2.6 million shares, respectively.

[0000068505-17-000011:notes:45]
[same as prior period, unchanged from 0000068505-17-000005:notes:44]

[0000068505-17-000011:notes:46]
[same as prior period, unchanged from 0000068505-17-000005:notes:45]

[0000068505-17-000011:notes:47]
[same as prior period, unchanged from 0000068505-17-000005:notes:46]

[0000068505-17-000011:notes:48]
|  | July 1, 2017 |  | December 31, 2016 |
| Accounts receivable | $ | 1,250 |  |  | $ | 1,454 |  |
| Less allowance for doubtful accounts | (39 | ) |  | (44 | ) |
|  | $ | 1,211 |  |  | $ | 1,410 |  |

[0000068505-17-000011:notes:49]
[same as prior period, unchanged from 0000068505-17-000005:notes:48]

[0000068505-17-000011:notes:50]
[same as prior period, unchanged from 0000068505-17-000005:notes:49]

[0000068505-17-000011:notes:51]
|  | July 1, 2017 |  | December 31, 2016 |
| Finished goods | $ | 197 |  |  | $ | 151 |  |
| Work-in-process and production materials | 321 |  |  | 253 |  |
|  | 518 |  |  | 404 |  |
| Less inventory reserves | (127 | ) |  | (131 | ) |
|  | $ | 391 |  |  | $ | 273 |  |

[0000068505-17-000011:notes:52]
[same as prior period, unchanged from 0000068505-17-000005:notes:51]

[0000068505-17-000011:notes:53]
[same as prior period, unchanged from 0000068505-17-000005:notes:52]

[0000068505-17-000011:notes:54]
|  | July 1, 2017 |  | December 31, 2016 |
| Available-for-sale securities | $ | 50 |  |  | $ | 46 |  |
| Costs and earnings in excess of billings | 529 |  |  | 495 |  |
| Tax-related refunds receivable | 110 |  |  | 90 |  |
| Other | 115 |  |  | 124 |  |
|  | $ | 804 |  |  | $ | 755 |  |

[0000068505-17-000011:notes:55]
[same as prior period, unchanged from 0000068505-17-000005:notes:54]

[0000068505-17-000011:notes:56]
[same as prior period, unchanged from 0000068505-17-000005:notes:55]

[0000068505-17-000011:notes:57]
|  | July 1, 2017 |  | December 31, 2016 |
| Land | $ | 10 |  |  | $ | 12 |  |
| Building | 267 |  |  | 306 |  |
| Machinery and equipment | 2,078 |  |  | 1,921 |  |
|  | 2,355 |  |  | 2,239 |  |
| Less accumulated depreciation | (1,496 | ) |  | (1,450 | ) |
|  | $ | 859 |  |  | $ | 789 |  |

[0000068505-17-000011:notes:58]
Depreciation expense for the three months ended July 1, 2017 and July 2, 2016 was $49 million and $44 million, respectively. Depreciation expense for the six months ended July 1, 2017 and July 2, 2016 was $93 million and $92 million, respectively.

[0000068505-17-000011:notes:59]
[same as prior period, unchanged from 0000068505-17-000005:notes:60]

[0000068505-17-000011:notes:60]
Other investments include strategic investments in non-public technology-driven startup companies recorded at cost of $74 million and $76 million, and insurance policies recorded at their cash surrender value of $136 million and $135 million, at July 1, 2017 and December 31, 2016.

[0000068505-17-000011:notes:61]
During the three months ended July 1, 2017, the Company recognized a loss on the sale of investments and businesses of $1 million, compared to a gain of $1 million during the three months ended July 2, 2016. During the six months ended July 1, 2017, the Company recognized a gain on the sale of investments and businesses of $2 million, compared to a loss of $20 million during the six months ended July 2, 2016, of which, $19 million was associated with the sale of United Kingdom treasury securities.

[0000068505-17-000011:notes:62]
[same as prior period, unchanged from 0000068505-17-000005:notes:63]

[0000068505-17-000011:notes:63]
[same as prior period, unchanged from 0000068505-17-000005:notes:64]

[0000068505-17-000011:notes:64]
|  | July 1, 2017 |  | December 31, 2016 |
| Long-term receivables | 35 |  |  | 49 |  |
| Defined benefit plan assets | 125 |  |  | 102 |  |
| Other | 40 |  |  | 49 |  |
|  | $ | 200 |  |  | 200 |  |

[0000068505-17-000011:notes:65]
[same as prior period, unchanged from 0000068505-17-000005:notes:66]

[0000068505-17-000011:notes:66]
[same as prior period, unchanged from 0000068505-17-000005:notes:67]

[0000068505-17-000011:notes:67]
|  | July 1, 2017 |  | December 31, 2016 |
| Deferred revenue | $ | 427 |  |  | $ | 439 |  |
| Compensation | 171 |  |  | 250 |  |
| Billings in excess of costs and earnings | 387 |  |  | 434 |  |
| Tax liabilities | 134 |  |  | 111 |  |
| Dividend payable | 76 |  |  | 77 |  |
| Trade liabilities | 174 |  |  | 180 |  |
| Other | 555 |  |  | 620 |  |
|  | $ | 1,924 |  |  | $ | 2,111 |  |

[0000068505-17-000011:notes:68]
[same as prior period, unchanged from 0000068505-17-000005:notes:69]

[0000068505-17-000011:notes:69]
[same as prior period, unchanged from 0000068505-17-000005:notes:70]

[0000068505-17-000011:notes:70]
[same as prior period, unchanged from 0000068505-17-000005:notes:71]

[0000068505-17-000011:notes:71]
During the six months ended July 1, 2017, the Company paid an aggregate of $258 million, including transaction costs, to repurchase approximately 3.2 million shares at an average price of $81.66 per share. As of July 1, 2017, the Company had used approximately $12.1 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.9 billion of authority available for future repurchases.

[0000068505-17-000011:notes:72]
Payment of Dividends: During the three months ended July 1, 2017 and July 2, 2016, the Company paid $77 million and $72 million, respectively, in cash dividends to holders of its common stock. During the six months ended July 1, 2017 and July 2, 2016, the Company paid $154 million and $143 million, respectively, in cash dividends to holders of its common stock.

[0000068505-17-000011:notes:73]
[same as prior period, unchanged from 0000068505-17-000005:notes:74]

[0000068505-17-000011:notes:74]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and six months ended July 1, 2017 and July 2, 2016:

[0000068505-17-000011:notes:75]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (460 | ) |  | $ | (253 | ) |  | $ | (494 | ) |  | $ | (266 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 47 |  |  | (98 | ) |  | 84 |  |  | (84 | ) |
| Tax expense | — |  |  | — |  |  | (3 | ) |  | (1 | ) |
| Other comprehensive income (loss), net of tax | 47 |  |  | (98 | ) |  | 81 |  |  | (85 | ) |
| Balance at end of period | $ | (413 | ) |  | $ | (351 | ) |  | $ | (413 | ) |  | $ | (351 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | (3 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 7 |  |  | (2 | ) |  | 7 |  |  | (2 | ) |
| Tax (expense) benefit | (3 | ) |  | 1 |  |  | (3 | ) |  | 1 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 4 |  |  | (1 | ) |  | 4 |  |  | (1 | ) |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net | — |  |  | — |  |  | — |  |  | 6 |  |
| Tax benefit | — |  |  | — |  |  | — |  |  | (2 | ) |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | — |  |  | — |  |  | — |  |  | 4 |  |
| Other comprehensive income (loss), net of tax | 4 |  |  | (1 | ) |  | 4 |  |  | 3 |  |
| Balance at end of period | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | (1,804 | ) |  | (1,593 | ) |  | $ | (1,823 | ) |  | $ | (1,597 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (11 | ) |  | 53 |  |  | (11 | ) |  | 53 |  |
| Tax expense | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (11 | ) |  | 37 |  |  | (11 | ) |  | 37 |  |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 16 |  |  | 18 |  |  | 32 |  |  | 28 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (4 | ) |  | (7 | ) |  | (8 | ) |  | (13 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other charges | 16 |  |  | — |  |  | 25 |  |  | — |  |
| Tax expense (benefit) | (3 | ) |  | 8 |  |  | (5 | ) |  | 8 |  |
| Reclassification adjustment into Operating earnings, net of tax | 25 |  |  | 19 |  |  | 44 |  |  | 23 |  |
| Other comprehensive income, net of tax | 14 |  |  | 56 |  |  | 33 |  |  | 60 |  |
| Balance at end of period | $ | (1,790 | ) |  | $ | (1,537 | ) |  | $ | (1,790 | ) |  | $ | (1,537 | ) |
| Total Accumulated other comprehensive loss | $ | (2,199 | ) |  | $ | (1,888 | ) |  | $ | (2,199 | ) |  | $ | (1,888 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-17-000011:notes:76]
The condensed consolidated financial statements as of July 1, 2017 and for the three and six months ended July 1, 2017 and July 2, 2016 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-17-000011:notes:77]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2016. The results of operations for the three and six months ended July 1, 2017 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-17-000011:notes:78]
[same as prior period, unchanged from 0000068505-17-000005:notes:79]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-17-000011:notes:79]
Commitments and Contingencies

[0000068505-17-000011:notes:80]
Legal Matters

[0000068505-17-000011:notes:81]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-17-000011:notes:82]
Other Indemnifications

[0000068505-17-000011:notes:83]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-17-000011:notes:84]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at July 1, 2017.

[0000068505-17-000011:notes:85]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-17-000011:notes:86]
Debt and Credit Facilities

[0000068505-17-000011:notes:87]
On April 25, 2017, the Company entered into a $2.2 billion syndicated, unsecured revolving credit facility expiring April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement replaces the 2014 Motorola Solutions Credit Agreement.

[0000068505-17-000011:notes:88]
The 2017 Motorola Solutions Credit Agreement has a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes.

[0000068505-17-000011:notes:89]
Under the 2017 Motorola Solutions Credit Agreement, the Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with it financial covenants as of July 1, 2017. The Company did not borrow or issue any letters of credit under the 2017 Motorola Solutions Credit Agreement during the three months ended July 1, 2017.

[0000068505-17-000011:notes:90]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances including, for example, if the volume weighted average price of the Company's stock exceeds $85 for ten consecutive trading days, then up to 20% of the notes may be transferred, and then subsequently converted to shares of Company stock by such transferee. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share).  During the three months ended July 1, 2017, the volume weighted average price of the Company's stock exceeded $85 for ten consecutive trading days, making 20% of Senior Convertible Notes convertible. In the event of conversion, the notes may be settled in either cash or stock, at the Company's discretion. The Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-17-000011:notes:91]
[same as prior period, unchanged from 0000068505-17-000005:notes:90]

[0000068505-17-000011:notes:92]
[same as prior period, unchanged from 0000068505-17-000005:notes:91]

[0000068505-17-000011:notes:93]
As of July 1, 2017, the Company had outstanding foreign exchange contracts with notional amounts totaling $590 million, compared to $717 million outstanding at December 31, 2016. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-17-000011:notes:94]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of July 1, 2017, and the corresponding positions as of December 31, 2016:

[0000068505-17-000011:notes:95]
|  | Notional Amount |
| Net Buy (Sell) by Currency | July 1, 2017 |  | December 31, 2016 |
| Euro | $ | 161 |  |  | $ | 122 |  |
| British Pound | 149 |  |  | 246 |  |
| Chinese Renminbi | (81 | ) |  | (108 | ) |
| Australian Dollar | (50 | ) |  | (51 | ) |
| Brazilian Real | (45 | ) |  | (56 | ) |

[0000068505-17-000011:notes:96]
During the six months ended July 1, 2017, the Company entered into forward contracts to sell £50 million, expiring in December 2017. The forward contracts have been designated as a net investment hedge which is in place to partially hedge the Company's British Pound foreign currency exposure on its net investment in Airwave Solutions Limited. The gains and losses on the Company's net investment in pound-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive loss. As of July 1, 2017, the fair value of the derivative contract was $2 million.

[0000068505-17-000011:notes:97]
[same as prior period, unchanged from 0000068505-17-000005:notes:96]

[0000068505-17-000011:notes:98]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swaps liability was de minimus at both July 1, 2017 and December 31, 2016.

[0000068505-17-000011:notes:99]
[same as prior period, unchanged from 0000068505-17-000005:notes:98]

[0000068505-17-000011:notes:100]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of July 1, 2017, all of the counterparties have investment grade credit ratings. As of July 1, 2017, the Company had $6 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-17-000011:notes:101]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of July 1, 2017 and December 31, 2016:

[0000068505-17-000011:notes:102]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| July 1, 2017 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 2 |  |  | Other liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 6 |  |  | Other current assets |  | $ | 4 |  |  | Accrued liabilities |
| Total derivatives | $ | 6 |  |  |  |  | $ | 6 |  |  |  |

[0000068505-17-000011:notes:103]
[same as prior period, unchanged from 0000068505-17-000005:notes:102]

[0000068505-17-000011:notes:104]
The following table summarizes the effect of derivatives designated as hedging instruments on the Company's condensed consolidated financial statements for the three and six months ended July 1, 2017 and July 2, 2016:

[0000068505-17-000011:notes:105]
|  | Three Months Ended |  | Six Months Ended |  | Balance SheetLocation |
| Derivatives Designated as Hedging Instruments | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |  |
| Foreign exchange contracts | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |  | $ | — |  |  | Other comprehensive income (loss) |

[0000068505-17-000011:notes:106]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated financial statements for the three and six months ended July 1, 2017 and July 2, 2016:

[0000068505-17-000011:notes:107]
|  | Three Months Ended |  | Six Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |  |
| Foreign exchange contracts | 18 |  |  | (18 | ) |  | 11 |  |  | (30 | ) |  | Other income (expense) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-17-000011:notes:108]
[same as prior period, unchanged from 0000068505-17-000005:notes:106]

[0000068505-17-000011:notes:109]
During the six months ended July 1, 2017, the Company granted 0.5 million RSUs and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $39 million and $6 million, respectively, and 0.3 million stock options and 0.6 million performance options ("POs") with an aggregate grant-date fair value of $5 million and $9 million, respectively. Share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-17-000011:notes:110]
[same as prior period, unchanged from 0000068505-17-000005:notes:108]

[0000068505-17-000011:notes:111]
[same as prior period, unchanged from 0000068505-17-000005:notes:109]

[0000068505-17-000011:notes:112]
[same as prior period, unchanged from 0000068505-17-000005:notes:110]

[0000068505-17-000011:notes:113]
[same as prior period, unchanged from 0000068505-17-000005:notes:111]

[0000068505-17-000011:notes:114]
[same as prior period, unchanged from 0000068505-17-000005:notes:112]

[0000068505-17-000011:notes:115]
[same as prior period, unchanged from 0000068505-17-000005:notes:113]

[0000068505-17-000011:notes:116]
The Company had no Level 3 holdings as of July 1, 2017 or December 31, 2016.

[0000068505-17-000011:notes:117]
At July 1, 2017 and December 31, 2016, the Company had $298 million and $309 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-17-000011:notes:118]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at July 1, 2017 and December 31, 2016 was $4.6 billion and $4.5 billion (Level 2), respectively.

[0000068505-17-000011:notes:119]
[same as prior period, unchanged from 0000068505-17-000005:notes:117]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-17-000011:notes:120]
[same as prior period, unchanged from 0000068505-17-000005:notes:118]

[0000068505-17-000011:notes:121]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company's condensed consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-17-000011:notes:122]
[same as prior period, unchanged from 0000068505-17-000005:notes:120]

[0000068505-17-000011:notes:123]
[same as prior period, unchanged from 0000068505-17-000005:notes:121]

[0000068505-17-000011:notes:124]
[same as prior period, unchanged from 0000068505-17-000005:notes:122]

[0000068505-17-000011:notes:125]
[same as prior period, unchanged from 0000068505-17-000005:notes:123]

[0000068505-17-000011:notes:126]
[same as prior period, unchanged from 0000068505-17-000005:notes:124]

[0000068505-17-000011:notes:127]
[same as prior period, unchanged from 0000068505-17-000005:notes:125]

[0000068505-17-000011:notes:128]
[same as prior period, unchanged from 0000068505-17-000005:notes:126]

[0000068505-17-000011:notes:129]
[same as prior period, unchanged from 0000068505-17-000005:notes:127]

[0000068505-17-000011:notes:130]
On July 28, 2017, the Company announced its intention to purchase Plant Holdings, Inc., which owns the Airbus DS Communications business. This acquisition will expand the Company's software portfolio in the Command Center with additional solutions for Next Gen 9-1-1.

[0000068505-17-000011:notes:131]
[same as prior period, unchanged from 0000068505-17-000005:notes:128]

[0000068505-17-000011:notes:132]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides Managed & Support services for communications systems to public safety and commercial customers in Chile, for a gross purchase price of $98 billion Chilean Pesos, or approximately $147 million U.S. Dollars based on cash proceeds of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $7 million of goodwill, $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $9 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-17-000011:notes:133]
On November 10, 2016, the Company completed the acquisition of Spillman Technologies, Inc., a provider of comprehensive law enforcement and public safety software solutions, for a gross purchase price of $221 million. As a result of the acquisition, the Company recognized $144 million of goodwill, $115 million of identifiable intangible assets, and $38 million of acquired liabilities. The identifiable intangible assets were classified as $49 million of completed technology, $59 million of customer-related intangibles, and $7 million of other intangibles and will be amortized over a period of seven to ten years.

[0000068505-17-000011:notes:134]
[same as prior period, unchanged from 0000068505-17-000005:notes:131]

[0000068505-17-000011:notes:135]
[same as prior period, unchanged from 0000068505-17-000005:notes:132]

[0000068505-17-000011:notes:136]
[same as prior period, unchanged from 0000068505-17-000005:notes:133]

[0000068505-17-000011:notes:137]
|  | July 1, 2017 |  | December 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 128 |  |  | $ | 46 |  |  | $ | 116 |  |  | $ | 38 |  |
| Patents | 8 |  |  | 7 |  |  | 8 |  |  | 6 |  |
| Customer-related | 918 |  |  | 167 |  |  | 810 |  |  | 101 |  |
| Other intangibles | 54 |  |  | 20 |  |  | 49 |  |  | 17 |  |
|  | $ | 1,108 |  |  | $ | 240 |  |  | $ | 983 |  |  | $ | 162 |  |

[0000068505-17-000011:notes:138]
Amortization expense on intangible assets was $37 million for the three months ended July 1, 2017 and $73 million for the six months ended July 1, 2017. Amortization expense on intangible assets was $38 million for the three months ended July 2, 2016 and $52 million for the six months ended July 2, 2016. The increase in amortization expense is primarily due to the acquisition of Airwave, Spillman Technologies, Inc. and Interexport. As of July 1, 2017, annual amortization expense is estimated to be $144 million in 2017, $148 million in 2018, $147 million in 2019, $144 million in 2020, $143 million in 2021, and $140 million in 2022.

[0000068505-17-000011:notes:139]
[same as prior period, unchanged from 0000068505-17-000005:notes:136]

[0000068505-17-000011:notes:140]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2017 to July 1, 2017:

[0000068505-17-000011:notes:141]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2017 |  |  |  |  |  |
| Goodwill, net of impairment losses | $ | 316 |  |  | $ | 412 |  |  | $ | 728 |  |
| Goodwill acquired | — |  |  | 7 |  |  | 7 |  |
| Purchase accounting adjustments | 1 |  |  | 3 |  |  | 4 |  |
| Foreign currency | — |  |  | 10 |  |  | 10 |  |
| Balance as of July 1, 2017 |  |  |  |  |  |
| Goodwill, net of impairment losses | $ | 317 |  |  | $ | 432 |  |  | $ | 749 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-17-000011:notes:142]
[same as prior period, unchanged from 0000068505-17-000005:notes:139]

[0000068505-17-000011:notes:143]
[same as prior period, unchanged from 0000068505-17-000005:notes:140]

[0000068505-17-000011:notes:144]
[same as prior period, unchanged from 0000068505-17-000005:notes:141]

[0000068505-17-000011:notes:145]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Net earnings before income taxes | $ | 205 |  |  | $ | 167 |  |  | $ | 324 |  |  | $ | 189 |  |
| Income tax expense | 73 |  |  | 59 |  |  | 114 |  |  | 64 |  |
| Effective tax rate | 36 | % |  | 35 | % |  | 35 | % |  | 34 | % |

[0000068505-17-000011:notes:146]
The Company recorded $73 million of net tax expense during the three months ended July 1, 2017, resulting in an effective tax rate of 36%, compared to $59 million of net tax expense during the three months ended July 2, 2016, resulting in an effective tax rate of 35%. The effective tax rate in the second quarter of 2017 was greater than the U.S. statutory tax rate of 35% partly due to change of estimates between provision and the filing of tax returns in foreign jurisdictions. The effective tax rate in the second quarter of 2016 was equal to the U.S. statutory tax rate of 35%.

[0000068505-17-000011:notes:147]
The Company recorded $114 million of net tax expense during the six months ended July 1, 2017, resulting in an effective tax rate of 35%, compared to $64 million of net tax expense during the six months ended July 2, 2016, resulting in an effective tax rate of 34%. The effective tax rate in the first half of 2017 was equal to the U.S. statutory tax rate of 35%. The effective tax rate in the first half of 2016 was lower than the U.S. statutory tax rate of 35% partly due to the recognition of excess tax benefits on share-based compensation.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-17-000011:notes:148]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

[0000068505-17-000011:notes:149]
The Company has continued to analyze the impact of the new standard on its financial results based on an inventory of the Company's current contracts with customers. The Company has obtained an understanding of the new standard and currently believes that it will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of its contracts is currently recognized under percentage of completion accounting, applying a cost-to-cost method.

[0000068505-17-000011:notes:150]
Under the new standard, the Company must identify the distinct promises to transfer goods and/or services within its contracts using certain factors. For contracts that are currently recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices represent distinct goods. Accordingly, adoption of the new standard will impact the Company's percentage of completion contracts that include devices, with the resulting impact being revenue recognized earlier as control of the devices transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's percentage of completion contracts, it will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in the Company's contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000011:notes:151]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While the Company may have contracts which fall under these rules in the current standard, it has not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, the Company does not anticipate a significant acceleration of revenue upon applying the new standard to its current contracts under these fact patterns.

[0000068505-17-000011:notes:152]
The Company continues to evaluate the impact of ASU No. 2014-09 on its financial results and prepare for the adoption of the standard on January 1, 2018, including readying its internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. The Company expects to adopt this standard under the modified retrospective method of adoption, which recognizes the cumulative effect of transition as an adjustment to retained earnings for contracts that are not completed as of the adoption date, without restating prior period financial statements.

[0000068505-17-000011:notes:153]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000011:notes:154]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company January 1, 2018 with early adoption permitted. The Company intends to adopt this ASU January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000011:notes:155]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The Company intends to adopt the ASU January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000011:notes:156]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in the total cash, cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for the Company January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires the retrospective application. The Company does not anticipate significant changes to the Company's financial statements and related disclosures from adoption of the ASU.

[0000068505-17-000011:notes:157]
In March 2017, the FASB issued ASU 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the Company plans to update the presentation of net periodic cost (benefit) accordingly, noting all components of the Company's net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of $37 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-17-000011:notes:158]
[same as prior period, unchanged from 0000068505-17-000005:notes:152]

[0000068505-17-000011:notes:159]
Recent Developments

[0000068505-17-000011:notes:160]
[same as prior period, unchanged from 0000068505-17-000005:notes:153]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-17-000011:notes:161]
[same as prior period, unchanged from 0000068505-17-000005:notes:154]

[0000068505-17-000011:notes:162]
[same as prior period, unchanged from 0000068505-17-000005:notes:155]

[0000068505-17-000011:notes:163]
[same as prior period, unchanged from 0000068505-17-000005:notes:156]

[0000068505-17-000011:notes:164]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 46 |  |  | 10 |  |  | 14 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (57 | ) |  | (55 | ) |  | (24 | ) |  | (24 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 11 |  |  | 9 |  |  | 4 |  |  | 3 |  |  | 1 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (7 | ) |
| Settlement loss | — |  |  | — |  |  | 16 |  |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | — |  |  | $ | — |  |  | $ | 7 |  |  | $ | (5 | ) |  | $ | (5 | ) |  | $ | (7 | ) |

[0000068505-17-000011:notes:165]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 92 |  |  | 91 |  |  | 20 |  |  | 28 |  |  | 2 |  |  | 2 |  |
| Expected return on plan assets | (115 | ) |  | (110 | ) |  | (47 | ) |  | (48 | ) |  | (6 | ) |  | (5 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 22 |  |  | 19 |  |  | 8 |  |  | 6 |  |  | 2 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (8 | ) |  | (13 | ) |
| Settlement loss | — |  |  | — |  |  | 25 |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (1 | ) |  | $ | — |  |  | $ | 8 |  |  | $ | (10 | ) |  | $ | (10 | ) |  | $ | (13 | ) |

[0000068505-17-000011:notes:166]
During the six months ended July 1, 2017, the Company offered lump-sum settlements to certain participants in the Non-US defined benefit plan within the United Kingdom. The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments. As of June 30, 2017, the window for the participant registration in the program has closed. However, the Company expects to account for continuing settlements through the third quarter of 2017, as remaining lump-sum settlements are paid to participants. As a result of the actions taken through the first half of 2017, the Company recorded a settlement loss of $16 million and $25 million during the three and six months ended July 1, 2017, which is recorded within Other Charges within the condensed consolidated statement of operations.

[0000068505-17-000011:notes:167]
During the six months ended July 2, 2016, the Company made an amendment to the Postretirement Health Care Benefits Plan (the “Amendment”). As a result of the Amendment, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. The Amendment to the Postretirement Health Care Benefits Plan required a remeasurement of the plan, resulting in a $53 million reduction in the Accumulated Postretirement Benefit Obligation. A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the condensed consolidated statements of operations over approximately five years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-17-000011:notes:168]
[same as prior period, unchanged from 0000068505-17-000005:notes:159]

[0000068505-17-000011:notes:169]
[same as prior period, unchanged from 0000068505-17-000005:notes:160]

[0000068505-17-000011:notes:170]
During the three months ended July 1, 2017, the Company recorded net reorganization of business charges of $3 million including $1 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $3 million were charges of $8 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000011:notes:171]
During the six months ended July 1, 2017, the Company recorded net reorganization of business charges of $22 million including $16 million of charges in Other charges and $6 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $22 million were charges of $23 million for employee separation costs and $4 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000011:notes:172]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2017 to July 1, 2017:

[0000068505-17-000011:notes:173]
|  | January 1, 2017 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | July 1, 2017 |
| Exit costs | $ | 7 |  |  | $ | 4 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 10 |  |
| Employee separation costs | 95 |  |  | 23 |  |  | (5 | ) |  | (55 | ) |  | 58 |  |
|  | $ | 102 |  |  | $ | 27 |  |  | $ | (5 | ) |  | $ | (56 | ) |  | $ | 68 |  |

[0000068505-17-000011:notes:174]
[same as prior period, unchanged from 0000068505-17-000005:notes:164]

[0000068505-17-000011:notes:175]
At January 1, 2017, the Company had $7 million of accruals for exit costs. During the six months ended July 1, 2017, there were $4 million of additional charges and $1 million of cash payments related to the exit of leased facilities. The remaining accrual of $10 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at July 1, 2017, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-17-000011:notes:176]
[same as prior period, unchanged from 0000068505-17-000005:notes:166]

[0000068505-17-000011:notes:177]
At January 1, 2017, the Company had an accrual of $95 million for employee separation costs. The 2017 additional charges of $23 million represent severance costs for approximately 300 employees. The adjustment of $5 million reflects reversals for accruals no longer needed. The $55 million used reflects cash payments to severed employees. The remaining accrual of $58 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at July 1, 2017, is expected to be paid, primarily within one year, to approximately 500 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-17-000011:notes:178]
[same as prior period, unchanged from 0000068505-17-000005:notes:168]

[0000068505-17-000011:notes:179]
During the three months ended July 2, 2016, the Company recorded net reorganization of business charges of $44 million including $36 million of charges in Other charges and $8 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $44 million were charges of: (i) $22 million of charges related to employee separation costs, (ii) $17 million for a building impairment, and (iii) $5 million for exit costs.

[0000068505-17-000011:notes:180]
During the six months ended July 2, 2016, the Company recorded net reorganization of business charges of $67 million including $42 million of charges in Other charges and $25 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $67 million were charges of: (i) $46 million related to employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $4 million of reversals for accruals no longer needed.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-17-000011:notes:181]
[same as prior period, unchanged from 0000068505-17-000005:notes:170]

[0000068505-17-000011:notes:182]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Products | $ | 848 |  |  | $ | 801 |  |  | $ | 1,551 |  |  | $ | 1,503 |  |
| Services | 649 |  |  | 629 |  |  | 1,226 |  |  | 1,120 |  |
|  | $ | 1,497 |  |  | $ | 1,430 |  |  | $ | 2,777 |  |  | $ | 2,623 |  |

[0000068505-17-000011:notes:183]
[same as prior period, unchanged from 0000068505-17-000005:notes:172]

[0000068505-17-000011:notes:184]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Products | $ | 168 |  |  | $ | 129 |  |  | $ | 257 |  |  | $ | 179 |  |
| Services | 89 |  |  | 95 |  |  | 176 |  |  | 144 |  |
| Operating earnings | 257 |  |  | 224 |  |  | 433 |  |  | 323 |  |
| Total other expense | (52 | ) |  | (57 | ) |  | (109 | ) |  | (134 | ) |
| Earnings before income taxes | $ | 205 |  |  | $ | 167 |  |  | $ | 324 |  |  | $ | 189 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-17-000011:notes:185]
[same as prior period, unchanged from 0000068505-17-000005:notes:174]

[0000068505-17-000011:notes:186]
[same as prior period, unchanged from 0000068505-17-000005:notes:175]

[0000068505-17-000011:notes:187]
[same as prior period, unchanged from 0000068505-17-000005:notes:176]

[0000068505-17-000011:notes:188]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed services offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers.
