# MSI 8-K — 0001193125-17-247458 filed 2017-08-03

## item codes, every 8-K on or before 2017-08-04

- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2017-08-04

- none on or before 2017-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-247458:8k_2_02:1]
EX-99.1
2
d434731dex991.htm
EX-99.1

[0001193125-17-247458:8k_2_02:2]
EX-99.1

[0001193125-17-247458:8k_2_02:3]
Exhibit 99.1

[0001193125-17-247458:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2017 Financial Results

[0001193125-17-247458:8k_2_02:5]
Company raises full-year revenue and earnings outlook

[0001193125-17-247458:8k_2_02:6]
|  | • |  | Sales of $1.5 billion, up 5 percent from a year ago |

[0001193125-17-247458:8k_2_02:7]
|  | • |  | Products sales up 6 percent driven by growth in every region |

[0001193125-17-247458:8k_2_02:8]
|  | • |  | Backlog growth of $265 million from a year ago |

[0001193125-17-247458:8k_2_02:9]
|  | • |  | GAAP earnings per share (EPS) of $0.78, up 28 percent |

[0001193125-17-247458:8k_2_02:10]
|  | • |  | Non-GAAP EPS of $1.12, up 9 percent |

[0001193125-17-247458:8k_2_02:11]
|  | • |  | Acquiring Airbus DS Communications (Plant Holdings, Inc.), strengthening command center software portfolio |

[0001193125-17-247458:8k_2_02:12]
CHICAGO – Aug. 3, 2017 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2017.
Click here for a printable news release and financial tables.

[0001193125-17-247458:8k_2_02:13]
SUPPORTING QUOTE

[0001193125-17-247458:8k_2_02:14]
“Q2 was an outstanding quarter of revenue and EPS growth driven primarily by our land mobile radio (LMR) business,” said Greg Brown, chairman and CEO
of Motorola Solutions. “Additionally, I’m pleased with our strong backlog position and recent acquisitions that provide the foundation for continued success.”

[0001193125-17-247458:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0001193125-17-247458:8k_2_02:16]
|  |  | Q2 2017 |  |  | Q2 2016 |  |  | % Change |  |
| Sales |  | $ | 1,497 |  |  | $ | 1,430 |  |  |  | 5 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 257 |  |  | $ | 224 |  |  |  | 15 | % |
| % of Sales |  |  | 17.2 | % |  |  | 15.7 | % |  |  |  |  |
| EPS |  | $ | 0.78 |  |  | $ | 0.61 |  |  |  | 28 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 328 |  |  | $ | 324 |  |  |  | 1 | % |
| % of Sales |  |  | 21.9 | % |  |  | 22.7 | % |  |  |  |  |
| EPS |  | $ | 1.12 |  |  | $ | 1.03 |  |  |  | 9 | % |
| Product Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 848 |  |  | $ | 801 |  |  |  | 6 | % |
| GAAP Operating Earnings |  | $ | 168 |  |  | $ | 129 |  |  |  | 30 | % |
| % of Sales |  |  | 19.8 | % |  |  | 16.1 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 193 |  |  | $ | 176 |  |  |  | 10 | % |
| % of Sales |  |  | 22.8 | % |  |  | 22.0 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 649 |  |  | $ | 629 |  |  |  | 3 | % |
| GAAP Operating Earnings |  | $ | 89 |  |  | $ | 95 |  |  |  | (6 | )% |
| % of Sales |  |  | 13.7 | % |  |  | 15.1 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 135 |  |  | $ | 148 |  |  |  | (9 | )% |
| % of Sales |  |  | 20.8 | % |  |  | 23.5 | % |  |  |  |  |

[0001193125-17-247458:8k_2_02:17]
| * | Non-GAAP financial information excludes the after-tax impact of approximately $0.34 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-17-247458:8k_2_02:18]
| • |  | Revenue – Sales increased 5 percent driven by the Americas region. Products segment sales grew 6 percent with growth in every region, driven primarily by P25 LMR systems. The Services segment grew 3 percent driven by the Americas, with global Managed & Support Services growth of 3 percent despite $20 million of Airwave currency headwinds. |

[0001193125-17-247458:8k_2_02:19]
| • |  | Operating margin – GAAP operating margin was 17.2 percent of sales, compared with 15.7 percent in the year-ago quarter. The improvement reflects higher sales volume and lower other costs. Non-GAAP operating margin was 21.9 percent of sales, compared with 22.7 percent in the year-ago quarter. As expected, the sales increase was offset by lower gross margin associated with higher systems mix in North America, as well as Airwave currency headwinds. |

[0001193125-17-247458:8k_2_02:20]
| • |  | Cash flow – The company generated $173 million in operating cash, a decrease of $119 million from the year-ago quarter. Free cash flow2 was $120 million, down $81 million. Cash flow for the quarter was down due to timing of higher working capital primarily associated with the implementation of a new ERP system. Year-to-date operating cash flow and free cash flow were higher than the prior year driven by higher earnings. |

[0001193125-17-247458:8k_2_02:21]
| • |  | Capital Allocation – The company ended the quarter with cash and cash equivalents of $805 million and a net debt position of approximately $3.7 billion3. The company repurchased approximately $80 million of its common stock and paid approximately $77 million in cash dividends. Additionally, the company announced the acquisition of Airbus DS Communications (Plant Holdings, Inc.), strengthening its command center software portfolio. |

[0001193125-17-247458:8k_2_02:22]
| • |  | Backlog – The company ended the quarter with $8.5 billion of backlog, up $265 million from the year-ago quarter. Products segment backlog is up 15 percent or $204 million, and Services is up 1 percent or $61 million. LMR demand led by the Americas continues to drive the backlog growth. |

[0001193125-17-247458:8k_2_02:23]
KEY HIGHLIGHTS

[0001193125-17-247458:8k_2_02:24]
Strategic wins and awards

[0001193125-17-247458:8k_2_02:25]
|  | • |  | $160 million for a 10-year Managed & Support Services agreement in Canada |

[0001193125-17-247458:8k_2_02:26]
|  | • |  | $43 million for P25 devices in a major U.S. city |

[0001193125-17-247458:8k_2_02:27]
|  | • |  | $40 million for P25 system in Broward County, Florida |

[0001193125-17-247458:8k_2_02:28]
|  | • |  | $24 million for P25 system with a large utility in the northeastern U.S. |

[0001193125-17-247458:8k_2_02:29]
|  | • |  | $19 million for P25 system covering three Kentucky counties that includes a 10-year Managed & Support Services agreement |

[0001193125-17-247458:8k_2_02:30]
|  | • |  | $10 million for P25 devices in Australia |

[0001193125-17-247458:8k_2_02:31]
Innovation and investments in growth

[0001193125-17-247458:8k_2_02:32]
|  | • |  | Announced acquisition of Airbus DS Communications (Plant Holdings, Inc.), strengthening the company’s command center software portfolio. Airbus DS Communications is a leading provider in North America of command center software for emergency call-handling |

[0001193125-17-247458:8k_2_02:33]
|  | • |  | Certified Public Safety LTE device LEX F10 for the AT&T FirstNet network |

[0001193125-17-247458:8k_2_02:34]
|  | • |  | Delivered 1,000th TETRA digital radio system and 25,000th base station |

[0001193125-17-247458:8k_2_02:35]
BUSINESS OUTLOOK

[0001193125-17-247458:8k_2_02:36]
|  | • |  | Third-quarter 2017 – Motorola Solutions expects revenue growth of 3 to 4 percent compared with the third quarter of 2016. The company expects non-GAAP earnings in the range of $1.36 to $1.41 per share. |

[0001193125-17-247458:8k_2_02:37]
|  | • |  | Full-year 2017 – The company now expects revenue growth of approximately 3 to 4 percent versus the prior outlook of approximately 2 percent, and non-GAAP earnings per share now in the range of $5.20 to $5.30 from the prior outlook of $5.08 to $5.23. This assumes current foreign exchange rates and approximately 170 million fully diluted shares for the full year. |

[0001193125-17-247458:8k_2_02:38]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m.
U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, Aug. 3. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0001193125-17-247458:8k_2_02:39]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0001193125-17-247458:8k_2_02:40]
A comparison of results from operations is as follows:

[0001193125-17-247458:8k_2_02:41]
|  |  | Q2 2017 |  |  | Q2 2016 |  |
| Net sales |  | $ | 1,497 |  |  | $ | 1,430 |  |
| Gross margin |  |  | 690 |  |  |  | 676 |  |
| Operating earnings |  |  | 257 |  |  |  | 224 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Net earnings |  |  | 131 |  |  |  | 107 |  |
| Diluted EPS |  | $ | 0.78 |  |  | $ | 0.61 |  |
| Weighted average diluted common shares outstanding |  |  | 169.0 |  |  |  | 174.8 |  |

[0001193125-17-247458:8k_2_02:42]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-17-247458:8k_2_02:43]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the second quarter of 2017.

[0001193125-17-247458:8k_2_02:44]
| (per diluted common share) |  | Q2 2017 |  |
| GAAP Earnings |  | $ | 0.78 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.07 |  |
| Reorganization of business charges |  |  | 0.02 |  |
| Intangibles amortization expense |  |  | 0.17 |  |
| Non-US pension settlement loss |  |  | 0.08 |  |
| Legal settlement |  |  | (0.01 | ) |
| Sale of business |  |  | 0.01 |  |
| Total Highlighted Items |  | $ | 0.34 |  |
| Non-GAAP Diluted EPS |  | $ | 1.12 |  |

[0001193125-17-247458:8k_2_02:45]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-17-247458:8k_2_02:46]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP
measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period
to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results
relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better
period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended
only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of
financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-17-247458:8k_2_02:47]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited
to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring or reorganization of business charges, non-cash pension adjustments, significant litigation and
other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the
company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s current operating performance or comparisons to the company’s past
operating performance. For the purposes of management’s internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the
company’s current operating performance or comparisons to the company’s past operating performance. Specifically in regards to its restructuring plans, the company has incurred significant reorganization of business charges as it reduced
operating expenses over the past four years.

[0001193125-17-247458:8k_2_02:48]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the
revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it
represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-17-247458:8k_2_02:49]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its
Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding
intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible
assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-17-247458:8k_2_02:50]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can
be found at the end of this press release.

[0001193125-17-247458:8k_2_02:51]
BUSINESS RISKS

[0001193125-17-247458:8k_2_02:52]
the government communications industry; (2) the impact of foreign currency fluctuations on the company; (3) the level of demand for the company’s products; (4) the
company’s ability to refresh existing and introduce new products and technologies in a timely manner; (5) negative impact on the company’s business from global economic and political conditions, which may include: (i) continued
deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company’s products; (iii) increased demand to provide vendor financing to customers;
(iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company’s suppliers that may no longer have access to necessary financing; (vi) counterparty failures negatively
impacting the company’s financial position; (vii) changes in the value of investments held by the company’s pension plan and other defined benefit plans, which could impact future required or voluntary pension contributions; and
(viii) the company’s ability to access the capital markets on acceptable terms and conditions; (6) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or
those it sells to or operates or maintains for its customers; (7) the outcome of ongoing and future tax matters; (8) the company’s ability to purchase sufficient materials, parts and components to meet customer demand, particularly in
light of global economic conditions and reductions in the company’s purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (10) the impact on the
company’s performance and financial results from strategic acquisitions or divestitures; (11) risks related to the company’s manufacturing and business operations in foreign countries; (12) the creditworthiness of the
company’s customers and distributors, particularly purchasers of large infrastructure systems; (13) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the
company build, own and operate their systems, often over a multi-year period; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in
income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes
to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to
possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the
company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company’s use of third party vendors for various activities, including certain manufacturing
operations, information technology and administrative functions; (22) the implementation of a new enterprise resource planning system; and (23) the company’s ability to settle the par value of its Senior Convertible Notes in cash.
Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0001193125-17-247458:8k_2_02:53]
DEFINITIONS

[0001193125-17-247458:8k_2_02:54]
| 1 | Q2 Non-GAAP financial information excludes the after-tax impact of approximately $0.34 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items for the fourth-quarter. Details on these non-GAAP adjustments and the use of non-GAAP measures are included in this news release. |

[0001193125-17-247458:8k_2_02:55]
| 2 | Free cash flow represents operating cash flow less capital expenditures |

[0001193125-17-247458:8k_2_02:56]
| 3 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-17-247458:8k_2_02:57]
ABOUT MOTOROLA SOLUTIONS

[0001193125-17-247458:8k_2_02:58]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build
safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-17-247458:8k_2_02:59]
MEDIA
CONTACT

[0001193125-17-247458:8k_2_02:60]
Tama McWhinney

[0001193125-17-247458:8k_2_02:61]
Motorola Solutions

[0001193125-17-247458:8k_2_02:62]
+1 847-538-1865

[0001193125-17-247458:8k_2_02:63]
tama.mcwhinney@motorolasolutions.com

[0001193125-17-247458:8k_2_02:64]
INVESTOR CONTACT

[0001193125-17-247458:8k_2_02:65]
Chris Kutsor

[0001193125-17-247458:8k_2_02:66]
Motorola Solutions

[0001193125-17-247458:8k_2_02:67]
+1 847-576-4995

[0001193125-17-247458:8k_2_02:68]
chris.kutsor@motorolasolutions.com

[0001193125-17-247458:8k_2_02:69]
MOTOROLA, MOTOROLA
SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners.
©2017 Motorola Solutions, Inc. All rights reserved.

[0001193125-17-247458:8k_2_02:70]
GAAP-1

[0001193125-17-247458:8k_2_02:71]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:72]
Condensed Consolidated Statements of Operations

[0001193125-17-247458:8k_2_02:73]
(In millions, except per share amounts)

[0001193125-17-247458:8k_2_02:74]
|  |  | Three Months Ended |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Net sales from products |  | $ | 848 |  |  | $ | 801 |  |
| Net sales from services |  |  | 649 |  |  |  | 629 |  |
| Net sales |  |  | 1,497 |  |  |  | 1,430 |  |
| Costs of products sales |  |  | 392 |  |  |  | 361 |  |
| Costs of services sales |  |  | 415 |  |  |  | 393 |  |
| Costs of sales |  |  | 807 |  |  |  | 754 |  |
| Gross margin |  |  | 690 |  |  |  | 676 |  |
| Selling, general and administrative expenses |  |  | 242 |  |  |  | 240 |  |
| Research and development expenditures |  |  | 138 |  |  |  | 138 |  |
| Other charges |  |  | 16 |  |  |  | 36 |  |
| Intangibles amortization |  |  | 37 |  |  |  | 38 |  |
| Operating earnings |  |  | 257 |  |  |  | 224 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (51 | ) |  |  | (54 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | (1 | ) |  |  | 1 |  |
| Other |  |  | — |  |  |  | (4 | ) |
| Total other expense |  |  | (52 | ) |  |  | (57 | ) |
| Net earnings before income taxes |  |  | 205 |  |  |  | 167 |  |
| Income tax expense |  |  | 73 |  |  |  | 59 |  |
| Net earnings |  |  | 132 |  |  |  | 108 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 131 |  |  | $ | 107 |  |
| Earnings per common share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.80 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.78 |  |  | $ | 0.61 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 163.1 |  |  |  | 171.9 |  |
| Diluted |  |  | 169.0 |  |  |  | 174.8 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 56.6 | % |  |  | 56.0 | % |
| Net sales from services |  |  | 43.4 | % |  |  | 44.0 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 46.2 | % |  |  | 45.1 | % |
| Costs of services sales |  |  | 63.9 | % |  |  | 62.5 | % |
| Costs of sales |  |  | 53.9 | % |  |  | 52.7 | % |
| Gross margin |  |  | 46.1 | % |  |  | 47.3 | % |
| Selling, general and administrative expenses |  |  | 16.2 | % |  |  | 16.8 | % |
| Research and development expenditures |  |  | 9.2 | % |  |  | 9.7 | % |
| Other charges |  |  | 1.1 | % |  |  | 2.5 | % |
| Intangibles amortization |  |  | 2.5 | % |  |  | 2.7 | % |
| Operating earnings |  |  | 17.2 | % |  |  | 15.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.4 | )% |  |  | (3.8 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | (0.1 | )% |  |  | 0.1 | % |
| Other |  |  | — | % |  |  | (0.3 | )% |
| Total other expense |  |  | (3.5 | )% |  |  | (4.0 | )% |
| Net earnings before income taxes |  |  | 13.7 | % |  |  | 11.7 | % |
| Income tax expense |  |  | 4.9 | % |  |  | 4.1 | % |
| Net earnings |  |  | 8.8 | % |  |  | 7.6 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 8.8 | % |  |  | 7.5 | % |

[0001193125-17-247458:8k_2_02:75]
| * | Percentages may not add up due to rounding |

[0001193125-17-247458:8k_2_02:76]
GAAP-2

[0001193125-17-247458:8k_2_02:77]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:78]
Condensed Consolidated Statements of Operations

[0001193125-17-247458:8k_2_02:79]
(In millions, except per share amounts)

[0001193125-17-247458:8k_2_02:80]
|  |  | Six Months Ended |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Net sales from products |  | $ | 1,551 |  |  | $ | 1,503 |  |
| Net sales from services |  |  | 1,226 |  |  |  | 1,120 |  |
| Net sales |  |  | 2,777 |  |  |  | 2,623 |  |
| Costs of products sales |  |  | 739 |  |  |  | 726 |  |
| Costs of services sales |  |  | 778 |  |  |  | 718 |  |
| Costs of sales |  |  | 1,517 |  |  |  | 1,444 |  |
| Gross margin |  |  | 1,260 |  |  |  | 1,179 |  |
| Selling, general and administrative expenses |  |  | 475 |  |  |  | 475 |  |
| Research and development expenditures |  |  | 273 |  |  |  | 274 |  |
| Other charges |  |  | 6 |  |  |  | 55 |  |
| Intangibles amortization |  |  | 73 |  |  |  | 52 |  |
| Operating earnings |  |  | 433 |  |  |  | 323 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (102 | ) |  |  | (103 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | 2 |  |  |  | (20 | ) |
| Other |  |  | (9 | ) |  |  | (11 | ) |
| Total other expense |  |  | (109 | ) |  |  | (134 | ) |
| Net earnings before income taxes |  |  | 324 |  |  |  | 189 |  |
| Income tax expense |  |  | 114 |  |  |  | 64 |  |
| Net earnings |  |  | 210 |  |  |  | 125 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 2 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 208 |  |  | $ | 124 |  |
| Earnings per common share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.27 |  |  | $ | 0.72 |  |
| Diluted |  | $ | 1.23 |  |  | $ | 0.71 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 163.7 |  |  |  | 173.0 |  |
| Diluted |  |  | 169.5 |  |  |  | 175.7 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 55.9 | % |  |  | 57.3 | % |
| Net sales from services |  |  | 44.1 | % |  |  | 42.7 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 47.6 | % |  |  | 48.3 | % |
| Costs of services sales |  |  | 63.5 | % |  |  | 64.1 | % |
| Costs of sales |  |  | 54.6 | % |  |  | 55.1 | % |
| Gross margin |  |  | 45.4 | % |  |  | 44.9 | % |
| Selling, general and administrative expenses |  |  | 17.1 | % |  |  | 18.1 | % |
| Research and development expenditures |  |  | 9.8 | % |  |  | 10.4 | % |
| Other charges |  |  | 0.2 | % |  |  | 2.1 | % |
| Intangibles amortization |  |  | 2.6 | % |  |  | 2.0 | % |
| Operating earnings |  |  | 15.6 | % |  |  | 12.3 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.7 | )% |  |  | (3.9 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | 0.1 | % |  |  | (0.8 | )% |
| Other |  |  | (0.3 | )% |  |  | (0.4 | )% |
| Total other expense |  |  | (3.9 | )% |  |  | (5.1 | )% |
| Net earnings before income taxes |  |  | 11.7 | % |  |  | 7.2 | % |
| Income tax expense |  |  | 4.1 | % |  |  | 2.4 | % |
| Net earnings |  |  | 7.6 | % |  |  | 4.8 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 7.5 | % |  |  | 4.7 | % |

[0001193125-17-247458:8k_2_02:81]
| * | Percentages may not add up due to rounding |

[0001193125-17-247458:8k_2_02:82]
GAAP-3

[0001193125-17-247458:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:84]
Condensed Consolidated Balance Sheets

[0001193125-17-247458:8k_2_02:85]
(In millions)

[0001193125-17-247458:8k_2_02:86]
|  |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 742 |  |  | $ | 967 |  |
| Restricted cash |  |  | 63 |  |  |  | 63 |  |
| Total cash and cash equivalents |  |  | 805 |  |  |  | 1,030 |  |
| Accounts receivable, net |  |  | 1,211 |  |  |  | 1,410 |  |
| Inventories, net |  |  | 391 |  |  |  | 273 |  |
| Other current assets |  |  | 804 |  |  |  | 755 |  |
| Total current assets |  |  | 3,211 |  |  |  | 3,468 |  |
| Property, plant and equipment, net |  |  | 859 |  |  |  | 789 |  |
| Investments |  |  | 248 |  |  |  | 238 |  |
| Deferred income taxes |  |  | 2,160 |  |  |  | 2,219 |  |
| Goodwill |  |  | 749 |  |  |  | 728 |  |
| Intangible Assets |  |  | 868 |  |  |  | 821 |  |
| Other assets |  |  | 200 |  |  |  | 200 |  |
| Total assets |  | $ | 8,295 |  |  | $ | 8,463 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 46 |  |  | $ | 4 |  |
| Accounts payable |  |  | 440 |  |  |  | 553 |  |
| Accrued liabilities |  |  | 1,924 |  |  |  | 2,111 |  |
| Total current liabilities |  |  | 2,410 |  |  |  | 2,668 |  |
| Long-term debt |  |  | 4,421 |  |  |  | 4,392 |  |
| Other liabilities |  |  | 2,440 |  |  |  | 2,355 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (988 | ) |  |  | (964 | ) |
| Noncontrolling interests |  |  | 12 |  |  |  | 12 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,295 |  |  | $ | 8,463 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (3,662 | ) |  | $ | (3,366 | ) |

[0001193125-17-247458:8k_2_02:87]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-17-247458:8k_2_02:88]
GAAP-4

[0001193125-17-247458:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:90]
Condensed Consolidated Statements of Cash Flows

[0001193125-17-247458:8k_2_02:91]
(In millions)

[0001193125-17-247458:8k_2_02:92]
|  |  | Three Months Ended |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 131 |  |  | $ | 107 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings |  |  | 132 |  |  |  | 108 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 86 |  |  |  | 82 |  |
| Non-cash other charges |  |  | 6 |  |  |  | 24 |  |
| Non-U.S. pension settlement loss |  |  | 16 |  |  |  | — |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 18 |  |
| Losses (gains) on sales of investments and businesses, net |  |  | 1 |  |  |  | (1 | ) |
| Deferred income taxes |  |  | 40 |  |  |  | 35 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (117 | ) |  |  | 50 |  |
| Inventories |  |  | (43 | ) |  |  | 2 |  |
| Other current assets |  |  | 38 |  |  |  | (22 | ) |
| Accounts payable and accrued liabilities |  |  | (33 | ) |  |  | 1 |  |
| Other assets and liabilities |  |  | 31 |  |  |  | (5 | ) |
| Net cash provided by operating activities |  |  | 173 |  |  |  | 292 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (34 | ) |  |  | (67 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 19 |  |  |  | 72 |  |
| Capital expenditures |  |  | (53 | ) |  |  | (91 | ) |
| Proceeds from sales of property, plant and equipment |  |  | — |  |  |  | 46 |  |
| Net cash used for investing activities |  |  | (68 | ) |  |  | (40 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (5 | ) |  |  | (1 | ) |
| Proceeds from financing through capital leases |  |  | 7 |  |  |  | — |  |
| Issuance of common stock |  |  | 6 |  |  |  | (1 | ) |
| Purchase of common stock |  |  | (80 | ) |  |  | (555 | ) |
| Payment of dividends |  |  | (77 | ) |  |  | (72 | ) |
| Payment of dividend to non-controlling interest |  |  | (2 | ) |  |  | — |  |
| Net cash used for financing activities |  |  | (151 | ) |  |  | (629 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 22 |  |  |  | (18 | ) |
| Net decrease in cash and cash equivalents |  |  | (24 | ) |  |  | (395 | ) |
| Cash and cash equivalents, beginning of period |  |  | 829 |  |  |  | 1,940 |  |
| Cash and cash equivalents, end of period |  | $ | 805 |  |  | $ | 1,545 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 120 |  |  | $ | 201 |  |

[0001193125-17-247458:8k_2_02:93]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-17-247458:8k_2_02:94]
GAAP-5

[0001193125-17-247458:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:96]
Condensed Consolidated Statements of Cash Flows

[0001193125-17-247458:8k_2_02:97]
(In millions)

[0001193125-17-247458:8k_2_02:98]
|  |  | Six Months Ended |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 208 |  |  | $ | 124 |  |
| Earnings attributable to noncontrolling interests |  |  | 2 |  |  |  | 1 |  |
| Net earnings |  |  | 210 |  |  |  | 125 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 166 |  |  |  | 144 |  |
| Non-cash other charges |  |  | 21 |  |  |  | 35 |  |
| Non-U.S. pension settlement loss |  |  | 25 |  |  |  | — |  |
| Share-based compensation expense |  |  | 33 |  |  |  | 35 |  |
| Losses (gains) on sales of investments and businesses, net |  |  | (2 | ) |  |  | 20 |  |
| Deferred income taxes |  |  | 63 |  |  |  | 71 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 251 |  |  |  | 327 |  |
| Inventories |  |  | (112 | ) |  |  | (2 | ) |
| Other current assets |  |  | (21 | ) |  |  | (65 | ) |
| Accounts payable and accrued liabilities |  |  | (340 | ) |  |  | (362 | ) |
| Other assets and liabilities |  |  | 21 |  |  |  | (24 | ) |
| Net cash provided by operating activities |  |  | 315 |  |  |  | 304 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (140 | ) |  |  | (1,120 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 72 |  |  |  | 553 |  |
| Capital expenditures |  |  | (121 | ) |  |  | (143 | ) |
| Proceeds from sales of property, plant and equipment |  |  | — |  |  |  | 46 |  |
| Net cash used for investing activities |  |  | (189 | ) |  |  | (664 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (6 | ) |  |  | (2 | ) |
| Net proceeds from issuance of debt |  |  | — |  |  |  | 673 |  |
| Proceeds from financing through capital leases |  |  | 7 |  |  |  | — |  |
| Issuance of common stock |  |  | 28 |  |  |  | 40 |  |
| Purchase of common stock |  |  | (258 | ) |  |  | (619 | ) |
| Payment of dividends |  |  | (154 | ) |  |  | (143 | ) |
| Payment of dividend to non-controlling interest |  |  | (2 | ) |  |  | — |  |
| Net cash used for financing activities |  |  | (385 | ) |  |  | (51 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 34 |  |  |  | (24 | ) |
| Net decrease in cash and cash equivalents |  |  | (225 | ) |  |  | (435 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,030 |  |  |  | 1,980 |  |
| Cash and cash equivalents, end of period |  | $ | 805 |  |  | $ | 1,545 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 194 |  |  | $ | 161 |  |

[0001193125-17-247458:8k_2_02:99]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-17-247458:8k_2_02:100]
GAAP-6

[0001193125-17-247458:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:102]
Segment Information

[0001193125-17-247458:8k_2_02:103]
(In
millions)

[0001193125-17-247458:8k_2_02:104]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 848 |  |  | $ | 801 |  |  |  | 6 | % |
| Services |  |  | 649 |  |  |  | 629 |  |  |  | 3 | % |
| Total Motorola Solutions |  | $ | 1,497 |  |  | $ | 1,430 |  |  |  | 5 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 1,551 |  |  | $ | 1,503 |  |  |  | 3 | % |
| Services |  |  | 1,226 |  |  |  | 1,120 |  |  |  | 9 | % |
| Total Motorola Solutions |  | $ | 2,777 |  |  | $ | 2,623 |  |  |  | 6 | % |
| Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 168 |  |  | $ | 129 |  |  |  | 30 | % |
| Services |  |  | 89 |  |  |  | 95 |  |  |  | (6 | )% |
| Total Motorola Solutions |  | $ | 257 |  |  | $ | 224 |  |  |  | 15 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 257 |  |  | $ | 179 |  |  |  | 44 | % |
| Services |  |  | 176 |  |  |  | 144 |  |  |  | 22 | % |
| Total Motorola Solutions |  | $ | 433 |  |  | $ | 323 |  |  |  | 34 | % |
| Operating Earnings % |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  |  |  |
| Products |  |  | 19.8 | % |  |  | 16.1 | % |  |  |  |  |
| Services |  |  | 13.7 | % |  |  | 15.1 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 17.2 | % |  |  | 15.7 | % |  |  |  |  |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  |  |  |
| Products |  |  | 16.6 | % |  |  | 11.9 | % |  |  |  |  |
| Services |  |  | 14.4 | % |  |  | 12.9 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 15.6 | % |  |  | 12.3 | % |  |  |  |  |

[0001193125-17-247458:8k_2_02:105]
Non-GAAP-1

[0001193125-17-247458:8k_2_02:106]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:107]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and
Highlighted Items)

[0001193125-17-247458:8k_2_02:108]
| Q1 2017 |  |
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 19 |  |  |  | 4 |  |  |  | 15 |  |  |  | 0.09 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 36 |  |  |  | 9 |  |  |  | 27 |  |  |  | 0.16 |  |
| Gain on legal settlement |  |  | Other charges |  |  |  | (42 | ) |  |  | (16 | ) |  |  | (26 | ) |  |  | (0.15 | ) |
| Building impairment |  |  | Other charges |  |  |  | 8 |  |  |  | — |  |  |  | 8 |  |  |  | 0.05 |  |
| Non-US pension settlement loss |  |  | Other charges |  |  |  | 9 |  |  |  | — |  |  |  | 9 |  |  |  | 0.05 |  |
| Sale of investments |  |  | Sale of Investment or Business(Gain) or Loss |  |  |  | (3 | ) |  |  | (1 | ) |  |  | (2 | ) |  |  | (0.01 | ) |
| Acquisition-related transaction fees |  |  | Other charges |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 0.01 |  |
| Total impact on Net earnings |  |  |  |  |  | $ | 45 |  |  | $ | 2 |  |  | $ | 43 |  |  | $ | 0.26 |  |
| Q2 2017 |  |
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 16 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | 0.02 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 37 |  |  |  | 9 |  |  |  | 28 |  |  |  | 0.17 |  |
| Non-US pension settlement loss |  |  | Other charges |  |  |  | 16 |  |  |  | — |  |  |  | 16 |  |  |  | 0.08 |  |
| Legal settlement |  |  | Other charges |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (0.01 | ) |
| Sale of business |  |  | Sale of Investment or Business(Gain) or Loss |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 0.01 |  |
| Total impact on Net earnings |  |  |  |  |  | $ | 72 |  |  | $ | 14 |  |  | $ | 58 |  |  | $ | 0.34 |  |

[0001193125-17-247458:8k_2_02:109]
Non-GAAP-2

[0001193125-17-247458:8k_2_02:110]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:111]
Non-GAAP Segment Information

[0001193125-17-247458:8k_2_02:112]
(In millions)

[0001193125-17-247458:8k_2_02:113]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 848 |  |  | $ | 801 |  |  |  | 6 | % |
| Services |  |  | 649 |  |  |  | 629 |  |  |  | 3 | % |
| Total Motorola Solutions |  | $ | 1,497 |  |  | $ | 1,430 |  |  |  | 5 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 1,551 |  |  | $ | 1,503 |  |  |  | 3 | % |
| Services |  |  | 1,226 |  |  |  | 1,120 |  |  |  | 9 | % |
| Total Motorola Solutions |  | $ | 2,777 |  |  | $ | 2,623 |  |  |  | 6 | % |
| Non-GAAP Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 193 |  |  | $ | 176 |  |  |  | 10 | % |
| Services |  |  | 135 |  |  |  | 148 |  |  |  | (9 | )% |
| Total Motorola Solutions |  | $ | 328 |  |  | $ | 324 |  |  |  | 1 | % |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | % Change |  |
| Products |  | $ | 294 |  |  | $ | 260 |  |  |  | 13 | % |
| Services |  |  | 258 |  |  |  | 230 |  |  |  | 12 | % |
| Total Motorola Solutions |  | $ | 552 |  |  | $ | 490 |  |  |  | 13 | % |
| Non-GAAP Operating Earnings % |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  |  |  |
| Products |  |  | 22.8 | % |  |  | 22.0 | % |  |  |  |  |
| Services |  |  | 20.8 | % |  |  | 23.5 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 21.9 | % |  |  | 22.7 | % |  |  |  |  |
|  |  | Six Months Ended |  |  |  |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  |  |  |
| Products |  |  | 19.0 | % |  |  | 17.3 | % |  |  |  |  |
| Services |  |  | 21.0 | % |  |  | 20.5 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 19.9 | % |  |  | 18.7 | % |  |  |  |  |

[0001193125-17-247458:8k_2_02:114]
Non-GAAP-3

[0001193125-17-247458:8k_2_02:115]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-247458:8k_2_02:116]
Operating Earnings after Non-GAAP Adjustments

[0001193125-17-247458:8k_2_02:117]
| Q1 2017 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,281 |  |  | $ | 703 |  |  | $ | 578 |  |
| Operating earnings (“OE”) |  | $ | 176 |  |  | $ | 89 |  |  | $ | 87 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 19 |  |  |  | 13 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 36 |  |  |  | 6 |  |  |  | 30 |  |
| Acquisition-related transaction fees |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Gain on legal settlement |  |  | (42 | ) |  |  | (30 | ) |  |  | (12 | ) |
| Building impairment |  |  | 8 |  |  |  | 6 |  |  |  | 2 |  |
| Non-US pension settlement loss |  |  | 9 |  |  |  | 6 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 48 |  |  |  | 12 |  |  |  | 36 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 224 |  |  | $ | 101 |  |  | $ | 123 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 13.7 | % |  |  | 12.7 | % |  |  | 15.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 17.5 | % |  |  | 14.4 | % |  |  | 21.3 | % |
| Q2 2017 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,497 |  |  | $ | 848 |  |  | $ | 649 |  |
| Operating earnings (“OE”) |  | $ | 257 |  |  | $ | 168 |  |  | $ | 89 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 11 |  |  |  | 5 |  |
| Reorganization of business charges |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Intangibles amortization expense |  |  | 37 |  |  |  | 1 |  |  |  | 36 |  |
| Legal Settlement |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |
| Non-US pension settlement loss |  |  | 16 |  |  |  | 11 |  |  |  | 5 |  |
| Total above-OE non-GAAP adjustments |  |  | 71 |  |  |  | 25 |  |  |  | 46 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 328 |  |  | $ | 193 |  |  | $ | 135 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 17.2 | % |  |  | 19.8 | % |  |  | 13.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 21.9 | % |  |  | 22.8 | % |  |  | 20.8 | % |
