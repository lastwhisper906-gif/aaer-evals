# MSI MD&A — 0000068505-17-000011


## mdna

[0000068505-17-000011:mdna:1]
[same as prior period, unchanged from 0000068505-17-000005:mdna:1]

[0000068505-17-000011:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended July 1, 2017 and July 2, 2016, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2016.

[0000068505-17-000011:mdna:3]
[same as prior period, unchanged from 0000068505-17-000005:mdna:3]

[0000068505-17-000011:mdna:4]
[same as prior period, unchanged from 0000068505-17-000005:mdna:4]

[0000068505-17-000011:mdna:5]
[same as prior period, unchanged from 0000068505-17-000005:mdna:5]

[0000068505-17-000011:mdna:6]
[same as prior period, unchanged from 0000068505-17-000005:mdna:6]

[0000068505-17-000011:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the second quarter of 2017, the segment’s net sales were $848 million, representing 57% of our consolidated net sales.

[0000068505-17-000011:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the second quarter of 2017, the segment’s net sales were $649 million, representing 43% of our consolidated net sales.

[0000068505-17-000011:mdna:9]
[same as prior period, unchanged from 0000068505-17-000005:mdna:9]

[0000068505-17-000011:mdna:10]
Impact of Macroeconomic Conditions: The stronger U.S. dollar and weakening economic conditions had a negative impact on sales throughout 2015 and 2016, particularly in Latin America, parts of Europe, and China. During that time, the strengthening dollar reduced the purchasing power of our customers, and economic challenges negatively impacted government and commercial budgets in these regions. While economic conditions in parts of the world are stabilizing in 2017 in contrast to the prior year, we expect continued political and economic uncertainty, in particular with the United Kingdom’s planned exit from the European Union (commonly referred to as “Brexit”), and in parts of Latin America and Europe.

[0000068505-17-000011:mdna:11]
Focus on Managed & Support Services and Software: Services continues to grow at a faster rate than the Products segment, driven by acquisitions and core growth in Managed & Support services. While Services generally experiences lower gross margins than our Products segment, we expect revenue growth will continue to drive operating margin expansion. During the six months ended July 1, 2017, we experienced revenue growth of 9% with higher operating margins in our Services segment.

[0000068505-17-000011:mdna:12]
In addition, we continue to invest in software through internal development and strategic acquisitions, as our customers increasingly demand expanded technology solutions that are delivered via software and related services. This includes mobile applications and software in the Command Center that provide enhanced capabilities such as analytics and predictive intelligence. In some cases, government funding or mandates help drive this software expansion such as Next Generation 9-1-1 funding in the United States, and Public Safety LTE investment in the United States, United Kingdom, and other countries. This evolving trend provides a growth opportunity for us.

[0000068505-17-000011:mdna:13]
Recent Developments

[0000068505-17-000011:mdna:14]
On July 28, 2017, we announced our intention to purchase Plant Holdings, Inc., which owns the Airbus DS Communications business. This acquisition will expand our software portfolio in the Command Center with additional solutions for Next Gen 9-1-1.

[0000068505-17-000011:mdna:15]
On May 1, 2017, we announced our intention to purchase Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers. The acquisition of Kodiak Networks reflects our strategy to build our communications and collaboration software portfolio. The acquisition is expected to be completed later this year.

[0000068505-17-000011:mdna:16]
Second Quarter Summary

[0000068505-17-000011:mdna:17]
| • | Net sales were $1.5 billion in the second quarter of 2017, up $67 million, or 5%, from the second quarter of 2016. |

[0000068505-17-000011:mdna:18]
| • | We generated operating earnings of $257 million, or 17% of net sales, in the second quarter of 2017, compared to $224 million, or 16% of net sales, in the second quarter of 2016. Profitability increased as a result of higher revenue in both the Products and Services segments and lower Other charges. |

[0000068505-17-000011:mdna:19]
| • | We had net earnings attributable to Motorola Solutions, Inc. of $131 million, or $0.78 per diluted common share, in the second quarter of 2017, compared to $107 million, or $0.61 per diluted common share, in the second quarter of 2016. |

[0000068505-17-000011:mdna:20]
| • | We generated net cash from operating activities of $315 million during the first half of 2017, compared to $304 million in the first half of 2016. |

[0000068505-17-000011:mdna:21]
| • | We returned $412 million in capital to shareholders through dividends and share repurchases during the first half of 2017. |

[0000068505-17-000011:mdna:22]
[same as prior period, unchanged from 0000068505-17-000005:mdna:26]

[0000068505-17-000011:mdna:23]
| • | Products: Net sales were $848 million in the second quarter of 2017, an increase of $47 million, or 6% compared to net sales of $801 million during the second quarter of 2016. On a geographic basis, net sales increased in every region, compared to the year-ago quarter. |

[0000068505-17-000011:mdna:24]
| • | Services: Net sales were $649 million in the second quarter of 2017, an increase of $20 million, or 3% compared to net sales of $629 million in the second quarter of 2016. On a geographic basis, net sales increased in the Americas and decreased in EMEA and AP, compared to the year-ago quarter. |

[0000068505-17-000011:mdna:25]
25

[0000068505-17-000011:mdna:26]
[same as prior period, unchanged from 0000068505-17-000005:mdna:30]

[0000068505-17-000011:mdna:27]
|  | Three Months Ended | Six Months Ended |
| (Dollars in millions, except per share amounts) | July 1, 2017 |  | % ofSales* |  | July 2, 2016 |  | % ofSales* | July 1, 2017 |  | % ofSales* |  | July 2, 2016 |  | % ofSales* |
| Net sales from products | $ | 848 |  |  |  |  | $ | 801 |  |  |  | $ | 1,551 |  |  |  |  | $ | 1,503 |  |  |  |
| Net sales from services | 649 |  |  |  |  | 629 |  |  |  | 1,226 |  |  |  |  | 1,120 |  |  |  |
| Net sales | 1,497 |  |  |  |  | 1,430 |  |  |  | 2,777 |  |  |  |  | 2,623 |  |  |  |
| Costs of products sales | 392 |  |  | 46.2 | % |  | 361 |  |  | 45.1 | % | 739 |  |  | 47.6 | % |  | 726 |  |  | 48.3 | % |
| Costs of services sales | 415 |  |  | 63.9 | % |  | 393 |  |  | 62.5 | % | 778 |  |  | 63.5 | % |  | 718 |  |  | 64.1 | % |
| Costs of sales | 807 |  |  |  |  | 754 |  |  |  | 1,517 |  |  |  |  | 1,444 |  |  |  |
| Gross margin | 690 |  |  | 46.1 | % |  | 676 |  |  | 47.3 | % | 1,260 |  |  | 45.4 | % |  | 1,179 |  |  | 44.9 | % |
| Selling, general and administrative expenses | 242 |  |  | 16.2 | % |  | 240 |  |  | 16.8 | % | 475 |  |  | 17.1 | % |  | 475 |  |  | 18.1 | % |
| Research and development expenditures | 138 |  |  | 9.2 | % |  | 138 |  |  | 9.7 | % | 273 |  |  | 9.8 | % |  | 274 |  |  | 10.4 | % |
| Other charges | 53 |  |  | 3.5 | % |  | 74 |  |  | 5.2 | % | 79 |  |  | 2.8 | % |  | 107 |  |  | 4.1 | % |
| Operating earnings | 257 |  |  | 17.2 | % |  | 224 |  |  | 15.7 | % | 433 |  |  | 15.6 | % |  | 323 |  |  | 12.3 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (51 | ) |  | (3.4 | )% |  | (54 | ) |  | (3.8 | )% | (102 | ) |  | (3.7 | )% |  | (103 | ) |  | (3.9 | )% |
| Gains (losses) on sales of investments and businesses, net | (1 | ) |  | (0.1 | )% |  | 1 |  |  | 0.1 | % | 2 |  |  | 0.1 | % |  | (20 | ) |  | (0.8 | )% |
| Other | — |  |  | — | % |  | (4 | ) |  | (0.3 | )% | (9 | ) |  | (0.3 | )% |  | (11 | ) |  | (0.4 | )% |
| Total other expense | (52 | ) |  | (3.5 | )% |  | (57 | ) |  | (4.0 | )% | (109 | ) |  | (3.9 | )% |  | (134 | ) |  | (5.1 | )% |
| Earnings before income taxes | 205 |  |  | 13.7 | % |  | 167 |  |  | 11.7 | % | 324 |  |  | 11.7 | % |  | 189 |  |  | 7.2 | % |
| Income tax expense | 73 |  |  | 4.9 | % |  | 59 |  |  | 4.1 | % | 114 |  |  | 4.1 | % |  | 64 |  |  | 2.4 | % |
| Net earnings | 132 |  |  | 8.8 | % |  | 108 |  |  | 7.6 | % | 210 |  |  | 7.6 | % |  | 125 |  |  | 4.8 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % | 2 |  |  | 0.1 | % |  | 1 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 131 |  |  | 8.8 | % |  | $ | 107 |  |  | 7.5 | % | $ | 208 |  |  | 7.5 | % |  | $ | 124 |  |  | 4.7 | % |
| Earnings per diluted common share | $ | 0.78 |  |  |  |  |  | $ | 0.61 |  |  |  |  | $ | 1.23 |  |  |  |  | $ | 0.71 |  |  |  |

[0000068505-17-000011:mdna:28]
[same as prior period, unchanged from 0000068505-17-000005:mdna:32]

[0000068505-17-000011:mdna:29]
26

[0000068505-17-000011:mdna:30]
Results of Operations—Three months ended July 1, 2017 compared to three months ended July 2, 2016

[0000068505-17-000011:mdna:31]
The results of operations for the second quarter of 2017 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-17-000011:mdna:32]
[same as prior period, unchanged from 0000068505-17-000005:mdna:36]

[0000068505-17-000011:mdna:33]
Net sales were $1.5 billion in the second quarter of 2017, a $67 million, or 5%, increase compared to the second quarter of 2016, reflecting solid demand across the globe for our core products and services. The increase in net sales is reflective of growth in the Americas and AP, partially offset by a decrease in EMEA. Systems and Devices sales within the Products segment both increased in each region. The Services segment increased in the Americas, partially offset by decreases in EMEA and AP. The Services segment net sales increase in the Americas was driven by the acquisition of Interexport and Spillman Technologies, Inc. and core growth in both Managed & Support services and Integration services. The Services segment net sales decrease in EMEA was due to a decrease in Airwave related to unfavorable foreign exchange rates in the second quarter of 2017, partially offset by core growth in Integration services. The Services segment net sales decrease in AP was due to lower Integration sales.

[0000068505-17-000011:mdna:34]
[same as prior period, unchanged from 0000068505-17-000005:mdna:38]

[0000068505-17-000011:mdna:35]
Gross margin was $690 million, or 46.1% of net sales, in the second quarter of 2017, compared to $676 million, or 47.3% of net sales, in the second quarter of 2016. The decrease in gross margin percentage was driven by a decrease in margins within both the Products and Services segments.  The decrease in gross margin percentage in the Products segment was driven by product mix primarily in North America, with higher Systems sales in the quarter which have lower gross margins than Devices. The decrease in gross margin percentage in the Services segment was driven by Airwave due to unfavorable foreign exchange rates in the second quarter of 2017.

[0000068505-17-000011:mdna:36]
[same as prior period, unchanged from 0000068505-17-000005:mdna:40]

[0000068505-17-000011:mdna:37]
SG&A expenses increased 1% to $242 million, or 16.2% of net sales, in the second quarter of 2017, compared to $240 million, or 16.8% of net sales, in the second quarter of 2016. The increase in SG&A expenditures is primarily due to increased expenses associated with acquisitions.

[0000068505-17-000011:mdna:38]
[same as prior period, unchanged from 0000068505-17-000005:mdna:42]

[0000068505-17-000011:mdna:39]
R&D expenditures were $138 million, or 9.2% of net sales, in the second quarter of 2017 and $138 million, or 9.7% of net sales, in the second quarter of 2016. R&D expenditures have remained flat, or decreased as a percentage of sales, due to ongoing leverage of employees located in lower cost areas, combined with growth in net sales.

[0000068505-17-000011:mdna:40]
[same as prior period, unchanged from 0000068505-17-000005:mdna:44]

[0000068505-17-000011:mdna:41]
We recorded net charges of $53 million in the second quarter of 2017, compared to net charges of $74 million in the second quarter of 2016. The net Other charges in the second quarter of 2017 included: (i) $37 million of charges relating to the amortization of intangibles, (ii) $16 million of charges relating to the Non-U.S. pension settlement loss, and (iii) $1 million of net reorganization of business charges, partially offset by a $1 million gain on a legal settlement. The net charges in the second quarter of 2016 of $74 million included: (i) $38 million of charges relating to the amortization of intangibles, and (ii) $36 million of net reorganization of business charges, including a $17 million building impairment. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-17-000011:mdna:42]
[same as prior period, unchanged from 0000068505-17-000005:mdna:47]

[0000068505-17-000011:mdna:43]
Net interest expense was $51 million in the second quarter of 2017 and $54 million in the second quarter of 2016. The decrease in net interest expense in the second quarter of 2017 as compared to the second quarter of 2016 was a result of lower outstanding debt, due to the repayment of $675 million of a term loan at the end of 2016.

[0000068505-17-000011:mdna:44]
[same as prior period, unchanged from 0000068505-17-000005:mdna:49]

[0000068505-17-000011:mdna:45]
Net loss on sales of investments and businesses was $1 million in the second quarter of 2017 compared to a gain of $1 million in the second quarter of 2016. The net loss in the second quarter of 2017 was related to the sale of a business. The net gains in the second quarter of 2016 were related to sales of equity investments.

[0000068505-17-000011:mdna:46]
[same as prior period, unchanged from 0000068505-17-000005:mdna:51]

[0000068505-17-000011:mdna:47]
Net Other expense was de minimus in the second quarter of 2017, compared to $4 million in the second quarter of 2016. The net other expense in the second quarter of 2017 was comprised of: a $20 million foreign currency loss, offset by: (i) a $18 million gain on derivative instruments, (ii) a $1 million gain on equity method investments, and (iii) $1 million of other non-operating income. The net Other expense in the second quarter of 2016 was comprised of an $18 million loss on derivative instruments offset by a $14 million foreign currency gain.

[0000068505-17-000011:mdna:48]
[same as prior period, unchanged from 0000068505-17-000005:mdna:53]

[0000068505-17-000011:mdna:49]
We recorded $73 million of net tax expense in the second quarter of 2017, resulting in an effective tax rate of 36%, compared to $59 million of net tax expense in the second quarter of 2016, resulting in an effective tax rate of 35%. Our effective tax rate in the second quarter of 2017 was greater than the U.S. statutory tax rate of 35% partly due to change of estimates between provision and the filing of tax returns in foreign jurisdictions. Our effective tax rate in the second quarter of 2016 was equal to the U.S. statutory tax rate of 35%.

[0000068505-17-000011:mdna:50]
[same as prior period, unchanged from 0000068505-17-000005:mdna:55]

[0000068505-17-000011:mdna:51]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $131 million, or $0.78 per diluted share, in the second quarter of 2017, compared to net earnings attributable to Motorola Solutions, Inc. of $107 million, or $0.61 per diluted share, in the second quarter of 2016.

[0000068505-17-000011:mdna:52]
The increase in net earnings in the second quarter of 2017, as compared to the second quarter of 2016, was primarily driven by an increase in sales in both the Products and Services segments and lower Other charges. The increase in net earnings per diluted share was driven by an increase in net earnings and lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-17-000011:mdna:53]
Results of Operations—Six months ended July 1, 2017 compared to six months ended July 2, 2016

[0000068505-17-000011:mdna:54]
Net Sales

[0000068505-17-000011:mdna:55]
Net sales were $2.8 billion in the first half of 2017, a $154 million, or 6%, increase compared to the first half of 2016. The increase in net sales is reflective of growth in every region. Within the Products segment, Devices net sales increased in each region while Systems net sales increased in the Americas and EMEA. The Services segment increased in the Americas and EMEA, partially offset by a decrease in AP. The Services segment net sales increase in the Americas was driven by the acquisition of Interexport and Spillman Technologies, Inc. and core growth in both Managed & Support services and Integration services. The Services segment net sales increase in EMEA was driven by Airwave and core growth in Integration services. The Services segment net sales decrease in AP was due to lower Integration sales.

[0000068505-17-000011:mdna:56]
Gross Margin

[0000068505-17-000011:mdna:57]
Gross margin was $1.3 billion, or 45.4% of net sales, in the first half of 2017, compared to $1.2 billion, or 44.9% of net sales, in the first half of 2016. The increase in gross margin percentage was driven by an increase in margins within both the Products and Services segments.  The increase in gross margin percentage in the Products segment was driven by a favorable mix. The increase in gross margin percentage in the Services segment was driven by the expansion of our Managed & Support services portfolio, primarily due to the acquisition of Airwave, which historically has had higher margins than our legacy portfolio.

[0000068505-17-000011:mdna:58]
Selling, General and Administrative Expenses

[0000068505-17-000011:mdna:59]
SG&A expenses were $475 million, or 17.1% of net sales, in the first half of 2017, compared to $475 million, or 18.1% of net sales, in the first half of 2016. SG&A expenditures were flat, or decreased as percentage of sales, due to higher sales, offset by increased expenses associated with acquisitions.

[0000068505-17-000011:mdna:60]
Research and Development Expenditures

[0000068505-17-000011:mdna:61]
R&D expenditures were $273 million, or 9.8% of net sales, in the first half of 2017 and $274 million, or 10.4% of net sales, in the first half of 2016. R&D expenditures decreased as a percentage of sales, due to ongoing leverage of employees located in lower cost areas, combined with growth in net sales.

[0000068505-17-000011:mdna:62]
Other Charges

[0000068505-17-000011:mdna:63]
We recorded net charges of $79 million in the first half of 2017, compared to net charges of $107 million in the first half of 2016. The net Other charges in the first half of 2017 included: (i) $73 million of charges relating to the amortization of intangibles, (ii) $25 million of charges relating to the Non-U.S. pension settlement loss, (iii)  $16 million of net reorganization of business charges, (iv) $8 million of charges related a building impairment, and (v) $1 million of transaction fees on the acquisition of Interexport, partially offset by a net gain of $44 million, related to legal settlements, including the $42 million legal settlement related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to us by a former customer of our legacy Networks business. The net charges in the first half of 2016 of $107 million included: (i) $52 million of charges relating to the amortization of intangibles, (ii) $42 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment of the corporate aircraft, and (iii) $13 million of transaction fees on the acquisition of Airwave. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-17-000011:mdna:64]
Net Interest Expense

[0000068505-17-000011:mdna:65]
Net interest expense was $102 million in the first half of 2017 and $103 million in the first half of 2016. The decrease in net interest expense in the first half of 2017 as compared to the first half of 2016 was a result of lower outstanding debt, due to the repayment of $675 million of a term loan at the end of 2016.

[0000068505-17-000011:mdna:66]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-17-000011:mdna:67]
Net gains on sales of investments and businesses were $2 million in the first half of 2017 compared to net losses of $20 million in the first half of 2016. The net gains in the first half of 2017 were primarily related to the sales of various equity investments. The net losses in the first half of 2016 consisted of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities, (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $6 million of gains on the sale of an equity investment.

[0000068505-17-000011:mdna:68]
Other

[0000068505-17-000011:mdna:69]
Net Other expense was $9 million in the first half of 2017, compared to $11 million in the first half of 2016. The net Other expense in the first half of 2017 was comprised of a $22 million foreign currency loss offset by a $11 million gain on derivative investments and $2 million of other non-operating income. The net Other expense in the first half of 2016 was comprised of: (i) a $30 million loss on derivative instruments, (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave, partially offset by: (i) a $27 million foreign currency gain and (ii) a $2 million gain on equity method investments.

[0000068505-17-000011:mdna:70]
Effective Tax Rate

[0000068505-17-000011:mdna:71]
We recorded $114 million of net tax expense in the first half of 2017, resulting in an effective tax rate of 35%, compared to $64 million of net tax expense in the first half of 2016, resulting in an effective tax rate of 34%. Our effective tax rate in the first half of 2017 was equal to the U.S. statutory tax rate of 35%. Our effective tax rate in the first half of 2016 was lower than the U.S. statutory tax rate of 35% primarily due to the recognition of excess tax benefits on share-based compensation.

[0000068505-17-000011:mdna:72]
Net Earnings Attributable to Motorola Solutions, Inc.

[0000068505-17-000011:mdna:73]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $208 million, or $1.23 per diluted share, in the first half of 2017, compared to net earnings attributable to Motorola Solutions, Inc. of $124 million, or $0.71 per diluted share, in the first half of 2016.

[0000068505-17-000011:mdna:74]
The increase in net earnings in the first half of 2017, as compared to the first half of 2016, was primarily driven by an increase in sales in both the Products and Services segments and lower Other charges. The increase in net earnings per diluted share was driven by an increase in net earnings and lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-17-000011:mdna:75]
[same as prior period, unchanged from 0000068505-17-000005:mdna:58]

[0000068505-17-000011:mdna:76]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and six months ended July 1, 2017 and July 2, 2016, as detailed in Note 11, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-17-000011:mdna:77]
[same as prior period, unchanged from 0000068505-17-000005:mdna:60]

[0000068505-17-000011:mdna:78]
For the second quarter of 2017, the segment’s net sales represented 57% of our consolidated net sales, compared to 56% of our consolidated net sales for the second quarter of 2016. For the first half of 2017, the segment’s net sales represented 56% of our consolidated net sales, compared to 57% of our consolidated net sales for the first half of 2016.

[0000068505-17-000011:mdna:79]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 1, 2017 |  | July 2, 2016 |  | % Change |  | July 1, 2017 |  | July 2, 2016 |  | % Change |
| Segment net sales | $ | 848 |  |  | $ | 801 |  |  | 6 | % |  | $ | 1,551 |  |  | $ | 1,503 |  |  | 3 | % |
| Operating earnings | 168 |  |  | 129 |  |  | 30 | % |  | 257 |  |  | 179 |  |  | 44 | % |

[0000068505-17-000011:mdna:80]
Three months ended July 1, 2017 compared to three months ended July 2, 2016

[0000068505-17-000011:mdna:81]
The segment’s net sales increased $47 million, to $848 million in the second quarter of 2017, as compared to $801 million during the second quarter of 2016. The increase in the segment's net sales was driven by an increase in both Systems and Devices sales in all regions.

[0000068505-17-000011:mdna:82]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 73% of the segment’s net sales in the second quarter of 2017 and 74% in the second quarter of 2016.

[0000068505-17-000011:mdna:83]
The segment had operating earnings of $168 million in the second quarter of 2017, compared to $129 million in the second quarter of 2016. The increase in operating earnings was primarily driven by: (i) higher sales, (ii) lower R&D expenditures, and (iii) lower Other charges.

[0000068505-17-000011:mdna:84]
Six months ended July 1, 2017 compared to six months ended July 2, 2016

[0000068505-17-000011:mdna:85]
The segment’s net sales increased $48 million, to $1.6 billion in the first half of 2017, as compared to $1.5 billion during the first half of 2016. The increase in the segment's net sales was primarily driven by an increase in Devices sales in all regions. On a geographic basis, net sales increased in all regions for the first half of 2017, compared to the first half of 2016.

[0000068505-17-000011:mdna:86]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in the first half of 2017 and 75% in the first half of 2016.

[0000068505-17-000011:mdna:87]
The segment had operating earnings of $257 million in the first half of 2017, compared to $179 million in the first half of 2016. The increase in operating earnings was primarily driven by: (i) higher gross margin due to product mix, (ii) lower SG&A and R&D expenditures, and (iii) lower Other charges.

[0000068505-17-000011:mdna:88]
[same as prior period, unchanged from 0000068505-17-000005:mdna:67]

[0000068505-17-000011:mdna:89]
For the second quarter of 2017, the segment’s net sales represented 43% of our consolidated net sales, compared to 44% of our consolidated net sales for the second quarter of 2016. For the first half of 2017, the segment’s net sales represented 44% of our consolidated net sales, compared to 43% of our consolidated net sales for the first half of 2016.

[0000068505-17-000011:mdna:90]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 1, 2017 |  | July 2, 2016 |  | % Change |  | July 1, 2017 |  | July 2, 2016 |  | % Change |
| Segment net sales | $ | 649 |  |  | $ | 629 |  |  | 3 | % |  | $ | 1,226 |  |  | $ | 1,120 |  |  | 9 | % |
| Operating earnings | 89 |  |  | 95 |  |  | (6 | )% |  | 176 |  |  | 144 |  |  | 22 | % |

[0000068505-17-000011:mdna:91]
Three months ended July 1, 2017 compared to three months ended July 2, 2016

[0000068505-17-000011:mdna:92]
The segment’s net sales increased $20 million, or 3%, to $649 million in the second quarter of 2017, as compared to $629 million in the second quarter of 2016. The increase in the segment's net sales was driven by the Interexport and Spillman Technologies, Inc. acquisitions as well as core growth in Managed & Support services and Integration services. The acquisition of Interexport and Spillman Technologies, Inc. provided increases within the Americas, compared to the first quarter of 2016, while the core Managed & Support services business grew in the Americas and the core Integration services grew in both the Americas and EMEA. On a geographic basis, net sales for the second quarter of 2017 increased in the Americas and decreased in EMEA and AP, compared to the second quarter of 2016. The decrease in EMEA was due to a decrease in Airwave related to unfavorable foreign exchange rates during the quarter. The decrease in AP was due to lower sales in Integration services.

[0000068505-17-000011:mdna:93]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the second quarter of 2017, compared to 54% of the segment’s net sales in the second quarter of 2016.

[0000068505-17-000011:mdna:94]
The segment had operating earnings of $89 million in the second quarter of 2017, compared to $95 million in the second quarter of 2016. The decrease in operating earnings in the second quarter of 2017 compared to the second quarter of 2016 was primarily driven by lower gross margin associated with unfavorable exchange rates related to Airwave and higher SG&A and R&D expenditures, partially offset by a decrease in Other charges.

[0000068505-17-000011:mdna:95]
Six months ended July 1, 2017 compared to six months ended July 2, 2016

[0000068505-17-000011:mdna:96]
The segment’s net sales increased $106 million, or 9%, to $1.2 billion in the first half of 2017, as compared to $1.1 billion in the first half of 2016. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from the Airwave, Interexport, and Spillman Technologies, Inc. acquisitions, as well as core growth. The acquisition of Airwave provided an increase of net sales within EMEA, compared to the first half of 2016, while the acquisitions of Interexport and Spillman Technologies, Inc. and the core Managed & Support services business increased in the Americas. On a geographic basis, net sales for the first half of 2017 increased in the Americas and EMEA and decreased in AP, compared to the first half of 2016.

[0000068505-17-000011:mdna:97]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in both the first half of 2017 and 2016.

[0000068505-17-000011:mdna:98]
The segment had operating earnings of $176 million in the first half of 2017, compared to $144 million in the first half of 2016. The increase in operating earnings in the first half of 2017 compared to the first half of 2016 was primarily driven by higher gross margin, partially offset by an increase in SG&A and R&D expenditures.

[0000068505-17-000011:mdna:99]
[same as prior period, unchanged from 0000068505-17-000005:mdna:74]

[0000068505-17-000011:mdna:100]
During the second quarter of 2017, we recorded net reorganization of business charges of $3 million including $1 million of charges recorded within Other charges and $2 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $3 million were charges of $8 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000011:mdna:101]
During the first half of 2017, we recorded net reorganization of business charges of $22 million including $16 million of charges recorded within Other charges and $6 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $22 million were charges of $23 million related to employee separation costs and $4 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000011:mdna:102]
30

[0000068505-17-000011:mdna:103]
During the second quarter of 2016, we recorded net reorganization of business charges of $44 million including $36 million of charges recorded within Other charges and $8 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $44 million were charges of: (i) $22 million related to employee separation costs, (ii) a $17 million charge related to a building impairment, and (iii) $5 million for exit costs.

[0000068505-17-000011:mdna:104]
During the first half of 2016, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first half of 2016, we recorded net reorganization of business charges of $67 million including charges of $42 million recorded in Other charges and $25 million in Cost of sales in our condensed consolidated statements of operations. Included in the $67 million were charges of: (i) $46 million related to employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of corporate aircraft, and (iii) $5 million for exit costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-17-000011:mdna:105]
[same as prior period, unchanged from 0000068505-17-000005:mdna:77]

[0000068505-17-000011:mdna:106]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Products | $ | 3 |  |  | $ | 33 |  |  | $ | 16 |  |  | $ | 54 |  |
| Services | — |  |  | 11 |  |  | 6 |  |  | 13 |  |
|  | $ | 3 |  |  | $ | 44 |  |  | $ | 22 |  |  | $ | 67 |  |

[0000068505-17-000011:mdna:107]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $56 million in the first half of 2017 and $42 million in the first half of 2016. The reorganization of business accruals at July 1, 2017 were $68 million, of which $58 million relate to employee separation costs that are expected to be paid within one year and $10 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-17-000011:mdna:108]
[same as prior period, unchanged from 0000068505-17-000005:mdna:80]

[0000068505-17-000011:mdna:109]
We decreased the aggregate of our cash and cash equivalent balances by $225 million from $1.0 billion as of December 31, 2016 to $805 million as of July 1, 2017. The decrease is primarily due to: (i) $412 million of capital returned to shareholders through share repurchases and dividends paid and (ii) $189 million used for investing activities, offset by $315 million of cash generated by operating activities.

[0000068505-17-000011:mdna:110]
[same as prior period, unchanged from 0000068505-17-000005:mdna:82]

[0000068505-17-000011:mdna:111]
[same as prior period, unchanged from 0000068505-17-000005:mdna:83]

[0000068505-17-000011:mdna:112]
At July 1, 2017, $368 million of the $805 million cash and cash equivalents balance was held in the U.S. and approximately $437 million was held by us or our subsidiaries in other countries, with approximately $142 million held in the United Kingdom. Restricted cash was $63 million at both July 1, 2017 and December 31, 2016.

[0000068505-17-000011:mdna:113]
[same as prior period, unchanged from 0000068505-17-000005:mdna:85]

[0000068505-17-000011:mdna:114]
Net cash provided by operating activities in the first half of 2017 was $315 million, as compared to $304 million in the first half of 2016. Operating cash flows in the first half of 2017, as compared to the first half of 2016, were positively impacted by higher earnings, offset by a temporary increase in working capital as a result of managing our Enterprise Resource Planning ("ERP") system implementation.

[0000068505-17-000011:mdna:115]
[same as prior period, unchanged from 0000068505-17-000005:mdna:88]

[0000068505-17-000011:mdna:116]
Net cash used by investing activities was $189 million in the first half of 2017, compared to $664 million in the first half of 2016. The $189 million cash used in the first half of 2017 included: (i) $140 million cash used for acquisitions and investments, including the acquisition of Interexport for $55 million, net of cash acquired and (ii) $121 million in capital expenditures, partially offset by $72 million of proceeds from sales of investments and businesses. The cash usage of $664 million in the first half of 2016 consisted primarily of: (i) $1.1 billion cash used for acquisitions and investments, including $1.0 billion paid for the acquisition of Airwave, and (ii) $143 million in capital expenditures, partially offset by $553 million of proceeds from the sale of investments and businesses and $46 million of proceeds from the sale of property, plant and equipment.

[0000068505-17-000011:mdna:117]
Acquisition and Investments:  We used net cash for acquisitions and investments of $140 million during the first half of 2017 compared to $1.1 billion in the first half of 2016. The cash used during the first half of 2017 was used for several debt and equity investments, and the acquisition of Interexport for $55 million, net of cash acquired. The cash used during the first half of 2016 consisted primarily of $1.0 billion related to the acquisition of Airwave. The remainder of the cash was used for several debt and equity investments.

[0000068505-17-000011:mdna:118]
Sales of Investments and Businesses:  We received $72 million of proceeds related to the sales of investments and businesses in the first half of 2017 compared to $553 million in the first half of 2016. The proceeds in the first half of 2017 primarily consisted of the sales of various debt and equity investments. The proceeds in the first half of 2016 were comprised of: (i) $382 million from the sale of United Kingdom treasury securities used to finance the acquisition of Airwave, (ii) $125 million from the sales of various debt and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations.

[0000068505-17-000011:mdna:119]
Capital Expenditures:  Capital expenditures decreased in the first half of 2017 to $121 million, compared to $143 million in the first half of 2016. The decrease in capital expenditures was primarily related to lower facilities spend and lower revenue-generating network expenditures, partially offset by an increase in information technology spend.

[0000068505-17-000011:mdna:120]
Sales of Property, Plant, and Equipment:  We had $46 million of proceeds related to the sale of property, plant, and equipment in the first half of 2016. The proceeds in the first half of 2016 were comprised of $27 million from the sale of buildings and land on our Schaumburg, IL campus and $19 million received from the sale of corporate aircraft.

[0000068505-17-000011:mdna:121]
[same as prior period, unchanged from 0000068505-17-000005:mdna:93]

[0000068505-17-000011:mdna:122]
Net cash used for financing activities was $385 million in the first half of 2017, compared to $51 million used in the first half of 2016. Cash used for financing activities in the first half of 2017 was primarily comprised of: (i) $258 million used for purchases of our common stock under our share repurchase program and (ii) $154 million of cash used for the payment of dividends, partially offset by $28 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first half of 2016 was primarily comprised of: (i) $619 million used for purchases of our common stock under our share repurchase program and (ii)  $143 million of cash used for the payment of dividends, partially offset by: (i) $673 million of net proceeds from the issuance of a term loan and (ii) $40 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-17-000011:mdna:123]
Long-Term Debt:  We had outstanding long-term debt of $4.5 billion and $4.4 billion, including the current portions of $46 million and $4 million at July 1, 2017 and December 31, 2016, respectively. In the acquisition of Interexport, we assumed $92 million of debt, including a current portion of $40 million, primarily related to capital leases.

[0000068505-17-000011:mdna:124]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances including, for example, if the volume weighted average price of our stock exceeds $85 for ten consecutive trading days, then up to 20% of the notes may be transferred, and then subsequently converted to shares of our stock by such transferee. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). During the three months ended July 1, 2017, the volume weighted average price of our stock exceeded $85 for ten consecutive trading days, making 20% of Senior Convertible Notes convertible. In the event of conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-17-000011:mdna:125]
[same as prior period, unchanged from 0000068505-17-000005:mdna:96]

[0000068505-17-000011:mdna:126]
Share Repurchase Program: During the six months ended July 1, 2017, we paid an aggregate of $258 million, including transaction costs, to repurchase approximately 3.2 million shares at an average price of $81.66 per share. As of July 1, 2017, the Company had used approximately $12.1 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.9 billion of authority available for future repurchases.

[0000068505-17-000011:mdna:127]
Payment of Dividends: During the second quarter of 2017, we paid $77 million in cash dividends to holders of our common stock. During the first half of 2017, we paid $154 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $76 million in cash dividends to holders of our common stock.

[0000068505-17-000011:mdna:128]
[same as prior period, unchanged from 0000068505-17-000005:mdna:99]

[0000068505-17-000011:mdna:129]
As of July 1, 2017, we had a $2.2 billion unsecured syndicated revolving credit facility, which includes a $500 million letter of credit sub-limit with $450 million of fronting commitments, (the “2017 Motorola Solutions Credit Agreement”) scheduled to mature on April 25, 2022. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of July 1, 2017. We did not borrow or issue any letters of credit under the 2017 Motorola Solutions Credit Agreement during the first half of 2017.

[0000068505-17-000011:mdna:130]
[same as prior period, unchanged from 0000068505-17-000005:mdna:102]

[0000068505-17-000011:mdna:131]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $209 million at July 1, 2017, compared to $125 million at December 31, 2016.  During the six months ended July 1, 2017, we agreed to provide long-term financing to one customer in the amount of $75 million.

[0000068505-17-000011:mdna:132]
Outstanding Long-Term Receivables:  We had non-current long-term receivables of $35 million at July 1, 2017, compared to $49 million at December 31, 2016.

[0000068505-17-000011:mdna:133]
[same as prior period, unchanged from 0000068505-17-000005:mdna:105]

[0000068505-17-000011:mdna:134]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended July 1, 2017 and July 2, 2016:

[0000068505-17-000011:mdna:135]
|  | Three Months Ended |  | Six Months Ended |
|  | July 1, 2017 |  | July 2, 2016 |  | July 1, 2017 |  | July 2, 2016 |
| Accounts receivable sales proceeds | $ | 61 |  |  | $ | 5 |  |  | $ | 80 |  |  | $ | 7 |  |
| Long-term receivables sales proceeds | 22 |  |  | 70 |  |  | 68 |  |  | 134 |  |
| Total proceeds from sales of accounts receivable | $ | 83 |  |  | $ | 75 |  |  | $ | 148 |  |  | $ | 141 |  |

[0000068505-17-000011:mdna:136]
At July 1, 2017, the Company had retained servicing obligations for $775 million of long-term receivables, compared to $774 million at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000011:mdna:137]
Other Contingencies

[0000068505-17-000011:mdna:138]
[same as prior period, unchanged from 0000068505-17-000005:mdna:110]

[0000068505-17-000011:mdna:139]
[same as prior period, unchanged from 0000068505-17-000005:mdna:111]

[0000068505-17-000011:mdna:140]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at July 1, 2017.

[0000068505-17-000011:mdna:141]
[same as prior period, unchanged from 0000068505-17-000005:mdna:113]

[0000068505-17-000011:mdna:142]
[same as prior period, unchanged from 0000068505-17-000005:mdna:114]

[0000068505-17-000011:mdna:143]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as our annual reporting period begins after December 15, 2017.

[0000068505-17-000011:mdna:144]
We continue to analyze the impact of the new standard on our financial results based on an inventory of our current contracts with customers. We have obtained an understanding of the new standard and currently believe that we will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of our contracts is currently recognized under percentage of completion accounting, applying a cost-to-cost method.

[0000068505-17-000011:mdna:145]
Under the new standard, we must identify the distinct promises to transfer goods and/or services within our contracts using certain factors. For contracts that are currently recognized under percentage of completion accounting, we have considered the factors used to determine whether promises made in the contract are distinct and determined that devices represent distinct goods. Accordingly, adoption of the new standard will impact our percentage of completion contracts that include devices, with the resulting impact being revenue recognized earlier as control of the devices transfers to the customer at a point in time rather

[0000068505-17-000011:mdna:146]
33

[0000068505-17-000011:mdna:147]
than over time. For the remaining promised goods and services within our percentage of completion contracts, we will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in our contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000011:mdna:148]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While we may have contracts which fall under these rules in the current standard, we have not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, we do not anticipate a significant acceleration of revenue upon applying the new standard to our current contracts under these fact patterns.

[0000068505-17-000011:mdna:149]
We continue to evaluate the impact of ASU No. 2014-09 on our financial results and prepare for the adoption of the standard on January 1, 2018, including readying our internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. We expect to adopt this standard under the modified retrospective method of adoption, which recognizes the cumulative effect of transition as an adjustment to retained earnings for contracts that are not completed as of the adoption date, without restating prior period financial statements.

[0000068505-17-000011:mdna:150]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for our January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000011:mdna:151]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for us January 1, 2018 with early adoption permitted. We intend to adopt this ASU January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, we do not anticipate significant changes to our existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000011:mdna:152]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption permitted. We intend to adopt the ASU January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. We are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000011:mdna:153]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in the total cash, cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for us January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires the retrospective application. We do not anticipate significant changes to our financial statements and related disclosures from adoption of the ASU.

[0000068505-17-000011:mdna:154]
In March 2017, the FASB issued ASU 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. We intend to adopt this ASU on January 1, 2018. Upon adoption, we plan to update the presentation of net periodic cost (benefit) accordingly, noting all components of our net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of $37 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.
