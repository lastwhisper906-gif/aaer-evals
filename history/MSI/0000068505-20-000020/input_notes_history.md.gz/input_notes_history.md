# MSI note change history — 0000068505-20-000013 → 0000068505-20-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-08-07):
[0000068505-20-000020:note_history:1]
Commitments and Contingencies
Legal Matters

- changed (2020-08-07):
[0000068505-20-000020:note_history:2]
As previously disclosed, on February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in it's trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million.  A motion for a new trial was filed by Hytera during the second quarter of 2020. In addition, during the second quarter of 2020 Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection; subsequent to the end of the second quarter, the Company filed motions to dismiss the bankruptcy proceedings.
  (was, 2020-05-08, similarity 0.7617):
[0000068505-20-000013:note_history:2]
Commitments and ContingenciesLegal MattersOn February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in it's trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million.  A motion for a new trial was filed by Hytera subsequent to the quarter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0000068505-20-000020:note_history:3]
Basis of Presentation
The condensed consolidated financial statements as of June 27, 2020 and for the three and six months ended June 27, 2020 and June 29, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2020-05-08, similarity 0.9463):
[0000068505-20-000013:note_history:3]
Basis of Presentation
The condensed consolidated financial statements as of March 28, 2020 and for the three months ended March 28, 2020 and March 30, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2020-08-07):
[0000068505-20-000020:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three and six months ended June 27, 2020 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2020-05-08, similarity 0.811):
[0000068505-20-000013:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three months ended March 28, 2020 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2020-08-07):
[0000068505-20-000020:note_history:5]
Recent Acquisitions
  (was, 2020-05-08, similarity 0.6909):
[0000068505-20-000013:note_history:5]
Recent Acquisitions and Developments

- added (2020-08-07):
[0000068505-20-000020:note_history:6]
On July 31, 2020, the Company acquired Pelco, Inc., a global provider of video security solutions for $110 million in cash. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, adding to its existing video portfolio a broad range of products that can be used in a variety of commercial and industrial environments and use cases.  The business will be part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2020-08-07):
[0000068505-20-000020:note_history:7]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The business is a part of both the Product and Systems Integration segment and the Software and Services segment.

- added (2020-08-07):
[0000068505-20-000020:note_history:8]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired.  The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

- changed (2020-08-07):
[0000068505-20-000020:note_history:9]
In December 2019, the FASB issued Accounting Standard Update ("ASU") No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company is still evaluating the impact of adoption on its disclosures.
  (was, 2020-05-08, similarity 0.6086):
[0000068505-20-000013:note_history:9]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes.  The ASU is effective

- changed (2020-08-07):
[0000068505-20-000020:note_history:10]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.
  (was, 2020-05-08, similarity 0.9996):
[0000068505-20-000013:note_history:10]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11," Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.

- changed (2020-08-07):
[0000068505-20-000020:note_history:11]
The Company considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets, and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (Direct and Indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact to the Company's financial statements.
  (was, 2020-05-08, similarity 0.9996):
[0000068505-20-000013:note_history:11]
The Company considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (Direct and Indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact to the Company's financial statements.

- changed (2020-08-07):
[0000068505-20-000020:note_history:12]
|  | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at June 27, 2020 |
| Allowance for credit losses | $ | 63 |  | $ | 24 |  | $ | (8) |  | $ | (2) |  | $ | 77 |  |
  (was, 2020-05-08, similarity 0.8209):
[0000068505-20-000013:note_history:12]
| Allowance for Credit Losses | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at March 28, 2020 |
| 2020 | $ | 63 |  | $ | 11 |  | $ | (5) |  | $ | (2) |  | $ | 67 |  |

- removed (2020-08-07):
[0000068505-20-000013:note_history:13]
On March 17, 2020, the Company announced the proposed acquisition of IndigoVision Group plc ("IndigoVision") for a purchase price of approximately $37 million in cash. The proposed acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The proposed acquisition is subject to customary closing conditions for a UK public transaction and is expected to close in the second quarter of 2020.

- removed (2020-08-07):
[0000068505-20-000013:note_history:14]
Change in presentation

- removed (2020-08-07):
[0000068505-20-000013:note_history:15]
During the first quarter of 2020, the Company restructured its operations to realize more operational efficiencies, combining EMEA, AP and LA into one region which is now reflected as "International."  Accordingly, the Company now reports net sales in the following two geographic regions: North America, which includes the United States and Canada, and International. The Company has updated all periods presented to reflect this change in presentation.

- removed (2020-08-07):
[0000068505-20-000013:note_history:16]
for the Company on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  The Company is still evaluating the impact of adoption on its financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-08-07):
[0000068505-20-000020:note_history:17]
Debt and Credit Facilities
As of June 27, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020, of which $300 million was repaid during the three months ended June 27, 2020. As of June 27, 2020, the outstanding loan amount was $500 million.  Subsequent to the quarter, the company repaid an additional $200 million. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 27, 2020 were 1.69% and 1.79%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 27, 2020.

- changed (2020-08-07):
[0000068505-20-000020:note_history:18]
As of June 27, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140, as may be adjusted for dividends declared, per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
The Company has an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 27, 2020 the Company had no outstanding debt under the commercial paper program.
  (was, 2020-05-08, similarity 0.9681):
[0000068505-20-000013:note_history:18]
As of March 28, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
The Company has an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 28, 2020 the Company had no outstanding debt under the commercial paper program.

- removed (2020-08-07):
[0000068505-20-000013:note_history:19]
Debt and Credit Facilities

- removed (2020-08-07):
[0000068505-20-000013:note_history:20]
|  | March 28, 2020 |  | December 31, 2019 |
| $2.2 billion revolving credit facility due April 2022 | $ | 800 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | 550 |  |  | 550 |  |
| 3.5% senior notes due 2023 | 597 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 593 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 990 |  |  | 988 |  |
| 6.5% debentures due 2025 | 72 |  |  | 72 |  |
| 7.5% debentures due 2025 | 254 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 28 |  |  | 35 |  |
|  | 5,928 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3) |  |  | (3) |  |
| Less: current portion | (814) |  |  | (16) |  |
| Long-term debt | $ | 5,111 |  |  | $ | 5,113 |  |

- removed (2020-08-07):
[0000068505-20-000013:note_history:21]
As of March 28, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution, of which, $800 million was outstanding as of March 28, 2020. The weighted average borrowing rate on outstanding amounts was 2.35%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 28, 2020.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-08-07):
[0000068505-20-000013:note_history:22]
|  | March 28, 2020 |  | December 31, 2019 |
| $2.2 billion revolving credit facility due April 2022 | $ | 800 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | 550 |  |  | 550 |  |
| 3.5% senior notes due 2023 | 597 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 593 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 990 |  |  | 988 |  |
| 6.5% debentures due 2025 | 72 |  |  | 72 |  |
| 7.5% debentures due 2025 | 254 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 28 |  |  | 35 |  |
|  | 5,928 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3) |  |  | (3) |  |
| Less: current portion | (814) |  |  | (16) |  |
| Long-term debt | $ | 5,111 |  |  | $ | 5,113 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0000068505-20-000020:note_history:23]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 27, 2020 and June 29, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:
  (was, 2020-05-08, similarity 0.8896):
[0000068505-20-000013:note_history:23]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 28, 2020 and March 30, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2020-08-07):
[0000068505-20-000020:note_history:24]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 719 |  |  | $ | 374 |  |  | $ | 911 |  |  | $ | 342 |  |
| International | 249 |  |  | 276 |  |  | 327 |  |  | 280 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 582 |  |  | $ | — |  |  | $ | 809 |  |  | $ | — |  |
| Systems and Systems Integration | 386 |  |  | — |  |  | 429 |  |  | — |  |
| Services | — |  |  | 484 |  |  | — |  |  | 469 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 153 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 634 |  |  | $ | 611 |  |  | $ | 771 |  |  | $ | 582 |  |
| Indirect | 334 |  |  | 39 |  |  | 467 |  |  | 40 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
  (was, 2020-05-08, similarity 0.975):
[0000068505-20-000013:note_history:24]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  |  |  | March 30, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 748 |  |  | $ | 368 |  |  | $ | 755 |  |  | $ | 320 |  |
| International | 245 |  |  | 294 |  |  | 314 |  |  | 268 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 620 |  |  | $ | — |  |  | $ | 686 |  |  | $ | — |  |
| Systems and Systems Integration | 373 |  |  | — |  |  | 383 |  |  | — |  |
| Services | — |  |  | 493 |  |  | — |  |  | 452 |  |
| Software | — |  |  | 169 |  |  | — |  |  | 136 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 641 |  |  | $ | 621 |  |  | $ | 657 |  |  | $ | 553 |  |
| Indirect | 352 |  |  | 41 |  |  | 412 |  |  | 35 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |

- added (2020-08-07):
[0000068505-20-000020:note_history:25]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 1,467 |  |  | $ | 742 |  |  | $ | 1,666 |  |  | $ | 662 |  |
| International | 494 |  |  | 570 |  |  | 641 |  |  | 548 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,202 |  |  | $ | — |  |  | $ | 1,495 |  |  | $ | — |  |
| Systems and Systems Integration | 759 |  |  | — |  |  | 812 |  |  | — |  |
| Services | — |  |  | 976 |  |  | — |  |  | 921 |  |
| Software | — |  |  | 336 |  |  | — |  |  | 289 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 1,429 |  |  | $ | 1,135 |  |
| Indirect | 686 |  |  | 80 |  |  | 878 |  |  | 75 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0000068505-20-000020:note_history:26]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 27, 2020 and June 29, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:
  (was, 2020-05-08, similarity 0.8896):
[0000068505-20-000013:note_history:26]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 28, 2020 and March 30, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2020-08-07):
[0000068505-20-000020:note_history:27]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 719 |  |  | $ | 374 |  |  | $ | 911 |  |  | $ | 342 |  |
| International | 249 |  |  | 276 |  |  | 327 |  |  | 280 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 582 |  |  | $ | — |  |  | $ | 809 |  |  | $ | — |  |
| Systems and Systems Integration | 386 |  |  | — |  |  | 429 |  |  | — |  |
| Services | — |  |  | 484 |  |  | — |  |  | 469 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 153 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 634 |  |  | $ | 611 |  |  | $ | 771 |  |  | $ | 582 |  |
| Indirect | 334 |  |  | 39 |  |  | 467 |  |  | 40 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
  (was, 2020-05-08, similarity 0.975):
[0000068505-20-000013:note_history:27]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  |  |  | March 30, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 748 |  |  | $ | 368 |  |  | $ | 755 |  |  | $ | 320 |  |
| International | 245 |  |  | 294 |  |  | 314 |  |  | 268 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 620 |  |  | $ | — |  |  | $ | 686 |  |  | $ | — |  |
| Systems and Systems Integration | 373 |  |  | — |  |  | 383 |  |  | — |  |
| Services | — |  |  | 493 |  |  | — |  |  | 452 |  |
| Software | — |  |  | 169 |  |  | — |  |  | 136 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 641 |  |  | $ | 621 |  |  | $ | 657 |  |  | $ | 553 |  |
| Indirect | 352 |  |  | 41 |  |  | 412 |  |  | 35 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |

- added (2020-08-07):
[0000068505-20-000020:note_history:28]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 1,467 |  |  | $ | 742 |  |  | $ | 1,666 |  |  | $ | 662 |  |
| International | 494 |  |  | 570 |  |  | 641 |  |  | 548 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,202 |  |  | $ | — |  |  | $ | 1,495 |  |  | $ | — |  |
| Systems and Systems Integration | 759 |  |  | — |  |  | 812 |  |  | — |  |
| Services | — |  |  | 976 |  |  | — |  |  | 921 |  |
| Software | — |  |  | 336 |  |  | — |  |  | 289 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 1,429 |  |  | $ | 1,135 |  |
| Indirect | 686 |  |  | 80 |  |  | 878 |  |  | 75 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |

- changed (2020-08-07):
[0000068505-20-000020:note_history:29]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 27, 2020 is $6.6 billion. A total of $2.8 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion is from Software and Services performance obligations that are not yet satisfied as of June 27, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2020-05-08, similarity 0.9936):
[0000068505-20-000013:note_history:29]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 28, 2020 is $6.7 billion. A total of $2.9 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion is from Software and Services performance obligations that are not yet satisfied as of March 28, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2020-08-07):
[0000068505-20-000020:note_history:30]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,134 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 937 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,294 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 263 |  |  | 274 |  |  |  |  |  |
  (was, 2020-05-08, similarity 0.6225):
[0000068505-20-000013:note_history:30]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 21 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 99 |  |  | 107 |  |  |  |  |  |

- added (2020-08-07):
[0000068505-20-000020:note_history:31]
Revenue recognized during the three months ended June 27, 2020 which was previously included in Contract liabilities as of March 28, 2020 is $370 million, compared to $340 million of revenue recognized during the three months ended June 29, 2019 which was previously included in Contract liabilities as of March 30, 2019. Revenue recognized during the six months ended June 27, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $631 million, compared to $600 million of revenue recognized during the six months ended June 29, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $12 million and $34 million was reversed during the three and six months ended June 27, 2020 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. Adjustments to revenue for the three and six months ended June 29, 2019 driven by changes in the estimates of progress on system contracts were immaterial.

- changed (2020-08-07):
[0000068505-20-000020:note_history:32]
There were no material expected credit losses recognized on contract assets during the three and six months ended June 27, 2020 and June 29, 2019.
  (was, 2020-05-08, similarity 0.9015):
[0000068505-20-000013:note_history:32]
There were no material expected credit losses recognized on contract assets during the three months ended March 28, 2020 and March 30, 2019.

- added (2020-08-07):
[0000068505-20-000020:note_history:33]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 22 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 101 |  |  | 107 |  |  |  |  |  |

- changed (2020-08-07):
[0000068505-20-000020:note_history:34]
Amortization of non-current contract cost assets was $11 million and $22 million for both the three and six months ended June 27, 2020 and June 29, 2019, respectively.
  (was, 2020-05-08, similarity 0.7761):
[0000068505-20-000013:note_history:34]
Amortization of non-current contract cost assets was $11 million for the three months ended March 28, 2020 and March 30, 2019.

- removed (2020-08-07):
[0000068505-20-000013:note_history:35]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,122 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 958 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,278 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 264 |  |  | 274 |  |  |  |  |  |

- removed (2020-08-07):
[0000068505-20-000013:note_history:36]
Revenue recognized during the three months ended March 28, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $382 million, compared to $393 million of revenue recognized during the three months ended March 30, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $19 million was reversed during the three months ended March 28, 2020, compared to $9 million of reversals for the three months ended March 30, 2019.
