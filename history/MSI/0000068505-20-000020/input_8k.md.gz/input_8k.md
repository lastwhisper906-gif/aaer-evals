# MSI 8-K — 0000068505-20-000018 filed 2020-08-06

## item codes, every 8-K on or before 2020-08-07

- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2020-08-07

- none on or before 2020-08-07

## item 2.02 — earnings release, exhibit 99.1

[0000068505-20-000018:8k_2_02:1]
EX-99.1
2
msiq22020pressrelease.htm
EX-99.1

[0000068505-20-000018:8k_2_02:2]
Document

[0000068505-20-000018:8k_2_02:3]
Exhibit 99.1

[0000068505-20-000018:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2020 Financial Results

[0000068505-20-000018:8k_2_02:5]
•Revenue of $1.6 billion, down 13% versus a year ago

[0000068505-20-000018:8k_2_02:6]
•Software and Services segment grew 5% and expanded operating margins by 260 bps

[0000068505-20-000018:8k_2_02:7]
•GAAP earnings per share (EPS) of $0.78

[0000068505-20-000018:8k_2_02:8]
•Non-GAAP EPS* of $1.39

[0000068505-20-000018:8k_2_02:9]
•Generated $209 million of operating cash flow and $155 million of free cash flow

[0000068505-20-000018:8k_2_02:10]
•Subsequent to quarter end, acquired Pelco Inc., a global provider of video security solutions for $110 million

[0000068505-20-000018:8k_2_02:11]
CHICAGO – Aug. 6, 2020 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2020. Click here for a printable news release and financial tables.

[0000068505-20-000018:8k_2_02:12]
“I’m proud of our solid execution in Q2, led by software & services, in the face of this global pandemic.  And, I'm even more impressed with our employees' resilience and unwavering commitment to our customers and to our business,” said Greg Brown, chairman and CEO, Motorola Solutions. “Demand for video security, software & services and increased customer engagements are driving our expectations for improvement in the second half of the year.”

[0000068505-20-000018:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-20-000018:8k_2_02:14]
|  | Q2 2020 | Q2 2019 | % Change |
| Sales | $1,618 | $1,860 | (13) | % |
| GAAP |  |  |  |
| Operating Earnings | $218 | $349 | (38) | % |
| % of Sales | 13.5 | % | 18.8 | % |  |
| EPS | $0.78 | $1.18 | (34) | % |
| Non-GAAP* |  |  |  |
| Operating Earnings | $359 | $444 | (19) | % |
| % of Sales | 22.2 | % | 23.9 | % |  |
| EPS | $1.39 | $1.69 | (18) | % |
| Products and Systems Integration Segment |  |  |  |
| Sales | $968 | $1,238 | (22) | % |
| GAAP Operating Earnings | $49 | $201 | (76) | % |
| % of Sales | 5.1 | % | 16.2 | % |  |
| Non-GAAP Operating Earnings* | $131 | $242 | (46) | % |
| % of Sales | 13.5 | % | 19.5 | % |  |
| Software and Services Segment |  |  |  |
| Sales | $650 | $622 | 5 | % |
| GAAP Operating Earnings | $169 | $148 | 14 | % |
| % of Sales | 26.0 | % | 23.8 | % |  |
| Non-GAAP Operating Earnings* | $228 | $202 | 13 | % |
| % of Sales | 35.1 | % | 32.5 | % |  |

[0000068505-20-000018:8k_2_02:15]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.61 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-20-000018:8k_2_02:16]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-20-000018:8k_2_02:17]
•Revenue - Sales were $1.6 billion, down 13% from the year-ago quarter driven by declines in North America and International. Revenue from acquisitions was $40 million, and currency headwinds were $30 million in the quarter. The Products and Systems Integration segment declined 22% primarily due to lower sales of professional and commercial radio (PCR) and public safety LMR products.  The Software and Services segment grew 5%, driven by growth in North America services and software.

[0000068505-20-000018:8k_2_02:18]
•Operating margin - GAAP operating margin was 13.5% of sales, down from 18.8% in the year-ago quarter primarily due to lower sales in the Products and System Integration segment, partially offset by higher sales and gross margin in the Software and Services segment. Non-GAAP operating margin was 22.2% of sales, down from 23.9% in the year-ago quarter primarily due to lower sales in the Products and System Integration segment, partially offset by higher sales and gross margin in the Software and Services segment.

[0000068505-20-000018:8k_2_02:19]
•Taxes - The GAAP effective tax rate was 23%, compared with 24% in the year-ago quarter. The non-GAAP effective tax rate was 23%, compared with 24% in the year-ago quarter. Both the GAAP and non-GAAP tax rates were lower in the current quarter primarily due to higher research and development credits.

[0000068505-20-000018:8k_2_02:20]
•Cash flow - Operating cash flow was $209 million, compared with $251 million in the year-ago quarter. Free cash flow was $155 million, compared with $188 million in the year-ago quarter. Cash flow for the quarter decreased due to lower sales and net income, partially offset by improved working capital.

[0000068505-20-000018:8k_2_02:21]
•Capital allocation - During the quarter, the company paid $109 million in cash dividends, repurchased $83 million of shares, used $65 million for acquisitions, and incurred $54 million of capital expenditures. Additionally, the company repaid $500 million of its revolving credit facility borrowing, of which $300 million was repaid during the quarter and $200 million was repaid subsequently. The remaining outstanding amount of the facility borrowing was $300 million as of Aug. 6, 2020.

[0000068505-20-000018:8k_2_02:22]
•Backlog - The company ended the quarter with backlog of $10.5 billion, down $376 million from the year-ago quarter, inclusive of $126 million of unfavorable currency adjustments. Software and Services segment backlog was down 2% or $148 million, inclusive of $116 million of unfavorable currency rates. The decline was primarily related to revenue recognized for the Airwave and ESN contracts, partially offset by growth in North America. Products and Systems Integration segment backlog was down 7% or $228 million, inclusive of $10 million of unfavorable currency adjustments, driven by large International deployments and lower orders due to the delay in sales engagements from COVID-19.

[0000068505-20-000018:8k_2_02:23]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-20-000018:8k_2_02:24]
Software and Services

[0000068505-20-000018:8k_2_02:25]
•$37 million P25 multi-year services contract with the State of Louisiana

[0000068505-20-000018:8k_2_02:26]
•$26 million Next Generation 911 services contract with the State of Utah

[0000068505-20-000018:8k_2_02:27]
•$10 million P25 statewide multi-year services contract in North America

[0000068505-20-000018:8k_2_02:28]
•$8 million multi-year computer aided dispatch contract with Baltimore County

[0000068505-20-000018:8k_2_02:29]
Products and Systems Integration

[0000068505-20-000018:8k_2_02:30]
•$24 million P25 order for State of Alaska

[0000068505-20-000018:8k_2_02:31]
•$20 million P25 order for Newton County, Georgia

[0000068505-20-000018:8k_2_02:32]
•$17 million P25 order for State of South Dakota

[0000068505-20-000018:8k_2_02:33]
•Launched the V300 continuous-operation body-worn camera

[0000068505-20-000018:8k_2_02:34]
•Closed acquisition of IndigoVision in Q2 and subsequent to quarter end announced the acquisition of Pelco Inc.

[0000068505-20-000018:8k_2_02:35]
BUSINESS OUTLOOK

[0000068505-20-000018:8k_2_02:36]
•Third-quarter 2020 - Motorola Solutions expects revenue decline of (9%) to (8%) compared with the third quarter of 2019. The company expects non-GAAP earnings per share in the range of $1.72 to $1.78. This assumes current foreign exchange rates, approximately 174 million fully diluted shares, and an effective tax rate of approximately 23%.

[0000068505-20-000018:8k_2_02:37]
•Full-year 2020 - Motorola Solutions expects revenue decline of approximately (7%) and non-GAAP earnings per share in the range of $7.40 to $7.52. This assumes current foreign exchange rates, approximately 175 million fully diluted shares, and an effective tax rate of 21% to 22%.

[0000068505-20-000018:8k_2_02:38]
COVID-19

[0000068505-20-000018:8k_2_02:39]
In response to the evolving COVID-19 pandemic, the company continues to adhere to its plans to keep its employees and customers healthy and safe, as well as  ensuring continued operations and business continuity. Safety measures during this outbreak include having the vast majority of employees work remotely, suspending employee travel, withdrawing from certain industry events, increasing cleaning services, encouraging face coverings and using thermal scanning. The company continues to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service mission-critical networks on-site as needed to ensure seamless operations. In addition, our supply chain partners remain supportive and continue to do their part to ensure that service levels to the company and its customers remain fulfilled.

[0000068505-20-000018:8k_2_02:40]
The sales teams’ engagement with customers, both virtual and in-person, has improved throughout the second quarter. The expectation is for improvement to continue throughout the second half of 2020. Additionally, the company’s engineering teams have adapted its solutions offerings to equip customers with the latest technology in the fight to protect their workplace from the spread of COVID-19. Specifically, in the video security business, the company has adapted its software and hardware offerings to provide analytics for occupancy counting, face mask detection and thermal detection capabilities.

[0000068505-20-000018:8k_2_02:41]
The company has also taken actions in a number of areas to reduce its operating expenses, mostly driven by lower variable compensation, travel costs, contractor spend and reduced real estate footprint to limit the negative effect on operating margins for the year despite the expected reduction of revenue.

[0000068505-20-000018:8k_2_02:42]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, Aug. 6. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-20-000018:8k_2_02:43]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-20-000018:8k_2_02:44]
A comparison of results from operations is as follows:

[0000068505-20-000018:8k_2_02:45]
|  | Q2 2020 | Q2 2019 |
| Net sales | $1,618 | $1,860 |
| Gross margin | 766 |  | 931 |  |
| Operating earnings | 218 |  | 349 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 135 |  | 207 |  |
| Diluted EPS | $0.78 | $1.18 |
| Weighted average diluted common shares outstanding | 173.6 |  | 176.1 |  |

[0000068505-20-000018:8k_2_02:46]
HIGHLIGHTED ITEMS

[0000068505-20-000018:8k_2_02:47]
The table below includes highlighted items, share-based compensation expenses and intangible amortization for the second quarter of 2020.

[0000068505-20-000018:8k_2_02:48]
| (per diluted common share) | Q2 2020 |
| GAAP Earnings | $0.78 |
| Highlighted Items: |  |
| Intangibles amortization expense | 0.22 |  |
| Reorganization of business charges | 0.18 |  |
| Share-based compensation expenses | 0.14 |  |
| Legal settlements | 0.03 |  |
| Hytera-related legal expenses | 0.02 |  |
| Fixed asset impairment | 0.02 |  |
| Acquisition-related transaction fees | 0.01 |  |
| Release of uncertain tax positions | 0.01 |  |
| Fair value adjustments to equity investments | (0.02) |  |
| Non-GAAP Diluted EPS | $1.39 |

[0000068505-20-000018:8k_2_02:49]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-20-000018:8k_2_02:50]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-20-000018:8k_2_02:51]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-20-000018:8k_2_02:52]
Hytera-Related Legal Expenses: On February 14, 2020, we announced that a jury in the U.S. District Court for the Northern District of Illinois decided in our favor in our trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection

[0000068505-20-000018:8k_2_02:53]
with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In the first quarter of 2020, we revised our definition of non-GAAP operating income to exclude the impact of Hytera-related legal expenses. The $5 million of Hytera-related legal expense incurred in the second quarter of 2020 reflects costs primarily associated with this jury trial. During the second quarter of 2020, Hytera filed a motion for a new trial and Hytera America, Inc. and Hytera Communications America (West) both filed for chapter 11 bankruptcy protection. Subsequent to quarter end, the company filed motions to dismiss the bankruptcy proceedings. Given our inability to predict the timing and outcome of these motions, together with the uncertainty of our ability to ultimately collect amounts awarded, at this time we have not recognized in our financial statements any gain related to the Hytera litigation.

[0000068505-20-000018:8k_2_02:54]
Management typically considers legal expenses associated with defending our intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both our GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. We anticipate further expenses associated with Hytera-related litigation; however, we believe that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate our business. In addition, if any contingent or actual gain associated with the Hytera litigation is recognized in the future, it will be similarly excluded from our non-GAAP operating income. We believe after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates our ongoing underlying business performance.

[0000068505-20-000018:8k_2_02:55]
For comparative purposes, $6 million, or $0.03 of earnings per share, net of tax, of Hytera-related legal expense was included in our second quarter 2019 Non-GAAP operating earnings.

[0000068505-20-000018:8k_2_02:56]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-20-000018:8k_2_02:57]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-20-000018:8k_2_02:58]
Free cash flow:  Free cash flow represents operating cash flow less capital expenditures. We believe that free cash flow is also useful to investors as the basis for comparing our performance and coverage ratios with other companies in our industries, although our measure of free cash flow may not be directly comparable to similar measures used by other companies.

[0000068505-20-000018:8k_2_02:59]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes non-GAAP organic revenue growth provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-20-000018:8k_2_02:60]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-20-000018:8k_2_02:61]
The company has not quantitatively reconciled its guidance for non-GAAP metrics to their most comparable GAAP measure because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-20-000018:8k_2_02:62]
BUSINESS RISKS

[0000068505-20-000018:8k_2_02:63]
from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its 1.75% senior convertible notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-20-000018:8k_2_02:64]
ABOUT MOTOROLA SOLUTIONS

[0000068505-20-000018:8k_2_02:65]
Motorola Solutions is a global leader in mission-critical communications and analytics. Our technology platforms in mission-critical communications, command center software and video security & analytics, bolstered by managed & support services, make cities safer and help communities and businesses thrive. At Motorola Solutions, we are ushering in a new era in public safety and security.  Learn more at www.motorolasolutions.com.

[0000068505-20-000018:8k_2_02:66]
MEDIA CONTACT

[0000068505-20-000018:8k_2_02:67]
Alexandra Reynolds

[0000068505-20-000018:8k_2_02:68]
Motorola Solutions

[0000068505-20-000018:8k_2_02:69]
+1 312-965-3968

[0000068505-20-000018:8k_2_02:70]
alexandra.reynolds@motorolasolutions.com

[0000068505-20-000018:8k_2_02:71]
INVESTOR CONTACT

[0000068505-20-000018:8k_2_02:72]
Tim Yocum

[0000068505-20-000018:8k_2_02:73]
Motorola Solutions

[0000068505-20-000018:8k_2_02:74]
+1 847-576-6899

[0000068505-20-000018:8k_2_02:75]
Tim.Yocum@motorolasolutions.com

[0000068505-20-000018:8k_2_02:76]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2020 Motorola Solutions, Inc. All rights reserved.

[0000068505-20-000018:8k_2_02:77]
GAAP-1

[0000068505-20-000018:8k_2_02:78]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:79]
Condensed Consolidated Statements of Operations

[0000068505-20-000018:8k_2_02:80]
(In millions, except per share amounts)

[0000068505-20-000018:8k_2_02:81]
|  | Three Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |
| Net sales from products | $ | 877 |  |  | $ | 1,118 |  |
| Net sales from services | 741 |  |  | 742 |  |
| Net sales | 1,618 |  |  | 1,860 |  |
| Costs of products sales | 413 |  |  | 490 |  |
| Costs of services sales | 439 |  |  | 439 |  |
| Costs of sales | 852 |  |  | 929 |  |
| Gross margin | 766 |  |  | 931 |  |
| Selling, general and administrative expenses | 297 |  |  | 351 |  |
| Research and development expenditures | 161 |  |  | 170 |  |
| Other charges | 39 |  |  | 9 |  |
| Intangibles amortization | 51 |  |  | 52 |  |
| Operating earnings | 218 |  |  | 349 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (58) |  |  | (56) |  |
| Gains on sales of investments and businesses, net | — |  |  | 3 |  |
| Other, net | 16 |  |  | (21) |  |
| Total other expense | (42) |  |  | (74) |  |
| Net earnings before income taxes | 176 |  |  | 275 |  |
| Income tax expense | 40 |  |  | 67 |  |
| Net earnings | 136 |  |  | 208 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 135 |  |  | $ | 207 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 0.79 |  |  | $ | 1.25 |  |
| Diluted | $ | 0.78 |  |  | $ | 1.18 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 170.0 |  |  | 164.9 |  |
| Diluted | 173.6 |  |  | 176.1 |  |
|  | Percentage of Net Sales* |  |  |
| Net sales from products | 54.2 | % |  | 60.1 | % |
| Net sales from services | 45.8 | % |  | 39.9 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.1 | % |  | 43.8 | % |
| Costs of services sales | 59.2 | % |  | 59.2 | % |
| Costs of sales | 52.7 | % |  | 49.9 | % |
| Gross margin | 47.3 | % |  | 50.1 | % |
| Selling, general and administrative expenses | 18.4 | % |  | 18.9 | % |
| Research and development expenditures | 10.0 | % |  | 9.1 | % |
| Other charges | 2.4 | % |  | 0.5 | % |
| Intangibles amortization | 3.2 | % |  | 2.8 | % |
| Operating earnings | 13.5 | % |  | 18.8 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.6) | % |  | (3.0) | % |
| Gains on sales of investments and businesses, net | — | % |  | 0.2 | % |
| Other, net | 1.0 | % |  | (1.1) | % |
| Total other expense | (2.6) | % |  | (4.0) | % |
| Net earnings before income taxes | 10.9 | % |  | 14.8 | % |
| Income tax expense | 2.5 | % |  | 3.6 | % |
| Net earnings | 8.4 | % |  | 11.2 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 8.3 | % |  | 11.1 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-20-000018:8k_2_02:82]
GAAP-2

[0000068505-20-000018:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:84]
Condensed Consolidated Statements of Operations

[0000068505-20-000018:8k_2_02:85]
(In millions, except per share amounts)

[0000068505-20-000018:8k_2_02:86]
|  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |
| Net sales from products | $ | 1,764 |  |  | $ | 2,063 |  |
| Net sales from services | 1,509 |  |  | 1,454 |  |
| Net sales | 3,273 |  |  | 3,517 |  |
| Costs of products sales | 812 |  |  | 934 |  |
| Costs of services sales | 908 |  |  | 879 |  |
| Costs of sales | 1,720 |  |  | 1,813 |  |
| Gross margin | 1,553 |  |  | 1,704 |  |
| Selling, general and administrative expenses | 638 |  |  | 676 |  |
| Research and development expenditures | 330 |  |  | 333 |  |
| Other charges | 5 |  |  | 14 |  |
| Intangibles amortization | 104 |  |  | 102 |  |
| Operating earnings | 476 |  |  | 579 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (109) |  |  | (111) |  |
| Gains on sales of investments and businesses, net | — |  |  | 4 |  |
| Other, net | 34 |  |  | (12) |  |
| Total other expense | (75) |  |  | (119) |  |
| Net earnings before income taxes | 401 |  |  | 460 |  |
| Income tax expense | 67 |  |  | 100 |  |
| Net earnings | 334 |  |  | 360 |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 332 |  |  | $ | 358 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.95 |  |  | $ | 2.18 |  |
| Diluted | $ | 1.90 |  |  | $ | 2.04 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 170.3 |  |  | 164.4 |  |
| Diluted | 174.8 |  |  | 175.3 |  |
|  | Percentage of Net Sales* |  |  |
| Net sales from products | 53.9 | % |  | 58.7 | % |
| Net sales from services | 46.1 | % |  | 41.3 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 46.0 | % |  | 45.3 | % |
| Costs of services sales | 60.2 | % |  | 60.5 | % |
| Costs of sales | 52.6 | % |  | 51.5 | % |
| Gross margin | 47.4 | % |  | 48.5 | % |
| Selling, general and administrative expenses | 19.5 | % |  | 19.2 | % |
| Research and development expenditures | 10.1 | % |  | 9.5 | % |
| Other charges | 0.2 | % |  | 0.4 | % |
| Intangibles amortization | 3.2 | % |  | 2.9 | % |
| Operating earnings | 14.5 | % |  | 16.5 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.3) | % |  | (3.2) | % |
| Gains on sales of investments and businesses, net | — | % |  | 0.1 | % |
| Other, net | 1.0 | % |  | (0.3) | % |
| Total other expense | (2.3) | % |  | (3.4) | % |
| Net earnings before income taxes | 12.3 | % |  | 13.1 | % |
| Income tax expense | 2.0 | % |  | 2.8 | % |
| Net earnings | 10.2 | % |  | 10.2 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 10.1 | % |  | 10.2 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-20-000018:8k_2_02:87]
GAAP-3

[0000068505-20-000018:8k_2_02:88]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:89]
Condensed Consolidated Balance Sheets

[0000068505-20-000018:8k_2_02:90]
(In millions)

[0000068505-20-000018:8k_2_02:91]
|  |  | June 27, 2020 |  | December 31, 2019 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,341 |  |  | $ | 1,001 |  |
| Accounts receivable, net |  | 1,134 |  |  | 1,412 |  |
| Contract assets |  | 937 |  |  | 1,046 |  |
| Inventories, net |  | 449 |  |  | 447 |  |
| Other current assets |  | 225 |  |  | 272 |  |
| Total current assets |  | 4,086 |  |  | 4,178 |  |
| Property, plant and equipment, net |  | 965 |  |  | 992 |  |
| Operating lease assets |  | 462 |  |  | 554 |  |
| Investments |  | 157 |  |  | 159 |  |
| Deferred income taxes |  | 922 |  |  | 943 |  |
| Goodwill |  | 2,123 |  |  | 2,067 |  |
| Intangible assets, net |  | 1,242 |  |  | 1,327 |  |
| Other assets |  | 417 |  |  | 422 |  |
| Total assets |  | $ | 10,374 |  |  | $ | 10,642 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |  |
| Current portion of long-term debt |  | $ | 517 |  |  | $ | 16 |  |
| Accounts payable |  | 498 |  |  | 618 |  |
| Contract liabilities |  | 1,294 |  |  | 1,449 |  |
| Accrued liabilities |  | 1,171 |  |  | 1,356 |  |
| Total current liabilities |  | 3,480 |  |  | 3,439 |  |
| Long-term debt |  | 5,111 |  |  | 5,113 |  |
| Operating lease liabilities |  | 385 |  |  | 497 |  |
| Other liabilities |  | 2,213 |  |  | 2,276 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (830) |  |  | (700) |  |
| Non-controlling interests |  | 15 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) |  | $ | 10,374 |  |  | $ | 10,642 |  |

[0000068505-20-000018:8k_2_02:92]
GAAP-4

[0000068505-20-000018:8k_2_02:93]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:94]
Condensed Consolidated Statements of Cash Flows

[0000068505-20-000018:8k_2_02:95]
(In millions)

[0000068505-20-000018:8k_2_02:96]
|  | Three Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 135 |  |  | $ | 207 |  |
| Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings | 136 |  |  | 208 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 98 |  |  | 96 |  |
| Non-cash other charges (income) | 11 |  |  | (6) |  |
| Share-based compensation expenses | 31 |  |  | 30 |  |
| Gain on sales of investments and businesses, net | — |  |  | (3) |  |
| Losses from the extinguishment of long term debt | — |  |  | 43 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 11 |  |  | (58) |  |
| Inventories | 1 |  |  | 2 |  |
| Other current assets and contract assets | 88 |  |  | (8) |  |
| Accounts payable, accrued liabilities, and contract liabilities | (153) |  |  | (84) |  |
| Other assets and liabilities | (11) |  |  | 8 |  |
| Deferred income taxes | (3) |  |  | 23 |  |
| Net cash provided by operating activities | 209 |  |  | 251 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (65) |  |  | (3) |  |
| Proceeds from sales of investments and businesses, net | 4 |  |  | 8 |  |
| Capital expenditures | (54) |  |  | (63) |  |
| Net cash used for investing activities | (115) |  |  | (58) |  |
| Financing |  |  |  |
| Repayments of debt | (4) |  |  | (658) |  |
| Repayment of revolver draw | (300) |  |  | — |  |
| Net proceeds from issuance of debt | — |  |  | 645 |  |
| Issuances of common stock | 44 |  |  | 25 |  |
| Purchases of common stock | (83) |  |  | (25) |  |
| Payments of dividends | (109) |  |  | (94) |  |
| Payments of dividends to non-controlling interests | (4) |  |  | (3) |  |
| Net cash used for financing activities | (456) |  |  | (110) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 31 |  |  | (16) |  |
| Net increase (decrease) in total cash and cash equivalents | (331) |  |  | 67 |  |
| Cash and cash equivalents, beginning of period | 1,672 |  |  | 897 |  |
| Cash and cash equivalents, end of period | $ | 1,341 |  |  | $ | 964 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 155 |  |  | $ | 188 |  |
| *Free cash flow = Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-20-000018:8k_2_02:97]
GAAP-5

[0000068505-20-000018:8k_2_02:98]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:99]
Condensed Consolidated Statements of Cash Flows

[0000068505-20-000018:8k_2_02:100]
(In millions)

[0000068505-20-000018:8k_2_02:101]
|  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 332 |  |  | $ | 358 |  |
| Earnings attributable to non-controlling interests | 2 |  |  | 2 |  |
| Net earnings | 334 |  |  | 360 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 197 |  |  | 191 |  |
| Non-cash other charges (income) | (40) |  |  | 4 |  |
| Share-based compensation expenses | 69 |  |  | 57 |  |
| Gain on sales of investments and businesses, net | — |  |  | (4) |  |
| Losses from the extinguishment of long term debt | — |  |  | 43 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 286 |  |  | 110 |  |
| Inventories | 3 |  |  | (61) |  |
| Other current assets and contract assets | 136 |  |  | 128 |  |
| Accounts payable, accrued liabilities, and contract liabilities | (454) |  |  | (345) |  |
| Other assets and liabilities | (15) |  |  | 2 |  |
| Deferred income taxes | 1 |  |  | 17 |  |
| Net cash provided by operating activities | 517 |  |  | 502 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (102) |  |  | (371) |  |
| Proceeds from sales of investments and businesses, net | 7 |  |  | 10 |  |
| Capital expenditures | (102) |  |  | (129) |  |
| Proceeds from sales of property, plant and equipment | 56 |  |  | — |  |
| Net cash used for investing activities | (141) |  |  | (490) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | — |  |  | 645 |  |
| Repayments of debt | (8) |  |  | (666) |  |
| Net proceeds from revolver draw | 800 |  |  | — |  |
| Repayment of revolver draw | (300) |  |  | — |  |
| Issuances of common stock | 49 |  |  | 70 |  |
| Purchases of common stock | (336) |  |  | (170) |  |
| Payments of dividends | (218) |  |  | (187) |  |
| Payments of dividends to non-controlling interests | (4) |  |  | (3) |  |
| Net cash used for financing activities | (17) |  |  | (311) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (19) |  |  | 6 |  |
| Net increase (decrease) in total cash and cash equivalents | 340 |  |  | (293) |  |
| Cash and cash equivalents, beginning of period | 1,001 |  |  | 1,257 |  |
| Cash and cash equivalents, end of period | $ | 1,341 |  |  | $ | 964 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 415 |  |  | $ | 373 |  |
| *Free cash flow = Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-20-000018:8k_2_02:102]
GAAP-6

[0000068505-20-000018:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:104]
Segment Information

[0000068505-20-000018:8k_2_02:105]
(In millions)

[0000068505-20-000018:8k_2_02:106]
| Net Sales |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 968 |  |  | $ | 1,238 |  |  | (22) | % |  |  |
| Software and Services | 650 |  |  | 622 |  |  | 5 | % |  |  |
| Total Motorola Solutions | $ | 1,618 |  |  | $ | 1,860 |  |  | (13) | % |  |  |
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 1,961 |  |  | $ | 2,307 |  |  | (15) | % |  |  |
| Software and Services | 1,312 |  |  | 1,210 |  |  | 8 | % |  |  |
| Total Motorola Solutions | $ | 3,273 |  |  | $ | 3,517 |  |  | (7) | % |  |  |
| Operating Earnings |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 49 |  |  | $ | 201 |  |  | (76) | % |  |  |
| Software and Services | 169 |  |  | 148 |  |  | 14 | % |  |  |
| Total Motorola Solutions | $ | 218 |  |  | $ | 349 |  |  | (38) | % |  |  |
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 141 |  |  | $ | 310 |  |  | (55) | % |  |  |
| Software and Services | 335 |  |  | 269 |  |  | 25 | % |  |  |
| Total Motorola Solutions | $ | 476 |  |  | $ | 579 |  |  | (18) | % |  |  |

[0000068505-20-000018:8k_2_02:107]
| Operating Earnings % |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  |  |  |  |
| Products and Systems Integration | 5.1 | % |  | 16.2 | % |  |  |  |  |
| Software and Services | 26.0 | % |  | 23.8 | % |  |  |  |  |
| Total Motorola Solutions | 13.5 | % |  | 18.8 | % |  |  |  |  |
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  |  |  |  |
| Products and Systems Integration | 7.2 | % |  | 13.4 | % |  |  |  |  |
| Software and Services | 25.5 | % |  | 22.2 | % |  |  |  |  |
| Total Motorola Solutions | 14.5 | % |  | 16.5 | % |  |  |  |  |

[0000068505-20-000018:8k_2_02:108]
Non-GAAP-1

[0000068505-20-000018:8k_2_02:109]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:110]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expenses, and Highlighted Items)

[0000068505-20-000018:8k_2_02:111]
(In millions)

[0000068505-20-000018:8k_2_02:112]
| Q1 2020 |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 53 |  |  | $ | 13 |  |  | $ | 40 |  |  | $ | 0.23 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 38 |  |  | 9 |  |  | 29 |  |  | 0.17 |  |
| Hytera-related legal expenses |  | SG&A |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.11 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Legal settlements |  | Other charges (income) |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income |  | (1) |  |  | — |  |  | (1) |  |  | (0.01) |  |
| Release of uncertain tax positions |  | Income tax expense |  | — |  |  | 1 |  |  | (1) |  |  | (0.01) |  |
| Gain on sale of property, plant, and equipment |  | Other charges (income) |  | (50) |  |  | (12) |  |  | (38) |  |  | (0.22) |  |
| Total impact on Net earnings |  |  |  | $ | 87 |  |  | $ | 21 |  |  | $ | 66 |  |  | $ | 0.37 |  |
| Q2 2020 |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 51 |  |  | $ | 12 |  |  | $ | 39 |  |  | $ | 0.22 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 41 |  |  | 10 |  |  | 31 |  |  | 0.18 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 31 |  |  | 7 |  |  | 24 |  |  | 0.14 |  |
| Legal settlements |  | Other charges (income) |  | 7 |  |  | 2 |  |  | 5 |  |  | 0.03 |  |
| Hytera-related legal expenses |  | SG&A |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Fixed asset impairment |  | Other charges (income) |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Release of uncertain tax positions |  | Income tax expense |  | — |  |  | (1) |  |  | 1 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income |  | (4) |  |  | (1) |  |  | (3) |  |  | (0.02) |  |
| Total impact on Net earnings |  |  |  | $ | 137 |  |  | $ | 31 |  |  | $ | 106 |  |  | $ | 0.61 |  |

[0000068505-20-000018:8k_2_02:113]
Non-GAAP-2

[0000068505-20-000018:8k_2_02:114]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:115]
Non-GAAP Segment Information

[0000068505-20-000018:8k_2_02:116]
(In millions)

[0000068505-20-000018:8k_2_02:117]
| Net Sales |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 968 |  |  | $ | 1,238 |  |  | (22) | % |  |  |
| Software and Services | 650 |  |  | 622 |  |  | 5 | % |  |  |
| Total Motorola Solutions | $ | 1,618 |  |  | $ | 1,860 |  |  | (13) | % |  |  |
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 1,961 |  |  | $ | 2,307 |  |  | (15) | % |  |  |
| Software and Services | 1,312 |  |  | 1,210 |  |  | 8 | % |  |  |
| Total Motorola Solutions | $ | 3,273 |  |  | $ | 3,517 |  |  | (7) | % |  |  |
| Non-GAAP Operating Earnings |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 131 |  |  | $ | 242 |  |  | (46) | % |  |  |
| Software and Services | 228 |  |  | 202 |  |  | 13 | % |  |  |
| Total Motorola Solutions | $ | 359 |  |  | $ | 444 |  |  | (19) | % |  |  |
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |  |
| Products and Systems Integration | $ | 253 |  |  | $ | 389 |  |  | (35) | % |  |  |
| Software and Services | 452 |  |  | 370 |  |  | 22 | % |  |  |
| Total Motorola Solutions | $ | 705 |  |  | $ | 759 |  |  | (7) | % |  |  |

[0000068505-20-000018:8k_2_02:118]
| Non-GAAP Operating Earnings % |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  |  |  |  |
| Products and Systems Integration | 13.5 | % |  | 19.5 | % |  |  |  |  |
| Software and Services | 35.1 | % |  | 32.5 | % |  |  |  |  |
| Total Motorola Solutions | 22.2 | % |  | 23.9 | % |  |  |  |  |
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  |  |  |  |
| Products and Systems Integration | 12.9 | % |  | 16.9 | % |  |  |  |  |
| Software and Services | 34.5 | % |  | 30.6 | % |  |  |  |  |
| Total Motorola Solutions | 21.5 | % |  | 21.6 | % |  |  |  |  |

[0000068505-20-000018:8k_2_02:119]
Non-GAAP-3

[0000068505-20-000018:8k_2_02:120]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:121]
Operating Earnings after Non-GAAP Adjustments

[0000068505-20-000018:8k_2_02:122]
(In millions)

[0000068505-20-000018:8k_2_02:123]
| Q1 2020 |  |  |  |  |  |  |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,655 |  |  | $ | 993 |  |  | $ | 662 |  |
| Operating earnings ("OE") |  | $ | 259 |  |  | $ | 92 |  |  | $ | 167 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 53 |  |  | 12 |  |  | 41 |  |
| Share-based compensation expenses |  | 38 |  |  | 27 |  |  | 11 |  |
| Hytera-related legal expenses |  | 25 |  |  | 25 |  |  | — |  |
| Reorganization of business charges |  | 18 |  |  | 14 |  |  | 4 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 1 |  |  | 1 |  |
| Legal settlements |  | 2 |  |  | 2 |  |  | — |  |
| Gain on sale of property, plant, and equipment |  | (50) |  |  | (50) |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 88 |  |  | 31 |  |  | 57 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 347 |  |  | $ | 123 |  |  | $ | 224 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 15.6 | % |  | 9.3 | % |  | 25.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 21.0 | % |  | 12.4 | % |  | 33.8 | % |
| Q2 2020 |  |  |  |  |  |  |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,618 |  |  | $ | 968 |  |  | $ | 650 |  |
| Operating earnings ("OE") |  | $ | 218 |  |  | $ | 49 |  |  | $ | 169 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 51 |  |  | 12 |  |  | 39 |  |
| Reorganization of business charges |  | 41 |  |  | 33 |  |  | 8 |  |
| Share-based compensation expenses |  | 31 |  |  | 22 |  |  | 9 |  |
| Legal settlements |  | 7 |  |  | 7 |  |  | — |  |
| Hytera-related legal expenses |  | 5 |  |  | 5 |  |  | — |  |
| Fixed asset impairment |  | 5 |  |  | 3 |  |  | 2 |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 141 |  |  | 82 |  |  | 59 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 359 |  |  | $ | 131 |  |  | $ | 228 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 13.5 | % |  | 5.1 | % |  | 26.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 22.2 | % |  | 13.5 | % |  | 35.1 | % |

[0000068505-20-000018:8k_2_02:124]
Non-GAAP-4

[0000068505-20-000018:8k_2_02:125]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-20-000018:8k_2_02:126]
Non-GAAP Organic Revenue

[0000068505-20-000018:8k_2_02:127]
(In millions)

[0000068505-20-000018:8k_2_02:128]
|  |  | Three Months Ended |  |  |  |  |  |
|  |  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |
| Net sales |  | $ | 1,618 |  |  | $ | 1,860 |  |  | (13) | % |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Sales from acquisitions |  | 40 |  |  | — |  |  |  |  |
| Organic revenue |  | $ | 1,578 |  |  | $ | 1,860 |  |  | (15) | % |  |
|  |  | Six Months Ended |  |  |  |  |  |
|  |  | June 27, 2020 |  | June 29, 2019 |  | % Change |  |
| Net sales |  | $ | 3,273 |  |  | $ | 3,517 |  |  | (7) | % |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Sales from acquisitions |  | 91 |  |  | 3 |  |  |  |  |
| Organic revenue |  | $ | 3,182 |  |  | $ | 3,514 |  |  | (9) | % |  |
