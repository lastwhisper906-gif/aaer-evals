# MSI notes — 0000068505-20-000020


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-20-000020:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of June 27, 2020 and for the three and six months ended June 27, 2020 and June 29, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-20-000020:notes:2]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three and six months ended June 27, 2020 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-20-000020:notes:3]
[same as prior period, unchanged from 0000068505-20-000013:notes:3]

[0000068505-20-000020:notes:4]
Recent Acquisitions

[0000068505-20-000020:notes:5]
On July 31, 2020, the Company acquired Pelco, Inc., a global provider of video security solutions for $110 million in cash. The acquisition demonstrates Motorola Solutions’ continued investment in video security and analytics, adding to its existing video portfolio a broad range of products that can be used in a variety of commercial and industrial environments and use cases.  The business will be part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-20-000020:notes:6]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The business is a part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000020:notes:7]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired.  The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-20-000020:notes:8]
[same as prior period, unchanged from 0000068505-20-000013:notes:6]

[0000068505-20-000020:notes:9]
[same as prior period, unchanged from 0000068505-20-000013:notes:7]

[0000068505-20-000020:notes:10]
[same as prior period, unchanged from 0000068505-20-000013:notes:8]

[0000068505-20-000020:notes:11]
[same as prior period, unchanged from 0000068505-20-000013:notes:9]

[0000068505-20-000020:notes:12]
[same as prior period, unchanged from 0000068505-20-000013:notes:10]

[0000068505-20-000020:notes:13]
[same as prior period, unchanged from 0000068505-20-000013:notes:13]

[0000068505-20-000020:notes:14]
In December 2019, the FASB issued Accounting Standard Update ("ASU") No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company is still evaluating the impact of adoption on its disclosures.

[0000068505-20-000020:notes:15]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-20-000020:notes:16]
Recently Adopted Accounting Pronouncements

[0000068505-20-000020:notes:17]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.

[0000068505-20-000020:notes:18]
The Company considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets, and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (Direct and Indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact to the Company's financial statements.

[0000068505-20-000020:notes:19]
[same as prior period, unchanged from 0000068505-20-000013:notes:20]

[0000068505-20-000020:notes:20]
|  | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at June 27, 2020 |
| Allowance for credit losses | $ | 63 |  | $ | 24 |  | $ | (8) |  | $ | (2) |  | $ | 77 |  |

[0000068505-20-000020:notes:21]
[same as prior period, unchanged from 0000068505-20-000013:notes:22]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-20-000020:notes:22]
[same as prior period, unchanged from 0000068505-20-000013:notes:23]

[0000068505-20-000020:notes:23]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 27, 2020 and June 29, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of the Company's segments:

[0000068505-20-000020:notes:24]
|  | Three Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 719 |  |  | $ | 374 |  |  | $ | 911 |  |  | $ | 342 |  |
| International | 249 |  |  | 276 |  |  | 327 |  |  | 280 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 582 |  |  | $ | — |  |  | $ | 809 |  |  | $ | — |  |
| Systems and Systems Integration | 386 |  |  | — |  |  | 429 |  |  | — |  |
| Services | — |  |  | 484 |  |  | — |  |  | 469 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 153 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 634 |  |  | $ | 611 |  |  | $ | 771 |  |  | $ | 582 |  |
| Indirect | 334 |  |  | 39 |  |  | 467 |  |  | 40 |  |
|  | $ | 968 |  |  | $ | 650 |  |  | $ | 1,238 |  |  | $ | 622 |  |

[0000068505-20-000020:notes:25]
|  | Six Months Ended |  |  |  |  |  |  |
|  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 1,467 |  |  | $ | 742 |  |  | $ | 1,666 |  |  | $ | 662 |  |
| International | 494 |  |  | 570 |  |  | 641 |  |  | 548 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,202 |  |  | $ | — |  |  | $ | 1,495 |  |  | $ | — |  |
| Systems and Systems Integration | 759 |  |  | — |  |  | 812 |  |  | — |  |
| Services | — |  |  | 976 |  |  | — |  |  | 921 |  |
| Software | — |  |  | 336 |  |  | — |  |  | 289 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,275 |  |  | $ | 1,232 |  |  | $ | 1,429 |  |  | $ | 1,135 |  |
| Indirect | 686 |  |  | 80 |  |  | 878 |  |  | 75 |  |
|  | $ | 1,961 |  |  | $ | 1,312 |  |  | $ | 2,307 |  |  | $ | 1,210 |  |

[0000068505-20-000020:notes:26]
[same as prior period, unchanged from 0000068505-20-000013:notes:26]

[0000068505-20-000020:notes:27]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 27, 2020 is $6.6 billion. A total of $2.8 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion is from Software and Services performance obligations that are not yet satisfied as of June 27, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-20-000020:notes:28]
[same as prior period, unchanged from 0000068505-20-000013:notes:28]

[0000068505-20-000020:notes:29]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,134 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 937 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,294 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 263 |  |  | 274 |  |  |  |  |  |

[0000068505-20-000020:notes:30]
Revenue recognized during the three months ended June 27, 2020 which was previously included in Contract liabilities as of March 28, 2020 is $370 million, compared to $340 million of revenue recognized during the three months ended June 29, 2019 which was previously included in Contract liabilities as of March 30, 2019. Revenue recognized during the six months ended June 27, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $631 million, compared to $600 million of revenue recognized during the six months ended June 29, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $12 million and $34 million was reversed during the three and six months ended June 27, 2020 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. Adjustments to revenue for the three and six months ended June 29, 2019 driven by changes in the estimates of progress on system contracts were immaterial.

[0000068505-20-000020:notes:31]
There were no material expected credit losses recognized on contract assets during the three and six months ended June 27, 2020 and June 29, 2019.

[0000068505-20-000020:notes:32]
[same as prior period, unchanged from 0000068505-20-000013:notes:32]

[0000068505-20-000020:notes:33]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 22 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 101 |  |  | 107 |  |  |  |  |  |

[0000068505-20-000020:notes:34]
Amortization of non-current contract cost assets was $11 million and $22 million for both the three and six months ended June 27, 2020 and June 29, 2019, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-20-000020:notes:35]
Leases
The components of the Company's lease expense are as follows:

[0000068505-20-000020:notes:36]
|  |  |  |  | Three months ended |  |  |  | Six Months Ended |  |  |
| (in millions) |  |  |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Lease expense: |  |  |  |  |  |  |  |  |  |  |
| Operating lease cost |  |  |  | $ | 33 |  |  | $ | 33 |  |  | $ | 67 |  |  | $ | 65 |  |
| Finance lease cost |  |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  |  | 3 |  |  | 3 |  |  | 6 |  |  | 6 |  |
| Interest on lease liabilities |  |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total finance lease cost |  |  |  | 3 |  |  | 3 |  |  | 7 |  |  | 7 |  |
| Short-term lease cost |  |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |
| Variable cost |  |  |  | 9 |  |  | 8 |  |  | 17 |  |  | 17 |  |
| Sublease income |  |  |  | (1) |  |  | (1) |  |  | (2) |  |  | (2) |  |
| Net lease expense |  |  |  | $ | 45 |  |  | $ | 44 |  |  | $ | 90 |  |  | $ | 90 |  |

[0000068505-20-000020:notes:37]
Lease assets and liabilities consist of the following:

[0000068505-20-000020:notes:38]
| (in millions) |  | Statement Line Classification |  | June 27, 2020 |  | December 31, 2019 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 462 |  |  | $ | 554 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 31 |  |  | 41 |  |  |  |
|  |  |  |  | $ | 493 |  |  | $ | 595 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 123 |  |  | $ | 122 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 11 |  |  | 13 |  |  |  |
|  |  |  |  | $ | 134 |  |  | $ | 135 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 385 |  |  | $ | 497 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 9 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 394 |  |  | $ | 513 |  |  |  |

[0000068505-20-000020:notes:39]
For the three months ended June 27, 2020, the Company exercised a break option reducing the term of an International office lease by five years.  This resulted in a reduction to both the right of use ("ROU") asset and lease liabilities by approximately $47 million.

[0000068505-20-000020:notes:40]
Other information related to leases is as follows:

[0000068505-20-000020:notes:41]
|  | Six Months Ended |  |  |  |  |
| (in millions) | June 27, 2020 |  | June 29, 2019 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 84 |  |  | $ | 80 |  |  |  |
| Net cash used for operating activities related to finance leases | 1 |  |  | 1 |  |  |  |
| Net cash used for financing activities related to finance leases | 6 |  |  | 8 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 24 |  |  | $ | 45 |  |  |  |

[0000068505-20-000020:notes:42]
| (in millions) | June 27, 2020 |  | December 31, 2019 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 7 |
| Finance leases | 2 |  | 2 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.57 | % |  | 3.61 | % |
| Finance leases | 4.25 | % |  | 4.28 | % |

[0000068505-20-000020:notes:43]
Future lease payments as of June 27, 2020 are as follows:

[0000068505-20-000020:notes:44]
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2020 | $ | 61 |  |  | $ | 6 |  |  | $ | 67 |  |
| 2021 | 129 |  |  | 11 |  |  | 140 |  |
| 2022 | 113 |  |  | 4 |  |  | 117 |  |
| 2023 | 63 |  |  | 1 |  |  | 64 |  |
| 2024 | 52 |  |  | — |  |  | 52 |  |
| Thereafter | 154 |  |  | — |  |  | 154 |  |
| Total lease payments | 572 |  |  | 22 |  |  | 594 |  |
| Less: interest | 64 |  |  | 2 |  |  | 66 |  |
| Present value of lease liabilities | $ | 508 |  |  | $ | 20 |  |  | $ | 528 |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-20-000020:notes:45]
[same as prior period, unchanged from 0000068505-20-000013:notes:44]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-20-000020:notes:46]
[same as prior period, unchanged from 0000068505-20-000013:notes:45]

[0000068505-20-000020:notes:47]
[same as prior period, unchanged from 0000068505-20-000013:notes:46]

[0000068505-20-000020:notes:48]
[same as prior period, unchanged from 0000068505-20-000013:notes:47]

[0000068505-20-000020:notes:49]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 51 |  |  | $ | 52 |  |  | $ | 104 |  |  | $ | 102 |  |
| Reorganization of business (Note 14) | 26 |  |  | 8 |  |  | 38 |  |  | 12 |  |
| Loss on legal settlements | 7 |  |  | 1 |  |  | 9 |  |  | — |  |
| Fixed asset impairment | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Gain on sale of property, plant and equipment | — |  |  | — |  |  | (50) |  |  | — |  |
| Acquisition-related transaction fees | 1 |  |  | — |  |  | 3 |  |  | 2 |  |
|  | $ | 90 |  |  | $ | 61 |  |  | $ | 109 |  |  | $ | 116 |  |

[0000068505-20-000020:notes:50]
During the six months ended June 27, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe.  This gain has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-20-000020:notes:51]
[same as prior period, unchanged from 0000068505-20-000013:notes:50]

[0000068505-20-000020:notes:52]
[same as prior period, unchanged from 0000068505-20-000013:notes:51]

[0000068505-20-000020:notes:53]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (60) |  |  | $ | (59) |  |  | $ | (114) |  |  | $ | (119) |  |
| Interest income | 2 |  |  | 3 |  |  | 5 |  |  | 8 |  |
|  | $ | (58) |  |  | $ | (56) |  |  | $ | (109) |  |  | $ | (111) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 19 |  |  | $ | 17 |  |  | $ | 39 |  |  | $ | 33 |  |
| Loss from the extinguishment of long-term debt (Note 5) | — |  |  | (43) |  |  | — |  |  | (43) |  |
| Investment impairments | — |  |  | (3) |  |  | — |  |  | (11) |  |
| Foreign currency loss | (21) |  |  | (7) |  |  | (3) |  |  | (11) |  |
| Gain (loss) on derivative instruments | 12 |  |  | (3) |  |  | (4) |  |  | (7) |  |
| Gain on equity method investments | — |  |  | — |  |  | — |  |  | 1 |  |
| Fair value adjustments to equity investments | 4 |  |  | 16 |  |  | 5 |  |  | 15 |  |
| Other | 2 |  |  | 2 |  |  | (3) |  |  | 11 |  |
|  | $ | 16 |  |  | $ | (21) |  |  | $ | 34 |  |  | $ | (12) |  |

[0000068505-20-000020:notes:54]
During the three and six months ended June 29, 2019, the Company recorded investment impairment charges of $3 million and $11 million, representing other-than-temporary declines in the value in the Company's strategic investment portfolio. Investment impairment charges are included in Other within Other income (expense) in the Company’s Condensed Consolidated Statements of Operations.

[0000068505-20-000020:notes:55]
[same as prior period, unchanged from 0000068505-20-000013:notes:53]

[0000068505-20-000020:notes:56]
[same as prior period, unchanged from 0000068505-20-000013:notes:54]

[0000068505-20-000020:notes:57]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 135 |  |  | $ | 207 |  |  | $ | 332 |  |  | $ | 358 |  |
| Weighted average common shares outstanding | 170.0 |  |  | 164.9 |  |  | 170.3 |  |  | 164.4 |  |
| Per share amount | $ | 0.79 |  |  | $ | 1.25 |  |  | $ | 1.95 |  |  | $ | 2.18 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 135 |  |  | $ | 207 |  |  | $ | 332 |  |  | $ | 358 |  |
| Weighted average common shares outstanding | 170.0 |  |  | 164.9 |  |  | 170.3 |  |  | 164.4 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.6 |  |  | 4.6 |  |  | 4.5 |  |  | 4.7 |  |
| 2.00% senior convertible notes | — |  |  | 6.6 |  |  | — |  |  | 6.2 |  |
| 1.75% senior convertible notes | — |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 173.6 |  |  | 176.1 |  |  | 174.8 |  |  | 175.3 |  |
| Per share amount | $ | 0.78 |  |  | $ | 1.18 |  |  | $ | 1.90 |  |  | $ | 2.04 |  |

[0000068505-20-000020:notes:58]
For the three months ended June 27, 2020, the assumed exercise of 0.6 million options, including 0.2 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the six months ended June 27, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-20-000020:notes:59]
For the three and six months ended June 29, 2019, the assumed exercise of 0.5 million options, including 0.3 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-20-000020:notes:60]
As of June 27, 2020, the Company had  $1.0 billion of 1.75% senior convertible notes outstanding which mature in September 15, 2024 ("New Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the New Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the New Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. The conversion price is adjusted for dividends declared through the date of settlement. For the period ended June 27, 2020, there was no dilutive effect of the New Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price. See further discussion in Note 5.

[0000068505-20-000020:notes:61]
[same as prior period, unchanged from 0000068505-20-000013:notes:59]

[0000068505-20-000020:notes:62]
[same as prior period, unchanged from 0000068505-20-000013:notes:60]

[0000068505-20-000020:notes:63]
[same as prior period, unchanged from 0000068505-20-000013:notes:61]

[0000068505-20-000020:notes:64]
|  | June 27, 2020 |  | December 31, 2019 |
| Accounts receivable | $ | 1,211 |  |  | $ | 1,475 |  |
| Less allowance for credit losses | (77) |  |  | (63) |  |
|  | $ | 1,134 |  |  | $ | 1,412 |  |

[0000068505-20-000020:notes:65]
[same as prior period, unchanged from 0000068505-20-000013:notes:63]

[0000068505-20-000020:notes:66]
[same as prior period, unchanged from 0000068505-20-000013:notes:64]

[0000068505-20-000020:notes:67]
|  | June 27, 2020 |  | December 31, 2019 |
| Finished goods | $ | 226 |  |  | $ | 209 |  |
| Work-in-process and production materials | 355 |  |  | 374 |  |
|  | 581 |  |  | 583 |  |
| Less inventory reserves | (132) |  |  | (136) |  |
|  | $ | 449 |  |  | $ | 447 |  |

[0000068505-20-000020:notes:68]
[same as prior period, unchanged from 0000068505-20-000013:notes:66]

[0000068505-20-000020:notes:69]
[same as prior period, unchanged from 0000068505-20-000013:notes:67]

[0000068505-20-000020:notes:70]
|  | June 27, 2020 |  | December 31, 2019 |
| Current contract cost assets (Note 2) | $ | 22 |  |  | $ | 24 |  |
| Tax-related deposits | 48 |  |  | 77 |  |
| Other | 155 |  |  | 171 |  |
|  | $ | 225 |  |  | $ | 272 |  |

[0000068505-20-000020:notes:71]
[same as prior period, unchanged from 0000068505-20-000013:notes:69]

[0000068505-20-000020:notes:72]
[same as prior period, unchanged from 0000068505-20-000013:notes:70]

[0000068505-20-000020:notes:73]
|  | June 27, 2020 |  | December 31, 2019 |
| Land | $ | 6 |  |  | $ | 15 |  |
| Leasehold improvements | 403 |  |  | 410 |  |
| Machinery and equipment | 2,100 |  |  | 2,051 |  |
|  | 2,509 |  |  | 2,476 |  |
| Less accumulated depreciation | (1,544) |  |  | (1,484) |  |
|  | $ | 965 |  |  | $ | 992 |  |

[0000068505-20-000020:notes:74]
Depreciation expense for the three months ended June 27, 2020 and June 29, 2019 was $47 million and $44 million, respectively. Depreciation expense for the six months ended June 27, 2020 and June 29, 2019 was $93 million and $89 million, respectively.

[0000068505-20-000020:notes:75]
[same as prior period, unchanged from 0000068505-20-000013:notes:73]

[0000068505-20-000020:notes:76]
[same as prior period, unchanged from 0000068505-20-000013:notes:74]

[0000068505-20-000020:notes:77]
|  | June 27, 2020 |  | December 31, 2019 |  |  |  |  |
| Common stock | $ | 23 |  |  | $ | 25 |  |  |  |  |  |
| Strategic investments, at cost | 46 |  |  | 40 |  |  |  |  |  |
| Company-owned life insurance policies | 70 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 18 |  |  | 20 |  |  |  |  |  |
|  | $ | 157 |  |  | $ | 159 |  |  |  |  |  |

[0000068505-20-000020:notes:78]
Other Assets

[0000068505-20-000020:notes:79]
[same as prior period, unchanged from 0000068505-20-000013:notes:77]

[0000068505-20-000020:notes:80]
|  | June 27, 2020 |  | December 31, 2019 |
| Defined benefit plan assets | $ | 260 |  |  | $ | 223 |  |
| Non-current contract cost assets (Note 2) | 101 |  |  | 107 |  |
| Other | 56 |  |  | 92 |  |
|  | $ | 417 |  |  | $ | 422 |  |

[0000068505-20-000020:notes:81]
[same as prior period, unchanged from 0000068505-20-000013:notes:79]

[0000068505-20-000020:notes:82]
[same as prior period, unchanged from 0000068505-20-000013:notes:80]

[0000068505-20-000020:notes:83]
|  | June 27, 2020 |  | December 31, 2019 |
| Compensation | $ | 193 |  |  | $ | 347 |  |
| Tax liabilities | 72 |  |  | 95 |  |
| Dividend payable | 109 |  |  | 110 |  |
| Trade liabilities | 140 |  |  | 161 |  |
| Operating lease liabilities (Note 3) | 123 |  |  | 122 |  |
| Other | 534 |  |  | 521 |  |
|  | $ | 1,171 |  |  | $ | 1,356 |  |

[0000068505-20-000020:notes:84]
[same as prior period, unchanged from 0000068505-20-000013:notes:82]

[0000068505-20-000020:notes:85]
[same as prior period, unchanged from 0000068505-20-000013:notes:83]

[0000068505-20-000020:notes:86]
|  | June 27, 2020 |  | December 31, 2019 |
| Defined benefit plans | $ | 1,483 |  |  | $ | 1,524 |  |
| Non-current contract liabilities (Note 2) | 263 |  |  | 274 |  |
| Unrecognized tax benefits | 55 |  |  | 53 |  |
| Deferred income taxes | 175 |  |  | 184 |  |
| Other | 237 |  |  | 241 |  |
|  | $ | 2,213 |  |  | $ | 2,276 |  |

[0000068505-20-000020:notes:87]
[same as prior period, unchanged from 0000068505-20-000013:notes:85]

[0000068505-20-000020:notes:88]
Share Repurchase Program: During the three and six months ended June 27, 2020, the Company paid an aggregate of $83 million and $336 million, including transaction costs, to repurchase approximately 0.6 million and 2.2 million shares at an average price of $133.93 and $154.58 per share, respectively. As of June 27, 2020, the Company had $925 million of authority available for future repurchases.

[0000068505-20-000020:notes:89]
Payment of Dividends: During the three months ended June 27, 2020 and June 29, 2019, the Company paid $109 million and $94 million, respectively, in cash dividends to holders of its common stock. During the six months ended June 27, 2020 and June 29, 2019, the Company paid $218 million and $187 million, respectively, in cash dividends to holders of its common stock.

[0000068505-20-000020:notes:90]
[same as prior period, unchanged from 0000068505-20-000013:notes:88]

[0000068505-20-000020:notes:91]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended June 27, 2020 and June 29, 2019:

[0000068505-20-000020:notes:92]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (548) |  |  | $ | (414) |  |  | $ | (410) |  |  | $ | (444) |  |
| Other comprehensive income (loss) before reclassification adjustment | 75 |  |  | (24) |  |  | (61) |  |  | 10 |  |
| Tax benefit (expense) | 3 |  |  | 1 |  |  | 1 |  |  | (3) |  |
| Other comprehensive income (loss), net of tax | 78 |  |  | (23) |  |  | (60) |  |  | 7 |  |
| Balance at end of period | $ | (470) |  |  | $ | (437) |  |  | $ | (470) |  |  | $ | (437) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,018) |  |  | $ | (2,310) |  |  | $ | (2,030) |  |  | $ | (2,321) |  |
| Reclassification adjustment - Actuarial net losses into Other income | 19 |  |  | 17 |  |  | 38 |  |  | 33 |  |
| Reclassification adjustment - Prior service benefits into Other expense | (4) |  |  | (4) |  |  | (8) |  |  | (7) |  |
| Tax expense | (2) |  |  | (3) |  |  | (5) |  |  | (5) |  |
| Other comprehensive income, net of tax | 13 |  |  | 10 |  |  | 25 |  |  | 21 |  |
| Balance at end of period | $ | (2,005) |  |  | $ | (2,300) |  |  | $ | (2,005) |  |  | $ | (2,300) |  |
| Total Accumulated other comprehensive loss | $ | (2,475) |  |  | $ | (2,737) |  |  | $ | (2,475) |  |  | $ | (2,737) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-20-000020:notes:93]
Debt and Credit Facilities
As of June 27, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020, of which $300 million was repaid during the three months ended June 27, 2020. As of June 27, 2020, the outstanding loan amount was $500 million.  Subsequent to the quarter, the company repaid an additional $200 million. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 27, 2020 were 1.69% and 1.79%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 27, 2020.

[0000068505-20-000020:notes:94]
As of June 27, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140, as may be adjusted for dividends declared, per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). The exercise price adjusts automatically for dividends. In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
The Company has an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 27, 2020 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-20-000020:notes:95]
[same as prior period, unchanged from 0000068505-20-000013:notes:95]

[0000068505-20-000020:notes:96]
As of June 27, 2020, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.0 billion, compared to $1.1 billion outstanding at December 31, 2019. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-20-000020:notes:97]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of June 27, 2020, and the corresponding positions as of December 31, 2019:

[0000068505-20-000020:notes:98]
|  | Notional Amount |  |  |
| Net Buy (Sell) by Currency | June 27, 2020 |  | December 31, 2019 |
| Euro | $ | 213 |  |  | $ | 134 |  |
| British Pound | 100 |  |  | 107 |  |
| Danish Krone | 27 |  |  | 18 |  |
| Australian dollar | (110) |  |  | (123) |  |
| Chinese renminbi | (68) |  |  | (79) |  |

[0000068505-20-000020:notes:99]
[same as prior period, unchanged from 0000068505-20-000013:notes:99]

[0000068505-20-000020:notes:100]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of June 27, 2020, all of the counterparties have investment grade credit ratings. As of June 27, 2020, the Company had $9 million of exposure to aggregate credit risk with all counterparties.

[0000068505-20-000020:notes:101]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of June 27, 2020 and December 31, 2019:

[0000068505-20-000020:notes:102]
|  | Fair Values of Derivative Instruments |  |  |  |  |
| June 27, 2020 | Other Current Assets |  |  |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange contracts | 6 |  |  |  |  | 3 |  |
| Total derivatives | $ | 9 |  |  |  |  | $ | 3 |  |

[0000068505-20-000020:notes:103]
|  | Fair Values of Derivative Instruments |  |  |  |  |
| December 31, 2019 | Other Current Assets |  |  |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange contracts | 1 |  |  |  |  | 5 |  |
| Total derivatives | $ | 4 |  |  |  |  | $ | 5 |  |

[0000068505-20-000020:notes:104]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended June 27, 2020 and June 29, 2019:

[0000068505-20-000020:notes:105]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |  | Financial Statement Location |
| Foreign Exchange Contracts | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |  |  |
| Effective portion | $ | (11) |  |  | $ | 6 |  |  | $ | 8 |  |  | $ | 8 |  |  | Accumulated othercomprehensive income |
| Forward points recognized | 1 |  |  | 2 |  |  | 2 |  |  | 3 |  |  | Other income |
| Undesignated derivatives recognized | 12 |  |  | (3) |  |  | (4) |  |  | (7) |  |  | Other expense |

[0000068505-20-000020:notes:106]
[same as prior period, unchanged from 0000068505-20-000013:notes:106]

[0000068505-20-000020:notes:107]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. As of June 27, 2020, the Company had €94 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-20-000020:notes:108]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense.  During the three and six months ended June 27, 2020, the Company amortized $1 million, and $2 million, respectively, of income from the excluded components through interest expense. During the three and six months ended June 29, 2019, the Company amortized $2 million, and $3 million, respectively, of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-20-000020:notes:109]
[same as prior period, unchanged from 0000068505-20-000013:notes:108]

[0000068505-20-000020:notes:110]
[same as prior period, unchanged from 0000068505-20-000013:notes:109]

[0000068505-20-000020:notes:111]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Net earnings before income taxes | $ | 176 |  |  | $ | 275 |  |  | $ | 401 |  |  | $ | 460 |  |
| Income tax expense | 40 |  |  | 67 |  |  | 67 |  |  | 100 |  |
| Effective tax rate | 23 | % |  | 24 | % |  | 17 | % |  | 22 | % |

[0000068505-20-000020:notes:112]
During the three and six months ended June 27, 2020, the Company recorded $40 million and $67 million of net tax expense, resulting in an effective tax rate of 23% and 17%, respectively. During the three and six months ended June 29, 2019, the Company recorded $67 million and $100 million of net tax expense, resulting in an effective tax rate of 24% and 22%, respectively. The three months ended June 27, 2020 and June 29, 2019 effective tax rates are different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset primarily by tax benefits related to a stock compensation adjustment.  The six months ended June 27, 2020 and June 29, 2019 effective tax rates are different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset by excess tax benefits on share-based compensation. The effective tax rate for the three months ended June 27, 2020 of 23% is lower than the effective tax rate for the three months ended June 29, 2019 of 24%, primarily due to an increased benefit of forecasted research and experimental development investment tax credit in the annual effective tax rate. The effective tax rate for the six months ended June 27, 2020 of 17% is lower than the effective tax rate for the six months ended June 29, 2019 of 22%, primarily due to higher excess tax benefits on share-based compensation.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-20-000020:notes:113]
[same as prior period, unchanged from 0000068505-20-000013:notes:112]

[0000068505-20-000020:notes:114]
[same as prior period, unchanged from 0000068505-20-000013:notes:113]

[0000068505-20-000020:notes:115]
|  | U.S. Pension Benefit Plans |  |  |  | Non-U.S. Pension Benefit Plans |  |  |  | Postretirement Health Care Benefits Plan |  |  |
| Three Months Ended | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 36 |  |  | 51 |  |  | 7 |  |  | 10 |  |  | — |  |  | 1 |  |
| Expected return on plan assets | (56) |  |  | (69) |  |  | (20) |  |  | (21) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 12 |  |  | 3 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | — |  |  | (3) |  |  | (4) |  |
| Net periodic pension benefits | $ | (5) |  |  | $ | (6) |  |  | $ | (10) |  |  | $ | (6) |  |  | $ | (5) |  |  | $ | (5) |  |

[0000068505-20-000020:notes:116]
|  | U.S. Pension Benefit Plans |  |  |  | Non-U.S. Pension Benefit Plans |  |  |  | Postretirement Health Care Benefits Plan |  |  |
| Six Months Ended | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 72 |  |  | 102 |  |  | 14 |  |  | 20 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (112) |  |  | (138) |  |  | (42) |  |  | (42) |  |  | (5) |  |  | (5) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 29 |  |  | 23 |  |  | 7 |  |  | 8 |  |  | 2 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | — |  |  | (7) |  |  | (7) |  |
| Net periodic pension benefits | $ | (11) |  |  | $ | (13) |  |  | $ | (21) |  |  | $ | (12) |  |  | $ | (9) |  |  | $ | (9) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-20-000020:notes:117]
[same as prior period, unchanged from 0000068505-20-000013:notes:115]

[0000068505-20-000020:notes:118]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 4 |  |  | $ | 3 |  |  | $ | 9 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 18 |  |  | 15 |  |  | 39 |  |  | 31 |  |
| Research and development expenditures | 9 |  |  | 12 |  |  | 21 |  |  | 19 |  |
| Share-based compensation expense included in Operating earnings | 31 |  |  | 30 |  |  | 69 |  |  | 57 |  |
| Tax benefit | (5) |  |  | (5) |  |  | (11) |  |  | (10) |  |
| Share-based compensation expense, net of tax | $ | 26 |  |  | $ | 25 |  |  | $ | 58 |  |  | $ | 47 |  |
| Decrease in basic earnings per share | $ | (0.15) |  |  | $ | (0.15) |  |  | $ | (0.34) |  |  | $ | (0.29) |  |
| Decrease in diluted earnings per share | $ | (0.15) |  |  | $ | (0.14) |  |  | $ | (0.33) |  |  | $ | (0.27) |  |

[0000068505-20-000020:notes:119]
During the six months ended June 27, 2020, the Company granted 0.4 million restricted stock units ("RSUs"), 0.03 million performance stock units ("PSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $51 million, $7 million, and $9 million, respectively, and 0.1 million stock options and 0.1 million performance options ("POs") with an aggregate grant-date fair value of $6 million and $9 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-20-000020:notes:120]
During the six months ended June 27, 2020, the Company granted 0.03 million shares of restricted stock in connection with the acquisition of a cybersecurity services business, for an aggregate grant-date fair value of $6 million related to compensation withheld from the purchase prices that will be expensed over an average service period of two years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-20-000020:notes:121]
Fair Value Measurements
The Company may hold certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-20-000020:notes:122]
[same as prior period, unchanged from 0000068505-20-000013:notes:119]

[0000068505-20-000020:notes:123]
[same as prior period, unchanged from 0000068505-20-000013:notes:120]

[0000068505-20-000020:notes:124]
[same as prior period, unchanged from 0000068505-20-000013:notes:121]

[0000068505-20-000020:notes:125]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of June 27, 2020 and December 31, 2019 were as follows:

[0000068505-20-000020:notes:126]
| June 27, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |
| Common stock | 23 |  |  | — |  |  |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 3 |  |  |  |  | $ | 3 |  |

[0000068505-20-000020:notes:127]
[same as prior period, unchanged from 0000068505-20-000013:notes:124]

[0000068505-20-000020:notes:128]
The Company had no Level 3 holdings as of June 27, 2020 or December 31, 2019.

[0000068505-20-000020:notes:129]
At June 27, 2020 and December 31, 2019, the Company had $520 million and $322 million, respectively, of investments in money market U.S. treasury and government funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-20-000020:notes:130]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at June 27, 2020 and December 31, 2019 was $6.1 billion and $5.5 billion (Level 2), respectively.

[0000068505-20-000020:notes:131]
[same as prior period, unchanged from 0000068505-20-000013:notes:128]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-20-000020:notes:132]
[same as prior period, unchanged from 0000068505-20-000013:notes:129]

[0000068505-20-000020:notes:133]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended June 27, 2020 and June 29, 2019:

[0000068505-20-000020:notes:134]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Accounts receivable sales proceeds | $ | 88 |  |  | $ | 3 |  |  | $ | 156 |  |  | $ | 27 |  |
| Long-term receivables sales proceeds | 29 |  |  | 55 |  |  | 70 |  |  | 76 |  |
| Total proceeds from receivable sales | $ | 117 |  |  | $ | 58 |  |  | $ | 226 |  |  | $ | 103 |  |

[0000068505-20-000020:notes:135]
At June 27, 2020, the Company had retained servicing obligations for $990 million of long-term receivables, compared to $984 million at December 31, 2019. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $88 million at June 27, 2020, compared to $78 million at December 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-20-000020:notes:136]
Commitments and Contingencies
Legal Matters

[0000068505-20-000020:notes:137]
As previously disclosed, on February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in it's trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million.  A motion for a new trial was filed by Hytera during the second quarter of 2020. In addition, during the second quarter of 2020 Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection; subsequent to the end of the second quarter, the Company filed motions to dismiss the bankruptcy proceedings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-20-000020:notes:138]
[same as prior period, unchanged from 0000068505-20-000013:notes:134]

[0000068505-20-000020:notes:139]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Products and Systems Integration | $ | 968 |  |  | $ | 1,238 |  |  | $ | 1,961 |  |  | $ | 2,307 |  |
| Software and Services | 650 |  |  | 622 |  |  | 1,312 |  |  | 1,210 |  |
|  | $ | 1,618 |  |  | $ | 1,860 |  |  | $ | 3,273 |  |  | $ | 3,517 |  |

[0000068505-20-000020:notes:140]
[same as prior period, unchanged from 0000068505-20-000013:notes:136]

[0000068505-20-000020:notes:141]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Products and Systems Integration | $ | 49 |  |  | $ | 201 |  |  | $ | 141 |  |  | $ | 310 |  |
| Software and Services | 169 |  |  | 148 |  |  | 335 |  |  | 269 |  |
| Operating earnings | 218 |  |  | 349 |  |  | 476 |  |  | 579 |  |
| Total other expense | (42) |  |  | (74) |  |  | (75) |  |  | (119) |  |
| Earnings before income taxes | $ | 176 |  |  | $ | 275 |  |  | $ | 401 |  |  | $ | 460 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-20-000020:notes:142]
Reorganization of Business
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits. In addition to the Involuntary Severance Plan, during the quarter ended June 27, 2020, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at six months of salary, were equalized for all employment level grades and capped at a full year’s salary.

[0000068505-20-000020:notes:143]
2020 Charges

[0000068505-20-000020:notes:144]
During the three months ended June 27, 2020, the Company recorded net reorganization of business charges of $41 million including $26 million of charges in Other charges and $15 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $41 million were charges of $46 million related to employee separation, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-20-000020:notes:145]
During the six months ended June 27, 2020, the Company recorded net reorganization of business charges of $59 million including $38 million of charges in Other charges and $21 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $59 million were charges of $68 million related to employee separation, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-20-000020:notes:146]
[same as prior period, unchanged from 0000068505-20-000013:notes:140]

[0000068505-20-000020:notes:147]
| June 27, 2020 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 33 |  |  | $ | 47 |  |
| Software and Services | 8 |  |  | 12 |  |
|  | $ | 41 |  |  | $ | 59 |  |

[0000068505-20-000020:notes:148]
The following table displays a rollforward of the reorganization of business accruals established for employee separation costs from January 1, 2020 to June 27, 2020:

[0000068505-20-000020:notes:149]
|  | January 1, 2020 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | June 27, 2020 |
| Employee separation costs | $ | 78 |  |  | $ | 68 |  |  | $ | (9) |  |  | $ | (41) |  |  | $ | 96 |  |

[0000068505-20-000020:notes:150]
[same as prior period, unchanged from 0000068505-20-000013:notes:144]

[0000068505-20-000020:notes:151]
At January 1, 2020, the Company had an accrual of $78 million for employee separation costs. The 2020 additional charges of $68 million represent severance costs for approximately 700 employees. The adjustment of $9 million reflects reversals for accruals no longer needed. The $41 million used reflects cash payments to severed employees. The remaining accrual of $96 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at June 27, 2020, is expected to be paid, primarily within one year, to approximately 1,100 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-20-000020:notes:152]
[same as prior period, unchanged from 0000068505-20-000013:notes:146]

[0000068505-20-000020:notes:153]
During the three months ended June 29, 2019, the Company recorded net reorganization of business charges of $12 million including $8 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $12 million were charges of $18 million related to employee separation costs and $6 million of reversals for accruals no longer needed.

[0000068505-20-000020:notes:154]
During the six months ended June 29, 2019, the Company recorded net reorganization of business charges of $20 million including $12 million of charges in Other charges and $8 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $20 million were charges of $30 million related to employee separation costs and $10 million of reversals for accruals no longer needed.

[0000068505-20-000020:notes:155]
| June 29, 2019 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 9 |  |  | $ | 16 |  |
| Software and Services | 3 |  |  | 4 |  |
|  | $ | 12 |  |  | $ | 20 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-20-000020:notes:156]
Intangible Assets and Goodwill
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The Company recognized $14 million of goodwill, $22 million of identifiable intangible assets, and $1 million of net liabilities.  The goodwill is not deductable for tax purposes.  The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting is not yet complete and as such the final allocation between income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-20-000020:notes:157]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The Company recognized $23 million of goodwill, $10 million of identifiable intangible assets and $1 million of net liabilities.  The goodwill is deductable for tax purposes.  The identifiable intangible assets were classified as $8 million of customer relationships and $2 million of developed technology that will be amortized over a period of twelve years and three years, respectively.  The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.  The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000020:notes:158]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The Company recognized $28 million of goodwill, $7 million of intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000020:notes:159]
[same as prior period, unchanged from 0000068505-20-000013:notes:150]

[0000068505-20-000020:notes:160]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's video security solutions platform. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $156 million of goodwill, $63 million of identifiable intangible assets, and $31 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of completed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000020:notes:161]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Software and Services segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible

[0000068505-20-000020:notes:162]
assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of 15 years. The purchase accounting was completed as of the third quarter of 2019.

[0000068505-20-000020:notes:163]
[same as prior period, unchanged from 0000068505-20-000013:notes:153]

[0000068505-20-000020:notes:164]
[same as prior period, unchanged from 0000068505-20-000013:notes:154]

[0000068505-20-000020:notes:165]
[same as prior period, unchanged from 0000068505-20-000013:notes:155]

[0000068505-20-000020:notes:166]
|  | June 27, 2020 |  |  |  | December 31, 2019 |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 740 |  |  | $ | 177 |  |  | $ | 738 |  |  | $ | 148 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,217 |  |  | 565 |  |  | 1,222 |  |  | 518 |  |
| Other intangibles | 73 |  |  | 46 |  |  | 75 |  |  | 42 |  |
|  | $ | 2,032 |  |  | $ | 790 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-20-000020:notes:167]
Amortization expense on intangible assets was $51 million and $104 million for the three and six months ended June 27, 2020, respectively.  Amortization expense on intangible assets was $52 million and $102 million for the three and six months ended June 29, 2019, respectively.  As of June 27, 2020, annual amortization expense is estimated to be $207 million in 2020, $206 million 2021, $203 million in 2022, $107 million in 2023, $83 million in 2024, and $73 million in 2025.

[0000068505-20-000020:notes:168]
[same as prior period, unchanged from 0000068505-20-000013:notes:158]

[0000068505-20-000020:notes:169]
|  | June 27, 2020 |  |  |  | December 31, 2019 |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 653 |  |  | $ | 105 |  |  | $ | 652 |  |  | $ | 82 |  |
| Software and Services | 1,379 |  |  | 685 |  |  | 1,385 |  |  | 628 |  |
|  | $ | 2,032 |  |  | $ | 790 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-20-000020:notes:170]
[same as prior period, unchanged from 0000068505-20-000013:notes:160]

[0000068505-20-000020:notes:171]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2020 to June 27, 2020:

[0000068505-20-000020:notes:172]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2020 | $ | 973 |  |  | $ | 1,094 |  |  | $ | 2,067 |  |
| Goodwill acquired | 11 |  |  | 54 |  |  | 65 |  |
| Foreign currency | — |  |  | (9) |  |  | (9) |  |
| Balance as of June 27, 2020 | $ | 984 |  |  | $ | 1,139 |  |  | $ | 2,123 |  |
