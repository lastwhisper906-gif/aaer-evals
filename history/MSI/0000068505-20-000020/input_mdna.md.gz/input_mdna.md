# MSI MD&A — 0000068505-20-000020


## mdna

[0000068505-20-000020:mdna:1]
[same as prior period, unchanged from 0000068505-20-000013:mdna:1]

[0000068505-20-000020:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended June 27, 2020 and June 29, 2019, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2019.

[0000068505-20-000020:mdna:3]
[same as prior period, unchanged from 0000068505-20-000013:mdna:3]

[0000068505-20-000020:mdna:4]
Second Quarter Financial Results

[0000068505-20-000020:mdna:5]
•Net sales were $1.6 billion in the second quarter of 2020 compared to $1.9 billion in the second quarter of 2019.

[0000068505-20-000020:mdna:6]
•Operating earnings were $218 million in the second quarter of 2020 compared to $349 million in the second quarter of 2019.

[0000068505-20-000020:mdna:7]
•Net earnings attributable to Motorola Solutions, Inc. were $135 million, or $0.78 per diluted common share, in the second quarter of 2020, compared to $207 million, or $1.18 per diluted common share, in the second quarter of 2019.

[0000068505-20-000020:mdna:8]
•Our operating cash flow increased $15 million to $517 million in the first half of 2020 compared to the first half of 2019.

[0000068505-20-000020:mdna:9]
•We repurchased $336 million of common stock and paid $218 million in dividends in the first half of 2020.

[0000068505-20-000020:mdna:10]
[same as prior period, unchanged from 0000068505-20-000013:mdna:10]

[0000068505-20-000020:mdna:11]
In March 2020, the COVID-19 outbreak was declared a pandemic by the World Health Organization (“WHO”). In response, there have been a broad number of governmental and commercial actions including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns in an effort to limit the spread of COVID-19. These events have resulted in a significant decline in global economic activity, and accordingly, we have assessed the impact on our employees, customers, communities, liquidity and financial position.

[0000068505-20-000020:mdna:12]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including having office workers work remotely, suspending employee travel, withdrawing from certain industry events, increased cleaning, encouraging face coverings and using thermal scanning. We have continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service our mission-critical networks on-site as needed to ensure seamless operations. The Sales teams’ virtual engagement with our customers has improved in the second quarter and is expected to continue throughout the second half of 2020. Additionally, our engineering teams have adapted our solutions offerings to equip our customers with the latest technology in the fight to protect their workplace from the spread of COVID-19. Specifically, in our video security business, we have adapted our software and hardware offerings to provide analytics over occupancy counting, facemask detection, and thermal detection capabilities.

[0000068505-20-000020:mdna:13]
We have assessed the adequacy of our liquidity as of the second quarter of 2020 and believe the measures taken over the past few years and months allow us the ability to operate under the current conditions. During the first quarter of 2020, we proactively withdrew $800 million from our unsecured revolving credit facility, of which $300 million was repaid during the quarter and $200 million was repaid subsequent to the quarter. This leaves $1.9 billion of capacity on the committed facility. Additionally, we have no bond maturities until 2022.

[0000068505-20-000020:mdna:14]
We continue to evaluate our financial position during this economic slowdown. Specifically, in our Software and Services segment, with the largely recurring nature of the business and strong backlog position, we expect that the impacts should be somewhat limited on revenue and operating margin. In our Products and Systems Integration segment, the impacts on revenue and operating margin are likely to be more significant with the largest impact expected during the second quarter of 2020. Reduced demand, particularly in our professional commercial radio business (“PCR”), as well as delays in engagements with our state and local customers in the near term, will most likely lead to year-over-year sales declines for the segment in 2020, as compared to 2019. Within the Products and Systems Integration segment, we are encouraged by the resiliency of the video security Device business and expect growth for fiscal year 2020. We have also taken actions in a number of areas to reduce our operating expenses, mostly driven by lower variable compensation, travel costs, contractor spend and reduced real estate footprint to limit the negative effect on operating margins for the year despite the expected reduction of revenue. In addition, our supply chain partners have been supportive and continue to do their part to ensure that service levels to the company and its customers remain fulfilled.

[0000068505-20-000020:mdna:15]
Lastly, we evaluated whether there were any impairment indicators as of June 27, 2020, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. We concluded that as of the end of the second quarter of 2020, our assets were fairly stated and recoverable.

[0000068505-20-000020:mdna:16]
[same as prior period, unchanged from 0000068505-20-000013:mdna:18]

[0000068505-20-000020:mdna:17]
On July 31, 2020, we acquired Pelco, Inc., a global provider of video security solutions for $110 million in cash. The acquisition demonstrates our continued investment in video security and analytics, adding to our existing video portfolio a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business will be part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-20-000020:mdna:18]
On June 16, 2020 we acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements our video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The business is a part of both the Product and System Integration segment and the Software and Services segment.

[0000068505-20-000020:mdna:19]
On April 30, 2020, we acquired a cybersecurity services business for $32 million of cash, net of cash acquired.  The acquisition expands our ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-20-000020:mdna:20]
[same as prior period, unchanged from 0000068505-20-000013:mdna:21]

[0000068505-20-000020:mdna:21]
[same as prior period, unchanged from 0000068505-20-000013:mdna:22]

[0000068505-20-000020:mdna:22]
[same as prior period, unchanged from 0000068505-20-000013:mdna:23]

[0000068505-20-000020:mdna:23]
[same as prior period, unchanged from 0000068505-20-000013:mdna:24]

[0000068505-20-000020:mdna:24]
[same as prior period, unchanged from 0000068505-20-000013:mdna:25]

[0000068505-20-000020:mdna:25]
[same as prior period, unchanged from 0000068505-20-000013:mdna:30]

[0000068505-20-000020:mdna:26]
A summary of our segment results for the second quarter of 2020 is as follows:

[0000068505-20-000020:mdna:27]
•In the Products and Systems Integration segment, net sales were $968 million in the second quarter of 2020, a decrease of $270 million, or 22%, compared to $1.2 billion in the second quarter of 2019. On a geographic basis, net sales decreased in both the North America and International regions compared to the year-ago quarter primarily driven by lower PCR and public safety land mobile radio ("LMR") sales. Operating earnings were $49 million in the second quarter of 2020, compared to $201 million in the second quarter of 2019. Operating margins decreased in 2020 to 5.1% from 16.2% in 2019 primarily driven by lower sales and partially offset by lower operating expenses primarily driven by lower employee incentive costs, indirect expenses and travel expenses.  The overall reduction in operating expenses was offset by: i) $24 million higher reorganization of business charges, ii) $6 million higher legal settlements, iii) $3 million higher share-based compensation expenses, and iv) higher operating expenses from acquisitions.

[0000068505-20-000020:mdna:28]
•In the Software and Services segment, net sales were $650 million in the second quarter of 2020, an increase of $28 million, or 5%, compared to net sales of $622 million in the second quarter of 2019. On a geographic basis, net sales increased in the North America region partially offset by a decrease in the International region compared to the year-ago quarter. Operating earnings were $169 million in the second quarter of 2020, compared to $148 million in the second quarter of 2019. Operating margins increased in 2020 to 26.0% from 23.8% in 2019 driven by higher sales, gross margin expansion, and reduced operating expenses primarily driven by lower employee incentive costs and travel expenses. The overall reduction in operating expenses was offset by: i) $5 million higher reorganization of business charges and ii) higher operating expenses from acquisitions.

[0000068505-20-000020:mdna:29]
[same as prior period, unchanged from 0000068505-20-000013:mdna:35]

[0000068505-20-000020:mdna:30]
|  | Three Months Ended |  |  |  |  |  |  |  | Six Months Ended |  |  |  |  |  |  |
| (Dollars in millions, except per share amounts) | June 27, 2020 |  | % ofSales* |  | June 29, 2019 |  | % ofSales* |  | June 27, 2020 |  | % ofSales* |  | June 29, 2019 |  | % ofSales* |
| Net sales from products | $ | 877 |  |  |  |  | $ | 1,118 |  |  |  |  | $ | 1,764 |  |  |  |  | $ | 2,063 |  |  |  |
| Net sales from services | 741 |  |  |  |  | 742 |  |  |  |  | 1,509 |  |  |  |  | 1,454 |  |  |  |
| Net sales | 1,618 |  |  |  |  | 1,860 |  |  |  |  | 3,273 |  |  |  |  | 3,517 |  |  |  |
| Costs of products sales | 413 |  |  | 47.1 | % |  | 490 |  |  | 43.8 | % |  | 812 |  |  | 46.0 | % |  | 934 |  |  | 45.3 | % |
| Costs of services sales | 439 |  |  | 59.2 | % |  | 439 |  |  | 59.2 | % |  | 908 |  |  | 60.2 | % |  | 879 |  |  | 60.5 | % |
| Costs of sales | 852 |  |  |  |  | 929 |  |  |  |  | 1,720 |  |  |  |  | 1,813 |  |  |  |
| Gross margin | 766 |  |  | 47.3 | % |  | 931 |  |  | 50.1 | % |  | 1,553 |  |  | 47.4 | % |  | 1,704 |  |  | 48.5 | % |
| Selling, general and administrative expenses | 297 |  |  | 18.4 | % |  | 351 |  |  | 18.9 | % |  | 638 |  |  | 19.5 | % |  | 676 |  |  | 19.2 | % |
| Research and development expenditures | 161 |  |  | 10.0 | % |  | 170 |  |  | 9.1 | % |  | 330 |  |  | 10.1 | % |  | 333 |  |  | 9.5 | % |
| Other charges | 90 |  |  | 5.6 | % |  | 61 |  |  | 3.3 | % |  | 109 |  |  | 3.3 | % |  | 116 |  |  | 3.3 | % |
| Operating earnings | 218 |  |  | 13.5 | % |  | 349 |  |  | 18.8 | % |  | 476 |  |  | 14.5 | % |  | 579 |  |  | 16.5 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (58) |  |  | (3.6) | % |  | (56) |  |  | (3.0) | % |  | (109) |  |  | (3.3) | % |  | (111) |  |  | (3.2) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | 3 |  |  | 0.2 | % |  | — |  |  | — | % |  | 4 |  |  | 0.1 | % |
| Other, net | 16 |  |  | 1.0 | % |  | (21) |  |  | (1.1) | % |  | 34 |  |  | 1.0 | % |  | (12) |  |  | (0.3) | % |
| Total other expense | (42) |  |  | (2.6) | % |  | (74) |  |  | (4.0) | % |  | (75) |  |  | (2.3) | % |  | (119) |  |  | (3.4) | % |
| Net earnings before income taxes | 176 |  |  | 10.9 | % |  | 275 |  |  | 14.8 | % |  | 401 |  |  | 12.3 | % |  | 460 |  |  | 13.1 | % |
| Income tax expense | 40 |  |  | 2.5 | % |  | 67 |  |  | 3.6 | % |  | 67 |  |  | 2.0 | % |  | 100 |  |  | 2.8 | % |
| Net earnings | 136 |  |  | 8.4 | % |  | 208 |  |  | 11.2 | % |  | 334 |  |  | 10.2 | % |  | 360 |  |  | 10.2 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 135 |  |  | 8.3 | % |  | $ | 207 |  |  | 11.1 | % |  | $ | 332 |  |  | 10.1 | % |  | $ | 358 |  |  | 10.2 | % |
| Earnings per diluted common share | $ | 0.78 |  |  |  |  | $ | 1.18 |  |  |  |  | $ | 1.90 |  |  |  |  | $ | 2.04 |  |  |  |

[0000068505-20-000020:mdna:31]
[same as prior period, unchanged from 0000068505-20-000013:mdna:37]

[0000068505-20-000020:mdna:32]
27

[0000068505-20-000020:mdna:33]
Results of Operations—Three months ended June 27, 2020 compared to three months ended June 29, 2019

[0000068505-20-000020:mdna:34]
The results of operations for the second quarter of 2020 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-20-000020:mdna:35]
[same as prior period, unchanged from 0000068505-20-000013:mdna:41]

[0000068505-20-000020:mdna:36]
|  | Three Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 968 |  |  | $ | 1,238 |  |  | (22) | % |
| Net sales from Software and Services | 650 |  |  | 622 |  |  | 5 | % |
| Net sales | $ | 1,618 |  |  | $ | 1,860 |  |  | (13) | % |

[0000068505-20-000020:mdna:37]
The Products and Systems Integration segment’s net sales represented 60% of our consolidated net sales in the second quarter of 2020 and 67% in the second quarter of 2019. The Software and Services segment’s net sales represented 40% of our consolidated net sales in the second quarter of 2020 and 33% in the second quarter of 2019.

[0000068505-20-000020:mdna:38]
Net sales decreased in the second quarter of 2020 compared to the second quarter of 2019. The 22% decline in sales within the Products and Systems Integration segment was driven by a 24% decline in the International region and a 21% decline in the North America region. The 5% increase in sales within the Software and Services segment was driven by a 9% increase in the North America region and partially offset by a 2% decrease in the International region. Net sales includes:

[0000068505-20-000020:mdna:39]
•a decline in the Products and System Integration segment, inclusive of acquisitions, driven by a decline in PCR and public safety LMR, partially offset by growth in video security;

[0000068505-20-000020:mdna:40]
•$30 million from unfavorable currency rates;

[0000068505-20-000020:mdna:41]
•partially offset by $40 million of revenue from acquisitions; and

[0000068505-20-000020:mdna:42]
•growth in Software and Services driven by services in North America and software sales, inclusive of acquisitions.

[0000068505-20-000020:mdna:43]
[same as prior period, unchanged from 0000068505-20-000013:mdna:49]

[0000068505-20-000020:mdna:44]
•a decrease in the North America region of 13% driven by a decline in the Products and System Integration segment, partially offset by growth in the Software and Services segment, inclusive of revenue from acquisitions; and

[0000068505-20-000020:mdna:45]
•a decrease in the International region of 14% driven by a decline in sales in both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-20-000020:mdna:46]
[same as prior period, unchanged from 0000068505-20-000013:mdna:52]

[0000068505-20-000020:mdna:47]
The 22% decrease in the Products and Systems Integration segment was driven by the following:

[0000068505-20-000020:mdna:48]
•28% decline in Devices revenue, primarily driven by a decline in PCR and public safety LMR in both the International and North America regions, inclusive of revenue from acquisitions;

[0000068505-20-000020:mdna:49]
•10% decline in Systems and Systems Integration revenue driven by a decline in customer engagement due to the COVID-19 pandemic; and

[0000068505-20-000020:mdna:50]
•partially offset by $20 million of revenue from acquisitions.

[0000068505-20-000020:mdna:51]
[same as prior period, unchanged from 0000068505-20-000013:mdna:57]

[0000068505-20-000020:mdna:52]
The 5% increase in the Software and Services segment was driven by the following:

[0000068505-20-000020:mdna:53]
•3% growth in Services, driven by services in North America, inclusive of acquisitions;

[0000068505-20-000020:mdna:54]
•8% growth in Software, driven primarily by acquisitions and growth in command center software; and

[0000068505-20-000020:mdna:55]
•$20 million of revenue from acquisitions.

[0000068505-20-000020:mdna:56]
[same as prior period, unchanged from 0000068505-20-000013:mdna:62]

[0000068505-20-000020:mdna:57]
|  | Three Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Gross margin | $ | 766 |  |  | $ | 931 |  |  | (18) | % |

[0000068505-20-000020:mdna:58]
Gross margin was 47.3% of net sales in the second quarter of 2020 compared to 50.1% in the second quarter of 2019. The primary drivers of the decrease are as follows:

[0000068505-20-000020:mdna:59]
•lower gross margin contribution in Products and Systems Integration as a result of the decline in PCR and public safety LMR sales, as well as lower margins in Systems and Systems Integration driven by a delay in engagements from COVID-19; and

[0000068505-20-000020:mdna:60]
•partially offset by higher margins within Software and Services primarily driven by margin expansion within the Services and Software businesses and the increased mix of Software to the total segment, inclusive of acquisitions.

[0000068505-20-000020:mdna:61]
[same as prior period, unchanged from 0000068505-20-000013:mdna:68]

[0000068505-20-000020:mdna:62]
|  | Three Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 297 |  |  | $ | 351 |  |  | (15) | % |

[0000068505-20-000020:mdna:63]
SG&A expenses decreased 15% compared to the second quarter of 2019. SG&A expenses were 18.4% of net sales compared to 18.9% of net sales in the second quarter of 2019. The decrease in SG&A expenditures is primarily due to reduced employee incentive costs, travel expenses and indirect expenses. The overall reduction in SG&A expenses was partially offset by expenses associated with acquired businesses.

[0000068505-20-000020:mdna:64]
[same as prior period, unchanged from 0000068505-20-000013:mdna:71]

[0000068505-20-000020:mdna:65]
|  | Three Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Research and development expenditures | $ | 161 |  |  | $ | 170 |  |  | (5) | % |

[0000068505-20-000020:mdna:66]
R&D expenditures decreased 5% primarily due to lower operating expenses in the second quarter of 2020 driven by lower employee incentive costs, partially offset by expenses associated with acquired businesses. R&D expenditures were 10.0% of net sales compared to 9.1% of net sales in the second quarter of 2019.

[0000068505-20-000020:mdna:67]
[same as prior period, unchanged from 0000068505-20-000013:mdna:74]

[0000068505-20-000020:mdna:68]
|  | Three Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Other charges | $ | 90 |  |  | $ | 61 |  |

[0000068505-20-000020:mdna:69]
Other charges increased by $29 million in the second quarter of 2020 compared to the second quarter of 2019. The change is driven by the following:

[0000068505-20-000020:mdna:70]
•$26 million of net reorganization business charges in the second quarter of 2020 compared to $8 million in the second quarter of 2019 (see further detail in “Reorganization of Businesses” section);

[0000068505-20-000020:mdna:71]
•$7 million of legal settlements in the second quarter of 2020 compared to $1 million in the second quarter of 2019; and

[0000068505-20-000020:mdna:72]
•$5 million of fixed asset impairments in the second quarter of 2020.

[0000068505-20-000020:mdna:73]
Operating Earnings

[0000068505-20-000020:mdna:74]
|  | Three Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Operating earnings from Products and Systems Integration | $ | 49 |  |  | $ | 201 |  |
| Operating earnings from Software and Services | 169 |  |  | 148 |  |
| Operating earnings | $ | 218 |  |  | $ | 349 |  |

[0000068505-20-000020:mdna:75]
Operating earnings were down $131 million, or 38%, compared to the second quarter of 2019. The decrease in Operating earnings was due to:

[0000068505-20-000020:mdna:76]
•Products and Systems Integration, which was down $152 million, driven by lower sales, gross margin and partially offset by lower operating expenses primarily driven by lower employee incentive costs, indirect expenses and travel expenses. The overall reduction in operating expenses was partially offset by: i) $24 million of higher reorganization of business charges, ii) $6 million higher legal settlements, iii)  $3 million higher share-based compensation expenses, and iv) higher operating expenses from acquisitions; and

[0000068505-20-000020:mdna:77]
•partially offset by Software and Services, which was up $21 million, driven by higher sales, gross margin expansion, and reduced operating expenses primarily driven by lower employee incentive costs and travel expenses. The overall reduction in operating expenses was partially offset by: i) $5 million higher reorganization of business charges and ii) higher operating expenses from acquisitions.

[0000068505-20-000020:mdna:78]
29

[0000068505-20-000020:mdna:79]
[same as prior period, unchanged from 0000068505-20-000013:mdna:84]

[0000068505-20-000020:mdna:80]
|  | Three Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Interest expense, net | $ | (58) |  |  | $ | (56) |  |

[0000068505-20-000020:mdna:81]
The increase in net interest expense in the second quarter of 2020 compared to the second quarter of 2019 was a result of higher average debt outstanding, partially offset by lower interest rates as of and for the period ending June 27, 2020 as compared to the period ending June 29, 2019.

[0000068505-20-000020:mdna:82]
[same as prior period, unchanged from 0000068505-20-000013:mdna:87]

[0000068505-20-000020:mdna:83]
|  | Three Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Other, net | $ | 16 |  |  | $ | (21) |  |

[0000068505-20-000020:mdna:84]
The increase in net Other income in the second quarter of 2020 as compared to the second quarter of 2019 was driven by:

[0000068505-20-000020:mdna:85]
•a $43 million loss of extinguishment of long term debt in the second quarter of 2019;

[0000068505-20-000020:mdna:86]
•$21 million of foreign currency losses in the second quarter of 2020 compared to $7 million of foreign currency losses in the second quarter of 2019;

[0000068505-20-000020:mdna:87]
•$3 million of investment impairments in the second quarter of 2019;

[0000068505-20-000020:mdna:88]
•partially offset by a $12 million gain on derivatives in the second quarter of 2020 compared to a $3 million loss on the derivatives in the second quarter of 2019; and

[0000068505-20-000020:mdna:89]
•$4 million of gains related to fair value adjustments to equity investments in the second quarter of 2020 compared to $16 million of gains related to fair value adjustments to equity investments in the second quarter of 2019.

[0000068505-20-000020:mdna:90]
[same as prior period, unchanged from 0000068505-20-000013:mdna:90]

[0000068505-20-000020:mdna:91]
|  | Three Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Income tax expense | $ | 40 |  |  | $ | 67 |  |

[0000068505-20-000020:mdna:92]
Income tax expense decreased by $27 million compared to the second quarter of 2019, resulting in an effective tax rate of 23%. Our effective tax rate for the three months ended June 27, 2020 is lower than the effective tax rate for the three months ended June 29, 2019 of 24%, primarily due to an increased benefit of forecasted research and experimental development investment tax credit in our annual effective tax rate.

[0000068505-20-000020:mdna:93]
Results of Operations—Six months ended June 27, 2020 compared to Six months ended June 29, 2019

[0000068505-20-000020:mdna:94]
Net Sales

[0000068505-20-000020:mdna:95]
|  | Six Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 1,961 |  |  | $ | 2,307 |  |  | (15) | % |
| Net sales from Software and Services | 1,312 |  |  | 1,210 |  |  | 8 | % |
| Net sales | $ | 3,273 |  |  | $ | 3,517 |  |  | (7) | % |

[0000068505-20-000020:mdna:96]
The Products and Systems Integration segment’s net sales represented 60% of our consolidated net sales in the first half of 2020 and 66% in the first half of 2019. The Software and Services segment’s net sales represented 40% of our consolidated net sales in the first half of 2020 and 34% in the first half quarter of 2019.

[0000068505-20-000020:mdna:97]
Net sales decreased in the first half of 2020 compared to the first half of 2019. The Products and Systems Integration segment declined approximately 15% which was comprised of a 23% decline in the International region and a 12% decline in the North America region. The Software and Services segment increased approximately 8% which is comprised of a 12% increase in the North America region and a 4% increase in the International region. Net sales includes:

[0000068505-20-000020:mdna:98]
•a decline in the Products and System Integration segment, inclusive of acquisitions, driven by a decline in PCR and public safety LMR, partially offset by growth in video security;

[0000068505-20-000020:mdna:99]
•$38 million from unfavorable currency rates;

[0000068505-20-000020:mdna:100]
•partially offset by $88 million of revenue from acquisitions; and

[0000068505-20-000020:mdna:101]
•growth in Software and Services driven by Services in North America and Software primarily from acquisitions and growth in command center software.

[0000068505-20-000020:mdna:102]
Regional results include:

[0000068505-20-000020:mdna:103]
•a 10% decline in the International region driven by a decline in PCR within the Product and System Integration segment, partially offset by a 4% increase in the Software and Services segment, inclusive of acquisitions; and

[0000068505-20-000020:mdna:104]
•a 5% decline in the North America region driven primarily by a decline in PCR and public safety LMR within the Products and System Integration segment, partially offset by growth of video security, and a 12% increase in the Software and Services segment driven by Services in North America and Software primarily from acquisitions.

[0000068505-20-000020:mdna:105]
Products and Systems Integration

[0000068505-20-000020:mdna:106]
The 15% decrease in the Products and Systems Integration segment was driven by the following:

[0000068505-20-000020:mdna:107]
•20% decline in Devices revenue, primarily driven by a decline in PCR and public safety LMR, partially offset by growth of our video security business, inclusive of acquisitions;

[0000068505-20-000020:mdna:108]
•7% decline in Systems and Systems Integration revenue driven by a decline in customer engagement due to the COVID-19 pandemic; and

[0000068505-20-000020:mdna:109]
•partially offset by $44 million of revenue from acquisitions.

[0000068505-20-000020:mdna:110]
Software and Services

[0000068505-20-000020:mdna:111]
The 8% increase in the Software and Services segment was driven by the following:

[0000068505-20-000020:mdna:112]
•6% growth in Services, driven by services in North America, inclusive of acquisitions;

[0000068505-20-000020:mdna:113]
•16% growth in Software, driven primarily by acquisitions and growth in command center software; and

[0000068505-20-000020:mdna:114]
•$44 million of revenue from acquisitions.

[0000068505-20-000020:mdna:115]
Gross Margin

[0000068505-20-000020:mdna:116]
|  | Six Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Gross margin | $ | 1,553 |  |  | $ | 1,704 |  |  | (9) | % |

[0000068505-20-000020:mdna:117]
Gross margin was 47.4% of net sales in the first half of 2020 compared to 48.5% in the first half of 2019. The primary drivers of the decrease are as follows:

[0000068505-20-000020:mdna:118]
•lower gross margin contribution in Products and Systems Integration as a result of the decline in PCR and public safety LMR sales, as well as lower margins in Systems and Systems Integration driven by a delay in engagements from COVID-19; and

[0000068505-20-000020:mdna:119]
•partially offset by higher margins within Software and Services primarily driven by margin expansion within the Services and Software businesses and the increased mix of Software to the total segment, inclusive of acquisitions.

[0000068505-20-000020:mdna:120]
Selling, General and Administrative Expenses

[0000068505-20-000020:mdna:121]
|  | Six Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 638 |  |  | $ | 676 |  |  | (6) | % |

[0000068505-20-000020:mdna:122]
SG&A expenses decreased 6% compared to the first half of 2019. SG&A expenses were 19.5% of net sales compared to 19.2% of net sales in the first half of 2019. The decrease in SG&A expenditures is primarily driven by reduced employee incentive costs, travel expenses and indirect expenses, partially offset by $14 million higher Hytera-related legal expenses.  The overall reduction in SG&A expenses was partially offset by expenses associated with acquired businesses.

[0000068505-20-000020:mdna:123]
Research and Development Expenditures

[0000068505-20-000020:mdna:124]
|  | Six Months Ended |  |  |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |  | % Change |
| Research and development expenditures | $ | 330 |  |  | $ | 333 |  |  | (1) | % |

[0000068505-20-000020:mdna:125]
R&D expenditures decreased 1% primarily due to lower operating expenses in the first half of 2020 driven by lower employee incentive costs partially offset by expenses associated with acquired businesses. R&D expenditures were 10.1% of net sales compared to 9.5% of net sales in the first half of 2019.

[0000068505-20-000020:mdna:126]
Other Charges

[0000068505-20-000020:mdna:127]
|  | Six Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Other charges | $ | 109 |  |  | $ | 116 |  |

[0000068505-20-000020:mdna:128]
Other charges decreased by $7 million in the first half quarter of 2020 compared to the first half of 2019. The change is driven by the following:

[0000068505-20-000020:mdna:129]
•a $50 million gain on the sale of property, plant and equipment in the first half of 2020;

[0000068505-20-000020:mdna:130]
•partially offset by, $38 million of net reorganization business charges in the first half of 2020 compared to $12 million in the first half of 2019 (see further detail in “Reorganization of Businesses” section);

[0000068505-20-000020:mdna:131]
•$9 million of legal settlements in the first half of 2020; and

[0000068505-20-000020:mdna:132]
•$5 million of fixed asset impairments in the first half of 2020.

[0000068505-20-000020:mdna:133]
Operating Earnings

[0000068505-20-000020:mdna:134]
|  | Six Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Operating earnings from Products and Systems Integration | $ | 141 |  |  | $ | 310 |  |
| Operating earnings from Software and Services | 335 |  |  | 269 |  |
| Operating earnings | $ | 476 |  |  | $ | 579 |  |

[0000068505-20-000020:mdna:135]
Operating earnings were down $103 million, or 18%, compared to the first half of 2019. The decrease in Operating earnings was due to:

[0000068505-20-000020:mdna:136]
•Products and Systems Integration, which was down $169 million, driven by lower sales and partially offset by lower operating expenses primarily driven by a $50 million gain from the sale of a manufacturing facility in Europe and lower employee incentive costs, indirect expenses and travel expenses.  The overall reduction in operating expenses was offset by: i) $32 million higher reorganization of business charges, ii) $14 million of additional Hytera-related legal expenses, iii) $10 million higher share-based compensation expenses, and iv) higher operating expenses from acquisitions; and

[0000068505-20-000020:mdna:137]
•partially offset by Software and Services, which was up $66 million, primarily driven by higher sales and gross margin expansion, acquisitions, and reduced operating expenses due to lower employee incentive costs and travel expenses. The overall reduction in operating expenses was partially offset by: i) $8 million of higher reorganization of business charges and ii) higher operating expenses from acquisitions.

[0000068505-20-000020:mdna:138]
Interest Expense, net

[0000068505-20-000020:mdna:139]
|  | Six Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Interest expense, net | $ | (109) |  |  | $ | (111) |  |

[0000068505-20-000020:mdna:140]
The decrease in net interest expense in the first half of 2020 compared to the first half of 2019 was a result of lower interest rates, partially offset by higher average debt outstanding as of and for the period ending June 27, 2020 as compared to the period ending June 29, 2019.

[0000068505-20-000020:mdna:141]
Other, net

[0000068505-20-000020:mdna:142]
|  | Six Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Other, net | $ | 34 |  |  | $ | (12) |  |

[0000068505-20-000020:mdna:143]
The increase in net Other income in the first half of 2020 as compared to the first half of 2019 was driven by the following:

[0000068505-20-000020:mdna:144]
•a $43 million loss of extinguishment of long term debt in the second quarter of 2019;

[0000068505-20-000020:mdna:145]
•$11 million of investment impairments in the second quarter of 2019;

[0000068505-20-000020:mdna:146]
•$3 million of foreign currency losses in the second quarter of 2020 compared to $11 million of foreign currency losses in the second quarter of 2019;

[0000068505-20-000020:mdna:147]
•$4 million loss on derivatives in the second quarter of 2020 compared to a $7 million loss on the derivatives in

[0000068505-20-000020:mdna:148]
the second quarter of 2019;

[0000068505-20-000020:mdna:149]
•$3 million of other operating expense in the second quarter of 2020 compared to $11 million of other operating income the second quarter of 2019;

[0000068505-20-000020:mdna:150]
•$5 million of fair value adjustments to equity investments in the second quarter of 2020 compared to $15 million of fair value adjustments to equity investments in the second quarter of 2019; and

[0000068505-20-000020:mdna:151]
•$39 million in net periodic pension and postretirement benefits in the second quarter of 2020 compared to 33 million in the second quarter of 2019.

[0000068505-20-000020:mdna:152]
Effective Tax Rate

[0000068505-20-000020:mdna:153]
|  | Six Months Ended |  |  |
| (In millions) | June 27, 2020 |  | June 29, 2019 |
| Income tax expense | $ | 67 |  |  | $ | 100 |  |

[0000068505-20-000020:mdna:154]
Income tax expense decreased by $33 million compared to the first half quarter of 2019, resulting in an effective tax rate of 17%. Our effective tax rate for the six months ended June 27, 2020 is lower than the effective tax rate for the six months ended June 29, 2019 of 22%, primarily due to higher excess tax benefits on share-based compensation.

[0000068505-20-000020:mdna:155]
[same as prior period, unchanged from 0000068505-20-000013:mdna:93]

[0000068505-20-000020:mdna:156]
During the second quarter of 2020, we recorded net reorganization of business charges of $41 million including $26 million of charges recorded within Other charges and $15 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $41 million were charges of $46 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-20-000020:mdna:157]
During the first half of 2020, we recorded net reorganization of business charges of $59 million including $38 million of charges recorded within Other charges and $21 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $59 million were charges of $68 million related to employee separation costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-20-000020:mdna:158]
During the second quarter of 2019, we recorded net reorganization of business charges of $12 million including $8 million of charges in Other charges and $4 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $12 million were charges of $18 million related to employee separation costs and $6 million reversals for accruals no longer needed.

[0000068505-20-000020:mdna:159]
During the first half of 2019, we recorded net reorganization of business charges of $20 million including $12 million of charges in Other charges and $8 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $20 million were charges of $30 million related to employee separation costs and $10 million reversals for accruals no longer needed.

[0000068505-20-000020:mdna:160]
[same as prior period, unchanged from 0000068505-20-000013:mdna:96]

[0000068505-20-000020:mdna:161]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Products and Systems Integration | $ | 33 |  |  | $ | 9 |  |  | $ | 47 |  |  | $ | 16 |  |
| Software and Services | 8 |  |  | 3 |  |  | 12 |  |  | 4 |  |
|  | $ | 41 |  |  | $ | 12 |  |  | $ | 59 |  |  | $ | 20 |  |

[0000068505-20-000020:mdna:162]
Cash payments for employee severance in connection with the reorganization of business plans were $41 million in the first half of 2020 and $28 million in the first half of 2019. The reorganization of business accrual at June 27, 2020 was $96 million related to employee separation costs that are expected to be paid within one year.

[0000068505-20-000020:mdna:163]
33

[0000068505-20-000020:mdna:164]
[same as prior period, unchanged from 0000068505-20-000013:mdna:99]

[0000068505-20-000020:mdna:165]
|  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 517 |  |  | $ | 502 |  |
| Investing activities | (141) |  |  | (490) |  |
| Financing activities | (17) |  |  | (311) |  |
| Effect of exchange rates on cash and cash equivalents | (19) |  |  | 6 |  |
| Increase (decrease) in cash and cash equivalents | $ | 340 |  |  | $ | (293) |  |

[0000068505-20-000020:mdna:166]
[same as prior period, unchanged from 0000068505-20-000013:mdna:101]

[0000068505-20-000020:mdna:167]
At June 27, 2020, $874 million of the $1.3 billion cash and cash equivalents balance was held in the U.S. and $467 million was held in other countries, with $161 million held in the United Kingdom.

[0000068505-20-000020:mdna:168]
[same as prior period, unchanged from 0000068505-20-000013:mdna:103]

[0000068505-20-000020:mdna:169]
The increase in operating cash flows from the first half of 2019 to the first half of 2020 was driven primarily by favorable working capital as a result of timing.

[0000068505-20-000020:mdna:170]
[same as prior period, unchanged from 0000068505-20-000013:mdna:105]

[0000068505-20-000020:mdna:171]
The decrease in net cash used by investing activities from the first half of 2019 to the first half of 2020 was primarily due to:

[0000068505-20-000020:mdna:172]
•a $269 million decrease in acquisitions and investments, primarily driven by cash used for the purchases of VaaS and Avtec in the first half of 2019;

[0000068505-20-000020:mdna:173]
•a $27 million decrease in capital expenditures in the first half of 2020 as compared to the first half of 2019 due to lower payments for the Airwave and ESN networks; and

[0000068505-20-000020:mdna:174]
•partially offset by a $56 million increase in the proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in the first half of 2020.

[0000068505-20-000020:mdna:175]
[same as prior period, unchanged from 0000068505-20-000013:mdna:110]

[0000068505-20-000020:mdna:176]
The decrease in cash used by financing activities in the first half of 2020 as compared to the first half of 2019 was driven by (also see further discussion in "Debt,"  "Share Repurchase Program" and "Dividends" below):

[0000068505-20-000020:mdna:177]
•a $500 million increase in debt due to the draw on our syndicated, unsecured revolving credit facility during the first half of 2020;

[0000068505-20-000020:mdna:178]
•a $166 million increase in share repurchases in the first half of 2020 as compared to the first half of 2019; and

[0000068505-20-000020:mdna:179]
•a $31 million increase in the payment of dividends in the first half of 2020 as compared to the first half of 2019.

[0000068505-20-000020:mdna:180]
[same as prior period, unchanged from 0000068505-20-000013:mdna:116]

[0000068505-20-000020:mdna:181]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended June 27, 2020 and June 29, 2019:

[0000068505-20-000020:mdna:182]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Accounts receivable sales proceeds | $ | 88 |  |  | $ | 3 |  |  | $ | 156 |  |  | $ | 27 |  |
| Long-term receivables sales proceeds | 29 |  |  | 55 |  |  | 70 |  |  | 76 |  |
| Total proceeds from sales of accounts receivable | $ | 117 |  |  | $ | 58 |  |  | $ | 226 |  |  | $ | 103 |  |

[0000068505-20-000020:mdna:183]
During the first half of 2020, we utilized a new cost-efficient receivable discounting facility to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe resulting in accounts receivable sales of $54 million and $98 million, during the three and six months ended June 27, 2020, respectively.  The net benefit to our operating cash flow from the utilization of the new receivable discounting facility for the three and six months ended June 27, 2020, was $10 million and $54 million, respectively, when adjusted for amounts that would still be collected from the customer within the periods in the absence of utilizing the discounting facility. The proceeds of our receivable sales are included in "Operating activities" within our Condensed Consolidated Statements of Cash Flows.

[0000068505-20-000020:mdna:184]
34

[0000068505-20-000020:mdna:185]
[same as prior period, unchanged from 0000068505-20-000013:mdna:120]

[0000068505-20-000020:mdna:186]
We had outstanding debt of $5.6 billion and $5.1 billion, including the current portions of $517 million and $16 million at June 27, 2020 and December 31, 2019, respectively.

[0000068505-20-000020:mdna:187]
We have a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, we borrowed $800 million under the facility to bolster our cash holdings out of precaution in the first quarter of 2020, of which, $300 million was repaid during the three months ended June 27, 2020. As of June 27, 2020, the outstanding loan amount was $500 million.  Subsequent to the quarter, we repaid an additional $200 million. The weighted average borrowing rate on outstanding amounts outstanding during the three and six months ended June 27, 2020 were 1.69% and 1.79%, respectively. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of June 27, 2020.

[0000068505-20-000020:mdna:188]
[same as prior period, unchanged from 0000068505-20-000013:mdna:123]

[0000068505-20-000020:mdna:189]
We have an unsecured commercial paper program, backed by the revolving credit facility, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time.  Proceeds from the issuances of the notes are expected to be used for general corporate purposes.  As of June 27, 2020 we had no outstanding debt under the commercial paper program.

[0000068505-20-000020:mdna:190]
[same as prior period, unchanged from 0000068505-20-000013:mdna:125]

[0000068505-20-000020:mdna:191]
[same as prior period, unchanged from 0000068505-20-000013:mdna:126]

[0000068505-20-000020:mdna:192]
During the three and six months ended June 27, 2020, we paid an aggregate of $83 million and $336 million, including transaction costs, to repurchase approximately 0.6 million and 2.2 million shares at an average price of $133.93 and  $154.58 per share. As of June 27, 2020, the Company had used approximately $13.1 billion of the share repurchase authority to repurchase shares, leaving $925 million of authority available for future repurchases.

[0000068505-20-000020:mdna:193]
[same as prior period, unchanged from 0000068505-20-000013:mdna:128]

[0000068505-20-000020:mdna:194]
During the second quarter of 2020 we paid $109 million in cash dividends to holders of our common stock. During the first half of 2020 we paid $218 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $109 million in cash dividends to holders of our common stock.

[0000068505-20-000020:mdna:195]
[same as prior period, unchanged from 0000068505-20-000013:mdna:130]

[0000068505-20-000020:mdna:196]
We had outstanding commitments to provide long-term financing to third parties totaling $88 million at June 27, 2020, compared to $78 million at December 31, 2019.

[0000068505-20-000020:mdna:197]
[same as prior period, unchanged from 0000068505-20-000013:mdna:132]

[0000068505-20-000020:mdna:198]
In December 2019, the FASB issued Accounting Standard Update (ASU) No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and simplifying other areas of accounting for income taxes.  The ASU is effective on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  We are still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-20-000020:mdna:199]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-20-000020:mdna:200]
Recently Adopted Accounting Pronouncements

[0000068505-20-000020:mdna:201]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires us to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the

[0000068505-20-000020:mdna:202]
FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11," Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU.  We adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.

[0000068505-20-000020:mdna:203]
[same as prior period, unchanged from 0000068505-20-000013:mdna:138]

[0000068505-20-000020:mdna:204]
36
