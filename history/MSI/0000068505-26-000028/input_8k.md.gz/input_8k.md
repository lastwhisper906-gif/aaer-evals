# MSI 8-K — 0000068505-26-000027 filed 2026-08-05

## item codes, every 8-K on or before 2026-08-05

- 2026-08-05 0000068505-26-000027 — 2.02, 9.01
- 2026-05-20 0001193125-26-232694 — 5.07
- 2026-05-07 0000068505-26-000018 — 2.02, 9.01
- 2026-03-12 0001193125-26-104278 — 5.02, 9.01
- 2026-02-11 0000068505-26-000006 — 2.02, 9.01
- 2025-11-18 0001193125-25-286239 — 5.02, 9.01
- 2025-10-30 0000068505-25-000050 — 2.02, 9.01
- 2025-08-07 0000068505-25-000038 — 2.02, 9.01
- 2025-08-06 0001193125-25-174512 — 2.01, 2.03, 7.01, 9.01
- 2025-07-21 0001193125-25-161886 — 1.01, 9.01
- 2025-06-16 0001193125-25-141449 — 8.01, 9.01
- 2025-05-27 0001193125-25-127588 — 1.01, 3.02, 7.01, 9.01
- 2025-05-19 0001193125-25-122455 — 5.07, 8.01
- 2025-05-01 0000068505-25-000022 — 2.02, 9.01
- 2025-04-25 0001193125-25-096928 — 1.01, 1.02, 2.03, 9.01
- 2025-02-13 0000068505-25-000008 — 2.02, 9.01
- 2024-11-07 0000068505-24-000032 — 2.02, 9.01
- 2024-10-09 0001193125-24-235267 — 5.02
- 2024-08-26 0001193125-24-207088 — 5.02, 9.01
- 2024-08-01 0000068505-24-000022 — 2.02, 9.01
- 2024-05-17 0001193125-24-141186 — 5.07
- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2026-08-05

- none on or before 2026-08-05

## item 2.02 — earnings release, exhibit 99.1

[0000068505-26-000027:8k_2_02:1]
EX-99.1
2
msiq22026pressrelease.htm
EX-99.1

[0000068505-26-000027:8k_2_02:2]
Document

[0000068505-26-000027:8k_2_02:3]
Exhibit 99.1

[0000068505-26-000027:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2026 Financial Results

[0000068505-26-000027:8k_2_02:5]
Company again raises full-year revenue and earnings outlook following record Q2 revenue, earnings and backlog

[0000068505-26-000027:8k_2_02:6]
•Sales of $3.1 billion, up 13% versus a year ago

[0000068505-26-000027:8k_2_02:7]
◦Products and Systems Integration sales up 15%

[0000068505-26-000027:8k_2_02:8]
◦Software and Services sales up 10%

[0000068505-26-000027:8k_2_02:9]
•GAAP earnings per share ("EPS")2 of $3.33, up 10% versus a year ago

[0000068505-26-000027:8k_2_02:10]
•Non-GAAP1 EPS2 of $4.41, up 24% versus a year ago

[0000068505-26-000027:8k_2_02:11]
•Operating cash flow of $469 million, up $197 million versus a year ago

[0000068505-26-000027:8k_2_02:12]
•Record Q2 ending backlog of $15.6 billion, up 11% versus a year ago

[0000068505-26-000027:8k_2_02:13]
•Entered into a definitive agreement to acquire D-Fend Solutions ("D-Fend") for $1.5 billion

[0000068505-26-000027:8k_2_02:14]
CHICAGO – August 5, 2026 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2026.

[0000068505-26-000027:8k_2_02:15]
“Q2 was exceptional across the board,” said Greg Brown, chairman and CEO, Motorola Solutions.  “This performance, along with record Q2 orders, is driving very strong momentum into the second half of this year.”

[0000068505-26-000027:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-26-000027:8k_2_02:17]
|  | Q2 2026 |  | Q2 2025 | % Change |
| Sales | $3,133 |  | $2,765 | 13 | % |
| GAAP |  |  |  |  |
| Operating Earnings2 | $809 |  | $692 | 17 | % |
| % of Sales2 | 25.8 | % |  | 25.0 | % |  |
| EPS2 | $3.33 |  | $3.04 | 10 | % |
| Non-GAAP1 |  |  |  |  |
| Operating Earnings2 | $1,032 |  | $818 | 26 | % |
| % of Sales2 | 32.9 | % |  | 29.6 | % |  |
| EPS2 | $4.41 |  | $3.57 | 24 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,908 |  | $1,653 | 15 | % |
| GAAP Operating Earnings2 | $453 |  | $363 | 25 | % |
| % of Sales2 | 23.7 | % |  | 22.0 | % |  |
| Non-GAAP1 Operating Earnings2 | $599 |  | $442 | 36 | % |
| % of Sales | 31.4 | % |  | 26.7 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $1,225 |  | $1,112 | 10 | % |
| GAAP Operating Earnings | $356 |  | $329 | 8 | % |
| % of Sales | 29.1 | % |  | 29.6 | % |  |
| Non-GAAP1 Operating Earnings | $433 |  | $376 | 15 | % |
| % of Sales | 35.3 | % |  | 33.8 | % |  |

[0000068505-26-000027:8k_2_02:18]
1 Non-GAAP financial information excludes the after-tax impact of approximately $1.08 per diluted share related to highlighted items, share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-26-000027:8k_2_02:19]
2 Inclusive of a $60M (pre-tax) benefit, or $0.25 per share, related to the International Economic Emergency Powers Act ("IEEPA") refunds recorded during the quarter.

[0000068505-26-000027:8k_2_02:20]
1

[0000068505-26-000027:8k_2_02:21]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-26-000027:8k_2_02:22]
•Revenue - Sales were $3.1 billion, up 13% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $243 million and foreign currency tailwinds were $35 million in the quarter. The Products and Systems Integration segment grew 15% driven by growth in Mission Critical Networks ("MCN") and Video Security and Access Control ("Video"). The Software and Services segment grew 10% driven by growth in MCN, Command Center and Video.

[0000068505-26-000027:8k_2_02:23]
•Operating margin - GAAP operating margin was 25.8% of sales, up from 25.0% in the year-ago quarter and Non-GAAP operating margin was 32.9% of sales, up 330 basis points from 29.6% a year ago. The increase in both GAAP and non-GAAP operating margin was driven by higher sales and improved operating leverage, inclusive of higher direct material costs and a $60 million benefit, or 190 bps, from IEEPA refunds recorded during the quarter.

[0000068505-26-000027:8k_2_02:24]
•Taxes - The GAAP effective tax rate during the quarter was 24.8%, versus 24.3% in the year-ago quarter and the non-GAAP effective tax rate was 22.6%, versus 23.5% in the year-ago quarter. The decrease in the non-GAAP effective tax rate was primarily driven by a higher deduction for income generated from export sales recognized in the current quarter.

[0000068505-26-000027:8k_2_02:25]
•Cash flow - Operating cash flow was $469 million, compared to $272 million in the year-ago quarter, and free cash flow was $414 million, compared to $224 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings, net of non-cash charges and lower tax payments, partially offset by higher investments in inventory.

[0000068505-26-000027:8k_2_02:26]
•Capital allocation - During the quarter, the company repurchased $326 million of common stock at an average price of $413.53 per share, paid $201 million in cash dividends and invested $55 million in capital expenditures. The company also entered into a definitive agreement to acquire D-Fend Solutions ("D-Fend"), an industry leader in counter-drone technology, for $1.5 billion.

[0000068505-26-000027:8k_2_02:27]
•Backlog - The company ended the quarter with record Q2 backlog of $15.6 billion, up 11% or $1.5 billion from the year-ago quarter driven by record Q2 orders. Products and Systems Integration segment backlog was up $329 million, or 10%, driven primarily by strong demand in MCN and Video. Software and Services segment backlog was up $1.2 billion, or 11%, driven by strong demand across all three technologies.

[0000068505-26-000027:8k_2_02:28]
2

[0000068505-26-000027:8k_2_02:29]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-26-000027:8k_2_02:30]
Products and Systems Integration

[0000068505-26-000027:8k_2_02:31]
•$52 million P25 systems order for a U.S. federal customer

[0000068505-26-000027:8k_2_02:32]
•$36 million P25 device and SVX order for a U.S. federal customer

[0000068505-26-000027:8k_2_02:33]
•$34 million P25 system upgrade for a U.S. state and local customer

[0000068505-26-000027:8k_2_02:34]
•$22 million P25 system upgrade for St. Louis County, MO

[0000068505-26-000027:8k_2_02:35]
•$20 million P25 device order for Atlanta, GA

[0000068505-26-000027:8k_2_02:36]
•$17 million P25 device order for Miami-Dade Corrections, FL

[0000068505-26-000027:8k_2_02:37]
Software and Services

[0000068505-26-000027:8k_2_02:38]
•$25 million mobile video order for the Florida Highway Patrol

[0000068505-26-000027:8k_2_02:39]
•$24 million mobile video order for Kansas City Police Dept, MO

[0000068505-26-000027:8k_2_02:40]
•$24 million P25 services order for a North American energy company

[0000068505-26-000027:8k_2_02:41]
•$20 million Command Center order for the State of Montana Dept of Justice

[0000068505-26-000027:8k_2_02:42]
•$16 million P25 services order for Fulton County, GA

[0000068505-26-000027:8k_2_02:43]
•$14 million Command Center order for Hillsborough County, FL

[0000068505-26-000027:8k_2_02:44]
BUSINESS OUTLOOK

[0000068505-26-000027:8k_2_02:45]
•Third quarter 2026 - The company expects revenue growth of approximately 8% compared to the third quarter of 2025 and non-GAAP EPS between $4.39 and $4.44 per share. This assumes approximately 168 million of fully diluted shares and a non-GAAP effective tax rate of approximately 23%.

[0000068505-26-000027:8k_2_02:46]
•Full-year 2026 - The company now expects revenue of approximately $12.975 billion, up from its prior guidance of $12.8 billion and non-GAAP EPS between $17.62 and $17.72 per share, up from the prior guidance of between $16.87 and $16.99 per share. This outlook assumes approximately 168 million of fully diluted shares and a non-GAAP effective tax rate between 22% and 22.5%.

[0000068505-26-000027:8k_2_02:47]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP measurements in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measurements have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-26-000027:8k_2_02:48]
RECENT EVENTS

[0000068505-26-000027:8k_2_02:49]
MACROECONOMIC ENVIRONMENT UPDATE

[0000068505-26-000027:8k_2_02:50]
The global trade landscape continues to shift rapidly, including evolving tariffs and import/export regulations, such as restrictions around rare earth minerals, trade barriers and trade disputes.

[0000068505-26-000027:8k_2_02:51]
On February 20, 2026, a U.S. Supreme Court ruling invalidated tariffs imposed under the International Emergency Economic Powers Act (“IEEPA”). On April 20, 2026, the U.S. Customs and Border Protection launched a system to process IEEPA tariff refund claims. Following the implementation of this system, the company determined that the recovery of a portion of these refunds is now probable. Accordingly, during the quarter ended July 4, 2026, the company recognized a favorable adjustment of $60 million recorded within Cost of sales in its Condensed Consolidated Statements of Operations.

[0000068505-26-000027:8k_2_02:52]
3

[0000068505-26-000027:8k_2_02:53]
In addition, the company is experiencing higher costs for memory in its products which is a result of substantial demand in the market driven by AI. As a result, the company continues to observe elevated volatility and uncertainty around the global supply chain. The company engages with global suppliers across a diverse network of locations around the world. The company is actively managing its inventory and continues to work with its global supply base to mitigate its exposure to elevated volatility and uncertainty from these rising memory costs, as well as global tariffs and import/export regulations that have developed, and which may continue to develop, to ensure supply continues at levels necessary to meet its current customer demand. The company expects inventory levels to remain elevated as it mitigates this dynamic supply chain environment. The current environment has led to increased costs on materials and components, for which the company continues to develop mitigation actions going forward.

[0000068505-26-000027:8k_2_02:54]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Wednesday, August 5. The conference call will be webcast live at www.motorolasolutions.com/investors. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-26-000027:8k_2_02:55]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-26-000027:8k_2_02:56]
A comparison of results from operations is as follows:

[0000068505-26-000027:8k_2_02:57]
|  | Q2 2026 | Q2 2025 |
| Net sales | $3,133 | $2,765 |
| Gross margin | $1,678 | $1,413 |
| Operating earnings | $809 | $692 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $557 | $513 |
| Diluted EPS | $3.33 | $3.04 |
| Weighted average diluted common shares outstanding | 167.2 |  | 168.8 |  |

[0000068505-26-000027:8k_2_02:58]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-26-000027:8k_2_02:59]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP net earnings attributable to MSI, non-GAAP tax rate, and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-26-000027:8k_2_02:60]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-26-000027:8k_2_02:61]
4

[0000068505-26-000027:8k_2_02:62]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-26-000027:8k_2_02:63]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-26-000027:8k_2_02:64]
Non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin and non-GAAP net earnings attributable to MSI each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-26-000027:8k_2_02:65]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt, adjustments to contingent earnout, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-26-000027:8k_2_02:66]
Hytera-Related Legal Expenses: In 2017, the company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for the Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the company's favor, ultimately resulting in an award to the company of $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-26-000027:8k_2_02:67]
In 2024, after both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), the Court of Appeals, among other items, affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, and directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, which remains subject to ruling by the District Court. As of July 4, 2026, as a result of this civil litigation and 2020 bankruptcy proceedings by Hytera America, Inc. and Hytera Communications America (West), Inc., Hytera had paid $232 million against this award, $60 million of which was paid in the first half of 2026. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations.

[0000068505-26-000027:8k_2_02:68]
Further, in 2022, the District Court ordered Hytera to pay the company a forward-looking reasonable royalty on Hytera’s products (“I-Series”) that use the company’s stolen trade secrets, applicable to I-Series products sold from July 1, 2019 forward. In 2024, the company received royalties of $61 million related to the I-Series products, which was recorded as a gain within Other charges within the Consolidated Statement of Operations. Beginning in 2025, a favorable ruling in a related legal proceeding in the District Court (which Hytera has subsequently appealed to the Court of Appeals) also ordered Hytera to pay the company for Hytera’s continued use of the company’s trade secrets and copyrighted source code in Hytera’s currently shipping products (“H-Series”), and Hytera has subsequently reported

[0000068505-26-000027:8k_2_02:69]
5

[0000068505-26-000027:8k_2_02:70]
to the company approximately $116 million in royalties subject to the Court's order. While several aspects of the court proceedings related to the H-Series are subject to appeal, the company continues to seek collection of the amounts owed by Hytera through the ongoing legal process.

[0000068505-26-000027:8k_2_02:71]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring.”  Since 2020, the company has believed that Hytera-related legal expenses have not been part of its “normal and recurring” legal expenses incurred to operate its business and has accordingly excluded such expenses from its GAAP operating Income. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the approximately $15 million realized in 2022, $61 million realized in 2024, $157 million realized in 2025, and $60 million realized in the first half of 2026. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-26-000027:8k_2_02:72]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-26-000027:8k_2_02:73]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-26-000027:8k_2_02:74]
FORWARD LOOKING STATEMENTS

[0000068505-26-000027:8k_2_02:75]
6

[0000068505-26-000027:8k_2_02:76]
or enhanced products and services in our segments; (iii) challenges relating to the use of artificial intelligence ("AI") in our products and services; (iv) impact of catastrophic events on our business or our customers' or suppliers' business; (v) the effectiveness of our strategic acquisitions, including the integrations of such acquired businesses; (vi) the inability of our products to meet our customers’ expectations or regulatory or industry standards, or actual or perceived systems or service failures of our products and services; (vii) our inability to purchase a sufficient amount of materials, parts, and components, as well as software and services, at acceptable prices to meet the demands of our customers, and any disruption to our suppliers or significant increase in the price of supplies; (viii) risks related to our large, multi-year system and services contracts; (ix) the global nature of our employees, customers, suppliers and outsource partners; (x) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xi) the inability of our subcontractors to perform in a timely and compliant manner or adhere to our Human Rights Policy; (xii) inability to attract and retain senior management and key employees; (xiii) evolving and sometimes conflicting expectations from investors, customers, lawmakers, regulators and other stakeholders regarding social and sustainability considerations and disclosures; (xiv) challenges relating to existing or future legislation and regulations pertaining to AI, AI-enabled products and the use of biometrics and other video analytics; (xv) the impact, including increased costs and potential liabilities, associated with changes in laws and regulations regarding cybersecurity, privacy, data protection, data sovereignty and information security; (xvi) the impact of government regulation of radio frequencies; (xvii) regulations, laws and other compliance requirements and risks applicable to our U.S. government customer contracts and grants; (xviii) the impact, including increased costs and additional compliance obligations, associated with existing or future telecommunications-related laws and regulations; (xix) impact of product regulatory and safety, consumer, worker safety and environmental product compliance and remediation laws; (xx) impact of tax matters; (xxi) increased cybersecurity threats, a security breach or other significant disruption of our IT systems or those of our outsource partners, suppliers or customers; (xxii) our inability to protect our intellectual property or potential infringement of intellectual property rights of third parties; (xxiii) risks relating to intellectual property licenses and intellectual property indemnities in our customer and supplier contracts; (xxiv) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xxv) inability to access the capital markets for financing on acceptable terms and conditions; (xxvi) exposure to exchange rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; (xxvii) impact of returns on pension and retirement plan assets and interest rate changes; and (xxviii) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-26-000027:8k_2_02:77]
The company uses its website as a means of disclosing material, non-public information and for complying with the company's disclosure obligations under Regulation FD. Therefore, the company encourages investors to monitor the Investor Relations page of the company's website at www.motorolasolutions.com/investors, and review the information the company posts on that page.

[0000068505-26-000027:8k_2_02:78]
About Motorola Solutions | Solving for safer

[0000068505-26-000027:8k_2_02:79]
Safety and security are at the heart of everything we do at Motorola Solutions. We build and connect technologies to help protect people, property and places. Our solutions foster the collaboration that’s critical for safer communities, safer schools, safer hospitals, safer businesses, and ultimately, safer nations. Learn more about our commitment to innovating for a safer future for us all at www.motorolasolutions.com.

[0000068505-26-000027:8k_2_02:80]
MEDIA CONTACT

[0000068505-26-000027:8k_2_02:81]
Matt Schuler

[0000068505-26-000027:8k_2_02:82]
Motorola Solutions

[0000068505-26-000027:8k_2_02:83]
+1 312-909-5234

[0000068505-26-000027:8k_2_02:84]
matt.schuler@motorolasolutions.com

[0000068505-26-000027:8k_2_02:85]
INVESTOR CONTACT

[0000068505-26-000027:8k_2_02:86]
Brian Piotrowski

[0000068505-26-000027:8k_2_02:87]
Motorola Solutions

[0000068505-26-000027:8k_2_02:88]
+1 847-576-6899

[0000068505-26-000027:8k_2_02:89]
Brian.Piotrowski@motorolasolutions.com

[0000068505-26-000027:8k_2_02:90]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2026 Motorola Solutions, Inc. All rights reserved.

[0000068505-26-000027:8k_2_02:91]
8

[0000068505-26-000027:8k_2_02:92]
GAAP-1

[0000068505-26-000027:8k_2_02:93]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:94]
Condensed Consolidated Statements of Operations

[0000068505-26-000027:8k_2_02:95]
(In millions, except per share amounts)

[0000068505-26-000027:8k_2_02:96]
|  | Three Months Ended |
|  | July 4, 2026 |  | June 28, 2025 |
| Net sales from products | $ | 1,818 |  |  | $ | 1,533 |  |
| Net sales from services | 1,315 |  |  | 1,232 |  |
| Net sales | 3,133 |  |  | 2,765 |  |
| Costs of products sales | 702 |  |  | 646 |  |
| Costs of services sales | 753 |  |  | 706 |  |
| Costs of sales | 1,455 |  |  | 1,352 |  |
| Gross margin | 1,678 |  |  | 1,413 |  |
| Selling, general and administrative expenses | 496 |  |  | 450 |  |
| Research and development expenditures | 260 |  |  | 231 |  |
| Other charges | 18 |  |  | 1 |  |
| Intangibles amortization | 95 |  |  | 39 |  |
| Operating earnings | 809 |  |  | 692 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (103) |  |  | (55) |  |
| Other, net | 36 |  |  | 43 |  |
| Total other expense | (67) |  |  | (12) |  |
| Net earnings before income taxes | 742 |  |  | 680 |  |
| Income tax expense | 184 |  |  | 165 |  |
| Net earnings | 558 |  |  | 515 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 557 |  |  | $ | 513 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.36 |  |  | $ | 3.08 |  |
| Diluted | $ | 3.33 |  |  | $ | 3.04 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 165.8 |  |  | 166.8 |  |
| Diluted | 167.2 |  |  | 168.8 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 58.0 | % |  | 55.4 | % |
| Net sales from services | 42.0 | % |  | 44.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 38.6 | % |  | 42.1 | % |
| Costs of services sales | 57.3 | % |  | 57.3 | % |
| Costs of sales | 46.4 | % |  | 48.9 | % |
| Gross margin | 53.6 | % |  | 51.1 | % |
| Selling, general and administrative expenses | 15.8 | % |  | 16.3 | % |
| Research and development expenditures | 8.3 | % |  | 8.4 | % |
| Other charges | 0.6 | % |  | — | % |
| Intangibles amortization | 3.0 | % |  | 1.4 | % |
| Operating earnings | 25.8 | % |  | 25.0 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.3) | % |  | (2.0) | % |
| Other, net | 1.1 | % |  | 1.6 | % |
| Total other expense | (2.1) | % |  | (0.4) | % |
| Net earnings before income taxes | 23.7 | % |  | 24.6 | % |
| Income tax expense | 5.9 | % |  | 6.0 | % |
| Net earnings | 17.8 | % |  | 18.6 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 17.8 | % |  | 18.6 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-26-000027:8k_2_02:97]
9

[0000068505-26-000027:8k_2_02:98]
GAAP-2

[0000068505-26-000027:8k_2_02:99]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:100]
Condensed Consolidated Statements of Operations

[0000068505-26-000027:8k_2_02:101]
(In millions, except per share amounts)

[0000068505-26-000027:8k_2_02:102]
|  | Six Months Ended |
|  | July 4, 2026 |  | June 28, 2025 |
| Net sales from products | $ | 3,300 |  |  | $ | 2,980 |  |
| Net sales from services | 2,548 |  |  | 2,313 |  |
| Net sales | 5,848 |  |  | 5,293 |  |
| Costs of products sales | 1,332 |  |  | 1,220 |  |
| Costs of services sales | 1,476 |  |  | 1,360 |  |
| Costs of sales | 2,808 |  |  | 2,580 |  |
| Gross margin | 3,040 |  |  | 2,713 |  |
| Selling, general and administrative expenses | 935 |  |  | 886 |  |
| Research and development expenditures | 512 |  |  | 464 |  |
| Other charges | 74 |  |  | 13 |  |
| Intangibles amortization | 185 |  |  | 76 |  |
| Operating earnings | 1,334 |  |  | 1,274 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (208) |  |  | (106) |  |
| Other, net | 56 |  |  | 59 |  |
| Total other expense | (152) |  |  | (47) |  |
| Net earnings before income taxes | 1,182 |  |  | 1,227 |  |
| Income tax expense | 256 |  |  | 280 |  |
| Net earnings | 926 |  |  | 947 |  |
| Less: Earnings attributable to non-controlling interests | 3 |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 923 |  |  | $ | 943 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 5.57 |  |  | $ | 5.65 |  |
| Diluted | $ | 5.51 |  |  | $ | 5.57 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 165.8 |  |  | 166.8 |  |
| Diluted | 167.6 |  |  | 169.4 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 56.4 | % |  | 56.3 | % |
| Net sales from services | 43.6 | % |  | 43.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 40.4 | % |  | 40.9 | % |
| Costs of services sales | 57.9 | % |  | 58.8 | % |
| Costs of sales | 48.0 | % |  | 48.7 | % |
| Gross margin | 52.0 | % |  | 51.3 | % |
| Selling, general and administrative expenses | 16.0 | % |  | 16.7 | % |
| Research and development expenditures | 8.8 | % |  | 8.8 | % |
| Other charges | 1.3 | % |  | 0.2 | % |
| Intangibles amortization | 3.2 | % |  | 1.4 | % |
| Operating earnings | 22.8 | % |  | 24.1 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.6) | % |  | (2.0) | % |
| Other, net | 1.0 | % |  | 1.1 | % |
| Total other expense | (2.6) | % |  | (0.9) | % |
| Net earnings before income taxes | 20.2 | % |  | 23.2 | % |
| Income tax expense | 4.4 | % |  | 5.3 | % |
| Net earnings | 15.8 | % |  | 17.9 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 15.8 | % |  | 17.8 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-26-000027:8k_2_02:103]
10

[0000068505-26-000027:8k_2_02:104]
GAAP-3

[0000068505-26-000027:8k_2_02:105]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:106]
Condensed Consolidated Balance Sheets

[0000068505-26-000027:8k_2_02:107]
(In millions)

[0000068505-26-000027:8k_2_02:108]
|  | July 4, 2026 |  | December 31, 2025 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 710 |  |  | $ | 1,165 |  |
| Accounts receivable, net | 2,160 |  |  | 2,200 |  |
| Contract assets | 1,455 |  |  | 1,574 |  |
| Inventories, net | 1,333 |  |  | 983 |  |
| Other current assets | 474 |  |  | 378 |  |
| Total current assets | 6,132 |  |  | 6,300 |  |
| Property, plant and equipment, net | 1,167 |  |  | 1,165 |  |
| Operating lease assets | 571 |  |  | 581 |  |
| Investments | 300 |  |  | 187 |  |
| Deferred income taxes | 733 |  |  | 761 |  |
| Goodwill | 6,883 |  |  | 6,800 |  |
| Intangible assets, net | 2,951 |  |  | 3,104 |  |
| Other assets | 505 |  |  | 491 |  |
| Total assets | $ | 19,242 |  |  | $ | 19,389 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Short-term borrowings | $ | 615 |  |  | $ | 749 |  |
| Accounts payable | 957 |  |  | 1,134 |  |
| Contract liabilities | 2,341 |  |  | 2,265 |  |
| Accrued liabilities | 1,666 |  |  | 1,930 |  |
| Total current liabilities | 5,579 |  |  | 6,078 |  |
| Long-term debt | 8,417 |  |  | 8,413 |  |
| Operating lease liabilities | 442 |  |  | 471 |  |
| Other liabilities | 2,116 |  |  | 2,000 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 2,672 |  |  | 2,410 |  |
| Non-controlling interests | 16 |  |  | 17 |  |
| Total liabilities and stockholders’ equity | $ | 19,242 |  |  | $ | 19,389 |  |

[0000068505-26-000027:8k_2_02:109]
11

[0000068505-26-000027:8k_2_02:110]
GAAP-4

[0000068505-26-000027:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:112]
Condensed Consolidated Statements of Cash Flows

[0000068505-26-000027:8k_2_02:113]
(In millions)

[0000068505-26-000027:8k_2_02:114]
|  | Three Months Ended |
|  | July 4, 2026 |  | June 28, 2025 |
| Operating |  |  |  |
| Net earnings | $ | 558 |  |  | $ | 515 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 148 |  |  | 86 |  |
| Contingent earnout adjustment | 16 |  |  | — |  |
| Non-cash other income | (8) |  |  | (12) |  |
| Share-based compensation expenses | 104 |  |  | 74 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (119) |  |  | (68) |  |
| Inventories | (156) |  |  | (22) |  |
| Other current assets and contract assets | (94) |  |  | (44) |  |
| Accounts payable, accrued liabilities and contract liabilities | 82 |  |  | (281) |  |
| Other assets and liabilities | (72) |  |  | 24 |  |
| Deferred income taxes | 10 |  |  | — |  |
| Net cash provided by operating activities | 469 |  |  | 272 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (100) |  |  | (14) |  |
| Proceeds from sales of investments and businesses, net | 4 |  |  | 2 |  |
| Capital expenditures | (55) |  |  | (48) |  |
| Net cash used for investing activities | (151) |  |  | (60) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | — |  |  | 1,983 |  |
| Net proceeds from short-term borrowings | 65 |  |  | — |  |
| Repayments of short-term debt | — |  |  | (252) |  |
| Revolving credit facility renewal fees | — |  |  | (5) |  |
| Issuances of common stock, net of tax | (3) |  |  | 54 |  |
| Purchases of common stock | (331) |  |  | (218) |  |
| Payments of dividends | (201) |  |  | (182) |  |
| Payments of dividends to non-controlling interests | (4) |  |  | (4) |  |
| Net cash provided by (used for) financing activities | (474) |  |  | 1,376 |  |
| Effect of exchange rate changes on total cash and cash equivalents | (20) |  |  | 54 |  |
| Net increase (decrease) in total cash and cash equivalents | (176) |  |  | 1,642 |  |
| Cash and cash equivalents, beginning of period | 886 |  |  | 1,564 |  |
| Cash and cash equivalents, end of period | $ | 710 |  |  | $ | 3,206 |  |

[0000068505-26-000027:8k_2_02:115]
12

[0000068505-26-000027:8k_2_02:116]
GAAP-5

[0000068505-26-000027:8k_2_02:117]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:118]
Condensed Consolidated Statements of Cash Flows

[0000068505-26-000027:8k_2_02:119]
(In millions)

[0000068505-26-000027:8k_2_02:120]
|  | Six Months Ended |
|  | July 4, 2026 |  | June 28, 2025 |
| Operating |  |  |  |
| Net earnings | $ | 926 |  |  | $ | 947 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 291 |  |  | 167 |  |
| Contingent earnout adjustment | 91 |  |  | — |  |
| Non-cash other income | — |  |  | (5) |  |
| Share-based compensation expenses | 204 |  |  | 140 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 36 |  |  | 129 |  |
| Inventories | (355) |  |  | (84) |  |
| Other current assets and contract assets | 9 |  |  | (122) |  |
| Accounts payable, accrued liabilities and contract liabilities | (208) |  |  | (455) |  |
| Other assets and liabilities | (84) |  |  | 49 |  |
| Deferred income taxes | 10 |  |  | 17 |  |
| Net cash provided by operating activities | 920 |  |  | 783 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (224) |  |  | (464) |  |
| Proceeds from sales of investments and businesses, net | 6 |  |  | 12 |  |
| Capital expenditures | (117) |  |  | (85) |  |
| Proceeds from sales of property, plant and equipment | 1 |  |  | — |  |
| Net cash used for investing activities | (334) |  |  | (537) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | — |  |  | 1,983 |  |
| Net proceeds from short-term borrowings | 65 |  |  | — |  |
| Repayments of short-term debt | (200) |  |  | (252) |  |
| Revolving credit facility renewal fees | — |  |  | (5) |  |
| Issuances of common stock, net of tax | (9) |  |  | (37) |  |
| Purchases of common stock | (449) |  |  | (543) |  |
| Payments of dividends | (402) |  |  | (364) |  |
| Payments of dividends to non-controlling interests | (4) |  |  | (4) |  |
| Net cash provided by (used for) financing activities | (999) |  |  | 778 |  |
| Effect of exchange rate changes on total cash and cash equivalents | (42) |  |  | 80 |  |
| Net increase (decrease) in total cash and cash equivalents | (455) |  |  | 1,104 |  |
| Cash and cash equivalents, beginning of period | 1,165 |  |  | 2,102 |  |
| Cash and cash equivalents, end of period | $ | 710 |  |  | $ | 3,206 |  |

[0000068505-26-000027:8k_2_02:121]
13

[0000068505-26-000027:8k_2_02:122]
Non-GAAP-1

[0000068505-26-000027:8k_2_02:123]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:124]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-26-000027:8k_2_02:125]
(In millions)

[0000068505-26-000027:8k_2_02:126]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 4, 2026 |  | June 28, 2025 |  | July 4, 2026 |  | June 28, 2025 |
| Net cash provided by operating activities |  | $ | 469 |  |  | $ | 272 |  |  | $ | 920 |  |  | $ | 783 |  |
| Capital expenditures |  | (55) |  |  | (48) |  |  | (117) |  |  | (85) |  |
| Free cash flow |  | $ | 414 |  |  | $ | 224 |  |  | $ | 803 |  |  | $ | 698 |  |

[0000068505-26-000027:8k_2_02:127]
14

[0000068505-26-000027:8k_2_02:128]
Non-GAAP-2

[0000068505-26-000027:8k_2_02:129]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:130]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-26-000027:8k_2_02:131]
(In millions)

[0000068505-26-000027:8k_2_02:132]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  | Statement Line |  | July 4, 2026 |  | June 28, 2025 |  | July 4, 2026 |  | June 28, 2025 |
| Net earnings attributable to MSI |  |  |  | $ | 557 |  |  | $ | 513 |  |  | $ | 923 |  |  | $ | 943 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 104 |  |  | $ | 74 |  |  | $ | 204 |  |  | $ | 140 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 95 |  |  | 39 |  |  | 185 |  |  | 76 |  |
| Contingent earnout adjustment |  | Other charges (income) |  | 16 |  |  | — |  |  | 91 |  |  | — |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 15 |  |  | 14 |  |  | 30 |  |  | 31 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 5 |  |  | 2 |  |  | 13 |  |  | 8 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 3 |  |  | — |  |  | 5 |  |  | — |  |
| Legal settlements |  | Other charges (income) |  | 3 |  |  | 1 |  |  | 4 |  |  | 5 |  |
| Hytera-related legal expenses |  | SG&A |  | 1 |  |  | 6 |  |  | 6 |  |  | 20 |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Fixed asset impairments |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Loss on financing issuance costs |  | Other (income) expense |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (13) |  |  | (18) |  |  | (8) |  |  | (13) |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (20) |  |  | (10) |  |  | (60) |  |  | (20) |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 211 |  |  | $ | 110 |  |  | $ | 472 |  |  | $ | 250 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 31 |  | 21 |  | 92 |  | 51 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 180 |  | 89 |  | 380 |  | 199 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 737 |  |  | $ | 602 |  |  | $ | 1,303 |  |  | $ | 1,142 |  |

[0000068505-26-000027:8k_2_02:133]
Calculation of Non-GAAP Tax Rate

[0000068505-26-000027:8k_2_02:134]
(In millions)

[0000068505-26-000027:8k_2_02:135]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 4, 2026 |  | June 28, 2025 |  | July 4, 2026 |  | June 28, 2025 |
| Net earnings before income taxes |  | $ | 742 |  |  | $ | 680 |  |  | $ | 1,182 |  |  | $ | 1,227 |  |
| Total Non-GAAP adjustments before income taxes* |  | 211 |  |  | 110 |  |  | 472 |  |  | 250 |  |
| Non-GAAP Net earnings before income taxes |  | 953 |  |  | 790 |  |  | 1,654 |  |  | 1,477 |  |
| Income tax expense |  | 184 |  |  | 165 |  |  | 256 |  |  | 280 |  |
| Income tax expense on Non-GAAP adjustments** |  | 31 |  |  | 21 |  |  | 92 |  |  | 51 |  |
| Total Non-GAAP Income tax expense |  | $ | 215 |  |  | $ | 186 |  |  | $ | 348 |  |  | $ | 331 |  |
| Non-GAAP Tax rate |  | 22.6 | % |  | 23.5 | % |  | 21.0 | % |  | 22.4 | % |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-26-000027:8k_2_02:136]
15

[0000068505-26-000027:8k_2_02:137]
Non-GAAP-2

[0000068505-26-000027:8k_2_02:138]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-26-000027:8k_2_02:139]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  | Statement Line |  | July 4, 2026 |  | June 28, 2025 |  | July 4, 2026 |  | June 28, 2025 |
| Net earnings attributable to MSI |  |  |  | $ | 3.33 |  |  | $ | 3.04 |  |  | $ | 5.51 |  |  | $ | 5.57 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.61 |  |  | $ | 0.44 |  |  | $ | 1.22 |  |  | $ | 0.83 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.56 |  |  | 0.23 |  |  | 1.10 |  |  | 0.45 |  |
| Contingent earnout adjustment |  | Other charges (income) |  | 0.10 |  |  | — |  |  | 0.54 |  |  | — |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.09 |  |  | 0.08 |  |  | 0.18 |  |  | 0.18 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.03 |  |  | 0.01 |  |  | 0.08 |  |  | 0.05 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.02 |  |  | — |  |  | 0.03 |  |  | — |  |
| Legal settlements |  | Other charges (income) |  | 0.02 |  |  | 0.01 |  |  | 0.02 |  |  | 0.03 |  |
| Hytera-related legal expenses |  | SG&A |  | 0.01 |  |  | 0.04 |  |  | 0.04 |  |  | 0.12 |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 0.01 |  |  | — |  |  | 0.01 |  |  | 0.01 |  |
| Fixed asset impairments |  | Other charges (income) |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Loss on financing issuance costs |  | Other (income) expense |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (0.08) |  |  | (0.11) |  |  | (0.05) |  |  | (0.08) |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (0.12) |  |  | (0.06) |  |  | (0.36) |  |  | (0.12) |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 1.26 |  |  | $ | 0.65 |  |  | $ | 2.82 |  |  | $ | 1.48 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.18 |  | 0.12 |  | 0.55 |  | 0.31 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 1.08 |  | 0.53 |  | 2.27 |  | 1.17 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 4.41 |  |  | $ | 3.57 |  |  | $ | 7.78 |  |  | $ | 6.74 |  |
| Diluted Weighted Average Common Shares |  |  |  | 167.2 |  |  | 168.8 |  |  | 167.6 |  |  | 169.4 |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |

[0000068505-26-000027:8k_2_02:140]
16

[0000068505-26-000027:8k_2_02:141]
Non-GAAP-3

[0000068505-26-000027:8k_2_02:142]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:143]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-26-000027:8k_2_02:144]
(In millions)

[0000068505-26-000027:8k_2_02:145]
|  |  | Three Months Ended |
|  |  | July 4, 2026 |  | June 28, 2025 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,908 |  |  | $ | 1,225 |  |  | $ | 3,133 |  |  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |
| Operating earnings ("OE") |  | 453 |  |  | 356 |  |  | 809 |  |  | 363 |  |  | 329 |  |  | 692 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 68 |  |  | 36 |  |  | 104 |  |  | 54 |  |  | 20 |  |  | 74 |  |
| Intangible assets amortization expense |  | 65 |  |  | 30 |  |  | 95 |  |  | 16 |  |  | 23 |  |  | 39 |  |
| Contingent earnout adjustment |  | 15 |  |  | 1 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |
| Reorganization of business charges |  | 10 |  |  | 5 |  |  | 15 |  |  | 10 |  |  | 4 |  |  | 14 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 3 |  |  | 5 |  |  | 2 |  |  | — |  |  | 2 |  |
| Operating lease asset impairments |  | 2 |  |  | 1 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |
| Legal settlements |  | 2 |  |  | 1 |  |  | 3 |  |  | 1 |  |  | — |  |  | 1 |  |
| Hytera-related legal expenses |  | 1 |  |  | — |  |  | 1 |  |  | 6 |  |  | — |  |  | 6 |  |
| Fixed asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Gain on Hytera litigation |  | (20) |  |  | — |  |  | (20) |  |  | (10) |  |  | — |  |  | (10) |  |
| Total above-OE non-GAAP adjustments |  | 146 |  |  | 77 |  |  | 223 |  |  | 79 |  |  | 47 |  |  | 126 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 599 |  |  | $ | 433 |  |  | $ | 1,032 |  |  | $ | 442 |  |  | $ | 376 |  |  | $ | 818 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 23.7 | % |  | 29.1 | % |  | 25.8 | % |  | 22.0 | % |  | 29.6 | % |  | 25.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 31.4 | % |  | 35.3 | % |  | 32.9 | % |  | 26.7 | % |  | 33.8 | % |  | 29.6 | % |

[0000068505-26-000027:8k_2_02:146]
17

[0000068505-26-000027:8k_2_02:147]
Non-GAAP-4

[0000068505-26-000027:8k_2_02:148]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:149]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-26-000027:8k_2_02:150]
(In millions)

[0000068505-26-000027:8k_2_02:151]
|  |  | Six Months Ended |
|  |  | July 4, 2026 |  | June 28, 2025 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 3,468 |  |  | $ | 2,380 |  |  | $ | 5,848 |  |  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |
| Operating earnings ("OE") |  | 666 |  |  | 668 |  |  | 1,334 |  |  | 715 |  |  | 559 |  |  | 1,274 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 134 |  |  | 70 |  |  | 204 |  |  | 102 |  |  | 38 |  |  | 140 |  |
| Intangible assets amortization expense |  | 127 |  |  | 58 |  |  | 185 |  |  | 32 |  |  | 44 |  |  | 76 |  |
| Contingent earnout adjustment |  | 82 |  |  | 9 |  |  | 91 |  |  | — |  |  | — |  |  | — |  |
| Reorganization of business charges |  | 21 |  |  | 9 |  |  | 30 |  |  | 22 |  |  | 9 |  |  | 31 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 11 |  |  | 13 |  |  | 2 |  |  | 6 |  |  | 8 |  |
| Hytera-related legal expenses |  | 6 |  |  | — |  |  | 6 |  |  | 20 |  |  | — |  |  | 20 |  |
| Operating lease asset impairments |  | 3 |  |  | 2 |  |  | 5 |  |  | — |  |  | — |  |  | — |  |
| Legal settlements |  | 3 |  |  | 1 |  |  | 4 |  |  | 3 |  |  | 2 |  |  | 5 |  |
| Fixed asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Gain on Hytera litigation |  | (60) |  |  | — |  |  | (60) |  |  | (20) |  |  | — |  |  | (20) |  |
| Total above-OE non-GAAP adjustments |  | 319 |  |  | 160 |  |  | 479 |  |  | 161 |  |  | 99 |  |  | 260 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 985 |  |  | $ | 828 |  |  | $ | 1,813 |  |  | $ | 876 |  |  | $ | 658 |  |  | $ | 1,534 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 19.2 | % |  | 28.1 | % |  | 22.8 | % |  | 22.4 | % |  | 26.7 | % |  | 24.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.4 | % |  | 34.8 | % |  | 31.0 | % |  | 27.4 | % |  | 31.4 | % |  | 29.0 | % |

[0000068505-26-000027:8k_2_02:152]
18

[0000068505-26-000027:8k_2_02:153]
Non-GAAP-5

[0000068505-26-000027:8k_2_02:154]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000027:8k_2_02:155]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-26-000027:8k_2_02:156]
(In millions)

[0000068505-26-000027:8k_2_02:157]
|  |  | Three Months Ended |  |  |
|  |  | July 4, 2026 |  | June 28, 2025 |  | % Change |
| Net sales |  | $ | 3,133 |  |  | $ | 2,765 |  |  | 13 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 243 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,890 |  |  | $ | 2,765 |  |  | 5 | % |
|  |  | Six Months Ended |  |  |
|  |  | July 4, 2026 |  | June 28, 2025 |  | % Change |
| Net sales |  | $ | 5,848 |  |  | $ | 5,293 |  |  | 10 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 466 |  |  | 3 |  |  |  |
| Organic revenue |  | $ | 5,382 |  |  | $ | 5,290 |  |  | 2 | % |
