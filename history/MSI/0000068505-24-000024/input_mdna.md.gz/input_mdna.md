# MSI MD&A — 0000068505-24-000024


## mdna

[0000068505-24-000024:mdna:1]
[same as prior period, unchanged from 0000068505-24-000016:mdna:1]

[0000068505-24-000024:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and six months ended June 29, 2024 and July 1, 2023, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2023 (the "Form 10-K").

[0000068505-24-000024:mdna:3]
[same as prior period, unchanged from 0000068505-24-000016:mdna:3]

[0000068505-24-000024:mdna:4]
[same as prior period, unchanged from 0000068505-24-000016:mdna:4]

[0000068505-24-000024:mdna:5]
[same as prior period, unchanged from 0000068505-24-000016:mdna:5]

[0000068505-24-000024:mdna:6]
[same as prior period, unchanged from 0000068505-24-000016:mdna:6]

[0000068505-24-000024:mdna:7]
[same as prior period, unchanged from 0000068505-24-000016:mdna:7]

[0000068505-24-000024:mdna:8]
[same as prior period, unchanged from 0000068505-24-000016:mdna:8]

[0000068505-24-000024:mdna:9]
[same as prior period, unchanged from 0000068505-24-000016:mdna:9]

[0000068505-24-000024:mdna:10]
[same as prior period, unchanged from 0000068505-24-000016:mdna:27]

[0000068505-24-000024:mdna:11]
Second Quarter Financial Results

[0000068505-24-000024:mdna:12]
•Net sales were $2.6 billion in the second quarter of 2024 compared to $2.4 billion in the second quarter of 2023.

[0000068505-24-000024:mdna:13]
•Operating earnings were $644 million in the second quarter of 2024 compared to $518 million in the second quarter of 2023.

[0000068505-24-000024:mdna:14]
•Net earnings attributable to Motorola Solutions, Inc. was $443 million, or $2.60 per diluted common share, in the second quarter of 2024, compared to net earnings of $371 million, or $2.15 per diluted common share, in the second quarter of 2023.

[0000068505-24-000024:mdna:15]
•Operating cash flow increased $477 million to $562 million in the first half of 2024 compared to $85 million in the first half of 2023.

[0000068505-24-000024:mdna:16]
•We repurchased $110 million of common stock and paid $326 million in dividends in the first half of 2024.

[0000068505-24-000024:mdna:17]
[same as prior period, unchanged from 0000068505-24-000016:mdna:16]

[0000068505-24-000024:mdna:18]
[same as prior period, unchanged from 0000068505-24-000016:mdna:17]

[0000068505-24-000024:mdna:19]
[same as prior period, unchanged from 0000068505-24-000016:mdna:18]

[0000068505-24-000024:mdna:20]
In 2023, the CMA imposed a legal order on Airwave which implemented a prospective price control on Airwave (the "Charge Control"). After the Competition Appeal Tribunal ("CAT") dismissed our appeal of the CMA's final decision on December 22, 2023, we filed an application with the United Kingdom Court of Appeal on February 13, 2024, requesting that it hear our appeal of the CAT judgment. On June 21, 2024, the United Kingdom Court of Appeal ordered a hearing on our application to be held later this year; which was subsequently set for November 11 and 12, 2024. Since August 1, 2023, revenue under the Airwave contract has been recognized in accordance with the Charge Control, and will continue to be unless the United Kingdom Court of Appeal were to reverse the CAT's judgment and overturn the Charge Control.

[0000068505-24-000024:mdna:21]
[same as prior period, unchanged from 0000068505-24-000016:mdna:20]

[0000068505-24-000024:mdna:22]
Our backlog for Airwave services contracted with the UK Home Office through December 31, 2026 was previously reduced by $777 million to align with the Charge Control. In the first quarter of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, we have recorded additional backlog of $748 million to reflect the incremental three years of services. On April 11, 2024, we filed proceedings in the UK High Court challenging the decision of the UK Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable UK procurement and public law. The hearing on this matter has been set to commence on April 22, 2025. The backlog related to the incremental years of service contemplated in the Deferred National Shutdown Notice could change depending on the outcome of the proceedings.

[0000068505-24-000024:mdna:23]
[same as prior period, unchanged from 0000068505-24-000016:mdna:22]

[0000068505-24-000024:mdna:24]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Video Security and Access Control | Products and Systems Integration | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |
| Video Security and Access Control | Products and Systems Integration | IPVideo | Creator of a multifunctional safety and security device. | $170 million and share-based compensation of $5 million | December 15, 2023 |

[0000068505-24-000024:mdna:25]
[same as prior period, unchanged from 0000068505-24-000016:mdna:24]

[0000068505-24-000024:mdna:26]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | June 29, 2024 |  | % ofSales* |  | July 1, 2023 |  | % ofSales* |  | June 29, 2024 |  | % ofSales* |  | July 1, 2023 |  | % ofSales* |
| Net sales from products | $ | 1,563 |  |  |  |  | $ | 1,349 |  |  |  |  | $ | 2,968 |  |  |  |  | $ | 2,573 |  |  |  |
| Net sales from services | 1,065 |  |  |  |  | 1,054 |  |  |  |  | 2,049 |  |  |  |  | 2,001 |  |  |  |
| Net sales | 2,628 |  |  |  |  | 2,403 |  |  |  |  | 5,017 |  |  |  |  | 4,574 |  |  |  |
| Costs of products sales | 653 |  |  | 41.8 | % |  | 636 |  |  | 47.1 | % |  | 1,252 |  |  | 42.2 | % |  | 1,209 |  |  | 47.0 | % |
| Costs of services sales | 636 |  |  | 59.7 | % |  | 578 |  |  | 54.8 | % |  | 1,234 |  |  | 60.2 | % |  | 1,130 |  |  | 56.5 | % |
| Costs of sales | 1,289 |  |  |  |  | 1,214 |  |  |  |  | 2,486 |  |  |  |  | 2,339 |  |  |  |
| Gross margin | 1,339 |  |  | 51.0 | % |  | 1,189 |  |  | 49.5 | % |  | 2,531 |  |  | 50.4 | % |  | 2,235 |  |  | 48.9 | % |
| Selling, general and administrative expenses | 430 |  |  | 16.4 | % |  | 390 |  |  | 16.2 | % |  | 827 |  |  | 16.5 | % |  | 757 |  |  | 16.6 | % |
| Research and development expenditures | 220 |  |  | 8.4 | % |  | 215 |  |  | 8.9 | % |  | 437 |  |  | 8.7 | % |  | 426 |  |  | 9.3 | % |
| Other charges | 45 |  |  | 1.7 | % |  | 66 |  |  | 2.7 | % |  | 104 |  |  | 2.1 | % |  | 135 |  |  | 3.0 | % |
| Operating earnings | 644 |  |  | 24.5 | % |  | 518 |  |  | 21.6 | % |  | 1,163 |  |  | 23.2 | % |  | 917 |  |  | 20.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (69) |  |  | (2.6) | % |  | (57) |  |  | (2.4) | % |  | (113) |  |  | (2.3) | % |  | (111) |  |  | (2.4) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | — |  |  | — | % |  | — |  |  | — | % |  | 1 |  |  | — | % |
| Other, net | 5 |  |  | 0.2 | % |  | 26 |  |  | 1.1 | % |  | (560) |  |  | (11.2) | % |  | 39 |  |  | 0.9 | % |
| Total other expense | (64) |  |  | (2.4) | % |  | (31) |  |  | (1.3) | % |  | (673) |  |  | (13.4) | % |  | (71) |  |  | (1.6) | % |
| Net earnings before income taxes | 580 |  |  | 22.1 | % |  | 487 |  |  | 20.3 | % |  | 490 |  |  | 9.8 | % |  | 846 |  |  | 18.5 | % |
| Income tax expense | 135 |  |  | 5.1 | % |  | 114 |  |  | 4.7 | % |  | 83 |  |  | 1.7 | % |  | 194 |  |  | 4.2 | % |
| Net earnings | 445 |  |  | 16.9 | % |  | 373 |  |  | 15.5 | % |  | 407 |  |  | 8.1 | % |  | 652 |  |  | 14.3 | % |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 443 |  |  | 16.8 | % |  | $ | 371 |  |  | 15.4 | % |  | $ | 404 |  |  | 8.0 | % |  | $ | 649 |  |  | 14.2 | % |
| Earnings per diluted common share | $ | 2.60 |  |  |  |  | $ | 2.15 |  |  |  |  | $ | 2.37 |  |  |  |  | $ | 3.76 |  |  |  |

[0000068505-24-000024:mdna:27]
[same as prior period, unchanged from 0000068505-24-000016:mdna:26]

[0000068505-24-000024:mdna:28]
29

[0000068505-24-000024:mdna:29]
Results of Operations—Three months ended June 29, 2024 compared to three months ended July 1, 2023

[0000068505-24-000024:mdna:30]
The results of operations for the second quarter of 2024 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-24-000024:mdna:31]
[same as prior period, unchanged from 0000068505-24-000016:mdna:30]

[0000068505-24-000024:mdna:32]
[same as prior period, unchanged from 0000068505-24-000016:mdna:31]

[0000068505-24-000024:mdna:33]
[same as prior period, unchanged from 0000068505-24-000016:mdna:32]

[0000068505-24-000024:mdna:34]
[same as prior period, unchanged from 0000068505-24-000016:mdna:33]

[0000068505-24-000024:mdna:35]
[same as prior period, unchanged from 0000068505-24-000016:mdna:34]

[0000068505-24-000024:mdna:36]
|  | Three Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |  | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |
| International | 413 |  |  | 298 |  |  | 711 |  |  | 412 |  |  | 350 |  |  | 762 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |  | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |
| Video | 295 |  |  | 181 |  |  | 476 |  |  | 287 |  |  | 146 |  |  | 433 |  |
| Command Center | — |  |  | 211 |  |  | 211 |  |  | — |  |  | 194 |  |  | 194 |  |
| Total | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Operating earnings | $ | 379 |  |  | $ | 265 |  |  | $ | 644 |  |  | $ | 212 |  |  | $ | 306 |  |  | $ | 518 |  |
| Operating margins | 22.9 | % |  | 27.3 | % |  | 24.5 | % |  | 14.8 | % |  | 31.7 | % |  | 21.6 | % |

[0000068505-24-000024:mdna:37]
[same as prior period, unchanged from 0000068505-24-000016:mdna:36]

[0000068505-24-000024:mdna:38]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in the second quarter of 2024 and 60% in the second quarter of 2023. The Software and Services segment’s net sales represented 37% of our net sales in the second quarter of 2024 and 40% in the second quarter of 2023.

[0000068505-24-000024:mdna:39]
Net sales increased $225 million, or 9%, in the second quarter of 2024 compared to the second quarter of 2023. The $221 million, or 15%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 21% in the North America region. The $4 million increase in net sales within the Software and Services segment was driven by an increase of 9% in the North America region and partially offset by a decrease of 15% in the International region. Net sales includes:

[0000068505-24-000024:mdna:40]
•an increase in the Products and Systems Integration segment, inclusive of $12 million of revenue from acquisitions, driven by an increase in LMR and Video;

[0000068505-24-000024:mdna:41]
•an increase in the Software and Services segment, inclusive of $1 million of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by a decrease LMR services due to the revenue reduction on Airwave services in accordance with the Charge Control and the exit of ESN; and

[0000068505-24-000024:mdna:42]
•inclusive of $5 million from unfavorable currency rates.

[0000068505-24-000024:mdna:43]
[same as prior period, unchanged from 0000068505-24-000016:mdna:42]

[0000068505-24-000024:mdna:44]
•a 17% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-24-000024:mdna:45]
•a 7% decrease in the International region, inclusive of revenue from acquisitions, driven by a decrease in LMR due to the revenue reduction on Airwave services in accordance with the Charge Control and the exit of ESN, partially offset by an increase in Video and Command Center.

[0000068505-24-000024:mdna:46]
[same as prior period, unchanged from 0000068505-24-000016:mdna:45]

[0000068505-24-000024:mdna:47]
The 15% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000024:mdna:48]
•$213 million, or 19% growth in LMR, driven by the North America and International regions, primarily due to an increase in devices;

[0000068505-24-000024:mdna:49]
•$8 million, or 3% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-24-000024:mdna:50]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-24-000024:mdna:51]
[same as prior period, unchanged from 0000068505-24-000016:mdna:49]

[0000068505-24-000024:mdna:52]
The Software and Services segment was flat driven by the following:

[0000068505-24-000024:mdna:53]
•$35 million, or 24% growth in Video, driven by the North America and International regions; and

[0000068505-24-000024:mdna:54]
•$17 million, or 9% growth in Command Center, driven by the North America and International regions; partially offset by

[0000068505-24-000024:mdna:55]
•$48 million, or 8% decrease in LMR, driven by the International region, the revenue reduction on Airwave services in accordance with the Charge Control, and the exit of ESN, partially offset by growth in the North America region; and

[0000068505-24-000024:mdna:56]
•inclusive of $3 million from unfavorable currency rates.

[0000068505-24-000024:mdna:57]
[same as prior period, unchanged from 0000068505-24-000016:mdna:55]

[0000068505-24-000024:mdna:58]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |  | % Change |
| Gross margin | $ | 1,339 |  |  | $ | 1,189 |  |  | 13 | % |

[0000068505-24-000024:mdna:59]
Gross margin was 51.0% of net sales in the second quarter of 2024 compared to 49.5% in the second quarter of 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-24-000024:mdna:60]
[same as prior period, unchanged from 0000068505-24-000016:mdna:58]

[0000068505-24-000024:mdna:61]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control.

[0000068505-24-000024:mdna:62]
[same as prior period, unchanged from 0000068505-24-000016:mdna:60]

[0000068505-24-000024:mdna:63]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |  | % Change |
| Selling, general and administrative expenses | $ | 430 |  |  | $ | 390 |  |  | 10 | % |

[0000068505-24-000024:mdna:64]
SG&A expenses increased 10% in the second quarter of 2024 compared to the second quarter of 2023. The increase in SG&A expenses was primarily due to higher employee incentive costs and an expansion of headcount in the sales force. SG&A expenses were 16.4% of net sales in the second quarter of 2024 compared to 16.2% of net sales in the second quarter of 2023.

[0000068505-24-000024:mdna:65]
[same as prior period, unchanged from 0000068505-24-000016:mdna:63]

[0000068505-24-000024:mdna:66]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |  | % Change |
| Research and development expenditures | $ | 220 |  |  | $ | 215 |  |  | 2 | % |

[0000068505-24-000024:mdna:67]
R&D expenditures increased 2% in the second quarter of 2024 compared to the second quarter of 2023 primarily due to higher employee incentive costs including share-based compensation. R&D expenditures were 8.4% of net sales in the second quarter of 2024 compared to 8.9% of net sales in the second quarter of 2023.

[0000068505-24-000024:mdna:68]
[same as prior period, unchanged from 0000068505-24-000016:mdna:66]

[0000068505-24-000024:mdna:69]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Other charges | $ | 45 |  |  | $ | 66 |  |

[0000068505-24-000024:mdna:70]
Other charges decreased by $21 million in the second quarter of 2024 compared to the second quarter of 2023. The change was driven primarily by the following:

[0000068505-24-000024:mdna:71]
•$15 million of environmental reserve expense in the second quarter of 2023 that did not occur in the second quarter of 2024; and

[0000068505-24-000024:mdna:72]
•$36 million of intangible asset amortization expense in the second quarter of 2024 compared to $43 million of intangible asset amortization expense in the second quarter of 2023; partially offset by

[0000068505-24-000024:mdna:73]
•$4 million of acquisition-related transaction fees in the second quarter of 2024 that did not occur in the second quarter of 2023.

[0000068505-24-000024:mdna:74]
[same as prior period, unchanged from 0000068505-24-000016:mdna:71]

[0000068505-24-000024:mdna:75]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Operating earnings from Products and Systems Integration | $ | 379 |  |  | $ | 212 |  |
| Operating earnings from Software and Services | 265 |  |  | 306 |  |
| Operating earnings | $ | 644 |  |  | $ | 518 |  |

[0000068505-24-000024:mdna:76]
Operating earnings increased $126 million, or 24%, in the second quarter of 2024 compared to the second quarter of 2023. The increase in Operating earnings was due to:

[0000068505-24-000024:mdna:77]
•$167 million increase in the Products and Systems Integration segment, primarily driven by higher sales, favorable change in year-over-year mix, and improved operating leverage, partially offset by higher employee incentive costs; partially offset by

[0000068505-24-000024:mdna:78]
•$41 million decrease in the Software and Services segment, driven by the revenue reduction on Airwave services in accordance with the Charge Control, partially offset by improved operating leverage.

[0000068505-24-000024:mdna:79]
[same as prior period, unchanged from 0000068505-24-000016:mdna:76]

[0000068505-24-000024:mdna:80]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Interest expense, net | $ | (69) |  |  | $ | (57) |  |

[0000068505-24-000024:mdna:81]
The $12 million increase in Interest expense, net in the second quarter of 2024 compared to the second quarter of 2023 was primarily driven by higher outstanding debt and an interest accrual related to audits with taxing authorities in foreign jurisdictions, partially offset by higher interest income.

[0000068505-24-000024:mdna:82]
[same as prior period, unchanged from 0000068505-24-000016:mdna:79]

[0000068505-24-000024:mdna:83]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Other, net | $ | 5 |  |  | $ | 26 |  |

[0000068505-24-000024:mdna:84]
The $21 million decrease in Other, net in the second quarter of 2024 compared to the second quarter of 2023 was primarily driven by:

[0000068505-24-000024:mdna:85]
•$11 million loss on fair value adjustments to equity investments in the second quarter of 2024 compared to a $16 million gain on fair value adjustments to equity investments in the second quarter of 2023;

[0000068505-24-000024:mdna:86]
•$5 million loss on derivatives in the second quarter of 2024 compared to a $9 million gain on derivatives in the second quarter of 2023; and

[0000068505-24-000024:mdna:87]
•$11 million loss on assessments of uncertain tax positions in the second quarter of 2024 that did not occur in the second quarter of 2023; partially offset by

[0000068505-24-000024:mdna:88]
•$3 million of foreign currency gains in the second quarter of 2024 compared to $21 million of foreign currency losses in the second quarter of 2023;

[0000068505-24-000024:mdna:89]
•$31 million of net periodic pension and postretirement benefit in the second quarter of 2024 compared to $24 million of net periodic pension and postretirement benefit in the second quarter of 2023; and

[0000068505-24-000024:mdna:90]
•$3 million loss on investment impairments in the second quarter of 2023 that did not occur in the second quarter of 2024.

[0000068505-24-000024:mdna:91]
[same as prior period, unchanged from 0000068505-24-000016:mdna:88]

[0000068505-24-000024:mdna:92]
|  | Three Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Income tax expense | $ | 135 |  |  | $ | 114 |  |

[0000068505-24-000024:mdna:93]
Income tax expense increased by $21 million in the second quarter of 2024 compared to the second quarter of 2023, resulting in an effective tax rate of 23%. Our effective tax rate for the three months ended June 29, 2024 of 23% was equal to the effective tax rate for the three months ended July 1, 2023 of 23%, primarily due to tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, offset by lower excess tax benefits of share-based compensation in 2024.

[0000068505-24-000024:mdna:94]
Results of Operations—Six months ended June 29, 2024 compared to Six months ended July 1, 2023

[0000068505-24-000024:mdna:95]
|  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |  | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |
| International | 821 |  |  | 586 |  |  | 1,407 |  |  | 765 |  |  | 676 |  |  | 1,441 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |  | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |
| Video | 529 |  |  | 345 |  |  | 874 |  |  | 510 |  |  | 282 |  |  | 792 |  |
| Command Center | — |  |  | 379 |  |  | 379 |  |  | — |  |  | 349 |  |  | 349 |  |
| Total | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Operating earnings | $ | 689 |  |  | $ | 474 |  |  | $ | 1,163 |  |  | $ | 388 |  |  | $ | 529 |  |  | $ | 917 |  |
| Operating margins | 21.9 | % |  | 25.4 | % |  | 23.2 | % |  | 14.2 | % |  | 28.8 | % |  | 20.0 | % |

[0000068505-24-000024:mdna:96]
Net Sales

[0000068505-24-000024:mdna:97]
The Products and Systems Integration segment's net sales represented 63% of our net sales in the first half of 2024 and 60% in the first half of 2023. Net sales from the Software and Services segment represented 37% of our net sales in the first half of 2024 and 40% in the first half of 2023.

[0000068505-24-000024:mdna:98]
Net sales increased $443 million, or 10%, in the first half of 2024 compared to the first half of 2023. The $409 million, or 15%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 18% in the North America region and an increase of 7% in the International region. The $34 million, or 2%, increase in net sales within the Software and Services segment was driven by an increase of 11% in the North America region, partially offset by a decrease of 13% in the International region. Net sales includes:

[0000068505-24-000024:mdna:99]
•an increase in the Products and Systems Integration segment, inclusive of $21 million of revenue from acquisitions, driven by an increase in LMR and Video;

[0000068505-24-000024:mdna:100]
•an increase in Software and Services, inclusive of $1 million of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by a decrease in LMR driven by the revenue reduction on Airwave services in accordance with the Charge Control and the exit of ESN; and

[0000068505-24-000024:mdna:101]
•inclusive of $4 million from unfavorable currency rates.

[0000068505-24-000024:mdna:102]
Regional results include:

[0000068505-24-000024:mdna:103]
•a 15% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-24-000024:mdna:104]
•a 2% decrease in the International region, inclusive of revenue from acquisitions, driven by a decrease in LMR due to the revenue reduction on Airwave services in accordance with the Charge Control and the exit of ESN, partially offset by an increase in Video and Command Center.

[0000068505-24-000024:mdna:105]
Products and Systems Integration

[0000068505-24-000024:mdna:106]
The 15% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000024:mdna:107]
•$390 million, or 17% growth in LMR, driven by both the North America and International regions, primarily due to an increase in devices;

[0000068505-24-000024:mdna:108]
•$19 million, or 4% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-24-000024:mdna:109]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-24-000024:mdna:110]
Software and Services

[0000068505-24-000024:mdna:111]
The 2% increase in the Software and Services segment was driven by the following:

[0000068505-24-000024:mdna:112]
•$63 million, or 22% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-24-000024:mdna:113]
•$30 million, or 9% growth in Command Center, driven by the North America and International regions; partially offset by

[0000068505-24-000024:mdna:114]
•$59 million, or 5% decrease in LMR, driven by the International region due to the revenue reduction on Airwave services in accordance with the Charge Control and the exit of ESN, partially offset by the North America region; and

[0000068505-24-000024:mdna:115]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-24-000024:mdna:116]
Gross Margin

[0000068505-24-000024:mdna:117]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |  | % Change |
| Gross margin | $ | 2,531 |  |  | $ | 2,235 |  |  | 13 | % |

[0000068505-24-000024:mdna:118]
Gross margin was 50.4% of net sales in the first half of 2024 compared to 48.9% in the first half of 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-24-000024:mdna:119]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales and favorable mix; partially offset by

[0000068505-24-000024:mdna:120]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, driven by the revenue reduction on Airwave services in accordance with the Charge Control.

[0000068505-24-000024:mdna:121]
Selling, General and Administrative Expenses

[0000068505-24-000024:mdna:122]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |  | % Change |
| Selling, general and administrative expenses | $ | 827 |  |  | $ | 757 |  |  | 9 | % |

[0000068505-24-000024:mdna:123]
SG&A expenses increased 9% in the first half of 2024 compared to the first half of 2023. The increase in SG&A expenses was primarily due to higher employee incentive costs, including share-based compensation, higher legal costs, including settlements, and higher expenses associated with acquired businesses. SG&A expenses were 16.5% of net sales in the first half of 2024 compared to 16.6% of net sales in the first half of 2023.

[0000068505-24-000024:mdna:124]
Research and Development Expenditures

[0000068505-24-000024:mdna:125]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |  | % Change |
| Research and development expenditures | $ | 437 |  |  | $ | 426 |  |  | 3 | % |

[0000068505-24-000024:mdna:126]
R&D expenditures increased 3% in the first half of 2024 compared to the first half of 2023 primarily due to higher employee incentive costs, including share-based compensation. R&D expenditures were 8.7% of net sales in the first half of 2024 compared to 9.3% of net sales in the first half of 2023.

[0000068505-24-000024:mdna:127]
Other Charges

[0000068505-24-000024:mdna:128]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Other charges | $ | 104 |  |  | $ | 135 |  |

[0000068505-24-000024:mdna:129]
Other charges decreased by $31 million in the first half of 2024 compared to the first half of 2023. The change was driven primarily by the following:

[0000068505-24-000024:mdna:130]
•$76 million of intangible asset amortization expense in the first half of 2024 compared to $98 million of intangible asset amortization expense in the first half of 2023;

[0000068505-24-000024:mdna:131]
•$15 million of environmental reserve expense in the first half of 2023 that did not occur in the first half of 2024; and

[0000068505-24-000024:mdna:132]
•$3 million of fixed asset impairments in the first half of 2023 that did not occur in the first half of 2024; partially offset by

[0000068505-24-000024:mdna:133]
•$6 million of legal settlement charges in the first half of 2024 that did not occur in the first half of 2023; and

[0000068505-24-000024:mdna:134]
•$7 million of acquisition-related transaction fees in the first half of 2024 compared to $2 million of acquisition-related transaction fees in the first half of 2023.

[0000068505-24-000024:mdna:135]
Operating Earnings

[0000068505-24-000024:mdna:136]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Operating earnings from Products and Systems Integration | $ | 689 |  |  | $ | 388 |  |
| Operating earnings from Software and Services | 474 |  |  | 529 |  |
| Operating earnings | $ | 1,163 |  |  | $ | 917 |  |

[0000068505-24-000024:mdna:137]
Operating earnings increased $246 million, or 27%, in the first half of 2024 compared to the first half of 2023. The increase in Operating earnings was due to:

[0000068505-24-000024:mdna:138]
•$301 million increase in the Products and Systems Integration segment, primarily driven by higher sales, favorable mix, and a reduction in intangible asset amortization, partially offset by higher employee incentive costs and higher expenses associated with acquired businesses; partially offset by

[0000068505-24-000024:mdna:139]
•$55 million decrease in the Software and Services segment, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control and higher employee incentive costs, partially offset by a reduction in intangible amortization expenses.

[0000068505-24-000024:mdna:140]
Interest Expense, net

[0000068505-24-000024:mdna:141]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Interest expense, net | $ | (113) |  |  | $ | (111) |  |

[0000068505-24-000024:mdna:142]
The $2 million increase in net interest expense in the first half of 2024 compared to the first half of 2023 was primarily driven by higher outstanding debt and an interest accrual related to the settlement of audits with taxing authorities in foreign jurisdictions, partially offset by higher interest income earned on cash.

[0000068505-24-000024:mdna:143]
Other, net

[0000068505-24-000024:mdna:144]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Other, net | $ | (560) |  |  | $ | 39 |  |

[0000068505-24-000024:mdna:145]
The $599 million decrease in Other, net in the first half of 2024 compared to the first half of 2023 was primarily driven by:

[0000068505-24-000024:mdna:146]
•$585 million loss from the extinguishment of the $1.0 billion of 1.75% senior convertible notes issued to Silver Lake Partners and scheduled to mature in September 2024 (the "Silver Lake Convertible Debt") in the first half of 2024;

[0000068505-24-000024:mdna:147]
•$15 million of losses on derivative instruments in the first half of 2024 compared to $17 million of gains on derivative instruments in the first half of 2023;

[0000068505-24-000024:mdna:148]
•$13 million loss on fair value adjustments to equity investments in the first half of 2024 compared to a $19 million gain on fair value adjustments to equity investments in the first half of 2023; and

[0000068505-24-000024:mdna:149]
•$11 million loss on assessments of uncertain tax positions in the first half of 2024 that did not occur in the first half 2023; of partially offset by

[0000068505-24-000024:mdna:150]
•$4 million of foreign currency gains in the first half of 2024 compared to $40 million of foreign currency losses in the first half of 2023;

[0000068505-24-000024:mdna:151]
•$63 million of net periodic pension and postretirement benefit in the first half of 2024 compared to $49 million of net periodic pension and postretirement benefit in the first half 2023; and

[0000068505-24-000024:mdna:152]
•$3 million of investment impairments in the first half of 2024 compared to $9 million of investment impairments in the first half of 2023.

[0000068505-24-000024:mdna:153]
Effective Tax Rate

[0000068505-24-000024:mdna:154]
|  | Six Months Ended |
| (In millions) | June 29, 2024 |  | July 1, 2023 |
| Income tax expense | $ | 83 |  |  | $ | 194 |  |

[0000068505-24-000024:mdna:155]
Income tax expense decreased by $111 million in the first half of 2024 compared to the first half of 2023, resulting in an effective tax rate of 17%. Our effective tax rate of 17% for the six months ended June 29, 2024 was lower than the effective tax rate for the six months ended July 1, 2023 of 23%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, offset by the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024.

[0000068505-24-000024:mdna:156]
[same as prior period, unchanged from 0000068505-24-000016:mdna:91]

[0000068505-24-000024:mdna:157]
During the second quarter of 2024, we recorded net reorganization of business charges of $4 million, including $4 million of charges recorded within Other charges in our Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $10 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals and $4 million of reversals for exit costs that are no longer needed.

[0000068505-24-000024:mdna:158]
During the first half of 2024, we recorded net reorganization of business charges of $14 million, including $11 million of charges recorded within Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $22 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $4 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000024:mdna:159]
During the second quarter of 2023, we recorded net reorganization of business charges of $3 million, including $5 million of charges in Other charges and $2 million of reversals in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $3 million were charges of $9 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $1 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000024:mdna:160]
During the first half of 2023, we recorded net reorganization of business charges of $16 million, including $12 million of charges recorded in Other charges and $4 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $24 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $3 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000024:mdna:161]
[same as prior period, unchanged from 0000068505-24-000016:mdna:94]

[0000068505-24-000024:mdna:162]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Products and Systems Integration | $ | 6 |  |  | $ | 6 |  |  | $ | 14 |  |  | $ | 17 |  |
| Software and Services | (2) |  |  | (3) |  |  | — |  |  | (1) |  |
|  | $ | 4 |  |  | $ | 3 |  |  | $ | 14 |  |  | $ | 16 |  |

[0000068505-24-000024:mdna:163]
Cash payments for employee severance in connection with the reorganization of business plans were $17 million in the first half of 2024 and $19 million in the first half of 2023. The reorganization of business accrual at June 29, 2024 was $24 million related to employee separation costs that are expected to be paid within one year.

[0000068505-24-000024:mdna:164]
At January 1, 2024, we had an accrual of $5 million for exit costs related to our exit of the ESN contract with the UK Home Office. The $1 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at June 29, 2024, and are expected to be paid within one year.

[0000068505-24-000024:mdna:165]
[same as prior period, unchanged from 0000068505-24-000016:mdna:98]

[0000068505-24-000024:mdna:166]
|  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 562 |  |  | $ | 85 |  |
| Investing activities | (118) |  |  | (111) |  |
| Financing activities | (743) |  |  | (629) |  |
| Effect of exchange rates on cash and cash equivalents | (25) |  |  | 40 |  |
| Increase (decrease) in cash and cash equivalents | $ | (324) |  |  | $ | (615) |  |

[0000068505-24-000024:mdna:167]
[same as prior period, unchanged from 0000068505-24-000016:mdna:100]

[0000068505-24-000024:mdna:168]
At June 29, 2024, $1.0 billion of the $1.4 billion cash and cash equivalents balance was held in the U.S. and $403 million was held in other countries.

[0000068505-24-000024:mdna:169]
[same as prior period, unchanged from 0000068505-24-000016:mdna:102]

[0000068505-24-000024:mdna:170]
The increase in cash flows provided by operating activities from the first half of 2023 to the first half of 2024 was driven primarily by higher earnings, net of non-cash adjustments, and improved working capital, offset by higher incentive payments.

[0000068505-24-000024:mdna:171]
[same as prior period, unchanged from 0000068505-24-000016:mdna:104]

[0000068505-24-000024:mdna:172]
The increase in cash flows used for investing activities in the first half of 2024 compared to the first half of 2023 was primarily due to an increase in cash used for acquisitions and investments, offset by proceeds from the sale of our Richmond, British Columbia and Richardson, Texas video manufacturing operations.

[0000068505-24-000024:mdna:173]
[same as prior period, unchanged from 0000068505-24-000016:mdna:106]

[0000068505-24-000024:mdna:174]
The increase in cash flows used for financing activities in the first half of 2024 compared to the first half of 2023 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-24-000024:mdna:175]
•$1.59 billion increase in repayments of debt driven by the repurchase of the Silver Lake Convertible Debt in the first half of 2024;

[0000068505-24-000024:mdna:176]
•$35 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first half of 2024 compared to the first half of 2023; and

[0000068505-24-000024:mdna:177]
•$30 million increase in the payment of dividends in the first half of 2024 compared to the first half of 2023; partially offset by

[0000068505-24-000024:mdna:178]
•$1.3 billion increase in net proceeds in the first half of 2024 driven the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; and

[0000068505-24-000024:mdna:179]
•$254 million decrease in share repurchases in the first half of 2024 compared to the first half of 2023.

[0000068505-24-000024:mdna:180]
[same as prior period, unchanged from 0000068505-24-000016:mdna:113]

[0000068505-24-000024:mdna:181]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended June 29, 2024 and July 1, 2023:

[0000068505-24-000024:mdna:182]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Accounts receivable sales proceeds | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term receivables sales proceeds | 17 |  |  | 26 |  |  | 27 |  |  | 58 |  |
| Total proceeds from receivable sales | $ | 17 |  |  | $ | 26 |  |  | $ | 27 |  |  | $ | 58 |  |

[0000068505-24-000024:mdna:183]
[same as prior period, unchanged from 0000068505-24-000016:mdna:116]

[0000068505-24-000024:mdna:184]
We had outstanding debt of $6.3 billion at June 29, 2024, of which $565 million was current. We had outstanding debt of $6.0 billion at December 31, 2023, of which $1.3 billion was current.

[0000068505-24-000024:mdna:185]
As of June 29, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, were classified within the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-24-000024:mdna:186]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue the Silver Lake Convertible Debt, which became fully convertible on September 5, 2021. On February 14, 2024, we agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The cash consideration was paid during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the three months ended March 30, 2024.

[0000068505-24-000024:mdna:187]
On March 25, 2024, we issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. We recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

[0000068505-24-000024:mdna:188]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of June 29, 2024.

[0000068505-24-000024:mdna:189]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of June 29, 2024 we had no outstanding debt under the commercial paper program.

[0000068505-24-000024:mdna:190]
[same as prior period, unchanged from 0000068505-24-000016:mdna:123]

[0000068505-24-000024:mdna:191]
[same as prior period, unchanged from 0000068505-24-000016:mdna:124]

[0000068505-24-000024:mdna:192]
During the three and six months ended June 29, 2024, we repurchased approximately 0.2 million and 0.3 million shares at an average price of $348.19 and $336.57 per share for an aggregate amount of $71 million and $110 million. As of June 29, 2024, we had used approximately $15.6 billion of the share repurchase authority to repurchase shares, leaving $2.4 billion of authority available for future repurchases.

[0000068505-24-000024:mdna:193]
[same as prior period, unchanged from 0000068505-24-000016:mdna:126]

[0000068505-24-000024:mdna:194]
During the second quarter of 2024 we paid $163 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $164 million in cash dividends to holders of our common stock.

[0000068505-24-000024:mdna:195]
[same as prior period, unchanged from 0000068505-24-000016:mdna:128]

[0000068505-24-000024:mdna:196]
[same as prior period, unchanged from 0000068505-24-000016:mdna:129]

[0000068505-24-000024:mdna:197]
[same as prior period, unchanged from 0000068505-24-000016:mdna:130]

[0000068505-24-000024:mdna:198]
[same as prior period, unchanged from 0000068505-24-000016:mdna:131]

[0000068505-24-000024:mdna:199]
We had outstanding commitments to provide long-term financing to third parties totaling $73 million at June 29, 2024, compared to $103 million at December 31, 2023.

[0000068505-24-000024:mdna:200]
[same as prior period, unchanged from 0000068505-24-000016:mdna:133]

[0000068505-24-000024:mdna:201]
[same as prior period, unchanged from 0000068505-24-000016:mdna:134]
