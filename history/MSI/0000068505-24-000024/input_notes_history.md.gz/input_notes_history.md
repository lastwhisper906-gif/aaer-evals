# MSI note change history — 0000068505-24-000016 → 0000068505-24-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-01):
[0000068505-24-000024:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.
  (was, 2024-05-02, similarity 0.9917):
[0000068505-24-000016:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

- changed (2024-08-01):
[0000068505-24-000024:note_history:2]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through July 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.
  (was, 2024-05-02, similarity 0.9793):
[0000068505-24-000016:note_history:2]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through April 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

- added (2024-08-01):
[0000068505-24-000024:note_history:3]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court.

- added (2024-08-01):
[0000068505-24-000024:note_history:4]
In the first half of 2024, the parties engaged in competing litigation in the District Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court has scheduled hearings in August 2024 concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code.

- removed (2024-08-01):
[0000068505-24-000016:note_history:5]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera subsequently filed several notices to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), including a notice of appeal filed on August 2, 2022, which appealed the orders related to the jury's verdict as well as the Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on the parties' appeals on December 5, 2023.

- removed (2024-08-01):
[0000068505-24-000016:note_history:6]
In the first quarter of 2024, the parties have been engaged in competing litigation in the Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. In March 2024, the Court ordered Hytera to take affirmative steps to withdraw its competing litigation. Hytera did not comply with the Court's order and, accordingly, the Court issued an order against Hytera for contempt sanctions on April 2, 2024, which included a worldwide sales injunction of all Hytera radio products. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the lower Court's various orders related to the contempt sanctions.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-01):
[0000068505-24-000024:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of June 29, 2024 and for the three and six months ended June 29, 2024 and July 1, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2024-05-02, similarity 0.9451):
[0000068505-24-000016:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of March 30, 2024 and for the three months ended March 30, 2024 and April 1, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2024-08-01):
[0000068505-24-000024:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three and six months ended June 29, 2024 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2024-05-02, similarity 0.8167):
[0000068505-24-000016:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three months ended March 30, 2024 are not necessarily indicative of the operating results to be expected for the full year.

- added (2024-08-01):
[0000068505-24-000024:note_history:9]
Subsequent to the quarter end, on July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

- added (2024-08-01):
[0000068505-24-000024:note_history:10]
Subsequent to the quarter end, on July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

- changed (2024-08-01):
[0000068505-24-000024:note_history:11]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.
  (was, 2024-05-02, similarity 0.9989):
[0000068505-24-000016:note_history:11]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

- changed (2024-08-01):
[0000068505-24-000024:note_history:12]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is part of the Products and Systems Integration segment.
  (was, 2024-05-02, similarity 0.9805):
[0000068505-24-000016:note_history:12]
On December 15, 2023, the Company acquired IPVideo Corporation ("IPVideo"), the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is a part of the Products and Systems Integration segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-01):
[0000068505-24-000024:note_history:13]
|  | June 29, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,309 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (565) |  |  | (1,313) |  |
| Long-term debt | $ | 5,743 |  |  | $ | 4,705 |  |
  (was, 2024-05-02, similarity 0.9934):
[0000068505-24-000016:note_history:13]
|  | March 30, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 695 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior noted due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,308 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (313) |  |  | (1,313) |  |
| Long-term debt | $ | 5,994 |  |  | $ | 4,705 |  |

- changed (2024-08-01):
[0000068505-24-000024:note_history:14]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the six months ended June 29, 2024.
  (was, 2024-05-02, similarity 0.9771):
[0000068505-24-000016:note_history:14]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the three months ended March 30, 2024.

- changed (2024-08-01):
[0000068505-24-000024:note_history:15]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt in the first quarter of 2024.
  (was, 2024-05-02, similarity 0.9633):
[0000068505-24-000016:note_history:15]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

- added (2024-08-01):
[0000068505-24-000024:note_history:16]
As of June 29, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, were reclassified from Long-term debt to the Current portion of long-term debt statement line within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

- changed (2024-08-01):
[0000068505-24-000024:note_history:17]
As of June 29, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 29, 2024.
  (was, 2024-05-02, similarity 0.9794):
[0000068505-24-000016:note_history:17]
As of March 30, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 30, 2024.

- changed (2024-08-01):
[0000068505-24-000024:note_history:18]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 29, 2024 the Company had no outstanding debt under the commercial paper program.
  (was, 2024-05-02, similarity 0.9934):
[0000068505-24-000016:note_history:18]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 30, 2024 the Company had no outstanding debt under the commercial paper program.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-01):
[0000068505-24-000024:note_history:19]
|  | June 29, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,309 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (565) |  |  | (1,313) |  |
| Long-term debt | $ | 5,743 |  |  | $ | 4,705 |  |
  (was, 2024-05-02, similarity 0.9934):
[0000068505-24-000016:note_history:19]
|  | March 30, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 695 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior noted due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,308 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (313) |  |  | (1,313) |  |
| Long-term debt | $ | 5,994 |  |  | $ | 4,705 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-01):
[0000068505-24-000024:note_history:20]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 29, 2024 and July 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2024-05-02, similarity 0.9282):
[0000068505-24-000016:note_history:20]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 30, 2024 and April 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2024-08-01):
[0000068505-24-000024:note_history:21]
|  | Three Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |  | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |
| International | 413 |  |  | 298 |  |  | 711 |  |  | 412 |  |  | 350 |  |  | 762 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |  | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |
| Video | 295 |  |  | 181 |  |  | 476 |  |  | 287 |  |  | 146 |  |  | 433 |  |
| Command Center | — |  |  | 211 |  |  | 211 |  |  | — |  |  | 194 |  |  | 194 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,000 |  |  | $ | 880 |  |  | 1,880 |  |  | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |
| Indirect | 658 |  |  | 90 |  |  | 748 |  |  | 641 |  |  | 91 |  |  | 732 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
  (was, 2024-05-02, similarity 0.8217):
[0000068505-24-000016:note_history:21]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |  | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |
| International | 408 |  |  | 288 |  |  | 696 |  |  | 353 |  |  | 326 |  |  | 679 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |  | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |
| Video | 235 |  |  | 163 |  |  | 398 |  |  | 223 |  |  | 136 |  |  | 359 |  |
| Command Center | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 155 |  |  | 155 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |  | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |
| Indirect | 630 |  |  | 77 |  |  | 707 |  |  | 580 |  |  | 73 |  |  | 653 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |

- added (2024-08-01):
[0000068505-24-000024:note_history:22]
|  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |  | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |
| International | 821 |  |  | 586 |  |  | 1,407 |  |  | 765 |  |  | 676 |  |  | 1,441 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |  | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |
| Video | 529 |  |  | 345 |  |  | 874 |  |  | 510 |  |  | 282 |  |  | 792 |  |
| Command Center | — |  |  | 379 |  |  | 379 |  |  | — |  |  | 349 |  |  | 349 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |  | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |
| Indirect | 1,288 |  |  | 167 |  |  | 1,455 |  |  | 1,221 |  |  | 164 |  |  | 1,385 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-01):
[0000068505-24-000024:note_history:23]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 29, 2024 and July 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2024-05-02, similarity 0.9282):
[0000068505-24-000016:note_history:23]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 30, 2024 and April 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2024-08-01):
[0000068505-24-000024:note_history:24]
|  | Three Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |  | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |
| International | 413 |  |  | 298 |  |  | 711 |  |  | 412 |  |  | 350 |  |  | 762 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |  | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |
| Video | 295 |  |  | 181 |  |  | 476 |  |  | 287 |  |  | 146 |  |  | 433 |  |
| Command Center | — |  |  | 211 |  |  | 211 |  |  | — |  |  | 194 |  |  | 194 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,000 |  |  | $ | 880 |  |  | 1,880 |  |  | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |
| Indirect | 658 |  |  | 90 |  |  | 748 |  |  | 641 |  |  | 91 |  |  | 732 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
  (was, 2024-05-02, similarity 0.8217):
[0000068505-24-000016:note_history:24]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |  | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |
| International | 408 |  |  | 288 |  |  | 696 |  |  | 353 |  |  | 326 |  |  | 679 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |  | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |
| Video | 235 |  |  | 163 |  |  | 398 |  |  | 223 |  |  | 136 |  |  | 359 |  |
| Command Center | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 155 |  |  | 155 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |  | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |
| Indirect | 630 |  |  | 77 |  |  | 707 |  |  | 580 |  |  | 73 |  |  | 653 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |

- added (2024-08-01):
[0000068505-24-000024:note_history:25]
|  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |  | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |
| International | 821 |  |  | 586 |  |  | 1,407 |  |  | 765 |  |  | 676 |  |  | 1,441 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |  | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |
| Video | 529 |  |  | 345 |  |  | 874 |  |  | 510 |  |  | 282 |  |  | 792 |  |
| Command Center | — |  |  | 379 |  |  | 379 |  |  | — |  |  | 349 |  |  | 349 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |  | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |
| Indirect | 1,288 |  |  | 167 |  |  | 1,455 |  |  | 1,221 |  |  | 164 |  |  | 1,385 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |

- changed (2024-08-01):
[0000068505-24-000024:note_history:26]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of June 29, 2024 was $9.1 billion. A total of $4.3 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of June 29, 2024, of which $2.6 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.8 billion was from Software and Services performance obligations that were not yet satisfied as of June 29, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.
  (was, 2024-05-02, similarity 0.9925):
[0000068505-24-000016:note_history:26]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of March 30, 2024 was $9.6 billion. A total of $4.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of March 30, 2024, of which $2.8 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.0 billion was from Software and Services performance obligations that were not yet satisfied as of March 30, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.7 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- changed (2024-08-01):
[0000068505-24-000024:note_history:27]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first half of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.
  (was, 2024-05-02, similarity 0.9922):
[0000068505-24-000016:note_history:27]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first quarter of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.

- changed (2024-08-01):
[0000068505-24-000024:note_history:28]
| (In millions) | June 29, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,762 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,210 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,852 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 446 |  |  | 424 |  |  |  |  |  |
  (was, 2024-05-02, similarity 0.6468):
[0000068505-24-000016:note_history:28]
| (In millions) | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 65 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 116 |  |  | 119 |  |  |  |  |  |

- added (2024-08-01):
[0000068505-24-000024:note_history:29]
Revenue recognized during the three months ended June 29, 2024 which was previously included in Contract liabilities as of March 30, 2024 was $553 million, compared to $502 million of revenue recognized during the three months ended July 1, 2023 which was previously included in Contract liabilities as of April 1, 2023. Revenue recognized during the six months ended June 29, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $908 million, compared to $824 million recognized during the six months ended July 1, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $11 million was reversed during the three months ended June 29, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended July 1, 2023, primarily driven by changes in the estimates of progress on system contracts. Revenue of $18 million was reversed during the six months ended June 29, 2024 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the six months ended July 1, 2023.

- changed (2024-08-01):
[0000068505-24-000024:note_history:30]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended June 29, 2024 and July 1, 2023.
  (was, 2024-05-02, similarity 0.913):
[0000068505-24-000016:note_history:30]
There were no material expected credit losses recorded on contract assets during each of the three months ended March 30, 2024 and April 1, 2023.

- added (2024-08-01):
[0000068505-24-000024:note_history:31]
| (In millions) | June 29, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 54 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 119 |  |  | 119 |  |  |  |  |  |

- changed (2024-08-01):
[0000068505-24-000024:note_history:32]
Amortization of contract cost assets was $12 million and $25 million for the three and six months ended June 29, 2024, respectively, and $16 million and $35 million for the three and six months ended July 1, 2023, respectively.
  (was, 2024-05-02, similarity 0.7443):
[0000068505-24-000016:note_history:32]
Amortization of contract cost assets was $13 million for the three months ended March 30, 2024 and $17 million for the three months ended April 1, 2023.

- removed (2024-08-01):
[0000068505-24-000016:note_history:33]
| (In millions) | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,592 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,127 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,890 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 430 |  |  | 424 |  |  |  |  |  |

- removed (2024-08-01):
[0000068505-24-000016:note_history:34]
Revenue recognized during the three months ended March 30, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $508 million, compared to $474 million of revenue recognized during the three months ended April 1, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $12 million was reversed during the three months ended March 30, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended April 1, 2023, primarily driven by changes in the estimates of progress on system contracts.
