# MSI notes — 0000068505-24-000024


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-24-000024:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of June 29, 2024 and for the three and six months ended June 29, 2024 and July 1, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-24-000024:notes:2]
[same as prior period, unchanged from 0000068505-24-000016:notes:2]

[0000068505-24-000024:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three and six months ended June 29, 2024 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-24-000024:notes:4]
[same as prior period, unchanged from 0000068505-24-000016:notes:4]

[0000068505-24-000024:notes:5]
[same as prior period, unchanged from 0000068505-24-000016:notes:5]

[0000068505-24-000024:notes:6]
[same as prior period, unchanged from 0000068505-24-000016:notes:6]

[0000068505-24-000024:notes:7]
[same as prior period, unchanged from 0000068505-24-000016:notes:7]

[0000068505-24-000024:notes:8]
[same as prior period, unchanged from 0000068505-24-000016:notes:8]

[0000068505-24-000024:notes:9]
[same as prior period, unchanged from 0000068505-24-000016:notes:9]

[0000068505-24-000024:notes:10]
[same as prior period, unchanged from 0000068505-24-000016:notes:10]

[0000068505-24-000024:notes:11]
Subsequent to the quarter end, on July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

[0000068505-24-000024:notes:12]
Subsequent to the quarter end, on July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

[0000068505-24-000024:notes:13]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

[0000068505-24-000024:notes:14]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is part of the Products and Systems Integration segment.

[0000068505-24-000024:notes:15]
[same as prior period, unchanged from 0000068505-24-000016:notes:13]

[0000068505-24-000024:notes:16]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The ASU is effective for fiscal years beginning after December 15, 2023, and interim periods beginning in 2025, with early adoption permitted. The ASU will require the Company to disclose additional expense categories at the segment level including Cost of sales, Selling, general and administrative expenses, Research and development expenditures and Other charges once it adopts this ASU. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-24-000024:notes:17]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-24-000024:notes:18]
[same as prior period, unchanged from 0000068505-24-000016:notes:16]

[0000068505-24-000024:notes:19]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 29, 2024 and July 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-24-000024:notes:20]
|  | Three Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |  | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |
| International | 413 |  |  | 298 |  |  | 711 |  |  | 412 |  |  | 350 |  |  | 762 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |  | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |
| Video | 295 |  |  | 181 |  |  | 476 |  |  | 287 |  |  | 146 |  |  | 433 |  |
| Command Center | — |  |  | 211 |  |  | 211 |  |  | — |  |  | 194 |  |  | 194 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,000 |  |  | $ | 880 |  |  | 1,880 |  |  | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |
| Indirect | 658 |  |  | 90 |  |  | 748 |  |  | 641 |  |  | 91 |  |  | 732 |  |
|  | $ | 1,658 |  |  | $ | 970 |  |  | 2,628 |  |  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |

[0000068505-24-000024:notes:21]
|  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |  | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |
| International | 821 |  |  | 586 |  |  | 1,407 |  |  | 765 |  |  | 676 |  |  | 1,441 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |  | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |
| Video | 529 |  |  | 345 |  |  | 874 |  |  | 510 |  |  | 282 |  |  | 792 |  |
| Command Center | — |  |  | 379 |  |  | 379 |  |  | — |  |  | 349 |  |  | 349 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |  | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |
| Indirect | 1,288 |  |  | 167 |  |  | 1,455 |  |  | 1,221 |  |  | 164 |  |  | 1,385 |  |
|  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |

[0000068505-24-000024:notes:22]
[same as prior period, unchanged from 0000068505-24-000016:notes:19]

[0000068505-24-000024:notes:23]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of June 29, 2024 was $9.1 billion. A total of $4.3 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of June 29, 2024, of which $2.6 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.8 billion was from Software and Services performance obligations that were not yet satisfied as of June 29, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-24-000024:notes:24]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first half of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.

[0000068505-24-000024:notes:25]
[same as prior period, unchanged from 0000068505-24-000016:notes:22]

[0000068505-24-000024:notes:26]
[same as prior period, unchanged from 0000068505-24-000016:notes:23]

[0000068505-24-000024:notes:27]
| (In millions) | June 29, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,762 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,210 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,852 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 446 |  |  | 424 |  |  |  |  |  |

[0000068505-24-000024:notes:28]
Revenue recognized during the three months ended June 29, 2024 which was previously included in Contract liabilities as of March 30, 2024 was $553 million, compared to $502 million of revenue recognized during the three months ended July 1, 2023 which was previously included in Contract liabilities as of April 1, 2023. Revenue recognized during the six months ended June 29, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $908 million, compared to $824 million recognized during the six months ended July 1, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $11 million was reversed during the three months ended June 29, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended July 1, 2023, primarily driven by changes in the estimates of progress on system contracts. Revenue of $18 million was reversed during the six months ended June 29, 2024 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the six months ended July 1, 2023.

[0000068505-24-000024:notes:29]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended June 29, 2024 and July 1, 2023.

[0000068505-24-000024:notes:30]
[same as prior period, unchanged from 0000068505-24-000016:notes:27]

[0000068505-24-000024:notes:31]
| (In millions) | June 29, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 54 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 119 |  |  | 119 |  |  |  |  |  |

[0000068505-24-000024:notes:32]
Amortization of contract cost assets was $12 million and $25 million for the three and six months ended June 29, 2024, respectively, and $16 million and $35 million for the three and six months ended July 1, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-24-000024:notes:33]
Leases
Components of Lease Expense

[0000068505-24-000024:notes:34]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 34 |  |  | $ | 34 |  |  | $ | 69 |  |  | $ | 68 |  |
| Short-term lease cost | — |  |  | — |  |  | — |  |  | 1 |
| Variable cost | 11 |  |  | 8 |  |  | 22 |  |  | 17 |  |
| Sublease income | (1) |  |  | (1) |  |  | (3) |  |  | (3) |  |
| Net lease expense from operating leases | $ | 44 |  |  | $ | 41 |  |  | $ | 88 |  |  | $ | 83 |  |

[0000068505-24-000024:notes:35]
Lease Assets and Liabilities

[0000068505-24-000024:notes:36]
| (in millions) |  | Statement Line Classification |  | June 29, 2024 |  | December 31, 2023 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 527 |  |  | $ | 495 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | 124 |  |  | 125 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | 421 |  |  | 407 |  |  |  |

[0000068505-24-000024:notes:37]
Other Information Related to Leases

[0000068505-24-000024:notes:38]
|  | Six Months Ended |  |  |
| (in millions) | June 29, 2024 |  | July 1, 2023 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 88 |  |  | $ | 81 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | 91 |  |  | 39 |  |  |  |

[0000068505-24-000024:notes:39]
During the six months ended June 29, 2024, the Company recorded $80 million of assets obtained in exchange for lease liabilities due to an assumption that it is reasonably certain that renewal options will be extended on its radio tower site leases operated within the Airwave radio network, consistent with the UK Home Office's notice of contract extension pursuant to their Deferred National Shutdown Notice through December 31, 2029.

[0000068505-24-000024:notes:40]
|  | June 29, 2024 |  | December 31, 2023 |
| Weighted average remaining lease terms (years) | 5 |  | 5 |
| Weighted average discount rate: | 3.87 | % |  | 4.34 | % |

[0000068505-24-000024:notes:41]
Future Lease Payments

[0000068505-24-000024:notes:42]
|  | June 29, 2024 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2024 | $ | 60 |  |  |  |  |  |
| 2025 | 135 |  |  |  |  |  |
| 2026 | 118 |  |  |  |  |  |
| 2027 | 100 |  |  |  |  |  |
| 2028 | 76 |  |  |  |  |  |
| Thereafter | 114 |  |  |  |  |  |
| Total lease payments | 603 |  |  |  |  |  |
| Less: interest | 58 |  |  |  |  |  |
| Present value of lease liabilities | $ | 545 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-24-000024:notes:43]
[same as prior period, unchanged from 0000068505-24-000016:notes:40]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-24-000024:notes:44]
[same as prior period, unchanged from 0000068505-24-000016:notes:41]

[0000068505-24-000024:notes:45]
[same as prior period, unchanged from 0000068505-24-000016:notes:42]

[0000068505-24-000024:notes:46]
Other charges included in Operating earnings consist of the following:

[0000068505-24-000024:notes:47]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 36 |  |  | $ | 43 |  |  | $ | 76 |  |  | $ | 98 |  |
| Reorganization of business (Note 14) | 4 |  |  | 5 |  |  | 11 |  |  | 12 |  |
| Operating lease asset impairments | 1 |  |  | 1 |  |  | 4 |  |  | 4 |  |
| Acquisition-related transaction fees | 4 |  |  | — |  |  | 7 |  |  | 2 |  |
| Environmental reserve expense | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Legal settlements | — |  |  | — |  |  | 6 |  |  | — |  |
| Fixed asset impairments | — |  |  | 1 |  |  | — |  |  | 3 |  |
| Other | — |  |  | 1 |  |  | — |  |  | 1 |  |
|  | $ | 45 |  |  | $ | 66 |  |  | $ | 104 |  |  | 135 |  |

[0000068505-24-000024:notes:48]
[same as prior period, unchanged from 0000068505-24-000016:notes:45]

[0000068505-24-000024:notes:49]
[same as prior period, unchanged from 0000068505-24-000016:notes:46]

[0000068505-24-000024:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (87) |  |  | $ | (63) |  |  | $ | (149) |  |  | $ | (126) |  |
| Interest income | 18 |  |  | 6 |  |  | 36 |  |  | 15 |  |
|  | $ | (69) |  |  | $ | (57) |  |  | $ | (113) |  |  | $ | (111) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 31 |  |  | $ | 24 |  |  | $ | 63 |  |  | $ | 49 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt (Note 5) | — |  |  | — |  |  | (585) |  |  | — |  |
| Investment impairments | — |  |  | (3) |  |  | (3) |  |  | (9) |  |
| Foreign currency gain (loss) | 3 |  |  | (21) |  |  | 4 |  |  | (40) |  |
| Gain (loss) on derivative instruments (Note 6) | (5) |  |  | 9 |  |  | (15) |  |  | 17 |  |
| Gain on equity method investments | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Fair value adjustments to equity investments | (11) |  |  | 16 |  |  | (13) |  |  | 19 |  |
| Assessments on uncertain tax positions | (11) |  |  | — |  |  | (11) |  |  | — |  |
| Other | (2) |  |  | — |  |  | — |  |  | 2 |  |
|  | $ | 5 |  |  | $ | 26 |  |  | (560) |  |  | 39 |  |

[0000068505-24-000024:notes:51]
Earnings Per Common Share

[0000068505-24-000024:notes:52]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-24-000024:notes:53]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 443 |  |  | $ | 371 |  |  | $ | 404 |  |  | $ | 649 |  |
| Weighted average common shares outstanding | 166.9 |  |  | 167.5 |  |  | 166.5 |  |  | 167.4 |  |
| Per share amount | $ | 2.65 |  |  | $ | 2.21 |  |  | $ | 2.43 |  |  | $ | 3.88 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 443 |  |  | $ | 371 |  |  | $ | 404 |  |  | $ | 649 |  |
| Weighted average common shares outstanding | 166.9 |  |  | 167.5 |  |  | 166.5 |  |  | 167.4 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.4 |  |  | 3.6 |  |  | 3.8 |  |  | 3.8 |  |
| Silver Lake Convertible Debt | — |  |  | 1.5 |  |  | — |  |  | 1.3 |  |
| Diluted weighted average common shares outstanding | 170.3 |  |  | 172.6 |  |  | 170.3 |  |  | 172.5 |  |
| Per share amount | $ | 2.60 |  |  | $ | 2.15 |  |  | $ | 2.37 |  |  | $ | 3.76 |  |

[0000068505-24-000024:notes:54]
In the computation of diluted earnings per common share for the three months ended June 29, 2024, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000024:notes:55]
In the computation of diluted earnings per common share for the six months ended June 29, 2024, a total of 0.5 million shares related to the Silver Lake Convertible Debt (as defined in Note 5, "Debt and Credit Facilities" in this "Part 1 - Financial Information" of this Form 10-Q) were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In addition, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000024:notes:56]
In the computation of diluted earnings per common share for the three and six months ended July 1, 2023, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000024:notes:57]
[same as prior period, unchanged from 0000068505-24-000016:notes:54]

[0000068505-24-000024:notes:58]
[same as prior period, unchanged from 0000068505-24-000016:notes:55]

[0000068505-24-000024:notes:59]
[same as prior period, unchanged from 0000068505-24-000016:notes:56]

[0000068505-24-000024:notes:60]
|  | June 29, 2024 |  | December 31, 2023 |
| Accounts receivable | $ | 1,838 |  |  | $ | 1,779 |  |
| Less allowance for credit losses | (76) |  |  | (69) |  |
|  | $ | 1,762 |  |  | $ | 1,710 |  |

[0000068505-24-000024:notes:61]
[same as prior period, unchanged from 0000068505-24-000016:notes:58]

[0000068505-24-000024:notes:62]
[same as prior period, unchanged from 0000068505-24-000016:notes:59]

[0000068505-24-000024:notes:63]
|  | June 29, 2024 |  | December 31, 2023 |
| Finished goods | $ | 339 |  |  | $ | 328 |  |
| Work-in-process and production materials | 602 |  |  | 640 |  |
|  | 941 |  |  | 968 |  |
| Less inventory reserves | (138) |  |  | (141) |  |
|  | $ | 803 |  |  | $ | 827 |  |

[0000068505-24-000024:notes:64]
[same as prior period, unchanged from 0000068505-24-000016:notes:61]

[0000068505-24-000024:notes:65]
[same as prior period, unchanged from 0000068505-24-000016:notes:62]

[0000068505-24-000024:notes:66]
|  | June 29, 2024 |  | December 31, 2023 |
| Current contract cost assets (Note 2) | $ | 54 |  |  | $ | 56 |  |
| Contractor receivables | 66 |  |  | 40 |  |
| Tax-related deposits | 43 |  |  | 32 |  |
| Other | 252 |  |  | 229 |  |
|  | $ | 415 |  |  | $ | 357 |  |

[0000068505-24-000024:notes:67]
[same as prior period, unchanged from 0000068505-24-000016:notes:64]

[0000068505-24-000024:notes:68]
[same as prior period, unchanged from 0000068505-24-000016:notes:65]

[0000068505-24-000024:notes:69]
|  | June 29, 2024 |  | December 31, 2023 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 439 |  |  | 448 |  |
| Machinery and equipment | 2,506 |  |  | 2,396 |  |
|  | 2,950 |  |  | 2,849 |  |
| Less accumulated depreciation | (1,963) |  |  | (1,885) |  |
|  | $ | 987 |  |  | $ | 964 |  |

[0000068505-24-000024:notes:70]
During the year ended December 31, 2023, the Company entered into an arrangement to sell its Richmond, British Columbia and Richardson, Texas video manufacturing operations, including the machinery and equipment, inventory, transfer of employees and related facility lease to a contract manufacturer. During the year ended December 31, 2023, the Company presented the assets and liabilities as held for sale in its Consolidated Balance Sheet and recognized an impairment loss of $24 million on the exit of these video manufacturing operations within Other charges in the Consolidated Statement of Operations, as the carrying value of the asset group was below the expected selling price. The transaction closed on February 1, 2024 resulting in a gain on the sale of these video manufacturing operations, which was de minimis.

[0000068505-24-000024:notes:71]
Depreciation expense for the three months ended June 29, 2024 and July 1, 2023 was $47 million and $44 million, respectively. Depreciation expense for the six months ended June 29, 2024 and July 1, 2023 was $90 million and $87 million, respectively.

[0000068505-24-000024:notes:72]
[same as prior period, unchanged from 0000068505-24-000016:notes:69]

[0000068505-24-000024:notes:73]
[same as prior period, unchanged from 0000068505-24-000016:notes:70]

[0000068505-24-000024:notes:74]
|  | June 29, 2024 |  | December 31, 2023 |  |  |  |  |
| Common stock | $ | 15 |  |  | $ | 28 |  |  |  |  |  |
| Strategic investments | 26 |  |  | 28 |  |  |  |  |  |
| Company-owned life insurance policies | 75 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 11 |  |  | 13 |  |  |  |  |  |
|  | $ | 127 |  |  | $ | 143 |  |  |  |  |  |

[0000068505-24-000024:notes:75]
During the six months ended June 29, 2024, the Company recognized a loss of $13 million in Other income (expense) within the Condensed Consolidated Statement of Operations related to a decrease in the fair value of its investment in Evolv Technologies, Inc. During the six months ended June 29, 2024, the Company recorded a $3 million investment impairment charge, representing an other-than-temporary decline in the value of the Company's strategic equity investment portfolio. The investment impairment charge is classified within Other income (expense) within the Condensed Consolidated Statement of Operations.

[0000068505-24-000024:notes:76]
[same as prior period, unchanged from 0000068505-24-000016:notes:72]

[0000068505-24-000024:notes:77]
[same as prior period, unchanged from 0000068505-24-000016:notes:73]

[0000068505-24-000024:notes:78]
|  | June 29, 2024 |  | December 31, 2023 |
| Defined benefit plan assets | $ | 128 |  |  | $ | 98 |  |
| Non-current contract cost assets (Note 2) | 119 |  |  | 119 |  |
| Other | 53 |  |  | 57 |  |
|  | $ | 300 |  |  | $ | 274 |  |

[0000068505-24-000024:notes:79]
[same as prior period, unchanged from 0000068505-24-000016:notes:75]

[0000068505-24-000024:notes:80]
[same as prior period, unchanged from 0000068505-24-000016:notes:76]

[0000068505-24-000024:notes:81]
The Company's outstanding amounts related to the suppliers participating in this program was $30 million and $35 million as of June 29, 2024 and December 31, 2023, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-24-000024:notes:82]
[same as prior period, unchanged from 0000068505-24-000016:notes:78]

[0000068505-24-000024:notes:83]
[same as prior period, unchanged from 0000068505-24-000016:notes:79]

[0000068505-24-000024:notes:84]
|  | June 29, 2024 |  | December 31, 2023 |
| Compensation | $ | 274 |  |  | $ | 407 |  |
| Tax liabilities | 145 |  |  | 231 |  |
| Dividend payable | 164 |  |  | 163 |  |
| Trade liabilities | 155 |  |  | 140 |  |
| Operating lease liabilities (Note 3) | 124 |  |  | 125 |  |
| Customer reserves | 84 |  |  | 89 |  |
| Other | 420 |  |  | 349 |  |
|  | $ | 1,366 |  |  | $ | 1,504 |  |

[0000068505-24-000024:notes:85]
[same as prior period, unchanged from 0000068505-24-000016:notes:81]

[0000068505-24-000024:notes:86]
[same as prior period, unchanged from 0000068505-24-000016:notes:82]

[0000068505-24-000024:notes:87]
|  | June 29, 2024 |  | December 31, 2023 |
| Defined benefit plans (Note 8) | $ | 875 |  |  | $ | 939 |  |
| Non-current contract liabilities (Note 2) | 446 |  |  | 424 |  |
| Unrecognized tax benefits (Note 7) | 22 |  |  | 26 |  |
| Deferred income taxes (Note 7) | 57 |  |  | 55 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Other | 201 |  |  | 178 |  |
|  | $ | 1,720 |  |  | $ | 1,741 |  |

[0000068505-24-000024:notes:88]
[same as prior period, unchanged from 0000068505-24-000016:notes:84]

[0000068505-24-000024:notes:89]
Share Repurchase Program: During the three and six months ended June 29, 2024, the Company repurchased approximately 0.2 million and 0.3 million shares at an average price of $348.19 and $336.57 per share for an aggregate amount of $71 million and $110 million, respectively.

[0000068505-24-000024:notes:90]
Payment of Dividends: During the three months ended June 29, 2024 and July 1, 2023, the Company paid $163 million and $148 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $164 million in cash dividends to holders of its common stock. During the six months ended June 29, 2024 and July 1, 2023, the Company paid $326 million and $296 million, respectively, in cash dividends to holders of its common stock.

[0000068505-24-000024:notes:91]
[same as prior period, unchanged from 0000068505-24-000016:notes:87]

[0000068505-24-000024:notes:92]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended June 29, 2024 and July 1, 2023:

[0000068505-24-000024:notes:93]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (506) |  |  | $ | (503) |  |  | $ | (482) |  |  | $ | (539) |  |
| Other comprehensive income (loss) before reclassification adjustment | (2) |  |  | 27 |  |  | (29) |  |  | 54 |  |
| Tax benefit (expense) | (1) |  |  | — |  |  | 2 |  |  | 9 |  |
| Other comprehensive income (loss), net of tax | (3) |  |  | 27 |  |  | (27) |  |  | 63 |  |
| Other comprehensive income attributable to noncontrolling interests, net of tax | — |  |  | — |  |  | — |  |  | — |  |
| Balance at end of period | $ | (509) |  |  | $ | (476) |  |  | $ | (509) |  |  | $ | (476) |  |
| Derivative instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (8) |  |  | $ | — |  |  | $ | (12) |  |  | $ | — |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | 4 |  |  | — |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | 4 |  |  | — |  |
| Other comprehensive income, net of tax | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |
| Balance at end of period | $ | (8) |  |  | $ | — |  |  | $ | (8) |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,039) |  |  | $ | (1,984) |  |  | $ | (2,046) |  |  | $ | (1,996) |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 8 |  |  | 15 |  |  | 17 |  |  | 30 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Tax expense | (2) |  |  | (3) |  |  | (4) |  |  | (7) |  |
| Reclassification adjustments into Net earnings, net of tax | 7 |  |  | 13 |  |  | 14 |  |  | 25 |  |
| Other comprehensive income, net of tax | 7 |  |  | 13 |  |  | 14 |  |  | 25 |  |
| Balance at end of period | $ | (2,032) |  |  | $ | (1,971) |  |  | $ | (2,032) |  |  | $ | (1,971) |  |
| Total Accumulated other comprehensive loss | $ | (2,549) |  |  | $ | (2,447) |  |  | $ | (2,549) |  |  | $ | (2,447) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-24-000024:notes:94]
Debt and Credit Facilities

[0000068505-24-000024:notes:95]
|  | June 29, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,309 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (565) |  |  | (1,313) |  |
| Long-term debt | $ | 5,743 |  |  | $ | 4,705 |  |

[0000068505-24-000024:notes:96]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the six months ended June 29, 2024.

[0000068505-24-000024:notes:97]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt in the first quarter of 2024.

[0000068505-24-000024:notes:98]
As of June 29, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, were reclassified from Long-term debt to the Current portion of long-term debt statement line within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-24-000024:notes:99]
As of June 29, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 29, 2024.

[0000068505-24-000024:notes:100]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 29, 2024 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-24-000024:notes:101]
[same as prior period, unchanged from 0000068505-24-000016:notes:96]

[0000068505-24-000024:notes:102]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.2 billion and $1.3 billion for the periods ended June 29, 2024 and December 31, 2023, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-24-000024:notes:103]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of June 29, 2024, and the corresponding positions as of December 31, 2023:

[0000068505-24-000024:notes:104]
|  | Notional Amount |
| Net Buy (Sell) by Currency | June 29, 2024 |  | December 31, 2023 |
| Euro | $ | 286 |  |  | $ | 322 |  |
| Australian dollar | (220) |  |  | (140) |  |
| British pound | 126 |  |  | 252 |  |
| Canadian dollar | 69 |  |  | 76 |  |
| Chinese renminbi | (64) |  |  | (66) |  |

[0000068505-24-000024:notes:105]
[same as prior period, unchanged from 0000068505-24-000016:notes:100]

[0000068505-24-000024:notes:106]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of June 29, 2024, all of the counterparties had investment grade credit ratings. As of June 29, 2024, the Company had $5 million of exposure to aggregate credit risk with all counterparties.

[0000068505-24-000024:notes:107]
[same as prior period, unchanged from 0000068505-24-000016:notes:102]

[0000068505-24-000024:notes:108]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of June 29, 2024 and December 31, 2023:

[0000068505-24-000024:notes:109]
|  | Fair Values of Derivative Instruments |
| June 29, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 2 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 2 |  |  | 7 |  |
| Equity swap contracts | 1 |  |  | — |  |
| Total derivatives | $ | 5 |  |  | $ | 7 |  |

[0000068505-24-000024:notes:110]
[same as prior period, unchanged from 0000068505-24-000016:notes:105]

[0000068505-24-000024:notes:111]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended June 29, 2024 and July 1, 2023:

[0000068505-24-000024:notes:112]
|  | Financial Statement Location | Three Months Ended |  | Six Months Ended |
| Foreign Exchange Contracts | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | 2 |  |  | $ | (2) |  |  | $ | 6 |  |  | $ | (4) |  |
| Forward points recognized | Other income (expense) | — |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Treasury rate lock | Accumulated other comprehensive income (loss) | — |  |  | — |  |  | 4 |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | (5) |  |  | $ | 9 |  |  | $ | (15) |  |  | $ | 17 |  |
| Equity swap contracts | Selling, general and administrative expenses | 1 |  |  | — |  |  | 2 |  |  | — |  |

[0000068505-24-000024:notes:113]
[same as prior period, unchanged from 0000068505-24-000016:notes:108]

[0000068505-24-000024:notes:114]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of June 29, 2024, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £60 million of net investment hedges in a British pound functional subsidiary.

[0000068505-24-000024:notes:115]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the forward points recognized will be amortized on a straight-line basis and recognized through interest expense within Other income (expense) in the Condensed Consolidated Statement of Operations.

[0000068505-24-000024:notes:116]
[same as prior period, unchanged from 0000068505-24-000016:notes:111]

[0000068505-24-000024:notes:117]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of June 29, 2024 was $18 million.

[0000068505-24-000024:notes:118]
[same as prior period, unchanged from 0000068505-24-000016:notes:113]

[0000068505-24-000024:notes:119]
In 2023, the Company entered into treasury rate agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the six months ended June 29, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated Other Comprehensive Income (AOCI) will be reclassified to interest expense on a straight-line basis over the 10-year term of such senior notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-24-000024:notes:120]
[same as prior period, unchanged from 0000068505-24-000016:notes:115]

[0000068505-24-000024:notes:121]
[same as prior period, unchanged from 0000068505-24-000016:notes:116]

[0000068505-24-000024:notes:122]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Net earnings before income taxes | $ | 580 |  |  | $ | 487 |  |  | $ | 490 |  |  | $ | 846 |  |
| Income tax expense | 135 |  |  | 114 |  |  | 83 |  |  | 194 |  |
| Effective tax rate | 23 | % |  | 23 | % |  | 17 | % |  | 23 | % |

[0000068505-24-000024:notes:123]
The effective tax rate for the three months ended June 29, 2024 of 23% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions and excess tax benefits of share-based compensation. The effective tax rate for the six months ended June 29, 2024 of 17% was lower than the U.S. federal statutory tax rate of 21% primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, and excess tax benefits of share-based compensation, offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in the first quarter of 2024 and state tax expense.

[0000068505-24-000024:notes:124]
The effective tax rate for each of the three and six months ended July 1, 2023 of 23% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by excess tax benefits of share-based compensation.

[0000068505-24-000024:notes:125]
The effective tax rate for the three months ended June 29, 2024 of 23% was equal to the effective tax rate for the three months ended July 1, 2023 of 23%, primarily due to tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, offset by lower excess tax benefits of share-based compensation in 2024. The effective tax rate for the six months ended June 29, 2024 of 17% was lower than the effective tax rate for the six months ended July 1, 2023 of 23%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of additional foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return as a result of the Company's decision to implement a business initiative in 2024, offset by the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-24-000024:notes:126]
[same as prior period, unchanged from 0000068505-24-000016:notes:121]

[0000068505-24-000024:notes:127]
[same as prior period, unchanged from 0000068505-24-000016:notes:122]

[0000068505-24-000024:notes:128]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 47 |  |  | 47 |  |  | 14 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Expected return on plan assets | (74) |  |  | (73) |  |  | (26) |  |  | (15) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 6 |  |  | 5 |  |  | 1 |  |  | 9 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Net periodic pension cost (benefits) | $ | (21) |  |  | $ | (21) |  |  | $ | (11) |  |  | $ | (4) |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-24-000024:notes:129]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 94 |  |  | 94 |  |  | 28 |  |  | 4 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (149) |  |  | (146) |  |  | (51) |  |  | (30) |  |  | (6) |  |  | (6) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 12 |  |  | 10 |  |  | 3 |  |  | 18 |  |  | 2 |  |  | 2 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | — |  |  | 2 |  |  | 2 |  |
| Net periodic pension cost (benefits) | $ | (43) |  |  | $ | (42) |  |  | $ | (21) |  |  | $ | (8) |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-24-000024:notes:130]
[same as prior period, unchanged from 0000068505-24-000016:notes:124]

[0000068505-24-000024:notes:131]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 12 |  |  | $ | 10 |  |  | $ | 24 |  |  | $ | 20 |  |
| Selling, general and administrative expenses | 35 |  |  | 29 |  |  | 64 |  |  | 59 |  |
| Research and development expenditures | 16 |  |  | 14 |  |  | 31 |  |  | 29 |  |
| Share-based compensation expense included in Operating earnings | 63 |  |  | 53 |  |  | 119 |  |  | 108 |  |
| Tax benefit | (13) |  |  | (11) |  |  | (24) |  |  | (22) |  |
| Share-based compensation expense, net of tax | $ | 50 |  |  | $ | 42 |  |  | $ | 95 |  |  | $ | 86 |  |
| Decrease in basic earnings per share | $ | (0.30) |  |  | $ | (0.25) |  |  | $ | (0.57) |  |  | $ | (0.51) |  |
| Decrease in diluted earnings per share | $ | (0.29) |  |  | $ | (0.24) |  |  | $ | (0.56) |  |  | $ | (0.50) |  |

[0000068505-24-000024:notes:132]
During the six months ended June 29, 2024, the Company granted 0.5 million RSUs, 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $174 million, $25 million and $14 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $8 million and $14 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-24-000024:notes:133]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of June 29, 2024 and December 31, 2023 were as follows:

[0000068505-24-000024:notes:134]
| June 29, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  |  |  | $ | 4 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |
| Common stock | 15 |  |  | — |  |  |  |  | 15 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |

[0000068505-24-000024:notes:135]
[same as prior period, unchanged from 0000068505-24-000016:notes:129]

[0000068505-24-000024:notes:136]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of June 29, 2024 or December 31, 2023.

[0000068505-24-000024:notes:137]
At June 29, 2024 and December 31, 2023, the Company had $577 million and $863 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-24-000024:notes:138]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of June 29, 2024 was $6.0 billion. The fair value of long-term debt at December 31, 2023 was $6.4 billion, of which the Silver Lake Convertible Debt was $1.6 billion (Level 2).

[0000068505-24-000024:notes:139]
[same as prior period, unchanged from 0000068505-24-000016:notes:133]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-24-000024:notes:140]
[same as prior period, unchanged from 0000068505-24-000016:notes:134]

[0000068505-24-000024:notes:141]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended June 29, 2024 and July 1, 2023:

[0000068505-24-000024:notes:142]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Long-term receivables sales proceeds | 17 |  |  | 26 |  |  | 27 |  |  | 58 |  |

[0000068505-24-000024:notes:143]
At June 29, 2024, the Company had retained servicing obligations for $770 million of long-term receivables, compared to $813 million at December 31, 2023. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $73 million at June 29, 2024, compared to $103 million at December 31, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-24-000024:notes:144]
Commitments and Contingencies
Legal Matters

[0000068505-24-000024:notes:145]
Hytera Litigation

[0000068505-24-000024:notes:146]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-24-000024:notes:147]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through July 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-24-000024:notes:148]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court.

[0000068505-24-000024:notes:149]
In the first half of 2024, the parties engaged in competing litigation in the District Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court has scheduled hearings in August 2024 concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-24-000024:notes:150]
[same as prior period, unchanged from 0000068505-24-000016:notes:144]

[0000068505-24-000024:notes:151]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Products and Systems Integration | $ | 1,658 |  |  | $ | 1,437 |  |  | $ | 3,149 |  |  | $ | 2,740 |  |
| Software and Services | 970 |  |  | 966 |  |  | 1,868 |  |  | 1,834 |  |
|  | $ | 2,628 |  |  | $ | 2,403 |  |  | $ | 5,017 |  |  | $ | 4,574 |  |

[0000068505-24-000024:notes:152]
[same as prior period, unchanged from 0000068505-24-000016:notes:146]

[0000068505-24-000024:notes:153]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Products and Systems Integration | $ | 379 |  |  | $ | 212 |  |  | $ | 689 |  |  | $ | 388 |  |
| Software and Services | 265 |  |  | 306 |  |  | 474 |  |  | 529 |  |
| Operating earnings | 644 |  |  | 518 |  |  | 1,163 |  |  | 917 |  |
| Total other expense | (64) |  |  | (31) |  |  | (673) |  |  | (71) |  |
| Earnings before income taxes | $ | 580 |  |  | $ | 487 |  |  | $ | 490 |  |  | $ | 846 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-24-000024:notes:154]
[same as prior period, unchanged from 0000068505-24-000016:notes:148]

[0000068505-24-000024:notes:155]
During the three months ended June 29, 2024, the Company recorded net reorganization of business charges of $4 million, consisting of $4 million of charges in Other charges in the Company's Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $10 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals and $4 million of reversals for exit cost accruals that are no longer needed.

[0000068505-24-000024:notes:156]
During the six months ended June 29, 2024, the Company recorded net reorganization of business charges of $14 million, including $11 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $22 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $4 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000024:notes:157]
[same as prior period, unchanged from 0000068505-24-000016:notes:150]

[0000068505-24-000024:notes:158]
| June 29, 2024 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 14 |  |
| Software and Services | (2) |  |  | — |  |
|  | $ | 4 |  |  | $ | 14 |  |

[0000068505-24-000024:notes:159]
[same as prior period, unchanged from 0000068505-24-000016:notes:152]

[0000068505-24-000024:notes:160]
|  | January 1, 2024 |  | Additional Charges |  | Adjustments |  | Amount Used |  | June 29, 2024 |
| Employee separation costs | $ | 23 |  |  | $ | 22 |  |  | $ | (4) |  |  | $ | (17) |  |  | $ | 24 |  |
| Exit costs | 5 |  |  | — |  |  | (4) |  |  | — |  |  | 1 |  |
|  | $ | 28 |  |  | $ | 22 |  |  | $ | (8) |  |  | $ | (17) |  |  | $ | 25 |  |

[0000068505-24-000024:notes:161]
[same as prior period, unchanged from 0000068505-24-000016:notes:154]

[0000068505-24-000024:notes:162]
At January 1, 2024, the Company had an accrual of $5 million for exit costs, related to the Company's exit of the Emergency Service Network contract with the UK Home Office. During the three months ended June 29, 2024, the Company recorded a $4 million reversal for accruals no longer needed. The $1 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at June 29, 2024, and are expected to be paid within one year.

[0000068505-24-000024:notes:163]
[same as prior period, unchanged from 0000068505-24-000016:notes:156]

[0000068505-24-000024:notes:164]
At January 1, 2024, the Company had an accrual of $23 million for employee separation costs. The 2024 additional charges of $22 million represent severance costs for approximately 315 employees. The adjustment of $4 million reflects reversals for accruals no longer needed. The $17 million used reflects cash payments to severed employees. The remaining accrual of $24 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at June 29, 2024, is expected to be paid, primarily within one year, to approximately 530 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-24-000024:notes:165]
[same as prior period, unchanged from 0000068505-24-000016:notes:158]

[0000068505-24-000024:notes:166]
During the three months ended July 1, 2023, the Company recorded net reorganization of business charges of $3 million, including $5 million of charges in Other charges and $2 million of reversals in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $3 million were charges of $9 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $1 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000024:notes:167]
During the six months ended July 1, 2023, the Company recorded net reorganization of business charges of $16 million, including $12 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $24 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $3 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000024:notes:168]
| July 1, 2023 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 17 |  |
| Software and Services | (3) |  |  | (1) |  |
|  | $ | 3 |  |  | $ | 16 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-24-000024:notes:169]
Intangible Assets and Goodwill
Subsequent to the quarter end, on July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which helps enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-24-000024:notes:170]
Subsequent to the quarter end, on July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-24-000024:notes:171]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The Company recognized $15 million of goodwill and $22 million of identifiable intangible assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $10 million of customer relationships and $11 million of developed technology and will be amortized over a period of two, fourteen and ten years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets and goodwill may be subject to change.

[0000068505-24-000024:notes:172]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. The transaction also includes the potential for the Company to make contingent earn-out payments of up to $15 million based on IPVideo's achievement of certain financial targets from January 1, 2024 through December 31, 2024. As of the acquisition date, the Company estimated the fair value of the contingent earn-out to be $2 million, which is included in the purchase price. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The Company recognized $98 million of goodwill, $83 million of identifiable intangible assets and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $8 million of trade names, $6 million of customer relationships and $69 million of developed technology and will be amortized over a period of eight, twelve and fifteen years, respectively. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-24-000024:notes:173]
[same as prior period, unchanged from 0000068505-24-000016:notes:163]

[0000068505-24-000024:notes:174]
[same as prior period, unchanged from 0000068505-24-000016:notes:164]

[0000068505-24-000024:notes:175]
|  | June 29, 2024 |  | December 31, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,177 |  |  | $ | 490 |  |  | $ | 1,156 |  |  | $ | 447 |  |
| Customer-related | 1,562 |  |  | 1,074 |  |  | 1,566 |  |  | 1,055 |  |
| Other intangibles | 107 |  |  | 74 |  |  | 107 |  |  | 72 |  |
|  | $ | 2,846 |  |  | $ | 1,638 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-24-000024:notes:176]
Amortization expense on intangible assets was $36 million and $76 million for the three and six months ended June 29, 2024, respectively. Amortization expense on intangible assets was $43 million and $98 million for the three and six months ended July 1, 2023, respectively. As of June 29, 2024, annual amortization expense is estimated to be $147 million in 2024, $134 million in 2025, $125 million in 2026, $115 million in 2027, $114 million in 2028 and $103 million in 2029.

[0000068505-24-000024:notes:177]
[same as prior period, unchanged from 0000068505-24-000016:notes:167]

[0000068505-24-000024:notes:178]
|  | June 29, 2024 |  | December 31, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 1,017 |  |  | $ | 373 |  |  | $ | 985 |  |  | $ | 337 |  |
| Software and Services | 1,829 |  |  | 1,265 |  |  | 1,844 |  |  | 1,237 |  |
|  | $ | 2,846 |  |  | $ | 1,638 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-24-000024:notes:179]
[same as prior period, unchanged from 0000068505-24-000016:notes:169]

[0000068505-24-000024:notes:180]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2024 to June 29, 2024:

[0000068505-24-000024:notes:181]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2024 | $ | 1,568 |  |  | $ | 1,833 |  |  | $ | 3,401 |  |
| Goodwill acquired | 15 |  |  | — |  |  | 15 |  |
| Purchase accounting adjustments | (12) |  |  | — |  |  | (12) |  |
| Foreign currency | — |  |  | (4) |  |  | (4) |  |
| Balance as of June 29, 2024 | $ | 1,571 |  |  | $ | 1,829 |  |  | $ | 3,400 |  |
