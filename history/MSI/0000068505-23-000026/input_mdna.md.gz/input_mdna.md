# MSI MD&A — 0000068505-23-000026


## mdna

[0000068505-23-000026:mdna:1]
[same as prior period, unchanged from 0000068505-22-000031:mdna:1]

[0000068505-23-000026:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three months ended April 1, 2023 and April 2, 2022, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2022 (the "Form 10-K").

[0000068505-23-000026:mdna:3]
[same as prior period, unchanged from 0000068505-22-000031:mdna:3]

[0000068505-23-000026:mdna:4]
[same as prior period, unchanged from 0000068505-22-000031:mdna:4]

[0000068505-23-000026:mdna:5]
[same as prior period, unchanged from 0000068505-22-000031:mdna:5]

[0000068505-23-000026:mdna:6]
The Company reports net sales in the following three major products and services (which we refer to as “technologies” in this Form 10-Q): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video") and Command Center. In January 2023, we began using Command Center as a naming convention, eliminating the "Software" descriptor from Command Center Software in order to inform investors that the Company has software components more broadly across all technologies; this name change does not require any financial information to be reclassified from previous periods.

[0000068505-23-000026:mdna:7]
[same as prior period, unchanged from 0000068505-22-000031:mdna:7]

[0000068505-23-000026:mdna:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence ("AI")-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

[0000068505-23-000026:mdna:9]
•Command Center: Software suite that enables collaboration and shares information throughout the public safety workflow from "911 call to case closure."

[0000068505-23-000026:mdna:10]
First Quarter Financial Results

[0000068505-23-000026:mdna:11]
•Net sales were $2.2 billion in the first quarter of 2023 compared to $1.9 billion in the first quarter of 2022.

[0000068505-23-000026:mdna:12]
•Operating earnings were $399 million in the first quarter of 2023 compared to $239 million in the first quarter of 2022.

[0000068505-23-000026:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. were $278 million, or $1.61 per diluted common share, in the first quarter of 2023, compared to $267 million, or $1.54 per diluted common share, in the first quarter of 2022.

[0000068505-23-000026:mdna:14]
•Operating cash flow decreased $160 million to an outflow of $8 million in the first quarter of 2023 compared to $152 million cash provided in the first quarter of 2022.

[0000068505-23-000026:mdna:15]
•We repurchased $140 million of common stock and paid $148 million in dividends in the first quarter of 2023.

[0000068505-23-000026:mdna:16]
[same as prior period, unchanged from 0000068505-22-000031:mdna:17]

[0000068505-23-000026:mdna:17]
During the first quarter of 2023, we continued to operate under challenging market conditions influenced by the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to materials in the semiconductor market. Over the last several quarters, we have navigated disruptions in our supply chain, in particular challenges in procuring certain semiconductor components, diminished transportation capacity and labor constraints. We anticipate inflationary pressures and increased material and supply chain costs and disruptions (including elevated costs to procure materials within the semiconductor market) to continue throughout 2023. We are closely monitoring supply chain disruptions and continue to remain focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages. In addition, we continue to actively manage our inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to our customers, which includes making changes that diversify the footprint of our supply chain operations. We expect to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-23-000026:mdna:18]
In order to combat rising inflation in the U.S., the Federal Reserve has raised interest rates multiple times since the beginning of 2022. The increase in U.S. dollar interest rates and overall market conditions led to significant U.S. dollar strengthening in 2022. We have seen a reversal of a portion of U.S. dollar strengthening from the peak but the outlook for the remainder of the year remains uncertain. We have cash flows denominated in foreign currencies where the fluctuations in the value of the U.S. dollar impact our earnings and cash flow.

[0000068505-23-000026:mdna:19]
Although the macroeconomic environment challenges continued in the first quarter of 2023, we are encouraged by customer demand for our products and services. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impact to operating margin will be limited throughout 2023. While we are encouraged by strong backlog and growth in our Products and Systems Integration segment in the first quarter of 2023, which we expect to continue to grow throughout 2023, supply constraints continue to impact our business and we expect demand for our products will continue to outpace our ability to obtain semiconductor component supply. Where appropriate, we have taken pricing actions around our product and service offerings to mitigate our exposure to inflationary pressures on our businesses and benefited from these adjustments during the first quarter of 2023. We expect to further benefit from such adjustments in 2023. Further, demand continues to be supported with ongoing sources of government funding, including the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus. We experienced the positive impact of the ARPA funding on our business and results of operations in 2022 and anticipate that the ARPA will continue to have a positive impact on our business throughout 2023.

[0000068505-23-000026:mdna:20]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of April 1, 2023. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-23-000026:mdna:21]
Lastly, as a result of the challenging market conditions described above, we evaluated whether there were any impairment indicators as of April 1, 2023, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the first quarter of 2023, we concluded our assets were fairly stated and recoverable.

[0000068505-23-000026:mdna:22]
[same as prior period, unchanged from 0000068505-22-000031:mdna:28]

[0000068505-23-000026:mdna:23]
[same as prior period, unchanged from 0000068505-22-000031:mdna:29]

[0000068505-23-000026:mdna:24]
In October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, our private mobile radio communications network that we acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain.

[0000068505-23-000026:mdna:25]
Subsequent to the quarter, the CMA issued its final decision which states it intends to impose a prospective price control on Airwave. MSI strongly disagrees with the CMA’s final decision and intends to appeal; the appeal process is expected to extend throughout 2023. Any price control remedies ultimately imposed under the final decision issued by the CMA are expected to go into effect after a remedies order review and consultation period and following the completion of the appeal process with the UK's

[0000068505-23-000026:mdna:26]
Competition Appeal Tribunal ("CAT"). The remedies implementation could potentially be further suspended if the appeal process extends beyond the CAT.

[0000068505-23-000026:mdna:27]
As a result of the issuance of a final decision from the CMA subsequent to our quarter close on April 1, 2023, we have tested our Airwave asset group for impairment, noting the assets are expected to be recoverable.

[0000068505-23-000026:mdna:28]
[same as prior period, unchanged from 0000068505-22-000031:mdna:36]

[0000068505-23-000026:mdna:29]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Command Center | Software and Services | Rave Mobile Safety, Inc. | Provider of mass notification and incident management services. | $553 million and share-based compensation of $2 million | December 14, 2022 |
| LMR Communications | Products and Systems Integration | Futurecom Systems Group, ULC | Provider of radio coverage extension solutions. | $30 million | October 25, 2022 |
| LMR Communications | Products and Systems Integration | Barrett Communications Pty Ltd | Provider of specialized radio communications. | $18 million | August 8, 2022 |
| Video Security and Access Control | Products and Systems Integration | Videotec S.p.A. | Provider of ruggedized video security solutions. | $23 million and share-based compensation of $4 million | May 12, 2022 |
| Video Security and Access Control | Software and Services | Calipsa, Inc. | Provider of cloud-native advanced video analytics. | $39 million and share-based compensation of $4 million | April 19, 2022 |
| LMR Communications | Software and Services | TETRA Ireland Communications Limited | Provider of Ireland's National Digital Radio Service. | $120 million | March 23, 2022 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Ava Security Limited | Provider of cloud-native video security and analytics. | $388 million and share-based awards and compensation of $7 million | March 3, 2022 |

[0000068505-23-000026:mdna:30]
26

[0000068505-23-000026:mdna:31]
[same as prior period, unchanged from 0000068505-22-000031:mdna:39]

[0000068505-23-000026:mdna:32]
|  | Three Months Ended |  |  |
| (Dollars in millions, except per share amounts) | April 1, 2023 |  | % ofSales* |  | April 2, 2022 |  | % ofSales* |  |  |  |  |  |  |  |  |
| Net sales from products | $ | 1,224 |  |  |  |  | $ | 1,046 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales from services | 947 |  |  |  |  | 846 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 2,171 |  |  |  |  | 1,892 |  |  |  |  |  |  |  |  |  |  |  |
| Costs of products sales | 576 |  |  | 47.1 | % |  | 548 |  |  | 52.4 | % |  |  |  |  |  |  |  |  |
| Costs of services sales | 549 |  |  | 58.0 | % |  | 487 |  |  | 57.6 | % |  |  |  |  |  |  |  |  |
| Costs of sales | 1,125 |  |  |  |  | 1,035 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 1,046 |  |  | 48.2 | % |  | 857 |  |  | 45.3 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 368 |  |  | 17.0 | % |  | 338 |  |  | 17.9 | % |  |  |  |  |  |  |  |  |
| Research and development expenditures | 210 |  |  | 9.7 | % |  | 188 |  |  | 9.9 | % |  |  |  |  |  |  |  |  |
| Other charges | 69 |  |  | 3.2 | % |  | 92 |  |  | 4.9 | % |  |  |  |  |  |  |  |  |
| Operating earnings | 399 |  |  | 18.4 | % |  | 239 |  |  | 12.6 | % |  |  |  |  |  |  |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (54) |  |  | (2.5) | % |  | (56) |  |  | (3.0) | % |  |  |  |  |  |  |  |  |
| Gains on sales of investments and businesses, net | 1 |  |  | — | % |  | 2 |  |  | 0.1 | % |  |  |  |  |  |  |  |  |
| Other, net | 12 |  |  | 0.6 | % |  | 34 |  |  | 1.8 | % |  |  |  |  |  |  |  |  |
| Total other expense | (41) |  |  | (1.9) | % |  | (20) |  |  | (1.1) | % |  |  |  |  |  |  |  |  |
| Net earnings before income taxes | 358 |  |  | 16.5 | % |  | 219 |  |  | 11.6 | % |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) | 79 |  |  | 3.6 | % |  | (49) |  |  | (2.6) | % |  |  |  |  |  |  |  |  |
| Net earnings | 279 |  |  | 12.9 | % |  | 268 |  |  | 14.2 | % |  |  |  |  |  |  |  |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | 0.1 | % |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 278 |  |  | 12.8 | % |  | $ | 267 |  |  | 14.1 | % |  |  |  |  |  |  |  |  |
| Earnings per diluted common share | $ | 1.61 |  |  |  |  | $ | 1.54 |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000026:mdna:33]
[same as prior period, unchanged from 0000068505-22-000031:mdna:41]

[0000068505-23-000026:mdna:34]
27

[0000068505-23-000026:mdna:35]
Results of Operations—Three months ended April 1, 2023 compared to three months ended April 2, 2022

[0000068505-23-000026:mdna:36]
The results of operations for the first quarter of 2023 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-23-000026:mdna:37]
[same as prior period, unchanged from 0000068505-22-000031:mdna:45]

[0000068505-23-000026:mdna:38]
[same as prior period, unchanged from 0000068505-22-000031:mdna:46]

[0000068505-23-000026:mdna:39]
[same as prior period, unchanged from 0000068505-22-000031:mdna:47]

[0000068505-23-000026:mdna:40]
[same as prior period, unchanged from 0000068505-22-000031:mdna:48]

[0000068505-23-000026:mdna:41]
[same as prior period, unchanged from 0000068505-22-000031:mdna:49]

[0000068505-23-000026:mdna:42]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |  | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |
| International | 353 |  |  | 326 |  |  | 679 |  |  | 272 |  |  | 315 |  |  | 587 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |  | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |
| Video | 223 |  |  | 136 |  |  | 359 |  |  | 194 |  |  | 113 |  |  | 307 |  |
| Command Center | — |  |  | 155 |  |  | 155 |  |  | — |  |  | 130 |  |  | 130 |  |
| Total | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Operating earnings | $ | 176 |  |  | $ | 223 |  |  | $ | 399 |  |  | $ | 39 |  |  | $ | 200 |  |  | $ | 239 |  |
| Operating margins | 13.5 | % |  | 25.7 | % |  | 18.4 | % |  | 3.5 | % |  | 25.3 | % |  | 12.6 | % |

[0000068505-23-000026:mdna:43]
[same as prior period, unchanged from 0000068505-22-000031:mdna:51]

[0000068505-23-000026:mdna:44]
The Products and Systems Integration segment’s net sales represented 60% of our net sales in the first quarter of 2023 and 58% in the first quarter of 2022. The Software and Services segment’s net sales represented 40% of our net sales in the first quarter of 2023 and 42% in the first quarter of 2022.

[0000068505-23-000026:mdna:45]
Net sales increased $279 million, or 15%, in the first quarter of 2023 compared to the first quarter of 2022. The $200 million, or 18%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 14% in the North America region and an increase of 30% in the International region. The $79 million, or 10%, increase in net sales within the Software and Services segment was driven by an increase of 14% in the North America region and an increase of 3% in the International region. Net sales includes:

[0000068505-23-000026:mdna:46]
•an increase in the Products and Systems Integration segment, inclusive of $12 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-23-000026:mdna:47]
•an increase in the Software and Services segment, inclusive of $30 million of revenue from acquisitions, driven by an increase in LMR Services, Command Center and Video;

[0000068505-23-000026:mdna:48]
•inclusive of $45 million from unfavorable currency rates.

[0000068505-23-000026:mdna:49]
[same as prior period, unchanged from 0000068505-22-000031:mdna:57]

[0000068505-23-000026:mdna:50]
•a 14% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-23-000026:mdna:51]
•a 16% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center.

[0000068505-23-000026:mdna:52]
[same as prior period, unchanged from 0000068505-22-000031:mdna:60]

[0000068505-23-000026:mdna:53]
The 18% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-23-000026:mdna:54]
•$171 million, or 19% growth in LMR, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-23-000026:mdna:55]
•$29 million, or 15% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-23-000026:mdna:56]
•inclusive of $19 million from unfavorable currency rates.

[0000068505-23-000026:mdna:57]
[same as prior period, unchanged from 0000068505-22-000031:mdna:65]

[0000068505-23-000026:mdna:58]
The 10% increase in the Software and Services segment was driven by the following:

[0000068505-23-000026:mdna:59]
•$31 million, or 6% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-23-000026:mdna:60]
•$25 million, or 19% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America region and International regions; and

[0000068505-23-000026:mdna:61]
•$23 million, or 20% growth in Video, inclusive of revenue from acquisitions, driven by the North America region and partially offset by the International region;

[0000068505-23-000026:mdna:62]
•inclusive of $26 million from unfavorable currency rates.

[0000068505-23-000026:mdna:63]
[same as prior period, unchanged from 0000068505-22-000031:mdna:71]

[0000068505-23-000026:mdna:64]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |  | % Change |
| Gross margin | $ | 1,046 |  |  | $ | 857 |  |  | 22 | % |

[0000068505-23-000026:mdna:65]
Gross margin was 48.2% of net sales in the first quarter of 2023 compared to 45.3% in the first quarter of 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-23-000026:mdna:66]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by pricing actions and lower supply chain costs; partially offset by

[0000068505-23-000026:mdna:67]
•lower gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by mix.

[0000068505-23-000026:mdna:68]
[same as prior period, unchanged from 0000068505-22-000031:mdna:76]

[0000068505-23-000026:mdna:69]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |  | % Change |
| Selling, general and administrative expenses | $ | 368 |  |  | $ | 338 |  |  | 9 | % |

[0000068505-23-000026:mdna:70]
SG&A expenses increased 9% in the first quarter of 2023 compared to the first quarter of 2022. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses and higher employee incentive expenses including shared-based compensation. SG&A expenses were 17.0% of net sales in the first quarter of 2023 compared to 17.9% of net sales in the first quarter of 2022.

[0000068505-23-000026:mdna:71]
[same as prior period, unchanged from 0000068505-22-000031:mdna:79]

[0000068505-23-000026:mdna:72]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |  | % Change |
| Research and development expenditures | $ | 210 |  |  | $ | 188 |  |  | 12 | % |

[0000068505-23-000026:mdna:73]
R&D expenditures increased 12% in the first quarter of 2023 compared to the first quarter of 2022 primarily due to higher expenses associated with acquired businesses and higher share-based compensation. R&D expenditures decreased to 9.7% of net sales in the first quarter of 2023 compared to 9.9% of net sales in the first quarter of 2022.

[0000068505-23-000026:mdna:74]
[same as prior period, unchanged from 0000068505-22-000031:mdna:82]

[0000068505-23-000026:mdna:75]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |
| Other charges | $ | 69 |  |  | $ | 92 |  |

[0000068505-23-000026:mdna:76]
Other charges decreased by $23 million in the first quarter of 2023 compared to the first quarter of 2022. The change was driven primarily by the following:

[0000068505-23-000026:mdna:77]
•$55 million of intangible asset amortization expense in the first quarter of 2023 compared to $66 million of intangible asset amortization expense in the first quarter of 2022;

[0000068505-23-000026:mdna:78]
•$11 million of legal settlement charges in the first quarter of 2022 that did not recur in the first quarter of 2023;

[0000068505-23-000026:mdna:79]
•$2 million of acquisition-related transaction fees in the first quarter of 2023 compared to $10 million of acquisition-related transaction fees in the first quarter of 2022;

[0000068505-23-000026:mdna:80]
•$3 million of operating lease asset impairments in the first quarter of 2023 compared to $9 million of operating lease asset impairments in the first quarter 2022; and

[0000068505-23-000026:mdna:81]
•$2 million of fixed asset impairments in the first quarter of 2023 compared to $3 million of fixed asset impairment in the first quarter of 2022; partially offset by

[0000068505-23-000026:mdna:82]
•$13 million of Hytera legal settlement gains in the first quarter of 2022 that did not recur in the first quarter of 2023.

[0000068505-23-000026:mdna:83]
[same as prior period, unchanged from 0000068505-22-000031:mdna:89]

[0000068505-23-000026:mdna:84]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |
| Operating earnings from Products and Systems Integration | $ | 176 |  |  | $ | 39 |  |
| Operating earnings from Software and Services | 223 |  |  | 200 |  |
| Operating earnings | $ | 399 |  |  | $ | 239 |  |

[0000068505-23-000026:mdna:85]
Operating earnings increased $160 million, or 67%, in the first quarter of 2023 compared to the first quarter of 2022. The increase in Operating earnings was due to:

[0000068505-23-000026:mdna:86]
•$137 million increase in the Products and Systems Integration segment, primarily driven by higher sales and lower material costs as well as improved operating leverage, partially offset by higher share-based compensation, a gain on Hytera Legal Settlement in Q1 2022 that did not recur in Q1 2023 and higher expenses associated with acquired businesses; and

[0000068505-23-000026:mdna:87]
•$23 million increase in the Software and Services segment, primarily driven by expenses related to legal settlements in Q1 2022 that did not recur in Q1 2023 and a reduction in intangible amortization expense, partially offset by a change in year-over-year mix and higher expenses associated with acquired businesses.

[0000068505-23-000026:mdna:88]
[same as prior period, unchanged from 0000068505-22-000031:mdna:94]

[0000068505-23-000026:mdna:89]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |
| Interest expense, net | $ | (54) |  |  | $ | (56) |  |

[0000068505-23-000026:mdna:90]
The $2 million decrease in Interest expense, net in the first quarter of 2023 compared to the first quarter of 2022 was primarily driven by higher interest income earned on cash, partially offset by higher outstanding debt.

[0000068505-23-000026:mdna:91]
[same as prior period, unchanged from 0000068505-22-000031:mdna:97]

[0000068505-23-000026:mdna:92]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |
| Other, net | $ | 12 |  |  | $ | 34 |  |

[0000068505-23-000026:mdna:93]
The $22 million decrease in Other, net in the first quarter of 2023 compared to the first quarter of 2022 was primarily driven by:

[0000068505-23-000026:mdna:94]
•$19 million of foreign currency losses in the first quarter of 2023 compared to $23 million of foreign currency gains in the first quarter of 2022;

[0000068505-23-000026:mdna:95]
•$21 million gain on an equity method investment in the first quarter of 2022 that did not recur in the first quarter of 2023;

[0000068505-23-000026:mdna:96]
•$25 million of net periodic pension and postretirement benefit in the first quarter of 2023 compared to $32 million of net periodic pension and postretirement benefit in the first quarter of 2022; and

[0000068505-23-000026:mdna:97]
•$6 million of investment impairments in the first quarter of 2023 compared to $1 million of investment impairments in the first quarter of 2022; partially offset by

[0000068505-23-000026:mdna:98]
•$7 million gain on derivatives in the first quarter of 2023 compared to a $23 million loss on derivatives in the first quarter of 2022; and

[0000068505-23-000026:mdna:99]
•$3 million gain on fair value adjustments to equity investments in the first quarter of 2023 compared to an $18 million loss on fair value adjustments to equity investments in the first quarter of 2022.

[0000068505-23-000026:mdna:100]
[same as prior period, unchanged from 0000068505-22-000031:mdna:106]

[0000068505-23-000026:mdna:101]
|  | Three Months Ended |
| (In millions) | April 1, 2023 |  | April 2, 2022 |
| Income tax expense (benefit) | $ | 79 |  |  | $ | (49) |  |

[0000068505-23-000026:mdna:102]
Income tax expense increased by $128 million in the first quarter of 2023 compared to the first quarter of 2022, resulting in an effective tax rate of 22%. Our effective tax rate for the three months ended April 1, 2023 of 22% was higher than the effective tax rate for the three months ended April 2, 2022 of (22)%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights, a higher foreign derived intangible income deduction and higher excess tax benefits of share-based compensation in 2022.

[0000068505-23-000026:mdna:103]
[same as prior period, unchanged from 0000068505-22-000031:mdna:173]

[0000068505-23-000026:mdna:104]
During the first quarter of 2023, we recorded net reorganization of business charges of $13 million, including $7 million of charges recorded within Other charges and $6 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $15 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-23-000026:mdna:105]
During the first quarter of 2022, we recorded net reorganization of business charges of $10 million, including $7 million of charges in Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-23-000026:mdna:106]
[same as prior period, unchanged from 0000068505-22-000031:mdna:178]

[0000068505-23-000026:mdna:107]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Products and Systems Integration | $ | 11 |  |  | $ | 8 |  |  |  |  |  |
| Software and Services | 2 |  |  | 2 |  |  |  |  |  |
|  | $ | 13 |  |  | $ | 10 |  |  |  |  |  |

[0000068505-23-000026:mdna:108]
Cash payments for employee severance in connection with the reorganization of business plans were $10 million in the first quarter of 2023 and $12 million in the first quarter of 2022. The reorganization of business accrual at April 1, 2023 was $29 million related to employee separation costs that are expected to be paid within one year.

[0000068505-23-000026:mdna:109]
At January 1, 2023, we had an accrual of $10 million for exit costs, related to our exit of the ESN contract with the Home Office in 2022. The $10 million of exit costs are recorded in Accrued liabilities in the our Condensed Consolidated Balance Sheet at April 1, 2023, and are expected to be paid within one year.

[0000068505-23-000026:mdna:110]
[same as prior period, unchanged from 0000068505-22-000031:mdna:181]

[0000068505-23-000026:mdna:111]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | (8) |  |  | $ | 152 |  |
| Investing activities | (53) |  |  | (557) |  |
| Financing activities | (263) |  |  | (577) |  |
| Effect of exchange rates on cash and cash equivalents | 21 |  |  | (14) |  |
| Increase (decrease) in cash and cash equivalents | $ | (303) |  |  | $ | (996) |  |

[0000068505-23-000026:mdna:112]
[same as prior period, unchanged from 0000068505-22-000031:mdna:183]

[0000068505-23-000026:mdna:113]
At April 1, 2023, $599 million of the $1.0 billion cash and cash equivalents balance was held in the U.S. and $423 million was held in other countries, with $83 million held in the United Kingdom.

[0000068505-23-000026:mdna:114]
[same as prior period, unchanged from 0000068505-22-000031:mdna:185]

[0000068505-23-000026:mdna:115]
The decrease in cash flows provided by operating activities from the first quarter of 2022 to the first quarter of 2023 was driven primarily by higher working capital and a one time $70 million cash tax payment related to an intellectual property reorganization completed in 2022.

[0000068505-23-000026:mdna:116]
[same as prior period, unchanged from 0000068505-22-000031:mdna:187]

[0000068505-23-000026:mdna:117]
The decrease in cash flows used for investing activities in the first quarter of 2023 compared to the first quarter of 2022 was primarily due to a $508 million decrease in cash used for acquisitions and investments.

[0000068505-23-000026:mdna:118]
[same as prior period, unchanged from 0000068505-22-000031:mdna:189]

[0000068505-23-000026:mdna:119]
The decrease in cash flows used for financing activities in the first quarter of 2023 compared to the first quarter of 2022 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-23-000026:mdna:120]
•$353 million decrease in share repurchases in the first quarter of 2023 compared to the first quarter of 2022;

[0000068505-23-000026:mdna:121]
•$26 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first quarter of 2023 compared to the first quarter of 2022; and

[0000068505-23-000026:mdna:122]
•$1 million decrease in repayments of debt in the first quarter of 2023 compared to the first quarter of 2022; partially offset by

[0000068505-23-000026:mdna:123]
•$14 million increase in the payment of dividends in the first quarter of 2023 compared to the first quarter of 2022.

[0000068505-23-000026:mdna:124]
[same as prior period, unchanged from 0000068505-22-000031:mdna:197]

[0000068505-23-000026:mdna:125]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended April 1, 2023 and April 2, 2022:

[0000068505-23-000026:mdna:126]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Contract-specific discounting facility | $ | — |  |  | $ | 49 |  |  |  |  |  |
| Accounts receivable sales proceeds | — |  |  | 22 |  |  |  |  |  |
| Long-term receivables sales proceeds | 32 |  |  | 17 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 32 |  |  | $ | 88 |  |  |  |  |  |

[0000068505-23-000026:mdna:127]
[same as prior period, unchanged from 0000068505-22-000031:mdna:201]

[0000068505-23-000026:mdna:128]
We had outstanding debt of $6.0 billion at each of April 1, 2023 and December 31, 2022, including the current portions of $1 million and $1 million, at April 1, 2023 and December 31, 2022, respectively.

[0000068505-23-000026:mdna:129]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of April 1, 2023. On February 8, 2023, we entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

[0000068505-23-000026:mdna:130]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("Senior Convertible Notes"). Interest on these notes is payable semiannually. The Senior Convertible Notes became fully convertible on September 5, 2021. The notes are convertible based on a conversion rate of 4.9670 per $1,000 principal amount (which is equal to conversion price of $201.33 per share). In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash.

[0000068505-23-000026:mdna:131]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of April 1, 2023 we had no outstanding debt under the commercial paper program.

[0000068505-23-000026:mdna:132]
[same as prior period, unchanged from 0000068505-22-000031:mdna:207]

[0000068505-23-000026:mdna:133]
During the three months ended April 1, 2023, we paid an aggregate of $140 million, including transaction costs, to repurchase approximately 0.5 million shares at an average price of $261.75 per share. As of April 1, 2023, we had used approximately $14.9 billion of the share repurchase authority to repurchase shares, leaving $1.1 billion of authority available for future repurchases.

[0000068505-23-000026:mdna:134]
[same as prior period, unchanged from 0000068505-22-000031:mdna:38]

[0000068505-23-000026:mdna:135]
[same as prior period, unchanged from 0000068505-22-000031:mdna:209]

[0000068505-23-000026:mdna:136]
During the first quarter of 2023 we paid $148 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $148 million in cash dividends to holders of our common stock.

[0000068505-23-000026:mdna:137]
[same as prior period, unchanged from 0000068505-22-000031:mdna:211]

[0000068505-23-000026:mdna:138]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement.

[0000068505-23-000026:mdna:139]
[same as prior period, unchanged from 0000068505-22-000031:mdna:215]

[0000068505-23-000026:mdna:140]
[same as prior period, unchanged from 0000068505-22-000031:mdna:216]

[0000068505-23-000026:mdna:141]
We had outstanding commitments to provide long-term financing to third parties totaling $153 million at April 1, 2023, compared to $65 million at December 31, 2022.

[0000068505-23-000026:mdna:142]
[same as prior period, unchanged from 0000068505-22-000031:mdna:218]

[0000068505-23-000026:mdna:143]
See "Recent Accounting Pronouncements" and “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
