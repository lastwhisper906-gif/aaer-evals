# MSI notes — 0000068505-23-000026


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-23-000026:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of April 1, 2023 and for the three months ended April 1, 2023 and April 2, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-23-000026:notes:2]
[same as prior period, unchanged from 0000068505-22-000031:notes:2]

[0000068505-23-000026:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three months ended April 1, 2023 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-23-000026:notes:4]
[same as prior period, unchanged from 0000068505-22-000031:notes:4]

[0000068505-23-000026:notes:5]
[same as prior period, unchanged from 0000068505-22-000031:notes:5]

[0000068505-23-000026:notes:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center. In January 2023, we began using Command Center as a naming convention, eliminating the "Software" descriptor from Command Center Software in order to inform investors that the Company has software components more broadly across all technologies; this name change does not require any financial information to be reclassified from previous periods.

[0000068505-23-000026:notes:7]
[same as prior period, unchanged from 0000068505-22-000031:notes:7]

[0000068505-23-000026:notes:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence ("AI")-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

[0000068505-23-000026:notes:9]
•Command Center: Software suite that enables collaboration and shares information throughout the public safety workflow from "911 call to case closure."

[0000068505-23-000026:notes:10]
[same as prior period, unchanged from 0000068505-22-000031:notes:10]

[0000068505-23-000026:notes:11]
On December 14, 2022, the Company acquired Rave Mobile Safety, Inc. ("Rave Mobile"), a leader in mass notification and incident management, for $553 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The business is a part of the Software and Services segment.

[0000068505-23-000026:notes:12]
On October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part the Products and Systems Integration segment.

[0000068505-23-000026:notes:13]
[same as prior period, unchanged from 0000068505-22-000031:notes:12]

[0000068505-23-000026:notes:14]
[same as prior period, unchanged from 0000068505-22-000031:notes:13]

[0000068505-23-000026:notes:15]
[same as prior period, unchanged from 0000068505-22-000031:notes:14]

[0000068505-23-000026:notes:16]
[same as prior period, unchanged from 0000068505-22-000031:notes:15]

[0000068505-23-000026:notes:17]
[same as prior period, unchanged from 0000068505-22-000031:notes:16]

[0000068505-23-000026:notes:18]
Recently Adopted Accounting Pronouncements

[0000068505-23-000026:notes:19]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs" (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-23-000026:notes:20]
[same as prior period, unchanged from 0000068505-22-000031:notes:27]

[0000068505-23-000026:notes:21]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 1, 2023 and April 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-23-000026:notes:22]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |  | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |
| International | 353 |  |  | 326 |  |  | 679 |  |  | 272 |  |  | 315 |  |  | 587 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |  | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |
| Video | 223 |  |  | 136 |  |  | 359 |  |  | 194 |  |  | 113 |  |  | 307 |  |
| Command Center | — |  |  | 155 |  |  | 155 |  |  | — |  |  | 130 |  |  | 130 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |  | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |
| Indirect | 580 |  |  | 73 |  |  | 653 |  |  | 447 |  |  | 87 |  |  | 534 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |

[0000068505-23-000026:notes:23]
|  | Three Months Ended |

[0000068505-23-000026:notes:24]
[same as prior period, unchanged from 0000068505-22-000031:notes:31]

[0000068505-23-000026:notes:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 1, 2023 was $9.2 billion. A total of $4.7 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of April 1, 2023, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.5 billion was from Software and Services performance obligations that were not yet

[0000068505-23-000026:notes:26]
satisfied as of April 1, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-23-000026:notes:27]
[same as prior period, unchanged from 0000068505-22-000031:notes:33]

[0000068505-23-000026:notes:28]
| (In millions) | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,340 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,024 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,793 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 378 |  |  | 363 |  |  |  |  |  |

[0000068505-23-000026:notes:29]
Revenue recognized during the three months ended April 1, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $474 million, compared to $456 million of revenue recognized during the three months ended April 2, 2022 which was previously included in Contract liabilities as of December 31, 2021. Revenue of $10 million was reversed during the three months ended April 1, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $17 million of reversals for the three months ended April 2, 2022.

[0000068505-23-000026:notes:30]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 1, 2023 and April 2, 2022.

[0000068505-23-000026:notes:31]
Contract Cost Balances

[0000068505-23-000026:notes:32]
| (In millions) | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 119 |  |  | 130 |  |  |  |  |  |

[0000068505-23-000026:notes:33]
Amortization of non-current contract cost assets was $17 million for both the three months ended April 1, 2023, and April 2, 2022.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-23-000026:notes:34]
LeasesComponents of Lease Expense

[0000068505-23-000026:notes:35]
|  | Three Months Ended |  |  |
| (in millions) | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 34 |  |  | $ | 33 |  |  |  |  |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 1 |  |  | $ | 2 |  |  |  |  |  |
| Short-term lease cost | $ | — |  |  | $ | 1 |  |  |  |  |  |
| Variable cost | 9 |  |  | 9 |  |  |  |  |  |
| Sublease income | (2) |  |  | (1) |  |  |  |  |  |
| Net lease expense | $ | 42 |  |  | $ | 44 |  |  |  |  |  |

[0000068505-23-000026:notes:36]
Lease Assets and Liabilities

[0000068505-23-000026:notes:37]
| (in millions) |  | Statement Line Classification |  | April 1, 2023 |  | December 31, 2022 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 472 |  |  | $ | 485 |  |  |  |
| Finance lease assets |  | Property, plant and equipment, net |  | 10 |  |  | 9 |  |  |  |
|  |  |  |  | $ | 482 |  |  | $ | 494 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 108 |  |  | $ | 118 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 1 |  |  | 1 |  |  |  |
|  |  |  |  | $ | 109 |  |  | $ | 119 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 398 |  |  | $ | 419 |  |  |  |

[0000068505-23-000026:notes:38]
Other Information Related to Leases

[0000068505-23-000026:notes:39]
|  | Three Months Ended |  |  |
| (in millions) | April 1, 2023 |  | April 2, 2022 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 52 |  |  | $ | 62 |  |  |  |
| Net cash used for financing activities related to finance leases | — |  |  | 2 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 8 |  |  | $ | 40 |  |  |  |

[0000068505-23-000026:notes:40]
Assets obtained in exchange for lease liabilities for the three months ended April 2, 2022 included $34 million of additional leases acquired in connection with the Company's acquisition of TETRA Ireland.

[0000068505-23-000026:notes:41]
|  | April 1, 2023 |  | December 31, 2022 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 5 |  | 5 |
| Finance leases | 1 |  | 1 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 4.09 | % |  | 4.07 | % |
| Finance leases | 2.77 | % |  | 3.23 | % |

[0000068505-23-000026:notes:42]
Future Lease Payments

[0000068505-23-000026:notes:43]
|  | April 1, 2023 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2023 | $ | 90 |  |  | $ | 1 |  |  | $ | 91 |  |
| 2024 | 129 |  |  | — |  |  | 129 |  |
| 2025 | 112 |  |  | — |  |  | 112 |  |
| 2026 | 96 |  |  | — |  |  | 96 |  |
| 2027 | 51 |  |  | — |  |  | 51 |  |
| Thereafter | 81 |  |  | — |  |  | 81 |  |
| Total lease payments | $ | 559 |  |  | $ | 1 |  |  | $ | 560 |  |
| Less: Interest | 53 |  |  | — |  |  | 53 |  |
| Present value of lease liabilities | $ | 506 |  |  | $ | 1 |  |  | $ | 507 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-23-000026:notes:44]
[same as prior period, unchanged from 0000068505-22-000031:notes:49]

[0000068505-23-000026:notes:45]
[same as prior period, unchanged from 0000068505-22-000031:notes:50]

[0000068505-23-000026:notes:46]
[same as prior period, unchanged from 0000068505-22-000031:notes:51]

[0000068505-23-000026:notes:47]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 55 |  |  | $ | 66 |  |  |  |  |  |
| Reorganization of business (Note 14) | 7 |  |  | 7 |  |  |  |  |  |
| Operating lease asset impairments | 3 |  |  | 9 |  |  |  |  |  |
| Acquisition-related transaction fees | 2 |  |  | 10 |  |  |  |  |  |
| Legal settlements | — |  |  | 11 |  |  |  |  |  |
| Fixed asset impairments | 2 |  |  | 3 |  |  |  |  |  |
| Gain on Hytera legal settlement | — |  |  | (13) |  |  |  |  |  |
| Other | — |  |  | (1) |  |  |  |  |  |
|  | $ | 69 |  |  | $ | 92 |  |  |  |  |  |

[0000068505-23-000026:notes:48]
[same as prior period, unchanged from 0000068505-22-000031:notes:54]

[0000068505-23-000026:notes:49]
[same as prior period, unchanged from 0000068505-22-000031:notes:55]

[0000068505-23-000026:notes:50]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (63) |  |  | $ | (58) |  |  |  |  |  |
| Interest income | 9 |  |  | 2 |  |  |  |  |  |
|  | $ | (54) |  |  | $ | (56) |  |  |  |  |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 25 |  |  | $ | 32 |  |  |  |  |  |
| Investment impairments | (6) |  |  | (1) |  |  |  |  |  |
| Foreign currency gain (loss) | (19) |  |  | 23 |  |  |  |  |  |
| Gain (loss) on derivative instruments (Note 6) | 7 |  |  | (23) |  |  |  |  |  |
| Fair value adjustments to equity investments | 3 |  |  | (18) |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment | — |  |  | 21 |  |  |  |  |  |
| Other | 2 |  |  | — |  |  |  |  |  |
|  | $ | 12 |  |  | $ | 34 |  |  |  |  |  |

[0000068505-23-000026:notes:51]
[same as prior period, unchanged from 0000068505-22-000031:notes:58]

[0000068505-23-000026:notes:52]
[same as prior period, unchanged from 0000068505-22-000031:notes:59]

[0000068505-23-000026:notes:53]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 278 |  |  | $ | 267 |  |  |  |  |  |
| Weighted average common shares outstanding | 167.4 |  |  | 168.0 |  |  |  |  |  |
| Per share amount | $ | 1.66 |  |  | $ | 1.59 |  |  |  |  |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 278 |  |  | $ | 267 |  |  |  |  |  |
| Weighted average common shares outstanding | 167.4 |  |  | 168.0 |  |  |  |  |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 4.0 |  |  | 4.5 |  |  |  |  |  |
| 1.75% senior convertible notes | 1.2 |  |  | 0.6 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 172.6 |  |  | 173.1 |  |  |  |  |  |
| Per share amount | $ | 1.61 |  |  | $ | 1.54 |  |  |  |  |  |

[0000068505-23-000026:notes:54]
In the computation of diluted earnings per common share for the three months ended April 1, 2023, the assumed exercise of 0.2 million options, inclusive of 0.1 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the three months ended April 2, 2022, the assumed exercise of 0.2 million options were excluded because their inclusion would have been antidilutive.

[0000068505-23-000026:notes:55]
As of April 1, 2023, the Company had $1.0 billion of the Senior Convertible Notes outstanding, which mature on September 15, 2024. The notes are convertible based on a conversion rate of 4.9670 per $1,000 principal amount (which is equal to a conversion price of $201.33 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, when the average stock price exceeded the contractual conversion price, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the quarter ended October 2, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended April 1, 2023. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of April 1, 2023 was $332 million.

[0000068505-23-000026:notes:56]
[same as prior period, unchanged from 0000068505-22-000031:notes:64]

[0000068505-23-000026:notes:57]
[same as prior period, unchanged from 0000068505-22-000031:notes:65]

[0000068505-23-000026:notes:58]
[same as prior period, unchanged from 0000068505-22-000031:notes:66]

[0000068505-23-000026:notes:59]
|  | April 1, 2023 |  | December 31, 2022 |
| Accounts receivable | $ | 1,403 |  |  | $ | 1,579 |  |
| Less allowance for credit losses | (63) |  |  | (61) |  |
|  | $ | 1,340 |  |  | $ | 1,518 |  |

[0000068505-23-000026:notes:60]
[same as prior period, unchanged from 0000068505-22-000031:notes:68]

[0000068505-23-000026:notes:61]
[same as prior period, unchanged from 0000068505-22-000031:notes:69]

[0000068505-23-000026:notes:62]
|  | April 1, 2023 |  | December 31, 2022 |
| Finished goods | $ | 365 |  |  | $ | 354 |  |
| Work-in-process and production materials | 852 |  |  | 829 |  |
|  | 1,217 |  |  | 1,183 |  |
| Less inventory reserves | (135) |  |  | (128) |  |
|  | $ | 1,082 |  |  | $ | 1,055 |  |

[0000068505-23-000026:notes:63]
[same as prior period, unchanged from 0000068505-22-000031:notes:71]

[0000068505-23-000026:notes:64]
[same as prior period, unchanged from 0000068505-22-000031:notes:72]

[0000068505-23-000026:notes:65]
|  | April 1, 2023 |  | December 31, 2022 |
| Current contract cost assets (Note 2) | $ | 69 |  |  | $ | 61 |  |
| Contractor receivables | 4 |  |  | 47 |  |
| Tax-related deposits | 38 |  |  | 33 |  |
| Other | 247 |  |  | 242 |  |
|  | $ | 358 |  |  | $ | 383 |  |

[0000068505-23-000026:notes:66]
[same as prior period, unchanged from 0000068505-22-000031:notes:74]

[0000068505-23-000026:notes:67]
[same as prior period, unchanged from 0000068505-22-000031:notes:75]

[0000068505-23-000026:notes:68]
|  | April 1, 2023 |  | December 31, 2022 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 463 |  |  | 456 |  |
| Machinery and equipment | 2,224 |  |  | 2,303 |  |
|  | 2,692 |  |  | 2,764 |  |
| Less accumulated depreciation | (1,765) |  |  | (1,837) |  |
|  | $ | 927 |  |  | $ | 927 |  |

[0000068505-23-000026:notes:69]
Depreciation expense for the three months ended April 1, 2023 and April 2, 2022 was $43 million and $45 million, respectively.

[0000068505-23-000026:notes:70]
[same as prior period, unchanged from 0000068505-22-000031:notes:79]

[0000068505-23-000026:notes:71]
[same as prior period, unchanged from 0000068505-22-000031:notes:80]

[0000068505-23-000026:notes:72]
|  | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Common stock | $ | 22 |  |  | $ | 21 |  |  |  |  |  |
| Strategic investments | 38 |  |  | 45 |  |  |  |  |  |
| Company-owned life insurance policies | 71 |  |  | 69 |  |  |  |  |  |
| Equity method investments | 13 |  |  | 12 |  |  |  |  |  |
|  | $ | 144 |  |  | $ | 147 |  |  |  |  |  |

[0000068505-23-000026:notes:73]
During the three months ended April 1, 2023, the Company recorded a $6 million investment impairment charge, representing an other-than-temporary decline in the value of the Company's strategic equity investment portfolio. The investment impairment charge is classified as Other, net within the Condensed Consolidated Statement of Operations.

[0000068505-23-000026:notes:74]
[same as prior period, unchanged from 0000068505-22-000031:notes:84]

[0000068505-23-000026:notes:75]
[same as prior period, unchanged from 0000068505-22-000031:notes:85]

[0000068505-23-000026:notes:76]
|  | April 1, 2023 |  | December 31, 2022 |
| Defined benefit plan assets | $ | 128 |  |  | $ | 164 |  |
| Non-current contract cost assets (Note 2) | 119 |  |  | 130 |  |
| Other | 75 |  |  | 16 |  |
|  | $ | 322 |  |  | $ | 310 |  |

[0000068505-23-000026:notes:77]
Accounts Payable

[0000068505-23-000026:notes:78]
The Company utilizes a supplier finance program which provides our suppliers the ability to accelerate payment on the Company's invoices beyond the stated payment terms. Under the terms of this program, the Company agrees to pay an intermediary the stated amount of confirmed invoices on the stated maturity dates of the invoices, and the supplier is able to negotiate earlier payment terms with the intermediary. The Company or the intermediary may terminate our agreement at any time upon 60 days' notice. The Company does not provide any forms of guarantees under this arrangement. Supplier participation in the program is solely at the supplier's discretion, and the participating suppliers negotiate their arrangements directly with the intermediary. The Company has no economic interest in a supplier's decision to participate in the program, and their participation has no bearing on our payment terms or amounts due. The stated invoice payment terms range from 75 to 120 days from the invoice date and are considered commercially reasonable.

[0000068505-23-000026:notes:79]
The Company's outstanding amounts related to the suppliers participating in this program was $36 million and $37 million as of April 1, 2023 and December 31, 2022, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-23-000026:notes:80]
[same as prior period, unchanged from 0000068505-22-000031:notes:87]

[0000068505-23-000026:notes:81]
[same as prior period, unchanged from 0000068505-22-000031:notes:88]

[0000068505-23-000026:notes:82]
|  | April 1, 2023 |  | December 31, 2022 |
| Compensation | $ | 329 |  |  | $ | 374 |  |
| Tax liabilities | 349 |  |  | 367 |  |
| Dividend payable | 148 |  |  | 148 |  |
| Trade liabilities | 138 |  |  | 145 |  |
| Operating lease liabilities (Note 3) | 108 |  |  | 118 |  |
| Customer reserves | 56 |  |  | 78 |  |
| Other | 325 |  |  | 408 |  |
|  | $ | 1,453 |  |  | $ | 1,638 |  |

[0000068505-23-000026:notes:83]
[same as prior period, unchanged from 0000068505-22-000031:notes:90]

[0000068505-23-000026:notes:84]
[same as prior period, unchanged from 0000068505-22-000031:notes:91]

[0000068505-23-000026:notes:85]
|  | April 1, 2023 |  | December 31, 2022 |
| Defined benefit plans | $ | 974 |  |  | $ | 1,004 |  |
| Non-current contract liabilities (Note 2) | 378 |  |  | 363 |  |
| Unrecognized tax benefits (Note 7) | 29 |  |  | 29 |  |
| Deferred income taxes (Note 7) | 74 |  |  | 73 |  |
| Environmental reserve | 108 |  |  | 108 |  |
| Other | 163 |  |  | 114 |  |
|  | $ | 1,726 |  |  | $ | 1,691 |  |

[0000068505-23-000026:notes:86]
Stockholders’ Equity

[0000068505-23-000026:notes:87]
Share Repurchase Program: During the three months ended April 1, 2023, the Company paid an aggregate of $140 million to repurchase approximately 0.5 million shares at an average price of $261.75. per share. As of April 1, 2023, the Company had $1.1 billion of authority available for future repurchases.

[0000068505-23-000026:notes:88]
Payment of Dividends: During the three months ended April 1, 2023 and April 2, 2022, the Company paid $148 million and $134 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $148 million in cash dividends to holders of its common stock.

[0000068505-23-000026:notes:89]
[same as prior period, unchanged from 0000068505-22-000031:notes:96]

[0000068505-23-000026:notes:90]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended April 1, 2023 and April 2, 2022:

[0000068505-23-000026:notes:91]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (539) |  |  | $ | (384) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | 27 |  |  | (18) |  |  |  |  |  |
| Tax benefit (expense) | 9 |  |  | (2) |  |  |  |  |  |
| Other comprehensive income (loss), net of tax | 36 |  |  | (20) |  |  |  |  |  |
| Balance at end of period | $ | (503) |  |  | $ | (404) |  |  |  |  |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,996) |  |  | $ | (1,995) |  |  |  |  |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 15 |  |  | 20 |  |  |  |  |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | 1 |  |  | (1) |  |  |  |  |  |
| Tax expense | (4) |  |  | (4) |  |  |  |  |  |
| Other comprehensive income, net of tax | 12 |  |  | 15 |  |  |  |  |  |
| Balance at end of period | $ | (1,984) |  |  | $ | (1,980) |  |  |  |  |  |
| Total Accumulated other comprehensive loss | $ | (2,487) |  |  | $ | (2,384) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-23-000026:notes:92]
Debt and Credit Facilities
As of April 1, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 1, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

[0000068505-23-000026:notes:93]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 1, 2023 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-23-000026:notes:94]
[same as prior period, unchanged from 0000068505-22-000031:notes:104]

[0000068505-23-000026:notes:95]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.1 billion for both periods ended April 1, 2023 and December 31, 2022. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-23-000026:notes:96]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 1, 2023, and the corresponding positions as of December 31, 2022:

[0000068505-23-000026:notes:97]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 1, 2023 |  | December 31, 2022 |
| British pound | $ | 255 |  |  | $ | 290 |  |
| Euro | 209 |  |  | 185 |  |
| Australian dollar | (111) |  |  | (130) |  |
| Chinese renminbi | (62) |  |  | (61) |  |
| Brazilian real | (49) |  |  | (44) |  |

[0000068505-23-000026:notes:98]
[same as prior period, unchanged from 0000068505-22-000031:notes:108]

[0000068505-23-000026:notes:99]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 1, 2023, all of the counterparties had investment grade credit ratings. As of April 1, 2023, the Company had $8 million of exposure to aggregate credit risk with all counterparties.

[0000068505-23-000026:notes:100]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of April 1, 2023 and December 31, 2022:

[0000068505-23-000026:notes:101]
|  | Fair Values of Derivative Instruments |
| April 1, 2023 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 8 |  |  | 1 |  |
| Total derivatives | $ | 8 |  |  | $ | 1 |  |

[0000068505-23-000026:notes:102]
|  | Fair Values of Derivative Instruments |
| December 31, 2022 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 5 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 15 |  |  | — |  |
| Total derivatives | $ | 15 |  |  | $ | 5 |  |

[0000068505-23-000026:notes:103]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended April 1, 2023 and April 2, 2022:

[0000068505-23-000026:notes:104]
|  | Financial Statement Location | Three Months Ended |  |  |
| Foreign Exchange Contracts | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Effective portion of derivatives designated | Accumulated othercomprehensive gain (loss) | $ | (2) |  |  | $ | 2 |  |  |  |  |  |
| Forward points recognized | Other income (expense) | 1 |  |  | — |  |  |  |  |  |
| Derivatives not designated as hedging instruments | Other income (expense) | 7 |  |  | (23) |  |  |  |  |  |

[0000068505-23-000026:notes:105]
[same as prior period, unchanged from 0000068505-22-000031:notes:115]

[0000068505-23-000026:notes:106]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of April 1, 2023, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £55 million of net investment hedges in a British pound functional subsidiary.

[0000068505-23-000026:notes:107]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. During the three months ended April 1, 2023, the Company amortized $1 million of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-23-000026:notes:108]
[same as prior period, unchanged from 0000068505-22-000031:notes:118]

[0000068505-23-000026:notes:109]
[same as prior period, unchanged from 0000068505-22-000031:notes:120]

[0000068505-23-000026:notes:110]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Net earnings before income taxes | $ | 358 |  |  | $ | 219 |  |  |  |  |  |
| Income tax expense (benefit) | 79 |  |  | (49) |  |  |  |  |  |
| Effective tax rate | 22 | % |  | (22) | % |  |  |  |  |

[0000068505-23-000026:notes:111]
The effective tax rate for the three months ended April 1, 2023 of 22% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by excess tax benefits of share-based compensation.

[0000068505-23-000026:notes:112]
The effective tax rate for the three months ended April 2, 2022 of (22)% was lower than the U.S. federal statutory tax rate of 21% primarily due to to a net deferred tax benefit as a result of an intra-group transfer of certain intellectual property ("IP") rights, a high foreign derived intangible income deduction and the excess tax benefits of share-based compensation. 
The effective tax rate for the three months ended April 1, 2023 of 22% was higher than the effective tax rate for the three months ended April 2, 2022 of (22)%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights, a higher foreign derived intangible income deduction, and higher excess tax benefits of share-based compensation in 2022.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-23-000026:notes:113]
[same as prior period, unchanged from 0000068505-22-000031:notes:125]

[0000068505-23-000026:notes:114]
[same as prior period, unchanged from 0000068505-22-000031:notes:126]

[0000068505-23-000026:notes:115]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 47 |  |  | 32 |  |  | 2 |  |  | 8 |  |  | 1 |  |  | — |  |
| Expected return on plan assets | (73) |  |  | (63) |  |  | (15) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 5 |  |  | 15 |  |  | 9 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | — |  |  | (1) |  |  | 1 |  |  | — |  |
| Net periodic pension benefits | $ | (21) |  |  | $ | (16) |  |  | $ | (4) |  |  | $ | (14) |  |  | $ | — |  |  | $ | (2) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-23-000026:notes:116]
[same as prior period, unchanged from 0000068505-22-000031:notes:129]

[0000068505-23-000026:notes:117]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 10 |  |  | $ | 6 |  |  |  |  |  |
| Selling, general and administrative expenses | 30 |  |  | 21 |  |  |  |  |  |
| Research and development expenditures | 15 |  |  | 10 |  |  |  |  |  |
| Share-based compensation expense included in Operating earnings | 55 |  |  | 37 |  |  |  |  |  |
| Tax benefit | (11) |  |  | (8) |  |  |  |  |  |
| Share-based compensation expense, net of tax | $ | 44 |  |  | $ | 29 |  |  |  |  |  |
| Decrease in basic earnings per share | $ | (0.26) |  |  | $ | (0.17) |  |  |  |  |  |
| Decrease in diluted earnings per share | $ | (0.25) |  |  | $ | (0.17) |  |  |  |  |  |

[0000068505-23-000026:notes:118]
During the three months ended April 1, 2023, the Company granted 0.6 million restricted stock units (RSUs) and 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $155 million, $24 million and $12 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $6 million and $12 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-23-000026:notes:119]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 1, 2023 and December 31, 2022 were as follows:

[0000068505-23-000026:notes:120]
| April 1, 2023 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  |  |  | $ | 8 |  |
| Common stock | 22 |  |  | — |  |  |  |  | 22 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  |  |  | $ | 1 |  |

[0000068505-23-000026:notes:121]
| December 31, 2022 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 15 |  |  |  |  | $ | 15 |  |
| Common stock | 21 |  |  | — |  |  |  |  | 21 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-23-000026:notes:122]
The Company had no foreign exchange derivative contracts or common stock investments in Level 3 holdings as of April 1, 2023 or December 31, 2022.

[0000068505-23-000026:notes:123]
At April 1, 2023 and December 31, 2022, the Company had $379 million and $490 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-23-000026:notes:124]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of April 1, 2023 was $6.1 billion, of which the Senior Convertible Notes were $1.4 billion (Level 2). The fair value of long-term debt at December 31, 2022 was $5.9 billion, of which the Senior Convertible Notes were $1.3 billion (Level 2).

[0000068505-23-000026:notes:125]
[same as prior period, unchanged from 0000068505-22-000031:notes:140]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-23-000026:notes:126]
[same as prior period, unchanged from 0000068505-22-000031:notes:141]

[0000068505-23-000026:notes:127]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended April 1, 2023 and April 2, 2022:

[0000068505-23-000026:notes:128]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Contract-specific discounting facility | $ | — |  |  | $ | 49 |  |  |  |  |  |
| Accounts receivable sales proceeds | — |  |  | 22 |  |  |  |  |  |
| Long-term receivables sales proceeds | 32 |  |  | 17 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 32 |  |  | $ | 88 |  |  |  |  |  |

[0000068505-23-000026:notes:129]
At April 1, 2023, the Company had retained servicing obligations for $828 million of long-term receivables, compared to $891 million at December 31, 2022. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $153 million at April 1, 2023, compared to $65 million at December 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-23-000026:notes:130]
Commitments and Contingencies
Legal Matters

[0000068505-23-000026:notes:131]
Hytera Litigation

[0000068505-23-000026:notes:132]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-23-000026:notes:133]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment in July. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023 and April 25, 2023, into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow.

[0000068505-23-000026:notes:134]
On August 2, 2022, Hytera appealed the Court's judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. On November 15, 2022, Hytera filed its appellate court brief in the Court of Appeals. The Company filed its response brief with the appellate court on February 13, 2023. Hytera’s reply brief is due May 1, 2023.

[0000068505-23-000026:notes:135]
Hytera Bankruptcy Proceedings

[0000068505-23-000026:notes:136]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-23-000026:notes:137]
[same as prior period, unchanged from 0000068505-22-000031:notes:152]

[0000068505-23-000026:notes:138]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Products and Systems Integration | $ | 1,303 |  |  | $ | 1,103 |  |  |  |  |  |
| Software and Services | 868 |  |  | 789 |  |  |  |  |  |
|  | $ | 2,171 |  |  | $ | 1,892 |  |  |  |  |  |

[0000068505-23-000026:notes:139]
[same as prior period, unchanged from 0000068505-22-000031:notes:154]

[0000068505-23-000026:notes:140]
|  | Three Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Products and Systems Integration | $ | 176 |  |  | $ | 39 |  |  |  |  |  |
| Software and Services | 223 |  |  | 200 |  |  |  |  |  |
| Operating earnings | 399 |  |  | 239 |  |  |  |  |  |
| Total other expense | (41) |  |  | (20) |  |  |  |  |  |
| Earnings before income taxes | $ | 358 |  |  | $ | 219 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-23-000026:notes:141]
Reorganization of Business
2023 Charges

[0000068505-23-000026:notes:142]
During the three months ended April 1, 2023, the Company recorded net reorganization of business charges of $13 million, including $7 million of charges in Other charges and $6 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $15 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-23-000026:notes:143]
[same as prior period, unchanged from 0000068505-22-000031:notes:159]

[0000068505-23-000026:notes:144]
| April 1, 2023 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 11 |  |  |  |
| Software and Services | 2 |  |  |  |
|  | $ | 13 |  |  |  |

[0000068505-23-000026:notes:145]
[same as prior period, unchanged from 0000068505-22-000031:notes:161]

[0000068505-23-000026:notes:146]
|  | January 1, 2023 |  | Additional Charges |  | Adjustments |  | Amount Used |  | April 1, 2023 |
| Employee separation costs | $ | 26 |  |  | $ | 15 |  |  | $ | (2) |  |  | $ | (10) |  |  | $ | 29 |  |
| Exit costs | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
|  | $ | 36 |  |  | $ | 15 |  |  | $ | (2) |  |  | $ | (10) |  |  | $ | 39 |  |

[0000068505-23-000026:notes:147]
Exit Costs

[0000068505-23-000026:notes:148]
At January 1, 2023, the Company had an accrual of $10 million for exit costs, related to the Company's exit of the ESN contract with the Home Office in 2022. The $10 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at April 1, 2023, and are expected to be paid within one year.

[0000068505-23-000026:notes:149]
[same as prior period, unchanged from 0000068505-22-000031:notes:163]

[0000068505-23-000026:notes:150]
At January 1, 2023, the Company had an accrual of $26 million for employee separation costs. The 2023 additional charges of $15 million represent severance costs for approximately 290 employees. The adjustment of $2 million reflects reversals for accruals no longer needed. The $10 million used reflects cash payments to severed employees. The remaining accrual of $29 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at April 1, 2023, is expected to be paid, primarily within one year, to approximately 600 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-23-000026:notes:151]
2022 Charges

[0000068505-23-000026:notes:152]
During the three months ended April 2, 2022, the Company recorded net reorganization of business charges of $10 million, including $7 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-23-000026:notes:153]
| April 2, 2022 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 8 |  |  |  |
| Software and Services | 2 |  |  |  |
|  | $ | 10 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-23-000026:notes:154]
Intangible Assets and GoodwillOn December 14, 2022, the Company acquired Rave Mobile, a leader in mass notification and incident management, for $553 million net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The Company recognized $403 million of goodwill, $212 million of identifiable intangible assets and $62 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of trade names, $82 million of developed technology and $121 million of customer relationships and will be amortized over a period of nine, seventeen years and seventeen years, respectively. The business is a part of the Software and Services segment. The 
purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-23-000026:notes:155]
On October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The Company recognized $11 million of goodwill, $11 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of six years. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-23-000026:notes:156]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The Company recognized $1 million of goodwill and $14 million of net assets. The goodwill is not deductible for tax purposes. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000026:notes:157]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $9 million of goodwill, $7 million of identifiable intangible assets, and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000026:notes:158]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The Company recognized $24 million of goodwill, $21 million of identifiable intangible assets and $6 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $20 million of developed technology and $1 million of customer relationships that will be amortized over a period of fifteen and three years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-23-000026:notes:159]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. As a result of the acquisition, the Company recognized a $21 million gain recorded within Other income (expense) on the Company's initial minority interest. The Company recognized $47 million of goodwill, $90 million of identifiable intangible assets, and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $83 million of customer relationships and $7 million of trade names that will be amortized over a period of twelve years and fourteen years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2023.

[0000068505-23-000026:notes:160]
On March 3, 2022, the Company acquired Ava, a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The Company recognized $267 million of goodwill, $165 million of identifiable intangible assets and $44 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $144 million of developed technology and $21 million of customer relationships that will be amortized over a period of fourteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the first quarter of 2023.

[0000068505-23-000026:notes:161]
[same as prior period, unchanged from 0000068505-22-000031:notes:178]

[0000068505-23-000026:notes:162]
[same as prior period, unchanged from 0000068505-22-000031:notes:179]

[0000068505-23-000026:notes:163]
|  | April 1, 2023 |  | December 31, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,096 |  |  | $ | 380 |  |  | $ | 1,083 |  |  | $ | 358 |  |
| Customer-related | 1,536 |  |  | 982 |  |  | 1,519 |  |  | 935 |  |
| Other intangibles | 100 |  |  | 68 |  |  | 99 |  |  | 66 |  |
|  | $ | 2,732 |  |  | $ | 1,430 |  |  | $ | 2,701 |  |  | $ | 1,359 |  |

[0000068505-23-000026:notes:164]
Amortization expense on intangible assets was $55 million for the three months ended April 1, 2023. Amortization expense on intangible assets was $66 million for the three months ended April 2, 2022. As of April 1, 2023, annual amortization expense is estimated to be $176 million in 2023, $138 million in 2024, $126 million in 2025, $117 million in 2026, $107 million in 2027 and $107 million in 2028.

[0000068505-23-000026:notes:165]
[same as prior period, unchanged from 0000068505-22-000031:notes:182]

[0000068505-23-000026:notes:166]
|  | April 1, 2023 |  | December 31, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 913 |  |  | $ | 281 |  |  | $ | 913 |  |  | $ | 261 |  |
| Software and Services | 1,819 |  |  | 1,149 |  |  | 1,788 |  |  | 1,098 |  |
|  | $ | 2,732 |  |  | $ | 1,430 |  |  | $ | 2,701 |  |  | $ | 1,359 |  |

[0000068505-23-000026:notes:167]
[same as prior period, unchanged from 0000068505-22-000031:notes:184]

[0000068505-23-000026:notes:168]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2023 to April 1, 2023:

[0000068505-23-000026:notes:169]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2023 | $ | 1,461 |  |  | $ | 1,851 |  |  | $ | 3,312 |  |
| Goodwill acquired | — |  |  | — |  |  | — |  |
| Purchase accounting adjustments | (1) |  |  | (27) |  |  | (28) |  |
| Foreign currency | — |  |  | 3 |  |  | 3 |  |
| Balance as of April 1, 2023 | $ | 1,460 |  |  | $ | 1,827 |  |  | $ | 3,287 |  |


## us-gaap:SubsequentEventsTextBlock

[0000068505-23-000026:notes:170]
Subsequent EventsIn October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, the Company's private mobile radio communications network that the Company acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain.Subsequent to the quarter, the CMA issued its final decision which states it intends to impose a prospective price control on Airwave. As a result of the issuance of a final decision from the CMA subsequent to quarter close on April 1, 2023, the Company tested the Airwave asset group for impairment, noting the assets are expected to be recoverable
