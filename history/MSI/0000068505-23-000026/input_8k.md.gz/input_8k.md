# MSI 8-K — 0000068505-23-000025 filed 2023-05-04

## item codes, every 8-K on or before 2023-05-04

- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2023-05-04

- none on or before 2023-05-04

## item 2.02 — earnings release, exhibit 99.1

[0000068505-23-000025:8k_2_02:1]
EX-99.1
2
msiq12023pressrelease.htm
EX-99.1

[0000068505-23-000025:8k_2_02:2]
Document

[0000068505-23-000025:8k_2_02:3]
Exhibit 99.1

[0000068505-23-000025:8k_2_02:4]
Motorola Solutions Reports First Quarter 2023 Financial Results

[0000068505-23-000025:8k_2_02:5]
Company raises full-year revenue and earnings outlook driven by record Q1 orders and backlog

[0000068505-23-000025:8k_2_02:6]
•Sales of $2.2 billion, up 15% versus a year ago

[0000068505-23-000025:8k_2_02:7]
◦Products and Systems Integration sales up 18%

[0000068505-23-000025:8k_2_02:8]
◦Software and Services sales up 10%

[0000068505-23-000025:8k_2_02:9]
•GAAP earnings per share (EPS) of $1.61, up 5% versus a year ago

[0000068505-23-000025:8k_2_02:10]
•Non-GAAP EPS* of $2.22, up 31% versus a year ago

[0000068505-23-000025:8k_2_02:11]
•Record Q1 ending backlog of $14.1 billion, up 5% versus a year ago

[0000068505-23-000025:8k_2_02:12]
•Awarded $340 million ten-year IDIQ contract from U.S. Air Force to provide LMR services

[0000068505-23-000025:8k_2_02:13]
CHICAGO – May 4, 2023 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2023.

[0000068505-23-000025:8k_2_02:14]
“Q1 was an exceptional quarter, highlighted by double-digit revenue growth across both segments and all three technologies,” said Greg Brown, chairman and CEO, Motorola Solutions. “Record first-quarter sales, orders and ending backlog positions us very well for continued growth. As a result, we’re raising our revenue and earnings guidance for the full year.”

[0000068505-23-000025:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-23-000025:8k_2_02:16]
|  | Q1 2023 |  | Q1 2022 | % Change |
| Sales | $2,171 |  | $1,892 | 15 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $399 |  | $239 | 67 | % |
| % of Sales | 18.4 | % |  | 12.6 | % |  |
| EPS | $1.61 |  | $1.54 | 5 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $532 |  | $374 | 42 | % |
| % of Sales | 24.5 | % |  | 19.8 | % |  |
| EPS | $2.22 |  | $1.70 | 31 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,303 |  | $1,103 | 18 | % |
| GAAP Operating Earnings | $176 |  | $39 | 351 | % |
| % of Sales | 13.5 | % |  | 3.5 | % |  |
| Non-GAAP Operating Earnings* | $246 |  | $96 | 156 | % |
| % of Sales | 18.9 | % |  | 8.7 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $868 |  | $789 | 10 | % |
| GAAP Operating Earnings | $223 |  | $200 | 12 | % |
| % of Sales | 25.7 | % |  | 25.3 | % |  |
| Non-GAAP Operating Earnings* | $286 |  | $278 | 3 | % |
| % of Sales | 32.9 | % |  | 35.2 | % |  |

[0000068505-23-000025:8k_2_02:17]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.61 per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-23-000025:8k_2_02:18]
1

[0000068505-23-000025:8k_2_02:19]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-23-000025:8k_2_02:20]
•Revenue - Sales were $2.2 billion, up 15% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $42 million and currency headwinds were $45 million in the quarter. The Products and Systems Integration segment grew 18%, driven by growth in Land Mobile Radio Communications ("LMR") and Video Security and Access Control ("Video"). The Software and Services segment grew 10%, driven by growth in LMR services, Command Center and Video.

[0000068505-23-000025:8k_2_02:21]
•Operating margin - GAAP operating margin was 18.4% of sales, up from 12.6% in the year-ago quarter and Non-GAAP operating margin was 24.5% of sales, up 470 basis points from 19.8% in the year-ago quarter.  The increase in both GAAP and Non-GAAP operating margin was driven by higher sales, lower direct material costs and improved operating leverage.

[0000068505-23-000025:8k_2_02:22]
•Taxes - The GAAP effective tax rate was 22.1%, up from (22.4)% in the year-ago quarter, primarily due to a discrete deferred tax benefit as a result of the taxable reorganization of intellectual property in the year-ago quarter. The non-GAAP effective tax rate was 21.9%, up from 15.2% in the year-ago quarter, primarily driven by lower benefits from stock-based compensation recognized in the current year.

[0000068505-23-000025:8k_2_02:23]
•Cash flow - Operating cash flow was a usage of $8 million, compared to $152 million of operating cash flow generated in the year-ago quarter and free cash flow was a usage of $62M, compared to $98 million of free cash flow generated in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter decreased primarily due to an increase in working capital and higher cash taxes, partially offset by higher earnings, net of non-cash charges.

[0000068505-23-000025:8k_2_02:24]
•Capital allocation - During the quarter, the company paid $148 million in cash dividends, repurchased $140 million of shares and incurred $54 million of capital expenditures.

[0000068505-23-000025:8k_2_02:25]
•Backlog - The company ended the quarter with record Q1 backlog of $14.1 billion, up 5% or $623 million from the year-ago quarter, inclusive of $372 million of unfavorable currency rates. Products and Systems Integration segment backlog was up $601 million, or 15%. The growth was primarily driven by strong LMR demand. Software and Services segment backlog was up $22 million, driven by an increase in multi-year software and services contracts in North America, partially offset by revenue recognition for the Airwave contract, $329 million of unfavorable currency rates and a reduction related to the exit from the ESN contract.

[0000068505-23-000025:8k_2_02:26]
2

[0000068505-23-000025:8k_2_02:27]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-23-000025:8k_2_02:28]
Software and Services

[0000068505-23-000025:8k_2_02:29]
•$340M ten-year IDIQ award from the U.S. Air Force to provide LMR services

[0000068505-23-000025:8k_2_02:30]
•$21M multi-year support services extension of Portugal's nationwide TETRA system

[0000068505-23-000025:8k_2_02:31]
•$10M LMR services agreement with a federal agency

[0000068505-23-000025:8k_2_02:32]
•$9M Fixed Video services contract renewal with the City of Chicago

[0000068505-23-000025:8k_2_02:33]
Products and Systems Integration

[0000068505-23-000025:8k_2_02:34]
•$27M countywide P25 system for Johnson County, MO

[0000068505-23-000025:8k_2_02:35]
•$20M P25 device order for a U.S. state and local customer

[0000068505-23-000025:8k_2_02:36]
•$17M P25 system for Wakulla County, FL

[0000068505-23-000025:8k_2_02:37]
•$16M Fixed Video contract for a healthcare customer

[0000068505-23-000025:8k_2_02:38]
•$15M APX and APX NEXT devices order for the Kansas Highway Patrol

[0000068505-23-000025:8k_2_02:39]
BUSINESS OUTLOOK

[0000068505-23-000025:8k_2_02:40]
•Second quarter 2023 - The company expects revenue growth between 10% and 11%, compared to the second quarter of 2022. The company expects non-GAAP EPS in the range of $2.49 to $2.54 per share. This assumes approximately 173 million fully diluted shares and a non-GAAP effective tax rate of approximately 24%.

[0000068505-23-000025:8k_2_02:41]
•Full-year 2023 - The company now expects revenue in the range of $9.725 billion to $9.775 billion, up from its prior guidance of $9.65 billion to $9.7 billion, and non-GAAP EPS of between $11.21 and $11.29 per share, up from its prior guidance of between $11.10 and $11.22 per share. This outlook assumes approximately $25 million in foreign exchange headwinds, approximately 172 million fully diluted shares and a non-GAAP effective tax rate between 23% and 24%.

[0000068505-23-000025:8k_2_02:42]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-23-000025:8k_2_02:43]
RECENT EVENTS

[0000068505-23-000025:8k_2_02:44]
CMA UPDATE

[0000068505-23-000025:8k_2_02:45]
In October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, the company's private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain.

[0000068505-23-000025:8k_2_02:46]
Subsequent to the quarter, the CMA issued its final decision which states it intends to impose a prospective price control on Airwave. The company strongly disagrees with the CMA’s final decision and intends to appeal; the appeal process is expected to extend throughout 2023. Any price control remedies ultimately imposed under the final decision issued by the CMA are expected to go into effect after a remedies order review and consultation period and following the completion of the appeal process with the U.K.'s Competition Appeal Tribunal ("CAT"). The remedies implementation could potentially be further suspended if the appeal process extends beyond the CAT.

[0000068505-23-000025:8k_2_02:47]
3

[0000068505-23-000025:8k_2_02:48]
MACROECONOMIC EVENTS

[0000068505-23-000025:8k_2_02:49]
During the first quarter of 2023, the company continued to operate under challenging market conditions, influenced by the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to materials in the semiconductor market. Over the last several quarters, the company has navigated disruptions in its supply chain, in particular challenges in procuring certain semiconductor components, diminished transportation capacity and labor constraints. The company anticipates inflationary pressures and increased material and supply chain costs and disruptions (including elevated costs to procure materials within the semiconductor market) to continue throughout 2023. The company is closely monitoring supply chain disruptions and continues to remain focused on improving its supplier network, engineering alternative designs and working to reduce supply shortages. In addition, the company continues to actively manage its inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to its customers, which includes making changes that diversify the footprint of its supply chain operations. The company expects to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-23-000025:8k_2_02:50]
In order to combat rising inflation in the U.S., the Federal Reserve has raised interest rates multiple times since the beginning of 2022. The increase in U.S. dollar interest rates and overall market conditions led to significant U.S. dollar strengthening in 2022. The company has seen a reversal of a portion of U.S. dollar strengthening from the peak but the outlook for the remainder of the year remains uncertain. The company has cash flows denominated in foreign currencies where the fluctuations in the value of the U.S. dollar impact its earnings and cash flow.

[0000068505-23-000025:8k_2_02:51]
Although the macroeconomic environment challenges continued in the first quarter of 2023, the company is encouraged by customer demand for its products and services. Specifically, in the Software and Services segment, with the largely recurring nature of the business and the strong backlog position, the company continues to expect that the impact to operating margin will be limited throughout 2023. While the company is encouraged by strong backlog and growth in its Products and Systems Integration segment in the first quarter of 2023, which the company expects to continue to grow throughout 2023, supply constraints continue to impact the business and the company expects demand for its products will continue to outpace its ability to obtain semiconductor component supply. Where appropriate, the company has taken pricing actions around its product and service offerings to mitigate its exposure to inflationary pressures on its businesses and benefited from these adjustments during the first quarter of 2023. The company expects to further benefit from such adjustments in 2023. Further, demand continues to be supported with ongoing sources of government funding, including the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus. The company experienced the positive impact of the ARPA funding on its business and results of operations in 2022 and anticipates that the ARPA will continue to have a positive impact on its business throughout 2023.

[0000068505-23-000025:8k_2_02:52]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, May 4. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-23-000025:8k_2_02:53]
4

[0000068505-23-000025:8k_2_02:54]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-23-000025:8k_2_02:55]
A comparison of results from operations is as follows:

[0000068505-23-000025:8k_2_02:56]
|  | Q1 2023 | Q1 2022 |
| Net sales | $2,171 | $1,892 |
| Gross margin | $1,046 | $857 |
| Operating earnings | $399 | $239 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $278 | $267 |
| Diluted EPS | $1.61 | $1.54 |
| Weighted average diluted common shares outstanding | 172.6 |  | 173.1 |  |

[0000068505-23-000025:8k_2_02:57]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-23-000025:8k_2_02:58]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-23-000025:8k_2_02:59]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-23-000025:8k_2_02:60]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-23-000025:8k_2_02:61]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-23-000025:8k_2_02:62]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-23-000025:8k_2_02:63]
5

[0000068505-23-000025:8k_2_02:64]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-23-000025:8k_2_02:65]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-23-000025:8k_2_02:66]
On December 17, 2020, the Court held that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets, and.  on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court’s previous July 5, 2022 royalty order. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment in July. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023 and April 25, 2023, into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow.

[0000068505-23-000025:8k_2_02:67]
On August 2, 2022,  Hytera appealed the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals").The company filed its cross-appeal on August 5, 2022. On November 15, 2022, Hytera filed its appellate court brief in the Court of Appeals. The Company filed its response brief with the appellate court on February 13, 2023. Hytera’s reply brief is due May 1, 2023.

[0000068505-23-000025:8k_2_02:68]
Separate from the company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including $13 million to the company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gain was recorded to Other charges (income).

[0000068505-23-000025:8k_2_02:69]
6

[0000068505-23-000025:8k_2_02:70]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $13 million of proceeds realized in Q1 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-23-000025:8k_2_02:71]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-23-000025:8k_2_02:72]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-23-000025:8k_2_02:73]
7

[0000068505-23-000025:8k_2_02:74]
FORWARD LOOKING STATEMENTS

[0000068505-23-000025:8k_2_02:75]
8

[0000068505-23-000025:8k_2_02:76]
ABOUT MOTOROLA SOLUTIONS

[0000068505-23-000025:8k_2_02:77]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio communications, video security and access control and command center, bolstered by managed & support services, create an integrated technology ecosystem to help make communities safer and businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-23-000025:8k_2_02:78]
MEDIA CONTACT

[0000068505-23-000025:8k_2_02:79]
Alexandra Reynolds

[0000068505-23-000025:8k_2_02:80]
Motorola Solutions

[0000068505-23-000025:8k_2_02:81]
+1 312-965-3968

[0000068505-23-000025:8k_2_02:82]
alexandra.reynolds@motorolasolutions.com

[0000068505-23-000025:8k_2_02:83]
INVESTOR CONTACT

[0000068505-23-000025:8k_2_02:84]
Tim Yocum

[0000068505-23-000025:8k_2_02:85]
Motorola Solutions

[0000068505-23-000025:8k_2_02:86]
+1 847-576-6899

[0000068505-23-000025:8k_2_02:87]
Tim.Yocum@motorolasolutions.com

[0000068505-23-000025:8k_2_02:88]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2023 Motorola Solutions, Inc. All rights reserved.

[0000068505-23-000025:8k_2_02:89]
9

[0000068505-23-000025:8k_2_02:90]
GAAP-1

[0000068505-23-000025:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:92]
Condensed Consolidated Statements of Operations

[0000068505-23-000025:8k_2_02:93]
(In millions, except per share amounts)

[0000068505-23-000025:8k_2_02:94]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| Net sales from products | $ | 1,224 |  |  | $ | 1,046 |  |
| Net sales from services | 947 |  |  | 846 |  |
| Net sales | 2,171 |  |  | 1,892 |  |
| Costs of products sales | 576 |  |  | 548 |  |
| Costs of services sales | 549 |  |  | 487 |  |
| Costs of sales | 1,125 |  |  | 1,035 |  |
| Gross margin | 1,046 |  |  | 857 |  |
| Selling, general and administrative expenses | 368 |  |  | 338 |  |
| Research and development expenditures | 210 |  |  | 188 |  |
| Other charges | 14 |  |  | 26 |  |
| Intangibles amortization | 55 |  |  | 66 |  |
| Operating earnings | 399 |  |  | 239 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (54) |  |  | (56) |  |
| Gain on sales of investments and businesses, net | 1 |  |  | 2 |  |
| Other, net | 12 |  |  | 34 |  |
| Total other expense | (41) |  |  | (20) |  |
| Net earnings before income taxes | 358 |  |  | 219 |  |
| Income tax expense (benefit) | 79 |  |  | (49) |  |
| Net earnings | 279 |  |  | 268 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 278 |  |  | $ | 267 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.66 |  |  | $ | 1.59 |  |
| Diluted | $ | 1.61 |  |  | $ | 1.54 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.4 |  |  | 168.0 |  |
| Diluted | 172.6 |  |  | 173.1 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 56.4 | % |  | 55.3 | % |
| Net sales from services | 43.6 | % |  | 44.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.1 | % |  | 52.4 | % |
| Costs of services sales | 58.0 | % |  | 57.6 | % |
| Costs of sales | 51.8 | % |  | 54.7 | % |
| Gross margin | 48.2 | % |  | 45.3 | % |
| Selling, general and administrative expenses | 17.0 | % |  | 17.9 | % |
| Research and development expenditures | 9.7 | % |  | 9.9 | % |
| Other charges | 0.6 | % |  | 1.4 | % |
| Intangibles amortization | 2.5 | % |  | 3.5 | % |
| Operating earnings | 18.4 | % |  | 12.6 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.5) | % |  | (3.0) | % |
| Gain on sales of investments and businesses, net | — | % |  | 0.1 | % |
| Other, net | 0.6 | % |  | 1.8 | % |
| Total other expense | (1.9) | % |  | (1.1) | % |
| Net earnings before income taxes | 16.5 | % |  | 11.6 | % |
| Income tax expense (benefit) | 3.6 | % |  | (2.6) | % |
| Net earnings | 12.9 | % |  | 14.2 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 12.8 | % |  | 14.1 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-23-000025:8k_2_02:95]
10

[0000068505-23-000025:8k_2_02:96]
GAAP-2

[0000068505-23-000025:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:98]
Condensed Consolidated Balance Sheets

[0000068505-23-000025:8k_2_02:99]
(In millions)

[0000068505-23-000025:8k_2_02:100]
|  | April 1, 2023 |  | December 31, 2022 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,022 |  |  | $ | 1,325 |  |
| Accounts receivable, net | 1,340 |  |  | 1,518 |  |
| Contract assets | 1,024 |  |  | 974 |  |
| Inventories, net | 1,082 |  |  | 1,055 |  |
| Other current assets | 358 |  |  | 383 |  |
| Total current assets | 4,826 |  |  | 5,255 |  |
| Property, plant and equipment, net | 927 |  |  | 927 |  |
| Operating lease assets | 472 |  |  | 485 |  |
| Investments | 144 |  |  | 147 |  |
| Deferred income taxes | 1,073 |  |  | 1,036 |  |
| Goodwill | 3,287 |  |  | 3,312 |  |
| Intangible assets, net | 1,302 |  |  | 1,342 |  |
| Other assets | 322 |  |  | 310 |  |
| Total assets | $ | 12,353 |  |  | $ | 12,814 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | 1 |  |  | $ | 1 |  |
| Accounts payable | 719 |  |  | 1,062 |  |
| Contract liabilities | 1,793 |  |  | 1,859 |  |
| Accrued liabilities | 1,453 |  |  | 1,638 |  |
| Total current liabilities | 3,966 |  |  | 4,560 |  |
| Long-term debt | 6,014 |  |  | 6,013 |  |
| Operating lease liabilities | 398 |  |  | 419 |  |
| Other liabilities | 1,726 |  |  | 1,691 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 234 |  |  | 116 |  |
| Non-controlling interests | 15 |  |  | 15 |  |
| Total liabilities and stockholders’ equity | $ | 12,353 |  |  | $ | 12,814 |  |

[0000068505-23-000025:8k_2_02:101]
11

[0000068505-23-000025:8k_2_02:102]
GAAP-3

[0000068505-23-000025:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:104]
Condensed Consolidated Statements of Cash Flows

[0000068505-23-000025:8k_2_02:105]
(In millions)

[0000068505-23-000025:8k_2_02:106]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| Operating |  |  |  |
| Net earnings | $ | 279 |  |  | $ | 268 |  |
| Adjustments to reconcile Net earnings to Net cash provided by (used for) operating activities: |  |  |  |
| Depreciation and amortization | 98 |  |  | 111 |  |
| Non-cash other charges | 7 |  |  | 2 |  |
| Share-based compensation expenses | 55 |  |  | 37 |  |
| Gain on sales of investments and businesses, net | (1) |  |  | (2) |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 179 |  |  | 248 |  |
| Inventories | (26) |  |  | (162) |  |
| Other current assets and contract assets | (40) |  |  | 47 |  |
| Accounts payable, accrued liabilities and contract liabilities | (536) |  |  | (188) |  |
| Other assets and liabilities | (5) |  |  | (30) |  |
| Deferred income taxes | (18) |  |  | (179) |  |
| Net cash provided by (used for) operating activities | (8) |  |  | 152 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (4) |  |  | (512) |  |
| Proceeds from sales of investments and businesses, net | 5 |  |  | 9 |  |
| Capital expenditures | (54) |  |  | (54) |  |
| Net cash used for investing activities | (53) |  |  | (557) |  |
| Financing |  |  |  |
| Repayments of debt | — |  |  | (2) |  |
| Issuances of common stock | 26 |  |  | 52 |  |
| Purchases of common stock | (140) |  |  | (493) |  |
| Payments of dividends | (148) |  |  | (134) |  |
| Payments of dividends to non-controlling interests | (1) |  |  | — |  |
| Net cash used for financing activities | (263) |  |  | (577) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 21 |  |  | (14) |  |
| Net decrease in total cash and cash equivalents | (303) |  |  | (996) |  |
| Cash and cash equivalents, beginning of period | 1,325 |  |  | 1,874 |  |
| Cash and cash equivalents, end of period | $ | 1,022 |  |  | $ | 878 |  |

[0000068505-23-000025:8k_2_02:107]
12

[0000068505-23-000025:8k_2_02:108]
Non-GAAP-1

[0000068505-23-000025:8k_2_02:109]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:110]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-23-000025:8k_2_02:111]
(In millions)

[0000068505-23-000025:8k_2_02:112]
|  |  | Three Months Ended |  |  |  |  |  |  |
|  |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used for) operating activities |  | $ | (8) |  |  | $ | 152 |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (54) |  |  | (54) |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow |  | $ | (62) |  |  | $ | 98 |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000025:8k_2_02:113]
13

[0000068505-23-000025:8k_2_02:114]
Non-GAAP-2

[0000068505-23-000025:8k_2_02:115]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:116]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-23-000025:8k_2_02:117]
(In millions)

[0000068505-23-000025:8k_2_02:118]
|  |  |  |  | Three Months Ended |  |  |  |  |  |
|  |  | Statement Line |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 278 |  |  | $ | 267 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 55 |  |  | $ | 66 |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 55 |  |  | 37 |  |  |  |  |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 13 |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | 6 |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 3 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 3 |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 2 |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | 2 |  |  | 3 |  |  |  |  |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (Income) |  | — |  |  | 11 |  |  |  |  |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | — |  |  | (2) |  |  |  |  |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | (13) |  |  |  |  |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | (21) |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (1) |  |  | (2) |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (3) |  |  | 18 |  |  |  |  |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 135 |  |  | $ | 129 |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 29 |  | 102 |  |  |  |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 106 |  | 27 |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 384 |  |  | $ | 294 |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000025:8k_2_02:119]
Calculation of Non-GAAP Tax Rate

[0000068505-23-000025:8k_2_02:120]
(In millions)

[0000068505-23-000025:8k_2_02:121]
|  |  | Three Months Ended |  |  |  |  |  |
|  |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |  |  |  |  |  |  |
| Net earnings before income taxes |  | $ | 358 |  |  | $ | 219 |  |  |  |  |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 135 |  |  | 129 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 493 |  |  | 348 |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) |  | 79 |  |  | (49) |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 29 |  |  | 102 |  |  |  |  |  |  |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | 108 |  |  | 53 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Tax rate |  | 21.9 | % |  | 15.2 | % |  |  |  |  |  |  |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |  |  |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000025:8k_2_02:122]
14

[0000068505-23-000025:8k_2_02:123]
Non-GAAP-2

[0000068505-23-000025:8k_2_02:124]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-23-000025:8k_2_02:125]
|  |  |  |  | Three Months Ended |  |  |  |  |  |
|  |  | Statement Line |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 1.61 |  |  | $ | 1.54 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 0.32 |  |  | $ | 0.38 |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 0.32 |  |  | 0.21 |  |  |  |  |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.08 |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | 0.03 |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.02 |  |  | 0.05 |  |  |  |  |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.02 |  |  | 0.01 |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.01 |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | 0.01 |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (Income) |  | — |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | — |  |  | (0.01) |  |  |  |  |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | — |  |  | (0.07) |  |  |  |  |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | (0.12) |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (0.01) |  |  | (0.01) |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (0.02) |  |  | 0.10 |  |  |  |  |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.78 |  |  | $ | 0.75 |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.17 |  | 0.59 |  |  |  |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.61 |  | 0.16 |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 2.22 |  |  | $ | 1.70 |  |  |  |  |  |  |  |  |  |  |  |
| Diluted Weighted Average Common Shares |  |  |  | 172.6 |  |  | 173.1 |  |  |  |  |  |  |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000025:8k_2_02:126]
15

[0000068505-23-000025:8k_2_02:127]
Non-GAAP-3

[0000068505-23-000025:8k_2_02:128]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:129]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-23-000025:8k_2_02:130]
(In millions)

[0000068505-23-000025:8k_2_02:131]
|  |  | Three Months Ended |
|  |  | April 1, 2023 |  | April 2, 2022 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Operating earnings ("OE") |  | $ | 176 |  |  | $ | 223 |  |  | $ | 399 |  |  | $ | 39 |  |  | $ | 200 |  |  | $ | 239 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 13 |  |  | 42 |  |  | 55 |  |  | 15 |  |  | 51 |  |  | 66 |  |
| Share-based compensation expenses |  | 40 |  |  | 15 |  |  | 55 |  |  | 27 |  |  | 10 |  |  | 37 |  |
| Reorganization of business charges |  | 11 |  |  | 2 |  |  | 13 |  |  | 8 |  |  | 2 |  |  | 10 |  |
| Operating lease asset impairments |  | 2 |  |  | 1 |  |  | 3 |  |  | 9 |  |  | — |  |  | 9 |  |
| Hytera-related legal expenses |  | 3 |  |  | — |  |  | 3 |  |  | 2 |  |  | — |  |  | 2 |  |
| Acquisition-related transaction fees |  | — |  |  | 2 |  |  | 2 |  |  | 6 |  |  | 4 |  |  | 10 |  |
| Fixed asset impairments |  | 1 |  |  | 1 |  |  | 2 |  |  | 3 |  |  | — |  |  | 3 |  |
| Legal settlements |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | 11 |  |
| Gain on Hytera legal settlement |  | — |  |  | — |  |  | — |  |  | (13) |  |  | — |  |  | (13) |  |
| Total above-OE non-GAAP adjustments |  | 70 |  |  | 63 |  |  | 133 |  |  | 57 |  |  | 78 |  |  | 135 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 246 |  |  | $ | 286 |  |  | $ | 532 |  |  | $ | 96 |  |  | $ | 278 |  |  | $ | 374 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 13.5 | % |  | 25.7 | % |  | 18.4 | % |  | 3.5 | % |  | 25.3 | % |  | 12.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 18.9 | % |  | 32.9 | % |  | 24.5 | % |  | 8.7 | % |  | 35.2 | % |  | 19.8 | % |

[0000068505-23-000025:8k_2_02:132]
16

[0000068505-23-000025:8k_2_02:133]
Non-GAAP-4

[0000068505-23-000025:8k_2_02:134]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000025:8k_2_02:135]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-23-000025:8k_2_02:136]
(In millions)

[0000068505-23-000025:8k_2_02:137]
|  |  | Three Months Ended |  |  |
|  |  | April 1, 2023 |  | April 2, 2022 |  | % Change |
| Net sales |  | $ | 2,171 |  |  | $ | 1,892 |  |  | 15 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 44 |  |  | 2 |  |  |  |
| Organic revenue |  | $ | 2,127 |  |  | $ | 1,890 |  |  | 13 | % |
