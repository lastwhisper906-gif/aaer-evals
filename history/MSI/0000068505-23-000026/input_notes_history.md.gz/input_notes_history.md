# MSI note change history — 0000068505-22-000031 → 0000068505-23-000026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-05-04):
[0000068505-23-000026:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

- added (2023-05-04):
[0000068505-23-000026:note_history:2]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment in July. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023 and April 25, 2023, into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow.

- added (2023-05-04):
[0000068505-23-000026:note_history:3]
On August 2, 2022, Hytera appealed the Court's judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. On November 15, 2022, Hytera filed its appellate court brief in the Court of Appeals. The Company filed its response brief with the appellate court on February 13, 2023. Hytera’s reply brief is due May 1, 2023.

- changed (2023-05-04):
[0000068505-23-000026:note_history:4]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.
  (was, 2022-11-03, similarity 0.6502):
[0000068505-22-000031:note_history:4]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. The gain was recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.

- removed (2023-05-04):
[0000068505-22-000031:note_history:5]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment.

- removed (2023-05-04):
[0000068505-22-000031:note_history:6]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions.

- removed (2023-05-04):
[0000068505-22-000031:note_history:7]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Court of Appeals dismissed the notice of appeal on February 16, 2022 after determining that such appeal was premature. On August 2, 2022, after the Court denied the motions described above on July 5, 2022, Hytera filed a renewed notice of appeal in the Court of Appeals. The Company filed its cross-appeal on August 5, 2022.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-04):
[0000068505-23-000026:note_history:8]
Basis of Presentation
The condensed consolidated financial statements as of April 1, 2023 and for the three months ended April 1, 2023 and April 2, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2022-11-03, similarity 0.9284):
[0000068505-22-000031:note_history:8]
Basis of Presentation
The condensed consolidated financial statements as of October 1, 2022 and for the three and nine months ended October 1, 2022 and October 2, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2023-05-04):
[0000068505-23-000026:note_history:9]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three months ended April 1, 2023 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2022-11-03, similarity 0.9608):
[0000068505-22-000031:note_history:9]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three and nine months ended October 1, 2022 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2023-05-04):
[0000068505-23-000026:note_history:10]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center. In January 2023, we began using Command Center as a naming convention, eliminating the "Software" descriptor from Command Center Software in order to inform investors that the Company has software components more broadly across all technologies; this name change does not require any financial information to be reclassified from previous periods.
  (was, 2022-11-03, similarity 0.6409):
[0000068505-22-000031:note_history:10]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center Software.

- changed (2023-05-04):
[0000068505-23-000026:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence ("AI")-enabled analytics that enable visibility “on scene” and bring attention to what’s important.
  (was, 2022-11-03, similarity 0.9284):
[0000068505-22-000031:note_history:11]
•Video Security and Access Control: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

- changed (2023-05-04):
[0000068505-23-000026:note_history:12]
•Command Center: Software suite that enables collaboration and shares information throughout the public safety workflow from "911 call to case closure."
  (was, 2022-11-03, similarity 0.9177):
[0000068505-22-000031:note_history:12]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from "911 call to case closure."

- added (2023-05-04):
[0000068505-23-000026:note_history:13]
On December 14, 2022, the Company acquired Rave Mobile Safety, Inc. ("Rave Mobile"), a leader in mass notification and incident management, for $553 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The business is a part of the Software and Services segment.

- changed (2023-05-04):
[0000068505-23-000026:note_history:14]
On October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part the Products and Systems Integration segment.
  (was, 2022-11-03, similarity 0.9686):
[0000068505-22-000031:note_history:14]
Subsequent to quarter end, on October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part the Products and Systems Integration segment.

- changed (2023-05-04):
[0000068505-23-000026:note_history:15]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs" (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.
  (was, 2022-11-03, similarity 0.6917):
[0000068505-22-000031:note_history:15]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is continuing to evaluate the impact of the adoption of this ASU on its financial statements and disclosures.

- removed (2023-05-04):
[0000068505-22-000031:note_history:16]
On December 16, 2021, the Company acquired 911 Datamaster, Inc. ("911 Datamaster"), a Next Generation 911 ("NG911") data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces the Company's strategy to be a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The business is a part of the Software and Services segment.

- removed (2023-05-04):
[0000068505-22-000031:note_history:17]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- removed (2023-05-04):
[0000068505-22-000031:note_history:18]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- removed (2023-05-04):
[0000068505-22-000031:note_history:19]
Recent Accounting Pronouncements

- removed (2023-05-04):
[0000068505-22-000031:note_history:20]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the Senior Convertible Notes on diluted earnings per common share.

- removed (2023-05-04):
[0000068505-22-000031:note_history:21]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers," which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and

- removed (2023-05-04):
[0000068505-22-000031:note_history:22]
disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

- removed (2023-05-04):
[0000068505-22-000031:note_history:23]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-04):
[0000068505-23-000026:note_history:24]
Debt and Credit Facilities
As of April 1, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 1, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.
  (was, 2022-11-03, similarity 0.6974):
[0000068505-22-000031:note_history:24]
As of October 1, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 1, 2022.

- changed (2023-05-04):
[0000068505-23-000026:note_history:25]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 1, 2023 the Company had no outstanding debt under the commercial paper program.
  (was, 2022-11-03, similarity 0.9912):
[0000068505-22-000031:note_history:25]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of October 1, 2022 the Company had no outstanding debt under the commercial paper program.

- removed (2023-05-04):
[0000068505-22-000031:note_history:26]
Debt and Credit Facilities

- removed (2023-05-04):
[0000068505-22-000031:note_history:27]
|  | October 1, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 694 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 1 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (1) |  |  | (5) |  |
| Long-term debt | $ | 6,012 |  |  | $ | 5,688 |  |

- removed (2023-05-04):
[0000068505-22-000031:note_history:28]
On May 31, 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the Company's 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-04):
[0000068505-22-000031:note_history:29]
|  | October 1, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 694 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 1 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (1) |  |  | (5) |  |
| Long-term debt | $ | 6,012 |  |  | $ | 5,688 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-04):
[0000068505-23-000026:note_history:30]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 1, 2023 and April 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2022-11-03, similarity 0.9193):
[0000068505-22-000031:note_history:30]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 1, 2022 and October 2, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2023-05-04):
[0000068505-23-000026:note_history:31]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |  | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |
| International | 353 |  |  | 326 |  |  | 679 |  |  | 272 |  |  | 315 |  |  | 587 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |  | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |
| Video | 223 |  |  | 136 |  |  | 359 |  |  | 194 |  |  | 113 |  |  | 307 |  |
| Command Center | — |  |  | 155 |  |  | 155 |  |  | — |  |  | 130 |  |  | 130 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |  | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |
| Indirect | 580 |  |  | 73 |  |  | 653 |  |  | 447 |  |  | 87 |  |  | 534 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
  (was, 2022-11-03, similarity 0.964):
[0000068505-22-000031:note_history:31]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |  | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |
| International | 363 |  |  | 323 |  |  | 686 |  |  | 333 |  |  | 325 |  |  | 658 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |  | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |
| Video Security and Access Control | 286 |  |  | 133 |  |  | 419 |  |  | 214 |  |  | 102 |  |  | 316 |  |
| Command Center Software | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 133 |  |  | 133 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |  | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |
| Indirect | 627 |  |  | 75 |  |  | 702 |  |  | 487 |  |  | 79 |  |  | 566 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |

- added (2023-05-04):
[0000068505-23-000026:note_history:32]
|  | Three Months Ended |

- removed (2023-05-04):
[0000068505-22-000031:note_history:33]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |  | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |
| International | 957 |  |  | 973 |  |  | 1,930 |  |  | 935 |  |  | 970 |  |  | 1,905 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |  | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |
| Video Security and Access Control | 728 |  |  | 368 |  |  | 1,096 |  |  | 590 |  |  | 284 |  |  | 874 |  |
| Command Center Software | — |  |  | 435 |  |  | 435 |  |  | — |  |  | 387 |  |  | 387 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |  | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |
| Indirect | 1,647 |  |  | 228 |  |  | 1,875 |  |  | 1,390 |  |  | 214 |  |  | 1,604 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-04):
[0000068505-23-000026:note_history:34]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 1, 2023 and April 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2022-11-03, similarity 0.9193):
[0000068505-22-000031:note_history:34]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 1, 2022 and October 2, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2023-05-04):
[0000068505-23-000026:note_history:35]
|  | Three Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |  | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |
| International | 353 |  |  | 326 |  |  | 679 |  |  | 272 |  |  | 315 |  |  | 587 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |  | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |
| Video | 223 |  |  | 136 |  |  | 359 |  |  | 194 |  |  | 113 |  |  | 307 |  |
| Command Center | — |  |  | 155 |  |  | 155 |  |  | — |  |  | 130 |  |  | 130 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |  | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |
| Indirect | 580 |  |  | 73 |  |  | 653 |  |  | 447 |  |  | 87 |  |  | 534 |  |
|  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |
  (was, 2022-11-03, similarity 0.964):
[0000068505-22-000031:note_history:35]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |  | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |
| International | 363 |  |  | 323 |  |  | 686 |  |  | 333 |  |  | 325 |  |  | 658 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |  | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |
| Video Security and Access Control | 286 |  |  | 133 |  |  | 419 |  |  | 214 |  |  | 102 |  |  | 316 |  |
| Command Center Software | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 133 |  |  | 133 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |  | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |
| Indirect | 627 |  |  | 75 |  |  | 702 |  |  | 487 |  |  | 79 |  |  | 566 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |

- added (2023-05-04):
[0000068505-23-000026:note_history:36]
|  | Three Months Ended |

- changed (2023-05-04):
[0000068505-23-000026:note_history:37]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 1, 2023 was $9.2 billion. A total of $4.7 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of April 1, 2023, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.5 billion was from Software and Services performance obligations that were not yet
  (was, 2022-11-03, similarity 0.6703):
[0000068505-22-000031:note_history:37]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of October 1, 2022 was $9.1 billion. A total of $4.8 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of October 1, 2022, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.3 billion was from Software and Services performance obligations that were not yet satisfied as of October 1, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.4 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- added (2023-05-04):
[0000068505-23-000026:note_history:38]
satisfied as of April 1, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2023-05-04):
[0000068505-23-000026:note_history:39]
| (In millions) | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,340 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,024 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,793 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 378 |  |  | 363 |  |  |  |  |  |
  (was, 2022-11-03, similarity 0.9771):
[0000068505-22-000031:note_history:39]
| (In millions) | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,368 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 1,033 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,549 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 327 |  |  | 306 |  |  |  |  |  |

- added (2023-05-04):
[0000068505-23-000026:note_history:40]
Revenue recognized during the three months ended April 1, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $474 million, compared to $456 million of revenue recognized during the three months ended April 2, 2022 which was previously included in Contract liabilities as of December 31, 2021. Revenue of $10 million was reversed during the three months ended April 1, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $17 million of reversals for the three months ended April 2, 2022.

- changed (2023-05-04):
[0000068505-23-000026:note_history:41]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 1, 2023 and April 2, 2022.
  (was, 2022-11-03, similarity 0.8301):
[0000068505-22-000031:note_history:41]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended October 1, 2022 and October 2, 2021.
Contract Cost Balances

- added (2023-05-04):
[0000068505-23-000026:note_history:42]
Contract Cost Balances

- changed (2023-05-04):
[0000068505-23-000026:note_history:43]
| (In millions) | April 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 119 |  |  | 130 |  |  |  |  |  |
  (was, 2022-11-03, similarity 0.9718):
[0000068505-22-000031:note_history:43]
| (In millions) | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 52 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 120 |  |  | 124 |  |  |  |  |  |

- added (2023-05-04):
[0000068505-23-000026:note_history:44]
Amortization of non-current contract cost assets was $17 million for both the three months ended April 1, 2023, and April 2, 2022.

- removed (2023-05-04):
[0000068505-22-000031:note_history:45]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |  | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |
| International | 957 |  |  | 973 |  |  | 1,930 |  |  | 935 |  |  | 970 |  |  | 1,905 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |  | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |
| Video Security and Access Control | 728 |  |  | 368 |  |  | 1,096 |  |  | 590 |  |  | 284 |  |  | 874 |  |
| Command Center Software | — |  |  | 435 |  |  | 435 |  |  | — |  |  | 387 |  |  | 387 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |  | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |
| Indirect | 1,647 |  |  | 228 |  |  | 1,875 |  |  | 1,390 |  |  | 214 |  |  | 1,604 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |

- removed (2023-05-04):
[0000068505-22-000031:note_history:46]
Revenue recognized during the three months ended October 1, 2022 which was previously included in Contract liabilities as of July 2, 2022 was $437 million, compared to $472 million of revenue recognized during the three months ended October 2, 2021 which was previously included in Contract liabilities as of July 3, 2021. Revenue recognized during the nine months ended October 1, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $939 million, compared to $946 million recognized during the nine months ended October 2, 2021 which was previously included in Contract liabilities as of December 31, 2020. The Company reversed $3 million of revenue during the three months ended October 1, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $2 million of reversals for the three months ended October 2, 2021, primarily driven by changes in the estimates of progress on system contracts. Revenue of $23 million was reversed during the nine months ended October 1, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the nine months ended October 2, 2021.

- removed (2023-05-04):
[0000068505-22-000031:note_history:47]
Amortization of non-current contract cost assets was $14 million and $41 million for the three and nine months ended October 1, 2022, respectively, and $12 million and $37 million for the three and nine months ended October 2, 2021, respectively


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-05-04):
[0000068505-23-000026:note_history:48]
Subsequent EventsIn October 2021, the United Kingdom’s Competition and Markets Authority (the "CMA") announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, the Company's private mobile radio communications network that the Company acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain.Subsequent to the quarter, the CMA issued its final decision which states it intends to impose a prospective price control on Airwave. As a result of the issuance of a final decision from the CMA subsequent to quarter close on April 1, 2023, the Company tested the Airwave asset group for impairment, noting the assets are expected to be recoverable
