# MSI note change history — 0000068505-23-000045 → 0000068505-24-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000068505-24-000016:note_history:1]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through April 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.
  (was, 2023-11-02, similarity 0.9953):
[0000068505-23-000045:note_history:1]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through October 2023. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

- added (2024-05-02):
[0000068505-24-000016:note_history:2]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera subsequently filed several notices to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), including a notice of appeal filed on August 2, 2022, which appealed the orders related to the jury's verdict as well as the Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on the parties' appeals on December 5, 2023.

- added (2024-05-02):
[0000068505-24-000016:note_history:3]
In the first quarter of 2024, the parties have been engaged in competing litigation in the Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. In March 2024, the Court ordered Hytera to take affirmative steps to withdraw its competing litigation. Hytera did not comply with the Court's order and, accordingly, the Court issued an order against Hytera for contempt sanctions on April 2, 2024, which included a worldwide sales injunction of all Hytera radio products. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the lower Court's various orders related to the contempt sanctions.

- removed (2024-05-02):
[0000068505-23-000045:note_history:4]
On August 2, 2022, Hytera appealed the Court's July 5, 2022 judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the Company's cross-appeal. The Court of Appeals set an oral argument date of December 5, 2023.

- removed (2024-05-02):
[0000068505-23-000045:note_history:5]
Hytera Bankruptcy Proceedings

- removed (2024-05-02):
[0000068505-23-000045:note_history:6]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000068505-24-000016:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of March 30, 2024 and for the three months ended March 30, 2024 and April 1, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2023-11-02, similarity 0.9333):
[0000068505-23-000045:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of September 30, 2023 and for the three and nine months ended September 30, 2023 and October 1, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2024-05-02):
[0000068505-24-000016:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three months ended March 30, 2024 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2023-11-02, similarity 0.9592):
[0000068505-23-000045:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three and nine months ended September 30, 2023 are not necessarily indicative of the operating results to be expected for the full year.

- added (2024-05-02):
[0000068505-24-000016:note_history:9]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services". Within these segments the Company has three principal product lines in which the Company reports net sales: Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center.

- changed (2024-05-02):
[0000068505-24-000016:note_history:10]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.
  (was, 2023-11-02, similarity 0.9901):
[0000068505-23-000045:note_history:10]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

- changed (2024-05-02):
[0000068505-24-000016:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.
  (was, 2023-11-02, similarity 0.9304):
[0000068505-23-000045:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence ("AI")-enabled analytics that enable visibility “on scene” and bring attention to what’s important.

- added (2024-05-02):
[0000068505-24-000016:note_history:12]
•Command Center: Command center solutions and software applications that unify voice, video and data analytics from public safety agencies, enterprises and the community to create a broad informational view to help simplify workflows and improve the accuracy and speed of decisions.

- added (2024-05-02):
[0000068505-24-000016:note_history:13]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

- added (2024-05-02):
[0000068505-24-000016:note_history:14]
On December 15, 2023, the Company acquired IPVideo Corporation ("IPVideo"), the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is a part of the Products and Systems Integration segment.

- changed (2024-05-02):
[0000068505-24-000016:note_history:15]
Recent Accounting Pronouncements
  (was, 2023-11-02, similarity 0.8649):
[0000068505-23-000045:note_history:15]
Recently Adopted Accounting Pronouncements

- added (2024-05-02):
[0000068505-24-000016:note_history:16]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The ASU is effective for fiscal years beginning after December 15, 2023, and interim periods beginning in 2025, with early adoption permitted. The ASU will require the Company to disclose additional expense categories at the segment level including Cost of sales, Selling, general and administrative expenses, Research and development expenditures and other charges once it adopts this ASU. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

- added (2024-05-02):
[0000068505-24-000016:note_history:17]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.

- removed (2024-05-02):
[0000068505-23-000045:note_history:18]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center.

- removed (2024-05-02):
[0000068505-23-000045:note_history:19]
•Command Center: Software suite that enables collaboration and shares information throughout the public safety workflow from "911 call to case closure."

- removed (2024-05-02):
[0000068505-23-000045:note_history:20]
On December 14, 2022, the Company acquired Rave Mobile Safety, Inc. ("Rave Mobile"), a leader in mass notification and incident management, for $553 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The business is a part of the Software and Services segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:21]
On October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part the Products and Systems Integration segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:22]
On August 8, 2022, the Company acquired Barrett Communications Pty Ltd ("Barrett Communications"), a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The business is a part of the Products and Systems Integration segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:23]
On May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of the Products and Systems Integration segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:24]
On April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:25]
On March 23, 2022, the Company acquired TETRA Ireland Communications Limited ("TETRA Ireland"), the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. The business is part of the Software and Services segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:26]
On March 3, 2022, the Company acquired Ava Security Limited ("Ava"), a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- removed (2024-05-02):
[0000068505-23-000045:note_history:27]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-02):
[0000068505-24-000016:note_history:28]
Debt and Credit Facilities

- added (2024-05-02):
[0000068505-24-000016:note_history:29]
|  | March 30, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 695 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior noted due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,308 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (313) |  |  | (1,313) |  |
| Long-term debt | $ | 5,994 |  |  | $ | 4,705 |  |

- added (2024-05-02):
[0000068505-24-000016:note_history:30]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the three months ended March 30, 2024.

- added (2024-05-02):
[0000068505-24-000016:note_history:31]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

- changed (2024-05-02):
[0000068505-24-000016:note_history:32]
As of March 30, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 30, 2024.
  (was, 2023-11-02, similarity 0.884):
[0000068505-23-000045:note_history:32]
As of September 30, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 30, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

- changed (2024-05-02):
[0000068505-24-000016:note_history:33]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 30, 2024 the Company had no outstanding debt under the commercial paper program.
  (was, 2023-11-02, similarity 0.9898):
[0000068505-23-000045:note_history:33]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 30, 2023 the Company had no outstanding debt under the commercial paper program.

- removed (2024-05-02):
[0000068505-23-000045:note_history:34]
Debt and Credit Facilities
As of September 30, 2023, $1.0 billion of Senior Convertible Notes and $313 million of 4.0% senior notes, which both mature in September 2024, were reclassified from Long-term debt to the Current portion of long-term debt statement line within the Company's Condensed Consolidated Balance Sheets, as the notes are due within the next twelve months.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2024-05-02):
[0000068505-24-000016:note_history:35]
|  | March 30, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 695 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior noted due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,308 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (313) |  |  | (1,313) |  |
| Long-term debt | $ | 5,994 |  |  | $ | 4,705 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000068505-24-000016:note_history:36]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 30, 2024 and April 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2023-11-02, similarity 0.9168):
[0000068505-23-000045:note_history:36]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 30, 2023 and October 1, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2024-05-02):
[0000068505-24-000016:note_history:37]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |  | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |
| International | 408 |  |  | 288 |  |  | 696 |  |  | 353 |  |  | 326 |  |  | 679 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |  | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |
| Video | 235 |  |  | 163 |  |  | 398 |  |  | 223 |  |  | 136 |  |  | 359 |  |
| Command Center | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 155 |  |  | 155 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |  | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |
| Indirect | 630 |  |  | 77 |  |  | 707 |  |  | 580 |  |  | 73 |  |  | 653 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
  (was, 2023-11-02, similarity 0.9805):
[0000068505-23-000045:note_history:37]
|  | Three Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |  | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |
| International | 457 |  |  | 316 |  |  | 773 |  |  | 363 |  |  | 323 |  |  | 686 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |  | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |
| Video | 300 |  |  | 153 |  |  | 453 |  |  | 286 |  |  | 133 |  |  | 419 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 142 |  |  | 142 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |  | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |
| Indirect | 672 |  |  | 85 |  |  | 757 |  |  | 627 |  |  | 75 |  |  | 702 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |

- removed (2024-05-02):
[0000068505-23-000045:note_history:38]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |  | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |
| International | 1,222 |  |  | 991 |  |  | 2,213 |  |  | 957 |  |  | 973 |  |  | 1,930 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |  | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |
| Video | 810 |  |  | 435 |  |  | 1,245 |  |  | 728 |  |  | 368 |  |  | 1,096 |  |
| Command Center | — |  |  | 535 |  |  | 535 |  |  | — |  |  | 435 |  |  | 435 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |  | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |
| Indirect | 1,893 |  |  | 248 |  |  | 2,141 |  |  | 1,647 |  |  | 228 |  |  | 1,875 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000068505-24-000016:note_history:39]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 30, 2024 and April 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2023-11-02, similarity 0.9168):
[0000068505-23-000045:note_history:39]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 30, 2023 and October 1, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2024-05-02):
[0000068505-24-000016:note_history:40]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |  | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |
| International | 408 |  |  | 288 |  |  | 696 |  |  | 353 |  |  | 326 |  |  | 679 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |  | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |
| Video | 235 |  |  | 163 |  |  | 398 |  |  | 223 |  |  | 136 |  |  | 359 |  |
| Command Center | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 155 |  |  | 155 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |  | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |
| Indirect | 630 |  |  | 77 |  |  | 707 |  |  | 580 |  |  | 73 |  |  | 653 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
  (was, 2023-11-02, similarity 0.9805):
[0000068505-23-000045:note_history:40]
|  | Three Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |  | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |
| International | 457 |  |  | 316 |  |  | 773 |  |  | 363 |  |  | 323 |  |  | 686 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |  | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |
| Video | 300 |  |  | 153 |  |  | 453 |  |  | 286 |  |  | 133 |  |  | 419 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 142 |  |  | 142 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |  | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |
| Indirect | 672 |  |  | 85 |  |  | 757 |  |  | 627 |  |  | 75 |  |  | 702 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |

- changed (2024-05-02):
[0000068505-24-000016:note_history:41]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of March 30, 2024 was $9.6 billion. A total of $4.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of March 30, 2024, of which $2.8 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.0 billion was from Software and Services performance obligations that were not yet satisfied as of March 30, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.7 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.
  (was, 2023-11-02, similarity 0.9885):
[0000068505-23-000045:note_history:41]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 30, 2023 was $9.3 billion. A total of $4.9 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 30, 2023, of which $3.1 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.4 billion was from Software and Services performance obligations that were not yet satisfied as of September 30, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- added (2024-05-02):
[0000068505-24-000016:note_history:42]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first quarter of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.

- added (2024-05-02):
[0000068505-24-000016:note_history:43]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a Contract asset or Contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

- changed (2024-05-02):
[0000068505-24-000016:note_history:44]
| (In millions) | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,592 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,127 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,890 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 430 |  |  | 424 |  |  |  |  |  |
  (was, 2023-11-02, similarity 0.9772):
[0000068505-23-000045:note_history:44]
| (In millions) | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,667 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,092 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,898 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 394 |  |  | 363 |  |  |  |  |  |

- added (2024-05-02):
[0000068505-24-000016:note_history:45]
Revenue recognized during the three months ended March 30, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $508 million, compared to $474 million of revenue recognized during the three months ended April 1, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $12 million was reversed during the three months ended March 30, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended April 1, 2023, primarily driven by changes in the estimates of progress on system contracts.

- changed (2024-05-02):
[0000068505-24-000016:note_history:46]
There were no material expected credit losses recorded on contract assets during each of the three months ended March 30, 2024 and April 1, 2023.
  (was, 2023-11-02, similarity 0.8982):
[0000068505-23-000045:note_history:46]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 30, 2023 and October 1, 2022.

- changed (2024-05-02):
[0000068505-24-000016:note_history:47]
| (In millions) | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 65 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 116 |  |  | 119 |  |  |  |  |  |
  (was, 2023-11-02, similarity 0.9719):
[0000068505-23-000045:note_history:47]
| (In millions) | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 89 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 109 |  |  | 130 |  |  |  |  |  |

- added (2024-05-02):
[0000068505-24-000016:note_history:48]
Amortization of contract cost assets was $13 million for the three months ended March 30, 2024 and $17 million for the three months ended April 1, 2023.

- removed (2024-05-02):
[0000068505-23-000045:note_history:49]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |  | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |
| International | 1,222 |  |  | 991 |  |  | 2,213 |  |  | 957 |  |  | 973 |  |  | 1,930 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |  | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |
| Video | 810 |  |  | 435 |  |  | 1,245 |  |  | 728 |  |  | 368 |  |  | 1,096 |  |
| Command Center | — |  |  | 535 |  |  | 535 |  |  | — |  |  | 435 |  |  | 435 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |  | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |
| Indirect | 1,893 |  |  | 248 |  |  | 2,141 |  |  | 1,647 |  |  | 228 |  |  | 1,875 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |

- removed (2024-05-02):
[0000068505-23-000045:note_history:50]
Revenue recognized during the three months ended September 30, 2023 which was previously included in Contract liabilities as of July 1, 2023 was $475 million, compared to $437 million of revenue recognized during the three months ended October 1, 2022 which was previously included in Contract liabilities as of July 2, 2022. Revenue recognized during the nine months ended September 30, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $1.1 billion, compared to $939 million recognized during the nine months ended October 1, 2022 which was previously included in Contract liabilities as of December 31, 2021. The Company did not reverse any revenue during the three months ended September 30, 2023 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $3 million of reversals for the three months ended October 1, 2022, primarily driven by changes in the estimates of progress on system contracts. Revenue of $18 million was reversed during the nine months ended September 30, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $23 million of reversals for the nine months ended October 1, 2022.

- removed (2024-05-02):
[0000068505-23-000045:note_history:51]
Amortization of contract cost assets was $10 million and $35 million for the three and nine months ended September 30, 2023, respectively, and $14 million and $41 million for the three and nine months ended October 1, 2022, respectively.
