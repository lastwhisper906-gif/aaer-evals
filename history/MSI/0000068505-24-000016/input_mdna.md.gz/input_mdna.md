# MSI MD&A — 0000068505-24-000016


## mdna

[0000068505-24-000016:mdna:1]
[same as prior period, unchanged from 0000068505-23-000045:mdna:1]

[0000068505-24-000016:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three months ended March 30, 2024 and April 1, 2023, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2023 (the "Form 10-K").

[0000068505-24-000016:mdna:3]
[same as prior period, unchanged from 0000068505-23-000045:mdna:3]

[0000068505-24-000016:mdna:4]
[same as prior period, unchanged from 0000068505-23-000045:mdna:4]

[0000068505-24-000016:mdna:5]
[same as prior period, unchanged from 0000068505-23-000045:mdna:5]

[0000068505-24-000016:mdna:6]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services." Within these segments the Company has three principal product lines in which the Company reports net sales: Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video") and Command Center.

[0000068505-24-000016:mdna:7]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

[0000068505-24-000016:mdna:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility “on scene” and bring attention to what’s important.

[0000068505-24-000016:mdna:9]
•Command Center: Command center solutions and software applications that unify voice, video, data and analytics from public safety agencies, enterprises and the community to create a broad informational view to help simplify workflows and improve the accuracy and speed of decisions.

[0000068505-24-000016:mdna:10]
First Quarter Financial Results

[0000068505-24-000016:mdna:11]
•Net sales were $2.4 billion in the first quarter of 2024 compared to $2.2 billion in the first quarter of 2023.

[0000068505-24-000016:mdna:12]
•Operating earnings were $519 million in the first quarter of 2024 compared to $399 million in the first quarter of 2023.

[0000068505-24-000016:mdna:13]
•Net loss attributable to Motorola Solutions, Inc. was $39 million, or $(0.23) per diluted common share, in the first quarter of 2024, compared to net earnings of $278 million, or $1.61 per diluted common share, in the first quarter of 2023.

[0000068505-24-000016:mdna:14]
•Operating cash flow increased $390 million to $382 million in the first quarter of 2024 compared to $8 million used in the first quarter of 2023.

[0000068505-24-000016:mdna:15]
•We repurchased $39 million of common stock and paid $163 million in dividends in the first quarter of 2024. Additionally, we extinguished the $1.0 billion of 1.75% senior convertible notes issued to Silver Lake Partners and scheduled to mature in September 2024 (the "Silver Lake Convertible Debt") for $1.59 billion in cash, inclusive of the conversion premium.

[0000068505-24-000016:mdna:16]
[same as prior period, unchanged from 0000068505-23-000045:mdna:19]

[0000068505-24-000016:mdna:17]
UK Home Office Update

[0000068505-24-000016:mdna:18]
In October 2021, the Competition and Markets Authority ("CMA") opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, our private mobile radio communications network that we acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-24-000016:mdna:19]
In 2023, the CMA imposed a legal order on Airwave which implemented a prospective price control on Airwave (the "Charge Control"). After the Competition Appeal Tribunal ("CAT") dismissed our appeal of the CMA's final decision on December 22, 2023, we filed an application with the United Kingdom Court of Appeal on February 13, 2024, requesting that it hear our appeal of the CAT judgment; the Court of Appeal has not yet responded to this request. Since August 1, 2023, revenue under the Airwave contract has been recognized in accordance with the Charge Control, and will continue to be unless the United Kingdom Court of Appeal were to reverse the CAT's judgment and overturn the Charge Control.

[0000068505-24-000016:mdna:20]
On March 13, 2024, we received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice extends the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the Charge Control rates.

[0000068505-24-000016:mdna:21]
Our backlog for Airwave services contracted with the UK Home Office through December 31, 2026 was previously reduced by $777 million to align with the Charge Control. In the first quarter of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, we have recorded additional backlog of $748 million to reflect the incremental three years of services. On April 11, 2024, we filed proceedings in the UK High Court challenging the decision of the UK Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable UK procurement and public law. The backlog related to the incremental years of service contemplated in the Deferred National Shutdown Notice could change depending on the outcome of the proceedings.

[0000068505-24-000016:mdna:22]
[same as prior period, unchanged from 0000068505-23-000045:mdna:24]

[0000068505-24-000016:mdna:23]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Video Security and Access Control | Products and Systems Integration | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |
| Video Security and Access Control | Products and Systems Integration | IPVideo Corporation | Creator of a multifunctional safety and security device. | $170 million and share-based compensation of $5 million | December 15, 2023 |

[0000068505-24-000016:mdna:24]
[same as prior period, unchanged from 0000068505-23-000045:mdna:27]

[0000068505-24-000016:mdna:25]
|  | Three Months Ended |
| (Dollars in millions, except per share amounts) | March 30, 2024 |  | % ofSales* |  | April 1, 2023 |  | % ofSales* |
| Net sales from products | $ | 1,405 |  |  |  |  | $ | 1,224 |  |  |  |
| Net sales from services | 984 |  |  |  |  | 947 |  |  |  |
| Net sales | 2,389 |  |  |  |  | 2,171 |  |  |  |
| Costs of products sales | 600 |  |  | 42.7 | % |  | 576 |  |  | 47.1 | % |
| Costs of services sales | 597 |  |  | 60.7 | % |  | 549 |  |  | 58.0 | % |
| Costs of sales | 1,197 |  |  |  |  | 1,125 |  |  |  |
| Gross margin | 1,192 |  |  | 49.9 | % |  | 1,046 |  |  | 48.2 | % |
| Selling, general and administrative expenses | 397 |  |  | 16.6 | % |  | 368 |  |  | 17.0 | % |
| Research and development expenditures | 218 |  |  | 9.1 | % |  | 210 |  |  | 9.7 | % |
| Other charges | 58 |  |  | 2.4 | % |  | 69 |  |  | 3.2 | % |
| Operating earnings | 519 |  |  | 21.7 | % |  | 399 |  |  | 18.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net | (44) |  |  | (1.8) | % |  | (54) |  |  | (2.5) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | 1 |  |  | — | % |
| Other, net | (565) |  |  | (23.7) | % |  | 12 |  |  | 0.6 | % |
| Total other expense | (609) |  |  | (25.5) | % |  | (41) |  |  | (1.9) | % |
| Earnings (loss) from continuing operations before income taxes | (90) |  |  | (3.8) | % |  | 358 |  |  | 16.5 | % |
| Income tax expense (benefit) | (52) |  |  | (2.2) | % |  | 79 |  |  | 3.6 | % |
| Net earnings (loss) | (38) |  |  | (1.6) | % |  | 279 |  |  | 12.9 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | — | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (39) |  |  | (1.6) | % |  | $ | 278 |  |  | 12.8 | % |
| Earnings (loss) per diluted common share | $ | (0.23) |  |  |  |  | $ | 1.61 |  |  |  |

[0000068505-24-000016:mdna:26]
[same as prior period, unchanged from 0000068505-23-000045:mdna:29]

[0000068505-24-000016:mdna:27]
27

[0000068505-24-000016:mdna:28]
Results of Operations—Three months ended March 30, 2024 compared to three months ended April 1, 2023

[0000068505-24-000016:mdna:29]
The results of operations for the first quarter of 2024 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-24-000016:mdna:30]
[same as prior period, unchanged from 0000068505-23-000045:mdna:33]

[0000068505-24-000016:mdna:31]
[same as prior period, unchanged from 0000068505-23-000045:mdna:34]

[0000068505-24-000016:mdna:32]
[same as prior period, unchanged from 0000068505-23-000045:mdna:35]

[0000068505-24-000016:mdna:33]
[same as prior period, unchanged from 0000068505-23-000045:mdna:36]

[0000068505-24-000016:mdna:34]
[same as prior period, unchanged from 0000068505-23-000045:mdna:37]

[0000068505-24-000016:mdna:35]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |  | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |
| International | 408 |  |  | 288 |  |  | 696 |  |  | 353 |  |  | 326 |  |  | 679 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |  | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |
| Video | 235 |  |  | 163 |  |  | 398 |  |  | 223 |  |  | 136 |  |  | 359 |  |
| Command Center | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 155 |  |  | 155 |  |
| Total | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Operating earnings | $ | 310 |  |  | $ | 209 |  |  | $ | 519 |  |  | $ | 176 |  |  | $ | 223 |  |  | $ | 399 |  |
| Operating margins | 20.8 | % |  | 23.2 | % |  | 21.7 | % |  | 13.5 | % |  | 25.7 | % |  | 18.4 | % |

[0000068505-24-000016:mdna:36]
[same as prior period, unchanged from 0000068505-23-000045:mdna:39]

[0000068505-24-000016:mdna:37]
The Products and Systems Integration segment’s net sales represented 62% of our net sales in the first quarter of 2024 and 60% in the first quarter of 2023. The Software and Services segment’s net sales represented 38% of our net sales in the first quarter of 2024 and 40% in the first quarter of 2023.

[0000068505-24-000016:mdna:38]
Net sales increased $218 million, or 10%, in the first quarter of 2024 compared to the first quarter of 2023. The $187 million, or 14%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 14% in the North America region and an increase of 16% in the International region. The $31 million, or 4%, increase in net sales within the Software and Services segment was driven by an increase of 13% in the North America region and partially offset by a decrease of 12% in the International region. Net sales includes:

[0000068505-24-000016:mdna:39]
•an increase in the Products and Systems Integration segment, inclusive of $10 million of revenue from acquisitions, driven by an increase in LMR and Video;

[0000068505-24-000016:mdna:40]
•an increase in the Software and Services segment, driven by an increase in Video and Command Center, partially offset by a decrease LMR services; and

[0000068505-24-000016:mdna:41]
•inclusive of $1 million from favorable currency rates.

[0000068505-24-000016:mdna:42]
[same as prior period, unchanged from 0000068505-23-000045:mdna:45]

[0000068505-24-000016:mdna:43]
•a 13% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-24-000016:mdna:44]
•a 3% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in Video and LMR, partially offset by the revenue reduction on Airwave services in accordance with the Charge Control.

[0000068505-24-000016:mdna:45]
[same as prior period, unchanged from 0000068505-23-000045:mdna:48]

[0000068505-24-000016:mdna:46]
The 14% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000016:mdna:47]
•$175 million, or 16% growth in LMR, driven by the North America and International regions; and

[0000068505-24-000016:mdna:48]
•$12 million, or 5% growth in Video, inclusive of revenue from acquisitions, driven by the International and North America regions.

[0000068505-24-000016:mdna:49]
[same as prior period, unchanged from 0000068505-23-000045:mdna:53]

[0000068505-24-000016:mdna:50]
The 4% increase in the Software and Services segment was driven by the following:

[0000068505-24-000016:mdna:51]
•$27 million, or 20% growth in Video, driven by the North America and International regions;

[0000068505-24-000016:mdna:52]
•$14 million, or 9% growth in Command Center, driven by the North America region, partially offset by the International region; partially offset by

[0000068505-24-000016:mdna:53]
•$10 million, or 2% decrease in LMR, driven by the International region and the revenue reduction on Airwave services in accordance with the Charge Control, partially offset by the North America region; and

[0000068505-24-000016:mdna:54]
•inclusive of $1 million from favorable currency rates.

[0000068505-24-000016:mdna:55]
[same as prior period, unchanged from 0000068505-23-000045:mdna:59]

[0000068505-24-000016:mdna:56]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |  | % Change |
| Gross margin | $ | 1,192 |  |  | $ | 1,046 |  |  | 14 | % |

[0000068505-24-000016:mdna:57]
Gross margin was 49.9% of net sales in the first quarter of 2024 compared to 48.2% in the first quarter of 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-24-000016:mdna:58]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales and favorable mix; partially offset by

[0000068505-24-000016:mdna:59]
•lower gross margin as a percentage of net sales in the Software and Services segment, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control and partially offset by higher sales.

[0000068505-24-000016:mdna:60]
[same as prior period, unchanged from 0000068505-23-000045:mdna:64]

[0000068505-24-000016:mdna:61]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |  | % Change |
| Selling, general and administrative expenses | $ | 397 |  |  | $ | 368 |  |  | 8 | % |

[0000068505-24-000016:mdna:62]
SG&A expenses increased 8% in the first quarter of 2024 compared to the first quarter of 2023. The increase in SG&A expenses was primarily due to higher employee incentive costs and higher expenses associated with acquired businesses. SG&A expenses were 16.6% of net sales in the first quarter of 2024 compared to 17.0% of net sales in the first quarter of 2023.

[0000068505-24-000016:mdna:63]
[same as prior period, unchanged from 0000068505-23-000045:mdna:67]

[0000068505-24-000016:mdna:64]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |  | % Change |
| Research and development expenditures | $ | 218 |  |  | $ | 210 |  |  | 4 | % |

[0000068505-24-000016:mdna:65]
R&D expenditures increased 4% in the first quarter of 2024 compared to the first quarter of 2023 primarily due to higher employee incentive costs and higher expenses associated with acquired businesses. R&D expenditures were 9.1% of net sales in the first quarter of 2024 compared to 9.7% of net sales in the first quarter of 2023.

[0000068505-24-000016:mdna:66]
[same as prior period, unchanged from 0000068505-23-000045:mdna:70]

[0000068505-24-000016:mdna:67]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |
| Other charges | $ | 58 |  |  | $ | 69 |  |

[0000068505-24-000016:mdna:68]
Other charges decreased by $11 million in the first quarter of 2024 compared to the first quarter of 2023. The change was driven primarily by the following:

[0000068505-24-000016:mdna:69]
•$39 million of intangible asset amortization expense in the first quarter of 2024 compared to $55 million of intangible asset amortization expense in the first quarter of 2023; partially offset by

[0000068505-24-000016:mdna:70]
•$6 million of legal settlement charges in the first quarter of 2024 that did not occur in the first quarter 2023.

[0000068505-24-000016:mdna:71]
[same as prior period, unchanged from 0000068505-23-000045:mdna:75]

[0000068505-24-000016:mdna:72]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |
| Operating earnings from Products and Systems Integration | $ | 310 |  |  | $ | 176 |  |
| Operating earnings from Software and Services | 209 |  |  | 223 |  |
| Operating earnings | $ | 519 |  |  | $ | 399 |  |

[0000068505-24-000016:mdna:73]
Operating earnings increased $120 million, or 30%, in the first quarter of 2024 compared to the first quarter of 2023. The increase in Operating earnings was due to:

[0000068505-24-000016:mdna:74]
•$134 million increase in the Products and Systems Integration segment, primarily driven by higher sales and favorable change in year-over-year mix, partially offset by higher employee incentive costs and higher expenses associated with acquired businesses; partially offset by

[0000068505-24-000016:mdna:75]
•$14 million decrease in the Software and Services segment, primarily driven by lower revenue as a result of the revenue reduction on Airwave services in accordance with the Charge Control and higher employee incentive costs, partially offset by higher sales and a reduction in intangible amortization expenses.

[0000068505-24-000016:mdna:76]
[same as prior period, unchanged from 0000068505-23-000045:mdna:80]

[0000068505-24-000016:mdna:77]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |
| Interest expense, net | $ | (44) |  |  | $ | (54) |  |

[0000068505-24-000016:mdna:78]
The $10 million decrease in Interest expense, net in the first quarter of 2024 compared to the first quarter of 2023 was primarily driven by higher interest income earned on cash.

[0000068505-24-000016:mdna:79]
[same as prior period, unchanged from 0000068505-23-000045:mdna:83]

[0000068505-24-000016:mdna:80]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |
| Other, net | $ | (565) |  |  | $ | 12 |  |

[0000068505-24-000016:mdna:81]
The $577 million decrease in Other, net in the first quarter of 2024 compared to the first quarter of 2023 was primarily driven by:

[0000068505-24-000016:mdna:82]
•$585 million loss from the extinguishment of Silver Lake Convertible Debt in the first quarter of 2024;

[0000068505-24-000016:mdna:83]
•$10 million loss on derivatives in the first quarter of 2024 compared to a $7 million gain on derivatives in the first quarter of 2023; and

[0000068505-24-000016:mdna:84]
•$2 million loss on fair value adjustments to equity investments in the first quarter of 2024 compared to a $3 million gain on fair value adjustments to equity investments in the first quarter of 2023; partially offset by

[0000068505-24-000016:mdna:85]
•$1 million of foreign currency gains in the first quarter of 2024 compared to $19 million of foreign currency losses in the first quarter of 2023;

[0000068505-24-000016:mdna:86]
•$32 million of net periodic pension and postretirement benefit in the first quarter of 2024 compared to $25 million of net periodic pension and postretirement benefit in the first quarter of 2023; and

[0000068505-24-000016:mdna:87]
•$3 million loss on investment impairments in the first quarter of 2024 compared to a $6 million loss on investment impairments in the first quarter of 2023.

[0000068505-24-000016:mdna:88]
[same as prior period, unchanged from 0000068505-23-000045:mdna:91]

[0000068505-24-000016:mdna:89]
|  | Three Months Ended |
| (In millions) | March 30, 2024 |  | April 1, 2023 |
| Income tax expense (benefit) | $ | (52) |  |  | $ | 79 |  |

[0000068505-24-000016:mdna:90]
Income tax expense decreased by $131 million in the first quarter of 2024 compared to the first quarter of 2023, resulting in an effective tax rate of 58%. Our effective tax rate for the three months ended March 30, 2024 of 58% was higher than the effective tax rate for the three months ended April 1, 2023 of 22%, primarily due to the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024, offset by the tax benefit recognized due to our ability to utilize additional foreign tax credit carryforwards and a higher federal derived intangible income deduction on our 2023 U.S. tax return as a result of our decision to implement a business initiative in 2024.

[0000068505-24-000016:mdna:91]
[same as prior period, unchanged from 0000068505-23-000045:mdna:158]

[0000068505-24-000016:mdna:92]
During the first quarter of 2024, we recorded net reorganization of business charges of $10 million, including $7 million of charges recorded within Other charges and $3 million of charges recorded in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000016:mdna:93]
During the first quarter of 2023, we recorded net reorganization of business charges of $13 million, including $7 million of charges in Other charges and $6 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $15 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-24-000016:mdna:94]
[same as prior period, unchanged from 0000068505-23-000045:mdna:163]

[0000068505-24-000016:mdna:95]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Products and Systems Integration | $ | 8 |  |  | $ | 11 |  |
| Software and Services | 2 |  |  | 2 |  |
|  | $ | 10 |  |  | $ | 13 |  |

[0000068505-24-000016:mdna:96]
Cash payments for employee severance in connection with the reorganization of business plans were $9 million in the first quarter of 2024 and $10 million in the first quarter of 2023. The reorganization of business accrual at March 30, 2024 was $24 million related to employee separation costs that are expected to be paid within one year.

[0000068505-24-000016:mdna:97]
At January 1, 2024, we had an accrual of $5 million for exit costs related to our exit of the ESN contract with the UK Home Office. The $5 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at March 30, 2024, and are expected to be paid within one year.

[0000068505-24-000016:mdna:98]
[same as prior period, unchanged from 0000068505-23-000045:mdna:167]

[0000068505-24-000016:mdna:99]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 382 |  |  | $ | (8) |  |
| Investing activities | (47) |  |  | (53) |  |
| Financing activities | (512) |  |  | (263) |  |
| Effect of exchange rates on cash and cash equivalents | (16) |  |  | 21 |  |
| Increase (decrease) in cash and cash equivalents | $ | (193) |  |  | $ | (303) |  |

[0000068505-24-000016:mdna:100]
[same as prior period, unchanged from 0000068505-23-000045:mdna:169]

[0000068505-24-000016:mdna:101]
At March 30, 2024, $1.2 billion of the $1.5 billion cash and cash equivalents balance was held in the U.S. and $317 million was held in other countries.

[0000068505-24-000016:mdna:102]
[same as prior period, unchanged from 0000068505-23-000045:mdna:171]

[0000068505-24-000016:mdna:103]
The increase in cash flows provided by operating activities from the first quarter of 2023 to the first quarter of 2024 was driven primarily by higher earnings, net of cash adjustments, improved working capital and lower income taxes due to a one time payment in the first quarter of 2023 of $70 million which did not recur in 2024.

[0000068505-24-000016:mdna:104]
[same as prior period, unchanged from 0000068505-23-000045:mdna:173]

[0000068505-24-000016:mdna:105]
The decrease in cash flows used for investing activities in the first quarter of 2024 compared to the first quarter of 2023 was primarily due to proceeds from the sale of our Richmond, British Columbia and Richardson, Texas video manufacturing operations and lower capital expenditures, offset by an increase in cash used for acquisitions and investments.

[0000068505-24-000016:mdna:106]
[same as prior period, unchanged from 0000068505-23-000045:mdna:175]

[0000068505-24-000016:mdna:107]
The increase in cash flows used for financing activities in the first quarter of 2024 compared to the first quarter of 2023 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-24-000016:mdna:108]
•$1.59 billion increase in repayments of debt driven by the repurchase of the Silver Lake Convertible Debt in the first quarter of 2024;

[0000068505-24-000016:mdna:109]
•$31 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first quarter of 2024 compared to the first quarter of 2023; and

[0000068505-24-000016:mdna:110]
•$15 million increase in the payment of dividends in the first quarter of 2024 compared to the first quarter of 2023; partially offset by

[0000068505-24-000016:mdna:111]
•$1.3 billion increase in net proceeds in the first quarter of 2024 driven the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; and

[0000068505-24-000016:mdna:112]
•$101 million decrease in share repurchases in the first quarter of 2024 compared to the first quarter of 2023.

[0000068505-24-000016:mdna:113]
[same as prior period, unchanged from 0000068505-23-000045:mdna:182]

[0000068505-24-000016:mdna:114]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended March 30, 2024 and April 1, 2023:

[0000068505-24-000016:mdna:115]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Accounts receivable sales proceeds | — |  |  | — |  |
| Long-term receivables sales proceeds | 10 |  |  | 32 |  |
| Total proceeds from receivable sales | $ | 10 |  |  | $ | 32 |  |

[0000068505-24-000016:mdna:116]
[same as prior period, unchanged from 0000068505-23-000045:mdna:185]

[0000068505-24-000016:mdna:117]
We had outstanding debt of $6.3 billion at March 30, 2024, of which $313 million of our 4.0% senior notes due 2024 was current. We had outstanding debt of $6.0 billion at December 31, 2023, of which $1.3 billion was current.

[0000068505-24-000016:mdna:118]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue the Silver Lake Convertible Debt, which became fully convertible on September 5, 2021. On February 14, 2024, we agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The cash consideration was paid during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the three months ended March 30, 2024.

[0000068505-24-000016:mdna:119]
On March 25, 2024, we issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. We recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

[0000068505-24-000016:mdna:120]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of March 30, 2024.

[0000068505-24-000016:mdna:121]
32

[0000068505-24-000016:mdna:122]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of March 30, 2024 we had no outstanding debt under the commercial paper program.

[0000068505-24-000016:mdna:123]
We have investment grade ratings on our senior unsecured long-term debt. During the first quarter of 2024, S&P Global Ratings and Fitch Ratings upgraded our credit rating to BBB from BBB-. We continue to believe that we will be able to maintain sufficient access to the capital markets in the next twelve months and the foreseeable future.

[0000068505-24-000016:mdna:124]
[same as prior period, unchanged from 0000068505-23-000045:mdna:191]

[0000068505-24-000016:mdna:125]
During the three months ended March 30, 2024, we repurchased approximately 0.1 million shares at an average price of $317.45 per share for an aggregate amount of $39 million, excluding transaction costs and excise tax. As of March 30, 2024, we had used approximately $15.6 billion of the share repurchase authority to repurchase shares, leaving $2.4 billion of authority available for future repurchases.

[0000068505-24-000016:mdna:126]
[same as prior period, unchanged from 0000068505-23-000045:mdna:193]

[0000068505-24-000016:mdna:127]
During the first quarter of 2024 we paid $163 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $163 million in cash dividends to holders of our common stock.

[0000068505-24-000016:mdna:128]
[same as prior period, unchanged from 0000068505-23-000045:mdna:195]

[0000068505-24-000016:mdna:129]
[same as prior period, unchanged from 0000068505-23-000045:mdna:196]

[0000068505-24-000016:mdna:130]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases.

[0000068505-24-000016:mdna:131]
[same as prior period, unchanged from 0000068505-23-000045:mdna:198]

[0000068505-24-000016:mdna:132]
We had outstanding commitments to provide long-term financing to third parties totaling $67 million at March 30, 2024, compared to $103 million at December 31, 2023.

[0000068505-24-000016:mdna:133]
[same as prior period, unchanged from 0000068505-23-000045:mdna:200]

[0000068505-24-000016:mdna:134]
See “Recent Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
