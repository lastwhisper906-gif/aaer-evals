# MSI notes — 0000068505-24-000016


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-24-000016:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of March 30, 2024 and for the three months ended March 30, 2024 and April 1, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-24-000016:notes:2]
[same as prior period, unchanged from 0000068505-23-000045:notes:2]

[0000068505-24-000016:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three months ended March 30, 2024 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-24-000016:notes:4]
[same as prior period, unchanged from 0000068505-23-000045:notes:4]

[0000068505-24-000016:notes:5]
[same as prior period, unchanged from 0000068505-23-000045:notes:5]

[0000068505-24-000016:notes:6]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services". Within these segments the Company has three principal product lines in which the Company reports net sales: Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center.

[0000068505-24-000016:notes:7]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

[0000068505-24-000016:notes:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.

[0000068505-24-000016:notes:9]
•Command Center: Command center solutions and software applications that unify voice, video and data analytics from public safety agencies, enterprises and the community to create a broad informational view to help simplify workflows and improve the accuracy and speed of decisions.

[0000068505-24-000016:notes:10]
[same as prior period, unchanged from 0000068505-23-000045:notes:10]

[0000068505-24-000016:notes:11]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

[0000068505-24-000016:notes:12]
On December 15, 2023, the Company acquired IPVideo Corporation ("IPVideo"), the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is a part of the Products and Systems Integration segment.

[0000068505-24-000016:notes:13]
Recent Accounting Pronouncements

[0000068505-24-000016:notes:14]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The ASU is effective for fiscal years beginning after December 15, 2023, and interim periods beginning in 2025, with early adoption permitted. The ASU will require the Company to disclose additional expense categories at the segment level including Cost of sales, Selling, general and administrative expenses, Research and development expenditures and other charges once it adopts this ASU. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-24-000016:notes:15]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-24-000016:notes:16]
[same as prior period, unchanged from 0000068505-23-000045:notes:20]

[0000068505-24-000016:notes:17]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 30, 2024 and April 1, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-24-000016:notes:18]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |  | $ | 950 |  |  | $ | 542 |  |  | $ | 1,492 |  |
| International | 408 |  |  | 288 |  |  | 696 |  |  | 353 |  |  | 326 |  |  | 679 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |  | $ | 1,080 |  |  | $ | 577 |  |  | $ | 1,657 |  |
| Video | 235 |  |  | 163 |  |  | 398 |  |  | 223 |  |  | 136 |  |  | 359 |  |
| Command Center | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 155 |  |  | 155 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |  | $ | 723 |  |  | $ | 795 |  |  | $ | 1,518 |  |
| Indirect | 630 |  |  | 77 |  |  | 707 |  |  | 580 |  |  | 73 |  |  | 653 |  |
|  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |

[0000068505-24-000016:notes:19]
[same as prior period, unchanged from 0000068505-23-000045:notes:24]

[0000068505-24-000016:notes:20]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of March 30, 2024 was $9.6 billion. A total of $4.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of March 30, 2024, of which $2.8 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.0 billion was from Software and Services performance obligations that were not yet satisfied as of March 30, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.7 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-24-000016:notes:21]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first quarter of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.

[0000068505-24-000016:notes:22]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a Contract asset or Contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-24-000016:notes:23]
[same as prior period, unchanged from 0000068505-23-000045:notes:26]

[0000068505-24-000016:notes:24]
| (In millions) | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,592 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,127 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,890 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 430 |  |  | 424 |  |  |  |  |  |

[0000068505-24-000016:notes:25]
Revenue recognized during the three months ended March 30, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $508 million, compared to $474 million of revenue recognized during the three months ended April 1, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $12 million was reversed during the three months ended March 30, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended April 1, 2023, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-24-000016:notes:26]
There were no material expected credit losses recorded on contract assets during each of the three months ended March 30, 2024 and April 1, 2023.

[0000068505-24-000016:notes:27]
[same as prior period, unchanged from 0000068505-23-000045:notes:30]

[0000068505-24-000016:notes:28]
| (In millions) | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 65 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 116 |  |  | 119 |  |  |  |  |  |

[0000068505-24-000016:notes:29]
Amortization of contract cost assets was $13 million for the three months ended March 30, 2024 and $17 million for the three months ended April 1, 2023.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-24-000016:notes:30]
[same as prior period, unchanged from 0000068505-23-000045:notes:33]

[0000068505-24-000016:notes:31]
|  | Three Months Ended |
| (in millions) | March 30, 2024 |  | April 1, 2023 |
| Lease expense: |  |  |  |
| Operating lease cost | $ | 35 |  |  | $ | 34 |  |
| Short-term lease cost | — |  |  | 1 |
| Variable cost | 11 |  |  | 9 |  |
| Sublease income | (1) |  |  | (2) |  |
| Net lease expense from operating leases | $ | 45 |  |  | $ | 42 |  |

[0000068505-24-000016:notes:32]
[same as prior period, unchanged from 0000068505-23-000045:notes:35]

[0000068505-24-000016:notes:33]
| (in millions) |  | Statement Line Classification |  | March 30, 2024 |  | December 31, 2023 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 534 |  |  | $ | 495 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | $ | 122 |  |  | $ | 125 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 447 |  |  | $ | 407 |  |  |  |

[0000068505-24-000016:notes:34]
[same as prior period, unchanged from 0000068505-23-000045:notes:37]

[0000068505-24-000016:notes:35]
|  | Three Months Ended |  |  |
| (in millions) | March 30, 2024 |  | April 1, 2023 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 38 |  |  | $ | 52 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | $ | 83 |  |  | $ | 8 |  |  |  |

[0000068505-24-000016:notes:36]
For the three months ended March 30, 2024, the Company recorded $80 million of assets obtained in exchange for lease liabilities due to an assumption that it is reasonably certain that renewal options will be extended on its radio tower site leases operated within the Airwave radio network, consistent with the UK Home Office's notice of contract extension pursuant to their Deferred National Shutdown Notice through December 31, 2029.

[0000068505-24-000016:notes:37]
|  | March 30, 2024 |  | December 31, 2023 |
| Weighted average remaining lease terms (years) | 6 |  | 5 |
| Weighted average discount rate | 3.82 | % |  | 4.34 | % |

[0000068505-24-000016:notes:38]
[same as prior period, unchanged from 0000068505-23-000045:notes:41]

[0000068505-24-000016:notes:39]
|  | March 30, 2024 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2024 | $ | 99 |  |  |  |  |  |
| 2025 | 132 |  |  |  |  |  |
| 2026 | 115 |  |  |  |  |  |
| 2027 | 98 |  |  |  |  |  |
| 2028 | 76 |  |  |  |  |  |
| Thereafter | 114 |  |  |  |  |  |
| Total lease payments | 634 |  |  |  |  |  |
| Less: Interest | 65 |  |  |  |  |  |
| Present value of lease liabilities | $ | 569 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-24-000016:notes:40]
Components of Lease Expense


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-24-000016:notes:41]
[same as prior period, unchanged from 0000068505-23-000045:notes:43]

[0000068505-24-000016:notes:42]
[same as prior period, unchanged from 0000068505-23-000045:notes:44]

[0000068505-24-000016:notes:43]
[same as prior period, unchanged from 0000068505-23-000045:notes:45]

[0000068505-24-000016:notes:44]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Other charges: |  |  |  |
| Intangibles amortization (Note 15) | $ | 39 |  |  | $ | 55 |  |
| Reorganization of business (Note 14) | 7 |  |  | 7 |  |
| Operating lease asset impairments | 3 |  |  | 3 |  |
| Acquisition-related transaction fees | 4 |  |  | 2 |  |
| Legal settlements | 6 |  |  | — |  |
| Fixed asset impairments | — |  |  | 2 |  |
| Other | (1) |  |  | — |  |
|  | $ | 58 |  |  | $ | 69 |  |

[0000068505-24-000016:notes:45]
[same as prior period, unchanged from 0000068505-23-000045:notes:48]

[0000068505-24-000016:notes:46]
Interest expense, net, and Other both included in Other income (expense), consist of the following:

[0000068505-24-000016:notes:47]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Interest income (expense), net: |  |  |  |
| Interest expense | $ | (61) |  |  | $ | (63) |  |
| Interest income | 17 |  |  | 9 |  |
|  | $ | (44) |  |  | $ | (54) |  |
| Other, net: |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 32 |  |  | $ | 25 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt (Note 5) | (585) |  |  | — |  |
| Investment impairments | (3) |  |  | (6) |  |
| Foreign currency gain (loss) | 1 |  |  | (19) |  |
| Gain (loss) on derivative instruments (Note 6) | (10) |  |  | 7 |  |
| Fair value adjustments to equity investments | (2) |  |  | 3 |  |
| Other | 2 |  |  | 2 |  |
|  | $ | (565) |  |  | $ | 12 |  |

[0000068505-24-000016:notes:48]
Earnings (Loss) Per Common Share

[0000068505-24-000016:notes:49]
Basic and diluted earnings (loss) per common share from net earnings (loss) attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-24-000016:notes:50]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Basic earnings (loss) per common share: |  |  |  |
| Earnings (loss) | $ | (39) |  |  | $ | 278 |  |
| Weighted average common shares outstanding | 166.3 |  |  | 167.4 |  |
| Per share amount | $ | (0.23) |  |  | $ | 1.66 |  |
| Diluted earnings (loss) per common share: |  |  |  |
| Earnings (loss) | $ | (39) |  |  | $ | 278 |  |
| Weighted average common shares outstanding | 166.3 |  |  | 167.4 |  |
| Add effect of dilutive securities: |  |  |  |
| Share-based awards | — |  |  | 4.0 |  |
| Silver Lake Convertible Debt | — |  |  | 1.2 |  |
| Diluted weighted average common shares outstanding | 166.3 |  |  | 172.6 |  |
| Per share amount | $ | (0.23) |  |  | $ | 1.61 |  |

[0000068505-24-000016:notes:51]
In the three months ended March 30, 2024, the Company recorded a net loss from continuing operations, which resulted in the presentation of diluted earnings (loss) per common share to be equal to basic earnings (loss) per common share, as any increase to the basic shares would be antidilutive. A total of 5.0 million shares outstanding were excluded from the computation of diluted earnings per common share for three months ended March 30, 2024, because their inclusion would have been antidilutive; these shares included the assumed exercise of 2.7 million options, the assumed vesting of 1.2 million restricted stock units (RSUs), the assumed vesting of 0.2 million related to the Long Range Incentive Plan (LRIP), and 0.9 million shares related to the Silver Lake Convertible Debt (as defined in Note 5, "Debt and Credit Facilities" in this "Part 1 - Financial Information" of this Form 10-Q).

[0000068505-24-000016:notes:52]
With respect to the Silver Lake Convertible Debt, on February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. A total of 0.9 million shares were potentially issuable under the terms of the Silver Lake Convertible Debt based on the Company's option to settle the conversion premium in shares through February 14, 2024. However, as stated above, in the computation of diluted earnings per common share for the three months ended March 30, 2024, the 0.9 million of shares were excluded because their inclusion would have been antidilutive. Refer to Note 5, "Debt and Credit Facilities" in this “Part 1 — Financial Information” of this Form 10-Q for a further discussion of the Silver Lake Convertible Debt.

[0000068505-24-000016:notes:53]
In the computation of diluted earnings per common share for the three months ended April 1, 2023, the assumed exercise of 0.2 million options, inclusive of 0.1 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000016:notes:54]
[same as prior period, unchanged from 0000068505-23-000045:notes:57]

[0000068505-24-000016:notes:55]
[same as prior period, unchanged from 0000068505-23-000045:notes:58]

[0000068505-24-000016:notes:56]
[same as prior period, unchanged from 0000068505-23-000045:notes:59]

[0000068505-24-000016:notes:57]
|  | March 30, 2024 |  | December 31, 2023 |
| Accounts receivable | $ | 1,666 |  |  | $ | 1,779 |  |
| Less allowance for credit losses | (74) |  |  | (69) |  |
|  | $ | 1,592 |  |  | $ | 1,710 |  |

[0000068505-24-000016:notes:58]
[same as prior period, unchanged from 0000068505-23-000045:notes:61]

[0000068505-24-000016:notes:59]
[same as prior period, unchanged from 0000068505-23-000045:notes:62]

[0000068505-24-000016:notes:60]
|  | March 30, 2024 |  | December 31, 2023 |
| Finished goods | $ | 347 |  |  | $ | 328 |  |
| Work-in-process and production materials | 641 |  |  | 640 |  |
|  | 988 |  |  | 968 |  |
| Less inventory reserves | (148) |  |  | (141) |  |
|  | $ | 840 |  |  | $ | 827 |  |

[0000068505-24-000016:notes:61]
[same as prior period, unchanged from 0000068505-23-000045:notes:64]

[0000068505-24-000016:notes:62]
[same as prior period, unchanged from 0000068505-23-000045:notes:65]

[0000068505-24-000016:notes:63]
|  | March 30, 2024 |  | December 31, 2023 |
| Current contract cost assets (Note 2) | $ | 65 |  |  | $ | 56 |  |
| Contractor receivables | 60 |  |  | 40 |  |
| Tax-related deposits | 35 |  |  | 32 |  |
| Other | 290 |  |  | 229 |  |
|  | $ | 450 |  |  | $ | 357 |  |

[0000068505-24-000016:notes:64]
[same as prior period, unchanged from 0000068505-23-000045:notes:67]

[0000068505-24-000016:notes:65]
[same as prior period, unchanged from 0000068505-23-000045:notes:68]

[0000068505-24-000016:notes:66]
|  | March 30, 2024 |  | December 31, 2023 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 433 |  |  | 448 |  |
| Machinery and equipment | 2,428 |  |  | 2,396 |  |
|  | 2,866 |  |  | 2,849 |  |
| Less accumulated depreciation | (1,909) |  |  | (1,885) |  |
|  | $ | 957 |  |  | $ | 964 |  |

[0000068505-24-000016:notes:67]
During the year ended December 31, 2023, the Company entered into an arrangement to sell its Richmond, British Columbia and Richardson, Texas video manufacturing operations, including the machinery and equipment, inventory, transfer of employees and related facility lease to a contract manufacturer. During the year ended December 31, 2023, the Company presented the assets and liabilities as held for sale in its Consolidated Balance Sheets and recognized an impairment loss of $24 million on the exit of these video manufacturing operations within Other charges in the Consolidated Statements of Operations, as the carrying value of the asset group was below the expected selling price. The transaction closed on February 1, 2024 resulting in a gain on the sale of these video manufacturing operations, which was de minimis.

[0000068505-24-000016:notes:68]
Depreciation expense for the three months ended March 30, 2024 and April 1, 2023 was $44 million and $43 million, respectively.

[0000068505-24-000016:notes:69]
[same as prior period, unchanged from 0000068505-23-000045:notes:72]

[0000068505-24-000016:notes:70]
[same as prior period, unchanged from 0000068505-23-000045:notes:73]

[0000068505-24-000016:notes:71]
|  | March 30, 2024 |  | December 31, 2023 |  |  |  |  |
| Common stock | $ | 26 |  |  | $ | 28 |  |  |  |  |  |
| Strategic investments | 27 |  |  | 28 |  |  |  |  |  |
| Company-owned life insurance policies | 76 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 12 |  |  | 13 |  |  |  |  |  |
|  | $ | 141 |  |  | $ | 143 |  |  |  |  |  |

[0000068505-24-000016:notes:72]
[same as prior period, unchanged from 0000068505-23-000045:notes:76]

[0000068505-24-000016:notes:73]
[same as prior period, unchanged from 0000068505-23-000045:notes:77]

[0000068505-24-000016:notes:74]
|  | March 30, 2024 |  | December 31, 2023 |
| Defined benefit plan assets | $ | 113 |  |  | $ | 98 |  |
| Non-current contract cost assets (Note 2) | 116 |  |  | 119 |  |
| Other | 58 |  |  | 57 |  |
|  | $ | 287 |  |  | $ | 274 |  |

[0000068505-24-000016:notes:75]
[same as prior period, unchanged from 0000068505-23-000045:notes:79]

[0000068505-24-000016:notes:76]
The Company utilizes a supplier finance program which provides our suppliers the ability to accelerate payment on the Company's invoices beyond the stated payment terms. Under the terms of this program, the Company agrees to pay an intermediary the stated amount of confirmed invoices on the stated maturity dates of the invoices, and the supplier is able to negotiate earlier payment terms with the intermediary. The Company or the intermediary may terminate their agreement at any time upon 60 days' notice. The Company does not provide any forms of guarantees under this arrangement. Supplier participation in the program is solely at the supplier's discretion, and the participating suppliers negotiate their arrangements directly with the intermediary. The Company has no economic interest in a supplier's decision to participate in the program, and their participation has no bearing on our payment terms or amounts due. The stated invoice payment terms range from 75 to 120 days from the invoice date and are considered commercially reasonable.

[0000068505-24-000016:notes:77]
The Company's outstanding amounts related to the suppliers participating in this program was $27 million and $35 million as of March 30, 2024 and December 31, 2023, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-24-000016:notes:78]
[same as prior period, unchanged from 0000068505-23-000045:notes:82]

[0000068505-24-000016:notes:79]
[same as prior period, unchanged from 0000068505-23-000045:notes:83]

[0000068505-24-000016:notes:80]
|  | March 30, 2024 |  | December 31, 2023 |
| Compensation | $ | 365 |  |  | $ | 407 |  |
| Tax liabilities | 325 |  |  | 231 |  |
| Dividend payable | 163 |  |  | 163 |  |
| Trade liabilities | 141 |  |  | 140 |  |
| Operating lease liabilities (Note 3) | 122 |  |  | 125 |  |
| Customer reserves | 77 |  |  | 89 |  |
| Other | 408 |  |  | 349 |  |
|  | $ | 1,601 |  |  | $ | 1,504 |  |

[0000068505-24-000016:notes:81]
[same as prior period, unchanged from 0000068505-23-000045:notes:85]

[0000068505-24-000016:notes:82]
[same as prior period, unchanged from 0000068505-23-000045:notes:86]

[0000068505-24-000016:notes:83]
|  | March 30, 2024 |  | December 31, 2023 |
| Defined benefit plans (Note 8) | $ | 906 |  |  | $ | 939 |  |
| Non-current contract liabilities (Note 2) | 430 |  |  | 424 |  |
| Unrecognized tax benefits (Note 7) | 26 |  |  | 26 |  |
| Deferred income taxes (Note 7) | 59 |  |  | 55 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Other | 182 |  |  | 178 |  |
|  | $ | 1,722 |  |  | $ | 1,741 |  |

[0000068505-24-000016:notes:84]
[same as prior period, unchanged from 0000068505-23-000045:notes:88]

[0000068505-24-000016:notes:85]
Share Repurchase Program: During the three months ended March 30, 2024, the Company repurchased approximately 0.1 million shares at an average price of $317.45 per share for an aggregate amount of $39 million, excluding transaction costs and excise tax.

[0000068505-24-000016:notes:86]
Payment of Dividends: During the three months ended March 30, 2024 and April 1, 2023, the Company paid $163 million and $148 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $163 million in cash dividends to holders of its common stock.

[0000068505-24-000016:notes:87]
[same as prior period, unchanged from 0000068505-23-000045:notes:91]

[0000068505-24-000016:notes:88]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended March 30, 2024 and April 1, 2023:

[0000068505-24-000016:notes:89]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Foreign Currency Translation Adjustments: |  |  |  |
| Balance at beginning of period | $ | (482) |  |  | $ | (539) |  |
| Other comprehensive income (loss) before reclassification adjustment | (27) |  |  | 27 |  |
| Tax benefit | 3 |  |  | 9 |  |
| Other comprehensive income (loss), net of tax | (24) |  |  | 36 |  |
| Balance at end of period | $ | (506) |  |  | $ | (503) |  |
| Derivative instruments: |  |  |  |
| Balance at beginning of period | $ | (12) |  |  | $ | — |  |
| Other comprehensive income before reclassification adjustment | 4 |  |  | — |  |
| Other comprehensive income, net of tax | 4 |  |  | — |  |
| Balance at end of period | $ | (8) |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |
| Balance at beginning of period | $ | (2,046) |  |  | $ | (1,996) |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 9 |  |  | 15 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | — |  |  | 1 |  |
| Tax expense | (2) |  |  | (4) |  |
| Reclassification adjustments into Net earnings, net of tax | 7 |  |  | 12 |  |
| Other comprehensive income, net of tax | 7 |  |  | 12 |  |
| Balance at end of period | $ | (2,039) |  |  | $ | (1,984) |  |
| Total Accumulated other comprehensive loss | $ | (2,553) |  |  | $ | (2,487) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-24-000016:notes:90]
Debt and Credit Facilities

[0000068505-24-000016:notes:91]
|  | March 30, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | 313 |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 695 |  |  | 695 |  |
| 6.5% debentures due 2028 | 25 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 894 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior noted due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 6,308 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (313) |  |  | (1,313) |  |
| Long-term debt | $ | 5,994 |  |  | $ | 4,705 |  |

[0000068505-24-000016:notes:92]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the three months ended March 30, 2024.

[0000068505-24-000016:notes:93]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

[0000068505-24-000016:notes:94]
As of March 30, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 30, 2024.

[0000068505-24-000016:notes:95]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 30, 2024 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-24-000016:notes:96]
[same as prior period, unchanged from 0000068505-23-000045:notes:97]

[0000068505-24-000016:notes:97]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.0 billion and $1.3 billion for periods ended March 30, 2024 and December 31, 2023, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-24-000016:notes:98]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of March 30, 2024, and the corresponding positions as of December 31, 2023:

[0000068505-24-000016:notes:99]
|  | Notional Amount |
| Net Buy (Sell) by Currency | March 30, 2024 |  | December 31, 2023 |
| Euro | $ | 248 |  |  | $ | 322 |  |
| British pound | 147 |  |  | 252 |  |
| Australian dollar | (105) |  |  | (140) |  |
| Chinese renminbi | (65) |  |  | (66) |  |
| Brazilian real | (27) |  |  | (34) |  |

[0000068505-24-000016:notes:100]
[same as prior period, unchanged from 0000068505-23-000045:notes:101]

[0000068505-24-000016:notes:101]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of March 30, 2024, all of the counterparties had investment grade credit ratings. As of March 30, 2024, the Company had $1 million of exposure to aggregate credit risk with all counterparties.

[0000068505-24-000016:notes:102]
[same as prior period, unchanged from 0000068505-23-000045:notes:103]

[0000068505-24-000016:notes:103]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of March 30, 2024 and December 31, 2023:

[0000068505-24-000016:notes:104]
|  | Fair Values of Derivative Instruments |
| March 30, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | — |  |  | 2 |  |
| Equity swap contracts | — |  |  | — |  |
| Total derivatives | $ | 1 |  |  | $ | 2 |  |

[0000068505-24-000016:notes:105]
|  | Fair Values of Derivative Instruments |
| December 31, 2023 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | 3 |  |
| Treasury rate lock | — |  |  | 12 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 12 |  |  | 1 |  |
| Equity swap contracts | 1 |  |  | — |  |
| Total derivatives | $ | 14 |  |  | $ | 16 |  |

[0000068505-24-000016:notes:106]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended March 30, 2024 and April 1, 2023:

[0000068505-24-000016:notes:107]
|  | Financial Statement Location | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | 4 |  |  | $ | (2) |  |
| Forward points recognized | Other income (expense) | 1 |  |  | 1 |  |
| Treasury rate lock | Accumulated other comprehensive income (loss) | 4 |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | (10) |  |  | $ | 7 |  |
| Equity swap contracts | Selling, general and administrative expenses | 1 |  |  | — |  |

[0000068505-24-000016:notes:108]
[same as prior period, unchanged from 0000068505-23-000045:notes:109]

[0000068505-24-000016:notes:109]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of March 30, 2024, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £60 million of net investment hedges in a British pound functional subsidiary.

[0000068505-24-000016:notes:110]
[same as prior period, unchanged from 0000068505-23-000045:notes:111]

[0000068505-24-000016:notes:111]
[same as prior period, unchanged from 0000068505-23-000045:notes:112]

[0000068505-24-000016:notes:112]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of March 30, 2024 was $15 million.

[0000068505-24-000016:notes:113]
Treasury Rate Lock

[0000068505-24-000016:notes:114]
In 2023, the Company entered into treasury rate agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as a cash flow hedges. During the three months ended March 30, 2024, the Company issued $900 million of 5.4% senior notes due 2034. The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated Other Comprehensive Income (AOCI) will be reclassified to interest expense on a straight-line basis over the 10-year term of such senior notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-24-000016:notes:115]
[same as prior period, unchanged from 0000068505-23-000045:notes:114]

[0000068505-24-000016:notes:116]
[same as prior period, unchanged from 0000068505-23-000045:notes:115]

[0000068505-24-000016:notes:117]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Earnings (loss) before income taxes | $ | (90) |  |  | $ | 358 |  |
| Income tax expense (benefit) | (52) |  |  | 79 |  |
| Effective tax rate | 58 | % |  | 22 | % |

[0000068505-24-000016:notes:118]
The effective tax rate for the three months ended March 30, 2024 of 58% was higher than the U.S. federal statutory tax rate of 21% primarily due to the non tax deductible loss on the extinguishment of the Silver Lake Convertible Debt and state tax expense, offset by the tax benefit recognized upon the Company's decision to implement a business initiative which allows for

[0000068505-24-000016:notes:119]
additional utilization of foreign tax credit carryforwards and a higher federal derived intangible income deduction on our 2023 U.S. tax return, and excess tax benefits of share-based compensation.

[0000068505-24-000016:notes:120]
The effective tax rate for the three months ended April 1, 2023 of 22% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by excess tax benefits of share-based compensation. 
The effective tax rate for the three months ended March 30, 2024 of 58% was higher than the effective tax rate for the three months ended April 1, 2023 of 22%, primarily due to the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in 2024, offset by the tax benefit recognized due to the Company's ability to utilize additional foreign tax credit carryforwards and a higher federal derived intangible income deduction on its 2023 U.S. tax return as a result of the Company's decision to implement a business initiative in 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-24-000016:notes:121]
[same as prior period, unchanged from 0000068505-23-000045:notes:121]

[0000068505-24-000016:notes:122]
[same as prior period, unchanged from 0000068505-23-000045:notes:122]

[0000068505-24-000016:notes:123]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |  | March 30, 2024 |  | April 1, 2023 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 47 |  |  | 47 |  |  | 14 |  |  | 2 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (74) |  |  | (73) |  |  | (26) |  |  | (15) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 6 |  |  | 5 |  |  | 2 |  |  | 9 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | — |  |  | 1 |  |  | 1 |  |
| Net periodic pension benefits | $ | (21) |  |  | $ | (21) |  |  | $ | (11) |  |  | $ | (4) |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-24-000016:notes:124]
[same as prior period, unchanged from 0000068505-23-000045:notes:125]

[0000068505-24-000016:notes:125]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Share-based compensation expense included in: |  |  |  |
| Costs of sales | $ | 11 |  |  | $ | 10 |  |
| Selling, general and administrative expenses | 30 |  |  | 30 |  |
| Research and development expenditures | 15 |  |  | 15 |  |
| Share-based compensation expense included in Operating earnings | 56 |  |  | 55 |  |
| Tax benefit | (11) |  |  | (11) |  |
| Share-based compensation expense, net of tax | $ | 45 |  |  | $ | 44 |  |
| Decrease in basic earnings per share | $ | (0.27) |  |  | $ | (0.26) |  |
| Decrease in diluted earnings per share | $ | (0.27) |  |  | $ | (0.25) |  |

[0000068505-24-000016:notes:126]
During the three months ended March 30, 2024, the Company granted 0.5 million RSUs, 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $163 million, $25 million and $14 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $7 million and $14 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-24-000016:notes:127]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of March 30, 2024 and December 31, 2023 were as follows:

[0000068505-24-000016:notes:128]
| March 30, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  |  |  | $ | 1 |  |
| Equity swap contracts | — |  |  | — |  |  |  |  | — |  |
| Common stock | 26 |  |  | — |  |  |  |  | 26 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  |  |  | $ | 2 |  |

[0000068505-24-000016:notes:129]
| December 31, 2023 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 13 |  |  |  |  | $ | 13 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |
| Common stock | 28 |  |  | — |  |  |  |  | 28 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  |  |  | $ | 4 |  |
| Treasury rate lock | — |  |  | 12 |  |  |  |  | 12 |  |

[0000068505-24-000016:notes:130]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of March 30, 2024 or December 31, 2023.

[0000068505-24-000016:notes:131]
At March 30, 2024 and December 31, 2023, the Company had $918 million and $863 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-24-000016:notes:132]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of March 30, 2024 was $6.0 billion. The fair value of long-term debt at December 31, 2023 was $6.4 billion, of which the Silver Lake Convertible Debt was $1.6 billion (Level 2).

[0000068505-24-000016:notes:133]
[same as prior period, unchanged from 0000068505-23-000045:notes:134]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-24-000016:notes:134]
[same as prior period, unchanged from 0000068505-23-000045:notes:135]

[0000068505-24-000016:notes:135]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended March 30, 2024 and April 1, 2023:

[0000068505-24-000016:notes:136]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Accounts receivable sales proceeds | — |  |  | — |  |
| Long-term receivables sales proceeds | 10 |  |  | 32 |  |
| Total proceeds from receivable sales | $ | 10 |  |  | $ | 32 |  |

[0000068505-24-000016:notes:137]
At March 30, 2024, the Company had retained servicing obligations for $777 million of long-term receivables, compared to $813 million at December 31, 2023. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $67 million at March 30, 2024, compared to $103 million at December 31, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-24-000016:notes:138]
Commitments and Contingencies
Legal Matters

[0000068505-24-000016:notes:139]
Hytera Litigation

[0000068505-24-000016:notes:140]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-24-000016:notes:141]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through April 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-24-000016:notes:142]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera subsequently filed several notices to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), including a notice of appeal filed on August 2, 2022, which appealed the orders related to the jury's verdict as well as the Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on the parties' appeals on December 5, 2023.

[0000068505-24-000016:notes:143]
In the first quarter of 2024, the parties have been engaged in competing litigation in the Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. In March 2024, the Court ordered Hytera to take affirmative steps to withdraw its competing litigation. Hytera did not comply with the Court's order and, accordingly, the Court issued an order against Hytera for contempt sanctions on April 2, 2024, which included a worldwide sales injunction of all Hytera radio products. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the lower Court's various orders related to the contempt sanctions.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-24-000016:notes:144]
[same as prior period, unchanged from 0000068505-23-000045:notes:146]

[0000068505-24-000016:notes:145]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Products and Systems Integration | $ | 1,490 |  |  | $ | 1,303 |  |
| Software and Services | 899 |  |  | 868 |  |
|  | $ | 2,389 |  |  | $ | 2,171 |  |

[0000068505-24-000016:notes:146]
[same as prior period, unchanged from 0000068505-23-000045:notes:148]

[0000068505-24-000016:notes:147]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Products and Systems Integration | $ | 310 |  |  | $ | 176 |  |
| Software and Services | 209 |  |  | 223 |  |
| Operating earnings | 519 |  |  | 399 |  |
| Total other expense | (609) |  |  | (41) |  |
| Earnings (loss) before income taxes | $ | (90) |  |  | $ | 358 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-24-000016:notes:148]
Reorganization of Business
2024 Charges

[0000068505-24-000016:notes:149]
During the three months ended March 30, 2024, the Company recorded net reorganization of business charges of $10 million, including $7 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000016:notes:150]
[same as prior period, unchanged from 0000068505-23-000045:notes:153]

[0000068505-24-000016:notes:151]
| March 30, 2024 | Three Months Ended |
| Products and Systems Integration | $ | 8 |  |
| Software and Services | 2 |  |
|  | $ | 10 |  |

[0000068505-24-000016:notes:152]
[same as prior period, unchanged from 0000068505-23-000045:notes:155]

[0000068505-24-000016:notes:153]
|  | January 1, 2024 |  | Additional Charges |  | Adjustments |  | Amount Used |  | March 30, 2024 |
| Employee separation costs | $ | 23 |  |  | $ | 12 |  |  | $ | (2) |  |  | $ | (9) |  |  | $ | 24 |  |
| Exit costs | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |
|  | $ | 28 |  |  | $ | 12 |  |  | $ | (2) |  |  | $ | (9) |  |  | $ | 29 |  |

[0000068505-24-000016:notes:154]
[same as prior period, unchanged from 0000068505-23-000045:notes:157]

[0000068505-24-000016:notes:155]
At January 1, 2024, the Company had an accrual of $5 million for exit costs, related to the Company's exit of the Emergency Service Network contract with the UK Home Office. The $5 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at March 30, 2024, and are expected to be paid within one year.

[0000068505-24-000016:notes:156]
[same as prior period, unchanged from 0000068505-23-000045:notes:159]

[0000068505-24-000016:notes:157]
At January 1, 2024, the Company had an accrual of $23 million for employee separation costs. The 2024 additional charges of $12 million represent severance costs for approximately 170 employees. The adjustment of $2 million reflects reversals for accruals no longer needed. The $9 million used reflects cash payments to severed employees. The remaining accrual of $24 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at March 30, 2024, is expected to be paid, primarily within one year, to approximately 630 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-24-000016:notes:158]
2023 Charges

[0000068505-24-000016:notes:159]
During the three months ended April 1, 2023, the Company recorded net reorganization of business charges of $13 million, including $7 million of charges in Other charges and $6 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $15 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-24-000016:notes:160]
| April 1, 2023 | Three Months Ended |
| Products and Systems Integration | $ | 11 |  |
| Software and Services | 2 |  |
|  | $ | 13 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-24-000016:notes:161]
Intangible Assets and Goodwill
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The Company recognized $17 million of goodwill, $19 million of identifiable intangible assets and $1 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $6 million of customer relationships and $12 million of developed technology and will be amortized over a period of two, fifteen and nine years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-24-000016:notes:162]
On December 15, 2023, the Company acquired IPVideo Corporation ("IPVideo"), the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. The transaction also includes the potential for the Company to make contingent earn-out payments of up to $15 million based on IPVideo's achievement of certain financial targets from January 1, 2024 through December 31, 2024. As of the acquisition date, the Company estimated the fair value of the contingent earn-out to be $2 million, which is included in the purchase price. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The Company recognized $106 million of goodwill, $72 million of identifiable intangible assets and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $8 million of trade names, $6 million of customer relationships and $58 million of developed technology and will be amortized over a period of eight, twelve and fifteen years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-24-000016:notes:163]
[same as prior period, unchanged from 0000068505-23-000045:notes:172]

[0000068505-24-000016:notes:164]
[same as prior period, unchanged from 0000068505-23-000045:notes:173]

[0000068505-24-000016:notes:165]
|  | March 30, 2024 |  | December 31, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,167 |  |  | $ | 467 |  |  | $ | 1,156 |  |  | $ | 447 |  |
| Customer-related | 1,556 |  |  | 1,059 |  |  | 1,566 |  |  | 1,055 |  |
| Other intangibles | 107 |  |  | 72 |  |  | 107 |  |  | 72 |  |
|  | $ | 2,830 |  |  | $ | 1,598 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-24-000016:notes:166]
Amortization expense on intangible assets was $39 million for the three months ended March 30, 2024. Amortization expense on intangible assets was $55 million for the three months ended April 1, 2023. As of March 30, 2024, annual amortization expense is estimated to be $146 million in 2024, $133 million in 2025, $125 million in 2026, $114 million in 2027, $114 million in 2028 and $102 million in 2029.

[0000068505-24-000016:notes:167]
[same as prior period, unchanged from 0000068505-23-000045:notes:176]

[0000068505-24-000016:notes:168]
|  | March 30, 2024 |  | December 31, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 1,004 |  |  | $ | 355 |  |  | $ | 985 |  |  | $ | 337 |  |
| Software and Services | 1,826 |  |  | 1,243 |  |  | 1,844 |  |  | 1,237 |  |
|  | $ | 2,830 |  |  | $ | 1,598 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-24-000016:notes:169]
[same as prior period, unchanged from 0000068505-23-000045:notes:178]

[0000068505-24-000016:notes:170]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2024 to March 30, 2024:

[0000068505-24-000016:notes:171]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2024 | $ | 1,568 |  |  | $ | 1,833 |  |  | $ | 3,401 |  |
| Goodwill acquired | 17 |  |  | — |  |  | 17 |  |
| Purchase accounting adjustments | (3) |  |  | — |  |  | (3) |  |
| Foreign currency | (1) |  |  | (4) |  |  | (5) |  |
| Balance as of March 30, 2024 | $ | 1,581 |  |  | $ | 1,829 |  |  | $ | 3,410 |  |
