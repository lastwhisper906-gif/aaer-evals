# MSI 8-K — 0000068505-24-000014 filed 2024-05-02

## item codes, every 8-K on or before 2024-05-02

- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2024-05-02

- none on or before 2024-05-02

## item 2.02 — earnings release, exhibit 99.1

[0000068505-24-000014:8k_2_02:1]
EX-99.1
2
msiq12024pressrelease.htm
EX-99.1

[0000068505-24-000014:8k_2_02:2]
Document

[0000068505-24-000014:8k_2_02:3]
Exhibit 99.1

[0000068505-24-000014:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2024 Financial Results

[0000068505-24-000014:8k_2_02:5]
Company raises full-year revenue and earnings outlook following strong Q1 results

[0000068505-24-000014:8k_2_02:6]
•Sales of $2.4 billion, up 10% versus a year ago

[0000068505-24-000014:8k_2_02:7]
◦Products and Systems Integration sales up 14%

[0000068505-24-000014:8k_2_02:8]
◦Software and Services sales up 4%; up 12%1 excluding U.K. Home Office sales

[0000068505-24-000014:8k_2_02:9]
•GAAP earnings per share (EPS) of ($0.23), inclusive of a ($3.42)2 loss due to settlement accounting for the Silver Lake convertible debt

[0000068505-24-000014:8k_2_02:10]
•Non-GAAP EPS3 of $2.81, up 27% versus a year ago

[0000068505-24-000014:8k_2_02:11]
•Record Q1 operating cash flow of $382 million, up $390 million versus a year ago

[0000068505-24-000014:8k_2_02:12]
•Record ending backlog of $14.4 billion, up 2% versus a year ago

[0000068505-24-000014:8k_2_02:13]
•Credit ratings upgraded to BBB by S&P and Fitch; issued $1.3 billion in long-term debt and settled Silver Lake convertible debt in cash

[0000068505-24-000014:8k_2_02:14]
•Acquired Silent Sentinel, a provider of specialized, long-range cameras

[0000068505-24-000014:8k_2_02:15]
CHICAGO – May 2, 2024 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2024.

[0000068505-24-000014:8k_2_02:16]
“Q1 was an outstanding quarter, with record Q1 revenue in both segments and record Q1 cash flow,” said Greg Brown, chairman and CEO, Motorola Solutions. “Our continued robust backlog and strong balance sheet position us well going forward. As a result, we’re raising both our revenue and earnings expectations for the full year.”

[0000068505-24-000014:8k_2_02:17]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-24-000014:8k_2_02:18]
|  | Q1 2024 |  | Q1 2023 | % Change |
| Sales | $2,389 |  | $2,171 | 10 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $519 |  | $399 | 30 | % |
| % of Sales | 21.7 | % |  | 18.4 | % |  |
| EPS | ($0.23) |  | $1.61 | (114) | % |
| Non-GAAP3 |  |  |  |  |
| Operating Earnings | $638 |  | $532 | 20 | % |
| % of Sales | 26.7 | % |  | 24.5 | % |  |
| EPS | $2.81 |  | $2.22 | 27 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,490 |  | $1,303 | 14 | % |
| GAAP Operating Earnings | $310 |  | $176 | 76 | % |
| % of Sales | 20.8 | % |  | 13.5 | % |  |
| Non-GAAP Operating Earnings3 | $370 |  | $246 | 50 | % |
| % of Sales | 24.8 | % |  | 18.9 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $899 |  | $868 | 4 | % |
| GAAP Operating Earnings | $209 |  | $223 | (6) | % |
| % of Sales | 23.2 | % |  | 25.7 | % |  |
| Non-GAAP Operating Earnings3 | $268 |  | $286 | (6) | % |
| % of Sales | 29.8 | % |  | 32.9 | % |  |

[0000068505-24-000014:8k_2_02:19]
1Details regarding this non-GAAP measure and the use of non-GAAP measures are included later in this news release.

[0000068505-24-000014:8k_2_02:20]
2A $3.42 pre-tax non-operating loss on the extinguishment of the Silver Lake convertible debt recorded during Q1 2024 is calculated as the loss of $585 million divided by dilutive shares of 171.3 million, which represents the dilutive share count that the company would have reported in the quarter if not for the loss due to this transaction.

[0000068505-24-000014:8k_2_02:21]
1

[0000068505-24-000014:8k_2_02:22]
3Non-GAAP financial information excludes the after-tax impact of approximately $3.04 per diluted share related to highlighted items, including the loss from the extinguishment of Silver Lake convertible debt, share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-24-000014:8k_2_02:23]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-24-000014:8k_2_02:24]
•Revenue - Sales were $2.4 billion, up 10% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $10 million and currency tailwinds were $1 million in the quarter. The Products and Systems Integration segment grew 14%, driven by growth in land mobile radio communications ("LMR") and video security and access control ("Video"). The Software and Services segment grew 4%, driven by growth in Video and Command Center, partially offset by lower revenue in the U.K. related to the CMA's decision to implement a prospective price control on Airwave (the "Charge Control") and our exit from the Emergency Services Network ("ESN") contract.

[0000068505-24-000014:8k_2_02:25]
•Operating margin - GAAP operating margin was 21.7% of sales, up from 18.4% in the year-ago quarter. Non-GAAP operating margin was 26.7% of sales, up 220 basis points from 24.5% in the year-ago quarter.  The increase in both GAAP and Non-GAAP operating margin was driven by higher sales, favorable mix and improved operating leverage, partially offset by the Charge Control.

[0000068505-24-000014:8k_2_02:26]
•Taxes - The GAAP effective tax rate during the quarter was 57.8%, driven by the non deductible loss on the extinguishment of Silver Lake convertible debt, offset by utilization of foreign tax credit carryovers. This compares to a tax rate of 22.1% in the year-ago quarter. The non-GAAP effective tax rate was 22.1%, compared to 21.9% in the year-ago quarter.

[0000068505-24-000014:8k_2_02:27]
•Cash flow - Operating cash flow was $382 million, compared to a usage of $8 million in the year-ago quarter and free cash flow was $336 million compared to a usage of $62 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to improved working capital and higher earnings, net of non-cash charges.

[0000068505-24-000014:8k_2_02:28]
•Capital allocation - During the quarter, the company paid $163 million in cash dividends, incurred $46 million of capital expenditures and repurchased $39 million of common stock.  Additionally, the company settled the Silver Lake convertible debt for $1.59 billion in cash, inclusive of the conversion premium, resulting in an overall reduction in the company's diluted share count and eliminating any further share dilution related to the note.  The company received credit rating upgrades to BBB from both S&P and Fitch, issued $1.3 billion in long-term debt during the quarter, and closed the acquisition of Silent Sentinel, a provider of specialized long-range cameras, for $37 million, net of cash acquired.

[0000068505-24-000014:8k_2_02:29]
•Backlog - The company ended the quarter with record backlog of $14.4 billion, up 2% or $331 million from the year-ago quarter. Products and Systems Integration segment backlog was down $74 million, or 2%, driven primarily by unfavorable foreign exchange rates.  Software and Services segment backlog was up $404 million, or 4%, driven by increases in multi-year software and services contracts in both regions.

[0000068505-24-000014:8k_2_02:30]
2

[0000068505-24-000014:8k_2_02:31]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-24-000014:8k_2_02:32]
Software and Services

[0000068505-24-000014:8k_2_02:33]
•$25M LMR services order for Douglas County, Colorado

[0000068505-24-000014:8k_2_02:34]
•$25M LMR services order for U.K. Department of Health

[0000068505-24-000014:8k_2_02:35]
•$18M Command Center order for San Francisco

[0000068505-24-000014:8k_2_02:36]
•$14M LMR services order for Lithuania

[0000068505-24-000014:8k_2_02:37]
•$11M LMR services order for São Paulo State Police, Brazil

[0000068505-24-000014:8k_2_02:38]
Products and Systems Integration

[0000068505-24-000014:8k_2_02:39]
•$22M P25 device order for large U.S. customer

[0000068505-24-000014:8k_2_02:40]
•$16M LMR order for an international customer

[0000068505-24-000014:8k_2_02:41]
•$13M LMR order for State of Tennessee

[0000068505-24-000014:8k_2_02:42]
•$13M mobile video order for North Carolina State Highway Patrol

[0000068505-24-000014:8k_2_02:43]
BUSINESS OUTLOOK

[0000068505-24-000014:8k_2_02:44]
•Second quarter 2024 - The company expects revenue growth between 7% and 8% compared to the second quarter of 2023. The company expects non-GAAP EPS in the range of $2.97 to $3.02 per share. This assumes approximately 170 million fully diluted shares and a non-GAAP effective tax rate of approximately 24%.

[0000068505-24-000014:8k_2_02:45]
•Full-year 2024 - The company now expects revenue growth of approximately 7%, up from its prior guidance of approximately 6%, and non-GAAP EPS of between $12.98 and $13.08 per share, up from its prior guidance of between $12.62 and $12.72 per share. This outlook assumes approximately $30 million of foreign exchange headwinds, a fully diluted share count between 170 million and 171 million shares and a non-GAAP effective tax rate between 23% and 24%.

[0000068505-24-000014:8k_2_02:46]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-24-000014:8k_2_02:47]
RECENT EVENTS

[0000068505-24-000014:8k_2_02:48]
U.K. HOME OFFICE UPDATE

[0000068505-24-000014:8k_2_02:49]
In October 2021, the Competition and Markets Authority ("CMA") opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, the company's private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-24-000014:8k_2_02:50]
In 2023, the CMA imposed a legal order on Airwave which implemented the Charge Control. After the Competition Appeal Tribunal ("CAT") dismissed the company's appeal of the CMA's final decision on December 22, 2023, the company filed an application with the United Kingdom Court of Appeal on February 13, 2024, requesting that it hear the company's appeal of the CAT judgment; the Court of Appeal has not yet responded to this request. Since August 1, 2023, revenue under the Airwave contract has been recognized in accordance with the Charge Control, and will continue to be unless the United Kingdom Court of Appeal were to reverse the CAT's judgment and overturn the Charge Control.

[0000068505-24-000014:8k_2_02:51]
3

[0000068505-24-000014:8k_2_02:52]
On March 13, 2024, the company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the U.K. Home Office. The Deferred National Shutdown Notice extends the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the Charge Control rates.

[0000068505-24-000014:8k_2_02:53]
The company's backlog for Airwave services contracted with the U.K. Home Office through December 31, 2026 was previously reduced by $777 million to align with the Charge Control. In the first quarter of 2024, as a result of the U.K. Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the company has recorded additional backlog of $748 million to reflect the incremental three years of services. On April 11, 2024, the company filed proceedings in the U.K. High Court challenging the decision of the U.K. Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable U.K. procurement and public law. The backlog related to the incremental years of service contemplated in the Deferred National Shutdown Notice could change depending on the outcome of the proceedings.

[0000068505-24-000014:8k_2_02:54]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, May 2. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-24-000014:8k_2_02:55]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-24-000014:8k_2_02:56]
A comparison of results from operations is as follows:

[0000068505-24-000014:8k_2_02:57]
|  | Q1 2024 | Q1 2023 |
| Net sales | $2,389 | $2,171 |
| Gross margin | $1,192 | $1,046 |
| Operating earnings | $519 | $399 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | ($39) | $278 |
| Diluted EPS | ($0.23) | $1.61 |
| Weighted average diluted common shares outstanding | 166.3 |  | 172.6 |  |

[0000068505-24-000014:8k_2_02:58]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-24-000014:8k_2_02:59]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate, organic revenue and net sales adjusted for the U.K. Home Office. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-24-000014:8k_2_02:60]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-24-000014:8k_2_02:61]
4

[0000068505-24-000014:8k_2_02:62]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-24-000014:8k_2_02:63]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-24-000014:8k_2_02:64]
Net sales adjusted for the U.K. Home Office or Net sales excluding U.K. Home Office sales: Net sales adjusted for the U.K. Home Office reflects net sales calculated under GAAP excluding net sales related to the U.K. Home Office. The company believes that net sales excluding the U.K. Home Office improves period-to-period comparability related to the Charge Control implemented as of August 1, 2023 and the company's exit from the ESN contract as of December 31, 2023.

[0000068505-24-000014:8k_2_02:65]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-24-000014:8k_2_02:66]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-24-000014:8k_2_02:67]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-24-000014:8k_2_02:68]
On December 17, 2020, the Court held that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court’s

[0000068505-24-000014:8k_2_02:69]
5

[0000068505-24-000014:8k_2_02:70]
previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through April 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-24-000014:8k_2_02:71]
Following the February 14, 2020 verdict and judgment in the company's favor, Hytera subsequently filed several notices to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), including a notice of appeal filed on August 2, 2022 which appealed the orders related to the jury's verdict as well as the Court's royalty order. The company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on the parties' appeals on December 5, 2023.

[0000068505-24-000014:8k_2_02:72]
In the first quarter of 2024, the parties have been engaged in competing litigation in the Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the company until November 2023) related to the possible continued use by Hytera of the company’s trade secrets in Hytera’s currently shipping products. In March 2024, the Court ordered Hytera to take affirmative steps to withdraw its competing litigation. Hytera did not comply with the Court's order and, accordingly, the Court issued an order against Hytera for contempt sanctions on April 2, 2024, which included a worldwide sales injunction of all Hytera radio products. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the lower Court's various orders related to the contempt sanctions.

[0000068505-24-000014:8k_2_02:73]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $15 million of proceeds realized in 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-24-000014:8k_2_02:74]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-24-000014:8k_2_02:75]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net income measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-24-000014:8k_2_02:76]
6

[0000068505-24-000014:8k_2_02:77]
FORWARD LOOKING STATEMENTS

[0000068505-24-000014:8k_2_02:78]
7

[0000068505-24-000014:8k_2_02:79]
obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-24-000014:8k_2_02:80]
ABOUT MOTOROLA SOLUTIONS

[0000068505-24-000014:8k_2_02:81]
Motorola Solutions is solving for safer. We build and connect technologies to help protect people, property and places. Our solutions enable the collaboration between public safety agencies and enterprises that’s critical for a proactive approach to safety and security. Learn more about how we’re solving for safer communities, safer schools, safer hospitals, safer businesses – safer everywhere – at www.motorolasolutions.com.

[0000068505-24-000014:8k_2_02:82]
MEDIA CONTACT

[0000068505-24-000014:8k_2_02:83]
Alexandra Reynolds

[0000068505-24-000014:8k_2_02:84]
Motorola Solutions

[0000068505-24-000014:8k_2_02:85]
+1 312-965-3968

[0000068505-24-000014:8k_2_02:86]
alexandra.reynolds@motorolasolutions.com

[0000068505-24-000014:8k_2_02:87]
INVESTOR CONTACT

[0000068505-24-000014:8k_2_02:88]
Tim Yocum

[0000068505-24-000014:8k_2_02:89]
Motorola Solutions

[0000068505-24-000014:8k_2_02:90]
+1 847-576-6899

[0000068505-24-000014:8k_2_02:91]
Tim.Yocum@motorolasolutions.com

[0000068505-24-000014:8k_2_02:92]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2024 Motorola Solutions, Inc. All rights reserved.

[0000068505-24-000014:8k_2_02:93]
8

[0000068505-24-000014:8k_2_02:94]
GAAP-1

[0000068505-24-000014:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:96]
Condensed Consolidated Statements of Operations

[0000068505-24-000014:8k_2_02:97]
(In millions, except per share amounts)

[0000068505-24-000014:8k_2_02:98]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Net sales from products | $ | 1,405 |  |  | $ | 1,224 |  |
| Net sales from services | 984 |  |  | 947 |  |
| Net sales | 2,389 |  |  | 2,171 |  |
| Costs of products sales | 600 |  |  | 576 |  |
| Costs of services sales | 597 |  |  | 549 |  |
| Costs of sales | 1,197 |  |  | 1,125 |  |
| Gross margin | 1,192 |  |  | 1,046 |  |
| Selling, general and administrative expenses | 397 |  |  | 368 |  |
| Research and development expenditures | 218 |  |  | 210 |  |
| Other charges | 19 |  |  | 14 |  |
| Intangibles amortization | 39 |  |  | 55 |  |
| Operating earnings | 519 |  |  | 399 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (44) |  |  | (54) |  |
| Gain on sales of investments and businesses, net | — |  |  | 1 |  |
| Other, net | (565) |  |  | 12 |  |
| Total other expense | (609) |  |  | (41) |  |
| Earnings (loss) before income taxes | (90) |  |  | 358 |  |
| Income tax expense (benefit) | (52) |  |  | 79 |  |
| Net earnings (loss) | (38) |  |  | 279 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | $ | (39) |  |  | $ | 278 |  |
| Earnings (loss) per common share: |  |  |  |
| Basic | $ | (0.23) |  |  | $ | 1.66 |  |
| Diluted | $ | (0.23) |  |  | $ | 1.61 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.3 |  |  | 167.4 |  |
| Diluted | 166.3 |  |  | 172.6 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 58.8 | % |  | 56.4 | % |
| Net sales from services | 41.2 | % |  | 43.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 42.7 | % |  | 47.1 | % |
| Costs of services sales | 60.7 | % |  | 58.0 | % |
| Costs of sales | 50.1 | % |  | 51.8 | % |
| Gross margin | 49.9 | % |  | 48.2 | % |
| Selling, general and administrative expenses | 16.6 | % |  | 17.0 | % |
| Research and development expenditures | 9.1 | % |  | 9.7 | % |
| Other charges | 0.8 | % |  | 0.6 | % |
| Intangibles amortization | 1.6 | % |  | 2.5 | % |
| Operating earnings | 21.7 | % |  | 18.4 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (1.8) | % |  | (2.5) | % |
| Gain on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | (23.7) | % |  | 0.6 | % |
| Total other expense | (25.5) | % |  | (1.9) | % |
| Earnings (loss) before income taxes | (3.8) | % |  | 16.5 | % |
| Income tax expense (benefit) | (2.2) | % |  | 3.6 | % |
| Net earnings (loss) | (1.6) | % |  | 12.9 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | — | % |
| Net earnings (loss) attributable to Motorola Solutions, Inc. | (1.6) | % |  | 12.8 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-24-000014:8k_2_02:99]
9

[0000068505-24-000014:8k_2_02:100]
GAAP-2

[0000068505-24-000014:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:102]
Condensed Consolidated Balance Sheets

[0000068505-24-000014:8k_2_02:103]
(In millions)

[0000068505-24-000014:8k_2_02:104]
|  | March 30, 2024 |  | December 31, 2023 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,512 |  |  | $ | 1,705 |  |
| Accounts receivable, net | 1,592 |  |  | 1,710 |  |
| Contract assets | 1,127 |  |  | 1,102 |  |
| Inventories, net | 840 |  |  | 827 |  |
| Other current assets | 450 |  |  | 357 |  |
| Current assets held for disposition | — |  |  | 24 |  |
| Total current assets | 5,521 |  |  | 5,725 |  |
| Property, plant and equipment, net | 957 |  |  | 964 |  |
| Operating lease assets | 534 |  |  | 495 |  |
| Investments | 141 |  |  | 143 |  |
| Deferred income taxes | 1,244 |  |  | 1,062 |  |
| Goodwill | 3,410 |  |  | 3,401 |  |
| Intangible assets, net | 1,232 |  |  | 1,255 |  |
| Other assets | 287 |  |  | 274 |  |
| Non-current assets held for disposition | — |  |  | 17 |  |
| Total assets | $ | 13,326 |  |  | $ | 13,336 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | 313 |  |  | $ | 1,313 |  |
| Accounts payable | 822 |  |  | 881 |  |
| Contract liabilities | 1,890 |  |  | 2,037 |  |
| Accrued liabilities | 1,601 |  |  | 1,504 |  |
| Current liabilities held for disposition | — |  |  | 1 |  |
| Total current liabilities | 4,626 |  |  | 5,736 |  |
| Long-term debt | 5,994 |  |  | 4,705 |  |
| Operating lease liabilities | 447 |  |  | 407 |  |
| Other liabilities | 1,722 |  |  | 1,741 |  |
| Non-current liabilities held for disposition | — |  |  | 8 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 521 |  |  | 724 |  |
| Non-controlling interests | 16 |  |  | 15 |  |
| Total liabilities and stockholders’ equity | $ | 13,326 |  |  | $ | 13,336 |  |

[0000068505-24-000014:8k_2_02:105]
10

[0000068505-24-000014:8k_2_02:106]
GAAP-3

[0000068505-24-000014:8k_2_02:107]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:108]
Condensed Consolidated Statements of Cash Flows

[0000068505-24-000014:8k_2_02:109]
(In millions)

[0000068505-24-000014:8k_2_02:110]
|  | Three Months Ended |
|  | March 30, 2024 |  | April 1, 2023 |
| Operating |  |  |  |
| Net earnings (loss) | $ | (38) |  |  | $ | 279 |  |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by (used for) operating activities: |  |  |  |
| Depreciation and amortization | 83 |  |  | 98 |  |
| Non-cash other charges | 3 |  |  | 7 |  |
| Share-based compensation expenses | 56 |  |  | 55 |  |
| Gain on sales of investments and businesses, net | — |  |  | (1) |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | 585 |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 113 |  |  | 179 |  |
| Inventories | (7) |  |  | (26) |  |
| Other current assets and contract assets | (123) |  |  | (40) |  |
| Accounts payable, accrued liabilities and contract liabilities | (90) |  |  | (536) |  |
| Other assets and liabilities | (19) |  |  | (5) |  |
| Deferred income taxes | (181) |  |  | (18) |  |
| Net cash provided by (used for) operating activities | 382 |  |  | (8) |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (37) |  |  | (4) |  |
| Proceeds from sales of investments and businesses, net | 36 |  |  | 5 |  |
| Capital expenditures | (46) |  |  | (54) |  |
| Net cash used for investing activities | (47) |  |  | (53) |  |
| Financing |  |  |  |
| Repayments of debt | (1,593) |  |  | — |  |
| Net proceeds from issuance of debt | 1,288 |  |  | — |  |
| Issuances of common stock | (5) |  |  | 26 |  |
| Purchases of common stock | (39) |  |  | (140) |  |
| Payments of dividends | (163) |  |  | (148) |  |
| Payments of dividends to non-controlling interests | — |  |  | (1) |  |
| Net cash used for financing activities | (512) |  |  | (263) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (16) |  |  | 21 |  |
| Net decrease in total cash and cash equivalents | (193) |  |  | (303) |  |
| Cash and cash equivalents, beginning of period | 1,705 |  |  | 1,325 |  |
| Cash and cash equivalents, end of period | $ | 1,512 |  |  | $ | 1,022 |  |

[0000068505-24-000014:8k_2_02:111]
11

[0000068505-24-000014:8k_2_02:112]
Non-GAAP-1

[0000068505-24-000014:8k_2_02:113]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:114]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-24-000014:8k_2_02:115]
(In millions)

[0000068505-24-000014:8k_2_02:116]
|  |  | Three Months Ended |  |  |
|  |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Net cash provided by (used for) operating activities |  | $ | 382 |  |  | $ | (8) |  |  |  |  |  |
| Capital expenditures |  | (46) |  |  | (54) |  |  |  |  |  |
| Free cash flow |  | $ | 336 |  |  | $ | (62) |  |  |  |  |  |

[0000068505-24-000014:8k_2_02:117]
12

[0000068505-24-000014:8k_2_02:118]
Non-GAAP-2

[0000068505-24-000014:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:120]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-24-000014:8k_2_02:121]
(In millions)

[0000068505-24-000014:8k_2_02:122]
|  |  |  |  | Three Months Ended |  |  |
|  |  | Statement Line |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Net earnings (loss) attributable to MSI |  |  |  | $ | (39) |  |  | $ | 278 |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | $ | 585 |  |  | $ | — |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 56 |  |  | 55 |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 39 |  |  | 55 |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 10 |  | 13 |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 6 |  |  | — |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 4 |  |  | 2 |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | 3 |  | 6 |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 3 |  |  | 3 |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 2 |  | (3) |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 1 |  |  | 3 |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | 1 |  |  | — |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | 2 |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | (1) |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 710 |  |  | $ | 135 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 189 |  | 29 |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 521 |  | 106 |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 482 |  |  | $ | 384 |  |  |  |  |  |

[0000068505-24-000014:8k_2_02:123]
Calculation of Non-GAAP Tax Rate

[0000068505-24-000014:8k_2_02:124]
(In millions)

[0000068505-24-000014:8k_2_02:125]
|  |  | Three Months Ended |  |  |
|  |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Net earnings (loss) before income taxes |  | $ | (90) |  |  | $ | 358 |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 710 |  |  | 135 |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 620 |  |  | 493 |  |  |  |  |  |
| Income tax expense (benefit) |  | (52) |  |  | 79 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 189 |  |  | 29 |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | $ | 137 |  |  | $ | 108 |  |  |  |  |  |
| Non-GAAP Tax rate |  | 22.1 | % |  | 21.9 | % |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-24-000014:8k_2_02:126]
13

[0000068505-24-000014:8k_2_02:127]
Non-GAAP-2

[0000068505-24-000014:8k_2_02:128]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-24-000014:8k_2_02:129]
|  |  |  |  | Three Months Ended |  |  |
|  |  | Statement Line |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Net earnings (loss) attributable to MSI |  |  |  | $ | (0.23) |  |  | $ | 1.61 |  |  |  |  |  |
| Adjust for dilution** |  |  |  | — |  |  | — |  |  |  |  |  |
| Diluted gains (loss) attributable to MSI |  |  |  | $ | (0.23) |  |  | $ | 1.61 |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | $ | 3.42 |  |  | $ | — |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 0.32 |  |  | 0.32 |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.23 |  |  | 0.32 |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.05 |  |  | 0.08 |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 0.03 |  |  | — |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.02 |  |  | 0.01 |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | 0.02 |  |  | 0.03 |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.02 |  |  | 0.02 |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 0.01 |  |  | (0.02) |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.01 |  |  | 0.02 |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | 0.01 |  |  | — |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | 0.01 |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | (0.01) |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 4.14 |  |  | $ | 0.78 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 1.10 |  | 0.17 |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 3.04 |  | 0.61 |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 2.81 |  |  | $ | 2.22 |  |  |  |  |  |
| GAAP Diluted Weighted Average Common Shares |  |  |  | 166.3 |  |  | 172.6 |  |  |  |  |  |
| Adjusted for dilutive shares outstanding** |  |  |  | 5.0 |  |  | — |  |  |  |  |  |
| Non-GAAP Diluted Weighted Average Common Shares |  |  |  | 171.3 |  |  | 172.6 |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |
| ** Under U.S. GAAP, the accounting for a net loss from continuing operations results in the presentation of diluted earnings per share equal to basic earnings per share, as any increase in basic shares would be anti-dilutive to earnings per share. As a result of the highlighted items identified during Q1 2024, the Company reported a net loss from continuing operations for the three months ended March 30, 2024 within our GAAP Condensed Consolidated Statement of Operations, while reporting earnings on a non-GAAP basis over the same periods. An adjustment is reflected to correct for the dilution of 5 million dilutive shares outstanding in Q1 2024. |  |  |  |  |

[0000068505-24-000014:8k_2_02:130]
14

[0000068505-24-000014:8k_2_02:131]
Non-GAAP-3

[0000068505-24-000014:8k_2_02:132]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:133]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-24-000014:8k_2_02:134]
(In millions)

[0000068505-24-000014:8k_2_02:135]
|  |  | Three Months Ended |
|  |  | March 30, 2024 |  | April 1, 2023 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |  | $ | 1,303 |  |  | $ | 868 |  |  | $ | 2,171 |  |
| Operating earnings ("OE") |  | $ | 310 |  |  | $ | 209 |  |  | $ | 519 |  |  | $ | 176 |  |  | $ | 223 |  |  | $ | 399 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 39 |  |  | 17 |  |  | 56 |  |  | 40 |  |  | 15 |  |  | 55 |  |
| Intangible assets amortization expense |  | 9 |  |  | 30 |  |  | 39 |  |  | 13 |  |  | 42 |  |  | 55 |  |
| Reorganization of business charges |  | 8 |  |  | 2 |  |  | 10 |  |  | 11 |  |  | 2 |  |  | 13 |  |
| Legal settlements |  | 1 |  |  | 5 |  |  | 6 |  |  | — |  |  | — |  |  | — |  |
| Acquisition-related transaction fees |  | — |  |  | 4 |  |  | 4 |  |  | — |  |  | 2 |  |  | 2 |  |
| Operating lease asset impairments |  | 2 |  |  | 1 |  |  | 3 |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Hytera-related legal expenses |  | 1 |  |  | — |  |  | 1 |  |  | 3 |  |  | — |  |  | 3 |  |
| Fixed asset impairments |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  | 60 |  |  | 59 |  |  | 119 |  |  | 70 |  |  | 63 |  |  | 133 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 370 |  |  | $ | 268 |  |  | $ | 638 |  |  | $ | 246 |  |  | $ | 286 |  |  | $ | 532 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 20.8 | % |  | 23.2 | % |  | 21.7 | % |  | 13.5 | % |  | 25.7 | % |  | 18.4 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.8 | % |  | 29.8 | % |  | 26.7 | % |  | 18.9 | % |  | 32.9 | % |  | 24.5 | % |

[0000068505-24-000014:8k_2_02:136]
15

[0000068505-24-000014:8k_2_02:137]
Non-GAAP-4

[0000068505-24-000014:8k_2_02:138]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:139]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-24-000014:8k_2_02:140]
(In millions)

[0000068505-24-000014:8k_2_02:141]
|  |  | Three Months Ended |  |  |
|  |  | March 30, 2024 |  | April 1, 2023 |  | % Change |
| Net sales |  | $ | 2,389 |  |  | $ | 2,171 |  |  | 10 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 10 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,379 |  |  | $ | 2,171 |  |  | 10 | % |

[0000068505-24-000014:8k_2_02:142]
16

[0000068505-24-000014:8k_2_02:143]
Non-GAAP-5

[0000068505-24-000014:8k_2_02:144]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000014:8k_2_02:145]
Reconciliation of Net Sales to Net Sales Adjusted for the U.K. Home Office

[0000068505-24-000014:8k_2_02:146]
(In millions)

[0000068505-24-000014:8k_2_02:147]
|  | Three Months Ended |  | % Change |  |  |  |  |
|  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |  |
| Software and Services net sales | $ | 899 |  |  | $ | 868 |  |  | 4 | % |  |  |  |  |  |  |
| U.K. Home Office net sales | (101) |  |  | (156) |  |  |  |  |  |  |  |  |  |
| Software and Services net sales adjusted for the U.K. Home Office | $ | 798 |  |  | $ | 712 |  |  | 12 | % |  |  |  |  |  |  |
| Net sales | $ | 2,389 |  |  | $ | 2,171 |  |  | 10 | % |  |  |  |  |  |  |
| U.K. Home Office net sales | (101) |  |  | (156) |  |  |  |  |  |  |  |  |  |
| Net sales adjusted for the U.K. Home Office | $ | 2,288 |  |  | $ | 2,015 |  |  | 14 | % |  |  |  |  |  |  |

[0000068505-24-000014:8k_2_02:148]
17
