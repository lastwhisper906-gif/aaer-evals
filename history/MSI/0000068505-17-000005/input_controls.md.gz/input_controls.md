# MSI 10-Q controls and the auditor's report


## item_4_controls

[0000068505-17-000005:item_4_controls:1]
Item 4. Controls and Procedures

[0000068505-17-000005:item_4_controls:2]
(a) Evaluation of disclosure controls and procedures. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of the end of the period covered by this quarterly report (the “Evaluation Date”). Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (“SEC”) reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-17-000005:item_4_controls:3]
(b) Changes in internal control over financial reporting. There have been no changes in our internal control over financial reporting that occurred during the quarter ended April 1, 2017, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.

[0000068505-17-000005:item_4_controls:4]
We previously were in the process of a multi-year phased upgrade and consolidation of our enterprise resource planning (“ERP”) systems into a single global platform across our businesses. With the sale of the Enterprise business which included the transfer of our existing ERP system to Zebra, we entered into transition service agreements which required us to operate in a shared information technology environment with Zebra until 2017. In April 2017, we went live on our new ERP system which is functioning as designed and continuing to support our business. Our new ERP system includes the replacement of regional systems supporting our product based business and back office finance processes including our general ledger. The system also includes the replacement of our current indirect procurement and service contract systems. As we are now live on our new ERP system, we will no longer need to rely upon the Zebra transition services agreement.

[0000068505-17-000005:item_4_controls:5]
32
