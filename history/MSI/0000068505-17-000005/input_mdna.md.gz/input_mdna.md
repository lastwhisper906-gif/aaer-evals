# MSI MD&A — 0000068505-17-000005


## mdna

[0000068505-17-000005:mdna:1]
[same as prior period, unchanged from 0000068505-16-000031:mdna:1]

[0000068505-17-000005:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three months ended April 1, 2017 and April 2, 2016, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2016.

[0000068505-17-000005:mdna:3]
[same as prior period, unchanged from 0000068505-16-000031:mdna:3]

[0000068505-17-000005:mdna:4]
[same as prior period, unchanged from 0000068505-16-000031:mdna:8]

[0000068505-17-000005:mdna:5]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 14,000 employees worldwide, based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-17-000005:mdna:6]
[same as prior period, unchanged from 0000068505-16-000031:mdna:10]

[0000068505-17-000005:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the first quarter of 2017, the segment’s net sales were $703 million, representing 55% of our consolidated net sales.

[0000068505-17-000005:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the first quarter of 2017, the segment’s net sales were $578 million, representing 45% of our consolidated net sales.

[0000068505-17-000005:mdna:9]
[same as prior period, unchanged from 0000068505-16-000031:mdna:13]

[0000068505-17-000005:mdna:10]
Impact of Macroeconomic Conditions: The stronger U.S. dollar and weakening economic conditions have had a negative impact on sales throughout 2015 and 2016, particularly in Latin America, parts of Europe, and China. Over this time, the strengthening dollar reduced the purchasing power of our customers, and economic challenges negatively impacted government and commercial budgets in these regions. While economic conditions in parts of the world stabilized in 2017 in contrast to the prior year, we expect continued political and economic uncertainty, in particular with the United Kingdom’s planned exit from the European Union (commonly referred to as “Brexit”), and in parts of Latin America and Europe.

[0000068505-17-000005:mdna:11]
Focus on Managed & Support Services and Software: Services continues to grow at a faster rate than the Products segment, driven by acquisitions such as Airwave and Interexport as well as organic growth in Managed & Support services. While Services generally experiences lower gross margins than our Products segment, revenue growth will continue to drive operating margin expansion. During the three months ended April 1, 2017, we experienced revenue growth of 18% in our Services segment.

[0000068505-17-000005:mdna:12]
In addition, we continue to invest in software through internal development and strategic acquisitions, as our customers increasingly demand expanded technology solutions that are delivered via software and related services. This includes mobile applications and software in the Command Center that provides enhanced capabilities such as analytics and predictive intelligence. In some cases, government funding or mandates help drive this software expansion such as Next Generation 9-1-1 funding in the United States, and Public Safety LTE investment in the United States, United Kingdom, and other countries. This evolving trend provides a growth opportunity for MSI.

[0000068505-17-000005:mdna:13]
Change in Presentation

[0000068505-17-000005:mdna:14]
During the first quarter of 2017, we restructured our regions operationally combining the North America and Latin America regions into one region which is now reflected as the Americas. Accordingly, we now report net sales in the following three geographic regions: Americas, Europe, Middle East and Africa ("EMEA"), and Asia Pacific ("AP"). We have updated all periods presented to reflect this change in presentation.

[0000068505-17-000005:mdna:15]
22

[0000068505-17-000005:mdna:16]
Geographic market sales measured by the locale of the end customer as a percent of total net sales are as follows:

[0000068505-17-000005:mdna:17]
|  | Three Months Ended |  | Year Ended December 31 |
|  | April 1, 2017 |  | April 2, 2016 |  | 2016 |  | 2015 |  | 2014 |
| Americas | 68 | % |  | 71 | % |  | 68 | % |  | 71 | % |  | 70 | % |
| EMEA | 22 | % |  | 19 | % |  | 21 | % |  | 17 | % |  | 19 | % |
| AP | 10 | % |  | 10 | % |  | 11 | % |  | 12 | % |  | 11 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-17-000005:mdna:18]
First Quarter Summary

[0000068505-17-000005:mdna:19]
| • | Net sales were $1.3 billion in the first quarter of 2017, up $88 million, or 7%, from the first quarter of 2016. |

[0000068505-17-000005:mdna:20]
| • | We generated operating earnings of $176 million, or 14% of net sales, in the first quarter of 2017, compared to $100 million, or 8% of net sales, in the first quarter of 2016. Profitability increased primarily as a result of higher revenue and gross margin expansion in the Services segment. |

[0000068505-17-000005:mdna:21]
| • | We had net earnings attributable to Motorola Solutions, Inc. of $77 million, or $0.45 per diluted common share, in the first quarter of 2017, compared to $17 million, or $0.10 per diluted common share, in the first quarter of 2016. |

[0000068505-17-000005:mdna:22]
| • | We generated net cash from operating activities of $142 million during the first quarter of 2017, compared to $13 million in the first quarter of 2016. |

[0000068505-17-000005:mdna:23]
| • | We returned $255 million in capital to shareholders through dividends and share repurchases during the first quarter of 2017. |

[0000068505-17-000005:mdna:24]
| • | We completed the acquisition of Interexport, a provider of Managed & Support services for communications systems to public safety and commercial customers in Chile. We expect the acquisition to be a key component in driving growth of our Managed & Support services across Latin America and enable us to provide our comprehensive solutions to a broader customer base. |

[0000068505-17-000005:mdna:25]
| • | On May 1, 2017, we announced our intention to purchase Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers. The acquisition of Kodiak Networks reflects our strategy to build our communications and collaboration software portfolio. The acquisition is expected to be completed later this year. |

[0000068505-17-000005:mdna:26]
[same as prior period, unchanged from 0000068505-16-000031:mdna:29]

[0000068505-17-000005:mdna:27]
| • | Products: Net sales were $703 million in the first quarter of 2017, an increase of $1 million, compared to net sales of $702 million during the first quarter of 2016. On a geographic basis, net sales increased in EMEA, decreased in AP and were flat in the Americas compared to the year-ago quarter. |

[0000068505-17-000005:mdna:28]
| • | Services: Net sales were $578 million in the first quarter of 2017, an increase of $87 million, or 18% compared to net sales of $491 million in the first quarter of 2016, primarily due to the acquisition of Airwave. On a geographic basis, net sales increased in every region, compared to the year-ago quarter. |

[0000068505-17-000005:mdna:29]
23

[0000068505-17-000005:mdna:30]
[same as prior period, unchanged from 0000068505-16-000031:mdna:33]

[0000068505-17-000005:mdna:31]
|  | Three Months Ended |
| (Dollars in millions, except per share amounts) | April 1, 2017 |  | % ofSales* |  | April 2, 2016 |  | % ofSales* |
| Net sales from products | $ | 703 |  |  |  |  | $ | 702 |  |  |  |
| Net sales from services | 578 |  |  |  |  | 491 |  |  |  |
| Net sales | 1,281 |  |  |  |  | 1,193 |  |  |  |
| Costs of product sales | 347 |  |  | 49.4 | % |  | 366 |  |  | 52.1 | % |
| Costs of services sales | 364 |  |  | 63.0 | % |  | 325 |  |  | 66.2 | % |
| Costs of sales | 711 |  |  |  |  | 691 |  |  |  |
| Gross margin | 570 |  |  | 44.5 | % |  | 502 |  |  | 42.1 | % |
| Selling, general and administrative expenses | 232 |  |  | 18.1 | % |  | 234 |  |  | 19.6 | % |
| Research and development expenditures | 135 |  |  | 10.5 | % |  | 135 |  |  | 11.3 | % |
| Other charges | 27 |  |  | 2.1 | % |  | 33 |  |  | 2.8 | % |
| Operating earnings | 176 |  |  | 13.7 | % |  | 100 |  |  | 8.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net | (51 | ) |  | (4.0 | )% |  | (49 | ) |  | (4.1 | )% |
| Gains (losses) on sales of investments and businesses, net | 3 |  |  | 0.2 | % |  | (21 | ) |  | (1.8 | )% |
| Other | (8 | ) |  | (0.6 | )% |  | (8) |  |  | (0.7 | )% |
| Total other expense | (56 | ) |  | (4.4 | )% |  | (78 | ) |  | (6.5 | )% |
| Earnings before income taxes | 120 |  |  | 9.4 | % |  | 22 |  |  | 1.8 | % |
| Income tax expense | 42 |  |  | 3.3 | % |  | 5 |  |  | 0.4 | % |
| Net earnings | 78 |  |  | 6.1 | % |  | 17 |  |  | 1.4 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | — |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 77 |  |  | 6.0 | % |  | $ | 17 |  |  | 1.4 | % |
| Earnings per diluted common share | $ | 0.45 |  |  |  |  |  | $ | 0.10 |  |  |  |  |

[0000068505-17-000005:mdna:32]
* Percentages may not add due to rounding

[0000068505-17-000005:mdna:33]
24

[0000068505-17-000005:mdna:34]
Results of Operations—Three months ended April 1, 2017 compared to three months ended April 2, 2016

[0000068505-17-000005:mdna:35]
The results of operations for the first quarter of 2017 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-17-000005:mdna:36]
[same as prior period, unchanged from 0000068505-16-000031:mdna:39]

[0000068505-17-000005:mdna:37]
Net sales were $1.3 billion in the first quarter of 2017, an $88 million, or 7%, increase compared to the first quarter of 2016. The increase in net sales is reflective of growth through acquisitions and organically in EMEA and the Americas. The increase in EMEA was primarily due to growth in Services sales, primarily due to the acquisition of Airwave. The increase in the Americas was due to growth in Services sales.

[0000068505-17-000005:mdna:38]
[same as prior period, unchanged from 0000068505-16-000031:mdna:41]

[0000068505-17-000005:mdna:39]
Gross margin was $570 million, or 44.5% of net sales, in the first quarter of 2017, compared to $502 million, or 42.1% of net sales, in the first quarter of 2016. The increase in gross margin percentage was driven by an increase in margins within both the Products and Services segments.  The increase in gross margin percentage in the Products segment was driven by a favorable mix. The increase in gross margin percentage in the Services segment was driven by the expansion of our Managed & Support services portfolio, primarily due to the acquisition of Airwave, which historically has had higher margins than our legacy portfolio.

[0000068505-17-000005:mdna:40]
[same as prior period, unchanged from 0000068505-16-000031:mdna:43]

[0000068505-17-000005:mdna:41]
SG&A expenses decreased 1% to $232 million, or 18.1% of net sales, in the first quarter of 2017, compared to $234 million, or 19.6% of net sales, in the first quarter of 2016. The decrease in SG&A expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-17-000005:mdna:42]
[same as prior period, unchanged from 0000068505-16-000031:mdna:45]

[0000068505-17-000005:mdna:43]
R&D expenditures were $135 million, or 10.5% of net sales, in the first quarter of 2017 and $135 million, or 11.3% of net sales, in the first quarter of 2016. R&D expenditures have remained flat, or decreased as a percentage of sales, due to ongoing cost saving initiatives.

[0000068505-17-000005:mdna:44]
[same as prior period, unchanged from 0000068505-16-000031:mdna:47]

[0000068505-17-000005:mdna:45]
We recorded net charges of $27 million in the first quarter of 2017, compared to net charges of $33 million in the first quarter of 2016. The net Other charges in the first quarter of 2017 included: (i) $36 million of charges relating to the amortization of intangibles, (ii) $15 million of net reorganization of business charges, (iii) $9 million of charges relating to the Non-U.S. pension settlement loss, (iv) $8 million of charges related a building impairment, and (v) $1 million of transaction fees on the acquisition of Interexport, partially offset by a net gain of $42 million, related to a legal settlement. The legal settlement relates to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer.

[0000068505-17-000005:mdna:46]
The net charges in the first quarter of 2016 of $33 million included: (i) $13 million of transaction fees on the acquisition of Airwave, (ii) $13 million of charges relating to the amortization of intangibles, and (iii) $7 million of net reorganization of business charges, including a $3 million impairment of the corporate aircraft. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-17-000005:mdna:47]
[same as prior period, unchanged from 0000068505-16-000031:mdna:49]

[0000068505-17-000005:mdna:48]
Net interest expense was $51 million in the first quarter of 2017 and $49 million in the first quarter of 2016. The increase in net interest expense in the first quarter of 2017 as compared to the first quarter of 2016 was a result of lower cash balances generating less interest income.

[0000068505-17-000005:mdna:49]
[same as prior period, unchanged from 0000068505-16-000031:mdna:51]

[0000068505-17-000005:mdna:50]
Net gains on sales of investments and businesses were $3 million in the first quarter of 2017 compared to a loss of $21 million in the first quarter of 2016. The net gains in the first quarter of 2017 were related to the sales of various equity investments. The net loss in the first quarter of 2016 consisted of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities and (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $5 million of gains on the sales of equity investments.

[0000068505-17-000005:mdna:51]
[same as prior period, unchanged from 0000068505-16-000031:mdna:53]

[0000068505-17-000005:mdna:52]
Net Other expense was $8 million in both the first quarter of 2017 and 2016. The net Other expense in the first quarter of 2017 was comprised of: (i) a $7 million loss on derivative investments, (ii) a $2 million foreign currency loss, and (iii) $1 million loss on equity method investments, partially offset by $2 million of other non-operating gains. The net Other expense in the first quarter of 2016 was comprised of: (i) a $12 million loss on derivative instruments and (ii) a $10 million realized foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave, partially offset by: (i) a $13 million foreign currency gain and (ii) a $1 million gain on equity method investments.

[0000068505-17-000005:mdna:53]
[same as prior period, unchanged from 0000068505-16-000031:mdna:55]

[0000068505-17-000005:mdna:54]
We recorded $42 million of net tax expense in the first quarter of 2017, resulting in an effective tax rate of 35%, compared to $5 million of net tax expense in the first quarter of 2016, resulting in an effective tax rate of 23%. Our effective tax rate in the first quarter of 2017 was equal to the U.S. statutory tax rate of 35%. Our effective tax rate in the first quarter of 2016 was lower than the U.S. statutory tax rate of 35% primarily due to the recognition of excess tax benefits on share-based compensation in income tax expense. The effective tax rate in the first quarter of 2016 was also positively impacted by the release of unrecognized tax benefit reserves, offset by an increase in state valuation allowances and other adjustments to certain deferred tax assets.

[0000068505-17-000005:mdna:55]
Net Earnings Attributable to Motorola Solutions, Inc.

[0000068505-17-000005:mdna:56]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $77 million, or $0.45 per diluted share, in the first quarter of 2017, compared to net earnings attributable to Motorola Solutions, Inc. of $17 million, or $0.10 per diluted share, in the first quarter of 2016.

[0000068505-17-000005:mdna:57]
The increase in net earnings in the first quarter of 2017, as compared to the first quarter of 2016, was primarily driven by gross margin expansion in our Managed & Support services in EMEA, primarily due to the acquisition of Airwave, and gains on sales of investments and businesses, compared to losses in prior periods. The increase in net earnings per diluted share was driven by an increase in net earnings and lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-17-000005:mdna:58]
[same as prior period, unchanged from 0000068505-16-000031:mdna:87]

[0000068505-17-000005:mdna:59]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three months ended April 1, 2017 and April 2, 2016, as detailed in Note 11, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-17-000005:mdna:60]
[same as prior period, unchanged from 0000068505-16-000031:mdna:89]

[0000068505-17-000005:mdna:61]
For the first quarter of 2017, the segment’s net sales represented 55% of our consolidated net sales, compared to 59% of our consolidated net sales for the first quarter of 2016.

[0000068505-17-000005:mdna:62]
|  | Three Months Ended |  |  |
|  | April 1, 2017 |  | April 2, 2016 |  | % Change |
| Segment net sales | $ | 703 |  |  | $ | 702 |  |  | — | % |
| Operating earnings | 89 |  |  | 51 |  |  | 75 | % |

[0000068505-17-000005:mdna:63]
Three months ended April 1, 2017 compared to three months ended April 2, 2016

[0000068505-17-000005:mdna:64]
The segment’s net sales increased $1 million, to $703 million in the first quarter of 2017, as compared to $702 million during the first quarter of 2016. The increase in the segment's net sales was primarily driven by an increase in Devices sales in all regions. On a geographic basis, net sales increased in EMEA, decreased in AP and were flat in the Americas for the first quarter of 2017, compared to the first quarter of 2016.

[0000068505-17-000005:mdna:65]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 75% of the segment’s net sales in both the first quarter of 2017 and 2016.

[0000068505-17-000005:mdna:66]
The segment had operating earnings of $89 million in the first quarter of 2017, compared to $51 million in the first quarter of 2016. The increase in operating earnings was primarily driven by: (i) higher gross margin due to product mix, (ii) lower SG&A and R&D expenditures, and (iii) lower Other charges.

[0000068505-17-000005:mdna:67]
[same as prior period, unchanged from 0000068505-16-000031:mdna:100]

[0000068505-17-000005:mdna:68]
For the first quarter of 2017, the segment’s net sales represented 45% of our consolidated net sales, compared to 41% of our consolidated net sales for the first quarter of 2016.

[0000068505-17-000005:mdna:69]
|  | Three Months Ended |  |  |
|  | April 1, 2017 |  | April 2, 2016 |  | % Change |
| Segment net sales | $ | 578 |  |  | $ | 491 |  |  | 18 | % |
| Operating earnings | 87 |  |  | 49 |  |  | 78 | % |

[0000068505-17-000005:mdna:70]
Three months ended April 1, 2017 compared to three months ended April 2, 2016

[0000068505-17-000005:mdna:71]
The segment’s net sales increased $87 million, or 18%, to $578 million in the first quarter of 2017, as compared to $491 million in the first quarter of 2016. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both the Airwave acquisition as well as organic growth. The acquisition of Airwave provided an additional $58 million of net sales within EMEA, compared to the first quarter of 2016, while the organic Managed & Support services business grew in the Americas. On a geographic basis, net sales for the first quarter of 2017 increased in all regions, compared to the first quarter of 2016.

[0000068505-17-000005:mdna:72]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the first quarter of 2017, compared to 63% of the segment’s net sales in the first quarter of 2016.

[0000068505-17-000005:mdna:73]
The segment had operating earnings of $87 million in the first quarter of 2017, compared to $49 million in the first quarter of 2016. The increase in operating earnings in the first quarter of 2017 compared to the first quarter of 2016 was primarily driven by increased sales volume generating higher gross margin on our Managed & Support services, primarily due to the Airwave acquisition, partially offset by a slight increase in Other charges.

[0000068505-17-000005:mdna:74]
[same as prior period, unchanged from 0000068505-16-000031:mdna:111]

[0000068505-17-000005:mdna:75]
During the first quarter of 2017, we recorded net reorganization of business charges of $19 million including $15 million of charges recorded within Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $19 million were charges of $15 million related to employee separation costs and $4 million for exit costs.

[0000068505-17-000005:mdna:76]
During the first quarter of 2016, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first quarter of 2016, we recorded net reorganization of business charges of $23 million including charges of $7 million recorded in Other charges and $16 million in Cost of sales in our condensed consolidated statements of operations. Included in the $23 million were charges of: (i) $24 million related to employee separation costs, (ii) $3 million for the impairment of corporate aircraft, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-17-000005:mdna:77]
[same as prior period, unchanged from 0000068505-16-000031:mdna:116]

[0000068505-17-000005:mdna:78]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Products | $ | 13 |  |  | $ | 21 |  |
| Services | 6 |  |  | 2 |  |
|  | $ | 19 |  |  | $ | 23 |  |

[0000068505-17-000005:mdna:79]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $30 million in the first quarter of 2017 and $23 million in the first quarter of 2016. The reorganization of business accruals at April 1, 2017 were $90 million, of which $80 million relate to employee separation costs that are expected to be paid within one year and $10 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-17-000005:mdna:80]
[same as prior period, unchanged from 0000068505-16-000031:mdna:119]

[0000068505-17-000005:mdna:81]
We decreased the aggregate of our cash and cash equivalent balances by $201 million from $1.0 billion as of December 31, 2016 to $829 million as of April 1, 2017. The decrease is primarily due to: (i) $255 million of capital returned to shareholders through share repurchases and dividends paid and (ii) $121 million used for investing activities, offset by $142 million of cash generated by operating activities.

[0000068505-17-000005:mdna:82]
[same as prior period, unchanged from 0000068505-16-000031:mdna:121]

[0000068505-17-000005:mdna:83]
[same as prior period, unchanged from 0000068505-16-000031:mdna:122]

[0000068505-17-000005:mdna:84]
At April 1, 2017, $295 million of the $829 million cash and cash equivalents balance was held in the U.S. and approximately $534 million was held by the Company or its subsidiaries in other countries, with approximately $229 million held in the United Kingdom. Restricted cash was $63 million at both April 1, 2017 and December 31, 2016.

[0000068505-17-000005:mdna:85]
[same as prior period, unchanged from 0000068505-16-000031:mdna:124]

[0000068505-17-000005:mdna:86]
Net cash provided by operating activities in the first quarter of 2017 was $142 million, as compared to $13 million in the first quarter of 2016. Operating cash flows in the first quarter of 2017, as compared to the first quarter of 2016, were positively impacted by: (i) higher earnings, and (ii) higher collections, including proceeds received from a legal settlement of $52 million, offset by higher employee incentive payments.

[0000068505-17-000005:mdna:87]
[same as prior period, unchanged from 0000068505-16-000031:mdna:32]

[0000068505-17-000005:mdna:88]
[same as prior period, unchanged from 0000068505-16-000031:mdna:126]

[0000068505-17-000005:mdna:89]
Net cash used by investing activities was $121 million in the first quarter of 2017, compared to $623 million in the first quarter of 2016. The $121 million cash used in the first quarter of 2017 included: (i) $106 million cash used for acquisitions and investments and (ii) $68 million in capital expenditures, partially offset by $53 million of proceeds from sales of investments and businesses. The cash usage of $623 million in the first quarter of 2016 consisted primarily of: (i) $1.1 billion cash used for acquisitions and investments, including $1.0 billion paid for the acquisition of Airwave, and (ii) $51 million in capital expenditures, partially offset by $481 million of proceeds from the sale of investments and businesses.

[0000068505-17-000005:mdna:90]
Acquisition and Investments:  We used net cash for acquisitions and investments of $106 million during the first quarter of 2017 compared to $1.1 billion in the first quarter of 2016. The cash used during the first quarter of 2017 was used for several debt and equity investments, including the acquisition of Interexport for $55 million, net of cash acquired. The cash used during the first quarter of 2016 consisted of $1.0 billion related to the acquisition of Airwave.

[0000068505-17-000005:mdna:91]
Sales of Investments and Businesses:  We received $53 million of proceeds related to the sales of investments and businesses in the first quarter of 2017 compared to $481 million in the first quarter of 2016. The proceeds in the first quarter of 2017 primarily consisted of the sales of various debt and equity investments. The proceeds in the first quarter of 2016 were comprised of: (i) $382 million from the sale of United Kingdom treasury securities used to finance the acquisition of Airwave, (ii) $53 million from the sales of various debt and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations.

[0000068505-17-000005:mdna:92]
Capital Expenditures:  Capital expenditures increased in the first quarter of 2017 to $68 million, compared to $51 million in the first quarter of 2016. The increase in capital expenditures was primarily related to revenue-generating network expenditures, information technology spend, and facility expenditures.

[0000068505-17-000005:mdna:93]
[same as prior period, unchanged from 0000068505-16-000031:mdna:132]

[0000068505-17-000005:mdna:94]
Net cash used for financing activities was $234 million in the first quarter of 2017, compared to $577 million provided in the first quarter of 2016. Cash used for financing activities in the first quarter of 2017 was primarily comprised of: (i) $178 million used for purchases of our common stock under our share repurchase program and (ii) $77 million of cash used for the payment of dividends, partially offset by $22 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash provided by financing activities in the first quarter of 2016 was primarily comprised of: (i) $673 million of net proceeds from the issuance of the Term Loan and (ii) $40 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, partially offset by: (i) $71 million of cash used for the payment of dividends and (ii) $64 million used for purchases of our common stock under our share repurchase program.

[0000068505-17-000005:mdna:95]
Long-Term Debt:  We had outstanding long-term debt of $4.5 billion and $4.4 billion, including the current portions of $44 million and $4 million at April 1, 2017 at December 31, 2016, respectively. In the acquisition of Interexport, we assumed $92 million of debt, including a current portion of $40 million, primarily related to capital leases.

[0000068505-17-000005:mdna:96]
[same as prior period, unchanged from 0000068505-16-000031:mdna:136]

[0000068505-17-000005:mdna:97]
Share Repurchase Program: During the three months ended April 1, 2017, we paid an aggregate of $178 million, including transaction costs, to repurchase approximately 2.2 million shares at an average price of $80.82 per share. As of April 1, 2017, the Company had used approximately $12.0 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $2.0 billion of authority available for future repurchases.

[0000068505-17-000005:mdna:98]
Payment of Dividends: During the first quarter of 2017, we paid $77 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $77 million in cash dividends to holders of our common stock.

[0000068505-17-000005:mdna:99]
[same as prior period, unchanged from 0000068505-16-000031:mdna:139]

[0000068505-17-000005:mdna:100]
As of April 1, 2017, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $500 million letter of credit sub-limit with $450 million of fronting commitments, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of April 1, 2017. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first quarter of 2017.

[0000068505-17-000005:mdna:101]
Subsequent to April 1, 2017, we entered into a $2.2 billion syndicated, unsecured revolving credit facility expiring April 2022, which can be used for borrowing and letters of credit ( the "2017 Revolving Credit Facility"). The 2017 Revolving Credit Facility has a $500 million letter of credit sub-limit. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. Under the 2017 Revolving Credit Facility, we must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Revolving Credit Facility.

[0000068505-17-000005:mdna:102]
[same as prior period, unchanged from 0000068505-16-000031:mdna:141]

[0000068505-17-000005:mdna:103]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $186 million at April 1, 2017, compared to $125 million at December 31, 2016.

[0000068505-17-000005:mdna:104]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $30 million at April 1, 2017, compared to $49 million at December 31, 2016.

[0000068505-17-000005:mdna:105]
[same as prior period, unchanged from 0000068505-16-000031:mdna:144]

[0000068505-17-000005:mdna:106]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended April 1, 2017 and April 2, 2016:

[0000068505-17-000005:mdna:107]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Accounts receivable sales proceeds | $ | 19 |  |  | $ | 2 |  |
| Long-term receivables sales proceeds | 46 |  |  | 64 |  |
| Total proceeds from sales of accounts receivable | $ | 65 |  |  | $ | 66 |  |

[0000068505-17-000005:mdna:108]
At April 1, 2017, the Company had retained servicing obligations for $768 million of long-term receivables, compared to $774 million of long-term receivables at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000005:mdna:109]
Other Contingencies

[0000068505-17-000005:mdna:110]
[same as prior period, unchanged from 0000068505-16-000031:mdna:150]

[0000068505-17-000005:mdna:111]
[same as prior period, unchanged from 0000068505-16-000031:mdna:151]

[0000068505-17-000005:mdna:112]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at April 1, 2017.

[0000068505-17-000005:mdna:113]
[same as prior period, unchanged from 0000068505-16-000031:mdna:153]

[0000068505-17-000005:mdna:114]
[same as prior period, unchanged from 0000068505-16-000031:mdna:154]

[0000068505-17-000005:mdna:115]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods or services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as our annual reporting period begins after December 15, 2017.

[0000068505-17-000005:mdna:116]
We continue to analyze the impact of the new standard on our financial results based on an inventory of our current contracts with customers. We have obtained an understanding of the new standard and currently believe that we will retain much of the same accounting treatment as used to recognize revenue under current standards. Revenue on a significant portion of our contracts is currently recognized under percentage of completion accounting, applying a cost-to-cost method. We believe under the new standard, we will continue to recognize revenue on these contracts using a cost-to-cost method based on the

[0000068505-17-000005:mdna:117]
continuous transfer of control to the customer over time. Transfer of control in our contracts is demonstrated by creating a customized asset for our customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000005:mdna:118]
In addition, we understand that the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by current software revenue recognition rules. While we may have contracts which fall under these accounting rules in the current standard, we have not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, we do not anticipate a significant acceleration of revenue upon applying the new standard to our current contracts under these fact patterns.

[0000068505-17-000005:mdna:119]
We continue to evaluate the impact of ASU No. 2014-09 on our financial results and prepare for the adoption of the standard on January 1, 2018, including readying our internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and the impact on our consolidated financial statements and footnote disclosures, and will continue to provide enhanced disclosures as we continue our assessment.

[0000068505-17-000005:mdna:120]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us January 1, 2019 and interim periods within that reporting period.  The ASU requires a modified retrospective method upon adoption. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000005:mdna:121]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for us January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, we do not anticipate significant changes to our existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000005:mdna:122]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. We are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000005:mdna:123]
In March 2017, the FASB issued ASU 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. Upon adoption, we plan to update the presentation of net periodic cost (benefit) accordingly, noting all components of our net periodic cost (benefit), as reflected in Note 6 of our Condensed Consolidated Financial Statements herein and as disclosed in Note 7 of our Form 10-K for the year ended December 31, 2016, with the exception of the service cost component, will be presented outside of operating earnings.
