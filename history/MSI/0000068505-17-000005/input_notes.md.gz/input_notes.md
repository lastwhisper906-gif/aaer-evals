# MSI notes — 0000068505-17-000005


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-17-000005:notes:1]
[same as prior period, unchanged from 0000068505-16-000031:notes:1]

[0000068505-17-000005:notes:2]
| April 1, 2017 |  |
| Available-for-sale securities: |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 50 |  |
| Corporate bonds | 5 |  |
|  | 55 |  |
| Other investments | 213 |  |
| Equity method investments | 14 |  |
|  | $ | 282 |  |
| Less: current portion of available-for-sale securities | 45 |  |
|  | $ | 237 |  |

[0000068505-17-000005:notes:3]
| December 31, 2016 |  |
| Available-for-sale securities: |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 51 |  |
| Corporate bonds | 5 |  |
|  | 56 |  |
| Other investments | 211 |  |
| Equity method investments | 17 |  |
|  | $ | 284 |  |
| Less: current portion of available-for-sale securities | 46 |  |
|  | $ | 238 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-17-000005:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 1, 2017 and December 31, 2016 were as follows:

[0000068505-17-000005:notes:5]
| April 1, 2017 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |
| Foreign exchange derivative contracts |  | $ | 2 |  |  | $ | 2 |  |
| Available-for-sale securities: |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations |  | $ | 50 |  |  | $ | 50 |  |
| Corporate bonds |  | 5 |  |  | 5 |  |
| Liabilities: |  |  |  |  |
| Foreign exchange derivative contracts |  | $ | 3 |  |  | $ | 3 |  |

[0000068505-17-000005:notes:6]
| December 31, 2016 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |
| Foreign exchange derivative contracts |  | $ | 9 |  |  | $ | 9 |  |
| Available-for-sale securities: |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations |  | 51 |  |  | 51 |  |
| Corporate bonds |  | 5 |  |  | 5 |  |
| Liabilities: |  |  |  |  |
| Foreign exchange derivative contracts |  | $ | 32 |  |  | $ | 32 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-17-000005:notes:7]
[same as prior period, unchanged from 0000068505-16-000031:notes:7]

[0000068505-17-000005:notes:8]
[same as prior period, unchanged from 0000068505-16-000031:notes:8]

[0000068505-17-000005:notes:9]
[same as prior period, unchanged from 0000068505-16-000031:notes:9]

[0000068505-17-000005:notes:10]
|  | April 1, 2017 |  | December 31, 2016 |
| Long-term receivables | 46 |  |  | 63 |  |
| Less current portion | (16 | ) |  | (14 | ) |
| Non-current long-term receivables | $ | 30 |  |  | $ | 49 |  |

[0000068505-17-000005:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $186 million at April 1, 2017, compared to $125 million at December 31, 2016.

[0000068505-17-000005:notes:12]
[same as prior period, unchanged from 0000068505-16-000031:notes:12]

[0000068505-17-000005:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended April 1, 2017 and April 2, 2016:

[0000068505-17-000005:notes:14]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Accounts receivable sales proceeds | $ | 19 |  |  | $ | 2 |  |
| Long-term receivables sales proceeds | 46 |  |  | 64 |  |
| Total proceeds from receivable sales | $ | 65 |  |  | $ | 66 |  |

[0000068505-17-000005:notes:15]
At April 1, 2017, the Company had retained servicing obligations for $768 million of long-term receivables, compared to $774 million of long-term receivables at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000005:notes:16]
[same as prior period, unchanged from 0000068505-16-000031:notes:16]

[0000068505-17-000005:notes:17]
An aging analysis of financing receivables at April 1, 2017 and December 31, 2016 is as follows:

[0000068505-17-000005:notes:18]
| April 1, 2017 | TotalLong-termReceivable |  | Past Due Under 90 Days |
| Municipal leases secured tax exempt | $ | 14 |  |  | $ | 1 |  |
| Commercial loans and leases secured | 32 |  |  | — |  |
| Long-term receivables, including current portion | $ | 46 |  |  | $ | 1 |  |

[0000068505-17-000005:notes:19]
| December 31, 2016 | TotalLong-termReceivable |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 20 |  |  | $ | — |  |
| Commercial loans and leases secured | 43 |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 63 |  |  | $ | 2 |  |


## msi:OtherChargesTableTextBlock

[0000068505-17-000005:notes:20]
[same as prior period, unchanged from 0000068505-16-000031:notes:20]

[0000068505-17-000005:notes:21]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Other charges: |  |  |  |
| Intangibles amortization | $ | 36 |  |  | $ | 13 |  |
| Reorganization of business | 15 |  |  | 7 |  |
| Building impairment | 8 |  |  | — |  |
| Non-U.S. pension settlement loss | 9 |  |  | — |  |
| Gain on legal settlement | (42 | ) |  | — |  |
| Acquisition-related transaction fees | 1 |  |  | 13 |  |
|  | $ | 27 |  |  | $ | 33 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-17-000005:notes:22]
[same as prior period, unchanged from 0000068505-16-000031:notes:22]

[0000068505-17-000005:notes:23]
| April 1, 2017 | Three Months Ended |
| Products | $ | 13 |  |
| Services | 6 |  |
|  | $ | 19 |  |

[0000068505-17-000005:notes:24]
| April 2, 2016 | Three Months Ended |
| Products | $ | 21 |  |
| Services | 2 |  |
|  | $ | 23 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-17-000005:notes:25]
[same as prior period, unchanged from 0000068505-16-000031:notes:25]

[0000068505-17-000005:notes:26]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Share-based compensation expense included in: |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |
| Selling, general and administrative expenses | 11 |  |  | 12 |  |
| Research and development expenditures | 4 |  |  | 3 |  |
| Share-based compensation expense included in Operating earnings | 17 |  |  | 17 |  |
| Tax benefit | 6 |  |  | 5 |  |
| Share-based compensation expense, net of tax | $ | 11 |  |  | $ | 12 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |
| Decrease in diluted earnings per share | $ | (0.06 | ) |  | $ | (0.07 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-17-000005:notes:27]
[same as prior period, unchanged from 0000068505-16-000031:notes:27]

[0000068505-17-000005:notes:28]
|  | April 1, 2017 |  | December 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 178 |  |  | $ | 69 |  |  | $ | 178 |  |  | $ | 63 |  |
| Services | 899 |  |  | 130 |  |  | 805 |  |  | 99 |  |
|  | $ | 1,077 |  |  | $ | 199 |  |  | $ | 983 |  |  | $ | 162 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-17-000005:notes:29]
[same as prior period, unchanged from 0000068505-16-000031:notes:29]

[0000068505-17-000005:notes:30]
|  | April 1, 2017 |  | December 31, 2016 |
| Defined benefit plans | $ | 1,795 |  |  | $ | 1,799 |  |
| Deferred revenue | 115 |  |  | 115 |  |
| Unrecognized tax benefits | 39 |  |  | 39 |  |
| Deferred income taxes | 140 |  |  | 121 |  |
| Deferred consideration (Note 13) | 74 |  |  | 72 |  |
| Other | 215 |  |  | 209 |  |
|  | $ | 2,378 |  |  | $ | 2,355 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-17-000005:notes:31]
[same as prior period, unchanged from 0000068505-16-000031:notes:31]

[0000068505-17-000005:notes:32]
[same as prior period, unchanged from 0000068505-16-000031:notes:32]

[0000068505-17-000005:notes:33]
[same as prior period, unchanged from 0000068505-16-000031:notes:33]

[0000068505-17-000005:notes:34]
During the three months ended April 1, 2017, the Company recognized a net gain of $42 million related to a legal settlement. The legal settlement relates to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer. The net gain of $42 million was based on $52 million of proceeds received, net $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-17-000005:notes:35]
[same as prior period, unchanged from 0000068505-16-000031:notes:34]

[0000068505-17-000005:notes:36]
[same as prior period, unchanged from 0000068505-16-000031:notes:35]

[0000068505-17-000005:notes:37]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Interest income (expense), net: |  |  |  |
| Interest expense | $ | (54 | ) |  | $ | (53 | ) |
| Interest income | 3 |  |  | 4 |  |
|  | $ | (51 | ) |  | $ | (49 | ) |
| Other: |  |  |  |
| Foreign currency gain (loss) | (2 | ) |  | 13 |  |
| Loss on derivative instruments | (7 | ) |  | (12 | ) |
| Gains (losses) on equity method investments | (1 | ) |  | 1 |  |
| Realized foreign currency loss on acquisition | — |  |  | (10 | ) |
| Other | 2 |  |  | — |  |
|  | $ | (8 | ) |  | $ | (8 | ) |

[0000068505-17-000005:notes:38]
[same as prior period, unchanged from 0000068505-16-000031:notes:37]

[0000068505-17-000005:notes:39]
[same as prior period, unchanged from 0000068505-16-000031:notes:38]

[0000068505-17-000005:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
| Three Months Ended | April 1, 2017 |  | April 2, 2016 |
| Basic earnings per common share: |  |  |  |
| Earnings | $ | 77 |  |  | $ | 17 |  |
| Weighted average common shares outstanding | 164.2 |  |  | 174.5 |  |
| Per share amount | $ | 0.47 |  |  | $ | 0.10 |  |
| Diluted earnings per common share: |  |  |  |
| Earnings | $ | 77 |  |  | $ | 17 |  |
| Weighted average common shares outstanding | 164.2 |  |  | 174.5 |  |
| Add effect of dilutive securities: |  |  |  |
| Share-based awards | 3.3 |  |  | 2.5 |  |
| Senior Convertible Notes | 2.4 |  |  | — |  |
| Diluted weighted average common shares outstanding | 169.9 |  |  | 177.0 |  |
| Per share amount | $ | 0.45 |  |  | $ | 0.10 |  |

[0000068505-17-000005:notes:41]
In the computation of diluted earnings per common share for the three months ended April 1, 2017, the assumed exercise of 2.7 million options, including 2.3 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive. For the three months ended April 2, 2016, the assumed exercise of 4.0 million options, including 2.1 million subject to market-based contingent stock agreements, and the assumed vesting of 0.6 million restricted stock units ("RSUs") were excluded because their inclusion would have been antidilutive.

[0000068505-17-000005:notes:42]
[same as prior period, unchanged from 0000068505-16-000031:notes:43]

[0000068505-17-000005:notes:43]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the three months ended April 1, 2017, the dilutive impact of the Senior Convertible Notes was 2.4 million shares.

[0000068505-17-000005:notes:44]
[same as prior period, unchanged from 0000068505-16-000031:notes:45]

[0000068505-17-000005:notes:45]
[same as prior period, unchanged from 0000068505-16-000031:notes:48]

[0000068505-17-000005:notes:46]
[same as prior period, unchanged from 0000068505-16-000031:notes:49]

[0000068505-17-000005:notes:47]
|  | April 1, 2017 |  | December 31, 2016 |
| Accounts receivable | $ | 1,109 |  |  | $ | 1,454 |  |
| Less allowance for doubtful accounts | (39 | ) |  | (44 | ) |
|  | $ | 1,070 |  |  | $ | 1,410 |  |

[0000068505-17-000005:notes:48]
[same as prior period, unchanged from 0000068505-16-000031:notes:51]

[0000068505-17-000005:notes:49]
[same as prior period, unchanged from 0000068505-16-000031:notes:52]

[0000068505-17-000005:notes:50]
|  | April 1, 2017 |  | December 31, 2016 |
| Finished goods | $ | 175 |  |  | $ | 151 |  |
| Work-in-process and production materials | 298 |  |  | 253 |  |
|  | 473 |  |  | 404 |  |
| Less inventory reserves | (128 | ) |  | (131 | ) |
|  | $ | 345 |  |  | $ | 273 |  |

[0000068505-17-000005:notes:51]
[same as prior period, unchanged from 0000068505-16-000031:notes:54]

[0000068505-17-000005:notes:52]
[same as prior period, unchanged from 0000068505-16-000031:notes:55]

[0000068505-17-000005:notes:53]
|  | April 1, 2017 |  | December 31, 2016 |
| Available-for-sale securities | $ | 45 |  |  | $ | 46 |  |
| Costs and earnings in excess of billings | 550 |  |  | 495 |  |
| Tax-related refunds receivable | 94 |  |  | 90 |  |
| Other | 140 |  |  | 124 |  |
|  | $ | 829 |  |  | $ | 755 |  |

[0000068505-17-000005:notes:54]
[same as prior period, unchanged from 0000068505-16-000031:notes:57]

[0000068505-17-000005:notes:55]
[same as prior period, unchanged from 0000068505-16-000031:notes:58]

[0000068505-17-000005:notes:56]
|  | April 1, 2017 |  | December 31, 2016 |
| Land | $ | 12 |  |  | $ | 12 |  |
| Building | 391 |  |  | 306 |  |
| Machinery and equipment | 1,924 |  |  | 1,921 |  |
|  | 2,327 |  |  | 2,239 |  |
| Less accumulated depreciation | (1,507 | ) |  | (1,450 | ) |
|  | $ | 820 |  |  | $ | 789 |  |

[0000068505-17-000005:notes:57]
Depreciation expense for the three months ended April 1, 2017 and April 2, 2016 was $44 million and $49 million, respectively.

[0000068505-17-000005:notes:58]
On February 1, 2016, the Company completed the sale of its Penang, Malaysia manufacturing operations, including the land, building, equipment, and inventory, as well as the transfer of employees to a contract manufacturer. During the three months ended April 2, 2016, the Company incurred a loss of $7 million on the sale of its Penang, Malaysia facility and manufacturing operations, which is included within Gains (losses) on sales of investments and businesses, net.

[0000068505-17-000005:notes:59]
The Company acquired property, plant and equipment, including network-related assets, with a fair value of $245 million in the acquisition of Airwave on February 19, 2016 and $70 million in the acquisition of Quorum II S.A. and its three subsidiaries - Interexport Telecomunicaciones Y Servicios S.A., Interexport Telecomunicaciones E Integracion De Sistemas S.A. and Mobilink S.A. (collectively "Interexport") on March 13, 2017. See discussion in Note 13.

[0000068505-17-000005:notes:60]
[same as prior period, unchanged from 0000068505-16-000031:notes:65]

[0000068505-17-000005:notes:61]
Cost basis was equal to fair value for available-for-sale securities at April 1, 2017 and December 31, 2016. Other investments include strategic investments in technology-driven startup companies recorded at cost of $77 million and $76 million, and insurance policies recorded at their cash surrender value of $136 million and $135 million, at April 1, 2017 and December 31, 2016.

[0000068505-17-000005:notes:62]
The Company recognized gains on the sale of investments and businesses of $3 million in the first quarter of 2017. The Company recognized losses on the sale of investments and businesses of $21 million in the first quarter of 2016, primarily driven by a realized loss of $19 million associated with the sale of United Kingdom treasury securities.

[0000068505-17-000005:notes:63]
[same as prior period, unchanged from 0000068505-16-000031:notes:67]

[0000068505-17-000005:notes:64]
[same as prior period, unchanged from 0000068505-16-000031:notes:68]

[0000068505-17-000005:notes:65]
|  | April 1, 2017 |  | December 31, 2016 |
| Non-current long-term receivables | 30 |  |  | 49 |  |
| Defined benefit plan assets | 118 |  |  | 102 |  |
| Other | 49 |  |  | 49 |  |
|  | $ | 197 |  |  | 200 |  |

[0000068505-17-000005:notes:66]
[same as prior period, unchanged from 0000068505-16-000031:notes:70]

[0000068505-17-000005:notes:67]
[same as prior period, unchanged from 0000068505-16-000031:notes:71]

[0000068505-17-000005:notes:68]
|  | April 1, 2017 |  | December 31, 2016 |
| Deferred revenue | $ | 473 |  |  | $ | 439 |  |
| Compensation | 176 |  |  | 250 |  |
| Billings in excess of costs and earnings | 391 |  |  | 434 |  |
| Tax liabilities | 93 |  |  | 111 |  |
| Dividend payable | 77 |  |  | 77 |  |
| Trade liabilities | 154 |  |  | 180 |  |
| Other | 544 |  |  | 620 |  |
|  | $ | 1,908 |  |  | $ | 2,111 |  |

[0000068505-17-000005:notes:69]
[same as prior period, unchanged from 0000068505-16-000031:notes:73]

[0000068505-17-000005:notes:70]
[same as prior period, unchanged from 0000068505-16-000031:notes:74]

[0000068505-17-000005:notes:71]
[same as prior period, unchanged from 0000068505-16-000031:notes:75]

[0000068505-17-000005:notes:72]
During the three months ended April 1, 2017, the Company paid an aggregate of $178 million, including transaction costs, to repurchase approximately 2.2 million shares at an average price of $80.82 per share. As of April 1, 2017, the Company had used approximately $12.0 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $2.0 billion of authority available for future repurchases.

[0000068505-17-000005:notes:73]
Payment of Dividends: During the three months ended April 1, 2017 and April 2, 2016, the Company paid $77 million and $71 million, respectively, in cash dividends to holders of its common stock.

[0000068505-17-000005:notes:74]
[same as prior period, unchanged from 0000068505-16-000031:notes:78]

[0000068505-17-000005:notes:75]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three months ended April 1, 2017 and April 2, 2016:

[0000068505-17-000005:notes:76]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Foreign Currency Translation Adjustments: |  |  |  |
| Balance at beginning of period | $ | (494 | ) |  | $ | (266 | ) |
| Other comprehensive income before reclassification adjustment | 37 |  |  | 14 |  |
| Tax expense | (3 | ) |  | (1 | ) |
| Other comprehensive income, net of tax | 34 |  |  | 13 |  |
| Balance at end of period | $ | (460 | ) |  | $ | (253 | ) |
| Available-for-Sale Securities: |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | (3 | ) |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net | — |  |  | 6 |  |
| Tax benefit | — |  |  | (2 | ) |
| Other comprehensive income, net of tax | — |  |  | 4 |  |
| Balance at end of period | $ | — |  |  | $ | 1 |  |
| Defined Benefit Plans: |  |  |  |
| Balance at beginning of period | (1,823 | ) |  | (1,597 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 16 |  |  | 10 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (4 | ) |  | (5 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other charges | 9 |  |  | — |  |
| Tax benefit | (2 | ) |  | (1 | ) |
| Other comprehensive income, net of tax | 19 |  |  | 4 |  |
| Balance at end of period | $ | (1,804 | ) |  | $ | (1,593 | ) |
| Total Accumulated other comprehensive loss | $ | (2,264 | ) |  | $ | (1,845 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-17-000005:notes:77]
The condensed consolidated financial statements as of April 1, 2017 and for the three months ended April 1, 2017 and April 2, 2016 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-17-000005:notes:78]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2016. The results of operations for the three months ended April 1, 2017 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-17-000005:notes:79]
[same as prior period, unchanged from 0000068505-16-000031:notes:83]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-17-000005:notes:80]
Commitments and Contingencies

[0000068505-17-000005:notes:81]
Legal Matters

[0000068505-17-000005:notes:82]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-17-000005:notes:83]
Other Indemnifications

[0000068505-17-000005:notes:84]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-17-000005:notes:85]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at April 1, 2017.

[0000068505-17-000005:notes:86]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-17-000005:notes:87]
Debt and Credit Facilities

[0000068505-17-000005:notes:88]
As of April 1, 2017, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $500 million letter of credit sub-limit with $450 million of fronting commitments, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 1, 2017. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the three months ended April 1, 2017.

[0000068505-17-000005:notes:89]
Subsequent to April 1, 2017, the Company entered into a $2.2 billion syndicated, unsecured revolving credit facility expiring April 2022, which can be used for borrowing and letters of credit (the "2017 Revolving Credit Facility"). The 2017 Revolving Credit Facility has a $500 million letter of credit sub-limit. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. Under the 2017 Revolving Credit Facility, the Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Revolving Credit Facility.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-17-000005:notes:90]
[same as prior period, unchanged from 0000068505-16-000031:notes:97]

[0000068505-17-000005:notes:91]
[same as prior period, unchanged from 0000068505-16-000031:notes:98]

[0000068505-17-000005:notes:92]
As of April 1, 2017, the Company had outstanding foreign exchange contracts with notional amounts totaling $692 million, compared to $717 million outstanding at December 31, 2016. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-17-000005:notes:93]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 1, 2017, and the corresponding positions as of December 31, 2016:

[0000068505-17-000005:notes:94]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 1, 2017 |  | December 31, 2016 |
| British Pound | $ | 172 |  |  | $ | 246 |  |
| Euro | 158 |  |  | 122 |  |
| Chinese Renminbi | (120 | ) |  | (108 | ) |
| Brazilian Real | (54 | ) |  | (56 | ) |
| Australian Dollar | (42 | ) |  | (51 | ) |

[0000068505-17-000005:notes:95]
During the three months ended April 1, 2017, the Company entered into forward contracts to sell £50 million, expiring in December 2017. The forward contracts have been designated as a net investment hedge which is in place to partially hedge the Company's British Pound foreign currency exposure on its net investment in Airwave Solutions Limited for the purpose of future cash repatriations. The gains and losses on the Company's net investment in pound-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive loss. As of April 1, 2017, the fair value of the derivative contract was de minimus.

[0000068505-17-000005:notes:96]
[same as prior period, unchanged from 0000068505-16-000031:notes:102]

[0000068505-17-000005:notes:97]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swaps liability was de minimus at both April 1, 2017 and December 31, 2016.

[0000068505-17-000005:notes:98]
[same as prior period, unchanged from 0000068505-16-000031:notes:105]

[0000068505-17-000005:notes:99]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 1, 2017, all of the counterparties have investment grade credit ratings. As of April 1, 2017, the Company had $2 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-17-000005:notes:100]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of April 1, 2017 and December 31, 2016:

[0000068505-17-000005:notes:101]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| April 1, 2017 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 2 |  |  | Other current assets |  | $ | 3 |  |  | Accrued liabilities |

[0000068505-17-000005:notes:102]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2016 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 9 |  |  | Other current assets |  | $ | 32 |  |  | Accrued liabilities |

[0000068505-17-000005:notes:103]
The fair value of derivatives designated as hedging instruments at April 1, 2017 was de minimus.

[0000068505-17-000005:notes:104]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated statements of operations for the three months ended April 1, 2017 and April 2, 2016:

[0000068505-17-000005:notes:105]
|  | Three Months Ended |  | Statements ofOperations Location |
| Loss on Derivative Instruments | April 1, 2017 |  | April 2, 2016 |  |
| Foreign exchange contracts | (7 | ) |  | (12 | ) |  | Other income (expense) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-17-000005:notes:106]
[same as prior period, unchanged from 0000068505-16-000031:notes:113]

[0000068505-17-000005:notes:107]
During the three months ended April 1, 2017, the Company granted 0.5 million RSUs and market stock units ("MSUs") with an aggregate grant-date fair value of $42 million and 0.9 million stock options and performance options ("POs") with an aggregate grant-date fair value of $13 million. Share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-17-000005:notes:108]
[same as prior period, unchanged from 0000068505-16-000031:notes:118]

[0000068505-17-000005:notes:109]
[same as prior period, unchanged from 0000068505-16-000031:notes:119]

[0000068505-17-000005:notes:110]
[same as prior period, unchanged from 0000068505-16-000031:notes:120]

[0000068505-17-000005:notes:111]
[same as prior period, unchanged from 0000068505-16-000031:notes:121]

[0000068505-17-000005:notes:112]
[same as prior period, unchanged from 0000068505-16-000031:notes:122]

[0000068505-17-000005:notes:113]
[same as prior period, unchanged from 0000068505-16-000031:notes:123]

[0000068505-17-000005:notes:114]
The Company had no Level 3 holdings as of April 1, 2017 or December 31, 2016.

[0000068505-17-000005:notes:115]
At April 1, 2017 and December 31, 2016, the Company had $299 million and $309 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-17-000005:notes:116]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at April 1, 2017 and December 31, 2016 was $4.5 billion (Level 2).

[0000068505-17-000005:notes:117]
[same as prior period, unchanged from 0000068505-16-000031:notes:127]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-17-000005:notes:118]
[same as prior period, unchanged from 0000068505-16-000031:notes:128]

[0000068505-17-000005:notes:119]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company's consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-17-000005:notes:120]
Guardian Digital Communications Limited

[0000068505-17-000005:notes:121]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited (collectively referred to as "Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of Airwave was acquired for the sum of £1, after which the Company invested into Airwave £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018.

[0000068505-17-000005:notes:122]
The acquisition of Airwave enables the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers.

[0000068505-17-000005:notes:123]
The acquisition of Airwave has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value.

[0000068505-17-000005:notes:124]
The total consideration for the acquisition of Airwave was approximately $1.1 billion, consisting of cash payments of $1.0 billion, net of cash acquired, and deferred consideration valued at fair value on the date of the acquisition of $82 million. The fair value of deferred consideration has been determined based on its net present value, calculated using a discount rate of 4.2%, which is reflective of the credit standing of the combined entity. The following table summarizes fair values of assets acquired and liabilities assumed as of the February 19, 2016 acquisition date:

[0000068505-17-000005:notes:125]
| Cash |  | $ | 86 |  |
| Accounts receivable, net |  | 55 |  |
| Other current assets |  | 36 |  |
| Property, plant and equipment, net |  | 245 |  |
| Deferred income taxes |  | 82 |  |
| Accounts payable |  | (18 | ) |
| Accrued liabilities |  | (181 | ) |
| Other liabilities |  | (289 | ) |
| Goodwill |  | 191 |  |
| Intangible assets |  | 875 |  |
| Total consideration |  | $ | 1,082 |  |
| Net present value of deferred consideration payment to former owners |  | (82 | ) |
| Net cash consideration at purchase |  | $ | 1,000 |  |

[0000068505-17-000005:notes:126]
Acquired intangible assets consist of $846 million of customer relationships and $29 million of trade names. All intangibles have a useful life of seven years, over which amortization expense will be recognized on a straight line basis. Acquired goodwill of $191 million is calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. Goodwill is not deductible for tax purposes.

[0000068505-17-000005:notes:127]
Other Acquisitions

[0000068505-17-000005:notes:128]
On May 1, 2017, the Company announced its intention to purchase Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers. The acquisition of Kodiak Networks reflects Motorola Solutions' strategy to build its communications and collaboration software portfolio. The acquisition is expected to be completed later this year.

[0000068505-17-000005:notes:129]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides Managed & Support services for communications systems to public safety and commercial customers in Chile, for a gross purchase price of $98 billion Chilean Pesos, or approximately $147 million U.S. Dollars based on cash proceeds of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $3 million of goodwill, $68 million of identifiable intangible assets, and $70 million of acquired property, plant and equipment and $6 million of net other tangible assets. The estimated identifiable intangible assets were classified as $63 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years. As of April 1, 2017, the purchase accounting is not yet complete and as such the final allocation between identifiable intangibles and goodwill may be subject to change.

[0000068505-17-000005:notes:130]
On November 10, 2016, the Company completed the acquisition of Spillman Technologies, Inc., a provider of comprehensive law enforcement and public safety software solutions, for a gross purchase price of $217 million. As a result of the acquisition, the Company recognized $140 million of goodwill, $115 million of identifiable intangible assets, and $38 million of acquired liabilities. The identifiable intangible assets were classified as $49 million of completed technology, $59 million of customer-related intangibles, and $7 million of other intangibles and will be amortized over a period of seven to ten years.

[0000068505-17-000005:notes:131]
During the year ended December 31, 2016, the Company completed the acquisition of several software and service-based providers for a total of $30 million, recognizing $6 million of goodwill, $15 million of intangible assets, and $9 million of tangible net assets related to these acquisitions. Under the preliminary purchase accounting, the $15 million of identifiable intangible assets were classified as: (i) $7 million of completed technology and (ii) $8 million of customer-related intangibles and will be amortized over a period of five years. During the first quarter of 2017, the Company completed the purchase accounting and recorded an additional $11 million completed technology intangible asset that will be amortized over a period of eight years.

[0000068505-17-000005:notes:132]
[same as prior period, unchanged from 0000068505-16-000031:notes:145]

[0000068505-17-000005:notes:133]
[same as prior period, unchanged from 0000068505-16-000031:notes:146]

[0000068505-17-000005:notes:134]
|  | April 1, 2017 |  | December 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 128 |  |  | $ | 42 |  |  | $ | 116 |  |  | $ | 38 |  |
| Patents | 8 |  |  | 6 |  |  | 8 |  |  | 6 |  |
| Customer-related | 888 |  |  | 133 |  |  | 810 |  |  | 101 |  |
| Other intangibles | 53 |  |  | 18 |  |  | 49 |  |  | 17 |  |
|  | $ | 1,077 |  |  | $ | 199 |  |  | $ | 983 |  |  | $ | 162 |  |

[0000068505-17-000005:notes:135]
Amortization expense on intangible assets was $36 million for the three months ended April 1, 2017 and $13 million for the three months ended April 2, 2016. The increase in amortization expense is primarily due to the acquisition of Airwave and Spillman Technologies, Inc. As of April 1, 2017, annual amortization expense is estimated to be $134 million in 2017, $143 million in 2018, $142 million in 2019, $139 million in 2020, $138 million in 2021, and $135 million in 2022.

[0000068505-17-000005:notes:136]
[same as prior period, unchanged from 0000068505-16-000031:notes:149]

[0000068505-17-000005:notes:137]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2017 to April 1, 2017:

[0000068505-17-000005:notes:138]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2017 |  |  |  |  |  |
| Goodwill, net of impairment losses | $ | 316 |  |  | $ | 412 |  |  | $ | 728 |  |
| Goodwill acquired | — |  |  | 3 |  |  | 3 |  |
| Purchase accounting adjustments | 1 |  |  | 1 |  |  | 2 |  |
| Foreign currency | — |  |  | 4 |  |  | 4 |  |
| Balance as of April 1, 2017 |  |  |  |  |  |
| Goodwill, net of impairment losses | $ | 317 |  |  | $ | 420 |  |  | $ | 737 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-17-000005:notes:139]
[same as prior period, unchanged from 0000068505-16-000031:notes:152]

[0000068505-17-000005:notes:140]
[same as prior period, unchanged from 0000068505-16-000031:notes:153]

[0000068505-17-000005:notes:141]
[same as prior period, unchanged from 0000068505-16-000031:notes:154]

[0000068505-17-000005:notes:142]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Net earnings before income taxes | $ | 120 |  |  | $ | 22 |  |
| Income tax expense | 42 |  |  | 5 |  |
| Effective tax rate | 35 | % |  | 23 | % |

[0000068505-17-000005:notes:143]
The Company recorded $42 million of net tax expense in the first quarter of 2017 resulting in an effective tax rate of 35%, compared to $5 million of net tax expense in the first quarter of 2016 resulting in an effective tax rate of 23%. The effective tax rate in the first quarter of 2017 was equal to the U.S. statutory tax rate of 35%. The effective tax rate in the first quarter of 2016 was lower than the U.S. statutory tax rate of 35% primarily due to the recognition of excess tax benefits on share-based compensation in income tax expense. The effective tax rate in the first quarter of 2016 was also positively impacted by the release of unrecognized tax benefit reserves, offset by increases in state valuation allowances and other adjustments to certain deferred tax assets.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-17-000005:notes:144]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

[0000068505-17-000005:notes:145]
The Company has continued to analyze the impact of the new standard on its financial results based on an inventory of the Company's current contracts with customers. The Company has obtained an understanding of the new standard and currently believes that it will retain much of the same accounting treatment as used to recognize revenue under current standards. Revenue on a significant portion of its contracts is currently recognized under percentage of completion accounting, applying a cost-to-cost method. Under the new standard, the Company will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in the Company's contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000005:notes:146]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While the Company may have contracts which fall under these rules in the current standard, it has not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, the Company does not anticipate a significant acceleration of revenue upon applying the new standard to its current contracts under these fact patterns.

[0000068505-17-000005:notes:147]
The Company continues to evaluate the impact of ASU No. 2014-09 on our financial results and prepare for the adoption of the standard on January 1, 2018, including readying its internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and the impact on our consolidated financial statements and footnote disclosures, and will provide enhanced disclosures as we continue our assessment.

[0000068505-17-000005:notes:148]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000005:notes:149]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000005:notes:150]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000005:notes:151]
In March 2017, the FASB issued ASU 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. Upon adoption, the Company plans to update the presentation of net periodic cost (benefit) accordingly, noting all components of the Company's net periodic cost (benefit), as reflected in Note 6 of the Company's Condensed Consolidated Financial Statements and as disclosed in Note 7 of the Company's Form 10-K for the year ended December 31, 2016, with the exception of the service cost component, will be presented outside of operating earnings.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-17-000005:notes:152]
[same as prior period, unchanged from 0000068505-16-000031:notes:164]

[0000068505-17-000005:notes:153]
[same as prior period, unchanged from 0000068505-16-000031:notes:167]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-17-000005:notes:154]
[same as prior period, unchanged from 0000068505-16-000031:notes:168]

[0000068505-17-000005:notes:155]
[same as prior period, unchanged from 0000068505-16-000031:notes:169]

[0000068505-17-000005:notes:156]
[same as prior period, unchanged from 0000068505-16-000031:notes:170]

[0000068505-17-000005:notes:157]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 46 |  |  | 10 |  |  | 14 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (58 | ) |  | (55 | ) |  | (23 | ) |  | (24 | ) |  | (3 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 11 |  |  | 9 |  |  | 4 |  |  | 3 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (5 | ) |
| Settlement loss | — |  |  | — |  |  | 9 |  |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | (1 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (5 | ) |  | $ | (5 | ) |  | $ | (5 | ) |

[0000068505-17-000005:notes:158]
During the three months ended April 1, 2017, the Company offered lump-sum settlements to certain participants in the Non-US defined benefit plan within the United Kingdom. The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments. As a result of the actions taken, the Company recorded a settlement loss of $9 million as of April 1, 2017, which is recorded within Other Charges within the condensed consolidated statement of operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-17-000005:notes:159]
[same as prior period, unchanged from 0000068505-16-000031:notes:179]

[0000068505-17-000005:notes:160]
2017 Charges

[0000068505-17-000005:notes:161]
During the three months ended April 1, 2017, the Company recorded net reorganization of business charges of $19 million including $15 million of charges in Other charges and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $19 million were charges of $15 million related to employee separation costs and $4 million for exit costs.

[0000068505-17-000005:notes:162]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2017 to April 1, 2017:

[0000068505-17-000005:notes:163]
|  | January 1, 2017 |  | AdditionalCharges |  | AmountUsed |  | April 1, 2017 |
| Exit costs | $ | 7 |  |  | $ | 4 |  |  | $ | (1 | ) |  | $ | 10 |  |
| Employee separation costs | 94 |  |  | 15 |  |  | (29 | ) |  | 80 |  |
|  | $ | 101 |  |  | $ | 19 |  |  | $ | (30 | ) |  | $ | 90 |  |

[0000068505-17-000005:notes:164]
[same as prior period, unchanged from 0000068505-16-000031:notes:185]

[0000068505-17-000005:notes:165]
At January 1, 2017, the Company had $7 million of accruals for exit costs. During the three months ended April 1, 2017, there were $4 million of additional charges and $1 million of cash payments related to the exit of leased facilities. The remaining accrual of $10 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at April 1, 2017, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-17-000005:notes:166]
[same as prior period, unchanged from 0000068505-16-000031:notes:187]

[0000068505-17-000005:notes:167]
At January 1, 2017, the Company had an accrual of $94 million for employee separation costs. The 2017 additional charges of $15 million represent severance costs for approximately 200 employees. The $29 million used reflects cash payments to severed employees. The remaining accrual of $80 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at April 1, 2017, is expected to be paid, primarily within one year, to approximately 700 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-17-000005:notes:168]
[same as prior period, unchanged from 0000068505-16-000031:notes:180]

[0000068505-17-000005:notes:169]
During the three months ended April 2, 2016, the Company recorded net reorganization of business charges of $23 million including $7 million of charges in Other charges and $16 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $23 million were charges of: (i) $24 million related to employee separation costs, (ii) $3 million for the impairment of the corporate aircraft, partially offset by $4 million of reversals for accruals no longer needed.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-17-000005:notes:170]
[same as prior period, unchanged from 0000068505-16-000031:notes:192]

[0000068505-17-000005:notes:171]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Products | $ | 703 |  |  | $ | 702 |  |
| Services | 578 |  |  | 491 |  |
|  | $ | 1,281 |  |  | $ | 1,193 |  |

[0000068505-17-000005:notes:172]
[same as prior period, unchanged from 0000068505-16-000031:notes:194]

[0000068505-17-000005:notes:173]
|  | Three Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |
| Products | $ | 89 |  |  | $ | 51 |  |
| Services | 87 |  |  | 49 |  |
| Operating earnings | 176 |  |  | 100 |  |
| Total other expense | (56 | ) |  | (78 | ) |
| Earnings before income taxes | $ | 120 |  |  | $ | 22 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-17-000005:notes:174]
[same as prior period, unchanged from 0000068505-16-000031:notes:196]

[0000068505-17-000005:notes:175]
[same as prior period, unchanged from 0000068505-16-000031:notes:197]

[0000068505-17-000005:notes:176]
[same as prior period, unchanged from 0000068505-16-000031:notes:198]

[0000068505-17-000005:notes:177]
[same as prior period, unchanged from 0000068505-16-000031:notes:199]
