# MSI 8-K — 0001193125-17-158741 filed 2017-05-04

## item codes, every 8-K on or before 2017-05-05

- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2017-05-05

- none on or before 2017-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-158741:8k_2_02:1]
EX-99.1
2
d391087dex991.htm
EX-99.1

[0001193125-17-158741:8k_2_02:2]
EX-99.1

[0001193125-17-158741:8k_2_02:3]
Exhibit 99.1

[0001193125-17-158741:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2017 Financial Results

[0001193125-17-158741:8k_2_02:5]
Company completes Interexport acquisition, raises full year EPS outlook

[0001193125-17-158741:8k_2_02:6]
HIGHLIGHTS

[0001193125-17-158741:8k_2_02:7]
|  | • |  | Sales of $1.3 billion, up 7 percent from a year ago |

[0001193125-17-158741:8k_2_02:8]
|  | • |  | Americas growth of 3 percent on strength in Services |

[0001193125-17-158741:8k_2_02:9]
|  | • |  | Backlog growth of $129 million from a year ago |

[0001193125-17-158741:8k_2_02:10]
|  | • |  | Generated $142 million of operating cash flow, up $129 million |

[0001193125-17-158741:8k_2_02:11]
|  | • |  | GAAP earnings per share (EPS) of $0.45 |

[0001193125-17-158741:8k_2_02:12]
|  | • |  | Non-GAAP EPS1 of $0.71, up 37 percent |

[0001193125-17-158741:8k_2_02:13]
CHICAGO – May 4, 2017 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2017.
Click here for a printable news release and financial tables.

[0001193125-17-158741:8k_2_02:14]
SUPPORTING QUOTE

[0001193125-17-158741:8k_2_02:15]
“Q1 was a strong quarter and an excellent start to the year,” said Greg Brown, chairman and CEO of Motorola Solutions. “I’m very pleased
with our momentum going forward.”

[0001193125-17-158741:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0001193125-17-158741:8k_2_02:17]
|  |  | Q1 2017 |  |  | Q1 2016 |  |  | % Change |  |
| Sales |  | $ | 1,281 |  |  | $ | 1,193 |  |  |  | 7 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 176 |  |  | $ | 100 |  |  |  | 76 | % |
| % of Sales |  |  | 13.7 | % |  |  | 8.4 | % |  |  |  |  |
| EPS |  | $ | 0.45 |  |  | $ | 0.10 |  |  |  | 350 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 224 |  |  | $ | 166 |  |  |  | 35 | % |
| % of Sales |  |  | 17.5 | % |  |  | 13.9 | % |  |  |  |  |
| EPS |  | $ | 0.71 |  |  | $ | 0.52 |  |  |  | 37 | % |
| Product Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 703 |  |  | $ | 702 |  |  |  | — | % |
| GAAP Operating Earnings |  | $ | 89 |  |  | $ | 51 |  |  |  | 75 | % |
| % of Sales |  |  | 12.7 | % |  |  | 7.3 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 101 |  |  | $ | 84 |  |  |  | 20 | % |
| % of Sales |  |  | 14.4 | % |  |  | 12.0 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 578 |  |  | $ | 491 |  |  |  | 18 | % |
| GAAP Operating Earnings |  | $ | 87 |  |  | $ | 49 |  |  |  | 78 | % |
| % of Sales |  |  | 15.1 | % |  |  | 10.0 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 123 |  |  | $ | 82 |  |  |  | 50 | % |
| % of Sales |  |  | 21.3 | % |  |  | 16.7 | % |  |  |  |  |

[0001193125-17-158741:8k_2_02:18]
| * | Non-GAAP financial information excludes the after-tax impact of approximately $0.26 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-17-158741:8k_2_02:19]
| • |  | Revenue – Sales increased 7 percent in total, and 3 percent excluding Airwave. The increase reflects growth in EMEA and the Americas. Product segment sales were up $1 million. The Services segment grew 18 percent, including $58 million of incremental Airwave revenue. Excluding Airwave, Services grew 7 percent. |

[0001193125-17-158741:8k_2_02:20]
| • |  | Operating margin – GAAP operating margin was 13.7 percent of sales, compared with 8.4 percent in the year-ago quarter. The improvement reflects higher sales and gross margin. Non-GAAP operating margin was 17.5 percent of sales, compared with 13.9 percent in the year-ago quarter, driven by higher sales and gross margin as well as lower operating expenses. |

[0001193125-17-158741:8k_2_02:21]
| • |  | Cash flow – The company generated $142 million in operating cash, an increase of $129 million from the year-ago quarter on higher revenue and earnings. Q1 also included a $52 million legal settlement. Free cash flow2 was up $112 million to $74 million, driven by higher revenue and earnings. |

[0001193125-17-158741:8k_2_02:22]
| • |  | Capital Allocation – The company ended the quarter with cash and cash equivalents of $829 million and a net debt position of approximately $3.6 billion3. The company repurchased approximately $178 million of its common stock, paid approximately $77 million in cash dividends, and invested $55 million in acquisitions. |

[0001193125-17-158741:8k_2_02:23]
| • |  | Backlog – The company ended the quarter with $8.5 billion of backlog, up $129 million from the year-ago quarter. Products backlog is up $285 million, while Services backlog is down $156 million, driven by a reduction of approximately $650 million in Airwave backlog over the prior 12 months. |

[0001193125-17-158741:8k_2_02:24]
KEY HIGHLIGHTS

[0001193125-17-158741:8k_2_02:25]
Strategic wins

[0001193125-17-158741:8k_2_02:26]
|  | • |  | $80 million to upgrade and manage a nationwide TETRA network in Europe |

[0001193125-17-158741:8k_2_02:27]
|  | • |  | $38 million for Managed Services with Victoria Police in Australia |

[0001193125-17-158741:8k_2_02:28]
|  | • |  | $34 million P25 network with multi-year services in California |

[0001193125-17-158741:8k_2_02:29]
|  | • |  | $10 million P25 system with Central Louisiana Electric Company (CLECO) |

[0001193125-17-158741:8k_2_02:30]
|  | • |  | Double-digit growth for Command Center software driven by Spillman, Emergency CallWorks, and PremierOne solutions |

[0001193125-17-158741:8k_2_02:31]
Innovation and investments in growth

[0001193125-17-158741:8k_2_02:32]
|  | • |  | Announced planned acquisition of Kodiak Networks, a leading provider of broadband push-to-talk for commercial customers, which adds a carrier-integrated, cellular push-to-talk solution for mobile operators around the world |

[0001193125-17-158741:8k_2_02:33]
|  | • |  | Acquired Interexport, a provider of managed services for communications systems to public safety and commercial customers in Chile |

[0001193125-17-158741:8k_2_02:34]
|  | • |  | Announced new head of software, Andrew Sinclair, to lead a new integrated Software Enterprise team focused on the development, sales and delivery of software |

[0001193125-17-158741:8k_2_02:35]
|  | • |  | Launched WAVE OnCloud, which provides instant communications between various devices and networks with a new subscription-based Software-as-a-Service (SaaS) model that reduces adoption barriers |

[0001193125-17-158741:8k_2_02:36]
BUSINESS OUTLOOK

[0001193125-17-158741:8k_2_02:37]
|  | • |  | Second-quarter 2017 – Motorola Solutions expects revenue growth of 2 to 3 percent compared with the second quarter of 2016. The company expects non-GAAP earnings in the range of $0.98 to $1.03 per share. |

[0001193125-17-158741:8k_2_02:38]
|  | • |  | Full-year 2017 – The company now expects revenue growth of approximately 2 percent versus the prior outlook of 1 to 2 percent, and raises non-GAAP earnings per share to $5.08 to $5.23 versus the prior outlook of $5.05 to $5.20. |

[0001193125-17-158741:8k_2_02:39]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m.
U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, May 4. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-17-158741:8k_2_02:40]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0001193125-17-158741:8k_2_02:41]
A comparison of results from operations is as follows:

[0001193125-17-158741:8k_2_02:42]
|  |  | Q1 2017 |  |  | Q1 2016 |  |
| Net sales |  | $ | 1,281 |  |  | $ | 1,193 |  |
| Gross margin |  |  | 570 |  |  |  | 502 |  |
| Operating earnings |  |  | 176 |  |  |  | 100 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings, net of tax |  |  | 77 |  |  |  | 17 |  |
| Net earnings |  |  | 77 |  |  |  | 17 |  |
| Diluted EPS |  | $ | 0.45 |  |  | $ | 0.10 |  |
| Weighted average diluted common shares outstanding |  |  | 169.9 |  |  |  | 177.0 |  |

[0001193125-17-158741:8k_2_02:43]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-17-158741:8k_2_02:44]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the first quarter of 2017.

[0001193125-17-158741:8k_2_02:45]
| (per diluted common share) |  | Q1 2017 |  |
| GAAP Earnings |  | $ | 0.45 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.06 |  |
| Reorganization of business charges |  |  | 0.09 |  |
| Intangibles amortization expense |  |  | 0.16 |  |
| Gain on legal settlement |  |  | (0.15 | ) |
| Building impairment |  |  | 0.05 |  |
| Non-US pension settlement loss |  |  | 0.05 |  |
| Sale of investments |  |  | (0.01 | ) |
| Acquisition-related transaction fees |  |  | 0.01 |  |
| Total Highlighted Items |  | $ | 0.26 |  |
| Non-GAAP Diluted EPS |  | $ | 0.71 |  |

[0001193125-17-158741:8k_2_02:46]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-17-158741:8k_2_02:47]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP
measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period
to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results
relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better
period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended
only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of
financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-17-158741:8k_2_02:48]
Highlighted items: The company has excluded the
effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments,
significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income
measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s current operating performance or comparisons
to the company’s past operating performance. For the purposes of management’s internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a
meaningful evaluation of the company’s current operating performance or comparisons to the company’s past operating performance. Specifically in regards to its restructuring plans, the company has incurred significant restructuring charges
as it reduced operating expenses in the past four years.

[0001193125-17-158741:8k_2_02:49]
Share-based compensation expense: The company has excluded share-based compensation
expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation
contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily
because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-17-158741:8k_2_02:50]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its
Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding
intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible
assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-17-158741:8k_2_02:51]
Constant Currency: The company evaluates its results of operations on both an as reported and a constant currency basis. The constant currency
presentation, which is a non-GAAP measure, excludes the impact of fluctuations in foreign currency exchange rates. The company calculates constant currency percentages by converting its current period
local currency results using prior-period exchange rates, and then comparing these adjusted values to prior period reported results.

[0001193125-17-158741:8k_2_02:52]
Details of the above items and reconciliations of the non-GAAP
measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0001193125-17-158741:8k_2_02:53]
BUSINESS RISKS

[0001193125-17-158741:8k_2_02:54]
laws or regulations; (21) negative consequences from the company’s use of third party vendors for various activities, including certain manufacturing operations, information technology
and administrative functions; (22) the impact of the sale of the company’s legacy information systems, including components of the enterprise resource planning (ERP) system and the implementation of a new ERP system; and (23) the
company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future
events or otherwise

[0001193125-17-158741:8k_2_02:55]
DEFINITIONS

[0001193125-17-158741:8k_2_02:56]
1 Q1 Non-GAAP financial information excludes the after-tax impact of approximately $0.26 per diluted share related to
share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are
included in this news release.

[0001193125-17-158741:8k_2_02:57]
2 Free cash flow represents operating cash flow less capital
expenditures

[0001193125-17-158741:8k_2_02:58]
3 Net debt represents cash and cash equivalents less long-term debt, including current
portion

[0001193125-17-158741:8k_2_02:59]
ABOUT MOTOROLA SOLUTIONS

[0001193125-17-158741:8k_2_02:60]
Motorola Solutions
(NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or
subscribe to a news feed.

[0001193125-17-158741:8k_2_02:61]
MEDIA CONTACT

[0001193125-17-158741:8k_2_02:62]
Tama
McWhinney

[0001193125-17-158741:8k_2_02:63]
Motorola Solutions

[0001193125-17-158741:8k_2_02:64]
+1 847-538-1865

[0001193125-17-158741:8k_2_02:65]
tama.mcwhinney@motorolasolutions.com

[0001193125-17-158741:8k_2_02:66]
INVESTOR CONTACT

[0001193125-17-158741:8k_2_02:67]
Chris Kutsor

[0001193125-17-158741:8k_2_02:68]
Motorola Solutions

[0001193125-17-158741:8k_2_02:69]
+1 847-576-4995

[0001193125-17-158741:8k_2_02:70]
chris.kutsor@motorolasolutions.com

[0001193125-17-158741:8k_2_02:71]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license.
All other trademarks are the property of their respective owners. ©2017 Motorola Solutions, Inc. All rights reserved.

[0001193125-17-158741:8k_2_02:72]
GAAP-1

[0001193125-17-158741:8k_2_02:73]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:74]
Condensed Consolidated Statements of Operations

[0001193125-17-158741:8k_2_02:75]
(In millions, except per share amounts)

[0001193125-17-158741:8k_2_02:76]
|  |  | Three Months Ended |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Net sales from products |  | $ | 703 |  |  | $ | 702 |  |
| Net sales from services |  |  | 578 |  |  |  | 491 |  |
| Net sales |  |  | 1,281 |  |  |  | 1,193 |  |
| Costs of products sales |  |  | 347 |  |  |  | 366 |  |
| Costs of services sales |  |  | 364 |  |  |  | 325 |  |
| Costs of sales |  |  | 711 |  |  |  | 691 |  |
| Gross margin |  |  | 570 |  |  |  | 502 |  |
| Selling, general and administrative expenses |  |  | 232 |  |  |  | 234 |  |
| Research and development expenditures |  |  | 135 |  |  |  | 135 |  |
| Other charges |  |  | (9 | ) |  |  | 20 |  |
| Intangibles amortization |  |  | 36 |  |  |  | 13 |  |
| Operating earnings |  |  | 176 |  |  |  | 100 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (51 | ) |  |  | (49 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | 3 |  |  |  | (21 | ) |
| Other |  |  | (8 | ) |  |  | (8 | ) |
| Total other expense |  |  | (56 | ) |  |  | (78 | ) |
| Net earnings before income taxes |  |  | 120 |  |  |  | 22 |  |
| Income tax expense |  |  | 42 |  |  |  | 5 |  |
| Net earnings |  |  | 78 |  |  |  | 17 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 77 |  |  | $ | 17 |  |
| Earnings per common share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.47 |  |  | $ | 0.10 |  |
| Diluted |  | $ | 0.45 |  |  | $ | 0.10 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 164.2 |  |  |  | 174.5 |  |
| Diluted |  |  | 169.9 |  |  |  | 177.0 |  |

[0001193125-17-158741:8k_2_02:77]
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 54.9 | % |  |  | 58.8 | % |
| Net sales from services |  |  | 45.1 | % |  |  | 41.2 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 49.4 | % |  |  | 52.1 | % |
| Costs of services sales |  |  | 63.0 | % |  |  | 66.2 | % |
| Costs of sales |  |  | 55.5 | % |  |  | 57.9 | % |
| Gross margin |  |  | 44.5 | % |  |  | 42.1 | % |
| Selling, general and administrative expenses |  |  | 18.1 | % |  |  | 19.6 | % |
| Research and development expenditures |  |  | 10.5 | % |  |  | 11.3 | % |
| Other charges |  |  | (0.7 | )% |  |  | 1.7 | % |
| Intangibles amortization |  |  | 2.8 | % |  |  | 1.1 | % |
| Operating earnings |  |  | 13.7 | % |  |  | 8.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (4.0 | )% |  |  | (4.1 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | 0.2 | % |  |  | (1.8 | )% |
| Other |  |  | (0.6 | )% |  |  | (0.7 | )% |
| Total other expense |  |  | (4.4 | )% |  |  | (6.5 | )% |
| Net earnings before income taxes |  |  | 9.4 | % |  |  | 1.8 | % |
| Income tax expense |  |  | 3.3 | % |  |  | 0.4 | % |
| Net earnings |  |  | 6.1 | % |  |  | 1.4 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 6.0 | % |  |  | 1.4 | % |

[0001193125-17-158741:8k_2_02:78]
| * | Percentages may not add up due to rounding |

[0001193125-17-158741:8k_2_02:79]
GAAP-2

[0001193125-17-158741:8k_2_02:80]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:81]
Condensed Consolidated Balance Sheets

[0001193125-17-158741:8k_2_02:82]
(In millions)

[0001193125-17-158741:8k_2_02:83]
|  |  | April 1, 2017 |  |  | December 31, 2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 766 |  |  | $ | 967 |  |
| Restricted cash |  |  | 63 |  |  |  | 63 |  |
| Total cash and cash equivalents |  |  | 829 |  |  |  | 1,030 |  |
| Accounts receivable, net |  |  | 1,070 |  |  |  | 1,410 |  |
| Inventories, net |  |  | 345 |  |  |  | 273 |  |
| Other current assets |  |  | 829 |  |  |  | 755 |  |
| Total current assets |  |  | 3,073 |  |  |  | 3,468 |  |
| Property, plant and equipment, net |  |  | 820 |  |  |  | 789 |  |
| Investments |  |  | 237 |  |  |  | 238 |  |
| Deferred income taxes |  |  | 2,198 |  |  |  | 2,219 |  |
| Goodwill |  |  | 737 |  |  |  | 728 |  |
| Intangible Assets |  |  | 878 |  |  |  | 821 |  |
| Other assets |  |  | 197 |  |  |  | 200 |  |
| Total assets |  | $ | 8,140 |  |  | $ | 8,463 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 44 |  |  | $ | 4 |  |
| Accounts payable |  |  | 433 |  |  |  | 553 |  |
| Accrued liabilities |  |  | 1,908 |  |  |  | 2,111 |  |
| Total current liabilities |  |  | 2,385 |  |  |  | 2,668 |  |
| Long-term debt |  |  | 4,414 |  |  |  | 4,392 |  |
| Other liabilities |  |  | 2,378 |  |  |  | 2,355 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (1,050 | ) |  |  | (964 | ) |
| Noncontrolling interests |  |  | 13 |  |  |  | 12 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,140 |  |  | $ | 8,463 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (3,629 | ) |  | $ | (3,366 | ) |

[0001193125-17-158741:8k_2_02:84]
*Net cash (debt) = Total cash – Current portion of long-term debt – Long-term debt

[0001193125-17-158741:8k_2_02:85]
GAAP-3

[0001193125-17-158741:8k_2_02:86]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:87]
Condensed Consolidated Statements of Cash Flows

[0001193125-17-158741:8k_2_02:88]
(In millions)

[0001193125-17-158741:8k_2_02:89]
|  |  | Three Months Ended |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 77 |  |  | $ | 17 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings |  |  | 78 |  |  |  | 17 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 80 |  |  |  | 62 |  |
| Non-cash other charges |  |  | 15 |  |  |  | 11 |  |
| Non-U.S. pension settlement loss |  |  | 9 |  |  |  | — |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 17 |  |
| Losses (gains) on sales of investments and businesses, net |  |  | (3 | ) |  |  | 21 |  |
| Deferred income taxes |  |  | 23 |  |  |  | 35 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 368 |  |  |  | 277 |  |
| Inventories |  |  | (69 | ) |  |  | (4 | ) |
| Other current assets |  |  | (59 | ) |  |  | (43 | ) |
| Accounts payable and accrued liabilities |  |  | (307 | ) |  |  | (363 | ) |
| Other assets and liabilities |  |  | (10 | ) |  |  | (17 | ) |
| Net cash provided by operating activities |  |  | 142 |  |  |  | 13 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (106 | ) |  |  | (1,053 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 53 |  |  |  | 481 |  |
| Capital expenditures |  |  | (68 | ) |  |  | (51 | ) |
| Net cash used for investing activities |  |  | (121 | ) |  |  | (623 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (1 | ) |
| Net proceeds from issuance of debt |  |  | — |  |  |  | 673 |  |
| Issuance of common stock |  |  | 22 |  |  |  | 40 |  |
| Purchase of common stock |  |  | (178 | ) |  |  | (64 | ) |
| Payment of dividends |  |  | (77 | ) |  |  | (71 | ) |
| Net cash provided by (used for) financing activities |  |  | (234 | ) |  |  | 577 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 12 |  |  |  | (7 | ) |
| Net decrease in cash and cash equivalents |  |  | (201 | ) |  |  | (40 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,030 |  |  |  | 1,980 |  |
| Cash and cash equivalents, end of period |  | $ | 829 |  |  | $ | 1,940 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 74 |  |  | $ | (38 | ) |

[0001193125-17-158741:8k_2_02:90]
*Free cash flow = Net cash provided by operating activities—Capital Expenditures

[0001193125-17-158741:8k_2_02:91]
GAAP-4

[0001193125-17-158741:8k_2_02:92]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:93]
Segment Information

[0001193125-17-158741:8k_2_02:94]
(In
millions)

[0001193125-17-158741:8k_2_02:95]
Net Sales

[0001193125-17-158741:8k_2_02:96]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |  | % Change |  |
| Products |  | $ | 703 |  |  | $ | 702 |  |  |  | — | % |
| Services |  |  | 578 |  |  |  | 491 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 1,281 |  |  | $ | 1,193 |  |  |  | 7 | % |

[0001193125-17-158741:8k_2_02:97]
Operating Earnings

[0001193125-17-158741:8k_2_02:98]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |  | % Change |  |
| Products |  | $ | 89 |  |  | $ | 51 |  |  |  | 75 | % |
| Services |  |  | 87 |  |  |  | 49 |  |  |  | 78 | % |
| Total Motorola Solutions |  | $ | 176 |  |  | $ | 100 |  |  |  | 76 | % |

[0001193125-17-158741:8k_2_02:99]
Operating Earnings %

[0001193125-17-158741:8k_2_02:100]
|  |  | Three Months Ended |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Products |  |  | 12.7 | % |  |  | 7.3 | % |
| Services |  |  | 15.1 | % |  |  | 10.0 | % |
| Total Motorola Solutions |  |  | 13.7 | % |  |  | 8.4 | % |

[0001193125-17-158741:8k_2_02:101]
Non-GAAP-1

[0001193125-17-158741:8k_2_02:102]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:103]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and
Highlighted Items)

[0001193125-17-158741:8k_2_02:104]
Q1 2017

[0001193125-17-158741:8k_2_02:105]
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 19 |  |  |  | 4 |  |  |  | 15 |  |  |  | 0.09 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 36 |  |  |  | 9 |  |  |  | 27 |  |  |  | 0.16 |  |
| Gain on legal settlement |  | Other charges |  |  | (42 | ) |  |  | (16 | ) |  |  | (26 | ) |  |  | (0.15 | ) |
| Building impairment |  | Other charges |  |  | 8 |  |  |  | — |  |  |  | 8 |  |  |  | 0.05 |  |
| Non-US pension settlement loss |  | Other charges |  |  | 9 |  |  |  | — |  |  |  | 9 |  |  |  | 0.05 |  |
| Sale of investments |  | Sale of Investment or Business (Gain) or Loss |  |  | (3 | ) |  |  | (1 | ) |  |  | (2 | ) |  |  | (0.01 | ) |
| Acquisition-related transaction fees |  | Other charges |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 0.01 |  |
| Total impact on Net earnings |  |  |  | $ | 45 |  |  | $ | 2 |  |  | $ | 43 |  |  | $ | 0.26 |  |

[0001193125-17-158741:8k_2_02:106]
Non-GAAP-2

[0001193125-17-158741:8k_2_02:107]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:108]
Non-GAAP Segment Information

[0001193125-17-158741:8k_2_02:109]
(In millions)

[0001193125-17-158741:8k_2_02:110]
Net Sales

[0001193125-17-158741:8k_2_02:111]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |  | % Change |  |
| Products |  | $ | 703 |  |  | $ | 702 |  |  |  | — | % |
| Services |  |  | 578 |  |  |  | 491 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 1,281 |  |  | $ | 1,193 |  |  |  | 7 | % |

[0001193125-17-158741:8k_2_02:112]
Non-GAAP Operating
Earnings

[0001193125-17-158741:8k_2_02:113]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |  | % Change |  |
| Products |  | $ | 101 |  |  | $ | 84 |  |  |  | 20 | % |
| Services |  |  | 123 |  |  |  | 82 |  |  |  | 50 | % |
| Total Motorola Solutions |  | $ | 224 |  |  | $ | 166 |  |  |  | 35 | % |

[0001193125-17-158741:8k_2_02:114]
Non-GAAP Operating
Earnings %

[0001193125-17-158741:8k_2_02:115]
|  |  | Three Months Ended |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Products |  |  | 14.4 | % |  |  | 12.0 | % |
| Services |  |  | 21.3 | % |  |  | 16.7 | % |
| Total Motorola Solutions |  |  | 17.5 | % |  |  | 13.9 | % |

[0001193125-17-158741:8k_2_02:116]
Non-GAAP-3

[0001193125-17-158741:8k_2_02:117]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-158741:8k_2_02:118]
Operating Earnings after Non-GAAP Adjustments

[0001193125-17-158741:8k_2_02:119]
Q1 2017

[0001193125-17-158741:8k_2_02:120]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,281 |  |  | $ | 703 |  |  | $ | 578 |  |
| Operating earnings (“OE”) |  | $ | 176 |  |  | $ | 89 |  |  | $ | 87 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 19 |  |  |  | 13 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 36 |  |  |  | 6 |  |  |  | 30 |  |
| Acquisition-related transaction fees |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Gain on legal settlement |  |  | (42 | ) |  |  | (30 | ) |  |  | (12 | ) |
| Building impairment |  |  | 8 |  |  |  | 6 |  |  |  | 2 |  |
| Non-US pension settlement loss |  |  | 9 |  |  |  | 6 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 48 |  |  |  | 12 |  |  |  | 36 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 224 |  |  | $ | 101 |  |  | $ | 123 |  |
| Operating earnings as a percentage of net sales—GAAP |  |  | 13.7 | % |  |  | 12.7 | % |  |  | 15.1 | % |
| Operating earnings as a percentage of net sales—after non-GAAP adjustments |  |  | 17.5 | % |  |  | 14.4 | % |  |  | 21.3 | % |
