# MSI notes — 0000068505-23-000015


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000068505-23-000015:notes:1]
Portions of the registrant’s definitive Proxy Statement to be delivered to stockholders in connection with its Annual Meeting of Shareholders to be held on May 16, 2023 (the "Proxy Statement"), are incorporated by reference into Part III of this Annual Report on Form 10-K (this "Form 10-K").


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-23-000015:notes:2]
Summary of Significant Accounting Policies
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-23-000015:notes:3]
The consolidated financial statements as of December 31, 2022 and 2021 and for the years ended December 31, 2022, 2021 and 2020, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.

[0000068505-23-000015:notes:4]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-23-000015:notes:5]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of devices, systems and system integration and a full set of software and service offerings. The Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services.

[0000068505-23-000015:notes:6]
The Products and Systems Integration segment is comprised of devices, systems, and systems integration for our Land Mobile Radio Communication ("LMR" or "LMR Communications") and Video Security and Access Control ("Video") technologies. Direct customers of the Products and Systems Integration segment are typically government, public safety agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional and commercial radios and video security, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video security are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. For Products and Systems Integration sales, the Company records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-23-000015:notes:7]
LMR and Video devices include two-way portable and vehicle-mounted radios, fixed video cameras and accessories. Devices are considered capable of being distinct and distinct within the context of the Company's contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-23-000015:notes:8]
The Products and Systems Integration segment includes both customized radio networks and video security solutions, including the integration of these networks with devices, software, and applications within both LMR and Video technologies. For systems contracts, revenue for the year ended December 31, 2022 was $1.8 billion compared to $1.9 billion for the year ended December 31, 2021 and $1.8 billion for the year ended December 31, 2020. The networks include the aggregation of promises to the customer to provide i) a radio network core and central processing software, base stations, consoles, and repeaters or ii) a video security solution including video analytics, network video management hardware and software, and access control solutions. The individual promises within a radio network contract are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Products and Systems Integration revenue for radio network systems is recognized over an average duration of approximately one to two years. Individual promises of the video security solution are capable of being distinct and distinct in the context of the contract. Video security solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-23-000015:notes:9]
The Software and Services segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Software and Services segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-23-000015:notes:10]
Software offerings primarily include Command Center and Video software and services which can be delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services

[0000068505-23-000015:notes:11]
that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-23-000015:notes:12]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are generally each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is generally recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis. In certain situations when the software license is not distinct within the context of the contract, revenue for the software license is recognized over time following the transfer of control under the arrangement.

[0000068505-23-000015:notes:13]
Services include a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer-owned or Motorola Solutions-owned networks. Services are provided across all technologies and are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-23-000015:notes:14]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-23-000015:notes:15]
The Company accounts for certain system contracts without an alternative use on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-23-000015:notes:16]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. The Company has a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-23-000015:notes:17]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $2 million at each of December 31, 2022 and December 31, 2021.

[0000068505-23-000015:notes:18]
Investments: The Company generally invests in debt and equity securities of a strategic nature.

[0000068505-23-000015:notes:19]
The Company applies the equity method of accounting for equity investments if the Company has significant influence over the issuing entity. The Company’s share of the investee’s underlying net income or loss is recorded to Other, net within Other income (expense).

[0000068505-23-000015:notes:20]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other, net within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative

[0000068505-23-000015:notes:21]
assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded to Other, net within Other income (expense).

[0000068505-23-000015:notes:22]
Investments in debt securities are classified as available-for-sale and held-to-maturity on the basis of the Company’s intent and ability to hold the investments. Investments classified as available-for-sale are carried at fair value with changes reflected in other comprehensive income. Any credit-related impairment is recognized through an allowance for expected credit losses, and adjusted subsequently if conditions change, with a corresponding impact in earnings. Where there is an intention or a requirement to sell an impaired available-for-sale debt security, the entire impairment is recognized in earnings with a corresponding adjustment to the amortized cost basis of the security. Investments classified as held-to-maturity are carried at amortized cost less allowance for credit losses recorded within Other, net within Other income (expense).

[0000068505-23-000015:notes:23]
Inventories: Inventories are valued at the lower of cost (which approximates cost on a first-in, first-out basis) and net realizable value.

[0000068505-23-000015:notes:24]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, one to twenty years; machinery and equipment, one to fifteen years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-23-000015:notes:25]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment as of the last day of the third quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and selling, general and administrative costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it is determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform a quantitative goodwill impairment test, which compares the fair value of the reporting unit to its carrying value. A quantitative assessment includes the assignment of assets and liabilities to each of the Company's reporting units and an assessment of the fair value of each of the Company's reporting units. The Company estimates the fair value of each reporting utilizing an income approach (discounted cash flows) to estimate the fair value of each reporting unit, which is corroborated by market multiples when available and as appropriate.  Key assumptions in the quantitative analysis include revenue growth rates (including long-term growth rates for terminal value assumptions), operating margin estimates, discount rates, and where applicable, the comparable multiples from publicly traded companies in the Company's industry.

[0000068505-23-000015:notes:26]
If the carrying amount of a reporting unit exceeds its fair value, the Company would recognize an impairment loss in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0000068505-23-000015:notes:27]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.

[0000068505-23-000015:notes:28]
Leases: The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-23-000015:notes:29]
The Company determines if an arrangement is a lease at inception of the contract. The Company’s key considerations in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company’s contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the right to operate the asset at its discretion during the term of the contract.

[0000068505-23-000015:notes:30]
Right-of-use ("ROU") assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company’s lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in lease payments. For the Company’s leases consisting of land and other equipment (i.e. “communication network sites”), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage. ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-23-000015:notes:31]
As the majority of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company’s incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-23-000015:notes:32]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of

[0000068505-23-000015:notes:33]
the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communication network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-23-000015:notes:34]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-23-000015:notes:35]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expenses and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-23-000015:notes:36]
Long-Term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. Long-term receivables are considered past due if payments have not been received according to the contractual terms of the note agreement, including principal and interest. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-23-000015:notes:37]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the Accrued liabilities statement line and the non-current portion is included in the Other liabilities statement line within the Company’s Consolidated Balance Sheet.

[0000068505-23-000015:notes:38]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have transactions denominated in local currency which differs from functional currency, transactions denominated in the local currency are measured in their functional currency using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-23-000015:notes:39]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-23-000015:notes:40]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-23-000015:notes:41]
Derivative Instruments: Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of

[0000068505-23-000015:notes:42]
Accumulated other comprehensive income. Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income at their initial value and amortized into Interest expense, net on a straight-line basis.

[0000068505-23-000015:notes:43]
Fair Value Measurements: The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-23-000015:notes:44]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-23-000015:notes:45]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-23-000015:notes:46]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-23-000015:notes:47]
Earnings Per Share: The Company calculates its basic earnings per share based on the weighted-average number of common shares issued and outstanding. Net earnings attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings per share. Diluted earnings per share is calculated by dividing net earnings attributable to Motorola Solutions, by the sum of the weighted-average number of common shares used in the basic earnings per share calculation and the weighted-average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings per share calculation. Both basic and diluted earnings per share amounts are calculated for net earnings attributable to Motorola Solutions for all periods presented.

[0000068505-23-000015:notes:48]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk-free rate, dividend yield, and expected life. Performance-based stock options, performance stock units, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-23-000015:notes:49]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from nine to twenty-seven years. Prior service costs will be amortized over periods ranging from one to seventeen years. Benefits under all pension plans are valued based on the projected unit credit cost method. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-23-000015:notes:50]
The benefit obligation and plan assets for the Company's defined benefit plans are presented on a net basis according to the plans' net funded status and measured as of December 31, 2022.

[0000068505-23-000015:notes:51]
Recent Acquisitions:

[0000068505-23-000015:notes:52]
On December 14, 2022, the Company acquired Rave Mobile Safety, Inc. ("Rave Mobile"), a leader in mass notification and incident management, for $553 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The business is a part of the Software and Services segment.

[0000068505-23-000015:notes:53]
On October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part of the Products and Systems Integration segment.

[0000068505-23-000015:notes:54]
On August 8, 2022, the Company acquired Barrett Communications Pty Ltd ("Barrett Communications"), a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The business is a part of the Products and Systems Integration segment.

[0000068505-23-000015:notes:55]
On May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of the Products and Systems Integration segment.

[0000068505-23-000015:notes:56]
On April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

[0000068505-23-000015:notes:57]
On March 23, 2022, the Company acquired TETRA Ireland Communications Limited ("TETRA Ireland"), the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. The business is part of the Software and Services segment.

[0000068505-23-000015:notes:58]
On March 3, 2022, the Company acquired Ava Security Limited ("Ava"), a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-23-000015:notes:59]
On December 16, 2021, the Company acquired 911 Datamaster, Inc. ("911 Datamaster"), a Next Generation 911 ("NG911") data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service of two years. This acquisition reinforces the Company's strategy to be a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The business is a part of the Software and Services segment.

[0000068505-23-000015:notes:60]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-23-000015:notes:61]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years.This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-23-000015:notes:62]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to the Company's existing Command Center suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

[0000068505-23-000015:notes:63]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-23-000015:notes:64]
On June 16, 2020 the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-23-000015:notes:65]
On April 30, 2020, the Company acquired a cybersecurity services business for $32 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-23-000015:notes:66]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-23-000015:notes:67]
Recent Accounting Pronouncements:

[0000068505-23-000015:notes:68]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The ASU became effective for the Company on January 1, 2023, including interim periods, with early adoption permitted. The Company does not expect the adoption to have a material impact on its financial statements and disclosures.

[0000068505-23-000015:notes:69]
Recently Adopted Accounting Pronouncements

[0000068505-23-000015:notes:70]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our consolidated financial statements included in this "Part II, Item 8. Financial Statements and Supplementary Data" of this Form 10-K for the effect of the Senior Convertible Notes on diluted earnings per common share.

[0000068505-23-000015:notes:71]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers," which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

[0000068505-23-000015:notes:72]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-23-000015:notes:73]
Revenue from Contracts with Customers
Disaggregation of Revenue

[0000068505-23-000015:notes:74]
In January 2023, the Company began using Command Center as a naming convention, eliminating the "Software" descriptor from Command Center Software in order to inform investors that the Company has software components more broadly across all technologies; this name change does not require any financial information to be reclassified from previous periods.

[0000068505-23-000015:notes:75]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the years ended December 31, 2022, 2021 and 2020, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of reportable segments:

[0000068505-23-000015:notes:76]
|  | Years Ended |
|  | 2022 |  | 2021 |  | 2020 |
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions |
| North America | $ | 4,286 |  |  | $ | 2,088 |  |  | $ | 6,374 |  |  | $ | 3,723 |  |  | $ | 1,838 |  |  | $ | 5,561 |  |  | $ | 3,418 |  |  | $ | 1,606 |  |  | $ | 5,024 |  |
| International | 1,442 |  |  | 1,296 |  |  | 2,738 |  |  | 1,310 |  |  | 1,300 |  |  | 2,610 |  |  | 1,216 |  |  | 1,174 |  |  | 2,390 |  |
|  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |
| Major Products and Services |
| LMR Communications | $ | 4,713 |  |  | $ | 2,274 |  |  | $ | 6,987 |  |  | $ | 4,203 |  |  | $ | 2,205 |  |  | $ | 6,408 |  |  | $ | 3,992 |  |  | $ | 2,008 |  |  | $ | 6,000 |  |
| Video | 1,015 |  |  | 508 |  |  | 1,523 |  |  | 830 |  |  | 396 |  |  | 1,226 |  |  | 642 |  |  | 285 |  |  | 927 |  |
| Command Center | — |  |  | 602 |  |  | 602 |  |  | — |  |  | 537 |  |  | 537 |  |  | — |  |  | 487 |  |  | 487 |  |
|  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |
| Customer Type |
| Direct | $ | 3,368 |  |  | $ | 3,057 |  |  | $ | 6,425 |  |  | $ | 3,147 |  |  | $ | 2,842 |  |  | $ | 5,989 |  |  | $ | 2,991 |  |  | $ | 2,558 |  |  | $ | 5,549 |  |
| Indirect | 2,360 |  |  | 327 |  |  | 2,687 |  |  | 1,886 |  |  | 296 |  |  | 2,182 |  |  | 1,643 |  |  | 222 |  |  | 1,865 |  |
|  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |

[0000068505-23-000015:notes:77]
Remaining Performance Obligations

[0000068505-23-000015:notes:78]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of December 31, 2022 was $9.5 billion. A total of $4.9 billion was from Products and Systems Integration performance obligations that were not yet satisfied, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.6 billion was from Software and Services performance obligations that were not yet satisfied as of December 31, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-23-000015:notes:79]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a Contract asset or Contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-23-000015:notes:80]
Contract Balances

[0000068505-23-000015:notes:81]
| December 31 (in millions) | 2022 |  | 2021 |  | 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,518 |  |  | $ | 1,386 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 974 |  |  | 1,105 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,859 |  |  | 1,650 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 363 |  |  | 306 |  |  | 283 |  |  |  |  |  |

[0000068505-23-000015:notes:82]
Revenue recognized during the year ended December 31, 2022 which was previously included in Contract liabilities as of January 1, 2022 was $1.1 billion, compared to $1.0 billion of revenue recognized during the year ended December 31, 2021 which was previously included in Contract liabilities as of January 1, 2021, and $946 million of revenue recognized during the year ended December 31, 2020 which was previously included in Contract liabilities as of January 1, 2020. Revenue of $26 million was reversed during the year ended December 31, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $4 million during the year ended December 31, 2021 and $53 million during the year ended December 31, 2020.

[0000068505-23-000015:notes:83]
There have been no material expected credit losses recognized on contract assets during the year ended December 31, 2022.

[0000068505-23-000015:notes:84]
Contract Cost Balances

[0000068505-23-000015:notes:85]
| December 31 (in millions) | 2022 |  | 2021 |  | 2020 |  |  |  |  |
| Current contract cost assets | $ | 61 |  |  | $ | 30 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 130 |  |  | 124 |  |  | 105 |  |  |  |  |  |

[0000068505-23-000015:notes:86]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one year to eight years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $62 million for the year ended December 31, 2022, compared to $52 million as of the year ended December 31, 2021 and $49 million as of the year ended December 31, 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-23-000015:notes:87]
Leases
The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-23-000015:notes:88]
Components of Lease Expense

[0000068505-23-000015:notes:89]
| (in millions) | December 31, 2022 |  | December 31, 2021 |
| Lease expense: |  |  |  |
| Operating lease cost | $ | 130 |  |  | $ | 133 |  |
| Finance lease cost |  |  |  |
| Amortization of right-of-use assets | $ | 6 |  |  | $ | 10 |  |
| Short-term lease cost | $ | 1 |  |  | $ | 2 |  |
| Variable cost | 33 |  |  | 36 |  |
| Sublease income | (5) |  |  | (7) |  |
| Net lease expense | $ | 165 |  |  | $ | 174 |  |

[0000068505-23-000015:notes:90]
Lease Assets and Liabilities

[0000068505-23-000015:notes:91]
| (in millions) |  | Statement Line Classification |  | December 31, 2022 |  | December 31, 2021 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 485 |  |  | $ | 382 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 9 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 494 |  |  | $ | 398 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 118 |  |  | $ | 124 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 1 |  |  | 4 |  |  |  |
|  |  |  |  | $ | 119 |  |  | $ | 128 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 419 |  |  | $ | 313 |  |  |  |

[0000068505-23-000015:notes:92]
Other Information Related to Leases

[0000068505-23-000015:notes:93]
| (in millions) | December 31, 2022 |  | December 31, 2021 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 145 |  |  | $ | 145 |  |  |  |
| Net cash used for operating activities related to finance leases | — |  |  | — |  |  |  |
| Net cash used for financing activities related to finance leases | 4 |  |  | 11 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 221 |  |  | $ | 40 |  |  |  |

[0000068505-23-000015:notes:94]
During the year ended December 31, 2022 the Company recorded $150 million of assets obtained in exchange for lease liabilities due to an assumption that it is reasonably certain that renewal options will be extended on its radio tower site leases operated within the Airwave radio network consistent with the contract extension of the radio communication services through 2026. In addition, assets obtained in exchange for lease liabilities of $34 million were recorded in connection with the Company's acquisition of TETRA Ireland on March 23, 2022.

[0000068505-23-000015:notes:95]
|  | December 31, 2022 |  | December 31, 2021 |  |  |
| Weighted average remaining lease terms (years): |  |  |  |  |  |
| Operating leases | 5 |  | 6 |  |  |
| Finance leases | 1 |  | 1 |  |  |
| Weighted average discount rate: |  |  |  |  |  |
| Operating leases | 4.07 | % |  | 3.11 | % |  |  |
| Finance leases | 3.23 | % |  | 3.99 | % |  |  |

[0000068505-23-000015:notes:96]
Future Lease Payments

[0000068505-23-000015:notes:97]
| December 31 (in millions) | Operating Leases |  | Finance Leases |  | Total |
| 2023 | $ | 137 |  |  | $ | 1 |  |  | $ | 138 |  |
| 2024 | 125 |  |  | — |  |  | 125 |  |
| 2025 | 108 |  |  | — |  |  | 108 |  |
| 2026 | 93 |  |  | — |  |  | 93 |  |
| 2027 | 50 |  |  | — |  |  | 50 |  |
| Thereafter | 80 |  |  | — |  |  | 80 |  |
| Total lease payments | $ | 593 |  |  | $ | 1 |  |  | $ | 594 |  |
| Less: Interest | 56 |  |  | — |  |  | 56 |  |
| Present value of lease liabilities | $ | 537 |  |  | $ | 1 |  |  | $ | 538 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-23-000015:notes:98]
Other Financial Data
Statement of Operations Information

[0000068505-23-000015:notes:99]
Other Charges (Income)

[0000068505-23-000015:notes:100]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-23-000015:notes:101]
| Years ended December 31 (in millions) | 2022 |  | 2021 |  | 2020 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 257 |  |  | $ | 236 |  |  | $ | 215 |  |
| Reorganization of businesses (Note 14) | 18 |  |  | 24 |  |  | 57 |  |
| Legal Settlements | 23 |  |  | 3 |  |  | 9 |  |
| Fixed asset impairments | 12 |  |  | — |  |  | 5 |  |
| Gain on sale of property, plant, and equipment | — |  |  | — |  |  | (50) |  |
| Operating lease asset impairments | 24 |  |  | 10 |  |  | — |  |
| Acquisition-related transaction fees | 23 |  |  | 15 |  |  | 9 |  |
| Gain on Hytera legal settlement | (15) |  |  | — |  |  | — |  |
| Other | (3) |  |  | (2) |  |  | 1 |  |
|  | $ | 339 |  |  | $ | 286 |  |  | $ | 246 |  |

[0000068505-23-000015:notes:102]
During the year ended December 31, 2022, the Company recognized a gain of $15 million related to the recovery, through legal proceedings to seize and liquidate assets, of financial receivables owed to the Company by the bankruptcy estate of two U.S. subsidiaries of Hytera Communications Corporation Limited of Shenzhen, China. Refer also to "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our consolidated financial statements included in this "Part I, Item 8.Financial Statements and Supplementary Data" of this Form 10-K for additional information related to these proceedings.

[0000068505-23-000015:notes:103]
During the year ended December 31, 2022, the Company recognized $24 million of operating lease asset impairments primarily relating to the Company's reduction of its corporate real estate footprint. This loss has been recognized in Other charges in the Company's Consolidated Statements of Operations. During the year ended December 31, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe.

[0000068505-23-000015:notes:104]
Other Income (Expense)

[0000068505-23-000015:notes:105]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-23-000015:notes:106]
| Years ended December 31 (in millions) | 2022 |  | 2021 |  | 2020 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (240) |  |  | $ | (215) |  |  | $ | (233) |  |
| Interest income | 14 |  |  | 7 |  |  | 13 |  |
|  | $ | (226) |  |  | $ | (208) |  |  | $ | (220) |  |
| Other, net: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 123 |  |  | $ | 123 |  |  | $ | 81 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (6) |  |  | (18) |  |  | (56) |  |
| Investment impairments | (1) |  |  | — |  |  | (4) |  |
| Foreign currency gain (loss) | 37 |  |  | 17 |  |  | (44) |  |
| Gain (loss) on derivative instruments | (61) |  |  | (30) |  |  | 25 |  |
| Gains (loss) on equity method investments | (3) |  |  | 5 |  |  | 3 |  |
| Fair value adjustments to equity investments | (30) |  |  | (8) |  |  | 6 |  |
| Gain on TETRA Ireland equity method investment | 21 |  |  | — |  |  | — |  |
| Other | (3) |  |  | 3 |  |  | 2 |  |
|  | $ | 77 |  |  | $ | 92 |  |  | $ | 13 |  |

[0000068505-23-000015:notes:107]
The Company previously held a minority ownership interest in TETRA Ireland, and, upon acquisition of 100% of the equity of TETRA Ireland on March 23, 2022, recorded a $21 million gain to adjust the Company's initial equity method investment to fair value during the year ended December 31, 2022. Refer to "Note 15:" Intangible Assets and Goodwill" to the Company's consolidated financial statements included in this "Part II.Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information related to this acquisition.

[0000068505-23-000015:notes:108]
Earnings Per Common Share

[0000068505-23-000015:notes:109]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-23-000015:notes:110]
|  |  |  |  |  |  |  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  |  |  | Net Earnings |
| Years ended December 31 |  |  |  |  |  |  | 2022 |  | 2021 |  | 2020 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 1,363 |  |  | $ | 1,245 |  |  | $ | 949 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 167.5 |  |  | 169.2 |  |  | 170.0 |  |
| Per share amount |  |  |  |  |  |  | $ | 8.14 |  |  | $ | 7.36 |  |  | $ | 5.58 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 1,363 |  |  | $ | 1,245 |  |  | $ | 949 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 167.5 |  |  | 169.2 |  |  | 170.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards |  |  |  |  |  |  | 3.7 |  |  | 4.0 |  |  | 4.1 |  |
| 1.75% senior convertible notes |  |  |  |  |  |  | 0.7 |  |  | 0.4 |  |  | — |  |
| Diluted weighted average common shares outstanding |  |  |  |  |  |  | 171.9 |  |  | 173.6 |  |  | 174.1 |  |
| Per share amount |  |  |  |  |  |  | $ | 7.93 |  |  | $ | 7.17 |  |  | $ | 5.45 |  |

[0000068505-23-000015:notes:111]
In the computation of diluted earnings per common share for the year ended December 31, 2022, the assumed exercise of 0.3 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2021, the assumed exercise of 0.2 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-23-000015:notes:112]
As of December 31, 2022, the Company had $1.0 billion of senior convertible notes outstanding, which mature on September 15, 2024 ("Senior Convertible Notes"). The notes are convertible based on a rate of 4.9140 per $1,000 principal amount as of December 31, 2022 (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the year ended December 31, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended December 31, 2022. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of December 31, 2022 was $304 million. Refer to "Note 5: Debt and Credit Facilities" in this “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for a further discussion of the Senior Convertible Notes.

[0000068505-23-000015:notes:113]
Balance Sheet Information

[0000068505-23-000015:notes:114]
Accounts Receivable, Net

[0000068505-23-000015:notes:115]
Accounts receivable, net, consists of the following:

[0000068505-23-000015:notes:116]
| December 31 | 2022 |  | 2021 |
| Accounts receivable | $ | 1,579 |  |  | $ | 1,456 |  |
| Less allowance for credit losses | (61) |  |  | (70) |  |
|  | $ | 1,518 |  |  | $ | 1,386 |  |

[0000068505-23-000015:notes:117]
Inventories, Net

[0000068505-23-000015:notes:118]
Inventories, net, consist of the following:

[0000068505-23-000015:notes:119]
| December 31 | 2022 |  | 2021 |
| Finished goods | $ | 354 |  |  | $ | 268 |  |
| Work-in-process and production materials | 829 |  |  | 643 |  |
|  | 1,183 |  |  | 911 |  |
| Less inventory reserves | (128) |  |  | (123) |  |
|  | $ | 1,055 |  |  | $ | 788 |  |

[0000068505-23-000015:notes:120]
Other Current Assets

[0000068505-23-000015:notes:121]
Other current assets consist of the following:

[0000068505-23-000015:notes:122]
| December 31 | 2022 |  | 2021 |
| Current contract cost assets (Note 2) | $ | 61 |  |  | $ | 30 |  |
| Contractor receivables | 47 |  |  | 7 |  |
| Tax-related deposits (Note 7) | 33 |  |  | 41 |  |
| Other | 242 |  |  | 181 |  |
|  | $ | 383 |  |  | $ | 259 |  |

[0000068505-23-000015:notes:123]
Property, Plant and Equipment, Net

[0000068505-23-000015:notes:124]
Property, plant and equipment, net, consist of the following:

[0000068505-23-000015:notes:125]
| December 31 | 2022 |  | 2021 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 456 |  |  | 474 |  |
| Machinery and equipment | 2,303 |  |  | 2,439 |  |
|  | 2,764 |  |  | 2,918 |  |
| Less accumulated depreciation | (1,837) |  |  | (1,876) |  |
|  | $ | 927 |  |  | $ | 1,042 |  |

[0000068505-23-000015:notes:126]
During the year ended December 31, 2022, the Company signed a mutual agreement with the Home Office of the United Kingdom (the "Home Office") for the Company to exit the Emergency Services Network ("ESN") communications systems contract early, inclusive of twelve months of transition services through the end of 2023. During the third quarter of 2022, the Company determined that the future service potential of the ESN communications systems contract was limited, based on the Company's intention to terminate the contract in advance of the contracted service term. The Company thus recorded a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the contract with the Home Office based on its expectation that, more likely than not, the ESN long-lived asset group would be disposed of significantly before the end of its previously estimated useful life. The impairment loss was recorded in the Software and Services segment within cost of sales in the Consolidated Statements of Operations. The recognized impairment loss represents the amount by which the carrying amount of the asset group exceeded the fair value under a measurement of discounted cash flows.

[0000068505-23-000015:notes:127]
Depreciation expense for the years ended December 31, 2022, 2021, and 2020 was $183 million, $202 million and $194 million, respectively.

[0000068505-23-000015:notes:128]
Investments

[0000068505-23-000015:notes:129]
Investments consist of the following:

[0000068505-23-000015:notes:130]
| December 31 | 2022 |  | 2021 |  |  |  |  |
| Common stock | $ | 21 |  |  | $ | 69 |  |  |  |  |  |
| Strategic investments, at cost | 45 |  |  | 35 |  |  |  |  |  |
| Company-owned life insurance policies | 69 |  |  | 81 |  |  |  |  |  |
| Equity method investments | 12 |  |  | 24 |  |  |  |  |  |
|  | $ | 147 |  |  | $ | 209 |  |  |  |  |  |

[0000068505-23-000015:notes:131]
During the year ended December 31, 2021, the Company paid $50 million for equity securities of NewHold Investment Corp. ("NHIC"), a special purpose acquisition company (SPAC) that completed a business combination with Evolv Technologies, Inc. After the business combination, NHIC was renamed “Evolv Technologies Holdings, Inc.” During the years ended December 31, 2022 and December 31, 2021, the Company recognized a loss of $11 million and $30 million, respectively, in

[0000068505-23-000015:notes:132]
Other income (expense) within the Consolidated Statements of Operations related to a decrease in the fair value of the investment.

[0000068505-23-000015:notes:133]
During the year ended December 31, 2022, the Company sold $15 million of equity securities from a single investment, recognizing losses of $11 million in Other income (expense) within the Consolidated Statements of Operations.

[0000068505-23-000015:notes:134]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities.

[0000068505-23-000015:notes:135]
During the year ended December 31, 2022, the Company recorded a $1 million investment impairment charge, compared to no investment impairment charges during the year ended December 31, 2021 and $4 million in investment impairments charges during the year ended December 31, 2020, representing other-than-temporary declines in the value of the Company’s strategic equity investment portfolio.

[0000068505-23-000015:notes:136]
Other Assets

[0000068505-23-000015:notes:137]
Other assets consist of the following:

[0000068505-23-000015:notes:138]
| December 31 | 2022 |  | 2021 |
| Defined benefit plan assets (Note 8) | $ | 164 |  |  | $ | 365 |  |
| Non-current contract cost assets (Note 2) | 130 |  |  | 124 |  |
| Other | 16 |  |  | 69 |  |
|  | $ | 310 |  |  | $ | 558 |  |

[0000068505-23-000015:notes:139]
Accrued Liabilities

[0000068505-23-000015:notes:140]
Accrued liabilities consist of the following:

[0000068505-23-000015:notes:141]
| December 31 | 2022 |  | 2021 |
| Compensation | $ | 374 |  |  | $ | 360 |  |
| Tax liabilities (Note 7) | 367 |  |  | 183 |  |
| Dividend payable | 148 |  |  | 134 |  |
| Trade liabilities | 145 |  |  | 235 |  |
| Operating lease liabilities (Note 3) | 118 |  |  | 124 |  |
| Customer reserves | 78 |  |  | 102 |  |
| Other | 408 |  |  | 419 |  |
|  | $ | 1,638 |  |  | $ | 1,557 |  |

[0000068505-23-000015:notes:142]
Other Liabilities

[0000068505-23-000015:notes:143]
Other liabilities consist of the following:

[0000068505-23-000015:notes:144]
| December 31 | 2022 |  | 2021 |
| Defined benefit plans (Note 8) | $ | 1,004 |  |  | $ | 1,390 |  |
| Non-current contract liabilities (Note 2) | 363 |  |  | 306 |  |
| Unrecognized tax benefits (Note 7) | 29 |  |  | 36 |  |
| Deferred income taxes (Note 7) | 73 |  |  | 183 |  |
| Environmental Reserve | 108 |  |  | 108 |  |
| Other | 114 |  |  | 125 |  |
|  | $ | 1,691 |  |  | $ | 2,148 |  |

[0000068505-23-000015:notes:145]
Stockholders’ Equity Information

[0000068505-23-000015:notes:146]
Share Repurchase Program: Through a series of actions, the Board of Directors has authorized the Company to repurchase in the aggregate up to $16.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2022, the Company had used approximately $14.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $1.3 billion of authority available for future repurchases.

[0000068505-23-000015:notes:147]
The Company's share repurchases, including transaction costs, for 2022, 2021, and 2020 can be summarized as follows:

[0000068505-23-000015:notes:148]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2022 | 3.7 |  |  | $ | 225.00 |  |  | $ | 836 |  |
| 2021 | 2.5 |  |  | 208.41 |  |  | 528 |  |
| 2020 | 3.9 |  |  | 155.93 |  |  | 612 |  |

[0000068505-23-000015:notes:149]
Payment of Dividends: On November 17, 2022, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.79 per share of common stock to $0.88 per share of common stock. During the years ended December 31, 2022, 2021, and 2020 the Company paid $530 million, $482 million, and $436 million, respectively, in cash dividends to holders of its common stock. On January 14, 2022, the Company paid an additional $148 million in cash dividends to holders of its common stock.

[0000068505-23-000015:notes:150]
Accumulated Other Comprehensive Loss

[0000068505-23-000015:notes:151]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2022, 2021, and 2020:

[0000068505-23-000015:notes:152]
|  | Years ended December 31 |
|  | 2022 |  | 2021 |  | 2020 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (384) |  |  | $ | (360) |  |  | $ | (410) |  |
| Other comprehensive income (loss) before reclassification adjustment | (156) |  |  | (30) |  |  | 55 |  |
| Tax benefit (expense) | 1 |  |  | 6 |  |  | (5) |  |
| Other comprehensive income (loss), net of tax | (155) |  |  | (24) |  |  | 50 |  |
| Balance at end of period | $ | (539) |  |  | $ | (384) |  |  | $ | (360) |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (1,995) |  |  | $ | (2,086) |  |  | $ | (2,030) |  |
| Other comprehensive income (loss) before reclassification adjustment | (76) |  |  | 37 |  |  | (130) |  |
| Tax benefit (expense) | 18 |  |  | (7) |  |  | 30 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (58) |  |  | 30 |  |  | (100) |  |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 80 |  |  | 89 |  |  | 76 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (2) |  |  | (8) |  |  | (18) |  |
| Tax expense | (21) |  |  | (20) |  |  | (14) |  |
| Reclassification adjustments into Net earnings, net of tax | 57 |  |  | 61 |  |  | 44 |  |
| Other comprehensive income (loss), net of tax | (1) |  |  | 91 |  |  | (56) |  |
| Balance at end of period | $ | (1,996) |  |  | $ | (1,995) |  |  | $ | (2,086) |  |
| Total Accumulated other comprehensive loss | $ | (2,535) |  |  | $ | (2,379) |  |  | $ | (2,446) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-23-000015:notes:153]
Debt and Credit Facilities
Long-Term Debt

[0000068505-23-000015:notes:154]
| December 31 | 2022 |  | 2021 |
| 4.0% senior notes due 2024 | 312 |  |  | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 694 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 845 |  |  | 844 |  |
| 5.60% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | — |  |  | 5 |  |
|  | 6,015 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (1) |  |  | (5) |  |
| Long-term debt | $ | 6,013 |  |  | $ | 5,688 |  |

[0000068505-23-000015:notes:155]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue the Senior Convertible Notes. Interest on these notes is payable semiannually. The notes became fully convertible as of September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount as of December 31, 2022 (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Senior Convertible Notes are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings.  Refer to "Note 1: Summary of Accounting Policies" in this “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for a further discussion regarding the effect of the adoption of ASU 2020-06.

[0000068505-23-000015:notes:156]
In August of 2020, the Company issued $900 million of 2.30% senior notes due 2030. The Company recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% senior notes due 2022 for a redemption price of $582 million, excluding $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of its long-term debt under a tender offer, for a purchase price of $315 million, excluding $5 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-23-000015:notes:157]
In May of 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of the 3.5% senior notes due 2023 for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-23-000015:notes:158]
In May of 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the Company's 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-23-000015:notes:159]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement (defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the commercial paper notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not

[0000068505-23-000015:notes:160]
redeemable prior to maturity. As of December 31, 2022 the Company had no outstanding debt under the commercial paper program.

[0000068505-23-000015:notes:161]
Aggregate requirements for long-term debt maturities during the next three years are as follows: 2023—$1 million; 2024—$1.3 billion; and 2025—$322 million. The Company has no maturities of long-term debt in 2026 or 2027.

[0000068505-23-000015:notes:162]
Credit Facilities
As of December 31, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million.  An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2022. Subsequent to year end, on February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to the Secured Overnight Financing Rate (SOFR).


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-23-000015:notes:163]
Risk Management
Foreign Currency Risk

[0000068505-23-000015:notes:164]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.1 billion at each of December 31, 2022 and December 31, 2021. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-23-000015:notes:165]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2022 and the corresponding positions as of December 31, 2021:

[0000068505-23-000015:notes:166]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2022 |  | 2021 |
| British pound | $ | 290 |  |  | $ | 128 |  |
| Euro | 185 |  |  | 164 |  |
| Australian dollar | (130) |  |  | (76) |  |
| Chinese renminbi | (61) |  |  | (89) |  |
| Brazilian real | (44) |  |  | (23) |  |

[0000068505-23-000015:notes:167]
Net Investment Hedges

[0000068505-23-000015:notes:168]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of December 31, 2022, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £45 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-23-000015:notes:169]
Counterparty Risk

[0000068505-23-000015:notes:170]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2022, all of the counterparties had investment grade credit ratings. As of December 31, 2022, the credit risk with all derivative counterparties was approximately $15 million.

[0000068505-23-000015:notes:171]
Derivative Financial Instruments

[0000068505-23-000015:notes:172]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2022 and 2021:

[0000068505-23-000015:notes:173]
|  | Fair Values of Derivative Instruments |
| December 31, 2022 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 5 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 15 |  | $ | — |  |
| Total derivatives | $ | 15 |  |  | $ | 5 |  |

[0000068505-23-000015:notes:174]
|  | Fair Values of Derivative Instruments |
| December 31, 2021 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 2 |  | 5 |
| Total derivatives | $ | 7 |  |  | $ | 5 |  |

[0000068505-23-000015:notes:175]
The following table summarizes the effect of derivatives on the Company's consolidated financial statements for the years ended December 31, 2022, 2021 and 2020:

[0000068505-23-000015:notes:176]
|  | Financial Statement Location |  |  |  |  |  |
| Foreign Exchange Contracts | 2022 |  | 2021 |  | 2020 |
| Effective portion of derivatives designated | Accumulated other comprehensive income (loss) | $ | 12 |  |  | $ | 13 |  |  | $ | (7) |  |
| Derivatives not designated as hedging instruments | Other income (expense) | $ | (61) |  |  | $ | (30) |  |  | $ | 25 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-23-000015:notes:177]
Income Taxes
Components of Income Tax Expense

[0000068505-23-000015:notes:178]
Components of earnings before income taxes are as follows:

[0000068505-23-000015:notes:179]
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |
| United States | $ | 1,312 |  |  | $ | 1,030 |  |  | $ | 1,029 |  |
| Other nations | 203 |  |  | 522 |  |  | 145 |  |
|  | $ | 1,515 |  |  | $ | 1,552 |  |  | $ | 1,174 |  |

[0000068505-23-000015:notes:180]
Components of income tax expense are as follows:

[0000068505-23-000015:notes:181]
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |
| United States Federal | $ | 240 |  |  | $ | 134 |  |  | $ | 117 |  |
| Other nations | 159 |  |  | 98 |  |  | 98 |  |
| States (U.S.) | 83 |  |  | 36 |  |  | 31 |  |
| Current income tax expense | 482 |  |  | 268 |  |  | 246 |  |
| United States Federal | (179) |  |  | (2) |  |  | (21) |  |
| Other nations | (118) |  |  | 22 |  |  | 8 |  |
| States (U.S.) | (37) |  |  | 14 |  |  | (12) |  |
| Deferred income tax expense (benefit) | (334) |  |  | 34 |  |  | (25) |  |
| Total income tax expense | $ | 148 |  |  | $ | 302 |  |  | $ | 221 |  |

[0000068505-23-000015:notes:182]
Differences between income tax expense computed at the U.S. federal statutory tax rate of 21% and income tax expense as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-23-000015:notes:183]
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |
| Income tax expense at statutory rate | $ | 318 |  | 21.0 | % |  | $ | 326 |  | 21.0 | % |  | $ | 246 |  | 21.0 | % |
| State income taxes, net of federal benefit | 76 |  | 5.0 | % |  | 55 |  | 3.5 | % |  | 39 |  | 3.3 | % |
| Non-U.S. tax expense on non-U.S. earnings | 1 |  | 0.1 | % |  | 8 |  | 0.5 | % |  | 5 |  | 0.5 | % |
| U.S. tax expense (benefit) on undistributed non-U.S. earnings | (43) |  | (2.8) | % |  | 6 |  | 0.4 | % |  | (2) |  | (0.2) | % |
| Intra-group IP transfer | (77) |  | (5.1) | % |  | — |  | — | % |  | — |  | — | % |
| Stock compensation | (68) |  | (4.5) | % |  | (32) |  | (2.1) | % |  | (48) |  | (4.1) | % |
| Valuation allowances | (51) |  | (3.4) | % |  | (34) |  | (2.2) | % |  | 4 |  | 0.3 | % |
| Research credits | (16) |  | (1.1) | % |  | (20) |  | (1.3) | % |  | (28) |  | (2.4) | % |
| Reserve for uncertain tax positions | (6) |  | (0.4) | % |  | (10) |  | (0.6) | % |  | — |  | — | % |
| Other tax expense (benefit) | 14 |  | 0.9 | % |  | 3 |  | 0.2 | % |  | 5 |  | 0.4 | % |
|  | $ | 148 |  | 9.8 | % |  | $ | 302 |  | 19.5 | % |  | $ | 221 |  | 18.8 | % |

[0000068505-23-000015:notes:184]
The effective tax rate for 2022 was below the current U.S. federal statutory rate of 21% primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain intellectual property ("IP") rights (described below), the recognition of excess tax benefits on share-based compensation, the foreign derived intangible income deduction, and a partial release of the valuation allowance recorded on the U.S. foreign tax credit carryforward.

[0000068505-23-000015:notes:185]
In January 2022, the Company completed an intra-group transfer of certain IP rights from non-U.S. wholly-owned subsidiaries of the Company to the United States in order to better align with current and future business operations. The transfer resulted in a step-up in tax basis driven by the fair value of the transferred IP rights, resulting in a one-time net deferred benefit of $77 million during 2022. The determination of the fair value involves judgment on future revenue growth, operating margins and discount rates. The Company expects to realize the net deferred tax asset recorded as a result of the IP transfer and will periodically assess such realizability. The tax-deductible amortization related to the transferred IP rights will be recognized over a 15-year period.

[0000068505-23-000015:notes:186]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are the result of retirement benefit adjustments and currency translation adjustments. The adjustments were charges of $2 million for the year ended December 31, 2022, charges of $21 million for the year ended December 31, 2021 and benefits of $11 million for the year ended December 31, 2020.

[0000068505-23-000015:notes:187]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the 2017 U.S. Tax Cuts and Jobs Act ("the Tax Act"), dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-23-000015:notes:188]
Undistributed foreign earnings that the Company intends to reinvest indefinitely amounted to, in the aggregate, $1.6 billion at December 31, 2022. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-23-000015:notes:189]
Gross deferred tax assets were $2.2 billion and $2.0 billion for December 31, 2022 and December 31, 2021, respectively. Deferred tax assets, net of valuation allowances, were $2.0 billion and $1.8 billion at December 31, 2022 and December 31, 2021, respectively. Gross deferred tax liabilities were $1.0 billion at each of December 31, 2022 and December 31, 2021, respectively.

[0000068505-23-000015:notes:190]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-23-000015:notes:191]
| December 31 | 2022 |  | 2021 |
| Inventory | $ | 38 |  |  | $ | 29 |  |
| Accrued liabilities and allowances | 67 |  |  | 86 |  |
| Employee benefits | 290 |  |  | 321 |  |
| Capitalized items | 95 |  |  | (86) |  |
| Tax basis differences on investments | 6 |  |  | (1) |  |
| Depreciation tax basis differences on fixed assets | 1 |  |  | 23 |  |
| Undistributed non-U.S. earnings | (38) |  |  | (36) |  |
| Tax attribute carryforwards | 298 |  |  | 410 |  |
| Business reorganization | 7 |  |  | 8 |  |
| Warranty and customer liabilities | 22 |  |  | 27 |  |
| Deferred revenue and costs | 382 |  |  | 213 |  |
| Valuation allowances | (221) |  |  | (275) |  |
| Operating lease assets | (116) |  |  | (95) |  |
| Operating lease liabilities | 129 |  |  | 108 |  |
| Other | 4 |  |  | 1 |  |
|  | $ | 964 |  |  | $ | 733 |  |

[0000068505-23-000015:notes:192]
At December 31, 2022 and 2021, the Company had valuation allowances of $221 million and $275 million, respectively, against its deferred tax assets, including $46 million and $53 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance decreased $47 million during 2022 primarily due to a change in the Company's ability to utilize U.S. foreign tax credits. The Company's Non-U.S. valuation allowance decreased $7 million during 2022 primarily due to a change in the realizability of certain Non-US deferred tax assets and the expiration of tax attributes. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-23-000015:notes:193]
Tax attribute carryforwards are as follows:

[0000068505-23-000015:notes:194]
| December 31, 2022 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 109 |  |  | $ | 23 |  |  | 2029-2037 |
| Foreign tax credits | — |  |  | 181 |  |  | 2023 |
| General business credits | — |  |  | 1 |  |  | 2030-2033 |
| State tax losses | — |  |  | 16 |  |  | 2023-2041 |
| State tax credits | — |  |  | 6 |  |  | 2023-2041 |
| Non-U.S. subsidiaries: |  |  |  |  |  |
| Japan tax losses | 9 |  |  | 3 |  |  | 2023-2029 |
| United Kingdom tax losses | 152 |  |  | 38 |  |  | Unlimited |
| Canada tax losses | 17 |  |  | 4 |  |  | 2034-2042 |
| Spain tax credits | — |  |  | 11 |  |  | 2023-2029 |
| Other subsidiaries tax losses | 29 |  |  | 6 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 9 |  |  | Various |
|  |  |  | $ | 298 |  |  |  |

[0000068505-23-000015:notes:195]
The Company had unrecognized tax benefits of $35 million and $43 million at December 31, 2022 and December 31, 2021, respectively, of which approximately $29 million and $36 million, if recognized, would have affected the effective tax rate for 2022 and 2021, respectively.

[0000068505-23-000015:notes:196]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-23-000015:notes:197]
| (in millions) | 2022 |  | 2021 |
| Balance at January 1 | $ | 43 |  |  | $ | 64 |  |
| Additions based on tax positions related to current year | 1 |  |  | 1 |  |
| Additions for tax positions of prior years | 2 |  |  | 2 |  |
| Reductions for tax positions of prior years | (1) |  |  | — |  |
| Settlements and agreements | (4) |  |  | (18) |  |
| Lapse of statute of limitations | (6) |  |  | (6) |  |
| Balance at December 31 | $ | 35 |  |  | $ | 43 |  |

[0000068505-23-000015:notes:198]
The Company recorded $29 million and $36 million of unrecognized tax benefits in other liabilities at December 31, 2022 and December 31, 2021, respectively.

[0000068505-23-000015:notes:199]
The Company has several US state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-23-000015:notes:200]
| Jurisdiction | Tax Years |
| United States | 2018-2022 |
| Australia | 2018-2022 |
| Canada | 2018-2022 |
| Germany | 2018-2022 |
| India | 1997-2022 |
| Israel | 2019-2022 |
| Poland | 2016-2022 |
| Malaysia | 2015-2022 |
| United Kingdom | 2020-2022 |

[0000068505-23-000015:notes:201]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-23-000015:notes:202]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be up to a $6 million tax benefit.

[0000068505-23-000015:notes:203]
At December 31, 2022, the Company had $22 million accrued for interest and $12 million accrued for penalties on unrecognized tax benefits. At December 31, 2021, the Company had $22 million and $15 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-23-000015:notes:204]
Retirement Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-23-000015:notes:205]
U.S. Pension Benefit Plans

[0000068505-23-000015:notes:206]
The Company’s non-contributory U.S. defined benefit plans (the "U.S. Pension Plans") provide benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. In December 2008, the Company amended the U.S. Pension Plans and MSPP (together the "U.S. Pension Benefit Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-23-000015:notes:207]
Postretirement Health Care Benefits Plan

[0000068505-23-000015:notes:208]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment or retirement eligibility (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of

[0000068505-23-000015:notes:209]
amendments, all eligible retirees under the age of 65 are provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-23-000015:notes:210]
Non-U.S. Pension Benefit Plans

[0000068505-23-000015:notes:211]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-23-000015:notes:212]
In June 2015, the Company amended its non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-23-000015:notes:213]
Net Periodic Cost (Benefit)

[0000068505-23-000015:notes:214]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-23-000015:notes:215]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 128 |  |  | 115 |  |  | 144 |  |  | 29 |  |  | 21 |  |  | 29 |  |  | 2 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (254) |  |  | (235) |  |  | (225) |  |  | (93) |  |  | (99) |  |  | (85) |  |  | (12) |  |  | (11) |  |  | (10) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 62 |  |  | 70 |  |  | 58 |  |  | 14 |  |  | 16 |  |  | 15 |  |  | 4 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (2) |  |  | (3) |  |  | (3) |  |  | — |  |  | (5) |  |  | (15) |  |
| Net periodic cost (benefit) | $ | (64) |  |  | $ | (50) |  |  | $ | (23) |  |  | $ | (51) |  |  | $ | (64) |  |  | $ | (42) |  |  | $ | (6) |  |  | $ | (12) |  |  | $ | (20) |  |

[0000068505-23-000015:notes:216]
The status of the Company’s plans is as follows:

[0000068505-23-000015:notes:217]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 5,140 |  |  | $ | 5,226 |  |  | $ | 1,935 |  |  | $ | 2,058 |  |  | $ | 78 |  |  | $ | 71 |  |
| Service cost | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Interest cost | 128 |  |  | 115 |  |  | 29 |  |  | 21 |  |  | 2 |  |  | 1 |  |
| Plan amendments | — |  |  | — |  |  | — |  |  | — |  |  | 46 |  |  | — |  |
| Actuarial loss (gain) | (1,329) |  |  | (71) |  |  | (534) |  |  | (61) |  |  | (12) |  |  | 10 |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (174) |  |  | (31) |  |  | — |  |  | — |  |
| Benefit payments | (130) |  |  | (130) |  |  | (50) |  |  | (53) |  |  | (11) |  |  | (4) |  |
| Benefit obligation at December 31 | $ | 3,809 |  |  | $ | 5,140 |  |  | $ | 1,207 |  |  | $ | 1,935 |  |  | $ | 103 |  |  | $ | 78 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 4,157 |  |  | $ | 4,083 |  |  | $ | 1,870 |  |  | $ | 1,880 |  |  | $ | 186 |  |  | $ | 181 |  |
| Return on plan assets | (954) |  |  | 201 |  |  | (555) |  |  | 43 |  |  | (41) |  |  | 9 |  |
| Company contributions | 3 |  |  | 3 |  |  | 8 |  |  | 9 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (181) |  |  | (9) |  |  | — |  |  | — |  |
| Benefit payments | (130) |  |  | (130) |  |  | (50) |  |  | (53) |  |  | (11) |  |  | (4) |  |
| Fair value at December 31 | $ | 3,076 |  |  | $ | 4,157 |  |  | $ | 1,092 |  |  | $ | 1,870 |  |  | $ | 134 |  |  | $ | 186 |  |
| Funded status of the plan | $ | (733) |  |  | $ | (983) |  |  | $ | (115) |  |  | $ | (65) |  |  | $ | 31 |  |  | $ | 108 |  |
| Unrecognized net loss | 1,689 |  |  | 1,871 |  |  | 758 |  |  | 655 |  |  | 70 |  |  | 31 |  |
| Unrecognized prior service benefit (cost) | — |  |  | — |  |  | (70) |  |  | (77) |  |  | 46 |  |  | — |  |
| Prepaid pension cost | $ | 956 |  |  | $ | 888 |  |  | $ | 573 |  |  | $ | 513 |  |  | $ | 147 |  |  | $ | 139 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3) |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (730) |  |  | (980) |  |  | (185) |  |  | (297) |  |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 70 |  |  | 232 |  |  | 31 |  |  | 108 |  |
| Deferred income taxes | 403 |  |  | 454 |  |  | 83 |  |  | 61 |  |  | 32 |  |  | 11 |  |
| Accumulated other comprehensive loss | 1,286 |  |  | 1,417 |  |  | 605 |  |  | 517 |  |  | 84 |  |  | 20 |  |
| Prepaid pension cost | $ | 956 |  |  | $ | 888 |  |  | $ | 573 |  |  | $ | 513 |  |  | $ | 147 |  |  | $ | 139 |  |

[0000068505-23-000015:notes:218]
For the year ended December 31, 2022, the primary driver of the decrease in the U.S. Pension Benefit Plans' benefit obligation was higher actuarial gains due to an increase in the discount rate from 2.98% as of December 31, 2021 to 5.20% as of December 31, 2022. For the year ended December 31, 2021, the primary driver of the decrease in the U.S. Pension Benefit Plans benefit obligation was higher actuarial gains due to an increase in the discount rate from 2.63% as of December 31, 2020 to 2.98% as of December 31, 2021, partially offset by increases in the benefit obligation due to demographic assumption updates.

[0000068505-23-000015:notes:219]
For the year ended December 31, 2022, the most significant drivers of the decrease in Non-U.S. Pension Benefit Plans' benefit obligation were the higher actuarial gains coupled with favorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial gains primarily due to increases in the discount rates from 1.82% as of December 31, 2021 to 4.60% as of December 31, 2022. For the year ended December 31, 2021, the most significant drivers of the decrease in Non-U.S. Pension Benefit Plans benefit obligation were the higher actuarial gains coupled with favorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial gains primarily due to an increase in the discount rate from 1.24% as of December 31, 2020 to 1.82% as of December 31, 2021.

[0000068505-23-000015:notes:220]
Actuarial Assumptions

[0000068505-23-000015:notes:221]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-23-000015:notes:222]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-23-000015:notes:223]
The Company used "Mortality Improvement Scale MP-2021" to calculate both the 2022 U.S. projected benefit obligations and the 2021 U.S. projected benefit obligations.

[0000068505-23-000015:notes:224]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-23-000015:notes:225]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Discount rate | 2.52 | % |  | 2.25 | % |  | 1.68 | % |  | 1.02 | % |  | 2.78 | % |  | 1.57 | % |
| Investment return assumption | 6.76 | % |  | 6.75 | % |  | 4.78 | % |  | 4.54 | % |  | 6.90 | % |  | 6.75 | % |

[0000068505-23-000015:notes:226]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-23-000015:notes:227]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Discount rate | 5.20 | % |  | 2.98 | % |  | 4.60 | % |  | 1.82 | % |  | 5.10 | % |  | 2.78 | % |
| Future compensation increase rate | n/a |  | n/a |  | 0.67 | % |  | 0.54 | % |  | n/a |  | n/a |

[0000068505-23-000015:notes:228]
The following table presents the accumulated benefit obligation, projected benefit obligation and fair value of plan assets for our plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets:

[0000068505-23-000015:notes:229]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  |
| December 31 | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |
| Accumulated benefit obligation | $ | 3,809 |  |  | $ | 5,140 |  |  | $ | 1,206 |  |  | $ | 1,933 |  |  |  |  |
| Projected benefit obligation | 3,809 |  |  | 5,140 |  |  | 1,207 |  |  | 1,935 |  |  |  |  |
| Fair value of plan assets | 3,076 |  |  | 4,157 |  |  | 1,092 |  |  | 1,870 |  |  |  |  |

[0000068505-23-000015:notes:230]
Investment Policy

[0000068505-23-000015:notes:231]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-23-000015:notes:232]
The weighted-average asset allocations by asset categories for all pension plans and the Postretirement Health Care Benefits Plan were as follows:

[0000068505-23-000015:notes:233]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 25 | % |  | 26 | % |  | 28 | % |  | 28 | % |
| Fixed income securities | 57 | % |  | 57 | % |  | 52 | % |  | 52 | % |
| Cash and other investments | 18 | % |  | 17 | % |  | 20 | % |  | 20 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 25 | % |  | 26 | % |  | 28 | % |  | 29 | % |
| Fixed income securities | 56 | % |  | 58 | % |  | 52 | % |  | 53 | % |
| Cash and other investments | 19 | % |  | 16 | % |  | 20 | % |  | 18 | % |

[0000068505-23-000015:notes:234]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-23-000015:notes:235]
Cash Funding

[0000068505-23-000015:notes:236]
The Company made $3 million of contributions to its U.S. Pension Benefit Plans during each of 2022 and 2021. The Company contributed $8 million and $9 million to its Non U.S. Pension Benefit Plans during 2022 and 2021,respectively. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2022 or 2021.

[0000068505-23-000015:notes:237]
Expected Future Benefit Payments

[0000068505-23-000015:notes:238]
The following benefit payments are expected to be paid:

[0000068505-23-000015:notes:239]
| Year | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2023 | $ | 165 |  |  | $ | 50 |  |  | $ | 15 |  |
| 2024 | 187 |  |  | 52 |  |  | 14 |  |
| 2025 | 207 |  |  | 53 |  |  | 13 |  |
| 2026 | 226 |  |  | 54 |  |  | 12 |  |
| 2027 | 244 |  |  | 56 |  |  | 11 |  |
| 2028-2032 | 1,366 |  |  | 293 |  |  | 35 |  |

[0000068505-23-000015:notes:240]
Other Benefit Plans

[0000068505-23-000015:notes:241]
Split-Dollar Life Insurance Arrangements

[0000068505-23-000015:notes:242]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-23-000015:notes:243]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2022, 2021 and 2020. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $54 million and $68 million as of December 31, 2022 and December 31, 2021, respectively.

[0000068505-23-000015:notes:244]
Deferred Compensation Plan

[0000068505-23-000015:notes:245]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the 401(k) plan (as defined below). The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for officers elected by the board of directors of the Company, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-23-000015:notes:246]
Defined Contribution Plan

[0000068505-23-000015:notes:247]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the Motorola Solutions 401(k) plan (the "401(k) plan") is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2022, 2021 and 2020 were $43 million, $36 million and $15 million, respectively.

[0000068505-23-000015:notes:248]
Due to the economic uncertainties caused by the COVID-19 pandemic, the Company took action in a number of areas to reduce its operating expenses, including by suspending all Company match contributions to the 401(k) plan for the period from May 15, 2020 through December 31, 2020, which were reinstated on January 1, 2021.

[0000068505-23-000015:notes:249]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2022, 2021, and 2020 the Company made no discretionary contributions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-23-000015:notes:250]
Share-Based Compensation and Other Incentive Plans
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option and stock appreciation right granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-23-000015:notes:251]
Restricted stock grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees. The grants are restricted in such that they are subject to vesting conditions; however, restricted stock holders have voting rights, and the rights to earn dividends on unvested shares.

[0000068505-23-000015:notes:252]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-23-000015:notes:253]
Performance-based stock options (“performance options”), market stock units ("MSUs"), and performance stock units ("PSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years. PSUs have been granted as a portion of the Long Range Incentive Plan (“LRIP”) awards issued to certain Company executive officers. The PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual TSR compared to the S&P 500 over the three-year performance period.

[0000068505-23-000015:notes:254]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2022, 2021 and 2020, employees purchased 0.4 million, 0.6 million and 0.7 million shares, respectively, at purchase prices of $199.16 and $190.37, $133.27 and $160.11, and $112.98 and $107.18, respectively.

[0000068505-23-000015:notes:255]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-23-000015:notes:256]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2022, 2021 and 2020 was $67.18, $41.57 and $39.98, respectively, using the following weighted-average assumptions:

[0000068505-23-000015:notes:257]
|  | 2022 |  | 2021 |  | 2020 |
| Expected volatility | 29.2 | % |  | 27.3 | % |  | 33.7 | % |
| Risk-free interest rate | 2.5 | % |  | 0.8 | % |  | 0.6 | % |
| Dividend yield | 1.9 | % |  | 2.2 | % |  | 2.7 | % |
| Expected life (years) | 6.6 |  | 5.9 |  | 5.9 |

[0000068505-23-000015:notes:258]
The Company calculates the value of each performance option, MSU, and PSU using a Monte Carlo simulation option pricing model, estimated on the date of grant. The fair values of performance options, MSUs, and PSUs granted during 2022 were $84.73, $244.13 and $249.51, respectively. The fair values of performance options, MSUs, and PSUs granted during 2021 were $60.42, $184.71 and $203.57, respectively. The fair value of performance options, MSUs and PSUs granted during 2020 was $77.82, $112.17 and $233.96, respectively. The following assumptions were used for the calculations.

[0000068505-23-000015:notes:259]
|  | 2022 |  | 2021 |  | 2020 |
|  | Performance Options |  | Performance Options |  | Performance Options |
| Expected volatility of common stock | 29.7 | % |  | 28.5 | % |  | 34.7 | % |
| Expected volatility of the S&P 500 | 39.2 | % |  | 38.7 | % |  | 29.0 | % |
| Risk-free interest rate | 2.0 | % |  | 1.2 | % |  | 0.8 | % |
| Dividend yield | 2.0 | % |  | 2.3 | % |  | 2.6 | % |
| Expected life (years) | 6.5 |  | 6.5 |  | 6.5 |

[0000068505-23-000015:notes:260]
|  | 2022 |  | 2021 |  | 2020 |
|  | Market Stock Unit |  | Market Stock Unit |  | Market Stock Units |
| Expected volatility of common stock | 29.7 | % |  | 28.5 | % |  | 34.7 | % |
| Risk-free interest rate | 1.9 | % |  | 0.3 | % |  | 0.6 | % |
| Dividend yield | 1.6 | % |  | 1.8 | % |  | 1.7 | % |

[0000068505-23-000015:notes:261]
|  | 2022 |  |  | 2021 | 2020 |
|  | Performance Stock Units |  |  | Performance Stock Units | Performance Stock Units |
| Expected volatility of common stock | 29.7 | % |  |  | 28.5 | % | 34.7 | % |
| Expected volatility of the S&P 500 | 39.2 | % |  |  | 38.7 | % | 29.0 | % |
| Risk-free interest rate | 1.8 | % |  |  | 0.3 | % | 0.6 | % |
| Dividend yield | 1.6 | % |  |  | 1.8 | % | 1.7 | % |

[0000068505-23-000015:notes:262]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PSUs. The selection of the implied volatility approach was based upon the availability of actively-traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. At the conclusion of each three-year PSU and performance option cycle, the Company uses the historical volatility as the expected volatility to calculate the actual TSR compared to the S&P 500.

[0000068505-23-000015:notes:263]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-23-000015:notes:264]
The Company has applied forfeiture rates, estimated based on historical data, of 10% to the stock option fair values calculated by the Black-Scholes option pricing model and 15% to RSUs. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-23-000015:notes:265]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, at December 31, 2022 (in thousands, except exercise price and years):

[0000068505-23-000015:notes:266]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| $51-$70 | 586 |  |  | 66 |  |  | 2 |  | 586 |  |  | 66 |  |  | 2 |
| $71-$90 | 786 |  |  | 77 |  |  | 4 |  | 786 |  |  | 77 |  |  | 4 |
| $91-$110 | 267 |  |  | 108 |  |  | 5 |  | 267 |  |  | 108 |  |  | 5 |
| $111-$130 | 51 |  |  | 121 |  |  | 6 |  | 40 |  |  | 121 |  |  | 6 |
| $131-$150 | 288 |  |  | 139 |  |  | 6 |  | 281 |  |  | 139 |  |  | 6 |
| $151-$170 | 206 |  |  | 156 |  |  | 7 |  | 56 |  |  | 157 |  |  | 7 |
| $171-$190 | 284 |  |  | 180 |  |  | 8 |  | 38 |  |  | 180 |  |  | 8 |
| $191 and over | 303 |  |  | 225 |  |  | 9 |  | 11 |  |  | 223 |  |  | 9 |
|  | 2,771 |  |  |  |  |  |  | 2,065 |  |  |  |  |  |

[0000068505-23-000015:notes:267]
As of December 31, 2022, the weighted average contractual life for options outstanding and exercisable was four and three years, respectively.

[0000068505-23-000015:notes:268]
Current Year Activity

[0000068505-23-000015:notes:269]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-23-000015:notes:270]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2022 | 1,587 |  |  | $ | 92 |  |  | 924 |  |  | $ | 199 |  |  | 209 |  |  | $ | 203 |  |
| Granted | 153 |  |  | 227 |  |  | 776 |  |  | 217 |  |  | 48 |  |  | 217 |  |
| Releases/Exercised | (734) |  |  | 70 |  |  | (408) |  |  | 157 |  |  | (143) |  |  | 195 |  |
| Forfeited/Canceled | (10) |  |  | 183 |  |  | (81) |  |  | 193 |  |  | — |  |  | — |  |
| Balance as of December 31, 2022 | 996 |  |  | $ | 128 |  |  | 1,211 |  |  | $ | 211 |  |  | 114 |  |  | $ | 224 |  |
| Awards exercisable | 684 |  |  | 95 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-23-000015:notes:271]
|  | Performance Options |  | Market Stock Units |  | Performance Stock Units |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2022 | 2,368 |  |  | $ | 91 |  |  | 120 |  |  | $ | 147 |  |  | 128 |  |  | $ | 210 |  |
| Granted | 122 |  |  | 222 |  |  | 43 |  |  | 244 |  |  | 68 |  |  | 248 |  |
| Releases/Exercised | (830) |  |  | 72 |  |  | (80) |  |  | 140 |  |  | (48) |  |  | 217 |  |
| Adjustment for payout factor | 115 |  |  | 133 |  |  | 20 |  |  | 129 |  |  | 21 |  |  | 217 |  |
| Balance as of December 31, 2022 | 1,775 |  |  | $ | 112 |  |  | 103 |  |  | $ | 192 |  |  | 169 |  |  | $ | 226 |  |
| Awards exercisable | 1,381 |  |  | 91 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-23-000015:notes:272]
At December 31, 2022 and 2021, 8.3 million and 4.9 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-23-000015:notes:273]
Total Share-Based Compensation Expense

[0000068505-23-000015:notes:274]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-23-000015:notes:275]
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 28 |  |  | $ | 16 |  |  | $ | 16 |  |
| Selling, general and administrative expenses | 98 |  |  | 79 |  |  | 73 |  |
| Research and development expenditures | 46 |  |  | 34 |  |  | 40 |  |
| Share-based compensation expense included in Operating earnings | 172 |  |  | 129 |  |  | 129 |  |
| Tax benefit | 34 |  |  | 15 |  |  | 30 |  |
| Share-based compensation expense, net of tax | $ | 138 |  |  | $ | 114 |  |  | $ | 99 |  |
| Decrease in basic earnings per share | $ | (0.82) |  |  | $ | (0.67) |  |  | $ | (0.58) |  |
| Decrease in diluted earnings per share | $ | (0.80) |  |  | $ | (0.66) |  |  | $ | (0.57) |  |

[0000068505-23-000015:notes:276]
At December 31, 2022, the Company had unrecognized compensation expense related to all share based awards of $184 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately three years and $5 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. The aggregate fair value of outstanding share based awards as of December 31, 2022 was $408 million.

[0000068505-23-000015:notes:277]
Cash received from stock option exercises and the employee stock purchase plan was $156 million, $102 million, and $108 million for the years ended December 31, 2022, 2021, and 2020, respectively. The total intrinsic value of options exercised during the years ended December 31, 2022, 2021, and 2020 was $292 million, $186 million, and $149 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2022 was $389 million and $342 million, respectively, based on a December 31, 2022 stock price of $257.71 per share.

[0000068505-23-000015:notes:278]
Motorola Solutions Incentive Plans

[0000068505-23-000015:notes:279]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2022, 2021 and 2020 was $165 million, $161 million and $78 million, respectively.

[0000068505-23-000015:notes:280]
Long-Range Incentive Plan

[0000068505-23-000015:notes:281]
The LRIP rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. The expense for those LRIP awards with cash settlement terms was $4 million, $8 million and $9 million for the years ended December 31, 2022, 2021 and 2020 , respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-23-000015:notes:282]
Fair Value Measurements
Investments and Derivatives

[0000068505-23-000015:notes:283]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2022 and December 31, 2021 were as follows:

[0000068505-23-000015:notes:284]
| December 31, 2022 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 15 |  |  |  |  | $ | 15 |  |
| Common stock and equivalents | 21 |  |  | — |  |  |  |  | 21 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-23-000015:notes:285]
| December 31, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |
| Common stock and equivalents | 69 |  |  | — |  |  |  |  | 69 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-23-000015:notes:286]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-23-000015:notes:287]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2022 and 2021 were as follows:

[0000068505-23-000015:notes:288]
| December 31, 2022 | Level 1 |  | Level 2 |  | Level 3 |  |  |  | Total |
| Equities | $ | 48 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 48 |  |
| Commingled funds | 1,159 |  |  | 488 |  |  | — |  |  |  |  | 1,647 |  |
| Government fixed income securities | — |  |  | 159 |  |  | — |  |  |  |  | 159 |  |
| Corporate fixed income securities | — |  |  | 863 |  |  | — |  |  |  |  | 863 |  |
| Short-term investment funds | 186 |  |  | — |  |  | — |  |  |  |  | 186 |  |
| Private assets | — |  |  | — |  |  | 111 |  |  |  |  | 111 |  |
| Total investment securities | $ | 1,393 |  |  | $ | 1,510 |  |  | $ | 111 |  |  |  |  | $ | 3,014 |  |
| Accrued income receivable |  |  |  |  |  |  |  |  | 45 |  |
| Cash |  |  |  |  |  |  |  |  | 17 |  |
| Fair value plan assets |  |  |  |  |  |  |  |  | $ | 3,076 |  |

[0000068505-23-000015:notes:289]
The following table summarizes the changes in fair value of the Level 3 assets:

[0000068505-23-000015:notes:290]
|  | 2022 |
| Fair value at January 1, 2022 | 60 |  |
| Actual return on plan assets | (1) |  |
| Purchases | 52 |  |
| Fair value at December 31, 2022 | 111 |  |

[0000068505-23-000015:notes:291]
| December 31, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |  |
| Equities | $ | 41 |  |  | $ | — |  |  | — |  |  | $ | 41 |  |  |  |
| Commingled funds | 1,601 |  |  | 505 |  |  | — |  |  | 2,106 |  |  |  |
| Government fixed income securities | — |  |  | 412 |  |  | — |  |  | 412 |  |  |  |
| Corporate fixed income securities | — |  |  | 1,145 |  |  | — |  |  | 1,145 |  |  |  |
| Short-term investment funds | 338 |  |  | — |  |  | — |  |  | 338 |  |  |  |
| Private Assets | — |  |  | — |  |  | 60 |  |  | 60 |  |  |  |
| Total investment securities | $ | 1,980 |  |  | $ | 2,062 |  |  | $ | 60 |  |  | $ | 4,102 |  |  |  |
| Accrued income receivable |  |  |  |  |  |  | 49 |  |  |  |
| Cash |  |  |  |  |  |  | 6 |  |  |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 4,157 |  |  |  |

[0000068505-23-000015:notes:292]
| December 31, 2022 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 55 |  |  | $ | — |  |  |  |  | $ | 55 |  |
| Commingled funds | 252 |  |  | 41 |  |  |  |  | 293 |  |
| Government fixed income securities | — |  |  | 491 |  |  |  |  | 491 |  |
| Short-term investment funds | 83 |  |  | — |  |  |  |  | 83 |  |
| Total investment securities | $ | 390 |  |  | $ | 532 |  |  |  |  | $ | 922 |  |
| Cash |  |  |  |  |  |  | 3 |  |
| Accrued income receivable |  |  |  |  |  |  | 121 |  |
| Insurance contracts |  |  |  |  |  |  | 46 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,092 |  |

[0000068505-23-000015:notes:293]
| December 31, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 94 |  |  | $ | — |  |  |  |  | $ | 94 |  |
| Commingled funds | 458 |  |  | 75 |  |  |  |  | 533 |  |
| Government fixed income securities | 2 |  |  | 1,004 |  |  |  |  | 1,006 |  |
| Short-term investment funds | 105 |  |  | — |  |  |  |  | 105 |  |
| Total investment securities | $ | 659 |  |  | $ | 1,079 |  |  |  |  | $ | 1,738 |  |
| Cash |  |  |  |  |  |  | 4 |  |
| Accrued income receivable |  |  |  |  |  |  | 78 |  |
| Insurance contracts |  |  |  |  |  |  | 50 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,870 |  |

[0000068505-23-000015:notes:294]
| December 31, 2022 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equities | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Commingled funds | 49 |  |  | 22 |  |  | — |  |  | 71 |  |
| Government fixed income securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Corporate fixed income securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Short-term investment funds | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Private funds | — |  |  | — |  |  | 5 |  |  | 5 |  |
| Total investment securities | $ | 59 |  |  | $ | 68 |  |  | 5 |  |  | 132 |  |
| Accrued income receivable |  |  |  |  |  |  | 2 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 134 |  |

[0000068505-23-000015:notes:295]
|  | 2022 |
| Fair value at January 1, 2022 | 3 |  |
| Purchases | 2 |  |
| Fair value at December 31, 2022 | 5 |  |

[0000068505-23-000015:notes:296]
| December 31, 2021 | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Equities | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  |
| Commingled funds | 72 |  |  | 23 |  |  | — |  |  | 95 |  |  |
| Government fixed income securities | — |  |  | 18 |  |  | — |  |  | 18 |  |  |
| Corporate fixed income securities | — |  |  | 51 |  |  | — |  |  | 51 |  |  |
| Short-term investment funds | 15 |  |  | — |  |  | — |  |  | 15 |  |  |
| Private funds | — |  |  | — |  |  | 3 |  |  | 3 |  |  |
| Total investment securities | $ | 89 |  |  | $ | 92 |  |  | 3 |  | $ | 184 |  |  |
| Accrued income receivable |  |  |  |  |  |  | 2 |  |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 186 |  |  |

[0000068505-23-000015:notes:297]
The following is a description of the categories of investments:

[0000068505-23-000015:notes:298]
Equities — A diversified portfolio of corporate common and preferred stocks.

[0000068505-23-000015:notes:299]
Commingled funds — A diversified portfolio of assets that includes corporate common and preferred stocks, emerging market and high-yield fixed income securities among others.

[0000068505-23-000015:notes:300]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-23-000015:notes:301]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-23-000015:notes:302]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-23-000015:notes:303]
Private funds — A diversified portfolio of assets that includes private equity funds and private loans.

[0000068505-23-000015:notes:304]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. Level 3 investments include securities with valuations derived from valuation techniques, in which one or more significant inputs are unobservable. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-23-000015:notes:305]
At December 31, 2022, the Company had $490 million of investments in money market government and U.S. treasury funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $685 million at December 31, 2021. The money market funds had quoted market prices that are approximately at par.

[0000068505-23-000015:notes:306]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2022 was $5.9 billion, of which the Senior Convertible Notes were $1.3 billion (Level 2). The fair value of long-term debt at December 31, 2021 was 6.2 billion (Level 2). Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-23-000015:notes:307]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-23-000015:notes:308]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-23-000015:notes:309]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-23-000015:notes:310]
| December 31 | 2022 |  | 2021 |
| Long-term receivables, gross | $ | 40 |  |  | $ | 49 |  |
| Less allowance for losses | (2) |  |  | (2) |  |
| Long-term receivables | $ | 38 |  |  | $ | 47 |  |
| Less current portion | (13) |  |  | (20) |  |
| Non-current long-term receivables | $ | 25 |  |  | $ | 27 |  |

[0000068505-23-000015:notes:311]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized interest income on long-term receivables of $1 million for each of the years ended December 31, 2022, 2021 and 2020.

[0000068505-23-000015:notes:312]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $65 million at December 31, 2022 and $56 million at December 31, 2021.

[0000068505-23-000015:notes:313]
Sales of Receivables

[0000068505-23-000015:notes:314]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements.

[0000068505-23-000015:notes:315]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2022, 2021 and 2020.

[0000068505-23-000015:notes:316]
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |
| Contract-specific discounting facility | $ | 49 |  |  | $ | 211 |  |  | $ | 228 |  |
| Accounts receivable sales proceeds | 179 |  |  | 56 |  |  | 74 |  |
| Long-term receivables sales proceeds | 204 |  |  | 248 |  |  | 181 |  |
| Total proceeds from receivable sales | $ | 432 |  |  | $ | 515 |  |  | $ | 483 |  |

[0000068505-23-000015:notes:317]
The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-23-000015:notes:318]
At December 31, 2022, the Company had retained servicing obligations for $891 million of long-term receivables, compared to $940 million of long-term receivables at December 31, 2021. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-23-000015:notes:319]
During the year ended December 31, 2022, the Company utilized and fully repaid a cost-efficient receivable discounting facility, implemented in 2020, to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe. Both the proceeds and repayment of the Company's receivable sales are included in "Operating Activities" within its Consolidated Statements of Cash Flows.

[0000068505-23-000015:notes:320]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-23-000015:notes:321]
An aging analysis of financing receivables at December 31, 2022 and December 31, 2021 is as follows:

[0000068505-23-000015:notes:322]
| December 31, 2022 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 22 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Commercial loans and leases secured | 18 |  |  | — |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 40 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |

[0000068505-23-000015:notes:323]
| December 31, 2021 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 28 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 21 |  |  | 1 |  |  | — |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 49 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |

[0000068505-23-000015:notes:324]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-23-000015:notes:325]
Commitments and Contingencies
Purchase Obligations

[0000068505-23-000015:notes:326]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow it to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancellable.

[0000068505-23-000015:notes:327]
As of December 31, 2022, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2027. The Company expects to make total payments of $306 million under these arrangements as follows: $131 million in 2023, $127 million in 2024, $27 million in 2025, $18 million in 2026, and $3 million in 2027.

[0000068505-23-000015:notes:328]
The Company outsources certain corporate functions, such as benefit administration and information technology-related services, under various contracts, the longest of which is expected to expire in 2028. The remaining payments under these contracts are approximately $18 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-23-000015:notes:329]
Legal Matters

[0000068505-23-000015:notes:330]
Hytera Litigation

[0000068505-23-000015:notes:331]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment in July. Hytera made quarterly royalty payments on October 31, 2022 and January 31, 2023 into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow.

[0000068505-23-000015:notes:332]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for prejudgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in prejudgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions.

[0000068505-23-000015:notes:333]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Court of Appeals dismissed the notice of appeal on February 16, 2022 after determining that such appeal was premature. On August 2, 2022, after the Court denied the motions described above on July 5, 2022, Hytera filed a renewed notice of appeal in the Court of Appeals. The Company filed its cross-appeal on August 5, 2022. On November 15, 2022, Hytera filed its appellate court brief in the Court of Appeals.

[0000068505-23-000015:notes:334]
Hytera Bankruptcy Proceedings

[0000068505-23-000015:notes:335]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company.  On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the Company's Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-23-000015:notes:336]
Information by Segment and Geographic Region
The Company conducts its business globally and manages it through the following two segments:

[0000068505-23-000015:notes:337]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security devices and infrastructure, and the implementation and integration of such systems, devices, and applications. Within LMR Communications, the Company is a global leader in the two-way radio category, including the Company’s Project 25 ("P25"), Terrestrial Trunked Radio (TETRA), Digital Mobile Radio (DMR), as well as other professional and commercial radio (“PCR”) solutions. The Company provides LTE solutions for public safety, government and commercial users, including infrastructure and devices operating in 700

[0000068505-23-000015:notes:338]
MHz, 900 MHz and Citizens' Broadband Radio Service (CBRS) frequencies. The Company's Video technology includes network video management infrastructure, fixed security, certain mobile video equipment and access control solutions. The primary customers of the Products and Systems Integration segment are government, public safety and commercial customers who operate private communications networks and video security solutions and typically manage a mobile workforce. In 2022, the segment’s net sales were $5.7 billion, representing 63% of the Company's consolidated net sales.

[0000068505-23-000015:notes:339]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and commercial customers. Software includes public safety and enterprise Command Center, unified communications applications, certain mobile video equipment, and video software solutions, delivered both on-premise and “as-a-service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced technologies include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer-owned or Motorola Solutions-owned networks. In 2022, the segment’s net sales were $3.4 billion, representing 37% of the Company's consolidated net sales.

[0000068505-23-000015:notes:340]
For the years ended December 31, 2022, 2021 and 2020, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-23-000015:notes:341]
Segment Information

[0000068505-23-000015:notes:342]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-23-000015:notes:343]
|  | Net Sales |  | Operating Earnings |
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| Products and Systems Integration | $ | 5,728 |  |  | $ | 5,033 |  |  | $ | 4,634 |  |  | $ | 913 |  |  | $ | 760 |  |  | $ | 656 |  |
| Software and Services | 3,384 |  |  | 3,138 |  |  | 2,780 |  |  | 748 |  |  | 907 |  |  | 727 |  |
|  | $ | 9,112 |  |  | $ | 8,171 |  |  | $ | 7,414 |  |  | $ | 1,661 |  |  | $ | 1,667 |  |  | $ | 1,383 |  |
| Total other expense |  |  |  |  |  |  | (146) |  |  | (115) |  |  | (209) |  |
| Net earnings before income taxes |  |  |  |  |  |  | $ | 1,515 |  |  | $ | 1,552 |  |  | $ | 1,174 |  |

[0000068505-23-000015:notes:344]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-23-000015:notes:345]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| Products and Systems Integration | $ | 77 |  |  | $ | 90 |  |  | $ | 91 |  |  | $ | 79 |  |  | $ | 87 |  |  | $ | 90 |  |
| Software and Services | 179 |  |  | 153 |  |  | 126 |  |  | 104 |  |  | 115 |  |  | 104 |  |
|  | $ | 256 |  |  | $ | 243 |  |  | $ | 217 |  |  | $ | 183 |  |  | $ | 202 |  |  | $ | 194 |  |

[0000068505-23-000015:notes:346]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-23-000015:notes:347]
Geographic Area Information

[0000068505-23-000015:notes:348]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| United States | $ | 6,008 |  |  | $ | 5,236 |  |  | $ | 4,770 |  |  | $ | 9,227 |  |  | $ | 9,420 |  |  | $ | 7,009 |  |
| United Kingdom | 789 |  |  | 849 |  |  | 740 |  |  | 2,321 |  |  | 1,588 |  |  | 2,460 |  |
| Canada | 366 |  |  | 324 |  |  | 254 |  |  | 394 |  |  | 950 |  |  | 1,016 |  |
| Other, net of eliminations | 1,949 |  |  | 1,762 |  |  | 1,650 |  |  | 872 |  |  | 231 |  |  | 391 |  |
|  | $ | 9,112 |  |  | $ | 8,171 |  |  | $ | 7,414 |  |  | $ | 12,814 |  |  | $ | 12,189 |  |  | $ | 10,876 |  |

[0000068505-23-000015:notes:349]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-23-000015:notes:350]
Reorganization of Businesses
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of contractual lease termination costs and costs to exit committed contracts. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-23-000015:notes:351]
During 2022, 2021, and 2020 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. During 2020, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at nine months of salary, were equalized for all employment level grades and capped at a full year’s salary for the voluntary applicants. The remainder of the initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-23-000015:notes:352]
2022 Charges

[0000068505-23-000015:notes:353]
During 2022, the Company recorded net reorganization of business charges of $36 million, including $18 million of charges in Costs of sales and $18 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $36 million were charges of $36 million for employee separation costs and $10 million for exit costs, partially offset by $10 million of reversals of accruals no longer needed.

[0000068505-23-000015:notes:354]
The following table displays the net charges incurred by segment:

[0000068505-23-000015:notes:355]
| Year ended December 31 | 2022 |
| Products and Systems Integration | $ | 21 |  |
| Software and Services | 15 |  |
|  | $ | 36 |  |

[0000068505-23-000015:notes:356]
Reorganization of Businesses Accruals

[0000068505-23-000015:notes:357]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Reorganization costs | $ | 34 |  |  | $ | 36 |  |  | $ | (10) |  |  | $ | (34) |  |  | $ | 26 |  |
| Exit costs | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |
|  | $ | 34 |  |  | $ | 46 |  |  | $ | (10) |  |  | $ | (34) |  |  | $ | 36 |  |

[0000068505-23-000015:notes:358]
Exit Costs

[0000068505-23-000015:notes:359]
At January 1, 2022, the Company did not have an accrual for exit costs. There were $10 million of exit cost charges in 2022 related to the Company's exit of the ESN contract with the Home Office. The $10 million of exit costs are recorded in Accrued liabilities in the Company's Consolidated Balance Sheet at December 31, 2022, and are expected to be paid within one year.

[0000068505-23-000015:notes:360]
Employee Separation Costs

[0000068505-23-000015:notes:361]
At January 1, 2022, the Company had an accrual of $34 million for employee separation costs. The 2022 additional charges of $36 million include severance costs for approximately 460 employees, of which 310 were direct employees and 150 were indirect employees. The adjustments of $10 million reflect reversals of accruals no longer needed. The $34 million used in 2022 reflects cash payments to severed employees. The remaining accrual of $26 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2022, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 50 employees to be separated in 2023.

[0000068505-23-000015:notes:362]
2021 Charges

[0000068505-23-000015:notes:363]
During 2021, the Company recorded net reorganization of business charges of $32 million, including $8 million of charges in Costs of sales and $24 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $32 million were charges of $42 million for employee separation costs, partially offset by $10 million of reversals of accruals no longer needed.

[0000068505-23-000015:notes:364]
| Year ended December 31 | 2021 |
| Products and Systems Integration | $ | 25 |  |
| Software and Services | 7 |  |
|  | $ | 32 |  |

[0000068505-23-000015:notes:365]
| Accruals atJanuary 1, 2021 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31, 2021 |
| $ | 79 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | (77) |  |  | $ | 34 |  |

[0000068505-23-000015:notes:366]
At January 1, 2021, the Company had an accrual of $79 million for employee separation costs. The additional 2021 charges of $42 million represent severance costs for approximately an additional 600 employees, of which 400 were direct employees and 200 were indirect employees. The adjustments of $10 million reflect reversals of accruals no longer needed. The $77 million used in 2021 reflects cash payments to severed employees. The remaining accrual of $34 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2021.

[0000068505-23-000015:notes:367]
2020 Charges

[0000068505-23-000015:notes:368]
During 2020, the Company recorded net reorganization of business charges of $86 million, including $29 million of charges in Costs of sales and $57 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $86 million are charges of $100 million for employee separation costs and $2 million of charges for exit costs, partially offset by $16 million of reversals for accruals no longer needed.

[0000068505-23-000015:notes:369]
| Year ended December 31 | 2020 |
| Products and Systems integration | $ | 69 |  |
| Software and Services | 17 |  |
|  | $ | 86 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-23-000015:notes:370]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-23-000015:notes:371]
Recent Acquisitions

[0000068505-23-000015:notes:372]
On December 14, 2022, the Company acquired Rave Mobile, a leader in mass notification and incident management, for $553 million net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's  portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The Company recognized $431 million of goodwill, $199 million of identifiable intangible assets and $77 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of trade names, $69 million of developed technology and $121 million of customer relationships and will be amortized over a period of nine, seventeen years and seventeen years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-23-000015:notes:373]
On October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The Company recognized $13 million of goodwill, $11 million of identifiable intangible assets, and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of six years. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-23-000015:notes:374]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The Company recognized $1 million of goodwill, $3 million of identifiable intangible assets, and $14 million of net assets. The identifiable intangible assets were classified as $1 million of trade names and $2 million of developed technology, both of which will be amortized over a period of seven years. The goodwill is not deductible for tax purposes. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-23-000015:notes:375]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $9 million of goodwill, $6 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000015:notes:376]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The Company recognized $24 million of goodwill, $21 million of identifiable intangible assets, and $6 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $20 million of developed technology and $1 million of customer relationships that will be amortized over a period of fifteen and three years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-23-000015:notes:377]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. As a result of the acquisition, the Company recognized a $21 million gain recorded within Other income (expense) on the Company's initial minority interest. The Company recognized $47 million of goodwill, $90 million of identifiable intangible assets, and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $83 million of customer relationships and $7 million of trade names that will be amortized over a period of twelve years and fourteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000015:notes:378]
On March 3, 2022, the Company acquired Ava, a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The Company recognized $267 million of goodwill, $165 million of identifiable intangible assets, and $44 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $144 million of developed technology and $21 million of customer relationships that will be amortized over a period of fourteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-23-000015:notes:379]
On December 16, 2021, the Company acquired 911 Datamaster, an NG911 data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces Motorola Solutions’ commitment to being a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The Company recognized $21 million of goodwill, $16 million of identifiable intangible assets and $2 million of net liabilities.The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $7 million of developed technology and $9 million of customer relationships that will be amortized over periods of nine and fourteen years, respectively. The business is a part of the Software and Services segment. The purchase accounting was completed as of the fourth quarter of 2022.

[0000068505-23-000015:notes:380]
On October 29, 2021, the Company acquired Envysion, a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video. The Company recognized $79 million of goodwill, $37 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $26 million of customer relationships, $6 million of developed technology, and $5 million of trade names that will be amortized over a period of fifteen, four, and nine years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the fourth quarter of 2022.

[0000068505-23-000015:notes:381]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction included the potential for the Company to make earn-out payments of up to $40 million based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. The Company concluded there will be no payout related to the earn-out payments. This acquisition expands the Company's ability to combine video security and access control solutions within Video to help support enterprise customers. The Company recognized $234 million of goodwill, $73 million of identifiable intangible assets, and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $57 million of developed technology and $16 million of customer relationships that will be amortized over a period of sixteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the third quarter of 2022.

[0000068505-23-000015:notes:382]
On August 28, 2020, the Company acquired Callyo, a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing Command Center suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The Company recognized $38 million of goodwill, $31 million of identifiable intangible assets, and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $27 million of customer relationships and $4 million of developed technology that will be amortized over a period of fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-23-000015:notes:383]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in Video, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $38 million of goodwill, $30 million of identifiable intangible assets, and $39 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the third quarter of 2021.

[0000068505-23-000015:notes:384]
On June 16, 2020, the Company acquired IndigoVision for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video technology, providing enhanced geographical reach across a wider customer base. The Company recognized $18 million of goodwill, $22 million of identifiable intangible assets, and $5 million of net liabilities.  The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting was completed as of the second quarter of 2021.

[0000068505-23-000015:notes:385]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The Company recognized $23 million of goodwill, $10 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $8 million of customer relationships and $2 million of developed technology that will be amortized over a period of twelve years and three years, respectively. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-23-000015:notes:386]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The Company recognized $28 million of goodwill, $7 million of intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset of $7 million was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2021.

[0000068505-23-000015:notes:387]
The results of operations for these acquisitions have been included in the Company’s Consolidated Statements of Operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-23-000015:notes:388]
Intangible Assets

[0000068505-23-000015:notes:389]
Amortized intangible assets are comprised of the following:

[0000068505-23-000015:notes:390]
|  | 2022 |  | 2021 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Developed technology | $ | 1,083 |  |  | $ | 358 |  |  | $ | 828 |  |  | $ | 278 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,519 |  |  | 935 |  |  | 1,367 |  |  | 836 |  |
| Other intangibles | 97 |  |  | 64 |  |  | 82 |  |  | 58 |  |
|  | $ | 2,701 |  |  | $ | 1,359 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-23-000015:notes:391]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $257 million, $236 million, and $215 million for the years ended December 31, 2022, 2021, and 2020, respectively. As of December 31, 2022, future amortization expense is estimated to be $174 million in 2023, $136 million in 2024, $123 million in 2025, $114 million in 2026, and $104 million in 2027.

[0000068505-23-000015:notes:392]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-23-000015:notes:393]
|  | 2022 |  | 2021 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 913 |  |  | $ | 261 |  |  | $ | 766 |  |  | $ | 184 |  |
| Software and Services | 1,788 |  |  | 1,098 |  |  | 1,513 |  |  | 990 |  |
|  | $ | 2,701 |  |  | $ | 1,359 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-23-000015:notes:394]
Goodwill

[0000068505-23-000015:notes:395]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2021 to December 31, 2022:

[0000068505-23-000015:notes:396]
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2021 | $ | 1,019 |  |  | $ | 1,200 |  |  | $ | 2,219 |  |
| Goodwill acquired | 218 |  |  | 131 |  |  | 349 |  |
| Purchase accounting adjustments | (1) |  |  | (1) |  |  | (2) |  |
| Foreign currency translation | — |  |  | (1) |  |  | (1) |  |
| Balance as of December 31, 2021 | $ | 1,236 |  |  | $ | 1,329 |  |  | $ | 2,565 |  |
| Goodwill acquired | 227 |  |  | 573 |  |  | 800 |  |
| Purchase accounting adjustments | (2) |  |  | (29) |  |  | (31) |  |
| Foreign currency translation | — |  |  | (22) |  |  | (22) |  |
| Balance as of December 31, 2022 | $ | 1,461 |  |  | $ | 1,851 |  |  | $ | 3,312 |  |

[0000068505-23-000015:notes:397]
The Company conducts its annual assessment of goodwill for impairment as of the last day of the third quarter of each fiscal year. The goodwill impairment assessment is performed at the reporting unit level which is an operating segment or one level below an operating segment.

[0000068505-23-000015:notes:398]
In 2022, the Company elected to perform a quantitative assessment for each of its reporting units to determine if the fair value of each reporting unit exceeded the carrying value of the reporting unit.  The Company concluded that the fair value of each reporting unit exceeded the carrying value and no goodwill impairment was required.

[0000068505-23-000015:notes:399]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2021 and 2020. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal 
years 2021 and 2020, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, a quantitative goodwill impairment test was not required and there was no impairment of goodwill in 2021 and 2020.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-23-000015:notes:400]
Valuation and Qualifying Accounts
The following table presents the valuation and qualifying account activity for the years ended December 31, 2022, 2021, and 2020:

[0000068505-23-000015:notes:401]
|  | Balance atBeginning of Period |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atEnd of Period |
| 2022 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | $ | 70 |  |  | $ | 28 |  |  | $ | (36) |  |  | $ | (1) |  |  | $ | 61 |  |
| 2021 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 75 |  |  | 22 |  |  | (26) |  |  | (1) |  |  | 70 |  |
| 2020 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 63 |  |  | 47 |  |  | (34) |  |  | (1) |  |  | 75 |  |

[0000068505-23-000015:notes:402]
* Adjustments include translation adjustments
