# MSI 8-K — 0000068505-23-000009 filed 2023-02-09

## item codes, every 8-K on or before 2023-02-16

- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2023-02-16

- none on or before 2023-02-16

## item 2.02 — earnings release, exhibit 99.1

[0000068505-23-000009:8k_2_02:1]
EX-99.1
2
msiq42022pressrelease.htm
EX-99.1

[0000068505-23-000009:8k_2_02:2]
Document

[0000068505-23-000009:8k_2_02:3]
Exhibit 99.1

[0000068505-23-000009:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-23-000009:8k_2_02:5]
Company Achieves Record Q4 and Full-Year Sales, Earnings Per Share and Backlog

[0000068505-23-000009:8k_2_02:6]
•Sales of $2.7 billion, up 17% from Q4 in the prior year; up 12% for full year

[0000068505-23-000009:8k_2_02:7]
◦Products and Systems Integration sales grew 21% in Q4; up 14% for full year

[0000068505-23-000009:8k_2_02:8]
◦Software and Services sales grew 9% in Q4; up 8% for full year

[0000068505-23-000009:8k_2_02:9]
•Record backlog of $14.3 billion, up $788 million or 6% versus a year ago

[0000068505-23-000009:8k_2_02:10]
•Generated record $1.3 billion of operating cash flow in Q4; $1.8 billion for full year

[0000068505-23-000009:8k_2_02:11]
•GAAP Q4 earnings per share (EPS) of $3.43, up 49% versus a year ago; $7.93 for full year

[0000068505-23-000009:8k_2_02:12]
•Non-GAAP Q4 EPS* of $3.60, up 26% versus a year ago; $10.36 for full year, up 13%

[0000068505-23-000009:8k_2_02:13]
CHICAGO - February 9, 2023 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2022. Click here for a printable news release and financial tables.

[0000068505-23-000009:8k_2_02:14]
“2022 was an outstanding year, with record sales in both segments and all three technologies,” said Greg Brown, chairman and CEO of Motorola Solutions. “We achieved all-time Q4 records in sales, operating earnings, earnings per share and cash flow, highlighting the strong demand we continue to see for our public safety and enterprise security solutions. Our record backlog and a robust funding environment position us exceptionally well going forward.”

[0000068505-23-000009:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-23-000009:8k_2_02:16]
|  | Fourth Quarter | Full Year |
|  | Q4 2022 | Q4 2021 | % Change | 2022 | 2021 | % Change |
| Sales | $2,706 | $2,320 | 17 | % | $9,112 | $8,171 | 12 | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $692 | $549 | 26 | % | $1,661 | $1,667 | — | % |
| % of Sales | 25.6 | % | 23.7 | % |  | 18.2 | % | 20.4 | % |  |
| EPS | $3.43 | $2.30 | 49 | % | $7.93 | $7.17 | 11 | % |
| Non-GAAP* |  |  |  |  |  |  |
| Operating Earnings | $822 | $670 | 23 | % | $2,368 | $2,117 | 12 | % |
| % of Sales | 30.4 | % | 28.9 | % |  | 26.0 | % | 25.9 | % |  |
| EPS | $3.60 | $2.85 | 26 | % | $10.36 | $9.15 | 13 | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $1,810 | $1,495 | 21 | % | $5,728 | $5,033 | 14 | % |
| GAAP Operating Earnings | $454 | $320 | 42 | % | $913 | $760 | 20 | % |
| % of Sales | 25.1 | % | 21.4 | % |  | 15.9 | % | 15.1 | % |  |
| Non-GAAP Operating Earnings* | $514 | $378 | 36 | % | $1,172 | $976 | 20 | % |
| % of Sales | 28.4 | % | 25.3 | % |  | 20.5 | % | 19.4 | % |  |
| Software and Services Segment |  |  |  |  |  |  |
| Sales | $896 | $825 | 9 | % | $3,384 | $3,138 | 8 | % |
| GAAP Operating Earnings | $238 | $229 | 4 | % | $748 | $907 | (18) | % |
| % of Sales | 26.6 | % | 27.8 | % |  | 22.1 | % | 28.9 | % |  |
| Non-GAAP Operating Earnings* | $308 | $292 | 5 | % | $1,196 | $1,141 | 5 | % |
| % of Sales | 34.4 | % | 35.4 | % |  | 35.3 | % | 36.4 | % |  |

[0000068505-23-000009:8k_2_02:17]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.17 for Q4 and $2.43 for FY per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-23-000009:8k_2_02:18]
1

[0000068505-23-000009:8k_2_02:19]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-23-000009:8k_2_02:20]
•Revenue - Fourth-quarter sales were $2.7 billion, up 17% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $39 million, and currency headwinds were $87 million.The Products and Systems Integration segment increased 21% due to growth in land mobile radio (LMR) and video security and access control (Video). The Software and Services segment grew 9% driven by growth in LMR services, Video and Command center.

[0000068505-23-000009:8k_2_02:21]
•Operating margin - GAAP operating margin was 25.6% of sales, up from 23.7% in the year-ago quarter. Non-GAAP operating margin was 30.4% of sales, up from 28.9% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margin was primarily driven by higher sales in both segments and improved operating leverage in the Products and Systems Integration segment.

[0000068505-23-000009:8k_2_02:22]
•Taxes - The GAAP effective tax rate was 11.0%, down from 22.4% in the year-ago quarter driven primarily by higher benefits in the current year related to a partial release of a valuation allowance recorded on the U.S. foreign tax credits carryforward and higher stock-based compensation. The non-GAAP effective tax rate was 21.2%, compared to 22.3% in the year-ago quarter, driven by higher benefits from stock-based compensation in the current year.

[0000068505-23-000009:8k_2_02:23]
•Cash flow - Operating cash flow was $1.3 billion, up $570 million compared to the year-ago quarter. Free cash flow was $1.2 billion, up $565 million compared to the year-ago quarter. The increase in both operating and free cash flow was driven by improvements in working capital and higher earnings.

[0000068505-23-000009:8k_2_02:24]
•Capital allocation - During the quarter, the company paid $132 million in dividends, repurchased $87 million of its common stock and incurred $73 million in capital expenditures. Additionally, the company closed the acquisitions of Rave Mobile Safety and FutureCom Systems Group for $553 million and $30 million, net of cash acquired, respectively.

[0000068505-23-000009:8k_2_02:25]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-23-000009:8k_2_02:26]
•Revenue - Full-year sales were $9.1 billion, up 12% driven by growth in North America and International. The Products and Systems Integration segment grew 14% primarily due to higher sales of LMR and Video. The Software and Services segment grew 8% driven by growth in Video, LMR services and Command center. The impact of unfavorable currency rates was $216 million and sales from acquisitions was $121 million.

[0000068505-23-000009:8k_2_02:27]
•Operating margin - For the full year, GAAP operating margin was 18.2% of sales, compared to 20.4% for the prior year. The decrease was primarily driven by a fixed asset impairment charge of $147 million related to the exit from the Emergency Services Network (ESN) contract in the U.K. and higher stock based compensation in the current year. Non-GAAP operating margin was 26.0% of sales, up from 25.9% in the prior year, driven by higher sales and improved operating leverage, partially offset by higher material costs and expenses from acquisitions.

[0000068505-23-000009:8k_2_02:28]
•Taxes - The 2022 GAAP effective tax rate was 9.8%, down from 19.5% in the prior year driven primarily by a discrete deferred tax benefit as a result of the taxable reorganization of our intellectual property in the current year, a benefit from a partial release of the valuation allowance recorded on the U.S. foreign tax credit carryforward and the benefit from higher stock based compensation in the current year. The non-GAAP effective tax rate was 20.1%, down from 21.0% in the previous year, primarily driven by the benefit from higher stock based compensation in the current year.

[0000068505-23-000009:8k_2_02:29]
•Cash flow - The company generated $1.8 billion in operating cash and free cash flow was $1.6 billion in both the current and prior years. Higher earnings generated in the current year were offset by an increase in working capital and higher incentive payments.

[0000068505-23-000009:8k_2_02:30]
•Capital allocation - In 2022, the company paid $1.2 billion, net of cash acquired, for seven acquisitions, repurchased $836 million of its common stock at an average price of $225 per

[0000068505-23-000009:8k_2_02:31]
2

[0000068505-23-000009:8k_2_02:32]
share and paid $530 million in dividends. The company also issued $600 million of long-term debt and repaid $275 million of outstanding long-term debt.

[0000068505-23-000009:8k_2_02:33]
•Backlog - The company ended the year with record backlog of $14.3 billion, up $788 million from the prior year. Products and Systems Integrations segment backlog was up 22% or $894 million driven by record LMR product orders. Software and Services segment backlog was down 1% or $106 million, primarily driven by revenue recognition for the Airwave and ESN contracts, $367 million of unfavorable currency rates, and a reduction relating to the exit from the ESN contract, partially offset by growth in multi-year software and services contracts in North America.

[0000068505-23-000009:8k_2_02:34]
NOTABLE WINS & ACHIEVEMENTS IN Q4

[0000068505-23-000009:8k_2_02:35]
Software and Services

[0000068505-23-000009:8k_2_02:36]
•$56M P25 multi-year managed service extension of the Interexport contract for the Chilean National Law Enforcement Police

[0000068505-23-000009:8k_2_02:37]
•$25M P25 software upgrade agreement renewal for a large U.S. customer

[0000068505-23-000009:8k_2_02:38]
•$22M NG911 expansion and renewal for Greater Harris County, TX

[0000068505-23-000009:8k_2_02:39]
•$21M system upgrade and multi-year services renewal for Lane County, OR

[0000068505-23-000009:8k_2_02:40]
•$15M P25 and command center upgrade agreement extension order for Columbus, GA

[0000068505-23-000009:8k_2_02:41]
•$15M license plate recognition camera system expansion order for the Illinois State Police

[0000068505-23-000009:8k_2_02:42]
Products and Systems Integration

[0000068505-23-000009:8k_2_02:43]
•$45M P25 APX NEXT devices order for the city of Houston, TX

[0000068505-23-000009:8k_2_02:44]
•$39M P25 APX NEXT devices order for a large U.S. customer

[0000068505-23-000009:8k_2_02:45]
•$30M P25 APX NEXT devices order for the city of Dallas, TX

[0000068505-23-000009:8k_2_02:46]
•$21M add-on P25 APX NEXT devices order for a large U.S. customer

[0000068505-23-000009:8k_2_02:47]
•$20M P25 APX NEXT devices and command center order for Kansas City, MO

[0000068505-23-000009:8k_2_02:48]
•$19M P25 system order for a large international customer

[0000068505-23-000009:8k_2_02:49]
•$3M fixed video order for Metra Rail

[0000068505-23-000009:8k_2_02:50]
BUSINESS OUTLOOK

[0000068505-23-000009:8k_2_02:51]
•First-quarter 2023 - The company expects revenue growth between 12% and 13% compared to the first quarter of 2022. The company expects non-GAAP earnings per share in the range of $2.02 to $2.07 per share. This assumes approximately $40 million in foreign exchange headwinds, approximately 172 million fully diluted shares, and an effective tax rate of approximately 23%.

[0000068505-23-000009:8k_2_02:52]
•Full-year 2023 - The company expects revenue in the range of $9.65 billion to $9.7 billion and non-GAAP earnings per share in the range of $11.10 to $11.22 per share. This assumes approximately $40 million in foreign exchange headwinds, approximately 172 million fully diluted shares and a non-GAAP effective tax rate of 23% to 24%.

[0000068505-23-000009:8k_2_02:53]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP measurements in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-23-000009:8k_2_02:54]
3

[0000068505-23-000009:8k_2_02:55]
RECENT EVENTS

[0000068505-23-000009:8k_2_02:56]
CMA UPDATE

[0000068505-23-000009:8k_2_02:57]
In October 2021, the United Kingdom’s Competition and Markets Authority (the CMA) announced that it had opened a market investigation into the Mobile Radio Network for the Police and Emergency Services. This investigation affects Airwave, the company’s private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to public emergency service agencies in Great Britain. In October 2022, the CMA published a provisional decision with its findings regarding competition and proposed remedies. The company disagrees with the CMA’s provisional decision and will continue to work with the CMA to demonstrate the value of the Airwave network and pursue its legal avenues to protect Airwave’s contractual position.

[0000068505-23-000009:8k_2_02:58]
ESN MATTERS

[0000068505-23-000009:8k_2_02:59]
During the year ended December 31, 2022, the company signed a mutual agreement with the Home Office for the company to exit the ESN contract early, inclusive of twelve months of transition services through the end of 2023. During the third quarter of 2022, the company determined that the future service potential of the ESN communications systems contract was limited, based on the company's intention to terminate the contract in advance of the contracted service term. The company thus recorded a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the contract.

[0000068505-23-000009:8k_2_02:60]
MACROECONOMIC EVENTS

[0000068505-23-000009:8k_2_02:61]
During fiscal year 2022, the company operated under challenging market conditions, influenced by events such as those discussed below. For a more complete discussion of the risks the company encounters in its business, please refer to Part I. Item 1A. “Risk Factors” in the company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2021 and Part II. Item 1A. “Risk Factors” in the company’s Quarterly Report on Form 10-Q for the fiscal quarter ended October 2, 2022.

[0000068505-23-000009:8k_2_02:62]
Russia-Ukraine Conflict

[0000068505-23-000009:8k_2_02:63]
During the first quarter of 2022, in response to Russia's invasion of Ukraine, the company suspended all sales, provision of services and shipments of its products to Russia and Belarus, which did not constitute a material portion of the company's business. For the year ended December 31, 2021, the company's net sales in Russia and Belarus were less than $25 million. However, throughout 2022, the company indirectly experienced impacts from the Russia-Ukraine conflict (as further described below). While the company does not anticipate that the current posture of the Russia-Ukraine conflict will materially and adversely affect its results of operations, the conflict is still ongoing and has had, and may continue to have, a significant impact on the global macroeconomic and geopolitical environments, including increased volatility in capital and commodity markets, rapid changes to regulatory conditions (including the use of sanctions), supply chain and operational challenges for multinational corporations, inflationary pressures and an increased risk of cybersecurity incidents.

[0000068505-23-000009:8k_2_02:64]
COVID-19, Supply Chain Disruptions & Inflationary Cost Environment

[0000068505-23-000009:8k_2_02:65]
Throughout 2022, the company's supply chain was, and continues to be, impacted by global issues related to the effects of the COVID-19 pandemic, the Russia-Ukraine conflict and the inflationary cost environment, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in the company's supply chain, as well as difficulties and delays in procuring certain semiconductor components. Cost increases were driven by elevated lead times and increased material costs, in particular the need to purchase semiconductor components from alternative sources, including brokers. While the company continued to navigate supply chain constraints in 2022, the company

[0000068505-23-000009:8k_2_02:66]
4

[0000068505-23-000009:8k_2_02:67]
anticipates the broader impact of inflationary pressures and increased material and supply chain costs and disruptions (including elevated costs to procure materials within the semiconductor market) to continue into 2023.  However, the company expects global transportation costs to improve in 2023 as compared to 2022. The company is closely monitoring supply chain disruptions and continues to remain focused on improving its supplier network, engineering alternative designs and working to reduce supply shortages. The company also continues to actively manage its inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to its customers, and the company expects to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-23-000009:8k_2_02:68]
In order to combat rising inflation in the U.S., the Federal Reserve has raised interest rates multiple times since the beginning of 2022. The increase in U.S. dollar interest rates and overall market conditions led to significant strengthening of the U.S. dollar against many other global currencies in 2022. The strong U.S. dollar negatively impacted cash generated from the company's foreign operations in 2022, driven by revenues and costs that are denominated in foreign currencies. The company expects fluctuations in the value of U.S. dollar relative to other currencies to continue to impact its operating cash flows and net earnings throughout 2023.

[0000068505-23-000009:8k_2_02:69]
Although the macroeconomic environment continued to introduce challenges during 2022, the company is encouraged by customer demand for the company's products and services. Specifically, in the Software and Services segment, with the largely recurring nature of the business and its strong backlog position, the company expects that the impact to operating margin will be limited during 2023. While the company was encouraged by strong backlog and growth in the Products and Systems Integration segment throughout 2022, which the company expects to continue to grow during 2023, supply constraints continue to impact the company's business and the company expects demand for its products will continue to outpace its ability to obtain semiconductor component supply throughout 2023. Where appropriate, the company has taken pricing actions around its product and service offerings to mitigate exposure to inflationary pressures on its businesses and benefited from these adjustments during 2022. The company expects to further benefit from such adjustments throughout 2023. Further, demand continues to be supported with ongoing sources of government funding, including the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus. The company experienced the positive impact of the ARPA funding on its business and results of operations throughout 2022 and anticipate that the ARPA will continue to have a positive impact on the company's business in 2023.

[0000068505-23-000009:8k_2_02:70]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) on Thursday, February 9. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-23-000009:8k_2_02:71]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-23-000009:8k_2_02:72]
A comparison of results from operations is as follows:

[0000068505-23-000009:8k_2_02:73]
|  | Fourth Quarter | Full Year |
|  | 2022 | 2021 | 2022 | 2021 |
| Net sales | $2,706 | $2,320 | $9,112 | $8,171 |
| Gross margin | 1,351 |  | 1,183 |  | 4,229 |  | 4,040 |  |
| Operating earnings | 692 |  | 549 |  | 1,661 |  | 1,667 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | 589 |  | 401 |  | 1,363 |  | 1,245 |  |
| Diluted EPS from continuing operations | $3.43 | $2.30 | $7.93 | $7.17 |
| Weighted average diluted common shares outstanding | 171.9 |  | 174.2 |  | 171.9 |  | 173.6 |  |

[0000068505-23-000009:8k_2_02:74]
5

[0000068505-23-000009:8k_2_02:75]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-23-000009:8k_2_02:76]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-23-000009:8k_2_02:77]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-23-000009:8k_2_02:78]
Free cash flow:  Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-23-000009:8k_2_02:79]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-23-000009:8k_2_02:80]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-23-000009:8k_2_02:81]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-23-000009:8k_2_02:82]
6

[0000068505-23-000009:8k_2_02:83]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the company on December 15, 2021, and, consistent with the company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court’s previous July 5, 2022 royalty order. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment in July. Hytera made quarterly royalty payments on October 31, 2022 and January 31, 2023.

[0000068505-23-000009:8k_2_02:84]
In response to the Court's decision to award the company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for prejudgment interest. On August 10, 2021, the Court ruled that Hytera must pay the company $51.1 million in prejudgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the company with respect to several of the company's post-trial motions, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award. On October 15, 2021, the Court granted the company’s request for $34.2 million in attorneys’ fees against Hytera.  On September 29, 2021, the company filed two additional motions with the Court, requesting the Court to reconsider its order denying the company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions.

[0000068505-23-000009:8k_2_02:85]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals").  The Court of Appeals dismissed the notice of appeal on February 16, 2022 after determining that such appeal was premature. On August 2, 2022, after the Court denied the motions described on July 5, 2022, Hytera filed a renewed notice of appeal in the Court of Appeals. The company filed its cross-appeal on August 5, 2022. Hytera filed its appellate court brief on November 15, 2022.  The company’s reply brief is due on February 13, 2023.

[0000068505-23-000009:8k_2_02:86]
7

[0000068505-23-000009:8k_2_02:87]
Separate from the company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including $13 million to the company.  On December 22, 2022, an additional distribution of $2 million was made to the company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the company’s Consolidated Statements of Operations.

[0000068505-23-000009:8k_2_02:88]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the approximately $15 million of proceeds realized in 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-23-000009:8k_2_02:89]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-23-000009:8k_2_02:90]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-23-000009:8k_2_02:91]
FORWARD LOOKING STATEMENTS

[0000068505-23-000009:8k_2_02:92]
8

[0000068505-23-000009:8k_2_02:93]
full-year of 2023; the impact of the CMA’s provisional decision regarding Airwave (including Motorola Solutions’ actions in response to such provisional decision); the impact of Motorola Solutions’ entry into a signed agreement with the Home Office for us to exit from the ESN contract early; and the impact of the COVID-19 pandemic, supply chain constraints, the Russia-Ukraine conflict, inflation and the ARPA, including the impact of actions taken by Motorola Solutions or others in response to such events, on Motorola Solutions' business and results of operations. Motorola Solutions cautions the reader that the risks and uncertainties below, as well as those in Part I Item 1A of Motorola Solutions’ 2021 Annual Report on Form 10-K, Part II Item 1A of Motorola Solutions’ 2022 Third Quarter Report on Form 10-Q, and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at www.motorolasolutions.com, could cause Motorola Solutions’ actual results to differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (i) the impact including increased costs and potential liabilities, associated with changes in laws and regulations regarding privacy, data protection and information security; (ii) challenges relating to existing or future legislation and regulations pertaining to artificial intelligence (“AI”),  AI-enabled products and the use of biometrics and other video analytics; (iii) the impact of government regulation of radio frequencies; (iv) audits and regulations and laws applicable to our U.S. government customer contracts and grants; (v) the impact, including additional compliance obligations, associated with existing or future telecommunications-related laws and regulations; (vi) the evolving state of environmental regulation relating to climate change, and the physical risks of climate change; (vii) impact of product regulatory and safety, consumer, worker safety and environmental laws; (viii) impact of tax matters; (ix) the continuing and future impact of the COVID-19 pandemic on our business; (x) additional compliance obligations and increased risk, costs and competition associated with the expansion of our technologies within our Products and Systems Integration and Software and Services segments (including, but not limited to, with respect to the CMA's provisional decision regarding Airwave); (xi) the effectiveness of our investments in new products and technologies; (xii) the effectiveness of our strategic acquisitions, including the integrations of such acquired businesses; (xiii) increased cybersecurity threats, a security breach or other significant disruption of our IT systems or those of our outsource partners, suppliers or customers; (xiv) our inability to protect our intellectual property or potential infringement of intellectual property rights of third parties; (xv) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xvi) the global nature of our employees, customers, suppliers and outsource partners; (xvii) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xviii) the inability of our subcontractors to perform in a timely and compliant manner or adhere to our Human Rights Policy; (xix) our inability to purchase at acceptable prices a sufficient amount of materials, parts, and components, as well as software and services, to meet the demands of our customers, and any disruption to our suppliers or significant increase in the price of supplies; (xx) risks related to our large, multi-year system and services contracts (including, but not limited to, with respect to the ESN and Airwave contracts); (xxi) the inability of our products to meet our customers’ expectations or regulatory or industry standards; (xxii) impact of current global economic and political conditions in the markets in which we operate (including, but not limited to, the Russia-Ukraine conflict and inflation); (xxiii) impact of returns on pension and retirement plan assets and interest rate changes; (xxiv) inability to access the capital markets for financing on acceptable terms and conditions; (xxv) inability to attract and retain senior management and key employees; (xxvi) impact of the ARPA on our business; and (xxvii) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-23-000009:8k_2_02:94]
ABOUT MOTOROLA SOLUTIONS

[0000068505-23-000009:8k_2_02:95]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio communications, video security & access control and command center, bolstered by managed & support services, create an integrated technology ecosystem to help make communities safer and help

[0000068505-23-000009:8k_2_02:96]
9

[0000068505-23-000009:8k_2_02:97]
Exhibit 99.1

[0000068505-23-000009:8k_2_02:98]
businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-23-000009:8k_2_02:99]
MEDIA CONTACT

[0000068505-23-000009:8k_2_02:100]
Alexandra Reynolds

[0000068505-23-000009:8k_2_02:101]
Motorola Solutions

[0000068505-23-000009:8k_2_02:102]
+1 312-965-3968

[0000068505-23-000009:8k_2_02:103]
alexandra.reynolds@motorolasolutions.com

[0000068505-23-000009:8k_2_02:104]
INVESTOR CONTACT

[0000068505-23-000009:8k_2_02:105]
Tim Yocum

[0000068505-23-000009:8k_2_02:106]
Motorola Solutions

[0000068505-23-000009:8k_2_02:107]
+1 847-576-6899

[0000068505-23-000009:8k_2_02:108]
Tim.Yocum@motorolasolutions.com

[0000068505-23-000009:8k_2_02:109]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2023 Motorola Solutions, Inc. All rights reserved.

[0000068505-23-000009:8k_2_02:110]
10

[0000068505-23-000009:8k_2_02:111]
GAAP-1

[0000068505-23-000009:8k_2_02:112]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:113]
Consolidated Statements of Operations

[0000068505-23-000009:8k_2_02:114]
(In millions, except per share amount)

[0000068505-23-000009:8k_2_02:115]
|  | Three Months Ended |
|  | December 31, 2022 |  | December 31, 2021 |
| Net sales from products | $ | 1,671 |  |  | $ | 1,358 |  |
| Net sales from services | 1,035 |  |  | 962 |  |
| Net sales | 2,706 |  |  | 2,320 |  |
| Costs of products sales | 751 |  |  | 589 |  |
| Costs of services sales | 604 |  |  | 548 |  |
| Costs of sales | 1,355 |  |  | 1,137 |  |
| Gross margin | 1,351 |  |  | 1,183 |  |
| Selling, general and administrative expenses | 381 |  |  | 368 |  |
| Research and development expenditures | 201 |  |  | 189 |  |
| Other charges | 14 |  |  | 13 |  |
| Intangibles amortization | 63 |  |  | 64 |  |
| Operating earnings | 692 |  |  | 549 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (54) |  |  | (54) |  |
| Gains on sales of investments and businesses, net | — |  |  | 1 |  |
| Other, net | 25 |  |  | 22 |  |
| Total other expense | (29) |  |  | (31) |  |
| Net earnings before income taxes | 663 |  |  | 518 |  |
| Income tax expense | 73 |  |  | 116 |  |
| Net earnings | 590 |  |  | 402 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 589 |  |  | $ | 401 |  |
| Earnings per common share: |  |  |  |
| Basic: | $ | 3.52 |  |  | $ | 2.38 |  |
| Diluted: | $ | 3.43 |  |  | $ | 2.30 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.4 |  | 168.8 |
| Diluted | 171.9 |  | 174.2 |

[0000068505-23-000009:8k_2_02:116]
|  | Percentage of Net Sales* |
| Net sales from products | 61.8 | % |  | 58.5 | % |
| Net sales from services | 38.2 | % |  | 41.5 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 44.9 | % |  | 43.4 | % |
| Costs of services sales | 58.4 | % |  | 57.0 | % |
| Costs of sales | 50.1 | % |  | 49.0 | % |
| Gross margin | 49.9 | % |  | 51.0 | % |
| Selling, general and administrative expenses | 14.1 | % |  | 15.9 | % |
| Research and development expenditures | 7.4 | % |  | 8.1 | % |
| Other charges | 0.5 | % |  | 0.6 | % |
| Intangibles amortization | 2.3 | % |  | 2.8 | % |
| Operating earnings | 25.6 | % |  | 23.7 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.0) | % |  | (2.3) | % |
| Gains on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 0.9 | % |  | 0.9 | % |
| Total other expense | (1.1) | % |  | (1.3) | % |
| Net earnings before income taxes | 24.5 | % |  | 22.3 | % |
| Income tax expense | 2.7 | % |  | 5.0 | % |
| Net earnings | 21.8 | % |  | 17.3 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 21.8 | % |  | 17.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-23-000009:8k_2_02:117]
11

[0000068505-23-000009:8k_2_02:118]
GAAP-2

[0000068505-23-000009:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:120]
Consolidated Statements of Operations

[0000068505-23-000009:8k_2_02:121]
(In millions, except per share amounts)

[0000068505-23-000009:8k_2_02:122]
|  | Years Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2020 |
| Net sales from products | $ | 5,368 |  |  | $ | 4,606 |  |  | $ | 4,087 |  |
| Net sales from services | 3,744 |  |  | 3,565 |  |  | 3,327 |  |
| Net sales | 9,112 |  |  | 8,171 |  |  | 7,414 |  |
| Costs of products sales | 2,595 |  |  | 2,104 |  |  | 1,872 |  |
| Costs of services sales | 2,288 |  |  | 2,027 |  |  | 1,934 |  |
| Costs of sales | 4,883 |  |  | 4,131 |  |  | 3,806 |  |
| Gross margin | 4,229 |  |  | 4,040 |  |  | 3,608 |  |
| Selling, general and administrative expenses | 1,450 |  |  | 1,353 |  |  | 1,293 |  |
| Research and development expenditures | 779 |  |  | 734 |  |  | 686 |  |
| Other charges | 82 |  |  | 50 |  |  | 31 |  |
| Intangibles amortization | 257 |  |  | 236 |  |  | 215 |  |
| Operating earnings | 1,661 |  |  | 1,667 |  |  | 1,383 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (226) |  |  | (208) |  |  | (220) |  |
| Gains (losses) on sales of investments and businesses, net | 3 |  |  | 1 |  |  | (2) |  |
| Other, net | 77 |  |  | 92 |  |  | 13 |  |
| Total other expense | (146) |  |  | (115) |  |  | (209) |  |
| Net earnings before income taxes | 1,515 |  |  | 1,552 |  |  | 1,174 |  |
| Income tax expense | 148 |  |  | 302 |  |  | 221 |  |
| Net earnings | 1,367 |  |  | 1,250 |  |  | 953 |  |
| Less: Earnings attributable to noncontrolling interests | 4 |  |  | 5 |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 1,363 |  |  | $ | 1,245 |  |  | $ | 949 |  |
| Earnings per common share: |  |  |  |  |  |
| Basic: | $ | 8.14 |  |  | $ | 7.36 |  |  | $ | 5.58 |  |
| Diluted: | $ | 7.93 |  |  | $ | 7.17 |  |  | $ | 5.45 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 167.5 |  |  | 169.2 |  |  | 170.0 |  |
| Diluted | 171.9 |  |  | 173.6 |  |  | 174.1 |  |

[0000068505-23-000009:8k_2_02:123]
|  | Percentage of Net Sales* |
| Net sales from products | 58.9 | % |  | 56.4 | % |  | 55.1 | % |
| Net sales from services | 41.1 | % |  | 43.6 | % |  | 44.9 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 48.3 | % |  | 45.7 | % |  | 45.8 | % |
| Costs of services sales | 61.1 | % |  | 56.9 | % |  | 58.1 | % |
| Costs of sales | 53.6 | % |  | 50.6 | % |  | 51.3 | % |
| Gross margin | 46.4 | % |  | 49.4 | % |  | 48.7 | % |
| Selling, general and administrative expenses | 15.9 | % |  | 16.6 | % |  | 17.4 | % |
| Research and development expenditures | 8.5 | % |  | 9.0 | % |  | 9.3 | % |
| Other charges | 0.9 | % |  | 0.6 | % |  | 0.4 | % |
| Intangibles amortization | 2.8 | % |  | 2.9 | % |  | 2.9 | % |
| Operating earnings | 18.2 | % |  | 20.4 | % |  | 18.7 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (2.5) | % |  | (2.5) | % |  | (3.0) | % |
| Gains (losses) on sales of investments and businesses, net | — | % |  | — | % |  | — | % |
| Other, net | 0.8 | % |  | 1.1 | % |  | 0.2 | % |
| Total other expense | (1.6) | % |  | (1.4) | % |  | (2.8) | % |
| Net earnings before income taxes | 16.6 | % |  | 19.0 | % |  | 15.8 | % |
| Income tax expense | 1.6 | % |  | 3.7 | % |  | 3.0 | % |
| Net earnings | 15.0 | % |  | 15.3 | % |  | 12.9 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 15.0 | % |  | 15.2 | % |  | 12.8 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-23-000009:8k_2_02:124]
12

[0000068505-23-000009:8k_2_02:125]
GAAP-3

[0000068505-23-000009:8k_2_02:126]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:127]
Consolidated Balance Sheets

[0000068505-23-000009:8k_2_02:128]
(In millions)

[0000068505-23-000009:8k_2_02:129]
|  |  | December 31, 2022 |  | December 31, 2021 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,325 |  |  | $ | 1,874 |  |
| Accounts receivable, net |  | 1,518 |  |  | 1,386 |  |
| Contract assets |  | 974 |  |  | 1,105 |  |
| Inventories, net |  | 1,055 |  |  | 788 |  |
| Other current assets |  | 383 |  |  | 259 |  |
| Total current assets |  | 5,255 |  |  | 5,412 |  |
| Property, plant and equipment, net |  | 927 |  |  | 1,042 |  |
| Operating lease assets |  | 485 |  |  | 382 |  |
| Investments |  | 147 |  |  | 209 |  |
| Deferred income taxes |  | 1,036 |  |  | 916 |  |
| Goodwill |  | 3,312 |  |  | 2,565 |  |
| Intangible assets, net |  | 1,342 |  |  | 1,105 |  |
| Other assets |  | 310 |  |  | 558 |  |
| Total assets |  | $ | 12,814 |  |  | $ | 12,189 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |  |
| Current portion of long-term debt |  | $ | 1 |  |  | $ | 5 |  |
| Accounts payable |  | 1,062 |  |  | 851 |  |
| Contract liabilities |  | 1,859 |  |  | 1,650 |  |
| Accrued liabilities |  | 1,638 |  |  | 1,557 |  |
| Total current liabilities |  | 4,560 |  |  | 4,063 |  |
| Long-term debt |  | 6,013 |  |  | 5,688 |  |
| Operating lease liabilities |  | 419 |  |  | 313 |  |
| Other liabilities |  | 1,691 |  |  | 2,148 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | 116 |  |  | (40) |  |
| Noncontrolling interests |  | 15 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) |  | $ | 12,814 |  |  | $ | 12,189 |  |

[0000068505-23-000009:8k_2_02:130]
13

[0000068505-23-000009:8k_2_02:131]
GAAP-4

[0000068505-23-000009:8k_2_02:132]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:133]
Consolidated Statements of Cash Flows

[0000068505-23-000009:8k_2_02:134]
(In millions)

[0000068505-23-000009:8k_2_02:135]
|  | Three Months Ended |
|  | December 31, 2022 |  | December 31, 2021 |
| Operating |  |  |  |
| Net earnings | $ | 590 |  |  | $ | 402 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 109 |  |  | 113 |  |
| Non-cash other charges (income) | 4 |  |  | 9 |  |
| Share-based compensation expense | 46 |  |  | 35 |  |
| Gains on sales of investments and businesses, net | — |  |  | (1) |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (117) |  |  | (186) |  |
| Inventories | 118 |  |  | (185) |  |
| Other current assets and contract assets | 37 |  |  | (69) |  |
| Accounts payable, accrued liabilities, and contract liabilities | 634 |  |  | 617 |  |
| Other assets and liabilities | (26) |  |  | (64) |  |
| Deferred income taxes | (122) |  |  | 32 |  |
| Net cash provided by operating activities | 1,273 |  |  | 703 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (587) |  |  | (161) |  |
| Proceeds from sales of investments | 8 |  |  | 12 |  |
| Capital expenditures | (73) |  |  | (68) |  |
| Net cash used for investing activities | (652) |  |  | (217) |  |
| Financing |  |  |  |
| Repayment of debt | (2) |  |  | (2) |  |
| Issuances of common stock | 19 |  |  | 3 |  |
| Purchases of common stock | (87) |  |  | (131) |  |
| Payment of dividends | (132) |  |  | (120) |  |
| Net cash used for financing activities | (202) |  |  | (250) |  |
| Effect of exchange rate changes on cash and cash equivalents | 84 |  |  | (15) |  |
| Net increase in cash and cash equivalents | 503 |  |  | 221 |  |
| Cash and cash equivalents, beginning of period | 822 |  |  | 1,653 |  |
| Cash and cash equivalents, end of period | $ | 1,325 |  |  | $ | 1,874 |  |

[0000068505-23-000009:8k_2_02:136]
14

[0000068505-23-000009:8k_2_02:137]
GAAP-5

[0000068505-23-000009:8k_2_02:138]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:139]
Consolidated Statements of Cash Flows

[0000068505-23-000009:8k_2_02:140]
(In millions)

[0000068505-23-000009:8k_2_02:141]
|  | Years Ended |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2020 |
| Operating |  |  |  |  |  |
| Net earnings | $ | 1,367 |  |  | $ | 1,250 |  |  | $ | 953 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 440 |  |  | 438 |  |  | 409 |  |
| Non-cash other charges (income) | 23 |  |  | 3 |  |  | (13) |  |
| Loss on ESN fixed asset impairment | 147 |  |  | — |  |  | — |  |
| Share-based compensation expense | 172 |  |  | 129 |  |  | 129 |  |
| Losses (gains) on sales of investments and businesses, net | (3) |  |  | (1) |  |  | 2 |  |
| Losses from the extinguishment of long-term debt | 6 |  |  | 18 |  |  | 56 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | (112) |  |  | 3 |  |  | 90 |  |
| Inventories | (242) |  |  | (284) |  |  | (14) |  |
| Other current assets and contract assets | (1) |  |  | (205) |  |  | 167 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 451 |  |  | 578 |  |  | (116) |  |
| Other assets and liabilities | (91) |  |  | (126) |  |  | (25) |  |
| Deferred income taxes | (334) |  |  | 34 |  |  | (25) |  |
| Net cash provided by operating activities | 1,823 |  |  | 1,837 |  |  | 1,613 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (1,177) |  |  | (521) |  |  | (287) |  |
| Proceeds from sales of investments | 46 |  |  | 16 |  |  | 11 |  |
| Capital expenditures | (256) |  |  | (243) |  |  | (217) |  |
| Proceeds from sales of property, plant and equipment | — |  |  | 6 |  |  | 56 |  |
| Net cash used for investing activities | (1,387) |  |  | (742) |  |  | (437) |  |
| Financing |  |  |  |  |  |
| Net proceeds from issuance of debt | 595 |  |  | 844 |  |  | 892 |  |
| Repayment of debt | (285) |  |  | (353) |  |  | (914) |  |
| Proceeds from unsecured revolving credit facility draw | — |  |  | — |  |  | 800 |  |
| Repayment of unsecured revolving credit facility draw | — |  |  | — |  |  | (800) |  |
| Revolving credit facility renewal fees | — |  |  | (7) |  |  | — |  |
| Issuances of common stock | 156 |  |  | 102 |  |  | 108 |  |
| Purchases of common stock | (836) |  |  | (528) |  |  | (612) |  |
| Payment of dividends | (530) |  |  | (482) |  |  | (436) |  |
| Payment of dividends to noncontrolling interest | (6) |  |  | (5) |  |  | (4) |  |
| Net cash used for financing activities | (906) |  |  | (429) |  |  | (966) |  |
| Effect of exchange rate changes on cash and cash equivalents | (79) |  |  | (46) |  |  | 43 |  |
| Net increase (decrease) in cash and cash equivalents | (549) |  |  | 620 |  |  | 253 |  |
| Cash and cash equivalents, beginning of period | 1,874 |  |  | 1,254 |  |  | 1,001 |  |
| Cash and cash equivalents, end of period | $ | 1,325 |  |  | $ | 1,874 |  |  | $ | 1,254 |  |

[0000068505-23-000009:8k_2_02:142]
15

[0000068505-23-000009:8k_2_02:143]
Non-GAAP-1

[0000068505-23-000009:8k_2_02:144]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow |
| (In millions) |

[0000068505-23-000009:8k_2_02:145]
|  |  | Three Months Ended |  | Years Ended |  |  |  |  |
|  |  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 1,273 |  |  | $ | 703 |  |  | $ | 1,823 |  |  | $ | 1,837 |  |  |  |  |  |  |  |
| Capital expenditures |  | (73) |  |  | (68) |  |  | (256) |  |  | (243) |  |  |  |  |  |  |  |
| Free cash flow |  | $ | 1,200 |  |  | $ | 635 |  |  | $ | 1,567 |  |  | $ | 1,594 |  |  |  |  |  |  |  |

[0000068505-23-000009:8k_2_02:146]
16

[0000068505-23-000009:8k_2_02:147]
Non-GAAP-2

[0000068505-23-000009:8k_2_02:148]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:149]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-23-000009:8k_2_02:150]
(In millions)

[0000068505-23-000009:8k_2_02:151]
|  |  |  |  | Three Months Ended |  | Years Ended |  |  |  |
|  |  | Statement Line |  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 589 |  |  | $ | 401 |  |  | $ | 1,363 |  |  | $ | 1,245 |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 63 |  |  | $ | 64 |  |  | $ | 257 |  |  | $ | 236 |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 46 |  |  | 35 |  |  | 172 |  |  | 129 |  |  |  |  |  |  |  |
| Loss on ESN fixed asset impairment |  | Cost of sales |  | — |  |  | — |  |  | 147 |  |  | — |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 5 |  |  | 3 |  |  | 36 |  |  | 32 |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (5) |  |  | 3 |  |  | 30 |  |  | 8 |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 3 |  |  | 8 |  |  | 28 |  |  | 26 |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 8 |  |  | 3 |  |  | 24 |  |  | 10 |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (Income) |  | — |  |  | — |  |  | 23 |  |  | 3 |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 7 |  |  | 9 |  |  | 23 |  |  | 15 |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | — |  |  | 12 |  |  | — |  |  |  |  |  |  |  |
| Loss from extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | — |  |  | 6 |  |  | 18 |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | — |  |  | 1 |  |  | — |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | (2) |  |  | (1) |  |  | (3) |  |  | (10) |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | (1) |  |  | (3) |  |  | (1) |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | (2) |  |  | — |  |  | (15) |  |  | — |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | (21) |  |  | — |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 123 |  |  | $ | 123 |  |  | $ | 717 |  |  | $ | 466 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 94 |  | 27 |  | 300 |  | 122 |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 29 |  | 96 |  | 417 |  |  | 344 |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 618 |  |  | $ | 497 |  |  | $ | 1,780 |  |  | $ | 1,589 |  |  |  |  |  |  |  |

[0000068505-23-000009:8k_2_02:152]
Calculation of Non-GAAP Tax Rate

[0000068505-23-000009:8k_2_02:153]
(In millions)

[0000068505-23-000009:8k_2_02:154]
|  |  | Three Months Ended |  | Years Ended |  |  |  |
|  |  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |  |  |  |  |  |  |
| Net earnings before income taxes |  | $ | 663 |  |  | $ | 518 |  |  | $ | 1,515 |  |  | $ | 1,552 |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 123 |  |  | 123 |  |  | 717 |  |  | 466 |  |  |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 786 |  |  | 641 |  |  | 2,232 |  |  | 2,018 |  |  |  |  |  |  |  |
| Income tax expense |  | 73 |  |  | 116 |  |  | 148 |  |  | 302 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 94 |  |  | 27 |  |  | 300 |  |  | 122 |  |  |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | 167 |  |  | 143 |  |  | 448 |  |  | 424 |  |  |  |  |  |  |  |
| Non-GAAP Tax rate |  | 21.2 | % |  | 22.3 | % |  | 20.1 | % |  | 21.0 | % |  |  |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |  |  |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000009:8k_2_02:155]
17

[0000068505-23-000009:8k_2_02:156]
Non-GAAP-2

[0000068505-23-000009:8k_2_02:157]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-23-000009:8k_2_02:158]
|  |  |  |  | Three Months Ended |  | Years Ended |  |  |  |
|  |  | Statement Line |  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 3.43 |  |  | $ | 2.30 |  |  | $ | 7.93 |  |  | $ | 7.17 |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 0.36 |  |  | $ | 0.36 |  |  | $ | 1.50 |  |  | $ | 1.36 |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 0.27 |  |  | 0.20 |  |  | 1.00 |  |  | 0.74 |  |  |  |  |  |  |  |
| Loss on ESN fixed asset impairment |  | Cost of sales |  | — |  |  | — |  |  | 0.86 |  |  | — |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.03 |  |  | 0.02 |  |  | 0.21 |  |  | 0.18 |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (0.03) |  |  | 0.02 |  |  | 0.18 |  |  | 0.05 |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.02 |  |  | 0.05 |  |  | 0.16 |  |  | 0.15 |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.05 |  |  | 0.02 |  |  | 0.14 |  |  | 0.06 |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (Income) |  | — |  |  | — |  |  | 0.14 |  |  | 0.02 |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.04 |  |  | 0.05 |  |  | 0.13 |  |  | 0.09 |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | — |  |  | 0.07 |  |  | — |  |  |  |  |  |  |  |
| Loss from extinguishment of long-term debt |  | Other (income) expense |  | — |  |  | — |  |  | 0.03 |  |  | 0.10 |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | (0.01) |  |  | (0.01) |  |  | (0.02) |  |  | (0.06) |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | (0.01) |  |  | (0.02) |  |  | (0.01) |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | (0.01) |  |  | — |  |  | (0.09) |  |  | — |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | — |  |  | — |  |  | (0.12) |  |  | — |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.72 |  |  | $ | 0.70 |  |  | $ | 4.18 |  |  | $ | 2.68 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.55 |  | 0.15 |  | 1.75 |  | 0.70 |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.17 |  | 0.55 |  | 2.43 |  | 1.98 |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 3.60 |  |  | $ | 2.85 |  |  | $ | 10.36 |  |  | $ | 9.15 |  |  |  |  |  |  |  |
| Diluted Weighted Average Common Shares |  |  |  | 171.9 |  |  | 174.2 |  |  | 171.9 |  |  | 173.6 |  |  |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-23-000009:8k_2_02:159]
18

[0000068505-23-000009:8k_2_02:160]
Non-GAAP-3

[0000068505-23-000009:8k_2_02:161]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:162]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-23-000009:8k_2_02:163]
(In millions)

[0000068505-23-000009:8k_2_02:164]
|  |  | Three Months Ended |
|  |  | December 31, 2022 |  | December 31, 2021 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,810 |  |  | $ | 896 |  |  | $ | 2,706 |  |  | $ | 1,495 |  |  | $ | 825 |  |  | $ | 2,320 |  |
| Operating earnings |  | $ | 454 |  |  | $ | 238 |  |  | $ | 692 |  |  | $ | 320 |  |  | $ | 229 |  |  | $ | 549 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 15 |  |  | 48 |  |  | 63 |  |  | 15 |  |  | 49 |  |  | 64 |  |
| Share-based compensation expenses |  | 34 |  |  | 12 |  |  | 46 |  |  | 28 |  |  | 7 |  |  | 35 |  |
| Operating lease asset impairments |  | 5 |  |  | 3 |  |  | 8 |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Acquisition-related transaction fees |  | 1 |  |  | 6 |  |  | 7 |  |  | 3 |  |  | 6 |  |  | 9 |  |
| Reorganization of business charges |  | 4 |  |  | 1 |  |  | 5 |  |  | 3 |  |  | — |  |  | 3 |  |
| Hytera-related legal expenses |  | 3 |  |  | — |  |  | 3 |  |  | 8 |  |  | — |  |  | 8 |  |
| Gain on sales of investments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Gain on Hytera legal settlement |  | (2) |  |  | — |  |  | (2) |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 60 |  |  | 70 |  |  | 130 |  |  | 58 |  |  | 63 |  |  | 121 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 514 |  |  | $ | 308 |  |  | $ | 822 |  |  | $ | 378 |  |  | $ | 292 |  |  | $ | 670 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 25.1 | % |  | 26.6 | % |  | 25.6 | % |  | 21.4 | % |  | 27.8 | % |  | 23.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.4 | % |  | 34.4 | % |  | 30.4 | % |  | 25.3 | % |  | 35.4 | % |  | 28.9 | % |

[0000068505-23-000009:8k_2_02:165]
19

[0000068505-23-000009:8k_2_02:166]
Non-GAAP-4

[0000068505-23-000009:8k_2_02:167]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-23-000009:8k_2_02:168]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-23-000009:8k_2_02:169]
(In millions)

[0000068505-23-000009:8k_2_02:170]
|  |  | Years Ended |
|  |  | December 31, 2022 |  | December 31, 2021 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |  | $ | 5,033 |  |  | $ | 3,138 |  |  | $ | 8,171 |  |
| Operating earnings ("OE") |  | $ | 913 |  |  | $ | 748 |  |  | $ | 1,661 |  |  | $ | 760 |  |  | $ | 907 |  |  | $ | 1,667 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 60 |  |  | 197 |  |  | 257 |  |  | 54 |  |  | 182 |  |  | 236 |  |
| Share-based compensation expenses |  | 126 |  |  | 46 |  |  | 172 |  |  | 99 |  |  | 30 |  |  | 129 |  |
| Loss on ESN fixed asset impairment |  | — |  |  | 147 |  |  | 147 |  |  | — |  |  | — |  |  | — |  |
| Reorganization of business charges |  | 21 |  |  | 15 |  |  | 36 |  |  | 25 |  |  | 7 |  |  | 32 |  |
| Hytera-related legal expenses |  | 28 |  |  | — |  |  | 28 |  |  | 26 |  |  | — |  |  | 26 |  |
| Operating lease asset impairments |  | 18 |  |  | 6 |  |  | 24 |  |  | 7 |  |  | 3 |  |  | 10 |  |
| Acquisition-related transaction fees |  | 9 |  |  | 14 |  |  | 23 |  |  | 4 |  |  | 11 |  |  | 15 |  |
| Legal settlements |  | 3 |  |  | 20 |  |  | 23 |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Fixed asset impairments |  | 9 |  |  | 3 |  |  | 12 |  |  | — |  |  | — |  |  | — |  |
| Gain on Hytera legal settlement |  | (15) |  |  | — |  |  | (15) |  |  | — |  |  | — |  |  | — |  |
| Gain on sales of investments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Total above-OE non-GAAP adjustments |  | 259 |  |  | 448 |  |  | 707 |  |  | 216 |  |  | 234 |  |  | 450 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,172 |  |  | $ | 1,196 |  |  | $ | 2,368 |  |  | $ | 976 |  |  | $ | 1,141 |  |  | $ | 2,117 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 15.9 | % |  | 22.1 | % |  | 18.2 | % |  | 15.1 | % |  | 28.9 | % |  | 20.4 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 20.5 | % |  | 35.3 | % |  | 26.0 | % |  | 19.4 | % |  | 36.4 | % |  | 25.9 | % |

[0000068505-23-000009:8k_2_02:171]
20

[0000068505-23-000009:8k_2_02:172]
Non-GAAP-5

[0000068505-23-000009:8k_2_02:173]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Revenue to Non-GAAP Organic Revenue |
| (In millions) |

[0000068505-23-000009:8k_2_02:174]
|  |  | Three Months Ended |  |  |
|  |  | December 31, 2022 |  | December 31, 2021 |  | % Change |
| Net sales |  | $ | 2,706 |  |  | $ | 2,320 |  |  | 17 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 44 |  |  | 5 |  |  |  |
| Organic revenue |  | $ | 2,662 |  |  | $ | 2,315 |  |  | 15 | % |

[0000068505-23-000009:8k_2_02:175]
|  |  | Years Ended |  |  |
|  |  | December 31, 2022 |  | December 31, 2021 |  | % Change |
| Net sales |  | $ | 9,112 |  |  | $ | 8,171 |  |  | 12 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 127 |  |  | 6 |  |  |  |
| Organic revenue |  | $ | 8,985 |  |  | $ | 8,165 |  |  | 10 | % |

[0000068505-23-000009:8k_2_02:176]
21
