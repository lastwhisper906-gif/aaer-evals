# MSI note change history — 0000068505-22-000025 → 0000068505-22-000031


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-03):
[0000068505-22-000031:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment.
  (was, 2022-08-04, similarity 0.8984):
[0000068505-22-000025:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for not making the royalty payment.

- changed (2022-11-03):
[0000068505-22-000031:note_history:2]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions.
  (was, 2022-08-04, similarity 0.8075):
[0000068505-22-000025:note_history:2]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief, which the Court granted on January 8, 2021, reducing the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

- added (2022-11-03):
[0000068505-22-000031:note_history:3]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Court of Appeals dismissed the notice of appeal on February 16, 2022 after determining that such appeal was premature. On August 2, 2022, after the Court denied the motions described above on July 5, 2022, Hytera filed a renewed notice of appeal in the Court of Appeals. The Company filed its cross-appeal on August 5, 2022.

- removed (2022-11-03):
[0000068505-22-000025:note_history:4]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On July 5, 2022, the Court denied both motions due to ongoing appeals in the case.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-03):
[0000068505-22-000031:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of October 1, 2022 and for the three and nine months ended October 1, 2022 and October 2, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2022-08-04, similarity 0.9407):
[0000068505-22-000025:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of July 2, 2022 and for the three and six months ended July 2, 2022 and July 3, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2022-11-03):
[0000068505-22-000031:note_history:6]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three and nine months ended October 1, 2022 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2022-08-04, similarity 0.8176):
[0000068505-22-000025:note_history:6]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three and six months ended July 2, 2022 are not necessarily indicative of the operating results to be expected for the full year.

- added (2022-11-03):
[0000068505-22-000031:note_history:7]
Subsequent to quarter end, on October 25, 2022, the Company acquired Futurecom Systems Group, ULC ("Futurecom"), a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The business is a part the Products and Systems Integration segment.

- added (2022-11-03):
[0000068505-22-000031:note_history:8]
On August 8, 2022, the Company acquired Barrett Communications Pty Ltd ("Barrett Communications"), a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The business is a part of the Products and Systems Integration segment.

- added (2022-11-03):
[0000068505-22-000031:note_history:9]
Recent Accounting Pronouncements

- added (2022-11-03):
[0000068505-22-000031:note_history:10]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is continuing to evaluate the impact of the adoption of this ASU on its financial statements and disclosures.

- changed (2022-11-03):
[0000068505-22-000031:note_history:11]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the Senior Convertible Notes on diluted earnings per common share.
  (was, 2022-08-04, similarity 0.9711):
[0000068505-22-000025:note_history:11]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the Senior Convertible Notes on diluted earnings per common share.

- changed (2022-11-03):
[0000068505-22-000031:note_history:12]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers," which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and
  (was, 2022-08-04, similarity 0.9252):
[0000068505-22-000025:note_history:12]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, "which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

- added (2022-11-03):
[0000068505-22-000031:note_history:13]
disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

- changed (2022-11-03):
[0000068505-22-000031:note_history:14]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.
  (was, 2022-08-04, similarity 0.9889):
[0000068505-22-000025:note_history:14]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU was effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-03):
[0000068505-22-000031:note_history:15]
|  | October 1, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 694 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 1 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (1) |  |  | (5) |  |
| Long-term debt | $ | 6,012 |  |  | $ | 5,688 |  |
  (was, 2022-08-04, similarity 0.993):
[0000068505-22-000025:note_history:15]
|  | July 2, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 2 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (2) |  |  | (5) |  |
| Long-term debt | $ | 6,011 |  |  | $ | 5,688 |  |

- added (2022-11-03):
[0000068505-22-000031:note_history:16]
On May 31, 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the Company's 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- changed (2022-11-03):
[0000068505-22-000031:note_history:17]
As of October 1, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 1, 2022.
  (was, 2022-08-04, similarity 0.9897):
[0000068505-22-000025:note_history:17]
As of July 2, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 2, 2022.

- changed (2022-11-03):
[0000068505-22-000031:note_history:18]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of October 1, 2022 the Company had no outstanding debt under the commercial paper program.
  (was, 2022-08-04, similarity 0.9364):
[0000068505-22-000025:note_history:18]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 2, 2022 the Company had no outstanding debt under the commercial paper program.

- removed (2022-11-03):
[0000068505-22-000025:note_history:19]
On May 31, 2022, the Company issued $600 million of 5.6% senior notes due 2032. The Company recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-03):
[0000068505-22-000031:note_history:20]
|  | October 1, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 694 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 1 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (1) |  |  | (5) |  |
| Long-term debt | $ | 6,012 |  |  | $ | 5,688 |  |
  (was, 2022-08-04, similarity 0.993):
[0000068505-22-000025:note_history:20]
|  | July 2, 2022 |  | December 31, 2021 |
| 4.0% senior notes due 2024 | $ | 312 |  |  | $ | 585 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 1,000 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 693 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 893 |  |  | 893 |  |
| 2.75% senior notes due 2031 | 844 |  |  | 844 |  |
| 5.6% senior notes due 2032 | 595 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other debt | 2 |  |  | 5 |  |
|  | 6,014 |  |  | 5,695 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (2) |  |
| Less: current portion | (2) |  |  | (5) |  |
| Long-term debt | $ | 6,011 |  |  | $ | 5,688 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-03):
[0000068505-22-000031:note_history:21]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 1, 2022 and October 2, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2022-11-03):
[0000068505-22-000031:note_history:22]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |  | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |
| International | 363 |  |  | 323 |  |  | 686 |  |  | 333 |  |  | 325 |  |  | 658 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |  | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |
| Video Security and Access Control | 286 |  |  | 133 |  |  | 419 |  |  | 214 |  |  | 102 |  |  | 316 |  |
| Command Center Software | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 133 |  |  | 133 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |  | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |
| Indirect | 627 |  |  | 75 |  |  | 702 |  |  | 487 |  |  | 79 |  |  | 566 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
  (was, 2022-08-04, similarity 0.982):
[0000068505-22-000025:note_history:22]
|  | Three Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |  | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |
| International | 322 |  |  | 334 |  |  | 656 |  |  | 329 |  |  | 330 |  |  | 659 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |  | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |
| Video Security and Access Control | 247 |  |  | 123 |  |  | 370 |  |  | 212 |  |  | 94 |  |  | 306 |  |
| Command Center Software | — |  |  | 162 |  |  | 162 |  |  | — |  |  | 134 |  |  | 134 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |  | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |
| Indirect | 574 |  |  | 77 |  |  | 651 |  |  | 492 |  |  | 67 |  |  | 559 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |

- changed (2022-11-03):
[0000068505-22-000031:note_history:23]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |  | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |
| International | 957 |  |  | 973 |  |  | 1,930 |  |  | 935 |  |  | 970 |  |  | 1,905 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |  | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |
| Video Security and Access Control | 728 |  |  | 368 |  |  | 1,096 |  |  | 590 |  |  | 284 |  |  | 874 |  |
| Command Center Software | — |  |  | 435 |  |  | 435 |  |  | — |  |  | 387 |  |  | 387 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |  | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |
| Indirect | 1,647 |  |  | 228 |  |  | 1,875 |  |  | 1,390 |  |  | 214 |  |  | 1,604 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
  (was, 2022-08-04, similarity 0.9789):
[0000068505-22-000025:note_history:23]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |  | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |
| International | 594 |  |  | 650 |  |  | 1,244 |  |  | 602 |  |  | 645 |  |  | 1,247 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |  | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |
| Video Security and Access Control | 441 |  |  | 236 |  |  | 677 |  |  | 377 |  |  | 182 |  |  | 559 |  |
| Command Center Software | — |  |  | 292 |  |  | 292 |  |  | — |  |  | 254 |  |  | 254 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |  | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |
| Indirect | 1,021 |  |  | 164 |  |  | 1,185 |  |  | 903 |  |  | 135 |  |  | 1,038 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |

- removed (2022-11-03):
[0000068505-22-000025:note_history:24]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 2, 2022 and July 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-03):
[0000068505-22-000031:note_history:25]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 1, 2022 and October 2, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2022-11-03):
[0000068505-22-000031:note_history:26]
|  | Three Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |  | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |
| International | 363 |  |  | 323 |  |  | 686 |  |  | 333 |  |  | 325 |  |  | 658 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |  | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |
| Video Security and Access Control | 286 |  |  | 133 |  |  | 419 |  |  | 214 |  |  | 102 |  |  | 316 |  |
| Command Center Software | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 133 |  |  | 133 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |  | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |
| Indirect | 627 |  |  | 75 |  |  | 702 |  |  | 487 |  |  | 79 |  |  | 566 |  |
|  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |
  (was, 2022-08-04, similarity 0.982):
[0000068505-22-000025:note_history:26]
|  | Three Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |  | $ | 869 |  |  | $ | 443 |  |  | $ | 1,312 |  |
| International | 322 |  |  | 334 |  |  | 656 |  |  | 329 |  |  | 330 |  |  | 659 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |  | $ | 986 |  |  | $ | 545 |  |  | $ | 1,531 |  |
| Video Security and Access Control | 247 |  |  | 123 |  |  | 370 |  |  | 212 |  |  | 94 |  |  | 306 |  |
| Command Center Software | — |  |  | 162 |  |  | 162 |  |  | — |  |  | 134 |  |  | 134 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |  | $ | 706 |  |  | $ | 706 |  |  | $ | 1,412 |  |
| Indirect | 574 |  |  | 77 |  |  | 651 |  |  | 492 |  |  | 67 |  |  | 559 |  |
|  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |  | $ | 1,198 |  |  | $ | 773 |  |  | $ | 1,971 |  |

- changed (2022-11-03):
[0000068505-22-000031:note_history:27]
|  | Nine Months Ended |
|  | October 1, 2022 |  | October 2, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |  | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |
| International | 957 |  |  | 973 |  |  | 1,930 |  |  | 935 |  |  | 970 |  |  | 1,905 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |  | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |
| Video Security and Access Control | 728 |  |  | 368 |  |  | 1,096 |  |  | 590 |  |  | 284 |  |  | 874 |  |
| Command Center Software | — |  |  | 435 |  |  | 435 |  |  | — |  |  | 387 |  |  | 387 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |  | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |
| Indirect | 1,647 |  |  | 228 |  |  | 1,875 |  |  | 1,390 |  |  | 214 |  |  | 1,604 |  |
|  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |
  (was, 2022-08-04, similarity 0.9789):
[0000068505-22-000025:note_history:27]
|  | Six Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |  | $ | 1,611 |  |  | $ | 886 |  |  | $ | 2,497 |  |
| International | 594 |  |  | 650 |  |  | 1,244 |  |  | 602 |  |  | 645 |  |  | 1,247 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |  | $ | 1,836 |  |  | $ | 1,095 |  |  | $ | 2,931 |  |
| Video Security and Access Control | 441 |  |  | 236 |  |  | 677 |  |  | 377 |  |  | 182 |  |  | 559 |  |
| Command Center Software | — |  |  | 292 |  |  | 292 |  |  | — |  |  | 254 |  |  | 254 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |  | $ | 1,310 |  |  | $ | 1,396 |  |  | $ | 2,706 |  |
| Indirect | 1,021 |  |  | 164 |  |  | 1,185 |  |  | 903 |  |  | 135 |  |  | 1,038 |  |
|  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |  | $ | 2,213 |  |  | $ | 1,531 |  |  | $ | 3,744 |  |

- changed (2022-11-03):
[0000068505-22-000031:note_history:28]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of October 1, 2022 was $9.1 billion. A total of $4.8 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of October 1, 2022, of which $2.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.3 billion was from Software and Services performance obligations that were not yet satisfied as of October 1, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.4 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2022-08-04, similarity 0.9885):
[0000068505-22-000025:note_history:28]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 2, 2022 was $9.0 billion. A total of $4.3 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of July 2, 2022, of which $2.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.7 billion was from Software and Services performance obligations that were not yet satisfied as of July 2, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2022-11-03):
[0000068505-22-000031:note_history:29]
| (In millions) | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,368 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 1,033 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,549 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 327 |  |  | 306 |  |  |  |  |  |
  (was, 2022-08-04, similarity 0.979):
[0000068505-22-000025:note_history:29]
| (In millions) | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,284 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 1,045 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,556 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 308 |  |  | 306 |  |  |  |  |  |

- added (2022-11-03):
[0000068505-22-000031:note_history:30]
Revenue recognized during the three months ended October 1, 2022 which was previously included in Contract liabilities as of July 2, 2022 was $437 million, compared to $472 million of revenue recognized during the three months ended October 2, 2021 which was previously included in Contract liabilities as of July 3, 2021. Revenue recognized during the nine months ended October 1, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $939 million, compared to $946 million recognized during the nine months ended October 2, 2021 which was previously included in Contract liabilities as of December 31, 2020. The Company reversed $3 million of revenue during the three months ended October 1, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $2 million of reversals for the three months ended October 2, 2021, primarily driven by changes in the estimates of progress on system contracts. Revenue of $23 million was reversed during the nine months ended October 1, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the nine months ended October 2, 2021.

- changed (2022-11-03):
[0000068505-22-000031:note_history:31]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended October 1, 2022 and October 2, 2021.
Contract Cost Balances
  (was, 2022-08-04, similarity 0.8397):
[0000068505-22-000025:note_history:31]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 2, 2022 and July 3, 2021.

- changed (2022-11-03):
[0000068505-22-000031:note_history:32]
| (In millions) | October 1, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 52 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 120 |  |  | 124 |  |  |  |  |  |
  (was, 2022-08-04, similarity 0.9688):
[0000068505-22-000025:note_history:32]
| (In millions) | July 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 39 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 118 |  |  | 124 |  |  |  |  |  |

- changed (2022-11-03):
[0000068505-22-000031:note_history:33]
Amortization of non-current contract cost assets was $14 million and $41 million for the three and nine months ended October 1, 2022, respectively, and $12 million and $37 million for the three and nine months ended October 2, 2021, respectively
  (was, 2022-08-04, similarity 0.7974):
[0000068505-22-000025:note_history:33]
Amortization of non-current contract cost assets was $13 million and $26 million for the three and six months ended July 2, 2022, respectively, and $12 million and $25 million for the three and six months ended July 3, 2021, respectively

- removed (2022-11-03):
[0000068505-22-000025:note_history:34]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 2, 2022 and July 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- removed (2022-11-03):
[0000068505-22-000025:note_history:35]
Revenue recognized during the three months ended July 2, 2022 which was previously included in Contract liabilities as of April 2, 2022 was $456 million, compared to $483 million of revenue recognized during the three months ended July 3, 2021 which was previously included in Contract liabilities as of April 3, 2021. Revenue recognized during the six months ended July 2, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $712 million, compared to $705 million recognized during the six months ended July 3, 2021 which was previously included in Contract liabilities as of December 31, 2020. The Company did not reverse any revenue during the three months ended July 2, 2022 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $10 million of reversals for the three months ended July 3, 2021, primarily driven by changes in the estimates of progress on system contracts, Revenue of $22 million was reversed during the six months ended July 2, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $15 million of reversals for the six months ended July 3, 2021.

- removed (2022-11-03):
[0000068505-22-000025:note_history:36]
Contract Cost Balances
