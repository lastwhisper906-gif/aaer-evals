# MSI notes — 0000068505-18-000029


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-18-000029:notes:1]
[same as prior period, unchanged from 0000068505-18-000023:notes:1]

[0000068505-18-000029:notes:2]
|  | September 29, 2018 |  | December 31, 2017 |
| Corporate bonds | $ | 2 |  |  | $ | 2 |  |
| Common stock | 17 |  |  | 13 |  |
| Strategic investments, at cost | 60 |  |  | 78 |  |
| Company-owned life insurance policies | 83 |  |  | 141 |  |
| Equity method investments | 14 |  |  | 13 |  |
|  | $ | 176 |  |  | $ | 247 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-18-000029:notes:3]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 29, 2018 and December 31, 2017 were as follows:

[0000068505-18-000029:notes:4]
| September 29, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |
| Corporate bonds | 2 |  |  | — |  |  | 2 |  |
| Common stock | — |  |  | 17 |  |  | 17 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-18-000029:notes:5]
[same as prior period, unchanged from 0000068505-18-000023:notes:5]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-18-000029:notes:6]
[same as prior period, unchanged from 0000068505-18-000023:notes:6]

[0000068505-18-000029:notes:7]
[same as prior period, unchanged from 0000068505-18-000023:notes:7]

[0000068505-18-000029:notes:8]
[same as prior period, unchanged from 0000068505-18-000023:notes:8]

[0000068505-18-000029:notes:9]
|  | September 29, 2018 |  | December 31, 2017 |
| Long-term receivables, gross | $ | 29 |  |  | $ | 37 |  |
| Less allowance for losses | (2 | ) |  | — |  |
| Long-term receivables | 27 |  |  | 37 |  |
| Less current portion | (7 | ) |  | (18 | ) |
| Non-current long-term receivables | $ | 20 |  |  | $ | 19 |  |

[0000068505-18-000029:notes:10]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $86 million at September 29, 2018, compared to $93 million at December 31, 2017.

[0000068505-18-000029:notes:11]
[same as prior period, unchanged from 0000068505-18-000023:notes:11]

[0000068505-18-000029:notes:12]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 29, 2018 and September 30, 2017:

[0000068505-18-000029:notes:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Accounts receivable sales proceeds | $ | — |  |  | $ | 99 |  |  | $ | 76 |  |  | $ | 179 |  |
| Long-term receivables sales proceeds | 73 |  |  | 55 |  |  | 101 |  |  | 123 |  |
| Total proceeds from receivable sales | $ | 73 |  |  | $ | 154 |  |  | $ | 177 |  |  | $ | 302 |  |

[0000068505-18-000029:notes:14]
At September 29, 2018, the Company had retained servicing obligations for $879 million of long-term receivables, compared to $873 million at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000029:notes:15]
Credit Quality of Long-term Receivables and Allowance for Credit Losses

[0000068505-18-000029:notes:16]
An aging analysis of long-term receivables at September 29, 2018 and December 31, 2017 is as follows:

[0000068505-18-000029:notes:17]
| September 29, 2018 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 20 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Commercial loans and leases secured | 9 |  |  | 2 |  |  | — |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 29 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 3 |  |

[0000068505-18-000029:notes:18]
[same as prior period, unchanged from 0000068505-18-000023:notes:18]


## msi:OtherChargesTableTextBlock

[0000068505-18-000029:notes:19]
[same as prior period, unchanged from 0000068505-18-000023:notes:19]

[0000068505-18-000029:notes:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 14) | $ | 46 |  |  | $ | 39 |  |  | $ | 140 |  |  | $ | 111 |  |
| Reorganization of business (Note 13) | 21 |  |  | 6 |  |  | 46 |  |  | 22 |  |
| Environmental reserve expense | 57 |  |  | — |  |  | 57 |  |  | — |  |
| Building impairment | — |  |  | — |  |  | — |  |  | 8 |  |
| Loss (Gain) on legal settlements | 2 |  |  | — |  |  | 3 |  |  | (2 | ) |
| Gain on recovery of financial receivables | — |  |  | — |  |  | — |  |  | (42 | ) |
| Asset impairment | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Acquisition-related transaction fees | — |  |  | — |  |  | 17 |  |  | 1 |  |
|  | $ | 126 |  |  | $ | 47 |  |  | $ | 263 |  |  | $ | 100 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-18-000029:notes:21]
[same as prior period, unchanged from 0000068505-18-000023:notes:21]

[0000068505-18-000029:notes:22]
| September 29, 2018 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 19 |  |  | $ | 47 |  |
| Services and Software | 6 |  |  | 15 |  |
|  | $ | 25 |  |  | $ | 62 |  |

[0000068505-18-000029:notes:23]
| September 30, 2017 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 22 |  |
| Services and Software | 2 |  |  | 8 |  |
|  | $ | 8 |  |  | $ | 30 |  |


## msi:RevenuefromContractWithCustomerPolicyTextBlock

[0000068505-18-000029:notes:24]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-18-000029:notes:25]
Significant Judgments

[0000068505-18-000029:notes:26]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-18-000029:notes:27]
The Company accounts for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized product solutions. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-18-000029:notes:28]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-18-000029:notes:29]
[same as prior period, unchanged from 0000068505-18-000023:notes:24]

[0000068505-18-000029:notes:30]
[same as prior period, unchanged from 0000068505-18-000023:notes:25]

[0000068505-18-000029:notes:31]
[same as prior period, unchanged from 0000068505-18-000023:notes:26]

[0000068505-18-000029:notes:32]
[same as prior period, unchanged from 0000068505-18-000023:notes:27]

[0000068505-18-000029:notes:33]
[same as prior period, unchanged from 0000068505-18-000023:notes:28]

[0000068505-18-000029:notes:34]
[same as prior period, unchanged from 0000068505-18-000023:notes:29]


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-18-000029:notes:35]
[same as prior period, unchanged from 0000068505-18-000023:notes:30]

[0000068505-18-000029:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 3 |  |  | $ | 2 |  |  | $ | 8 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 12 |  |  | 11 |  |  | 33 |  |  | 32 |  |
| Research and development expenditures | 4 |  |  | 3 |  |  | 12 |  |  | 10 |  |
| Share-based compensation expense included in Operating earnings | 19 |  |  | 16 |  |  | 53 |  |  | 49 |  |
| Tax benefit | 5 |  |  | 5 |  |  | 13 |  |  | 16 |  |
| Share-based compensation expense, net of tax | $ | 14 |  |  | $ | 11 |  |  | $ | 40 |  |  | $ | 33 |  |
| Decrease in basic earnings per share | $ | (0.09 | ) |  | $ | (0.07 | ) |  | $ | (0.25 | ) |  | $ | (0.20 | ) |
| Decrease in diluted earnings per share | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.23 | ) |  | $ | (0.19 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-18-000029:notes:37]
[same as prior period, unchanged from 0000068505-18-000023:notes:32]

[0000068505-18-000029:notes:38]
|  | September 29, 2018 |  | December 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 510 |  |  | $ | 29 |  |  | $ | 12 |  |  | $ | 8 |  |
| Services and Software | 1,241 |  |  | 425 |  |  | 1,171 |  |  | 314 |  |
|  | $ | 1,751 |  |  | $ | 454 |  |  | $ | 1,183 |  |  | $ | 322 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-18-000029:notes:39]
[same as prior period, unchanged from 0000068505-18-000023:notes:34]

[0000068505-18-000029:notes:40]
|  | September 29, 2018 |  | December 31, 2017 |
| Defined benefit plans | $ | 1,446 |  |  | $ | 2,019 |  |
| Non-current contract liabilities (Note 2) | 159 |  |  | — |  |
| Deferred revenue (Note 1) | — |  |  | 169 |  |
| Unrecognized tax benefits | 51 |  |  | 54 |  |
| Deferred income taxes | 234 |  |  | 115 |  |
| Other | 285 |  |  | 228 |  |
|  | $ | 2,175 |  |  | $ | 2,585 |  |


## msi:ScheduleOfTaxCutsAndJobsActof2017IncompleteAccountingProvisionalIncomeTaxExpenseBenefitTableTextBlock

[0000068505-18-000029:notes:41]
For the nine months ended September 29, 2018, the Company has recorded the following adjustments to the previously recorded provisional tax amounts:

[0000068505-18-000029:notes:42]
|  | December 31, 2017 |  | Adjustment |  | September 29, 2018 |  | Financial Statement Location |
| Valuation allowance on foreign tax credit carryforward | $ | 471 |  |  | $ | (9 | ) |  | $ | 462 |  |  | Deferred tax expense |
| Measurement of U.S. deferred tax balances at 21% | 366 |  |  | (11 | ) |  | 355 |  |  | Deferred tax expense |
| Transition tax on repatriation of foreign earnings | 16 |  |  | 2 |  |  | 18 |  |  | Current tax expense |
| Uncertain tax positions on foreign operations | 21 |  |  | — |  |  | 21 |  |  | Current tax expense |
| Disallowed deduction of covered employees' incentive plans | — |  |  | 4 |  |  | 4 |  |  | Deferred tax expense |
|  | $ | 874 |  |  | $ | (14 | ) |  | $ | 860 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-18-000029:notes:43]
[same as prior period, unchanged from 0000068505-18-000023:notes:36]

[0000068505-18-000029:notes:44]
[same as prior period, unchanged from 0000068505-18-000023:notes:37]

[0000068505-18-000029:notes:45]
[same as prior period, unchanged from 0000068505-18-000023:notes:38]

[0000068505-18-000029:notes:46]
During the third quarter of 2018, the Company revised the estimate of a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. During the third quarter of 2018, the Company became aware of additional remediation requirements for the Superfund site. As such, the Company recorded a charge of $57 million during the third quarter of 2018 which was primarily due to: (i) changes in the expected timeline of the remediation activities to 30 years and (ii) additional costs for further remediation efforts, increasing the reserve to $107 million. Given the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounted the cash flows used in estimating this accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is $4 million and is included in the “Accrued liabilities” statement line and the non-current portion is included in the “Other liabilities” statement line within the Company's Condensed Consolidated Balance Sheet.

[0000068505-18-000029:notes:47]
During the nine months ending September 29, 2018, the Company recognized $17 million of acquisition-related transaction fees for the Avigilon and Plant acquisitions.

[0000068505-18-000029:notes:48]
During the nine months ended September 30, 2017, the Company recognized $8 million of building impairments related to the anticipated sale of its Basingstoke, U.K. building.

[0000068505-18-000029:notes:49]
During the nine months ended September 30, 2017, the Company recognized a net gain of $42 million related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business.

[0000068505-18-000029:notes:50]
[same as prior period, unchanged from 0000068505-18-000023:notes:42]

[0000068505-18-000029:notes:51]
[same as prior period, unchanged from 0000068505-18-000023:notes:43]

[0000068505-18-000029:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (62 | ) |  | $ | (55 | ) |  | $ | (178 | ) |  | $ | (164 | ) |
| Interest income | 3 |  |  | 3 |  |  | 15 |  |  | 10 |  |
|  | $ | (59 | ) |  | $ | (52 | ) |  | $ | (163 | ) |  | $ | (154 | ) |
| Other: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 7) | $ | 18 |  |  | $ | 11 |  |  | $ | 58 |  |  | $ | 36 |  |
| Non-U.S. pension settlement loss (Note 7) | — |  |  | (21 | ) |  | — |  |  | (46 | ) |
| Gain from the extinguishment of convertible debt (Note 4) | 6 |  |  | — |  |  | 6 |  |  | — |  |
| Foreign currency loss | (14 | ) |  | (7 | ) |  | (14 | ) |  | (29 | ) |
| Gain (loss) on derivative instruments | 8 |  |  | 3 |  |  | (15 | ) |  | 14 |  |
| Gains on equity method investments | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Fair value adjustments to equity investments | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Other | 3 |  |  | 4 |  |  | 1 |  |  | 4 |  |
|  | $ | 29 |  |  | $ | (9 | ) |  | $ | 45 |  |  | $ | (20 | ) |

[0000068505-18-000029:notes:53]
During the three and nine months ended September 29, 2018, the Company recognized a foreign currency loss of $14 million, primarily driven by the Brazilian real, the Euro, the Australian dollar and the Argentinian peso. During the three and nine months ended September 29, 2018, the Company recognized a gain of $8 million and a loss of $15 million, respectively, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations. The loss on derivative instruments during the nine months ended September 29, 2018, includes a loss of $14 million on foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the purchase of Avigilon.

[0000068505-18-000029:notes:54]
During the three and nine months ended September 30, 2017, the Company recognized foreign currency losses of $7 million and $29 million, respectively, primarily driven by British Pound, partially offset by gains of $3 million and $14 million, respectively, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-18-000029:notes:55]
[same as prior period, unchanged from 0000068505-18-000023:notes:48]

[0000068505-18-000029:notes:56]
[same as prior period, unchanged from 0000068505-18-000023:notes:49]

[0000068505-18-000029:notes:57]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 247 |  |  | $ | 212 |  |  | $ | 544 |  |  | $ | 420 |  |
| Weighted average common shares outstanding | 162.6 |  |  | 162.3 |  |  | 162.0 |  |  | 163.2 |  |
| Per share amount | $ | 1.52 |  |  | $ | 1.30 |  |  | $ | 3.36 |  |  | $ | 2.57 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 247 |  |  | $ | 212 |  |  | $ | 544 |  |  | $ | 420 |  |
| Weighted average common shares outstanding | 162.6 |  |  | 162.3 |  |  | 162.0 |  |  | 163.2 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 4.6 |  |  | 3.4 |  |  | 4.2 |  |  | 3.3 |  |
| Senior Convertible Notes | 5.4 |  |  | 3.3 |  |  | 5.4 |  |  | 2.8 |  |
| Diluted weighted average common shares outstanding | 172.6 |  |  | 169.0 |  |  | 171.6 |  |  | 169.3 |  |
| Per share amount | $ | 1.43 |  |  | $ | 1.25 |  |  | $ | 3.17 |  |  | $ | 2.48 |  |

[0000068505-18-000029:notes:58]
In the computation of diluted earnings per common share for the three months ended September 29, 2018, the assumed exercise of 0.2 million options were excluded because their inclusion would have been antidilutive. For the nine months ended September 29, 2018, the assumed exercise of 3.2 million options, including 0.8 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-18-000029:notes:59]
For the three months ended September 30, 2017, the assumed exercise of 2.0 million options, including 1.7 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the nine months ended September 30, 2017, the assumed exercise of 2.3 million options, including 1.9 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-18-000029:notes:60]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. On September 5, 2018, the Company agreed with Silver Lake Partners to re-purchase $200 million principal of the convertible notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. During the third quarter of 2018, the Company paid $169 million, with the remaining $200 million paid on October 15, 2018. In the event of an additional conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Since the Company’s intention is to settle the par value of the Senior Convertible Notes in cash upon conversion, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-18-000029:notes:61]
[same as prior period, unchanged from 0000068505-18-000023:notes:54]

[0000068505-18-000029:notes:62]
[same as prior period, unchanged from 0000068505-18-000023:notes:55]

[0000068505-18-000029:notes:63]
[same as prior period, unchanged from 0000068505-18-000023:notes:56]

[0000068505-18-000029:notes:64]
|  | September 29, 2018 |  | December 31, 2017 |
| Accounts receivable | $ | 1,227 |  |  | $ | 1,568 |  |
| Less allowance for doubtful accounts | (48 | ) |  | (45 | ) |
|  | $ | 1,179 |  |  | $ | 1,523 |  |

[0000068505-18-000029:notes:65]
During the nine months ended September 29, 2018, $297 million of Unbilled accounts receivable were reclassified to Contract assets and $24 million of non-customer miscellaneous receivables were reclassified to Other current assets as a result of the adoption of ASC 606.

[0000068505-18-000029:notes:66]
[same as prior period, unchanged from 0000068505-18-000023:notes:59]

[0000068505-18-000029:notes:67]
[same as prior period, unchanged from 0000068505-18-000023:notes:60]

[0000068505-18-000029:notes:68]
|  | September 29, 2018 |  | December 31, 2017 |
| Finished goods | $ | 190 |  |  | $ | 178 |  |
| Work-in-process and production materials | 313 |  |  | 282 |  |
|  | 503 |  |  | 460 |  |
| Less inventory reserves | (136 | ) |  | (133 | ) |
|  | $ | 367 |  |  | $ | 327 |  |

[0000068505-18-000029:notes:69]
During the nine months ended September 29, 2018, the increase in Inventories, net was primarily driven by the acquisition of Avigilon.

[0000068505-18-000029:notes:70]
[same as prior period, unchanged from 0000068505-18-000023:notes:63]

[0000068505-18-000029:notes:71]
[same as prior period, unchanged from 0000068505-18-000023:notes:64]

[0000068505-18-000029:notes:72]
|  | September 29, 2018 |  | December 31, 2017 |
| Costs and earnings in excess of billings (Note 1) | $ | — |  |  | $ | 549 |  |
| Current contract cost assets (Note 2) | 57 |  |  | 62 |  |
| Tax-related refunds receivable | 119 |  |  | 90 |  |
| Other | 174 |  |  | 131 |  |
|  | $ | 350 |  |  | $ | 832 |  |

[0000068505-18-000029:notes:73]
[same as prior period, unchanged from 0000068505-18-000023:notes:66]

[0000068505-18-000029:notes:74]
[same as prior period, unchanged from 0000068505-18-000023:notes:67]

[0000068505-18-000029:notes:75]
|  | September 29, 2018 |  | December 31, 2017 |
| Land | $ | 11 |  |  | $ | 11 |  |
| Building | 355 |  |  | 316 |  |
| Machinery and equipment | 2,224 |  |  | 2,122 |  |
|  | 2,590 |  |  | 2,449 |  |
| Less accumulated depreciation | (1,698 | ) |  | (1,593 | ) |
|  | $ | 892 |  |  | $ | 856 |  |

[0000068505-18-000029:notes:76]
Depreciation expense for the three months ended September 29, 2018 and September 30, 2017 was $43 million and $49 million, respectively. Depreciation expense for the nine months ended September 29, 2018 and September 30, 2017 was $127 million and $142 million, respectively.

[0000068505-18-000029:notes:77]
[same as prior period, unchanged from 0000068505-18-000023:notes:71]

[0000068505-18-000029:notes:78]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the nine months ended September 29, 2018.

[0000068505-18-000029:notes:79]
The Company’s common stock portfolio reflects an investment in the communications services sector and is valued utilizing active market prices for similar instruments. During the three and nine months ended September 29, 2018, the Company recognized $7 million in Other income (expense) related to an increase in the fair value of the investments.

[0000068505-18-000029:notes:80]
Company-owned life insurance policies were recorded at their cash surrender value. During the nine months ended September 29, 2018, the Company withdrew $60 million of excess cash from its company-sponsored life insurance investments.

[0000068505-18-000029:notes:81]
During the three months ended September 29, 2018, Gains on the sale of investments and businesses were $6 million. During the nine months ended September 29, 2018, Gains on the sale of investments and businesses were $16 million, compared to $3 million during the nine months ended September 30, 2017.

[0000068505-18-000029:notes:82]
[same as prior period, unchanged from 0000068505-18-000023:notes:76]

[0000068505-18-000029:notes:83]
[same as prior period, unchanged from 0000068505-18-000023:notes:77]

[0000068505-18-000029:notes:84]
|  | September 29, 2018 |  | December 31, 2017 |
| Defined benefit plan assets | $ | 182 |  |  | $ | 133 |  |
| Tax receivable | 101 |  |  | 101 |  |
| Non-current contract cost assets (Note 2) | 95 |  |  | — |  |
| Other | 66 |  |  | 99 |  |
|  | $ | 444 |  |  | $ | 333 |  |

[0000068505-18-000029:notes:85]
[same as prior period, unchanged from 0000068505-18-000023:notes:79]

[0000068505-18-000029:notes:86]
[same as prior period, unchanged from 0000068505-18-000023:notes:80]

[0000068505-18-000029:notes:87]
|  | September 29, 2018 |  | December 31, 2017 |
| Deferred revenue (Note 1) | $ | — |  |  | $ | 613 |  |
| Compensation | 248 |  |  | 273 |  |
| Billings in excess of costs and earnings (Note 1) | — |  |  | 428 |  |
| Tax liabilities | 127 |  |  | 107 |  |
| Deferred consideration on Airwave acquisition | 84 |  |  | 83 |  |
| Dividend payable | 85 |  |  | 84 |  |
| Trade liabilities | 165 |  |  | 151 |  |
| Other | 459 |  |  | 547 |  |
|  | $ | 1,168 |  |  | $ | 2,286 |  |

[0000068505-18-000029:notes:88]
[same as prior period, unchanged from 0000068505-18-000023:notes:82]

[0000068505-18-000029:notes:89]
[same as prior period, unchanged from 0000068505-18-000023:notes:83]

[0000068505-18-000029:notes:90]
The Company made a $500 million contribution to our U.S. Pension Plans during the nine months ended September 29, 2018.

[0000068505-18-000029:notes:91]
During the nine months ended September 29, 2018, the deferred income taxes increase was primarily driven by the intangible assets related to acquisition of Avigilon.

[0000068505-18-000029:notes:92]
[same as prior period, unchanged from 0000068505-18-000023:notes:86]

[0000068505-18-000029:notes:93]
[same as prior period, unchanged from 0000068505-18-000023:notes:87]

[0000068505-18-000029:notes:94]
During the nine months ended September 29, 2018, the Company paid an aggregate of $66 million, including transaction costs, to repurchase approximately 0.6 million shares at an average price of $101.54 per share. As of September 29, 2018, the Company had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-18-000029:notes:95]
Payment of Dividends: During the three months ended September 29, 2018 and September 30, 2017, the Company paid $84 million and $76 million, respectively, in cash dividends to holders of its common stock. During the nine months ended September 29, 2018 and September 30, 2017, the Company paid $252 million and $230 million, respectively, in cash dividends to holders of its common stock.

[0000068505-18-000029:notes:96]
[same as prior period, unchanged from 0000068505-18-000023:notes:90]

[0000068505-18-000029:notes:97]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and nine months ended September 29, 2018 and September 30, 2017:

[0000068505-18-000029:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (391 | ) |  | $ | (413 | ) |  | $ | (353 | ) |  | $ | (494 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (3 | ) |  | 49 |  |  | (33 | ) |  | 133 |  |
| Tax benefit | (1 | ) |  | (3 | ) |  | (9 | ) |  | (6 | ) |
| Other comprehensive income (loss), net of tax | (4 | ) |  | 46 |  |  | (42 | ) |  | 127 |  |
| Balance at end of period | $ | (395 | ) |  | $ | (367 | ) |  | $ | (395 | ) |  | $ | (367 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | 4 |  |  | $ | 6 |  |  | $ | — |  |
| Other comprehensive income before reclassification adjustment | — |  |  | 1 |  |  | — |  |  | 8 |  |
| Tax benefit | — |  |  | — |  |  | — |  |  | (3 | ) |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | 1 |  |  | — |  |  | 5 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | — |  |  | — |  |  | (8 | ) |  | — |  |
| Tax expense | — |  |  | — |  |  | 2 |  |  | — |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | — |  |  | — |  |  | (6 | ) |  | — |  |
| Other comprehensive income (loss), net of tax | — |  |  | 1 |  |  | (6 | ) |  | 5 |  |
| Balance at end of period | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,189 | ) |  | $ | (1,790 | ) |  | $ | (2,215 | ) |  | $ | (1,823 | ) |
| Other comprehensive loss before reclassification adjustment, net of tax | — |  |  | (4 | ) |  | — |  |  | (15 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 20 |  |  | 17 |  |  | 57 |  |  | 49 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4 | ) |  | (4 | ) |  | (11 | ) |  | (12 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other income (expense) | — |  |  | 21 |  |  | — |  |  | 46 |  |
| Tax benefit | (3 | ) |  | (4 | ) |  | (7 | ) |  | (9 | ) |
| Reclassification adjustment into Net earnings, net of tax | 13 |  |  | 30 |  |  | 39 |  |  | 74 |  |
| Other comprehensive income, net of tax | 13 |  |  | 26 |  |  | 39 |  |  | 59 |  |
| Balance at end of period | $ | (2,176 | ) |  | $ | (1,764 | ) |  | $ | (2,176 | ) |  | $ | (1,764 | ) |
| Total Accumulated other comprehensive loss | $ | (2,571 | ) |  | $ | (2,126 | ) |  | $ | (2,571 | ) |  | $ | (2,126 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-18-000029:notes:99]
The condensed consolidated financial statements as of September 29, 2018 and for the three and nine months ended September 29, 2018 and September 30, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-18-000029:notes:100]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three and nine months ended September 29, 2018 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-18-000029:notes:101]
[same as prior period, unchanged from 0000068505-18-000023:notes:95]


## us-gaap:CapitalizedContractCostTableTextBlock

[0000068505-18-000029:notes:102]
| (in millions) | September 29, 2018 |  | January 1, 2018 |  |
| Current contract cost assets | $ | 57 |  |  | $ | 62 |  |
| Non-current contract cost assets | 95 |  |  | 85 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-18-000029:notes:103]
Commitments and Contingencies

[0000068505-18-000029:notes:104]
Legal Matters

[0000068505-18-000029:notes:105]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-18-000029:notes:106]
Other Indemnifications

[0000068505-18-000029:notes:107]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-18-000029:notes:108]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at September 29, 2018.

[0000068505-18-000029:notes:109]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000068505-18-000029:notes:110]
| (in millions) | September 29, 2018 |  | January 1, 2018 |  |
| Receivables | $ | 1,179 |  |  | $ | 1,198 |  |
| Contract assets | 917 |  |  | 931 |  |
| Contract liabilities | 1,127 |  |  | 1,082 |  |
| Non-current contract liabilities | 159 |  |  | 162 |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-18-000029:notes:111]
Debt and Credit Facilities

[0000068505-18-000029:notes:112]
As of September 29, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, the Company borrowed $400 million under the facility to complete the Avigilon acquisition. As of September 29, 2018, the outstanding loan amount under the facility was $100 million, with $200 million paid during the third quarter. Subsequent to the quarter, the Company paid the remaining $100 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts for the three and nine months ended September 29, 2018 was 3.58%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 29, 2018.

[0000068505-18-000029:notes:113]
Also in conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the three and nine months ended September 29, 2018 were 3.33% and 3.43%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-18-000029:notes:114]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan.

[0000068505-18-000029:notes:115]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.8252, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.45 per share). The exercise price adjusts automatically for dividends. On September 5, 2018, the Company agreed with Silver Lake Partners to repurchase $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. As of September 29, 2018, the Company paid $169 million of cash to Silver Lake Partners and recorded a gain of $6 million from the extinguishment of the convertible debt. The principal amount of $200 million was reclassified to short term debt. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of September 29, 2018 was $712 million. In the event of an additional conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-18-000029:notes:116]
On September 28, 2018, the Company issued an additional $200 million on the outstanding 4.60% Senior notes due 2028 bringing the outstanding total to $700 million. The Company settled the issuance on October 5, 2018 and recognized net proceeds of $196 million, subsequent to quarter end, which was then used to pay the $200 million principal due to Silver Lake Partners on October 15, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-18-000029:notes:117]
[same as prior period, unchanged from 0000068505-18-000023:notes:111]

[0000068505-18-000029:notes:118]
[same as prior period, unchanged from 0000068505-18-000023:notes:112]

[0000068505-18-000029:notes:119]
As of September 29, 2018, the Company had outstanding foreign exchange contracts with notional amounts totaling $782 million, compared to $507 million outstanding at December 31, 2017. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-18-000029:notes:120]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 29, 2018, and the corresponding positions as of December 31, 2017:

[0000068505-18-000029:notes:121]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 29, 2018 |  | December 31, 2017 |
| British Pound | $ | 221 |  |  | $ | 72 |  |
| Euro | 215 |  |  | 149 |  |
| Australian Dollar | (109 | ) |  | (64 | ) |
| Chinese Renminbi | (75 | ) |  | (73 | ) |
| Brazilian Real | (46 | ) |  | (45 | ) |

[0000068505-18-000029:notes:122]
[same as prior period, unchanged from 0000068505-18-000023:notes:119]

[0000068505-18-000029:notes:123]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 29, 2018, all of the counterparties have investment grade credit ratings. As of September 29, 2018, the Company had $6 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-18-000029:notes:124]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of September 29, 2018 and December 31, 2017:

[0000068505-18-000029:notes:125]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| September 29, 2018 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 6 |  |  | Other current assets |  | $ | 1 |  |  | Accrued liabilities |

[0000068505-18-000029:notes:126]
[same as prior period, unchanged from 0000068505-18-000023:notes:123]

[0000068505-18-000029:notes:127]
The following table summarizes the effect of derivatives designated as hedging instruments on the Company's condensed consolidated financial statements for the three and nine months ended September 29, 2018 and September 30, 2017:

[0000068505-18-000029:notes:128]
|  | Three Months Ended |  | Nine Months Ended |  | Balance SheetLocation |
| Loss on Derivative Instruments | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |  |
| Foreign exchange contracts | $ | (1 | ) |  | $ | (1 | ) |  | $ | — |  |  | $ | (3 | ) |  | Other comprehensive income (loss) |

[0000068505-18-000029:notes:129]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated financial statements for the three and nine months ended September 29, 2018 and September 30, 2017:

[0000068505-18-000029:notes:130]
|  | Three Months Ended |  | Nine Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |  |
| Interest agreements | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | Other income (expense) |
| Foreign exchange contracts | 8 |  |  | 4 |  |  | (15 | ) |  | 15 |  |  | Other income (expense) |
| Total derivatives | $ | 8 |  |  | $ | 3 |  |  | $ | (15 | ) |  | $ | 14 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000068505-18-000029:notes:131]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-18-000029:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 957 |  |  | $ | 343 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 199 |  |  | 189 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 132 |  |  | 42 |  |  | 353 |  |  | 126 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 828 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 460 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 455 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 119 |  |  | — |  |  | 303 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 811 |  |  | $ | 543 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 477 |  |  | 31 |  |  | 1,261 |  |  | 74 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-18-000029:notes:133]
[same as prior period, unchanged from 0000068505-18-000023:notes:130]

[0000068505-18-000029:notes:134]
During the nine months ended September 29, 2018, the Company granted 0.4 million restricted stock units ("RSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $45 million and $7 million, respectively, and 0.2 million stock options and 0.2 million performance options ("POs") with an aggregate grant-date fair value of $6 million and $7 million, respectively. Share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-18-000029:notes:135]
[same as prior period, unchanged from 0000068505-18-000023:notes:132]

[0000068505-18-000029:notes:136]
[same as prior period, unchanged from 0000068505-18-000023:notes:133]

[0000068505-18-000029:notes:137]
[same as prior period, unchanged from 0000068505-18-000023:notes:134]

[0000068505-18-000029:notes:138]
[same as prior period, unchanged from 0000068505-18-000023:notes:135]

[0000068505-18-000029:notes:139]
[same as prior period, unchanged from 0000068505-18-000023:notes:136]

[0000068505-18-000029:notes:140]
[same as prior period, unchanged from 0000068505-18-000023:notes:137]

[0000068505-18-000029:notes:141]
The Company had no Level 3 holdings as of September 29, 2018 or December 31, 2017.

[0000068505-18-000029:notes:142]
At September 29, 2018 and December 31, 2017, the Company had $284 million and $633 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-18-000029:notes:143]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at September 29, 2018 and December 31, 2017 was $5.5 billion and $4.6 billion (Level 2), respectively.

[0000068505-18-000029:notes:144]
[same as prior period, unchanged from 0000068505-18-000023:notes:141]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-18-000029:notes:145]
[same as prior period, unchanged from 0000068505-18-000023:notes:142]

[0000068505-18-000029:notes:146]
[same as prior period, unchanged from 0000068505-18-000023:notes:143]

[0000068505-18-000029:notes:147]
[same as prior period, unchanged from 0000068505-18-000023:notes:144]

[0000068505-18-000029:notes:148]
[same as prior period, unchanged from 0000068505-18-000023:notes:145]

[0000068505-18-000029:notes:149]
[same as prior period, unchanged from 0000068505-18-000023:notes:146]

[0000068505-18-000029:notes:150]
| Accounts receivable, net |  | $ | 67 |  |
| Inventory |  | 93 |  |
| Other current assets |  | 18 |  |
| Property, plant and equipment, net |  | 33 |  |
| Deferred income taxes |  | 4 |  |
| Accounts payable |  | (21 | ) |
| Accrued liabilities |  | (28 | ) |
| Deferred income tax liabilities |  | (134 | ) |
| Goodwill |  | 444 |  |
| Intangible assets |  | 498 |  |
| Total consideration |  | $ | 974 |  |

[0000068505-18-000029:notes:151]
[same as prior period, unchanged from 0000068505-18-000023:notes:148]

[0000068505-18-000029:notes:152]
[same as prior period, unchanged from 0000068505-18-000023:notes:149]

[0000068505-18-000029:notes:153]
[same as prior period, unchanged from 0000068505-18-000023:notes:150]

[0000068505-18-000029:notes:154]
[same as prior period, unchanged from 0000068505-18-000023:notes:151]

[0000068505-18-000029:notes:155]
[same as prior period, unchanged from 0000068505-18-000023:notes:152]

[0000068505-18-000029:notes:156]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million net cash. This acquisition will expand the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1. The Company recognized $161 million of goodwill, $80 million of identifiable intangible assets and $4 million of acquired liabilities. Goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of 10 to 20 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change.

[0000068505-18-000029:notes:157]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers, for a purchase price of $225 million. As a result of the acquisition, the Company recognized $191 million of goodwill, $44 million of identifiable intangible assets and $10 million of acquired liabilities. The identifiable intangible assets were classified as $25 million of customer-related intangibles and $19 million of completed technology and will be amortized over a period of 13 to 16 years.

[0000068505-18-000029:notes:158]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides services for communications systems to public safety and commercial customers in Chile, for a purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $16 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-18-000029:notes:159]
[same as prior period, unchanged from 0000068505-18-000023:notes:156]

[0000068505-18-000029:notes:160]
[same as prior period, unchanged from 0000068505-18-000023:notes:157]

[0000068505-18-000029:notes:161]
[same as prior period, unchanged from 0000068505-18-000023:notes:158]

[0000068505-18-000029:notes:162]
|  | September 29, 2018 |  | December 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 559 |  |  | $ | 81 |  |  | $ | 148 |  |  | $ | 55 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,115 |  |  | 344 |  |  | 977 |  |  | 242 |  |
| Other intangibles | 75 |  |  | 27 |  |  | 56 |  |  | 23 |  |
|  | $ | 1,751 |  |  | $ | 454 |  |  | $ | 1,183 |  |  | $ | 322 |  |

[0000068505-18-000029:notes:163]
Amortization expense on intangible assets was $46 million for the three months ended September 29, 2018 and $140 million for the nine months ended September 29, 2018. Amortization expense on intangible assets was $39 million for the three months ended September 30, 2017 and $111 million for the nine months ended September 30, 2017. As of September 29, 2018, annual amortization expense is estimated to be $189 million in 2018, $193 million in 2019, $191 million in 2020, $187 million in 2021, $184 million in 2022, and $84 million in 2023.

[0000068505-18-000029:notes:164]
[same as prior period, unchanged from 0000068505-18-000023:notes:161]

[0000068505-18-000029:notes:165]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2018 to September 29, 2018:

[0000068505-18-000029:notes:166]
|  | Products and Systems Integration |  | Services and Software |  | Total |
| Balance as of January 1, 2018 | $ | 362 |  |  | $ | 576 |  |  | $ | 938 |  |
| Goodwill acquired | 359 |  |  | 231 |  |  | 590 |  |
| Purchase accounting adjustments | 10 |  |  | 7 |  |  | 17 |  |
| Foreign currency | — |  |  | (4 | ) |  | (4 | ) |
| Balance as of September 29, 2018 | $ | 731 |  |  | $ | 810 |  |  | $ | 1,541 |  |

[0000068505-18-000029:notes:167]
During the second quarter of 2018, the Company modified its internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership, in part, as a result of recent acquisitions contributing to the growth within the newly aligned Services and Software segment. Previously, the Company had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration-related revenue and costs moving from the old Services segment into the newly presented Products and Systems Integration segment and Software related revenue and costs moving from the old Products segment into the newly presented Services and Software segment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-18-000029:notes:168]
[same as prior period, unchanged from 0000068505-18-000023:notes:165]

[0000068505-18-000029:notes:169]
[same as prior period, unchanged from 0000068505-18-000023:notes:166]

[0000068505-18-000029:notes:170]
[same as prior period, unchanged from 0000068505-18-000023:notes:167]

[0000068505-18-000029:notes:171]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Net earnings before income taxes | $ | 270 |  |  | $ | 286 |  |  | $ | 637 |  |  | $ | 610 |  |
| Income tax expense | 22 |  |  | 73 |  |  | 91 |  |  | 188 |  |
| Effective tax rate | 8 | % |  | 26 | % |  | 14 | % |  | 31 | % |

[0000068505-18-000029:notes:172]
The Company recorded $22 million of net tax expense during the three months ended September 29, 2018, resulting in an effective tax rate of 8%, compared to $73 million of net tax expense during the three months ended September 30, 2017, resulting in an effective tax rate of 26%. The effective tax rate for the three months ended September 29, 2018 of 8% is lower than the effective tax rate for the three months ended September 30, 2017 of 26%, primarily due to the following items: (i) corporate income tax rate decrease from 35% to 21% as a result of the U.S. Tax Cuts and Jobs Act (the “Tax Act”) enacted December 22, 2017; (ii) a tax benefit due to the recognition of excess tax benefits on share-based compensation; and (iii) a tax benefit related to the recording of U.S. federal return-to-provision adjustments. The effective tax rate in the third quarter of 2018 was lower than the U.S. statutory tax rate of 21% primarily driven by a tax benefit due to the recognition of tax benefits on share-based compensation and a tax benefit related to the recording of U.S. federal return-to-provision adjustments. The effective tax rate in the third quarter of 2017 was lower than the U.S. statutory tax rate of 35% primarily driven by a tax benefit due to the recognition of a U.S. capital loss.

[0000068505-18-000029:notes:173]
The Company recorded $91 million of net tax expense during the nine months ended September 29, 2018, resulting in an effective tax rate of 14%, compared to $188 million of net tax expense during the nine months ended September 30, 2017, resulting in an effective tax rate of 31%. The effective tax rate for the nine months ended September 29, 2018 of 14% is lower than the effective tax rate for the nine months ended September 30, 2017 of 31%, primarily due to the following items: (i) corporate income tax rate decrease from 35% to 21% as a result of the Tax Act; (ii) a tax benefit due to the recognition of excess tax benefits on share-based compensation; and (iii) a tax benefit related to the recording of U.S. federal return-to-provision adjustments. The effective tax rate for nine months ended September 29, 2018 was lower than the U.S. statutory tax rate of 21% primarily due to: (i) the recognition of excess tax benefits on share-based compensation, (ii) a tax benefit due to a favorable settlement of a state audit, and (iii) a tax benefit related to the recording of U.S. federal return-to-provision adjustments. The effective tax rate for the nine months ended September 30, 2017 was lower than the U.S. statutory tax rate of 35% primarily due to a tax benefit due to the recognition of a U.S. capital loss.

[0000068505-18-000029:notes:174]
Under the guidance in the U.S. Securities and Exchange Commission's Staff Accounting Bulletin No. 118 ("SAB 118"), the Company recorded provisional amounts for the impact of the Tax Act as of December 31, 2017, representing $874 million of incremental tax expense. Under the transitional provisions of SAB 118, the Company has a one-year measurement period to complete the accounting for the initial tax effects of the Tax Act. The Company is continuing to analyze the impact of the recently issued IRS Notices related to the Tax Act and will record its final adjustments to the provisional amounts during the last three months of 2018. For the nine months ended September 29, 2018, the Company has recorded the following adjustments to the previously recorded provisional tax amounts:


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-18-000029:notes:175]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. In July 2018, the FASB issued ASU 2018-11 that amended the ASU to include an additional (and optional) transition relief. The additional transition relief provides entities the option to adopt the ASU by applying the new ASU at the adoption date and recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption without restatement of comparative periods. The new ASU must be adopted utilizing the modified retrospective method as of the earliest comparative period presented if the optional adoption method is not selected. The Company will adopt the ASU on January 1, 2019, utilizing the modified retrospective method as of the adoption date. The Company is continuing to assess the impact of the ASU on its condensed consolidated financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects a material impact to its condensed consolidated balance sheet through the recording of right-of-use assets and lease obligations that are not required to be recorded within the condensed consolidated balance sheet under current accounting standards.

[0000068505-18-000029:notes:176]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires entities to estimate and recognize current expected credit losses rather than delay recognition of credit losses until the loss is probable of occurring. The ASU is effective for the Company on January 1, 2020, and interim periods within that reporting period with early option permitted. The Company is currently evaluating the impact of the ASU on its consolidated financial statements and disclosures.

[0000068505-18-000029:notes:177]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The guidance related to cash flow and net investment hedges existing at the date of adoption should be applied using the modified retrospective method by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption. The guidance related to presentation and disclosure should be applied prospectively. The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and disclosures.

[0000068505-18-000029:notes:178]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2020 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-18-000029:notes:179]
Recently Adopted Accounting Pronouncements

[0000068505-18-000029:notes:180]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. The Company recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-18-000029:notes:181]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $18 million and $10 million in the three months ended September 29, 2018 and September 30, 2017, respectively, and $58 million and $10 million in the nine months ended September 29, 2018 and September 30, 2017, respectively.

[0000068505-18-000029:notes:182]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-18-000029:notes:183]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-18-000029:notes:184]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-18-000029:notes:185]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

[0000068505-18-000029:notes:186]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

[0000068505-18-000029:notes:187]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000029:notes:188]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-18-000029:notes:189]
[same as prior period, unchanged from 0000068505-18-000023:notes:194]

[0000068505-18-000029:notes:190]
During the second quarter of 2018, the Company modified its internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership, in part, as a result of recent acquisitions contributing to the growth within the newly aligned Services and Software segment. Previously, the Company had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration related revenue and costs moving from the old Services segment into the newly presented Products and Systems Integration segment and Software related revenue and costs moving from the old Products segment into the newly presented Services and Software segment.

[0000068505-18-000029:notes:191]
[same as prior period, unchanged from 0000068505-18-000023:notes:195]

[0000068505-18-000029:notes:192]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

[0000068505-18-000029:notes:193]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-18-000029:notes:194]
[same as prior period, unchanged from 0000068505-18-000023:notes:196]

[0000068505-18-000029:notes:195]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 is as follows:

[0000068505-18-000029:notes:196]
Balance Sheet (Selected captions)

[0000068505-18-000029:notes:197]
| (In millions) | December 31, 2017 |  | Reclassification of Contract Assets |  | Reclassification of Non-customer receivables |  | Reclassification of Contract Liabilities |  | Impact of Adoption on Open Contracts |  | January 1, 2018 |
|  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |
| ASSETS |
| Accounts receivable, net | $ | 1,523 |  |  | $ | (297 | ) |  | $ | (24 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | 1,198 |  |
| Contract assets | — |  |  | 846 |  |  | — |  |  | — |  |  | 85 |  |  | 931 |  |
| Inventories, net | 327 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 328 |  |
| Other current assets | 832 |  |  | (549 | ) |  | 24 |  |  | — |  |  | (23 | ) |  | 284 |  |
| Deferred income taxes | 1,023 |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | 982 |  |
| Other assets | 333 |  |  | — |  |  | — |  |  | — |  |  | 85 |  |  | 418 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Contract liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | (17 | ) |  | $ | 1,082 |  |
| Accrued liabilities | 2,286 |  |  | — |  |  | — |  |  | (1,099 | ) |  | — |  |  | 1,187 |  |
| Other liabilities | 2,585 |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | 2,578 |  |
| Stockholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings | 467 |  |  | — |  |  | — |  |  | — |  |  | 127 |  |  | 594 |  |

[0000068505-18-000029:notes:198]
Adoption Impact to Financial Statements

[0000068505-18-000029:notes:199]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three and nine months ended September 29, 2018 is as follows:

[0000068505-18-000029:notes:200]
Statements of Operations (Selected captions)

[0000068505-18-000029:notes:201]
|  | Three Months Ended |
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,862 |  |  | $ | (19 | ) |  | $ | 1,843 |  |
| Gross margin | 901 |  |  | (18 | ) |  | 883 |  |
| Selling, general and administrative expenses | 323 |  |  | (17 | ) |  | 306 |  |
| Operating earnings | 294 |  |  | (1 | ) |  | 293 |  |
| Net earnings before income taxes | 270 |  |  | (1 | ) |  | 269 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 247 |  |  | $ | (1 | ) |  | $ | 246 |  |

[0000068505-18-000029:notes:202]
|  | Nine Months Ended |
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| Net sales | $ | 5,089 |  |  | $ | (58 | ) |  | $ | 5,031 |  |
| Gross margin | 2,392 |  |  | (57 | ) |  | 2,335 |  |
| Selling, general and administrative expenses | 918 |  |  | (46 | ) |  | 872 |  |
| Operating earnings | 739 |  |  | (11 | ) |  | 728 |  |
| Net earnings before income taxes | 637 |  |  | (11 | ) |  | 626 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 544 |  |  | $ | (11 | ) |  | $ | 533 |  |

[0000068505-18-000029:notes:203]
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| ASSETS |
| Accounts receivable, net | $ | 1,179 |  |  | $ | 315 |  |  | $ | 1,494 |  |
| Contract assets | 917 |  |  | (917 | ) |  | — |  |
| Other current assets | 350 |  |  | 540 |  |  | 890 |  |
| Deferred income taxes | 949 |  |  | 41 |  |  | 990 |  |
| Other assets | 444 |  |  | (95 | ) |  | 349 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |
| Contract liabilities | $ | 1,127 |  |  | $ | (1,127 | ) |  | $ | — |  |
| Accrued liabilities | 1,168 |  |  | 1,139 |  |  | 2,307 |  |
| Other liabilities | 2,175 |  |  | 10 |  |  | 2,185 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 788 |  |  | (138 | ) |  | 650 |  |

[0000068505-18-000029:notes:204]
There is no impact to the condensed consolidated statement of comprehensive income or the statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the condensed consolidated balance sheet and disclosed above.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-18-000029:notes:205]
[same as prior period, unchanged from 0000068505-18-000023:notes:197]

[0000068505-18-000029:notes:206]
[same as prior period, unchanged from 0000068505-18-000023:notes:198]

[0000068505-18-000029:notes:207]
[same as prior period, unchanged from 0000068505-18-000023:notes:199]

[0000068505-18-000029:notes:208]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 47 |  |  | 46 |  |  | 9 |  |  | 10 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (68 | ) |  | (57 | ) |  | (22 | ) |  | (24 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 11 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Settlement loss | — |  |  | — |  |  | — |  |  | 21 |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | (6 | ) |  | $ | — |  |  | $ | (8 | ) |  | $ | 12 |  |  | $ | (5 | ) |  | $ | (4 | ) |

[0000068505-18-000029:notes:209]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 139 |  |  | 138 |  |  | 30 |  |  | 30 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (203 | ) |  | (172 | ) |  | (70 | ) |  | (71 | ) |  | (8 | ) |  | (9 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 43 |  |  | 33 |  |  | 11 |  |  | 12 |  |  | 3 |  |  | 4 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (11 | ) |  | (12 | ) |
| Settlement loss | — |  |  | — |  |  | — |  |  | 46 |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (21 | ) |  | $ | (1 | ) |  | $ | (27 | ) |  | $ | 20 |  |  | $ | (14 | ) |  | $ | (14 | ) |

[0000068505-18-000029:notes:210]
The Company made a $500 million contribution to its U.S. Pension Benefit Plans during the nine months ended September 29, 2018.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-18-000029:notes:211]
[same as prior period, unchanged from 0000068505-18-000023:notes:203]

[0000068505-18-000029:notes:212]
[same as prior period, unchanged from 0000068505-18-000023:notes:204]

[0000068505-18-000029:notes:213]
During the three months ended September 29, 2018, the Company recorded net reorganization of business charges of $25 million including $21 million of charges in Other charges and $4 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $25 million were charges of $13 million related to employee separation costs and $12 million related to exit costs.

[0000068505-18-000029:notes:214]
During the nine months ended September 29, 2018, the Company recorded net reorganization of business charges of $62 million including $46 million of charges in Other charges and $16 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $62 million were charges of $61 million related to employee separation costs and $16 million related to exit costs, partially offset by $15 million of reversals for accruals no longer needed.

[0000068505-18-000029:notes:215]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2018 to September 29, 2018:

[0000068505-18-000029:notes:216]
|  | January 1, 2018 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | September 29, 2018 |
| Exit costs | $ | 9 |  |  | $ | 16 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | 22 |  |
| Employee separation costs | 41 |  |  | 61 |  |  | (15 | ) |  | (48 | ) |  | 39 |  |
|  | $ | 50 |  |  | $ | 77 |  |  | $ | (15 | ) |  | $ | (51 | ) |  | $ | 61 |  |

[0000068505-18-000029:notes:217]
[same as prior period, unchanged from 0000068505-18-000023:notes:209]

[0000068505-18-000029:notes:218]
At January 1, 2018, the Company had $9 million of accruals for exit costs. During the nine months ended September 29, 2018, there were $16 million of additional charges and $3 million of cash payments related to the exit of leased facilities. The remaining accrual of $22 million, which the current portion is included in Accrued liabilities and the non-current portion is included in Other liabilities in the Company’s condensed consolidated balance sheet at September 29, 2018, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-18-000029:notes:219]
[same as prior period, unchanged from 0000068505-18-000023:notes:211]

[0000068505-18-000029:notes:220]
At January 1, 2018, the Company had an accrual of $41 million for employee separation costs. The 2018 additional charges of $61 million represent severance costs for approximately 700 employees. The adjustment of $15 million reflects reversals for accruals no longer needed. The $48 million used reflects cash payments to severed employees. The remaining accrual of $39 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at September 29, 2018, is expected to be paid, primarily within one year, to approximately 500 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-18-000029:notes:221]
[same as prior period, unchanged from 0000068505-18-000023:notes:213]

[0000068505-18-000029:notes:222]
During the three months ended September 30, 2017, the Company recorded net reorganization of business charges of $8 million including $6 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $8 million were charges of $7 million related to employee separation costs and $1 million related to exit costs.

[0000068505-18-000029:notes:223]
During the nine months ended September 30, 2017, the Company recorded net reorganization of business charges of $30 million including $22 million of charges in Other charges and $8 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $30 million were charges of $30 million related to employee separation costs and $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-18-000029:notes:224]
[same as prior period, unchanged from 0000068505-18-000023:notes:216]

[0000068505-18-000029:notes:225]
[same as prior period, unchanged from 0000068505-18-000023:notes:218]

[0000068505-18-000029:notes:226]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government, public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-18-000029:notes:227]
[same as prior period, unchanged from 0000068505-18-000023:notes:220]

[0000068505-18-000029:notes:228]
[same as prior period, unchanged from 0000068505-18-000023:notes:221]

[0000068505-18-000029:notes:229]
Systems also include Avigilon end-to-end security and surveillance solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

[0000068505-18-000029:notes:230]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-18-000029:notes:231]
[same as prior period, unchanged from 0000068505-18-000023:notes:224]

[0000068505-18-000029:notes:232]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-18-000029:notes:233]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis.

[0000068505-18-000029:notes:234]
[same as prior period, unchanged from 0000068505-18-000023:notes:231]

[0000068505-18-000029:notes:235]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of September 29, 2018 is $6.1 billion. A total of $3.3 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.9 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $2.8 billion is from Services and Software performance obligations that are not yet satisfied as of September 29, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-18-000029:notes:236]
[same as prior period, unchanged from 0000068505-18-000023:notes:233]

[0000068505-18-000029:notes:237]
[same as prior period, unchanged from 0000068505-18-000023:notes:234]

[0000068505-18-000029:notes:238]
Revenue recognized during the three months ended September 29, 2018 which was previously included in Contract liabilities as of July 1, 2018 is $327 million. Revenue recognized during the nine months ended September 29, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $777 million. Revenue of $7 million was reversed during the three months ended September 29, 2018 and $4 million of revenue was reversed during the nine months ended September 29, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-18-000029:notes:239]
There have been no material impairment losses recognized on contract assets during the nine months ended September 29, 2018.

[0000068505-18-000029:notes:240]
[same as prior period, unchanged from 0000068505-18-000023:notes:238]

[0000068505-18-000029:notes:241]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $11 million and $34 million for the three and nine months ended September 29, 2018, respectively.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-18-000029:notes:242]
[same as prior period, unchanged from 0000068505-18-000023:notes:240]

[0000068505-18-000029:notes:243]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Products and Systems Integration | $ | 1,288 |  |  | $ | 1,174 |  |  | $ | 3,429 |  |  | $ | 3,076 |  |
| Services and Software | 574 |  |  | 471 |  |  | 1,660 |  |  | 1,347 |  |
|  | $ | 1,862 |  |  | $ | 1,645 |  |  | $ | 5,089 |  |  | $ | 4,423 |  |

[0000068505-18-000029:notes:244]
[same as prior period, unchanged from 0000068505-18-000023:notes:242]

[0000068505-18-000029:notes:245]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Products and Systems Integration | $ | 183 |  |  | $ | 266 |  |  | $ | 449 |  |  | $ | 553 |  |
| Services and Software | 111 |  |  | 81 |  |  | 290 |  |  | 228 |  |
| Operating earnings | 294 |  |  | 347 |  |  | 739 |  |  | 781 |  |
| Total other expense | (24 | ) |  | (61 | ) |  | (102 | ) |  | (171 | ) |
| Earnings before income taxes | $ | 270 |  |  | $ | 286 |  |  | $ | 637 |  |  | $ | 610 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-18-000029:notes:246]
[same as prior period, unchanged from 0000068505-18-000023:notes:244]

[0000068505-18-000029:notes:247]
[same as prior period, unchanged from 0000068505-18-000023:notes:245]

[0000068505-18-000029:notes:248]
[same as prior period, unchanged from 0000068505-18-000023:notes:246]

[0000068505-18-000029:notes:249]
[same as prior period, unchanged from 0000068505-18-000023:notes:247]
