# MSI MD&A — 0000068505-18-000029


## mdna

[0000068505-18-000029:mdna:1]
[same as prior period, unchanged from 0000068505-18-000023:mdna:1]

[0000068505-18-000029:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 29, 2018 and September 30, 2017, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2017.

[0000068505-18-000029:mdna:3]
[same as prior period, unchanged from 0000068505-18-000023:mdna:5]

[0000068505-18-000029:mdna:4]
[same as prior period, unchanged from 0000068505-18-000023:mdna:3]

[0000068505-18-000029:mdna:5]
[same as prior period, unchanged from 0000068505-18-000023:mdna:4]

[0000068505-18-000029:mdna:6]
We have reached an agreement with the UK Home Office on terms for the new direction of the UK Emergency Services Network (“ESN”) as well as an agreement on terms to extend the Airwave contract through 2022.

[0000068505-18-000029:mdna:7]
On March 28, 2018, we completed the acquisition of Avigilon Corporation, a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

[0000068505-18-000029:mdna:8]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-18-000029:mdna:9]
[same as prior period, unchanged from 0000068505-18-000023:mdna:6]

[0000068505-18-000029:mdna:10]
[same as prior period, unchanged from 0000068505-18-000023:mdna:7]

[0000068505-18-000029:mdna:11]
[same as prior period, unchanged from 0000068505-18-000023:mdna:8]

[0000068505-18-000029:mdna:12]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, such as video surveillance cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions and manage a mobile workforce. In the third quarter of 2018, the segment’s net sales were $1.3 billion, representing 69% of our consolidated net sales.

[0000068505-18-000029:mdna:13]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services offerings range from partial to full operation of customer or Motorola Solutions owned networks. Software includes public safety and enterprise command center solutions, unified communications applications, and video software solutions, delivered both on premise and “as a service.” In the third quarter of 2018, the segment’s net sales were $574 million, representing 31% of our consolidated net sales.

[0000068505-18-000029:mdna:14]
Third Quarter Summary

[0000068505-18-000029:mdna:15]
| • | Net sales were $1.9 billion in the third quarter of 2018, up $217 million, or 13%, from the third quarter of 2017. |

[0000068505-18-000029:mdna:16]
| • | We generated operating earnings of $294 million, or 16% of net sales, in the third quarter of 2018, compared to $347 million, or 21% of net sales, in the third quarter of 2017. |

[0000068505-18-000029:mdna:17]
| • | We had net earnings attributable to Motorola Solutions, Inc. of $247 million, or $1.43 per diluted common share, in the third quarter of 2018, compared to $212 million, or $1.25 per diluted common share, in the third quarter of 2017. |

[0000068505-18-000029:mdna:18]
| • | We generated net cash from operating activities of $263 million during the first nine months of 2018, compared to $585 million in the first nine months of 2017. The decrease is primarily driven by the $500 million contribution to our U.S. pension plan, partially offset by improved working capital. |

[0000068505-18-000029:mdna:19]
| • | We returned $318 million in capital to shareholders through dividends and share repurchases during the first nine months of 2018, compared to $588 million during the first nine months of 2017. |

[0000068505-18-000029:mdna:20]
A summary of our segment results for the third quarter of 2018 is as follows:

[0000068505-18-000029:mdna:21]
| • | Products and Systems Integration: Net sales were $1.3 billion, an increase of $114 million, or 10% compared to net sales of $1.2 billion during the third quarter of 2017. On a geographic basis, net sales increased in the Americas and EMEA and decreased in AP, compared to the year-ago quarter. |

[0000068505-18-000029:mdna:22]
| • | Services and Software: Net sales were $574 million, an increase of $103 million, or 22% compared to net sales of $471 million in the third quarter of 2017. On a geographic basis, net sales increased in every region, compared to the year-ago quarter. |

[0000068505-18-000029:mdna:23]
[same as prior period, unchanged from 0000068505-18-000023:mdna:25]

[0000068505-18-000029:mdna:24]
[same as prior period, unchanged from 0000068505-18-000023:mdna:22]

[0000068505-18-000029:mdna:25]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 29, 2018 |  | % ofSales* |  | September 30, 2017 |  | % ofSales* |  | September 29, 2018 |  | % ofSales* |  | September 30, 2017 |  | % ofSales* |
| Net sales from products | $ | 1,151 |  |  |  |  | $ | 989 |  |  |  |  | $ | 2,993 |  |  |  |  | $ | 2,540 |  |  |  |
| Net sales from services | 711 |  |  |  |  | 656 |  |  |  |  | 2,096 |  |  |  |  | 1,883 |  |  |  |
| Net sales | 1,862 |  |  |  |  | 1,645 |  |  |  |  | 5,089 |  |  |  |  | 4,423 |  |  |  |
| Costs of products sales | 516 |  |  | 44.8 | % |  | 428 |  |  | 43.3 | % |  | 1,383 |  |  | 46.2 | % |  | 1,167 |  |  | 45.9 | % |
| Costs of services sales | 445 |  |  | 62.6 | % |  | 423 |  |  | 64.5 | % |  | 1,314 |  |  | 62.7 | % |  | 1,202 |  |  | 63.8 | % |
| Costs of sales | 961 |  |  |  |  | 851 |  |  |  |  | 2,697 |  |  |  |  | 2,369 |  |  |  |
| Gross margin | 901 |  |  | 48.4 | % |  | 794 |  |  | 48.3 | % |  | 2,392 |  |  | 47.0 | % |  | 2,054 |  |  | 46.4 | % |
| Selling, general and administrative expenses | 323 |  |  | 17.3 | % |  | 259 |  |  | 15.7 | % |  | 918 |  |  | 18.0 | % |  | 760 |  |  | 17.2 | % |
| Research and development expenditures | 158 |  |  | 8.5 | % |  | 141 |  |  | 8.6 | % |  | 472 |  |  | 9.3 | % |  | 413 |  |  | 9.3 | % |
| Other charges | 126 |  |  | 6.8 | % |  | 47 |  |  | 2.9 | % |  | 263 |  |  | 5.2 | % |  | 100 |  |  | 2.3 | % |
| Operating earnings | 294 |  |  | 15.8 | % |  | 347 |  |  | 21.1 | % |  | 739 |  |  | 14.5 | % |  | 781 |  |  | 17.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (59 | ) |  | (3.2 | )% |  | (52 | ) |  | (3.2 | )% |  | (163 | ) |  | (3.2 | )% |  | (154 | ) |  | (3.5 | )% |
| Gains on sales of investments and businesses, net | 6 |  |  | 0.3 | % |  | — |  |  | — | % |  | 16 |  |  | 0.3 | % |  | 3 |  |  | 0.1 | % |
| Other | 29 |  |  | 1.6 | % |  | (9 | ) |  | (0.5 | )% |  | 45 |  |  | 0.9 | % |  | (20 | ) |  | (0.5 | )% |
| Total other expense | (24 | ) |  | (1.3 | )% |  | (61 | ) |  | (3.7 | )% |  | (102 | ) |  | (2.0 | )% |  | (171 | ) |  | (3.9 | )% |
| Earnings before income taxes | 270 |  |  | 14.5 | % |  | 286 |  |  | 17.4 | % |  | 637 |  |  | 12.5 | % |  | 610 |  |  | 13.8 | % |
| Income tax expense | 22 |  |  | 1.2 | % |  | 73 |  |  | 4.4 | % |  | 91 |  |  | 1.8 | % |  | 188 |  |  | 4.3 | % |
| Net earnings | 248 |  |  | 13.3 | % |  | 213 |  |  | 12.9 | % |  | 546 |  |  | 10.7 | % |  | 422 |  |  | 9.5 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 2 |  |  | — | % |  | 2 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 247 |  |  | 13.3 | % |  | $ | 212 |  |  | 12.9 | % |  | $ | 544 |  |  | 10.7 | % |  | $ | 420 |  |  | 9.5 | % |
| Earnings per diluted common share | $ | 1.43 |  |  |  |  |  | $ | 1.25 |  |  |  |  |  | $ | 3.17 |  |  |  |  | $ | 2.48 |  |  |  |

[0000068505-18-000029:mdna:26]
[same as prior period, unchanged from 0000068505-18-000023:mdna:24]

[0000068505-18-000029:mdna:27]
33

[0000068505-18-000029:mdna:28]
Results of Operations—Three months ended September 29, 2018 compared to three months ended September 30, 2017

[0000068505-18-000029:mdna:29]
The results of operations for the third quarter of 2018 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-18-000029:mdna:30]
[same as prior period, unchanged from 0000068505-18-000023:mdna:28]

[0000068505-18-000029:mdna:31]
Net sales were $1.9 billion in the third quarter of 2018, a $217 million, or 13%, increase compared to the third quarter of 2017. The net sales increase for the third quarter of 2018 included $145 million from acquisitions and $19 million from the adoption of ASC 606 (see Note 1 of our Condensed Consolidated Financial Statements), partially offset by $9 million from unfavorable foreign currency rates. The Products and Systems Integration segment grew 10% driven by the Americas and EMEA. The Services and Software segment grew 22% with growth in all regions.

[0000068505-18-000029:mdna:32]
The increase in net sales is reflective of growth in the Americas and EMEA. Devices net sales within the Products and Systems Integration segment increased in the Americas and EMEA and decreased in AP. Systems and Systems Integration net sales within the Products and Systems Integration segment increased in every region. The Services and Software segment net sales increased in every region. The Services and Software segment net sales increase in the Americas was driven by acquisitions within the Software business and growth absent of acquisitions in both Services and Software. The Services and Software segment net sales increase in EMEA was primarily driven by growth absent of acquisitions in Services. The Services and Software segment net sales increase in AP was driven by growth absent of acquisitions in both Services and Software.

[0000068505-18-000029:mdna:33]
[same as prior period, unchanged from 0000068505-18-000023:mdna:30]

[0000068505-18-000029:mdna:34]
Gross margin was $901 million, or 48.4% of net sales, in the third quarter of 2018, compared to $794 million, or 48.3% of net sales, in the third quarter of 2017. The increase in gross margin was primarily driven by the adoption of ASC 606 and a favorable mix within the Services and Software segment, partially offset by lower margins in the Products and Systems Integration segment due to acquisitions and lower margins on a few large projects.

[0000068505-18-000029:mdna:35]
[same as prior period, unchanged from 0000068505-18-000023:mdna:32]

[0000068505-18-000029:mdna:36]
SG&A expenses were $323 million, or 17.3% of net sales, in the third quarter of 2018, compared to $259 million, or 15.7% of net sales, in the third quarter of 2017. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses and the change in classification of our third-party sales commissions from the adoption of ASC 606.

[0000068505-18-000029:mdna:37]
[same as prior period, unchanged from 0000068505-18-000023:mdna:34]

[0000068505-18-000029:mdna:38]
R&D expenditures were $158 million, or 8.5% of net sales, in the third quarter of 2018 and $141 million, or 8.6% of net sales, in the third quarter of 2017. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-18-000029:mdna:39]
[same as prior period, unchanged from 0000068505-18-000023:mdna:36]

[0000068505-18-000029:mdna:40]
We recorded net charges of $126 million in the third quarter of 2018, compared to net charges of $47 million in the third quarter of 2017. The net Other charges in the third quarter of 2018 were primarily driven by: (i) a $57 million charge related to ongoing remediation efforts of environmental media for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act incurred by a legacy business (See Note 3 of our Condensed Consolidated Financial Statements), (ii) $46 million of charges relating to the amortization of intangibles, and (iii) $21 million of net reorganization of business charges. The net charges in the third quarter of 2017 of $47 million were primarily from $39 million of charges relating to the amortization of intangibles and $6 million of net reorganization of business charges. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-18-000029:mdna:41]
[same as prior period, unchanged from 0000068505-18-000023:mdna:38]

[0000068505-18-000029:mdna:42]
Net interest expense was $59 million in the third quarter of 2018 and $52 million in the third quarter of 2017. The increase in net interest expense in the third quarter of 2018 as compared to the third quarter of 2017 was a result of increases in outstanding debt issued during 2018.

[0000068505-18-000029:mdna:43]
Gains on Sales of Investments and Businesses, net

[0000068505-18-000029:mdna:44]
Net gains on sales of investments and businesses were $6 million in the third quarter of 2018. The net gains were related to the sales of various equity investments.

[0000068505-18-000029:mdna:45]
[same as prior period, unchanged from 0000068505-18-000023:mdna:40]

[0000068505-18-000029:mdna:46]
Net Other income was $29 million in the third quarter of 2018, compared to an expense of $9 million in the third quarter of 2017. The net other income in the third quarter of 2018 was primarily comprised of: (i) $18 million of net periodic pension and postretirement benefit, (ii) an $8 million gain on derivative instruments, (iii) $7 million gain on fair value adjustments to investments, and iv) a $6 million gain from the extinguishment of convertible debt, partially offset by a $14 million foreign currency loss. The net Other expense in the third quarter of 2017 was primarily comprised of: (i) $21 million of charges relating to the Non-U.S. pension settlement loss and (ii) a $7 million foreign currency loss, partially offset by: (i) $11 million of net periodic pension and postretirement benefit, (ii) $4 million of other non-operating gains and (iii) a $3 million gain on derivative instruments.

[0000068505-18-000029:mdna:47]
[same as prior period, unchanged from 0000068505-18-000023:mdna:42]

[0000068505-18-000029:mdna:48]
We recorded $22 million of net tax expense in the third quarter of 2018, resulting in an effective tax rate of 8%, compared to $73 million of net tax expense in the third quarter of 2017, resulting in an effective tax rate of 26%. Our effective tax rate for the three months ended September 29, 2018 of 8% is lower than our effective tax rate for the three months ended September 30, 2017 of 26%, primarily due to the following items: (i) corporate income tax rate decrease from 35% to 21% as a result of the U.S. Tax Cuts and Jobs Act (the “Tax Act”) enacted December 22, 2017; (ii) a tax benefit due to the recognition of excess tax benefits on share-based compensation; and (iii) a tax benefit related to the recording of U.S. federal return-to-provision adjustments. Our effective tax rate in the third quarter of 2018 was lower than the U.S. statutory tax rate of 21% primarily driven by a tax benefit due to the recognition of tax benefits on share-based compensation and a tax benefit related to the recording of U.S. federal return-to-provision adjustments. Our effective tax rate in the third quarter of 2017 was lower than the U.S. statutory tax rate of 35% primarily driven by a tax benefit due to the recognition of a U.S. capital loss.

[0000068505-18-000029:mdna:49]
Results of Operations—Nine months ended September 29, 2018 compared to nine months ended September 30, 2017

[0000068505-18-000029:mdna:50]
[same as prior period, unchanged from 0000068505-18-000023:mdna:48]

[0000068505-18-000029:mdna:51]
Net sales were $5.1 billion in the first nine months of 2018, a $666 million, or 15%, increase compared to the first nine months of 2017. The net sales increase for the first nine months of 2018 included $347 million from acquisitions, $58 million from the adoption of ASC 606 (see Note 1 of our Condensed Consolidated Financial Statements), and $56 million from favorable foreign currency rates. The Products and Systems Integration segment grew 11% driven by the Americas and EMEA. The Services and Software segment grew 23% with growth in all regions.

[0000068505-18-000029:mdna:52]
The increase in net sales is reflective of growth in every region. Within the Products and Systems Integration segment, Devices net sales increased in the Americas and EMEA and decreased in AP and Systems and Systems Integration net sales increased in every region. The Services and Software segment increased in every region. The Services and Software segment net sales increase in the Americas was driven by acquisitions within the Software business, the acquisition of Interexport in Services and growth absent of acquisitions in both Services and Software. The Services and Software segment net sales increase in EMEA was primarily driven by growth absent of acquisitions in Services. The Services and Software segment net sales increase in AP was driven by the acquisition of Kodiak Networks in the Software business and growth absent of acquisitions in both Services and the Software businesses.

[0000068505-18-000029:mdna:53]
[same as prior period, unchanged from 0000068505-18-000023:mdna:50]

[0000068505-18-000029:mdna:54]
Gross margin was $2.4 billion, or 47.0% of net sales, in the first nine months of 2018, compared to $2.1 billion, or 46.4% of net sales, in the first nine months of 2017. The increase in gross margin percentage was primarily driven by the adoption of ASC 606 and improved margins in the Services and Software segment, partially offset by lower margins in the Products and Systems Integration segment due to acquisitions and lower margins on a few large projects.

[0000068505-18-000029:mdna:55]
[same as prior period, unchanged from 0000068505-18-000023:mdna:52]

[0000068505-18-000029:mdna:56]
SG&A expenses were $918 million, or 18.0% of net sales, in the first nine months of 2018, compared to $760 million, or 17.2% of net sales, in the first nine months of 2017. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses and the change in classification of our third-party sales commissions from the adoption of ASC 606.

[0000068505-18-000029:mdna:57]
[same as prior period, unchanged from 0000068505-18-000023:mdna:54]

[0000068505-18-000029:mdna:58]
R&D expenditures were $472 million, or 9.3% of net sales, in the first nine months of 2018 and $413 million, or 9.3% of net sales, in the first nine months of 2017. R&D expenditures increased due to increased expenses associated with acquired businesses.

[0000068505-18-000029:mdna:59]
[same as prior period, unchanged from 0000068505-18-000023:mdna:56]

[0000068505-18-000029:mdna:60]
We recorded net charges of $263 million in the first nine months of 2018, compared to net charges of $100 million in the first nine months of 2017. The net Other charges in the first nine months of 2018 were primarily driven by: (i) $140 million of charges relating to the amortization of intangibles, (ii) a $57 million charge related to ongoing remediation efforts of environmental media for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act incurred by a legacy business  (See Note 3 of our Condensed Consolidated Financial Statements), (iii) $46 million of net reorganization of business charges, and (iv) $17 million of acquisition related transaction fees. The net charges in the first nine months of 2017 of $100 million primarily consisted of: (i) $111 million of charges relating to the amortization of intangibles, (ii) $22 million of net reorganization of business charges and (iii) $8 million of charges related to a building impairment, partially offset by a net gain of $42 million, related to the recovery of receivables owed to the Company by a former customer. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-18-000029:mdna:61]
[same as prior period, unchanged from 0000068505-18-000023:mdna:58]

[0000068505-18-000029:mdna:62]
Net interest expense was $163 million in the first nine months of 2018 and $154 million in the first nine months of 2017. The increase in net interest expense in the first nine months of 2018 as compared to the first nine months of 2017 was a result of increases in outstanding debt.

[0000068505-18-000029:mdna:63]
Gains on Sales of Investments and Businesses, net

[0000068505-18-000029:mdna:64]
Net gains on sales of investments and businesses were $16 million in the first nine months of 2018 compared to $3 million in the first nine months of 2017. The net gains in the first nine months of 2018 and 2017 were primarily related to the sales of various equity investments.

[0000068505-18-000029:mdna:65]
[same as prior period, unchanged from 0000068505-18-000023:mdna:62]

[0000068505-18-000029:mdna:66]
Net Other income was $45 million in the first nine months of 2018, compared to expense of $20 million in the first nine months of 2017. The net Other income in the first nine months of 2018 was primarily comprised of: (i) $58 million net periodic postretirement benefit, (ii) $7 million gain on fair value adjustments to investments, and (iii) a $6 million gain from the extinguishment of convertible debt, partially offset by: (i) $15 million loss on derivative investments, including losses of $14 million associated with foreign currency derivative contracts related to the acquisition of Avigilon and (ii) $14 million of foreign currency losses. The net Other expense in the first nine months of 2017 was comprised of $46 million of charges relating to the Non-U.S. pension settlement loss and a $29 million foreign currency loss, partially offset by: (i) $36 million of net periodic postretirement benefit, (ii) a $14 million gain on derivative instruments, and (iii) $4 million of other non-operating gains.

[0000068505-18-000029:mdna:67]
[same as prior period, unchanged from 0000068505-18-000023:mdna:65]

[0000068505-18-000029:mdna:68]
We recorded $91 million of net tax expense in the first nine months of 2018, resulting in an effective tax rate of 14%, compared to $188 million of net tax expense in the first nine months of 2017, resulting in an effective tax rate of 31%. Our effective tax rate for the nine months ended September 29, 2018 of 14% is lower than our effective tax rate for the nine months ended September 30, 2017 of 31%, primarily due to the following items: (i) corporate income tax rate decrease from 35% to 21% as a result of the Tax Act; (ii) a tax benefit due to the recognition of excess tax benefits on share-based compensation; and (iii) a tax benefit related to the recording of U.S. federal return-to-provision adjustments. Our effective tax rate in the first nine months of 2018 was lower than the U.S. statutory tax rate of 21% primarily due to: (i) the recognition of excess tax benefits on share-based compensation, (ii) a tax benefit due to a favorable settlement of a state audit, and (iii) a tax benefit related to the recording of U.S. federal return-to-provision adjustments. Our effective tax rate in the first nine months of 2017 was lower than the U.S. statutory tax rate of 35% primarily due to a tax benefit due to the recognition of a U.S. capital loss.

[0000068505-18-000029:mdna:69]
[same as prior period, unchanged from 0000068505-18-000023:mdna:70]

[0000068505-18-000029:mdna:70]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and nine months ended September 29, 2018 and September 30, 2017, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-18-000029:mdna:71]
[same as prior period, unchanged from 0000068505-18-000023:mdna:72]

[0000068505-18-000029:mdna:72]
For the third quarter of 2018, the segment’s net sales represented 69% of our consolidated net sales, compared to 71% of our consolidated net sales for the third quarter of 2017. For the first nine months of 2018, the segment's net sales represented 67% of our consolidated net sales, compared to 70% of our consolidated net sales for the first nine months of 2017.

[0000068505-18-000029:mdna:73]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Segment net sales | $ | 1,288 |  |  | $ | 1,174 |  |  | 10 | % |  | $ | 3,429 |  |  | $ | 3,076 |  |  | 11 | % |
| Operating earnings | 183 |  |  | 266 |  |  | (31 | )% |  | 449 |  |  | 553 |  |  | (19 | )% |

[0000068505-18-000029:mdna:74]
Three months ended September 29, 2018 compared to three months ended September 30, 2017

[0000068505-18-000029:mdna:75]
The segment’s net sales increased $114 million, to $1.3 billion in the third quarter of 2018, as compared to $1.2 billion during the third quarter of 2017. The increase in the segment's net sales was driven by an increase in Devices and Systems and Systems Integration sales. Devices net sales increased in the Americas and EMEA due to the acquisition of Avigilon and growth absent of acquisitions and decreased in AP. Systems and Systems Integration net sales increased in the Americas and EMEA due to the acquisition of Avigilon. Systems and Systems Integration net sales increased in AP due to the acquisition of Avigilon and growth absent of acquisitions.

[0000068505-18-000029:mdna:76]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in the third quarter of 2018, compared to 73% of the segment's net sales in the third quarter of 2017.

[0000068505-18-000029:mdna:77]
The segment had operating earnings of $183 million in the third quarter of 2018, compared to $266 million in the third quarter of 2017. The decrease in operating earnings in the third quarter of 2018 compared to the third quarter of 2017 was driven

[0000068505-18-000029:mdna:78]
by higher Other charges, SG&A expenses, and R&D expenditures driven by an environmental reserve charge, increased expenses associated with acquired businesses including the amortization of intangibles, and increased in reorganization of business charges, partially offset by higher net sales.

[0000068505-18-000029:mdna:79]
Nine months ended September 29, 2018 compared to nine months ended September 30, 2017

[0000068505-18-000029:mdna:80]
The segment’s net sales increased $353 million, to $3.4 billion in the first nine months of 2018, as compared to $3.1 billion during the first nine months of 2017. The increase in the segment's net sales was driven by an increase in Devices and Systems and Systems Integration sales. Devices net sales increased in the Americas and EMEA due to the acquisition of Avigilon and growth absent of acquisitions and decreased in AP. Systems and Systems Integration net sales increased in the Americas and EMEA due to the acquisition of Avigilon. Systems and Systems Integration net sales increased in AP due to the acquisition of Avigilon and growth absent of acquisitions.

[0000068505-18-000029:mdna:81]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in the first nine months of 2018, compared to 73% of the segment's net sales in the first nine months of 2017.

[0000068505-18-000029:mdna:82]
The segment had operating earnings of $449 million in the first nine months of 2018, compared to $553 million in the first nine months of 2017. The decrease in operating earnings in the first nine months of 2018 compared to the first nine months of 2017 was driven by higher SG&A expenses, Other charges, and R&D expenditures driven by increased expenses associated with acquired businesses including the amortization of intangibles, an environmental reserve charge, increased reorganization of business charges, and an impact from the adoption of ASC 606, partially offset by higher net sales.

[0000068505-18-000029:mdna:83]
[same as prior period, unchanged from 0000068505-18-000023:mdna:83]

[0000068505-18-000029:mdna:84]
For third quarter of 2018, the segment’s net sales represented 31% of our consolidated net sales, compared to 29% of our consolidated net sales for the third quarter of 2017. For the first nine months of 2018, the segment's net sales represented 33% of our consolidated net sales, compared to 30% of our consolidated net sales for the first nine months of 2017.

[0000068505-18-000029:mdna:85]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Segment net sales | $ | 574 |  |  | $ | 471 |  |  | 22 | % |  | $ | 1,660 |  |  | $ | 1,347 |  |  | 23 | % |
| Operating earnings | 111 |  |  | 81 |  |  | 37 | % |  | 290 |  |  | 228 |  |  | 27 | % |

[0000068505-18-000029:mdna:86]
Three months ended September 29, 2018 compared to three months ended September 30, 2017

[0000068505-18-000029:mdna:87]
The segment’s net sales increased $103 million, or 22%, to $574 million in the third quarter of 2018, as compared to $471 million in the third quarter of 2017. The increase in the segment's net sales was driven by acquisitions within the Software business, as well as growth absent of acquisitions in both Services and Software. On a geographic basis, net sales for the third quarter of 2018 increased in every region, compared to the third quarter of 2017.

[0000068505-18-000029:mdna:88]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 60% of the segment’s net sales in the third quarter of 2018, compared to 56% of the segment’s net sales in the third quarter of 2017.

[0000068505-18-000029:mdna:89]
The segment had operating earnings of $111 million in the third quarter of 2018, compared to $81 million in the third quarter of 2017. The increase in operating earnings in the third quarter of 2018 compared to the third quarter of 2017 was driven by higher sales, partially offset by higher Other charges, SG&A expenses, and R&D expenditures driven by an environmental reserve charge, increased expenses associated with acquired businesses, and increased reorganization of business charges.

[0000068505-18-000029:mdna:90]
Nine months ended September 29, 2018 compared to nine months ended September 30, 2017

[0000068505-18-000029:mdna:91]
The segment’s net sales increased $313 million, or 23%, to $1.7 billion in the first nine months of 2018, as compared to $1.3 billion in the first nine months of 2017. The increase in the segment's net sales was driven by acquisitions within the Software business and the Interexport acquisition within Services, as well as growth absent of acquisitions in both Services and Software. On a geographic basis, net sales for the first nine months of 2018 increased in every region, compared to the first nine months of 2017.

[0000068505-18-000029:mdna:92]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the first nine months of 2018, compared to 55% of the segment’s net sales in the first nine months of 2017.

[0000068505-18-000029:mdna:93]
The segment had operating earnings of $290 million in the first nine months of 2018, compared to $228 million in the first nine months of 2017. The increase in operating earnings in the first nine months of 2018 compared to the first nine months of 2017 was driven by higher sales, partially offset by higher Other charges, R&D expenditures, and SG&A expenses driven by increased expenses associated with acquired businesses including the amortization of intangibles, an environmental reserve charge, increased reorganization of business charges, and an impact from the adoption of ASC 606.

[0000068505-18-000029:mdna:94]
[same as prior period, unchanged from 0000068505-18-000023:mdna:113]

[0000068505-18-000029:mdna:95]
[same as prior period, unchanged from 0000068505-18-000023:mdna:94]

[0000068505-18-000029:mdna:96]
During the third quarter of 2018, we recorded net reorganization of business charges of $25 million including $21 million of charges recorded within Other charges and $4 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $25 million were charges of $13 million related to employee separation costs and $12 million related to exit costs.

[0000068505-18-000029:mdna:97]
During the first nine months of 2018, we recorded net reorganization of business charges of $62 million including $46 million of charges recorded within Other charges and $16 million in Cost of sales in our condensed consolidated statements of operations. Included in the $62 million were charges of $61 million related to employee separation costs and $16 million related to exit costs, partially offset by $15 million of reversals for accruals no longer needed.

[0000068505-18-000029:mdna:98]
During the third quarter of 2017, we recorded net reorganization of business charges of $8 million including $6 million of charges recorded within Other charges and $2 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $8 million were charges of $7 million related to employee separation costs and $1 million related to exit costs.

[0000068505-18-000029:mdna:99]
During the first nine months of 2017, we recorded net reorganization of business charges of $30 million including $22 million of charges recorded within Other charges and $8 million in Cost of sales in our condensed consolidated statements of operations. Included in the $30 million were charges of $30 million related to employee separation costs and $5 million related to exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-18-000029:mdna:100]
[same as prior period, unchanged from 0000068505-18-000023:mdna:99]

[0000068505-18-000029:mdna:101]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Products and Systems Integration | $ | 19 |  |  | $ | 6 |  |  | $ | 47 |  |  | $ | 22 |  |
| Services and Software | 6 |  |  | 2 |  |  | 15 |  |  | 8 |  |
|  | $ | 25 |  |  | $ | 8 |  |  | $ | 62 |  |  | $ | 30 |  |

[0000068505-18-000029:mdna:102]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $51 million in the first nine months of 2018 and $77 million in the first nine months of 2017. The reorganization of business accruals at September 29, 2018 were $61 million, of which $39 million relate to employee separation costs that are expected to be paid within one year and $22 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-18-000029:mdna:103]
[same as prior period, unchanged from 0000068505-18-000023:mdna:102]

[0000068505-18-000029:mdna:104]
|  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 263 |  |  | $ | 585 |  |
| Investing activities | (1,196 | ) |  | (415 | ) |
| Financing activities | 534 |  |  | (537 | ) |
| Effect of exchange rates on cash and cash equivalents | (18 | ) |  | 54 |  |
| Decrease in cash and cash equivalents | $ | (417 | ) |  | $ | (313 | ) |

[0000068505-18-000029:mdna:105]
[same as prior period, unchanged from 0000068505-18-000023:mdna:104]

[0000068505-18-000029:mdna:106]
At September 29, 2018, $290 million of the $851 million cash and cash equivalents balance was held in the U.S. and $561 million was held by us or our subsidiaries in other countries, with approximately $200 million held in the United Kingdom. Restricted cash was $12 million at September 29, 2018 and $63 million at December 31, 2017. During the three months ended September 29, 2018, restricted cash decreased from $63 million to $12 million due to the completion of a settlement related to our legacy Networks business.

[0000068505-18-000029:mdna:107]
[same as prior period, unchanged from 0000068505-18-000023:mdna:106]

[0000068505-18-000029:mdna:108]
Net cash provided by operating activities in the first nine months of 2018 decreased $322 million, compared to the first nine months of 2017. Operating cash flows in the first nine months of 2018, as compared to the first nine months of 2017, were negatively impacted by a $500 million contribution to our U.S. pension plan in February 2018, a settlement payment related to our legacy Networks business, higher incentive payments, and the recovery of financial receivables owed to us by a former customer in the first quarter of 2017, partially offset by improved working capital. The contribution to our U.S. pension plan moves the next anticipated required contribution to 2024, or beyond.

[0000068505-18-000029:mdna:109]
[same as prior period, unchanged from 0000068505-18-000023:mdna:108]

[0000068505-18-000029:mdna:110]
Net cash used by investing activities increased $781 million in the first nine months of 2018, compared to the first nine months of 2017. The $1.2 billion of cash used in the first nine months of 2018 included $1.2 billion used for acquisitions and investments and $128 million in capital expenditures, partially offset by $90 million of proceeds from sales of investments and businesses. The cash usage of $415 million in the first nine months of 2017 consisted primarily of $383 million cash used for acquisitions and investments and $206 million in capital expenditures, partially offset by $174 million of proceeds from the sale of investments and businesses.

[0000068505-18-000029:mdna:111]
Acquisition and Investments:  We used net cash for acquisitions and investments of $1.2 billion during the first nine months of 2018 compared to $383 million in the first nine months of 2017. The cash used during the first nine months of 2018 was primarily used for the acquisitions of Avigilon for a total of $903 million, net of cash acquired, and Plant for total of $237 million, net of cash acquired. The cash used during the first nine months of 2017 was used for investment in short-term government securities, and the acquisitions of Kodiak Networks for $205 million and Interexport for $55 million, net of cash acquired.

[0000068505-18-000029:mdna:112]
Sales of Investments and Businesses:  We received $90 million of proceeds related to the sales of investments and businesses in the first nine months of 2018 compared to $174 million in the first nine months of 2017. The proceeds in the first nine months of 2018 primarily consisted of $60 million of excess cash withdrawn from company-sponsored life insurance investments and the sales of various equity investments. The proceeds from the first quarter of 2017 primarily consisted of the sales of short-term government securities.

[0000068505-18-000029:mdna:113]
Capital Expenditures:  Capital expenditures decreased in the first nine months of 2018 to $128 million, compared to $206 million in the first nine months of 2017. The decrease in capital expenditures was primarily related to lower information technology and facilities spend.

[0000068505-18-000029:mdna:114]
[same as prior period, unchanged from 0000068505-18-000023:mdna:114]

[0000068505-18-000029:mdna:115]
Net cash provided by financing activities increased $1.1 billion in the first nine months of 2018, compared to the first nine months of 2017. Cash provided by financing activities in the first nine months of 2018 was primarily comprised of $1.3 billion of proceeds from the issuance of debt and $139 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, partially offset by: (i) $412 million used for the repayment of debt, (ii) $252 million of cash used for the payment of dividends, (iii) $169 million used to pay the conversion premium on the repurchase of convertible debt, and (iv) $66 million used for purchases under our share repurchase program. Net cash used for financing activities in the first nine months of 2017 was primarily comprised of: (i) $358 million used for purchases under our share repurchase program, (ii) $230 million of cash used for the payment of dividends, and (iii) $15 million used for the repayment of debt, partially offset by $61 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-18-000029:mdna:116]
Current and Long-Term Debt:  We had outstanding long-term debt of $5.4 billion and $4.5 billion, including the current portions of $337 million and $52 million at September 29, 2018 and December 31, 2017, respectively.

[0000068505-18-000029:mdna:117]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three and nine months ended September 29, 2018 were 3.33% and 3.43%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-18-000029:mdna:118]
In February of 2018, we issued $500 million of 4.60% Senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan in the first quarter of 2018.

[0000068505-18-000029:mdna:119]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.8252, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.45 per share). The exercise price adjusts automatically for dividends. On September 5, 2018, we agreed with Silver Lake Partners to repurchase $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. As of September 29, 2018, we paid $169 million of cash to Silver Lake Partners and recorded a gain of $6 million from the extinguishment of the convertible debt. The principal amount of $200 million was reclassified to short term debt. In the event of an additional conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-18-000029:mdna:120]
On September 28, 2018, we issued an additional $200 million on the outstanding 4.60% Senior notes due 2028 bringing the outstanding total to $700 million. We settled the issuance on October 5, 2018 and recognized net proceeds of $196 million, subsequent to quarter end, which was then used to pay the $200 million principal due to Silver Lake Partners on October 15, 2018.

[0000068505-18-000029:mdna:121]
We continue to believe that we hold sufficient liquidity to cover the day-to-day operations of our business as well as any future volatility or uncertainty that may arise in the capital markets.

[0000068505-18-000029:mdna:122]
Share Repurchase Program: During the nine months ended September 29, 2018, we paid an aggregate of $66 million, including transaction costs, to repurchase approximately 0.6 million shares at an average price of $101.54 per share. As of September 29, 2018, we had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-18-000029:mdna:123]
Payment of Dividends: During the third quarter of 2018, we paid $84 million in cash dividends to holders of our common stock. During the first nine months of 2018, we paid $252 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $85 million in cash dividends to holders of our common stock.

[0000068505-18-000029:mdna:124]
Deferred Acquisition Consideration: We currently have an $84 million deferred consideration related to the Airwave acquisition within Accrued liabilities. This will be paid on November 15, 2018.

[0000068505-18-000029:mdna:125]
[same as prior period, unchanged from 0000068505-18-000023:mdna:125]

[0000068505-18-000029:mdna:126]
As of September 29, 2018, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, we borrowed $400 million under the facility to complete the Avigilon acquisition. As of September 29, 2018, the outstanding loan amount under the facility was $100 million, with $200 million paid during the third quarter. Subsequent to the quarter, we paid the remaining $100 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The weighted average borrowing rate on outstanding amounts for the three and nine months ended September 29, 2018 was 3.58%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 29, 2018.

[0000068505-18-000029:mdna:127]
[same as prior period, unchanged from 0000068505-18-000023:mdna:127]

[0000068505-18-000029:mdna:128]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $86 million at September 29, 2018, compared to $93 million at December 31, 2017.

[0000068505-18-000029:mdna:129]
[same as prior period, unchanged from 0000068505-18-000023:mdna:130]

[0000068505-18-000029:mdna:130]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 29, 2018 and September 30, 2017:

[0000068505-18-000029:mdna:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Accounts receivable sales proceeds | $ | — |  |  | $ | 99 |  |  | $ | 76 |  |  | $ | 179 |  |
| Long-term receivables sales proceeds | 73 |  |  | 55 |  |  | 101 |  |  | 123 |  |
| Total proceeds from sales of accounts receivable | $ | 73 |  |  | $ | 154 |  |  | $ | 177 |  |  | $ | 302 |  |

[0000068505-18-000029:mdna:132]
At September 29, 2018, the Company had retained servicing obligations for $879 million of long-term receivables, compared to $873 million at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000029:mdna:133]
Other Contingencies

[0000068505-18-000029:mdna:134]
There were no significant changes impacting our commitments and contingencies during the three months ended September 29, 2018.

[0000068505-18-000029:mdna:135]
[same as prior period, unchanged from 0000068505-18-000023:mdna:139]

[0000068505-18-000029:mdna:136]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. In July 2018 the FASB issued ASU 2018-11 that amended the ASU to include an additional (and optional) transition relief. The additional transition relief provides entities the option to adopt the ASU by applying the new ASU at the adoption date and recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption without restatement of comparative periods. The new ASU must be adopted utilizing the modified retrospective method as of the earliest comparative period presented if the optional adoption method is not selected. We will adopt the ASU on January 1, 2019, utilizing the modified retrospective method as of the adoption date. We are continuing to assess the impact of the ASU on our financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, we expect a material impact to our balance sheet through the recording of right-of-use assets and lease obligations that are not required to be recorded within the balance sheet under current accounting standards.

[0000068505-18-000029:mdna:137]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires entities to estimate and recognize current expected credit losses rather than delay recognition of credit losses until the loss is probable of occurring. The ASU is effective for us on January 1, 2020, and interim periods within that reporting period with early option permitted. We are currently evaluating the impact of the ASU on our consolidated financial statements and disclosures.

[0000068505-18-000029:mdna:138]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for us on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The guidance related to cash flow and net investment hedges existing at the date of adoption should be applied using the modified retrospective method by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption. The guidance related to presentation and disclosure should be applied prospectively. We are currently assessing the impact of this ASU, including transition elections and required elections, on our consolidated financial statements and disclosures.

[0000068505-18-000029:mdna:139]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2020 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-18-000029:mdna:140]
Recently Adopted Accounting Pronouncements

[0000068505-18-000029:mdna:141]
We adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. We recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to our opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, we will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-18-000029:mdna:142]
We adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. We have restated our comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of our net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. We reclassified $18 million and $10 million in the three months ended September 29, 2018 and September 30, 2017, respectively, and $58 million and $10 million in the nine months ended September 29, 2018 and September 30, 2017, respectively.

[0000068505-18-000029:mdna:143]
We adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to our opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-18-000029:mdna:144]
[same as prior period, unchanged from 0000068505-18-000023:mdna:146]

[0000068505-18-000029:mdna:145]
[same as prior period, unchanged from 0000068505-18-000023:mdna:147]

[0000068505-18-000029:mdna:146]
[same as prior period, unchanged from 0000068505-18-000023:mdna:148]

[0000068505-18-000029:mdna:147]
[same as prior period, unchanged from 0000068505-18-000023:mdna:149]

[0000068505-18-000029:mdna:148]
Under prior accounting standards, we expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, we capitalize sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000029:mdna:149]
[same as prior period, unchanged from 0000068505-18-000023:mdna:151]

[0000068505-18-000029:mdna:150]
42
