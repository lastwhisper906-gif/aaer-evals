# MSI 8-K — 0000068505-18-000027 filed 2018-11-01

## item codes, every 8-K on or before 2018-11-02

- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2018-11-02

- none on or before 2018-11-02

## item 2.02 — earnings release, exhibit 99.1

[0000068505-18-000027:8k_2_02:1]
EX-99.1
2
msiq32018pressrelease.htm
EXHIBIT 99.1

[0000068505-18-000027:8k_2_02:2]
Exhibit

[0000068505-18-000027:8k_2_02:3]
Exhibit 99.1

[0000068505-18-000027:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2018 Financial Results

[0000068505-18-000027:8k_2_02:5]
Company raises full-year earnings outlook

[0000068505-18-000027:8k_2_02:6]
| • | Sales of $1.9 billion, up 13 percent |

[0000068505-18-000027:8k_2_02:7]
| • | Backlog of $9.5 billion, up $572 million or 6 percent from a year ago |

[0000068505-18-000027:8k_2_02:8]
| • | Generated $338 million of operating cash flow, up 25 percent |

[0000068505-18-000027:8k_2_02:9]
| • | GAAP earnings per share (EPS) of $1.43, up 14 percent |

[0000068505-18-000027:8k_2_02:10]
| • | Non-GAAP EPS* of $1.94, up 27 percent |

[0000068505-18-000027:8k_2_02:11]
CHICAGO – Nov. 1, 2018 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of 2018. Click here for a printable news release and financial tables.

[0000068505-18-000027:8k_2_02:12]
"Q3 was another strong quarter of revenue and earnings growth,” said Greg Brown, chairman and CEO of Motorola Solutions. “Our overall business performance, along with our record Q3 backlog, provides solid momentum moving forward.”

[0000068505-18-000027:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-18-000027:8k_2_02:14]
|  | Q3 2018 |  | Q3 2017 |  | % Change |
| Sales | $1,862 | $1,645 | 13 | % |
| GAAP |  |  |  |
| Operating Earnings | $294 | $347 | (15 | )% |
| % of Sales | 15.8 | % | 21.1 | % |  |
| EPS | $1.43 | $1.25 | 14 | % |
| Non-GAAP |  |  |  |
| Operating Earnings | $452 | $412 | 10 | % |
| % of Sales | 24.3 | % | 25.0 | % |  |
| EPS | $1.94 | $1.53 | 27 | % |
| Products and Systems Integration Segment |  |  |  |
| Sales | $1,288 | $1,174 | 10 | % |
| GAAP Operating Earnings | $183 | $266 | (31 | )% |
| % of Sales | 14.2 | % | 22.7 | % |  |
| Non-GAAP Operating Earnings | $276 | $285 | (3 | )% |
| % of Sales | 21.4 | % | 24.3 | % |  |
| Services and Software Segment |  |  |  |
| Sales | $574 | $471 | 22 | % |
| GAAP Operating Earnings | $111 | $81 | 37 | % |
| % of Sales | 19.3 | % | 17.2 | % |  |
| Non-GAAP Operating Earnings | $176 | $127 | 39 | % |
| % of Sales | 30.7 | % | 27.0 | % |  |

[0000068505-18-000027:8k_2_02:15]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.51 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-18-000027:8k_2_02:16]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-18-000027:8k_2_02:17]
| • | Revenue - Sales increased $217 million, or 13 percent from the year-ago quarter, driven by growth in the Americas and EMEA. Approximately $145 million of revenue growth was related to acquisitions, and $19 million was related to the adoption of accounting standard ASC 606. The Products and Systems Integration segment grew 10 percent driven by the Americas and EMEA. The Services and Software segment grew 22 percent with growth in all regions. |

[0000068505-18-000027:8k_2_02:18]
| • | Operating margin - GAAP operating margin was 15.8 percent of sales, compared with 21.1 percent in the year-ago quarter. The decline was primarily due to higher operating expenses related to acquisitions and an increase to an existing environmental reserve related to a legacy business, partially offset by higher gross margins in Services and Software. Non-GAAP operating margin was 24.3 percent of sales, compared with 25.0 percent in the year-ago quarter due to higher operating expenses related to acquisitions partially offset by higher sales and favorable gross margin mix. |

[0000068505-18-000027:8k_2_02:19]
| • | Taxes - The GAAP effective tax rate was 8 percent, compared with 26 percent in the year-ago quarter. The Non-GAAP effective tax rate was 18 percent compared with 30 percent in the year-ago quarter. Both the GAAP and Non-GAAP tax rates were favorably affected by the recognition of U.S. federal return to provision adjustments and the tax benefits related to share-based compensation; however, certain return to provision benefits that relate to the Tax Cuts and Jobs Act of 2017 were excluded from the Non-GAAP tax rate. |

[0000068505-18-000027:8k_2_02:20]
| • | Cash flow - Operating cash flow was $338 million, compared with $270 million of operating cash generated in the year-ago quarter. Free cash flow1 was $292 million, compared with $185 million of free cash flow generated in the year-ago quarter. Cash flow for the quarter increased on higher earnings, improved working capital and lower capital expenditures. |

[0000068505-18-000027:8k_2_02:21]
| • | Capital allocation - The company paid $84 million in cash dividends. From a debt perspective, the company repaid the remaining $300 million on the revolving credit facility ahead of schedule; $200 million was repaid during the quarter, and $100 million was repaid subsequent to the quarter-end. The company also repurchased 20% of the Silver Lake convertible note for $369 million; the $200 million of principal was repaid with new senior unsecured debt and the $169 million premium was paid in cash. |

[0000068505-18-000027:8k_2_02:22]
| • | Backlog - The company ended the quarter with backlog of $9.5 billion, up $572 million from the year-ago quarter. Products and Systems Integration segment backlog was up 9 percent or $277 million, and Services and Software was up 5 percent or $295 million. Land mobile radio demand led by the Americas continues to drive backlog growth. |

[0000068505-18-000027:8k_2_02:23]
KEY HIGHLIGHTS

[0000068505-18-000027:8k_2_02:24]
Services and Software wins

[0000068505-18-000027:8k_2_02:25]
| • | $19 million digital evidence management solution contract for the city of Las Vegas |

[0000068505-18-000027:8k_2_02:26]
| • | $18 million computer aided dispatch (CAD) & mobile records contract for Chesterfield County, Virginia |

[0000068505-18-000027:8k_2_02:27]
| • | $17 million multi-year services contract for Petrobras (Brazil) |

[0000068505-18-000027:8k_2_02:28]
Products and Systems Integration wins

[0000068505-18-000027:8k_2_02:29]
| • | $50+ million Tetra system upgrade in Europe |

[0000068505-18-000027:8k_2_02:30]
| • | $21 million P25 system and device upgrade for city of Indianapolis and Marion County, Indiana |

[0000068505-18-000027:8k_2_02:31]
| • | $15 million P25 device order for city of Austin, Texas |

[0000068505-18-000027:8k_2_02:32]
| • | $12 million P25 system order for city of Augusta, Georgia |

[0000068505-18-000027:8k_2_02:33]
BUSINESS OUTLOOK

[0000068505-18-000027:8k_2_02:34]
| • | Fourth-quarter 2018 - Motorola Solutions expects revenue growth of approximately 13.5 percent compared with the fourth quarter of 2017. The company expects non-GAAP earnings in the range of $2.50 to $2.55 per share. This assumes current foreign exchange rates, approximately 173 million fully diluted shares and a 25 percent effective tax rate. |

[0000068505-18-000027:8k_2_02:35]
| • | Full-year 2018 - The company continues to expect revenue growth of approximately 14.5 percent, and now expects non-GAAP earnings per share in the range of $7.00 to $7.05, up from the prior guidance of $6.79 to $6.89. This assumes current foreign exchange rates, approximately 172 million fully diluted shares and a 22.5 percent effective tax rate. |

[0000068505-18-000027:8k_2_02:36]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, Nov. 1. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-18-000027:8k_2_02:37]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-18-000027:8k_2_02:38]
A comparison of results from operations is as follows:

[0000068505-18-000027:8k_2_02:39]
|  | Q3 2018 |  | Q3 2017 |  |
| Net sales | $1,862 | $1,645 |
| Gross margin | 901 |  | 794 |  |
| Operating earnings | 294 |  | 347 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 247 |  | 212 |  |
| Diluted EPS | $1.43 | $1.25 |
| Weighted average diluted common shares outstanding | 172.6 |  | 169.0 |  |

[0000068505-18-000027:8k_2_02:40]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-18-000027:8k_2_02:41]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the third quarter of 2018.

[0000068505-18-000027:8k_2_02:42]
| (per diluted common share) | Q3 2018 |  |
| GAAP Earnings | $1.43 |
| Highlighted Items: |  |
| Share-based compensation expense | $0.08 |
| Reorganization of business charges | 0.11 |  |
| Intangibles amortization expense | 0.21 |  |
| Avigilon purchase accounting adjustment | 0.04 |  |
| Gain from the extinguishment of convertible debt | (0.03 | ) |
| Fair value adjustments to equity investments | (0.03 | ) |
| Loss on legal settlement | 0.01 |  |
| Environmental reserve expense | 0.25 |  |
| Sale of investments | (0.03 | ) |
| Return-to-provision adjustments as related to federal tax reform | (0.10 | ) |
| Non-GAAP Diluted EPS | $1.94 |

[0000068505-18-000027:8k_2_02:43]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-18-000027:8k_2_02:44]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-18-000027:8k_2_02:45]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments, significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-18-000027:8k_2_02:46]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-18-000027:8k_2_02:47]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-18-000027:8k_2_02:48]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-18-000027:8k_2_02:49]
BUSINESS RISKS

[0000068505-18-000027:8k_2_02:50]
“intends,” “anticipates,” “estimates” and similar expressions. The company can give no assurance that any actual or future results or events discussed in these statements will be achieved. Any forward-looking statements represent the company’s views only as of today and should not be relied upon as representing the company’s views as of any subsequent date. Readers are cautioned that such forward-looking statements are subject to a variety of risks and uncertainties that could cause the company’s actual results to differ materially from the statements contained in this release. Such forward-looking statements include, but are not limited to, Motorola Solutions’ financial outlook for the fourth quarter and full year of 2018. Motorola Solutions cautions the reader that the risk factors below, as well as those on pages 8 through 20 in Item 1A of Motorola Solutions’ 2017 Annual Report on Form 10-K and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at www.motorolasolutions.com, could cause Motorola Solutions’ actual results to differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (1) the economic outlook for the government communications industry; (2) the impact of foreign currency fluctuations on the company; (3) the level of demand for the company's products; (4) the company's ability to refresh existing and introduce new products and technologies in a timely manner; (5) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (6) negative impact on the company's business from global economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company's products; (iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company's suppliers that may no longer have access to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company's pension plan and other defined benefit plans, which could impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (7) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or those it sells to or operates or maintains for its customers; (8) the outcome of ongoing and future tax matters; (9) the company's ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (10) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (11) the impact on the company's performance and financial results from strategic acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-18-000027:8k_2_02:51]
DEFINITIONS

[0000068505-18-000027:8k_2_02:52]
1  Free cash flow represents operating cash flow less capital expenditures.

[0000068505-18-000027:8k_2_02:53]
ABOUT MOTOROLA SOLUTIONS

[0000068505-18-000027:8k_2_02:54]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions, including devices, networks, services, software and video, that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0000068505-18-000027:8k_2_02:55]
MEDIA CONTACT

[0000068505-18-000027:8k_2_02:56]
Tama McWhinney

[0000068505-18-000027:8k_2_02:57]
Motorola Solutions

[0000068505-18-000027:8k_2_02:58]
+1 847-538-1865

[0000068505-18-000027:8k_2_02:59]
tama.mcwhinney@motorolasolutions.com

[0000068505-18-000027:8k_2_02:60]
INVESTOR CONTACT

[0000068505-18-000027:8k_2_02:61]
Chris Kutsor

[0000068505-18-000027:8k_2_02:62]
Motorola Solutions

[0000068505-18-000027:8k_2_02:63]
+1 847-576-4995

[0000068505-18-000027:8k_2_02:64]
chris.kutsor@motorolasolutions.com

[0000068505-18-000027:8k_2_02:65]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2018 Motorola Solutions, Inc. All rights reserved.

[0000068505-18-000027:8k_2_02:66]
GAAP-1

[0000068505-18-000027:8k_2_02:67]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:68]
Condensed Consolidated Statements of Operations

[0000068505-18-000027:8k_2_02:69]
(In millions, except per share amounts)

[0000068505-18-000027:8k_2_02:70]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Net sales from products | $ | 1,151 |  |  | $ | 989 |  |
| Net sales from services | 711 |  |  | 656 |  |
| Net sales | 1,862 |  |  | 1,645 |  |
| Costs of products sales | 516 |  |  | 428 |  |
| Costs of services sales | 445 |  |  | 423 |  |
| Costs of sales | 961 |  |  | 851 |  |
| Gross margin | 901 |  |  | 794 |  |
| Selling, general and administrative expenses | 323 |  |  | 259 |  |
| Research and development expenditures | 158 |  |  | 141 |  |
| Other charges | 80 |  |  | 8 |  |
| Intangibles amortization | 46 |  |  | 39 |  |
| Operating earnings | 294 |  |  | 347 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (59 | ) |  | (52 | ) |
| Gains on sales of investments and businesses, net | 6 |  |  | — |  |
| Other | 29 |  |  | (9 | ) |
| Total other expense | (24 | ) |  | (61 | ) |
| Net earnings before income taxes | 270 |  |  | 286 |  |
| Income tax expense | 22 |  |  | 73 |  |
| Net earnings | 248 |  |  | 213 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 247 |  |  | $ | 212 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.52 |  |  | $ | 1.30 |  |
| Diluted | $ | 1.43 |  |  | $ | 1.25 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 162.6 |  |  | 162.3 |  |
| Diluted | 172.6 |  |  | 169.0 |  |

[0000068505-18-000027:8k_2_02:71]
|  | Percentage of Net Sales* |
| Net sales from products | 61.8 | % |  | 60.1 | % |
| Net sales from services | 38.2 | % |  | 39.9 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 44.8 | % |  | 43.3 | % |
| Costs of services sales | 62.6 | % |  | 64.5 | % |
| Costs of sales | 51.6 | % |  | 51.7 | % |
| Gross margin | 48.4 | % |  | 48.3 | % |
| Selling, general and administrative expenses | 17.3 | % |  | 15.7 | % |
| Research and development expenditures | 8.5 | % |  | 8.6 | % |
| Other charges | 4.3 | % |  | 0.5 | % |
| Intangibles amortization | 2.5 | % |  | 2.4 | % |
| Operating earnings | 15.8 | % |  | 21.1 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.2 | )% |  | (3.2 | )% |
| Gains on sales of investments and businesses, net | 0.3 | % |  | — | % |
| Other | 1.6 | % |  | (0.5 | )% |
| Total other expense | (1.3 | )% |  | (3.7 | )% |
| Net earnings before income taxes | 14.5 | % |  | 17.4 | % |
| Income tax expense | 1.2 | % |  | 4.4 | % |
| Net earnings | 13.3 | % |  | 12.9 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 13.3 | % |  | 12.9 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-18-000027:8k_2_02:72]
GAAP-2

[0000068505-18-000027:8k_2_02:73]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:74]
Condensed Consolidated Statements of Operations

[0000068505-18-000027:8k_2_02:75]
(In millions, except per share amounts)

[0000068505-18-000027:8k_2_02:76]
|  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Net sales from products | $ | 2,993 |  |  | $ | 2,540 |  |
| Net sales from services | 2,096 |  |  | 1,883 |  |
| Net sales | 5,089 |  |  | 4,423 |  |
| Costs of products sales | 1,383 |  |  | 1,167 |  |
| Costs of services sales | 1,314 |  |  | 1,202 |  |
| Costs of sales | 2,697 |  |  | 2,369 |  |
| Gross margin | 2,392 |  |  | 2,054 |  |
| Selling, general and administrative expenses | 918 |  |  | 760 |  |
| Research and development expenditures | 472 |  |  | 413 |  |
| Other charges | 123 |  |  | (11 | ) |
| Intangibles amortization | 140 |  |  | 111 |  |
| Operating earnings | 739 |  |  | 781 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (163 | ) |  | (154 | ) |
| Gains on sales of investments and businesses, net | 16 |  |  | 3 |  |
| Other | 45 |  |  | (20 | ) |
| Total other expense | (102 | ) |  | (171 | ) |
| Net earnings before income taxes | 637 |  |  | 610 |  |
| Income tax expense | 91 |  |  | 188 |  |
| Net earnings | 546 |  |  | 422 |  |
| Less: Earnings attributable to noncontrolling interests | 2 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 544 |  |  | $ | 420 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.36 |  |  | $ | 2.57 |  |
| Diluted | $ | 3.17 |  |  | $ | 2.48 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 162.0 |  |  | 163.2 |  |
| Diluted | 171.6 |  |  | 169.3 |  |

[0000068505-18-000027:8k_2_02:77]
|  | Percentage of Net Sales* |
| Net sales from products | 58.8 | % |  | 57.4 | % |
| Net sales from services | 41.2 | % |  | 42.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 46.2 | % |  | 45.9 | % |
| Costs of services sales | 62.7 | % |  | 63.8 | % |
| Costs of sales | 53.0 | % |  | 53.6 | % |
| Gross margin | 47.0 | % |  | 46.4 | % |
| Selling, general and administrative expenses | 18.0 | % |  | 17.2 | % |
| Research and development expenditures | 9.3 | % |  | 9.3 | % |
| Other charges | 2.4 | % |  | (0.2 | )% |
| Intangibles amortization | 2.8 | % |  | 2.5 | % |
| Operating earnings | 14.5 | % |  | 17.7 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.2 | )% |  | (3.5 | )% |
| Gains on sales of investments and businesses, net | 0.3 | % |  | 0.1 | % |
| Other | 0.9 | % |  | (0.5 | )% |
| Total other expense | (2.0 | )% |  | (3.9 | )% |
| Net earnings before income taxes | 12.5 | % |  | 13.8 | % |
| Income tax expense | 1.8 | % |  | 4.3 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 10.7 | % |  | 9.5 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-18-000027:8k_2_02:78]
GAAP-3

[0000068505-18-000027:8k_2_02:79]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:80]
Condensed Consolidated Balance Sheets

[0000068505-18-000027:8k_2_02:81]
(In millions)

[0000068505-18-000027:8k_2_02:82]
|  |  | September 29, 2018 |  | December 31, 2017 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 839 |  |  | $ | 1,205 |  |
| Restricted cash |  | 12 |  |  | 63 |  |
| Total cash and cash equivalents |  | 851 |  |  | 1,268 |  |
| Accounts receivable, net |  | 1,179 |  |  | 1,523 |  |
| Contract assets |  | 917 |  |  | — |  |
| Inventories, net |  | 367 |  |  | 327 |  |
| Other current assets |  | 350 |  |  | 832 |  |
| Total current assets |  | 3,664 |  |  | 3,950 |  |
| Property, plant and equipment, net |  | 892 |  |  | 856 |  |
| Investments |  | 176 |  |  | 247 |  |
| Deferred income taxes |  | 949 |  |  | 1,023 |  |
| Goodwill |  | 1,541 |  |  | 938 |  |
| Intangible assets |  | 1,297 |  |  | 861 |  |
| Other assets |  | 444 |  |  | 333 |  |
| Total assets |  | $ | 8,963 |  |  | $ | 8,208 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 337 |  |  | $ | 52 |  |
| Accounts payable |  | 456 |  |  | 593 |  |
| Contract liabilities |  | 1,127 |  |  | — |  |
| Accrued liabilities |  | 1,168 |  |  | 2,286 |  |
| Total current liabilities |  | 3,088 |  |  | 2,931 |  |
| Long-term debt |  | 5,095 |  |  | 4,419 |  |
| Other liabilities |  | 2,175 |  |  | 2,585 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,411 | ) |  | (1,742 | ) |
| Noncontrolling interests |  | 16 |  |  | 15 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,963 |  |  | $ | 8,208 |  |

[0000068505-18-000027:8k_2_02:83]
GAAP-4

[0000068505-18-000027:8k_2_02:84]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:85]
Condensed Consolidated Statements of Cash Flows

[0000068505-18-000027:8k_2_02:86]
(In millions)

[0000068505-18-000027:8k_2_02:87]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 247 |  |  | $ | 212 |  |
| Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings | 248 |  |  | 213 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 89 |  |  | 88 |  |
| Non-cash other charges | 44 |  |  | 8 |  |
| Non-U.S. pension settlement loss | — |  |  | 21 |  |
| Share-based compensation expense | 19 |  |  | 16 |  |
| Gains on sales of investments and businesses, net | (6 | ) |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable, contract assets and contract liabilities | (20 | ) |  | (152 | ) |
| Inventories | 24 |  |  | 29 |  |
| Other current assets | (180 | ) |  | (129 | ) |
| Accounts payable and accrued liabilities | 170 |  |  | 152 |  |
| Other assets and liabilities | (38 | ) |  | (12 | ) |
| Deferred income taxes | (12 | ) |  | 36 |  |
| Net cash provided by operating activities | 338 |  |  | 270 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (5 | ) |  | (243 | ) |
| Proceeds from sales of investments and businesses, net | 11 |  |  | 102 |  |
| Capital expenditures | (46 | ) |  | (85 | ) |
| Net cash used for investing activities | (40 | ) |  | (226 | ) |
| Financing |  |  |  |
| Repayment of debt | (215 | ) |  | (9 | ) |
| Issuance of common stock | 80 |  |  | 33 |  |
| Purchases of common stock | — |  |  | (100 | ) |
| Payments of dividends | (84 | ) |  | (76 | ) |
| Settlement of conversion premium on convertible debt | (169 | ) |  | — |  |
| Net cash used for financing activities | (388 | ) |  | (152 | ) |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | 20 |  |
| Net decrease in cash and cash equivalents | (90 | ) |  | (88 | ) |
| Cash and cash equivalents, beginning of period | 941 |  |  | 805 |  |
| Cash and cash equivalents, end of period | $ | 851 |  |  | $ | 717 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 292 |  |  | $ | 185 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-18-000027:8k_2_02:88]
GAAP-5

[0000068505-18-000027:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:90]
Condensed Consolidated Statements of Cash Flows

[0000068505-18-000027:8k_2_02:91]
(In millions)

[0000068505-18-000027:8k_2_02:92]
|  | Nine Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 544 |  |  | $ | 420 |  |
| Earnings attributable to noncontrolling interests | 2 |  |  | 2 |  |
| Net earnings | 546 |  |  | 422 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 267 |  |  | 254 |  |
| Non-cash other charges | 50 |  |  | 29 |  |
| Non-U.S. pension settlement loss | — |  |  | 46 |  |
| Share-based compensation expense | 53 |  |  | 49 |  |
| Gains on sales of investments and businesses, net | (16 | ) |  | (3 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable, contract assets and contract liabilities | 186 |  |  | 81 |  |
| Inventories | 61 |  |  | (83 | ) |
| Other current assets | (137 | ) |  | (142 | ) |
| Accounts payable and accrued liabilities | (170 | ) |  | (178 | ) |
| Other assets and liabilities | (596 | ) |  | 11 |  |
| Deferred income taxes | 19 |  |  | 99 |  |
| Net cash provided by operating activities | 263 |  |  | 585 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (1,158 | ) |  | (383 | ) |
| Proceeds from sales of investments and businesses, net | 90 |  |  | 174 |  |
| Capital expenditures | (128 | ) |  | (206 | ) |
| Net cash used for investing activities | (1,196 | ) |  | (415 | ) |
| Financing |  |  |  |
| Repayment of debt | (412 | ) |  | (15 | ) |
| Net proceeds from issuance of debt | 1,295 |  |  | — |  |
| Proceeds from financing through capital leases | — |  |  | 7 |  |
| Issuance of common stock | 139 |  |  | 61 |  |
| Purchases of common stock | (66 | ) |  | (358 | ) |
| Payments of dividends | (252 | ) |  | (230 | ) |
| Payments of dividend to non-controlling interest | (1 | ) |  | (2 | ) |
| Settlement of conversion premium on convertible debt | (169 | ) |  | — |  |
| Net cash provided by (used for) financing activities | 534 |  |  | (537 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (18 | ) |  | 54 |  |
| Net decrease in cash and cash equivalents | (417 | ) |  | (313 | ) |
| Cash and cash equivalents, beginning of period | 1,268 |  |  | 1,030 |  |
| Cash and cash equivalents, end of period | $ | 851 |  |  | $ | 717 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 135 |  |  | $ | 379 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-18-000027:8k_2_02:93]
GAAP-6

[0000068505-18-000027:8k_2_02:94]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:95]
Segment Information

[0000068505-18-000027:8k_2_02:96]
(In millions)

[0000068505-18-000027:8k_2_02:97]
| Net Sales |
|  | Three Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 1,288 |  |  | $ | 1,174 |  |  | 10 | % |
| Services and software | 574 |  |  | 471 |  |  | 22 | % |
| Total Motorola Solutions | $ | 1,862 |  |  | $ | 1,645 |  |  | 13 | % |
|  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 3,429 |  |  | $ | 3,076 |  |  | 11 | % |
| Services and software | 1,660 |  |  | 1,347 |  |  | 23 | % |
| Total Motorola Solutions | $ | 5,089 |  |  | $ | 4,423 |  |  | 15 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 183 |  |  | $ | 266 |  |  | (31 | )% |
| Services and software | 111 |  |  | 81 |  |  | 37 | % |
| Total Motorola Solutions | $ | 294 |  |  | $ | 347 |  |  | (15 | )% |
|  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 449 |  |  | $ | 553 |  |  | (19 | )% |
| Services and software | 290 |  |  | 228 |  |  | 27 | % |
| Total Motorola Solutions | $ | 739 |  |  | $ | 781 |  |  | (5 | )% |

[0000068505-18-000027:8k_2_02:98]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  |  |
| Products and systems integration | 14.2 | % |  | 22.7 | % |  |  |
| Services and software | 19.3 | % |  | 17.2 | % |  |  |
| Total Motorola Solutions | 15.8 | % |  | 21.1 | % |  |  |
|  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  |  |
| Products and systems integration | 13.1 | % |  | 18.0 | % |  |  |
| Services and software | 17.5 | % |  | 16.9 | % |  |  |
| Total Motorola Solutions | 14.5 | % |  | 17.7 | % |  |  |

[0000068505-18-000027:8k_2_02:99]
Non-GAAP-1

[0000068505-18-000027:8k_2_02:100]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:101]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-18-000027:8k_2_02:102]
| Q1 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 13 |  |  | 3 |  |  | 10 |  |  | 0.06 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 41 |  |  | 8 |  |  | 33 |  |  | 0.19 |  |
| Loss on legal settlements |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on derivative instruments related to Avigilon purchase |  | Other expense |  | 14 |  |  | 4 |  |  | 10 |  |  | 0.06 |  |
| Release of FIN 48 reserve |  | Income tax expense |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | (11 | ) |  | (3 | ) |  | (8 | ) |  | (0.05 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 17 |  |  | 5 |  |  | 12 |  |  | 0.07 |  |
| Total impact on Net earnings |  |  |  | $ | 92 |  |  | $ | 22 |  |  | $ | 70 |  |  | $ | 0.41 |  |
| Q2 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.10 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 53 |  |  | 12 |  |  | 41 |  |  | 0.23 |  |
| Avigilon purchase accounting adjustment |  | Cost of sales |  | 10 |  |  | 3 |  |  | 7 |  |  | 0.04 |  |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on foreign currency related to Avigilon purchase |  | Other expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| FIN 48 reserve |  | Income tax expense |  | — |  |  | (1 | ) |  | 1 |  |  | 0.01 |  |
| State audit settlement |  | Income tax expense |  | — |  |  | 12 |  |  | (12 | ) |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 107 |  |  | $ | 36 |  |  | $ | 71 |  |  | $ | 0.41 |  |
| Q3 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 19 |  |  | $ | 5 |  |  | $ | 14 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.11 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 46 |  |  | 10 |  |  | 36 |  |  | 0.21 |  |
| Avigilon purchase accounting adjustment |  | Cost of sales |  | 9 |  |  | 2 |  |  | 7 |  |  | 0.04 |  |
| Gain from the extinguishment of convertible debt |  | Other income |  | (6 | ) |  | — |  |  | (6 | ) |  | (0.03 | ) |
| Fair value adjustments to equity investments |  | Other income |  | (7 | ) |  | (2 | ) |  | (5 | ) |  | (0.03 | ) |
| Loss on legal settlement |  | Other charges |  | 2 |  |  | 1 |  |  | 1 |  |  | 0.01 |  |
| Environmental reserve expense |  | Other charges |  | 57 |  |  | 14 |  |  | 43 |  |  | 0.25 |  |
| Sale of investments |  | (Gain) or Loss on Sales of Investments and Businesses, net |  | (6 | ) |  | (1 | ) |  | (5 | ) |  | (0.03 | ) |
| Return-to-provision adjustments as related to federal tax reform |  | Income tax expense |  | — |  |  | 16 |  |  | (16 | ) |  | (0.10 | ) |
| Total impact on Net earnings |  |  |  | $ | 139 |  |  | $ | 51 |  |  | $ | 88 |  |  | $ | 0.51 |  |

[0000068505-18-000027:8k_2_02:103]
Non-GAAP-2

[0000068505-18-000027:8k_2_02:104]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:105]
Non-GAAP Segment Information

[0000068505-18-000027:8k_2_02:106]
(In millions)

[0000068505-18-000027:8k_2_02:107]
| Net Sales |
|  | Three Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 1,288 |  |  | $ | 1,174 |  |  | 10 | % |
| Services and software | 574 |  |  | 471 |  |  | 22 | % |
| Total Motorola Solutions | $ | 1,862 |  |  | $ | 1,645 |  |  | 13 | % |
|  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 3,429 |  |  | $ | 3,076 |  |  | 11 | % |
| Services and software | 1,660 |  |  | 1,347 |  |  | 23 | % |
| Total Motorola Solutions | $ | 5,089 |  |  | $ | 4,423 |  |  | 15 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 276 |  |  | $ | 285 |  |  | (3 | )% |
| Services and software | 176 |  |  | 127 |  |  | 39 | % |
| Total Motorola Solutions | $ | 452 |  |  | $ | 412 |  |  | 10 | % |
|  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Products and systems integration | $ | 627 |  |  | $ | 591 |  |  | 6 | % |
| Services and software | 463 |  |  | 349 |  |  | 33 | % |
| Total Motorola Solutions | $ | 1,090 |  |  | $ | 940 |  |  | 16 | % |

[0000068505-18-000027:8k_2_02:108]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  |  |
| Products and systems integration | 21.4 | % |  | 24.3 | % |  |  |
| Services and software | 30.7 | % |  | 27.0 | % |  |  |
| Total Motorola Solutions | 24.3 | % |  | 25.0 | % |  |  |
|  | Nine Months Ended |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  |  |
| Products and systems integration | 18.3 | % |  | 19.2 | % |  |  |
| Services and software | 27.9 | % |  | 25.9 | % |  |  |
| Total Motorola Solutions | 21.4 | % |  | 21.3 | % |  |  |

[0000068505-18-000027:8k_2_02:109]
Non-GAAP-3

[0000068505-18-000027:8k_2_02:110]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:111]
Operating Earnings after Non-GAAP Adjustments

[0000068505-18-000027:8k_2_02:112]
| Q1 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,468 |  |  | $ | 952 |  |  | $ | 516 |  |
| Operating earnings ("OE") |  | $ | 171 |  |  | $ | 90 |  |  | $ | 81 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 13 |  |  | 9 |  |  | 4 |  |
| Intangibles amortization expense |  | 41 |  |  | 1 |  |  | 40 |  |
| Acquisition-related transaction fees |  | 17 |  |  | 12 |  |  | 5 |  |
| Loss on legal settlements |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 89 |  |  | 35 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 260 |  |  | $ | 125 |  |  | $ | 135 |  |

[0000068505-18-000027:8k_2_02:113]
| Operating earnings as a percentage of net sales - GAAP |  | 11.6 | % |  | 9.5 | % |  | 15.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 17.7 | % |  | 13.1 | % |  | 26.2 | % |

[0000068505-18-000027:8k_2_02:114]
| Q2 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,760 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Operating earnings ("OE") |  | $ | 273 |  |  | $ | 175 |  |  | $ | 98 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 25 |  |  | 19 |  |  | 6 |  |
| Intangibles amortization expense |  | 53 |  |  | 10 |  |  | 43 |  |
| Avigilon purchase accounting adjustment |  | 10 |  |  | 10 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 105 |  |  | 51 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 378 |  |  | $ | 226 |  |  | $ | 152 |  |

[0000068505-18-000027:8k_2_02:115]
| Operating earnings as a percentage of net sales - GAAP |  | 15.5 | % |  | 14.7 | % |  | 17.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 21.5 | % |  | 19.0 | % |  | 26.6 | % |

[0000068505-18-000027:8k_2_02:116]
| Q3 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,862 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Operating earnings ("OE") |  | $ | 294 |  |  | $ | 183 |  |  | $ | 111 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 19 |  |  | 13 |  |  | 6 |  |
| Reorganization of business charges |  | 25 |  |  | 19 |  |  | 6 |  |
| Intangibles amortization expense |  | 46 |  |  | 11 |  |  | 35 |  |
| Avigilon purchase accounting adjustment |  | 9 |  |  | 9 |  |  | — |  |
| Loss on legal settlement |  | 2 |  |  | 1 |  |  | 1 |  |
| Environmental reserve expense |  | 57 |  |  | 40 |  |  | 17 |  |
| Total above-OE non-GAAP adjustments |  | 158 |  |  | 93 |  |  | 65 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 452 |  |  | $ | 276 |  |  | $ | 176 |  |

[0000068505-18-000027:8k_2_02:117]
| Operating earnings as a percentage of net sales - GAAP |  | 15.8 | % |  | 14.2 | % |  | 19.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.3 | % |  | 21.4 | % |  | 30.7 | % |

[0000068505-18-000027:8k_2_02:118]
Non-GAAP-4

[0000068505-18-000027:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000027:8k_2_02:120]
Non-GAAP Organic Revenue

[0000068505-18-000027:8k_2_02:121]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |
|  |  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Net sales |  | $ | 1,862 |  |  | $ | 1,645 |  |  | 13 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (149 | ) |  | (4 | ) |  |  |
| ASC 606 impact |  | (19 | ) |  | — |  |  |  |
| Organic revenue |  | 1,694 |  |  | 1,641 |  |  | 3 | % |
| Less foreign exchange impact |  | 9 |  |  | — |  |  |  |
| Organic revenue in constant currency |  | $ | 1,703 |  |  | $ | 1,641 |  |  | 4 | % |

[0000068505-18-000027:8k_2_02:122]
| Total Motorola Solutions |
|  |  | Nine Months Ended |  |  |
|  |  | September 29, 2018 |  | September 30, 2017 |  | % Change |
| Net sales |  | $ | 5,089 |  |  | $ | 4,423 |  |  | 15 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (356 | ) |  | (9 | ) |  |  |
| ASC 606 impact |  | (58 | ) |  | — |  |  |  |
| Organic revenue |  | 4,675 |  |  | 4,414 |  |  | 6 | % |
| Less foreign exchange impact |  | (56 | ) |  | — |  |  |  |
| Organic revenue in constant currency |  | $ | 4,619 |  |  | $ | 4,414 |  |  | 5 | % |
