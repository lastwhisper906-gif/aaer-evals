# MSI MD&A — 0000068505-20-000013


## mdna

[0000068505-20-000013:mdna:1]
[same as prior period, unchanged from 0000068505-19-000025:mdna:1]

[0000068505-20-000013:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three months ended March 28, 2020 and March 30, 2019, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2019.

[0000068505-20-000013:mdna:3]
[same as prior period, unchanged from 0000068505-19-000025:mdna:3]

[0000068505-20-000013:mdna:4]
First Quarter Financial Results

[0000068505-20-000013:mdna:5]
•Net sales were $1.7 billion for both of the first quarters of 2020 and 2019.

[0000068505-20-000013:mdna:6]
•Operating earnings were $259 million in the first quarter of 2020 compared to $229 million in the first quarter of 2019.

[0000068505-20-000013:mdna:7]
•Net earnings attributable to Motorola Solutions, Inc. were $197 million, or $1.12 per diluted common share, in the first quarter of 2020, compared to $151 million, or $0.86 per diluted common share, in the first quarter of 2019.

[0000068505-20-000013:mdna:8]
•Our operating cash flow increased $57 million to $308 million in the first quarter of 2020 compared to the first quarter of 2019.

[0000068505-20-000013:mdna:9]
•We repurchased $253 million of common stock and paid $109 million in dividends in the first quarter of 2020.

[0000068505-20-000013:mdna:10]
Recent Developments

[0000068505-20-000013:mdna:11]
In March 2020, the COVID-19 outbreak was declared a pandemic by the World Health Organization (“WHO”). In response, there have been a broad number of governmental and commercial actions including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns in an effort to limit the spread of coronavirus. These events have resulted in a significant decline in global economic activity, and accordingly, we have assessed the impact on our employees, customers, communities, liquidity and financial position.

[0000068505-20-000013:mdna:12]
We have implemented a number of measures in an effort to protect the health and well-being of our employees and customers, including having office workers work remotely, suspending employee travel, withdrawing from certain industry events, increased cleaning, encouraging face coverings and using thermal scanning. Additionally, we have ensured customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and visitation by field workers to customer sites to keep mission-critical networks operating.

[0000068505-20-000013:mdna:13]
We recognize the effects of the virus on first responders and front-line health care professionals and their families during this time. In response, our charitable foundation has committed $1 million in cash and in-kind donations in support of these groups. We have also reprioritized our foundation funding to support COVID-19 relief efforts in the communities in which we work and serve.

[0000068505-20-000013:mdna:14]
We also assessed the adequacy of our liquidity. We believe the steps we have taken, over the past few years and months, have strengthened our ability to operate under the current conditions. These include the proactive withdrawal in March 2020 of $800 million from our unsecured revolving credit facility as a precaution and to provide additional flexibility during the disruption in the financial markets. This leaves $1.4 billion of capacity on the committed facility. Additionally, we have no bond maturities until 2022.

[0000068505-20-000013:mdna:15]
We evaluated our financial position during this economic slowdown. Specifically, in our Software and Services segment, with the recurring nature of the business and strong backlog position, we expect that the impact should be somewhat limited.  In our Products and Systems Integration segment, the impact is likely to be more significant with the largest impact occurring during the second quarter.  Reduced demand, particularly in our professional commercial radio business (“PCR”), as well as delays in engagements with our state and local customers in the near term, will most likely lead to year-over-year sales declines for the segment in 2020, as compared to 2019.  Within the Products and Systems Integration segment, we are encouraged by the resiliency of the video security Device business and expect growth for fiscal year 2020. We have also taken actions in a number of areas to reduce our operating expenses, mostly driven by lower variable compensation, travel costs, contractor spend and reduced real estate footprint to limit the negative effect on operating margins for the year despite the expected reduction of revenue.

[0000068505-20-000013:mdna:16]
Lastly, we evaluated whether there were any impairment indicators in the first quarter, which included a review of our receivables, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. We concluded that as of the end of the first quarter of 2020, our assets were fairly stated and recoverable.

[0000068505-20-000013:mdna:17]
For additional discussion of risks related to the COVID-19 pandemic, please refer to “Item 1A. Risk Factors.”

[0000068505-20-000013:mdna:18]
Recent Acquisitions

[0000068505-20-000013:mdna:19]
On March 17, 2020, we announced the proposed acquisition of IndigoVision Group plc ("IndigoVision") for a purchase price of approximately $37 million in cash. The proposed acquisition complements our video security and analytics portfolio, providing

[0000068505-20-000013:mdna:20]
enhanced geographical reach across a wider customer base. The proposed acquisition is subject to customary closing conditions for a UK public transaction and is currently expected to close in the second quarter of 2020.

[0000068505-20-000013:mdna:21]
On March 3, 2020, we acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands our ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-20-000013:mdna:22]
On October 16, 2019, we acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances our video security platform by adding data to our existing license plate recognition (“LPR”) database within our Software and Services segment.

[0000068505-20-000013:mdna:23]
On July 11, 2019, we acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000013:mdna:24]
On March 11, 2019, we acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands our commercial portfolio with new capabilities, allowing us to offer an enhanced platform for customers to communicate, coordinate resources and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000013:mdna:25]
On January 7, 2019, we announced that we acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands our video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000013:mdna:26]
Change in Presentation

[0000068505-20-000013:mdna:27]
During the first quarter of 2020, we restructured our operations to realize more operational efficiencies, combining EMEA, AP and LA into one region which is now reflected as "International."  Accordingly, we now report net sales in the following two geographic regions: North America, which includes the United States and Canada, and International. We have updated all periods presented to reflect this change in presentation.

[0000068505-20-000013:mdna:28]
Geographic market sales measured by the locale of the end customer as a percent of total net sales are as follows:

[0000068505-20-000013:mdna:29]
|  | Three Months Ended |  | Year Ended December 31 |  |  |
|  | March 28, 2020 | March 30, 2019 | 2019 | 2018 | 2017 |
| North America | 67 | % | 65 | % | 67 | % | 64 | % | 62 | % |
| International | 33 | % | 35 | % | 33 | % | 36 | % | 38 | % |

[0000068505-20-000013:mdna:30]
[same as prior period, unchanged from 0000068505-19-000025:mdna:18]

[0000068505-20-000013:mdna:31]
A summary of our segment results for the first quarter of 2020 is as follows:

[0000068505-20-000013:mdna:32]
•In the Products and Systems Integration segment, net sales were $993 million in the first quarter of 2020, a decrease of $76 million, or 7%, compared to $1.1 billion in the first quarter of 2019. On a geographic basis, net sales decreased in both the North America and International regions compared to the year-ago quarter primarily driven by our PCR Devices sales. Operating earnings were $92 million in the first quarter of 2020, compared to $108 million in the first quarter of 2019. Operating earnings decreased in 2020 to 9.3% from 10.1% in 2019 primarily driven by lower sales, gross margin, and higher operating expenses primarily driven by i) $15 million of additional Hytera-related legal expenses, ii) $7 million higher share-based compensation expenses, iii) $7 million higher reorganization of business charges and iv) higher operating expenses from acquisitions, and partially offset by a $50 million gain from the sale of a manufacturing facility in Europe.

[0000068505-20-000013:mdna:33]
•In the Software and Services segment, net sales were $662 million in the first quarter of 2020, an increase of $74 million, or 13%, compared to net sales of $588 million in the first quarter of 2019. On a geographic basis, net sales increased in both the North America and International regions compared to the year-ago quarter. Operating earnings were $167 million in the first quarter of 2020, compared to $121 million in the first quarter of 2019. Operating earnings increased in 2020 to 25.2% from 20.6% in 2019 driven by higher sales and gross margin expansion, and partially offset by higher operating expenses driven by i) $4 million of higher share-based compensation expenses, ii) $3 million of higher reorganization of business charges and iii) $2 million of higher intangible amortization driven by acquisitions.

[0000068505-20-000013:mdna:34]
24

[0000068505-20-000013:mdna:35]
[same as prior period, unchanged from 0000068505-19-000025:mdna:25]

[0000068505-20-000013:mdna:36]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions, except per share amounts) | March 28, 2020 |  | % ofSales* |  | March 30, 2019 |  | % ofSales* |  |  |  |  |  |  |  |  |
| Net sales from products | $ | 884 |  |  |  |  | $ | 945 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales from services | 771 |  |  |  |  | 712 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 1,655 |  |  |  |  | 1,657 |  |  |  |  |  |  |  |  |  |  |  |
| Costs of products sales | 397 |  |  | 44.9 | % |  | 444 |  |  | 47.0 | % |  |  |  |  |  |  |  |  |
| Costs of services sales | 471 |  |  | 61.1 | % |  | 440 |  |  | 61.8 | % |  |  |  |  |  |  |  |  |
| Costs of sales | 868 |  |  |  |  | 884 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 787 |  |  | 47.6 | % |  | 773 |  |  | 46.7 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 341 |  |  | 20.6 | % |  | 327 |  |  | 19.7 | % |  |  |  |  |  |  |  |  |
| Research and development expenditures | 168 |  |  | 10.2 | % |  | 162 |  |  | 9.8 | % |  |  |  |  |  |  |  |  |
| Other charges |  | 19 |  |  | 1.1 | % |  | 55 |  |  | 3.3 | % |  |  |  |  |  |  |  |  |
| Operating earnings | 259 |  |  | 15.6 | % |  | 229 |  |  | 13.8 | % |  |  |  |  |  |  |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (52) |  |  | (3.1) | % |  | (55) |  |  | (3.3) | % |  |  |  |  |  |  |  |  |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | 1 |  |  | — | % |  |  |  |  |  |  |  |  |
| Other, net | 17 |  |  | 1.0 | % |  | (10) |  |  | (0.6) | % |  |  |  |  |  |  |  |  |
| Total other expense | (35) |  |  | (2.1) | % |  | (44) |  |  | (2.7) | % |  |  |  |  |  |  |  |  |
| Net earnings before income taxes | 224 |  |  | 13.5 | % |  | 185 |  |  | 11.2 | % |  |  |  |  |  |  |  |  |
| Income tax expense | 26 |  |  | 1.6 | % |  | 33 |  |  | 2.0 | % |  |  |  |  |  |  |  |  |
| Net earnings | 198 |  |  | 12.0 | % |  | 152 |  |  | 9.2 | % |  |  |  |  |  |  |  |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | — | % |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 197 |  |  | 11.9 | % |  | $ | 151 |  |  | 9.1 | % |  |  |  |  |  |  |  |  |
| Earnings per diluted common share | $ | 1.12 |  |  |  |  |  | $ | 0.86 |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-20-000013:mdna:37]
[same as prior period, unchanged from 0000068505-19-000025:mdna:27]

[0000068505-20-000013:mdna:38]
25

[0000068505-20-000013:mdna:39]
Results of Operations—Three months ended March 28, 2020 compared to three months ended March 30, 2019

[0000068505-20-000013:mdna:40]
The results of operations for the first quarter of 2020 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-20-000013:mdna:41]
[same as prior period, unchanged from 0000068505-19-000025:mdna:31]

[0000068505-20-000013:mdna:42]
|  | Three Months Ended |  |  |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 993 |  |  | $ | 1,069 |  |  | (7) | % |
| Net sales from Software and Services | 662 |  |  | 588 |  |  | 13 | % |
| Net sales | $ | 1,655 |  |  | $ | 1,657 |  |  | — | % |

[0000068505-20-000013:mdna:43]
The Products and Systems Integration segment’s net sales represented 60% of our consolidated net sales in the first quarter of 2020 and 65% in the first quarter of 2019. The Software and Services segment’s net sales represented 40% of our consolidated net sales in the first quarter of 2020 and 35% in the first quarter of 2019.

[0000068505-20-000013:mdna:44]
Net sales were flat in the first quarter of 2020 compared to the first quarter of 2019. The 7% decline in sales within the Products and Systems Integration segment was driven by a 22% decline in the International region and a 1% decline in the North America region. The 13% increase in sales within the Software and Services segment was driven by a 15% increase in the North America region and a 10% increase in the International region. Net sales includes:

[0000068505-20-000013:mdna:45]
•a decline in the Products and System Integration segment, inclusive of acquisitions, driven by a decline in PCR Devices, a subset of our Devices portfolio, and partially offset by growth in Video Devices; and

[0000068505-20-000013:mdna:46]
•$7 million from unfavorable currency rates;

[0000068505-20-000013:mdna:47]
•partially offset by $48 million of revenue from acquisitions; and

[0000068505-20-000013:mdna:48]
•growth in Software and Services driven by maintenance and managed services, and video security and command center software.

[0000068505-20-000013:mdna:49]
[same as prior period, unchanged from 0000068505-19-000025:mdna:38]

[0000068505-20-000013:mdna:50]
•an increase in the North America region of 4% driven by growth in the Software and Services segment, inclusive of revenue from acquisitions; and

[0000068505-20-000013:mdna:51]
•partially offset by a decline in the International region of 7% driven primarily by a decline in sales in our PCR Devices.

[0000068505-20-000013:mdna:52]
[same as prior period, unchanged from 0000068505-19-000025:mdna:42]

[0000068505-20-000013:mdna:53]
The 7% decrease in the Products and Systems Integration segment was driven by the following:

[0000068505-20-000013:mdna:54]
•10% decline in Devices revenue, primarily driven by a decline in the demand of our PCR devices in both the International and North America regions, inclusive of revenue from acquisitions;

[0000068505-20-000013:mdna:55]
•3% decline in Systems and Systems Integration revenue; and

[0000068505-20-000013:mdna:56]
•partially offset by $24 million of revenue from acquisitions.

[0000068505-20-000013:mdna:57]
Software and Services

[0000068505-20-000013:mdna:58]
The 13% increase in the Software and Services segment was driven by the following:

[0000068505-20-000013:mdna:59]
•9% growth in Services, driven by growth in our maintenance and managed services revenue, inclusive of acquisitions;

[0000068505-20-000013:mdna:60]
•25% growth in Software, driven primarily by an increase in video security and command center software sales, inclusive of acquisitions; and

[0000068505-20-000013:mdna:61]
•$24 million of revenue from acquisitions.

[0000068505-20-000013:mdna:62]
[same as prior period, unchanged from 0000068505-19-000025:mdna:52]

[0000068505-20-000013:mdna:63]
|  | Three Months Ended |  |  |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |  | % Change |
| Gross margin | $ | 787 |  |  | $ | 773 |  |  | 2 | % |

[0000068505-20-000013:mdna:64]
Gross margin was 47.6% of net sales in the first quarter of 2020 compared to 46.7% in the first quarter of 2019. The primary drivers of the increase are as follows:

[0000068505-20-000013:mdna:65]
26

[0000068505-20-000013:mdna:66]
•higher margins within Software and Services primarily driven by margin expansion within the Services and Software businesses and the increased mix of Software to the total segment, inclusive of acquisitions;

[0000068505-20-000013:mdna:67]
•partially offset by lower gross margin contribution in Products and Systems Integration as a result of the decline in Devices sales, inclusive of acquisitions.

[0000068505-20-000013:mdna:68]
[same as prior period, unchanged from 0000068505-19-000025:mdna:57]

[0000068505-20-000013:mdna:69]
|  | Three Months Ended |  |  |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 341 |  |  | $ | 327 |  |  | 4 | % |

[0000068505-20-000013:mdna:70]
SG&A expenses increased 4% compared to the first quarter of 2019. SG&A expenses were 20.6% of net sales compared to 19.7% of net sales in the first quarter of 2019. The increase in SG&A expenditures is primarily due to $25 million in Hytera-related legal expenses incurred during the first quarter of 2020 compared to $10 million in the first quarter of 2019.

[0000068505-20-000013:mdna:71]
[same as prior period, unchanged from 0000068505-19-000025:mdna:60]

[0000068505-20-000013:mdna:72]
|  | Three Months Ended |  |  |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |  | % Change |
| Research and development expenditures | $ | 168 |  |  | $ | 162 |  |  | 4 | % |

[0000068505-20-000013:mdna:73]
R&D expenditures increased 4% primarily due to increased expenses associated with acquired businesses. R&D expenditures were 10.2% of net sales compared to 9.8% of net sales in the first quarter of 2019.

[0000068505-20-000013:mdna:74]
[same as prior period, unchanged from 0000068505-19-000025:mdna:63]

[0000068505-20-000013:mdna:75]
|  | Three Months Ended |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |
| Other charges |  | $ | 19 |  |  | $ | 55 |  |

[0000068505-20-000013:mdna:76]
Other charges decreased by $36 million in the first quarter of 2020 compared to the first quarter of 2019. The change is driven by the following:

[0000068505-20-000013:mdna:77]
•a $50 million gain on the sale of property, plant and equipment in the first quarter of 2020;

[0000068505-20-000013:mdna:78]
•partially offset by $12 million of net reorganization business charges in the first quarter of 2020 compared to $4 million in the first quarter of 2019 (see further detail in “Reorganization of Businesses” section); and

[0000068505-20-000013:mdna:79]
•$53 million of intangible amortization in the first quarter of 2020 compared to $50 million in the first quarter of 2019.

[0000068505-20-000013:mdna:80]
|  | Three Months Ended |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |
| Operating earnings from Products and Systems Integration | $ | 92 |  |  | $ | 108 |  |
| Operating earnings from Software and Services | 167 |  |  | 121 |  |
| Operating earnings | $ | 259 |  |  | $ | 229 |  |

[0000068505-20-000013:mdna:81]
Operating earnings were up $30 million, or 13%, compared to the first quarter of 2019. The increase in Operating earnings was due to:

[0000068505-20-000013:mdna:82]
•Software and Services, which was up $46 million, primarily driven by higher sales and gross margin expansion, partially offset by higher operating expenses driven by: i) $4 million of higher share-based compensation expenses ii) $3 million of higher reorganization of business charges and iii) $2 million of higher intangible amortization driven by acquisitions; and

[0000068505-20-000013:mdna:83]
•Products and Systems Integration, which was down $16 million, driven by lower sales, gross margin and higher operating expenses primarily driven by: i) $15 million of additional Hytera-related legal expenses, ii) $7 million higher share-based compensation expenses, iii) $7 million higher reorganization of business charges and iv) higher operating expenses from acquisitions, and partially offset by a $50 million gain from the sale of a manufacturing facility in Europe.

[0000068505-20-000013:mdna:84]
[same as prior period, unchanged from 0000068505-19-000025:mdna:71]

[0000068505-20-000013:mdna:85]
|  | Three Months Ended |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |
| Interest expense, net | $ | (52) |  |  | $ | (55) |  |

[0000068505-20-000013:mdna:86]
The decrease in net interest expense in the first quarter of 2020 compared to the first quarter of 2019 was a result of less average debt outstanding as of and for the period ending March 28, 2020 as compared to the period ending March 30, 2019.

[0000068505-20-000013:mdna:87]
[same as prior period, unchanged from 0000068505-19-000025:mdna:77]

[0000068505-20-000013:mdna:88]
|  | Three Months Ended |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |
| Other, net | $ | 17 |  |  | $ | 10 |  |

[0000068505-20-000013:mdna:89]
The increase in net Other income in the first quarter of 2020 as compared to the first quarter of 2019 was driven by $8 million of investment impairments in the first quarter of 2019.

[0000068505-20-000013:mdna:90]
[same as prior period, unchanged from 0000068505-19-000025:mdna:86]

[0000068505-20-000013:mdna:91]
|  | Three Months Ended |  |  |
| (In millions) | March 28, 2020 |  | March 30, 2019 |
| Income tax expense | $ | 26 |  |  | $ | 33 |  |

[0000068505-20-000013:mdna:92]
Income tax expense decreased by $7 million compared to the first quarter of 2019, resulting in an effective tax rate of 12%. Our effective tax rate for the three months ended March 28, 2020 is lower than the effective tax rate for the three months ended March 30, 2019 of 18%, primarily due to a higher excess tax benefits on share-based compensation.

[0000068505-20-000013:mdna:93]
[same as prior period, unchanged from 0000068505-19-000025:mdna:155]

[0000068505-20-000013:mdna:94]
During the first quarter of 2020, we recorded net reorganization of business charges of $18 million including $12 million of charges recorded within Other charges and $6 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $22 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-20-000013:mdna:95]
During the first quarter of 2019, we recorded net reorganization of business charges of $8 million including $4 million of charges in Other charges and $4 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $8 million were charges of $12 million related to employee separation costs and $4 million reversals for accruals no longer needed.

[0000068505-20-000013:mdna:96]
[same as prior period, unchanged from 0000068505-19-000025:mdna:160]

[0000068505-20-000013:mdna:97]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Products and Systems Integration | $ | 14 |  |  | $ | 7 |  |  |  |  |  |
| Software and Services | 4 |  |  | 1 |  |  |  |  |  |
|  | $ | 18 |  |  | $ | 8 |  |  |  |  |  |

[0000068505-20-000013:mdna:98]
Cash payments for employee severance in connection with the reorganization of business plans were $22 million in the first quarter of 2020 and $14 million in the first quarter of 2019. The reorganization of business accrual at March 28, 2020 was $74 million related to employee separation costs that are expected to be paid within one year.

[0000068505-20-000013:mdna:99]
[same as prior period, unchanged from 0000068505-19-000025:mdna:164]

[0000068505-20-000013:mdna:100]
|  | Three Months Ended |  |  |
|  | March 28, 2020 |  | March 30, 2019 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 308 |  |  | $ | 251 |  |
| Investing activities | (26) |  |  | (432) |  |
| Financing activities | 439 |  |  | (201) |  |
| Effect of exchange rates on cash and cash equivalents | (50) |  |  | 22 |  |
| Increase (decrease) in cash and cash equivalents | $ | 671 |  |  | $ | (360) |  |

[0000068505-20-000013:mdna:101]
[same as prior period, unchanged from 0000068505-19-000025:mdna:166]

[0000068505-20-000013:mdna:102]
At March 28, 2020, $1.2 billion of the $1.7 billion cash and cash equivalents balance was held in the U.S. and $459 million was held in other countries, with $162 million held in the United Kingdom.

[0000068505-20-000013:mdna:103]
[same as prior period, unchanged from 0000068505-19-000025:mdna:168]

[0000068505-20-000013:mdna:104]
The increase in operating cash flows from the first quarter of 2019 to the first quarter of 2020 was driven primarily by favorable working capital as a result of timing.

[0000068505-20-000013:mdna:105]
[same as prior period, unchanged from 0000068505-19-000025:mdna:175]

[0000068505-20-000013:mdna:106]
The decrease in net cash used by investing activities from the first quarter of 2019 to the first quarter of 2020 was primarily due to:

[0000068505-20-000013:mdna:107]
•a $332 million decrease in acquisitions and investments, primarily driven by cash used for the purchases of VaaS and Avtec in the first quarter of 2019;

[0000068505-20-000013:mdna:108]
•a $18 million decrease in capital expenditures in the first quarter of 2020 as compared to the first quarter of 2019 due to lower payments for the Airwave and ESN networks; and

[0000068505-20-000013:mdna:109]
•a $56 million increase in the proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in the first quarter of 2020.

[0000068505-20-000013:mdna:110]
[same as prior period, unchanged from 0000068505-19-000025:mdna:180]

[0000068505-20-000013:mdna:111]
The increase in cash provided by financing activities in the first quarter of 2020 as compared to the cash provided by financing activities in the first quarter of 2019 was driven by (also see further discussion in "Debt,"  "Share Repurchase Program" and "Dividends" below):

[0000068505-20-000013:mdna:112]
•a $800 million increase in debt due to the draw on our syndicated, unsecured revolving credit facility during the first quarter of 2020;

[0000068505-20-000013:mdna:113]
•partially offset by a $108 million increase in share repurchases in the first quarter of 2020 as compared to the first quarter of 2019;

[0000068505-20-000013:mdna:114]
•a $40 million decrease in the cash received from the issuance of common stock due to the issuance of stock related to our employee stock purchase program taking place during the second quarter of 2020 compared to the first quarter of 2019; and

[0000068505-20-000013:mdna:115]
•a $16 million increase in the payment of dividends in the first quarter of 2020 as compared to the first quarter of 2019.

[0000068505-20-000013:mdna:116]
[same as prior period, unchanged from 0000068505-19-000025:mdna:187]

[0000068505-20-000013:mdna:117]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended March 28, 2020 and March 30, 2019:

[0000068505-20-000013:mdna:118]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Accounts receivable sales proceeds | $ | 68 |  |  | $ | 24 |  |  |  |  |  |
| Long-term receivables sales proceeds | 41 |  |  | 21 |  |  |  |  |  |
| Total proceeds from sales of accounts receivable | $ | 109 |  |  | $ | 45 |  |  |  |  |  |

[0000068505-20-000013:mdna:119]
[same as prior period, unchanged from 0000068505-19-000025:mdna:190]

[0000068505-20-000013:mdna:120]
[same as prior period, unchanged from 0000068505-19-000025:mdna:191]

[0000068505-20-000013:mdna:121]
We had outstanding long-term debt of $5.9 billion and $5.1 billion, including the current portions of $814 million and $16 million at March 28, 2020 and December 31, 2019, respectively.

[0000068505-20-000013:mdna:122]
We have a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, we borrowed $800 million under the facility to bolster our cash holdings out of precaution, of which, $800 million was outstanding as of March 28, 2020.  The weighted average borrowing rate on outstanding amounts was 2.35%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of March 28, 2020.

[0000068505-20-000013:mdna:123]
[same as prior period, unchanged from 0000068505-19-000025:mdna:200]

[0000068505-20-000013:mdna:124]
We have an unsecured commercial paper program, backed by the revolving credit facility, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time.  Proceeds from the issuances of the notes are expected to be used for general corporate purposes.  As of March 28, 2020 we had no outstanding debt under the commercial paper program.

[0000068505-20-000013:mdna:125]
[same as prior period, unchanged from 0000068505-19-000025:mdna:202]

[0000068505-20-000013:mdna:126]
[same as prior period, unchanged from 0000068505-19-000025:mdna:205]

[0000068505-20-000013:mdna:127]
During the three months ended March 28, 2020, we paid an aggregate of $253 million, including transaction costs, to repurchase approximately 1.6 million shares at an average price of $162.85 per share. As of March 28, 2020, the Company had used approximately $13.0 billion of the share repurchase authority to repurchase shares, leaving $1.0 billion of authority available for future repurchases.

[0000068505-20-000013:mdna:128]
[same as prior period, unchanged from 0000068505-19-000025:mdna:207]

[0000068505-20-000013:mdna:129]
During both the first quarter of 2020 and subsequent to the quarter, we paid $109 million in cash dividends to holders of our common stock.

[0000068505-20-000013:mdna:130]
[same as prior period, unchanged from 0000068505-19-000025:mdna:209]

[0000068505-20-000013:mdna:131]
We had outstanding commitments to provide long-term financing to third parties totaling $94 million at March 28, 2020, compared to $78 million at December 31, 2019.

[0000068505-20-000013:mdna:132]
[same as prior period, unchanged from 0000068505-19-000025:mdna:211]

[0000068505-20-000013:mdna:133]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and simplifying other areas of accounting for income taxes.  The ASU is effective on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  We are still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-20-000013:mdna:134]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-20-000013:mdna:135]
Recently Adopted Accounting Pronouncements

[0000068505-20-000013:mdna:136]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires us to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition

[0000068505-20-000013:mdna:137]
Relief," and ASU No. 2019-11," Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU.  We adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.

[0000068505-20-000013:mdna:138]
We considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. We estimate credit losses on accounts receivable based on historical losses and then take into account estimates of current and future economic conditions. Our historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (direct and indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact on our financial statements.

[0000068505-20-000013:mdna:139]
[same as prior period, unchanged from 0000068505-19-000025:mdna:28]
