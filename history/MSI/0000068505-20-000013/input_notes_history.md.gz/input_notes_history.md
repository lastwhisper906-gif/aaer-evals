# MSI note change history — 0000068505-19-000025 → 0000068505-20-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-05-08):
[0000068505-20-000013:note_history:1]
Commitments and ContingenciesLegal MattersOn February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in it's trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million.  A motion for a new trial was filed by Hytera subsequent to the quarter.

- removed (2020-05-08):
[0000068505-19-000025:note_history:2]
Commitments and Contingencies
Legal Matters

- removed (2020-05-08):
[0000068505-19-000025:note_history:3]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

- removed (2020-05-08):
[0000068505-19-000025:note_history:4]
Other Indemnifications

- removed (2020-05-08):
[0000068505-19-000025:note_history:5]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

- removed (2020-05-08):
[0000068505-19-000025:note_history:6]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000068505-20-000013:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of March 28, 2020 and for the three months ended March 28, 2020 and March 30, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2019-10-31, similarity 0.8079):
[0000068505-19-000025:note_history:7]
The condensed consolidated financial statements as of September 28, 2019 and for the three and nine months ended September 28, 2019 and September 29, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2020-05-08):
[0000068505-20-000013:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three months ended March 28, 2020 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2019-10-31, similarity 0.9579):
[0000068505-19-000025:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three and nine months ended September 28, 2019 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2020-05-08):
[0000068505-20-000013:note_history:9]
Recent Acquisitions and Developments
  (was, 2019-10-31, similarity 0.6909):
[0000068505-19-000025:note_history:9]
Recent Acquisitions

- added (2020-05-08):
[0000068505-20-000013:note_history:10]
On March 17, 2020, the Company announced the proposed acquisition of IndigoVision Group plc ("IndigoVision") for a purchase price of approximately $37 million in cash. The proposed acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The proposed acquisition is subject to customary closing conditions for a UK public transaction and is expected to close in the second quarter of 2020.

- added (2020-05-08):
[0000068505-20-000013:note_history:11]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years.  The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

- added (2020-05-08):
[0000068505-20-000013:note_history:12]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances the Company's video security platform by adding data to the Company’s existing license plate recognition (“LPR”) database within the Software and Services segment.

- changed (2020-05-08):
[0000068505-20-000013:note_history:13]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.
  (was, 2019-10-31, similarity 0.8712):
[0000068505-19-000025:note_history:13]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security solutions platform.

- changed (2020-05-08):
[0000068505-20-000013:note_history:14]
On March 11, 2019, the Company acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.
  (was, 2019-10-31, similarity 0.8668):
[0000068505-19-000025:note_history:14]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities.

- changed (2020-05-08):
[0000068505-20-000013:note_history:15]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.
  (was, 2019-10-31, similarity 0.8475):
[0000068505-19-000025:note_history:15]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million.

- changed (2020-05-08):
[0000068505-20-000013:note_history:16]
Change in presentation
  (was, 2019-10-31, similarity 0.6977):
[0000068505-19-000025:note_history:16]
Basis of Presentation

- added (2020-05-08):
[0000068505-20-000013:note_history:17]
During the first quarter of 2020, the Company restructured its operations to realize more operational efficiencies, combining EMEA, AP and LA into one region which is now reflected as "International."  Accordingly, the Company now reports net sales in the following two geographic regions: North America, which includes the United States and Canada, and International. The Company has updated all periods presented to reflect this change in presentation.

- added (2020-05-08):
[0000068505-20-000013:note_history:18]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes.  The ASU is effective

- added (2020-05-08):
[0000068505-20-000013:note_history:19]
for the Company on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  The Company is still evaluating the impact of adoption on its financial statements and disclosures.

- changed (2020-05-08):
[0000068505-20-000013:note_history:20]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11," Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.
  (was, 2019-10-31, similarity 0.6416):
[0000068505-19-000025:note_history:20]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020 and requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

- added (2020-05-08):
[0000068505-20-000013:note_history:21]
The Company considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (Direct and Indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact to the Company's financial statements.

- added (2020-05-08):
[0000068505-20-000013:note_history:22]
The following table displays the rollforward of the allowance for credit losses on the Company's trade receivables:

- added (2020-05-08):
[0000068505-20-000013:note_history:23]
| Allowance for Credit Losses | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at March 28, 2020 |
| 2020 | $ | 63 |  | $ | 11 |  | $ | (5) |  | $ | (2) |  | $ | 67 |  |

- added (2020-05-08):
[0000068505-20-000013:note_history:24]
*Adjustments include translation adjustments

- removed (2020-05-08):
[0000068505-19-000025:note_history:25]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash, net of cash acquired, debt assumed, and transaction costs paid.

- removed (2020-05-08):
[0000068505-19-000025:note_history:26]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash, net of cash acquired. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.

- removed (2020-05-08):
[0000068505-19-000025:note_history:27]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

- removed (2020-05-08):
[0000068505-19-000025:note_history:28]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1, 2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

- removed (2020-05-08):
[0000068505-19-000025:note_history:29]
ASC 842 provides for a number of optional practical expedients in transition. The Company elected the practical expedients, which permit the Company to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. The Company did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing it to carry forward the lease term as determined prior to adoption of ASC 842. Finally, the Company also elected the practical expedient related to land easements, which enabled it to continue its accounting treatment for land easements on existing agreements as of January 1, 2019.

- removed (2020-05-08):
[0000068505-19-000025:note_history:30]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. The Company elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows the Company to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with the Company’s prior accounting. The Company also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

- removed (2020-05-08):
[0000068505-19-000025:note_history:31]
As of January 1, 2019, the Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition.

- removed (2020-05-08):
[0000068505-19-000025:note_history:32]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000068505-20-000013:note_history:33]
|  | March 28, 2020 |  | December 31, 2019 |
| $2.2 billion revolving credit facility due April 2022 | $ | 800 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | 550 |  |  | 550 |  |
| 3.5% senior notes due 2023 | 597 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 593 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 990 |  |  | 988 |  |
| 6.5% debentures due 2025 | 72 |  |  | 72 |  |
| 7.5% debentures due 2025 | 254 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 28 |  |  | 35 |  |
|  | 5,928 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3) |  |  | (3) |  |
| Less: current portion | (814) |  |  | (16) |  |
| Long-term debt | $ | 5,111 |  |  | $ | 5,113 |  |
  (was, 2019-10-31, similarity 0.9008):
[0000068505-19-000025:note_history:33]
|  | September 28, 2019 |  | December 31, 2018 |
| Term Loan due 2021 | $ | — |  |  | $ | 399 |  |
| 3.5% senior notes due 2021 | — |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 1.75% senior convertible notes due 2024 | 987 |  |  | — |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 804 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 638 |  |  | 862 |  |
|  | 5,732 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3 | ) |  | (4 | ) |
| Less: current portion | (617 | ) |  | (31 | ) |
| Long-term debt | $ | 5,112 |  |  | $ | 5,289 |  |

- added (2020-05-08):
[0000068505-20-000013:note_history:34]
As of March 28, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution, of which, $800 million was outstanding as of March 28, 2020. The weighted average borrowing rate on outstanding amounts was 2.35%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 28, 2020.

- changed (2020-05-08):
[0000068505-20-000013:note_history:35]
As of March 28, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
The Company has an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 28, 2020 the Company had no outstanding debt under the commercial paper program.
  (was, 2019-10-31, similarity 0.911):
[0000068505-19-000025:note_history:35]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
During the third quarter of 2019, the Company established an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 28, 2019 the Company had no outstanding debt under the commercial paper program. Subsequent to the end of the quarter, the Company issued $265 million commercial paper under the program.

- removed (2020-05-08):
[0000068505-19-000025:note_history:36]
As of September 28, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 28, 2019. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2018 and September 28, 2019.

- removed (2020-05-08):
[0000068505-19-000025:note_history:37]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the three and nine months ended September 28, 2019 were 3.53% and 3.68%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed. During the three months ended September 28, 2019, the Company repaid all amounts borrowed under the Term Loan.

- removed (2020-05-08):
[0000068505-19-000025:note_history:38]
In May of 2019, the Company issued $650 million of 4.60% senior notes due 2029, receiving proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $43 million related to this repurchase in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.

- removed (2020-05-08):
[0000068505-19-000025:note_history:39]
In August of 2019, the Company issued a follow-on $150 million to the outstanding 4.60% senior notes due 2029, bringing the total outstanding principal to $800 million. The Company recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount outstanding of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding approximately $2 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $7 million related to this repurchase in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

- removed (2020-05-08):
[0000068505-19-000025:note_history:40]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% senior convertible notes ("Senior Convertible Notes") which were scheduled to mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes were convertible based on a conversion rate adjusted for dividends declared which automatically adjusts the exercise price. During the third quarter of 2018, the Company settled $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium.

- removed (2020-05-08):
[0000068505-19-000025:note_history:41]
During the third quarter of 2019, the remaining notes were convertible based on a conversion rate of 14.9186, adjusted for dividends declared, per $1,000 principal amount (equal to a conversion price of $67.03 per share). On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to settle the remaining $800 million in principal amount of the Senior Convertible Notes in two installments: (i) $200 million of principal notes were repurchased during the third quarter for an aggregate consideration of $526 million in cash, inclusive of the conversion premium and (ii) $600 million of principal paid in cash on October 7, 2019, subsequent to the quarter, with 5.5 million shares converted into common stock on September 5, 2019.  As of September 28, 2019, the Company reflected the principal amount of $600 million paid subsequent to the quarter as short term debt and recognized a gain of $4 million from the extinguishment of the 2.00% senior convertible notes in Other, net within Other income (expense) in the Condensed Consolidated Statement of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000068505-20-000013:note_history:42]
|  | March 28, 2020 |  | December 31, 2019 |
| $2.2 billion revolving credit facility due April 2022 | $ | 800 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | 550 |  |  | 550 |  |
| 3.5% senior notes due 2023 | 597 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 593 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 990 |  |  | 988 |  |
| 6.5% debentures due 2025 | 72 |  |  | 72 |  |
| 7.5% debentures due 2025 | 254 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 28 |  |  | 35 |  |
|  | 5,928 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3) |  |  | (3) |  |
| Less: current portion | (814) |  |  | (16) |  |
| Long-term debt | $ | 5,111 |  |  | $ | 5,113 |  |
  (was, 2019-10-31, similarity 0.9008):
[0000068505-19-000025:note_history:42]
|  | September 28, 2019 |  | December 31, 2018 |
| Term Loan due 2021 | $ | — |  |  | $ | 399 |  |
| 3.5% senior notes due 2021 | — |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 1.75% senior convertible notes due 2024 | 987 |  |  | — |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 804 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 638 |  |  | 862 |  |
|  | 5,732 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3 | ) |  | (4 | ) |
| Less: current portion | (617 | ) |  | (31 | ) |
| Long-term debt | $ | 5,112 |  |  | $ | 5,289 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000068505-20-000013:note_history:43]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 28, 2020 and March 30, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2019-10-31, similarity 0.9069):
[0000068505-19-000025:note_history:43]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 28, 2019 and September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2020-05-08):
[0000068505-20-000013:note_history:44]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  |  |  | March 30, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 748 |  |  | $ | 368 |  |  | $ | 755 |  |  | $ | 320 |  |
| International | 245 |  |  | 294 |  |  | 314 |  |  | 268 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 620 |  |  | $ | — |  |  | $ | 686 |  |  | $ | — |  |
| Systems and Systems Integration | 373 |  |  | — |  |  | 383 |  |  | — |  |
| Services | — |  |  | 493 |  |  | — |  |  | 452 |  |
| Software | — |  |  | 169 |  |  | — |  |  | 136 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 641 |  |  | $ | 621 |  |  | $ | 657 |  |  | $ | 553 |  |
| Indirect | 352 |  |  | 41 |  |  | 412 |  |  | 35 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
  (was, 2019-10-31, similarity 0.7403):
[0000068505-19-000025:note_history:44]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,050 |  |  | $ | 403 |  |  | $ | 957 |  |  | $ | 343 |  |
| EMEA | 182 |  |  | 201 |  |  | 199 |  |  | 189 |  |
| Asia Pacific | 117 |  |  | 41 |  |  | 132 |  |  | 42 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 896 |  |  | $ | — |  |  | $ | 828 |  |  | $ | — |  |
| Systems and Systems Integration | 453 |  |  | — |  |  | 460 |  |  | — |  |
| Services | — |  |  | 479 |  |  | — |  |  | 455 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 119 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 602 |  |  | $ | 811 |  |  | $ | 543 |  |
| Indirect | 489 |  |  | 43 |  |  | 477 |  |  | 31 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |

- removed (2020-05-08):
[0000068505-19-000025:note_history:45]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 2,832 |  |  | $ | 1,133 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 499 |  |  | 603 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 325 |  |  | 119 |  |  | 353 |  |  | 126 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 2,391 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 1,265 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 1,400 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 455 |  |  | — |  |  | 303 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,289 |  |  | $ | 1,737 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 1,367 |  |  | 118 |  |  | 1,261 |  |  | 74 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000068505-20-000013:note_history:46]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 28, 2020 and March 30, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2019-10-31, similarity 0.9069):
[0000068505-19-000025:note_history:46]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 28, 2019 and September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2020-05-08):
[0000068505-20-000013:note_history:47]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  |  |  | March 30, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 748 |  |  | $ | 368 |  |  | $ | 755 |  |  | $ | 320 |  |
| International | 245 |  |  | 294 |  |  | 314 |  |  | 268 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 620 |  |  | $ | — |  |  | $ | 686 |  |  | $ | — |  |
| Systems and Systems Integration | 373 |  |  | — |  |  | 383 |  |  | — |  |
| Services | — |  |  | 493 |  |  | — |  |  | 452 |  |
| Software | — |  |  | 169 |  |  | — |  |  | 136 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 641 |  |  | $ | 621 |  |  | $ | 657 |  |  | $ | 553 |  |
| Indirect | 352 |  |  | 41 |  |  | 412 |  |  | 35 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
  (was, 2019-10-31, similarity 0.7403):
[0000068505-19-000025:note_history:47]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,050 |  |  | $ | 403 |  |  | $ | 957 |  |  | $ | 343 |  |
| EMEA | 182 |  |  | 201 |  |  | 199 |  |  | 189 |  |
| Asia Pacific | 117 |  |  | 41 |  |  | 132 |  |  | 42 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 896 |  |  | $ | — |  |  | $ | 828 |  |  | $ | — |  |
| Systems and Systems Integration | 453 |  |  | — |  |  | 460 |  |  | — |  |
| Services | — |  |  | 479 |  |  | — |  |  | 455 |  |
| Software | — |  |  | 166 |  |  | — |  |  | 119 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 860 |  |  | $ | 602 |  |  | $ | 811 |  |  | $ | 543 |  |
| Indirect | 489 |  |  | 43 |  |  | 477 |  |  | 31 |  |
|  | $ | 1,349 |  |  | $ | 645 |  |  | $ | 1,288 |  |  | $ | 574 |  |

- changed (2020-05-08):
[0000068505-20-000013:note_history:48]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 28, 2020 is $6.7 billion. A total of $2.9 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion is from Software and Services performance obligations that are not yet satisfied as of March 28, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2019-10-31, similarity 0.8054):
[0000068505-19-000025:note_history:48]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of September 28, 2019 is $7.1 billion. A total of $3.2 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.9 billion is from Services and Software performance obligations that are not yet satisfied as of September 28, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- added (2020-05-08):
[0000068505-20-000013:note_history:49]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,122 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 958 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,278 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 264 |  |  | 274 |  |  |  |  |  |

- added (2020-05-08):
[0000068505-20-000013:note_history:50]
Revenue recognized during the three months ended March 28, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $382 million, compared to $393 million of revenue recognized during the three months ended March 30, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $19 million was reversed during the three months ended March 28, 2020, compared to $9 million of reversals for the three months ended March 30, 2019.

- changed (2020-05-08):
[0000068505-20-000013:note_history:51]
There were no material expected credit losses recognized on contract assets during the three months ended March 28, 2020 and March 30, 2019.
  (was, 2019-10-31, similarity 0.8148):
[0000068505-19-000025:note_history:51]
There were no material impairment losses recognized on contract assets during the three and nine months ended September 28, 2019 and September 29, 2018.

- changed (2020-05-08):
[0000068505-20-000013:note_history:52]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 21 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 99 |  |  | 107 |  |  |  |  |  |
  (was, 2019-10-31, similarity 0.8882):
[0000068505-19-000025:note_history:52]
|  | September 28, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 28 |  |  | $ | 30 |  |
| Non-current contract cost assets | 102 |  |  | 98 |  |

- added (2020-05-08):
[0000068505-20-000013:note_history:53]
Amortization of non-current contract cost assets was $11 million for the three months ended March 28, 2020 and March 30, 2019.

- removed (2020-05-08):
[0000068505-19-000025:note_history:54]
|  | Nine Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 2,832 |  |  | $ | 1,133 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 499 |  |  | 603 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 325 |  |  | 119 |  |  | 353 |  |  | 126 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 2,391 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 1,265 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 1,400 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 455 |  |  | — |  |  | 303 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 2,289 |  |  | $ | 1,737 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 1,367 |  |  | 118 |  |  | 1,261 |  |  | 74 |  |
|  | $ | 3,656 |  |  | $ | 1,855 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |

- removed (2020-05-08):
[0000068505-19-000025:note_history:55]
|  | September 28, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,295 |  |  | $ | 1,293 |  |
| Contract assets | 921 |  |  | 1,012 |  |
| Contract liabilities | 1,223 |  |  | 1,263 |  |
| Non-current contract liabilities | 253 |  |  | 214 |  |

- removed (2020-05-08):
[0000068505-19-000025:note_history:56]
Revenue recognized during the three months ended September 28, 2019 which was previously included in Contract liabilities as of June 29, 2019 is $342 million, compared to $327 million of revenue recognized during the three months ended September 29, 2018 which was previously included in Contract liabilities as of July 1, 2018. Revenue recognized during the nine months ended September 28, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $783 million, compared to $777 million of revenue recognized during the nine months ended September 29, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $26 million and $42 million was reversed during the three and nine months ended September 28, 2019, respectively, which were primarily driven by changes in the estimates of progress on two Americas system contracts, compared to $7 million and $4 million of reversals for the three and nine months ended September 29, 2018, respectively.

- removed (2020-05-08):
[0000068505-19-000025:note_history:57]
Amortization of non-current contract cost assets was $10 million and $11 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $32 million and $34 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.
