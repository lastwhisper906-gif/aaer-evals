# MSI notes — 0000068505-20-000013


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-20-000013:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of March 28, 2020 and for the three months ended March 28, 2020 and March 30, 2019 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-20-000013:notes:2]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2019. The results of operations for the three months ended March 28, 2020 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-20-000013:notes:3]
[same as prior period, unchanged from 0000068505-19-000025:notes:4]

[0000068505-20-000013:notes:4]
Recent Acquisitions and Developments

[0000068505-20-000013:notes:5]
On March 17, 2020, the Company announced the proposed acquisition of IndigoVision Group plc ("IndigoVision") for a purchase price of approximately $37 million in cash. The proposed acquisition complements the Company's video security and analytics portfolio, providing enhanced geographical reach across a wider customer base. The proposed acquisition is subject to customary closing conditions for a UK public transaction and is expected to close in the second quarter of 2020.

[0000068505-20-000013:notes:6]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years.  The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-20-000013:notes:7]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances the Company's video security platform by adding data to the Company’s existing license plate recognition (“LPR”) database within the Software and Services segment.

[0000068505-20-000013:notes:8]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000013:notes:9]
On March 11, 2019, the Company acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000013:notes:10]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's video security platform within both the Product and Systems Integration segment and the Software and Services segment.

[0000068505-20-000013:notes:11]
Change in presentation

[0000068505-20-000013:notes:12]
During the first quarter of 2020, the Company restructured its operations to realize more operational efficiencies, combining EMEA, AP and LA into one region which is now reflected as "International."  Accordingly, the Company now reports net sales in the following two geographic regions: North America, which includes the United States and Canada, and International. The Company has updated all periods presented to reflect this change in presentation.

[0000068505-20-000013:notes:13]
[same as prior period, unchanged from 0000068505-19-000025:notes:11]

[0000068505-20-000013:notes:14]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes.  The ASU is effective

[0000068505-20-000013:notes:15]
for the Company on January 1, 2021 with early adoption permitted.  Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods.  The Company is still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-20-000013:notes:16]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-20-000013:notes:17]
Recently Adopted Accounting Pronouncements

[0000068505-20-000013:notes:18]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11," Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which provided additional implementation guidance on the previously issued ASU. The Company adopted ASC 326 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information will not be updated and disclosures required under ASC 326 will not be provided for dates and periods before January 1, 2020.

[0000068505-20-000013:notes:19]
The Company considered the impact of adoption by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (Direct and Indirect) and the geographic region (North America and International). The adoption of this standard did not have a material impact to the Company's financial statements.

[0000068505-20-000013:notes:20]
The following table displays the rollforward of the allowance for credit losses on the Company's trade receivables:

[0000068505-20-000013:notes:21]
| Allowance for Credit Losses | Balance at January 1, 2020 | Charged to Earnings | Used | Adjustments* | Balance at March 28, 2020 |
| 2020 | $ | 63 |  | $ | 11 |  | $ | (5) |  | $ | (2) |  | $ | 67 |  |

[0000068505-20-000013:notes:22]
*Adjustments include translation adjustments


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-20-000013:notes:23]
[same as prior period, unchanged from 0000068505-19-000025:notes:21]

[0000068505-20-000013:notes:24]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 28, 2020 and March 30, 2019, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-20-000013:notes:25]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  |  |  | March 30, 2019 |  |  |
|  | Products and Systems Integration |  | Software and Services |  | Products and Systems Integration |  | Software and Services |
| Regions: |  |  |  |  |  |  |  |
| North America | $ | 748 |  |  | $ | 368 |  |  | $ | 755 |  |  | $ | 320 |  |
| International | 245 |  |  | 294 |  |  | 314 |  |  | 268 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 620 |  |  | $ | — |  |  | $ | 686 |  |  | $ | — |  |
| Systems and Systems Integration | 373 |  |  | — |  |  | 383 |  |  | — |  |
| Services | — |  |  | 493 |  |  | — |  |  | 452 |  |
| Software | — |  |  | 169 |  |  | — |  |  | 136 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 641 |  |  | $ | 621 |  |  | $ | 657 |  |  | $ | 553 |  |
| Indirect | 352 |  |  | 41 |  |  | 412 |  |  | 35 |  |
|  | $ | 993 |  |  | $ | 662 |  |  | $ | 1,069 |  |  | $ | 588 |  |

[0000068505-20-000013:notes:26]
[same as prior period, unchanged from 0000068505-19-000025:notes:25]

[0000068505-20-000013:notes:27]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 28, 2020 is $6.7 billion. A total of $2.9 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.4 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.8 billion is from Software and Services performance obligations that are not yet satisfied as of March 28, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-20-000013:notes:28]
[same as prior period, unchanged from 0000068505-19-000025:notes:27]

[0000068505-20-000013:notes:29]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Accounts receivable, net | $ | 1,122 |  |  | $ | 1,412 |  |  |  |  |  |
| Contract assets | 958 |  |  | 1,046 |  |  |  |  |  |
| Contract liabilities | 1,278 |  |  | 1,449 |  |  |  |  |  |
| Non-current contract liabilities | 264 |  |  | 274 |  |  |  |  |  |

[0000068505-20-000013:notes:30]
Revenue recognized during the three months ended March 28, 2020 which was previously included in Contract liabilities as of December 31, 2019 is $382 million, compared to $393 million of revenue recognized during the three months ended March 30, 2019 which was previously included in Contract liabilities as of December 31, 2018. Revenue of $19 million was reversed during the three months ended March 28, 2020, compared to $9 million of reversals for the three months ended March 30, 2019.

[0000068505-20-000013:notes:31]
There were no material expected credit losses recognized on contract assets during the three months ended March 28, 2020 and March 30, 2019.

[0000068505-20-000013:notes:32]
[same as prior period, unchanged from 0000068505-19-000025:notes:31]

[0000068505-20-000013:notes:33]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Current contract cost assets | $ | 21 |  |  | $ | 24 |  |  |  |  |  |
| Non-current contract cost assets | 99 |  |  | 107 |  |  |  |  |  |

[0000068505-20-000013:notes:34]
Amortization of non-current contract cost assets was $11 million for the three months ended March 28, 2020 and March 30, 2019.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-20-000013:notes:35]
Leases
The components of the Company's lease expense are as follows:

[0000068505-20-000013:notes:36]
|  |  |  |  | Three months ended |  |  |
| (in millions) |  |  |  | March 28, 2020 |  | March 30, 2019 |
| Lease expense: |  |  |  |  |  |  |
| Operating lease cost |  |  |  | $ | 34 |  |  | $ | 33 |  |
| Finance lease cost |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  |  | 3 |  |  | 3 |  |
| Interest on lease liabilities |  |  |  | — |  |  | 1 |  |
| Total finance lease cost |  |  |  | 3 |  |  | 4 |  |
| Short-term lease cost |  |  |  | — |  |  | 2 |  |
| Variable cost |  |  |  | 8 |  |  | 9 |  |
| Sublease income |  |  |  | (1) |  |  | (1) |  |
| Net lease expense |  |  |  | $ | 44 |  |  | $ | 47 |  |

[0000068505-20-000013:notes:37]
[same as prior period, unchanged from 0000068505-19-000025:notes:41]

[0000068505-20-000013:notes:38]
| (in millions) |  | Statement Line Classification |  | March 28, 2020 |  | December 31, 2019 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 521 |  |  | $ | 554 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 33 |  |  | 41 |  |  |  |
|  |  |  |  | $ | 554 |  |  | $ | 595 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 119 |  |  | $ | 122 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 11 |  |  | 13 |  |  |  |
|  |  |  |  | $ | 130 |  |  | $ | 135 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 458 |  |  | $ | 497 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 11 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 469 |  |  | $ | 513 |  |  |  |

[0000068505-20-000013:notes:39]
[same as prior period, unchanged from 0000068505-19-000025:notes:43]

[0000068505-20-000013:notes:40]
|  | Three months ended |  |  |  |  |
| (in millions) | March 28, 2020 |  | March 30, 2019 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 37 |  |  | $ | 33 |  |  |  |
| Net cash used for operating activities related to finance leases | — |  |  | 1 |  |  |  |
| Net cash used for financing activities related to finance leases | 3 |  |  | 4 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 19 |  |  | $ | 27 |  |  |  |

[0000068505-20-000013:notes:41]
| (in millions) | March 28, 2020 |  | December 31, 2019 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 7 |  | 7 |
| Finance leases | 2 |  | 2 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.64 | % |  | 3.61 | % |
| Finance leases | 4.27 | % |  | 4.28 | % |

[0000068505-20-000013:notes:42]
Future lease payments as of March 28, 2020 are as follows:

[0000068505-20-000013:notes:43]
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2020 | $ | 104 |  |  | $ | 9 |  |  | $ | 113 |  |
| 2021 | 127 |  |  | 10 |  |  | 137 |  |
| 2022 | 112 |  |  | 4 |  |  | 116 |  |
| 2023 | 65 |  |  | 1 |  |  | 66 |  |
| 2024 | 54 |  |  | — |  |  | 54 |  |
| Thereafter | 201 |  |  | — |  |  | 201 |  |
| Total lease payments | 663 |  |  | 24 |  |  | 687 |  |
| Less: interest | 86 |  |  | 2 |  |  | 88 |  |
| Present value of lease liabilities | $ | 577 |  |  | $ | 22 |  |  | $ | 599 |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-20-000013:notes:44]
The components of the Company's lease expense are as follows:


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-20-000013:notes:45]
[same as prior period, unchanged from 0000068505-19-000025:notes:51]

[0000068505-20-000013:notes:46]
[same as prior period, unchanged from 0000068505-19-000025:notes:52]

[0000068505-20-000013:notes:47]
[same as prior period, unchanged from 0000068505-19-000025:notes:53]

[0000068505-20-000013:notes:48]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 53 |  |  | $ | 50 |  |  |  |  |  |
| Reorganization of business (Note 14) | 12 |  |  | 4 |  |  |  |  |  |
| Loss (gain) on legal settlements | 2 |  |  | (1) |  |  |  |  |  |
| Gain on sale of property, plant and equipment | (50) |  |  | — |  |  |  |  |  |
| Acquisition-related transaction fees | 2 |  |  | 2 |  |  |  |  |  |
|  | $ | 19 |  |  | $ | 55 |  |  |  |  |  |

[0000068505-20-000013:notes:49]
During the three months ended March 28, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe.  This gain has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-20-000013:notes:50]
[same as prior period, unchanged from 0000068505-19-000025:notes:57]

[0000068505-20-000013:notes:51]
[same as prior period, unchanged from 0000068505-19-000025:notes:58]

[0000068505-20-000013:notes:52]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (55) |  |  | $ | (60) |  |  |  |  |  |
| Interest income | 3 |  |  | 5 |  |  |  |  |  |
|  | $ | (52) |  |  | $ | (55) |  |  |  |  |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) |  | $ | 20 |  |  | $ | 16 |  |  |  |  |  |
| Investment impairments | — |  |  | (8) |  |  |  |  |  |
| Foreign currency gain (loss) |  | 18 |  |  | (4) |  |  |  |  |  |
| Loss on derivative instruments | (16) |  |  | (4) |  |  |  |  |  |
| Gains on equity method investments |  | 1 |  |  | 1 |  |  |  |  |  |
| Fair value adjustments to equity investments | 1 |  |  | (1) |  |  |  |  |  |
| Other | (7) |  |  | 10 |  |  |  |  |  |
|  | $ | 17 |  |  | $ | 10 |  |  |  |  |  |

[0000068505-20-000013:notes:53]
[same as prior period, unchanged from 0000068505-19-000025:notes:62]

[0000068505-20-000013:notes:54]
[same as prior period, unchanged from 0000068505-19-000025:notes:63]

[0000068505-20-000013:notes:55]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings |  | $ | 197 |  |  | $ | 151 |  |  |  |  |  |
| Weighted average common shares outstanding | 170.6 |  |  | 164.0 |  |  |  |  |  |
| Per share amount | $ | 1.15 |  |  | $ | 0.92 |  |  |  |  |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings |  | $ | 197 |  |  | $ | 151 |  |  |  |  |  |
| Weighted average common shares outstanding | 170.6 |  |  | 164.0 |  |  |  |  |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 5.3 |  |  | 4.9 |  |  |  |  |  |
| 2.00% senior convertible notes | — |  |  | 5.7 |  |  |  |  |  |
| 1.75% senior convertible notes | — |  |  | — |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 175.9 |  |  | 174.6 |  |  |  |  |  |
| Per share amount | $ | 1.12 |  |  | $ | 0.86 |  |  |  |  |  |

[0000068505-20-000013:notes:56]
For the three months ended March 28, 2020, the assumed exercise of 0.2 million employee stock options, were excluded because their inclusion would have been antidilutive. For the three months ended March 30, 2019, the assumed exercise of 0.5 million options, including 0.2 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-20-000013:notes:57]
As of March 28, 2020, the Company had  $1.0 billion of 1.75% senior convertible notes outstanding which mature in September 15, 2024 ("New Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the New Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the New Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock

[0000068505-20-000013:notes:58]
method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. For the period ended March 28, 2020, there was no dilutive effect of the New Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price. See further discussion in Note 5.

[0000068505-20-000013:notes:59]
[same as prior period, unchanged from 0000068505-19-000025:notes:69]

[0000068505-20-000013:notes:60]
[same as prior period, unchanged from 0000068505-19-000025:notes:70]

[0000068505-20-000013:notes:61]
[same as prior period, unchanged from 0000068505-19-000025:notes:71]

[0000068505-20-000013:notes:62]
|  | March 28, 2020 |  | December 31, 2019 |
| Accounts receivable | $ | 1,189 |  |  | $ | 1,475 |  |
| Less allowance for credit losses | (67) |  |  | (63) |  |
|  | $ | 1,122 |  |  | $ | 1,412 |  |

[0000068505-20-000013:notes:63]
[same as prior period, unchanged from 0000068505-19-000025:notes:73]

[0000068505-20-000013:notes:64]
[same as prior period, unchanged from 0000068505-19-000025:notes:74]

[0000068505-20-000013:notes:65]
|  | March 28, 2020 |  | December 31, 2019 |
| Finished goods | $ | 214 |  |  | $ | 209 |  |
| Work-in-process and production materials | 363 |  |  | 374 |  |
|  | 577 |  |  | 583 |  |
| Less inventory reserves | (135) |  |  | (136) |  |
|  | $ | 442 |  |  | $ | 447 |  |

[0000068505-20-000013:notes:66]
[same as prior period, unchanged from 0000068505-19-000025:notes:76]

[0000068505-20-000013:notes:67]
[same as prior period, unchanged from 0000068505-19-000025:notes:77]

[0000068505-20-000013:notes:68]
|  | March 28, 2020 |  | December 31, 2019 |
| Current contract cost assets (Note 2) | $ | 21 |  |  | $ | 24 |  |
| Tax-related deposits | 60 |  |  | 77 |  |
| Other | 206 |  |  | 171 |  |
|  | $ | 287 |  |  | $ | 272 |  |

[0000068505-20-000013:notes:69]
[same as prior period, unchanged from 0000068505-19-000025:notes:79]

[0000068505-20-000013:notes:70]
[same as prior period, unchanged from 0000068505-19-000025:notes:80]

[0000068505-20-000013:notes:71]
|  | March 28, 2020 |  | December 31, 2019 |
| Land | $ | 6 |  |  | $ | 15 |  |
| Leasehold improvements | 379 |  |  | 410 |  |
| Machinery and equipment | 1,997 |  |  | 2,051 |  |
|  | 2,382 |  |  | 2,476 |  |
| Less accumulated depreciation | (1,450) |  |  | (1,484) |  |
|  | $ | 932 |  |  | $ | 992 |  |

[0000068505-20-000013:notes:72]
Depreciation expense for the three months ended March 28, 2020 and March 30, 2019 was $46 million and $45 million, respectively.

[0000068505-20-000013:notes:73]
[same as prior period, unchanged from 0000068505-19-000025:notes:83]

[0000068505-20-000013:notes:74]
[same as prior period, unchanged from 0000068505-19-000025:notes:84]

[0000068505-20-000013:notes:75]
|  | March 28, 2020 |  | December 31, 2019 |  |  |  |  |
| Common stock | $ | 21 |  |  | $ | 25 |  |  |  |  |  |
| Strategic investments, at cost | 44 |  |  | 40 |  |  |  |  |  |
| Company-owned life insurance policies | 68 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 21 |  |  | 20 |  |  |  |  |  |
|  | $ | 154 |  |  | $ | 159 |  |  |  |  |  |

[0000068505-20-000013:notes:76]
During the three months ended March 30, 2019, the Company recorded an investment impairment charge of $8 million, representing other-than-temporary declines in the value in the Company's Strategic investment portfolio. Investment impairment charges are included in Other within Other income (expense) in the Company’s Condensed Consolidated Statements of Operations.

[0000068505-20-000013:notes:77]
[same as prior period, unchanged from 0000068505-19-000025:notes:93]

[0000068505-20-000013:notes:78]
|  | March 28, 2020 |  | December 31, 2019 |
| Defined benefit plan assets | $ | 236 |  |  | $ | 223 |  |
| Non-current contract cost assets (Note 2) | 99 |  |  | 107 |  |
| Other | 58 |  |  | 92 |  |
|  | $ | 393 |  |  | $ | 422 |  |

[0000068505-20-000013:notes:79]
[same as prior period, unchanged from 0000068505-19-000025:notes:95]

[0000068505-20-000013:notes:80]
[same as prior period, unchanged from 0000068505-19-000025:notes:96]

[0000068505-20-000013:notes:81]
|  | March 28, 2020 |  | December 31, 2019 |
| Compensation | $ | 361 |  |  | $ | 347 |  |
| Tax liabilities | 48 |  |  | 95 |  |
| Dividend payable | 109 |  |  | 110 |  |
| Trade liabilities | 144 |  |  | 161 |  |
| Operating lease liabilities (Note 3) | 119 |  |  | 122 |  |
| Other | 475 |  |  | 521 |  |
|  | $ | 1,256 |  |  | $ | 1,356 |  |

[0000068505-20-000013:notes:82]
[same as prior period, unchanged from 0000068505-19-000025:notes:98]

[0000068505-20-000013:notes:83]
[same as prior period, unchanged from 0000068505-19-000025:notes:99]

[0000068505-20-000013:notes:84]
|  | March 28, 2020 |  | December 31, 2019 |
| Defined benefit plans | $ | 1,490 |  |  | $ | 1,524 |  |
| Non-current contract liabilities (Note 2) | 264 |  |  | 274 |  |
| Unrecognized tax benefits | 55 |  |  | 53 |  |
| Deferred income taxes | 171 |  |  | 184 |  |
| Other | 218 |  |  | 241 |  |
|  | $ | 2,198 |  |  | $ | 2,276 |  |

[0000068505-20-000013:notes:85]
Stockholders’ Equity (Deficit)

[0000068505-20-000013:notes:86]
Share Repurchase Program: During the three months ended March 28, 2020, the Company paid an aggregate of $253 million, including transaction costs, to repurchase approximately 1.6 million shares at an average price of $162.85 per share. As of March 28, 2020, the Company had $1.0 billion of authority available for future repurchases.

[0000068505-20-000013:notes:87]
Payment of Dividends: During the three months ended March 28, 2020 and March 30, 2019, the Company paid $109 million and $93 million, respectively, in cash dividends to holders of its common stock.

[0000068505-20-000013:notes:88]
[same as prior period, unchanged from 0000068505-19-000025:notes:104]

[0000068505-20-000013:notes:89]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended March 28, 2020 and March 30, 2019:

[0000068505-20-000013:notes:90]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (410) |  |  | $ | (444) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | (136) |  |  | 34 |  |  |  |  |  |
| Tax expense | (2) |  |  | (4) |  |  |  |  |  |
| Other comprehensive income (loss), net of tax | (138) |  |  | 30 |  |  |  |  |  |
| Balance at end of period | $ | (548) |  |  | $ | (414) |  |  |  |  |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,030) |  |  | $ | (2,321) |  |  |  |  |  |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 19 |  |  | 17 |  |  |  |  |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4) |  |  | (4) |  |  |  |  |  |
| Tax expense | (3) |  |  | (2) |  |  |  |  |  |
| Other comprehensive income, net of tax | 12 |  |  | 11 |  |  |  |  |  |
| Balance at end of period | $ | (2,018) |  |  | $ | (2,310) |  |  |  |  |  |
| Total Accumulated other comprehensive loss | $ | (2,566) |  |  | $ | (2,724) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-20-000013:notes:91]
Debt and Credit Facilities

[0000068505-20-000013:notes:92]
|  | March 28, 2020 |  | December 31, 2019 |
| $2.2 billion revolving credit facility due April 2022 | $ | 800 |  |  | $ | — |  |
| 3.75% senior notes due 2022 | 550 |  |  | 550 |  |
| 3.5% senior notes due 2023 | 597 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 593 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 990 |  |  | 988 |  |
| 6.5% debentures due 2025 | 72 |  |  | 72 |  |
| 7.5% debentures due 2025 | 254 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 691 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 804 |  |  | 804 |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 28 |  |  | 35 |  |
|  | 5,928 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (3) |  |  | (3) |  |
| Less: current portion | (814) |  |  | (16) |  |
| Long-term debt | $ | 5,111 |  |  | $ | 5,113 |  |

[0000068505-20-000013:notes:93]
As of March 28, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 Pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution, of which, $800 million was outstanding as of March 28, 2020. The weighted average borrowing rate on outstanding amounts was 2.35%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 28, 2020.

[0000068505-20-000013:notes:94]
As of March 28, 2020, the Company had $1.0 billion of 1.75% senior convertible notes with Silver Lake, which mature in September 2024 ("New Senior Convertible Notes"). The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company has recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital. 
The Company has an unsecured commercial paper program, backed by the revolving credit facility, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component.  At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 28, 2020 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-20-000013:notes:95]
[same as prior period, unchanged from 0000068505-19-000025:notes:116]

[0000068505-20-000013:notes:96]
As of March 28, 2020, the Company had outstanding foreign exchange contracts with notional amounts totaling $989 million, compared to $1.1 billion outstanding at December 31, 2019. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-20-000013:notes:97]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of March 28, 2020, and the corresponding positions as of December 31, 2019:

[0000068505-20-000013:notes:98]
|  | Notional Amount |  |  |
| Net Buy (Sell) by Currency | March 28, 2020 |  | December 31, 2019 |
| Euro | $ | 228 |  |  | $ | 134 |  |
| Norwegian krone | 28 |  |  | 32 |  |
| Canadian dollar | 21 |  |  | 8 |  |
| Australian dollar | (93) |  |  | (123) |  |
| Chinese renminbi | (74) |  |  | (79) |  |

[0000068505-20-000013:notes:99]
[same as prior period, unchanged from 0000068505-19-000025:notes:120]

[0000068505-20-000013:notes:100]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of March 28, 2020, all of the counterparties have investment grade credit ratings. As of March 28, 2020, the Company had $24 million of exposure to aggregate credit risk with all counterparties.

[0000068505-20-000013:notes:101]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of March 28, 2020 and December 31, 2019:

[0000068505-20-000013:notes:102]
|  |  |  | Fair Values of Derivative Instruments |  |  |  |  |
| March 28, 2020 |  |  | Other Current Assets |  |  |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | $ | 18 |  |  |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | 6 |  |  |  |  | 6 |  |
| Total derivatives |  |  | $ | 24 |  |  |  |  | $ | 6 |  |

[0000068505-20-000013:notes:103]
|  |  |  | Fair Values of Derivative Instruments |  |  |  |  |
| December 31, 2019 |  |  | Other Current Assets |  |  |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | $ | 3 |  |  |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | 1 |  |  |  |  | 5 |  |
| Total derivatives |  |  | $ | 4 |  |  |  |  | $ | 5 |  |

[0000068505-20-000013:notes:104]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended March 28, 2020 and March 30, 2019:

[0000068505-20-000013:notes:105]
|  | Three Months Ended |  |  |  |  |  |  |  | Financial Statement Location |
| Foreign Exchange Contracts | March 28, 2020 |  | March 30, 2019 |  |  |  |  |  |  |
| Effective portion | $ | 19 |  |  | $ | 2 |  |  |  |  |  |  | Accumulated othercomprehensive income |
| Forward points recognized | 1 |  |  | 1 |  |  |  |  |  |  | Other income |
| Undesignated derivatives recognized | (16) |  |  | (4) |  |  |  |  |  |  | Other expense |

[0000068505-20-000013:notes:106]
[same as prior period, unchanged from 0000068505-19-000025:notes:127]

[0000068505-20-000013:notes:107]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. As of March 28, 2020, the Company had €94 million of net investment hedges in certain Euro functional subsidiaries and £100 million of net investment hedges in certain British pound functional subsidiaries.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-20-000013:notes:108]
[same as prior period, unchanged from 0000068505-19-000025:notes:129]

[0000068505-20-000013:notes:109]
[same as prior period, unchanged from 0000068505-19-000025:notes:130]

[0000068505-20-000013:notes:110]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Net earnings before income taxes | $ | 224 |  |  | $ | 185 |  |  |  |  |  |
| Income tax expense | 26 |  |  | 33 |  |  |  |  |  |
| Effective tax rate | 12 | % |  | 18 | % |  |  |  |  |

[0000068505-20-000013:notes:111]
During the three months ended March 28, 2020, the Company recorded $26 million of net tax expense, resulting in an effective tax rate of 12%. During the three months ended March 30, 2019, the Company recorded $33 million of net tax expense, resulting in an effective tax rate of 18%. The three months ended March 28, 2020 and March 30, 2019 effective tax rates are different from the U.S. federal statutory tax rate of 21% due to state tax expense, offset by excess tax benefits on share-based compensation.  The effective tax rate for the three months ended March 28, 2020 of 12% is lower than the effective tax rate for the three months ended March 30, 2019 of 18%, primarily due to a higher excess tax benefits on share-based compensation.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-20-000013:notes:112]
[same as prior period, unchanged from 0000068505-19-000025:notes:133]

[0000068505-20-000013:notes:113]
[same as prior period, unchanged from 0000068505-19-000025:notes:134]

[0000068505-20-000013:notes:114]
|  | U.S. Pension Benefit Plans |  |  |  | Non-U.S. Pension Benefit Plans |  |  |  | Postretirement Health Care Benefits Plan |  |  |
| Three Months Ended | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 36 |  |  | 51 |  |  | 7 |  |  | 10 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (56) |  |  | (69) |  |  | (22) |  |  | (21) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 14 |  |  | 12 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4) |  |  | (4) |  |
| Net periodic pension benefits | $ | (6) |  |  | $ | (6) |  |  | $ | (10) |  |  | $ | (6) |  |  | $ | (5) |  |  | $ | (5) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-20-000013:notes:115]
[same as prior period, unchanged from 0000068505-19-000025:notes:137]

[0000068505-20-000013:notes:116]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 5 |  |  | $ | 4 |  |  |  |  |  |
| Selling, general and administrative expenses | 21 |  |  | 16 |  |  |  |  |  |
| Research and development expenditures | 12 |  |  | 7 |  |  |  |  |  |
| Share-based compensation expense included in Operating earnings | 38 |  |  | 27 |  |  |  |  |  |
| Tax benefit | (7) |  |  | (6) |  |  |  |  |  |
| Share-based compensation expense, net of tax | $ | 31 |  |  | $ | 21 |  |  |  |  |  |
| Decrease in basic earnings per share | $ | (0.18) |  |  | $ | (0.13) |  |  |  |  |  |
| Decrease in diluted earnings per share | $ | (0.17) |  |  | $ | (0.12) |  |  |  |  |  |

[0000068505-20-000013:notes:117]
During the three months ended March 28, 2020, the Company granted 0.3 million restricted stock units ("RSUs"), 0.03 million performance stock units ("PSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $46 million, $7 million, and $9 million, respectively, and 0.1 million stock options and 0.1 million performance options ("POs") with an aggregate grant-date fair value of $5 million and $9 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years. 
The Company granted an additional 0.03 million of restricted stock in connection with the acquisition of a cybersecurity services business, with an aggregate grant-date fair value of $6 million related to compensation withheld from the purchase price that will be expensed over an average service period of two years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-20-000013:notes:118]
[same as prior period, unchanged from 0000068505-19-000025:notes:144]

[0000068505-20-000013:notes:119]
[same as prior period, unchanged from 0000068505-19-000025:notes:145]

[0000068505-20-000013:notes:120]
[same as prior period, unchanged from 0000068505-19-000025:notes:146]

[0000068505-20-000013:notes:121]
[same as prior period, unchanged from 0000068505-19-000025:notes:147]

[0000068505-20-000013:notes:122]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of March 28, 2020 and December 31, 2019 were as follows:

[0000068505-20-000013:notes:123]
| March 28, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 24 |  |  |  |  | $ | 24 |  |
| Common stock | 21 |  |  | — |  |  |  |  | 21 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  |  |  | $ | 6 |  |

[0000068505-20-000013:notes:124]
| December 31, 2019 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  |  |  | $ | 4 |  |
| Common stock | 25 |  |  | — |  |  |  |  | 25 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-20-000013:notes:125]
The Company had no Level 3 holdings as of March 28, 2020 or December 31, 2019.

[0000068505-20-000013:notes:126]
At March 28, 2020 and December 31, 2019, the Company had $914 million and $322 million, respectively, of investments in money market U.S. treasury and government funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-20-000013:notes:127]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at March 28, 2020 and December 31, 2019 was $5.9 billion and $5.5 billion (Level 2), respectively.

[0000068505-20-000013:notes:128]
[same as prior period, unchanged from 0000068505-19-000025:notes:154]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-20-000013:notes:129]
[same as prior period, unchanged from 0000068505-19-000025:notes:155]

[0000068505-20-000013:notes:130]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended March 28, 2020 and March 30, 2019:

[0000068505-20-000013:notes:131]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Accounts receivable sales proceeds | $ | 68 |  |  | $ | 24 |  |  |  |  |  |
| Long-term receivables sales proceeds | 41 |  |  | 21 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 109 |  |  | $ | 45 |  |  |  |  |  |

[0000068505-20-000013:notes:132]
At March 28, 2020, the Company had retained servicing obligations for $974 million of long-term receivables, compared to $984 million at December 31, 2019. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $94 million at March 28, 2020, compared to $78 million at December 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-20-000013:notes:133]
Commitments and ContingenciesLegal MattersOn February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois decided in the Company's favor in it's trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded Motorola Solutions $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million.  A motion for a new trial was filed by Hytera subsequent to the quarter.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-20-000013:notes:134]
[same as prior period, unchanged from 0000068505-19-000025:notes:164]

[0000068505-20-000013:notes:135]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Products and Systems Integration | $ | 993 |  |  | $ | 1,069 |  |  |  |  |  |
| Software and Services | 662 |  |  | 588 |  |  |  |  |  |
|  | $ | 1,655 |  |  | $ | 1,657 |  |  |  |  |  |

[0000068505-20-000013:notes:136]
[same as prior period, unchanged from 0000068505-19-000025:notes:166]

[0000068505-20-000013:notes:137]
|  | Three Months Ended |  |  |  |  |  |  |
|  | March 28, 2020 |  | March 30, 2019 |  |  |  |  |
| Products and Systems Integration | $ | 92 |  |  | $ | 108 |  |  |  |  |  |
| Software and Services | 167 |  |  | 121 |  |  |  |  |  |
| Operating earnings | 259 |  |  | 229 |  |  |  |  |  |
| Total other expense | (35) |  |  | (44) |  |  |  |  |  |
| Earnings before income taxes | $ | 224 |  |  | $ | 185 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-20-000013:notes:138]
Reorganization of Business
2020 Charges

[0000068505-20-000013:notes:139]
During the three months ended March 28, 2020, the Company recorded net reorganization of business charges of $18 million including $12 million of charges in Other charges and $6 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $18 million were charges of $22 million related to employee separation, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-20-000013:notes:140]
[same as prior period, unchanged from 0000068505-19-000025:notes:171]

[0000068505-20-000013:notes:141]
| March 28, 2020 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 14 |  |  |  |
| Software and Services | 4 |  |  |  |
|  | $ | 18 |  |  |  |

[0000068505-20-000013:notes:142]
The following table displays a rollforward of the reorganization of business accruals established for employee separation costs from January 1, 2020 to March 28, 2020:

[0000068505-20-000013:notes:143]
|  | January 1, 2020 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | March 28, 2020 |
| Employee separation costs | $ | 78 |  |  | $ | 22 |  |  | $ | (4) |  |  | $ | (22) |  |  | $ | 74 |  |

[0000068505-20-000013:notes:144]
[same as prior period, unchanged from 0000068505-19-000025:notes:175]

[0000068505-20-000013:notes:145]
At January 1, 2020, the Company had an accrual of $78 million for employee separation costs. The 2020 additional charges of $22 million represent severance costs for approximately 300 employees. The adjustment of $4 million reflects reversals for accruals no longer needed. The $22 million used reflects cash payments to severed employees. The remaining accrual of $74 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at March 28, 2020, is expected to be paid, primarily within one year, to approximately 900 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-20-000013:notes:146]
2019 Charges

[0000068505-20-000013:notes:147]
During the three months ended March 30, 2019, the Company recorded net reorganization of business charges of $8 million including $4 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $8 million were charges of $12 million related to employee separation costs and $4 million of reversals for accruals no longer needed.

[0000068505-20-000013:notes:148]
| March 30, 2019 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 7 |  |  |  |
| Software and Services | 1 |  |  |  |
|  | $ | 8 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-20-000013:notes:149]
Intangible Assets and Goodwill
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The company recognized $27 million of goodwill, $7 million of intangible assets and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts, intangible assets, goodwill and net liabilities may be subject to change based on the finalization of assumptions and settlement of working capital considerations.

[0000068505-20-000013:notes:150]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million in cash, net of cash acquired. The acquisition enhances the Company's video security platform by adding data to the Company’s existing LPR database within the Software and Services segment. The Company recognized $54 million of goodwill, $28 million of identifiable intangible assets, and $3 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $22 million of customer relationships and $6 million of developed technology and will be amortized over a period of sixteen years and five years, respectively. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000013:notes:151]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's video security solutions platform. The business will be part of both the Products and Systems Integration and Software and Services segments. The Company recognized $156 million of goodwill, $63 million of identifiable intangible assets, and $31 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of completed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-20-000013:notes:152]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Software and Services segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of 15 years. The purchase accounting was completed as of the third quarter of 2019.

[0000068505-20-000013:notes:153]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business will be part of both the Products and Systems Integration and Software and Services segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of 15 years. The purchase accounting was completed as of the first quarter of 2020.

[0000068505-20-000013:notes:154]
[same as prior period, unchanged from 0000068505-19-000025:notes:190]

[0000068505-20-000013:notes:155]
[same as prior period, unchanged from 0000068505-19-000025:notes:191]

[0000068505-20-000013:notes:156]
|  | March 28, 2020 |  |  |  | December 31, 2019 |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 736 |  |  | $ | 162 |  |  | $ | 738 |  |  | $ | 148 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,144 |  |  | 505 |  |  | 1,222 |  |  | 518 |  |
| Other intangibles | 72 |  |  | 43 |  |  | 75 |  |  | 42 |  |
|  | $ | 1,954 |  |  | $ | 712 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-20-000013:notes:157]
Amortization expense on intangible assets was $53 million for the three months ended March 28, 2020 and $50 million for the three months ended March 30, 2019. As of March 28, 2020, annual amortization expense is estimated to be $202 million in 2020, $198 million 2021, $195 million in 2022, $105 million in 2023, $82 million in 2024, and $72 million in 2025.

[0000068505-20-000013:notes:158]
[same as prior period, unchanged from 0000068505-19-000025:notes:194]

[0000068505-20-000013:notes:159]
|  | March 28, 2020 |  |  |  | December 31, 2019 |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 652 |  |  | $ | 94 |  |  | $ | 652 |  |  | $ | 82 |  |
| Software and Services | 1,302 |  |  | 618 |  |  | 1,385 |  |  | 628 |  |
|  | $ | 1,954 |  |  | $ | 712 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-20-000013:notes:160]
[same as prior period, unchanged from 0000068505-19-000025:notes:196]

[0000068505-20-000013:notes:161]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2020 to March 28, 2020:

[0000068505-20-000013:notes:162]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2020 | $ | 973 |  |  | $ | 1,094 |  |  | $ | 2,067 |  |
| Goodwill acquired | — |  |  | 27 |  |  | 27 |  |
| Foreign currency | — |  |  | (19) |  |  | (19) |  |
| Balance as of March 28, 2020 | $ | 973 |  |  | $ | 1,102 |  |  | $ | 2,075 |  |
