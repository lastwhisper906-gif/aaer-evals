# MSI MD&A — 0000068505-22-000019


## mdna

[0000068505-22-000019:mdna:1]
[same as prior period, unchanged from 0000068505-21-000027:mdna:1]

[0000068505-22-000019:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three months ended April 2, 2022 and April 3, 2021, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2021 (the "Form 10-K").

[0000068505-22-000019:mdna:3]
[same as prior period, unchanged from 0000068505-21-000027:mdna:3]

[0000068505-22-000019:mdna:4]
[same as prior period, unchanged from 0000068505-21-000027:mdna:4]

[0000068505-22-000019:mdna:5]
[same as prior period, unchanged from 0000068505-21-000027:mdna:5]

[0000068505-22-000019:mdna:6]
The Company reports net sales in the following three major products and services (which we refer to as “technologies” in this Form 10-Q): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control and Command Center Software. In January 2022 the Company renamed one of its three major products and services technologies from LMR Mission Critical Communications to LMR Communications in an effort to more succinctly brand its LMR technology. This change was to the name of the technology only and no financial information was reclassified from previous periods presented or for the quarter ended April 2, 2022.

[0000068505-22-000019:mdna:7]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

[0000068505-22-000019:mdna:8]
[same as prior period, unchanged from 0000068505-21-000027:mdna:8]

[0000068505-22-000019:mdna:9]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from "911 call to case closure."

[0000068505-22-000019:mdna:10]
First Quarter Financial Results

[0000068505-22-000019:mdna:11]
•Net sales were $1.9 billion in the first quarter of 2022 compared to $1.8 billion in the first quarter of 2021.

[0000068505-22-000019:mdna:12]
•Operating earnings were $239 million in the first quarter of 2022 compared to $298 million in the first quarter of 2021.

[0000068505-22-000019:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. were $267 million, or $1.54 per diluted common share, in the first quarter of 2022, compared to $244 million, or $1.41 per diluted common share, in the first quarter of 2021.

[0000068505-22-000019:mdna:14]
•Operating cash flow decreased $218 million to $152 million in the first quarter of 2022 compared to $370 million in the first quarter of 2021.

[0000068505-22-000019:mdna:15]
•We repurchased $493 million of common stock and paid $134 million in dividends in the first quarter of 2022.

[0000068505-22-000019:mdna:16]
Macroeconomic Events

[0000068505-22-000019:mdna:17]
Recent macroeconomic events impacting our business are discussed below. During the first quarter of 2022, we continued to operate under challenging market conditions, influenced by events such as the Russia-Ukraine conflict, the continuing impact of the COVID-19 pandemic, disruption to our supply chain and the inflationary cost environment.

[0000068505-22-000019:mdna:18]
Russia-Ukraine Conflict

[0000068505-22-000019:mdna:19]
In February 2022, Russia's invasion of Ukraine prompted the United States, the European Union and other countries to impose economic sanctions on Russia. During the first quarter of 2022, we suspended all sales, provision of services and shipments of our products to Russia and Belarus. Russia, Ukraine and Belarus do not constitute a material portion of our business. For the year ended December 31, 2021, our net sales in Russia and Belarus were less than $25 million. While we do not anticipate that the current posture of the Russia-Ukraine conflict will materially and adversely affect our results of operations, the conflict is still ongoing and future impacts are difficult to estimate. An escalation of the conflict’s current scope or expansion of the conflict’s economic disruption could materially and adversely affect our company and its operations. During the first quarter of 2022, we indirectly experienced impacts from the Russia-Ukraine conflict (as further described below). The conflict has and may continue to have a significant impact on the global macroeconomic and geopolitical environments, including increased volatility in capital and commodity markets, rapid changes to regulatory conditions (including the use of sanctions), supply chain and operational challenges for multinational corporations, inflationary pressures and an increased risk of cybersecurity incidents. For a more complete discussion of the risks we encounter in our business, please refer to Part I, Item 1A, "Risk Factors" in the Form 10-K and Part II, Item 1A, "Risk Factors" in this Form 10-Q.

[0000068505-22-000019:mdna:20]
COVID-19, Supply Chain Disruptions & Inflationary Cost Environment

[0000068505-22-000019:mdna:21]
The COVID-19 pandemic continues to be dynamic, and near-term challenges across the economy remain. The health and safety of our employees remains our top priority, and we continue to work to mitigate the impact of COVID-19 on our employees, customers, communities, liquidity and financial position.

[0000068505-22-000019:mdna:22]
As we have progressed throughout the first quarter of 2022, our supply chain has been increasingly impacted by global issues related to the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity (including indirectly as a result of the Russia-Ukraine conflict) and labor constraints. This has resulted in disruptions in our supply chain, as well as difficulties and delays in procuring certain semiconductor components. During the latter part of the fourth quarter of 2021 and continuing into the first quarter of 2022, cost increases were driven by elevated lead times and increased material costs, in particular the need to purchase semiconductor components from alternative sources, including brokers. We anticipate increased costs to procure materials within the semiconductor market to continue through the first half of 2022.  Further, we anticipate the broader impact of inflationary pressures and increased material and supply chain costs and disruptions to continue throughout 2022. We are closely monitoring our supply chain, including impacts from manufacturing lockdowns related to the spread of COVID-19 in China during the first quarter of 2022 which continue to disrupt the semiconductor supply market. Accordingly, in the first quarter of 2022 we focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages. We are actively managing our inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to our customers, and we expect to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-22-000019:mdna:23]
Although the macroeconomic environment continued to introduce challenges in the first quarter of 2022, we are encouraged by customer demand for our products and services. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impacts on net sales and operating margin will be limited throughout 2022. Within the Products and Systems Integration segment, while we are encouraged by strong LMR backlog and the resiliency of the Video Security and Access Control technology that experienced growth in the first quarter of 2022 and which we expect to continue to grow for the remainder of 2022, supply constraints continue to impact our LMR business and we expect demand for our products will continue to out-pace our ability to obtain semiconductor component supply throughout 2022. Where appropriate, we have established pricing adjustments to our product and service offerings to mitigate our exposure to inflationary pressures on our businesses and expect to benefit from these adjustments in the second half of 2022. Further, demand continues to be supported with ongoing sources of government funding. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We experienced the positive impact of the ARPA funding on our business and results of operations during the first quarter of 2022 and anticipate that the ARPA will continue to have a positive impact throughout the remainder of 2022.

[0000068505-22-000019:mdna:24]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of April 2, 2022. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-22-000019:mdna:25]
Lastly, we evaluated whether there were any impairment indicators as of April 2, 2022, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the first quarter of 2022, we concluded our assets were fairly stated and recoverable.

[0000068505-22-000019:mdna:26]
[same as prior period, unchanged from 0000068505-21-000027:mdna:26]

[0000068505-22-000019:mdna:27]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| LMR Communications | Software and Services | TETRA Ireland Communications Limited | Provider of Ireland's National Digital Radio Service. | $120 million | March 23, 2022 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Ava Security Limited | Provider of cloud-native video security and analytics. | $387 million and share-based awards of $7 million | March 3, 2022 |
| Command Center Software | Software and Services | 911 Datamaster, Inc. | Provider of Next Generation 911 data solutions that help to ensure emergency calls are accurately located and routed based on the caller's location. | $35 million and share-based compensation of $3 million | December 16, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Envysion, Inc. | Provider of enterprise video security and business analytics. | $124 million and share-based compensation of $1 million | October 29, 2021 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Openpath Security, Inc. | Provider of cloud-based mobile access control. | $298 million and share-based compensation of $29 million | July 15, 2021 |

[0000068505-22-000019:mdna:28]
28

[0000068505-22-000019:mdna:29]
[same as prior period, unchanged from 0000068505-21-000027:mdna:29]

[0000068505-22-000019:mdna:30]
|  | Three Months Ended |  |  |
| (Dollars in millions, except per share amounts) | April 2, 2022 |  | % ofSales* |  | April 3, 2021 |  | % ofSales* |  |  |  |  |  |  |  |  |
| Net sales from products | $ | 1,046 |  |  |  |  | $ | 926 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales from services | 846 |  |  |  |  | 847 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 1,892 |  |  |  |  | 1,773 |  |  |  |  |  |  |  |  |  |  |  |
| Costs of products sales | 548 |  |  | 52.4 | % |  | 438 |  |  | 47.3 | % |  |  |  |  |  |  |  |  |
| Costs of services sales | 487 |  |  | 57.6 | % |  | 475 |  |  | 56.1 | % |  |  |  |  |  |  |  |  |
| Costs of sales | 1,035 |  |  |  |  | 913 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 857 |  |  | 45.3 | % |  | 860 |  |  | 48.5 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 338 |  |  | 17.9 | % |  | 303 |  |  | 17.1 | % |  |  |  |  |  |  |  |  |
| Research and development expenditures | 188 |  |  | 9.9 | % |  | 180 |  |  | 10.2 | % |  |  |  |  |  |  |  |  |
| Other charges | 92 |  |  | 4.9 | % |  | 79 |  |  | 4.5 | % |  |  |  |  |  |  |  |  |
| Operating earnings | 239 |  |  | 12.6 | % |  | 298 |  |  | 16.8 | % |  |  |  |  |  |  |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (56) |  |  | (3.0) | % |  | (54) |  |  | (3.0) | % |  |  |  |  |  |  |  |  |
| Gains on sales of investments and businesses, net | 2 |  |  | 0.1 | % |  | — |  |  | — | % |  |  |  |  |  |  |  |  |
| Other, net | 34 |  |  | 1.8 | % |  | 45 |  |  | 2.5 | % |  |  |  |  |  |  |  |  |
| Total other expense | (20) |  |  | (1.1) | % |  | (9) |  |  | (0.5) | % |  |  |  |  |  |  |  |  |
| Net earnings before income taxes | 219 |  |  | 11.6 | % |  | 289 |  |  | 16.3 | % |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) | (49) |  |  | (2.6) | % |  | 44 |  |  | 2.5 | % |  |  |  |  |  |  |  |  |
| Net earnings | 268 |  |  | 14.2 | % |  | 245 |  |  | 13.8 | % |  |  |  |  |  |  |  |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 267 |  |  | 14.1 | % |  | $ | 244 |  |  | 13.8 | % |  |  |  |  |  |  |  |  |
| Earnings per diluted common share | $ | 1.54 |  |  |  |  | $ | 1.41 |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-22-000019:mdna:31]
[same as prior period, unchanged from 0000068505-21-000027:mdna:31]

[0000068505-22-000019:mdna:32]
[same as prior period, unchanged from 0000068505-21-000027:mdna:25]

[0000068505-22-000019:mdna:33]
Results of Operations—Three months ended April 2, 2022 compared to three months ended April 3, 2021

[0000068505-22-000019:mdna:34]
The results of operations for the first quarter of 2022 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-22-000019:mdna:35]
[same as prior period, unchanged from 0000068505-21-000027:mdna:34]

[0000068505-22-000019:mdna:36]
[same as prior period, unchanged from 0000068505-21-000027:mdna:35]

[0000068505-22-000019:mdna:37]
[same as prior period, unchanged from 0000068505-21-000027:mdna:36]

[0000068505-22-000019:mdna:38]
[same as prior period, unchanged from 0000068505-21-000027:mdna:37]

[0000068505-22-000019:mdna:39]
[same as prior period, unchanged from 0000068505-21-000027:mdna:38]

[0000068505-22-000019:mdna:40]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |  | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |
| International | 272 |  |  | 315 |  |  | 587 |  |  | 273 |  |  | 315 |  |  | 588 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |  | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |
| Video Security and Access Control | 194 |  |  | 113 |  |  | 307 |  |  | 165 |  |  | 88 |  |  | 253 |  |
| Command Center Software | — |  |  | 130 |  |  | 130 |  |  | — |  |  | 119 |  |  | 119 |  |
| Total | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Operating earnings | $ | 39 |  |  | $ | 200 |  |  | $ | 239 |  |  | $ | 77 |  |  | $ | 221 |  |  | $ | 298 |  |
| Operating margins | 3.5 | % |  | 25.3 | % |  | 12.6 | % |  | 7.6 | % |  | 29.1 | % |  | 16.8 | % |

[0000068505-22-000019:mdna:41]
[same as prior period, unchanged from 0000068505-21-000027:mdna:40]

[0000068505-22-000019:mdna:42]
The Products and Systems Integration segment’s net sales represented 58% of our net sales in the first quarter of 2022 and 57% in the first quarter of 2021. The Software and Services segment’s net sales represented 42% of our net sales in the first quarter of 2022 and 43% in the first quarter of 2021.

[0000068505-22-000019:mdna:43]
Net sales increased $119 million, or 7%, in the first quarter of 2022 compared to the first quarter of 2021. The $88 million, or 9%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 12% in the North America region and partially offset by a decrease of 1% in the International region. The $31 million, or 4%, increase in net sales within the Software and Services segment was driven by an increase of 7% in the North America region. Net sales includes:

[0000068505-22-000019:mdna:44]
•an increase in the Products and Systems Integration segment, inclusive of $7 million of revenue from acquisitions, driven by an increase in LMR and Video Security and Access Control; and

[0000068505-22-000019:mdna:45]
•an increase in the Software and Services segment, inclusive of $10 million of revenue from acquisitions, driven by an increase in Video Security and Access Control and Command Center Software, offset by a decrease in LMR services; partially offset by

[0000068505-22-000019:mdna:46]
•$18 million from unfavorable currency rates.

[0000068505-22-000019:mdna:47]
[same as prior period, unchanged from 0000068505-21-000027:mdna:46]

[0000068505-22-000019:mdna:48]
•a 10% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software; and

[0000068505-22-000019:mdna:49]
•consistent net sales in the International region, inclusive of revenue from acquisitions, driven by an increase in Video Security and Access Control and Command Center Software, offset by a decrease in LMR.

[0000068505-22-000019:mdna:50]
[same as prior period, unchanged from 0000068505-21-000027:mdna:49]

[0000068505-22-000019:mdna:51]
The 9% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-22-000019:mdna:52]
•$59 million, or 7% growth in LMR, driven by the North America region and partially offset by the International region; and

[0000068505-22-000019:mdna:53]
•$29 million, or 18% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions; partially offset by

[0000068505-22-000019:mdna:54]
•$8 million from unfavorable currency rates.

[0000068505-22-000019:mdna:55]
[same as prior period, unchanged from 0000068505-21-000027:mdna:54]

[0000068505-22-000019:mdna:56]
The 4% increase in the Software and Services segment was driven by the following:

[0000068505-22-000019:mdna:57]
•$25 million, or 28% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-22-000019:mdna:58]
•$11 million, or 9% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; partially offset by

[0000068505-22-000019:mdna:59]
•$10 million from unfavorable currency rates; and

[0000068505-22-000019:mdna:60]
•$5 million, or 1% decrease in LMR services, driven by both the International and North America regions.

[0000068505-22-000019:mdna:61]
[same as prior period, unchanged from 0000068505-21-000027:mdna:60]

[0000068505-22-000019:mdna:62]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |  | % Change |
| Gross margin | $ | 857 |  |  | $ | 860 |  |  | — | % |

[0000068505-22-000019:mdna:63]
Gross margin was 45.3% of net sales in the first quarter of 2022 compared to 48.5% in the first quarter of 2021. The primary drivers of this decrease were:

[0000068505-22-000019:mdna:64]
•lower gross margin in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by an increase in material and freight costs, partially offset by higher sales volume; and

[0000068505-22-000019:mdna:65]
•consistent gross margin in the Software and Services segment, inclusive of acquisitions, primarily driven by sales growth, offset by unfavorable mix.

[0000068505-22-000019:mdna:66]
[same as prior period, unchanged from 0000068505-21-000027:mdna:65]

[0000068505-22-000019:mdna:67]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |  | % Change |
| Selling, general and administrative expenses | $ | 338 |  |  | $ | 303 |  |  | 12 | % |

[0000068505-22-000019:mdna:68]
SG&A expenses increased 12% in the first quarter of 2022 compared to the first quarter of 2021. The increase in SG&A expenses was primarily due to higher expenses associated with acquired businesses and higher travel expenses, partially offset by a reduction in reorganization of business charges. SG&A expenses were 17.9% of net sales in the first quarter of 2022 compared to 17.1% of net sales in the first quarter of 2021.

[0000068505-22-000019:mdna:69]
[same as prior period, unchanged from 0000068505-21-000027:mdna:68]

[0000068505-22-000019:mdna:70]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |  | % Change |
| Research and development expenditures | $ | 188 |  |  | $ | 180 |  |  | 4 | % |

[0000068505-22-000019:mdna:71]
R&D expenditures increased 4% in the first quarter of 2022 compared to the first quarter of 2021 primarily due to higher expenses associated with acquired businesses. R&D expenditures decreased to 9.9% of net sales in the first quarter of 2022 compared to 10.2% of net sales in the first quarter of 2021.

[0000068505-22-000019:mdna:72]
[same as prior period, unchanged from 0000068505-21-000027:mdna:71]

[0000068505-22-000019:mdna:73]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |
| Other charges | $ | 92 |  |  | $ | 79 |  |

[0000068505-22-000019:mdna:74]
Other charges increased by $13 million in the first quarter of 2022 compared to the first quarter of 2021. The change was driven primarily by the following:

[0000068505-22-000019:mdna:75]
•$11 million of legal settlement charges in the first quarter of 2022 that did not occur in the first quarter of 2021;

[0000068505-22-000019:mdna:76]
•$10 million of acquisition-related transaction fees in the first quarter of 2022 compared to $1 million of acquisition-related transaction fees in the first quarter of 2021;

[0000068505-22-000019:mdna:77]
•$66 million of intangible asset amortization expense in the first quarter of 2022 compared to $58 million of intangible asset amortization expense in the first quarter of 2021;

[0000068505-22-000019:mdna:78]
•$3 million of fixed asset impairments in the first quarter of 2022 that did not occur in the first quarter of 2021; and

[0000068505-22-000019:mdna:79]
•$9 million of operating lease asset impairments in the first quarter of 2022 compared to $7 million of operating lease impairments in the first quarter of 2021; partially offset by

[0000068505-22-000019:mdna:80]
•$7 million of net reorganization of business charges in the first quarter of 2022 compared to $14 million of net reorganization business charges in the first quarter of 2021 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q); and

[0000068505-22-000019:mdna:81]
•$13 million gain on recoveries from the legal settlement under the Hytera bankruptcy proceedings in the first quarter of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q).

[0000068505-22-000019:mdna:82]
[same as prior period, unchanged from 0000068505-21-000027:mdna:77]

[0000068505-22-000019:mdna:83]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |
| Operating earnings from Products and Systems Integration | $ | 39 |  |  | $ | 77 |  |
| Operating earnings from Software and Services | 200 |  |  | 221 |  |
| Operating earnings | $ | 239 |  |  | $ | 298 |  |

[0000068505-22-000019:mdna:84]
Operating earnings decreased $59 million, or 20%, in the first quarter of 2022 compared to the first quarter of 2021. The decrease in Operating earnings was due to:

[0000068505-22-000019:mdna:85]
•$38 million decrease in the Products and Systems Integration segment, driven by lower gross margin contribution, higher expenses related to material and freight costs, higher expenses associated with acquired businesses and higher travel expenses, partially offset by a gain on recoveries related to the legal settlement of the Hytera bankruptcy proceedings in the first quarter of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q) and lower reorganization of business charges; and

[0000068505-22-000019:mdna:86]
•$21 million decrease in the Software and Services segment, driven by a legal settlement charge in the first quarter of 2022 and higher expenses associated with acquired businesses; partially offset by higher sales.

[0000068505-22-000019:mdna:87]
[same as prior period, unchanged from 0000068505-21-000027:mdna:82]

[0000068505-22-000019:mdna:88]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |
| Interest expense, net | $ | (56) |  |  | $ | (54) |  |

[0000068505-22-000019:mdna:89]
The $2 million increase in interest expense, net in the first quarter of 2022 compared to the first quarter of 2021 was primarily driven by higher outstanding debt, partially offset by lower interest rates on outstanding debt and lower interest expense associated with the fully amortized discount related to the Senior Convertible Notes (defined below).

[0000068505-22-000019:mdna:90]
[same as prior period, unchanged from 0000068505-21-000027:mdna:85]

[0000068505-22-000019:mdna:91]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |
| Other, net | $ | 34 |  |  | $ | 45 |  |

[0000068505-22-000019:mdna:92]
The $11 million decrease in Other, net in the first quarter of 2022 compared to the first quarter of 2021 was primarily driven by:

[0000068505-22-000019:mdna:93]
•$18 million loss on fair value adjustments to equity investments in the first quarter of 2022 compared to a $5 million gain on fair value adjustments to equity investments in the first quarter of 2021;

[0000068505-22-000019:mdna:94]
•$23 million loss on derivatives in the first quarter of 2022 compared to a $8 million loss on derivatives in the first quarter of 2021;

[0000068505-22-000019:mdna:95]
•$2 million gain in other income during the first quarter of 2021 that did not occur in in the first quarter of 2022; and

[0000068505-22-000019:mdna:96]
•$1 million of investment impairment in the first quarter of 2022 that did not occur in in the first quarter of 2021; partially offset by

[0000068505-22-000019:mdna:97]
•$21 million gain on TETRA Ireland equity method investment in the first quarter of 2022 compared to $2 million gain on equity method investments in the first quarter of 2021 (see further detail in "Other Charges" in Note 4, "Other Financial Data" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q);

[0000068505-22-000019:mdna:98]
•$23 million of foreign currency gains in the first quarter of 2022 compared to $14 million of foreign currency gains in the first quarter of 2021; and

[0000068505-22-000019:mdna:99]
•$32 million of net periodic pension and postretirement benefit in the first quarter of 2022 compared to $30 million of net periodic pension and postretirement benefit in the first quarter of 2021.

[0000068505-22-000019:mdna:100]
[same as prior period, unchanged from 0000068505-21-000027:mdna:93]

[0000068505-22-000019:mdna:101]
|  | Three Months Ended |
| (In millions) | April 2, 2022 |  | April 3, 2021 |
| Income tax expense (benefit) | $ | (49) |  |  | $ | 44 |  |

[0000068505-22-000019:mdna:102]
Income tax expense decreased by $93 million in the first quarter of 2022 compared to the first quarter of 2021, resulting in an effective tax rate of (22)%. Our effective tax rate for the three months ended April 2, 2022 of (22)% was lower than the effective tax rate for the three months ended April 3, 2021 of 15%, primarily due to a $77 million one-time net deferred tax benefit as a result of an intra-group transfer of certain intellectual property rights and a higher tax rate benefit from the foreign derived intangible income deduction and share-based compensation in 2022 compared to 2021 (see Note 7, "Income Taxes" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q for further information).

[0000068505-22-000019:mdna:103]
[same as prior period, unchanged from 0000068505-21-000027:mdna:156]

[0000068505-22-000019:mdna:104]
During the first quarter of 2022, we recorded net reorganization of business charges of $10 million, including $7 million of charges recorded within Other charges and $3 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-22-000019:mdna:105]
During the first quarter of 2021, we recorded net reorganization of business charges of $16 million, including $14 million of charges in Other charges and $2 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $18 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-22-000019:mdna:106]
[same as prior period, unchanged from 0000068505-21-000027:mdna:161]

[0000068505-22-000019:mdna:107]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Products and Systems Integration | $ | 8 |  |  | $ | 12 |  |  |  |  |  |
| Software and Services | 2 |  |  | 4 |  |  |  |  |  |
|  | $ | 10 |  |  | $ | 16 |  |  |  |  |  |

[0000068505-22-000019:mdna:108]
Cash payments for employee severance in connection with the reorganization of business plans were $12 million in the first quarter of 2022 and $37 million in the first quarter of 2021. The reorganization of business accrual at April 2, 2022 was $32 million related to employee separation costs that are expected to be paid within one year.

[0000068505-22-000019:mdna:109]
[same as prior period, unchanged from 0000068505-21-000027:mdna:164]

[0000068505-22-000019:mdna:110]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 152 |  |  | $ | 370 |  |
| Investing activities | (557) |  |  | (52) |  |
| Financing activities | (577) |  |  | (256) |  |
| Effect of exchange rates on cash and cash equivalents | (14) |  |  | 4 |  |
| Increase (decrease) in cash and cash equivalents | $ | (996) |  |  | $ | 66 |  |

[0000068505-22-000019:mdna:111]
[same as prior period, unchanged from 0000068505-21-000027:mdna:166]

[0000068505-22-000019:mdna:112]
At April 2, 2022, $374 million of the $878 million cash and cash equivalents balance was held in the U.S. and $504 million was held in other countries, with $142 million held in the United Kingdom.

[0000068505-22-000019:mdna:113]
[same as prior period, unchanged from 0000068505-21-000027:mdna:168]

[0000068505-22-000019:mdna:114]
The decrease in cash flows provided by operating activities from the first quarter of 2021 to the first quarter of 2022 was driven primarily by higher working capital due to an increase in inventory.

[0000068505-22-000019:mdna:115]
[same as prior period, unchanged from 0000068505-21-000027:mdna:170]

[0000068505-22-000019:mdna:116]
The increase in cash flows used for investing activities in the first quarter of 2022 compared to the first quarter of 2021 was primarily due to a $510 million increase in cash used for acquisitions and investments.

[0000068505-22-000019:mdna:117]
[same as prior period, unchanged from 0000068505-21-000027:mdna:175]

[0000068505-22-000019:mdna:118]
The increase in cash flows used for financing activities in the first quarter of 2022 compared to the first quarter of 2021 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-22-000019:mdna:119]
•$323 million increase in share repurchases in the first quarter of 2022 compared to the first quarter of 2021;

[0000068505-22-000019:mdna:120]
•$13 million increase in the payment of dividends in the first quarter of 2022 compared to the first quarter of 2021; partially offset by

[0000068505-22-000019:mdna:121]
•$7 million increase in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first quarter of 2022 compared to the first quarter of 2021;

[0000068505-22-000019:mdna:122]
•$7 million related to the payment of revolving credit facility renewal fees in the first quarter of 2021 that did not occur in the first quarter of 2022.

[0000068505-22-000019:mdna:123]
[same as prior period, unchanged from 0000068505-21-000027:mdna:182]

[0000068505-22-000019:mdna:124]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended April 2, 2022 and April 3, 2021:

[0000068505-22-000019:mdna:125]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Contract-specific discounting facility | $ | 49 |  |  | $ | 71 |  |  |  |  |  |
| Accounts receivable sales proceeds | 22 |  |  | — |  |  |  |  |  |
| Long-term receivables sales proceeds | 17 |  |  | 54 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 88 |  |  | $ | 125 |  |  |  |  |  |

[0000068505-22-000019:mdna:126]
During the three months ended April 2, 2022, we completed the final draw against a cost-efficient receivables discounting facility, implemented in 2020 to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe, resulting in accounts receivable sales of $49 million. The proceeds of our receivable sales are included in Operating activities within our Condensed Consolidated Statements of Cash Flows.

[0000068505-22-000019:mdna:127]
[same as prior period, unchanged from 0000068505-21-000027:mdna:186]

[0000068505-22-000019:mdna:128]
We had outstanding debt of $5.7 billion at both April 2, 2022 and December 31, 2021, including the current portions of $4 million and $5 million, at April 2, 2022 and December 31, 2021, respectively.

[0000068505-22-000019:mdna:129]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of April 2, 2022.

[0000068505-22-000019:mdna:130]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("Senior Convertible Notes"). Interest on these notes is payable semiannually. The Senior Convertible Notes became fully convertible on September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash.

[0000068505-22-000019:mdna:131]
34

[0000068505-22-000019:mdna:132]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of April 2, 2022 we had no outstanding debt under the commercial paper program.

[0000068505-22-000019:mdna:133]
[same as prior period, unchanged from 0000068505-21-000027:mdna:193]

[0000068505-22-000019:mdna:134]
During the three months ended April 2, 2022, we repurchased approximately 2.2 million shares at an average price of $224.41 per share for an aggregate of $493 million, including transaction costs, which was paid within the quarter. As of April 2, 2022, we had used approximately $14.4 billion of the share repurchase authority to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-22-000019:mdna:135]
[same as prior period, unchanged from 0000068505-21-000027:mdna:195]

[0000068505-22-000019:mdna:136]
During the first quarter of 2022 we paid $134 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $132 million in cash dividends to holders of our common stock.

[0000068505-22-000019:mdna:137]
Adequate Internal Funding Resources

[0000068505-22-000019:mdna:138]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement.

[0000068505-22-000019:mdna:139]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer also to the “Macroeconomic Events” section in this Part I, Item 2 of this Form 10-Q for a discussion of the impact of macroeconomic events on our liquidity.

[0000068505-22-000019:mdna:140]
[same as prior period, unchanged from 0000068505-21-000027:mdna:197]

[0000068505-22-000019:mdna:141]
We had outstanding commitments to provide long-term financing to third parties totaling $32 million at April 2, 2022, compared to $56 million at December 31, 2021.

[0000068505-22-000019:mdna:142]
[same as prior period, unchanged from 0000068505-21-000027:mdna:199]

[0000068505-22-000019:mdna:143]
See “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
