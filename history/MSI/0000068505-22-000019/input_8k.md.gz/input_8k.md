# MSI 8-K — 0000068505-22-000017 filed 2022-05-12

## item codes, every 8-K on or before 2022-05-12

- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2022-05-12

- none on or before 2022-05-12

## item 2.02 — earnings release, exhibit 99.1

[0000068505-22-000017:8k_2_02:1]
EX-99.1
2
msiq12022pressrelease.htm
EX-99.1

[0000068505-22-000017:8k_2_02:2]
Document

[0000068505-22-000017:8k_2_02:3]
Exhibit 99.1

[0000068505-22-000017:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2022 Financial Results

[0000068505-22-000017:8k_2_02:5]
Company achieves record Q1 orders, sales, and ending backlog

[0000068505-22-000017:8k_2_02:6]
•Sales of $1.9 billion, up 7% versus a year ago

[0000068505-22-000017:8k_2_02:7]
◦Products and Systems Integration sales up 9%

[0000068505-22-000017:8k_2_02:8]
◦Software and Services sales up 4%

[0000068505-22-000017:8k_2_02:9]
•GAAP earnings per share (EPS) of $1.54

[0000068505-22-000017:8k_2_02:10]
•Non-GAAP EPS* of $1.70

[0000068505-22-000017:8k_2_02:11]
•Record Q1 ending backlog of $13.4 billion, up 19% versus a year ago

[0000068505-22-000017:8k_2_02:12]
•Repurchased $493 million of shares

[0000068505-22-000017:8k_2_02:13]
•Closed the acquisitions of Ava Security, a global provider of cloud-native video security and analytics, and TETRA Ireland, the country's National Digital Radio Service provider

[0000068505-22-000017:8k_2_02:14]
CHICAGO – May 12, 2022 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2022.

[0000068505-22-000017:8k_2_02:15]
“I’m pleased with our strong start to the year, highlighted by robust growth in video security,” said Greg Brown, chairman and CEO, Motorola Solutions. “Record first-quarter orders, sales and ending backlog position us well for continued growth in 2022, while we continue to navigate a challenging macroeconomic and supply chain environment.”

[0000068505-22-000017:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-22-000017:8k_2_02:17]
|  | Q1 2022 |  | Q1 2021 | % Change |
| Sales | $1,892 |  | $1,773 | 7 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $239 |  | $298 | (20) | % |
| % of Sales | 12.6 | % |  | 16.8 | % |  |
| EPS | $1.54 |  | $1.41 | 9 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $374 |  | $411 | (9) | % |
| % of Sales | 19.8 | % |  | 23.2 | % |  |
| EPS | $1.70 |  | $1.87 | (9) | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,103 |  | $1,015 | 9 | % |
| GAAP Operating Earnings | $39 |  | $77 | (49) | % |
| % of Sales | 3.5 | % |  | 7.6 | % |  |
| Non-GAAP Operating Earnings* | $96 |  | $131 | (27) | % |
| % of Sales | 8.7 | % |  | 12.9 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $789 |  | $758 | 4 | % |
| GAAP Operating Earnings | $200 |  | $221 | (10) | % |
| % of Sales | 25.3 | % |  | 29.1 | % |  |
| Non-GAAP Operating Earnings* | $278 |  | $280 | (1) | % |
| % of Sales | 35.2 | % |  | 36.9 | % |  |

[0000068505-22-000017:8k_2_02:18]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.16 per diluted share related to highlighted items, including share-based compensation expenses and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-22-000017:8k_2_02:19]
1

[0000068505-22-000017:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-22-000017:8k_2_02:21]
•Revenue - Sales were $1.9 billion, up 7% from the year-ago quarter driven by growth in North America. Revenue from acquisitions was $17 million and currency headwinds were $18 million in the quarter. The Products and Systems Integration segment grew 9% driven by growth in land mobile radio (LMR) and video security. The Software and Services segment grew 4%, driven by growth in video security and command center software.

[0000068505-22-000017:8k_2_02:22]
•Operating margin - GAAP operating margin was 12.6% of sales, down from 16.8% in the year-ago quarter. Non-GAAP operating margin was 19.8% of sales, down from 23.2% in the year-ago quarter. The decrease in both GAAP and non-GAAP operating margins was primarily due to the impact of higher direct material costs for semiconductors which were highlighted last quarter and higher operating expenses for acquisitions, partially offset by higher sales related to better than expected supply in LMR.

[0000068505-22-000017:8k_2_02:23]
•Taxes - The GAAP effective tax rate was (22.4)%, down from 15.1% in the year-ago quarter, primarily due to a discrete deferred tax benefit as a result of the taxable reorganization of our intellectual property in the current quarter.  The non-GAAP effective tax rate was 15.2%, down from 17.7% in the year-ago quarter, driven primarily by the benefit of higher export sales and higher stock-based compensation in the current quarter.

[0000068505-22-000017:8k_2_02:24]
•Cash flow - Operating cash flow was $152 million, compared to $370 million in the year-ago quarter. Free cash flow was $98 million, compared to $318 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter decreased primarily due to an increase in inventory.

[0000068505-22-000017:8k_2_02:25]
•Capital allocation - During the quarter, the company repurchased $493 million of shares, paid $134 million in cash dividends and incurred $54 million of capital expenditures. Additionally, the company closed the acquisitions of Ava Security for $387 million and TETRA Ireland for $120 million, each net of cash acquired.  Subsequent to quarter end, the company acquired Calipsa, a leader in cloud-based advanced video analytics for $40 million, and Videotec, a global provider of pan-tilt-zoom and explosion proof cameras for $22M, each net of cash acquired.

[0000068505-22-000017:8k_2_02:26]
•Backlog - The company ended the quarter with record Q1 backlog of $13.4 billion, up 19% or $2.1 billion, from the year-ago quarter. Products and Systems Integration segment backlog was up 26%, or $852 million. The growth was primarily driven by strong LMR and video security demand. Software and Services segment backlog was up 16% or $1.3 billion, driven by the extension of the Airwave contract in the fourth quarter of 2021 and an increase in multi-year software and services contracts in North America.

[0000068505-22-000017:8k_2_02:27]
2

[0000068505-22-000017:8k_2_02:28]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-22-000017:8k_2_02:29]
Software and Services

[0000068505-22-000017:8k_2_02:30]
•$27M command center software order for a customer in LATAM

[0000068505-22-000017:8k_2_02:31]
•$20M of U.S. Federal multi-year service orders

[0000068505-22-000017:8k_2_02:32]
•$8M command center software record management order for the City of Phoenix, AZ

[0000068505-22-000017:8k_2_02:33]
•$8M services agreement with the City of Chicago, IL

[0000068505-22-000017:8k_2_02:34]
•28% growth in video security and access control software

[0000068505-22-000017:8k_2_02:35]
•Subsequent to quarter end, launched the Public Safety Threat Alliance, a cybersecurity information sharing and intelligence hub for the public safety community

[0000068505-22-000017:8k_2_02:36]
Products and Systems Integration

[0000068505-22-000017:8k_2_02:37]
•$60M+ nationwide P25 order for Taiwan National Police Agency

[0000068505-22-000017:8k_2_02:38]
•$20M P25 upgrade order for Los Angeles Unified School District

[0000068505-22-000017:8k_2_02:39]
•$14M TETRA upgrade order for Israel Railways

[0000068505-22-000017:8k_2_02:40]
•$11M P25 expansion for a large U.S. customer

[0000068505-22-000017:8k_2_02:41]
•$5M video security order for a large U.S. public school system

[0000068505-22-000017:8k_2_02:42]
BUSINESS OUTLOOK

[0000068505-22-000017:8k_2_02:43]
•Second-quarter 2022 - The company expects revenue growth of 4% to 5% compared to the second quarter of 2021. The company expects non-GAAP EPS in the range of $1.83 to $1.88 per share. This assumes $50 million in foreign exchange headwinds, 173 million fully diluted shares, and an effective tax rate of 22% to 23%.

[0000068505-22-000017:8k_2_02:44]
•Full-year 2022 - The company is maintaining its prior guidance of 7% revenue growth and non-GAAP EPS guidance of between $9.80 and $9.95 per share. This outlook assumes $170 million in foreign exchange headwinds, an increase of $110 million from the prior guidance.  It also assumes 173 million fully diluted shares and an effective tax rate of 21% to 21.5%. The company expects pricing actions, targeted cost reductions, and a favorable mix for LMR products to result in higher operating margins in the second half of the year.

[0000068505-22-000017:8k_2_02:45]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-22-000017:8k_2_02:46]
MACROECONOMIC EVENTS

[0000068505-22-000017:8k_2_02:47]
Recent macroeconomic events impacting the company are discussed below. During the first quarter of 2022, the company continued to operate under challenging market conditions, influenced by events such as the Russia-Ukraine conflict, the continuing impact of the COVID-19 pandemic, disruption to the company's supply chain and the inflationary cost environment.

[0000068505-22-000017:8k_2_02:48]
3

[0000068505-22-000017:8k_2_02:49]
Russia-Ukraine Conflict

[0000068505-22-000017:8k_2_02:50]
In February 2022, Russia's invasion of Ukraine prompted the United States, the European Union and other countries to impose economic sanctions on Russia. During the first quarter of 2022, the company suspended all sales, provision of services and shipments of its products to Russia and Belarus. Russia, Ukraine and Belarus do not constitute a material portion of the company's business. For the year ended December 31, 2021, the company's net sales in Russia and Belarus were less than $25 million. While the company does not anticipate that the current posture of the Russia-Ukraine conflict will materially and adversely affect its results of operations, the conflict is still ongoing and future impacts are difficult to estimate. An escalation of the conflict's current scope or expansion of the conflict's economic disruption could materially and adversely affect the company and its operations. During the first quarter of 2022, the company indirectly experienced impacts from the Russia-Ukraine conflict within its supply chain (as further described below). The conflict has and may continue to have a significant impact on the global macroeconomic and geopolitical environments, including increased volatility in capital and commodity markets, rapid changes to regulatory conditions (including the use of sanctions), supply chain and operational challenges for multinational corporations, inflationary pressures and an increased risk of cybersecurity incidents. For a more complete discussion of the risks the company encounters in its business, please refer to Part I, Item 1A, "Risk Factors" in the company's Annual Report on Form 10-K for the fiscal year ended December 31, 2021.

[0000068505-22-000017:8k_2_02:51]
COVID-19, Supply Chain Disruptions & Inflationary Cost Environment

[0000068505-22-000017:8k_2_02:52]
The COVID-19 pandemic continues to be dynamic, and near-term challenges across the economy remain. The health and safety of the company's employees remains its top priority, and the company continues to work to mitigate the impact of COVID-19 on its employees, customers, communities, liquidity and financial position.

[0000068505-22-000017:8k_2_02:53]
As the company progressed throughout the first quarter of 2022, its supply chain has been increasingly impacted by global issues related to the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity (including indirectly as a result of the Russia-Ukraine conflict) and labor constraints. This has resulted in disruptions in the company's supply chain, as well as difficulties and delays in procuring certain semiconductor components. During the latter part of the fourth quarter of 2021 and continuing into the first quarter of 2022, cost increases were driven by elevated lead times and increased material costs, in particular the need to purchase semiconductor components from alternative sources, including brokers. The company anticipates increased costs to procure materials within the semiconductor market to continue through the first half of 2022.  Further, the company anticipates the broader impact of inflationary pressures and increased material and supply chain costs and disruptions to continue throughout 2022. The company is closely monitoring its supply chain, including impacts from manufacturing lockdowns related to the spread of COVID-19 in China during the first quarter of 2022 which continue to disrupt the semiconductor supply market. Accordingly, in the first quarter of 2022 the company focused on improving its supplier network, engineering alternative designs and working to reduce supply shortages. The company is actively managing its inventory in an effort to minimize supply chain disruptions and enable continuity of supply and services to its customers, and it expects to maintain elevated levels of inventory until supply constraints have been remediated.

[0000068505-22-000017:8k_2_02:54]
Although the macroeconomic environment continued to introduce challenges in the first quarter of 2022, the company is encouraged by customer demand for its products and services. Specifically, in the Software and Services segment, with the largely recurring nature of the business and the strong backlog position, the company continues to expect that the impacts on net sales and operating margin will be limited throughout 2022. Within the Products and Systems Integration segment, while the company is encouraged by strong LMR backlog and the resiliency of the Video Security and Access Control technology that experienced growth in the first quarter of 2022 and which the company expects to

[0000068505-22-000017:8k_2_02:55]
4

[0000068505-22-000017:8k_2_02:56]
continue to grow for the remainder of 2022, supply constraints continue to impact the LMR business and the company expects demand for its products will continue to out-pace its ability to obtain semiconductor component supply throughout 2022. Where appropriate, the company has established pricing adjustments to its product and service offerings to mitigate its exposure to inflationary pressures on its businesses and expects to benefit from these adjustments in the second half of 2022. Further, demand continues to be supported with ongoing sources of government funding. In March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. The company experienced the positive impact of the ARPA funding on its business and results of operations during the first quarter of 2022 and anticipates that the ARPA will continue to have a positive impact throughout the remainder of 2022.

[0000068505-22-000017:8k_2_02:57]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, May 12. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-22-000017:8k_2_02:58]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-22-000017:8k_2_02:59]
A comparison of results from operations is as follows:

[0000068505-22-000017:8k_2_02:60]
|  | Q1 2022 | Q1 2021 |
| Net sales | $1,892 | $1,773 |
| Gross margin | $857 | $860 |
| Operating earnings | $239 | $298 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $267 | $244 |
| Diluted EPS | $1.54 | $1.41 |
| Weighted average diluted common shares outstanding | 173.1 |  | 173.2 |  |

[0000068505-22-000017:8k_2_02:61]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-22-000017:8k_2_02:62]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-22-000017:8k_2_02:63]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-22-000017:8k_2_02:64]
5

[0000068505-22-000017:8k_2_02:65]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-22-000017:8k_2_02:66]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-22-000017:8k_2_02:67]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-22-000017:8k_2_02:68]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-22-000017:8k_2_02:69]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the company on December 15, 2021, and, consistent with the company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  The Court also ordered the parties to jointly file by February 22, 2022, a proposed royalty agreement for the Court's review and approval. Because the parties could not concur on the royalty agreement, they each filed supporting papers for their proposed draft agreements, and on April 12, 2022, the Court issued a ruling generally favorable to the company on the critical aspects of the royalty agreement. On April 19, 2022, the parties filed an agreed royalty agreement that incorporates the findings of the Court's ruling.

[0000068505-22-000017:8k_2_02:70]
In response to the Court's decision to award the company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief. On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the company with respect to several

[0000068505-22-000017:8k_2_02:71]
6

[0000068505-22-000017:8k_2_02:72]
of the company's post-trial motions, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award. On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the company's judgment award, or, in the alternative, hold Hytera in contempt. On October 15, 2021, the Court granted the company’s request for $34.2 million in attorneys’ fees against Hytera.

[0000068505-22-000017:8k_2_02:73]
Separate from the company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including $13 million to the company. The gain was recorded to Other charges (income).

[0000068505-22-000017:8k_2_02:74]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $13 million of proceeds realized in Q1 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-22-000017:8k_2_02:75]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-22-000017:8k_2_02:76]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-22-000017:8k_2_02:77]
7

[0000068505-22-000017:8k_2_02:78]
FORWARD LOOKING STATEMENTS

[0000068505-22-000017:8k_2_02:79]
8

[0000068505-22-000017:8k_2_02:80]
ABOUT MOTOROLA SOLUTIONS

[0000068505-22-000017:8k_2_02:81]
Motorola Solutions is a global leader in public safety and enterprise security. Our solutions in land mobile radio communications, video security & access control and command center software, bolstered by managed & support services, create an integrated technology ecosystem to help make communities safer and businesses stay productive and secure. At Motorola Solutions, we’re ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-22-000017:8k_2_02:82]
MEDIA CONTACT

[0000068505-22-000017:8k_2_02:83]
Alexandra Reynolds

[0000068505-22-000017:8k_2_02:84]
Motorola Solutions

[0000068505-22-000017:8k_2_02:85]
+1 312-965-3968

[0000068505-22-000017:8k_2_02:86]
alexandra.reynolds@motorolasolutions.com

[0000068505-22-000017:8k_2_02:87]
INVESTOR CONTACT

[0000068505-22-000017:8k_2_02:88]
Tim Yocum

[0000068505-22-000017:8k_2_02:89]
Motorola Solutions

[0000068505-22-000017:8k_2_02:90]
+1 847-576-6899

[0000068505-22-000017:8k_2_02:91]
Tim.Yocum@motorolasolutions.com

[0000068505-22-000017:8k_2_02:92]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2022 Motorola Solutions, Inc. All rights reserved.

[0000068505-22-000017:8k_2_02:93]
9

[0000068505-22-000017:8k_2_02:94]
GAAP-1

[0000068505-22-000017:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:96]
Condensed Consolidated Statements of Operations

[0000068505-22-000017:8k_2_02:97]
(In millions, except per share amounts)

[0000068505-22-000017:8k_2_02:98]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| Net sales from products | $ | 1,046 |  |  | $ | 926 |  |
| Net sales from services | 846 |  |  | 847 |  |
| Net sales | 1,892 |  |  | 1,773 |  |
| Costs of products sales | 548 |  |  | 438 |  |
| Costs of services sales | 487 |  |  | 475 |  |
| Costs of sales | 1,035 |  |  | 913 |  |
| Gross margin | 857 |  |  | 860 |  |
| Selling, general and administrative expenses | 338 |  |  | 303 |  |
| Research and development expenditures | 188 |  |  | 180 |  |
| Other charges | 26 |  |  | 21 |  |
| Intangibles amortization | 66 |  |  | 58 |  |
| Operating earnings | 239 |  |  | 298 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (56) |  |  | (54) |  |
| Gain on sales of investments and businesses, net | 2 |  |  | — |  |
| Other, net | 34 |  |  | 45 |  |
| Total other expense | (20) |  |  | (9) |  |
| Net earnings before income taxes | 219 |  |  | 289 |  |
| Income tax expense (benefit) | (49) |  |  | 44 |  |
| Net earnings | 268 |  |  | 245 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 267 |  |  | $ | 244 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.59 |  |  | $ | 1.44 |  |
| Diluted | $ | 1.54 |  |  | $ | 1.41 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 168.0 |  |  | 169.3 |  |
| Diluted | 173.1 |  |  | 173.2 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 55.3 | % |  | 52.2 | % |
| Net sales from services | 44.7 | % |  | 47.8 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 52.4 | % |  | 47.3 | % |
| Costs of services sales | 57.6 | % |  | 56.1 | % |
| Costs of sales | 54.7 | % |  | 51.5 | % |
| Gross margin | 45.3 | % |  | 48.5 | % |
| Selling, general and administrative expenses | 17.9 | % |  | 17.1 | % |
| Research and development expenditures | 9.9 | % |  | 10.2 | % |
| Other charges | 1.4 | % |  | 1.2 | % |
| Intangibles amortization | 3.5 | % |  | 3.3 | % |
| Operating earnings | 12.6 | % |  | 16.8 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.0) | % |  | (3.0) | % |
| Gain on sales of investments and businesses, net | 0.1 | % |  | — | % |
| Other, net | 1.8 | % |  | 2.5 | % |
| Total other expense | (1.1) | % |  | (0.5) | % |
| Net earnings before income taxes | 11.6 | % |  | 16.3 | % |
| Income tax expense (benefit) | (2.6) | % |  | 2.5 | % |
| Net earnings | 14.2 | % |  | 13.8 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 14.1 | % |  | 13.8 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-22-000017:8k_2_02:99]
10

[0000068505-22-000017:8k_2_02:100]
GAAP-2

[0000068505-22-000017:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:102]
Condensed Consolidated Balance Sheets

[0000068505-22-000017:8k_2_02:103]
(In millions)

[0000068505-22-000017:8k_2_02:104]
|  | April 2, 2022 |  | December 31, 2021 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 878 |  |  | $ | 1,874 |  |
| Accounts receivable, net | 1,151 |  |  | 1,386 |  |
| Contract assets | 999 |  |  | 1,105 |  |
| Inventories, net | 952 |  |  | 788 |  |
| Other current assets | 300 |  |  | 259 |  |
| Total current assets | 4,280 |  |  | 5,412 |  |
| Property, plant and equipment, net | 1,080 |  |  | 1,042 |  |
| Operating lease assets | 387 |  |  | 382 |  |
| Investments | 183 |  |  | 209 |  |
| Deferred income taxes | 999 |  |  | 916 |  |
| Goodwill | 2,864 |  |  | 2,565 |  |
| Intangible assets, net | 1,304 |  |  | 1,105 |  |
| Other assets | 552 |  |  | 558 |  |
| Total assets | $ | 11,649 |  |  | $ | 12,189 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |
| Current portion of long-term debt | $ | 4 |  |  | $ | 5 |  |
| Accounts payable | 827 |  |  | 851 |  |
| Contract liabilities | 1,590 |  |  | 1,650 |  |
| Accrued liabilities | 1,465 |  |  | 1,557 |  |
| Total current liabilities | 3,886 |  |  | 4,063 |  |
| Long-term debt | 5,689 |  |  | 5,688 |  |
| Operating lease liabilities | 320 |  |  | 313 |  |
| Other liabilities | 2,052 |  |  | 2,148 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) | (316) |  |  | (40) |  |
| Non-controlling interests | 18 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 11,649 |  |  | $ | 12,189 |  |

[0000068505-22-000017:8k_2_02:105]
11

[0000068505-22-000017:8k_2_02:106]
GAAP-3

[0000068505-22-000017:8k_2_02:107]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:108]
Condensed Consolidated Statements of Cash Flows

[0000068505-22-000017:8k_2_02:109]
(In millions)

[0000068505-22-000017:8k_2_02:110]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| Operating |  |  |  |
| Net earnings | $ | 268 |  |  | $ | 245 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 111 |  |  | 110 |  |
| Non-cash other charges (income) | 2 |  |  | (7) |  |
| Share-based compensation expenses | 37 |  |  | 29 |  |
| Gain on sales of investments and businesses, net | (2) |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 248 |  |  | 298 |  |
| Inventories | (162) |  |  | (24) |  |
| Other current assets and contract assets | 47 |  |  | 149 |  |
| Accounts payable, accrued liabilities, and contract liabilities | (188) |  |  | (426) |  |
| Other assets and liabilities | (30) |  |  | (5) |  |
| Deferred income taxes | (179) |  |  | 1 |  |
| Net cash provided by operating activities | 152 |  |  | 370 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (512) |  |  | (2) |  |
| Proceeds from sales of investments and businesses, net | 9 |  |  | 2 |  |
| Capital expenditures | (54) |  |  | (52) |  |
| Net cash used for investing activities | (557) |  |  | (52) |  |
| Financing |  |  |  |
| Repayments of debt | (2) |  |  | (3) |  |
| Revolving credit facility renewal fees | — |  |  | (7) |  |
| Issuances of common stock | 52 |  |  | 45 |  |
| Purchases of common stock | (493) |  |  | (170) |  |
| Payments of dividends | (134) |  |  | (121) |  |
| Net cash used for financing activities | (577) |  |  | (256) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (14) |  |  | 4 |  |
| Net increase (decrease) in total cash and cash equivalents | (996) |  |  | 66 |  |
| Cash and cash equivalents, beginning of period | 1,874 |  |  | 1,254 |  |
| Cash and cash equivalents, end of period | $ | 878 |  |  | $ | 1,320 |  |

[0000068505-22-000017:8k_2_02:111]
12

[0000068505-22-000017:8k_2_02:112]
Non-GAAP-1

[0000068505-22-000017:8k_2_02:113]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:114]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-22-000017:8k_2_02:115]
(In millions)

[0000068505-22-000017:8k_2_02:116]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 152 |  |  | $ | 370 |  |  |  |  |  |  |  |
| Capital expenditures |  | (54) |  |  | (52) |  |  |  |  |  |  |  |
| Free cash flow |  | $ | 98 |  |  | $ | 318 |  |  |  |  |  |  |  |

[0000068505-22-000017:8k_2_02:117]
13

[0000068505-22-000017:8k_2_02:118]
Non-GAAP-2

[0000068505-22-000017:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:120]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-22-000017:8k_2_02:121]
(In millions)

[0000068505-22-000017:8k_2_02:122]
|  |  |  |  | Three Months Ended |  |  |  |  |
|  |  | Statement Line |  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 267 |  |  | $ | 244 |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 66 |  |  | $ | 58 |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 37 |  |  | 29 |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 18 |  |  | (5) |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 11 |  |  | — |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 10 |  |  | 1 |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 10 |  |  | 16 |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 9 |  |  | 7 |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | 3 |  |  | — |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 2 |  |  | 2 |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | 1 |  |  | — |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (2) |  |  | — |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | (2) |  |  | (1) |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | (13) |  |  | — |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | (21) |  |  | — |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 129 |  |  | $ | 107 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 102 |  | 27 |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 27 |  | 80 |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 294 |  |  | $ | 324 |  |  |  |  |  |  |  |

[0000068505-22-000017:8k_2_02:123]
Calculation of Non-GAAP Tax Rate

[0000068505-22-000017:8k_2_02:124]
(In millions)

[0000068505-22-000017:8k_2_02:125]
|  |  | Three Months Ended |  |  |  |  |
|  |  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |  |  |
| Net earnings before income taxes |  | $ | 219 |  |  | $ | 289 |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 129 |  |  | 107 |  |  |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 348 |  |  | 396 |  |  |  |  |  |  |  |
| Income tax expense (benefit) |  | (49) |  |  | 44 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 102 |  |  | 27 |  |  |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | 53 |  |  | 71 |  |  |  |  |  |  |  |
| Non-GAAP Tax rate |  | 15.2 | % |  | 17.7 | % |  |  |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |  |  |

[0000068505-22-000017:8k_2_02:126]
14

[0000068505-22-000017:8k_2_02:127]
Non-GAAP-2

[0000068505-22-000017:8k_2_02:128]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-22-000017:8k_2_02:129]
|  |  |  |  | Three Months Ended |  |  |  |  |
|  |  | Statement Line |  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 1.54 |  |  | $ | 1.41 |  |  |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 0.38 |  |  | $ | 0.33 |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 0.21 |  |  | 0.17 |  |  |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 0.10 |  |  | (0.02) |  |  |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 0.06 |  |  | — |  |  |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.06 |  |  | 0.01 |  |  |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.06 |  |  | 0.09 |  |  |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.05 |  |  | 0.04 |  |  |  |  |  |  |  |
| Fixed asset impairments |  | Other charges (income) |  | 0.02 |  |  | — |  |  |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.01 |  |  | 0.01 |  |  |  |  |  |  |  |
| Investment impairments |  | Other (income) expense |  | 0.01 |  |  | — |  |  |  |  |  |  |  |
| Gain on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (0.01) |  |  | — |  |  |  |  |  |  |  |
| Adjustments to uncertain tax positions |  | Interest income, net |  | (0.01) |  |  | (0.01) |  |  |  |  |  |  |  |
| Gain on Hytera legal settlement |  | Other charges (income) |  | (0.07) |  |  | — |  |  |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment |  | Other (income) expense |  | (0.12) |  |  | — |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.75 |  |  | $ | 0.62 |  |  |  |  |  |  |  |
| Income tax expense (income) on Non-GAAP adjustments |  |  |  | 0.59 |  | 0.16 |  |  |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.16 |  | 0.46 |  |  |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 1.70 |  |  | $ | 1.87 |  |  |  |  |  |  |  |
| Diluted Weighted Average Common Shares |  |  |  | 173.1 |  |  | 173.2 |  |  |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-22-000017:8k_2_02:130]
15

[0000068505-22-000017:8k_2_02:131]
Non-GAAP-3

[0000068505-22-000017:8k_2_02:132]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:133]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-22-000017:8k_2_02:134]
(In millions)

[0000068505-22-000017:8k_2_02:135]
|  |  | Three Months Ended |
|  |  | April 2, 2022 |  | April 3, 2021 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Operating earnings ("OE") |  | $ | 39 |  |  | $ | 200 |  |  | $ | 239 |  |  | $ | 77 |  |  | $ | 221 |  |  | $ | 298 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 15 |  |  | 51 |  |  | 66 |  |  | 13 |  |  | 45 |  |  | 58 |  |
| Share-based compensation expenses |  | 27 |  |  | 10 |  |  | 37 |  |  | 22 |  |  | 7 |  |  | 29 |  |
| Legal settlements |  | — |  |  | 11 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |
| Acquisition-related transaction fees |  | 6 |  |  | 4 |  |  | 10 |  |  | — |  |  | 1 |  |  | 1 |  |
| Reorganization of business charges |  | 8 |  |  | 2 |  |  | 10 |  |  | 12 |  |  | 4 |  |  | 16 |  |
| Operating lease asset impairment |  | 9 |  |  | — |  |  | 9 |  |  | 5 |  |  | 2 |  |  | 7 |  |
| Fixed asset impairment |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |
| Hytera-related legal expenses |  | 2 |  |  | — |  |  | 2 |  |  | 2 |  |  | — |  |  | 2 |  |
| Gain on Hytera legal settlement |  | (13) |  |  | — |  |  | (13) |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 57 |  |  | 78 |  |  | 135 |  |  | 54 |  |  | 59 |  |  | 113 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 96 |  |  | $ | 278 |  |  | $ | 374 |  |  | $ | 131 |  |  | $ | 280 |  |  | $ | 411 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 3.5 | % |  | 25.3 | % |  | 12.6 | % |  | 7.6 | % |  | 29.1 | % |  | 16.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 8.7 | % |  | 35.2 | % |  | 19.8 | % |  | 12.9 | % |  | 36.9 | % |  | 23.2 | % |

[0000068505-22-000017:8k_2_02:136]
16

[0000068505-22-000017:8k_2_02:137]
Non-GAAP-4

[0000068505-22-000017:8k_2_02:138]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-22-000017:8k_2_02:139]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-22-000017:8k_2_02:140]
(In millions)

[0000068505-22-000017:8k_2_02:141]
|  |  | Three Months Ended |  |  |
|  |  | April 2, 2022 |  | April 3, 2021 |  | % Change |
| Net sales |  | $ | 1,892 |  |  | $ | 1,773 |  |  | 7 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 17 |  |  | — |  |  |  |
| Organic revenue |  | $ | 1,875 |  |  | $ | 1,773 |  |  | 6 | % |

[0000068505-22-000017:8k_2_02:142]
17
