# MSI note change history — 0000068505-21-000027 → 0000068505-22-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-05-12):
[0000068505-22-000019:note_history:1]
Hytera Litigation

- changed (2022-05-12):
[0000068505-22-000019:note_history:2]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  The Court also ordered the parties to jointly file by February 22, 2022, a proposed royalty agreement for the Court's review and approval. Because the parties could not concur on the royalty agreement, they each filed supporting papers for their proposed draft agreements, and on April 12, 2022, the Court issued a ruling generally favorable to the Company on the critical aspects of the royalty agreement. On April 19, 2022, the parties filed an agreed royalty agreement that incorporates the findings of the Court's ruling.
  (was, 2021-11-04, similarity 0.7194):
[0000068505-21-000027:note_history:2]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As of the third quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.

- added (2022-05-12):
[0000068505-22-000019:note_history:3]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief. On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

- added (2022-05-12):
[0000068505-22-000019:note_history:4]
Hytera Bankruptcy Proceedings

- changed (2022-05-12):
[0000068505-22-000019:note_history:5]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. The gain was recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.
  (was, 2021-11-04, similarity 0.7441):
[0000068505-21-000027:note_history:5]
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.

- removed (2022-05-12):
[0000068505-21-000027:note_history:6]
On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. Subsequent to quarter end, on October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

- removed (2022-05-12):
[0000068505-21-000027:note_history:7]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties are briefing a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-12):
[0000068505-22-000019:note_history:8]
Basis of Presentation
The condensed consolidated financial statements as of April 2, 2022 and for the three months ended April 2, 2022 and April 3, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2021-11-04, similarity 0.9361):
[0000068505-21-000027:note_history:8]
Basis of Presentation
The condensed consolidated financial statements as of October 2, 2021 and for the three and nine months ended October 2, 2021 and September 26, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2022-05-12):
[0000068505-22-000019:note_history:9]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three months ended April 2, 2022 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2021-11-04, similarity 0.9608):
[0000068505-21-000027:note_history:9]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three and nine months ended October 2, 2021 are not necessarily indicative of the operating results to be expected for the full year.

- added (2022-05-12):
[0000068505-22-000019:note_history:10]
Business Overview

- added (2022-05-12):
[0000068505-22-000019:note_history:11]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control, and Command Center Software. In January 2022 the Company renamed one of its three major products and services technologies from LMR Mission Critical Communications to LMR Communications in an effort to more succinctly brand its LMR technology. The change was to the name of the technology only and no financial information was reclassified from previous periods presented or for the quarter ended April 2, 2022.

- changed (2022-05-12):
[0000068505-22-000019:note_history:12]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.
  (was, 2021-11-04, similarity 0.9727):
[0000068505-21-000027:note_history:12]
•LMR Mission Critical Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

- changed (2022-05-12):
[0000068505-22-000019:note_history:13]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from "911 call to case closure."
  (was, 2021-11-04, similarity 0.9939):
[0000068505-21-000027:note_history:13]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from 911 call to case closure.

- added (2022-05-12):
[0000068505-22-000019:note_history:14]
Subsequent to quarter end, on May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2022-05-12):
[0000068505-22-000019:note_history:15]
Subsequent to quarter end, on April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

- added (2022-05-12):
[0000068505-22-000019:note_history:16]
On March 23, 2022, the Company acquired TETRA Ireland Communications Limited ("TETRA Ireland"), the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. The business is part of the Software and Services segment.

- added (2022-05-12):
[0000068505-22-000019:note_history:17]
On March 3, 2022, the Company acquired Ava Security Limited ("Ava"), a global provider of cloud-native video security and analytics, for $387 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2022-05-12):
[0000068505-22-000019:note_history:18]
On December 16, 2021, the Company acquired 911 Datamaster, Inc. ("911 Datamaster"), a Next Generation 911 ("NG911") data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces the Company's strategy to be a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The business is a part of the Software and Services segment.

- changed (2022-05-12):
[0000068505-22-000019:note_history:19]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video Security and Access Control. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2021-11-04, similarity 0.6656):
[0000068505-21-000027:note_history:19]
Subsequent to quarter end, on October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video Security and Access Control. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete.

- changed (2022-05-12):
[0000068505-22-000019:note_history:20]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2021-11-04, similarity 0.983):
[0000068505-21-000027:note_history:20]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2022-05-12):
[0000068505-22-000019:note_history:21]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the convertible notes on diluted earnings per common share.

- added (2022-05-12):
[0000068505-22-000019:note_history:22]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, "which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 will result in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

- added (2022-05-12):
[0000068505-22-000019:note_history:23]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.

- removed (2022-05-12):
[0000068505-21-000027:note_history:24]
Change in Presentation

- removed (2022-05-12):
[0000068505-21-000027:note_history:25]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control, and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended October 2, 2021.

- removed (2022-05-12):
[0000068505-21-000027:note_history:26]
On August 28, 2020, the Company acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to the Company's existing Command Center Software suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

- removed (2022-05-12):
[0000068505-21-000027:note_history:27]
On July 31, 2020, the Company acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates the Company's continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- removed (2022-05-12):
[0000068505-21-000027:note_history:28]
On June 16, 2020, the Company acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Access Control technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

- removed (2022-05-12):
[0000068505-21-000027:note_history:29]
On April 30, 2020, the Company acquired a cybersecurity services business for $32 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

- removed (2022-05-12):
[0000068505-21-000027:note_history:30]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands the Company's ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

- removed (2022-05-12):
[0000068505-21-000027:note_history:31]
Recent Accounting Pronouncements

- removed (2022-05-12):
[0000068505-21-000027:note_history:32]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of the adoption of this ASU on its financial statements and disclosures.

- removed (2022-05-12):
[0000068505-21-000027:note_history:33]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-12):
[0000068505-22-000019:note_history:34]
Debt and Credit Facilities
As of April 2, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 2, 2022.
  (was, 2021-11-04, similarity 0.971):
[0000068505-21-000027:note_history:34]
As of October 2, 2021, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 2, 2021.

- changed (2022-05-12):
[0000068505-22-000019:note_history:35]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 2, 2022 the Company had no outstanding debt under the commercial paper program.
  (was, 2021-11-04, similarity 0.9912):
[0000068505-21-000027:note_history:35]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of October 2, 2021 the Company had no outstanding debt under the commercial paper program.

- removed (2022-05-12):
[0000068505-21-000027:note_history:36]
Debt and Credit Facilities

- removed (2022-05-12):
[0000068505-21-000027:note_history:37]
|  | October 2, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 8 |  |  | 18 |  |
|  | 5,695 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (6) |  |  | (12) |  |
| Long-term debt | $ | 5,687 |  |  | $ | 5,163 |  |

- removed (2022-05-12):
[0000068505-21-000027:note_history:38]
In May of 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of its outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-05-12):
[0000068505-21-000027:note_history:39]
|  | October 2, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 8 |  |  | 18 |  |
|  | 5,695 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (6) |  |  | (12) |  |
| Long-term debt | $ | 5,687 |  |  | $ | 5,163 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-12):
[0000068505-22-000019:note_history:40]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 2, 2022 and April 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2021-11-04, similarity 0.9168):
[0000068505-21-000027:note_history:40]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 2, 2021 and September 26, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2022-05-12):
[0000068505-22-000019:note_history:41]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |  | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |
| International | 272 |  |  | 315 |  |  | 587 |  |  | 273 |  |  | 315 |  |  | 588 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |  | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |
| Video Security and Access Control | 194 |  |  | 113 |  |  | 307 |  |  | 165 |  |  | 88 |  |  | 253 |  |
| Command Center Software | — |  |  | 130 |  |  | 130 |  |  | — |  |  | 119 |  |  | 119 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |  | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |
| Indirect | 447 |  |  | 87 |  |  | 534 |  |  | 411 |  |  | 68 |  |  | 479 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
  (was, 2021-11-04, similarity 0.8318):
[0000068505-21-000027:note_history:41]
|  | Three Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |  | $ | 863 |  |  | $ | 405 |  |  | $ | 1,268 |  |
| International | 333 |  |  | 325 |  |  | 658 |  |  | 300 |  |  | 300 |  |  | 600 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |  | $ | 989 |  |  | $ | 510 |  |  | $ | 1,499 |  |
| Video Security and Access Control | 214 |  |  | 102 |  |  | 316 |  |  | 174 |  |  | 77 |  |  | 251 |  |
| Command Center Software | — |  |  | 133 |  |  | 133 |  |  | — |  |  | 118 |  |  | 118 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |  | $ | 733 |  |  | $ | 637 |  |  | $ | 1,370 |  |
| Indirect | 487 |  |  | 79 |  |  | 566 |  |  | 430 |  |  | 68 |  |  | 498 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |

- removed (2022-05-12):
[0000068505-21-000027:note_history:42]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |  | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 3,476 |  |
| International | 935 |  |  | 970 |  |  | 1,905 |  |  | 794 |  |  | 871 |  |  | 1,665 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |  | $ | 2,685 |  |  | $ | 1,480 |  |  | $ | 4,165 |  |
| Video Security and Access Control | 590 |  |  | 284 |  |  | 874 |  |  | 439 |  |  | 196 |  |  | 635 |  |
| Command Center Software | — |  |  | 387 |  |  | 387 |  |  | — |  |  | 341 |  |  | 341 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |  | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 3,877 |  |
| Indirect | 1,390 |  |  | 214 |  |  | 1,604 |  |  | 1,116 |  |  | 148 |  |  | 1,264 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-12):
[0000068505-22-000019:note_history:43]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 2, 2022 and April 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2021-11-04, similarity 0.9168):
[0000068505-21-000027:note_history:43]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 2, 2021 and September 26, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2022-05-12):
[0000068505-22-000019:note_history:44]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |  | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |
| International | 272 |  |  | 315 |  |  | 587 |  |  | 273 |  |  | 315 |  |  | 588 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |  | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |
| Video Security and Access Control | 194 |  |  | 113 |  |  | 307 |  |  | 165 |  |  | 88 |  |  | 253 |  |
| Command Center Software | — |  |  | 130 |  |  | 130 |  |  | — |  |  | 119 |  |  | 119 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |  | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |
| Indirect | 447 |  |  | 87 |  |  | 534 |  |  | 411 |  |  | 68 |  |  | 479 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
  (was, 2021-11-04, similarity 0.8318):
[0000068505-21-000027:note_history:44]
|  | Three Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |  | $ | 863 |  |  | $ | 405 |  |  | $ | 1,268 |  |
| International | 333 |  |  | 325 |  |  | 658 |  |  | 300 |  |  | 300 |  |  | 600 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |  | $ | 989 |  |  | $ | 510 |  |  | $ | 1,499 |  |
| Video Security and Access Control | 214 |  |  | 102 |  |  | 316 |  |  | 174 |  |  | 77 |  |  | 251 |  |
| Command Center Software | — |  |  | 133 |  |  | 133 |  |  | — |  |  | 118 |  |  | 118 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |  | $ | 733 |  |  | $ | 637 |  |  | $ | 1,370 |  |
| Indirect | 487 |  |  | 79 |  |  | 566 |  |  | 430 |  |  | 68 |  |  | 498 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |

- changed (2022-05-12):
[0000068505-22-000019:note_history:45]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 2, 2022 was $9.0 billion. A total of $4.1 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of April 2, 2022, of which $2.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.9 billion was from Software and Services performance obligations that were not yet satisfied as of April 2, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2021-11-04, similarity 0.9875):
[0000068505-21-000027:note_history:45]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of October 2, 2021 was $7.1 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of October 2, 2021, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.5 billion was from Software and Services performance obligations that were not yet satisfied as of October 2, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2022-05-12):
[0000068505-22-000019:note_history:46]
| (In millions) | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,151 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 999 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,590 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 299 |  |  | 306 |  |  |  |  |  |
  (was, 2021-11-04, similarity 0.9771):
[0000068505-21-000027:note_history:46]
| (In millions) | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,196 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 1,030 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,538 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 309 |  |  | 283 |  |  |  |  |  |

- added (2022-05-12):
[0000068505-22-000019:note_history:47]
Revenue recognized during the three months ended April 2, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $456 million, compared to $396 million of revenue recognized during the three months ended April 3, 2021 which was previously included in Contract liabilities as of December 31, 2020. Revenue of $17 million was reversed during the three months ended April 2, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $4 million of reversals for the three months ended April 3, 2021.

- changed (2022-05-12):
[0000068505-22-000019:note_history:48]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 2, 2022 and April 3, 2021.
  (was, 2021-11-04, similarity 0.8982):
[0000068505-21-000027:note_history:48]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended October 2, 2021 and September 26, 2020.

- changed (2022-05-12):
[0000068505-22-000019:note_history:49]
| (In millions) | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 39 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 118 |  |  | 124 |  |  |  |  |  |
  (was, 2021-11-04, similarity 0.9718):
[0000068505-21-000027:note_history:49]
| (In millions) | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 26 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 113 |  |  | 105 |  |  |  |  |  |

- added (2022-05-12):
[0000068505-22-000019:note_history:50]
Amortization of non-current contract cost assets was $13 million for each of the three months ended April 2, 2022 and April 3, 2021

- removed (2022-05-12):
[0000068505-21-000027:note_history:51]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |  | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 3,476 |  |
| International | 935 |  |  | 970 |  |  | 1,905 |  |  | 794 |  |  | 871 |  |  | 1,665 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |  | $ | 2,685 |  |  | $ | 1,480 |  |  | $ | 4,165 |  |
| Video Security and Access Control | 590 |  |  | 284 |  |  | 874 |  |  | 439 |  |  | 196 |  |  | 635 |  |
| Command Center Software | — |  |  | 387 |  |  | 387 |  |  | — |  |  | 341 |  |  | 341 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |  | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 3,877 |  |
| Indirect | 1,390 |  |  | 214 |  |  | 1,604 |  |  | 1,116 |  |  | 148 |  |  | 1,264 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |

- removed (2022-05-12):
[0000068505-21-000027:note_history:52]
Revenue recognized during the three months ended October 2, 2021 which was previously included in Contract liabilities as of July 3, 2021 was $472 million, compared to $349 million of revenue recognized during the three months ended September 26, 2020 which was previously included in Contract liabilities as of June 27, 2020. Revenue recognized during the nine months ended October 2, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $946 million, compared to $807 million recognized during the nine months ended September 26, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $2 million and $15 million was reversed during the three and nine months ended October 2, 2021, respectively, related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $12 million and $48 million of reversals for the three and nine months ended September 26, 2020, respectively.

- removed (2022-05-12):
[0000068505-21-000027:note_history:53]
Amortization of non-current contract cost assets was $12 million and $37 million for the three and nine months ended October 2, 2021, respectively, and $13 million and $35 million for the three and nine months ended September 26, 2020, respectively
