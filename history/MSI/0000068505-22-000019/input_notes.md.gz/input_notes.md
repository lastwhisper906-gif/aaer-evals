# MSI notes — 0000068505-22-000019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-22-000019:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of April 2, 2022 and for the three months ended April 2, 2022 and April 3, 2021 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-22-000019:notes:2]
[same as prior period, unchanged from 0000068505-21-000027:notes:2]

[0000068505-22-000019:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2021 (the "Form 10-K"). The results of operations for the three months ended April 2, 2022 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-22-000019:notes:4]
[same as prior period, unchanged from 0000068505-21-000027:notes:4]

[0000068505-22-000019:notes:5]
Business Overview

[0000068505-22-000019:notes:6]
The Company reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control, and Command Center Software. In January 2022 the Company renamed one of its three major products and services technologies from LMR Mission Critical Communications to LMR Communications in an effort to more succinctly brand its LMR technology. The change was to the name of the technology only and no financial information was reclassified from previous periods presented or for the quarter ended April 2, 2022.

[0000068505-22-000019:notes:7]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and Professional Commercial Radio ("PCR")) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

[0000068505-22-000019:notes:8]
[same as prior period, unchanged from 0000068505-21-000027:notes:8]

[0000068505-22-000019:notes:9]
•Command Center Software: Software suite that enables collaboration and seamless information sharing through the public safety workflow from "911 call to case closure."

[0000068505-22-000019:notes:10]
[same as prior period, unchanged from 0000068505-21-000027:notes:10]

[0000068505-22-000019:notes:11]
Subsequent to quarter end, on May 12, 2022, the Company acquired Videotec S.p.A. ("Videotec"), a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000019:notes:12]
Subsequent to quarter end, on April 19, 2022, the Company acquired Calipsa, Inc. ("Calipsa"), a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

[0000068505-22-000019:notes:13]
On March 23, 2022, the Company acquired TETRA Ireland Communications Limited ("TETRA Ireland"), the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. The business is part of the Software and Services segment.

[0000068505-22-000019:notes:14]
On March 3, 2022, the Company acquired Ava Security Limited ("Ava"), a global provider of cloud-native video security and analytics, for $387 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000019:notes:15]
On December 16, 2021, the Company acquired 911 Datamaster, Inc. ("911 Datamaster"), a Next Generation 911 ("NG911") data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces the Company's strategy to be a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The business is a part of the Software and Services segment.

[0000068505-22-000019:notes:16]
On October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video Security and Access Control. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000019:notes:17]
On July 15, 2021, the Company acquired Openpath Security Inc. ("Openpath"), a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-22-000019:notes:18]
Recently Adopted Accounting Pronouncements

[0000068505-22-000019:notes:19]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The Company adopted ASU No. 2020-06 on January 1, 2022, using the modified retrospective method of adoption. As a result of the adoption of this ASU, the Company's $1 billion of 1.75% senior convertible notes due 2024 issued to Silver Lake Partners (the "Senior Convertible Notes") are accounted as a single liability measured at its amortized cost, given the embedded conversion feature does not require bifurcation and recognition as a derivative. Upon adoption of this ASU, amounts previously recognized in additional paid-in capital from the original embedded conversion feature of $10 million were reclassified to retained earnings. The Company uses the if-converted method as required under ASU No. 2020-06 to determine the dilutive effect of the convertible instrument. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the effect of the convertible notes on diluted earnings per common share.

[0000068505-22-000019:notes:20]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805) - Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, "which requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC Topic 606. Under current U.S. GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 will result in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures. The Company anticipates that this adoption will generally result in the Company recognizing larger contract liabilities in connection with business combinations.

[0000068505-22-000019:notes:21]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832) – Disclosures by Business Entities about Government Assistance." This ASU requires disclosures that are expected to increase the transparency of transactions with a governmental entity accounted for by applying a grant or contribution accounting model by analogy, including disclosures around: (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis, and the adoption of this standard did not have a material impact on the Company's financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-22-000019:notes:22]
[same as prior period, unchanged from 0000068505-21-000027:notes:22]

[0000068505-22-000019:notes:23]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 2, 2022 and April 3, 2021, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-22-000019:notes:24]
|  | Three Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 831 |  |  | $ | 474 |  |  | $ | 1,305 |  |  | $ | 742 |  |  | $ | 443 |  |  | $ | 1,185 |  |
| International | 272 |  |  | 315 |  |  | 587 |  |  | 273 |  |  | 315 |  |  | 588 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 909 |  |  | $ | 546 |  |  | $ | 1,455 |  |  | $ | 850 |  |  | $ | 551 |  |  | $ | 1,401 |  |
| Video Security and Access Control | 194 |  |  | 113 |  |  | 307 |  |  | 165 |  |  | 88 |  |  | 253 |  |
| Command Center Software | — |  |  | 130 |  |  | 130 |  |  | — |  |  | 119 |  |  | 119 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 656 |  |  | $ | 702 |  |  | $ | 1,358 |  |  | $ | 604 |  |  | $ | 690 |  |  | $ | 1,294 |  |
| Indirect | 447 |  |  | 87 |  |  | 534 |  |  | 411 |  |  | 68 |  |  | 479 |  |
|  | $ | 1,103 |  |  | $ | 789 |  |  | $ | 1,892 |  |  | $ | 1,015 |  |  | $ | 758 |  |  | $ | 1,773 |  |

[0000068505-22-000019:notes:25]
[same as prior period, unchanged from 0000068505-21-000027:notes:26]

[0000068505-22-000019:notes:26]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of April 2, 2022 was $9.0 billion. A total of $4.1 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of April 2, 2022, of which $2.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.9 billion was from Software and Services performance obligations that were not yet satisfied as of April 2, 2022. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-22-000019:notes:27]
[same as prior period, unchanged from 0000068505-21-000027:notes:28]

[0000068505-22-000019:notes:28]
| (In millions) | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Accounts receivable, net | $ | 1,151 |  |  | $ | 1,386 |  |  |  |  |  |
| Contract assets | 999 |  |  | 1,105 |  |  |  |  |  |
| Contract liabilities | 1,590 |  |  | 1,650 |  |  |  |  |  |
| Non-current contract liabilities | 299 |  |  | 306 |  |  |  |  |  |

[0000068505-22-000019:notes:29]
Revenue recognized during the three months ended April 2, 2022 which was previously included in Contract liabilities as of December 31, 2021 was $456 million, compared to $396 million of revenue recognized during the three months ended April 3, 2021 which was previously included in Contract liabilities as of December 31, 2020. Revenue of $17 million was reversed during the three months ended April 2, 2022 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $4 million of reversals for the three months ended April 3, 2021.

[0000068505-22-000019:notes:30]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 2, 2022 and April 3, 2021.

[0000068505-22-000019:notes:31]
[same as prior period, unchanged from 0000068505-21-000027:notes:32]

[0000068505-22-000019:notes:32]
| (In millions) | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Current contract cost assets | $ | 39 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 118 |  |  | 124 |  |  |  |  |  |

[0000068505-22-000019:notes:33]
Amortization of non-current contract cost assets was $13 million for each of the three months ended April 2, 2022 and April 3, 2021


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-22-000019:notes:34]
[same as prior period, unchanged from 0000068505-21-000027:notes:35]

[0000068505-22-000019:notes:35]
|  | Three Months Ended |  |  |
| (in millions) | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 33 |  |  | $ | 33 |  |  |  |  |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | 2 |  |  | 3 |  |  |  |  |  |
| Short-term lease cost | 1 |  |  | 1 |  |  |  |  |  |
| Variable cost | 9 |  |  | 9 |  |  |  |  |  |
| Sublease income | (1) |  |  | (1) |  |  |  |  |  |
| Net lease expense | $ | 44 |  |  | $ | 45 |  |  |  |  |  |

[0000068505-22-000019:notes:36]
[same as prior period, unchanged from 0000068505-21-000027:notes:37]

[0000068505-22-000019:notes:37]
| (in millions) |  | Statement Line Classification |  | April 2, 2022 |  | December 31, 2021 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 387 |  |  | $ | 382 |  |  |  |
| Finance lease assets |  | Property, plant and equipment, net |  | 15 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 402 |  |  | $ | 398 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 102 |  |  | $ | 124 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 3 |  |  | 4 |  |  |  |
|  |  |  |  | $ | 105 |  |  | $ | 128 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 320 |  |  | $ | 313 |  |  |  |
|  |  |  |  | $ | 320 |  |  | $ | 313 |  |  |  |

[0000068505-22-000019:notes:38]
[same as prior period, unchanged from 0000068505-21-000027:notes:39]

[0000068505-22-000019:notes:39]
|  | Three Months Ended |  |  |
| (in millions) | April 2, 2022 |  | April 3, 2021 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 62 |  |  | $ | 54 |  |  |  |
| Net cash used for financing activities related to finance leases | 2 |  |  | 3 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 40 |  |  | $ | 15 |  |  |  |

[0000068505-22-000019:notes:40]
The increase in assets obtained in exchange for lease liabilities for the three months ended April 2, 2022 compared to the three months ended April 3, 2021 was primarily due to $27 million of additional leases acquired in connection with the Company's acquisition of TETRA Ireland during the quarter ended April 2, 2022.

[0000068505-22-000019:notes:41]
|  | April 2, 2022 |  | December 31, 2021 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 6 |
| Finance leases | 1 |  | 1 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.18 | % |  | 3.11 | % |
| Finance leases | 3.94 | % |  | 3.99 | % |

[0000068505-22-000019:notes:42]
[same as prior period, unchanged from 0000068505-21-000027:notes:42]

[0000068505-22-000019:notes:43]
|  | April 2, 2022 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2022 | $ | 81 |  |  | $ | 3 |  |  | $ | 84 |  |
| 2023 | 91 |  |  | — |  |  | 91 |  |
| 2024 | 76 |  |  | — |  |  | 76 |  |
| 2025 | 60 |  |  | — |  |  | 60 |  |
| 2026 | 48 |  |  | — |  |  | 48 |  |
| Thereafter | 109 |  |  | — |  |  | 109 |  |
| Total lease payments | 465 |  |  | 3 |  |  | 468 |  |
| Less: interest | 43 |  |  | — |  |  | 43 |  |
| Present value of lease liabilities | $ | 422 |  |  | $ | 3 |  |  | $ | 425 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-22-000019:notes:44]
[same as prior period, unchanged from 0000068505-21-000027:notes:44]

[0000068505-22-000019:notes:45]
[same as prior period, unchanged from 0000068505-21-000027:notes:45]

[0000068505-22-000019:notes:46]
[same as prior period, unchanged from 0000068505-21-000027:notes:46]

[0000068505-22-000019:notes:47]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 66 |  |  | $ | 58 |  |  |  |  |  |
| Reorganization of business (Note 14) | 7 |  |  | 14 |  |  |  |  |  |
| Operating lease asset impairments | 9 |  |  | 7 |  |  |  |  |  |
| Acquisition-related transaction fees | 10 |  |  | 1 |  |  |  |  |  |
| Legal settlements | 11 |  |  | — |  |  |  |  |  |
| Fixed asset impairment | 3 |  |  | — |  |  |  |  |  |
| Gain on Hytera legal settlement | (13) |  |  | — |  |  |  |  |  |
| Other | (1) |  |  | (1) |  |  |  |  |  |
|  | $ | 92 |  |  | $ | 79 |  |  |  |  |  |

[0000068505-22-000019:notes:48]
In February 2022, the Company recognized a gain of $13 million related to the recovery, through legal proceedings to seize and liquidate assets, of financial receivables owed to the Company by the bankruptcy estate of the two U.S. subsidiaries of Hytera Communications Corporation Limited of Shenzhen, China.  Refer also to "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for additional information related to these proceedings.

[0000068505-22-000019:notes:49]
[same as prior period, unchanged from 0000068505-21-000027:notes:50]

[0000068505-22-000019:notes:50]
[same as prior period, unchanged from 0000068505-21-000027:notes:51]

[0000068505-22-000019:notes:51]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (58) |  |  | $ | (56) |  |  |  |  |  |
| Interest income | 2 |  |  | 2 |  |  |  |  |  |
|  | $ | (56) |  |  | $ | (54) |  |  |  |  |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 32 |  |  | $ | 30 |  |  |  |  |  |
| Investment impairments | (1) |  |  | — |  |  |  |  |  |
| Foreign currency gain | 23 |  |  | 14 |  |  |  |  |  |
| Loss on derivative instruments (Note 6) | (23) |  |  | (8) |  |  |  |  |  |
| Gain on equity method investments | — |  |  | 2 |  |  |  |  |  |
| Fair value adjustments to equity investments | (18) |  |  | 5 |  |  |  |  |  |
| Gain on TETRA Ireland equity method investment | 21 |  |  | — |  |  |  |  |  |
| Other | — |  |  | 2 |  |  |  |  |  |
|  | $ | 34 |  |  | $ | 45 |  |  |  |  |  |

[0000068505-22-000019:notes:52]
The Company previously held a minority ownership interest in TETRA Ireland, and, upon acquisition of 100% of the equity of TETRA Ireland in the first quarter of 2022, recorded a $21 million gain to adjust the Company's initial equity method investment to fair value during the three months ended April 2, 2022.  Refer to Note 15, "Intangible Assets and Goodwill" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for further information related to this acquisition.

[0000068505-22-000019:notes:53]
[same as prior period, unchanged from 0000068505-21-000027:notes:53]

[0000068505-22-000019:notes:54]
[same as prior period, unchanged from 0000068505-21-000027:notes:54]

[0000068505-22-000019:notes:55]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 267 |  |  | $ | 244 |  |  |  |  |  |
| Weighted average common shares outstanding | 168.0 |  |  | 169.3 |  |  |  |  |  |
| Per share amount | $ | 1.59 |  |  | $ | 1.44 |  |  |  |  |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 267 |  |  | $ | 244 |  |  |  |  |  |
| Weighted average common shares outstanding | 168.0 |  |  | 169.3 |  |  |  |  |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 4.5 |  |  | 3.9 |  |  |  |  |  |
| 1.75% senior convertible notes | 0.6 |  |  | — |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 173.1 |  |  | 173.2 |  |  |  |  |  |
| Per share amount | $ | 1.54 |  |  | $ | 1.41 |  |  |  |  |  |

[0000068505-22-000019:notes:56]
In the computation of diluted earnings per common share for the three months ended April 2, 2022, the assumed exercise of 0.2 million options were excluded because their inclusion would have been antidilutive. For the three months ended April 3, 2021, 0.3 million options were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-22-000019:notes:57]
As of April 2, 2022, the Company had $1.0 billion of the Senior Convertible Notes outstanding, which mature on September 15, 2024. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, when the average stock price exceeded the contractual conversion price, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the quarter ended October 2, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion (under the if-converted method of accounting for share dilution) in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended April 2, 2022. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of April 2, 2022 was $124 million. For the period ended April 3, 2021, there was no dilutive effect of the Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price.

[0000068505-22-000019:notes:58]
[same as prior period, unchanged from 0000068505-21-000027:notes:59]

[0000068505-22-000019:notes:59]
[same as prior period, unchanged from 0000068505-21-000027:notes:60]

[0000068505-22-000019:notes:60]
[same as prior period, unchanged from 0000068505-21-000027:notes:61]

[0000068505-22-000019:notes:61]
|  | April 2, 2022 |  | December 31, 2021 |
| Accounts receivable | $ | 1,221 |  |  | $ | 1,456 |  |
| Less allowance for credit losses | (70) |  |  | (70) |  |
|  | $ | 1,151 |  |  | $ | 1,386 |  |

[0000068505-22-000019:notes:62]
[same as prior period, unchanged from 0000068505-21-000027:notes:63]

[0000068505-22-000019:notes:63]
[same as prior period, unchanged from 0000068505-21-000027:notes:64]

[0000068505-22-000019:notes:64]
|  | April 2, 2022 |  | December 31, 2021 |
| Finished goods | $ | 309 |  |  | $ | 268 |  |
| Work-in-process and production materials | 766 |  |  | 643 |  |
|  | 1,075 |  |  | 911 |  |
| Less inventory reserves | (123) |  |  | (123) |  |
|  | $ | 952 |  |  | $ | 788 |  |

[0000068505-22-000019:notes:65]
[same as prior period, unchanged from 0000068505-21-000027:notes:66]

[0000068505-22-000019:notes:66]
[same as prior period, unchanged from 0000068505-21-000027:notes:67]

[0000068505-22-000019:notes:67]
|  | April 2, 2022 |  | December 31, 2021 |
| Current contract cost assets (Note 2) | $ | 39 |  |  | $ | 30 |  |
| Tax-related deposits | 42 |  |  | 41 |  |
| Other | 219 |  |  | 188 |  |
|  | $ | 300 |  |  | $ | 259 |  |

[0000068505-22-000019:notes:68]
[same as prior period, unchanged from 0000068505-21-000027:notes:69]

[0000068505-22-000019:notes:69]
[same as prior period, unchanged from 0000068505-21-000027:notes:70]

[0000068505-22-000019:notes:70]
|  | April 2, 2022 |  | December 31, 2021 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 473 |  |  | 474 |  |
| Machinery and equipment | 2,494 |  |  | 2,439 |  |
|  | 2,972 |  |  | 2,918 |  |
| Less accumulated depreciation | (1,892) |  |  | (1,876) |  |
|  | $ | 1,080 |  |  | $ | 1,042 |  |

[0000068505-22-000019:notes:71]
Depreciation expense for the three months ended April 2, 2022 and April 3, 2021 was $45 million and $52 million, respectively.

[0000068505-22-000019:notes:72]
[same as prior period, unchanged from 0000068505-21-000027:notes:73]

[0000068505-22-000019:notes:73]
[same as prior period, unchanged from 0000068505-21-000027:notes:74]

[0000068505-22-000019:notes:74]
|  | April 2, 2022 |  | December 31, 2021 |  |  |  |  |
| Common stock | $ | 50 |  |  | $ | 69 |  |  |  |  |  |
| Strategic investments | 40 |  |  | 35 |  |  |  |  |  |
| Company-owned life insurance policies | 78 |  |  | 81 |  |  |  |  |  |
| Equity method investments | 15 |  |  | 24 |  |  |  |  |  |
|  | $ | 183 |  |  | $ | 209 |  |  |  |  |  |

[0000068505-22-000019:notes:75]
On July 16, 2021, the Company paid $50 million for equity securities of NewHold Investment Corp. ("NHIC"), a special purpose acquisition company (SPAC) that completed a business combination with Evolv Technologies, Inc. After the business combination, NHIC was renamed “Evolv Technologies Holdings, Inc.” (together with its subsidiaries, “Evolv”). During the three months ended April 2, 2022, the Company recognized a loss of $12 million in Other income (expense) related to a decrease in the fair value of the investment.

[0000068505-22-000019:notes:76]
[same as prior period, unchanged from 0000068505-21-000027:notes:77]

[0000068505-22-000019:notes:77]
[same as prior period, unchanged from 0000068505-21-000027:notes:78]

[0000068505-22-000019:notes:78]
|  | April 2, 2022 |  | December 31, 2021 |
| Defined benefit plan assets | $ | 380 |  |  | $ | 365 |  |
| Non-current contract cost assets (Note 2) | 118 |  |  | 124 |  |
| Other | 54 |  |  | 69 |  |
|  | $ | 552 |  |  | $ | 558 |  |

[0000068505-22-000019:notes:79]
[same as prior period, unchanged from 0000068505-21-000027:notes:80]

[0000068505-22-000019:notes:80]
[same as prior period, unchanged from 0000068505-21-000027:notes:81]

[0000068505-22-000019:notes:81]
|  | April 2, 2022 |  | December 31, 2021 |
| Compensation | $ | 310 |  |  | $ | 360 |  |
| Tax liabilities | 262 |  |  | 183 |  |
| Dividend payable | 132 |  |  | 134 |  |
| Trade liabilities | 166 |  |  | 235 |  |
| Operating lease liabilities (Note 3) | 102 |  |  | 124 |  |
| Other | 493 |  |  | 521 |  |
|  | $ | 1,465 |  |  | $ | 1,557 |  |

[0000068505-22-000019:notes:82]
[same as prior period, unchanged from 0000068505-21-000027:notes:83]

[0000068505-22-000019:notes:83]
[same as prior period, unchanged from 0000068505-21-000027:notes:84]

[0000068505-22-000019:notes:84]
|  | April 2, 2022 |  | December 31, 2021 |
| Defined benefit plans | $ | 1,341 |  |  | $ | 1,390 |  |
| Non-current contract liabilities (Note 2) | 299 |  |  | 306 |  |
| Unrecognized tax benefits (Note 7) | 36 |  |  | 36 |  |
| Deferred income taxes (Note 7) | 143 |  |  | 183 |  |
| Environmental reserve | 108 |  |  | 108 |  |
| Other | 125 |  |  | 125 |  |
|  | $ | 2,052 |  |  | $ | 2,148 |  |

[0000068505-22-000019:notes:85]
[same as prior period, unchanged from 0000068505-21-000027:notes:86]

[0000068505-22-000019:notes:86]
Share Repurchase Program: During the three months ended April 2, 2022, the Company repurchased approximately 2.2 million shares at an average price of $224.41 per share for an aggregate of $493 million, including transaction costs. As of April 2, 2022, the Company had $1.6 billion of authority available for future repurchases.

[0000068505-22-000019:notes:87]
Payment of Dividends: During the three months ended April 2, 2022 and April 3, 2021, the Company paid $134 million and $121 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $132 million in cash dividends to holders of its common stock.

[0000068505-22-000019:notes:88]
[same as prior period, unchanged from 0000068505-21-000027:notes:89]

[0000068505-22-000019:notes:89]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended April 2, 2022 and April 3, 2021:

[0000068505-22-000019:notes:90]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (384) |  |  | $ | (360) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | (18) |  |  | 17 |  |  |  |  |  |
| Tax benefit (expense) | (2) |  |  | 2 |  |  |  |  |  |
| Other comprehensive income (loss), net of tax | (20) |  |  | 19 |  |  |  |  |  |
| Balance at end of period | $ | (404) |  |  | $ | (341) |  |  |  |  |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,995) |  |  | $ | (2,086) |  |  |  |  |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 20 |  |  | 22 |  |  |  |  |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | (1) |  |  | (2) |  |  |  |  |  |
| Tax expense | (4) |  |  | (3) |  |  |  |  |  |
| Other comprehensive income, net of tax | 15 |  |  | 17 |  |  |  |  |  |
| Balance at end of period | $ | (1,980) |  |  | $ | (2,069) |  |  |  |  |  |
| Total Accumulated other comprehensive loss | $ | (2,384) |  |  | $ | (2,410) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-22-000019:notes:91]
Debt and Credit Facilities
As of April 2, 2022, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 2, 2022.

[0000068505-22-000019:notes:92]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 2, 2022 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-22-000019:notes:93]
[same as prior period, unchanged from 0000068505-21-000027:notes:97]

[0000068505-22-000019:notes:94]
At April 2, 2022, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.0 billion, compared to $1.1 billion at December 31, 2021. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-22-000019:notes:95]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 2, 2022, and the corresponding positions as of December 31, 2021:

[0000068505-22-000019:notes:96]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 2, 2022 |  | December 31, 2021 |
| British pound | $ | 221 |  |  | $ | 128 |  |
| Euro | 200 |  |  | 164 |  |
| Chinese renminbi | (79) |  |  | (89) |  |
| Australian dollar | (68) |  |  | (76) |  |
| Brazilian real | (32) |  |  | (23) |  |

[0000068505-22-000019:notes:97]
[same as prior period, unchanged from 0000068505-21-000027:notes:101]

[0000068505-22-000019:notes:98]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 2, 2022, all of the counterparties had investment grade credit ratings. As of April 2, 2022, the Company had $4 million of exposure to aggregate credit risk with all counterparties.

[0000068505-22-000019:notes:99]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of April 2, 2022 and December 31, 2021:

[0000068505-22-000019:notes:100]
|  | Fair Values of Derivative Instruments |
| April 2, 2022 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 2 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 2 |  |  | 10 |  |
| Total derivatives | $ | 4 |  |  | $ | 10 |  |

[0000068505-22-000019:notes:101]
|  | Fair Values of Derivative Instruments |
| December 31, 2021 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 2 |  |  | 5 |  |
| Total derivatives | $ | 7 |  |  | $ | 5 |  |

[0000068505-22-000019:notes:102]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended April 2, 2022 and April 3, 2021:

[0000068505-22-000019:notes:103]
|  | Financial Statement Location | Three Months Ended |  |  |
| Foreign Exchange Contracts | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Effective portion | Accumulated othercomprehensive loss | $ | 2 |  |  | $ | 4 |  |  |  |  |  |
| Undesignated derivatives recognized | Other income (expense) | (23) |  |  | (8) |  |  |  |  |  |

[0000068505-22-000019:notes:104]
[same as prior period, unchanged from 0000068505-21-000027:notes:108]

[0000068505-22-000019:notes:105]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of April 2, 2022, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £25 million of net investment hedges in certain British pound functional subsidiaries.
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-22-000019:notes:106]
[same as prior period, unchanged from 0000068505-21-000027:notes:111]

[0000068505-22-000019:notes:107]
In January 2022, the Company completed an intra-group transfer of certain intellectual property ("IP") rights from non-U.S. wholly-owned subsidiaries of the Company to the United States in order to better align with current and future business operations. The transfer resulted in a step-up in tax basis driven by the fair value of the transferred IP rights, resulting in a one-time net deferred benefit of $77 million in the quarter ended April 2, 2022. The determination of the fair value involves judgment on future revenue growth, operating margins and discount rates. The Company expects to realize the net deferred tax asset recorded as a result of the IP transfer and will periodically assess such realizability. The tax-deductible amortization related to the transferred IP rights will be recognized over a 15-year period.

[0000068505-22-000019:notes:108]
[same as prior period, unchanged from 0000068505-21-000027:notes:112]

[0000068505-22-000019:notes:109]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Net earnings before income taxes | $ | 219 |  |  | $ | 289 |  |  |  |  |  |
| Income tax expense (benefit) | (49) |  |  | 44 |  |  |  |  |  |
| Effective tax rate | (22) | % |  | 15 | % |  |  |  |  |

[0000068505-22-000019:notes:110]
The effective tax rate for the three months ended April 2, 2022 of (22)% was lower than the U.S. federal statutory tax rate of 21% primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights (as described above), a higher foreign derived intangible income deduction and the excess tax benefits of share-based compensation.

[0000068505-22-000019:notes:111]
The effective tax rate for the three months ended April 3, 2021 of 15% was lower than the U.S. federal statutory tax rate of 21% due to the excess tax benefits on share-based compensation, offset by state tax expense.
The effective tax rate for the three months ended April 2, 2022 of (22)% was lower than the effective tax rate for the three months ended April 3, 2021 of 15%, primarily due to a net deferred tax benefit as a result of an intra-group transfer of certain IP rights (as described above) and a higher tax rate benefit from the foreign derived intangible income deduction and share-based compensation in 2022 compared to 2021


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-22-000019:notes:112]
[same as prior period, unchanged from 0000068505-21-000027:notes:117]

[0000068505-22-000019:notes:113]
[same as prior period, unchanged from 0000068505-21-000027:notes:118]

[0000068505-22-000019:notes:114]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 32 |  |  | 29 |  |  | 8 |  |  | 5 |  |  | — |  |  | — |  |
| Expected return on plan assets | (63) |  |  | (59) |  |  | (26) |  |  | (25) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 17 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | (1) |  |  | — |  |  | (1) |  |
| Net periodic pension benefits | $ | (16) |  |  | $ | (13) |  |  | $ | (14) |  |  | $ | (16) |  |  | $ | (2) |  |  | $ | (3) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-22-000019:notes:115]
[same as prior period, unchanged from 0000068505-21-000027:notes:121]

[0000068505-22-000019:notes:116]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 6 |  |  | $ | 4 |  |  |  |  |  |
| Selling, general and administrative expenses | 21 |  |  | 17 |  |  |  |  |  |
| Research and development expenditures | 10 |  |  | 8 |  |  |  |  |  |
| Share-based compensation expense included in Operating earnings | 37 |  |  | 29 |  |  |  |  |  |
| Tax benefit | (8) |  |  | (6) |  |  |  |  |  |
| Share-based compensation expense, net of tax | $ | 29 |  |  | $ | 23 |  |  |  |  |  |
| Decrease in basic earnings per share | $ | (0.17) |  |  | $ | (0.14) |  |  |  |  |  |
| Decrease in diluted earnings per share | $ | (0.17) |  |  | $ | (0.13) |  |  |  |  |  |

[0000068505-22-000019:notes:117]
During the three months ended April 2, 2022, the Company granted 0.7 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $140 million, $16 million, and $10 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $7 million and $10 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-22-000019:notes:118]
During the three months ended April 2, 2022, the Company granted 0.01 million shares of restricted stock with an aggregate grant-date fair value of $3 million and 0.02 million shares of RSUs with a grant-date fair value of $4 million (included in the amounts noted above) to certain key employees as share-based compensation in connection with the acquisition of Ava, which will be expensed over an average service period of 2 years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-22-000019:notes:119]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 2, 2022 and December 31, 2021 were as follows:

[0000068505-22-000019:notes:120]
| April 2, 2022 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  |  |  | $ | 4 |  |
| Common stock | 50 |  |  | — |  |  |  |  | 50 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  |  |  | $ | 10 |  |

[0000068505-22-000019:notes:121]
| December 31, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |
| Common stock | 69 |  |  | — |  |  |  |  | 69 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-22-000019:notes:122]
The Company had no foreign exchange derivative contracts or common stock investment Level 3 holdings as of April 2, 2022 or December 31, 2021.

[0000068505-22-000019:notes:123]
At April 2, 2022 and December 31, 2021, the Company had $192 million and $685 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-22-000019:notes:124]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of April 2, 2022 was $5.9 billion, of which the Senior Convertible Notes were $1.2 billion (Level 2). The fair value of long-term debt at December 31, 2021 was $6.2 billion (Level 2).

[0000068505-22-000019:notes:125]
[same as prior period, unchanged from 0000068505-21-000027:notes:130]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-22-000019:notes:126]
[same as prior period, unchanged from 0000068505-21-000027:notes:131]

[0000068505-22-000019:notes:127]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended April 2, 2022 and April 3, 2021:

[0000068505-22-000019:notes:128]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Contract-specific discounting facility | $ | 49 |  |  | $ | 71 |  |  |  |  |  |
| Accounts receivable sales proceeds | 22 |  |  | — |  |  |  |  |  |
| Long-term receivables sales proceeds | 17 |  |  | 54 |  |  |  |  |  |
| Total proceeds from receivable sales | $ | 88 |  |  | $ | 125 |  |  |  |  |  |

[0000068505-22-000019:notes:129]
At April 2, 2022, the Company had retained servicing obligations for $905 million of long-term receivables, compared to $940 million at December 31, 2021. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $32 million at April 2, 2022, compared to $56 million at December 31, 2021.

[0000068505-22-000019:notes:130]
During the three months ended April 2, 2022, the Company completed its final draw against a cost-efficient receivables discounting facility, implemented in 2020 to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe, resulting in accounts receivable sales of $49 million. The proceeds of the Company's receivable sales are included in Operating activities within the Company's Condensed Consolidated Statements of Cash Flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-22-000019:notes:131]
Commitments and Contingencies
Legal Matters

[0000068505-22-000019:notes:132]
Hytera Litigation

[0000068505-22-000019:notes:133]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As the parties were unable to agree on a reasonable royalty rate, the Court entered an order favorable to the Company on December 15, 2021, and, consistent with the Company's requests, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  The Court also ordered the parties to jointly file by February 22, 2022, a proposed royalty agreement for the Court's review and approval. Because the parties could not concur on the royalty agreement, they each filed supporting papers for their proposed draft agreements, and on April 12, 2022, the Court issued a ruling generally favorable to the Company on the critical aspects of the royalty agreement. On April 19, 2022, the parties filed an agreed royalty agreement that incorporates the findings of the Court's ruling.

[0000068505-22-000019:notes:134]
In response to the Court's decision to award the Company $764.6 million in compensatory and punitive damages, Hytera motioned for certain equitable relief. On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties have briefed a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal and await the Court's determination. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. On October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

[0000068505-22-000019:notes:135]
Hytera Bankruptcy Proceedings

[0000068505-22-000019:notes:136]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property. On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. The gain was recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-22-000019:notes:137]
[same as prior period, unchanged from 0000068505-21-000027:notes:141]

[0000068505-22-000019:notes:138]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Products and Systems Integration | $ | 1,103 |  |  | $ | 1,015 |  |  |  |  |  |
| Software and Services | 789 |  |  | 758 |  |  |  |  |  |
|  | $ | 1,892 |  |  | $ | 1,773 |  |  |  |  |  |

[0000068505-22-000019:notes:139]
[same as prior period, unchanged from 0000068505-21-000027:notes:143]

[0000068505-22-000019:notes:140]
|  | Three Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| Products and Systems Integration | $ | 39 |  |  | $ | 77 |  |  |  |  |  |
| Software and Services | 200 |  |  | 221 |  |  |  |  |  |
| Operating earnings | 239 |  |  | 298 |  |  |  |  |  |
| Total other expense | (20) |  |  | (9) |  |  |  |  |  |
| Earnings before income taxes | $ | 219 |  |  | $ | 289 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-22-000019:notes:141]
Reorganization of Business
2022 Charges

[0000068505-22-000019:notes:142]
During the three months ended April 2, 2022, the Company recorded net reorganization of business charges of $10 million, including $7 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $10 million were charges of $12 million related to employee separation, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-22-000019:notes:143]
[same as prior period, unchanged from 0000068505-21-000027:notes:148]

[0000068505-22-000019:notes:144]
|  |  |  | Three Months Ended |
|  |  |  | April 2, 2022 |
| Products and Systems Integration |  |  | $ | 8 |  |
| Software and Services |  |  | 2 |  |
|  |  |  | $ | 10 |  |

[0000068505-22-000019:notes:145]
[same as prior period, unchanged from 0000068505-21-000027:notes:150]

[0000068505-22-000019:notes:146]
| January 1, 2022 |  | Additional Charges |  | Adjustments |  | Amount Used |  | April 2, 2022 |
| $ | 34 |  |  | $ | 12 |  |  | $ | (2) |  |  | $ | (12) |  |  | $ | 32 |  |

[0000068505-22-000019:notes:147]
[same as prior period, unchanged from 0000068505-21-000027:notes:152]

[0000068505-22-000019:notes:148]
At January 1, 2022, the Company had an accrual of $34 million for employee separation costs. The 2022 additional charges of $12 million represent severance costs for approximately 150 employees. The adjustment of $2 million reflects reversals for accruals no longer needed. The $12 million used reflects cash payments to severed employees. The remaining accrual of $32 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at April 2, 2022, is expected to be paid, primarily within one year, to approximately 500 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-22-000019:notes:149]
2021 Charges

[0000068505-22-000019:notes:150]
During the three months ended April 3, 2021, the Company recorded net reorganization of business charges of $16 million, including $14 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $16 million were charges of $18 million related to employee separation, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-22-000019:notes:151]
|  | Three Months Ended |  |  |
|  | April 3, 2021 |  |  |
| Products and Systems Integration | $ | 12 |  |  |  |
| Software and Services | 4 |  |  |  |
|  | $ | 16 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-22-000019:notes:152]
Intangible Assets and Goodwill
Subsequent to quarter end, on May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is part of both the Products and Systems Integration segment and the Software and Services segment. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-22-000019:notes:153]
Subsequent to quarter end, on April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $40 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-22-000019:notes:154]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. As a result of the acquisition, the Company recognized a $21 million gain recorded within Other income (expense) on the Company's initial minority interest. The Company recognized $58 million of goodwill, $83 million of identifiable intangible assets, and $2 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $78 million of customer relationships and $5 million of trade names that will be amortized over a period of twelve years and eleven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-22-000019:notes:155]
On March 3, 2022, the Company acquired Ava, a global provider of cloud-native video security and analytics, for $387 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The Company recognized $261 million of goodwill, $167 million of identifiable intangible assets, and $41 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $146 million of developed technology and $21 million of customer relationships that will be amortized over a period of fourteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-22-000019:notes:156]
On December 16, 2021, the Company acquired 911 Datamaster, an NG911 data solutions provider, for $35 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of two years. This acquisition reinforces Motorola Solutions’ commitment to being a leader in command center solutions and further supports 911 call centers’ unique organizational workflows as they transition to NG911 technologies. The Company recognized $20 million of goodwill, $16 million of identifiable intangible assets, and $1 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $9 million of developed technology and $7 million of customer relationships that will be amortized over a period of nine years and fourteen years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-22-000019:notes:157]
On October 29, 2021, the Company acquired Envysion, a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy to be a global leader in end-to-end video security solutions within Video Security and Access Control. The Company recognized $79 million of goodwill, $37 million of identifiable intangible assets, and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $26 million of customer relationships, $6 million of developed technology, and $5 million of trade names that will be amortized over a period of fifteen, four, and nine years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-22-000019:notes:158]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $298 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments of up to $40 million based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. The Company estimated there will be no payout related to the earn-out payments. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The Company recognized $234 million of goodwill, $73 million of identifiable intangible assets, and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $57 million of developed technology and $16 million of customer relationships that will be amortized over a period of sixteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-22-000019:notes:159]
[same as prior period, unchanged from 0000068505-21-000027:notes:164]

[0000068505-22-000019:notes:160]
[same as prior period, unchanged from 0000068505-21-000027:notes:165]

[0000068505-22-000019:notes:161]
|  | April 2, 2022 |  | December 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 982 |  |  | $ | 299 |  |  | $ | 828 |  |  | $ | 278 |  |
| Customer-related | 1,458 |  |  | 865 |  |  | 1,367 |  |  | 836 |  |
| Other intangibles | 90 |  |  | 62 |  |  | 84 |  |  | 60 |  |
|  | $ | 2,530 |  |  | $ | 1,226 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-22-000019:notes:162]
Amortization expense on intangible assets was $66 million for the three months ended April 2, 2022. Amortization expense on intangible assets was $58 million for the three months ended April 3, 2021. As of April 2, 2022, annual amortization expense is estimated to be $260 million in 2022, $159 million in 2023, $120 million in 2024, $107 million in 2025, $100 million in 2026, and $91 million in 2027.

[0000068505-22-000019:notes:163]
[same as prior period, unchanged from 0000068505-21-000027:notes:168]

[0000068505-22-000019:notes:164]
|  | April 2, 2022 |  | December 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 894 |  |  | $ | 204 |  |  | $ | 766 |  |  | $ | 184 |  |
| Software and Services | 1,636 |  |  | 1,022 |  |  | 1,513 |  |  | 990 |  |
|  | $ | 2,530 |  |  | $ | 1,226 |  |  | $ | 2,279 |  |  | $ | 1,174 |  |

[0000068505-22-000019:notes:165]
[same as prior period, unchanged from 0000068505-21-000027:notes:170]

[0000068505-22-000019:notes:166]
The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2022 to April 2, 2022:

[0000068505-22-000019:notes:167]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2021 | $ | 1,236 |  |  | $ | 1,329 |  |  | $ | 2,565 |  |
| Goodwill acquired | 201 |  |  | 118 |  |  | 319 |  |
| Purchase accounting adjustments | — |  |  | (16) |  |  | (16) |  |
| Foreign currency | — |  |  | (4) |  |  | (4) |  |
| Balance as of April 2, 2022 | $ | 1,437 |  |  | $ | 1,427 |  |  | $ | 2,864 |  |
