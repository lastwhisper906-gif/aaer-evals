# MSI 8-K — 0000068505-24-000032 filed 2024-11-07

## item codes, every 8-K on or before 2024-11-07

- 2024-11-07 0000068505-24-000032 — 2.02, 9.01
- 2024-10-09 0001193125-24-235267 — 5.02
- 2024-08-26 0001193125-24-207088 — 5.02, 9.01
- 2024-08-01 0000068505-24-000022 — 2.02, 9.01
- 2024-05-17 0001193125-24-141186 — 5.07
- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2024-11-07

- none on or before 2024-11-07

## item 2.02 — earnings release, exhibit 99.1

[0000068505-24-000032:8k_2_02:1]
EX-99.1
2
msiq32024pressrelease.htm
EX-99.1

[0000068505-24-000032:8k_2_02:2]
Document

[0000068505-24-000032:8k_2_02:3]
Exhibit 99.1

[0000068505-24-000032:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2024 Financial Results

[0000068505-24-000032:8k_2_02:5]
Company again raises full-year revenue and earnings outlook following strong Q3 results

[0000068505-24-000032:8k_2_02:6]
•Sales of $2.8 billion, up 9% versus a year ago

[0000068505-24-000032:8k_2_02:7]
◦Products and Systems Integration sales up 11%

[0000068505-24-000032:8k_2_02:8]
◦Software and Services sales up 7%; up 13%1 excluding U.K. Home Office sales

[0000068505-24-000032:8k_2_02:9]
•GAAP earnings per share ("EPS") of $3.29, up 22% versus a year ago

[0000068505-24-000032:8k_2_02:10]
•Non-GAAP EPS2 of $3.74, up 17% versus a year ago

[0000068505-24-000032:8k_2_02:11]
•Operating cash flow of $759 million, up $45 million versus a year ago

[0000068505-24-000032:8k_2_02:12]
•Subsequent to quarter end, acquired an international provider of Command Center software solutions for $22 million, net of cash acquired.

[0000068505-24-000032:8k_2_02:13]
CHICAGO – November 7, 2024 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of 2024.

[0000068505-24-000032:8k_2_02:14]
“Our third-quarter results were exceptional, with record Q3 revenue, earnings and cash flow,” said Greg Brown, chairman and CEO, Motorola Solutions. “We achieved strong growth across the board, and I’m pleased with the momentum of our business. As a result, we’re again raising our revenue and earnings expectations for the full year.”

[0000068505-24-000032:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-24-000032:8k_2_02:16]
|  | Q3 2024 |  | Q3 2023 | % Change |
| Sales | $2,790 |  | $2,556 | 9 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $711 |  | $639 | 11 | % |
| % of Sales | 25.5 | % |  | 25.0 | % |  |
| EPS | $3.29 |  | $2.70 | 22 | % |
| Non-GAAP |  |  |  |  |
| Operating Earnings | $830 |  | $741 | 12 | % |
| % of Sales | 29.7 | % |  | 29.0 | % |  |
| EPS | $3.74 |  | $3.19 | 17 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,784 |  | $1,612 | 11 | % |
| GAAP Operating Earnings | $446 |  | $364 | 23 | % |
| % of Sales | 25.0 | % |  | 22.6 | % |  |
| Non-GAAP Operating Earnings | $522 |  | $420 | 24 | % |
| % of Sales | 29.3 | % |  | 26.1 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $1,006 |  | $944 | 7 | % |
| GAAP Operating Earnings | $265 |  | $275 | (4) | % |
| % of Sales | 26.3 | % |  | 29.1 | % |  |
| Non-GAAP Operating Earnings | $308 |  | $321 | (4) | % |
| % of Sales | 30.6 | % |  | 34.0 | % |  |

[0000068505-24-000032:8k_2_02:17]
1 Details regarding this non-GAAP measure and the use of non-GAAP measures are included later in this news release.

[0000068505-24-000032:8k_2_02:18]
2 Non-GAAP financial information excludes the after-tax impact of approximately $0.45 per diluted share related to highlighted items, share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-24-000032:8k_2_02:19]
1

[0000068505-24-000032:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-24-000032:8k_2_02:21]
•Revenue - Sales were $2.8 billion, up 9% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $36 million and currency headwinds were $4 million in the quarter. The Products and Systems Integration segment grew 11%, driven by growth in Land Mobile Radio Communications ("LMR"). The Software and Services segment grew 7%, driven by growth in Video Security and Access Control ("Video") and Command Center, partially offset by lower revenue in the U.K. related to the Airwave Charge Control and the exit from the Emergency Services Network ("ESN") contract. Excluding the U.K. Home Office, Software and Services grew 13% with growth in all three technologies.

[0000068505-24-000032:8k_2_02:22]
•Operating margin - GAAP operating margin was 25.5% of sales, up from 25.0% in the year-ago quarter. Non-GAAP operating margin was 29.7% of sales, up 70 basis points from 29.0% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margins was driven by higher sales, favorable mix and lower material costs, partially offset by the Airwave Charge Control and higher expenses related to investments in video and employee incentives.

[0000068505-24-000032:8k_2_02:23]
•Taxes - The GAAP effective tax rate during the quarter was 19.0%, down from 21.5% in the year-ago quarter. The non-GAAP effective tax rate was 20.6%, down from 22.7% in the year-ago quarter. Both the GAAP and non-GAAP rates decreased primarily due to higher benefits from share-based compensation recognized in the current quarter.

[0000068505-24-000032:8k_2_02:24]
•Cash flow - Operating cash flow was $759 million, compared to $714 million in the year-ago quarter and free cash flow was $702 million, up from $649 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings in the current year, net of non-cash charges.

[0000068505-24-000032:8k_2_02:25]
•Capital allocation - During the quarter, the company paid $164 million in cash dividends, repurchased $31 million of common stock and incurred $57 million of capital expenditures. Additionally, the company closed the acquisitions of Noggin and a provider of vehicle location and management solutions in the financial services vertical for $223 million, net of cash acquired, and settled $313 million of senior notes that were due within the quarter. Subsequent to the quarter, the company acquired an international provider of Command Center software solutions, for $22 million, net of cash acquired.

[0000068505-24-000032:8k_2_02:26]
•Backlog - The company ended the quarter with backlog of $14.1 billion, down 1% or $178 million from the year-ago quarter. Products and Systems Integration segment backlog was down $712 million, or 15%, driven primarily by strong LMR shipments. Software and Services segment backlog was up $534 million, or 6%, driven by strong demand in all three technologies and favorable foreign currency rates, partially offset by the revenue recognition for the U.K. Home Office.

[0000068505-24-000032:8k_2_02:27]
2

[0000068505-24-000032:8k_2_02:28]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-24-000032:8k_2_02:29]
Software and Services

[0000068505-24-000032:8k_2_02:30]
•$191M five-year LMR services award from the U.S. Navy

[0000068505-24-000032:8k_2_02:31]
•$100M+ five-year LMR services award for South Carolina's statewide network

[0000068505-24-000032:8k_2_02:32]
•$84M five-year LMR services award from a U.S. federal law enforcement agency

[0000068505-24-000032:8k_2_02:33]
•$30M Command Center order for the State of Utah

[0000068505-24-000032:8k_2_02:34]
•$24M Command Center order for Maricopa County Sheriff's Office, AZ

[0000068505-24-000032:8k_2_02:35]
•$18M mobile video order from São Paulo State Government, Brazil

[0000068505-24-000032:8k_2_02:36]
Products and Systems Integration

[0000068505-24-000032:8k_2_02:37]
•$88M P25 system and device order for a customer in North Africa

[0000068505-24-000032:8k_2_02:38]
•$31M P25 system order for a U.S. state and local customer

[0000068505-24-000032:8k_2_02:39]
•$31M P25 system order for a county in Wisconsin

[0000068505-24-000032:8k_2_02:40]
•$25M P25 system expansion for Tennessee's statewide network

[0000068505-24-000032:8k_2_02:41]
•$23M P25 device order for a U.S. federal customer

[0000068505-24-000032:8k_2_02:42]
•$4M fixed video order for a U.S. federal customer

[0000068505-24-000032:8k_2_02:43]
BUSINESS OUTLOOK

[0000068505-24-000032:8k_2_02:44]
•Full-year 2024 - The company now expects revenue growth of 8.25%, up from its prior guidance of approximately 8%, and non-GAAP EPS of between $13.63 and $13.68 per share, up from its prior guidance of between $13.22 and $13.30 per share. This outlook assumes a fully diluted share count of approximately 171 million shares and a non-GAAP effective tax rate of approximately 22.5%.

[0000068505-24-000032:8k_2_02:45]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-24-000032:8k_2_02:46]
RECENT EVENTS

[0000068505-24-000032:8k_2_02:47]
U.K. HOME OFFICE UPDATE

[0000068505-24-000032:8k_2_02:48]
In October 2021, the Competition and Markets Authority ("CMA") opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, the company's private mobile radio communications network that it acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-24-000032:8k_2_02:49]
In 2023, the CMA imposed a legal order on Airwave which implemented a prospective price control on Airwave ("Airwave Charge Control"). After the Competition Appeal Tribunal ("CAT") dismissed the company's appeal of the CMA's final decision on December 22, 2023, the company filed an application with the United Kingdom Court of Appeal on February 13, 2024, requesting that it hear the company's appeal of the CAT judgment. On June 21, 2024, the United Kingdom Court of Appeal ordered a hearing on the company's application to be held later this year; which was subsequently set for November 11 and 12, 2024. Since August 1, 2023, revenue under the Airwave contract has been recognized in accordance with the Airwave Charge Control, and will continue to be unless the United Kingdom Court of Appeal were to reverse the CAT's judgment and overturn the Airwave Charge Control.

[0000068505-24-000032:8k_2_02:50]
3

[0000068505-24-000032:8k_2_02:51]
On March 13, 2024, the company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the U.K. Home Office. The Deferred National Shutdown Notice extends the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the Airwave Charge Control rates.

[0000068505-24-000032:8k_2_02:52]
The company's backlog for Airwave services contracted with the U.K. Home Office through December 31, 2026 was previously reduced by $777 million to align with the Airwave Charge Control. In the first quarter of 2024, as a result of the U.K. Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the company has recorded additional backlog of $748 million to reflect the incremental three years of services. On April 11, 2024, the company filed proceedings in the U.K. High Court challenging the decision of the U.K. Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable U.K. procurement and public law. The hearing on this matter has been set to commence on April 22, 2025. The backlog related to the incremental years of service contemplated in the Deferred National Shutdown Notice could change depending on the outcome of the proceedings.

[0000068505-24-000032:8k_2_02:53]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, November 7. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-24-000032:8k_2_02:54]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-24-000032:8k_2_02:55]
A comparison of results from operations is as follows:

[0000068505-24-000032:8k_2_02:56]
|  | Q3 2024 | Q3 2023 |
| Net sales | $2,790 | $2,556 |
| Gross margin | $1,433 | $1,280 |
| Operating earnings | $711 | $639 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $562 | $464 |
| Diluted EPS | $3.29 | $2.70 |
| Weighted average diluted common shares outstanding | 170.9 |  | 171.7 |  |

[0000068505-24-000032:8k_2_02:57]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-24-000032:8k_2_02:58]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate, organic revenue and net sales adjusted for the U.K. Home Office. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-24-000032:8k_2_02:59]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-24-000032:8k_2_02:60]
4

[0000068505-24-000032:8k_2_02:61]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-24-000032:8k_2_02:62]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-24-000032:8k_2_02:63]
Net sales adjusted for the U.K. Home Office or Net sales excluding U.K. Home Office sales: Net sales adjusted for the U.K. Home Office reflects net sales calculated under GAAP excluding net sales related to the U.K. Home Office. The company believes that net sales excluding the U.K. Home Office improves period-to-period comparability related to the Airwave Charge Control implemented as of August 1, 2023 and the company's exit from the ESN contract as of December 31, 2023.

[0000068505-24-000032:8k_2_02:64]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-24-000032:8k_2_02:65]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-24-000032:8k_2_02:66]
Hytera-Related Legal Expenses: On March 14, 2017, the company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “District Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the company announced that a jury decided in the company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-24-000032:8k_2_02:67]
On December 17, 2020, the District Court held that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify

[0000068505-24-000032:8k_2_02:68]
5

[0000068505-24-000032:8k_2_02:69]
or stay the District Court’s previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through October 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-24-000032:8k_2_02:70]
Following the February 14, 2020 verdict and judgment in the company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera’s motion for rehearing. The case has been remanded to the District Court for further action per the Court of Appeals' decision.

[0000068505-24-000032:8k_2_02:71]
In 2024, the parties engaged in competing litigation in the District Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the company until November 2023) related to the possible continued use by Hytera of the company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings on August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the company's trade secrets and copyrighted source code. The issue is now under consideration by the District Court.

[0000068505-24-000032:8k_2_02:72]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $15 million of proceeds realized in 2022. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-24-000032:8k_2_02:73]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-24-000032:8k_2_02:74]
6

[0000068505-24-000032:8k_2_02:75]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net income measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-24-000032:8k_2_02:76]
FORWARD LOOKING STATEMENTS

[0000068505-24-000032:8k_2_02:77]
7

[0000068505-24-000032:8k_2_02:78]
compliant manner or adhere to our Human Rights Policy; (xxiii) inability of our products to meet our customers’ expectations or regulatory or industry standards; (xxiv) increasing scrutiny and evolving expectations from investors, customers, lawmakers, regulators and other stakeholders regarding environmental, social and governance-related practices and disclosures; (xxv) inability to attract and retain senior management and key employees; (xxvi) impact of current global economic and political conditions in the markets in which we operate; (xxvii) impact of returns on pension and retirement plan assets and interest rate changes; (xxviii) inability to access the capital markets for financing on acceptable terms and conditions; (xix) exposure to exchange rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; and (xxx) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-24-000032:8k_2_02:79]
ABOUT MOTOROLA SOLUTIONS

[0000068505-24-000032:8k_2_02:80]
Motorola Solutions is solving for safer. We build and connect technologies to help protect people, property and places. Our solutions enable the collaboration between public safety agencies and enterprises that’s critical for a proactive approach to safety and security. Learn more about how we’re solving for safer communities, safer schools, safer hospitals, safer businesses – safer everywhere – at www.motorolasolutions.com.

[0000068505-24-000032:8k_2_02:81]
MEDIA CONTACT

[0000068505-24-000032:8k_2_02:82]
Alexandra Reynolds

[0000068505-24-000032:8k_2_02:83]
Motorola Solutions

[0000068505-24-000032:8k_2_02:84]
+1 312-965-3968

[0000068505-24-000032:8k_2_02:85]
alexandra.reynolds@motorolasolutions.com

[0000068505-24-000032:8k_2_02:86]
INVESTOR CONTACT

[0000068505-24-000032:8k_2_02:87]
Tim Yocum

[0000068505-24-000032:8k_2_02:88]
Motorola Solutions

[0000068505-24-000032:8k_2_02:89]
+1 847-576-6899

[0000068505-24-000032:8k_2_02:90]
Tim.Yocum@motorolasolutions.com

[0000068505-24-000032:8k_2_02:91]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2024 Motorola Solutions, Inc. All rights reserved.

[0000068505-24-000032:8k_2_02:92]
8

[0000068505-24-000032:8k_2_02:93]
GAAP-1

[0000068505-24-000032:8k_2_02:94]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:95]
Condensed Consolidated Statements of Operations

[0000068505-24-000032:8k_2_02:96]
(In millions, except per share amounts)

[0000068505-24-000032:8k_2_02:97]
|  | Three Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| Net sales from products | $ | 1,670 |  |  | $ | 1,490 |  |
| Net sales from services | 1,120 |  |  | 1,066 |  |
| Net sales | 2,790 |  |  | 2,556 |  |
| Costs of products sales | 688 |  |  | 658 |  |
| Costs of services sales | 669 |  |  | 618 |  |
| Costs of sales | 1,357 |  |  | 1,276 |  |
| Gross margin | 1,433 |  |  | 1,280 |  |
| Selling, general and administrative expenses | 439 |  |  | 380 |  |
| Research and development expenditures | 234 |  |  | 215 |  |
| Other charges | 11 |  |  | 7 |  |
| Intangibles amortization | 38 |  |  | 39 |  |
| Operating earnings | 711 |  |  | 639 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (58) |  |  | (53) |  |
| Loss on sales of investments and businesses, net | — |  |  | (1) |  |
| Other, net | 42 |  |  | 7 |  |
| Total other expense | (16) |  |  | (47) |  |
| Net earnings before income taxes | 695 |  |  | 592 |  |
| Income tax expense | 132 |  |  | 127 |  |
| Net earnings | 563 |  |  | 465 |  |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 562 |  |  | $ | 464 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.36 |  |  | $ | 2.78 |  |
| Diluted | $ | 3.29 |  |  | $ | 2.70 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 167.1 |  |  | 166.7 |  |
| Diluted | 170.9 |  |  | 171.7 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 59.9 | % |  | 58.3 | % |
| Net sales from services | 40.1 | % |  | 41.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.2 | % |  | 44.2 | % |
| Costs of services sales | 59.7 | % |  | 58.0 | % |
| Costs of sales | 48.6 | % |  | 49.9 | % |
| Gross margin | 51.4 | % |  | 50.1 | % |
| Selling, general and administrative expenses | 15.7 | % |  | 14.9 | % |
| Research and development expenditures | 8.4 | % |  | 8.4 | % |
| Other charges | 0.4 | % |  | 0.3 | % |
| Intangibles amortization | 1.4 | % |  | 1.5 | % |
| Operating earnings | 25.5 | % |  | 25.0 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.1) | % |  | (2.1) | % |
| Loss on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 1.5 | % |  | 0.3 | % |
| Total other expense | (0.6) | % |  | (1.8) | % |
| Net earnings before income taxes | 24.9 | % |  | 23.2 | % |
| Income tax expense | 4.7 | % |  | 5.0 | % |
| Net earnings | 20.2 | % |  | 18.2 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 20.2 | % |  | 18.2 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-24-000032:8k_2_02:98]
9

[0000068505-24-000032:8k_2_02:99]
GAAP-2

[0000068505-24-000032:8k_2_02:100]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:101]
Condensed Consolidated Statements of Operations

[0000068505-24-000032:8k_2_02:102]
(In millions, except per share amounts)

[0000068505-24-000032:8k_2_02:103]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| Net sales from products | $ | 4,639 |  |  | $ | 4,063 |  |
| Net sales from services | 3,167 |  |  | 3,066 |  |
| Net sales | 7,806 |  |  | 7,129 |  |
| Costs of products sales | 1,941 |  |  | 1,867 |  |
| Costs of services sales | 1,902 |  |  | 1,747 |  |
| Costs of sales | 3,843 |  |  | 3,614 |  |
| Gross margin | 3,963 |  |  | 3,515 |  |
| Selling, general and administrative expenses | 1,265 |  |  | 1,138 |  |
| Research and development expenditures | 671 |  |  | 640 |  |
| Other charges | 39 |  |  | 44 |  |
| Intangibles amortization | 114 |  |  | 137 |  |
| Operating earnings | 1,874 |  |  | 1,556 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (171) |  |  | (164) |  |
| Other, net | (519) |  |  | 46 |  |
| Total other expense | (690) |  |  | (118) |  |
| Net earnings before income taxes | 1,184 |  |  | 1,438 |  |
| Income tax expense | 214 |  |  | 321 |  |
| Net earnings | 970 |  |  | 1,117 |  |
| Less: Earnings attributable to non-controlling interests | 4 |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 966 |  |  | $ | 1,113 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 5.79 |  |  | $ | 6.66 |  |
| Diluted | $ | 5.66 |  |  | $ | 6.46 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.7 |  |  | 167.2 |  |
| Diluted | 170.6 |  |  | 172.2 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 59.4 | % |  | 57.0 | % |
| Net sales from services | 40.6 | % |  | 43.0 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.8 | % |  | 46.0 | % |
| Costs of services sales | 60.1 | % |  | 57.0 | % |
| Costs of sales | 49.2 | % |  | 50.7 | % |
| Gross margin | 50.8 | % |  | 49.3 | % |
| Selling, general and administrative expenses | 16.2 | % |  | 16.0 | % |
| Research and development expenditures | 8.6 | % |  | 9.0 | % |
| Other charges | 0.5 | % |  | 0.6 | % |
| Intangibles amortization | 1.5 | % |  | 1.9 | % |
| Operating earnings | 24.0 | % |  | 21.8 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.2) | % |  | (2.3) | % |
| Other, net | (6.6) | % |  | 0.6 | % |
| Total other expense | (8.8) | % |  | (1.7) | % |
| Net earnings before income taxes | 15.2 | % |  | 20.2 | % |
| Income tax expense | 2.7 | % |  | 4.5 | % |
| Net earnings | 12.4 | % |  | 15.7 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 12.3 | % |  | 15.6 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-24-000032:8k_2_02:104]
10

[0000068505-24-000032:8k_2_02:105]
GAAP-3

[0000068505-24-000032:8k_2_02:106]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:107]
Condensed Consolidated Balance Sheets

[0000068505-24-000032:8k_2_02:108]
(In millions)

[0000068505-24-000032:8k_2_02:109]
|  | September 28, 2024 |  | December 31, 2023 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,404 |  |  | $ | 1,705 |  |
| Accounts receivable, net | 1,848 |  |  | 1,710 |  |
| Contract assets | 1,301 |  |  | 1,102 |  |
| Inventories, net | 816 |  |  | 827 |  |
| Other current assets | 439 |  |  | 357 |  |
| Current assets held for disposition | — |  |  | 24 |  |
| Total current assets | 5,808 |  |  | 5,725 |  |
| Property, plant and equipment, net | 1,024 |  |  | 964 |  |
| Operating lease assets | 551 |  |  | 495 |  |
| Investments | 140 |  |  | 143 |  |
| Deferred income taxes | 1,214 |  |  | 1,062 |  |
| Goodwill | 3,523 |  |  | 3,401 |  |
| Intangible assets, net | 1,295 |  |  | 1,255 |  |
| Other assets | 334 |  |  | 274 |  |
| Non-current assets held for disposition | — |  |  | 17 |  |
| Total assets | $ | 13,889 |  |  | $ | 13,336 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | 322 |  |  | $ | 1,313 |  |
| Accounts payable | 872 |  |  | 881 |  |
| Contract liabilities | 1,942 |  |  | 2,037 |  |
| Accrued liabilities | 1,529 |  |  | 1,504 |  |
| Current liabilities held for disposition | — |  |  | 1 |  |
| Total current liabilities | 4,665 |  |  | 5,736 |  |
| Long-term debt | 5,674 |  |  | 4,705 |  |
| Operating lease liabilities | 444 |  |  | 407 |  |
| Other liabilities | 1,765 |  |  | 1,741 |  |
| Non-current liabilities held for disposition | — |  |  | 8 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 1,326 |  |  | 724 |  |
| Non-controlling interests | 15 |  |  | 15 |  |
| Total liabilities and stockholders’ equity | $ | 13,889 |  |  | $ | 13,336 |  |

[0000068505-24-000032:8k_2_02:110]
11

[0000068505-24-000032:8k_2_02:111]
GAAP-4

[0000068505-24-000032:8k_2_02:112]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:113]
Condensed Consolidated Statements of Cash Flows

[0000068505-24-000032:8k_2_02:114]
(In millions)

[0000068505-24-000032:8k_2_02:115]
|  | Three Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| Operating |  |  |  |
| Net earnings | $ | 563 |  |  | $ | 465 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 84 |  |  | 86 |  |
| Non-cash other charges (income) | (3) |  |  | 12 |  |
| Share-based compensation expenses | 61 |  |  | 52 |  |
| Loss on sales of investments and businesses, net | — |  |  | 1 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (64) |  |  | (164) |  |
| Inventories | (8) |  |  | 58 |  |
| Other current assets and contract assets | (96) |  |  | (111) |  |
| Accounts payable, accrued liabilities and contract liabilities | 206 |  |  | 217 |  |
| Other assets and liabilities | 1 |  |  | (20) |  |
| Deferred income taxes | 15 |  |  | 118 |  |
| Net cash provided by operating activities | 759 |  |  | 714 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (226) |  |  | (2) |  |
| Proceeds from sales of investments and businesses, net | 1 |  |  | 6 |  |
| Capital expenditures | (57) |  |  | (65) |  |
| Net cash used for investing activities | (282) |  |  | (61) |  |
| Financing |  |  |  |
| Repayments of debt | (313) |  |  | — |  |
| Issuances of common stock | 18 |  |  | 40 |  |
| Purchases of common stock | (31) |  |  | (306) |  |
| Payments of dividends | (164) |  |  | (147) |  |
| Payments of dividends to non-controlling interests | (1) |  |  | (1) |  |
| Net cash used for financing activities | (491) |  |  | (414) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 37 |  |  | (39) |  |
| Net increase in total cash and cash equivalents | 23 |  |  | 200 |  |
| Cash and cash equivalents, beginning of period | 1,381 |  |  | 710 |  |
| Cash and cash equivalents, end of period | $ | 1,404 |  |  | $ | 910 |  |

[0000068505-24-000032:8k_2_02:116]
12

[0000068505-24-000032:8k_2_02:117]
GAAP-5

[0000068505-24-000032:8k_2_02:118]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:119]
Condensed Consolidated Statements of Cash Flows

[0000068505-24-000032:8k_2_02:120]
(In millions)

[0000068505-24-000032:8k_2_02:121]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| Operating |  |  |  |
| Net earnings | $ | 970 |  |  | $ | 1,117 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 250 |  |  | 271 |  |
| Non-cash other charges | 12 |  |  | 8 |  |
| Share-based compensation expenses | 180 |  |  | 160 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt (Note 5) | 585 |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (121) |  |  | (154) |  |
| Inventories | 21 |  |  | 94 |  |
| Other current assets and contract assets | (279) |  |  | (140) |  |
| Accounts payable, accrued liabilities and contract liabilities | (125) |  |  | (534) |  |
| Other assets and liabilities | (17) |  |  | (21) |  |
| Deferred income taxes | (155) |  |  | (2) |  |
| Net cash provided by operating activities | 1,321 |  |  | 799 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (268) |  |  | (12) |  |
| Proceeds from sales of investments and businesses, net | 39 |  |  | 12 |  |
| Capital expenditures | (171) |  |  | (172) |  |
| Net cash used for investing activities | (400) |  |  | (172) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | 1,288 |  |  | — |  |
| Repayments of debt | (1,906) |  |  | (1) |  |
| Issuances of common stock | 19 |  |  | 76 |  |
| Purchases of common stock | (141) |  |  | (670) |  |
| Payments of dividends | (490) |  |  | (443) |  |
| Payments of dividends to non-controlling interests | (4) |  |  | (5) |  |
| Net cash used for financing activities | (1,234) |  |  | (1,043) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 12 |  |  | 1 |  |
| Net decrease in total cash and cash equivalents | (301) |  |  | (415) |  |
| Cash and cash equivalents, beginning of period | 1,705 |  |  | 1,325 |  |
| Cash and cash equivalents, end of period | $ | 1,404 |  |  | $ | 910 |  |

[0000068505-24-000032:8k_2_02:122]
13

[0000068505-24-000032:8k_2_02:123]
Non-GAAP-1

[0000068505-24-000032:8k_2_02:124]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:125]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-24-000032:8k_2_02:126]
(In millions)

[0000068505-24-000032:8k_2_02:127]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net cash provided by operating activities |  | $ | 759 |  |  | $ | 714 |  |  | $ | 1,321 |  |  | $ | 799 |  |
| Capital expenditures |  | (57) |  |  | (65) |  |  | (171) |  |  | (172) |  |
| Free cash flow |  | $ | 702 |  |  | $ | 649 |  |  | $ | 1,150 |  |  | $ | 627 |  |

[0000068505-24-000032:8k_2_02:128]
14

[0000068505-24-000032:8k_2_02:129]
Non-GAAP-2

[0000068505-24-000032:8k_2_02:130]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:131]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-24-000032:8k_2_02:132]
(In millions)

[0000068505-24-000032:8k_2_02:133]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  | Statement Line |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net earnings attributable to MSI |  |  |  | $ | 562 |  |  | $ | 464 |  |  | $ | 966 |  |  | $ | 1,113 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 61 |  |  | $ | 52 |  |  | $ | 180 |  |  | $ | 160 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 38 |  |  | 39 |  |  | 114 |  |  | 137 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 7 |  |  | 6 |  |  | 21 |  |  | 22 |  |
| Hytera-related legal expenses |  | SG&A |  | 7 |  |  | 3 |  |  | 14 |  |  | 13 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 4 |  |  | 1 |  |  | 11 |  |  | 3 |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 1 |  |  | — |  |  | 22 |  |  | — |  |
| Legal settlements |  | Other charges (income) |  | 1 |  |  | 1 |  |  | 7 |  |  | 1 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 1 |  |  | — |  |  | 5 |  |  | 4 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (9) |  |  | 7 |  |  | 4 |  |  | (12) |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | — |  |  | 585 |  |  | — |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | 7 |  |  | 3 |  |  | 16 |  |
| Environmental reserve expense |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | 15 |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Loss on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 111 |  |  | $ | 117 |  |  | $ | 966 |  |  | $ | 362 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 34 |  | 34 |  | 259 |  | 86 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 77 |  | 83 |  | 707 |  | 276 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 639 |  |  | $ | 547 |  |  | $ | 1,673 |  |  | $ | 1,389 |  |

[0000068505-24-000032:8k_2_02:134]
Calculation of Non-GAAP Tax Rate

[0000068505-24-000032:8k_2_02:135]
(In millions)

[0000068505-24-000032:8k_2_02:136]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net earnings before income taxes |  | $ | 695 |  |  | $ | 592 |  |  | $ | 1,184 |  |  | $ | 1,438 |  |
| Total Non-GAAP adjustments before income taxes* |  | 111 |  |  | 117 |  |  | 966 |  |  | 362 |  |
| Non-GAAP Net earnings before income taxes |  | 806 |  |  | 709 |  |  | 2,150 |  |  | 1,800 |  |
| Income tax expense |  | 132 |  |  | 127 |  |  | 214 |  |  | 321 |  |
| Income tax expense on Non-GAAP adjustments** |  | 34 |  |  | 34 |  |  | 259 |  |  | 86 |  |
| Total Non-GAAP Income tax expense |  | $ | 166 |  |  | $ | 161 |  |  | 473 |  |  | 407 |  |
| Non-GAAP Tax rate |  | 20.6 | % |  | 22.7 | % |  | 22.0 | % |  | 22.6 | % |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-24-000032:8k_2_02:137]
15

[0000068505-24-000032:8k_2_02:138]
Non-GAAP-2

[0000068505-24-000032:8k_2_02:139]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-24-000032:8k_2_02:140]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  | Statement Line |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net earnings attributable to MSI |  |  |  | $ | 3.29 |  |  | $ | 2.70 |  |  | $ | 5.66 |  |  | $ | 6.46 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.35 |  |  | $ | 0.30 |  |  | $ | 1.05 |  |  | $ | 0.92 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.22 |  |  | 0.22 |  |  | 0.67 |  |  | 0.79 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.04 |  |  | 0.03 |  |  | 0.12 |  |  | 0.13 |  |
| Hytera-related legal expenses |  | SG&A |  | 0.04 |  |  | 0.02 |  |  | 0.08 |  |  | 0.08 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.02 |  |  | 0.01 |  |  | 0.07 |  |  | 0.02 |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 0.01 |  |  | — |  |  | 0.13 |  |  | — |  |
| Legal settlements |  | Other charges (income) |  | 0.01 |  |  | 0.01 |  |  | 0.04 |  |  | 0.01 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.01 |  |  | — |  |  | 0.03 |  |  | 0.02 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (0.05) |  |  | 0.04 |  |  | 0.02 |  |  | (0.07) |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | — |  |  | 3.42 |  |  | — |  |
| Investment impairments |  | Other (income) expense |  | — |  |  | 0.04 |  |  | 0.02 |  |  | 0.09 |  |
| Environmental reserve expense |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | 0.09 |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | — |  |  | — |  |  | 0.02 |  |
| Loss on sales of investments |  | (Gain) or loss on sales of investments and businesses, net |  | — |  |  | 0.01 |  |  | — |  |  | — |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.65 |  |  | $ | 0.68 |  |  | $ | 5.65 |  |  | $ | 2.10 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.20 |  | 0.19 |  | 1.52 |  | 0.50 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.45 |  | 0.49 |  | 4.13 |  | 1.60 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 3.74 |  |  | $ | 3.19 |  |  | $ | 9.79 |  |  | $ | 8.06 |  |
| GAAP Diluted Weighted Average Common Shares |  |  |  | 170.9 |  |  | 171.7 |  |  | 170.6 |  |  | 172.2 |  |
| Adjusted for dilutive shares outstanding** |  |  |  | — |  |  | — |  |  | 0.3 |  |  | — |  |
| Non-GAAP Diluted Weighted Average Common Shares |  |  |  | 170.9 |  |  | 171.7 |  |  | 170.9 |  |  | 172.2 |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |
| ** Under U.S. GAAP, the Silver Lake shares were considered anti-dilutive to earnings per share for the nine months ended September 28, 2024 and were excluded from the computation of GAAP diluted weighted average common shares and diluted earnings per share. The shares are considered dilutive for non-GAAP earnings per share for the nine months ended September 28, 2024 and an adjustment is reflected to include these shares for non-GAAP diluted earnings per share. |

[0000068505-24-000032:8k_2_02:141]
16

[0000068505-24-000032:8k_2_02:142]
Non-GAAP-3

[0000068505-24-000032:8k_2_02:143]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:144]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-24-000032:8k_2_02:145]
(In millions)

[0000068505-24-000032:8k_2_02:146]
|  |  | Three Months Ended |
|  |  | September 28, 2024 |  | September 30, 2023 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Operating earnings ("OE") |  | $ | 446 |  |  | $ | 265 |  |  | $ | 711 |  |  | $ | 364 |  |  | $ | 275 |  |  | $ | 639 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 43 |  |  | 18 |  |  | 61 |  |  | 38 |  |  | 14 |  |  | 52 |  |
| Intangible assets amortization expense |  | 18 |  |  | 20 |  |  | 38 |  |  | 9 |  |  | 30 |  |  | 39 |  |
| Reorganization of business charges |  | 6 |  |  | 1 |  |  | 7 |  |  | 5 |  |  | 1 |  |  | 6 |  |
| Hytera-related legal expenses |  | 7 |  |  | — |  |  | 7 |  |  | 3 |  |  | — |  |  | 3 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 2 |  |  | 4 |  |  | — |  |  | 1 |  |  | 1 |  |
| Legal settlements |  | — |  |  | 1 |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Operating lease asset impairments |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 76 |  |  | 43 |  |  | 119 |  |  | 56 |  |  | 46 |  |  | 102 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 522 |  |  | $ | 308 |  |  | $ | 830 |  |  | $ | 420 |  |  | $ | 321 |  |  | $ | 741 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 25.0 | % |  | 26.3 | % |  | 25.5 | % |  | 22.6 | % |  | 29.1 | % |  | 25.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 29.3 | % |  | 30.6 | % |  | 29.7 | % |  | 26.1 | % |  | 34.0 | % |  | 29.0 | % |

[0000068505-24-000032:8k_2_02:147]
17

[0000068505-24-000032:8k_2_02:148]
Non-GAAP-4

[0000068505-24-000032:8k_2_02:149]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:150]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-24-000032:8k_2_02:151]
(In millions)

[0000068505-24-000032:8k_2_02:152]
|  |  | Nine Months Ended |
|  |  | September 28, 2024 |  | September 30, 2023 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Operating earnings ("OE") |  | $ | 1,135 |  |  | $ | 739 |  |  | $ | 1,874 |  |  | $ | 752 |  |  | $ | 804 |  |  | $ | 1,556 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 126 |  |  | 54 |  |  | 180 |  |  | 116 |  |  | 44 |  |  | 160 |  |
| Intangible assets amortization expense |  | 35 |  |  | 79 |  |  | 114 |  |  | 32 |  |  | 105 |  |  | 137 |  |
| Reorganization of business charges |  | 20 |  |  | 1 |  |  | 21 |  |  | 22 |  |  | — |  |  | 22 |  |
| Hytera-related legal expenses |  | 14 |  |  | — |  |  | 14 |  |  | 13 |  |  | — |  |  | 13 |  |
| Acquisition-related transaction fees |  | 3 |  |  | 8 |  |  | 11 |  |  | — |  |  | 3 |  |  | 3 |  |
| Legal settlements |  | 1 |  |  | 6 |  |  | 7 |  |  | 1 |  |  | — |  |  | 1 |  |
| Operating lease asset impairments |  | 3 |  |  | 2 |  |  | 5 |  |  | 3 |  |  | 1 |  |  | 4 |  |
| Environmental reserve expense |  | — |  |  | — |  |  | — |  |  | 10 |  |  | 5 |  |  | 15 |  |
| Fixed asset impairments |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  | 202 |  |  | 150 |  |  | 352 |  |  | 199 |  |  | 159 |  |  | 358 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,337 |  |  | $ | 889 |  |  | $ | 2,226 |  |  | $ | 951 |  |  | $ | 963 |  |  | $ | 1,914 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 23.0 | % |  | 25.7 | % |  | 24.0 | % |  | 17.3 | % |  | 29.0 | % |  | 21.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 27.1 | % |  | 30.9 | % |  | 28.5 | % |  | 21.9 | % |  | 34.7 | % |  | 26.8 | % |

[0000068505-24-000032:8k_2_02:153]
18

[0000068505-24-000032:8k_2_02:154]
Non-GAAP-5

[0000068505-24-000032:8k_2_02:155]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:156]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-24-000032:8k_2_02:157]
(In millions)

[0000068505-24-000032:8k_2_02:158]
|  |  | Three Months Ended |  |  |
|  |  | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Net sales |  | $ | 2,790 |  |  | $ | 2,556 |  |  | 9 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 36 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,754 |  |  | $ | 2,556 |  |  | 8 | % |
|  |  | Nine Months Ended |  |  |
|  |  | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Net sales |  | $ | 7,806 |  |  | $ | 7,129 |  |  | 9 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 58 |  |  | — |  |  |  |
| Organic revenue |  | $ | 7,748 |  |  | $ | 7,129 |  |  | 9 | % |

[0000068505-24-000032:8k_2_02:159]
19

[0000068505-24-000032:8k_2_02:160]
Non-GAAP-6

[0000068505-24-000032:8k_2_02:161]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-24-000032:8k_2_02:162]
Reconciliation of Net Sales to Net Sales Adjusted for the U.K. Home Office

[0000068505-24-000032:8k_2_02:163]
(In millions)

[0000068505-24-000032:8k_2_02:164]
|  | Three Months Ended |  | % Change |  | Nine Months Ended |  | % Change |  |  |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |  |
| Software and Services net sales | $ | 1,006 |  |  | $ | 944 |  |  | 7 | % |  | $ | 2,873 |  |  | $ | 2,777 |  |  | 3 | % |  |  |  |  |  |  |
| U.K. Home Office net sales | (92) |  |  | (138) |  |  |  |  | (286) |  |  | (471) |  |  |  |  |  |  |  |  |  |
| Software and Services net sales adjusted for the U.K. Home Office | $ | 914 |  |  | $ | 806 |  |  | 13 | % |  | $ | 2,587 |  |  | $ | 2,306 |  |  | 12 | % |  |  |  |  |  |  |
| Net sales | $ | 2,790 |  |  | $ | 2,556 |  |  | 9 | % |  | $ | 7,806 |  |  | $ | 7,129 |  |  | 9 | % |  |  |  |  |  |  |
| U.K. Home Office net sales | (92) |  |  | (138) |  |  |  |  | (286) |  |  | (471) |  |  |  |  |  |  |  |  |  |
| Net sales adjusted for the U.K. Home Office | $ | 2,698 |  |  | $ | 2,418 |  |  | 12 | % |  | $ | 7,520 |  |  | $ | 6,658 |  |  | 13 | % |  |  |  |  |  |  |

[0000068505-24-000032:8k_2_02:165]
20
