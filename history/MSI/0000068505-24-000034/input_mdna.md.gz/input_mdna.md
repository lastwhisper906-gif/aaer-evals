# MSI MD&A — 0000068505-24-000034


## mdna

[0000068505-24-000034:mdna:1]
[same as prior period, unchanged from 0000068505-24-000024:mdna:1]

[0000068505-24-000034:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 28, 2024 and September 30, 2023, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2023 (the "Form 10-K").

[0000068505-24-000034:mdna:3]
[same as prior period, unchanged from 0000068505-24-000024:mdna:3]

[0000068505-24-000034:mdna:4]
[same as prior period, unchanged from 0000068505-24-000024:mdna:4]

[0000068505-24-000034:mdna:5]
[same as prior period, unchanged from 0000068505-24-000024:mdna:5]

[0000068505-24-000034:mdna:6]
[same as prior period, unchanged from 0000068505-24-000024:mdna:6]

[0000068505-24-000034:mdna:7]
[same as prior period, unchanged from 0000068505-24-000024:mdna:7]

[0000068505-24-000034:mdna:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.

[0000068505-24-000034:mdna:9]
[same as prior period, unchanged from 0000068505-24-000024:mdna:9]

[0000068505-24-000034:mdna:10]
Third Quarter Financial Results

[0000068505-24-000034:mdna:11]
•Net sales were $2.8 billion in the third quarter of 2024 compared to $2.6 billion in the third quarter of 2023.

[0000068505-24-000034:mdna:12]
•Operating earnings were $711 million in the third quarter of 2024 compared to $639 million in the third quarter of 2023.

[0000068505-24-000034:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. was $562 million, or $3.29 per diluted common share, in the third quarter of 2024, compared to net earnings of $464 million, or $2.70 per diluted common share, in the third quarter of 2023.

[0000068505-24-000034:mdna:14]
•Operating cash flow increased $522 million to $1.3 billion in the first nine months of 2024 compared to $799 million in the first nine months of 2023.

[0000068505-24-000034:mdna:15]
•We repurchased $141 million of common stock and paid $490 million in dividends in the first nine months of 2024.

[0000068505-24-000034:mdna:16]
[same as prior period, unchanged from 0000068505-24-000024:mdna:17]

[0000068505-24-000034:mdna:17]
[same as prior period, unchanged from 0000068505-24-000024:mdna:18]

[0000068505-24-000034:mdna:18]
[same as prior period, unchanged from 0000068505-24-000024:mdna:19]

[0000068505-24-000034:mdna:19]
[same as prior period, unchanged from 0000068505-24-000024:mdna:20]

[0000068505-24-000034:mdna:20]
[same as prior period, unchanged from 0000068505-24-000024:mdna:21]

[0000068505-24-000034:mdna:21]
[same as prior period, unchanged from 0000068505-24-000024:mdna:22]

[0000068505-24-000034:mdna:22]
[same as prior period, unchanged from 0000068505-24-000024:mdna:23]

[0000068505-24-000034:mdna:23]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Command Center | Software and Services | Noggin | Provider of cloud-based business continuity planning, operational resilience and critical event management software. | $91 million and share-based compensation of $19 million | July 1, 2024 |
| Video Security and Access Control | Software and Services | Unnamed vehicle location and management solutions business | Provider of vehicle location and management solutions. | $132 million and share-based compensation of $3 million | July 1, 2024 |
| Video Security and Access Control | Products and Systems Integration | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |
| Video Security and Access Control | Products and Systems Integration | IPVideo | Creator of a multifunctional safety and security device. | $170 million and share-based compensation of $5 million | December 15, 2023 |

[0000068505-24-000034:mdna:24]
31

[0000068505-24-000034:mdna:25]
[same as prior period, unchanged from 0000068505-24-000024:mdna:25]

[0000068505-24-000034:mdna:26]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 28, 2024 |  | % ofSales* |  | September 30, 2023 |  | % ofSales* |  | September 28, 2024 |  | % ofSales* |  | September 30, 2023 |  | % ofSales* |
| Net sales from products | $ | 1,670 |  |  |  |  | $ | 1,490 |  |  |  |  | $ | 4,639 |  |  |  |  | $ | 4,063 |  |  |  |
| Net sales from services | 1,120 |  |  |  |  | 1,066 |  |  |  |  | 3,167 |  |  |  |  | 3,066 |  |  |  |
| Net sales | 2,790 |  |  |  |  | 2,556 |  |  |  |  | 7,806 |  |  |  |  | 7,129 |  |  |  |
| Costs of products sales | 688 |  |  | 41.2 | % |  | 658 |  |  | 44.2 | % |  | 1,941 |  |  | 41.8 | % |  | 1,867 |  |  | 46.0 | % |
| Costs of services sales | 669 |  |  | 59.7 | % |  | 618 |  |  | 58.0 | % |  | 1,902 |  |  | 60.1 | % |  | 1,747 |  |  | 57.0 | % |
| Costs of sales | 1,357 |  |  |  |  | 1,276 |  |  |  |  | 3,843 |  |  |  |  | 3,614 |  |  |  |
| Gross margin | 1,433 |  |  | 51.4 | % |  | 1,280 |  |  | 50.1 | % |  | 3,963 |  |  | 50.8 | % |  | 3,515 |  |  | 49.3 | % |
| Selling, general and administrative expenses | 439 |  |  | 15.7 | % |  | 380 |  |  | 14.9 | % |  | 1,265 |  |  | 16.2 | % |  | 1,138 |  |  | 16.0 | % |
| Research and development expenditures | 234 |  |  | 8.4 | % |  | 215 |  |  | 8.4 | % |  | 671 |  |  | 8.6 | % |  | 640 |  |  | 9.0 | % |
| Other charges | 49 |  |  | 1.8 | % |  | 46 |  |  | 1.8 | % |  | 153 |  |  | 2.0 | % |  | 181 |  |  | 2.5 | % |
| Operating earnings | 711 |  |  | 25.5 | % |  | 639 |  |  | 25.0 | % |  | 1,874 |  |  | 24.0 | % |  | 1,556 |  |  | 21.8 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (58) |  |  | (2.1) | % |  | (53) |  |  | (2.1) | % |  | (171) |  |  | (2.2) | % |  | (164) |  |  | (2.3) | % |
| Losses on sales of investments and businesses, net | — |  |  | — | % |  | (1) |  |  | — | % |  | — |  |  | — | % |  | — |  |  | — | % |
| Other, net | 42 |  |  | 1.5 | % |  | 7 |  |  | 0.3 | % |  | (519) |  |  | (6.6) | % |  | 46 |  |  | 0.6 | % |
| Total other expense | (16) |  |  | (0.6) | % |  | (47) |  |  | (1.8) | % |  | (690) |  |  | (8.8) | % |  | (118) |  |  | (1.7) | % |
| Net earnings before income taxes | 695 |  |  | 24.9 | % |  | 592 |  |  | 23.2 | % |  | 1,184 |  |  | 15.2 | % |  | 1,438 |  |  | 20.2 | % |
| Income tax expense | 132 |  |  | 4.7 | % |  | 127 |  |  | 5.0 | % |  | 214 |  |  | 2.7 | % |  | 321 |  |  | 4.5 | % |
| Net earnings | 563 |  |  | 20.2 | % |  | 465 |  |  | 18.2 | % |  | 970 |  |  | 12.4 | % |  | 1,117 |  |  | 15.7 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | — | % |  | 4 |  |  | 0.1 | % |  | 4 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 562 |  |  | 20.2 | % |  | $ | 464 |  |  | 18.2 | % |  | $ | 966 |  |  | 12.3 | % |  | $ | 1,113 |  |  | 15.6 | % |
| Earnings per diluted common share | $ | 3.29 |  |  |  |  | $ | 2.70 |  |  |  |  | $ | 5.66 |  |  |  |  | $ | 6.46 |  |  |  |

[0000068505-24-000034:mdna:27]
[same as prior period, unchanged from 0000068505-24-000024:mdna:27]

[0000068505-24-000034:mdna:28]
32

[0000068505-24-000034:mdna:29]
Results of Operations—Three months ended September 28, 2024 compared to three months ended September 30, 2023

[0000068505-24-000034:mdna:30]
The results of operations for the third quarter of 2024 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-24-000034:mdna:31]
[same as prior period, unchanged from 0000068505-24-000024:mdna:31]

[0000068505-24-000034:mdna:32]
[same as prior period, unchanged from 0000068505-24-000024:mdna:32]

[0000068505-24-000034:mdna:33]
[same as prior period, unchanged from 0000068505-24-000024:mdna:33]

[0000068505-24-000034:mdna:34]
[same as prior period, unchanged from 0000068505-24-000024:mdna:34]

[0000068505-24-000034:mdna:35]
[same as prior period, unchanged from 0000068505-24-000024:mdna:35]

[0000068505-24-000034:mdna:36]
|  | Three Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |  | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |
| International | 480 |  |  | 303 |  |  | 783 |  |  | 457 |  |  | 316 |  |  | 773 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |  | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |
| Video | 292 |  |  | 208 |  |  | 500 |  |  | 300 |  |  | 153 |  |  | 453 |  |
| Command Center | — |  |  | 202 |  |  | 202 |  |  | — |  |  | 186 |  |  | 186 |  |
| Total | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Operating earnings | $ | 446 |  |  | $ | 265 |  |  | $ | 711 |  |  | $ | 364 |  |  | $ | 275 |  |  | $ | 639 |  |
| Operating margins | 25.0 | % |  | 26.3 | % |  | 25.5 | % |  | 22.6 | % |  | 29.1 | % |  | 25.0 | % |

[0000068505-24-000034:mdna:37]
[same as prior period, unchanged from 0000068505-24-000024:mdna:37]

[0000068505-24-000034:mdna:38]
The Products and Systems Integration segment’s net sales represented 64% of our net sales in the third quarter of 2024 and 63% in the third quarter of 2023. The Software and Services segment’s net sales represented 36% of our net sales in the third quarter of 2024 and 37% in the third quarter of 2023.

[0000068505-24-000034:mdna:39]
Net sales increased $234 million, or 9%, in the third quarter of 2024 compared to the third quarter of 2023. The $172 million, or 11%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 13% in the North America region and an increase of 5% in the International region. The $62 million, or 7% increase in net sales within the Software and Services segment was driven by an increase of 12% in the North America region, partially offset by a decrease of 4% in the International region. Net sales includes:

[0000068505-24-000034:mdna:40]
•an increase in the Products and Systems Integration segment, inclusive of $11 million of revenue from acquisitions, driven by an increase in LMR, partially offset by a decrease in Video;

[0000068505-24-000034:mdna:41]
•an increase in the Software and Services segment, inclusive of $25 million of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by a decrease in LMR services due to the revenue reduction on Airwave services in accordance with the Charge Control and the Company's exit of the ESN contract with the UK Home Office in 2022, inclusive of twelve months of transition services through the end of 2023 (the "ESN Exit"); and

[0000068505-24-000034:mdna:42]
•inclusive of $4 million from unfavorable currency rates.

[0000068505-24-000034:mdna:43]
[same as prior period, unchanged from 0000068505-24-000024:mdna:43]

[0000068505-24-000034:mdna:44]
•a 13% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-24-000034:mdna:45]
•a 1% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in Video, Command Center and LMR, inclusive of the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit.

[0000068505-24-000034:mdna:46]
[same as prior period, unchanged from 0000068505-24-000024:mdna:46]

[0000068505-24-000034:mdna:47]
The 11% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000034:mdna:48]
•$180 million, or 14% growth in LMR, driven by the North America and International regions due to improved supply and favorable mix; partially offset by

[0000068505-24-000034:mdna:49]
•$8 million, or 3% decrease in Video, inclusive of revenue from acquisitions, driven by the International and North America regions; and

[0000068505-24-000034:mdna:50]
•inclusive of $1 million from unfavorable currency rates.

[0000068505-24-000034:mdna:51]
[same as prior period, unchanged from 0000068505-24-000024:mdna:51]

[0000068505-24-000034:mdna:52]
The 7% increase in the Software and Services segment was driven by the following:

[0000068505-24-000034:mdna:53]
•$55 million, or 36% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-24-000034:mdna:54]
•$16 million, or 9% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America and International regions; partially offset by

[0000068505-24-000034:mdna:55]
•$9 million, or 1% decrease in LMR services, driven by the International region due to the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by an increase in the North America region; and

[0000068505-24-000034:mdna:56]
[same as prior period, unchanged from 0000068505-24-000024:mdna:56]

[0000068505-24-000034:mdna:57]
[same as prior period, unchanged from 0000068505-24-000024:mdna:57]

[0000068505-24-000034:mdna:58]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Gross margin | $ | 1,433 |  |  | $ | 1,280 |  |  | 12 | % |

[0000068505-24-000034:mdna:59]
Gross margin was 51.4% of net sales in the third quarter of 2024 compared to 50.1% in the third quarter of 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-24-000034:mdna:60]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, favorable mix and lower direct material costs; partially offset by

[0000068505-24-000034:mdna:61]
[same as prior period, unchanged from 0000068505-24-000024:mdna:61]

[0000068505-24-000034:mdna:62]
[same as prior period, unchanged from 0000068505-24-000024:mdna:62]

[0000068505-24-000034:mdna:63]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Selling, general and administrative expenses | $ | 439 |  |  | $ | 380 |  |  | 16 | % |

[0000068505-24-000034:mdna:64]
SG&A expenses increased 16% in the third quarter of 2024 compared to the third quarter of 2023. The increase in SG&A expenses was primarily due to higher employee incentive costs, including share-based compensation, higher expenses related to legal matters and higher expenses associated with acquired businesses. SG&A expenses were 15.7% of net sales in the third quarter of 2024 compared to 14.9% of net sales in the third quarter of 2023.

[0000068505-24-000034:mdna:65]
[same as prior period, unchanged from 0000068505-24-000024:mdna:65]

[0000068505-24-000034:mdna:66]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Research and development expenditures | $ | 234 |  |  | $ | 215 |  |  | 9 | % |

[0000068505-24-000034:mdna:67]
R&D expenditures increased 9% in the third quarter of 2024 compared to the third quarter of 2023 primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses. R&D expenditures were 8.4% of net sales in each of the third quarter of 2024 and in the third quarter of 2023.

[0000068505-24-000034:mdna:68]
[same as prior period, unchanged from 0000068505-24-000024:mdna:68]

[0000068505-24-000034:mdna:69]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Other charges | $ | 49 |  |  | $ | 46 |  |

[0000068505-24-000034:mdna:70]
Other charges increased by $3 million in the third quarter of 2024 compared to the third quarter of 2023. The change was driven primarily by $4 million of acquisition-related transaction fees in the third quarter of 2024 compared to $1 million of acquisition-related transaction fees in third quarter of 2023.

[0000068505-24-000034:mdna:71]
[same as prior period, unchanged from 0000068505-24-000024:mdna:74]

[0000068505-24-000034:mdna:72]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Operating earnings from Products and Systems Integration | $ | 446 |  |  | $ | 364 |  |
| Operating earnings from Software and Services | 265 |  |  | 275 |  |
| Operating earnings | $ | 711 |  |  | $ | 639 |  |

[0000068505-24-000034:mdna:73]
Operating earnings increased $72 million, or 11%, in the third quarter of 2024 compared to the third quarter of 2023. The increase in Operating earnings was due to:

[0000068505-24-000034:mdna:74]
•an $82 million increase in the Products and Systems Integration segment, primarily driven by higher sales, favorable change in year-over-year mix and lower direct material costs, partially offset by higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters; partially offset by

[0000068505-24-000034:mdna:75]
•a $10 million decrease in the Software and Services segment, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control, higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters, partially offset by higher sales.

[0000068505-24-000034:mdna:76]
[same as prior period, unchanged from 0000068505-24-000024:mdna:79]

[0000068505-24-000034:mdna:77]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Interest expense, net | $ | (58) |  |  | $ | (53) |  |

[0000068505-24-000034:mdna:78]
The $5 million increase in Interest expense, net in the third quarter of 2024 compared to the third quarter of 2023 was primarily driven by higher interest rates on outstanding debt, partially offset by higher interest income.

[0000068505-24-000034:mdna:79]
[same as prior period, unchanged from 0000068505-24-000024:mdna:82]

[0000068505-24-000034:mdna:80]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Other, net | $ | 42 |  |  | $ | 7 |  |

[0000068505-24-000034:mdna:81]
The $35 million increase in Other, net in the third quarter of 2024 compared to the third quarter of 2023 was primarily driven by:

[0000068505-24-000034:mdna:82]
•$22 million gain on derivatives in the third quarter of 2024 compared to a $26 million loss on derivatives in the third quarter of 2023;

[0000068505-24-000034:mdna:83]
•$9 million gain on fair value adjustments to equity investments in the third quarter of 2024 compared to a $7 million loss on fair value adjustments to equity investments in the third quarter of 2023;

[0000068505-24-000034:mdna:84]
•$32 million of net periodic pension and postretirement benefit in the third quarter of 2024 compared to $24 million of net periodic pension and postretirement benefit in the third quarter of 2023; and

[0000068505-24-000034:mdna:85]
•$7 million loss on investment impairments in the third quarter of 2023 that did not occur in the third quarter of 2024; partially offset by

[0000068505-24-000034:mdna:86]
•$26 million of foreign currency losses in the third quarter of 2024 compared to $23 million of foreign currency gains in the third quarter of 2023.

[0000068505-24-000034:mdna:87]
[same as prior period, unchanged from 0000068505-24-000024:mdna:91]

[0000068505-24-000034:mdna:88]
|  | Three Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Income tax expense | $ | 132 |  |  | $ | 127 |  |

[0000068505-24-000034:mdna:89]
Income tax expense increased by $5 million in the third quarter of 2024 compared to the third quarter of 2023, resulting in an effective tax rate of 19%. Our effective tax rate for the three months ended September 28, 2024 of 19% was lower than the effective tax rate for the three months ended September 30, 2023 of 21%, primarily due to higher excess tax benefits of share-based compensation and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024.

[0000068505-24-000034:mdna:90]
Results of Operations—Nine months ended September 28, 2024 compared to Nine months ended September 30, 2023

[0000068505-24-000034:mdna:91]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |  | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |
| International | 1,302 |  |  | 888 |  |  | 2,190 |  |  | 1,222 |  |  | 991 |  |  | 2,213 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |  | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |
| Video | 821 |  |  | 553 |  |  | 1,374 |  |  | 810 |  |  | 435 |  |  | 1,245 |  |
| Command Center | — |  |  | 581 |  |  | 581 |  |  | — |  |  | 535 |  |  | 535 |  |
| Total | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Operating earnings | $ | 1,135 |  |  | $ | 739 |  |  | $ | 1,874 |  |  | $ | 752 |  |  | $ | 804 |  |  | $ | 1,556 |  |
| Operating margins | 23.0 | % |  | 25.7 | % |  | 24.0 | % |  | 17.3 | % |  | 29.0 | % |  | 21.8 | % |

[0000068505-24-000034:mdna:92]
[same as prior period, unchanged from 0000068505-24-000024:mdna:96]

[0000068505-24-000034:mdna:93]
The Products and Systems Integration segment's net sales represented 63% of our net sales in the first nine months of 2024 and 61% in the first nine months of 2023. Net sales from the Software and Services segment represented 37% of our net sales in the first nine months of 2024 and 39% in the first nine months of 2023.

[0000068505-24-000034:mdna:94]
Net sales increased $677 million, or 9%, in the first nine months of 2024 compared to the first nine months of 2023. The $581 million, or 13%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 16% in the North America region and an increase of 7% in the International region. The $96 million, or 3%, increase in net sales within the Software and Services segment was driven by an increase of 11% in the North America region, partially offset by a decrease of 10% in the International region. Net sales includes:

[0000068505-24-000034:mdna:95]
•an increase in the Products and Systems Integration segment, inclusive of $32 million of revenue from acquisitions, driven by an increase in LMR and Video;

[0000068505-24-000034:mdna:96]
•an increase in Software and Services, inclusive of $26 million of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by a decrease in LMR services driven by the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit; and

[0000068505-24-000034:mdna:97]
•inclusive of $8 million from unfavorable currency rates.

[0000068505-24-000034:mdna:98]
[same as prior period, unchanged from 0000068505-24-000024:mdna:102]

[0000068505-24-000034:mdna:99]
•a 14% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; partially offset by

[0000068505-24-000034:mdna:100]
•a 1% decrease in the International region, inclusive of revenue from acquisitions, driven by a decrease in LMR due to the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by an increase in Video and Command Center.

[0000068505-24-000034:mdna:101]
[same as prior period, unchanged from 0000068505-24-000024:mdna:105]

[0000068505-24-000034:mdna:102]
The 13% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-24-000034:mdna:103]
•$570 million, or 16% growth in LMR, driven by both the North America and International regions;

[0000068505-24-000034:mdna:104]
•$11 million, or 1% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-24-000034:mdna:105]
•inclusive of $3 million from unfavorable currency rates.

[0000068505-24-000034:mdna:106]
[same as prior period, unchanged from 0000068505-24-000024:mdna:110]

[0000068505-24-000034:mdna:107]
The 3% increase in the Software and Services segment was driven by the following:

[0000068505-24-000034:mdna:108]
•$118 million, or 27% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-24-000034:mdna:109]
•$46 million, or 9% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America and International regions; partially offset by

[0000068505-24-000034:mdna:110]
•$68 million, or 4% decrease in LMR services, driven by the International region due to the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by an increase in the North America region; and

[0000068505-24-000034:mdna:111]
•inclusive of $5 million from unfavorable currency rates.

[0000068505-24-000034:mdna:112]
[same as prior period, unchanged from 0000068505-24-000024:mdna:116]

[0000068505-24-000034:mdna:113]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Gross margin | $ | 3,963 |  |  | $ | 3,515 |  |  | 13 | % |

[0000068505-24-000034:mdna:114]
Gross margin was 50.8% of net sales in the first nine months of 2024 compared to 49.3% in the first nine months of 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-24-000034:mdna:115]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, favorable mix and lower direct material costs; partially offset by

[0000068505-24-000034:mdna:116]
[same as prior period, unchanged from 0000068505-24-000024:mdna:120]

[0000068505-24-000034:mdna:117]
[same as prior period, unchanged from 0000068505-24-000024:mdna:121]

[0000068505-24-000034:mdna:118]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Selling, general and administrative expenses | $ | 1,265 |  |  | $ | 1,138 |  |  | 11 | % |

[0000068505-24-000034:mdna:119]
SG&A expenses increased 11% in the first nine months of 2024 compared to the first nine months of 2023. The increase in SG&A expenses was primarily due to higher employee incentive costs, including share-based compensation, higher expenses related to legal matters and higher expenses associated with acquired businesses. SG&A expenses were 16.2% of net sales in the first nine months of 2024 compared to 16.0% of net sales in the first nine months of 2023.

[0000068505-24-000034:mdna:120]
[same as prior period, unchanged from 0000068505-24-000024:mdna:124]

[0000068505-24-000034:mdna:121]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |  | % Change |
| Research and development expenditures | $ | 671 |  |  | $ | 640 |  |  | 5 | % |

[0000068505-24-000034:mdna:122]
R&D expenditures increased 5% in the first nine months of 2024 compared to the first nine months of 2023 primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses. R&D expenditures were 8.6% of net sales in the first nine months of 2024 compared to 9.0% of net sales in the first nine months of 2023.

[0000068505-24-000034:mdna:123]
[same as prior period, unchanged from 0000068505-24-000024:mdna:127]

[0000068505-24-000034:mdna:124]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Other charges | $ | 153 |  |  | $ | 181 |  |

[0000068505-24-000034:mdna:125]
Other charges decreased by $28 million in the first nine months of 2024 compared to the first nine months of 2023. The change was driven primarily by the following:

[0000068505-24-000034:mdna:126]
•$114 million of intangible asset amortization expense in the first nine months of 2024 compared to $137 million of intangible asset amortization expense in the first nine months of 2023; and

[0000068505-24-000034:mdna:127]
•$15 million of environmental reserve expense in the first nine months of 2023 that did not occur in the first nine months of 2024; partially offset by

[0000068505-24-000034:mdna:128]
•$11 million of acquisition-related transaction fees in the first nine months of 2024 compared to $3 million of acquisition-related transaction fees in the first nine months of 2023; and

[0000068505-24-000034:mdna:129]
•$7 million of legal settlement charges in the first nine months of 2024 compared to $1 million of legal settlement charges in the first nine months of 2023.

[0000068505-24-000034:mdna:130]
[same as prior period, unchanged from 0000068505-24-000024:mdna:135]

[0000068505-24-000034:mdna:131]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Operating earnings from Products and Systems Integration | $ | 1,135 |  |  | $ | 752 |  |
| Operating earnings from Software and Services | 739 |  |  | 804 |  |
| Operating earnings | $ | 1,874 |  |  | $ | 1,556 |  |

[0000068505-24-000034:mdna:132]
Operating earnings increased $318 million, or 20%, in the first nine months of 2024 compared to the first nine months of 2023. The increase in Operating earnings was due to:

[0000068505-24-000034:mdna:133]
•a $383 million increase in the Products and Systems Integration segment, primarily driven by higher sales, favorable mix, and lower direct material costs, partially offset by higher employee incentive costs, including share-based compensation, higher expenses associated with acquired businesses and higher expenses related to legal matters; partially offset by

[0000068505-24-000034:mdna:134]
•a $65 million decrease in the Software and Services segment, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control, higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters, partially offset by higher sales and a reduction in intangible amortization expenses.

[0000068505-24-000034:mdna:135]
[same as prior period, unchanged from 0000068505-24-000024:mdna:140]

[0000068505-24-000034:mdna:136]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Interest expense, net | $ | (171) |  |  | $ | (164) |  |

[0000068505-24-000034:mdna:137]
The $7 million increase in net interest expense in the first nine months of 2024 compared to the first nine months of 2023 was primarily driven by higher outstanding debt, higher interest rates on outstanding debt and an interest accrual related to the settlement of audits with taxing authorities in foreign jurisdictions, partially offset by higher interest income earned on cash.

[0000068505-24-000034:mdna:138]
[same as prior period, unchanged from 0000068505-24-000024:mdna:143]

[0000068505-24-000034:mdna:139]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Other, net | $ | (519) |  |  | $ | 46 |  |

[0000068505-24-000034:mdna:140]
The $565 million decrease in Other, net in the first nine months of 2024 compared to the first nine months of 2023 was primarily driven by:

[0000068505-24-000034:mdna:141]
•$585 million loss from the extinguishment of the $1.0 billion of 1.75% senior convertible notes issued to Silver Lake Partners and scheduled to mature in September 2024 (the "Silver Lake Convertible Debt") which was recognized in the first nine months of 2024;

[0000068505-24-000034:mdna:142]
•$4 million loss on fair value adjustments to equity investments in the first nine months of 2024 compared to a $12 million gain on fair value adjustments to equity investments in the first nine months of 2023;

[0000068505-24-000034:mdna:143]
•$11 million loss on assessments of uncertain tax positions in the first nine months of 2024 that did not occur in the first nine months of 2023; and

[0000068505-24-000034:mdna:144]
•$22 million of foreign currency losses in the first nine months of 2024 compared to $16 million of foreign currency losses in the first nine months of 2023; partially offset by

[0000068505-24-000034:mdna:145]
•$95 million of net periodic pension and postretirement benefit in the first nine months of 2024 compared to $73 million of net periodic pension and postretirement benefit in the first nine months of 2023;

[0000068505-24-000034:mdna:146]
•$7 million of gains on derivative instruments in the first nine months of 2024 compared to $9 million of losses on derivative instruments in the first nine months of 2023; and

[0000068505-24-000034:mdna:147]
•$3 million of investment impairments in the first nine months of 2024 compared to $16 million of investment impairments in the first nine months of 2023.

[0000068505-24-000034:mdna:148]
[same as prior period, unchanged from 0000068505-24-000024:mdna:153]

[0000068505-24-000034:mdna:149]
|  | Nine Months Ended |
| (In millions) | September 28, 2024 |  | September 30, 2023 |
| Income tax expense | $ | 214 |  |  | $ | 321 |  |

[0000068505-24-000034:mdna:150]
Income tax expense decreased by $107 million in the first nine months of 2024 compared to the first nine months of 2023, resulting in an effective tax rate of 18%. Our effective tax rate of 18% for the nine months ended September 28, 2024 was lower than the effective tax rate for the nine months ended September 30, 2023 of 22%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions, and higher excess tax benefits of share-based compensation in 2024, offset by the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024.

[0000068505-24-000034:mdna:151]
[same as prior period, unchanged from 0000068505-24-000024:mdna:156]

[0000068505-24-000034:mdna:152]
During the third quarter of 2024, we recorded net reorganization of business charges of $7 million, including $5 million of charges recorded within Other charges and $2 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for employee separation accruals that are no longer needed.

[0000068505-24-000034:mdna:153]
During the first nine months of 2024, we recorded net reorganization of business charges of $21 million, including $16 million of charges recorded within Other charges and $5 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $21 million were charges of $30 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000034:mdna:154]
During the third quarter of 2023, we recorded net reorganization of business charges of $6 million, including $4 million of charges in Other charges and $2 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $6 million were charges of $8 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000034:mdna:155]
During the first nine months of 2023, we recorded net reorganization of business charges of $22 million, including $16 million of charges recorded in Other charges and $6 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $22 million were charges of $32 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000034:mdna:156]
[same as prior period, unchanged from 0000068505-24-000024:mdna:161]

[0000068505-24-000034:mdna:157]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Products and Systems Integration | $ | 6 |  |  | $ | 5 |  |  | $ | 20 |  |  | $ | 22 |  |
| Software and Services | 1 |  |  | 1 |  |  | 1 |  |  | — |  |
|  | $ | 7 |  |  | $ | 6 |  |  | $ | 21 |  |  | $ | 22 |  |

[0000068505-24-000034:mdna:158]
Cash payments for employee severance in connection with the reorganization of business plans were $27 million in the first nine months of 2024 and $28 million in the first nine months of 2023. The reorganization of business accrual at September 28, 2024 was $21 million related to employee separation costs that are expected to be paid within one year.

[0000068505-24-000034:mdna:159]
At January 1, 2024, we had an accrual of $5 million for exit costs related to our exit of the ESN contract with the UK Home Office. During the nine months ended September 28, 2024, we recorded a $4 million reversal for accruals no longer needed. The $1 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at September 28, 2024, and are expected to be paid within one year.

[0000068505-24-000034:mdna:160]
[same as prior period, unchanged from 0000068505-24-000024:mdna:165]

[0000068505-24-000034:mdna:161]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 1,321 |  |  | $ | 799 |  |
| Investing activities | (400) |  |  | (172) |  |
| Financing activities | (1,234) |  |  | (1,043) |  |
| Effect of exchange rates on cash and cash equivalents | 12 |  |  | 1 |  |
| Decrease in cash and cash equivalents | $ | (301) |  |  | $ | (415) |  |

[0000068505-24-000034:mdna:162]
[same as prior period, unchanged from 0000068505-24-000024:mdna:167]

[0000068505-24-000034:mdna:163]
At September 28, 2024, $1.1 billion of the $1.4 billion cash and cash equivalents balance was held in the U.S. and $297 million was held in other countries.

[0000068505-24-000034:mdna:164]
[same as prior period, unchanged from 0000068505-24-000024:mdna:169]

[0000068505-24-000034:mdna:165]
The increase in cash flows provided by operating activities from the first nine months of 2023 to the first nine months of 2024 was driven primarily by higher earnings, net of non-cash adjustments, and improved working capital.

[0000068505-24-000034:mdna:166]
[same as prior period, unchanged from 0000068505-24-000024:mdna:171]

[0000068505-24-000034:mdna:167]
The increase in cash flows used for investing activities in the first nine months of 2024 compared to the first nine months of 2023 was primarily due to an increase in cash used for acquisitions and investments, offset by proceeds from the sale of our Richmond, British Columbia and Richardson, Texas video manufacturing operations.

[0000068505-24-000034:mdna:168]
[same as prior period, unchanged from 0000068505-24-000024:mdna:173]

[0000068505-24-000034:mdna:169]
The increase in cash flows used for financing activities in the first nine months of 2024 compared to the first nine months of 2023 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-24-000034:mdna:170]
•$1.9 billion increase in repayments of debt during the first nine months of 2024 driven primarily by the repurchase of the Silver Lake Convertible Debt and repayment of our 4.0% senior notes due 2024;

[0000068505-24-000034:mdna:171]
•$57 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first nine months of 2024 compared to the first nine months of 2023; and

[0000068505-24-000034:mdna:172]
•$47 million increase in the payment of dividends in the first nine months of 2024 compared to the first nine months of 2023; partially offset by

[0000068505-24-000034:mdna:173]
•$1.3 billion increase in net proceeds in the first nine months of 2024 compared to the first nine months of 2023 driven the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; and

[0000068505-24-000034:mdna:174]
•$529 million decrease in share repurchases in the first nine months of 2024 compared to the first nine months of 2023.

[0000068505-24-000034:mdna:175]
[same as prior period, unchanged from 0000068505-24-000024:mdna:180]

[0000068505-24-000034:mdna:176]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 28, 2024 and September 30, 2023:

[0000068505-24-000034:mdna:177]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Accounts receivable sales proceeds | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |
| Long-term receivables sales proceeds | 56 |  |  | 65 |  |  | 82 |  |  | 123 |  |

[0000068505-24-000034:mdna:178]
[same as prior period, unchanged from 0000068505-24-000024:mdna:183]

[0000068505-24-000034:mdna:179]
We had outstanding debt of $6.0 billion at September 28, 2024, of which $322 million was current. We had outstanding debt of $6.0 billion at December 31, 2023, of which $1.3 billion was current.

[0000068505-24-000034:mdna:180]
During the three months ended September 28, 2024, we repaid the $313 million aggregate principal amount of our 4.0% senior notes due 2024.

[0000068505-24-000034:mdna:181]
As of September 28, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were classified within the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-24-000034:mdna:182]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue the Silver Lake Convertible Debt, which became fully convertible on September 5, 2021. On February 14, 2024, we agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The cash consideration was paid during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the nine months ended September 28, 2024.

[0000068505-24-000034:mdna:183]
On March 25, 2024, we issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. We recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

[0000068505-24-000034:mdna:184]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 28, 2024.

[0000068505-24-000034:mdna:185]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of September 28, 2024 we had no outstanding debt under the commercial paper program.

[0000068505-24-000034:mdna:186]
[same as prior period, unchanged from 0000068505-24-000024:mdna:190]

[0000068505-24-000034:mdna:187]
[same as prior period, unchanged from 0000068505-24-000024:mdna:191]

[0000068505-24-000034:mdna:188]
During the three and nine months ended September 28, 2024, we repurchased approximately 0.1 million and 0.4 million shares at an average price of $440.53 and $355.31 per share for an aggregate amount of $31 million and $141 million, respectively. As of September 28, 2024, we had used approximately $15.7 billion of the share repurchase authority to repurchase shares, leaving $2.3 billion of authority available for future repurchases.

[0000068505-24-000034:mdna:189]
[same as prior period, unchanged from 0000068505-24-000024:mdna:193]

[0000068505-24-000034:mdna:190]
During the third quarter of 2024 we paid $164 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $164 million in cash dividends to holders of our common stock.

[0000068505-24-000034:mdna:191]
[same as prior period, unchanged from 0000068505-24-000024:mdna:195]

[0000068505-24-000034:mdna:192]
[same as prior period, unchanged from 0000068505-24-000024:mdna:196]

[0000068505-24-000034:mdna:193]
[same as prior period, unchanged from 0000068505-24-000024:mdna:197]

[0000068505-24-000034:mdna:194]
[same as prior period, unchanged from 0000068505-24-000024:mdna:198]

[0000068505-24-000034:mdna:195]
We had outstanding commitments to provide long-term financing to third parties totaling $66 million at September 28, 2024, compared to $103 million at December 31, 2023.

[0000068505-24-000034:mdna:196]
[same as prior period, unchanged from 0000068505-24-000024:mdna:200]

[0000068505-24-000034:mdna:197]
[same as prior period, unchanged from 0000068505-24-000024:mdna:201]
