# MSI notes — 0000068505-24-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-24-000034:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of September 28, 2024 and for the three and nine months ended September 28, 2024 and September 30, 2023 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-24-000034:notes:2]
[same as prior period, unchanged from 0000068505-24-000024:notes:2]

[0000068505-24-000034:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2023 (the "Form 10-K"). The results of operations for the three and nine months ended September 28, 2024 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-24-000034:notes:4]
[same as prior period, unchanged from 0000068505-24-000024:notes:4]

[0000068505-24-000034:notes:5]
[same as prior period, unchanged from 0000068505-24-000024:notes:5]

[0000068505-24-000034:notes:6]
[same as prior period, unchanged from 0000068505-24-000024:notes:6]

[0000068505-24-000034:notes:7]
[same as prior period, unchanged from 0000068505-24-000024:notes:7]

[0000068505-24-000034:notes:8]
[same as prior period, unchanged from 0000068505-24-000024:notes:8]

[0000068505-24-000034:notes:9]
[same as prior period, unchanged from 0000068505-24-000024:notes:9]

[0000068505-24-000034:notes:10]
[same as prior period, unchanged from 0000068505-24-000024:notes:10]

[0000068505-24-000034:notes:11]
Subsequent to quarter end, on October 29, 2024, the Company acquired 3tc Software ("3tc"), a provider of control room software solutions for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the UK's public safety agencies. This business is part of the Software and Services segment.

[0000068505-24-000034:notes:12]
On July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

[0000068505-24-000034:notes:13]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

[0000068505-24-000034:notes:14]
[same as prior period, unchanged from 0000068505-24-000024:notes:13]

[0000068505-24-000034:notes:15]
[same as prior period, unchanged from 0000068505-24-000024:notes:14]

[0000068505-24-000034:notes:16]
[same as prior period, unchanged from 0000068505-24-000024:notes:15]

[0000068505-24-000034:notes:17]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The ASU is effective for fiscal years beginning after December 15, 2023, and interim periods beginning in 2025, with early adoption permitted. The ASU will require the Company to disclose additional expense categories at the segment level including Cost of sales, Selling, general and administrative expenses, Research and development expenditures and Other charges once it adopts this ASU. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-24-000034:notes:18]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-24-000034:notes:19]
[same as prior period, unchanged from 0000068505-24-000024:notes:18]

[0000068505-24-000034:notes:20]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 28, 2024 and September 30, 2023, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-24-000034:notes:21]
|  | Three Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |  | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |
| International | 480 |  |  | 303 |  |  | 783 |  |  | 457 |  |  | 316 |  |  | 773 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |  | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |
| Video | 292 |  |  | 208 |  |  | 500 |  |  | 300 |  |  | 153 |  |  | 453 |  |
| Command Center | — |  |  | 202 |  |  | 202 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,108 |  |  | $ | 917 |  |  | 2,025 |  |  | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |
| Indirect | 676 |  |  | 89 |  |  | 765 |  |  | 672 |  |  | 85 |  |  | 757 |  |
|  | $ | 1,784 |  |  | $ | 1,006 |  |  | 2,790 |  |  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |

[0000068505-24-000034:notes:22]
|  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |  | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |
| International | 1,302 |  |  | 888 |  |  | 2,190 |  |  | 1,222 |  |  | 991 |  |  | 2,213 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |  | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |
| Video | 821 |  |  | 553 |  |  | 1,374 |  |  | 810 |  |  | 435 |  |  | 1,245 |  |
| Command Center | — |  |  | 581 |  |  | 581 |  |  | — |  |  | 535 |  |  | 535 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |  | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |
| Indirect | 1,964 |  |  | 256 |  |  | 2,220 |  |  | 1,893 |  |  | 248 |  |  | 2,141 |  |
|  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |

[0000068505-24-000034:notes:23]
[same as prior period, unchanged from 0000068505-24-000024:notes:22]

[0000068505-24-000034:notes:24]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 28, 2024 was $9.1 billion. A total of $4.2 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 28, 2024, of which $2.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.9 billion was from Software and Services performance obligations that were not yet satisfied as of September 28, 2024. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-24-000034:notes:25]
On March 13, 2024, the Company received a notice of contract extension (the “Deferred National Shutdown Notice”) from the UK Home Office. The Deferred National Shutdown Notice seeks to extend the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the rates implemented by a prospective price control on Airwave imposed by the Competition and Markets Authority (the "Charge Control"). In the first nine months of 2024, as a result of the UK Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, the Company recorded additional Software and Services performance obligations of $748 million to reflect the incremental three-years of services.

[0000068505-24-000034:notes:26]
[same as prior period, unchanged from 0000068505-24-000024:notes:25]

[0000068505-24-000034:notes:27]
[same as prior period, unchanged from 0000068505-24-000024:notes:26]

[0000068505-24-000034:notes:28]
| (In millions) | September 28, 2024 |  | December 31, 2023 |  |  |  |  |
| Accounts receivable, net | $ | 1,848 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,301 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 1,942 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 480 |  |  | 424 |  |  |  |  |  |

[0000068505-24-000034:notes:29]
Revenue recognized during the three months ended September 28, 2024 which was previously included in Contract liabilities as of June 29, 2024 was $572 million, compared to $475 million of revenue recognized during the three months ended September 30, 2023 which was previously included in Contract liabilities as of July 1, 2023. Revenue recognized during the nine months ended September 28, 2024 which was previously included in Contract liabilities as of December 31, 2023 was $1.2 billion, compared to $1.1 billion recognized during the nine months ended September 30, 2023 which was previously included in Contract liabilities as of December 31, 2022. Revenue of $6 million was recognized during the three months ended September 28, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. During the three months ended September 30, 2023, revenue adjustments driven by the changes in estimates of progress on system contracts were de minimis. Revenue of $11 million was reversed during the nine months ended September 28, 2024 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $18 million of reversals for the nine months ended September 30, 2023.

[0000068505-24-000034:notes:30]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 28, 2024 and September 30, 2023.

[0000068505-24-000034:notes:31]
[same as prior period, unchanged from 0000068505-24-000024:notes:30]

[0000068505-24-000034:notes:32]
| (In millions) | September 28, 2024 |  | December 31, 2023 |  |  |  |  |
| Current contract cost assets | $ | 78 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 124 |  |  | 119 |  |  |  |  |  |

[0000068505-24-000034:notes:33]
Amortization of contract cost assets was $13 million and $38 million for the three and nine months ended September 28, 2024, respectively, and $10 million and $35 million for the three and nine months ended September 30, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-24-000034:notes:34]
[same as prior period, unchanged from 0000068505-24-000024:notes:33]

[0000068505-24-000034:notes:35]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 34 |  |  | $ | 35 |  |  | $ | 103 |  |  | $ | 103 |  |
| Short-term lease cost | — |  |  | — |  |  | — |  |  | 1 |
| Variable cost | 12 |  |  | 10 |  |  | 34 |  |  | 28 |  |
| Sublease income | (1) |  |  | (1) |  |  | (4) |  |  | (3) |  |
| Net lease expense from operating leases | $ | 45 |  |  | $ | 44 |  |  | $ | 133 |  |  | $ | 129 |  |

[0000068505-24-000034:notes:36]
[same as prior period, unchanged from 0000068505-24-000024:notes:35]

[0000068505-24-000034:notes:37]
| (in millions) |  | Statement Line Classification |  | September 28, 2024 |  | December 31, 2023 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 551 |  |  | $ | 495 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | 131 |  |  | 125 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | 444 |  |  | 407 |  |  |  |

[0000068505-24-000034:notes:38]
[same as prior period, unchanged from 0000068505-24-000024:notes:37]

[0000068505-24-000034:notes:39]
|  | Nine Months Ended |  |  |
| (in millions) | September 28, 2024 |  | September 30, 2023 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 118 |  |  | $ | 103 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | 123 |  |  | 52 |  |  |  |

[0000068505-24-000034:notes:40]
During the nine months ended September 28, 2024, the Company recorded $80 million of assets obtained in exchange for lease liabilities due to an assumption that it is reasonably certain that renewal options will be extended on its radio tower site leases operated within the Airwave radio network, consistent with the UK Home Office's notice of contract extension pursuant to their Deferred National Shutdown Notice through December 31, 2029. In addition, assets obtained in exchange for lease liabilities of $19 million were recorded in connection with the Company's renewal of an International region office lease by ten years.

[0000068505-24-000034:notes:41]
|  | September 28, 2024 |  | December 31, 2023 |
| Weighted average remaining lease terms (years) | 5 |  | 5 |
| Weighted average discount rate: | 3.92 | % |  | 4.34 | % |

[0000068505-24-000034:notes:42]
[same as prior period, unchanged from 0000068505-24-000024:notes:41]

[0000068505-24-000034:notes:43]
|  | September 28, 2024 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2024 | $ | 32 |  |  |  |  |  |
| 2025 | 147 |  |  |  |  |  |
| 2026 | 128 |  |  |  |  |  |
| 2027 | 109 |  |  |  |  |  |
| 2028 | 84 |  |  |  |  |  |
| Thereafter | 136 |  |  |  |  |  |
| Total lease payments | 636 |  |  |  |  |  |
| Less: interest | 61 |  |  |  |  |  |
| Present value of lease liabilities | $ | 575 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-24-000034:notes:44]
[same as prior period, unchanged from 0000068505-24-000024:notes:43]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-24-000034:notes:45]
[same as prior period, unchanged from 0000068505-24-000024:notes:44]

[0000068505-24-000034:notes:46]
[same as prior period, unchanged from 0000068505-24-000024:notes:45]

[0000068505-24-000034:notes:47]
[same as prior period, unchanged from 0000068505-24-000024:notes:46]

[0000068505-24-000034:notes:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 38 |  |  | $ | 39 |  |  | $ | 114 |  |  | $ | 137 |  |
| Reorganization of business (Note 14) | 5 |  |  | 4 |  |  | 16 |  |  | 16 |  |
| Operating lease asset impairments | 1 |  |  | — |  |  | 5 |  |  | 4 |  |
| Acquisition-related transaction fees | 4 |  |  | 1 |  |  | 11 |  |  | 3 |  |
| Environmental reserve expense | — |  |  | — |  |  | — |  |  | 15 |  |
| Legal settlements | 1 |  |  | 1 |  |  | 7 |  |  | 1 |  |
| Fixed asset impairments | — |  |  | — |  |  | — |  |  | 3 |  |
| Other | — |  |  | 1 |  |  | — |  |  | 2 |  |
|  | $ | 49 |  |  | $ | 46 |  |  | $ | 153 |  |  | $ | 181 |  |

[0000068505-24-000034:notes:49]
[same as prior period, unchanged from 0000068505-24-000024:notes:48]

[0000068505-24-000034:notes:50]
Interest expense, net, and Other, net, both included in Other income (expense), consist of the following:

[0000068505-24-000034:notes:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Interest, net: |  |  |  |  |  |  |  |
| Interest expense | $ | (73) |  |  | $ | (60) |  |  | $ | (221) |  |  | $ | (186) |  |
| Interest income | 15 |  |  | 7 |  |  | 50 |  |  | 22 |  |
|  | $ | (58) |  |  | $ | (53) |  |  | $ | (171) |  |  | $ | (164) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 32 |  |  | $ | 24 |  |  | $ | 95 |  |  | $ | 73 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt (Note 5) | — |  |  | — |  |  | (585) |  |  | — |  |
| Investment impairments | — |  |  | (7) |  |  | (3) |  |  | (16) |  |
| Foreign currency gain (loss) | (26) |  |  | 23 |  |  | (22) |  |  | (16) |  |
| Gain (loss) on derivative instruments (Note 6) | 22 |  |  | (26) |  |  | 7 |  |  | (9) |  |
| Fair value adjustments to equity investments | 9 |  |  | (7) |  |  | (4) |  |  | 12 |  |
| Assessments on uncertain tax positions | — |  |  | — |  |  | (11) |  |  | — |  |
| Other | 5 |  |  | — |  |  | 4 |  |  | 2 |  |
|  | $ | 42 |  |  | $ | 7 |  |  | $ | (519) |  |  | $ | 46 |  |

[0000068505-24-000034:notes:52]
[same as prior period, unchanged from 0000068505-24-000024:notes:51]

[0000068505-24-000034:notes:53]
[same as prior period, unchanged from 0000068505-24-000024:notes:52]

[0000068505-24-000034:notes:54]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 562 |  |  | $ | 464 |  |  | $ | 966 |  |  | $ | 1,113 |  |
| Weighted average common shares outstanding | 167.1 |  |  | 166.7 |  |  | 166.7 |  |  | 167.2 |  |
| Per share amount | $ | 3.36 |  |  | $ | 2.78 |  |  | $ | 5.79 |  |  | $ | 6.66 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 562 |  |  | $ | 464 |  |  | $ | 966 |  |  | $ | 1,113 |  |
| Weighted average common shares outstanding | 167.1 |  |  | 166.7 |  |  | 166.7 |  |  | 167.2 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.8 |  |  | 3.5 |  |  | 3.9 |  |  | 3.6 |  |
| Silver Lake Convertible Debt | — |  |  | 1.5 |  |  | — |  |  | 1.4 |  |
| Diluted weighted average common shares outstanding | 170.9 |  |  | 171.7 |  |  | 170.6 |  |  | 172.2 |  |
| Per share amount | $ | 3.29 |  |  | $ | 2.70 |  |  | $ | 5.66 |  |  | $ | 6.46 |  |

[0000068505-24-000034:notes:55]
In the computation of diluted earnings per common share for the three months ended September 28, 2024, the assumed exercise of 0.1 million options were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000034:notes:56]
In the computation of diluted earnings per common share for the nine months ended September 28, 2024, a total of 0.3 million shares related to the Silver Lake Convertible Debt (as defined in Note 5, "Debt and Credit Facilities" in this "Part 1 - Financial Information" of this Form 10-Q) were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In addition, the assumed exercise of 0.1 million options were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000034:notes:57]
In the computation of diluted earnings per common share for the three and nine months ended September 30, 2023, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-24-000034:notes:58]
[same as prior period, unchanged from 0000068505-24-000024:notes:57]

[0000068505-24-000034:notes:59]
[same as prior period, unchanged from 0000068505-24-000024:notes:58]

[0000068505-24-000034:notes:60]
[same as prior period, unchanged from 0000068505-24-000024:notes:59]

[0000068505-24-000034:notes:61]
|  | September 28, 2024 |  | December 31, 2023 |
| Accounts receivable | $ | 1,929 |  |  | $ | 1,779 |  |
| Less allowance for credit losses | (81) |  |  | (69) |  |
|  | $ | 1,848 |  |  | $ | 1,710 |  |

[0000068505-24-000034:notes:62]
[same as prior period, unchanged from 0000068505-24-000024:notes:61]

[0000068505-24-000034:notes:63]
[same as prior period, unchanged from 0000068505-24-000024:notes:62]

[0000068505-24-000034:notes:64]
|  | September 28, 2024 |  | December 31, 2023 |
| Finished goods | $ | 366 |  |  | $ | 328 |  |
| Work-in-process and production materials | 586 |  |  | 640 |  |
|  | 952 |  |  | 968 |  |
| Less inventory reserves | (136) |  |  | (141) |  |
|  | $ | 816 |  |  | $ | 827 |  |

[0000068505-24-000034:notes:65]
[same as prior period, unchanged from 0000068505-24-000024:notes:64]

[0000068505-24-000034:notes:66]
[same as prior period, unchanged from 0000068505-24-000024:notes:65]

[0000068505-24-000034:notes:67]
|  | September 28, 2024 |  | December 31, 2023 |
| Current contract cost assets (Note 2) | $ | 78 |  |  | $ | 56 |  |
| Contractor receivables | 29 |  |  | 40 |  |
| Tax-related deposits | 41 |  |  | 32 |  |
| Other | 291 |  |  | 229 |  |
|  | $ | 439 |  |  | $ | 357 |  |

[0000068505-24-000034:notes:68]
[same as prior period, unchanged from 0000068505-24-000024:notes:67]

[0000068505-24-000034:notes:69]
[same as prior period, unchanged from 0000068505-24-000024:notes:68]

[0000068505-24-000034:notes:70]
|  | September 28, 2024 |  | December 31, 2023 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 447 |  |  | 448 |  |
| Machinery and equipment | 2,404 |  |  | 2,396 |  |
|  | 2,856 |  |  | 2,849 |  |
| Less accumulated depreciation | (1,832) |  |  | (1,885) |  |
|  | $ | 1,024 |  |  | $ | 964 |  |

[0000068505-24-000034:notes:71]
[same as prior period, unchanged from 0000068505-24-000024:notes:70]

[0000068505-24-000034:notes:72]
Depreciation expense for the three months ended September 28, 2024 and September 30, 2023 was $46 million and $47 million, respectively. Depreciation expense for the nine months ended September 28, 2024 and September 30, 2023 was $136 million and $134 million, respectively.

[0000068505-24-000034:notes:73]
[same as prior period, unchanged from 0000068505-24-000024:notes:72]

[0000068505-24-000034:notes:74]
[same as prior period, unchanged from 0000068505-24-000024:notes:73]

[0000068505-24-000034:notes:75]
|  | September 28, 2024 |  | December 31, 2023 |  |  |  |  |
| Common stock | $ | 25 |  |  | $ | 28 |  |  |  |  |  |
| Strategic investments | 26 |  |  | 28 |  |  |  |  |  |
| Company-owned life insurance policies | 78 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 11 |  |  | 13 |  |  |  |  |  |
|  | $ | 140 |  |  | $ | 143 |  |  |  |  |  |

[0000068505-24-000034:notes:76]
[same as prior period, unchanged from 0000068505-24-000024:notes:76]

[0000068505-24-000034:notes:77]
[same as prior period, unchanged from 0000068505-24-000024:notes:77]

[0000068505-24-000034:notes:78]
|  | September 28, 2024 |  | December 31, 2023 |
| Defined benefit plan assets | $ | 149 |  |  | $ | 98 |  |
| Non-current contract cost assets (Note 2) | 124 |  |  | 119 |  |
| Other | 61 |  |  | 57 |  |
|  | $ | 334 |  |  | $ | 274 |  |

[0000068505-24-000034:notes:79]
[same as prior period, unchanged from 0000068505-24-000024:notes:79]

[0000068505-24-000034:notes:80]
[same as prior period, unchanged from 0000068505-24-000024:notes:80]

[0000068505-24-000034:notes:81]
The Company's outstanding amounts related to the suppliers participating in this program was $38 million and $35 million as of September 28, 2024 and December 31, 2023, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-24-000034:notes:82]
[same as prior period, unchanged from 0000068505-24-000024:notes:82]

[0000068505-24-000034:notes:83]
[same as prior period, unchanged from 0000068505-24-000024:notes:83]

[0000068505-24-000034:notes:84]
|  | September 28, 2024 |  | December 31, 2023 |
| Compensation | $ | 369 |  |  | $ | 407 |  |
| Tax liabilities | 144 |  |  | 231 |  |
| Dividend payable | 164 |  |  | 163 |  |
| Trade liabilities | 175 |  |  | 140 |  |
| Operating lease liabilities (Note 3) | 131 |  |  | 125 |  |
| Customer reserves | 86 |  |  | 89 |  |
| Other | 460 |  |  | 349 |  |
|  | $ | 1,529 |  |  | $ | 1,504 |  |

[0000068505-24-000034:notes:85]
[same as prior period, unchanged from 0000068505-24-000024:notes:85]

[0000068505-24-000034:notes:86]
[same as prior period, unchanged from 0000068505-24-000024:notes:86]

[0000068505-24-000034:notes:87]
|  | September 28, 2024 |  | December 31, 2023 |
| Defined benefit plans (Note 8) | $ | 855 |  |  | $ | 939 |  |
| Non-current contract liabilities (Note 2) | 480 |  |  | 424 |  |
| Unrecognized tax benefits (Note 7) | 38 |  |  | 26 |  |
| Deferred income taxes (Note 7) | 59 |  |  | 55 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Other | 214 |  |  | 178 |  |
|  | $ | 1,765 |  |  | $ | 1,741 |  |

[0000068505-24-000034:notes:88]
[same as prior period, unchanged from 0000068505-24-000024:notes:88]

[0000068505-24-000034:notes:89]
Share Repurchase Program: During the three and nine months ended September 28, 2024, the Company repurchased approximately 0.1 million and 0.4 million shares at an average price of $440.53 and $355.31 per share for an aggregate amount of $31 million and $141 million, respectively.

[0000068505-24-000034:notes:90]
Payment of Dividends: During the three months ended September 28, 2024 and September 30, 2023, the Company paid $164 million and $147 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $164 million in cash dividends to holders of its common stock. During the nine months ended September 28, 2024 and September 30, 2023, the Company paid $490 million and $443 million, respectively, in cash dividends to holders of its common stock.

[0000068505-24-000034:notes:91]
[same as prior period, unchanged from 0000068505-24-000024:notes:91]

[0000068505-24-000034:notes:92]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended September 28, 2024 and September 30, 2023:

[0000068505-24-000034:notes:93]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (509) |  |  | $ | (476) |  |  | $ | (482) |  |  | $ | (539) |  |
| Other comprehensive income (loss) before reclassification adjustment | 73 |  |  | (62) |  |  | 44 |  |  | (8) |  |
| Tax benefit (expense) | (1) |  |  | (8) |  |  | 1 |  |  | 1 |  |
| Other comprehensive income (loss), net of tax | 72 |  |  | (70) |  |  | 45 |  |  | (7) |  |
| Balance at end of period | $ | (437) |  |  | $ | (546) |  |  | $ | (437) |  |  | $ | (546) |  |
| Derivative instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (8) |  |  | $ | — |  |  | $ | (12) |  |  | $ | — |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | 4 |  |  | — |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | 4 |  |  | — |  |
| Other comprehensive income, net of tax | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |
| Balance at end of period | $ | (8) |  |  | $ | — |  |  | $ | (8) |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,032) |  |  | $ | (1,971) |  |  | $ | (2,046) |  |  | $ | (1,996) |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 9 |  |  | 15 |  |  | 25 |  |  | 45 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | — |  |  | 1 |  |  | 2 |  |  | 3 |  |
| Tax expense | (2) |  |  | (4) |  |  | (6) |  |  | (11) |  |
| Reclassification adjustments into Net earnings, net of tax | 7 |  |  | 12 |  |  | 21 |  |  | 37 |  |
| Other comprehensive income, net of tax | 7 |  |  | 12 |  |  | 21 |  |  | 37 |  |
| Balance at end of period | $ | (2,025) |  |  | $ | (1,959) |  |  | $ | (2,025) |  |  | $ | (1,959) |  |
| Total Accumulated other comprehensive loss | $ | (2,470) |  |  | $ | (2,505) |  |  | $ | (2,470) |  |  | $ | (2,505) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-24-000034:notes:94]
Debt and Credit Facilities

[0000068505-24-000034:notes:95]
|  | September 28, 2024 |  | December 31, 2023 |
| 4.0% senior notes due 2024 | $ | — |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 24 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 895 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 846 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 5,997 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (322) |  |  | (1,313) |  |
| Long-term debt | $ | 5,674 |  |  | $ | 4,705 |  |

[0000068505-24-000034:notes:96]
During the three months ended September 28, 2024, the Company repaid the $313 million aggregate principal amount of the 4.0% senior notes due 2024.

[0000068505-24-000034:notes:97]
As of September 28, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-24-000034:notes:98]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. On February 14, 2024, the Company agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The Company paid the cash consideration during the first quarter of 2024. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Condensed Consolidated Statements of Operations during the nine months ended September 28, 2024.

[0000068505-24-000034:notes:99]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt in the first quarter of 2024.

[0000068505-24-000034:notes:100]
As of September 28, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 28, 2024.

[0000068505-24-000034:notes:101]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 28, 2024 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-24-000034:notes:102]
[same as prior period, unchanged from 0000068505-24-000024:notes:101]

[0000068505-24-000034:notes:103]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.3 billion for each of the periods ended September 28, 2024 and December 31, 2023. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-24-000034:notes:104]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 28, 2024, and the corresponding positions as of December 31, 2023:

[0000068505-24-000034:notes:105]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 28, 2024 |  | December 31, 2023 |
| Euro | $ | 307 |  |  | $ | 322 |  |
| Australian dollar | (240) |  |  | (140) |  |
| British pound | 206 |  |  | 252 |  |
| Canadian dollar | 74 |  |  | 76 |  |
| Chinese renminbi | (68) |  |  | (66) |  |

[0000068505-24-000034:notes:106]
[same as prior period, unchanged from 0000068505-24-000024:notes:105]

[0000068505-24-000034:notes:107]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 28, 2024, all of the counterparties had investment grade credit ratings. As of September 28, 2024, the Company had $9 million of exposure to aggregate credit risk with all counterparties.

[0000068505-24-000034:notes:108]
[same as prior period, unchanged from 0000068505-24-000024:notes:107]

[0000068505-24-000034:notes:109]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of September 28, 2024 and December 31, 2023:

[0000068505-24-000034:notes:110]
|  | Fair Values of Derivative Instruments |
| September 28, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 5 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 9 |  |  | 3 |  |
| Total derivatives | $ | 9 |  |  | $ | 8 |  |

[0000068505-24-000034:notes:111]
[same as prior period, unchanged from 0000068505-24-000024:notes:110]

[0000068505-24-000034:notes:112]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended September 28, 2024 and September 30, 2023:

[0000068505-24-000034:notes:113]
|  | Financial Statement Location | Three Months Ended |  | Nine Months Ended |
| Foreign Exchange Contracts | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | (9) |  |  | $ | 9 |  |  | $ | 3 |  |  | $ | 5 |  |
| Forward points recognized | Other income (expense) | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Treasury rate lock | Accumulated other comprehensive income (loss) | — |  |  | — |  |  | 4 |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | 22 |  |  | $ | (26) |  |  | $ | 7 |  |  | $ | (9) |  |
| Equity swap contracts | Selling, general and administrative expenses | 1 |  |  | (1) |  |  | 3 |  |  | (1) |  |

[0000068505-24-000034:notes:114]
[same as prior period, unchanged from 0000068505-24-000024:notes:113]

[0000068505-24-000034:notes:115]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of September 28, 2024, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in a British pound functional subsidiary.

[0000068505-24-000034:notes:116]
[same as prior period, unchanged from 0000068505-24-000024:notes:115]

[0000068505-24-000034:notes:117]
[same as prior period, unchanged from 0000068505-24-000024:notes:116]

[0000068505-24-000034:notes:118]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of September 28, 2024 was $19 million.

[0000068505-24-000034:notes:119]
[same as prior period, unchanged from 0000068505-24-000024:notes:118]

[0000068505-24-000034:notes:120]
In 2023, the Company entered into treasury rate agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the nine months ended September 28, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated Other Comprehensive Income (AOCI) will be reclassified to interest expense on a straight-line basis over the 10-year term of the 2034 notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-24-000034:notes:121]
[same as prior period, unchanged from 0000068505-24-000024:notes:120]

[0000068505-24-000034:notes:122]
[same as prior period, unchanged from 0000068505-24-000024:notes:121]

[0000068505-24-000034:notes:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net earnings before income taxes | $ | 695 |  |  | $ | 592 |  |  | $ | 1,184 |  |  | $ | 1,438 |  |
| Income tax expense | 132 |  |  | 127 |  |  | 214 |  |  | 321 |  |
| Effective tax rate | 19 | % |  | 21 | % |  | 18 | % |  | 22 | % |

[0000068505-24-000034:notes:124]
The effective tax rate for the three months ended September 28, 2024 of 19% was lower than the U.S. federal statutory tax rate of 21% primarily due to favorable U.S. return-to-provision adjustments, excess tax benefits of share-based compensation, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions, partially offset by state tax expense. The effective tax rate for the nine months ended September 28, 2024 of 18% was lower than the U.S. federal statutory tax rate of 21% primarily due to favorable U.S. return-to-provision adjustments (inclusive of the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return), excess tax benefits of share-based compensation, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions, partially offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in the first quarter of 2024 and state tax expense.

[0000068505-24-000034:notes:125]
The effective tax rate for the three months ended September 30, 2023 of 21% was equal to the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by the excess tax benefits of share-based compensation and favorable U.S. return-to-provision adjustments. The effective tax rate for the nine months ended September 30, 2023 of 22% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, partially offset by the excess tax benefits of share-based compensation and favorable U.S. return-to-provision adjustments.

[0000068505-24-000034:notes:126]
The effective tax rate for the three months ended September 28, 2024 of 19% was lower than the effective tax rate for the three months ended September 30, 2023 of 21%, primarily due to higher excess tax benefits of share-based compensation and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024. The effective tax rate for the nine months ended September 28, 2024 of 18% was lower than the effective tax rate for the nine months ended September 30, 2023 of 22%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions, and higher excess tax benefits of share-based compensation in 2024, offset by the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-24-000034:notes:127]
[same as prior period, unchanged from 0000068505-24-000024:notes:126]

[0000068505-24-000034:notes:128]
[same as prior period, unchanged from 0000068505-24-000024:notes:127]

[0000068505-24-000034:notes:129]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Interest cost | 47 |  |  | 47 |  |  | 14 |  |  | 2 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (75) |  |  | (73) |  |  | (26) |  |  | (16) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 6 |  |  | 5 |  |  | 2 |  |  | 9 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | — |  |  | 1 |  |  | 1 |  |
| Net periodic pension cost (benefits) | $ | (22) |  |  | $ | (21) |  |  | $ | (11) |  |  | $ | (5) |  |  | $ | — |  |  | $ | 1 |  |

[0000068505-24-000034:notes:130]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Interest cost | 141 |  |  | 141 |  |  | 42 |  |  | 6 |  |  | 4 |  |  | 5 |  |
| Expected return on plan assets | (223) |  |  | (219) |  |  | (78) |  |  | (46) |  |  | (9) |  |  | (9) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 17 |  |  | 15 |  |  | 5 |  |  | 27 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (2) |  |  | — |  |  | 4 |  |  | 3 |  |
| Net periodic pension cost (benefits) | $ | (65) |  |  | $ | (63) |  |  | $ | (33) |  |  | $ | (13) |  |  | $ | 2 |  |  | $ | 2 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-24-000034:notes:131]
[same as prior period, unchanged from 0000068505-24-000024:notes:130]

[0000068505-24-000034:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 12 |  |  | $ | 10 |  |  | $ | 36 |  |  | $ | 30 |  |
| Selling, general and administrative expenses | 33 |  |  | 28 |  |  | 97 |  |  | 87 |  |
| Research and development expenditures | 16 |  |  | 14 |  |  | 47 |  |  | 43 |  |
| Share-based compensation expense included in Operating earnings | 61 |  |  | 52 |  |  | 180 |  |  | 160 |  |
| Tax benefit | (13) |  |  | (11) |  |  | (37) |  |  | (33) |  |
| Share-based compensation expense, net of tax | $ | 48 |  |  | $ | 41 |  |  | $ | 143 |  |  | $ | 127 |  |
| Decrease in basic earnings per share | $ | (0.29) |  |  | $ | (0.25) |  |  | $ | (0.86) |  |  | $ | (0.76) |  |
| Decrease in diluted earnings per share | $ | (0.28) |  |  | $ | (0.24) |  |  | $ | (0.84) |  |  | $ | (0.74) |  |

[0000068505-24-000034:notes:133]
During the nine months ended September 28, 2024, the Company granted 0.6 million RSUs, 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $184 million, $25 million and $14 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $8 million and $14 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-24-000034:notes:134]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 28, 2024 and December 31, 2023 were as follows:

[0000068505-24-000034:notes:135]
| September 28, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |
| Common stock | 25 |  |  | — |  |  |  |  | 25 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  |  |  | $ | 8 |  |

[0000068505-24-000034:notes:136]
[same as prior period, unchanged from 0000068505-24-000024:notes:135]

[0000068505-24-000034:notes:137]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of September 28, 2024 or December 31, 2023.

[0000068505-24-000034:notes:138]
At September 28, 2024 and December 31, 2023, the Company had $625 million and $863 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-24-000034:notes:139]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of September 28, 2024 was $6.0 billion. The fair value of long-term debt at December 31, 2023 was $6.4 billion, of which the Silver Lake Convertible Debt was $1.6 billion (Level 2).

[0000068505-24-000034:notes:140]
[same as prior period, unchanged from 0000068505-24-000024:notes:139]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-24-000034:notes:141]
[same as prior period, unchanged from 0000068505-24-000024:notes:140]

[0000068505-24-000034:notes:142]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 28, 2024 and September 30, 2023:

[0000068505-24-000034:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Accounts receivable sales proceeds | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |
| Long-term receivables sales proceeds | 56 |  |  | 65 |  |  | 82 |  |  | 123 |  |

[0000068505-24-000034:notes:144]
At September 28, 2024, the Company had retained servicing obligations for $762 million of long-term receivables, compared to $813 million at December 31, 2023. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $66 million at September 28, 2024, compared to $103 million at December 31, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-24-000034:notes:145]
Commitments and Contingencies
Legal Matters

[0000068505-24-000034:notes:146]
Hytera Litigation

[0000068505-24-000034:notes:147]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-24-000034:notes:148]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through October 2024. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-24-000034:notes:149]
Following the February 14, 2020 verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case has been remanded to the District Court for further action per the Court of Appeals' decision.

[0000068505-24-000034:notes:150]
In 2024, the parties engaged in competing litigation in the District Court and a court in Shenzhen, China (originally filed by Hytera in June 2022 and not served upon the Company until November 2023) related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings on August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is now under consideration by the District Court.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-24-000034:notes:151]
[same as prior period, unchanged from 0000068505-24-000024:notes:150]

[0000068505-24-000034:notes:152]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Products and Systems Integration | $ | 1,784 |  |  | $ | 1,612 |  |  | $ | 4,933 |  |  | $ | 4,352 |  |
| Software and Services | 1,006 |  |  | 944 |  |  | 2,873 |  |  | 2,777 |  |
|  | $ | 2,790 |  |  | $ | 2,556 |  |  | $ | 7,806 |  |  | $ | 7,129 |  |

[0000068505-24-000034:notes:153]
[same as prior period, unchanged from 0000068505-24-000024:notes:152]

[0000068505-24-000034:notes:154]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Products and Systems Integration | $ | 446 |  |  | $ | 364 |  |  | $ | 1,135 |  |  | $ | 752 |  |
| Software and Services | 265 |  |  | 275 |  |  | 739 |  |  | 804 |  |
| Operating earnings | 711 |  |  | 639 |  |  | 1,874 |  |  | 1,556 |  |
| Total other expense | (16) |  |  | (47) |  |  | (690) |  |  | (118) |  |
| Earnings before income taxes | $ | 695 |  |  | $ | 592 |  |  | $ | 1,184 |  |  | $ | 1,438 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-24-000034:notes:155]
[same as prior period, unchanged from 0000068505-24-000024:notes:154]

[0000068505-24-000034:notes:156]
During the three months ended September 28, 2024, the Company recorded net reorganization of business charges of $7 million, consisting of $5 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for employee separation accruals that are no longer needed.

[0000068505-24-000034:notes:157]
During the nine months ended September 28, 2024, the Company recorded net reorganization of business charges of $21 million, including $16 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $21 million were charges of $30 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000034:notes:158]
[same as prior period, unchanged from 0000068505-24-000024:notes:157]

[0000068505-24-000034:notes:159]
| September 28, 2024 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 20 |  |
| Software and Services | 1 |  |  | 1 |  |
|  | $ | 7 |  |  | $ | 21 |  |

[0000068505-24-000034:notes:160]
[same as prior period, unchanged from 0000068505-24-000024:notes:159]

[0000068505-24-000034:notes:161]
|  | January 1, 2024 |  | Additional Charges |  | Adjustments |  | Amount Used |  | September 28, 2024 |
| Employee separation costs | $ | 23 |  |  | $ | 30 |  |  | $ | (5) |  |  | $ | (27) |  |  | $ | 21 |  |
| Exit costs | 5 |  |  | — |  |  | (4) |  |  | — |  |  | 1 |  |
|  | $ | 28 |  |  | $ | 30 |  |  | $ | (9) |  |  | $ | (27) |  |  | $ | 22 |  |

[0000068505-24-000034:notes:162]
[same as prior period, unchanged from 0000068505-24-000024:notes:161]

[0000068505-24-000034:notes:163]
At January 1, 2024, the Company had an accrual of $5 million for exit costs, related to the Company's exit of the Emergency Service Network contract with the UK Home Office. During the nine months ended September 28, 2024, the Company recorded a $4 million reversal for accruals no longer needed. The $1 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at September 28, 2024, and are expected to be paid within one year.

[0000068505-24-000034:notes:164]
[same as prior period, unchanged from 0000068505-24-000024:notes:163]

[0000068505-24-000034:notes:165]
At January 1, 2024, the Company had an accrual of $23 million for employee separation costs. The 2024 additional charges of $30 million represent severance costs for approximately 480 employees. The adjustment of $5 million reflects reversals for accruals no longer needed. The $27 million used reflects cash payments to severed employees. The remaining accrual of $21 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at September 28, 2024, is expected to be paid, primarily within one year, to approximately 540 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-24-000034:notes:166]
[same as prior period, unchanged from 0000068505-24-000024:notes:165]

[0000068505-24-000034:notes:167]
During the three months ended September 30, 2023, the Company recorded net reorganization of business charges of $6 million, including $4 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $6 million were charges of $8 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000034:notes:168]
During the nine months ended September 30, 2023, the Company recorded net reorganization of business charges of $22 million, including $16 million of charges in Other charges and $6 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $22 million were charges of $32 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-24-000034:notes:169]
| September 30, 2023 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 5 |  |  | $ | 22 |  |
| Software and Services | 1 |  |  | — |  |
|  | $ | 6 |  |  | $ | 22 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-24-000034:notes:170]
Intangible Assets and Goodwill
Subsequent to quarter end, on October 29, 2024, the Company acquired 3tc, a provider of control room software solutions for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's critical experience and innovation focused on advancing CAD for the UK's public safety agencies. This business is part of the Software and Services segment. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.

[0000068505-24-000034:notes:171]
On July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which helps enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The Company recognized $46 million of goodwill, $54 million of identifiable intangible assets, and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $7 million of customer relationships and $46 million of developed technology and will be amortized over a period of three, fifteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-24-000034:notes:172]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The Company recognized $62 million of goodwill, $65 million of identifiable intangible assets and $5 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $11 million of trade names, $51 million of customer relationships and $3 million of developed technology and will be amortized over a period of nine, eighteen and six years, respectively. The acquisition expands the Company's video solutions within the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net assets and goodwill may be subject to change.

[0000068505-24-000034:notes:173]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The Company recognized $16 million of goodwill, $23 million of identifiable intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $10 million of customer relationships and $12 million of developed technology and will be amortized over a period of two, fourteen and ten years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts net liabilities and goodwill may be subject to change.

[0000068505-24-000034:notes:174]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. The transaction also includes the potential for the Company to make contingent earn-out payments of up to $15 million based on IPVideo's achievement of certain financial targets from January 1, 2024 through December 31, 2024. As of the acquisition date, the Company estimated the fair value of the contingent earn-out to be $2 million, which was included in the purchase price. However, as of September 28, 2024, the Company no longer estimates that the contingent earn-out targets will be achieved. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The Company recognized $96 million of goodwill, $83 million of identifiable intangible assets and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $8 million of trade names, $6 million of customer relationships and $69 million of developed technology and will be amortized over a period of eight, twelve and fifteen years, respectively. The business is part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-24-000034:notes:175]
[same as prior period, unchanged from 0000068505-24-000024:notes:173]

[0000068505-24-000034:notes:176]
[same as prior period, unchanged from 0000068505-24-000024:notes:174]

[0000068505-24-000034:notes:177]
|  | September 28, 2024 |  | December 31, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,230 |  |  | $ | 515 |  |  | $ | 1,156 |  |  | $ | 447 |  |
| Customer-related | 1,670 |  |  | 1,134 |  |  | 1,566 |  |  | 1,055 |  |
| Other intangibles | 121 |  |  | 77 |  |  | 107 |  |  | 72 |  |
|  | $ | 3,021 |  |  | $ | 1,726 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-24-000034:notes:178]
Amortization expense on intangible assets was $38 million and $114 million for the three and nine months ended September 28, 2024, respectively. Amortization expense on intangible assets was $39 million and $137 million for the three and nine months ended September 30, 2023, respectively. As of September 28, 2024, annual amortization expense is estimated to be $151 million in 2024, $143 million in 2025, $135 million in 2026, $124 million in 2027, $124 million in 2028 and $112 million in 2029.

[0000068505-24-000034:notes:179]
[same as prior period, unchanged from 0000068505-24-000024:notes:177]

[0000068505-24-000034:notes:180]
|  | September 28, 2024 |  | December 31, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 1,019 |  |  | $ | 392 |  |  | $ | 985 |  |  | $ | 337 |  |
| Software and Services | 2,002 |  |  | 1,334 |  |  | 1,844 |  |  | 1,237 |  |
|  | $ | 3,021 |  |  | $ | 1,726 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-24-000034:notes:181]
[same as prior period, unchanged from 0000068505-24-000024:notes:179]

[0000068505-24-000034:notes:182]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2024 to September 28, 2024:

[0000068505-24-000034:notes:183]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2024 | $ | 1,568 |  |  | $ | 1,833 |  |  | $ | 3,401 |  |
| Goodwill acquired | 16 |  |  | 108 |  |  | 124 |  |
| Purchase accounting adjustments | (13) |  |  | — |  |  | (13) |  |
| Foreign currency | (1) |  |  | 12 |  |  | 11 |  |
| Balance as of September 28, 2024 | $ | 1,570 |  |  | $ | 1,953 |  |  | $ | 3,523 |  |
