# MSI notes — 0000068505-23-000045


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-23-000045:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of September 30, 2023 and for the three and nine months ended September 30, 2023 and October 1, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-23-000045:notes:2]
[same as prior period, unchanged from 0000068505-23-000039:notes:2]

[0000068505-23-000045:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three and nine months ended September 30, 2023 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-23-000045:notes:4]
[same as prior period, unchanged from 0000068505-23-000039:notes:4]

[0000068505-23-000045:notes:5]
[same as prior period, unchanged from 0000068505-23-000039:notes:5]

[0000068505-23-000045:notes:6]
[same as prior period, unchanged from 0000068505-23-000039:notes:6]

[0000068505-23-000045:notes:7]
[same as prior period, unchanged from 0000068505-23-000039:notes:7]

[0000068505-23-000045:notes:8]
[same as prior period, unchanged from 0000068505-23-000039:notes:8]

[0000068505-23-000045:notes:9]
[same as prior period, unchanged from 0000068505-23-000039:notes:9]

[0000068505-23-000045:notes:10]
[same as prior period, unchanged from 0000068505-23-000039:notes:10]

[0000068505-23-000045:notes:11]
[same as prior period, unchanged from 0000068505-23-000039:notes:11]

[0000068505-23-000045:notes:12]
[same as prior period, unchanged from 0000068505-23-000039:notes:12]

[0000068505-23-000045:notes:13]
[same as prior period, unchanged from 0000068505-23-000039:notes:13]

[0000068505-23-000045:notes:14]
[same as prior period, unchanged from 0000068505-23-000039:notes:14]

[0000068505-23-000045:notes:15]
[same as prior period, unchanged from 0000068505-23-000039:notes:15]

[0000068505-23-000045:notes:16]
[same as prior period, unchanged from 0000068505-23-000039:notes:16]

[0000068505-23-000045:notes:17]
[same as prior period, unchanged from 0000068505-23-000039:notes:17]

[0000068505-23-000045:notes:18]
Recently Adopted Accounting Pronouncements

[0000068505-23-000045:notes:19]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-23-000045:notes:20]
[same as prior period, unchanged from 0000068505-23-000039:notes:20]

[0000068505-23-000045:notes:21]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 30, 2023 and October 1, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-23-000045:notes:22]
|  | Three Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |  | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |
| International | 457 |  |  | 316 |  |  | 773 |  |  | 363 |  |  | 323 |  |  | 686 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |  | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |
| Video | 300 |  |  | 153 |  |  | 453 |  |  | 286 |  |  | 133 |  |  | 419 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 142 |  |  | 142 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |  | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |
| Indirect | 672 |  |  | 85 |  |  | 757 |  |  | 627 |  |  | 75 |  |  | 702 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |

[0000068505-23-000045:notes:23]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |  | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |
| International | 1,222 |  |  | 991 |  |  | 2,213 |  |  | 957 |  |  | 973 |  |  | 1,930 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |  | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |
| Video | 810 |  |  | 435 |  |  | 1,245 |  |  | 728 |  |  | 368 |  |  | 1,096 |  |
| Command Center | — |  |  | 535 |  |  | 535 |  |  | — |  |  | 435 |  |  | 435 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |  | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |
| Indirect | 1,893 |  |  | 248 |  |  | 2,141 |  |  | 1,647 |  |  | 228 |  |  | 1,875 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |

[0000068505-23-000045:notes:24]
[same as prior period, unchanged from 0000068505-23-000039:notes:24]

[0000068505-23-000045:notes:25]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 30, 2023 was $9.3 billion. A total of $4.9 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 30, 2023, of which $3.1 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.4 billion was from Software and Services performance obligations that were not yet satisfied as of September 30, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-23-000045:notes:26]
[same as prior period, unchanged from 0000068505-23-000039:notes:26]

[0000068505-23-000045:notes:27]
| (In millions) | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,667 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,092 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,898 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 394 |  |  | 363 |  |  |  |  |  |

[0000068505-23-000045:notes:28]
Revenue recognized during the three months ended September 30, 2023 which was previously included in Contract liabilities as of July 1, 2023 was $475 million, compared to $437 million of revenue recognized during the three months ended October 1, 2022 which was previously included in Contract liabilities as of July 2, 2022. Revenue recognized during the nine months ended September 30, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $1.1 billion, compared to $939 million recognized during the nine months ended October 1, 2022 which was previously included in Contract liabilities as of December 31, 2021. The Company did not reverse any revenue during the three months ended September 30, 2023 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $3 million of reversals for the three months ended October 1, 2022, primarily driven by changes in the estimates of progress on system contracts. Revenue of $18 million was reversed during the nine months ended September 30, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $23 million of reversals for the nine months ended October 1, 2022.

[0000068505-23-000045:notes:29]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 30, 2023 and October 1, 2022.

[0000068505-23-000045:notes:30]
[same as prior period, unchanged from 0000068505-23-000039:notes:30]

[0000068505-23-000045:notes:31]
| (In millions) | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 89 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 109 |  |  | 130 |  |  |  |  |  |

[0000068505-23-000045:notes:32]
Amortization of contract cost assets was $10 million and $35 million for the three and nine months ended September 30, 2023, respectively, and $14 million and $41 million for the three and nine months ended October 1, 2022, respectively.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-23-000045:notes:33]
Leases
Components of Lease Expense

[0000068505-23-000045:notes:34]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 35 |  |  | $ | 32 |  |  | $ | 103 |  |  | $ | 98 |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 5 |  |
| Short-term lease cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Variable cost | 10 |  |  | 9 |  |  | 28 |  |  | 26 |  |
| Sublease income | (1) |  |  | (1) |  |  | (3) |  |  | (4) |  |
| Net lease expense | $ | 45 |  |  | $ | 41 |  |  | $ | 131 |  |  | $ | 126 |  |

[0000068505-23-000045:notes:35]
Lease Assets and Liabilities

[0000068505-23-000045:notes:36]
| (in millions) |  | Statement Line Classification |  | September 30, 2023 |  | December 31, 2022 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 453 |  |  | $ | 485 |  |  |  |
| Finance lease assets |  | Property, plant and equipment, net |  | 8 |  |  | 9 |  |  |  |
|  |  |  |  | $ | 461 |  |  | $ | 494 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 118 |  |  | $ | 118 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | — |  |  | 1 |  |  |  |
|  |  |  |  | $ | 118 |  |  | $ | 119 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 368 |  |  | $ | 419 |  |  |  |

[0000068505-23-000045:notes:37]
Other Information Related to Leases

[0000068505-23-000045:notes:38]
|  | Nine Months Ended |  |  |
| (in millions) | September 30, 2023 |  | October 1, 2022 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 103 |  |  | $ | 124 |  |  |  |
| Net cash used for financing activities related to finance leases | 1 |  |  | 4 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 52 |  |  | $ | 77 |  |  |  |

[0000068505-23-000045:notes:39]
Assets obtained in exchange for lease liabilities for the nine months ended September 30, 2023 included $20 million of additional leases due to a renewal of a large managed services contract. Assets obtained in exchange for lease liabilities for the nine months ended October 1, 2022 included $34 million of additional leases acquired in connection with the Company's acquisition of TETRA Ireland.

[0000068505-23-000045:notes:40]
|  | September 30, 2023 |  | December 31, 2022 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 5 |  | 5 |
| Finance leases | 0 |  | 1 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 4.26 | % |  | 4.07 | % |
| Finance leases | — | % |  | 3.23 | % |

[0000068505-23-000045:notes:41]
Future Lease Payments

[0000068505-23-000045:notes:42]
|  | September 30, 2023 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2023 | $ | 29 |  |  |  |  |  |
| 2024 | 135 |  |  |  |  |  |
| 2025 | 119 |  |  |  |  |  |
| 2026 | 102 |  |  |  |  |  |
| 2027 | 56 |  |  |  |  |  |
| Thereafter | 97 |  |  |  |  |  |
| Total lease payments | $ | 538 |  |  |  |  |  |
| Less: Interest | 52 |  |  |  |  |  |
| Present value of lease liabilities | $ | 486 |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-23-000045:notes:43]
[same as prior period, unchanged from 0000068505-23-000039:notes:43]

[0000068505-23-000045:notes:44]
[same as prior period, unchanged from 0000068505-23-000039:notes:44]

[0000068505-23-000045:notes:45]
[same as prior period, unchanged from 0000068505-23-000039:notes:45]

[0000068505-23-000045:notes:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 39 |  |  | $ | 63 |  |  | $ | 137 |  |  | $ | 194 |  |
| Environmental reserve expense | — |  |  | — |  |  | 15 |  |  | — |  |
| Reorganization of business (Note 14) | 4 |  |  | 2 |  |  | 16 |  |  | 14 |  |
| Operating lease asset impairments | — |  |  | 4 |  |  | 4 |  |  | 16 |  |
| Acquisition-related transaction fees | 1 |  |  | 2 |  |  | 3 |  |  | 16 |  |
| Legal settlements | 1 |  |  | 12 |  |  | 1 |  |  | 23 |  |
| Fixed asset impairments | — |  |  | 1 |  |  | 3 |  |  | 12 |  |
| Gain on Hytera legal settlement | — |  |  | — |  |  | — |  |  | (13) |  |
| Other | 1 |  |  | (1) |  |  | 2 |  |  | — |  |
|  | $ | 46 |  |  | $ | 83 |  |  | $ | 181 |  |  | $ | 262 |  |

[0000068505-23-000045:notes:47]
During the nine months ended September 30, 2023, the Company revised the estimate for its liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the "Superfund Act") incurred by a legacy business. It is the Company's policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. During the nine months ended September 30, 2023, the Company became aware of incremental costs required in its remediation of the Superfund site. As such, the Company recorded a charge of $15 million, increasing the reserve balance to $127 million. The Company discounted the cash flows used in estimating this accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is $4 million and is included in the Accrued liabilities statement line and the non-current portion is included in the "Other liabilities" statement line within the Company's Condensed Consolidated Balance Sheets.

[0000068505-23-000045:notes:48]
[same as prior period, unchanged from 0000068505-23-000039:notes:48]

[0000068505-23-000045:notes:49]
[same as prior period, unchanged from 0000068505-23-000039:notes:49]

[0000068505-23-000045:notes:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (60) |  |  | $ | (62) |  |  | $ | (186) |  |  | $ | (179) |  |
| Interest income | 7 |  |  | 2 |  |  | 22 |  |  | 8 |  |
|  | $ | (53) |  |  | $ | (60) |  |  | $ | (164) |  |  | (171) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 24 |  |  | $ | 28 |  |  | $ | 73 |  |  | $ | 91 |  |
| Loss from the extinguishment of long-term debt (Note 5) | — |  |  | — |  |  | — |  |  | (6) |  |
| Investment impairments | (7) |  |  | — |  |  | (16) |  |  | (1) |  |
| Foreign currency gain (loss) | 23 |  |  | 45 |  |  | (16) |  |  | 95 |  |
| Loss on derivative instruments (Note 6) | (26) |  |  | (54) |  |  | (9) |  |  | (111) |  |
| Loss on equity method investments | — |  |  | — |  |  | — |  |  | (2) |  |
| Fair value adjustments to equity investments | (7) |  |  | (5) |  |  | 12 |  |  | (35) |  |
| Gain on TETRA Ireland equity method investment | — |  |  | — |  |  | — |  |  | 21 |  |
| Other | — |  |  | 5 |  |  | 2 |  |  | (2) |  |
|  | $ | 7 |  |  | $ | 19 |  |  | $ | 46 |  |  | $ | 50 |  |

[0000068505-23-000045:notes:51]
[same as prior period, unchanged from 0000068505-23-000039:notes:51]

[0000068505-23-000045:notes:52]
[same as prior period, unchanged from 0000068505-23-000039:notes:52]

[0000068505-23-000045:notes:53]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 464 |  |  | $ | 279 |  |  | $ | 1,113 |  |  | $ | 774 |  |
| Weighted average common shares outstanding | 166.7 |  |  | 167.2 |  |  | 167.2 |  |  | 167.5 |  |
| Per share amount | $ | 2.78 |  |  | $ | 1.67 |  |  | $ | 6.66 |  |  | $ | 4.62 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 464 |  |  | $ | 279 |  |  | $ | 1,113 |  |  | $ | 774 |  |
| Weighted average common shares outstanding | 166.7 |  |  | 167.2 |  |  | 167.2 |  |  | 167.5 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.5 |  |  | 3.6 |  |  | 3.6 |  |  | 3.8 |  |
| 1.75% senior convertible notes | 1.5 |  |  | 0.7 |  |  | 1.4 |  |  | 0.6 |  |
| Diluted weighted average common shares outstanding | 171.7 |  |  | 171.5 |  |  | 172.2 |  |  | 171.9 |  |
| Per share amount | $ | 2.70 |  |  | $ | 1.63 |  |  | $ | 6.46 |  |  | $ | 4.50 |  |

[0000068505-23-000045:notes:54]
In the computation of diluted earnings per common share for the three months ended and nine months ended September 30, 2023, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-23-000045:notes:55]
In the computation of diluted earnings per common share for the three months ended October 1, 2022, the assumed exercise of 0.4 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the nine months ended October 1, 2022, the assumed exercise of 0.2 million options, inclusive of 0.1 million options subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-23-000045:notes:56]
As of September 30, 2023, the Company had $1.0 billion of 1.75% senior convertible notes outstanding, which mature on September 15, 2024 (the "Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9670 per $1,000 principal amount (which is equal to a conversion price of $201.33 per share), adjusted for dividends declared through the date of settlement. The notes became fully convertible as of September 5, 2021, when the average stock price exceeded the contractual conversion price, providing the holders the option to convert all or any portion of their Senior Convertible Notes. In November 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the principal amount of the Senior Convertible Notes to be settled in cash. Because the Company has irrevocably decided to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the quarter ended October 2, 2021. Upon conversion of the Senior Convertible Notes, the Company has the option to settle the conversion spread in cash or shares. The Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended September 30, 2023. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of September 30, 2023 was $398 million.

[0000068505-23-000045:notes:57]
[same as prior period, unchanged from 0000068505-23-000039:notes:58]

[0000068505-23-000045:notes:58]
[same as prior period, unchanged from 0000068505-23-000039:notes:59]

[0000068505-23-000045:notes:59]
[same as prior period, unchanged from 0000068505-23-000039:notes:60]

[0000068505-23-000045:notes:60]
|  | September 30, 2023 |  | December 31, 2022 |
| Accounts receivable | $ | 1,728 |  |  | $ | 1,579 |  |
| Less allowance for credit losses | (61) |  |  | (61) |  |
|  | $ | 1,667 |  |  | $ | 1,518 |  |

[0000068505-23-000045:notes:61]
[same as prior period, unchanged from 0000068505-23-000039:notes:62]

[0000068505-23-000045:notes:62]
[same as prior period, unchanged from 0000068505-23-000039:notes:63]

[0000068505-23-000045:notes:63]
|  | September 30, 2023 |  | December 31, 2022 |
| Finished goods | $ | 337 |  |  | $ | 354 |  |
| Work-in-process and production materials | 763 |  |  | 829 |  |
|  | 1,100 |  |  | 1,183 |  |
| Less inventory reserves | (141) |  |  | (128) |  |
|  | $ | 959 |  |  | $ | 1,055 |  |

[0000068505-23-000045:notes:64]
[same as prior period, unchanged from 0000068505-23-000039:notes:65]

[0000068505-23-000045:notes:65]
[same as prior period, unchanged from 0000068505-23-000039:notes:66]

[0000068505-23-000045:notes:66]
|  | September 30, 2023 |  | December 31, 2022 |
| Current contract cost assets (Note 2) | $ | 89 |  |  | $ | 61 |  |
| Contractor receivables | 38 |  |  | 47 |  |
| Tax-related deposits | 32 |  |  | 33 |  |
| Other | 245 |  |  | 242 |  |
|  | $ | 404 |  |  | $ | 383 |  |

[0000068505-23-000045:notes:67]
[same as prior period, unchanged from 0000068505-23-000039:notes:68]

[0000068505-23-000045:notes:68]
[same as prior period, unchanged from 0000068505-23-000039:notes:69]

[0000068505-23-000045:notes:69]
|  | September 30, 2023 |  | December 31, 2022 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 459 |  |  | 456 |  |
| Machinery and equipment | 2,295 |  |  | 2,303 |  |
|  | 2,759 |  |  | 2,764 |  |
| Less accumulated depreciation | (1,828) |  |  | (1,837) |  |
|  | $ | 931 |  |  | $ | 927 |  |

[0000068505-23-000045:notes:70]
During the three months ended October 1, 2022, the Company recorded a fixed asset impairment loss of $147 million related to assets constructed and used in the deployment of the Emergency Services Network ("ESN") service contract with the Home Office of the United Kingdom (the "Home Office"). The recognized impairment was based on the Company's expectation that, more likely than not, the ESN long-lived asset group will be disposed of significantly before the end of its previously estimated useful life as a result of the Company's early exit from its ESN contract with the Home Office. The impairment loss was recorded in the Software and Services segment within cost of sales in the Condensed Consolidated Statements of Operations.

[0000068505-23-000045:notes:71]
Depreciation expense for the three months ended September 30, 2023 and October 1, 2022 was $47 million and $45 million, respectively. Depreciation expense for the nine months ended September 30, 2023 and October 1, 2022 was $134 million and $137 million, respectively.

[0000068505-23-000045:notes:72]
[same as prior period, unchanged from 0000068505-23-000039:notes:72]

[0000068505-23-000045:notes:73]
[same as prior period, unchanged from 0000068505-23-000039:notes:73]

[0000068505-23-000045:notes:74]
|  | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Common stock | $ | 30 |  |  | $ | 21 |  |  |  |  |  |
| Strategic investments | 28 |  |  | 45 |  |  |  |  |  |
| Company-owned life insurance policies | 71 |  |  | 69 |  |  |  |  |  |
| Equity method investments | 13 |  |  | 12 |  |  |  |  |  |
|  | $ | 142 |  |  | $ | 147 |  |  |  |  |  |

[0000068505-23-000045:notes:75]
During the nine months ended September 30, 2023, the Company recognized a gain of $13 million in Other income (expense) within the Condensed Consolidated Statement of Operations related to an increase in the fair value of its investment in Evolv Technologies, Inc. During the nine months ended September 30, 2023, the Company recorded a $16 million investment impairment charge, representing an other-than-temporary decline in the value of the Company's strategic equity investment portfolio. The investment impairment charge is classified within Other income (expense) within the Condensed Consolidated Statement of Operations.

[0000068505-23-000045:notes:76]
[same as prior period, unchanged from 0000068505-23-000039:notes:76]

[0000068505-23-000045:notes:77]
[same as prior period, unchanged from 0000068505-23-000039:notes:77]

[0000068505-23-000045:notes:78]
|  | September 30, 2023 |  | December 31, 2022 |
| Defined benefit plan assets | $ | 168 |  |  | $ | 164 |  |
| Non-current contract cost assets (Note 2) | 109 |  |  | 130 |  |
| Other | 59 |  |  | 16 |  |
|  | $ | 336 |  |  | $ | 310 |  |

[0000068505-23-000045:notes:79]
[same as prior period, unchanged from 0000068505-23-000039:notes:79]

[0000068505-23-000045:notes:80]
[same as prior period, unchanged from 0000068505-23-000039:notes:80]

[0000068505-23-000045:notes:81]
The Company's outstanding amounts related to the suppliers participating in this program was $31 million and $37 million as of September 30, 2023 and December 31, 2022, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-23-000045:notes:82]
[same as prior period, unchanged from 0000068505-23-000039:notes:82]

[0000068505-23-000045:notes:83]
[same as prior period, unchanged from 0000068505-23-000039:notes:83]

[0000068505-23-000045:notes:84]
|  | September 30, 2023 |  | December 31, 2022 |
| Compensation | $ | 299 |  |  | $ | 374 |  |
| Tax liabilities | 208 |  |  | 367 |  |
| Dividend payable | 146 |  |  | 148 |  |
| Trade liabilities | 137 |  |  | 145 |  |
| Operating lease liabilities (Note 3) | 118 |  |  | 118 |  |
| Customer reserves | 83 |  |  | 78 |  |
| Other | 364 |  |  | 408 |  |
|  | $ | 1,355 |  |  | $ | 1,638 |  |

[0000068505-23-000045:notes:85]
[same as prior period, unchanged from 0000068505-23-000039:notes:85]

[0000068505-23-000045:notes:86]
[same as prior period, unchanged from 0000068505-23-000039:notes:86]

[0000068505-23-000045:notes:87]
|  | September 30, 2023 |  | December 31, 2022 |
| Defined benefit plans | $ | 915 |  |  | $ | 1,004 |  |
| Non-current contract liabilities (Note 2) | 394 |  |  | 363 |  |
| Unrecognized tax benefits (Note 7) | 29 |  |  | 29 |  |
| Deferred income taxes (Note 7) | 72 |  |  | 73 |  |
| Environmental reserve | 123 |  |  | 108 |  |
| Other | 167 |  |  | 114 |  |
|  | $ | 1,700 |  |  | $ | 1,691 |  |

[0000068505-23-000045:notes:88]
[same as prior period, unchanged from 0000068505-23-000039:notes:88]

[0000068505-23-000045:notes:89]
Share Repurchase Program: During the three and nine months ended September 30, 2023, the Company repurchased approximately 1.1 million and 2.5 million shares at an average price of $281.79 and $277.96 per share for an aggregate amount of $322 million and $686 million, respectively, excluding transaction costs and excise tax. The Company paid $306 million and $670 million to settle share repurchases during the three and nine months ended September 30, 2023, respectively. As of January 1, 2023, the Company's share repurchases in excess of issuances are subject to a 1% excise tax enacted by the Inflation Reduction Act of 2022, which was $3 million as of September 30, 2023.

[0000068505-23-000045:notes:90]
Payment of Dividends: During the three months ended September 30, 2023 and October 1, 2022, the Company paid $147 million and $132 million, respectively, in cash dividends to holders of its common stock. During the nine months ended September 30, 2023 and October 1, 2022, the Company paid $443 million and $398 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $146 million in cash dividends to holders of its common stock.

[0000068505-23-000045:notes:91]
[same as prior period, unchanged from 0000068505-23-000039:notes:91]

[0000068505-23-000045:notes:92]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended September 30, 2023 and October 1, 2022:

[0000068505-23-000045:notes:93]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (476) |  |  | $ | (539) |  |  | $ | (539) |  |  | $ | (384) |  |
| Other comprehensive income (loss) before reclassification adjustment | (62) |  |  | (153) |  |  | (8) |  |  | (304) |  |
| Tax benefit (expense) | (8) |  |  | (9) |  |  | 1 |  |  | (13) |  |
| Other comprehensive income (loss), net of tax | (70) |  |  | (162) |  |  | (7) |  |  | (317) |  |
| Balance at end of period | $ | (546) |  |  | $ | (701) |  |  | $ | (546) |  |  | $ | (701) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,971) |  |  | $ | (1,952) |  |  | $ | (1,996) |  |  | $ | (1,995) |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | — |  |  | 17 |  |
| Tax expense | — |  |  | — |  |  | — |  |  | (3) |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | — |  |  | 14 |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 15 |  |  | 20 |  |  | 45 |  |  | 60 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | 1 |  |  | (1) |  |  | 3 |  |  | (3) |  |
| Tax expense | (4) |  |  | (4) |  |  | (11) |  |  | (13) |  |
| Reclassification adjustments into Net earnings, net of tax | 12 |  |  | 15 |  |  | 37 |  |  | 44 |  |
| Other comprehensive income, net of tax | 12 |  |  | 15 |  |  | 37 |  |  | 58 |  |
| Balance at end of period | $ | (1,959) |  |  | $ | (1,937) |  |  | $ | (1,959) |  |  | $ | (1,937) |  |
| Total Accumulated other comprehensive loss | $ | (2,505) |  |  | $ | (2,638) |  |  | $ | (2,505) |  |  | $ | (2,638) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-23-000045:notes:94]
Debt and Credit Facilities
As of September 30, 2023, $1.0 billion of Senior Convertible Notes and $313 million of 4.0% senior notes, which both mature in September 2024, were reclassified from Long-term debt to the Current portion of long-term debt statement line within the Company's Condensed Consolidated Balance Sheets, as the notes are due within the next twelve months.

[0000068505-23-000045:notes:95]
As of September 30, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 30, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

[0000068505-23-000045:notes:96]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 30, 2023 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-23-000045:notes:97]
[same as prior period, unchanged from 0000068505-23-000039:notes:96]

[0000068505-23-000045:notes:98]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.3 billion and $1.1 billion for periods ended September 30, 2023 and December 31, 2022, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-23-000045:notes:99]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 30, 2023, and the corresponding positions as of December 31, 2022:

[0000068505-23-000045:notes:100]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 30, 2023 |  | December 31, 2022 |
| British pound | $ | 262 |  |  | $ | 290 |  |
| Euro | 250 |  |  | 185 |  |
| Australian dollar | (124) |  |  | (130) |  |
| Canadian dollar | 75 |  |  | — |  |
| Chinese renminbi | (68) |  |  | (61) |  |

[0000068505-23-000045:notes:101]
[same as prior period, unchanged from 0000068505-23-000039:notes:100]

[0000068505-23-000045:notes:102]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 30, 2023, all of the counterparties had investment grade credit ratings. As of September 30, 2023, the Company had $10 million of exposure to aggregate credit risk with all counterparties.

[0000068505-23-000045:notes:103]
Derivative Financial Instruments

[0000068505-23-000045:notes:104]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of September 30, 2023 and December 31, 2022:

[0000068505-23-000045:notes:105]
|  | Fair Values of Derivative Instruments |
| September 30, 2023 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 9 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 1 |  |  | 19 |  |
| Equity swap contracts | — |  |  | 1 |  |
| Total derivatives | $ | 10 |  |  | $ | 20 |  |

[0000068505-23-000045:notes:106]
[same as prior period, unchanged from 0000068505-23-000039:notes:104]

[0000068505-23-000045:notes:107]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended September 30, 2023 and October 1, 2022:

[0000068505-23-000045:notes:108]
|  | Financial Statement Location | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive gain (loss) | $ | 9 |  |  | $ | 12 |  |  | $ | 5 |  |  | $ | 24 |  |
| Forward points recognized | Other income (expense) | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | (26) |  |  | (54) |  |  | (9) |  |  | (111) |  |
| Equity swap contracts | Selling, general and administrative expenses | (1) |  |  | — |  |  | (1) |  |  | — |  |

[0000068505-23-000045:notes:109]
[same as prior period, unchanged from 0000068505-23-000039:notes:107]

[0000068505-23-000045:notes:110]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of September 30, 2023, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £70 million of net investment hedges in a British pound functional subsidiary.

[0000068505-23-000045:notes:111]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the forward points recognized will be amortized on a straight line basis and recognized through interest expense within Other income (expense) in the Condensed Consolidated Statement of Operations.

[0000068505-23-000045:notes:112]
Equity Swap Contracts

[0000068505-23-000045:notes:113]
During the three months ended September 30, 2023, the Company entered into equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of September 30, 2023 was $15 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-23-000045:notes:114]
[same as prior period, unchanged from 0000068505-23-000039:notes:110]

[0000068505-23-000045:notes:115]
[same as prior period, unchanged from 0000068505-23-000039:notes:111]

[0000068505-23-000045:notes:116]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Net earnings before income taxes | $ | 592 |  |  | $ | 333 |  |  | $ | 1,438 |  |  | $ | 852 |  |
| Income tax expense | 127 |  |  | 53 |  |  | 321 |  |  | 75 |  |
| Effective tax rate | 21 | % |  | 16 | % |  | 22 | % |  | 9 | % |

[0000068505-23-000045:notes:117]
The effective tax rate for the three months ended September 30, 2023 of 21% was equal to the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by the excess tax benefits of share-based compensation and favorable US return-to-provision adjustments. The effective tax rate for the nine months ended September 30, 2023 of 22% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, partially offset by the excess tax benefits of share-based compensation and favorable US return-to-provision adjustments.

[0000068505-23-000045:notes:118]
The effective tax rate for the three months ended October 1, 2022 of 16% was lower than the U.S. federal statutory tax rate of 21% primarily due to the excess tax benefits of share-based compensation. The effective tax rate for the nine months ended October 1, 2022 of 9% was lower than the U.S. federal statutory tax rate of 21% primarily due to a net deferred tax benefit of

[0000068505-23-000045:notes:119]
$77 million as a result of an intra-group transfer of certain intellectual property ("IP") rights and the excess tax benefits of share-based compensation.

[0000068505-23-000045:notes:120]
The effective tax rate for the three months ended September 30, 2023 of 21% was higher than the effective tax rate for the three months ended October 1, 2022 of 16%, primarily due to lower excess tax benefits of share-based compensation in 2023, partially offset by more favorable US return-to-provision adjustments in 2023. The effective tax rate for the nine months ended September 30, 2023 of 22% was higher than the effective tax rate for the nine months ended October 1, 2022 of 9%, primarily due to a net deferred tax benefit in 2022 as a result of an intra-group transfer of certain IP rights, lower excess tax benefits of share-based compensation in 2023 and a lower foreign derived intangible income deduction in 2023, partially offset by more favorable US return-to-provision adjustments in 2023.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-23-000045:notes:121]
[same as prior period, unchanged from 0000068505-23-000039:notes:116]

[0000068505-23-000045:notes:122]
[same as prior period, unchanged from 0000068505-23-000039:notes:117]

[0000068505-23-000045:notes:123]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 47 |  |  | 32 |  |  | 2 |  |  | 8 |  |  | 2 |  |  | — |  |
| Expected return on plan assets | (73) |  |  | (64) |  |  | (16) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 5 |  |  | 15 |  |  | 9 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | — |  |  | (1) |  |  | 1 |  |  | — |  |
| Net periodic pension cost (benefits) | $ | (21) |  |  | $ | (17) |  |  | $ | (5) |  |  | $ | (14) |  |  | $ | 1 |  |  | $ | (2) |  |

[0000068505-23-000045:notes:124]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 141 |  |  | 96 |  |  | 6 |  |  | 24 |  |  | 5 |  |  | 1 |  |
| Expected return on plan assets | (219) |  |  | (191) |  |  | (46) |  |  | (77) |  |  | (9) |  |  | (9) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 15 |  |  | 46 |  |  | 27 |  |  | 11 |  |  | 3 |  |  | 3 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | — |  |  | (3) |  |  | 3 |  |  | — |  |
| Net periodic pension cost (benefits) | $ | (63) |  |  | $ | (49) |  |  | $ | (13) |  |  | $ | (42) |  |  | $ | 2 |  |  | $ | (5) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-23-000045:notes:125]
[same as prior period, unchanged from 0000068505-23-000039:notes:120]

[0000068505-23-000045:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 10 |  |  | $ | 7 |  |  | $ | 30 |  |  | $ | 20 |  |
| Selling, general and administrative expenses | 28 |  |  | 26 |  |  | 87 |  |  | 72 |  |
| Research and development expenditures | 14 |  |  | 12 |  |  | 43 |  |  | 34 |  |
| Share-based compensation expense included in Operating earnings | 52 |  |  | 45 |  |  | 160 |  |  | 126 |  |
| Tax benefit | (11) |  |  | (9) |  |  | (33) |  |  | (26) |  |
| Share-based compensation expense, net of tax | $ | 41 |  |  | $ | 36 |  |  | $ | 127 |  |  | $ | 100 |  |
| Decrease in basic earnings per share | $ | (0.25) |  |  | $ | (0.22) |  |  | $ | (0.76) |  |  | $ | (0.60) |  |
| Decrease in diluted earnings per share | $ | (0.24) |  |  | $ | (0.21) |  |  | $ | (0.74) |  |  | $ | (0.58) |  |

[0000068505-23-000045:notes:127]
During the nine months ended September 30, 2023, the Company granted 0.7 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $172 million, $24 million and $13 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $7 million and $13 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-23-000045:notes:128]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 30, 2023 and December 31, 2022 were as follows:

[0000068505-23-000045:notes:129]
| September 30, 2023 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  |  |  | $ | 10 |  |
| Common stock | 30 |  |  | — |  |  |  |  | 30 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | — |  |  | 19 |  |  |  |  | 19 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |

[0000068505-23-000045:notes:130]
[same as prior period, unchanged from 0000068505-23-000039:notes:125]

[0000068505-23-000045:notes:131]
The Company had no foreign exchange derivative contracts or common stock investments in Level 3 holdings as of September 30, 2023 or December 31, 2022.

[0000068505-23-000045:notes:132]
At September 30, 2023 and December 31, 2022, the Company had $510 million and $490 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-23-000045:notes:133]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of September 30, 2023 was $5.9 billion, of which the Senior Convertible Notes were $1.4 billion (Level 2). The fair value of long-term debt at December 31, 2022 was $5.9 billion, of which the Senior Convertible Notes were $1.3 billion (Level 2).

[0000068505-23-000045:notes:134]
[same as prior period, unchanged from 0000068505-23-000039:notes:129]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-23-000045:notes:135]
[same as prior period, unchanged from 0000068505-23-000039:notes:130]

[0000068505-23-000045:notes:136]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 30, 2023 and October 1, 2022:

[0000068505-23-000045:notes:137]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Contract-specific discounting facility | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 49 |  |
| Accounts receivable sales proceeds | — |  |  | — |  |  | — |  |  | 62 |  |
| Long-term receivables sales proceeds | 65 |  |  | 42 |  |  | 123 |  |  | 64 |  |
| Total proceeds from receivable sales | $ | 65 |  |  | $ | 42 |  |  | $ | 123 |  |  | $ | 175 |  |

[0000068505-23-000045:notes:138]
At September 30, 2023, the Company had retained servicing obligations for $844 million of long-term receivables, compared to $891 million at December 31, 2022. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $97 million at September 30, 2023, compared to $65 million at December 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-23-000045:notes:139]
Commitments and Contingencies
Legal Matters

[0000068505-23-000045:notes:140]
Hytera Litigation

[0000068505-23-000045:notes:141]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-23-000045:notes:142]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through October 2023. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

[0000068505-23-000045:notes:143]
On August 2, 2022, Hytera appealed the Court's July 5, 2022 judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the Company's cross-appeal. The Court of Appeals set an oral argument date of December 5, 2023.

[0000068505-23-000045:notes:144]
Hytera Bankruptcy Proceedings

[0000068505-23-000045:notes:145]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and the distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. The gains for the two monetary distributions were recorded to Other charges (income) in the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-23-000045:notes:146]
[same as prior period, unchanged from 0000068505-23-000039:notes:141]

[0000068505-23-000045:notes:147]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Products and Systems Integration | $ | 1,612 |  |  | $ | 1,529 |  |  | $ | 4,352 |  |  | $ | 3,918 |  |
| Software and Services | 944 |  |  | 844 |  |  | 2,777 |  |  | 2,487 |  |
|  | $ | 2,556 |  |  | $ | 2,373 |  |  | $ | 7,129 |  |  | $ | 6,405 |  |

[0000068505-23-000045:notes:148]
[same as prior period, unchanged from 0000068505-23-000039:notes:143]

[0000068505-23-000045:notes:149]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Products and Systems Integration | $ | 364 |  |  | $ | 303 |  |  | $ | 752 |  |  | $ | 460 |  |
| Software and Services | 275 |  |  | 70 |  |  | 804 |  |  | 510 |  |
| Operating earnings | 639 |  |  | 373 |  |  | 1,556 |  |  | 970 |  |
| Total other expense | (47) |  |  | (40) |  |  | (118) |  |  | (118) |  |
| Earnings before income taxes | $ | 592 |  |  | $ | 333 |  |  | $ | 1,438 |  |  | $ | 852 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-23-000045:notes:150]
[same as prior period, unchanged from 0000068505-23-000039:notes:145]

[0000068505-23-000045:notes:151]
During the three months ended September 30, 2023, the Company recorded net reorganization of business charges of $6 million, including $4 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $6 million were charges of $8 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000045:notes:152]
During the nine months ended September 30, 2023, the Company recorded net reorganization of business charges of $22 million, including $16 million of charges in Other charges and $6 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $22 million were charges of $32 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000045:notes:153]
[same as prior period, unchanged from 0000068505-23-000039:notes:148]

[0000068505-23-000045:notes:154]
| September 30, 2023 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 5 |  |  | $ | 22 |  |
| Software and Services | 1 |  |  | — |  |
|  | $ | 6 |  |  | $ | 22 |  |

[0000068505-23-000045:notes:155]
[same as prior period, unchanged from 0000068505-23-000039:notes:150]

[0000068505-23-000045:notes:156]
|  | January 1, 2023 |  | Additional Charges |  | Adjustments |  | Amount Used |  | September 30, 2023 |
| Employee separation costs | $ | 26 |  |  | $ | 32 |  |  | $ | (5) |  |  | $ | (28) |  |  | $ | 25 |  |
| Exit costs | 10 |  |  | — |  |  | (5) |  |  | — |  |  | 5 |  |
|  | $ | 36 |  |  | $ | 32 |  |  | $ | (10) |  |  | $ | (28) |  |  | $ | 30 |  |

[0000068505-23-000045:notes:157]
[same as prior period, unchanged from 0000068505-23-000039:notes:152]

[0000068505-23-000045:notes:158]
At January 1, 2023, the Company had an accrual of $10 million for exit costs, related to the Company's exit of the ESN contract with the Home Office in 2022. During the three months ended September 30, 2023, the Company recorded a $5 million reversal for accruals no longer needed. The remaining $5 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at September 30, 2023, and are expected to be paid within one year.

[0000068505-23-000045:notes:159]
[same as prior period, unchanged from 0000068505-23-000039:notes:154]

[0000068505-23-000045:notes:160]
At January 1, 2023, the Company had an accrual of $26 million for employee separation costs. The 2023 additional charges of $32 million represent severance costs for approximately 560 employees. The adjustment of $5 million reflects reversals for accruals no longer needed. The $28 million used reflects cash payments to severed employees. The remaining accrual of $25 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at September 30, 2023, is expected to be paid, primarily within one year, to approximately 530 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-23-000045:notes:161]
[same as prior period, unchanged from 0000068505-23-000039:notes:156]

[0000068505-23-000045:notes:162]
During the three months ended October 1, 2022, the Company recorded net reorganization of business charges of $14 million, including $2 million of charges in Other charges and $12 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $7 million related to employee separation costs and $10 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-23-000045:notes:163]
During the nine months ended October 1, 2022, the Company recorded net reorganization of business charges of $31 million, including $14 million of charges in Other charges and $17 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $31 million were charges of $30 million related to employee separation costs and $10 million related to exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-23-000045:notes:164]
| October 1, 2022 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 3 |  |  | $ | 17 |  |
| Software and Services | 11 |  |  | 14 |  |
|  | $ | 14 |  |  | $ | 31 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-23-000045:notes:165]
Intangible Assets and Goodwill
On December 14, 2022, the Company acquired Rave Mobile, a leader in mass notification and incident management, for $553 million net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The Company recognized $399 million of goodwill, $212 million of identifiable intangible assets and $58 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of trade names, $82 million of developed technology and $121 million of customer relationships and will be amortized over a period of nine years, seventeen years and seventeen years, respectively. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-23-000045:notes:166]
On October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's radio network and device portfolios. The Company recognized $10 million of goodwill, $11 million of identifiable intangible assets and $9 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of six years. The business is a part of the Products and Systems Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-23-000045:notes:167]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company     to use high frequency and very high frequency radio communications to support mission-critical operations. The Company recognized $1 million of goodwill, $3 million of identifiable intangible assets and $14 million of net assets. The identifiable intangible assets were classified as $1 million of trade names and $2 million of developed technology, both of which will be amortized over a period of seven years.The goodwill is not deductible for tax purposes. The business is part of the Products and Systems Integration segment. The purchase accounting was completed as of the third quarter of 2023.

[0000068505-23-000045:notes:168]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $9 million of goodwill, $6 million of identifiable intangible assets and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting was completed as of the second quarter of 2023.

[0000068505-23-000045:notes:169]
[same as prior period, unchanged from 0000068505-23-000039:notes:164]

[0000068505-23-000045:notes:170]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. As a result of the acquisition, the Company recognized a $21 million gain recorded within Other income (expense) on the Company's initial minority interest. The Company recognized $47 million of goodwill, $90 million of identifiable intangible assets and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $83 million of customer relationships and $7 million of trade names that will be amortized over a period of twelve years and fourteen years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2023.

[0000068505-23-000045:notes:171]
[same as prior period, unchanged from 0000068505-23-000039:notes:166]

[0000068505-23-000045:notes:172]
[same as prior period, unchanged from 0000068505-23-000039:notes:167]

[0000068505-23-000045:notes:173]
[same as prior period, unchanged from 0000068505-23-000039:notes:168]

[0000068505-23-000045:notes:174]
|  | September 30, 2023 |  | December 31, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,095 |  |  | $ | 423 |  |  | $ | 1,083 |  |  | $ | 358 |  |
| Customer-related | 1,517 |  |  | 1,001 |  |  | 1,519 |  |  | 935 |  |
| Other intangibles | 98 |  |  | 69 |  |  | 99 |  |  | 66 |  |
|  | $ | 2,710 |  |  | $ | 1,493 |  |  | $ | 2,701 |  |  | $ | 1,359 |  |

[0000068505-23-000045:notes:175]
Amortization expense on intangible assets was $39 million and $137 million for the three and nine months ended September 30, 2023, respectively. Amortization expense on intangible assets was $63 million and $194 million for the three and nine months ended October 1, 2022, respectively. As of September 30, 2023, annual amortization expense is estimated to be $176 million in 2023, $138 million in 2024, $125 million in 2025, $117 million in 2026, $107 million in 2027 and $106 million in 2028.

[0000068505-23-000045:notes:176]
[same as prior period, unchanged from 0000068505-23-000039:notes:171]

[0000068505-23-000045:notes:177]
|  | September 30, 2023 |  | December 31, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 912 |  |  | $ | 319 |  |  | $ | 913 |  |  | $ | 261 |  |
| Software and Services | 1,798 |  |  | 1,174 |  |  | 1,788 |  |  | 1,098 |  |
|  | $ | 2,710 |  |  | $ | 1,493 |  |  | $ | 2,701 |  |  | $ | 1,359 |  |

[0000068505-23-000045:notes:178]
[same as prior period, unchanged from 0000068505-23-000039:notes:173]

[0000068505-23-000045:notes:179]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2023 to September 30, 2023:

[0000068505-23-000045:notes:180]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2023 | $ | 1,461 |  |  | $ | 1,851 |  |  | $ | 3,312 |  |
| Purchase accounting adjustments | (2) |  |  | (30) |  |  | (32) |  |
| Foreign currency | — |  |  | (2) |  |  | (2) |  |
| Balance as of September 30, 2023 | $ | 1,459 |  |  | $ | 1,819 |  |  | $ | 3,278 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000068505-23-000045:notes:181]
During the three months ended September 30, 2023, the following director or officer of the Company adopted or terminated a "Rule 10b5-1 trading arrangement" or "non-Rule 10b5-1 trading arrangement," as each term is defined in Item 408(a) of Regulation S-K.

[0000068505-23-000045:notes:182]
| Name & Title | Date of Adoption / Termination | Character of Trading Arrangement(1) | Aggregate Number of Shares of Common Stock to be Purchased / Sold Pursuant to Trading Arrangement | Duration of Plan(3) |
| John P. "Jack" Molloy, Executive Vice President and Chief Operating Officer | Adopted September 13, 2023 | Rule 10b5-1(c) Trading Arrangement | Up to 76,819 shares to be sold(2) | December 13, 2023 - June 11, 2024 |

[0000068505-23-000045:notes:183]
(1)Each trading arrangement marked as a "Rule 10b5-1(c) Trading Arrangement" is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c), as amended (the "Rule").

[0000068505-23-000045:notes:184]
(2)Mr. Molloy's Rule 10b5-1(c) Trading Arrangement provides for the potential exercise of vested performance options and the associated sale of up to 76,819 shares of the Company's common stock.

[0000068505-23-000045:notes:185]
(3)Each trading arrangement marked as a "Rule 10b5-1(c) Trading Arrangement" only permits transactions beginning on the indicated start date and, in any case, upon expiration of the applicable mandatory cooling-off period under the Rule, and until the earlier of the indicated duration end date or completion of all sales contemplated in the Rule 10b5-1(c) Trading Arrangement.
