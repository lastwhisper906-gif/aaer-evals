# MSI MD&A — 0000068505-23-000045


## mdna

[0000068505-23-000045:mdna:1]
[same as prior period, unchanged from 0000068505-23-000039:mdna:1]

[0000068505-23-000045:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 30, 2023 and October 1, 2022, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2022 (the "Form 10-K").

[0000068505-23-000045:mdna:3]
[same as prior period, unchanged from 0000068505-23-000039:mdna:3]

[0000068505-23-000045:mdna:4]
[same as prior period, unchanged from 0000068505-23-000039:mdna:4]

[0000068505-23-000045:mdna:5]
[same as prior period, unchanged from 0000068505-23-000039:mdna:5]

[0000068505-23-000045:mdna:6]
[same as prior period, unchanged from 0000068505-23-000039:mdna:6]

[0000068505-23-000045:mdna:7]
[same as prior period, unchanged from 0000068505-23-000039:mdna:7]

[0000068505-23-000045:mdna:8]
[same as prior period, unchanged from 0000068505-23-000039:mdna:8]

[0000068505-23-000045:mdna:9]
[same as prior period, unchanged from 0000068505-23-000039:mdna:9]

[0000068505-23-000045:mdna:10]
Third Quarter Financial Results

[0000068505-23-000045:mdna:11]
•Net sales were $2.6 billion in the third quarter of 2023 compared to $2.4 billion in the third quarter of 2022.

[0000068505-23-000045:mdna:12]
•Operating earnings were $639 million in the third quarter of 2023 compared to $373 million in the third quarter of 2022.

[0000068505-23-000045:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. were $464 million, or $2.70 per diluted common share, in the third quarter of 2023, compared to $279 million, or $1.63 per diluted common share, in the third quarter of 2022.

[0000068505-23-000045:mdna:14]
•Operating cash flow increased $249 million to $799 million in the first nine months of 2023 compared to $550 million in the first nine months of 2022.

[0000068505-23-000045:mdna:15]
•We repurchased $686 million of common stock and paid $443 million in dividends in the first nine months of 2023.

[0000068505-23-000045:mdna:16]
[same as prior period, unchanged from 0000068505-23-000039:mdna:17]

[0000068505-23-000045:mdna:17]
Since the beginning of the COVID-19 pandemic, we have navigated disruptions in our supply chain, in particular, challenges in procuring certain semiconductor components along with diminished transportation capacity and higher freight costs. During the first nine months of 2023, we have experienced gradual improvement in the market conditions influenced by the effects of the COVID-19 pandemic and the inflationary cost environment, particularly with respect to availability of materials in the semiconductor market. Where appropriate, we have taken pricing actions around our product and service offerings to mitigate our exposure to inflationary pressures and have benefited from these adjustments during the first nine months of 2023. We expect to continue to benefit from such adjustments in the last quarter of 2023. We continue to remain focused on improving our supplier network, engineering alternative designs and working to reduce supply shortages and effectively manage costs. In addition, we continue to actively manage our inventory in an effort to enable continuity of supply and services to our customers, which includes diversifying the footprint of our supply chain operations. We expect to maintain elevated levels of inventory until supply conditions stabilize.

[0000068505-23-000045:mdna:18]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of September 30, 2023. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-23-000045:mdna:19]
[same as prior period, unchanged from 0000068505-23-000039:mdna:21]

[0000068505-23-000045:mdna:20]
[same as prior period, unchanged from 0000068505-23-000039:mdna:22]

[0000068505-23-000045:mdna:21]
[same as prior period, unchanged from 0000068505-23-000039:mdna:23]

[0000068505-23-000045:mdna:22]
[same as prior period, unchanged from 0000068505-23-000039:mdna:24]

[0000068505-23-000045:mdna:23]
Based on the adoption of the remedies order, since August 1, 2023, revenue under the Airwave contract has been deferred and recognized in accordance with the prospective price control, which will continue until a successful appeal. We estimate a year-over-year reduction in Airwave revenue of approximately $80 million in 2023, driven by the deferral of revenue, offset by incremental ongoing services and favorable foreign exchange rates. Meanwhile, our backlog continues to remain at original contract terms until new pricing is final. We have tested our Airwave asset group for impairment, noting the assets are expected to be recoverable.

[0000068505-23-000045:mdna:24]
[same as prior period, unchanged from 0000068505-23-000039:mdna:26]

[0000068505-23-000045:mdna:25]
[same as prior period, unchanged from 0000068505-23-000039:mdna:27]

[0000068505-23-000045:mdna:26]
30

[0000068505-23-000045:mdna:27]
[same as prior period, unchanged from 0000068505-23-000039:mdna:29]

[0000068505-23-000045:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 30, 2023 |  | % ofSales* |  | October 1, 2022 |  | % ofSales* |  | September 30, 2023 |  | % ofSales* |  | October 1, 2022 |  | % ofSales* |
| Net sales from products | $ | 1,490 |  |  |  |  | $ | 1,439 |  |  |  |  | $ | 4,063 |  |  |  |  | $ | 3,697 |  |  |  |
| Net sales from services | 1,066 |  |  |  |  | 934 |  |  |  |  | 3,066 |  |  |  |  | 2,708 |  |  |  |
| Net sales | 2,556 |  |  |  |  | 2,373 |  |  |  |  | 7,129 |  |  |  |  | 6,405 |  |  |  |
| Costs of products sales | 658 |  |  | 44.2 | % |  | 659 |  |  | 45.8 | % |  | 1,867 |  |  | 46.0 | % |  | 1,844 |  |  | 49.9 | % |
| Costs of services sales | 618 |  |  | 58.0 | % |  | 683 |  |  | 73.1 | % |  | 1,747 |  |  | 57.0 | % |  | 1,683 |  |  | 62.1 | % |
| Costs of sales | 1,276 |  |  |  |  | 1,342 |  |  |  |  | 3,614 |  |  |  |  | 3,527 |  |  |  |
| Gross margin | 1,280 |  |  | 50.1 | % |  | 1,031 |  |  | 43.4 | % |  | 3,515 |  |  | 49.3 | % |  | 2,878 |  |  | 44.9 | % |
| Selling, general and administrative expenses | 380 |  |  | 14.9 | % |  | 378 |  |  | 15.9 | % |  | 1,138 |  |  | 16.0 | % |  | 1,069 |  |  | 16.7 | % |
| Research and development expenditures | 215 |  |  | 8.4 | % |  | 197 |  |  | 8.3 | % |  | 640 |  |  | 9.0 | % |  | 577 |  |  | 9.0 | % |
| Other charges | 46 |  |  | 1.8 | % |  | 83 |  |  | 3.5 | % |  | 181 |  |  | 2.5 | % |  | 262 |  |  | 4.1 | % |
| Operating earnings | 639 |  |  | 25.0 | % |  | 373 |  |  | 15.7 | % |  | 1,556 |  |  | 21.8 | % |  | 970 |  |  | 15.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (53) |  |  | (2.1) | % |  | (60) |  |  | (2.5) | % |  | (164) |  |  | (2.3) | % |  | (171) |  |  | (2.7) | % |
| Gains (losses) on sales of investments and businesses, net | (1) |  |  | — | % |  | 1 |  |  | — | % |  | — |  |  | — | % |  | 3 |  |  | — | % |
| Other, net | 7 |  |  | 0.3 | % |  | 19 |  |  | 0.8 | % |  | 46 |  |  | 0.6 | % |  | 50 |  |  | 0.8 | % |
| Total other expense | (47) |  |  | (1.8) | % |  | (40) |  |  | (1.7) | % |  | (118) |  |  | (1.7) | % |  | (118) |  |  | (1.8) | % |
| Net earnings before income taxes | 592 |  |  | 23.2 | % |  | 333 |  |  | 14.0 | % |  | 1,438 |  |  | 20.2 | % |  | 852 |  |  | 13.3 | % |
| Income tax expense | 127 |  |  | 5.0 | % |  | 53 |  |  | 2.2 | % |  | 321 |  |  | 4.5 | % |  | 75 |  |  | 1.2 | % |
| Net earnings | 465 |  |  | 18.2 | % |  | 280 |  |  | 11.8 | % |  | 1,117 |  |  | 15.7 | % |  | 777 |  |  | 12.1 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | — | % |  | 4 |  |  | 0.1 | % |  | 3 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 464 |  |  | 18.2 | % |  | $ | 279 |  |  | 11.8 | % |  | $ | 1,113 |  |  | 15.6 | % |  | $ | 774 |  |  | 12.1 | % |
| Earnings per diluted common share | $ | 2.70 |  |  |  |  | $ | 1.63 |  |  |  |  | $ | 6.46 |  |  |  |  | $ | 4.50 |  |  |  |

[0000068505-23-000045:mdna:29]
[same as prior period, unchanged from 0000068505-23-000039:mdna:31]

[0000068505-23-000045:mdna:30]
31

[0000068505-23-000045:mdna:31]
Results of Operations—Three months ended September 30, 2023 compared to three months ended October 1, 2022

[0000068505-23-000045:mdna:32]
The results of operations for the third quarter of 2023 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-23-000045:mdna:33]
[same as prior period, unchanged from 0000068505-23-000039:mdna:35]

[0000068505-23-000045:mdna:34]
[same as prior period, unchanged from 0000068505-23-000039:mdna:36]

[0000068505-23-000045:mdna:35]
[same as prior period, unchanged from 0000068505-23-000039:mdna:37]

[0000068505-23-000045:mdna:36]
[same as prior period, unchanged from 0000068505-23-000039:mdna:38]

[0000068505-23-000045:mdna:37]
[same as prior period, unchanged from 0000068505-23-000039:mdna:39]

[0000068505-23-000045:mdna:38]
|  | Three Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |  | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |
| International | 457 |  |  | 316 |  |  | 773 |  |  | 363 |  |  | 323 |  |  | 686 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |  | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |
| Video | 300 |  |  | 153 |  |  | 453 |  |  | 286 |  |  | 133 |  |  | 419 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 142 |  |  | 142 |  |
| Total | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Operating earnings | $ | 364 |  |  | $ | 275 |  |  | $ | 639 |  |  | $ | 303 |  |  | $ | 70 |  |  | $ | 373 |  |
| Operating margins | 22.6 | % |  | 29.1 | % |  | 25.0 | % |  | 19.8 | % |  | 8.3 | % |  | 15.7 | % |

[0000068505-23-000045:mdna:39]
[same as prior period, unchanged from 0000068505-23-000039:mdna:41]

[0000068505-23-000045:mdna:40]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in the third quarter of 2023 and 64% in the third quarter of 2022. The Software and Services segment’s net sales represented 37% of our net sales in the third quarter of 2023 and 36% in the third quarter of 2022.

[0000068505-23-000045:mdna:41]
Net sales increased $183 million, or 8%, in the third quarter of 2023 compared to the third quarter of 2022. The $83 million, or 5%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 26% in the International region and partially offset by a decrease of 1% in the North America region. The $100 million, or 12%, increase in net sales within the Software and Services segment was driven by an increase of 21% in the North America region and partially offset by a decrease of 2% in the International region. Net sales includes:

[0000068505-23-000045:mdna:42]
•an increase in the Software and Services segment, inclusive of $18 million of revenue from acquisitions, driven by an increase in Command Center, LMR and Video, partially offset by the deferral of revenue on the Airwave contract attributed to the pricing control in the remedies order; and

[0000068505-23-000045:mdna:43]
•an increase in the Products and Systems Integration segment, inclusive of $1 million of revenue from acquisitions, driven by an increase in LMR and Video;

[0000068505-23-000045:mdna:44]
•inclusive of $13 million from favorable currency rates.

[0000068505-23-000045:mdna:45]
[same as prior period, unchanged from 0000068505-23-000039:mdna:47]

[0000068505-23-000045:mdna:46]
•a 6% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in Command Center, LMR and Video; and

[0000068505-23-000045:mdna:47]
•a 13% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR and Video, partially offset by the deferral of revenue recognition on the Airwave contract.

[0000068505-23-000045:mdna:48]
[same as prior period, unchanged from 0000068505-23-000039:mdna:50]

[0000068505-23-000045:mdna:49]
The 5% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-23-000045:mdna:50]
•$69 million, or 6% growth in LMR, inclusive of revenue from acquisitions, driven by the International region and partially offset by the North America region; and

[0000068505-23-000045:mdna:51]
•$14 million, or 5% growth in Video, driven by the International and North America regions;

[0000068505-23-000045:mdna:52]
•inclusive of $4 million from favorable currency rates.

[0000068505-23-000045:mdna:53]
[same as prior period, unchanged from 0000068505-23-000039:mdna:55]

[0000068505-23-000045:mdna:54]
[same as prior period, unchanged from 0000068505-23-000039:mdna:119]

[0000068505-23-000045:mdna:55]
•$44 million, or 31% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-23-000045:mdna:56]
•$36 million, or 6% growth in LMR, driven by the North America region and partially offset by the International region, inclusive of the deferral of revenue recognition on the Airwave contract; and

[0000068505-23-000045:mdna:57]
•$20 million, or 15% growth in Video, driven by the North America region and partially offset by the International region;

[0000068505-23-000045:mdna:58]
•inclusive of $9 million from favorable currency rates.

[0000068505-23-000045:mdna:59]
[same as prior period, unchanged from 0000068505-23-000039:mdna:61]

[0000068505-23-000045:mdna:60]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |  | % Change |
| Gross margin | $ | 1,280 |  |  | $ | 1,031 |  |  | 24 | % |

[0000068505-23-000045:mdna:61]
Gross margin was 50.1% of net sales in the third quarter of 2023 compared to 43.4% in the third quarter of 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-23-000045:mdna:62]
•higher gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by a $147 million fixed asset impairment loss during the third quarter of 2022 that did not recur in the third quarter of 2023, related to assets constructed and used in the deployment of the ESN service contract with the Home Office; and higher sales, partially offset by the deferral of revenue recognition on the Airwave contract; and

[0000068505-23-000045:mdna:63]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales and lower direct material costs, partially offset by mix.

[0000068505-23-000045:mdna:64]
[same as prior period, unchanged from 0000068505-23-000039:mdna:66]

[0000068505-23-000045:mdna:65]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |  | % Change |
| Selling, general and administrative expenses | $ | 380 |  |  | $ | 378 |  |  | 1 | % |

[0000068505-23-000045:mdna:66]
SG&A expenses increased 1% in the third quarter of 2023 compared to the third quarter of 2022. The increase in SG&A expenses was primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses, partially offset by lower Hytera-related legal expenses. SG&A expenses were 14.9% of net sales in the third quarter of 2023 compared to 15.9% of net sales in the third quarter of 2022.

[0000068505-23-000045:mdna:67]
[same as prior period, unchanged from 0000068505-23-000039:mdna:69]

[0000068505-23-000045:mdna:68]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |  | % Change |
| Research and development expenditures | $ | 215 |  |  | $ | 197 |  |  | 9 | % |

[0000068505-23-000045:mdna:69]
R&D expenditures increased 9% in the third quarter of 2023 compared to the third quarter of 2022 primarily due to higher employee incentive costs, including share-based compensation and higher expenses associated with acquired businesses. R&D expenditures were 8.4% of net sales in the third quarter of 2023 compared to 8.3% of net sales in the third quarter of 2022.

[0000068505-23-000045:mdna:70]
[same as prior period, unchanged from 0000068505-23-000039:mdna:72]

[0000068505-23-000045:mdna:71]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Other charges | $ | 46 |  |  | $ | 83 |  |

[0000068505-23-000045:mdna:72]
Other charges decreased by $37 million in the third quarter of 2023 compared to the third quarter of 2022. The change was driven primarily by the following:

[0000068505-23-000045:mdna:73]
•$39 million of intangible asset amortization expense in the third quarter of 2023 compared to $63 million of intangible asset amortization expense in the third quarter of 2022; and

[0000068505-23-000045:mdna:74]
•$1 million of legal settlement charges in the third quarter of 2023 compared to $12 million of legal settlement charges in the third quarter 2022.

[0000068505-23-000045:mdna:75]
[same as prior period, unchanged from 0000068505-23-000039:mdna:80]

[0000068505-23-000045:mdna:76]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Operating earnings from Products and Systems Integration | $ | 364 |  |  | $ | 303 |  |
| Operating earnings from Software and Services | 275 |  |  | 70 |  |
| Operating earnings | $ | 639 |  |  | $ | 373 |  |

[0000068505-23-000045:mdna:77]
Operating earnings increased $266 million, or 71%, in the third quarter of 2023 compared to the third quarter of 2022. The increase in Operating earnings was due to:

[0000068505-23-000045:mdna:78]
•$205 million increase in the Software and Services segment, primarily driven by a $147 million fixed asset impairment loss during the third quarter of 2022 that did not recur in the third quarter of 2023, related to assets constructed and used in the deployment of the ESN service contract with the Home Office; higher sales; improved operating leverage and a reduction in intangible amortization expenses, partially offset by the deferral of revenue recognition on the Airwave contract; and

[0000068505-23-000045:mdna:79]
•$61 million increase in the Products and Systems Integration segment, primarily driven by higher sales, lower direct material costs, improved operating leverage and lower Hytera-related legal expenses, partially offset by mix.

[0000068505-23-000045:mdna:80]
[same as prior period, unchanged from 0000068505-23-000039:mdna:85]

[0000068505-23-000045:mdna:81]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Interest expense, net | $ | (53) |  |  | $ | (60) |  |

[0000068505-23-000045:mdna:82]
The $7 million decrease in Interest expense, net in the third quarter of 2023 compared to the third quarter of 2022 was primarily driven by higher interest income earned on cash.

[0000068505-23-000045:mdna:83]
[same as prior period, unchanged from 0000068505-23-000039:mdna:88]

[0000068505-23-000045:mdna:84]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Other, net | $ | 7 |  |  | $ | 19 |  |

[0000068505-23-000045:mdna:85]
The $12 million decrease in Other, net in the third quarter of 2023 compared to the third quarter of 2022 was primarily driven by:

[0000068505-23-000045:mdna:86]
•$23 million of foreign currency gains in the third quarter of 2023 compared to $45 million of foreign currency gains in the third quarter of 2022;

[0000068505-23-000045:mdna:87]
•$7 million of investment impairments in the third quarter of 2023 that did not occur in the third quarter of 2022;

[0000068505-23-000045:mdna:88]
•$24 million of net periodic pension and postretirement benefit in the third quarter of 2023 compared to $28 million of net periodic pension and postretirement benefit in the third quarter of 2022; and

[0000068505-23-000045:mdna:89]
•$7 million loss on fair value adjustments to equity investments in the third quarter of 2023 compared to a $5 million loss on fair value adjustments to equity investments in the third quarter of 2022; partially offset by

[0000068505-23-000045:mdna:90]
•$26 million loss on derivatives in the third quarter of 2023 compared to a $54 million loss on derivatives in the third quarter of 2022.

[0000068505-23-000045:mdna:91]
[same as prior period, unchanged from 0000068505-23-000039:mdna:98]

[0000068505-23-000045:mdna:92]
|  | Three Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Income tax expense | $ | 127 |  |  | $ | 53 |  |

[0000068505-23-000045:mdna:93]
Income tax expense increased by $74 million in the third quarter of 2023 compared to the third quarter of 2022, resulting in an effective tax rate of 21%. Our effective tax rate for the three months ended September 30, 2023 of 21% was higher than the effective tax rate for the three months ended October 1, 2022 of 16%, primarily due to lower excess tax benefits of share-based compensation in 2023, partially offset by more favorable US return-to-provision adjustments in 2023.

[0000068505-23-000045:mdna:94]
Results of Operations—Nine months ended September 30, 2023 compared to Nine months ended October 1, 2022

[0000068505-23-000045:mdna:95]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |  | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |
| International | 1,222 |  |  | 991 |  |  | 2,213 |  |  | 957 |  |  | 973 |  |  | 1,930 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |  | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |
| Video | 810 |  |  | 435 |  |  | 1,245 |  |  | 728 |  |  | 368 |  |  | 1,096 |  |
| Command Center | — |  |  | 535 |  |  | 535 |  |  | — |  |  | 435 |  |  | 435 |  |
| Total | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Operating earnings | 752 |  |  | 804 |  |  | 1,556 |  |  | 460 |  |  | 510 |  |  | 970 |  |
| Operating margins | 17.3 | % |  | 29.0 | % |  | 21.8 | % |  | 11.7 | % |  | 20.5 | % |  | 15.1 | % |

[0000068505-23-000045:mdna:96]
[same as prior period, unchanged from 0000068505-23-000039:mdna:103]

[0000068505-23-000045:mdna:97]
The Products and Systems Integration segment's net sales represented 61% of our net sales in both the first nine months of 2023 and 2022. Net sales from the Software and Services segment represented 39% of our net sales in both the first nine months of 2023 and 2022.

[0000068505-23-000045:mdna:98]
Net sales increased $724 million, or 11%, in the first nine months of 2023 compared to the first nine months of 2022. The $434 million, or 11%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 28% in the International region and an increase of 6% in the North America region. The $290 million, or 12%, increase in net sales within the Software and Services segment was driven by an increase of 18% in the North America region and an increase of 2% in the International region. Net sales includes:

[0000068505-23-000045:mdna:99]
•an increase in the Products and Systems Integration segment, inclusive of $15 million of revenue from acquisitions, driven by an increase in LMR and Video; and

[0000068505-23-000045:mdna:100]
•an increase in Software and Services, inclusive of $66 million of revenue from acquisitions, driven by an increase in LMR, Command Center and Video, partially offset by the deferral of revenue on the Airwave contract attributed to the pricing control in the remedies order;

[0000068505-23-000045:mdna:101]
•inclusive of $54 million from favorable currency rates.

[0000068505-23-000045:mdna:102]
[same as prior period, unchanged from 0000068505-23-000039:mdna:109]

[0000068505-23-000045:mdna:103]
•a 10% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-23-000045:mdna:104]
•a 15% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR and Video, partially offset by the deferral of revenue recognition on the Airwave contract.

[0000068505-23-000045:mdna:105]
[same as prior period, unchanged from 0000068505-23-000039:mdna:112]

[0000068505-23-000045:mdna:106]
The 11% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-23-000045:mdna:107]
•$352 million, or 11% growth in LMR, inclusive of revenue from acquisitions, driven by both the International and North America regions; and

[0000068505-23-000045:mdna:108]
•$82 million, or 11% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-23-000045:mdna:109]
•inclusive of $24 million from favorable currency rates.

[0000068505-23-000045:mdna:110]
[same as prior period, unchanged from 0000068505-23-000039:mdna:118]

[0000068505-23-000045:mdna:111]
The 12% increase in the Software and Services segment was driven by the following:

[0000068505-23-000045:mdna:112]
•$123 million, or 7% growth in LMR, inclusive of revenue from acquisitions, driven by the North America and International regions, inclusive of the deferral of revenue recognition on the Airwave contract;

[0000068505-23-000045:mdna:113]
•$100 million, or 23% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America region; and

[0000068505-23-000045:mdna:114]
•$67 million, or 18% growth in Video, inclusive of revenue from acquisitions, driven by the North America region and partially offset by the International region;

[0000068505-23-000045:mdna:115]
•inclusive of $30 million from favorable currency rates.

[0000068505-23-000045:mdna:116]
[same as prior period, unchanged from 0000068505-23-000039:mdna:124]

[0000068505-23-000045:mdna:117]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |  | % Change |
| Gross margin | $ | 3,515 |  |  | $ | 2,878 |  |  | 22 | % |

[0000068505-23-000045:mdna:118]
Gross margin was 49.3% of net sales in the first nine months of 2023 compared to 44.9% in the first nine months of 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-23-000045:mdna:119]
•higher gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, inclusive of higher pricing, and lower direct material costs, partially offset by mix; and

[0000068505-23-000045:mdna:120]
•higher gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales and a $147 million fixed asset impairment loss during the first nine months of 2022 that did not recur in the first nine months of 2023, related to assets constructed and used in the deployment of the ESN service contract with the Home Office, and partially offset by the deferral of revenue recognition on the Airwave contract.

[0000068505-23-000045:mdna:121]
[same as prior period, unchanged from 0000068505-23-000039:mdna:129]

[0000068505-23-000045:mdna:122]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |  | % Change |
| Selling, general and administrative expenses | $ | 1,138 |  |  | $ | 1,069 |  |  | 6 | % |

[0000068505-23-000045:mdna:123]
SG&A expenses increased 6% in the first nine months of 2023 compared to the first nine months of 2022. The increase in SG&A expenses was primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses, partially offset by lower Hytera-related legal expenses. SG&A expenses were 16.0% of net sales in the first nine months of 2023 compared to 16.7% of net sales in the first nine months of 2022.

[0000068505-23-000045:mdna:124]
[same as prior period, unchanged from 0000068505-23-000039:mdna:132]

[0000068505-23-000045:mdna:125]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |  | % Change |
| Research and development expenditures | $ | 640 |  |  | $ | 577 |  |  | 11 | % |

[0000068505-23-000045:mdna:126]
R&D expenditures increased 11% in the first nine months of 2023 compared to the first nine months of 2022 primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses. R&D expenditures were 9.0% of net sales in both the first nine months of 2023 and 2022.

[0000068505-23-000045:mdna:127]
[same as prior period, unchanged from 0000068505-23-000039:mdna:135]

[0000068505-23-000045:mdna:128]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Other charges | $ | 181 |  |  | $ | 262 |  |

[0000068505-23-000045:mdna:129]
Other charges decreased by $81 million in the first nine months of 2023 compared to the first nine months of 2022. The change was driven primarily by the following:

[0000068505-23-000045:mdna:130]
•$137 million of intangible asset amortization expense in the first nine months of 2023 compared to $194 million of intangible asset amortization expense in the first nine months of 2022;

[0000068505-23-000045:mdna:131]
•$1 million of legal settlement charges in the first nine months of 2023 compared to $23 million of legal settlement charges in the first nine months of 2022;

[0000068505-23-000045:mdna:132]
•$3 million of acquisition-related transaction fees in the first nine months of 2023 compared to $16 million of acquisition-related transaction fees in the first nine months of 2022;

[0000068505-23-000045:mdna:133]
•$4 million of operating lease asset impairments in the first nine months of 2023 compared to $16 million of operating lease asset impairments in the first nine months of 2022; and

[0000068505-23-000045:mdna:134]
•$3 million of fixed asset impairments in the first nine months of 2023 compared to $12 million of fixed asset impairments in the first nine months of 2022; partially offset by

[0000068505-23-000045:mdna:135]
•$15 million of environmental reserve expense in the first nine months of 2023 that did not occur in the first nine months of 2022; and

[0000068505-23-000045:mdna:136]
•$13 million gain on recoveries from the legal settlement under the Hytera bankruptcy proceedings in the first nine months of 2022 (see further detail in "Hytera Bankruptcy Proceedings" in Note 12, "Commitments and Contingencies" to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q), that did not recur in the first nine months of 2023.

[0000068505-23-000045:mdna:137]
[same as prior period, unchanged from 0000068505-23-000039:mdna:145]

[0000068505-23-000045:mdna:138]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Operating earnings from Products and Systems Integration | $ | 752 |  |  | $ | 460 |  |
| Operating earnings from Software and Services | 804 |  |  | 510 |  |
| Operating earnings | $ | 1,556 |  |  | $ | 970 |  |

[0000068505-23-000045:mdna:139]
Operating earnings increased $586 million, or 60%, in the first nine months of 2023 compared to the first nine months of 2022. The increase in Operating earnings was due to:

[0000068505-23-000045:mdna:140]
•$294 million increase in the Software and Services segment, primarily driven by higher sales, a $147 million fixed asset impairment loss during the first nine months of 2022 that did not recur in the first nine months of 2023 related to assets constructed and used in the deployment of the ESN service contract with the Home Office; and a reduction in intangible amortization expenses, partially offset by higher expenses associated with acquired businesses and the deferral of revenue recognition on the Airwave contract; and

[0000068505-23-000045:mdna:141]
•$292 million increase in the Products and Systems Integration segment, primarily driven by higher sales, pricing actions and lower supply chain costs, partially offset by higher employee incentive costs, including share-based compensation and mix.

[0000068505-23-000045:mdna:142]
[same as prior period, unchanged from 0000068505-23-000039:mdna:150]

[0000068505-23-000045:mdna:143]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Interest expense, net | $ | (164) |  |  | $ | (171) |  |

[0000068505-23-000045:mdna:144]
The $7 million decrease in net interest expense in the first nine months of 2023 compared to the first nine months of 2022 was primarily driven by higher interest income earned on cash, partially offset by interest on higher outstanding debt.

[0000068505-23-000045:mdna:145]
[same as prior period, unchanged from 0000068505-23-000039:mdna:153]

[0000068505-23-000045:mdna:146]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Other, net | $ | 46 |  |  | $ | 50 |  |

[0000068505-23-000045:mdna:147]
The $4 million decrease in Other, net in the first nine months of 2023 compared to the first nine months of 2022 was primarily driven by:

[0000068505-23-000045:mdna:148]
•$16 million of foreign currency losses in the first nine months of 2023 compared to $95 million of foreign currency gains in the first nine months of 2022;

[0000068505-23-000045:mdna:149]
•$19 million gain on equity method investments in the first nine months of 2022 that did not occur in the first nine months of 2023;

[0000068505-23-000045:mdna:150]
•$73 million of net periodic pension and postretirement benefit in the first nine months of 2023 compared to $91 million of net periodic pension and postretirement benefit in the first nine months of 2022; and

[0000068505-23-000045:mdna:151]
•$16 million of investment impairments in the first nine months of 2023 compared to $1 million of investment impairments in the first nine months of 2022; partially offset by

[0000068505-23-000045:mdna:152]
•$9 million of losses on derivative instruments in the first nine months of 2023 compared to $111 million of losses on derivative instruments in the first nine months of 2022;

[0000068505-23-000045:mdna:153]
•$12 million gain on fair value adjustments to equity investments in the first nine months of 2023 compared to a $35 million loss on fair value adjustments to equity investments in the first nine months of 2022; and

[0000068505-23-000045:mdna:154]
•$6 million loss on the extinguishment of long-term debt in the first nine months of 2022 that did not recur in the first nine months of 2023.

[0000068505-23-000045:mdna:155]
[same as prior period, unchanged from 0000068505-23-000039:mdna:164]

[0000068505-23-000045:mdna:156]
|  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | October 1, 2022 |
| Income tax expense | $ | 321 |  |  | $ | 75 |  |

[0000068505-23-000045:mdna:157]
Income tax expense increased by $246 million in the first nine months of 2023 compared to the first nine months of 2022, resulting in an effective tax rate of 22%. Our effective tax rate of 22% for the nine months ended September 30, 2023 was higher than the effective tax rate for the nine months ended October 1, 2022 of 9%, primarily due to a net deferred tax benefit in 2022 as a result of an intra-group transfer of certain IP rights, lower excess tax benefits of share-based compensation in 2023, and a lower foreign derived intangible income deduction in 2023, partially offset by more favorable US return-to-provision adjustments in 2023.

[0000068505-23-000045:mdna:158]
[same as prior period, unchanged from 0000068505-23-000039:mdna:167]

[0000068505-23-000045:mdna:159]
During the third quarter of 2023, we recorded net reorganization of business charges of $6 million, including $4 million of charges recorded within Other charges and $2 million of charges recorded in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $6 million were charges of $8 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000045:mdna:160]
During the first nine months of 2023, we recorded net reorganization of business charges of $22 million, including $16 million of charges recorded within Other charges and $6 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $22 million were charges of $32 million related to employee separation costs, partially offset by $5 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-23-000045:mdna:161]
During the third quarter of 2022, we recorded net reorganization of business charges of $14 million, including $2 million of charges in Other charges and $12 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $7 million related to employee separation costs and $10 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-23-000045:mdna:162]
During the first nine months of 2022, we recorded net reorganization of business charges of $31 million, including $14 million of charges recorded within Other charges and $17 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $31 million were charges of $30 million related to employee separation costs and $10 million related to exit costs, partially offset by $9 million of reversals for accruals no longer needed.

[0000068505-23-000045:mdna:163]
[same as prior period, unchanged from 0000068505-23-000039:mdna:172]

[0000068505-23-000045:mdna:164]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Products and Systems Integration | $ | 5 |  |  | $ | 3 |  |  | $ | 22 |  |  | $ | 17 |  |
| Software and Services | 1 |  |  | 11 |  |  | — |  |  | 14 |  |
|  | $ | 6 |  |  | $ | 14 |  |  | $ | 22 |  |  | $ | 31 |  |

[0000068505-23-000045:mdna:165]
Cash payments for employee severance in connection with the reorganization of business plans were $28 million in the first nine months of 2023 and $27 million in the first nine months of 2022. The reorganization of business accrual at September 30, 2023 was $25 million related to employee separation costs that are expected to be paid within one year.

[0000068505-23-000045:mdna:166]
At January 1, 2023, we had an accrual of $10 million for exit costs related to our exit of the ESN contract with the Home Office in 2022. During the nine months ended September 30, 2023, the Company recorded a $5 million reversal for accruals no longer needed. The remaining $5 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at September 30, 2023, and are expected to be paid within one year.

[0000068505-23-000045:mdna:167]
[same as prior period, unchanged from 0000068505-23-000039:mdna:176]

[0000068505-23-000045:mdna:168]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 799 |  |  | $ | 550 |  |
| Investing activities | (172) |  |  | (735) |  |
| Financing activities | (1,043) |  |  | (704) |  |
| Effect of exchange rates on cash and cash equivalents | 1 |  |  | (163) |  |
| Increase (decrease) in cash and cash equivalents | $ | (415) |  |  | $ | (1,052) |  |

[0000068505-23-000045:mdna:169]
[same as prior period, unchanged from 0000068505-23-000039:mdna:178]

[0000068505-23-000045:mdna:170]
At September 30, 2023, $630 million of the $910 million cash and cash equivalents balance was held in the U.S. and $280 million was held in other countries.

[0000068505-23-000045:mdna:171]
[same as prior period, unchanged from 0000068505-23-000039:mdna:180]

[0000068505-23-000045:mdna:172]
The increase in cash flows provided by operating activities from the first nine months of 2022 to the first nine months of 2023 was driven primarily by higher earnings, net of non-cash charges and improved working capital, and partially offset by higher cash taxes, including a one-time $70 million cash tax payment made in 2023 related to an intra-group transfer of certain IP rights that was completed in 2022.

[0000068505-23-000045:mdna:173]
[same as prior period, unchanged from 0000068505-23-000039:mdna:182]

[0000068505-23-000045:mdna:174]
The decrease in cash flows used for investing activities in the first nine months of 2023 compared to the first nine months of 2022 was primarily due to a $578 million decrease in cash used for acquisitions and investments.

[0000068505-23-000045:mdna:175]
[same as prior period, unchanged from 0000068505-23-000039:mdna:184]

[0000068505-23-000045:mdna:176]
The increase in cash flows used for financing activities in the first nine months of 2023 compared to the first nine months of 2022 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-23-000045:mdna:177]
•$595 million in net proceeds from the issuance of debt in the first nine months of 2022 that did not recur in the first nine months of 2023;

[0000068505-23-000045:mdna:178]
•$61 million decrease in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first nine months of 2023 compared to the first nine months of 2022; and

[0000068505-23-000045:mdna:179]
•$45 million increase in the payment of dividends in the first nine months of 2023 compared to the first nine months of 2022; partially offset by

[0000068505-23-000045:mdna:180]
•$282 million decrease in repayments of debt in the first nine months of 2023 compared to the first nine months of 2022; and

[0000068505-23-000045:mdna:181]
•$79 million decrease in share repurchases in the first nine months of 2023 compared to the first nine months of 2022.

[0000068505-23-000045:mdna:182]
[same as prior period, unchanged from 0000068505-23-000039:mdna:191]

[0000068505-23-000045:mdna:183]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 30, 2023 and October 1, 2022:

[0000068505-23-000045:mdna:184]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Contract-specific discounting facility | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 49 |  |
| Accounts receivable sales proceeds | — |  |  | — |  |  | $ | — |  |  | $ | 62 |  |
| Long-term receivables sales proceeds | 65 |  |  | 42 |  |  | 123 |  |  | 64 |  |
| Total proceeds from receivable sales | $ | 65 |  |  | $ | 42 |  |  | $ | 123 |  |  | $ | 175 |  |

[0000068505-23-000045:mdna:185]
[same as prior period, unchanged from 0000068505-23-000039:mdna:194]

[0000068505-23-000045:mdna:186]
[same as prior period, unchanged from 0000068505-23-000039:mdna:198]

[0000068505-23-000045:mdna:187]
We had outstanding debt of $4.7 billion at September 30, 2023, of which $1.3 billion, inclusive of the $1.0 billion of Senior Convertible Notes and $313 million of 4.0% senior notes, was current. We had outstanding debt of $6.0 billion at December 31, 2022, of which $1 million was current.

[0000068505-23-000045:mdna:188]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 30, 2023. On February 8, 2023, we entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

[0000068505-23-000045:mdna:189]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of September 30, 2023 we had no outstanding debt under the commercial paper program.

[0000068505-23-000045:mdna:190]
We have investment grade ratings on our senior unsecured long-term debt. During the third quarter of 2023, Moody's Investors Service upgraded our credit rating to Baa2 from Baa3. We continue to believe that we will be able to maintain sufficient access to the capital markets in the next twelve months and the foreseeable future.

[0000068505-23-000045:mdna:191]
[same as prior period, unchanged from 0000068505-23-000039:mdna:201]

[0000068505-23-000045:mdna:192]
During the three and nine months ended September 30, 2023, we repurchased approximately 1.1 million and 2.5 million shares at an average price of $281.79 and $277.96 per share for an aggregate amount of $322 million and $686 million, respectively, excluding transaction costs and excise tax. We paid $306 million and $670 million to settle share repurchases during the three and nine months ended September 30, 2023, respectively. As of January 1, 2023, our share repurchases in excess of issuances are subject to a 1% excise tax enacted by the Inflation Reduction Act of 2022, which was $3 million as of September 30, 2023. As of September 30, 2023, we had used approximately $15.4 billion of the share repurchase authority to repurchase shares, leaving $599 million of authority available for future repurchases.

[0000068505-23-000045:mdna:193]
[same as prior period, unchanged from 0000068505-23-000039:mdna:203]

[0000068505-23-000045:mdna:194]
During the third quarter of 2023 we paid $147 million in cash dividends to holders of our common stock. During the first nine months of 2023 we paid $443 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $146 million in cash dividends to holders of our common stock.

[0000068505-23-000045:mdna:195]
[same as prior period, unchanged from 0000068505-23-000039:mdna:205]

[0000068505-23-000045:mdna:196]
[same as prior period, unchanged from 0000068505-23-000039:mdna:206]

[0000068505-23-000045:mdna:197]
[same as prior period, unchanged from 0000068505-23-000039:mdna:207]

[0000068505-23-000045:mdna:198]
[same as prior period, unchanged from 0000068505-23-000039:mdna:208]

[0000068505-23-000045:mdna:199]
We had outstanding commitments to provide long-term financing to third parties totaling $97 million at September 30, 2023, compared to $65 million at December 31, 2022.

[0000068505-23-000045:mdna:200]
[same as prior period, unchanged from 0000068505-23-000039:mdna:210]

[0000068505-23-000045:mdna:201]
See “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
