# MSI note change history — 0000068505-23-000039 → 0000068505-23-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000068505-23-000045:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.
  (was, 2023-08-03, similarity 0.994):
[0000068505-23-000039:note_history:1]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury in the Court decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys fees. The Company continues to seek collection of the judgment through the ongoing legal process.

- added (2023-11-02):
[0000068505-23-000045:note_history:2]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order, which the Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis regular quarterly royalty payments into the third-party escrow from October 2022 through October 2023. The aggregate amount paid into escrow will not be recognized until all contingencies are resolved and such amount is released from escrow.

- changed (2023-11-02):
[0000068505-23-000045:note_history:3]
On August 2, 2022, Hytera appealed the Court's July 5, 2022 judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the Company's cross-appeal. The Court of Appeals set an oral argument date of December 5, 2023.
  (was, 2023-08-03, similarity 0.9487):
[0000068505-23-000039:note_history:3]
On August 2, 2022, Hytera appealed the Court's judgment to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The Company filed its cross-appeal on August 5, 2022. The parties have now submitted all briefs and responses on Hytera's appeal and the Company's cross-appeal. The Court of Appeals has not set an oral argument date yet.

- removed (2023-11-02):
[0000068505-23-000039:note_history:4]
On December 17, 2020, the Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the Court's previous July 5, 2022 royalty order. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. Hytera made quarterly royalty payments on October 31, 2022, January 31, 2023, April 25, 2023 and July 25, 2023 into a third-party escrow. The amounts paid into escrow were de minimis and will not be recognized until all contingencies are resolved and amounts are released from escrow. On July 11, 2023, the Court denied Hytera's modification and stay motions and stated that it will consider the Company's contempt motion on August 8, 2023, if Hytera has not yet made the deposit previously due on July 31, 2022, into the escrow account. The Court subsequently set the Company's contempt motion for hearing on August 17, 2023.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000068505-23-000045:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of September 30, 2023 and for the three and nine months ended September 30, 2023 and October 1, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2023-08-03, similarity 0.9363):
[0000068505-23-000039:note_history:5]
Basis of Presentation
The condensed consolidated financial statements as of July 1, 2023 and for the three and six months ended July 1, 2023 and July 2, 2022 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2023-11-02):
[0000068505-23-000045:note_history:6]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three and nine months ended September 30, 2023 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2023-08-03, similarity 0.8162):
[0000068505-23-000039:note_history:6]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2022 (the "Form 10-K"). The results of operations for the three and six months ended July 1, 2023 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2023-11-02):
[0000068505-23-000045:note_history:7]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.
  (was, 2023-08-03, similarity 0.9995):
[0000068505-23-000039:note_history:7]
In September 2022, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2022-04, “Liabilities—Supplier Finance Programs" (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations,” which requires disclosures to enhance transparency about an entity’s use of supplier finance programs. The amendments require a buyer that uses supplier finance programs to disclose the program’s key terms, outstanding confirmed amounts as of the end of the period, a rollforward of such amounts during each annual period and a description of where in the financial statements outstanding amounts are presented. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted ASU 2022-04 on January 1, 2023. Refer to Note 4, "Other Financial Data" to our condensed consolidated financial statements included in this Part I, Item 1 of this Form 10-Q for the related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-02):
[0000068505-23-000045:note_history:8]
Debt and Credit Facilities
As of September 30, 2023, $1.0 billion of Senior Convertible Notes and $313 million of 4.0% senior notes, which both mature in September 2024, were reclassified from Long-term debt to the Current portion of long-term debt statement line within the Company's Condensed Consolidated Balance Sheets, as the notes are due within the next twelve months.

- changed (2023-11-02):
[0000068505-23-000045:note_history:9]
As of September 30, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 30, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.
  (was, 2023-08-03, similarity 0.9699):
[0000068505-23-000039:note_history:9]
Debt and Credit Facilities
As of July 1, 2023, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 1, 2023. On February 8, 2023, the Company entered into an amendment to the 2021 Motorola Solutions Credit Agreement to replace the interest rate benchmark from London Interbank Offered Rate (LIBOR) to SOFR.

- changed (2023-11-02):
[0000068505-23-000045:note_history:10]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 30, 2023 the Company had no outstanding debt under the commercial paper program.
  (was, 2023-08-03, similarity 0.935):
[0000068505-23-000039:note_history:10]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of July 1, 2023 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-02):
[0000068505-23-000045:note_history:11]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 30, 2023 and October 1, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2023-11-02):
[0000068505-23-000045:note_history:12]
|  | Three Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |  | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |
| International | 457 |  |  | 316 |  |  | 773 |  |  | 363 |  |  | 323 |  |  | 686 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |  | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |
| Video | 300 |  |  | 153 |  |  | 453 |  |  | 286 |  |  | 133 |  |  | 419 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 142 |  |  | 142 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |  | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |
| Indirect | 672 |  |  | 85 |  |  | 757 |  |  | 627 |  |  | 75 |  |  | 702 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
  (was, 2023-08-03, similarity 0.9805):
[0000068505-23-000039:note_history:12]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |  | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |
| International | 412 |  |  | 350 |  |  | 762 |  |  | 322 |  |  | 334 |  |  | 656 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |  | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |
| Video | 287 |  |  | 146 |  |  | 433 |  |  | 247 |  |  | 123 |  |  | 370 |  |
| Command Center | — |  |  | 194 |  |  | 194 |  |  | — |  |  | 162 |  |  | 162 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |  | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |
| Indirect | 641 |  |  | 91 |  |  | 732 |  |  | 574 |  |  | 77 |  |  | 651 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |

- changed (2023-11-02):
[0000068505-23-000045:note_history:13]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |  | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |
| International | 1,222 |  |  | 991 |  |  | 2,213 |  |  | 957 |  |  | 973 |  |  | 1,930 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |  | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |
| Video | 810 |  |  | 435 |  |  | 1,245 |  |  | 728 |  |  | 368 |  |  | 1,096 |  |
| Command Center | — |  |  | 535 |  |  | 535 |  |  | — |  |  | 435 |  |  | 435 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |  | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |
| Indirect | 1,893 |  |  | 248 |  |  | 2,141 |  |  | 1,647 |  |  | 228 |  |  | 1,875 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
  (was, 2023-08-03, similarity 0.9772):
[0000068505-23-000039:note_history:13]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |  | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |
| International | 765 |  |  | 676 |  |  | 1,441 |  |  | 594 |  |  | 650 |  |  | 1,244 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |  | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |
| Video | 510 |  |  | 282 |  |  | 792 |  |  | 441 |  |  | 236 |  |  | 677 |  |
| Command Center | — |  |  | 349 |  |  | 349 |  |  | — |  |  | 292 |  |  | 292 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |  | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |
| Indirect | 1,221 |  |  | 164 |  |  | 1,385 |  |  | 1,021 |  |  | 164 |  |  | 1,185 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |

- removed (2023-11-02):
[0000068505-23-000039:note_history:14]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 1, 2023 and July 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-02):
[0000068505-23-000045:note_history:15]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 30, 2023 and October 1, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2023-11-02):
[0000068505-23-000045:note_history:16]
|  | Three Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,155 |  |  | $ | 628 |  |  | $ | 1,783 |  |  | $ | 1,166 |  |  | $ | 521 |  |  | $ | 1,687 |  |
| International | 457 |  |  | 316 |  |  | 773 |  |  | 363 |  |  | 323 |  |  | 686 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,312 |  |  | $ | 605 |  |  | $ | 1,917 |  |  | $ | 1,243 |  |  | $ | 569 |  |  | $ | 1,812 |  |
| Video | 300 |  |  | 153 |  |  | 453 |  |  | 286 |  |  | 133 |  |  | 419 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 142 |  |  | 142 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 940 |  |  | $ | 859 |  |  | $ | 1,799 |  |  | $ | 902 |  |  | $ | 769 |  |  | $ | 1,671 |  |
| Indirect | 672 |  |  | 85 |  |  | 757 |  |  | 627 |  |  | 75 |  |  | 702 |  |
|  | $ | 1,612 |  |  | $ | 944 |  |  | $ | 2,556 |  |  | $ | 1,529 |  |  | $ | 844 |  |  | $ | 2,373 |  |
  (was, 2023-08-03, similarity 0.9805):
[0000068505-23-000039:note_history:16]
|  | Three Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,025 |  |  | $ | 616 |  |  | $ | 1,641 |  |  | $ | 963 |  |  | $ | 521 |  |  | $ | 1,484 |  |
| International | 412 |  |  | 350 |  |  | 762 |  |  | 322 |  |  | 334 |  |  | 656 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,150 |  |  | $ | 626 |  |  | $ | 1,776 |  |  | $ | 1,038 |  |  | $ | 570 |  |  | $ | 1,608 |  |
| Video | 287 |  |  | 146 |  |  | 433 |  |  | 247 |  |  | 123 |  |  | 370 |  |
| Command Center | — |  |  | 194 |  |  | 194 |  |  | — |  |  | 162 |  |  | 162 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 796 |  |  | $ | 875 |  |  | $ | 1,671 |  |  | $ | 711 |  |  | $ | 778 |  |  | $ | 1,489 |  |
| Indirect | 641 |  |  | 91 |  |  | 732 |  |  | 574 |  |  | 77 |  |  | 651 |  |
|  | $ | 1,437 |  |  | $ | 966 |  |  | $ | 2,403 |  |  | $ | 1,285 |  |  | $ | 855 |  |  | $ | 2,140 |  |

- changed (2023-11-02):
[0000068505-23-000045:note_history:17]
|  | Nine Months Ended |
|  | September 30, 2023 |  | October 1, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,130 |  |  | $ | 1,786 |  |  | $ | 4,916 |  |  | $ | 2,961 |  |  | $ | 1,514 |  |  | $ | 4,475 |  |
| International | 1,222 |  |  | 991 |  |  | 2,213 |  |  | 957 |  |  | 973 |  |  | 1,930 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 3,542 |  |  | $ | 1,807 |  |  | $ | 5,349 |  |  | $ | 3,190 |  |  | $ | 1,684 |  |  | $ | 4,874 |  |
| Video | 810 |  |  | 435 |  |  | 1,245 |  |  | 728 |  |  | 368 |  |  | 1,096 |  |
| Command Center | — |  |  | 535 |  |  | 535 |  |  | — |  |  | 435 |  |  | 435 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,459 |  |  | $ | 2,529 |  |  | $ | 4,988 |  |  | $ | 2,271 |  |  | $ | 2,259 |  |  | $ | 4,530 |  |
| Indirect | 1,893 |  |  | 248 |  |  | 2,141 |  |  | 1,647 |  |  | 228 |  |  | 1,875 |  |
|  | $ | 4,352 |  |  | $ | 2,777 |  |  | $ | 7,129 |  |  | $ | 3,918 |  |  | $ | 2,487 |  |  | $ | 6,405 |  |
  (was, 2023-08-03, similarity 0.9772):
[0000068505-23-000039:note_history:17]
|  | Six Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,975 |  |  | $ | 1,158 |  |  | $ | 3,133 |  |  | $ | 1,794 |  |  | $ | 994 |  |  | $ | 2,788 |  |
| International | 765 |  |  | 676 |  |  | 1,441 |  |  | 594 |  |  | 650 |  |  | 1,244 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,230 |  |  | $ | 1,203 |  |  | $ | 3,433 |  |  | $ | 1,947 |  |  | $ | 1,116 |  |  | $ | 3,063 |  |
| Video | 510 |  |  | 282 |  |  | 792 |  |  | 441 |  |  | 236 |  |  | 677 |  |
| Command Center | — |  |  | 349 |  |  | 349 |  |  | — |  |  | 292 |  |  | 292 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,519 |  |  | $ | 1,670 |  |  | $ | 3,189 |  |  | $ | 1,367 |  |  | $ | 1,480 |  |  | $ | 2,847 |  |
| Indirect | 1,221 |  |  | 164 |  |  | 1,385 |  |  | 1,021 |  |  | 164 |  |  | 1,185 |  |
|  | $ | 2,740 |  |  | $ | 1,834 |  |  | $ | 4,574 |  |  | $ | 2,388 |  |  | $ | 1,644 |  |  | $ | 4,032 |  |

- changed (2023-11-02):
[0000068505-23-000045:note_history:18]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 30, 2023 was $9.3 billion. A total of $4.9 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 30, 2023, of which $3.1 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.4 billion was from Software and Services performance obligations that were not yet satisfied as of September 30, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.
  (was, 2023-08-03, similarity 0.989):
[0000068505-23-000039:note_history:18]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of July 1, 2023 was $9.4 billion. A total of $4.8 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of July 1, 2023, of which $3.0 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $4.6 billion was from Software and Services performance obligations that were not yet satisfied as of July 1, 2023. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.6 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- changed (2023-11-02):
[0000068505-23-000045:note_history:19]
| (In millions) | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,667 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,092 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,898 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 394 |  |  | 363 |  |  |  |  |  |
  (was, 2023-08-03, similarity 0.9295):
[0000068505-23-000039:note_history:19]
| (In millions) | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,513 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,033 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 1,764 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 382 |  |  | 363 |  |  |  |  |  |

- added (2023-11-02):
[0000068505-23-000045:note_history:20]
Revenue recognized during the three months ended September 30, 2023 which was previously included in Contract liabilities as of July 1, 2023 was $475 million, compared to $437 million of revenue recognized during the three months ended October 1, 2022 which was previously included in Contract liabilities as of July 2, 2022. Revenue recognized during the nine months ended September 30, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $1.1 billion, compared to $939 million recognized during the nine months ended October 1, 2022 which was previously included in Contract liabilities as of December 31, 2021. The Company did not reverse any revenue during the three months ended September 30, 2023 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $3 million of reversals for the three months ended October 1, 2022, primarily driven by changes in the estimates of progress on system contracts. Revenue of $18 million was reversed during the nine months ended September 30, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $23 million of reversals for the nine months ended October 1, 2022.

- changed (2023-11-02):
[0000068505-23-000045:note_history:21]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 30, 2023 and October 1, 2022.
  (was, 2023-08-03, similarity 0.9003):
[0000068505-23-000039:note_history:21]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended July 1, 2023 and July 2, 2022.

- changed (2023-11-02):
[0000068505-23-000045:note_history:22]
| (In millions) | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 89 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 109 |  |  | 130 |  |  |  |  |  |
  (was, 2023-08-03, similarity 0.9634):
[0000068505-23-000039:note_history:22]
| (In millions) | July 1, 2023 |  | December 31, 2022 |  |  |  |  |
| Current contract cost assets | $ | 84 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 130 |  |  |  |  |  |

- added (2023-11-02):
[0000068505-23-000045:note_history:23]
Amortization of contract cost assets was $10 million and $35 million for the three and nine months ended September 30, 2023, respectively, and $14 million and $41 million for the three and nine months ended October 1, 2022, respectively.

- removed (2023-11-02):
[0000068505-23-000039:note_history:24]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended July 1, 2023 and July 2, 2022, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- removed (2023-11-02):
[0000068505-23-000039:note_history:25]
Revenue recognized during the three months ended July 1, 2023 which was previously included in Contract liabilities as of April 1, 2023 was $502 million, compared to $456 million of revenue recognized during the three months ended July 2, 2022 which was previously included in Contract liabilities as of April 2, 2022. Revenue recognized during the six months ended July 1, 2023 which was previously included in Contract liabilities as of December 31, 2022 was $824 million, compared to $712 million recognized during the six months ended July 2, 2022 which was previously included in Contract liabilities as of December 31, 2021. The Company reversed $10 million of revenue during the three months ended July 1, 2023 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to no reversals for the three months ended July 2, 2022, primarily driven by changes in the estimates of progress on system contracts. Revenue of $15 million was reversed during the six months ended July 1, 2023 related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $22 million of reversals for the six months ended July 2, 2022.

- removed (2023-11-02):
[0000068505-23-000039:note_history:26]
Amortization of non-current contract cost assets was $16 million and $35 million for the three and six months ended July 1, 2023, respectively, and $13 million and $26 million for the three and six months ended July 2, 2022, respectively.
