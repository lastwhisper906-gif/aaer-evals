# MSI MD&A — 0000068505-26-000021


## mdna

[0000068505-26-000021:mdna:1]
[same as prior period, unchanged from 0000068505-25-000052:mdna:1]

[0000068505-26-000021:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three months ended April 4, 2026 and March 29, 2025, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2025 (the "Form 10-K").

[0000068505-26-000021:mdna:3]
[same as prior period, unchanged from 0000068505-25-000052:mdna:3]

[0000068505-26-000021:mdna:4]
[same as prior period, unchanged from 0000068505-25-000052:mdna:4]

[0000068505-26-000021:mdna:5]
[same as prior period, unchanged from 0000068505-25-000052:mdna:5]

[0000068505-26-000021:mdna:6]
The Company manages the business through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, the Company reports net sales across three principal product lines:

[0000068505-26-000021:mdna:7]
•MCN: Infrastructure, mobile ad-hoc network ("MANET") technology, devices (two-way radio and broadband, including both for public safety and professional and commercial radio ("PCR")), software and artificial intelligence ("AI")-powered capabilities. MCN includes installation and integration, backed by managed and support services, to help assure mission-critical communications availability, security and resiliency;

[0000068505-26-000021:mdna:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, video monitoring, software and AI-powered analytics that enable visibility of events and focus attention on what's important, to inform faster and more accurate decisions and actions; and

[0000068505-26-000021:mdna:9]
•Command Center: Command center solutions, software applications and AI-powered capabilities, that unify voice and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents while helping to accelerate workflows and improve the accuracy, speed and trust of decisions.

[0000068505-26-000021:mdna:10]
We have invested across these three technologies organically and through acquisitions to evolve our land mobile radio ("LMR") focus and expand our ecosystem of safety and security products and services. Across all three technologies, we offer AI-powered capabilities and software solutions, services such as cybersecurity subscription services and managed and support services.

[0000068505-26-000021:mdna:11]
26

[0000068505-26-000021:mdna:12]
First Quarter Financial Results

[0000068505-26-000021:mdna:13]
•Net sales were $2.7 billion in the first quarter of 2026 compared to $2.5 billion in the first quarter of 2025.

[0000068505-26-000021:mdna:14]
•Operating earnings were $525 million in the first quarter of 2026 compared to $582 million in the first quarter of 2025.

[0000068505-26-000021:mdna:15]
•Net earnings attributable to Motorola Solutions, Inc. was $366 million, or $2.18 per diluted common share, in the first quarter of 2026, compared to $430 million, or $2.53 per diluted common share, in the first quarter of 2025.

[0000068505-26-000021:mdna:16]
•Operating cash flow decreased $59 million to $451 million in the first quarter of 2026 compared to $510 million in the first quarter of 2025.

[0000068505-26-000021:mdna:17]
•We repurchased $118 million of common stock and paid $201 million in dividends in the first quarter of 2026.

[0000068505-26-000021:mdna:18]
[same as prior period, unchanged from 0000068505-25-000052:mdna:16]

[0000068505-26-000021:mdna:19]
[same as prior period, unchanged from 0000068505-25-000052:mdna:17]

[0000068505-26-000021:mdna:20]
Since February 2025, the U.S. has initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, including tariffs levied under the International Emergency Economic Powers Act (“IEEPA”), contributing to a global trade landscape subject to evolving tariffs, import/export regulations, including restrictions around rare earth minerals, trade barriers and trade disputes.

[0000068505-26-000021:mdna:21]
On February 20, 2026, a U.S. Supreme Court ruling invalidated tariffs imposed under IEEPA; however, the ruling did not address potential refunds. Following the ruling, the Court of International Trade (“CIT”) ordered U.S. Customs and Border Protection (“CBP”) to facilitate refunds for all affected importers. On April 20, 2026, CBP launched Phase 1 of the Consolidated Administration and Processing of Entries (“CAPE”) system to facilitate these refunds. As of April 4, 2026, we had not recognized an asset related to any potential refund given the potential uncertainty in receiving refunds. We plan to continue to evaluate new information as it becomes available, and recognize the refund when recovery is probable.

[0000068505-26-000021:mdna:22]
In addition, we are experiencing higher costs for memory in our products which is a result of substantial demand in the market driven by AI. As a result, we continue to observe elevated volatility and uncertainty around the global supply chain. We engage with global suppliers across a diverse network of locations around the world. We continue to work with our global supply base to mitigate our exposure to the risks from global reciprocal (and sectoral) tariffs, rising memory costs, and import/export regulations that have developed, and which may continue to develop, to ensure supply continues at levels necessary to meet our current customer demand. As a result of the dynamic supply chain environment, we have experienced increased costs on materials and components, for which we continue to develop mitigation actions going forward.

[0000068505-26-000021:mdna:23]
[same as prior period, unchanged from 0000068505-25-000052:mdna:23]

[0000068505-26-000021:mdna:24]
| Segment(s) | Technology | Acquisition | Description | Purchase Price | Date of Acquisition |
| Software and Services | Command Center | Hyper | Provider of conversational, agentic AI designed to reduce the burden on understaffed public safety answering points (PSAPs) by handling non-emergency calls. | $23 million and share-based compensation of $2 million | March 24, 2026 |
| Software and Services | Command Center | Exacom | Provider of cloud-native voice and multimedia recording and logging solutions for mission-critical communications. | $67 million and share-based compensation of $1 million | March 11, 2026 |
| Software and Services | Video Security and Access Control | Blue Eye | Provider of AI-powered enterprise remote video monitoring ("RVM") services. | $79 million and share-based compensation of $1 million | November 18, 2025 |
| Products and Systems Integration&Software and Services | Mission Critical Networks | Silvus Technologies | Designer and developer of software-defined high-speed MANET technology. | $4.4 billion and share-based compensation of $20 million | August 6, 2025 |
| Software and Services | Command Center | Theatro | Creator of AI and voice-powered communication and digital workflow software for frontline workers. | $174 million and share-based compensation of $5 million | March 6, 2025 |
| Software and Services | Command Center | RapidDeploy | Provider of cloud-native 911 solutions. | $240 million and share-based compensation of $6 million | February 21, 2025 |

[0000068505-26-000021:mdna:25]
[same as prior period, unchanged from 0000068505-25-000052:mdna:26]

[0000068505-26-000021:mdna:26]
|  | Three Months Ended |  |  |
| (Dollars in millions, except per share amounts) | April 4, 2026 |  | % ofSales* |  | March 29, 2025 |  | % ofSales* |  |  |  |  |  |  |  |  |
| Net sales from products | $ | 1,481 |  |  |  |  | $ | 1,448 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales from services | 1,233 |  |  |  |  | 1,080 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 2,714 |  |  |  |  | 2,528 |  |  |  |  |  |  |  |  |  |  |  |
| Costs of products sales | 629 |  |  | 42.5 | % |  | 573 |  |  | 39.6 | % |  |  |  |  |  |  |  |  |
| Costs of services sales | 723 |  |  | 58.6 | % |  | 655 |  |  | 60.6 | % |  |  |  |  |  |  |  |  |
| Costs of sales | 1,352 |  |  |  |  | 1,228 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 1,362 |  |  | 50.2 | % |  | 1,300 |  |  | 51.4 | % |  |  |  |  |  |  |  |  |
| Selling, general and administrative expenses | 439 |  |  | 16.2 | % |  | 436 |  |  | 17.2 | % |  |  |  |  |  |  |  |  |
| Research and development expenditures | 252 |  |  | 9.3 | % |  | 233 |  |  | 9.2 | % |  |  |  |  |  |  |  |  |
| Other charges | 146 |  |  | 5.4 | % |  | 49 |  |  | 1.9 | % |  |  |  |  |  |  |  |  |
| Operating earnings | 525 |  |  | 19.3 | % |  | 582 |  |  | 23.0 | % |  |  |  |  |  |  |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (104) |  |  | (3.8) | % |  | (51) |  |  | (2.0) | % |  |  |  |  |  |  |  |  |
| Other, net | 20 |  |  | 0.7 | % |  | 16 |  |  | 0.6 | % |  |  |  |  |  |  |  |  |
| Total other expense | (84) |  |  | (3.1) | % |  | (35) |  |  | (1.4) | % |  |  |  |  |  |  |  |  |
| Net earnings before income taxes | 441 |  |  | 16.2 | % |  | 547 |  |  | 21.6 | % |  |  |  |  |  |  |  |  |
| Income tax expense | 73 |  |  | 2.7 | % |  | 115 |  |  | 4.5 | % |  |  |  |  |  |  |  |  |
| Net earnings | 368 |  |  | 13.6 | % |  | 432 |  |  | 17.1 | % |  |  |  |  |  |  |  |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 366 |  |  | 13.5 | % |  | $ | 430 |  |  | 17.0 | % |  |  |  |  |  |  |  |  |
| Earnings per diluted common share | $ | 2.18 |  |  |  |  | $ | 2.53 |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-26-000021:mdna:27]
[same as prior period, unchanged from 0000068505-25-000052:mdna:28]

[0000068505-26-000021:mdna:28]
28

[0000068505-26-000021:mdna:29]
Results of Operations—Three months ended April 4, 2026 compared to three months ended March 29, 2025

[0000068505-26-000021:mdna:30]
The results of operations for the first quarter of 2026 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-26-000021:mdna:31]
[same as prior period, unchanged from 0000068505-25-000052:mdna:32]

[0000068505-26-000021:mdna:32]
[same as prior period, unchanged from 0000068505-25-000052:mdna:33]

[0000068505-26-000021:mdna:33]
[same as prior period, unchanged from 0000068505-25-000052:mdna:34]

[0000068505-26-000021:mdna:34]
[same as prior period, unchanged from 0000068505-25-000052:mdna:35]

[0000068505-26-000021:mdna:35]
[same as prior period, unchanged from 0000068505-25-000052:mdna:36]

[0000068505-26-000021:mdna:36]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,064 |  |  | $ | 793 |  |  | $ | 1,857 |  |  | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |
| International | 495 |  |  | 362 |  |  | 857 |  |  | 368 |  |  | 308 |  |  | 676 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,288 |  |  | $ | 680 |  |  | $ | 1,968 |  |  | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |
| Video | 271 |  |  | 239 |  |  | 510 |  |  | 231 |  |  | 210 |  |  | 441 |  |
| Command Center | — |  |  | 236 |  |  | 236 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Operating earnings | $ | 213 |  |  | $ | 312 |  |  | $ | 525 |  |  | $ | 352 |  |  | $ | 230 |  |  | $ | 582 |  |
| Operating margins | 13.7 | % |  | 27.0 | % |  | 19.3 | % |  | 22.8 | % |  | 23.4 | % |  | 23.0 | % |

[0000068505-26-000021:mdna:37]
[same as prior period, unchanged from 0000068505-25-000052:mdna:38]

[0000068505-26-000021:mdna:38]
The Products and Systems Integration segment’s net sales represented 57% of our net sales in the first quarter of 2026 and 61% in the first quarter of 2025. The Software and Services segment’s net sales represented 43% of our net sales in the first quarter of 2026 and 39% in the first quarter of 2025.

[0000068505-26-000021:mdna:39]
Net sales increased $186 million, or 7%, in the first quarter of 2026 compared to the first quarter of 2025. The $173 million, or 18%, increase in net sales within the Software and Services segment was driven by an increase of 18% in both the North America and International regions. The $13 million, or 1%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 35% in the International region, partially offset by a decrease of 10% in the North America region. Net sales includes:

[0000068505-26-000021:mdna:40]
•an increase in the Software and Services segment, inclusive of $38 million of revenue from acquisitions, driven by an increase in MCN, Command Center and Video;

[0000068505-26-000021:mdna:41]
•an increase in the Products and Systems Integration segment, inclusive of $181 million of revenue from acquisitions, driven by an increase in Video partially offset by a decrease in MCN; and

[0000068505-26-000021:mdna:42]
•inclusive of $60 million from favorable currency rates.

[0000068505-26-000021:mdna:43]
[same as prior period, unchanged from 0000068505-25-000052:mdna:44]

[0000068505-26-000021:mdna:44]
•a 27% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in MCN, Video and Command Center; and

[0000068505-26-000021:mdna:45]
•the North America region was flat, inclusive of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by a decrease in MCN.

[0000068505-26-000021:mdna:46]
[same as prior period, unchanged from 0000068505-25-000052:mdna:47]

[0000068505-26-000021:mdna:47]
The 1% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-26-000021:mdna:48]
•$40 million, or 17%, growth in Video, driven by the North America and International regions;

[0000068505-26-000021:mdna:49]
•$27 million, or 2%, decrease in MCN, inclusive of revenue from acquisitions, driven by the North America region, partially offset by the International region; and

[0000068505-26-000021:mdna:50]
•inclusive of $30 million from favorable currency rates.

[0000068505-26-000021:mdna:51]
[same as prior period, unchanged from 0000068505-25-000052:mdna:52]

[0000068505-26-000021:mdna:52]
The 18% increase in the Software and Services segment was driven by the following:

[0000068505-26-000021:mdna:53]
•$94 million, or 16%, growth in MCN, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-26-000021:mdna:54]
•$50 million, or 27%, growth in Command Center, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-26-000021:mdna:55]
•$29 million, or 14%, growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-26-000021:mdna:56]
•inclusive of $30 million from favorable currency rates.

[0000068505-26-000021:mdna:57]
[same as prior period, unchanged from 0000068505-25-000052:mdna:58]

[0000068505-26-000021:mdna:58]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 805 |  |  | $ | 852 |  |  | (6) | % |
| Gross margin from Software and Services | 557 |  |  | 448 |  |  | 24 | % |
| Gross margin | $ | 1,362 |  |  | $ | 1,300 |  |  | 5 | % |

[0000068505-26-000021:mdna:59]
Gross margin was 50.2% of net sales in the first quarter of 2026 compared to 51.4% in the first quarter of 2025. The primary drivers of this decrease in gross margin as a percentage of net sales were:

[0000068505-26-000021:mdna:60]
•a 3.5% decrease in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by unfavorable mix and supply chain costs; partially offset by

[0000068505-26-000021:mdna:61]
•a 2.6% increase in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales, favorable mix, and improved operating leverage.

[0000068505-26-000021:mdna:62]
[same as prior period, unchanged from 0000068505-25-000052:mdna:63]

[0000068505-26-000021:mdna:63]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 341 |  |  | $ | 341 |  |  | — | % |
| SG&A expenses from Software and Services | 98 |  |  | 95 |  |  | 3 | % |
| SG&A expenses | $ | 439 |  |  | $ | 436 |  |  | 1 | % |

[0000068505-26-000021:mdna:64]
SG&A expenses increased 1% in the first quarter of 2026 compared to the first quarter of 2025 primarily driven by a $3 million, or 3%, increase in Software and Services SG&A expenses related to higher expenses associated with acquired businesses. SG&A expenses were 16.2% of net sales in the first quarter of 2026 compared to 17.2% of net sales in the first quarter of 2025.

[0000068505-26-000021:mdna:65]
[same as prior period, unchanged from 0000068505-25-000052:mdna:69]

[0000068505-26-000021:mdna:66]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 152 |  |  | $ | 142 |  |  | 7 | % |
| R&D expenditures from Software and Services | 100 |  |  | 91 |  |  | 10 | % |
| R&D expenditures | $ | 252 |  |  | $ | 233 |  |  | 8 | % |

[0000068505-26-000021:mdna:67]
R&D expenditures increased $19 million, or 8%, in the first quarter of 2026 compared to the first quarter of 2025, primarily driven by higher expenditures associated with acquired businesses in both the Products and Systems Integration and Software and Services segments. Products and Systems Integration R&D expenditures increased $10 million, or 7% and Software and Services R&D expenditures increased $9 million, or 10%. R&D expenditures were 9.3% of net sales in the first quarter of 2026 and 9.2% of net sales in the first quarter of 2025.

[0000068505-26-000021:mdna:68]
[same as prior period, unchanged from 0000068505-25-000052:mdna:72]

[0000068505-26-000021:mdna:69]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |
| Other charges from Products and Systems Integration | $ | 99 |  |  | $ | 17 |  |
| Other charges from Software and Services | 47 |  |  | 32 |  |
| Other charges | $ | 146 |  |  | $ | 49 |  |

[0000068505-26-000021:mdna:70]
Other charges increased $97 million in the first quarter of 2026 compared to the first quarter of 2025. The increase was primarily driven by:

[0000068505-26-000021:mdna:71]
•a $75 million contingent earnout charge related to the Silvus acquisition in the first quarter of 2026 that did not occur in the first quarter of 2025; and

[0000068505-26-000021:mdna:72]
•$90 million of intangible amortization expense in the first quarter of 2026 compared to $37 million of intangible amortization expense in the first quarter of 2025; partially offset by

[0000068505-26-000021:mdna:73]
•a $40 million gain on Hytera litigation for amounts recovered through legal proceedings due to the theft of our trade secrets recognized in the first quarter of 2026 compared to $10 million of gains on Hytera litigation in the first quarter of 2025.

[0000068505-26-000021:mdna:74]
[same as prior period, unchanged from 0000068505-25-000052:mdna:79]

[0000068505-26-000021:mdna:75]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |
| Operating earnings from Products and Systems Integration | $ | 213 |  |  | $ | 352 |  |
| Operating earnings from Software and Services | 312 |  |  | 230 |  |
| Operating earnings | $ | 525 |  |  | $ | 582 |  |

[0000068505-26-000021:mdna:76]
Operating earnings decreased $57 million, or 10%, in the first quarter of 2026 compared to the first quarter of 2025. The decrease in Operating earnings was due to:

[0000068505-26-000021:mdna:77]
•a $139 million decrease in the Products and Systems Integration segment, primarily driven by the Silvus contingent earnout charge, unfavorable mix, an increase in intangible amortization expense, higher expenses associated with acquired businesses, and higher supply chain costs, partially offset by a gain on the Hytera litigation, improved operating leverage, and lower expenses related to legal matters, including Hytera-related expenses; partially offset by

[0000068505-26-000021:mdna:78]
•a $82 million increase in the Software and Services segment, primarily driven by higher sales, including favorable mix, and improved operating leverage, partially offset by higher expenses associated with acquired businesses.

[0000068505-26-000021:mdna:79]
[same as prior period, unchanged from 0000068505-25-000052:mdna:84]

[0000068505-26-000021:mdna:80]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |
| Interest expense, net | $ | (104) |  |  | $ | (51) |  |

[0000068505-26-000021:mdna:81]
The $53 million increase in Interest expense, net in the first quarter of 2026 compared to the first quarter of 2025 was primarily driven by higher outstanding debt.

[0000068505-26-000021:mdna:82]
[same as prior period, unchanged from 0000068505-25-000052:mdna:87]

[0000068505-26-000021:mdna:83]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |
| Other, net | $ | 20 |  |  | $ | 16 |  |

[0000068505-26-000021:mdna:84]
The $4 million increase in Other, net in the first quarter of 2026 compared to the first quarter of 2025 was primarily driven by:

[0000068505-26-000021:mdna:85]
•a $25 million gain on foreign currency in the first quarter of 2026 compared to a $20 million loss on foreign currency in the first quarter of 2025; partially offset by

[0000068505-26-000021:mdna:86]
•a $27 million loss on derivatives in the first quarter of 2026 compared to a $13 million gain on derivatives in the first quarter of 2025.

[0000068505-26-000021:mdna:87]
[same as prior period, unchanged from 0000068505-25-000052:mdna:92]

[0000068505-26-000021:mdna:88]
|  | Three Months Ended |
| (In millions) | April 4, 2026 |  | March 29, 2025 |
| Income tax expense | $ | 73 |  |  | $ | 115 |  |

[0000068505-26-000021:mdna:89]
The effective tax rate for the three months ended April 4, 2026 of 17% was lower than the effective tax rate for the three months ended March 29, 2025 of 21%, primarily due to higher excess tax benefits of share-based compensation and an increased deduction for foreign-derived deduction-eligible income (formerly known as foreign-derived intangible income).

[0000068505-26-000021:mdna:90]
On July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law, introducing a broad range of changes to the U.S. corporate income tax framework. The legislation includes business provisions that impact our tax position, including tax cut extensions and modifications to the international tax framework and corporate income tax deductions. Certain provisions of this legislation were effective for the 2025 fiscal year, whereas other provisions became effective starting in 2026. For the three months ended April 4, 2026, the impact of the enacted legislation on our tax position was not material. We plan to continue to assess the ongoing impact of this legislation as further guidance is made available.

[0000068505-26-000021:mdna:91]
[same as prior period, unchanged from 0000068505-25-000052:mdna:162]

[0000068505-26-000021:mdna:92]
During the first quarter of 2026, we recorded net reorganization of business charges of $15 million, consisting of $10 million of charges in Other charges and $5 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations related to employee separation costs.

[0000068505-26-000021:mdna:93]
During the first quarter of 2025, we recorded net reorganization of business charges of $17 million, including $12 million of charges recorded within Other charges and $5 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $19 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals that are no longer needed.

[0000068505-26-000021:mdna:94]
[same as prior period, unchanged from 0000068505-25-000052:mdna:168]

[0000068505-26-000021:mdna:95]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Products and Systems Integration | $ | 11 |  |  | $ | 12 |  |  |  |  |  |
| Software and Services | 4 |  |  | 5 |  |  |  |  |  |
|  | $ | 15 |  |  | $ | 17 |  |  |  |  |  |

[0000068505-26-000021:mdna:96]
Cash payments for employee severance in connection with the reorganization of business plans were $12 million in the first quarter of 2026 and $14 million in the first quarter of 2025. The reorganization of business accrual at April 4, 2026 was $27 million related to employee separation costs that are expected to be paid primarily within one year.

[0000068505-26-000021:mdna:97]
[same as prior period, unchanged from 0000068505-25-000052:mdna:25]

[0000068505-26-000021:mdna:98]
[same as prior period, unchanged from 0000068505-25-000052:mdna:172]

[0000068505-26-000021:mdna:99]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 451 |  |  | $ | 510 |  |
| Investing activities | (183) |  |  | (477) |  |
| Financing activities | (525) |  |  | (597) |  |
| Effect of exchange rates on cash and cash equivalents | (22) |  |  | 26 |  |
| Decrease in cash and cash equivalents | $ | (279) |  |  | $ | (538) |  |

[0000068505-26-000021:mdna:100]
[same as prior period, unchanged from 0000068505-25-000052:mdna:174]

[0000068505-26-000021:mdna:101]
At April 4, 2026, $570 million of the $886 million cash and cash equivalents balance was held in the U.S. and $316 million was held in other countries.

[0000068505-26-000021:mdna:102]
[same as prior period, unchanged from 0000068505-25-000052:mdna:176]

[0000068505-26-000021:mdna:103]
The decrease in cash flows provided by operating activities from the first quarter of 2025 to the first quarter of 2026 was driven primarily by increased investments in inventory and higher interest and tax payments in the first quarter of 2026 compared to the first quarter of 2025, partially offset by higher earnings, net of non-cash charges.

[0000068505-26-000021:mdna:104]
[same as prior period, unchanged from 0000068505-25-000052:mdna:178]

[0000068505-26-000021:mdna:105]
The decrease in cash flows used for investing activities in the first quarter of 2026 compared to the first quarter of 2025 was primarily due to a $326 million decrease in cash used for acquisitions and investments.

[0000068505-26-000021:mdna:106]
[same as prior period, unchanged from 0000068505-25-000052:mdna:181]

[0000068505-26-000021:mdna:107]
The decrease in cash flows used for financing activities in the first quarter of 2026 compared to the cash flows used for financing activities in the first quarter of 2025 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-26-000021:mdna:108]
•$207 million decrease in share repurchases in the first quarter of 2026 compared to the first quarter of 2025; and

[0000068505-26-000021:mdna:109]
•$84 million decrease in cash used for the issuance of common stock, net of tax, in the first quarter of 2026 compared to the first quarter of 2025; partially offset by

[0000068505-26-000021:mdna:110]
•$19 million increase in the payment of dividends in the first quarter of 2026 compared to the first quarter of 2025; and

[0000068505-26-000021:mdna:111]
•$200 million repayment of short-term debt driven by the repayment of our 364-day term loan in the first quarter of 2026 which did not occur in the first quarter of 2025.

[0000068505-26-000021:mdna:112]
[same as prior period, unchanged from 0000068505-25-000052:mdna:189]

[0000068505-26-000021:mdna:113]
The following table summarizes the proceeds received from sales of long-term customer financing receivables for the three months ended April 4, 2026 and March 29, 2025:

[0000068505-26-000021:mdna:114]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Long-term receivables sales proceeds | $ | 50 |  |  | $ | 24 |  |  |  |  |  |

[0000068505-26-000021:mdna:115]
[same as prior period, unchanged from 0000068505-25-000052:mdna:192]

[0000068505-26-000021:mdna:116]
We had outstanding debt of $9.0 billion at April 4, 2026, of which $550 million was current. We had outstanding debt of $9.2 billion at December 31, 2025, of which $749 million was current.

[0000068505-26-000021:mdna:117]
On June 16, 2025, we issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032, and $900 million of 5.55% senior notes due 2035. We recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-26-000021:mdna:118]
On August 6, 2025, we borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. On January 30, 2026, we repaid $200 million of the $750 million 364-day term loan, reducing the outstanding principal balance to $550 million. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. We were in compliance with our financial covenants as of April 4, 2026. During the three months ended April 4, 2026, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 4.77% and 4.99%, respectively.

[0000068505-26-000021:mdna:119]
We have an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement (as defined below), under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 4, 2026, we have no outstanding debt under the commercial paper program.

[0000068505-26-000021:mdna:120]
We have a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of April 4, 2026.

[0000068505-26-000021:mdna:121]
[same as prior period, unchanged from 0000068505-25-000052:mdna:199]

[0000068505-26-000021:mdna:122]
[same as prior period, unchanged from 0000068505-25-000052:mdna:200]

[0000068505-26-000021:mdna:123]
During the three months ended April 4, 2026, we repurchased approximately 0.3 million shares at an average price of $440.94 per share for an aggregate amount of $118 million, excluding transaction costs and excise tax. As of April 4, 2026, we had used approximately $17.0 billion of the share repurchase authority to repurchase shares, leaving $1.0 billion of authority available for future repurchases.

[0000068505-26-000021:mdna:124]
[same as prior period, unchanged from 0000068505-25-000052:mdna:202]

[0000068505-26-000021:mdna:125]
During the three months ended April 4, 2026, we paid $201 million in cash dividends to holders of our common stock. Subsequent to the end of the quarter, we paid an additional $201 million in cash dividends to holders of our common stock.

[0000068505-26-000021:mdna:126]
[same as prior period, unchanged from 0000068505-25-000052:mdna:204]

[0000068505-26-000021:mdna:127]
[same as prior period, unchanged from 0000068505-25-000052:mdna:205]

[0000068505-26-000021:mdna:128]
[same as prior period, unchanged from 0000068505-25-000052:mdna:206]

[0000068505-26-000021:mdna:129]
[same as prior period, unchanged from 0000068505-25-000052:mdna:208]

[0000068505-26-000021:mdna:130]
We had outstanding commitments to provide long-term financing to third parties totaling $200 million at April 4, 2026, compared to $179 million at December 31, 2025.

[0000068505-26-000021:mdna:131]
[same as prior period, unchanged from 0000068505-25-000052:mdna:210]

[0000068505-26-000021:mdna:132]
See “Recent Accounting Pronouncements” and "Recently Adopted Accounting Pronouncements" in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
