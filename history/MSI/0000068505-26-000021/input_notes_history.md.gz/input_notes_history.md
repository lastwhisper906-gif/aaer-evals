# MSI note change history — 0000068505-25-000052 → 0000068505-26-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-07):
[0000068505-26-000021:note_history:1]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor, ultimately resulting in an award to the Company of $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.
  (was, 2025-10-30, similarity 0.9408):
[0000068505-25-000052:note_history:1]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for the Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor and awarded the Company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

- added (2026-05-07):
[0000068505-26-000021:note_history:2]
In 2024, after both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), the Court of Appeals, among other items, affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, and directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, which remains subject to ruling by the District Court. As of April 4, 2026, as a result of this civil litigation and 2020 bankruptcy proceedings by Hytera America, Inc. and Hytera Communications America (West), Inc., Hytera had paid over $212 million against this award, $40 million of which was paid in the first quarter of 2026. Net of withholding taxes, the Company had received over $192 million as of April 4, 2026, $36 million of which was received in the first quarter of 2026. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations.

- added (2026-05-07):
[0000068505-26-000021:note_history:3]
Further, in 2022, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on Hytera’s products (“I-Series”) that use the Company’s stolen trade secrets, applicable to I-Series products sold from July 1, 2019 forward. In 2024, the Company received royalties of $61 million related to the I-Series products, which was recorded as a gain within Other charges within the Consolidated Statement of Operations. Beginning in 2025, a favorable ruling in a related legal proceeding in the District Court (which Hytera has subsequently appealed to the Court of Appeals) also ordered Hytera to pay the Company for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera’s currently shipping products (“H-Series”), and Hytera has subsequently reported approximately $110 million in royalties subject to the Court's order. While several aspects of the court proceedings related to both the I-Series and H-Series are subject to appeal, the Company continues to seek collection of the amounts owed by Hytera through the ongoing legal process.

- added (2026-05-07):
[0000068505-26-000021:note_history:4]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. At Hytera's sentencing on March 5, 2026, which included Hytera’s sentencing to five years of probation, the District Court found that Hytera caused the Company to lose $214 million in profits, but that this restitution amount was offset in full by payments previously made by Hytera towards the civil judgment. As a condition of Hytera’s probation, the District Court ordered Hytera to pay the Company $100 million in 2026 towards the civil judgment and $100 million for each succeeding year until the civil judgment is paid in full. The District Court also fined Hytera $50 million, to be paid to the U.S. government after the Company's civil judgment is fully paid. The Company has appealed the District Court’s sentencing order.

- removed (2026-05-07):
[0000068505-25-000052:note_history:5]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products ("I-Series") that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The Company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations. Hytera has made de minimis royalty payments related to the I-Series products directly to the Company between January 2025 and July 2025.

- removed (2026-05-07):
[0000068505-25-000052:note_history:6]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation, turnover of Hytera assets to the Company, and injunction are currently briefed. On October 14-15, 2025, the District Court held hearings on these issues, but has not yet issued any rulings.

- removed (2026-05-07):
[0000068505-25-000052:note_history:7]
In 2025, Hytera made payments towards amounts awarded to the Company and owed by Hytera pursuant to court orders related to I-Series products. In the third quarter of 2025, the Company received payments of $74 million, resulting in an aggregate of $94 million of payments received in the nine months ended September 27, 2025. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. The Company continues to seek collection of the judgment through the ongoing legal process.

- removed (2026-05-07):
[0000068505-25-000052:note_history:8]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products ("H-Series"). On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain H-Series products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions.

- removed (2026-05-07):
[0000068505-25-000052:note_history:9]
The District Court held hearings in August 2024, concerning whether Hytera's currently shipping H-Series products continue to misuse the Company's trade secrets and copyrighted source code. On August 25, 2025, the District Court held Hytera in civil contempt for violation of the District Court’s royalty order and ordered Hytera to pay the Company approximately $70 million for unpaid royalties and interest for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera's H-Series products. Hytera has appealed the District Court’s order to the Court of Appeals. Hytera’s appeal does not automatically stay its obligation to pay the $70 million. On October 14-15, 2025, the District Court heard arguments on whether Hytera must pay the $70 million into escrow, or directly to the Company as a payment towards amounts awarded to the Company and owed by Hytera pursuant to prior court orders, but has not yet issued a ruling.

- removed (2026-05-07):
[0000068505-25-000052:note_history:10]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 24th and 25th, 2025. Pursuant to the plea agreement, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-07):
[0000068505-26-000021:note_history:11]
Basis of Presentation
The condensed consolidated financial statements as of April 4, 2026 and for the three months ended April 4, 2026 and March 29, 2025 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. and its controlled subsidiaries (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2025-10-30, similarity 0.906):
[0000068505-25-000052:note_history:11]
Basis of Presentation
The condensed consolidated financial statements as of September 27, 2025 and for the three and nine months ended September 27, 2025 and September 28, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2026-05-07):
[0000068505-26-000021:note_history:12]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2025 (the "Form 10-K"). The results of operations for the three months ended April 4, 2026 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2025-10-30, similarity 0.9592):
[0000068505-25-000052:note_history:12]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three and nine months ended September 27, 2025 are not necessarily indicative of the operating results to be expected for the full year.

- added (2026-05-07):
[0000068505-26-000021:note_history:13]
The Company manages the business through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, the Company reports net sales across three principal product lines:

- added (2026-05-07):
[0000068505-26-000021:note_history:14]
•Mission Critical Networks ("MCN"): Infrastructure, mobile ad-hoc network ("MANET") technology, devices (two-way radio and broadband, including both for public safety and professional and commercial radio ("PCR")), software and artificial intelligence ("AI")-powered capabilities. MCN includes installation and integration, backed by managed and support services, to help assure mission-critical communications availability, security and resiliency;

- added (2026-05-07):
[0000068505-26-000021:note_history:15]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, video monitoring, software and AI-powered analytics that enable visibility of events and focus attention on what's important, to inform faster and more accurate decisions and actions; and

- added (2026-05-07):
[0000068505-26-000021:note_history:16]
•Command Center: Command center solutions, software applications and AI-powered capabilities, that unify voice and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents while helping to accelerate workflows and improve the accuracy, speed and trust of decisions.

- added (2026-05-07):
[0000068505-26-000021:note_history:17]
Recent Announcements

- added (2026-05-07):
[0000068505-26-000021:note_history:18]
On March 26, 2026, the Company entered into a definitive agreement to acquire the land mobile radio networks services business from Bell Mobility, the wireless subsidiary of Bell Canada and BCE Inc., for $675 million Canadian dollars, subject to customary adjustments and a deferred net working capital settlement. The land mobile radio networks services business provides secure, resilient and highly reliable LMR communications for customers across Canada. Subject to the closing of the transaction, this business will be part of both the Products and Systems Integration segment and the Software and Services segment. The acquisition is expected to be completed in the fourth quarter of 2026.

- added (2026-05-07):
[0000068505-26-000021:note_history:19]
On March 24, 2026, the Company acquired Hyper for $23 million, net of cash acquired. Hyper provides conversational, agentic AI designed to reduce the burden on understaffed public safety answering points ("PSAPs") by handling non-emergency calls. The Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. The acquisition expands the Company's use of agentic AI across its Command Center portfolio and mission-critical AI, Assist. This business is part of the Software and Services segment.

- added (2026-05-07):
[0000068505-26-000021:note_history:20]
On March 11, 2026, the Company acquired Exacom, a provider of cloud-native voice and multimedia recording and logging solutions for mission-critical communications for $67 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's public safety ecosystem by consolidating call logs, recording 911 audio and radio traffic into a cloud-based solution to unify voice and video across the incident lifecycle. This business is part of the Software and Services segment.

- added (2026-05-07):
[0000068505-26-000021:note_history:21]
On November 18, 2025, the Company acquired Blue Eye, a provider of AI-powered enterprise remote video monitoring ("RVM") services for $79 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's video security portfolio, serving a wide range of enterprises with real-time intelligence to help reduce loss and damage, mitigate risk and boost profitability. This business is part of the Software and Services segment.

- changed (2026-05-07):
[0000068505-26-000021:note_history:22]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired and customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million. Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be paid in shares of common stock. This business is part of both the Products and Systems Integration segment and the Software and Services segment.
  (was, 2025-10-30, similarity 0.9986):
[0000068505-25-000052:note_history:22]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million. Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be paid in shares of common stock. This business is part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2026-05-07):
[0000068505-26-000021:note_history:23]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software" to modernize the accounting for internal-use software costs. The ASU is effective for fiscal years beginning after December 15, 2027 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.
  (was, 2025-10-30, similarity 0.9984):
[0000068505-25-000052:note_history:23]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software" to modernize the accounting for internal-use software costs. The ASU is effective for fiscal years beginning after December 15, 2027 and interim periods with annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

- added (2026-05-07):
[0000068505-26-000021:note_history:24]
Recently Adopted Accounting Pronouncements

- changed (2026-05-07):
[0000068505-26-000021:note_history:25]
In July 2025, the FASB issued ASU No. 2025-05, "Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets" to introduce a practical expedient in the estimation of expected credit losses for current accounts receivable and current contract assets. The ASU is effective for fiscal years beginning after December 15, 2025 and interim periods within annual reporting periods beginning after December 15, 2025, with early adoption permitted. The Company has elected the practical expedient to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset, which did not have a material impact to the Company's current expected credit losses.
  (was, 2025-10-30, similarity 0.7445):
[0000068505-25-000052:note_history:25]
In July 2025, the FASB issued ASU No. 2025-05, "Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets" to introduce a practical expedient in the estimation of expected credit losses for current accounts receivable and current contract assets. The ASU is effective for fiscal years beginning after December 15, 2025 and interim periods with annual reporting periods beginning after December 15, 2025, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

- added (2026-05-07):
[0000068505-26-000021:note_history:26]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. The Company adopted ASU No. 2023-09 for the year ended December 31, 2025 and applied the retrospective transition method. As the provisions of ASU 2023-09 relate primarily to annual disclosure requirements, the adoption has no impact on "Part 1 - Financial Information" of this Form 10-Q.

- removed (2026-05-07):
[0000068505-25-000052:note_history:27]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services". Within these segments the Company has three principal product lines in which the Company reports net sales: Mission Critical Networks (“MCN”), Video Security and Access Control ("Video"), and Command Center. With the acquisition of Silvus Technologies Holdings Inc. (“Silvus”) in August 2025, the Company will now report net sales from its principal product lines by combining the former Land Mobile Radio Communications and newly acquired Silvus under the new technology name Mission Critical Networks. This name change does not require any financial information to be reclassified from previous periods.

- removed (2026-05-07):
[0000068505-25-000052:note_history:28]
•MCN: Infrastructure, mobile ad-hoc network technology ("MANET"), devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software, inclusive of installation and integration, and backed by managed and support services to help assure mission-critical communications availability, security and resiliency.

- removed (2026-05-07):
[0000068505-25-000052:note_history:29]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence ("AI")-powered analytics that enable visibility to what's happening and bring attention to what’s important to help inform decisions and actions.

- removed (2026-05-07):
[0000068505-25-000052:note_history:30]
•Command Center: Command center solutions and software applications, including AI-powered analytics, that unify voice, video and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents to help accelerate workflows and improve the accuracy and speed of decisions.

- removed (2026-05-07):
[0000068505-25-000052:note_history:31]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.

- removed (2026-05-07):
[0000068505-25-000052:note_history:32]
On July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $92 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

- removed (2026-05-07):
[0000068505-25-000052:note_history:33]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

- removed (2026-05-07):
[0000068505-25-000052:note_history:34]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers, and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and Systems Integration segment.

- removed (2026-05-07):
[0000068505-25-000052:note_history:35]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.

- removed (2026-05-07):
[0000068505-25-000052:note_history:36]
Recently Adopted Accounting Pronouncements
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The Company adopted ASU No. 2023-07 for the year ended December 31, 2024 and applied the required retrospective transition method. Refer to Note 13, "Segment Information" in this "Part 1 — Financial Information" of this Form 10-Q for the related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-07):
[0000068505-26-000021:note_history:37]
|  | April 4, 2026 |  | December 31, 2025 |
| 364 day term loan | $ | 550 |  |  | $ | 749 |  |
| 4.6% senior notes due 2028 | 698 |  |  | 698 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| Term loan due 2028 | 749 |  |  | 748 |  |
| 5.0% senior notes due 2029 | 398 |  |  | 397 |  |
| 4.6% senior notes due 2029 | 801 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 896 |  |
| 4.85% senior notes due 2030 | 596 |  |  | 595 |  |
| 2.75% senior notes due 2031 | 847 |  |  | 847 |  |
| 5.2% senior notes due 2032 | 496 |  |  | 496 |  |
| 5.6% senior notes due 2032 | 597 |  |  | 597 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 894 |  |
| 5.55% senior notes due 2035 | 892 |  |  | 892 |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 8,966 |  |  | 9,163 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (550) |  |  | (749) |  |
| Long-term debt | $ | 8,415 |  |  | $ | 8,413 |  |

- added (2026-05-07):
[0000068505-26-000021:note_history:38]
On August 6, 2025, the Company borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. On January 30, 2026, the Company repaid $200 million of the $750 million 364-day term loan, reducing the outstanding principal balance to $550 million. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. The Company was in compliance with its financial covenants as of April 4, 2026. During the three months ended April 4, 2026, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 4.77% and 4.99%, respectively.

- added (2026-05-07):
[0000068505-26-000021:note_history:39]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement (as defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 4, 2026, the Company had no outstanding debt under the commercial paper program.
As of April 4, 2026, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 4, 2026.

- removed (2026-05-07):
[0000068505-25-000052:note_history:40]
|  | September 27, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | — |  |  | 70 |  |
| 364-day term loan | 749 |  |  | — |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| Term loan due 2028 | 748 |  |  | — |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 597 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
| Other short-term borrowings | 179 |  |  | — |  |
|  | 9,340 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (928) |  |  | (322) |  |
| Long-term debt | $ | 8,411 |  |  | $ | 5,675 |  |

- removed (2026-05-07):
[0000068505-25-000052:note_history:41]
On August 6, 2025 the Company borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. The Company was in compliance with its financial covenants as of September 27, 2025. During the three months ended September 27, 2025, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 5.30% and 5.25%, respectively.

- removed (2026-05-07):
[0000068505-25-000052:note_history:42]
During the three months ended September 27, 2025, the Company repaid the $70 million aggregate principal amount of the 6.5% debentures due 2025. Additionally, during the nine months ended September 27, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% debentures due 2025.

- removed (2026-05-07):
[0000068505-25-000052:note_history:43]
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 27, 2025. 
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 27, 2025, the Company had outstanding other short-term borrowings of $179 million, inclusive of the commercial paper program, with a weighted-average interest rate of 4.52% during the three months ended September 27, 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-07):
[0000068505-26-000021:note_history:44]
|  | April 4, 2026 |  | December 31, 2025 |
| 364 day term loan | $ | 550 |  |  | $ | 749 |  |
| 4.6% senior notes due 2028 | 698 |  |  | 698 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| Term loan due 2028 | 749 |  |  | 748 |  |
| 5.0% senior notes due 2029 | 398 |  |  | 397 |  |
| 4.6% senior notes due 2029 | 801 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 896 |  |
| 4.85% senior notes due 2030 | 596 |  |  | 595 |  |
| 2.75% senior notes due 2031 | 847 |  |  | 847 |  |
| 5.2% senior notes due 2032 | 496 |  |  | 496 |  |
| 5.6% senior notes due 2032 | 597 |  |  | 597 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 894 |  |
| 5.55% senior notes due 2035 | 892 |  |  | 892 |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 8,966 |  |  | 9,163 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (550) |  |  | (749) |  |
| Long-term debt | $ | 8,415 |  |  | $ | 8,413 |  |

- removed (2026-05-07):
[0000068505-25-000052:note_history:45]
|  | September 27, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | — |  |  | 70 |  |
| 364-day term loan | 749 |  |  | — |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| Term loan due 2028 | 748 |  |  | — |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 597 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
| Other short-term borrowings | 179 |  |  | — |  |
|  | 9,340 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (928) |  |  | (322) |  |
| Long-term debt | $ | 8,411 |  |  | $ | 5,675 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-07):
[0000068505-26-000021:note_history:46]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 4, 2026 and March 29, 2025, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2025-10-30, similarity 0.9143):
[0000068505-25-000052:note_history:46]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 27, 2025 and September 28, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2026-05-07):
[0000068505-26-000021:note_history:47]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,064 |  |  | $ | 793 |  |  | $ | 1,857 |  |  | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |
| International | 495 |  |  | 362 |  |  | 857 |  |  | 368 |  |  | 308 |  |  | 676 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,288 |  |  | $ | 680 |  |  | $ | 1,968 |  |  | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |
| Video | 271 |  |  | 239 |  |  | 510 |  |  | 231 |  |  | 210 |  |  | 441 |  |
| Command Center | — |  |  | 236 |  |  | 236 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 944 |  |  | $ | 1,053 |  |  | $ | 1,997 |  |  | $ | 1,016 |  |  | $ | 907 |  |  | $ | 1,923 |  |
| Indirect | 615 |  |  | 102 |  |  | 717 |  |  | 530 |  |  | 75 |  |  | 605 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
  (was, 2025-10-30, similarity 0.9593):
[0000068505-25-000052:note_history:47]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,789 |  |  | $ | 2,211 |  |  | $ | 6,000 |  |  | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |
| International | 1,306 |  |  | 996 |  |  | 2,302 |  |  | 1,302 |  |  | 888 |  |  | 2,190 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 4,269 |  |  | $ | 1,878 |  |  | $ | 6,147 |  |  | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |
| Video | 826 |  |  | 672 |  |  | 1,498 |  |  | 821 |  |  | 553 |  |  | 1,374 |  |
| Command Center | — |  |  | 657 |  |  | 657 |  |  | — |  |  | 581 |  |  | 581 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 3,233 |  |  | $ | 2,929 |  |  | $ | 6,162 |  |  | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |
| Indirect | 1,862 |  |  | 278 |  |  | 2,140 |  |  | 1,964 |  |  | 256 |  |  | 2,220 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |

- removed (2026-05-07):
[0000068505-25-000052:note_history:48]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,360 |  |  | $ | 761 |  |  | $ | 2,121 |  |  | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |
| International | 537 |  |  | 351 |  |  | 888 |  |  | 480 |  |  | 303 |  |  | 783 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,598 |  |  | $ | 643 |  |  | $ | 2,241 |  |  | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |
| Video | 299 |  |  | 235 |  |  | 534 |  |  | 292 |  |  | 208 |  |  | 500 |  |
| Command Center | — |  |  | 234 |  |  | 234 |  |  | — |  |  | 202 |  |  | 202 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,187 |  |  | $ | 1,006 |  |  | 2,193 |  |  | $ | 1,108 |  |  | $ | 917 |  |  | $ | 2,025 |  |
| Indirect | 710 |  |  | 106 |  |  | 816 |  |  | 676 |  |  | 89 |  |  | 765 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-07):
[0000068505-26-000021:note_history:49]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 4, 2026 and March 29, 2025, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2025-10-30, similarity 0.9143):
[0000068505-25-000052:note_history:49]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 27, 2025 and September 28, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2026-05-07):
[0000068505-26-000021:note_history:50]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,064 |  |  | $ | 793 |  |  | $ | 1,857 |  |  | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |
| International | 495 |  |  | 362 |  |  | 857 |  |  | 368 |  |  | 308 |  |  | 676 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,288 |  |  | $ | 680 |  |  | $ | 1,968 |  |  | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |
| Video | 271 |  |  | 239 |  |  | 510 |  |  | 231 |  |  | 210 |  |  | 441 |  |
| Command Center | — |  |  | 236 |  |  | 236 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 944 |  |  | $ | 1,053 |  |  | $ | 1,997 |  |  | $ | 1,016 |  |  | $ | 907 |  |  | $ | 1,923 |  |
| Indirect | 615 |  |  | 102 |  |  | 717 |  |  | 530 |  |  | 75 |  |  | 605 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
  (was, 2025-10-30, similarity 0.9593):
[0000068505-25-000052:note_history:50]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,789 |  |  | $ | 2,211 |  |  | $ | 6,000 |  |  | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |
| International | 1,306 |  |  | 996 |  |  | 2,302 |  |  | 1,302 |  |  | 888 |  |  | 2,190 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 4,269 |  |  | $ | 1,878 |  |  | $ | 6,147 |  |  | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |
| Video | 826 |  |  | 672 |  |  | 1,498 |  |  | 821 |  |  | 553 |  |  | 1,374 |  |
| Command Center | — |  |  | 657 |  |  | 657 |  |  | — |  |  | 581 |  |  | 581 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 3,233 |  |  | $ | 2,929 |  |  | $ | 6,162 |  |  | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |
| Indirect | 1,862 |  |  | 278 |  |  | 2,140 |  |  | 1,964 |  |  | 256 |  |  | 2,220 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |

- added (2026-05-07):
[0000068505-26-000021:note_history:51]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. Remaining performance obligations are equal to disclosed backlog, except within our Software and Services contracts where multi-year contract terms may be limited by the customer's ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The transaction value associated with remaining performance obligations which were not yet satisfied as of April 4, 2026 was $9.5 billion, of which $4.1 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented and services are performed.

- changed (2026-05-07):
[0000068505-26-000021:note_history:52]
| (In millions) | April 4, 2026 |  | December 31, 2025 |  |  |  |  |
| Accounts receivable, net | $ | 2,046 |  |  | $ | 2,200 |  |  |  |  |  |
| Contract assets | 1,388 |  |  | 1,574 |  |  |  |  |  |
| Contract liabilities | 2,296 |  |  | 2,265 |  |  |  |  |  |
| Non-current contract liabilities | 761 |  |  | 751 |  |  |  |  |  |
  (was, 2025-10-30, similarity 0.9772):
[0000068505-25-000052:note_history:52]
| (In millions) | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 2,018 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,515 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 2,074 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 670 |  |  | 496 |  |  |  |  |  |

- added (2026-05-07):
[0000068505-26-000021:note_history:53]
Revenue recognized during the three months ended April 4, 2026 which was previously included in Contract liabilities as of December 31, 2025 was $691 million, compared to $537 million of revenue recognized during the three months ended March 29, 2025 which was previously included in Contract liabilities as of December 31, 2024. Revenue of $2 million was recognized during the three months ended April 4, 2026 related to performance obligations satisfied, or partially satisfied, in previous periods,

- added (2026-05-07):
[0000068505-26-000021:note_history:54]
compared to $9 million reversed for the three months ended March 29, 2025, primarily driven by changes in the estimates of progress on system contracts.

- changed (2026-05-07):
[0000068505-26-000021:note_history:55]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 4, 2026 and March 29, 2025.
  (was, 2025-10-30, similarity 0.899):
[0000068505-25-000052:note_history:55]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 27, 2025 and September 28, 2024.

- changed (2026-05-07):
[0000068505-26-000021:note_history:56]
| (In millions) | April 4, 2026 |  | December 31, 2025 |  |  |  |  |
| Current contract cost assets | $ | 81 |  |  | $ | 72 |  |  |  |  |  |
| Non-current contract cost assets | 147 |  |  | 152 |  |  |  |  |  |
  (was, 2025-10-30, similarity 0.9719):
[0000068505-25-000052:note_history:56]
| (In millions) | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 77 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 134 |  |  | 141 |  |  |  |  |  |

- added (2026-05-07):
[0000068505-26-000021:note_history:57]
Contract cost assets include incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to eight years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $14 million for the three months ended April 4, 2026, and $13 million for the three months ended March 29, 2025, respectively.

- removed (2026-05-07):
[0000068505-25-000052:note_history:58]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,360 |  |  | $ | 761 |  |  | $ | 2,121 |  |  | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |
| International | 537 |  |  | 351 |  |  | 888 |  |  | 480 |  |  | 303 |  |  | 783 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,598 |  |  | $ | 643 |  |  | $ | 2,241 |  |  | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |
| Video | 299 |  |  | 235 |  |  | 534 |  |  | 292 |  |  | 208 |  |  | 500 |  |
| Command Center | — |  |  | 234 |  |  | 234 |  |  | — |  |  | 202 |  |  | 202 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,187 |  |  | $ | 1,006 |  |  | 2,193 |  |  | $ | 1,108 |  |  | $ | 917 |  |  | $ | 2,025 |  |
| Indirect | 710 |  |  | 106 |  |  | 816 |  |  | 676 |  |  | 89 |  |  | 765 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |

- removed (2026-05-07):
[0000068505-25-000052:note_history:59]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 27, 2025 was $8.9 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 27, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of September 27, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- removed (2026-05-07):
[0000068505-25-000052:note_history:60]
Revenue recognized during the three months ended September 27, 2025 which was previously included in Contract liabilities as of June 28, 2025 was $637 million, compared to $572 million of revenue recognized during the three months ended September 28, 2024 which was previously included in Contract liabilities as of June 29, 2024. The Company recognized revenue of $1.2 billion during each of the nine months ended September 27, 2025 and September 28, 2024, which was previously included in Contract liabilities as of December 31, 2024 and December 31, 2023, respectively. Revenue of $7 million was recognized during the three months ended September 27, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $6 million recognized for the three months ended September 28, 2024, primarily driven by changes in the estimates of progress on system contracts. Revenue of $7 million was reversed during the nine months ended September 27, 2025 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $11 million of reversals for the nine months ended September 28, 2024.

- removed (2026-05-07):
[0000068505-25-000052:note_history:61]
Amortization of contract cost assets was $13 million and $39 million for the three and nine months ended September 27, 2025, respectively, and $13 million and $38 million for the three and nine months ended September 28, 2024, respectively.
