# MSI notes — 0000068505-26-000021


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-26-000021:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of April 4, 2026 and for the three months ended April 4, 2026 and March 29, 2025 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. and its controlled subsidiaries (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-26-000021:notes:2]
[same as prior period, unchanged from 0000068505-25-000052:notes:2]

[0000068505-26-000021:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2025 (the "Form 10-K"). The results of operations for the three months ended April 4, 2026 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-26-000021:notes:4]
[same as prior period, unchanged from 0000068505-25-000052:notes:4]

[0000068505-26-000021:notes:5]
[same as prior period, unchanged from 0000068505-25-000052:notes:5]

[0000068505-26-000021:notes:6]
The Company manages the business through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, the Company reports net sales across three principal product lines:

[0000068505-26-000021:notes:7]
•Mission Critical Networks ("MCN"): Infrastructure, mobile ad-hoc network ("MANET") technology, devices (two-way radio and broadband, including both for public safety and professional and commercial radio ("PCR")), software and artificial intelligence ("AI")-powered capabilities. MCN includes installation and integration, backed by managed and support services, to help assure mission-critical communications availability, security and resiliency;

[0000068505-26-000021:notes:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, video monitoring, software and AI-powered analytics that enable visibility of events and focus attention on what's important, to inform faster and more accurate decisions and actions; and

[0000068505-26-000021:notes:9]
•Command Center: Command center solutions, software applications and AI-powered capabilities, that unify voice and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents while helping to accelerate workflows and improve the accuracy, speed and trust of decisions.

[0000068505-26-000021:notes:10]
Recent Announcements

[0000068505-26-000021:notes:11]
On March 26, 2026, the Company entered into a definitive agreement to acquire the land mobile radio networks services business from Bell Mobility, the wireless subsidiary of Bell Canada and BCE Inc., for $675 million Canadian dollars, subject to customary adjustments and a deferred net working capital settlement. The land mobile radio networks services business provides secure, resilient and highly reliable LMR communications for customers across Canada. Subject to the closing of the transaction, this business will be part of both the Products and Systems Integration segment and the Software and Services segment. The acquisition is expected to be completed in the fourth quarter of 2026.

[0000068505-26-000021:notes:12]
[same as prior period, unchanged from 0000068505-25-000052:notes:10]

[0000068505-26-000021:notes:13]
On March 24, 2026, the Company acquired Hyper for $23 million, net of cash acquired. Hyper provides conversational, agentic AI designed to reduce the burden on understaffed public safety answering points ("PSAPs") by handling non-emergency calls. The Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. The acquisition expands the Company's use of agentic AI across its Command Center portfolio and mission-critical AI, Assist. This business is part of the Software and Services segment.

[0000068505-26-000021:notes:14]
On March 11, 2026, the Company acquired Exacom, a provider of cloud-native voice and multimedia recording and logging solutions for mission-critical communications for $67 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's public safety ecosystem by consolidating call logs, recording 911 audio and radio traffic into a cloud-based solution to unify voice and video across the incident lifecycle. This business is part of the Software and Services segment.

[0000068505-26-000021:notes:15]
On November 18, 2025, the Company acquired Blue Eye, a provider of AI-powered enterprise remote video monitoring ("RVM") services for $79 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's video security portfolio, serving a wide range of enterprises with real-time intelligence to help reduce loss and damage, mitigate risk and boost profitability. This business is part of the Software and Services segment.

[0000068505-26-000021:notes:16]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired and customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million. Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be paid in shares of common stock. This business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-26-000021:notes:17]
[same as prior period, unchanged from 0000068505-25-000052:notes:12]

[0000068505-26-000021:notes:18]
[same as prior period, unchanged from 0000068505-25-000052:notes:13]

[0000068505-26-000021:notes:19]
[same as prior period, unchanged from 0000068505-25-000052:notes:18]

[0000068505-26-000021:notes:20]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software" to modernize the accounting for internal-use software costs. The ASU is effective for fiscal years beginning after December 15, 2027 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-26-000021:notes:21]
In November 2024, the FASB issued ASU No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date," which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-26-000021:notes:22]
Recently Adopted Accounting Pronouncements

[0000068505-26-000021:notes:23]
In July 2025, the FASB issued ASU No. 2025-05, "Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets" to introduce a practical expedient in the estimation of expected credit losses for current accounts receivable and current contract assets. The ASU is effective for fiscal years beginning after December 15, 2025 and interim periods within annual reporting periods beginning after December 15, 2025, with early adoption permitted. The Company has elected the practical expedient to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset, which did not have a material impact to the Company's current expected credit losses.

[0000068505-26-000021:notes:24]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. The Company adopted ASU No. 2023-09 for the year ended December 31, 2025 and applied the retrospective transition method. As the provisions of ASU 2023-09 relate primarily to annual disclosure requirements, the adoption has no impact on "Part 1 - Financial Information" of this Form 10-Q.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-26-000021:notes:25]
[same as prior period, unchanged from 0000068505-25-000052:notes:24]

[0000068505-26-000021:notes:26]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended April 4, 2026 and March 29, 2025, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-26-000021:notes:27]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,064 |  |  | $ | 793 |  |  | $ | 1,857 |  |  | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |
| International | 495 |  |  | 362 |  |  | 857 |  |  | 368 |  |  | 308 |  |  | 676 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,288 |  |  | $ | 680 |  |  | $ | 1,968 |  |  | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |
| Video | 271 |  |  | 239 |  |  | 510 |  |  | 231 |  |  | 210 |  |  | 441 |  |
| Command Center | — |  |  | 236 |  |  | 236 |  |  | — |  |  | 186 |  |  | 186 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 944 |  |  | $ | 1,053 |  |  | $ | 1,997 |  |  | $ | 1,016 |  |  | $ | 907 |  |  | $ | 1,923 |  |
| Indirect | 615 |  |  | 102 |  |  | 717 |  |  | 530 |  |  | 75 |  |  | 605 |  |
|  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |

[0000068505-26-000021:notes:28]
[same as prior period, unchanged from 0000068505-25-000052:notes:28]

[0000068505-26-000021:notes:29]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. Remaining performance obligations are equal to disclosed backlog, except within our Software and Services contracts where multi-year contract terms may be limited by the customer's ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The transaction value associated with remaining performance obligations which were not yet satisfied as of April 4, 2026 was $9.5 billion, of which $4.1 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented and services are performed.

[0000068505-26-000021:notes:30]
[same as prior period, unchanged from 0000068505-25-000052:notes:30]

[0000068505-26-000021:notes:31]
| (In millions) | April 4, 2026 |  | December 31, 2025 |  |  |  |  |
| Accounts receivable, net | $ | 2,046 |  |  | $ | 2,200 |  |  |  |  |  |
| Contract assets | 1,388 |  |  | 1,574 |  |  |  |  |  |
| Contract liabilities | 2,296 |  |  | 2,265 |  |  |  |  |  |
| Non-current contract liabilities | 761 |  |  | 751 |  |  |  |  |  |

[0000068505-26-000021:notes:32]
[same as prior period, unchanged from 0000068505-25-000052:notes:32]

[0000068505-26-000021:notes:33]
Revenue recognized during the three months ended April 4, 2026 which was previously included in Contract liabilities as of December 31, 2025 was $691 million, compared to $537 million of revenue recognized during the three months ended March 29, 2025 which was previously included in Contract liabilities as of December 31, 2024. Revenue of $2 million was recognized during the three months ended April 4, 2026 related to performance obligations satisfied, or partially satisfied, in previous periods,

[0000068505-26-000021:notes:34]
compared to $9 million reversed for the three months ended March 29, 2025, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-26-000021:notes:35]
There were no material expected credit losses recorded on contract assets during each of the three months ended April 4, 2026 and March 29, 2025.

[0000068505-26-000021:notes:36]
[same as prior period, unchanged from 0000068505-25-000052:notes:35]

[0000068505-26-000021:notes:37]
| (In millions) | April 4, 2026 |  | December 31, 2025 |  |  |  |  |
| Current contract cost assets | $ | 81 |  |  | $ | 72 |  |  |  |  |  |
| Non-current contract cost assets | 147 |  |  | 152 |  |  |  |  |  |

[0000068505-26-000021:notes:38]
Contract cost assets include incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to eight years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $14 million for the three months ended April 4, 2026, and $13 million for the three months ended March 29, 2025, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-26-000021:notes:39]
Leases
Components of Lease Expense

[0000068505-26-000021:notes:40]
|  | Three Months Ended |  |  |
| (in millions) | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 41 |  |  | $ | 35 |  |  |  |  |  |
| Short-term lease cost | 1 |  |  | — |  |  |  |  |  |
| Variable cost | 8 |  |  | 12 |  |  |  |  |  |
| Sublease income | (1) |  |  | (2) |  |  |  |  |  |
| Net lease expense from operating leases | $ | 49 |  |  | $ | 45 |  |  |  |  |  |

[0000068505-26-000021:notes:41]
Lease Assets and Liabilities

[0000068505-26-000021:notes:42]
| (in millions) |  | Statement Line Classification |  | April 4, 2026 |  | December 31, 2025 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 609 |  |  | $ | 581 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | 130 |  |  | 133 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | 494 |  |  | 471 |  |  |  |

[0000068505-26-000021:notes:43]
Other Information Related to Leases

[0000068505-26-000021:notes:44]
|  | Three Months Ended |  |  |
| (in millions) | April 4, 2026 |  | March 29, 2025 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 53 |  |  | $ | 54 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | 57 |  |  | 12 |  |  |  |

[0000068505-26-000021:notes:45]
During the three months ended April 4, 2026, assets obtained in exchange for lease liabilities were primarily driven by new and renewed real estate leases.

[0000068505-26-000021:notes:46]
|  | April 4, 2026 |  | December 31, 2025 |
| Weighted average remaining lease terms (years) | 6 |  | 5 |
| Weighted average discount rate: | 4.27 | % |  | 4.21 | % |

[0000068505-26-000021:notes:47]
Future Lease Payments

[0000068505-26-000021:notes:48]
|  | April 4, 2026 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2026 | $ | 112 |  |  |  |  |  |
| 2027 | 162 |  |  |  |  |  |
| 2028 | 136 |  |  |  |  |  |
| 2029 | 103 |  |  |  |  |  |
| 2030 | 52 |  |  |  |  |  |
| Thereafter | 141 |  |  |  |  |  |
| Total lease payments | 706 |  |  |  |  |  |
| Less: interest | 82 |  |  |  |  |  |
| Present value of lease liabilities | $ | 624 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-26-000021:notes:49]
[same as prior period, unchanged from 0000068505-25-000052:notes:47]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-26-000021:notes:50]
[same as prior period, unchanged from 0000068505-25-000052:notes:48]

[0000068505-26-000021:notes:51]
[same as prior period, unchanged from 0000068505-25-000052:notes:49]

[0000068505-26-000021:notes:52]
[same as prior period, unchanged from 0000068505-25-000052:notes:50]

[0000068505-26-000021:notes:53]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 90 |  |  | $ | 37 |  |  |  |  |  |
| Contingent earnout adjustment (Note 10) | 75 |  |  | — |  |  |  |  |  |
| Reorganization of business (Note 14) | 10 |  |  | 12 |  |  |  |  |  |
| Acquisition-related transaction fees | 8 |  |  | 6 |  |  |  |  |  |
| Operating lease asset impairments | 2 |  |  | — |  |  |  |  |  |
| Legal settlements | 1 |  |  | 4 |  |  |  |  |  |
| Gain on Hytera litigation | (40) |  |  | (10) |  |  |  |  |  |
|  | $ | 146 |  |  | $ | 49 |  |  |  |  |  |

[0000068505-26-000021:notes:54]
During the three months ended April 4, 2026, the Company recorded a charge of $75 million to increase the fair value of the contingent earnout consideration related to the Silvus acquisition. Refer to "Note 10: Fair Value Measurements," in this "Part 1 — Financial Information" of this Form 10-Q for more information.

[0000068505-26-000021:notes:55]
During the three months ended April 4, 2026, the Company recognized a gain on the Hytera litigation of $40 million for amounts recovered through legal proceedings due to theft of the Company's trade secrets. Refer to "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" in this "Part 1 — Financial Information" of this Form 10-Q for more information.

[0000068505-26-000021:notes:56]
[same as prior period, unchanged from 0000068505-25-000052:notes:53]

[0000068505-26-000021:notes:57]
[same as prior period, unchanged from 0000068505-25-000052:notes:54]

[0000068505-26-000021:notes:58]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Interest, net: |  |  |  |  |  |  |  |
| Interest expense | $ | (111) |  |  | $ | (69) |  |  |  |  |  |
| Interest income | 7 |  |  | 18 |  |  |  |  |  |
|  | $ | (104) |  |  | $ | (51) |  |  |  |  |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 27 |  |  | $ | 30 |  |  |  |  |  |
| Foreign currency gain (loss) | 25 |  |  | (20) |  |  |  |  |  |
| Gain (loss) on derivative instruments (Note 6) | (27) |  |  | 13 |  |  |  |  |  |
| Fair value adjustments to equity investments | (5) |  |  | (5) |  |  |  |  |  |
| Other | — |  |  | (2) |  |  |  |  |  |
|  | $ | 20 |  |  | $ | 16 |  |  |  |  |  |

[0000068505-26-000021:notes:59]
[same as prior period, unchanged from 0000068505-25-000052:notes:56]

[0000068505-26-000021:notes:60]
[same as prior period, unchanged from 0000068505-25-000052:notes:57]

[0000068505-26-000021:notes:61]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 366 |  |  | $ | 430 |  |  |  |  |  |
| Weighted average common shares outstanding | 165.8 |  |  | 166.9 |  |  |  |  |  |
| Per share amount | $ | 2.21 |  |  | $ | 2.58 |  |  |  |  |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 366 |  |  | $ | 430 |  |  |  |  |  |
| Weighted average common shares outstanding | 165.8 |  |  | 166.9 |  |  |  |  |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.2 |  |  | 2.9 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 168.0 |  |  | 169.8 |  |  |  |  |  |
| Per share amount | $ | 2.18 |  |  | $ | 2.53 |  |  |  |  |  |

[0000068505-26-000021:notes:62]
In the computation of diluted earnings per common share for the three months ended April 4, 2026, the assumed exercise of 0.2 million options and 0.2 million awards subject to performance conditions were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-26-000021:notes:63]
In the computation of diluted earnings per common share for the three months ended March 29, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-26-000021:notes:64]
In connection with the acquisition of Silvus, the Seller will have the potential to earn contingent earnout consideration upon the achievement of certain financial targets payable in shares of common stock of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The estimated fair value of the total contingent earnout consideration was $111 million as of April 4, 2026. The shares required to settle the contingent earnout consideration will only be reflected within diluted earnings per share when and if the earnout financial targets have been achieved, in each of the two respective periods.

[0000068505-26-000021:notes:65]
[same as prior period, unchanged from 0000068505-25-000052:notes:64]

[0000068505-26-000021:notes:66]
[same as prior period, unchanged from 0000068505-25-000052:notes:65]

[0000068505-26-000021:notes:67]
[same as prior period, unchanged from 0000068505-25-000052:notes:66]

[0000068505-26-000021:notes:68]
|  | April 4, 2026 |  | December 31, 2025 |
| Accounts receivable | $ | 2,130 |  |  | $ | 2,283 |  |
| Less allowance for credit losses | (84) |  |  | (83) |  |
|  | $ | 2,046 |  |  | $ | 2,200 |  |

[0000068505-26-000021:notes:69]
[same as prior period, unchanged from 0000068505-25-000052:notes:68]

[0000068505-26-000021:notes:70]
[same as prior period, unchanged from 0000068505-25-000052:notes:69]

[0000068505-26-000021:notes:71]
|  | April 4, 2026 |  | December 31, 2025 |
| Finished goods | $ | 494 |  |  | $ | 455 |  |
| Work-in-process and production materials | 810 |  |  | 644 |  |
|  | 1,304 |  |  | 1,099 |  |
| Less inventory reserves | (123) |  |  | (116) |  |
|  | $ | 1,181 |  |  | $ | 983 |  |

[0000068505-26-000021:notes:72]
[same as prior period, unchanged from 0000068505-25-000052:notes:71]

[0000068505-26-000021:notes:73]
[same as prior period, unchanged from 0000068505-25-000052:notes:72]

[0000068505-26-000021:notes:74]
|  | April 4, 2026 |  | December 31, 2025 |
| Current contract cost assets (Note 2) | $ | 81 |  |  | $ | 72 |  |
| Contractor receivables | 13 |  |  | 19 |  |
| Tax-related deposits | 33 |  |  | 41 |  |
| Other | 323 |  |  | 246 |  |
|  | $ | 450 |  |  | $ | 378 |  |

[0000068505-26-000021:notes:75]
[same as prior period, unchanged from 0000068505-25-000052:notes:74]

[0000068505-26-000021:notes:76]
[same as prior period, unchanged from 0000068505-25-000052:notes:75]

[0000068505-26-000021:notes:77]
|  | April 4, 2026 |  | December 31, 2025 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 512 |  |  | 479 |  |
| Machinery and equipment | 2,664 |  |  | 2,655 |  |
|  | 3,181 |  |  | 3,139 |  |
| Less accumulated depreciation | (2,020) |  |  | (1,974) |  |
|  | $ | 1,161 |  |  | $ | 1,165 |  |

[0000068505-26-000021:notes:78]
Depreciation expense was $53 million and $44 million for the three months ended April 4, 2026 and March 29, 2025, respectively.

[0000068505-26-000021:notes:79]
[same as prior period, unchanged from 0000068505-25-000052:notes:78]

[0000068505-26-000021:notes:80]
[same as prior period, unchanged from 0000068505-25-000052:notes:79]

[0000068505-26-000021:notes:81]
|  | April 4, 2026 |  | December 31, 2025 |  |  |  |  |
| Common stock | $ | 35 |  |  | $ | 42 |  |  |  |  |  |
| Strategic investments | 54 |  |  | 54 |  |  |  |  |  |
| Company-owned life insurance policies | 90 |  |  | 83 |  |  |  |  |  |
| Equity method investments | 8 |  |  | 8 |  |  |  |  |  |
|  | $ | 187 |  |  | $ | 187 |  |  |  |  |  |

[0000068505-26-000021:notes:82]
[same as prior period, unchanged from 0000068505-25-000052:notes:81]

[0000068505-26-000021:notes:83]
[same as prior period, unchanged from 0000068505-25-000052:notes:82]

[0000068505-26-000021:notes:84]
|  | April 4, 2026 |  | December 31, 2025 |
| Defined benefit plan assets (Note 8) | $ | 243 |  |  | $ | 228 |  |
| Non-current contract cost assets (Note 2) | 147 |  |  | 152 |  |
| Non-current long-term receivables (Note 11) | 49 |  |  | 59 |  |
| Other | 54 |  |  | 52 |  |
|  | $ | 493 |  |  | $ | 491 |  |

[0000068505-26-000021:notes:85]
[same as prior period, unchanged from 0000068505-25-000052:notes:84]

[0000068505-26-000021:notes:86]
The Company utilizes a supplier finance program which provides its suppliers the ability to accelerate payment on the Company's invoices beyond the stated payment terms. Under the terms of this program, the Company agrees to pay an intermediary the stated amount of confirmed invoices on the stated maturity dates of the invoices, and the supplier is able to negotiate earlier payment terms with the intermediary. The Company or the intermediary may terminate their agreement at any time upon 60 days' notice. The Company does not provide any forms of guarantees under this arrangement. Supplier participation in the program is solely at the supplier's discretion, and the participating suppliers negotiate their arrangements directly with the intermediary. The Company has no economic interest in a supplier's decision to participate in the program, and their participation has no bearing on payment terms or amounts due. The stated invoice payment terms range from 75 to 120 days from the invoice date and are considered commercially reasonable.

[0000068505-26-000021:notes:87]
The Company's outstanding amounts related to the suppliers participating in this program was $31 million and $34 million as of April 4, 2026 and December 31, 2025, respectively. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-26-000021:notes:88]
[same as prior period, unchanged from 0000068505-25-000052:notes:87]

[0000068505-26-000021:notes:89]
[same as prior period, unchanged from 0000068505-25-000052:notes:88]

[0000068505-26-000021:notes:90]
|  | April 4, 2026 |  | December 31, 2025 |
| Compensation | $ | 420 |  |  | $ | 479 |  |
| Tax liabilities (Note 7) | 193 |  |  | 225 |  |
| Dividend payable | 201 |  |  | 201 |  |
| Trade liabilities | 179 |  |  | 194 |  |
| Operating lease liabilities (Note 3) | 130 |  |  | 133 |  |
| Customer reserves | 88 |  |  | 125 |  |
| External interest liabilities | 103 |  |  | 113 |  |
| Other | 471 |  |  | 460 |  |
|  | $ | 1,785 |  |  | $ | 1,930 |  |

[0000068505-26-000021:notes:91]
[same as prior period, unchanged from 0000068505-25-000052:notes:90]

[0000068505-26-000021:notes:92]
[same as prior period, unchanged from 0000068505-25-000052:notes:91]

[0000068505-26-000021:notes:93]
|  | April 4, 2026 |  | December 31, 2025 |
| Defined benefit plans (Note 8) | $ | 651 |  |  | $ | 683 |  |
| Non-current contract liabilities (Note 2) | 761 |  |  | 751 |  |
| Unrecognized tax benefits (Note 7) | 38 |  |  | 41 |  |
| Deferred income taxes (Note 7) | 123 |  |  | 124 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Deferred compensation | 112 |  |  | 111 |  |
| Contingent earnout consideration (Note 10) | 111 |  |  | 37 |  |
| Other | 134 |  |  | 134 |  |
|  | $ | 2,049 |  |  | $ | 2,000 |  |

[0000068505-26-000021:notes:94]
[same as prior period, unchanged from 0000068505-25-000052:notes:93]

[0000068505-26-000021:notes:95]
Share Repurchase Program: During the three months ended April 4, 2026, the Company repurchased approximately 0.3 million shares at an average price of $440.94 per share for an aggregate amount of $118 million.

[0000068505-26-000021:notes:96]
Payment of Dividends: During the three months ended April 4, 2026 and March 29, 2025, the Company paid $201 million and $182 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $201 million in cash dividends to holders of its common stock.

[0000068505-26-000021:notes:97]
[same as prior period, unchanged from 0000068505-25-000052:notes:96]

[0000068505-26-000021:notes:98]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three months ended April 4, 2026 and March 29, 2025:

[0000068505-26-000021:notes:99]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (445) |  |  | $ | (546) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | (14) |  |  | 38 |  |  |  |  |  |
| Reclassification adjustment into Net earnings | (1) |  |  | — |  |  |  |  |  |
| Tax benefit | — |  |  | 3 |  |  |  |  |  |
| Other comprehensive income (loss), net of tax | (15) |  |  | 41 |  |  |  |  |  |
| Balance at end of period | $ | (460) |  |  | $ | (505) |  |  |  |  |  |
| Derivative Instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (6) |  |  | $ | (7) |  |  |  |  |  |
| Other comprehensive income, net of tax | — |  |  | — |  |  |  |  |  |
| Balance at end of period | $ | (6) |  |  | $ | (7) |  |  |  |  |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,969) |  |  | $ | (1,986) |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment | 2 |  |  | (12) |  |  |  |  |  |
| Tax expense (benefit) | (1) |  |  | 3 |  |  |  |  |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 1 |  |  | (9) |  |  |  |  |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 15 |  |  | 9 |  |  |  |  |  |
| Tax expense | (4) |  |  | (2) |  |  |  |  |  |
| Reclassification adjustments into Net earnings, net of tax | 11 |  |  | 7 |  |  |  |  |  |
| Other comprehensive income, net of tax | 12 |  |  | (2) |  |  |  |  |  |
| Balance at end of period | $ | (1,957) |  |  | $ | (1,988) |  |  |  |  |  |
| Total Accumulated other comprehensive loss | $ | (2,423) |  |  | $ | (2,500) |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-26-000021:notes:100]
Debt and Credit Facilities

[0000068505-26-000021:notes:101]
|  | April 4, 2026 |  | December 31, 2025 |
| 364 day term loan | $ | 550 |  |  | $ | 749 |  |
| 4.6% senior notes due 2028 | 698 |  |  | 698 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| Term loan due 2028 | 749 |  |  | 748 |  |
| 5.0% senior notes due 2029 | 398 |  |  | 397 |  |
| 4.6% senior notes due 2029 | 801 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 896 |  |
| 4.85% senior notes due 2030 | 596 |  |  | 595 |  |
| 2.75% senior notes due 2031 | 847 |  |  | 847 |  |
| 5.2% senior notes due 2032 | 496 |  |  | 496 |  |
| 5.6% senior notes due 2032 | 597 |  |  | 597 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 894 |  |
| 5.55% senior notes due 2035 | 892 |  |  | 892 |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 8,966 |  |  | 9,163 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (550) |  |  | (749) |  |
| Long-term debt | $ | 8,415 |  |  | $ | 8,413 |  |

[0000068505-26-000021:notes:102]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032, and $900 million of 5.55% senior notes due 2035. The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-26-000021:notes:103]
On August 6, 2025, the Company borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. On January 30, 2026, the Company repaid $200 million of the $750 million 364-day term loan, reducing the outstanding principal balance to $550 million. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. The Company was in compliance with its financial covenants as of April 4, 2026. During the three months ended April 4, 2026, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 4.77% and 4.99%, respectively.

[0000068505-26-000021:notes:104]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement (as defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of April 4, 2026, the Company had no outstanding debt under the commercial paper program.
As of April 4, 2026, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of April 4, 2026.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-26-000021:notes:105]
[same as prior period, unchanged from 0000068505-25-000052:notes:105]

[0000068505-26-000021:notes:106]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.4 billion and $1.6 billion for the periods ended April 4, 2026 and December 31, 2025, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-26-000021:notes:107]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of April 4, 2026, and the corresponding positions as of December 31, 2025:

[0000068505-26-000021:notes:108]
|  | Notional Amount |
| Net Buy (Sell) by Currency | April 4, 2026 |  | December 31, 2025 |
| British Pound | $ | 304 |  |  | $ | 301 |  |
| Euro | 200 |  |  | 191 |  |
| Canadian dollar | 122 |  |  | 115 |  |
| Australian dollar | (106) |  |  | (160) |  |
| Danish krone | 65 |  |  | 58 |  |

[0000068505-26-000021:notes:109]
[same as prior period, unchanged from 0000068505-25-000052:notes:109]

[0000068505-26-000021:notes:110]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of April 4, 2026, all of the counterparties had investment grade credit ratings. As of April 4, 2026, the Company had $5 million of exposure to aggregate credit risk with all counterparties.

[0000068505-26-000021:notes:111]
[same as prior period, unchanged from 0000068505-25-000052:notes:111]

[0000068505-26-000021:notes:112]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of April 4, 2026 and December 31, 2025:

[0000068505-26-000021:notes:113]
|  | Fair Values of Derivative Instruments |
| April 4, 2026 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 4 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | 10 |  |
| Total derivatives | $ | 5 |  |  | $ | 10 |  |

[0000068505-26-000021:notes:114]
|  | Fair Values of Derivative Instruments |
| December 31, 2025 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 19 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 10 |  |  | $ | — |  |
| Total derivatives | $ | 10 |  |  | $ | 19 |  |

[0000068505-26-000021:notes:115]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended April 4, 2026 and March 29, 2025:

[0000068505-26-000021:notes:116]
|  | Financial Statement Location | Three Months Ended |  |  |
| Derivatives | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | 2 |  |  | $ | (6) |  |  |  |  |  |
| Amortized hedge income | Other income (expense) | 1 |  |  | 1 |  |  |  |  |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | (27) |  |  | $ | 13 |  |  |  |  |  |
| Equity swap contracts | Selling, general and administrative expenses | (1) |  |  | (1) |  |  |  |  |  |

[0000068505-26-000021:notes:117]
[same as prior period, unchanged from 0000068505-25-000052:notes:117]

[0000068505-26-000021:notes:118]
The Company uses foreign exchange forward and option contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of April 4, 2026, the Company had €160 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in a British pound functional subsidiary.

[0000068505-26-000021:notes:119]
[same as prior period, unchanged from 0000068505-25-000052:notes:119]

[0000068505-26-000021:notes:120]
[same as prior period, unchanged from 0000068505-25-000052:notes:120]

[0000068505-26-000021:notes:121]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of April 4, 2026 was $21 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-26-000021:notes:122]
[same as prior period, unchanged from 0000068505-25-000052:notes:124]

[0000068505-26-000021:notes:123]
[same as prior period, unchanged from 0000068505-25-000052:notes:125]

[0000068505-26-000021:notes:124]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Net earnings before income taxes | $ | 441 |  |  | $ | 547 |  |  |  |  |  |
| Income tax expense | 73 |  |  | 115 |  |  |  |  |  |
| Effective tax rate | 17 | % |  | 21 | % |  |  |  |  |

[0000068505-26-000021:notes:125]
The effective tax rate for the three months ended April 4, 2026 of 17% was lower than the U.S. federal statutory tax rate of 21% primarily due to excess tax benefits of share-based compensation and the deduction for foreign-derived deduction-eligible income (formerly known as foreign-derived intangible income), partially offset by state tax expense.

[0000068505-26-000021:notes:126]
The effective tax rate for the three months ended March 29, 2025 of 21% was equal to the U.S. federal statutory tax rate of 21% primarily due to excess tax benefits of share-based compensation, offset by state tax expense.

[0000068505-26-000021:notes:127]
The effective tax rate for the three months ended April 4, 2026 of 17% was lower than the effective tax rate for the three months ended March 29, 2025 of 21%, primarily due to higher excess tax benefits of share-based compensation and an increased deduction for foreign-derived deduction-eligible income.

[0000068505-26-000021:notes:128]
On July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law, introducing a broad range of changes to the U.S. corporate income tax framework. The legislation includes business provisions that impact the Company's tax position, including tax cut extensions and modifications to the international tax framework and corporate income tax deductions. Certain provisions of this legislation were effective for the 2025 fiscal year, whereas other provisions became effective starting in 2026. For the three months ended April 4, 2026, the impact of the enacted legislation on the Company's tax position was not material. The Company will continue to assess the ongoing impact of this legislation as further guidance is made available.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-26-000021:notes:129]
[same as prior period, unchanged from 0000068505-25-000052:notes:131]

[0000068505-26-000021:notes:130]
[same as prior period, unchanged from 0000068505-25-000052:notes:132]

[0000068505-26-000021:notes:131]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | April 4, 2026 |  | March 29, 2025 |  | April 4, 2026 |  | March 29, 2025 |  | April 4, 2026 |  | March 29, 2025 |
| Interest cost | $ | 47 |  |  | $ | 50 |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 1 |  |
| Expected return on plan assets | (74) |  |  | (76) |  |  | (26) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 10 |  |  | 6 |  |  | 4 |  |  | 2 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | (1) |  |  | 1 |  |  | 1 |  |
| Net periodic pension benefits | $ | (17) |  |  | $ | (20) |  |  | $ | (9) |  |  | $ | (11) |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-26-000021:notes:132]
[same as prior period, unchanged from 0000068505-25-000052:notes:135]

[0000068505-26-000021:notes:133]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 21 |  |  | $ | 14 |  |  |  |  |  |
| Selling, general and administrative expenses | 54 |  |  | 35 |  |  |  |  |  |
| Research and development expenditures | 25 |  |  | 17 |  |  |  |  |  |
| Share-based compensation expense included in Operating earnings | 100 |  |  | 66 |  |  |  |  |  |
| Tax benefit | (18) |  |  | (14) |  |  |  |  |  |
| Share-based compensation expense, net of tax | $ | 82 |  |  | $ | 52 |  |  |  |  |  |
| Decrease in basic earnings per share | $ | (0.49) |  |  | $ | (0.31) |  |  |  |  |  |
| Decrease in diluted earnings per share | $ | (0.49) |  |  | $ | (0.31) |  |  |  |  |  |

[0000068505-26-000021:notes:134]
During the three months ended April 4, 2026, the Company granted 0.5 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $208 million, $40 million and $20 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $8 million and $20 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-26-000021:notes:135]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the Motorola Solutions 401(k) Plan (the "401(k) Plan") is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. Beginning January 1, 2026, the Company's matching contribution under the 401(k) Plan was made in Company common stock. During the three months ended April 4, 2026, the Company issued 0.03 million shares of common stock with an aggregate grant-date fair value of $14 million to fund the 401(k) Plan Company matching contribution. The share-based compensation expense was recorded in the period in which the shares were issued.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-26-000021:notes:136]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of April 4, 2026 and December 31, 2025 were as follows:

[0000068505-26-000021:notes:137]
| April 4, 2026 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Common stock and equivalents | 35 |  |  | — |  |  | — |  |  | 35 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earnout consideration (Note 15) | $ | — |  |  | $ | — |  |  | $ | 111 |  |  | $ | 111 |  |
| Foreign exchange derivative contracts | — |  |  | 10 |  |  | — |  |  | 10 |  |

[0000068505-26-000021:notes:138]
| December 31, 2025 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Common stock and equivalents | 42 |  |  | — |  |  | — |  |  | 42 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earnout consideration (Note 15) | $ | — |  |  | $ | — |  |  | $ | 37 |  |  | $ | 37 |  |
| Foreign exchange derivative contracts | — |  |  | 19 |  |  | — |  |  | 19 |  |

[0000068505-26-000021:notes:139]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of April 4, 2026 or December 31, 2025.

[0000068505-26-000021:notes:140]
At April 4, 2026 and December 31, 2025, the Company had $439 million and $735 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-26-000021:notes:141]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of April 4, 2026 was $8.9 billion. The fair value of long-term debt as of December 31, 2025 was $9.2 billion.

[0000068505-26-000021:notes:142]
In connection with the acquisition of Silvus, the Seller will have the potential to earn contingent earnout consideration upon the achievement of certain financial targets. Refer to Note 15, “Intangible Assets and Goodwill” in this “Part 1 – Financial Information” of this Form 10-Q for more information regarding the details of the contingent earnout consideration. The Company determines the fair value of the contingent earnout consideration liability using a Monte Carlo simulation model, which requires the use of Level 3 inputs, such as projected future net sales, gross margin and cash flows. At the acquisition date, the Company recorded a contingent liability of approximately $38 million, related to the estimated fair value of the contingent earnout consideration, which was included in the purchase price. As of April 4, 2026, the fair value of the contingent earnout consideration was estimated to be $111 million, resulting in a charge of $75 million recorded within Other Charges in the Company's Consolidated Statement of Operations during the three months ended April 4, 2026. This non-cash charge is attributable to the Company's updated expectations regarding the achievement of the previously noted financial targets.

[0000068505-26-000021:notes:143]
[same as prior period, unchanged from 0000068505-25-000052:notes:145]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-26-000021:notes:144]
[same as prior period, unchanged from 0000068505-25-000052:notes:146]

[0000068505-26-000021:notes:145]
The following table summarizes the proceeds received from sales of long-term receivables for the three months ended April 4, 2026 and March 29, 2025:

[0000068505-26-000021:notes:146]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Long-term receivables sales proceeds | 50 |  |  | 24 |  |  |  |  |  |

[0000068505-26-000021:notes:147]
At April 4, 2026, the Company had retained servicing obligations for $832 million of long-term receivables, compared to $814 million at December 31, 2025. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $200 million at April 4, 2026, compared to $179 million at December 31, 2025.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-26-000021:notes:148]
Commitments and Contingencies
Legal Matters

[0000068505-26-000021:notes:149]
Hytera Civil Litigation

[0000068505-26-000021:notes:150]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor, ultimately resulting in an award to the Company of $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-26-000021:notes:151]
In 2024, after both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), the Court of Appeals, among other items, affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, and directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, which remains subject to ruling by the District Court. As of April 4, 2026, as a result of this civil litigation and 2020 bankruptcy proceedings by Hytera America, Inc. and Hytera Communications America (West), Inc., Hytera had paid over $212 million against this award, $40 million of which was paid in the first quarter of 2026. Net of withholding taxes, the Company had received over $192 million as of April 4, 2026, $36 million of which was received in the first quarter of 2026. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations.

[0000068505-26-000021:notes:152]
Further, in 2022, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on Hytera’s products (“I-Series”) that use the Company’s stolen trade secrets, applicable to I-Series products sold from July 1, 2019 forward. In 2024, the Company received royalties of $61 million related to the I-Series products, which was recorded as a gain within Other charges within the Consolidated Statement of Operations. Beginning in 2025, a favorable ruling in a related legal proceeding in the District Court (which Hytera has subsequently appealed to the Court of Appeals) also ordered Hytera to pay the Company for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera’s currently shipping products (“H-Series”), and Hytera has subsequently reported approximately $110 million in royalties subject to the Court's order. While several aspects of the court proceedings related to both the I-Series and H-Series are subject to appeal, the Company continues to seek collection of the amounts owed by Hytera through the ongoing legal process.

[0000068505-26-000021:notes:153]
Hytera Criminal Litigation

[0000068505-26-000021:notes:154]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. At Hytera's sentencing on March 5, 2026, which included Hytera’s sentencing to five years of probation, the District Court found that Hytera caused the Company to lose $214 million in profits, but that this restitution amount was offset in full by payments previously made by Hytera towards the civil judgment. As a condition of Hytera’s probation, the District Court ordered Hytera to pay the Company $100 million in 2026 towards the civil judgment and $100 million for each succeeding year until the civil judgment is paid in full. The District Court also fined Hytera $50 million, to be paid to the U.S. government after the Company's civil judgment is fully paid. The Company has appealed the District Court’s sentencing order.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-26-000021:notes:155]
[same as prior period, unchanged from 0000068505-25-000052:notes:160]

[0000068505-26-000021:notes:156]
|  | Three Months Ended |
|  | April 4, 2026 |  |  |  |  |  | March 29, 2025 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  |  |  |  |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  |  |  |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Cost of sales | 754 |  | 598 |  | 1,352 |  |  |  |  |  | 694 |  | 534 |  | 1,228 |
| Gross margin | 805 |  | 557 |  | 1,362 |  |  |  |  |  | 852 |  | 448 |  | 1,300 |
| Selling, general and administrative expenses | 341 |  | 98 |  | 439 |  |  |  |  |  | 341 |  | 95 |  | 436 |
| Research and development expenditures | 152 |  | 100 |  | 252 |  |  |  |  |  | 142 |  | 91 |  | 233 |
| Other charges | 99 |  | 47 |  | 146 |  |  |  |  |  | 17 |  | 32 |  | 49 |
| Operating earnings | $ | 213 |  |  | $ | 312 |  |  | $ | 525 |  |  |  |  |  |  | $ | 352 |  |  | $ | 230 |  |  | $ | 582 |  |
| Total other expense |  |  |  |  | (84) |  |  |  |  |  |  |  |  |  | (35) |
| Earnings before income taxes |  |  |  |  | $ | 441 |  |  |  |  |  |  |  |  |  |  | $ | 547 |  |

[0000068505-26-000021:notes:157]
[same as prior period, unchanged from 0000068505-25-000052:notes:163]

[0000068505-26-000021:notes:158]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Products and Systems Integration | $ | 25 |  |  | $ | 15 |  |  |  |  |  |
| Software and Services | 37 |  |  | 22 |  |  |  |  |  |
|  | $ | 62 |  |  | $ | 37 |  |  |  |  |  |

[0000068505-26-000021:notes:159]
[same as prior period, unchanged from 0000068505-25-000052:notes:165]

[0000068505-26-000021:notes:160]
|  | Three Months Ended |  |  |
|  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Products and Systems Integration | $ | 23 |  |  | $ | 22 |  |  |  |  |  |
| Software and Services | 30 |  |  | 22 |  |  |  |  |  |
|  | $ | 53 |  |  | $ | 44 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-26-000021:notes:161]
Reorganization of Business
2026 Charges

[0000068505-26-000021:notes:162]
During the three months ended April 4, 2026, the Company recorded net reorganization of business charges of $15 million, including $10 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations related to employee separation costs.

[0000068505-26-000021:notes:163]
[same as prior period, unchanged from 0000068505-25-000052:notes:170]

[0000068505-26-000021:notes:164]
| April 4, 2026 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 11 |  |  |  |
| Software and Services | 4 |  |  |  |
|  | $ | 15 |  |  |  |

[0000068505-26-000021:notes:165]
[same as prior period, unchanged from 0000068505-25-000052:notes:172]

[0000068505-26-000021:notes:166]
|  | January 1, 2026 |  | Additional Charges |  | Adjustments |  | Amount Used |  | April 4, 2026 |
| Employee separation costs | $ | 24 |  |  | $ | 15 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 27 |  |

[0000068505-26-000021:notes:167]
[same as prior period, unchanged from 0000068505-25-000052:notes:176]

[0000068505-26-000021:notes:168]
At January 1, 2026, the Company had an accrual of $24 million for employee separation costs. The 2026 additional charges of $15 million represent severance costs for approximately 230 employees. The $12 million used reflects cash payments to severed employees. The remaining accrual of $27 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at April 4, 2026, is expected to be paid, primarily within one year, to approximately 620 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-26-000021:notes:169]
2025 Charges

[0000068505-26-000021:notes:170]
During the three months ended March 29, 2025, the Company recorded net reorganization of business charges of $17 million, consisting of $12 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $17 million were charges of $19 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals that are no longer needed.

[0000068505-26-000021:notes:171]
| March 29, 2025 | Three Months Ended |  |  |
| Products and Systems Integration | $ | 12 |  |  |  |
| Software and Services | 5 |  |  |  |
|  | $ | 17 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-26-000021:notes:172]
[same as prior period, unchanged from 0000068505-25-000052:notes:182]

[0000068505-26-000021:notes:173]
On August 6, 2025, the Company acquired Silvus from the Seller. Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired and customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million.

[0000068505-26-000021:notes:174]
Under the terms of the transaction, the Seller will have the potential to earn contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The contingent earnout consideration, if any, will be paid in shares of common stock. The Company valued the contingent earnout consideration using a Monte Carlo methodology which resulted in the Company recognizing $38 million in purchase consideration at the date of close in Other liabilities on the Company’s Condensed Consolidated Balance Sheet. Contingent earnout consideration will continue to be valued at fair value until settled. Changes to the fair value of the contingent earnout consideration will be recorded as a component of operating income within Other income, net in the Company's Consolidated Statement of Operations. For further information, refer to "Note 10: Fair Value Measurements" in this "Part 1 — Financial Information" of this Form 10-Q.

[0000068505-26-000021:notes:175]
The Company recognized goodwill of $3.0 billion which was allocated primarily to the Products and Systems Integration segment. In addition, the Company recognized $1.9 billion of intangible assets and $407 million of net liabilities, inclusive of $454 million of deferred tax liabilities and $47 million of net tangible assets. Goodwill represents the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized including future customer relationships, new technology and the assembled workforce. The goodwill is not deductible for tax purposes.

[0000068505-26-000021:notes:176]
The identifiable intangible assets were each classified primarily as one asset as follows: $135 million of trade names, $820 million of customer relationships and $920 million of developed technology which will be amortized over a period of twelve, twelve and eight years, respectively. The fair values of all intangible assets were estimated using the income approach. Customer relationships was valued under the excess earnings method, which assumes that the value of intangible assets is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible assets. Developed technology and trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them. The Company applies significant judgment in determining the estimates and assumptions used to estimate the fair values of the intangible assets, including the forecasted revenue growth rates, customer attrition rate, and discount rate for customer relationships and the forecasted revenue growth rates, royalty rate, and discount rate for developed technology.

[0000068505-26-000021:notes:177]
This business is part of both the Products and Systems Integration segment and the Software and Services segment. Between the acquisition date and April 4, 2026, the Company recorded a net reduction of $15 million in goodwill and an increase primarily to intangible assets related to purchase accounting adjustments during the measurement period. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net tangible assets and goodwill may be subject to change.

[0000068505-26-000021:notes:178]
[same as prior period, unchanged from 0000068505-25-000052:notes:188]

[0000068505-26-000021:notes:179]
On March 24, 2026, the Company acquired Hyper for $23 million, net of cash acquired. Hyper provides conversational, agentic AI designed to reduce the burden on understaffed PSAPs by handling non-emergency calls. The Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. The acquisition expands the Company's use of agentic AI across its Command Center portfolio and mission-critical AI, Assist. The Company recognized $20 million of goodwill, $5 million of identifiable intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $5 million of developed technology that will be amortized over a period of nine years. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-26-000021:notes:180]
On March 11, 2026, the Company acquired Exacom, a provider of cloud-native voice and multimedia recording and logging solutions for mission-critical communications for $67 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's public safety ecosystem by consolidating call logs, recording 911 audio and radio traffic into a cloud-based solution to unify voice and video across the incident lifecycle. The Company recognized $51 million of goodwill, $30 million of identifiable intangible assets and $14 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $15 million of customer relationships and $14 million of developed technology and will be amortized over a period of six, fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-26-000021:notes:181]
On November 18, 2025, the Company acquired Blue Eye, a provider of AI-powered enterprise RVM services for $79 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's video security portfolio, serving a wide range of enterprises with real-time intelligence to help reduce loss and damage, mitigate risk and boost profitability. The Company recognized $59 million of goodwill, $24 million of identifiable intangible assets and $4 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of customer relationships and $15 million of developed technology and will be amortized over a period of twenty and eleven years, respectively. This business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-26-000021:notes:182]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $174 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. The Company recognized $117 million of goodwill, $48 million of identifiable intangible assets and $9 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $15 million of customer relationships and $32 million of developed technology and will be amortized over a period of three, nineteen and eleven years, respectively. The business is part of the Software and Services segment. Between the acquisition date and April 4, 2026, the Company recorded a net reduction of $9 million in goodwill and an increase primarily to net assets related to purchase accounting adjustments during the measurement period. The purchase accounting was completed as of the first quarter of 2026.

[0000068505-26-000021:notes:183]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $240 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. The Company recognized $132 million of goodwill, $117 million of identifiable intangible assets, and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $6 million of trade names, $36 million of customer relationships and $75 million of developed technology and will be amortized over a period of nine, nineteen and eighteen years, respectively. The business is part of the Software and Services segment. Between the acquisition date and April 4, 2026, the Company recorded a net reduction of $54 million in goodwill and an increase primarily to intangible assets related to purchase accounting adjustments during the measurement period. The purchase accounting was completed as of the first quarter of 2026.

[0000068505-26-000021:notes:184]
[same as prior period, unchanged from 0000068505-25-000052:notes:195]

[0000068505-26-000021:notes:185]
[same as prior period, unchanged from 0000068505-25-000052:notes:196]

[0000068505-26-000021:notes:186]
|  | April 4, 2026 |  | December 31, 2025 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 2,302 |  |  | $ | 733 |  |  | $ | 2,285 |  |  | $ | 679 |  |
| Customer-related | 2,563 |  |  | 1,256 |  |  | 2,515 |  |  | 1,190 |  |
| Trade name | 250 |  |  | 80 |  |  | 247 |  |  | 74 |  |
| Other intangibles | 15 |  |  | 15 |  |  | 15 |  |  | 15 |  |
|  | $ | 5,130 |  |  | $ | 2,084 |  |  | $ | 5,062 |  |  | $ | 1,958 |  |

[0000068505-26-000021:notes:187]
Amortization expense on intangible assets was $90 million and $37 million for the three months ended April 4, 2026 and March 29, 2025, respectively. The increase in amortization expense period over period is primarily related to amortization of the intangible assets associated with the Silvus acquisition. As of April 4, 2026, annual amortization expense is estimated to be $351 million in 2026, $338 million in 2027, $337 million in 2028, $326 million in 2029, $322 million in 2030 and $318 million in 2031.

[0000068505-26-000021:notes:188]
[same as prior period, unchanged from 0000068505-25-000052:notes:199]

[0000068505-26-000021:notes:189]
|  | April 4, 2026 |  | December 31, 2025 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 2,706 |  |  | $ | 616 |  |  | $ | 2,707 |  |  | $ | 552 |  |
| Software and Services | 2,424 |  |  | 1,468 |  |  | 2,355 |  |  | 1,406 |  |
|  | $ | 5,130 |  |  | $ | 2,084 |  |  | $ | 5,062 |  |  | $ | 1,958 |  |

[0000068505-26-000021:notes:190]
[same as prior period, unchanged from 0000068505-25-000052:notes:201]

[0000068505-26-000021:notes:191]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2026 to April 4, 2026:

[0000068505-26-000021:notes:192]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2026 | $ | 4,229 |  |  | $ | 2,571 |  |  | $ | 6,800 |  |
| Goodwill acquired | — |  |  | 71 |  |  | 71 |  |
| Purchase accounting adjustments | 9 |  |  | (2) |  |  | 7 |  |
| Foreign currency | (1) |  |  | 8 |  |  | 7 |  |
| Balance as of April 4, 2026 | $ | 4,237 |  |  | $ | 2,648 |  |  | $ | 6,885 |  |
