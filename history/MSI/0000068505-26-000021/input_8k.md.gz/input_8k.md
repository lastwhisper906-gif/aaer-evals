# MSI 8-K — 0000068505-26-000018 filed 2026-05-07

## item codes, every 8-K on or before 2026-05-07

- 2026-05-07 0000068505-26-000018 — 2.02, 9.01
- 2026-03-12 0001193125-26-104278 — 5.02, 9.01
- 2026-02-11 0000068505-26-000006 — 2.02, 9.01
- 2025-11-18 0001193125-25-286239 — 5.02, 9.01
- 2025-10-30 0000068505-25-000050 — 2.02, 9.01
- 2025-08-07 0000068505-25-000038 — 2.02, 9.01
- 2025-08-06 0001193125-25-174512 — 2.01, 2.03, 7.01, 9.01
- 2025-07-21 0001193125-25-161886 — 1.01, 9.01
- 2025-06-16 0001193125-25-141449 — 8.01, 9.01
- 2025-05-27 0001193125-25-127588 — 1.01, 3.02, 7.01, 9.01
- 2025-05-19 0001193125-25-122455 — 5.07, 8.01
- 2025-05-01 0000068505-25-000022 — 2.02, 9.01
- 2025-04-25 0001193125-25-096928 — 1.01, 1.02, 2.03, 9.01
- 2025-02-13 0000068505-25-000008 — 2.02, 9.01
- 2024-11-07 0000068505-24-000032 — 2.02, 9.01
- 2024-10-09 0001193125-24-235267 — 5.02
- 2024-08-26 0001193125-24-207088 — 5.02, 9.01
- 2024-08-01 0000068505-24-000022 — 2.02, 9.01
- 2024-05-17 0001193125-24-141186 — 5.07
- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2026-05-07

- none on or before 2026-05-07

## item 2.02 — earnings release, exhibit 99.1

[0000068505-26-000018:8k_2_02:1]
EX-99.1
2
msiq12026pressrelease.htm
EX-99.1

[0000068505-26-000018:8k_2_02:2]
Document

[0000068505-26-000018:8k_2_02:3]
Exhibit 99.1

[0000068505-26-000018:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2026 Financial Results

[0000068505-26-000018:8k_2_02:5]
Company raises full-year revenue and earnings outlook driven by record Q1 orders and backlog

[0000068505-26-000018:8k_2_02:6]
•Sales of $2.7 billion, up 7% versus a year ago

[0000068505-26-000018:8k_2_02:7]
◦Software and Services sales up 18%

[0000068505-26-000018:8k_2_02:8]
◦Products and Systems Integration sales up 1%

[0000068505-26-000018:8k_2_02:9]
•GAAP earnings per share ("EPS") of $2.18

[0000068505-26-000018:8k_2_02:10]
•Non-GAAP EPS* of $3.37

[0000068505-26-000018:8k_2_02:11]
•Record Q1 ending backlog of $15.7 billion, up 11% versus a year ago

[0000068505-26-000018:8k_2_02:12]
•Acquired Exacom and Hyper for a combined $90 million, net of cash acquired, and entered into a definitive agreement to acquire Bell Canada's LMR networks services business

[0000068505-26-000018:8k_2_02:13]
CHICAGO – May 7, 2026 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2026.

[0000068505-26-000018:8k_2_02:14]
"Q1 was an outstanding start to the year, with strong sales and earnings,” said Greg Brown, chairman and CEO, Motorola Solutions. “Our record first-quarter backlog was driven by robust, broad-based demand. As a result, we’re raising both our revenue and earnings guidance for the full year 2026.”

[0000068505-26-000018:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-26-000018:8k_2_02:16]
|  | Q1 2026 |  | Q1 2025 | % Change |
| Sales | $2,714 |  | $2,528 | 7 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $525 |  | $582 | (10) | % |
| % of Sales | 19.3 | % |  | 23.0 | % |  |
| EPS | $2.18 |  | $2.53 | (14) | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $781 |  | $716 | 9 | % |
| % of Sales | 28.8 | % |  | 28.3 | % |  |
| EPS | $3.37 |  | $3.18 | 6 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,559 |  | $1,546 | 1 | % |
| GAAP Operating Earnings | $213 |  | $352 | (39) | % |
| % of Sales | 13.7 | % |  | 22.8 | % |  |
| Non-GAAP* Operating Earnings | $386 |  | $434 | (11) | % |
| % of Sales | 24.8 | % |  | 28.1 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $1,155 |  | $982 | 18 | % |
| GAAP Operating Earnings | $312 |  | $230 | 36 | % |
| % of Sales | 27.0 | % |  | 23.4 | % |  |
| Non-GAAP* Operating Earnings | $395 |  | $282 | 40 | % |
| % of Sales | 34.2 | % |  | 28.7 | % |  |

[0000068505-26-000018:8k_2_02:17]
* Non-GAAP financial information excludes the after-tax impact of approximately $1.19 per diluted share related to highlighted items, share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-26-000018:8k_2_02:18]
1

[0000068505-26-000018:8k_2_02:19]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-26-000018:8k_2_02:20]
•Revenue - Sales were $2.7 billion, up 7% from the year-ago quarter driven primarily by growth in International. Revenue from acquisitions was $219 million and foreign currency tailwinds were $60 million in the quarter. The Products and Systems Integration segment grew 1% driven by growth in Video Security and Access Control ("Video"), partially offset by Mission Critical Networks ("MCN"). The Software and Services segment grew 18% driven by growth in MCN, Command Center and Video.

[0000068505-26-000018:8k_2_02:21]
•Operating margin - GAAP operating margin was 19.3% of sales, down from 23.0% in the year-ago quarter primarily driven by an increase to the contingent Silvus earnout due to strong performance of the business and increased intangible amortization expense in the current quarter. Non-GAAP operating margin was 28.8% of sales, up 50 basis points from 28.3% in the year-ago quarter. The increase in non-GAAP operating margin was driven by higher sales and improved operating leverage, partially offset by higher supply chain costs.

[0000068505-26-000018:8k_2_02:22]
•Taxes - The GAAP effective tax rate during the quarter was 16.6%, versus 21.0% in the year-ago quarter and the non-GAAP effective tax rate was 19.1%, versus 21.1% in the year-ago quarter, driven by higher benefits from share-based compensation recognized in the current quarter.

[0000068505-26-000018:8k_2_02:23]
•Cash flow - Operating cash flow was $451 million, compared to $510 million in the year-ago quarter and free cash flow was $389 million, compared to $473 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter decreased primarily due to increased investments in inventory and higher interest and tax payments, partially offset by higher earnings, net of non-cash charges.

[0000068505-26-000018:8k_2_02:24]
•Capital allocation - During the quarter, the company paid $201 million in cash dividends, repurchased $118 million of common stock and invested $62 million in capital expenditures. The company closed the acquisitions of Exacom, a leading provider of cloud-native voice and multimedia recording and logging solutions for mission-critical communications, and Hyper, a leader in conversational, agentic AI designed to assist in handling non-emergency calls within public safety answering points (PSAPs), for a combined $90 million, net of cash acquired. The company also entered into a definitive agreement to acquire the LMR networks services business from Bell Canada for a purchase price of CAD $675 million, or approximately $500 million, subject to customary adjustments and a deferred net working capital settlement. The acquisition is expected to be completed in the fourth quarter of 2026.

[0000068505-26-000018:8k_2_02:25]
Additionally, the company repaid $200 million of the $1.5 billion term loans issued to fund the Silvus acquisition, leaving a balance of $1.3 billion outstanding.

[0000068505-26-000018:8k_2_02:26]
•Backlog - The company ended the quarter with record Q1 backlog of $15.7 billion, up 11% or $1.6 billion from the year-ago quarter driven by record Q1 orders. Products and Systems Integration segment backlog was up $255 million, or 7%, driven primarily by strong demand in Video and MCN. Software and Services segment backlog was up $1.3 billion, or 13%, driven by strong demand across all three technologies and favorable foreign currency impacts.

[0000068505-26-000018:8k_2_02:27]
2

[0000068505-26-000018:8k_2_02:28]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-26-000018:8k_2_02:29]
Products and Systems Integration

[0000068505-26-000018:8k_2_02:30]
•$148 million P25 device and SVX body-worn assistant orders for the U.S. Federal Government

[0000068505-26-000018:8k_2_02:31]
•$78 million of Silvus orders for a German-based unmanned systems provider

[0000068505-26-000018:8k_2_02:32]
•$16 million P25 device order for a U.S. state and local customer

[0000068505-26-000018:8k_2_02:33]
•$14 million fixed video order for a large U.S. fitness company

[0000068505-26-000018:8k_2_02:34]
•$10 million fixed video order for Duke Energy

[0000068505-26-000018:8k_2_02:35]
Software and Services

[0000068505-26-000018:8k_2_02:36]
•$41 million five-year P25 services renewal for the MN Department of Transportation

[0000068505-26-000018:8k_2_02:37]
•$24 million Command Center order for Denver, CO

[0000068505-26-000018:8k_2_02:38]
•$16 million Command Center order for Anne Arundel County, MD

[0000068505-26-000018:8k_2_02:39]
•$10 million P25 services order for Paraíba, Brazil Department of Social Services

[0000068505-26-000018:8k_2_02:40]
•$9 million mobile video order for a U.S. state and local customer

[0000068505-26-000018:8k_2_02:41]
BUSINESS OUTLOOK

[0000068505-26-000018:8k_2_02:42]
•Second quarter 2026 - The company expects revenue growth of approximately 8.5% compared to the second quarter of 2025 and non-GAAP EPS between $3.82 and $3.88 per share. This assumes approximately 168 million of fully diluted shares and a non-GAAP effective tax rate of approximately 23%.

[0000068505-26-000018:8k_2_02:43]
•Full-year 2026 - The company now expects revenue of approximately $12.8 billion, up from its prior guidance of $12.7 billion and non-GAAP EPS between $16.87 and $16.99 per share, up from its prior guidance of between $16.70 and $16.85 per share. This outlook assumes approximately 168 million of fully diluted shares and a non-GAAP effective tax rate of approximately 22.5%.

[0000068505-26-000018:8k_2_02:44]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP measurements in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measurements have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-26-000018:8k_2_02:45]
RECENT EVENTS

[0000068505-26-000018:8k_2_02:46]
MACROECONOMIC ENVIRONMENT UPDATE

[0000068505-26-000018:8k_2_02:47]
Since February 2025, the U.S. has initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, including tariffs levied under the International Emergency Economic Powers Act (“IEEPA”), contributing to a global trade landscape subject to evolving tariffs, import/export regulations, including restrictions around rare earth minerals, trade barriers and trade disputes.

[0000068505-26-000018:8k_2_02:48]
On February 20, 2026, a U.S. Supreme Court ruling invalidated tariffs imposed under IEEPA; however, the ruling did not address potential refunds. Following the ruling, the Court of International Trade (“CIT”) ordered U.S. Customs and Border Protection (“CBP”) to facilitate refunds for all affected importers. On April 20, 2026, CBP launched Phase 1 of the Consolidated Administration and Processing of Entries (“CAPE”) system to facilitate these refunds. As of April 4, 2026, the company had not recognized an asset

[0000068505-26-000018:8k_2_02:49]
3

[0000068505-26-000018:8k_2_02:50]
related to any potential refund given the potential uncertainty in receiving refunds. The company plans to continue to evaluate new information as it becomes available, and recognize the refund when recovery is probable.

[0000068505-26-000018:8k_2_02:51]
In addition, the company is experiencing higher costs for memory in its products which is a result of substantial demand in the market driven by AI. As a result, the company continues to observe elevated volatility and uncertainty around the global supply chain. The company engages with global suppliers across a diverse network of locations around the world. The company continues to work with its global supply base to mitigate its exposure to the risks from global reciprocal (and sectoral) tariffs, rising memory costs, and import/export regulations that have developed, and which may continue to develop, to ensure supply continues at levels necessary to meet its current customer demand. As a result of the dynamic supply chain environment, the company has experienced increased costs on materials and components, for which the company continues to develop mitigation actions going forward.

[0000068505-26-000018:8k_2_02:52]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, May 7. The conference call will be webcast live at www.motorolasolutions.com/investors. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-26-000018:8k_2_02:53]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-26-000018:8k_2_02:54]
A comparison of results from operations is as follows:

[0000068505-26-000018:8k_2_02:55]
|  | Q1 2026 | Q1 2025 |
| Net sales | $2,714 | $2,528 |
| Gross margin | $1,362 | $1,300 |
| Operating earnings | $525 | $582 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $366 | $430 |
| Diluted EPS | $2.18 | $2.53 |
| Weighted average diluted common shares outstanding | 168.0 |  | 169.8 |  |

[0000068505-26-000018:8k_2_02:56]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-26-000018:8k_2_02:57]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP net earnings attributable to MSI, non-GAAP tax rate, and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-26-000018:8k_2_02:58]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-26-000018:8k_2_02:59]
4

[0000068505-26-000018:8k_2_02:60]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-26-000018:8k_2_02:61]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-26-000018:8k_2_02:62]
Non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin and non-GAAP net earnings attributable to MSI each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-26-000018:8k_2_02:63]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt, adjustments to contingent earnout, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-26-000018:8k_2_02:64]
Hytera-Related Legal Expenses: In 2017, the company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the company's favor, ultimately resulting in an award to the company of $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-26-000018:8k_2_02:65]
In 2024, after both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), the Court of Appeals, among other items, affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, and directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, which remains subject to ruling by the District Court. As of April 4, 2026, as a result of this civil litigation and 2020 bankruptcy proceedings by Hytera America, Inc. and Hytera Communications America (West), Inc., Hytera had paid over $212 million against this award, $40 million of which was paid in the first quarter of 2026.  Net of withholding taxes, the company has received over $192 million as of April 4, 2026, $36 million of which was received in the first quarter of 2026. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations.

[0000068505-26-000018:8k_2_02:66]
Further, in 2022, the District Court ordered Hytera to pay the company a forward-looking reasonable royalty on Hytera’s products (“I-Series”) that use the company’s stolen trade secrets, applicable to I-Series products sold from July 1, 2019 forward. In 2024, the company received royalties of $61 million related to the I-Series products, which was recorded as a gain within Other charges within the Consolidated Statement of Operations. Beginning in 2025, a favorable ruling in a related legal proceeding in the District Court (which Hytera has subsequently appealed to the Court of Appeals) also ordered

[0000068505-26-000018:8k_2_02:67]
5

[0000068505-26-000018:8k_2_02:68]
Hytera to pay the company for Hytera’s continued use of the company’s trade secrets and copyrighted source code in Hytera’s currently shipping products (“H-Series”), and Hytera has subsequently reported approximately $110 million in royalties subject to the Court's order. While several aspects of the court proceedings related to both the I-Series and H-Series are subject to appeal, the company continues to seek collection of the amounts owed by Hytera through the ongoing legal process.

[0000068505-26-000018:8k_2_02:69]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring.”  Since 2020, the company has believed that Hytera-related legal expenses have not been part of its “normal and recurring” legal expenses incurred to operate its business and has accordingly excluded such expenses from its GAAP operating Income. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the approximately $15 million realized in 2022, $61 million realized in 2024, $157 million realized in 2025, and $40 million realized in the first quarter of 2026. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-26-000018:8k_2_02:70]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-26-000018:8k_2_02:71]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-26-000018:8k_2_02:72]
FORWARD LOOKING STATEMENTS

[0000068505-26-000018:8k_2_02:73]
6

[0000068505-26-000018:8k_2_02:74]
these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (i) impact of current global economic and political conditions in the markets in which the company operates; (ii) increased areas of risk, increased competition and additional compliance obligations associated with the introduction of new or enhanced products and services in our segments; (iii) challenges relating to the use of artificial intelligence ("AI") in our products and services; (iv) impact of catastrophic events on our business or our customers' or suppliers' business; (v) the effectiveness of our strategic acquisitions, including the integrations of such acquired businesses; (vi) the inability of our products to meet our customers’ expectations or regulatory or industry standards, or actual or perceived systems or service failures of our products and services; (vii) our inability to purchase a sufficient amount of materials, parts, and components, as well as software and services, at acceptable prices to meet the demands of our customers, and any disruption to our suppliers or significant increase in the price of supplies; (viii) risks related to our large, multi-year system and services contracts; (ix) the global nature of our employees, customers, suppliers and outsource partners; (x) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xi) the inability of our subcontractors to perform in a timely and compliant manner or adhere to our Human Rights Policy; (xii) inability to attract and retain senior management and key employees; (xiii) evolving and sometimes conflicting expectations from investors, customers, lawmakers, regulators and other stakeholders regarding social and sustainability considerations and disclosures; (xiv) challenges relating to existing or future legislation and regulations pertaining to AI, AI-enabled products and the use of biometrics and other video analytics; (xv) the impact, including increased costs and potential liabilities, associated with changes in laws and regulations regarding cybersecurity, privacy, data protection, data sovereignty and information security; (xvi) the impact of government regulation of radio frequencies; (xvii) regulations, laws and other compliance requirements and risks applicable to our U.S. government customer contracts and grants; (xviii) the impact, including increased costs and additional compliance obligations, associated with existing or future telecommunications-related laws and regulations; (xix) impact of product regulatory and safety, consumer, worker safety and environmental product compliance and remediation laws; (xx) impact of tax matters; (xxi) increased cybersecurity threats, a security breach or other significant disruption of our IT systems or those of our outsource partners, suppliers or customers; (xxii) our inability to protect our intellectual property or potential infringement of intellectual property rights of third parties; (xxiii) risks relating to intellectual property licenses and intellectual property indemnities in our customer and supplier contracts; (xxiv) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xxv) inability to access the capital markets for financing on acceptable terms and conditions; (xxvi) exposure to exchange rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; (xxvii) impact of returns on pension and retirement plan assets and interest rate changes; and (xxviii) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-26-000018:8k_2_02:75]
About Motorola Solutions | Solving for safer

[0000068505-26-000018:8k_2_02:76]
Safety and security are at the heart of everything we do at Motorola Solutions. We build and connect technologies to help protect people, property and places. Our solutions foster the collaboration that’s critical for safer communities, safer schools, safer hospitals, safer businesses, and ultimately, safer nations. Learn more about our commitment to innovating for a safer future for us all at www.motorolasolutions.com.

[0000068505-26-000018:8k_2_02:77]
MEDIA CONTACT

[0000068505-26-000018:8k_2_02:78]
Alexandra Reynolds

[0000068505-26-000018:8k_2_02:79]
Motorola Solutions

[0000068505-26-000018:8k_2_02:80]
+1 312-965-3968

[0000068505-26-000018:8k_2_02:81]
alexandra.reynolds@motorolasolutions.com

[0000068505-26-000018:8k_2_02:82]
INVESTOR CONTACT

[0000068505-26-000018:8k_2_02:83]
7

[0000068505-26-000018:8k_2_02:84]
Brian Piotrowski

[0000068505-26-000018:8k_2_02:85]
Motorola Solutions

[0000068505-26-000018:8k_2_02:86]
+1 847-576-6899

[0000068505-26-000018:8k_2_02:87]
Brian.Piotrowski@motorolasolutions.com

[0000068505-26-000018:8k_2_02:88]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2026 Motorola Solutions, Inc. All rights reserved.

[0000068505-26-000018:8k_2_02:89]
8

[0000068505-26-000018:8k_2_02:90]
GAAP-1

[0000068505-26-000018:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:92]
Condensed Consolidated Statements of Operations

[0000068505-26-000018:8k_2_02:93]
(In millions, except per share amounts)

[0000068505-26-000018:8k_2_02:94]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| Net sales from products | $ | 1,481 |  |  | $ | 1,448 |  |
| Net sales from services | 1,233 |  |  | 1,080 |  |
| Net sales | 2,714 |  |  | 2,528 |  |
| Costs of products sales | 629 |  |  | 573 |  |
| Costs of services sales | 723 |  |  | 655 |  |
| Costs of sales | 1,352 |  |  | 1,228 |  |
| Gross margin | 1,362 |  |  | 1,300 |  |
| Selling, general and administrative expenses | 439 |  |  | 436 |  |
| Research and development expenditures | 252 |  |  | 233 |  |
| Other charges | 56 |  |  | 12 |  |
| Intangibles amortization | 90 |  |  | 37 |  |
| Operating earnings | 525 |  |  | 582 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (104) |  |  | (51) |  |
| Other, net | 20 |  |  | 16 |  |
| Total other expense | (84) |  |  | (35) |  |
| Net earnings before income taxes | 441 |  |  | 547 |  |
| Income tax expense | 73 |  |  | 115 |  |
| Net earnings | 368 |  |  | 432 |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 366 |  |  | $ | 430 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 2.21 |  |  | $ | 2.58 |  |
| Diluted | $ | 2.18 |  |  | $ | 2.53 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 165.8 |  |  | 166.9 |  |
| Diluted | 168.0 |  |  | 169.8 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 54.6 | % |  | 57.3 | % |
| Net sales from services | 45.4 | % |  | 42.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 42.5 | % |  | 39.6 | % |
| Costs of services sales | 58.6 | % |  | 60.6 | % |
| Costs of sales | 49.8 | % |  | 48.6 | % |
| Gross margin | 50.2 | % |  | 51.4 | % |
| Selling, general and administrative expenses | 16.2 | % |  | 17.2 | % |
| Research and development expenditures | 9.3 | % |  | 9.2 | % |
| Other charges | 2.1 | % |  | 0.5 | % |
| Intangibles amortization | 3.3 | % |  | 1.5 | % |
| Operating earnings | 19.3 | % |  | 23.0 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.8) | % |  | (2.0) | % |
| Other, net | 0.7 | % |  | 0.6 | % |
| Total other expense | (3.1) | % |  | (1.4) | % |
| Net earnings before income taxes | 16.2 | % |  | 21.6 | % |
| Income tax expense | 2.7 | % |  | 4.5 | % |
| Net earnings | 13.6 | % |  | 17.1 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 13.5 | % |  | 17.0 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-26-000018:8k_2_02:95]
9

[0000068505-26-000018:8k_2_02:96]
GAAP-2

[0000068505-26-000018:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:98]
Condensed Consolidated Balance Sheets

[0000068505-26-000018:8k_2_02:99]
(In millions)

[0000068505-26-000018:8k_2_02:100]
|  | April 4, 2026 |  | December 31, 2025 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 886 |  |  | $ | 1,165 |  |
| Accounts receivable, net | 2,046 |  |  | 2,200 |  |
| Contract assets | 1,388 |  |  | 1,574 |  |
| Inventories, net | 1,181 |  |  | 983 |  |
| Other current assets | 450 |  |  | 378 |  |
| Total current assets | 5,951 |  |  | 6,300 |  |
| Property, plant and equipment, net | 1,161 |  |  | 1,165 |  |
| Operating lease assets | 609 |  |  | 581 |  |
| Investments | 187 |  |  | 187 |  |
| Deferred income taxes | 748 |  |  | 761 |  |
| Goodwill | 6,885 |  |  | 6,800 |  |
| Intangible assets, net | 3,046 |  |  | 3,104 |  |
| Other assets | 493 |  |  | 491 |  |
| Total assets | $ | 19,080 |  |  | $ | 19,389 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Short-term borrowings | $ | 550 |  |  | $ | 749 |  |
| Accounts payable | 928 |  |  | 1,134 |  |
| Contract liabilities | 2,296 |  |  | 2,265 |  |
| Accrued liabilities | 1,785 |  |  | 1,930 |  |
| Total current liabilities | 5,559 |  |  | 6,078 |  |
| Long-term debt | 8,415 |  |  | 8,413 |  |
| Operating lease liabilities | 494 |  |  | 471 |  |
| Other liabilities | 2,049 |  |  | 2,000 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 2,544 |  |  | 2,410 |  |
| Non-controlling interests | 19 |  |  | 17 |  |
| Total liabilities and stockholders’ equity | $ | 19,080 |  |  | $ | 19,389 |  |

[0000068505-26-000018:8k_2_02:101]
10

[0000068505-26-000018:8k_2_02:102]
GAAP-3

[0000068505-26-000018:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:104]
Condensed Consolidated Statements of Cash Flows

[0000068505-26-000018:8k_2_02:105]
(In millions)

[0000068505-26-000018:8k_2_02:106]
|  | Three Months Ended |
|  | April 4, 2026 |  | March 29, 2025 |
| Operating |  |  |  |
| Net earnings | $ | 368 |  |  | $ | 432 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 143 |  |  | 81 |  |
| Contingent earnout adjustment | 75 |  |  | — |  |
| Non-cash other charges | 8 |  |  | 7 |  |
| Share-based compensation expenses | 100 |  |  | 66 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 155 |  |  | 197 |  |
| Inventories | (199) |  |  | (62) |  |
| Other current assets and contract assets | 103 |  |  | (78) |  |
| Accounts payable, accrued liabilities and contract liabilities | (290) |  |  | (175) |  |
| Other assets and liabilities | (12) |  |  | 25 |  |
| Deferred income taxes | — |  |  | 17 |  |
| Net cash provided by operating activities | 451 |  |  | 510 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (124) |  |  | (450) |  |
| Proceeds from sales of investments and businesses, net | 2 |  |  | 10 |  |
| Capital expenditures | (62) |  |  | (37) |  |
| Proceeds from sale of property, plant and equipment | 1 |  |  | — |  |
| Net cash used for investing activities | (183) |  |  | (477) |  |
| Financing |  |  |  |
| Repayments of short-term debt | (200) |  |  | — |  |
| Issuances of common stock, net of tax | (6) |  |  | (90) |  |
| Purchases of common stock | (118) |  |  | (325) |  |
| Payments of dividends | (201) |  |  | (182) |  |
| Net cash used for financing activities | (525) |  |  | (597) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (22) |  |  | 26 |  |
| Net decrease in total cash and cash equivalents | (279) |  |  | (538) |  |
| Cash and cash equivalents, beginning of period | 1,165 |  |  | 2,102 |  |
| Cash and cash equivalents, end of period | $ | 886 |  |  | $ | 1,564 |  |

[0000068505-26-000018:8k_2_02:107]
11

[0000068505-26-000018:8k_2_02:108]
Non-GAAP-1

[0000068505-26-000018:8k_2_02:109]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:110]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-26-000018:8k_2_02:111]
(In millions)

[0000068505-26-000018:8k_2_02:112]
|  |  | Three Months Ended |  |  |
|  |  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 451 |  |  | $ | 510 |  |  |  |  |  |
| Capital expenditures |  | (62) |  |  | (37) |  |  |  |  |  |
| Free cash flow |  | $ | 389 |  |  | $ | 473 |  |  |  |  |  |

[0000068505-26-000018:8k_2_02:113]
12

[0000068505-26-000018:8k_2_02:114]
Non-GAAP-2

[0000068505-26-000018:8k_2_02:115]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:116]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-26-000018:8k_2_02:117]
(In millions)

[0000068505-26-000018:8k_2_02:118]
|  |  |  |  | Three Months Ended |  |  |
|  |  | Statement Line |  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 366 |  |  | $ | 430 |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 100 |  |  | $ | 66 |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 90 |  |  | 37 |  |  |  |  |  |
| Contingent earnout adjustment |  | Other charges (income) |  | 75 |  |  | — |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 15 |  |  | 17 |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 8 |  |  | 6 |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 5 |  |  | 5 |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 5 |  |  | 14 |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 2 |  |  | — |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 1 |  |  | 4 |  |  |  |  |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | — |  |  | 1 |  |  |  |  |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (40) |  |  | (10) |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 261 |  |  | $ | 140 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 61 |  | 30 |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 200 |  | 110 |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 566 |  |  | $ | 540 |  |  |  |  |  |

[0000068505-26-000018:8k_2_02:119]
Calculation of Non-GAAP Tax Rate

[0000068505-26-000018:8k_2_02:120]
(In millions)

[0000068505-26-000018:8k_2_02:121]
|  |  | Three Months Ended |  |  |
|  |  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Net earnings before income taxes |  | $ | 441 |  |  | $ | 547 |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 261 |  |  | 140 |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 702 |  |  | 687 |  |  |  |  |  |
| Income tax expense |  | 73 |  |  | 115 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 61 |  |  | 30 |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | $ | 134 |  |  | $ | 145 |  |  |  |  |  |
| Non-GAAP Tax rate |  | 19.1 | % |  | 21.1 | % |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-26-000018:8k_2_02:122]
Non-GAAP-2

[0000068505-26-000018:8k_2_02:123]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-26-000018:8k_2_02:124]
|  |  |  |  | Three Months Ended |  |  |
|  |  | Statement Line |  | April 4, 2026 |  | March 29, 2025 |  |  |  |  |
| Net earnings attributable to MSI |  |  |  | $ | 2.18 |  |  | $ | 2.53 |  |  |  |  |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.60 |  |  | $ | 0.39 |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.53 |  |  | 0.22 |  |  |  |  |  |
| Contingent earnout adjustment |  | Other charges (income) |  | 0.45 |  |  | — |  |  |  |  |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.09 |  |  | 0.10 |  |  |  |  |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.04 |  |  | 0.03 |  |  |  |  |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 0.03 |  |  | 0.03 |  |  |  |  |  |
| Hytera-related legal expenses |  | SG&A |  | 0.03 |  |  | 0.08 |  |  |  |  |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.01 |  |  | — |  |  |  |  |  |
| Legal settlements |  | Other charges (income) |  | 0.01 |  |  | 0.02 |  |  |  |  |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | — |  |  | 0.01 |  |  |  |  |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (0.24) |  |  | (0.06) |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 1.55 |  |  | $ | 0.82 |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.36 |  | 0.17 |  |  |  |  |
| Total Non-GAAP adjustments after income taxes |  |  |  | 1.19 |  | 0.65 |  |  |  |  |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 3.37 |  |  | $ | 3.18 |  |  |  |  |  |
| Diluted Weighted Average Common Shares |  |  |  | 168.0 |  |  | 169.8 |  |  |  |  |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |

[0000068505-26-000018:8k_2_02:125]
14

[0000068505-26-000018:8k_2_02:126]
Non-GAAP-3

[0000068505-26-000018:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:128]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-26-000018:8k_2_02:129]
(In millions)

[0000068505-26-000018:8k_2_02:130]
|  |  | Three Months Ended |
|  |  | April 4, 2026 |  | March 29, 2025 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,559 |  |  | $ | 1,155 |  |  | $ | 2,714 |  |  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |
| Operating earnings ("OE") |  | 213 |  |  | 312 |  |  | 525 |  |  | 352 |  |  | 230 |  |  | 582 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 66 |  |  | 34 |  |  | 100 |  |  | 48 |  |  | 18 |  |  | 66 |  |
| Intangible assets amortization expense |  | 62 |  |  | 28 |  |  | 90 |  |  | 16 |  |  | 21 |  |  | 37 |  |
| Contingent earnout adjustment |  | 67 |  |  | 8 |  |  | 75 |  |  | — |  |  | — |  |  | — |  |
| Reorganization of business charges |  | 11 |  |  | 4 |  |  | 15 |  |  | 12 |  |  | 5 |  |  | 17 |  |
| Acquisition-related transaction fees |  | — |  |  | 8 |  |  | 8 |  |  | — |  |  | 6 |  |  | 6 |  |
| Hytera-related legal expenses |  | 5 |  |  | — |  |  | 5 |  |  | 14 |  |  | — |  |  | 14 |  |
| Operating lease asset impairments |  | 1 |  |  | 1 |  |  | 2 |  |  | — |  |  | — |  |  | — |  |
| Legal settlements |  | 1 |  |  | — |  |  | 1 |  |  | 2 |  |  | 2 |  |  | 4 |  |
| Gain on Hytera litigation |  | (40) |  |  | — |  |  | (40) |  |  | (10) |  |  | — |  |  | (10) |  |
| Total above-OE non-GAAP adjustments |  | 173 |  |  | 83 |  |  | 256 |  |  | 82 |  |  | 52 |  |  | 134 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 386 |  |  | $ | 395 |  |  | $ | 781 |  |  | $ | 434 |  |  | $ | 282 |  |  | $ | 716 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 13.7 | % |  | 27.0 | % |  | 19.3 | % |  | 22.8 | % |  | 23.4 | % |  | 23.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.8 | % |  | 34.2 | % |  | 28.8 | % |  | 28.1 | % |  | 28.7 | % |  | 28.3 | % |

[0000068505-26-000018:8k_2_02:131]
15

[0000068505-26-000018:8k_2_02:132]
Non-GAAP-4

[0000068505-26-000018:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000018:8k_2_02:134]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-26-000018:8k_2_02:135]
(In millions)

[0000068505-26-000018:8k_2_02:136]
|  |  | Three Months Ended |  |  |
|  |  | April 4, 2026 |  | March 29, 2025 |  | % Change |
| Net sales |  | $ | 2,714 |  |  | $ | 2,528 |  |  | 7 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 222 |  |  | 3 |  |  |  |
| Organic revenue |  | $ | 2,492 |  |  | $ | 2,525 |  |  | (1) | % |

[0000068505-26-000018:8k_2_02:137]
16
