# MSI notes — 0000068505-19-000013


## msi:AssetsAndLiabilitiesLesseeTableTextBlock

[0000068505-19-000013:notes:1]
Lease assets and liabilities consist of the following:

[0000068505-19-000013:notes:2]
|  |  | Statement Line Classification |  | March 30, 2019 |
| Assets: |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 593 |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 53 |  |
|  |  |  |  | $ | 646 |  |
| Current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 116 |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 15 |  |
|  |  |  |  | $ | 131 |  |
| Non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 553 |  |
| Finance lease liabilities |  | Long-term debt |  | 25 |  |
|  |  |  |  | $ | 578 |  |


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-19-000013:notes:3]
[same as prior period, unchanged from 0000068505-18-000029:notes:1]

[0000068505-19-000013:notes:4]
|  | March 30, 2019 |  | December 31, 2018 |
| Corporate bonds | $ | — |  |  | $ | 1 |  |
| Common stock | 18 |  |  | 19 |  |
| Strategic investments, at cost | 50 |  |  | 62 |  |
| Company-owned life insurance policies | 78 |  |  | 75 |  |
| Equity method investments | 17 |  |  | 12 |  |
|  | $ | 163 |  |  | $ | 169 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-19-000013:notes:5]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of March 30, 2019 and December 31, 2018 were as follows:

[0000068505-19-000013:notes:6]
| March 30, 2019 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  | $ | 7 |  |
| Common stock | 18 |  |  | — |  |  | 18 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |

[0000068505-19-000013:notes:7]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Corporate bonds | 1 |  |  | — |  |  | 1 |  |
| Common stock | 19 |  |  | — |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-19-000013:notes:8]
[same as prior period, unchanged from 0000068505-18-000029:notes:6]

[0000068505-19-000013:notes:9]
[same as prior period, unchanged from 0000068505-18-000029:notes:7]

[0000068505-19-000013:notes:10]
Long-term receivables consist of receivables with payment terms greater than twelve months and long-term loans. Long-term receivables consist of the following:

[0000068505-19-000013:notes:11]
|  | March 30, 2019 |  | December 31, 2018 |
| Long-term receivables, gross | $ | 35 |  |  | $ | 33 |  |
| Less allowance for losses | (2 | ) |  | (2 | ) |
| Long-term receivables | 33 |  |  | 31 |  |
| Less current portion | (11 | ) |  | (7 | ) |
| Non-current long-term receivables | $ | 22 |  |  | $ | 24 |  |

[0000068505-19-000013:notes:12]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Condensed Consolidated Balance Sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $52 million at March 30, 2019, compared to $62 million at December 31, 2018.

[0000068505-19-000013:notes:13]
[same as prior period, unchanged from 0000068505-18-000029:notes:11]

[0000068505-19-000013:notes:14]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three months ended March 30, 2019 and March 31, 2018:

[0000068505-19-000013:notes:15]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Accounts receivable sales proceeds | $ | 24 |  |  | $ | 55 |  |
| Long-term receivables sales proceeds | 21 |  |  | 13 |  |
| Total proceeds from receivable sales | $ | 45 |  |  | $ | 68 |  |

[0000068505-19-000013:notes:16]
At March 30, 2019, the Company had retained servicing obligations for $944 million of long-term receivables, compared to $970 million at December 31, 2018. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.


## msi:OtherChargesTableTextBlock

[0000068505-19-000013:notes:17]
[same as prior period, unchanged from 0000068505-18-000029:notes:19]

[0000068505-19-000013:notes:18]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Other charges (income): |  |  |  |
| Intangibles amortization (Note 15) | $ | 50 |  |  | $ | 41 |  |
| Reorganization of business (Note 14) | 4 |  |  | 8 |  |
| Legal settlements | (1 | ) |  | 1 |  |
| Acquisition-related transaction fees | 2 |  |  | 17 |  |
|  | $ | 55 |  |  | $ | 67 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-19-000013:notes:19]
[same as prior period, unchanged from 0000068505-18-000029:notes:21]

[0000068505-19-000013:notes:20]
| March 31, 2018 | Three Months Ended |
| Products and Systems Integration | $ | 9 |  |
| Services and Software | 4 |  |
|  | $ | 13 |  |

[0000068505-19-000013:notes:21]
| March 30, 2019 | Three Months Ended |
| Products and Systems Integration | $ | 7 |  |
| Services and Software | 1 |  |
|  | $ | 8 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-19-000013:notes:22]
Compensation expense for the Company’s share-based plans was as follows:

[0000068505-19-000013:notes:23]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Share-based compensation expense included in: |  |  |  |
| Costs of sales | $ | 4 |  |  | $ | 2 |  |
| Selling, general and administrative expenses | 16 |  |  | 11 |  |
| Research and development expenditures | 7 |  |  | 4 |  |
| Share-based compensation expense included in Operating earnings | 27 |  |  | 17 |  |
| Tax benefit | (6 | ) |  | (4 | ) |
| Share-based compensation expense, net of tax | $ | 21 |  |  | $ | 13 |  |
| Decrease in basic earnings per share | $ | (0.13 | ) |  | $ | (0.08 | ) |
| Decrease in diluted earnings per share | $ | (0.12 | ) |  | $ | (0.08 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-19-000013:notes:24]
Amortized intangible assets were comprised of the following by segment:

[0000068505-19-000013:notes:25]
|  | March 30, 2019 |  | December 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 559 |  |  | $ | 46 |  |  | $ | 510 |  |  | $ | 38 |  |
| Services and Software | 1,412 |  |  | 509 |  |  | 1,209 |  |  | 451 |  |
|  | $ | 1,971 |  |  | $ | 555 |  |  | $ | 1,719 |  |  | $ | 489 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-19-000013:notes:26]
[same as prior period, unchanged from 0000068505-18-000029:notes:39]

[0000068505-19-000013:notes:27]
|  | March 30, 2019 |  | December 31, 2018 |
| Defined benefit plans (Note 8) | $ | 1,527 |  |  | $ | 1,557 |  |
| Non-current contract liabilities (Note 2) | 239 |  |  | 214 |  |
| Unrecognized tax benefits | 54 |  |  | 51 |  |
| Deferred income taxes | 222 |  |  | 201 |  |
| Other | 222 |  |  | 277 |  |
|  | $ | 2,264 |  |  | $ | 2,300 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-19-000013:notes:28]
[same as prior period, unchanged from 0000068505-18-000029:notes:43]

[0000068505-19-000013:notes:29]
[same as prior period, unchanged from 0000068505-18-000029:notes:44]

[0000068505-19-000013:notes:30]
[same as prior period, unchanged from 0000068505-18-000029:notes:45]

[0000068505-19-000013:notes:31]
During the three months ended March 30, 2019, the Company recognized $2 million of acquisition-related transaction fees for the VaaS and Avtec acquisitions and $17 million for the Avigilon and Plant acquisitions during the three months ended March 31, 2018.

[0000068505-19-000013:notes:32]
[same as prior period, unchanged from 0000068505-18-000029:notes:50]

[0000068505-19-000013:notes:33]
[same as prior period, unchanged from 0000068505-18-000029:notes:51]

[0000068505-19-000013:notes:34]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Interest income (expense), net: |  |  |  |
| Interest expense | $ | (60 | ) |  | $ | (54 | ) |
| Interest income | 5 |  |  | 8 |  |
|  | $ | (55 | ) |  | $ | (46 | ) |
| Other: |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 16 |  |  | $ | 20 |  |
| Investment impairments | (8 | ) |  | — |  |
| Foreign currency loss | (4 | ) |  | (11 | ) |
| Loss on derivative instruments | (4 | ) |  | (4 | ) |
| Gains on equity method investments | 1 |  |  | 1 |  |
| Fair value adjustments to equity investments | (1 | ) |  | — |  |
| Other | 10 |  |  | (2 | ) |
|  | $ | 10 |  |  | $ | 4 |  |

[0000068505-19-000013:notes:35]
During the three months ended March 30, 2019, the Company recognized a foreign currency loss of $4 million, primarily driven by the British pound, and a loss of $4 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-19-000013:notes:36]
During the three months ended March 31, 2018, the Company recognized a foreign currency loss of $11 million, primarily driven by the Euro and British pound, and a loss of $4 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations, which includes a loss of $14 million on foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the purchase of Avigilon.

[0000068505-19-000013:notes:37]
[same as prior period, unchanged from 0000068505-18-000029:notes:55]

[0000068505-19-000013:notes:38]
[same as prior period, unchanged from 0000068505-18-000029:notes:56]

[0000068505-19-000013:notes:39]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Basic earnings per common share: |  |  |  |
| Earnings | $ | 151 |  |  | $ | 117 |  |
| Weighted average common shares outstanding | 164.0 |  |  | 161.4 |  |
| Per share amount | $ | 0.92 |  |  | $ | 0.73 |  |
| Diluted earnings per common share: |  |  |  |
| Earnings | $ | 151 |  |  | $ | 117 |  |
| Weighted average common shares outstanding | 164.0 |  |  | 161.4 |  |
| Add effect of dilutive securities: |  |  |  |
| Share-based awards | 4.9 |  |  | 4.2 |  |
| Senior Convertible Notes | 5.7 |  |  | 5.0 |  |
| Diluted weighted average common shares outstanding | 174.6 |  |  | 170.6 |  |
| Per share amount | $ | 0.86 |  |  | $ | 0.69 |  |

[0000068505-19-000013:notes:40]
In the computation of diluted earnings per common share for the three months ended March 30, 2019, the assumed exercise of 0.5 million options, including 0.2 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the three months ended March 31, 2018, the assumed exercise of 1.5 million options, including 1.2 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-19-000013:notes:41]
As of March 30, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding which mature in September 2020 (the "Senior Convertible Notes"), and are fully convertible. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash and accordingly, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-19-000013:notes:42]
[same as prior period, unchanged from 0000068505-18-000029:notes:61]

[0000068505-19-000013:notes:43]
[same as prior period, unchanged from 0000068505-18-000029:notes:62]

[0000068505-19-000013:notes:44]
[same as prior period, unchanged from 0000068505-18-000029:notes:63]

[0000068505-19-000013:notes:45]
|  | March 30, 2019 |  | December 31, 2018 |
| Accounts receivable | $ | 1,208 |  |  | $ | 1,344 |  |
| Less allowance for doubtful accounts | (58 | ) |  | (51 | ) |
|  | $ | 1,150 |  |  | $ | 1,293 |  |

[0000068505-19-000013:notes:46]
[same as prior period, unchanged from 0000068505-18-000029:notes:66]

[0000068505-19-000013:notes:47]
[same as prior period, unchanged from 0000068505-18-000029:notes:67]

[0000068505-19-000013:notes:48]
|  | March 30, 2019 |  | December 31, 2018 |
| Finished goods | $ | 227 |  |  | $ | 206 |  |
| Work-in-process and production materials | 340 |  |  | 293 |  |
|  | 567 |  |  | 499 |  |
| Less inventory reserves | (142 | ) |  | (143 | ) |
|  | $ | 425 |  |  | $ | 356 |  |

[0000068505-19-000013:notes:49]
[same as prior period, unchanged from 0000068505-18-000029:notes:70]

[0000068505-19-000013:notes:50]
[same as prior period, unchanged from 0000068505-18-000029:notes:71]

[0000068505-19-000013:notes:51]
|  | March 30, 2019 |  | December 31, 2018 |
| Current contract cost assets (Note 2) | $ | 36 |  |  | $ | 30 |  |
| Tax-related deposits | 137 |  |  | 138 |  |
| Other | 191 |  |  | 186 |  |
|  | $ | 364 |  |  | $ | 354 |  |

[0000068505-19-000013:notes:52]
[same as prior period, unchanged from 0000068505-18-000029:notes:73]

[0000068505-19-000013:notes:53]
[same as prior period, unchanged from 0000068505-18-000029:notes:74]

[0000068505-19-000013:notes:54]
|  | March 30, 2019 |  | December 31, 2018 |
| Land | $ | 10 |  |  | $ | 10 |  |
| Leasehold improvements | 372 |  |  | 362 |  |
| Machinery and equipment | 1,903 |  |  | 1,886 |  |
|  | 2,285 |  |  | 2,258 |  |
| Less accumulated depreciation | (1,348 | ) |  | (1,363 | ) |
|  | $ | 937 |  |  | $ | 895 |  |

[0000068505-19-000013:notes:55]
Depreciation expense for the three months ended March 30, 2019 and March 31, 2018 was $45 million and $41 million, respectively.

[0000068505-19-000013:notes:56]
[same as prior period, unchanged from 0000068505-18-000029:notes:77]

[0000068505-19-000013:notes:57]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the three months ended March 30, 2019.

[0000068505-19-000013:notes:58]
The Company’s common stock portfolio reflects an investment in a publicly-traded company within the communications services sector and is valued utilizing active market prices for similar instruments. During the three months ended March 30, 2019, the Company recognized $1 million in Other income (expense) related to a decrease in the fair value of the investment.

[0000068505-19-000013:notes:59]
During the three months ended March 30, 2019, Gains on the sale of investments and businesses were $1 million, compared to $11 million during the three months ended March 31, 2018. During the three months ended March 30, 2019, the Company recorded investment impairment charges of $8 million, representing other-than-temporary declines in the value of the Company’s equity investment portfolio. There were no investment impairments recorded during the three months ended March 31, 2018. Investment impairment charges are included in Other within Other income (expense) in the Company’s Condensed Consolidated Statements of Operations.

[0000068505-19-000013:notes:60]
[same as prior period, unchanged from 0000068505-18-000029:notes:82]

[0000068505-19-000013:notes:61]
[same as prior period, unchanged from 0000068505-18-000029:notes:83]

[0000068505-19-000013:notes:62]
|  | March 30, 2019 |  | December 31, 2018 |
| Defined benefit plan assets (Note 8) | $ | 152 |  |  | $ | 135 |  |
| Tax receivable | 39 |  |  | 39 |  |
| Non-current contract cost assets (Note 2) | 99 |  |  | 98 |  |
| Other | 67 |  |  | 72 |  |
|  | $ | 357 |  |  | $ | 344 |  |

[0000068505-19-000013:notes:63]
[same as prior period, unchanged from 0000068505-18-000029:notes:85]

[0000068505-19-000013:notes:64]
[same as prior period, unchanged from 0000068505-18-000029:notes:86]

[0000068505-19-000013:notes:65]
|  | March 30, 2019 |  | December 31, 2018 |
| Compensation | $ | 336 |  |  | $ | 324 |  |
| Tax liabilities | 94 |  |  | 111 |  |
| Dividend payable | 94 |  |  | 93 |  |
| Trade liabilities | 161 |  |  | 185 |  |
| Operating lease liabilities (Note 3) | 116 |  |  | — |  |
| Other | 434 |  |  | 497 |  |
|  | $ | 1,235 |  |  | $ | 1,210 |  |

[0000068505-19-000013:notes:66]
[same as prior period, unchanged from 0000068505-18-000029:notes:89]

[0000068505-19-000013:notes:67]
[same as prior period, unchanged from 0000068505-18-000029:notes:92]

[0000068505-19-000013:notes:68]
Share Repurchase Program: During the three months ended March 30, 2019, the Company paid an aggregate of $145 million, including transaction costs, to repurchase approximately 1.2 million shares at an average price of $118.98 per share. As of March 30, 2019, the Company had used approximately $12.6 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-19-000013:notes:69]
Payment of Dividends: During the three months ended March 30, 2019 and March 31, 2018, the Company paid $93 million and $84 million, respectively, in cash dividends to holders of its common stock.

[0000068505-19-000013:notes:70]
[same as prior period, unchanged from 0000068505-18-000029:notes:96]

[0000068505-19-000013:notes:71]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three months ended March 30, 2019 and March 31, 2018:

[0000068505-19-000013:notes:72]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Foreign Currency Translation Adjustments: |  |  |  |
| Balance at beginning of period | $ | (444 | ) |  | $ | (353 | ) |
| Other comprehensive income before reclassification adjustment | 34 |  |  | 51 |  |
| Tax expense | (4 | ) |  | (3 | ) |
| Other comprehensive income, net of tax | 30 |  |  | 48 |  |
| Balance at end of period | $ | (414 | ) |  | $ | (305 | ) |
| Available-for-Sale Securities: |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | 6 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | — |  |  | (8 | ) |
| Tax benefit | — |  |  | 2 |  |
| Other comprehensive loss, net of tax | — |  |  | (6 | ) |
| Balance at end of period | $ | — |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |
| Balance at beginning of period | $ | (2,321 | ) |  | $ | (2,215 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 17 |  |  | 18 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4 | ) |  | (4 | ) |
| Tax expense | (2 | ) |  | (2 | ) |
| Other comprehensive income, net of tax | 11 |  |  | 12 |  |
| Balance at end of period | $ | (2,310 | ) |  | $ | (2,203 | ) |
| Total Accumulated other comprehensive loss | $ | (2,724 | ) |  | $ | (2,508 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-19-000013:notes:73]
The condensed consolidated financial statements as of March 30, 2019 and for the three months ended March 30, 2019 and March 31, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statements of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-19-000013:notes:74]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three months ended March 30, 2019 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-19-000013:notes:75]
[same as prior period, unchanged from 0000068505-18-000029:notes:101]


## us-gaap:CapitalizedContractCostTableTextBlock

[0000068505-19-000013:notes:76]
Contract Cost Balances

[0000068505-19-000013:notes:77]
|  | March 30, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 36 |  |  | $ | 30 |  |
| Non-current contract cost assets | 99 |  |  | 98 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-19-000013:notes:78]
Commitments and Contingencies

[0000068505-19-000013:notes:79]
Legal Matters

[0000068505-19-000013:notes:80]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-19-000013:notes:81]
Other Indemnifications

[0000068505-19-000013:notes:82]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-19-000013:notes:83]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at March 30, 2019.

[0000068505-19-000013:notes:84]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000068505-19-000013:notes:85]
|  | March 30, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,150 |  |  | $ | 1,293 |  |
| Contract assets | 878 |  |  | 1,012 |  |
| Contract liabilities | 1,158 |  |  | 1,263 |  |
| Non-current contract liabilities | 239 |  |  | 214 |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-19-000013:notes:86]
Debt and Credit Facilities

[0000068505-19-000013:notes:87]
As of March 30, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 30, 2019. During the first quarter of 2018, the Company borrowed $400 million to facilitate the Avigilon acquisition. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of March 30, 2019.

[0000068505-19-000013:notes:88]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three months ended March 30, 2019 was 3.75%. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-19-000013:notes:89]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan.

[0000068505-19-000013:notes:90]
As of March 30, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of March 30, 2019 was $876 million. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-19-000013:notes:91]
[same as prior period, unchanged from 0000068505-18-000029:notes:117]

[0000068505-19-000013:notes:92]
[same as prior period, unchanged from 0000068505-18-000029:notes:118]

[0000068505-19-000013:notes:93]
As of March 30, 2019, the Company had outstanding foreign exchange contracts with notional amounts totaling $897 million, compared to $819 million outstanding at December 31, 2018. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-19-000013:notes:94]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of March 30, 2019, and the corresponding positions as of December 31, 2018:

[0000068505-19-000013:notes:95]
|  | Notional Amount |
| Net Buy (Sell) by Currency | March 30, 2019 |  | December 31, 2018 |
| Euro | $ | 136 |  |  | $ | 89 |  |
| Norwegian Krone | 34 |  |  | 28 |  |
| Australian Dollar | (83 | ) |  | (105 | ) |
| Chinese Renminbi | (59 | ) |  | (55 | ) |
| Brazilian Real | (41 | ) |  | (41 | ) |

[0000068505-19-000013:notes:96]
[same as prior period, unchanged from 0000068505-18-000029:notes:122]

[0000068505-19-000013:notes:97]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of March 30, 2019, all of the counterparties have investment grade credit ratings. As of March 30, 2019, the Company had $7 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-19-000013:notes:98]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of March 30, 2019 and December 31, 2018:

[0000068505-19-000013:notes:99]
|  | Fair Values of Derivative Instruments |
| March 30, 2019 | Other Current Assets | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 2 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | $ | 3 |  |
| Total derivatives | $ | 7 |  |  | $ | 3 |  |

[0000068505-19-000013:notes:100]
|  | Fair Values of Derivative Instruments |
| December 31, 2018 | Other Current Assets | Accrued Liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 5 |  |  | $ | 4 |  |

[0000068505-19-000013:notes:101]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three months ended March 30, 2019 and March 31, 2018:

[0000068505-19-000013:notes:102]
|  | Three Months Ended |  | Financial Statement Location |
| Foreign Exchange Contracts | March 30, 2019 |  | March 31, 2018 |  |
| Effective portion | $ | 2 |  |  | $ | (3 | ) |  | Accumulated othercomprehensive loss |
| Forward points recognized | 1 |  |  | — |  |  | Other income (expense) |
| Undesignated derivatives recognized | (4 | ) |  | (4 | ) |  | Other income (expense) |

[0000068505-19-000013:notes:103]
Net Investment Hedges

[0000068505-19-000013:notes:104]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and Euro dollar exchange rate fluctuations on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. In accordance with ASU 2017-02, the Company has elected to exclude the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. As of March 30, 2019, the Company had €95 million of net investment hedges in certain Euro functional subsidiaries and £75 million of net investment hedges in certain British pound functional subsidiaries. During the first quarter of 2019, the Company amortized $1 million of income from the excluded components through interest expense.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000068505-19-000013:notes:105]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 30, 2019 and March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-19-000013:notes:106]
|  | March 30, 2019 |  | March 31, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 813 |  |  | $ | 352 |  |  | $ | 699 |  |  | $ | 296 |  |
| EMEA | 164 |  |  | 199 |  |  | 156 |  |  | 182 |  |
| Asia Pacific | 92 |  |  | 37 |  |  | 97 |  |  | 38 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 686 |  |  | $ | — |  |  | $ | 632 |  |  | $ | — |  |
| Systems and Systems Integration | 383 |  |  | — |  |  | 320 |  |  | — |  |
| Services | — |  |  | 452 |  |  | — |  |  | 446 |  |
| Software | — |  |  | 136 |  |  | — |  |  | 70 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 657 |  |  | $ | 553 |  |  | $ | 617 |  |  | $ | 506 |  |
| Indirect | 412 |  |  | 35 |  |  | 335 |  |  | 10 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-19-000013:notes:107]
[same as prior period, unchanged from 0000068505-18-000029:notes:133]

[0000068505-19-000013:notes:108]
During the three months ended March 30, 2019, the Company granted 0.5 million restricted stock units ("RSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $56 million and $7 million, respectively, and 0.2 million stock options and 0.2 million performance options ("POs") with an aggregate grant-date fair value of $6 million and $7 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-19-000013:notes:109]
The Company granted an additional 0.4 million of restricted stock in connection with the acquisition of VaaS, with an aggregate grant-date fair value of $38 million related to compensation withheld from the purchase price that will be expensed over an average service period of one year.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-19-000013:notes:110]
[same as prior period, unchanged from 0000068505-18-000029:notes:135]

[0000068505-19-000013:notes:111]
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-19-000013:notes:112]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-19-000013:notes:113]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-19-000013:notes:114]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-19-000013:notes:115]
The Company had no Level 3 holdings as of March 30, 2019 or December 31, 2018.

[0000068505-19-000013:notes:116]
At March 30, 2019 and December 31, 2018, the Company had $348 million and $734 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-19-000013:notes:117]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at March 30, 2019 and December 31, 2018 was $5.5 billion and $5.4 billion (Level 2), respectively.

[0000068505-19-000013:notes:118]
[same as prior period, unchanged from 0000068505-18-000029:notes:144]


## us-gaap:FinanceLeaseLiabilityMaturityTableTextBlock

[0000068505-19-000013:notes:119]
Future lease payments as of March 30, 2019 are as follows:

[0000068505-19-000013:notes:120]
|  | Operating Leases |  | Finance Leases |  | Total |
| 2019 | $ | 102 |  |  | $ | 13 |  |  | $ | 115 |  |
| 2020 | 134 |  |  | 14 |  |  | 148 |  |
| 2021 | 119 |  |  | 12 |  |  | 131 |  |
| 2022 | 106 |  |  | 5 |  |  | 111 |  |
| 2023 | 54 |  |  | — |  |  | 54 |  |
| Thereafter | 267 |  |  | — |  |  | 267 |  |
| Total lease payments | 782 |  |  | 44 |  |  | 826 |  |
| Less: Interest | 113 |  |  | 4 |  |  | 117 |  |
| Present value of lease liabilities | $ | 669 |  |  | $ | 40 |  |  | $ | 709 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-19-000013:notes:121]
[same as prior period, unchanged from 0000068505-18-000029:notes:145]

[0000068505-19-000013:notes:122]
[same as prior period, unchanged from 0000068505-18-000029:notes:146]

[0000068505-19-000013:notes:123]
Recent Acquisitions

[0000068505-19-000013:notes:124]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be a part of both the Products and Systems Integration and Services and Software segments. The Company recognized $73 million of identifiable intangible assets, $59 million of goodwill, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $49 million of completed technology and $24 million of customer relationship intangibles and will be amortized over a period of 15 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts, intangible assets, goodwill, and net assets may be subject to change based on the finalization of assumptions and settlement of working capital considerations.

[0000068505-19-000013:notes:125]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. This acquisition expands the Company's command center software portfolio under the Services and Software segment. The Company recognized $271 million of goodwill, $141 million of identifiable intangible assets and $21 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of 15 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts, goodwill, intangible assets, and net liabilities may be subject to change based on the finalization of assumptions and settlement of working capital considerations.

[0000068505-19-000013:notes:126]
[same as prior period, unchanged from 0000068505-18-000029:notes:159]

[0000068505-19-000013:notes:127]
[same as prior period, unchanged from 0000068505-18-000029:notes:147]

[0000068505-19-000013:notes:128]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. Prior to the end of the first quarter of 2018, $35 million of the assumed debt was repaid with the remaining $40 million repaid during the second quarter of 2018.

[0000068505-19-000013:notes:129]
The acquisition of Avigilon has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value. The purchase accounting has been completed as of March 30, 2019. The following table summarizes fair values of assets acquired and liabilities assumed as of the March 28, 2018 acquisition date:

[0000068505-19-000013:notes:130]
| Accounts receivable, net |  | $ | 67 |  |
| Inventory |  | 93 |  |
| Other current assets |  | 18 |  |
| Property, plant and equipment, net |  | 33 |  |
| Deferred income taxes |  | 4 |  |
| Accounts payable |  | (21 | ) |
| Accrued liabilities |  | (28 | ) |
| Deferred income tax liabilities |  | (124 | ) |
| Goodwill |  | 434 |  |
| Intangible assets |  | 498 |  |
| Total consideration |  | $ | 974 |  |

[0000068505-19-000013:notes:131]
Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to twenty years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-19-000013:notes:132]
Goodwill was calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. The goodwill is not deductible for tax purposes.

[0000068505-19-000013:notes:133]
The pro forma effect of this acquisition was not significant.

[0000068505-19-000013:notes:134]
[same as prior period, unchanged from 0000068505-18-000029:notes:154]

[0000068505-19-000013:notes:135]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million in cash, net cash acquired. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1. The Company recognized $160 million of goodwill, $80 million of identifiable intangible assets, and $3 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of ten to twenty years. The pro forma effect of this acquisition was not significant.

[0000068505-19-000013:notes:136]
[same as prior period, unchanged from 0000068505-18-000029:notes:160]

[0000068505-19-000013:notes:137]
[same as prior period, unchanged from 0000068505-18-000029:notes:161]

[0000068505-19-000013:notes:138]
|  | March 30, 2019 |  | December 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 707 |  |  | $ | 105 |  |  | $ | 558 |  |  | $ | 92 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,187 |  |  | 414 |  |  | 1,085 |  |  | 364 |  |
| Other intangibles | 75 |  |  | 34 |  |  | 74 |  |  | 31 |  |
|  | $ | 1,971 |  |  | $ | 555 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-19-000013:notes:139]
Amortization expense on intangible assets was $50 million for the three months ended March 30, 2019 and $41 million for the three months ended March 31, 2018. As of March 30, 2019, annual amortization expense is estimated to be $205 million in 2019 and 2020, $202 million in 2021, $200 million in 2022, $99 million in 2023, and $73 million in 2024.

[0000068505-19-000013:notes:140]
[same as prior period, unchanged from 0000068505-18-000029:notes:164]

[0000068505-19-000013:notes:141]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2019 to March 30, 2019:

[0000068505-19-000013:notes:142]
|  | Products and Systems Integration |  | Services and Software |  | Total |
| Balance as of January 1, 2019 | $ | 722 |  |  | $ | 792 |  |  | $ | 1,514 |  |
| Goodwill acquired | 47 |  |  | 283 |  |  | 330 |  |
| Purchase accounting adjustments | — |  |  | 9 |  |  | 9 |  |
| Foreign currency | — |  |  | 7 |  |  | 7 |  |
| Balance as of March 30, 2019 | $ | 769 |  |  | $ | 1,091 |  |  | $ | 1,860 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-19-000013:notes:143]
[same as prior period, unchanged from 0000068505-18-000029:notes:168]

[0000068505-19-000013:notes:144]
[same as prior period, unchanged from 0000068505-18-000029:notes:169]

[0000068505-19-000013:notes:145]
[same as prior period, unchanged from 0000068505-18-000029:notes:170]

[0000068505-19-000013:notes:146]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Net earnings before income taxes | $ | 185 |  |  | $ | 140 |  |
| Income tax expense | 33 |  |  | 23 |  |
| Effective tax rate | 18 | % |  | 16 | % |

[0000068505-19-000013:notes:147]
The Company recorded $33 million of net tax expense during the three months ended March 30, 2019, resulting in an effective tax rate of 18%, compared to $23 million of net tax expense during the three months ended March 31, 2018, resulting in an effective tax rate of 16%. The effective tax rates for the three months ended March 30, 2019 of 18% and March 31, 2018 of 16% are lower than the U.S. statutory tax rate of 21% primarily due to excess tax benefits on share-based compensation.


## us-gaap:LeaseCostTableTextBlock

[0000068505-19-000013:notes:148]
|  | Three Months Ended |
|  | March 30, 2019 |
| Weighted average remaining lease terms (years): |  |
| Operating leases | 8 |  |
| Finance leases | 3 |  |
| Weighted average discount rate: |  |
| Operating leases | 3.74 | % |
| Finance leases | 4.97 | % |

[0000068505-19-000013:notes:149]
Other information related to leases is as follows:

[0000068505-19-000013:notes:150]
|  | Three Months Ended |
|  | March 30, 2019 |
| Supplemental cash flow information: |  |
| Net cash used for operating activities related to operating leases | $ | 33 |  |
| Net cash used for operating activities related to finance leases | 1 |  |
| Net cash used for financing activities related to finance leases | 4 |  |
| Assets obtained in exchange for lease liabilities: |  |
| Operating leases | $ | 27 |  |

[0000068505-19-000013:notes:151]
The components of lease expense are as follows:

[0000068505-19-000013:notes:152]
|  |  | Three Months Ended |
|  |  | March 30, 2019 |
| Lease expense: |  |  |
| Operating lease cost |  | $ | 33 |  |
| Finance lease cost |  |  |
| Amortization of right-of-use assets |  | 3 |  |
| Interest on lease liabilities |  | 1 |  |
| Total finance lease cost |  | 4 |  |
| Short-term lease cost |  | 2 |  |
| Variable cost |  | 9 |  |
| Sublease income |  | (1 | ) |
| Net lease expense |  | $ | 47 |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-19-000013:notes:153]
Leases

[0000068505-19-000013:notes:154]
The Company leases certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases.

[0000068505-19-000013:notes:155]
The Company determines if an arrangement is a lease at inception of the contract. The Company's key decisions in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company's contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the rights to operate the asset at its discretion during the term of the contract.

[0000068505-19-000013:notes:156]
ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company's lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in the lease liabilities. For the Company's leases consisting of both land and other equipment (i.e. "communication network sites"), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs also include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage. ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-19-000013:notes:157]
As the majority of the Company's leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company's incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-19-000013:notes:158]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communication network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-19-000013:notes:159]
Rental expense, net of sublease income, for the year ended December 31, 2018 was $108 million.

[0000068505-19-000013:notes:160]
At December 31, 2018, future minimum lease obligations, net of minimum sublease rentals, for the next five years and beyond were as follows:

[0000068505-19-000013:notes:161]
| 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Beyond |  |
| $ | 131 |  | $ | 120 |  | $ | 112 |  | $ | 101 |  | $ | 54 |  | $ | 204 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-19-000013:notes:162]
Recent Accounting Pronouncements

[0000068505-19-000013:notes:163]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-19-000013:notes:164]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. This was subsequently amended by ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which clarifies that receivables arising from operating leases are not within the scope of the ASU and amends the transition requirements. The ASU is effective for the Company on January 1, 2020 with early adoption permitted beginning as of January 1, 2019. The ASU requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-19-000013:notes:165]
Recently Adopted Accounting Pronouncements

[0000068505-19-000013:notes:166]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-19-000013:notes:167]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1,2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

[0000068505-19-000013:notes:168]
ASC 842 provides for a number of optional practical expedients in transition. The Company elected the practical expedients, which permit the Company to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. The Company did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing it to carry forward the lease term as determined prior to adoption of ASC 842. Finally, the Company also elected the practical expedient related to land easements, which enabled it to continue its accounting treatment for land easements on existing agreements as of January 1, 2019.

[0000068505-19-000013:notes:169]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. The Company elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows the Company to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with the Company’s prior accounting. The Company also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

[0000068505-19-000013:notes:170]
The Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition. In future periods such balances will not be presented separately.

[0000068505-19-000013:notes:171]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (1) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (2) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 Revenue from Contract with Customers and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-19-000013:notes:172]
[same as prior period, unchanged from 0000068505-18-000029:notes:189]

[0000068505-19-000013:notes:173]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Services and Software segments.

[0000068505-19-000013:notes:174]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's command center software portfolio under the Services and Software segment.

[0000068505-19-000013:notes:175]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash.

[0000068505-19-000013:notes:176]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-19-000013:notes:177]
[same as prior period, unchanged from 0000068505-18-000029:notes:205]

[0000068505-19-000013:notes:178]
[same as prior period, unchanged from 0000068505-18-000029:notes:206]

[0000068505-19-000013:notes:179]
[same as prior period, unchanged from 0000068505-18-000029:notes:207]

[0000068505-19-000013:notes:180]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 51 |  |  | 46 |  |  | 10 |  |  | 10 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (69 | ) |  | (68 | ) |  | (21 | ) |  | (24 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 12 |  |  | 14 |  |  | 4 |  |  | 3 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Net periodic pension benefit | $ | (6 | ) |  | $ | (8 | ) |  | $ | (6 | ) |  | $ | (10 | ) |  | $ | (5 | ) |  | $ | (5 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-19-000013:notes:181]
[same as prior period, unchanged from 0000068505-18-000029:notes:211]

[0000068505-19-000013:notes:182]
2019 Charges

[0000068505-19-000013:notes:183]
During the three months ended March 30, 2019, the Company recorded net reorganization of business charges of $8 million including $4 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $8 million were charges of $12 million related to employee separation, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-19-000013:notes:184]
The following table displays a rollforward of the reorganization of business accruals established for employee separation costs from January 1, 2019 to March 30, 2019:

[0000068505-19-000013:notes:185]
|  | January 1, 2019 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | March 30, 2019 |
| Employee separation costs | $ | 84 |  |  | $ | 12 |  |  | $ | (4 | ) |  | $ | (14 | ) |  | $ | 78 |  |

[0000068505-19-000013:notes:186]
[same as prior period, unchanged from 0000068505-18-000029:notes:219]

[0000068505-19-000013:notes:187]
At January 1, 2019, the Company had an accrual of $84 million for employee separation costs. The 2019 additional charges of $12 million represent severance costs for approximately 100 employees. The adjustment of $4 million reflects reversals for accruals no longer needed. The $14 million used reflects cash payments to severed employees. The remaining accrual of $78 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at March 30, 2019, is expected to be paid, primarily within one year, to approximately 700 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-19-000013:notes:188]
As of January 1, 2019, accruals for exit costs are included in Operating lease liabilities with an offsetting impairment to the Company's ROU assets, all within its Condensed Consolidated Balance Sheets (see Note 3).

[0000068505-19-000013:notes:189]
[same as prior period, unchanged from 0000068505-18-000029:notes:212]

[0000068505-19-000013:notes:190]
During the three months ended March 31, 2018, the Company recorded net reorganization of business charges of $13 million including $8 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $22 million related to employee separation costs and $2 million related to exit costs, partially offset by $11 million of reversals for accruals no longer needed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-19-000013:notes:191]
[same as prior period, unchanged from 0000068505-18-000029:notes:224]

[0000068505-19-000013:notes:192]
[same as prior period, unchanged from 0000068505-18-000029:notes:225]

[0000068505-19-000013:notes:193]
[same as prior period, unchanged from 0000068505-18-000029:notes:234]

[0000068505-19-000013:notes:194]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 30, 2019 is $7.0 billion. A total of $3.0 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.6 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.0 billion is from Services and Software performance obligations that are not yet satisfied as of March 30, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-19-000013:notes:195]
[same as prior period, unchanged from 0000068505-18-000029:notes:236]

[0000068505-19-000013:notes:196]
Revenue recognized during the three months ended March 30, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $393 million, compared to $297 million of revenue recognized during the three months ended March 31, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $9 million was reversed during the three months ended March 30, 2019 and $9 million of revenue was recognized during the three months ended March 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-19-000013:notes:197]
There were no material impairment losses recognized on contract assets during the three months ended March 30, 2019 and March 31, 2018.

[0000068505-19-000013:notes:198]
Amortization of contract cost assets was $11 million and $12 million for the three months ended March 30, 2019 and March 31, 2018, respectively.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-19-000013:notes:199]
[same as prior period, unchanged from 0000068505-18-000029:notes:242]

[0000068505-19-000013:notes:200]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Products and Systems Integration | $ | 1,069 |  |  | $ | 952 |  |
| Services and Software | 588 |  |  | 516 |  |
|  | $ | 1,657 |  |  | $ | 1,468 |  |

[0000068505-19-000013:notes:201]
[same as prior period, unchanged from 0000068505-18-000029:notes:244]

[0000068505-19-000013:notes:202]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Products and Systems Integration | $ | 108 |  |  | $ | 90 |  |
| Services and Software | 121 |  |  | 81 |  |
| Operating earnings | 229 |  |  | 171 |  |
| Total other expense | (44 | ) |  | (31 | ) |
| Earnings before income taxes | $ | 185 |  |  | $ | 140 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-19-000013:notes:203]
[same as prior period, unchanged from 0000068505-18-000029:notes:246]

[0000068505-19-000013:notes:204]
[same as prior period, unchanged from 0000068505-18-000029:notes:247]

[0000068505-19-000013:notes:205]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, including video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions and typically managing a mobile workforce.

[0000068505-19-000013:notes:206]
Services and Software: The Services and Software segment provides a broad range of solution offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced platforms include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on premise and “as a service.”
