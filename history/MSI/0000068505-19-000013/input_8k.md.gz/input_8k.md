# MSI 8-K — 0000068505-19-000011 filed 2019-05-02

## item codes, every 8-K on or before 2019-05-03

- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2019-05-03

- none on or before 2019-05-03

## item 2.02 — earnings release, exhibit 99.1

[0000068505-19-000011:8k_2_02:1]
EX-99.1
2
msiq12019pressrelease.htm
EXHIBIT 99.1

[0000068505-19-000011:8k_2_02:2]
Exhibit

[0000068505-19-000011:8k_2_02:3]
Exhibit 99.1

[0000068505-19-000011:8k_2_02:4]
Motorola Solutions Reports First-Quarter 2019 Financial Results

[0000068505-19-000011:8k_2_02:5]
Record Q1 revenue, operating earnings and ending backlog; raises full-year earnings outlook

[0000068505-19-000011:8k_2_02:6]
| • | Revenue of $1.7 billion, up 13% from a year ago |

[0000068505-19-000011:8k_2_02:7]
| • | Operating cash flow of $251 million, up $751 million* from a year ago |

[0000068505-19-000011:8k_2_02:8]
| • | GAAP earnings per share (EPS) of $0.86, up 25% |

[0000068505-19-000011:8k_2_02:9]
| • | Non-GAAP EPS** of $1.28, up 16% |

[0000068505-19-000011:8k_2_02:10]
| • | Backlog of $10.4 billion, up $781 million from a year ago |

[0000068505-19-000011:8k_2_02:11]
CHICAGO – May 2, 2019 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the first quarter of 2019. Click here for a printable news release and financial tables.

[0000068505-19-000011:8k_2_02:12]
"Q1 was another outstanding quarter, with record first-quarter revenue, operating earnings and ending backlog,” said Greg Brown, chairman and CEO of Motorola Solutions. “We are well positioned for 2019 with continued demand across our platforms.”

[0000068505-19-000011:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-19-000011:8k_2_02:14]
|  | Q1 2019 |  | Q1 2018 |  | % Change |
| Sales | $1,657 | $1,468 | 13 | % |
| GAAP |  |  |  |
| Operating Earnings | $229 | $171 | 34 | % |
| % of Sales | 13.8 | % | 11.6 | % |  |
| EPS | $0.86 | $0.69 | 25 | % |
| Non-GAAP |  |  |  |
| Operating Earnings | $315 | $260 | 21 | % |
| % of Sales | 19.0 | % | 17.7 | % |  |
| EPS | $1.28 | $1.10 | 16 | % |
| Products and Systems Integration Segment |  |  |  |
| Sales | $1,069 | $952 | 12 | % |
| GAAP Operating Earnings | $108 | $90 | 20 | % |
| % of Sales | 10.1 | % | 9.5 | % |  |
| Non-GAAP Operating Earnings | $147 | $125 | 18 | % |
| % of Sales | 13.8 | % | 13.1 | % |  |
| Services and Software Segment |  |  |  |
| Sales | $588 | $516 | 14 | % |
| GAAP Operating Earnings | $121 | $81 | 49 | % |
| % of Sales | 20.6 | % | 15.7 | % |  |
| Non-GAAP Operating Earnings | $168 | $135 | 24 | % |
| % of Sales | 28.6 | % | 26.2 | % |  |

[0000068505-19-000011:8k_2_02:15]
* Includes voluntary $500M debt-funded U.S. pension contribution in Q1 2018

[0000068505-19-000011:8k_2_02:16]
**Non-GAAP financial information excludes the after-tax impact of approximately $0.42 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-19-000011:8k_2_02:17]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-19-000011:8k_2_02:18]
| • | Revenue - Sales were $1.7 billion, up $189 million, or 13% from the year-ago quarter, driven by growth in the Americas and EMEA. Revenue from acquisitions was $137 million in the quarter. The Products and Systems Integration segment grew 12%, and the Services and Software segment grew 14%. Both segments were driven by growth in the Americas and EMEA. |

[0000068505-19-000011:8k_2_02:19]
| • | Operating margin - GAAP operating margin was 13.8% of sales, compared with 11.6% in the year-ago quarter. The improvement was primarily due to higher sales and gross margin, partially offset by higher operating expenses related to acquisitions. Non-GAAP operating margin was 19.0% of sales, compared with 17.7% in the year-ago quarter due to higher sales and gross margin partially offset by higher operating expenses related to acquisitions. |

[0000068505-19-000011:8k_2_02:20]
| • | Taxes - The GAAP effective tax rate was 18%, compared with 16% in the year-ago quarter. The non-GAAP effective tax rate was 20% compared with 19% in the year-ago quarter. Rates were favorably impacted by tax benefits on excess share-based compensation. |

[0000068505-19-000011:8k_2_02:21]
| • | Cash flow - Operating cash flow was $251 million, compared with $500 million of operating cash outflow in the year-ago quarter. Free cash flow1 was $185 million, compared with $541 million of free cash outflow in the year-ago quarter. Cash flow for the quarter increased due to a $500 million voluntary pension contribution in the prior year, timing of annual incentive payments, higher earnings and improved working capital. |

[0000068505-19-000011:8k_2_02:22]
| • | Capital allocation - The company invested $445 million of cash and equity to acquire VaaS International Holdings and $136 million in cash for Avtec, Inc., repurchased $145 million of common stock, paid $93 million in cash dividends and $66 million of capital expenditures. |

[0000068505-19-000011:8k_2_02:23]
| • | Backlog - The company ended the quarter with backlog of $10.4 billion, up $781 million from the year-ago quarter. Services and Software was up 14% or $885 million due to growth in EMEA and the Americas. Products and Systems Integration segment backlog was down 3% or $104 million due to large projects in the Middle East and Africa in the prior year, partially offset by growth in the Americas. |

[0000068505-19-000011:8k_2_02:24]
KEY HIGHLIGHTS

[0000068505-19-000011:8k_2_02:25]
Services and Software wins

[0000068505-19-000011:8k_2_02:26]
| • | $17 million managed services contract with a mining customer in Latin America |

[0000068505-19-000011:8k_2_02:27]
| • | $7 million computer-aided dispatch (CAD) and records contract for a large government customer in California |

[0000068505-19-000011:8k_2_02:28]
| • | $5 million video services renewal with the Chicago Office of Emergency Management |

[0000068505-19-000011:8k_2_02:29]
Products and Systems Integration wins

[0000068505-19-000011:8k_2_02:30]
| • | Selected by North Dakota for a new statewide P25 radio system |

[0000068505-19-000011:8k_2_02:31]
| • | $25 million P25 win with New South Wales Telco Authority |

[0000068505-19-000011:8k_2_02:32]
| • | $8 million TETRA order for a utility customer in Chile |

[0000068505-19-000011:8k_2_02:33]
BUSINESS OUTLOOK

[0000068505-19-000011:8k_2_02:34]
| • | Second-quarter 2019 - Motorola Solutions expects revenue growth of approximately 4 to 5% compared with the second quarter of 2018. The company expects non-GAAP earnings in the range of $1.55 to $1.60 per share. This assumes current foreign exchange rates, approximately 176 million fully diluted shares and an effective tax rate of approximately 24%. |

[0000068505-19-000011:8k_2_02:35]
| • | Full-year 2019 - The company continues to expect revenue growth of approximately 6 to 7% and now expects non-GAAP earnings per share in the range of $7.60 to $7.72, up from the prior guidance of $7.55 to $7.70. This assumes current foreign exchange rates, approximately 176 million fully diluted shares and an effective tax rate of 24 to 25%. |

[0000068505-19-000011:8k_2_02:36]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, May 2. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-19-000011:8k_2_02:37]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-19-000011:8k_2_02:38]
A comparison of results from operations is as follows:

[0000068505-19-000011:8k_2_02:39]
|  | Q1 2019 |  | Q1 2018 |  |
| Net sales | $1,657 | $1,468 |
| Gross margin | 773 |  | 669 |  |
| Operating earnings | 229 |  | 171 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 151 |  | 117 |  |
| Diluted EPS | $0.86 | $0.69 |
| Weighted average diluted common shares outstanding | 174.6 |  | 170.6 |  |

[0000068505-19-000011:8k_2_02:40]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-19-000011:8k_2_02:41]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the first quarter of 2019.

[0000068505-19-000011:8k_2_02:42]
| (per diluted common share) | Q1 2019 |  |
| GAAP Earnings | $0.86 |
| Highlighted Items: |  |
| Share-based compensation expense | 0.12 |  |
| Reorganization of business charges | 0.04 |  |
| Intangibles amortization expense | 0.23 |  |
| Legal settlement | (0.01 | ) |
| Fair value adjustments to equity investments | 0.01 |  |
| Investment impairments | 0.04 |  |
| Sale of investments | (0.01 | ) |
| Acquisition-related transaction fees | 0.01 |  |
| FIN48 release | (0.01 | ) |
| Non-GAAP Diluted EPS | $1.28 |

[0000068505-19-000011:8k_2_02:43]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-19-000011:8k_2_02:44]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-19-000011:8k_2_02:45]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments, significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-19-000011:8k_2_02:46]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-19-000011:8k_2_02:47]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-19-000011:8k_2_02:48]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-19-000011:8k_2_02:49]
BUSINESS RISKS

[0000068505-19-000011:8k_2_02:50]
“intends,” “anticipates,” “estimates” and similar expressions. The company can give no assurance that any actual or future results or events discussed in these statements will be achieved. Any forward-looking statements represent the company’s views only as of today and should not be relied upon as representing the company’s views as of any subsequent date. Readers are cautioned that such forward-looking statements are subject to a variety of risks and uncertainties that could cause the company’s actual results to differ materially from the statements contained in this release. Such forward-looking statements include, but are not limited to, Motorola Solutions’ financial outlook for the second quarter and full year of 2019. Motorola Solutions cautions the reader that the risk factors below, as well as those on pages 9 through 21 in Item 1A of Motorola Solutions’ 2018 Annual Report on Form 10-K and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at www.motorolasolutions.com, could cause Motorola Solutions’ actual results to differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (1) the economic outlook for the government communications industry; (2) the impact of foreign currency fluctuations on the company; (3) the level of demand for the company's products; (4) the company's ability to refresh existing and introduce new products and technologies in a timely manner; (5) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (6) negative impact on the company's business from global economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company's products; (iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company's suppliers that may no longer have access to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company's pension plan and other defined benefit plans, which could impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (7) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or those it sells to or operates or maintains for its customers; (8) the outcome of ongoing and future tax matters; (9) the company's ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (10) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (11) the impact on the company's performance and financial results from strategic acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-19-000011:8k_2_02:51]
DEFINITIONS

[0000068505-19-000011:8k_2_02:52]
1  Free cash flow represents operating cash flow less capital expenditures.

[0000068505-19-000011:8k_2_02:53]
ABOUT MOTOROLA SOLUTIONS

[0000068505-19-000011:8k_2_02:54]
Motorola Solutions is a global leader in mission-critical communications. Our technology platforms in communications, command center software, video and services make cities safer and help communities and businesses thrive. At Motorola Solutions, we are ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com

[0000068505-19-000011:8k_2_02:55]
MEDIA CONTACT

[0000068505-19-000011:8k_2_02:56]
Kate Dyer

[0000068505-19-000011:8k_2_02:57]
Motorola Solutions

[0000068505-19-000011:8k_2_02:58]
+1 224-374-3124

[0000068505-19-000011:8k_2_02:59]
Kate.Dyer@motorolasolutions.com

[0000068505-19-000011:8k_2_02:60]
INVESTOR CONTACT

[0000068505-19-000011:8k_2_02:61]
Chris Kutsor

[0000068505-19-000011:8k_2_02:62]
Motorola Solutions

[0000068505-19-000011:8k_2_02:63]
+1 847-576-4995

[0000068505-19-000011:8k_2_02:64]
chris.kutsor@motorolasolutions.com

[0000068505-19-000011:8k_2_02:65]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2019 Motorola Solutions, Inc. All rights reserved.

[0000068505-19-000011:8k_2_02:66]
GAAP-1

[0000068505-19-000011:8k_2_02:67]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:68]
Condensed Consolidated Statements of Operations

[0000068505-19-000011:8k_2_02:69]
(In millions, except per share amounts)

[0000068505-19-000011:8k_2_02:70]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Net sales from products | $ | 945 |  |  | $ | 801 |  |
| Net sales from services | 712 |  |  | 667 |  |
| Net sales | 1,657 |  |  | 1,468 |  |
| Costs of products sales | 444 |  |  | 383 |  |
| Costs of services sales | 440 |  |  | 416 |  |
| Costs of sales | 884 |  |  | 799 |  |
| Gross margin | 773 |  |  | 669 |  |
| Selling, general and administrative expenses | 327 |  |  | 279 |  |
| Research and development expenditures | 162 |  |  | 152 |  |
| Other charges | 5 |  |  | 26 |  |
| Intangibles amortization | 50 |  |  | 41 |  |
| Operating earnings | 229 |  |  | 171 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (55 | ) |  | (46 | ) |
| Gains on sales of investments and businesses, net | 1 |  |  | 11 |  |
| Other | 10 |  |  | 4 |  |
| Total other expense | (44 | ) |  | (31 | ) |
| Net earnings before income taxes | 185 |  |  | 140 |  |
| Income tax expense | 33 |  |  | 23 |  |
| Net earnings | 152 |  |  | 117 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 151 |  |  | $ | 117 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 0.92 |  |  | $ | 0.73 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.69 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 164.0 |  |  | 161.4 |  |
| Diluted | 174.6 |  |  | 170.6 |  |

[0000068505-19-000011:8k_2_02:71]
|  | Percentage of Net Sales* |
| Net sales from products | 57.0 | % |  | 54.6 | % |
| Net sales from services | 43.0 | % |  | 45.4 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.0 | % |  | 47.8 | % |
| Costs of services sales | 61.8 | % |  | 62.4 | % |
| Costs of sales | 53.3 | % |  | 54.4 | % |
| Gross margin | 46.7 | % |  | 45.6 | % |
| Selling, general and administrative expenses | 19.7 | % |  | 19.0 | % |
| Research and development expenditures | 9.8 | % |  | 10.4 | % |
| Other charges | 0.3 | % |  | 1.8 | % |
| Intangibles amortization | 3.0 | % |  | 2.8 | % |
| Operating earnings | 13.8 | % |  | 11.6 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.3 | )% |  | (3.1 | )% |
| Gains on sales of investments and businesses, net | — | % |  | 0.7 | % |
| Other | 0.6 | % |  | 0.3 | % |
| Total other expense | (2.7 | )% |  | (2.1 | )% |
| Net earnings before income taxes | 11.2 | % |  | 9.5 | % |
| Income tax expense | 2.0 | % |  | 1.6 | % |
| Net earnings | 9.2 | % |  | 8.0 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 9.1 | % |  | 8.0 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-19-000011:8k_2_02:72]
GAAP-2

[0000068505-19-000011:8k_2_02:73]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:74]
Condensed Consolidated Balance Sheets

[0000068505-19-000011:8k_2_02:75]
(In millions)

[0000068505-19-000011:8k_2_02:76]
|  |  | March 30, 2019 |  | December 31, 2018 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 886 |  |  | $ | 1,246 |  |
| Restricted cash |  | 11 |  |  | 11 |  |
| Total cash and cash equivalents |  | 897 |  |  | 1,257 |  |
| Accounts receivable, net |  | 1,150 |  |  | 1,293 |  |
| Contract assets |  | 878 |  |  | 1,012 |  |
| Inventories, net |  | 425 |  |  | 356 |  |
| Other current assets |  | 364 |  |  | 354 |  |
| Total current assets |  | 3,714 |  |  | 4,272 |  |
| Property, plant and equipment, net |  | 937 |  |  | 895 |  |
| Operating lease assets |  | 593 |  |  | — |  |
| Investments |  | 163 |  |  | 169 |  |
| Deferred income taxes |  | 953 |  |  | 985 |  |
| Goodwill |  | 1,860 |  |  | 1,514 |  |
| Intangible assets, net |  | 1,416 |  |  | 1,230 |  |
| Other assets |  | 357 |  |  | 344 |  |
| Total assets |  | $ | 9,993 |  |  | $ | 9,409 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 28 |  |  | $ | 31 |  |
| Accounts payable |  | 558 |  |  | 592 |  |
| Contract liabilities |  | 1,158 |  |  | 1,263 |  |
| Accrued liabilities |  | 1,235 |  |  | 1,210 |  |
| Total current liabilities |  | 2,979 |  |  | 3,096 |  |
| Long-term debt |  | 5,287 |  |  | 5,289 |  |
| Operating lease liabilities |  | 553 |  |  | — |  |
| Other liabilities |  | 2,264 |  |  | 2,300 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,108 | ) |  | (1,293 | ) |
| Noncontrolling interests |  | 18 |  |  | 17 |  |
| Total liabilities and stockholders’ equity |  | $ | 9,993 |  |  | $ | 9,409 |  |

[0000068505-19-000011:8k_2_02:77]
GAAP-3

[0000068505-19-000011:8k_2_02:78]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:79]
Condensed Consolidated Statements of Cash Flows

[0000068505-19-000011:8k_2_02:80]
(In millions)

[0000068505-19-000011:8k_2_02:81]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 151 |  |  | $ | 117 |  |
| Earnings attributable to noncontrolling interests | 1 |  |  | — |  |
| Net earnings | 152 |  |  | 117 |  |
| Adjustments to reconcile Net earnings to Net cash provided by (used for) operating activities: |  |  |  |
| Depreciation and amortization | 95 |  |  | 82 |  |
| Non-cash other charges | 10 |  |  | 3 |  |
| Share-based compensation expense | 27 |  |  | 17 |  |
| Gains on sales of investments and businesses, net | (1 | ) |  | (11 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 168 |  |  | 195 |  |
| Inventories | (63 | ) |  | (9 | ) |
| Other current assets and contract assets | 136 |  |  | 2 |  |
| Accounts payable, accrued liabilities, and contract liabilities | (261 | ) |  | (350 | ) |
| Other assets and liabilities | (6 | ) |  | (553 | ) |
| Deferred income taxes | (6 | ) |  | 7 |  |
| Net cash provided by (used for) operating activities | 251 |  |  | (500 | ) |
| Investing |  |  |  |
| Acquisitions and investments, net | (368 | ) |  | (1,125 | ) |
| Proceeds from sales of investments and businesses, net | 2 |  |  | 77 |  |
| Capital expenditures | (66 | ) |  | (41 | ) |
| Net cash used for investing activities | (432 | ) |  | (1,089 | ) |
| Financing |  |  |  |
| Repayment of debt | (8 | ) |  | (50 | ) |
| Net proceeds from issuance of debt | — |  |  | 1,296 |  |
| Issuance of common stock | 45 |  |  | 53 |  |
| Purchases of common stock | (145 | ) |  | (66 | ) |
| Payments of dividends | (93 | ) |  | (84 | ) |
| Net cash provided by (used for) financing activities | (201 | ) |  | 1,149 |  |
| Effect of exchange rate changes on cash and cash equivalents | 22 |  |  | 30 |  |
| Net decrease in cash and cash equivalents | (360 | ) |  | (410 | ) |
| Cash and cash equivalents, beginning of period | 1,257 |  |  | 1,268 |  |
| Cash and cash equivalents, end of period | $ | 897 |  |  | $ | 858 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 185 |  |  | $ | (541 | ) |
| *Free cash flow = Net cash provided by (used for) operating activities - Capital expenditures |  |  |  |

[0000068505-19-000011:8k_2_02:82]
GAAP-4

[0000068505-19-000011:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:84]
Segment Information

[0000068505-19-000011:8k_2_02:85]
(In millions)

[0000068505-19-000011:8k_2_02:86]
| Net Sales |
|  | Three Months Ended |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 1,069 |  |  | $ | 952 |  |  | 12 | % |
| Services and Software | 588 |  |  | 516 |  |  | 14 | % |
| Total Motorola Solutions | $ | 1,657 |  |  | $ | 1,468 |  |  | 13 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 108 |  |  | $ | 90 |  |  | 20 | % |
| Services and Software | 121 |  |  | 81 |  |  | 49 | % |
| Total Motorola Solutions | $ | 229 |  |  | $ | 171 |  |  | 34 | % |

[0000068505-19-000011:8k_2_02:87]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  |  |
| Products and Systems Integration | 10.1 | % |  | 9.5 | % |  |  |
| Services and Software | 20.6 | % |  | 15.7 | % |  |  |
| Total Motorola Solutions | 13.8 | % |  | 11.6 | % |  |  |

[0000068505-19-000011:8k_2_02:88]
Non-GAAP-1

[0000068505-19-000011:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:90]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-19-000011:8k_2_02:91]
(In millions)

[0000068505-19-000011:8k_2_02:92]
| Q1 2019 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 27 |  |  | $ | 6 |  |  | $ | 21 |  |  | $ | 0.12 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 50 |  |  | 11 |  |  | 39 |  |  | 0.23 |  |
| Legal settlement |  | Other charges |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Fair value adjustments to equity investments |  | Other expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Investment impairments |  | Investment impairments |  | 8 |  |  | 2 |  |  | 6 |  |  | 0.04 |  |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | (1 | ) |  | — |  |  | (1 | ) |  | (0.01 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| FIN48 release |  | Income tax expense |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Total impact on Net earnings |  |  |  | $ | 94 |  |  | $ | 22 |  |  | $ | 72 |  |  | $ | 0.42 |  |

[0000068505-19-000011:8k_2_02:93]
Non-GAAP-2

[0000068505-19-000011:8k_2_02:94]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:95]
Non-GAAP Segment Information

[0000068505-19-000011:8k_2_02:96]
(In millions)

[0000068505-19-000011:8k_2_02:97]
| Net Sales |
|  | Three Months Ended |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 1,069 |  |  | $ | 952 |  |  | 12 | % |
| Services and Software | 588 |  |  | 516 |  |  | 14 | % |
| Total Motorola Solutions | $ | 1,657 |  |  | $ | 1,468 |  |  | 13 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Products and Systems Integration | $ | 147 |  |  | $ | 125 |  |  | 18 | % |
| Services and Software | 168 |  |  | 135 |  |  | 24 | % |
| Total Motorola Solutions | $ | 315 |  |  | $ | 260 |  |  | 21 | % |

[0000068505-19-000011:8k_2_02:98]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  |  |
| Products and Systems Integration | 13.8 | % |  | 13.1 | % |  |  |
| Services and Software | 28.6 | % |  | 26.2 | % |  |  |
| Total Motorola Solutions | 19.0 | % |  | 17.7 | % |  |  |

[0000068505-19-000011:8k_2_02:99]
Non-GAAP-3

[0000068505-19-000011:8k_2_02:100]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:101]
Operating Earnings after Non-GAAP Adjustments

[0000068505-19-000011:8k_2_02:102]
(In millions)

[0000068505-19-000011:8k_2_02:103]
| Q1 2019 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,657 |  |  | $ | 1,069 |  |  | $ | 588 |  |
| Operating earnings ("OE") |  | $ | 229 |  |  | $ | 108 |  |  | $ | 121 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 27 |  |  | 21 |  |  | 6 |  |
| Reorganization of business charges |  | 8 |  |  | 7 |  |  | 1 |  |
| Intangibles amortization expense |  | 50 |  |  | 11 |  |  | 39 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 1 |  |  | 1 |  |
| Legal settlement |  | (1 | ) |  | (1 | ) |  | — |  |
| Total above-OE non-GAAP adjustments |  | 86 |  |  | 39 |  |  | 47 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 315 |  |  | $ | 147 |  |  | $ | 168 |  |

[0000068505-19-000011:8k_2_02:104]
| Operating earnings as a percentage of net sales - GAAP |  | 13.8 | % |  | 10.1 | % |  | 20.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 19.0 | % |  | 13.8 | % |  | 28.6 | % |

[0000068505-19-000011:8k_2_02:105]
Non-GAAP-4

[0000068505-19-000011:8k_2_02:106]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-19-000011:8k_2_02:107]
Non-GAAP Organic Revenue

[0000068505-19-000011:8k_2_02:108]
(In millions)

[0000068505-19-000011:8k_2_02:109]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |
|  |  | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Net sales |  | $ | 1,657 |  |  | $ | 1,468 |  |  | 13 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (159 | ) |  | (22 | ) |  |  |
| Organic revenue |  | $ | 1,498 |  |  | $ | 1,446 |  |  | 4 | % |
