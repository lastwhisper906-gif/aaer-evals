# MSI MD&A — 0000068505-19-000013


## mdna

[0000068505-19-000013:mdna:1]
[same as prior period, unchanged from 0000068505-18-000029:mdna:1]

[0000068505-19-000013:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three months ended March 30, 2019 and March 31, 2018, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2018.

[0000068505-19-000013:mdna:3]
[same as prior period, unchanged from 0000068505-18-000029:mdna:3]

[0000068505-19-000013:mdna:4]
[same as prior period, unchanged from 0000068505-18-000029:mdna:4]

[0000068505-19-000013:mdna:5]
Recent Acquisitions and Developments

[0000068505-19-000013:mdna:6]
On March 11, 2019, we announced that we acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands our commercial portfolio with new capabilities, allowing us to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Services and Software segments.

[0000068505-19-000013:mdna:7]
On January 7, 2019, we announced that we acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands our command center software portfolio under the Services and Software segment.

[0000068505-19-000013:mdna:8]
We reached an agreement with the U.K. Home Office during the third quarter of 2018 on terms for the new direction of the U.K. Emergency Services Network (“ESN”) that we expect to sign during the second quarter of 2019.

[0000068505-19-000013:mdna:9]
On March 28, 2018, we completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash.

[0000068505-19-000013:mdna:10]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash. This acquisition expanded our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-19-000013:mdna:11]
[same as prior period, unchanged from 0000068505-18-000029:mdna:9]

[0000068505-19-000013:mdna:12]
We are a leading global provider of mission-critical communications. Our technology platforms in communications, software, video, and services make cities safer and help communities and businesses thrive. We are ushering in a new era in public safety and security. We serve our customers with a global footprint of sales in more than 100 countries and 17,000 employees worldwide based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-19-000013:mdna:13]
[same as prior period, unchanged from 0000068505-18-000029:mdna:11]

[0000068505-19-000013:mdna:14]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, such as video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions typically managing a mobile workforce. In the first quarter of 2019, the segment’s net sales were $1.1 billion, representing 65% of our consolidated net sales.

[0000068505-19-000013:mdna:15]
Services and Software: The Services and Software segment provides a broad range of solution offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on premise and “as a service.” In the first quarter of 2019, the segment’s net sales were $588 million, representing 35% of our consolidated net sales.

[0000068505-19-000013:mdna:16]
First Quarter Financial Results

[0000068505-19-000013:mdna:17]
| • | Net sales were $1.7 billion in the first quarter of 2019 compared to $1.5 billion in the first quarter of 2018 and driven by growth in the Americas and EMEA. |

[0000068505-19-000013:mdna:18]
| • | Operating earnings were $229 million in the first quarter of 2019 compared to $171 million in the first quarter of 2018. |

[0000068505-19-000013:mdna:19]
| • | Earnings attributable to Motorola Solutions, Inc. were $151 million, or $0.86 per diluted common share, in the first quarter of 2019, compared to $117 million, or $0.69 per diluted common share, in the first quarter of 2018. |

[0000068505-19-000013:mdna:20]
| • | Our operating cash flow increased $751 million to $251 million in the first quarter of 2019 compared to the first quarter of 2018. The increase is primarily driven by the $500 million voluntary contribution to our U.S. pension plan in the first quarter of 2018. |

[0000068505-19-000013:mdna:21]
| • | We invested $445 million of cash and equity for VaaS International Holdings, and $136 million in cash for Avtec, Inc., repurchased $145 million of common stock, and paid $93 million in dividends. |

[0000068505-19-000013:mdna:22]
Segment Financial Highlights

[0000068505-19-000013:mdna:23]
A summary of our segment results for the first quarter of 2019 is as follows:

[0000068505-19-000013:mdna:24]
| • | In the Products and Systems Integration segment, net sales were $1.1 billion in the first quarter of 2019, an increase of $117 million, or 12% compared to $952 million in the first quarter of 2018. On a geographic basis, net sales increased in the Americas and EMEA, partially offset by AP, compared to the year-ago quarter. Operating earnings were $108 million in the first quarter of 2019, compared to $90 million in the first quarter of 2018. Operating margin increased in 2019 to 10.1% from 9.5% in 2018 driven by higher sales and gross margin, offset by higher operating expenses associated with acquisitions. |

[0000068505-19-000013:mdna:25]
| • | In the Services and Software segment, net sales were $588 million in the first quarter of 2019, an increase of $72 million, or 14% compared to net sales of $516 million in the first quarter of 2018. On a geographic basis, net sales increased in the Americas and EMEA, partially offset by AP, compared to the year-ago quarter. Operating earnings were $121 million in the first quarter of 2019, compared to $81 million in the first quarter of 2018. Operating margin increased in 2019 to 20.6% from 15.7% in 2018 driven by higher sales and gross margin, offset by higher operating expenses associated with acquisitions. |

[0000068505-19-000013:mdna:26]
26

[0000068505-19-000013:mdna:27]
[same as prior period, unchanged from 0000068505-18-000029:mdna:24]

[0000068505-19-000013:mdna:28]
|  | Three Months Ended |
| (Dollars in millions, except per share amounts) | March 30, 2019 |  | % ofSales* |  | March 31, 2018 |  | % ofSales* |
| Net sales from products | $ | 945 |  |  |  |  | $ | 801 |  |  |  |
| Net sales from services | 712 |  |  |  |  | 667 |  |  |  |
| Net sales | 1,657 |  |  |  |  | 1,468 |  |  |  |
| Costs of products sales | 444 |  |  | 47.0 | % |  | 383 |  |  | 47.8 | % |
| Costs of services sales | 440 |  |  | 61.8 | % |  | 416 |  |  | 62.4 | % |
| Costs of sales | 884 |  |  |  |  | 799 |  |  |  |
| Gross margin | 773 |  |  | 46.7 | % |  | 669 |  |  | 45.6 | % |
| Selling, general and administrative expenses | 327 |  |  | 19.7 | % |  | 279 |  |  | 19.0 | % |
| Research and development expenditures | 162 |  |  | 9.8 | % |  | 152 |  |  | 10.4 | % |
| Other charges | 55 |  |  | 3.3 | % |  | 67 |  |  | 4.6 | % |
| Operating earnings | 229 |  |  | 13.8 | % |  | 171 |  |  | 11.6 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net | (55 | ) |  | (3.3 | )% |  | (46 | ) |  | (3.1 | )% |
| Gains on sales of investments and businesses, net | 1 |  |  | — | % |  | 11 |  |  | 0.7 | % |
| Other | 10 |  |  | 0.6 | % |  | 4 |  |  | 0.3 | % |
| Total other expense | (44 | ) |  | (2.7 | )% |  | (31 | ) |  | (2.1 | )% |
| Net earnings before income taxes | 185 |  |  | 11.2 | % |  | 140 |  |  | 9.5 | % |
| Income tax expense | 33 |  |  | 2.0 | % |  | 23 |  |  | 1.6 | % |
| Net earnings | 152 |  |  | 9.2 | % |  | 117 |  |  | 8.0 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | — | % |  | — |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 151 |  |  | 9.1 | % |  | $ | 117 |  |  | 8.0 | % |
| Earnings per diluted common share | $ | 0.86 |  |  |  |  |  | $ | 0.69 |  |  |  |  |

[0000068505-19-000013:mdna:29]
[same as prior period, unchanged from 0000068505-18-000029:mdna:26]

[0000068505-19-000013:mdna:30]
27

[0000068505-19-000013:mdna:31]
Results of Operations—Three months ended March 30, 2019 compared to three months ended March 31, 2018

[0000068505-19-000013:mdna:32]
The results of operations for the first quarter of 2019 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-19-000013:mdna:33]
[same as prior period, unchanged from 0000068505-18-000029:mdna:30]

[0000068505-19-000013:mdna:34]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 1,069 |  |  | $ | 952 |  |  | 12 | % |
| Net sales from Services and Software | 588 |  |  | 516 |  |  | 14 | % |
| Net sales | $ | 1,657 |  |  | $ | 1,468 |  |  | 13 | % |

[0000068505-19-000013:mdna:35]
The Products and Systems Integration segment’s net sales represented 65% of our consolidated net sales in the first quarter of 2019 and 2018. The Services and Software segment’s net sales represented 35% of our consolidated net sales in the first quarter of 2019 and 2018.

[0000068505-19-000013:mdna:36]
Net sales were up $189 million, or 13%, compared to the first quarter of 2018. The increase in net sales was driven by the Americas and EMEA, partially offset by AP, with a 12% increase in the Products and Systems Integration segment and a 14% increase in the Services and Software segment. This growth includes:

[0000068505-19-000013:mdna:37]
| • | $137 million of revenue from the acquisitions of VaaS and Avtec in the first quarter of 2019 and Avigilon and Plant which were acquired towards the end of the first quarter of 2018; |

[0000068505-19-000013:mdna:38]
| • | partially offset by $38 million from unfavorable currency rates. |

[0000068505-19-000013:mdna:39]
Regional results include:

[0000068505-19-000013:mdna:40]
| • | growth in the Americas region of 17% across both the Products and Systems Integration and the Services and Software segments, inclusive of revenue from acquisitions; |

[0000068505-19-000013:mdna:41]
| • | growth in the EMEA region of 7% primarily due to both Services and Software within our Services and Software segment and Devices within our Products and Systems Integration segment, inclusive of revenue from acquisitions; and |

[0000068505-19-000013:mdna:42]
| • | a decline in the AP region of 5% due to currency headwinds and lower sales in China. |

[0000068505-19-000013:mdna:43]
Products and Systems Integration

[0000068505-19-000013:mdna:44]
The 12% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000013:mdna:45]
| • | $75 million of revenue from the acquisitions of Avtec in the first quarter of 2019 and Avigilon and Plant which were acquired near the end of the first quarter of 2018; |

[0000068505-19-000013:mdna:46]
| • | 20% growth in Systems and Systems Integration revenue in the first quarter of 2019, as compared to the first quarter of 2018 driven by system deployments in the Americas and revenue from Avigilon; and |

[0000068505-19-000013:mdna:47]
| • | 9% growth in Devices revenue primarily due to the acquisition of Avigilon along with strong demand for land mobile radio ("LMR") in the Americas and EMEA. |

[0000068505-19-000013:mdna:48]
Services and Software

[0000068505-19-000013:mdna:49]
The 14% increase in the Services and Software segment was driven by the following:

[0000068505-19-000013:mdna:50]
| • | $62 million of revenue primarily from the acquisitions of VaaS in the first quarter of 2019 and Avigilon and Plant which were acquired near the end of the first quarter of 2018; |

[0000068505-19-000013:mdna:51]
| • | 1% growth in Services, driven by growth in both maintenance and managed service revenues, and revenue from the acquisition of Plant, partially offset by unfavorable currency headwinds; and |

[0000068505-19-000013:mdna:52]
| • | 94% growth in Software, driven primarily by revenue from the acquisitions of VaaS, Avigilon, and Plant, and growth in our command center software suite. |

[0000068505-19-000013:mdna:53]
[same as prior period, unchanged from 0000068505-18-000029:mdna:33]

[0000068505-19-000013:mdna:54]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Gross margin | $ | 773 |  |  | $ | 669 |  |  | 16 | % |

[0000068505-19-000013:mdna:55]
Gross margin was 46.7% of net sales in the first quarter of 2019 compared to 45.6% in the first quarter of 2018. The primary drivers of the increase are as follows:

[0000068505-19-000013:mdna:56]
| • | higher margins within the Services and Software segment primarily driven by higher margin contribution within our Software portfolio from acquisitions and operational improvements and efficiencies in service delivery costs of our Services portfolio; and |

[0000068505-19-000013:mdna:57]
| • | higher margins in the Products and Systems Integration segment primarily driven by Systems and Systems Integration, partially offset by a slight decline in our Devices margins due to product mix. |

[0000068505-19-000013:mdna:58]
[same as prior period, unchanged from 0000068505-18-000029:mdna:35]

[0000068505-19-000013:mdna:59]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 327 |  |  | $ | 279 |  |  | 17 | % |

[0000068505-19-000013:mdna:60]
SG&A expenses increased 17% compared to the first quarter of 2018. SG&A expenses were 19.7% of net sales compared to 19.0% of net sales in the first quarter of 2018. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-19-000013:mdna:61]
[same as prior period, unchanged from 0000068505-18-000029:mdna:37]

[0000068505-19-000013:mdna:62]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |  | % Change |
| Research and development expenditures | $ | 162 |  |  | $ | 152 |  |  | 7 | % |

[0000068505-19-000013:mdna:63]
R&D expenditures increased 7%. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses. R&D expenditures were 9.8% of net sales compared to 10.4% of net sales in the first quarter of 2018.

[0000068505-19-000013:mdna:64]
[same as prior period, unchanged from 0000068505-18-000029:mdna:39]

[0000068505-19-000013:mdna:65]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |
| Other charges | $ | 55 |  |  | $ | 67 |  |

[0000068505-19-000013:mdna:66]
The Other charges in the first quarter of 2019 as compared to the first quarter of 2018 can be summarized as follows:

[0000068505-19-000013:mdna:67]
| • | $2 million of charges for acquisition-related transaction fees in the first quarter of 2019 as compared to $17 million in the first quarter of 2018; and |

[0000068505-19-000013:mdna:68]
| • | $4 million of net reorganization of business charges in the first quarter of 2019 as compared to $8 million in the first quarter of 2018, (see further detail in “Reorganization of Businesses” section); |

[0000068505-19-000013:mdna:69]
| • | partially offset by $50 million of amortization of intangibles in the first quarter of 2019 compared to $41 million in the first quarter of 2018, driven by acquisitions. |

[0000068505-19-000013:mdna:70]
Operating Earnings

[0000068505-19-000013:mdna:71]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |
| Operating earnings from Products and Systems Integration | $ | 108 |  |  | $ | 90 |  |
| Operating earnings from Services and Software | 121 |  |  | 81 |  |
| Operating earnings | $ | 229 |  |  | $ | 171 |  |

[0000068505-19-000013:mdna:72]
Operating earnings were up $58 million, or 34%, compared to the first quarter of 2018. The increase in Operating earnings was due to:

[0000068505-19-000013:mdna:73]
| • | Services and Software segment, which was up $40 million from the first quarter of 2018 compared to the first quarter of 2019, driven by higher sales and gross margin, and partially offset by higher operating expenses related to acquisitions; and |

[0000068505-19-000013:mdna:74]
| • | Products and Systems Integration, which was up $18 million from the first quarter of 2018 compared to the first quarter of 2019, driven by higher sales and gross margin, and partially offset by higher operating expenses related to acquisitions. |

[0000068505-19-000013:mdna:75]
[same as prior period, unchanged from 0000068505-18-000029:mdna:41]

[0000068505-19-000013:mdna:76]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |
| Interest expense, net | $ | (55 | ) |  | $ | (46 | ) |

[0000068505-19-000013:mdna:77]
The increase in net interest expense in the first quarter of 2019 compared to the first quarter of 2018 was a result of $1.3 billion of debt issued towards the end of the first quarter of 2018.

[0000068505-19-000013:mdna:78]
[same as prior period, unchanged from 0000068505-18-000029:mdna:43]

[0000068505-19-000013:mdna:79]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |
| Gains on sales of investments and businesses, net | $ | 1 |  |  | $ | 11 |  |

[0000068505-19-000013:mdna:80]
Net gains on sales of investments and businesses were $1 million in the first quarter of 2019 compared to $11 million during the first quarter of 2018. The net gains were related to the sales of various equity investments.

[0000068505-19-000013:mdna:81]
[same as prior period, unchanged from 0000068505-18-000029:mdna:45]

[0000068505-19-000013:mdna:82]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |
| Other | $ | 10 |  |  | $ | 4 |  |

[0000068505-19-000013:mdna:83]
The net Other income in the first quarter of 2019 as compared to the first quarter of 2018 was primarily comprised of:

[0000068505-19-000013:mdna:84]
| • | $10 million of other non-operating income in the first quarter of 2019, as compared to expense of $2 million in the first quarter of 2018; |

[0000068505-19-000013:mdna:85]
| • | foreign currency losses of $4 million in the first quarter of 2019 as compared to $11 million in the first quarter of 2018; and |

[0000068505-19-000013:mdna:86]
| • | a $4 million loss on derivative instruments in the first quarter of 2019 and 2018; |

[0000068505-19-000013:mdna:87]
| • | partially offset by $8 million of investment impairments; and |

[0000068505-19-000013:mdna:88]
| • | $16 million of net periodic pension and postretirement benefit in the first quarter of 2019 as compared to $20 million in the first quarter of 2018. |

[0000068505-19-000013:mdna:89]
30

[0000068505-19-000013:mdna:90]
[same as prior period, unchanged from 0000068505-18-000029:mdna:47]

[0000068505-19-000013:mdna:91]
|  | Three Months Ended |
| (In millions) | March 30, 2019 |  | March 31, 2018 |
| Income tax expense | $ | 33 |  |  | $ | 23 |  |

[0000068505-19-000013:mdna:92]
Income tax expense increased by $10 million compared to the first quarter of 2018, for an effective tax rate of 18%. Our effective tax rates for the first quarter of 2019 of 18% and the first quarter of 2018 of 16% were lower than the current U.S. federal statutory rate of 21% primarily due to excess tax benefits on share-based compensation.

[0000068505-19-000013:mdna:93]
[same as prior period, unchanged from 0000068505-18-000029:mdna:95]

[0000068505-19-000013:mdna:94]
During the first quarter of 2019, we recorded net reorganization of business charges of $8 million including $4 million of charges recorded within Other charges and $4 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $8 million were charges of $12 million related to employee separation costs, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-19-000013:mdna:95]
During the first quarter of 2018, we recorded net reorganization of business charges of $13 million including $8 million of charges recorded within Other charges and $5 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $22 million related to employee separation costs and $2 million related to exit costs, partially offset by $11 million of reversals for accruals no longer needed.

[0000068505-19-000013:mdna:96]
[same as prior period, unchanged from 0000068505-18-000029:mdna:100]

[0000068505-19-000013:mdna:97]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Products and Systems Integration | $ | 7 |  |  | $ | 9 |  |
| Services and Software | 1 |  |  | 4 |  |
|  | $ | 8 |  |  | $ | 13 |  |

[0000068505-19-000013:mdna:98]
Cash payments for employee severance in connection with the reorganization of business plans were $14 million in the first quarter of 2019 and employee severance and exit costs were $15 million in the first quarter of 2018. The reorganization of business accrual at March 30, 2019 was $78 million, of which relate to employee separation costs that are expected to be paid within one year.

[0000068505-19-000013:mdna:99]
As of January 1, 2019, accruals for exit costs are included in Operating lease liabilities with an offsetting impairment to our right-of use assets ("ROU"), all within our Condensed Consolidated Balance Sheets (see Note 3 of our condensed consolidated financial statements).

[0000068505-19-000013:mdna:100]
[same as prior period, unchanged from 0000068505-18-000029:mdna:103]

[0000068505-19-000013:mdna:101]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 251 |  |  | $ | (500 | ) |
| Investing activities | (432 | ) |  | (1,089 | ) |
| Financing activities | (201 | ) |  | 1,149 |  |
| Effect of exchange rates on cash and cash equivalents | 22 |  |  | 30 |  |
| Decrease in cash and cash equivalents | $ | (360 | ) |  | $ | (410 | ) |

[0000068505-19-000013:mdna:102]
[same as prior period, unchanged from 0000068505-18-000029:mdna:105]

[0000068505-19-000013:mdna:103]
At March 30, 2019, $405 million of the $897 million cash and cash equivalents balance was held in the U.S. and $492 million was held by us or our subsidiaries in other countries, with approximately $138 million held in the United Kingdom. Restricted cash was $11 million at March 30, 2019 and December 31, 2018.

[0000068505-19-000013:mdna:104]
[same as prior period, unchanged from 0000068505-18-000029:mdna:107]

[0000068505-19-000013:mdna:105]
The increase in operating cash flows from the first quarter of 2018 to the first quarter of 2019 was driven by (see additional discussion under "Sales of Receivables" below):

[0000068505-19-000013:mdna:106]
| • | a $500 million debt-funded voluntary contribution to our U.S. pension plan in the first quarter of 2018; |

[0000068505-19-000013:mdna:107]
| • | annual incentive compensation payments being made in the first quarter of 2018, compared to the second quarter in 2019; and |

[0000068505-19-000013:mdna:108]
| • | higher earnings in the first quarter of 2019 as compared to the first quarter of 2018; |

[0000068505-19-000013:mdna:109]
| • | partially offset by $17 million of higher interest payments driven by additional debt issued towards the end of first quarter of 2018. |

[0000068505-19-000013:mdna:110]
[same as prior period, unchanged from 0000068505-18-000029:mdna:109]

[0000068505-19-000013:mdna:111]
The decrease in net cash used by investing activities from the first quarter of 2018 to the first quarter of 2019 was primarily due to:

[0000068505-19-000013:mdna:112]
| • | a $757 million decrease in acquisitions and investments, primarily driven by cash used for the purchases of VaaS and Avtec for $231 million and $136 million, respectively, as compared to the first quarter of 2018 when we made acquisitions of Avigilon and Plant Holdings for $887 million and $237 million, respectively; and |

[0000068505-19-000013:mdna:113]
| • | $75 million of lower proceeds from sales of investments and businesses, driven by $60 million of excess cash withdrawn from company-sponsored life insurance investments in the first quarter of 2018; and |

[0000068505-19-000013:mdna:114]
| • | partially offset by a $25 million increase in capital expenditures in the first quarter of 2019 as compared to the first quarter of 2018, primarily due to the network builds for Airwave and ESN, as well as expenditures for Avigilon. |

[0000068505-19-000013:mdna:115]
[same as prior period, unchanged from 0000068505-18-000029:mdna:114]

[0000068505-19-000013:mdna:116]
The increase in cash used for financing activities in the first quarter of 2019 as compared to the cash provided by financing activities in the first quarter of 2018 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" below):

[0000068505-19-000013:mdna:117]
| • | $1.3 billion of debt issuance in the first quarter of 2018; and |

[0000068505-19-000013:mdna:118]
| • | a $79 million increase in our share repurchase program in the first quarter of 2019 as compared to the first quarter of 2018. |

[0000068505-19-000013:mdna:119]
[same as prior period, unchanged from 0000068505-18-000029:mdna:129]

[0000068505-19-000013:mdna:120]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three months ended March 30, 2019 and March 31, 2018:

[0000068505-19-000013:mdna:121]
|  | Three Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Accounts receivable sales proceeds | $ | 24 |  |  | $ | 55 |  |
| Long-term receivables sales proceeds | 21 |  |  | 13 |  |
| Total proceeds from sales of accounts receivable | $ | 45 |  |  | $ | 68 |  |

[0000068505-19-000013:mdna:122]
The proceeds of our receivable sales are included in "Operating activities" within our Condensed Consolidated Statements of Cash Flows.

[0000068505-19-000013:mdna:123]
At March 30, 2019, the Company had retained servicing obligations for $944 million of long-term receivables, compared to $970 million at December 31, 2018. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-19-000013:mdna:124]
Debt

[0000068505-19-000013:mdna:125]
We had outstanding long-term debt of $5.3 billion, including the current portions of $28 million and $31 million at March 30, 2019 and December 31, 2018, respectively.

[0000068505-19-000013:mdna:126]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million with a maturity date of March 26, 2021 (the "Term Loan"). Interest on the Term Loan is variable, indexed to London Inter-bank Offered Rate ("LIBOR"), and paid monthly. The weighted average borrowing rate for amounts outstanding during the three months ended March 30, 2019 was 3.75%. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-19-000013:mdna:127]
In February of 2018, we issued $500 million of 4.60% Senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan in the first quarter of 2018.

[0000068505-19-000013:mdna:128]
As of March 30, 2019, we had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a published conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. In the event of a conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-19-000013:mdna:129]
[same as prior period, unchanged from 0000068505-18-000029:mdna:121]

[0000068505-19-000013:mdna:130]
[same as prior period, unchanged from 0000068505-18-000029:mdna:125]

[0000068505-19-000013:mdna:131]
As of March 30, 2019, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of March 30, 2019. During the first quarter of 2018, we borrowed $400 million to facilitate the Avigilon acquisition. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of March 30, 2019.

[0000068505-19-000013:mdna:132]
Share Repurchase Program

[0000068505-19-000013:mdna:133]
During the three months ended March 30, 2019, we paid an aggregate of $145 million, including transaction costs, to repurchase approximately 1.2 million shares at an average price of $118.98 per share. As of March 30, 2019, we had used approximately $12.6 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-19-000013:mdna:134]
Dividends

[0000068505-19-000013:mdna:135]
During the first quarter of 2019, we paid $93 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $94 million in cash dividends to holders of our common stock.

[0000068505-19-000013:mdna:136]
[same as prior period, unchanged from 0000068505-18-000029:mdna:127]

[0000068505-19-000013:mdna:137]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $52 million at March 30, 2019, compared to $62 million at December 31, 2018.

[0000068505-19-000013:mdna:138]
Other Contingencies

[0000068505-19-000013:mdna:139]
There were no significant changes impacting our commitments and contingencies during the three months ended March 30, 2019.

[0000068505-19-000013:mdna:140]
[same as prior period, unchanged from 0000068505-18-000029:mdna:135]

[0000068505-19-000013:mdna:141]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-19-000013:mdna:142]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires us to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. This was subsequently amended by ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which clarifies that receivables arising from operating leases are not within the scope of the ASU and amends the transition requirements. The ASU is effective for us on January 1, 2020 with early adoption permitted beginning as of January 1, 2019. The ASU requires a modified retrospective adoption method. We are still evaluating the impact of adoption on our financial statements and disclosures.

[0000068505-19-000013:mdna:143]
Recently Adopted Accounting Pronouncements

[0000068505-19-000013:mdna:144]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a

[0000068505-19-000013:mdna:145]
[same as prior period, unchanged from 0000068505-18-000029:mdna:27]

[0000068505-19-000013:mdna:146]
ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-19-000013:mdna:147]
We adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1,2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

[0000068505-19-000013:mdna:148]
ASC 842 provides for a number of optional practical expedients in transition. We elected the practical expedients, which permit us to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. We did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing us to carry forward the lease term as determined prior to adoption of ASC 842. Finally, we also elected the practical expedient related to land easements, which enabled us to continue our accounting treatment for land easements on existing agreements as of January 1, 2019.

[0000068505-19-000013:mdna:149]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. We elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows us to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with our prior accounting. We also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

[0000068505-19-000013:mdna:150]
We recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition. In future periods such balances will not be presented separately.

[0000068505-19-000013:mdna:151]
For arrangements where we are the lessor, the adoption of ASC 842 did not have a material impact on our financial statements as the majority of our leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (1) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (2) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 Revenue from Contract with Customers and accounting and disclosure under ASC 842 is not applicable. We have elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.

[0000068505-19-000013:mdna:152]
34
