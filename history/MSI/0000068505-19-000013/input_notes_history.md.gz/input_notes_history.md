# MSI note change history — 0000068505-18-000029 → 0000068505-19-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000068505-19-000013:note_history:1]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.
  (was, 2018-11-02, similarity 0.9925):
[0000068505-18-000029:note_history:1]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

- changed (2019-05-03):
[0000068505-19-000013:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at March 30, 2019.
  (was, 2018-11-02, similarity 0.9883):
[0000068505-18-000029:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at September 29, 2018.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000068505-19-000013:note_history:3]
The condensed consolidated financial statements as of March 30, 2019 and for the three months ended March 30, 2019 and March 31, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statements of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2018-11-02, similarity 0.9282):
[0000068505-18-000029:note_history:3]
The condensed consolidated financial statements as of September 29, 2018 and for the three and nine months ended September 29, 2018 and September 30, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2019-05-03):
[0000068505-19-000013:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three months ended March 30, 2019 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2018-11-02, similarity 0.9446):
[0000068505-18-000029:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three and nine months ended September 29, 2018 are not necessarily indicative of the operating results to be expected for the full year.

- added (2019-05-03):
[0000068505-19-000013:note_history:5]
Recent Acquisitions

- added (2019-05-03):
[0000068505-19-000013:note_history:6]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Services and Software segments.

- added (2019-05-03):
[0000068505-19-000013:note_history:7]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's command center software portfolio under the Services and Software segment.

- changed (2019-05-03):
[0000068505-19-000013:note_history:8]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash.
  (was, 2018-11-02, similarity 0.9147):
[0000068505-18-000029:note_history:8]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

- changed (2019-05-03):
[0000068505-19-000013:note_history:9]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.
  (was, 2018-11-02, similarity 0.9516):
[0000068505-18-000029:note_history:9]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

- added (2019-05-03):
[0000068505-19-000013:note_history:10]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. This was subsequently amended by ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which clarifies that receivables arising from operating leases are not within the scope of the ASU and amends the transition requirements. The ASU is effective for the Company on January 1, 2020 with early adoption permitted beginning as of January 1, 2019. The ASU requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

- added (2019-05-03):
[0000068505-19-000013:note_history:11]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

- added (2019-05-03):
[0000068505-19-000013:note_history:12]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1,2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

- added (2019-05-03):
[0000068505-19-000013:note_history:13]
ASC 842 provides for a number of optional practical expedients in transition. The Company elected the practical expedients, which permit the Company to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. The Company did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing it to carry forward the lease term as determined prior to adoption of ASC 842. Finally, the Company also elected the practical expedient related to land easements, which enabled it to continue its accounting treatment for land easements on existing agreements as of January 1, 2019.

- added (2019-05-03):
[0000068505-19-000013:note_history:14]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. The Company elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows the Company to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with the Company’s prior accounting. The Company also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

- added (2019-05-03):
[0000068505-19-000013:note_history:15]
The Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition. In future periods such balances will not be presented separately.

- added (2019-05-03):
[0000068505-19-000013:note_history:16]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (1) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (2) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 Revenue from Contract with Customers and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.

- removed (2019-05-03):
[0000068505-18-000029:note_history:17]
During the second quarter of 2018, the Company modified its internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership, in part, as a result of recent acquisitions contributing to the growth within the newly aligned Services and Software segment. Previously, the Company had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration related revenue and costs moving from the old Services segment into the newly presented Products and Systems Integration segment and Software related revenue and costs moving from the old Products segment into the newly presented Services and Software segment.

- removed (2019-05-03):
[0000068505-18-000029:note_history:18]
Recent Developments

- removed (2019-05-03):
[0000068505-18-000029:note_history:19]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. In July 2018, the FASB issued ASU 2018-11 that amended the ASU to include an additional (and optional) transition relief. The additional transition relief provides entities the option to adopt the ASU by applying the new ASU at the adoption date and recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption without restatement of comparative periods. The new ASU must be adopted utilizing the modified retrospective method as of the earliest comparative period presented if the optional adoption method is not selected. The Company will adopt the ASU on January 1, 2019, utilizing the modified retrospective method as of the adoption date. The Company is continuing to assess the impact of the ASU on its condensed consolidated financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects a material impact to its condensed consolidated balance sheet through the recording of right-of-use assets and lease obligations that are not required to be recorded within the condensed consolidated balance sheet under current accounting standards.

- removed (2019-05-03):
[0000068505-18-000029:note_history:20]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires entities to estimate and recognize current expected credit losses rather than delay recognition of credit losses until the loss is probable of occurring. The ASU is effective for the Company on January 1, 2020, and interim periods within that reporting period with early option permitted. The Company is currently evaluating the impact of the ASU on its consolidated financial statements and disclosures.

- removed (2019-05-03):
[0000068505-18-000029:note_history:21]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The guidance related to cash flow and net investment hedges existing at the date of adoption should be applied using the modified retrospective method by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption. The guidance related to presentation and disclosure should be applied prospectively. The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and disclosures.

- removed (2019-05-03):
[0000068505-18-000029:note_history:22]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. The Company recognized $31 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company will recognize tax expense when intra-entity transfers of assets other than inventory occur.

- removed (2019-05-03):
[0000068505-18-000029:note_history:23]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $18 million and $10 million in the three months ended September 29, 2018 and September 30, 2017, respectively, and $58 million and $10 million in the nine months ended September 29, 2018 and September 30, 2017, respectively.

- removed (2019-05-03):
[0000068505-18-000029:note_history:24]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

- removed (2019-05-03):
[0000068505-18-000029:note_history:25]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

- removed (2019-05-03):
[0000068505-18-000029:note_history:26]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

- removed (2019-05-03):
[0000068505-18-000029:note_history:27]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

- removed (2019-05-03):
[0000068505-18-000029:note_history:28]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

- removed (2019-05-03):
[0000068505-18-000029:note_history:29]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

- removed (2019-05-03):
[0000068505-18-000029:note_history:30]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

- removed (2019-05-03):
[0000068505-18-000029:note_history:31]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 is as follows:

- removed (2019-05-03):
[0000068505-18-000029:note_history:32]
Balance Sheet (Selected captions)

- removed (2019-05-03):
[0000068505-18-000029:note_history:33]
| (In millions) | December 31, 2017 |  | Reclassification of Contract Assets |  | Reclassification of Non-customer receivables |  | Reclassification of Contract Liabilities |  | Impact of Adoption on Open Contracts |  | January 1, 2018 |
|  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |
| ASSETS |
| Accounts receivable, net | $ | 1,523 |  |  | $ | (297 | ) |  | $ | (24 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | 1,198 |  |
| Contract assets | — |  |  | 846 |  |  | — |  |  | — |  |  | 85 |  |  | 931 |  |
| Inventories, net | 327 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 328 |  |
| Other current assets | 832 |  |  | (549 | ) |  | 24 |  |  | — |  |  | (23 | ) |  | 284 |  |
| Deferred income taxes | 1,023 |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | 982 |  |
| Other assets | 333 |  |  | — |  |  | — |  |  | — |  |  | 85 |  |  | 418 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Contract liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | (17 | ) |  | $ | 1,082 |  |
| Accrued liabilities | 2,286 |  |  | — |  |  | — |  |  | (1,099 | ) |  | — |  |  | 1,187 |  |
| Other liabilities | 2,585 |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | 2,578 |  |
| Stockholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings | 467 |  |  | — |  |  | — |  |  | — |  |  | 127 |  |  | 594 |  |

- removed (2019-05-03):
[0000068505-18-000029:note_history:34]
Adoption Impact to Financial Statements

- removed (2019-05-03):
[0000068505-18-000029:note_history:35]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three and nine months ended September 29, 2018 is as follows:

- removed (2019-05-03):
[0000068505-18-000029:note_history:36]
Statements of Operations (Selected captions)

- removed (2019-05-03):
[0000068505-18-000029:note_history:37]
|  | Three Months Ended |
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,862 |  |  | $ | (19 | ) |  | $ | 1,843 |  |
| Gross margin | 901 |  |  | (18 | ) |  | 883 |  |
| Selling, general and administrative expenses | 323 |  |  | (17 | ) |  | 306 |  |
| Operating earnings | 294 |  |  | (1 | ) |  | 293 |  |
| Net earnings before income taxes | 270 |  |  | (1 | ) |  | 269 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 247 |  |  | $ | (1 | ) |  | $ | 246 |  |

- removed (2019-05-03):
[0000068505-18-000029:note_history:38]
|  | Nine Months Ended |
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| Net sales | $ | 5,089 |  |  | $ | (58 | ) |  | $ | 5,031 |  |
| Gross margin | 2,392 |  |  | (57 | ) |  | 2,335 |  |
| Selling, general and administrative expenses | 918 |  |  | (46 | ) |  | 872 |  |
| Operating earnings | 739 |  |  | (11 | ) |  | 728 |  |
| Net earnings before income taxes | 637 |  |  | (11 | ) |  | 626 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 544 |  |  | $ | (11 | ) |  | $ | 533 |  |

- removed (2019-05-03):
[0000068505-18-000029:note_history:39]
Balance Sheet (Selected captions)

- removed (2019-05-03):
[0000068505-18-000029:note_history:40]
| (In millions) | September 29, 2018 |  | Adjustments due to ASC 606 |  | September 29, 2018 Balances Under ASC 605 |
| ASSETS |
| Accounts receivable, net | $ | 1,179 |  |  | $ | 315 |  |  | $ | 1,494 |  |
| Contract assets | 917 |  |  | (917 | ) |  | — |  |
| Other current assets | 350 |  |  | 540 |  |  | 890 |  |
| Deferred income taxes | 949 |  |  | 41 |  |  | 990 |  |
| Other assets | 444 |  |  | (95 | ) |  | 349 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |
| Contract liabilities | $ | 1,127 |  |  | $ | (1,127 | ) |  | $ | — |  |
| Accrued liabilities | 1,168 |  |  | 1,139 |  |  | 2,307 |  |
| Other liabilities | 2,175 |  |  | 10 |  |  | 2,185 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 788 |  |  | (138 | ) |  | 650 |  |

- removed (2019-05-03):
[0000068505-18-000029:note_history:41]
There is no impact to the condensed consolidated statement of comprehensive income or the statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the condensed consolidated balance sheet and disclosed above.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000068505-19-000013:note_history:42]
As of March 30, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 30, 2019. During the first quarter of 2018, the Company borrowed $400 million to facilitate the Avigilon acquisition. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of March 30, 2019.
  (was, 2018-11-02, similarity 0.6598):
[0000068505-18-000029:note_history:42]
As of September 29, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). As of March 31, 2018, the Company borrowed $400 million under the facility to complete the Avigilon acquisition. As of September 29, 2018, the outstanding loan amount under the facility was $100 million, with $200 million paid during the third quarter. Subsequent to the quarter, the Company paid the remaining $100 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts for the three and nine months ended September 29, 2018 was 3.58%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 29, 2018.

- changed (2019-05-03):
[0000068505-19-000013:note_history:43]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three months ended March 30, 2019 was 3.75%. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.
  (was, 2018-11-02, similarity 0.8999):
[0000068505-18-000029:note_history:43]
Also in conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rates for amounts outstanding during the three and nine months ended September 29, 2018 were 3.33% and 3.43%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- added (2019-05-03):
[0000068505-19-000013:note_history:44]
As of March 30, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of March 30, 2019 was $876 million. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- removed (2019-05-03):
[0000068505-18-000029:note_history:45]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.8252, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.45 per share). The exercise price adjusts automatically for dividends. On September 5, 2018, the Company agreed with Silver Lake Partners to repurchase $200 million in principal amount of the Senior Convertible Notes for aggregate consideration of $369 million in cash, inclusive of the conversion premium. As of September 29, 2018, the Company paid $169 million of cash to Silver Lake Partners and recorded a gain of $6 million from the extinguishment of the convertible debt. The principal amount of $200 million was reclassified to short term debt. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of September 29, 2018 was $712 million. In the event of an additional conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- removed (2019-05-03):
[0000068505-18-000029:note_history:46]
On September 28, 2018, the Company issued an additional $200 million on the outstanding 4.60% Senior notes due 2028 bringing the outstanding total to $700 million. The Company settled the issuance on October 5, 2018 and recognized net proceeds of $196 million, subsequent to quarter end, which was then used to pay the $200 million principal due to Silver Lake Partners on October 15, 2018.


## msi:RevenuefromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-05-03):
[0000068505-18-000029:note_history:47]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

- removed (2019-05-03):
[0000068505-18-000029:note_history:48]
Significant Judgments

- removed (2019-05-03):
[0000068505-18-000029:note_history:49]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

- removed (2019-05-03):
[0000068505-18-000029:note_history:50]
The Company accounts for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized product solutions. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

- removed (2019-05-03):
[0000068505-18-000029:note_history:51]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

- removed (2019-05-03):
[0000068505-18-000029:note_history:52]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

- removed (2019-05-03):
[0000068505-18-000029:note_history:53]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

- removed (2019-05-03):
[0000068505-18-000029:note_history:54]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

- removed (2019-05-03):
[0000068505-18-000029:note_history:55]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) noncash consideration, and (iv) consideration payable to a customer.

- removed (2019-05-03):
[0000068505-18-000029:note_history:56]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

- removed (2019-05-03):
[0000068505-18-000029:note_history:57]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000068505-19-000013:note_history:58]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 30, 2019 and March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2018-11-02, similarity 0.9044):
[0000068505-18-000029:note_history:58]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2019-05-03):
[0000068505-19-000013:note_history:59]
|  | March 30, 2019 |  | March 31, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 813 |  |  | $ | 352 |  |  | $ | 699 |  |  | $ | 296 |  |
| EMEA | 164 |  |  | 199 |  |  | 156 |  |  | 182 |  |
| Asia Pacific | 92 |  |  | 37 |  |  | 97 |  |  | 38 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 686 |  |  | $ | — |  |  | $ | 632 |  |  | $ | — |  |
| Systems and Systems Integration | 383 |  |  | — |  |  | 320 |  |  | — |  |
| Services | — |  |  | 452 |  |  | — |  |  | 446 |  |
| Software | — |  |  | 136 |  |  | — |  |  | 70 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 657 |  |  | $ | 553 |  |  | $ | 617 |  |  | $ | 506 |  |
| Indirect | 412 |  |  | 35 |  |  | 335 |  |  | 10 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
  (was, 2018-11-02, similarity 0.9534):
[0000068505-18-000029:note_history:59]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 957 |  |  | $ | 343 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 199 |  |  | 189 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 132 |  |  | 42 |  |  | 353 |  |  | 126 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 828 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 460 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 455 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 119 |  |  | — |  |  | 303 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 811 |  |  | $ | 543 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 477 |  |  | 31 |  |  | 1,261 |  |  | 74 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000068505-19-000013:note_history:60]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 30, 2019 and March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2018-11-02, similarity 0.9044):
[0000068505-18-000029:note_history:60]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and nine months ended September 29, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- changed (2019-05-03):
[0000068505-19-000013:note_history:61]
|  | March 30, 2019 |  | March 31, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 813 |  |  | $ | 352 |  |  | $ | 699 |  |  | $ | 296 |  |
| EMEA | 164 |  |  | 199 |  |  | 156 |  |  | 182 |  |
| Asia Pacific | 92 |  |  | 37 |  |  | 97 |  |  | 38 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 686 |  |  | $ | — |  |  | $ | 632 |  |  | $ | — |  |
| Systems and Systems Integration | 383 |  |  | — |  |  | 320 |  |  | — |  |
| Services | — |  |  | 452 |  |  | — |  |  | 446 |  |
| Software | — |  |  | 136 |  |  | — |  |  | 70 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 657 |  |  | $ | 553 |  |  | $ | 617 |  |  | $ | 506 |  |
| Indirect | 412 |  |  | 35 |  |  | 335 |  |  | 10 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
  (was, 2018-11-02, similarity 0.9534):
[0000068505-18-000029:note_history:61]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 957 |  |  | $ | 343 |  |  | $ | 2,533 |  |  | $ | 969 |  |
| EMEA | 199 |  |  | 189 |  |  | 543 |  |  | 565 |  |
| Asia Pacific | 132 |  |  | 42 |  |  | 353 |  |  | 126 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 828 |  |  | $ | — |  |  | $ | 2,184 |  |  | $ | — |  |
| Systems and Systems Integration | 460 |  |  | — |  |  | 1,245 |  |  | — |  |
| Services | — |  |  | 455 |  |  | — |  |  | 1,357 |  |
| Software | — |  |  | 119 |  |  | — |  |  | 303 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 811 |  |  | $ | 543 |  |  | $ | 2,168 |  |  | $ | 1,586 |  |
| Indirect | 477 |  |  | 31 |  |  | 1,261 |  |  | 74 |  |
| Total | $ | 1,288 |  |  | $ | 574 |  |  | $ | 3,429 |  |  | $ | 1,660 |  |

- changed (2019-05-03):
[0000068505-19-000013:note_history:62]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 30, 2019 is $7.0 billion. A total of $3.0 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.6 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.0 billion is from Services and Software performance obligations that are not yet satisfied as of March 30, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2018-11-02, similarity 0.9901):
[0000068505-18-000029:note_history:62]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of September 29, 2018 is $6.1 billion. A total of $3.3 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.9 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $2.8 billion is from Services and Software performance obligations that are not yet satisfied as of September 29, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- changed (2019-05-03):
[0000068505-19-000013:note_history:63]
|  | March 30, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,150 |  |  | $ | 1,293 |  |
| Contract assets | 878 |  |  | 1,012 |  |
| Contract liabilities | 1,158 |  |  | 1,263 |  |
| Non-current contract liabilities | 239 |  |  | 214 |  |
  (was, 2018-11-02, similarity 0.8476):
[0000068505-18-000029:note_history:63]
| (in millions) | September 29, 2018 |  | January 1, 2018 |  |
| Receivables | $ | 1,179 |  |  | $ | 1,198 |  |
| Contract assets | 917 |  |  | 931 |  |
| Contract liabilities | 1,127 |  |  | 1,082 |  |
| Non-current contract liabilities | 159 |  |  | 162 |  |

- added (2019-05-03):
[0000068505-19-000013:note_history:64]
Revenue recognized during the three months ended March 30, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $393 million, compared to $297 million of revenue recognized during the three months ended March 31, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $9 million was reversed during the three months ended March 30, 2019 and $9 million of revenue was recognized during the three months ended March 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

- changed (2019-05-03):
[0000068505-19-000013:note_history:65]
There were no material impairment losses recognized on contract assets during the three months ended March 30, 2019 and March 31, 2018.
  (was, 2018-11-02, similarity 0.8347):
[0000068505-18-000029:note_history:65]
There have been no material impairment losses recognized on contract assets during the nine months ended September 29, 2018.

- changed (2019-05-03):
[0000068505-19-000013:note_history:66]
|  | March 30, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 36 |  |  | $ | 30 |  |
| Non-current contract cost assets | 99 |  |  | 98 |  |
  (was, 2018-11-02, similarity 0.8678):
[0000068505-18-000029:note_history:66]
| (in millions) | September 29, 2018 |  | January 1, 2018 |  |
| Current contract cost assets | $ | 57 |  |  | $ | 62 |  |
| Non-current contract cost assets | 95 |  |  | 85 |  |

- added (2019-05-03):
[0000068505-19-000013:note_history:67]
Amortization of contract cost assets was $11 million and $12 million for the three months ended March 30, 2019 and March 31, 2018, respectively.

- removed (2019-05-03):
[0000068505-18-000029:note_history:68]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

- removed (2019-05-03):
[0000068505-18-000029:note_history:69]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

- removed (2019-05-03):
[0000068505-18-000029:note_history:70]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

- removed (2019-05-03):
[0000068505-18-000029:note_history:71]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) noncash consideration, and (iv) consideration payable to a customer.

- removed (2019-05-03):
[0000068505-18-000029:note_history:72]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

- removed (2019-05-03):
[0000068505-18-000029:note_history:73]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.

- removed (2019-05-03):
[0000068505-18-000029:note_history:74]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government, public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.

- removed (2019-05-03):
[0000068505-18-000029:note_history:75]
Devices: Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Devices also includes video surveillance cameras sold by Avigilon. Devices are considered capable of being distinct and distinct within the context of our contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

- removed (2019-05-03):
[0000068505-18-000029:note_history:76]
Systems and Systems Integration: Systems and Systems Integration include customized end-to-end radio network, video solutions and implementation, optimization, and integration of networks, devices, software, and applications. Radio network includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, and repeaters. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents distinct performance obligations for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Systems and Systems Integration revenue is recognized over an average duration of approximately one to two years.

- removed (2019-05-03):
[0000068505-18-000029:note_history:77]
Systems also include Avigilon end-to-end security and surveillance solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

- removed (2019-05-03):
[0000068505-18-000029:note_history:78]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

- removed (2019-05-03):
[0000068505-18-000029:note_history:79]
Services:  Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer or Motorola Solutions owned networks. Services are provided across all radio network technologies. Services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

- removed (2019-05-03):
[0000068505-18-000029:note_history:80]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

- removed (2019-05-03):
[0000068505-18-000029:note_history:81]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis.

- removed (2019-05-03):
[0000068505-18-000029:note_history:82]
Significant Judgments

- removed (2019-05-03):
[0000068505-18-000029:note_history:83]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

- removed (2019-05-03):
[0000068505-18-000029:note_history:84]
The Company accounts for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized product solutions. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

- removed (2019-05-03):
[0000068505-18-000029:note_history:85]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

- removed (2019-05-03):
[0000068505-18-000029:note_history:86]
Contract assets consist of amounts formerly classified as Costs and earnings in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of costs and earnings recognized, Customer downpayments and Deferred revenue.

- removed (2019-05-03):
[0000068505-18-000029:note_history:87]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

- removed (2019-05-03):
[0000068505-18-000029:note_history:88]
Revenue recognized during the three months ended September 29, 2018 which was previously included in Contract liabilities as of July 1, 2018 is $327 million. Revenue recognized during the nine months ended September 29, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $777 million. Revenue of $7 million was reversed during the three months ended September 29, 2018 and $4 million of revenue was reversed during the nine months ended September 29, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

- removed (2019-05-03):
[0000068505-18-000029:note_history:89]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $11 million and $34 million for the three and nine months ended September 29, 2018, respectively.
