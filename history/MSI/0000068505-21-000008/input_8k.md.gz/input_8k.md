# MSI 8-K — 0000068505-21-000005 filed 2021-02-04

## item codes, every 8-K on or before 2021-02-12

- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2021-02-12

- none on or before 2021-02-12

## item 2.02 — earnings release, exhibit 99.1

[0000068505-21-000005:8k_2_02:1]
EX-99.1
2
msiq42020pressrelease.htm
EX-99.1

[0000068505-21-000005:8k_2_02:2]
Document

[0000068505-21-000005:8k_2_02:3]
Exhibit 99.1

[0000068505-21-000005:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-21-000005:8k_2_02:5]
Company ends year with record backlog

[0000068505-21-000005:8k_2_02:6]
•Revenue of $2.3 billion, down 4% from Q4 in the prior year; down 6% for full year

[0000068505-21-000005:8k_2_02:7]
•Software and Services segment grew 8% in Q4; 9% for full year

[0000068505-21-000005:8k_2_02:8]
•Record backlog of $11.4 billion, up $175 million or 2% from a year ago

[0000068505-21-000005:8k_2_02:9]
•GAAP earnings per share (EPS) of $2.37; $5.45 for full year

[0000068505-21-000005:8k_2_02:10]
•Non-GAAP EPS* of $2.86, down 3% from Q4 in the prior year; $7.69 for full year, down 3%

[0000068505-21-000005:8k_2_02:11]
•Generated $703 million in operating cash flow in the quarter; $1.6 billion for full year

[0000068505-21-000005:8k_2_02:12]
CHICAGO - Feb. 4, 2021 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2020. Click here for a printable news release and financial tables.

[0000068505-21-000005:8k_2_02:13]
“Our fourth-quarter results, highlighted by record LMR orders in North America and continued strong growth in the Software and Services segment, reflect the criticality of our solutions and our team's unwavering execution throughout an unprecedented year,” said Greg Brown, chairman and CEO, Motorola Solutions. “This momentum, combined with our record ending backlog, positions us very well for strong growth in 2021.”

[0000068505-21-000005:8k_2_02:14]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-21-000005:8k_2_02:15]
|  | Fourth Quarter | Full Year |
|  | Q4 2020 | Q4 2019 | % Change | 2020 | 2019 | % Change |
| Sales | $2,273 | $2,377 | (4) | % | $7,414 | $7,887 | (6) | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $555 | $590 | (6) | % | $1,383 | $1,581 | (13) | % |
| % of Sales | 24.4 | % | 24.8 | % |  | 18.7 | % | 20.0 | % |  |
| EPS | $2.37 | 1.39 |  | 71 | % | $5.45 | $4.95 | 10 | % |
| Non-GAAP* |  |  |  |  |  |  |
| Operating Earnings | $667 | $707 | (6) | % | $1,835 | $1,975 | (7) | % |
| % of Sales | 29.3 | % | 29.7 | % |  | 24.8 | % | 25.0 | % |  |
| EPS | $2.86 | $2.94 | (3) | % | $7.69 | $7.96 | (3) | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $1,510 | $1,673 | (10) | % | $4,634 | $5,329 | (13) | % |
| GAAP Operating Earnings | $351 | $426 | (18) | % | $656 | $994 | (34) | % |
| % of Sales | 23.2 | % | 25.5 | % |  | 14.2 | % | 18.7 | % |  |
| Non-GAAP Operating Earnings* | $408 | $484 | (16) | % | $880 | $1,173 | (25) | % |
| % of Sales | 27.0 | % | 28.9 | % |  | 19.0 | % | 22.0 | % |  |
| Software and Services Segment |  |  |  |  |  |  |
| Sales | $763 | $704 | 8 | % | $2,780 | $2,558 | 9 | % |
| GAAP Operating Earnings | $204 | $164 | 24 | % | $727 | $587 | 24 | % |
| % of Sales | 26.7 | % | 23.3 | % |  | 26.2 | % | 22.9 | % |  |
| Non-GAAP Operating Earnings* | $259 | $223 | 16 | % | $955 | $802 | 19 | % |
| % of Sales | 33.9 | % | 31.7 | % |  | 34.3 | % | 31.4 | % |  |

[0000068505-21-000005:8k_2_02:16]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.49 for Q4 and $2.24 for FY per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-21-000005:8k_2_02:17]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-21-000005:8k_2_02:18]
•Revenue - Fourth-quarter revenue was $2.3 billion, down 4% from the year-ago quarter driven by declines in North America and International. The Products and Systems Integration segment declined 10% primarily due to lower sales of public safety LMR products and professional and commercial radio (PCR), partially offset by growth in video security. The Software and Services segment grew 8% driven by growth in LMR services, video security and command center software. Revenue from acquisitions was $60 million, and the impact of favorable currency rates was $19 million.

[0000068505-21-000005:8k_2_02:19]
•Operating earnings - GAAP operating margin was 24.4% of sales, down from 24.8% in the year-ago quarter primarily due to lower sales in the Products and Systems Integration segment, partially offset by higher sales and improved operating leverage in the Software and Services segment. Non-GAAP operating margin was 29.3% of sales, down from 29.7% in the year-ago quarter primarily due to lower sales in the Products and Systems Integration segment, partially offset by higher sales and improved operating leverage in the Software and Services segment.

[0000068505-21-000005:8k_2_02:20]
•Taxes - The GAAP effective tax rate was 20.9%, compared to (26.4)% in the year-ago quarter. The year-over-year increase in the GAAP rate was primarily due to the valuation allowance release of the US foreign tax credit in the year-ago quarter. The Non-GAAP effective tax rate was 21.0%, compared to 22.0% in the year-ago quarter. The year-over-year decrease was primarily driven by research and development credits recognized in 2020.

[0000068505-21-000005:8k_2_02:21]
•Cash flow - The company generated $703 million in operating cash, compared with $795 million in the year-ago quarter. Free cash flow was $637 million, compared with $736 million in the year-ago quarter. The year-over-year decline in cash flow was primarily driven by lower sales in Q4 2020.

[0000068505-21-000005:8k_2_02:22]
•Capital allocation - During the quarter, the company repurchased $171 million of its common stock and paid $109 million in dividends. Additionally, the company repaid the remaining $200 million of its revolving credit facility borrowing.

[0000068505-21-000005:8k_2_02:23]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-21-000005:8k_2_02:24]
•Revenue - Full-year revenue was $7.4 billion, down 6% driven by declines in North America and International. The Products and Systems Integration segment declined 13% primarily due to lower sales of public safety LMR products and PCR, partially offset by growth in video security. The Software and Services segment grew 9% driven by growth in LMR services, video security and command center software. Revenue from acquisitions was $203 million, and the impact of unfavorable currency rates was $12 million.

[0000068505-21-000005:8k_2_02:25]
•Operating earnings - For the full year, GAAP operating margin was 18.7% of revenue, compared with 20.0% for the prior year.  The decrease was primarily driven by lower sales in the Products and Systems Integration segment, partially offset by higher sales and improved operating leverage in the Software and Services segment. Non-GAAP operating margin was 24.8% of revenue, compared with 25.0% for the prior year, driven by lower sales in Products and Systems Integration, partially offset by higher sales and improved operating leverage in the Software and Services segment.

[0000068505-21-000005:8k_2_02:26]
•Taxes - The 2020 GAAP effective tax rate was 18.8%, compared to 13.0% for the prior year. The year-over-year increase in the GAAP rate was primarily due to the valuation allowance release of the US foreign tax credit in the prior year, offset by a higher tax benefit from share based compensation deduction in 2020. The non-GAAP effective tax rate was 20.0% compared with 22.4% in the previous year. The year-over-year decrease was driven by higher credits related to research and development and share based compensation recognized in the current year.

[0000068505-21-000005:8k_2_02:27]
•Cash flow - The company generated $1.6 billion in operating cash, compared to $1.8 billion in the prior year. Free cash flow was $1.4 billion, compared to $1.6 billion in the prior year. The

[0000068505-21-000005:8k_2_02:28]
decrease in cash flow was driven by lower sales and higher cash taxes, partially offset by improvements in working capital.

[0000068505-21-000005:8k_2_02:29]
•Backlog - The company ended the year with record backlog of $11.4 billion, up $175 million from the prior year. Software and Services segment backlog was up 3% or $213 million, primarily driven by growth in North America and $139 million of favorable currency rates, partially offset by revenue recognized for the Airwave and ESN contracts. Products and Systems Integrations segment backlog was down 1% or $38 million driven by delay in sales engagements related to COVID-19.

[0000068505-21-000005:8k_2_02:30]
•Capital allocation - In 2020, the company repurchased $612 million of its common stock at an average price of $155.93, paid $436 million in dividends, and used $287 million for acquisitions.  Additionally, the company refinanced approximately $900 million of debt with a new ten-year debt issuance at 2.3%.

[0000068505-21-000005:8k_2_02:31]
NOTABLE WINS & ACHIEVEMENTS IN Q4

[0000068505-21-000005:8k_2_02:32]
Software and Services

[0000068505-21-000005:8k_2_02:33]
•$100 million+ P25 managed services contract with State of Tasmania, Australia

[0000068505-21-000005:8k_2_02:34]
•$79 million TETRA managed services contract extension in Europe

[0000068505-21-000005:8k_2_02:35]
•$30 million P25 multi-year service contract with Minnesota DOT

[0000068505-21-000005:8k_2_02:36]
•$29 million P25 multi-year service contract with Austin, Texas

[0000068505-21-000005:8k_2_02:37]
•$11 million for a command center software contract in Norway

[0000068505-21-000005:8k_2_02:38]
Products and Systems Integration

[0000068505-21-000005:8k_2_02:39]
•$122 million P25 order for Nassau County, New York

[0000068505-21-000005:8k_2_02:40]
•$61 million P25 order for State of New Jersey

[0000068505-21-000005:8k_2_02:41]
•$50 million+ of P25 orders for several large North America utilities customers

[0000068505-21-000005:8k_2_02:42]
•$26 million P25 order for Morris County, New Jersey

[0000068505-21-000005:8k_2_02:43]
•$20 million TETRA MTS order in the U.K.

[0000068505-21-000005:8k_2_02:44]
•Double-digit growth in fixed video sales into government customers

[0000068505-21-000005:8k_2_02:45]
BUSINESS OUTLOOK

[0000068505-21-000005:8k_2_02:46]
•First-quarter 2021 - The company expects revenue growth of 5.5% to 6% compared with the first quarter of 2020. The company expects non-GAAP earnings per share in the range of $1.58 to $1.64 per share. This assumes current foreign exchange rates, approximately 174 million fully diluted shares, and an effective tax rate of approximately 19%.

[0000068505-21-000005:8k_2_02:47]
•Full-year 2021 - The company expects revenue growth of 7.25% to 8% and non-GAAP earnings per share in the range of $8.50 to $8.62 per share. This assumes current foreign exchange rates, 174 million fully diluted shares and a non-GAAP effective tax rate of 22.5% to 23%.

[0000068505-21-000005:8k_2_02:48]
COVID-19

[0000068505-21-000005:8k_2_02:49]
In response to the evolving COVID-19 pandemic, the company continues to adhere to its plans to keep its employees and customers healthy and safe, as well as ensuring continued operations and business continuity. Safety measures during this outbreak include having the vast majority of employees work remotely, suspending employee travel, withdrawing from certain industry events, increasing cleaning services, encouraging face coverings and using thermal scanning. The company continues to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service mission-critical networks on-site as needed to ensure seamless operations. In addition, our supply chain partners remain supportive and continue to do their part to ensure that service levels to the company and its customers remain fulfilled.

[0000068505-21-000005:8k_2_02:50]
The sales teams’ engagement with customers, both virtual and in-person, improved during the fourth quarter.  Additionally, the company’s engineering teams have adapted its solutions offerings to equip customers with the latest technology in the fight to protect their workplace from the spread of COVID-19. Specifically, in the video security business, the company has adapted its software and hardware offerings to provide analytics for occupancy counting, face mask detection and thermal detection capabilities. Given the prioritization of mission-critical communication solutions, we do not anticipate funding at the state and local levels to have a material, negative effect on expected revenues in 2021.

[0000068505-21-000005:8k_2_02:51]
The company has also taken actions in a number of areas to reduce its operating expenses, mostly driven by lower variable compensation, travel costs, contractor spend and reduced real estate footprint to limit the negative effect on operating margins for the year despite the expected reduction of revenue.

[0000068505-21-000005:8k_2_02:52]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) Thursday, Feb 4. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0000068505-21-000005:8k_2_02:53]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-21-000005:8k_2_02:54]
A comparison of results from operations is as follows:

[0000068505-21-000005:8k_2_02:55]
|  | Fourth Quarter | Full Year |
|  | 2020 | 2019 | 2020 | 2019 |
| Net sales | $2,273 | $2,377 | $7,414 | $7,887 |
| Gross margin | 1,146 |  | 1,220 |  | 3,608 |  | 3,931 |  |
| Operating earnings | 555 |  | 590 |  | 1,383 |  | 1,581 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | 412 |  | 244 |  | 949 |  | 868 |  |
| Diluted EPS from continuing operations | $2.37 | $1.39 | $5.45 | $4.95 |
| Weighted average diluted common shares outstanding | 173.5 |  | 175.6 |  | 174.1 |  | 175.6 |  |

[0000068505-21-000005:8k_2_02:56]
HIGHLIGHTED ITEMS

[0000068505-21-000005:8k_2_02:57]
The table below includes highlighted items, share-based compensation expenses, and intangible amortization expense for the fourth-quarter of 2020.

[0000068505-21-000005:8k_2_02:58]
| (per diluted common share) | Q4 2020 |
| GAAP Earnings | $2.37 |
| Highlighted Items: |  |
| Intangibles amortization expense | 0.25 |  |
| Share-based compensation expenses | 0.13 |  |
| Reorganization of business charges | 0.06 |  |
| Hytera-related legal expenses | 0.03 |  |
| Pelco purchase accounting adjustment | 0.02 |  |
| Investment impairments | 0.02 |  |
| Sale of investments | 0.01 |  |
| Acquisition-related transaction fees | — |  |
| Release of uncertain tax positions | — |  |
| Fair value adjustments to equity investments | (0.03) |  |
| Non-GAAP Diluted EPS | $2.86 |

[0000068505-21-000005:8k_2_02:59]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-21-000005:8k_2_02:60]
In addition to the GAAP results included in this news release, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with GAAP.

[0000068505-21-000005:8k_2_02:61]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-21-000005:8k_2_02:62]
Hytera-Related Legal Expenses: On February 14, 2020, the company announced that a jury in the U.S. District Court for the Northern District of Illinois (the "Court") decided in the company's favor in its trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded the company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the company’s motion for a permanent injunction, finding instead that Hytera must pay the company a forward-looking reasonable royalty on products that use the company’s stolen trade secrets. The royalty rate is yet to be determined, and will be set by the Court absent agreement of the parties.

[0000068505-21-000005:8k_2_02:63]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the company’s motion for pre-judgment interest, although the precise amount of interest owed to the company by Hytera is still to be determined by the Court. Other post-trial motions are fully briefed and awaiting ruling, including the company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the company’s judgment award. Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in May 2020; the company previously filed motions to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the U.S. Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the company’s intellectual property.

[0000068505-21-000005:8k_2_02:64]
Management typically considers legal expenses associated with defending our intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both our GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. We anticipate further expenses associated with Hytera-related litigation; however, we believe that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate our business. In addition, if any contingent or actual gain associated with the Hytera litigation is recognized in the future, it will be similarly excluded from our non-GAAP operating income. We believe after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates our ongoing underlying business performance.

[0000068505-21-000005:8k_2_02:65]
For comparative purposes, $5 million, or $0.02 of earnings per share, net of tax, of Hytera-related legal expense was included in our fourth quarter 2019 Non-GAAP operating earnings and $43 million, or $0.20 of earnings per share, net of tax, was included in 2019 Non-GAAP operating earnings.

[0000068505-21-000005:8k_2_02:66]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-21-000005:8k_2_02:67]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-21-000005:8k_2_02:68]
Free cash flow:  Free cash flow represents operating cash flow less capital expenditures. We believe that free cash flow is also useful to investors as the basis for comparing our performance and coverage ratios with other companies in our industries, although our measure of free cash flow may not be directly comparable to similar measures used by other companies.

[0000068505-21-000005:8k_2_02:69]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes non-GAAP organic revenue growth provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-21-000005:8k_2_02:70]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-21-000005:8k_2_02:71]
The company has not quantitatively reconciled its guidance for non-GAAP measurements under "Business Outlook" in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-21-000005:8k_2_02:72]
FORWARD LOOKING STATEMENTS

[0000068505-21-000005:8k_2_02:73]
(i) the impact including increased costs and potential liabilities, associated with changes in laws and regulations regarding privacy, data protection and information security; (ii) challenges relating to existing or future legislation and regulations pertaining to artificial intelligence (“AI”) and AI-enabled products; (iii) the impact of government regulation of radio frequencies; (iv) audits and regulations and laws applicable to our U.S. government customer contracts and grants; (v) impacts of, and associated responses to, COVID-19 and other catastrophic events; (vi) increased risk and competition associated with the expansion of our platforms within our Products and Systems Integration and Software and Services segments; (vii) the effectiveness of our investments in new products and technologies; (viii) the effectiveness of our integrations of acquired businesses; (ix) a security breach or other significant disruption of our IT systems; (x) our inability to protect our intellectual property or potential infringement of

[0000068505-21-000005:8k_2_02:74]
intellectual property rights of third parties; (xi) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xii) the global nature of our employees, customers, suppliers and outsource partners; (xiii) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xiv) the inability of our subcontractors to perform in a timely and compliant manner; (xv) our inability to purchase at acceptable prices a sufficient amount of materials, parts, and components, as well as software and services, to meet the demands of our customers; (xvi) risks related to our large, multi-year system and services contracts; (xvii) the inability of our products to meet our customers’ expectations or regulatory or industry standards; (xviii) impact of current global economic and political conditions in the markets in which we operate; (xix) the inability to settle for cash our 1.75% senior convertible notes; (xx) impact of returns on pension and retirement plan assets and interest rate changes; (xxi) inability to attract and retain senior management and key employees; (xxii) impact of product regulatory and safety, consumer, worker safety and environmental laws; (xxiii) inability to access the capital markets for financing on acceptable terms and conditions; and (xxiv) impact of tax matters. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-21-000005:8k_2_02:75]
ABOUT MOTOROLA SOLUTIONS

[0000068505-21-000005:8k_2_02:76]
Motorola Solutions is a global leader in mission-critical communications and analytics. Our technology platforms in mission-critical communications, command center software, video security & analytics, bolstered by managed & support services, make communities safer and help businesses stay productive and secure. At Motorola Solutions, we are ushering in a new era in public safety and security. Learn more at www.motorolasolutions.com.

[0000068505-21-000005:8k_2_02:77]
MEDIA CONTACT

[0000068505-21-000005:8k_2_02:78]
Alexandra Reynolds

[0000068505-21-000005:8k_2_02:79]
Motorola Solutions

[0000068505-21-000005:8k_2_02:80]
+1 312-965-3968

[0000068505-21-000005:8k_2_02:81]
alexandra.reynolds@motorolasolutions.com

[0000068505-21-000005:8k_2_02:82]
INVESTOR CONTACT

[0000068505-21-000005:8k_2_02:83]
Tim Yocum

[0000068505-21-000005:8k_2_02:84]
Motorola Solutions

[0000068505-21-000005:8k_2_02:85]
+1 847-576-6899

[0000068505-21-000005:8k_2_02:86]
Tim.Yocum@motorolasolutions.com

[0000068505-21-000005:8k_2_02:87]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2021 Motorola Solutions, Inc. All rights reserved.

[0000068505-21-000005:8k_2_02:88]
GAAP-1

[0000068505-21-000005:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:90]
Consolidated Statements of Operations

[0000068505-21-000005:8k_2_02:91]
(In millions, except per share amount)

[0000068505-21-000005:8k_2_02:92]
|  | Three Months Ended |
|  | December 31, 2020 |  | December 31, 2019 |
| Net sales from products | $ | 1,326 |  |  | $ | 1,507 |  |
| Net sales from services | 947 |  |  | 870 |  |
| Net sales | 2,273 |  |  | 2,377 |  |
| Costs of products sales | 568 |  |  | 621 |  |
| Costs of services sales | 559 |  |  | 536 |  |
| Costs of sales | 1,127 |  |  | 1,157 |  |
| Gross margin | 1,146 |  |  | 1,220 |  |
| Selling, general and administrative expenses | 343 |  |  | 368 |  |
| Research and development expenditures | 182 |  |  | 182 |  |
| Other charges | 9 |  |  | 26 |  |
| Intangibles amortization | 57 |  |  | 54 |  |
| Operating earnings | 555 |  |  | 590 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (53) |  |  | (55) |  |
| Gains (losses) on sales of investments and businesses, net | (1) |  |  | 1 |  |
| Other, net | 21 |  |  | (343) |  |
| Total other expense | (33) |  |  | (397) |  |
| Net earnings before income taxes | 522 |  |  | 193 |  |
| Income tax expense (benefit) | 109 |  |  | (51) |  |
| Net earnings | 413 |  |  | 244 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 412 |  |  | $ | 244 |  |
| Earnings per common share: |  |  |  |
| Basic: | $ | 2.43 |  |  | $ | 1.43 |  |
| Diluted: | $ | 2.37 |  |  | $ | 1.39 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 169.5 |  | 170.9 |
| Diluted | 173.5 |  | 175.6 |

[0000068505-21-000005:8k_2_02:93]
|  | Percentage of Net Sales* |
| Net sales from products | 58.3 | % |  | 63.4 | % |
| Net sales from services | 41.7 | % |  | 36.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 42.8 | % |  | 41.2 | % |
| Costs of services sales | 59.0 | % |  | 61.6 | % |
| Costs of sales | 49.6 | % |  | 48.7 | % |
| Gross margin | 50.4 | % |  | 51.3 | % |
| Selling, general and administrative expenses | 15.1 | % |  | 15.5 | % |
| Research and development expenditures | 8.0 | % |  | 7.7 | % |
| Other charges | 0.4 | % |  | 1.1 | % |
| Intangibles amortization | 2.5 | % |  | 2.3 | % |
| Operating earnings | 24.4 | % |  | 24.8 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.3) | % |  | (2.3) | % |
| Gains (losses) on sales of investments and businesses, net | — | % |  | — | % |
| Other, net | 0.9 | % |  | (14.4) | % |
| Total other expense | (1.5) | % |  | (16.7) | % |
| Net earnings before income taxes | 23.0 | % |  | 8.1 | % |
| Income tax expense (benefit) | 4.8 | % |  | (2.1) | % |
| Net earnings | 18.2 | % |  | 10.3 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 18.1 | % |  | 10.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-21-000005:8k_2_02:94]
GAAP-2

[0000068505-21-000005:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:96]
Consolidated Statements of Operations

[0000068505-21-000005:8k_2_02:97]
(In millions, except per share amounts)

[0000068505-21-000005:8k_2_02:98]
|  | Years Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2018 |
| Net sales from products | $ | 4,087 |  |  | $ | 4,746 |  |  | $ | 4,463 |  |
| Net sales from services | 3,327 |  |  | 3,141 |  |  | 2,880 |  |
| Net sales | 7,414 |  |  | 7,887 |  |  | 7,343 |  |
| Costs of products sales | 1,872 |  |  | 2,049 |  |  | 2,035 |  |
| Costs of services sales | 1,934 |  |  | 1,907 |  |  | 1,828 |  |
| Costs of sales | 3,806 |  |  | 3,956 |  |  | 3,863 |  |
| Gross margin | 3,608 |  |  | 3,931 |  |  | 3,480 |  |
| Selling, general and administrative expenses | 1,293 |  |  | 1,403 |  |  | 1,254 |  |
| Research and development expenditures | 686 |  |  | 687 |  |  | 637 |  |
| Other charges | 31 |  |  | 52 |  |  | 146 |  |
| Intangibles amortization | 215 |  |  | 208 |  |  | 188 |  |
| Operating earnings | 1,383 |  |  | 1,581 |  |  | 1,255 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (220) |  |  | (220) |  |  | (222) |  |
| Gains (losses) on sales of investments and businesses, net | (2) |  |  | 5 |  |  | 16 |  |
| Other, net | 13 |  |  | (365) |  |  | 53 |  |
| Total other expense | (209) |  |  | (580) |  |  | (153) |  |
| Net earnings before income taxes | 1,174 |  |  | 1,001 |  |  | 1,102 |  |
| Income tax expense | 221 |  |  | 130 |  |  | 133 |  |
| Net earnings | 953 |  |  | 871 |  |  | 969 |  |
| Less: Earnings attributable to noncontrolling interests | 4 |  |  | 3 |  |  | 3 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 949 |  |  | $ | 868 |  |  | $ | 966 |  |
| Earnings per common share: |  |  |  |  |  |
| Basic: | $ | 5.58 |  |  | $ | 5.21 |  |  | $ | 5.95 |  |
| Diluted: | $ | 5.45 |  |  | $ | 4.95 |  |  | $ | 5.62 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 170.0 |  |  | 166.6 |  |  | 162.4 |  |
| Diluted | 174.1 |  |  | 175.6 |  |  | 172.0 |  |

[0000068505-21-000005:8k_2_02:99]
|  | Percentage of Net Sales* |
| Net sales from products | 55.1 | % |  | 60.2 | % |  | 60.8 | % |
| Net sales from services | 44.9 | % |  | 39.8 | % |  | 39.2 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 45.8 | % |  | 43.2 | % |  | 45.6 | % |
| Costs of services sales | 58.1 | % |  | 60.7 | % |  | 63.5 | % |
| Costs of sales | 51.3 | % |  | 50.2 | % |  | 52.6 | % |
| Gross margin | 48.7 | % |  | 49.8 | % |  | 47.4 | % |
| Selling, general and administrative expenses | 17.4 | % |  | 17.8 | % |  | 17.1 | % |
| Research and development expenditures | 9.3 | % |  | 8.7 | % |  | 8.7 | % |
| Other charges | 0.4 | % |  | 0.7 | % |  | 2.0 | % |
| Intangibles amortization | 2.9 | % |  | 2.6 | % |  | 2.6 | % |
| Operating earnings | 18.7 | % |  | 20.0 | % |  | 17.1 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (3.0) | % |  | (2.8) | % |  | (3.0) | % |
| Gains (losses) on sales of investments and businesses, net | — | % |  | 0.1 | % |  | 0.2 | % |
| Other, net | 0.2 | % |  | (4.6) | % |  | 0.7 | % |
| Total other expense | (2.8) | % |  | (7.4) | % |  | (2.1) | % |
| Net earnings before income taxes | 15.8 | % |  | 12.7 | % |  | 15.0 | % |
| Income tax expense | 3.0 | % |  | 1.6 | % |  | 1.8 | % |
| Net earnings | 12.9 | % |  | 11.0 | % |  | 13.2 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 12.8 | % |  | 11.0 | % |  | 13.2 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-21-000005:8k_2_02:100]
GAAP-3

[0000068505-21-000005:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:102]
Consolidated Balance Sheets

[0000068505-21-000005:8k_2_02:103]
(In millions)

[0000068505-21-000005:8k_2_02:104]
|  |  | December 31, 2020 |  | December 31, 2019 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,254 |  |  | $ | 1,001 |  |
| Accounts receivable, net |  | 1,390 |  |  | 1,412 |  |
| Contract assets |  | 933 |  |  | 1,046 |  |
| Inventories, net |  | 508 |  |  | 447 |  |
| Other current assets |  | 242 |  |  | 272 |  |
| Total current assets |  | 4,327 |  |  | 4,178 |  |
| Property, plant and equipment, net |  | 1,022 |  |  | 992 |  |
| Operating lease assets |  | 468 |  |  | 554 |  |
| Investments |  | 158 |  |  | 159 |  |
| Deferred income taxes |  | 966 |  |  | 943 |  |
| Goodwill |  | 2,219 |  |  | 2,067 |  |
| Intangible assets, net |  | 1,234 |  |  | 1,327 |  |
| Other assets |  | 482 |  |  | 422 |  |
| Total assets |  | $ | 10,876 |  |  | $ | 10,642 |  |
| Liabilities and Stockholders' Equity (Deficit) |  |  |  |  |
| Current portion of long-term debt |  | $ | 12 |  |  | $ | 16 |  |
| Accounts payable |  | 612 |  |  | 618 |  |
| Contract liabilities |  | 1,554 |  |  | 1,449 |  |
| Accrued liabilities |  | 1,311 |  |  | 1,356 |  |
| Total current liabilities |  | 3,489 |  |  | 3,439 |  |
| Long-term debt |  | 5,163 |  |  | 5,113 |  |
| Operating lease liabilities |  | 402 |  |  | 497 |  |
| Other liabilities |  | 2,363 |  |  | 2,276 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (558) |  |  | (700) |  |
| Noncontrolling interests |  | 17 |  |  | 17 |  |
| Total liabilities and stockholders’ equity (deficit) |  | $ | 10,876 |  |  | $ | 10,642 |  |

[0000068505-21-000005:8k_2_02:105]
GAAP-4

[0000068505-21-000005:8k_2_02:106]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:107]
Consolidated Statements of Cash Flows

[0000068505-21-000005:8k_2_02:108]
(In millions)

[0000068505-21-000005:8k_2_02:109]
|  | Three Months Ended |
|  | December 31, 2020 |  | December 31, 2019 |
| Operating |  |  |  |
| Net earnings | $ | 413 |  |  | $ | 244 |  |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 109 |  |  | 104 |  |
| Non-cash other charges (income) | 15 |  |  | 8 |  |
| U.S. pension settlement loss | — |  |  | 359 |  |
| Share-based compensation expense | 29 |  |  | 31 |  |
| Loss (gains) on sales of investments and businesses, net | 1 |  |  | (1) |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (222) |  |  | (109) |  |
| Inventories | (16) |  |  | 14 |  |
| Other current assets and contract assets | 168 |  |  | (55) |  |
| Accounts payable, accrued liabilities, and contract liabilities | 263 |  |  | 341 |  |
| Other assets and liabilities | (8) |  |  | (16) |  |
| Deferred income taxes | (49) |  |  | (125) |  |
| Net cash provided by operating activities | 703 |  |  | 795 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (4) |  |  | (86) |  |
| Proceeds from sales of investments | 3 |  |  | 6 |  |
| Capital expenditures | (66) |  |  | (59) |  |
| Proceeds from sales of property, plant and equipment | — |  |  | 7 |  |
| Net cash used for investing activities | (67) |  |  | (132) |  |
| Financing |  |  |  |
| Repayment of debt | (4) |  |  | (604) |  |
| Repayment of unsecured revolving credit facility draw | (200) |  |  | — |  |
| Issuances of common stock | 49 |  |  | 32 |  |
| Purchases of common stock | (171) |  |  | (145) |  |
| Payment of dividends | (109) |  |  | (98) |  |
| Net cash used for financing activities | (435) |  |  | (815) |  |
| Effect of exchange rate changes on cash and cash equivalents | 46 |  |  | 13 |  |
| Net increase (decrease) in cash and cash equivalents | 247 |  |  | (139) |  |
| Cash and cash equivalents, beginning of period | 1,007 |  |  | 1,140 |  |
| Cash and cash equivalents, end of period | $ | 1,254 |  |  | $ | 1,001 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 637 |  |  | $ | 736 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |

[0000068505-21-000005:8k_2_02:110]
GAAP-5

[0000068505-21-000005:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:112]
Consolidated Statements of Cash Flows

[0000068505-21-000005:8k_2_02:113]
(In millions)

[0000068505-21-000005:8k_2_02:114]
|  | Years Ended |
|  | December 31, 2020 |  | December 31, 2019 |  | December 31, 2018 |
| Operating |  |  |  |  |  |
| Net earnings | $ | 953 |  |  | $ | 871 |  |  | $ | 969 |  |
| Adjustments to reconcile Net earnings (loss) to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 409 |  |  | 394 |  |  | 360 |  |
| Non-cash other charges (income) | (13) |  |  | 35 |  |  | 56 |  |
| U.S. pension settlement loss | — |  |  | 359 |  |  | — |  |
| Share-based compensation expense | 129 |  |  | 118 |  |  | 73 |  |
| Losses (gains) on sales of investments and businesses, net | 2 |  |  | (5) |  |  | (16) |  |
| Losses from the extinguishment of long-term debt | 56 |  |  | 50 |  |  | — |  |
| Gain from the extinguishment of 2.00% senior convertible notes | — |  |  | (4) |  |  | (6) |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | 90 |  |  | (79) |  |  | 62 |  |
| Inventories | (14) |  |  | (74) |  |  | 71 |  |
| Other current assets and contract assets | 167 |  |  | 49 |  |  | (251) |  |
| Accounts payable, accrued liabilities, and contract liabilities | (116) |  |  | 198 |  |  | 271 |  |
| Other assets and liabilities | (25) |  |  | (5) |  |  | (523) |  |
| Deferred income taxes | (25) |  |  | (84) |  |  | 9 |  |
| Net cash provided by operating activities | 1,613 |  |  | 1,823 |  |  | 1,075 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (287) |  |  | (709) |  |  | (1,164) |  |
| Proceeds from sales of investments | 11 |  |  | 16 |  |  | 95 |  |
| Capital expenditures | (217) |  |  | (248) |  |  | (197) |  |
| Proceeds from sales of property, plant and equipment | 56 |  |  | 7 |  |  | — |  |
| Net cash used for investing activities | (437) |  |  | (934) |  |  | (1,266) |  |
| Financing |  |  |  |  |  |
| Net proceeds from issuance of debt | 892 |  |  | 1,804 |  |  | 1,090 |  |
| Repayment of debt | (914) |  |  | (2,039) |  |  | (323) |  |
| Proceeds from unsecured revolving credit facility draw | 800 |  |  | — |  |  | 400 |  |
| Repayment of unsecured revolving credit facility draw | (800) |  |  | — |  |  | (400) |  |
| Issuances of common stock | 108 |  |  | 114 |  |  | 168 |  |
| Purchases of common stock | (612) |  |  | (315) |  |  | (132) |  |
| Settlement of conversion premium on 2.00% senior convertible notes | — |  |  | (326) |  |  | (169) |  |
| Payment of dividends | (436) |  |  | (379) |  |  | (337) |  |
| Payment of dividends to noncontrolling interest | (4) |  |  | (3) |  |  | (1) |  |
| Deferred acquisition costs | — |  |  | — |  |  | (76) |  |
| Net cash provided by (used for) financing activities | (966) |  |  | (1,144) |  |  | 220 |  |
| Effect of exchange rate changes on cash and cash equivalents | 43 |  |  | (1) |  |  | (40) |  |
| Net increase (decrease) in cash and cash equivalents | 253 |  |  | (256) |  |  | (11) |  |
| Cash and cash equivalents, beginning of period | 1,001 |  |  | 1,257 |  |  | 1,268 |  |
| Cash and cash equivalents, end of period | $ | 1,254 |  |  | $ | 1,001 |  |  | $ | 1,257 |  |
| Financial Ratios: |  |  |  |  |  |
| Free cash flow* | 1,396 |  |  | 1,575 |  |  | 878 |  |
| *Free cash flow is a non-GAAP financial measure and is calculated as Net cash provided by operating activities - Capital expenditures |  |  |  |  |  |

[0000068505-21-000005:8k_2_02:115]
GAAP-6

[0000068505-21-000005:8k_2_02:116]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:117]
Segment Information

[0000068505-21-000005:8k_2_02:118]
(In millions)

[0000068505-21-000005:8k_2_02:119]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 1,510 |  |  | $ | 1,673 |  |  | (10) | % |
| Software and Services | 763 |  |  | 704 |  |  | 8 | % |
| Total Motorola Solutions | $ | 2,273 |  |  | $ | 2,377 |  |  | (4) | % |
|  | Years Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 4,634 |  |  | $ | 5,329 |  |  | (13) | % |
| Software and Services | 2,780 |  |  | 2,558 |  |  | 9 | % |
| Total Motorola Solutions | $ | 7,414 |  |  | $ | 7,887 |  |  | (6) | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 351 |  |  | $ | 426 |  |  | (18) | % |
| Software and Services | 204 |  |  | 164 |  |  | 24 | % |
| Total Motorola Solutions | $ | 555 |  |  | $ | 590 |  |  | (6) | % |
|  | Years Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 656 |  |  | $ | 994 |  |  | (34) | % |
| Software and Services | 727 |  |  | 587 |  |  | 24 | % |
| Total Motorola Solutions | $ | 1,383 |  |  | $ | 1,581 |  |  | (13) | % |

[0000068505-21-000005:8k_2_02:120]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  |  |
| Products and Systems Integration | 23.2 | % |  | 25.5 | % |  |  |
| Software and Services | 26.7 | % |  | 23.3 | % |  |  |
| Total Motorola Solutions | 24.4 | % |  | 24.8 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  |  |
| Products and Systems Integration | 14.2 | % |  | 18.7 | % |  |  |
| Software and Services | 26.2 | % |  | 22.9 | % |  |  |
| Total Motorola Solutions | 18.7 | % |  | 20.0 | % |  |  |

[0000068505-21-000005:8k_2_02:121]
Non-GAAP-1

[0000068505-21-000005:8k_2_02:122]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:123]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expenses, and Highlighted Items)

[0000068505-21-000005:8k_2_02:124]
| Q1 2020 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 53 |  |  | $ | 13 |  |  | $ | 40 |  |  | $ | 0.23 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 38 |  |  | 9 |  |  | 29 |  |  | 0.17 |  |
| Hytera-related legal expenses |  | SG&A |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.11 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 18 |  |  | 4 |  |  | 14 |  |  | 0.08 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Legal settlements |  | Other charges (income) |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income |  | (1) |  |  | — |  |  | (1) |  |  | (0.01) |  |
| Release of uncertain tax positions |  | Income tax expense |  | — |  |  | 1 |  |  | (1) |  |  | (0.01) |  |
| Gain on sale of property, plant, and equipment |  | Other charges (income) |  | (50) |  |  | (12) |  |  | (38) |  |  | (0.22) |  |
| Total impact on Net earnings |  |  |  | $ | 87 |  |  | $ | 21 |  |  | $ | 66 |  |  | $ | 0.37 |  |
| Q2 2020 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 51 |  |  | $ | 12 |  |  | $ | 39 |  |  | $ | 0.22 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 41 |  |  | 10 |  |  | 31 |  |  | 0.18 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 31 |  |  | 7 |  |  | 24 |  |  | 0.14 |  |
| Legal settlements |  | Other charges (income) |  | 7 |  |  | 2 |  |  | 5 |  |  | 0.03 |  |
| Hytera-related legal expenses |  | SG&A |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Fixed asset impairment |  | Other charges (income) |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Release of uncertain tax positions |  | Income tax expense |  | — |  |  | (1) |  |  | 1 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other income |  | (4) |  |  | (1) |  |  | (3) |  |  | (0.02) |  |
| Total impact on Net earnings |  |  |  | $ | 137 |  |  | $ | 31 |  |  | $ | 106 |  |  | $ | 0.61 |  |
| Q3 2020 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Loss from extinguishment of long-term debt |  | Other expense |  | $ | 56 |  |  | $ | 13 |  |  | $ | 43 |  |  | $ | 0.25 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 54 |  |  | 12 |  |  | 42 |  |  | 0.24 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 31 |  |  | 7 |  |  | 24 |  |  | 0.14 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 13 |  |  | 3 |  |  | 10 |  |  | 0.06 |  |
| Hytera-related legal expenses |  | SG&A |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 5 |  |  | — |  |  | 5 |  |  | 0.03 |  |
| Fair value adjustments to equity investments |  | Other expense |  | 4 |  |  | 1 |  |  | 3 |  |  | 0.02 |  |
| Pelco purchase accounting adjustment |  | Cost of sales |  | 3 |  |  | 1 |  |  | 2 |  |  | 0.01 |  |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total impact on Net earnings |  |  |  | $ | 172 |  |  | $ | 38 |  |  | $ | 134 |  |  | $ | 0.77 |  |

[0000068505-21-000005:8k_2_02:125]
| Q4 2020 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 57 |  |  | $ | 13 |  |  | $ | 44 |  |  | $ | 0.25 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 29 |  |  | 7 |  |  | 22 |  |  | 0.13 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 14 |  |  | 4 |  |  | 10 |  |  | 0.06 |  |
| Hytera-related legal expenses |  | SG&A |  | 7 |  |  | 2 |  |  | 5 |  |  | 0.03 |  |
| Pelco purchase accounting adjustment |  | Cost of sales |  | 4 |  |  | 1 |  |  | 3 |  |  | 0.02 |  |
| Investment impairments |  | Other expense |  | 4 |  |  | 1 |  |  | 3 |  |  | 0.02 |  |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Release of uncertain tax positions |  | Other income and Income tax expense |  | (3) |  |  | (3) |  |  | — |  |  | — |  |
| Fair value adjustments to equity investments |  | Other income |  | (5) |  |  | (1) |  |  | (4) |  |  | (0.03) |  |
| Total impact on Net earnings |  |  |  | $ | 109 |  |  | $ | 24 |  |  | $ | 85 |  |  | $ | 0.49 |  |
| FY 2020 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 215 |  |  | $ | 50 |  |  | $ | 165 |  |  | $ | 0.95 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 129 |  |  | 30 |  |  | 99 |  |  | 0.57 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 86 |  |  | 21 |  |  | 65 |  |  | 0.37 |  |
| Loss from extinguishment of long-term debt |  | Other expense |  | 56 |  |  | 13 |  |  | 43 |  |  | 0.25 |  |
| Hytera-related legal expenses |  | SG&A |  | 42 |  |  | 10 |  |  | 32 |  |  | 0.18 |  |
| Legal settlements |  | Other charges (income) |  | 9 |  |  | 2 |  |  | 7 |  |  | 0.04 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 9 |  |  | — |  |  | 9 |  |  | 0.05 |  |
| Pelco purchase accounting adjustment |  | Cost of sales |  | 7 |  |  | 2 |  |  | 5 |  |  | 0.03 |  |
| Fixed asset impairment |  | Other charges (income) |  | 5 |  |  | 1 |  |  | 4 |  |  | 0.02 |  |
| Investment impairments |  | Other expense |  | 4 |  |  | 1 |  |  | 3 |  |  | 0.02 |  |
| Sale of investments |  | (Gain) or loss on sales of investments and businesses, net |  | 2 |  |  | — |  |  | 2 |  |  | 0.01 |  |
| Release of uncertain tax positions |  | Other income and Income tax expense |  | (3) |  |  | (3) |  |  | — |  |  | — |  |
| Fair value adjustments to equity investments |  | Other income |  | (6) |  |  | (1) |  |  | (5) |  |  | (0.03) |  |
| Gain on sale of property, plant, and equipment |  | Other charges (income) |  | (50) |  |  | (12) |  |  | (38) |  |  | (0.22) |  |
| Total impact on Net earnings |  |  |  | $ | 505 |  |  | $ | 114 |  |  | $ | 391 |  |  | $ | 2.24 |  |

[0000068505-21-000005:8k_2_02:126]
Non-GAAP-2

[0000068505-21-000005:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:128]
Non-GAAP Segment Information

[0000068505-21-000005:8k_2_02:129]
(In millions)

[0000068505-21-000005:8k_2_02:130]
| Net Sales |
|  | Three Months Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 1,510 |  |  | $ | 1,673 |  |  | (10) | % |
| Software and Services | 763 |  |  | 704 |  |  | 8 | % |
| Total Motorola Solutions | $ | 2,273 |  |  | $ | 2,377 |  |  | (4) | % |
|  | Years Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 4,634 |  |  | $ | 5,329 |  |  | (13) | % |
| Software and Services | 2,780 |  |  | 2,558 |  |  | 9 | % |
| Total Motorola Solutions | $ | 7,414 |  |  | $ | 7,887 |  |  | (6) | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 408 |  |  | $ | 484 |  |  | (16) | % |
| Software and Services | 259 |  |  | 223 |  |  | 16 | % |
| Total Motorola Solutions | $ | 667 |  |  | $ | 707 |  |  | (6) | % |
|  | Years Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Products and Systems Integration | $ | 880 |  |  | $ | 1,173 |  |  | (25) | % |
| Software and Services | 955 |  |  | 802 |  |  | 19 | % |
| Total Motorola Solutions | $ | 1,835 |  |  | $ | 1,975 |  |  | (7) | % |

[0000068505-21-000005:8k_2_02:131]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  |  |
| Products and Systems Integration | 27.0 | % |  | 28.9 | % |  |  |
| Software and Services | 33.9 | % |  | 31.7 | % |  |  |
| Total Motorola Solutions | 29.3 | % |  | 29.7 | % |  |  |
|  | Years Ended |  |  |
|  | December 31, 2020 |  | December 31, 2019 |  |  |
| Products and Systems Integration | 19.0 | % |  | 22.0 | % |  |  |
| Software and Services | 34.3 | % |  | 31.4 | % |  |  |
| Total Motorola Solutions | 24.8 | % |  | 25.0 | % |  |  |

[0000068505-21-000005:8k_2_02:132]
Non-GAAP-3

[0000068505-21-000005:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-21-000005:8k_2_02:134]
Operating Earnings after Non-GAAP Adjustments

[0000068505-21-000005:8k_2_02:135]
| Q1 2020 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,655 |  |  | $ | 993 |  |  | $ | 662 |  |
| Operating earnings ("OE") |  | $ | 259 |  |  | $ | 92 |  |  | $ | 167 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 53 |  |  | 12 |  |  | 41 |  |
| Share-based compensation expenses |  | 38 |  |  | 27 |  |  | 11 |  |
| Hytera-related legal expenses |  | 25 |  |  | 25 |  |  | — |  |
| Reorganization of business charges |  | 18 |  |  | 14 |  |  | 4 |  |
| Acquisition-related transaction fees |  | 2 |  |  | 1 |  |  | 1 |  |
| Legal settlements |  | 2 |  |  | 2 |  |  | — |  |
| Gain on sale of property, plant, and equipment |  | (50) |  |  | (50) |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 88 |  |  | 31 |  |  | 57 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 347 |  |  | $ | 123 |  |  | $ | 224 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 15.6 | % |  | 9.3 | % |  | 25.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 21.0 | % |  | 12.4 | % |  | 33.8 | % |

[0000068505-21-000005:8k_2_02:136]
| Q2 2020 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,618 |  |  | $ | 968 |  |  | $ | 650 |  |
| Operating earnings ("OE") |  | $ | 218 |  |  | $ | 49 |  |  | $ | 169 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 51 |  |  | 12 |  |  | 39 |  |
| Reorganization of business charges |  | 41 |  |  | 33 |  |  | 8 |  |
| Share-based compensation expenses |  | 31 |  |  | 22 |  |  | 9 |  |
| Legal settlements |  | 7 |  |  | 7 |  |  | — |  |
| Hytera-related legal expenses |  | 5 |  |  | 5 |  |  | — |  |
| Fixed asset impairment |  | 5 |  |  | 3 |  |  | 2 |  |
| Acquisition-related transaction fees |  | 1 |  |  | — |  |  | 1 |  |
| Total above-OE non-GAAP adjustments |  | 141 |  |  | 82 |  |  | 59 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 359 |  |  | $ | 131 |  |  | $ | 228 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 13.5 | % |  | 5.1 | % |  | 26.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 22.2 | % |  | 13.5 | % |  | 35.1 | % |

[0000068505-21-000005:8k_2_02:137]
| Q3 2020 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 1,868 |  |  | $ | 1,163 |  |  | $ | 705 |  |
| Operating earnings ("OE") |  | $ | 352 |  |  | $ | 164 |  |  | $ | 188 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 54 |  |  | 12 |  |  | 42 |  |
| Share-based compensation expenses |  | 31 |  |  | 22 |  |  | 9 |  |
| Reorganization of business charges |  | 13 |  |  | 10 |  |  | 3 |  |
| Acquisition-related transaction fees |  | 5 |  |  | 3 |  |  | 2 |  |
| Hytera-related legal expenses |  | 5 |  |  | 5 |  |  | — |  |
| Pelco purchase accounting adjustment |  | 3 |  |  | 3 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 111 |  |  | 55 |  |  | 56 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 463 |  |  | $ | 219 |  |  | $ | 244 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 18.9 | % |  | 14.1 | % |  | 26.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.8 | % |  | 18.8 | % |  | 34.6 | % |

[0000068505-21-000005:8k_2_02:138]
| Q4 2020 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 2,273 |  |  | $ | 1,510 |  |  | $ | 763 |  |
| Operating earnings ("OE") |  | $ | 555 |  |  | $ | 351 |  |  | $ | 204 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 57 |  |  | 13 |  |  | 44 |  |
| Share-based compensation expenses |  | 29 |  |  | 21 |  |  | 8 |  |
| Reorganization of business charges |  | 14 |  |  | 11 |  |  | 3 |  |
| Hytera-related legal expenses |  | 7 |  |  | 7 |  |  | — |  |
| Pelco purchase accounting adjustment |  | 4 |  |  | 4 |  |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 112 |  |  | 57 |  |  | 55 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 667 |  |  | $ | 408 |  |  | $ | 259 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 24.4 | % |  | 23.2 | % |  | 26.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 29.3 | % |  | 27.0 | % |  | 33.9 | % |

[0000068505-21-000005:8k_2_02:139]
| FY 2020 |
|  |  | TOTAL |  | Products and Systems Integration |  | Software and Services |
| Net sales |  | $ | 7,414 |  |  | $ | 4,634 |  |  | $ | 2,780 |  |
| Operating earnings ("OE") |  | $ | 1,383 |  |  | $ | 656 |  |  | $ | 727 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Intangibles amortization expense |  | 215 |  |  | 49 |  |  | 166 |  |
| Share-based compensation expenses |  | 129 |  |  | 92 |  |  | 37 |  |
| Reorganization of business charges |  | 86 |  |  | 68 |  |  | 18 |  |
| Hytera-related legal expenses |  | 42 |  |  | 42 |  |  | — |  |
| Legal settlements |  | 9 |  |  | 9 |  |  | — |  |
| Acquisition-related transaction fees |  | 9 |  |  | 4 |  |  | 5 |  |
| Fixed asset impairment |  | 5 |  |  | 3 |  |  | 2 |  |
| Pelco purchase accounting adjustment |  | 7 |  |  | 7 |  |  | — |  |
| Gain on sale of property, plant, and equipment |  | (50) |  |  | (50) |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 452 |  |  | 224 |  |  | 228 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,835 |  |  | $ | 880 |  |  | $ | 955 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 18.7 | % |  | 14.2 | % |  | 26.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 24.8 | % |  | 19.0 | % |  | 34.3 | % |

[0000068505-21-000005:8k_2_02:140]
Non-GAAP-4

[0000068505-21-000005:8k_2_02:141]
| Motorola Solutions, Inc. and Subsidiaries |
| Non-GAAP Organic Revenue |
| (In millions) |

[0000068505-21-000005:8k_2_02:142]
|  |  | Three Months Ended |  |  |
|  |  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Net sales |  | $ | 2,273 |  |  | $ | 2,377 |  |  | (4) | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 60 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,213 |  |  | $ | 2,377 |  |  | (7) | % |

[0000068505-21-000005:8k_2_02:143]
|  |  | Year Ended |  |  |
|  |  | December 31, 2020 |  | December 31, 2019 |  | % Change |
| Net sales |  | $ | 7,414 |  |  | $ | 7,887 |  |  | (6) | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 291 |  |  | 88 |  |  |  |
| Organic revenue |  | $ | 7,123 |  |  | $ | 7,799 |  |  | (9) | % |
