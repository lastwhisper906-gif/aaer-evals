# MSI notes — 0000068505-21-000008


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000068505-21-000008:notes:1]
Portions of the registrant’s definitive Proxy Statement to be delivered to stockholders in connection with its Annual Meeting of Stockholders to be held on May 18, 2021 (the "Proxy Statement"), are incorporated by reference into Part III of this Annual Report on Form 10-K (this "Form 10-K").


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-21-000008:notes:2]
Summary of Significant Accounting Policies
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-21-000008:notes:3]
The consolidated financial statements as of December 31, 2020 and 2019 and for the years ended December 31, 2020, 2019 and 2018, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.

[0000068505-21-000008:notes:4]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-21-000008:notes:5]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of devices, systems and system integration and a full set of software and service offerings. The Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services.

[0000068505-21-000008:notes:6]
The Products and Systems Integration segment is comprised of devices, systems, and systems integration for our LMR Mission Critical Communications and Video Security and Analytics technologies. Direct customers of the Products and Systems Integration segment are typically government, public safety agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and video security, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video security are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. For Products and Systems Integration sales, the Company records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-21-000008:notes:7]
LMR and Video Security and Analytics devices include two-way portable and vehicle-mounted radios, fixed and mobile video cameras and accessories. Devices are considered capable of being distinct and distinct within the context of the Company's contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-21-000008:notes:8]
The Products and Systems Integration segment includes both customized radio networks and video security solutions, including the integration of these networks with devices, software, and applications within both LMR and Video Security and Analytics technologies. The networks include the aggregation of promises to the customer to provide i) a radio network core and central processing software, base stations, consoles, and repeaters or ii) a video security solution including video analytics, network video management hardware and software, and access control solutions. The individual promises of the radio network are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised, while individual promises of the video security solution are capable of being distinct and distinct in the context of the contract. The radio network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Products and Systems Integration revenue is recognized over an average duration of approximately one to two years. Video security solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-21-000008:notes:9]
The Software and Services segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Software and Services segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-21-000008:notes:10]
Software offerings primarily include Command Center Software and Video Security and Analytics software and services which can be delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-21-000008:notes:11]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis.

[0000068505-21-000008:notes:12]
Services include a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer-owned or Motorola Solutions-owned networks. Services are provided across all technologies and are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-21-000008:notes:13]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-21-000008:notes:14]
The Company accounts for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, the Company has determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on its customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-21-000008:notes:15]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. The Company has a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined. For system contracts accounted for over time using estimated costs as a measure of performance completed, revenue for the year ended December 31, 2020 was $1.8 billion, compared to $1.9 billion for the years ended December 31, 2019 and December 31, 2018.

[0000068505-21-000008:notes:16]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $2 million at both December 31, 2020 and December 31, 2019.

[0000068505-21-000008:notes:17]
Investments: Investments in debt securities classified as available-for-sale are carried at fair value with changes in fair value recorded in other comprehensive income. Certain investments will be accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-21-000008:notes:18]
The Company assesses declines in the fair value of debt securities and equity method investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s Consolidated Statements of Operations in the period in which they become impaired.

[0000068505-21-000008:notes:19]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other, net within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded in Other, net within Other income (expense).

[0000068505-21-000008:notes:20]
Inventories: Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or net realizable value.

[0000068505-21-000008:notes:21]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, one to twenty years; machinery and equipment, one to fifteen years and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-21-000008:notes:22]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and selling, general and administrative costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it is determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform a quantitative goodwill impairment test, which compares the fair value of the reporting unit to its carrying value. If the carrying amount of a reporting unit exceeds its fair value, the Company would recognize an impairment loss in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-21-000008:notes:23]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.

[0000068505-21-000008:notes:24]
Leases: The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-21-000008:notes:25]
The Company determines if an arrangement is a lease at inception of the contract. The Company’s key considerations in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company’s contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the right to operate the asset at its discretion during the term of the contract.

[0000068505-21-000008:notes:26]
Right-of-use ("ROU") assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company’s lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in lease payments. For the Company’s leases consisting of land and other equipment (i.e. “communication network sites”), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage. ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-21-000008:notes:27]
As the majority of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company’s incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-21-000008:notes:28]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communication network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-21-000008:notes:29]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered

[0000068505-21-000008:notes:30]
to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-21-000008:notes:31]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expenses and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-21-000008:notes:32]
Long-Term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. Long-term receivables are considered past due if payments have not been received according to the contractual terms of the note agreement, including principal and interest. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-21-000008:notes:33]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the “Accrued liabilities” statement line and the non-current portion is included in the “Other liabilities” statement line within the Company’s Consolidated Balance Sheet.

[0000068505-21-000008:notes:34]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-21-000008:notes:35]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-21-000008:notes:36]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-21-000008:notes:37]
Derivative Instruments: Gains and losses on hedging instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income (loss). Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income (loss) at their initial value and amortized into Interest expense, net on a straight-line basis.

[0000068505-21-000008:notes:38]
Fair Value Measurements: The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while

[0000068505-21-000008:notes:39]
unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-21-000008:notes:40]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-21-000008:notes:41]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-21-000008:notes:42]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-21-000008:notes:43]
Earnings Per Share: The Company calculates its basic earnings per share based on the weighted-average number of common shares issued and outstanding. Net earnings attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings per share. Diluted earnings per share is calculated by dividing net earnings attributable to Motorola Solutions, Inc. by the sum of the weighted-average number of common shares used in the basic earnings per share calculation and the weighted-average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings per share calculation. Both basic and diluted earnings per share amounts are calculated for net earnings attributable to Motorola Solutions, Inc. for all periods presented.

[0000068505-21-000008:notes:44]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk-free rate, dividend yield, and expected life. Performance-based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-21-000008:notes:45]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from ten to thirty years. Prior service costs will be amortized over periods ranging from one to twenty-nine years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-21-000008:notes:46]
The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s Consolidated Balance Sheets using a December 31 measurement date.

[0000068505-21-000008:notes:47]
The benefit obligation and plan assets for the Company's U.S. Pension Benefit Plan and Postretirement Health Care Benefit Plan are measured as of December 31, 2020. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-21-000008:notes:48]
Recent Acquisitions:

[0000068505-21-000008:notes:49]
On August 28, 2020, we acquired the Callyo business ("Callyo"), a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to our existing Command Center Software suite critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. The business is a part of the Software and Services segment.

[0000068505-21-000008:notes:50]
On July 31, 2020, we acquired Pelco, Inc. ("Pelco"), a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates our continued investment in Video Security and Analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000008:notes:51]
On June 16, 2020 we acquired IndigoVision Group plc ("IndigoVision") for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements our Video Security and Analytics technology, providing enhanced geographical reach across a wider customer base. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000008:notes:52]
On April 30, 2020, we acquired a cybersecurity services business for $32 million of cash, net of cash acquired. The acquisition expands our ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment.

[0000068505-21-000008:notes:53]
On March 3, 2020, we acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The acquisition expands our ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment.

[0000068505-21-000008:notes:54]
On October 16, 2019, we acquired a data solutions business for vehicle location information for a purchase price of $85 million, net of cash acquired. The acquisition enhances our Video Security and Analytics technology by adding data to our existing license plate recognition (“LPR”) database within our Software and Services segment.

[0000068505-21-000008:notes:55]
On July 11, 2019, we acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands our Video Security and Analytics technology within both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000008:notes:56]
On March 11, 2019, we acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands our commercial portfolio with new capabilities, allowing us to offer an enhanced platform for customers to communicate, coordinate resources and secure their facilities. The business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000008:notes:57]
On January 7, 2019, we announced that we acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands Video Security and Analytics within both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000008:notes:58]
On March 28, 2018, we completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions, for a purchase price of $974 million. The acquisition expands Video Security and Analytics within both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000008:notes:59]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications, for a purchase price of $237 million. This acquisition expands our Command Center Software portfolio with additional solutions for next generation 911 within our Software and Services segment.

[0000068505-21-000008:notes:60]
Recent Accounting Pronouncements:

[0000068505-21-000008:notes:61]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-21-000008:notes:62]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company has determined that the adoption of this ASU will not have a material impact on its financial statement disclosures.

[0000068505-21-000008:notes:63]
Recently Adopted Accounting Pronouncements:

[0000068505-21-000008:notes:64]
In August 2018, the FASB issued ASU No. 2018-14, "Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans," which amends ASC 715-20, Compensation – Retirement Benefits – Defined Benefit Plans – General. This ASU modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include the amounts in accumulated other comprehensive income expected to be recognized in net periodic benefit costs over the next fiscal year and the effects of a one-percentage-point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for postretirement health care benefits. The new disclosures also require an explanation of significant gains and losses related to changes in benefit obligations. The Company adopted ASU No. 2018-14 for the year ended December 31, 2020 and applied the

[0000068505-21-000008:notes:65]
required retrospective transition method. The adoption, which is limited to disclosures only, did not have a material effect on the Company’s consolidated financial statements.

[0000068505-21-000008:notes:66]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019, May 2019 and November 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” ASU No. 2019-04, "Codification Improvements to Topic 326, Financial Instruments - Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments," ASU No. 2019-05, "Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief," and ASU No. 2019-11,"Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” respectively, which collectively provided additional implementation guidance regarding ASU No. 2016-13. The Company adopted ASU No. 2016-13 as of January 1, 2020 using a modified retrospective transition approach for all credit losses. Consequently, financial information was not updated and disclosures required under ASU No. 2016-13 are not provided for dates and periods before January 1, 2020.

[0000068505-21-000008:notes:67]
The Company considered the impact of adoption of ASU No. 2016-13 by reviewing historical losses in conjunction with current and future economic conditions on the following financial assets: i) cash equivalents, ii) accounts receivable, iii) contract assets, and iv) long-term receivables. Historical losses for these financial assets were previously insignificant with the exception of accounts receivable. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. The Company’s historical loss model is based on past due customer receivable balances and considers past collection experience, historical write-offs as well as the customer’s overall financial condition. Customer receivables are considered past due if payments have not been received within the agreed invoice terms. These historical losses are aggregated based on the type of customer (direct and indirect) and the geographic region (North America region and International region). The adoption of this standard did not have a material impact to the Company's financial statements.

[0000068505-21-000008:notes:68]
The following table displays the rollforward of the allowance for credit losses on the Company's trade receivables:

[0000068505-21-000008:notes:69]
|  | Balance atJanuary 1, 2020 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31, 2020 |
| Allowance for credit losses | $ | 63 |  |  | $ | 47 |  |  | $ | (34) |  |  | $ | (1) |  |  | $ | 75 |  |

[0000068505-21-000008:notes:70]
*Adjustments include translation adjustments

[0000068505-21-000008:notes:71]
We adopted ASU No. 2016-02, “Leases,” and all the related amendments (collectively “ASC 842”) on January 1, 2019. ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases are classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-21-000008:notes:72]
ASC 842 provides for a number of optional practical expedients in transition. We elected the practical expedients, which permit us to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. We did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing us to carry forward the lease term as determined prior to adoption of ASC 842. Finally, we also elected the practical expedient related to land easements, which enabled us to continue our accounting treatment for land easements on existing agreements as of January 1, 2019.

[0000068505-21-000008:notes:73]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. We elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows us to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with our prior accounting. We also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

[0000068505-21-000008:notes:74]
As of January 1, 2019, we recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition.

[0000068505-21-000008:notes:75]
For arrangements where we are the lessor, the adoption of ASC 842 did not have a material impact on our financial statements as the majority of our leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. We have elected the above practical expedient and determined that non-lease components are predominant and, accordingly, are accounting for the single components as managed service contracts under ASC Topic 606.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-21-000008:notes:76]
Revenue from Contracts with Customers
Disaggregation of Revenue

[0000068505-21-000008:notes:77]
During the first quarter of 2020, the Company restructured to realize more operational efficiencies, combining our Europe, Middle East and Africa ("EMEA"), Asia Pacific ("AP"), and Latin America ("LA") regions into one region, which is now reflected as "International." Accordingly, the Company now reports net sales in the following two geographic regions: North America, which includes the United States and Canada, and International. In addition, during the fourth quarter of 2020, the Company updated its presentation of major products and services to provide a more comprehensive view of technologies within our reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which we refer to as "technologies" in this Form 10-K): LMR Mission Critical Communications, Video Security and Analytics, and Command Center Software. The Company has updated all periods presented to reflect this change in presentation.

[0000068505-21-000008:notes:78]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the year ended December 31, 2020, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of reportable segments:

[0000068505-21-000008:notes:79]
|  | Years Ended |
|  | 2020 |  | 2019 |  | 2018 |
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions |
| North America | $ | 3,418 |  |  | $ | 1,606 |  |  | $ | 5,024 |  |  | $ | 3,846 |  |  | $ | 1,430 |  |  | $ | 5,276 |  |  | $ | 3,488 |  |  | $ | 1,176 |  |  | $ | 4,664 |  |
| International | 1,216 |  |  | 1,174 |  |  | 2,390 |  |  | 1,483 |  |  | 1,128 |  |  | 2,611 |  |  | 1,612 |  |  | 1,067 |  |  | 2,679 |  |
|  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 7,887 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |  | $ | 7,343 |  |
| Major Products and Services |
| LMR | $ | 3,992 |  |  | $ | 2,008 |  |  | $ | 6,000 |  |  | $ | 4,830 |  |  | $ | 1,891 |  |  | $ | 6,721 |  |  | $ | 4,783 |  |  | $ | 1,815 |  |  | $ | 6,598 |  |
| Video Security and Analytics | 642 |  |  | 285 |  |  | 927 |  |  | 499 |  |  | 210 |  |  | 709 |  |  | 317 |  |  | 65 |  |  | 382 |  |
| Command Center Software | — |  |  | 487 |  |  | 487 |  |  | — |  |  | 457 |  |  | 457 |  |  | — |  |  | 363 |  |  | 363 |  |
|  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 7,887 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |  | $ | 7,343 |  |
| Customer Type |
| Direct | $ | 2,991 |  |  | $ | 2,558 |  |  | $ | 5,549 |  |  | $ | 3,441 |  |  | $ | 2,395 |  |  | $ | 5,836 |  |  | $ | 3,317 |  |  | $ | 2,134 |  |  | $ | 5,451 |  |
| Indirect | 1,643 |  |  | 222 |  |  | 1,865 |  |  | 1,888 |  |  | 163 |  |  | 2,051 |  |  | 1,783 |  |  | 109 |  |  | 1,892 |  |
|  | $ | 4,634 |  |  | $ | 2,780 |  |  | $ | 7,414 |  |  | $ | 5,329 |  |  | $ | 2,558 |  |  | $ | 7,887 |  |  | $ | 5,100 |  |  | $ | 2,243 |  |  | $ | 7,343 |  |

[0000068505-21-000008:notes:80]
Remaining Performance Obligations

[0000068505-21-000008:notes:81]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which are not yet satisfied as of December 31, 2020 was $7.2 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.5 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.1 billion is from Software and Services performance obligations that were not yet satisfied as of December 31, 2020. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-21-000008:notes:82]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-21-000008:notes:83]
Contract Balances

[0000068505-21-000008:notes:84]
| (in millions) | 2020 |  | 2019 |  | 2018 |  |  |  |  |
| Accounts receivable, net | $ | 1,390 |  |  | $ | 1,412 |  |  | $ | 1,293 |  |  |  |  |  |
| Contract assets | 933 |  |  | 1,046 |  |  | 1,012 |  |  |  |  |  |
| Contract liabilities | 1,554 |  |  | 1,449 |  |  | 1,263 |  |  |  |  |  |
| Non-current contract liabilities | 283 |  |  | 274 |  |  | 214 |  |  |  |  |  |

[0000068505-21-000008:notes:85]
Revenue recognized during the year ended December 31, 2020 which was previously included in Contract liabilities as of January 1, 2020 was $946 million, compared to $854 million of revenue recognized during the year ended December 31, 2019 which was previously included in Contract liabilities as of January 1, 2019, and $836 million of revenue recognized during the year ended December 31, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $53 million was reversed during the year ended December 31, 2020 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $50 million during the year ended December 31, 2019 and $15 million during the year ended December 31, 2018.

[0000068505-21-000008:notes:86]
There have been no material expected credit losses recognized on contract assets during the year ended December 31, 2020.

[0000068505-21-000008:notes:87]
Contract Cost Balances

[0000068505-21-000008:notes:88]
| (in millions) | 2020 |  | 2019 |  | 2018 |  |  |  |  |
| Current contract cost assets | $ | 23 |  |  | $ | 24 |  |  | $ | 30 |  |  |  |  |  |
| Non-current contract cost assets | 105 |  |  | 107 |  |  | 98 |  |  |  |  |  |

[0000068505-21-000008:notes:89]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $49 million for the year ended December 31, 2020, compared to $42 million as of the year ended December 31, 2019 and $44 million as of the year ended December 31, 2018.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-21-000008:notes:90]
Leases
Components of Lease Expense

[0000068505-21-000008:notes:91]
| (in millions) | December 31, 2020 |  | December 31, 2019 |
| Lease expense: |  |  |  |
| Operating lease cost | $ | 130 |  |  | $ | 133 |  |
| Finance lease cost |  |  |  |
| Amortization of right-of-use assets | 11 |  |  | 12 |  |
| Interest on lease liabilities | 1 |  |  | 2 |  |
| Total finance lease cost | 12 |  |  | 14 |  |
| Short-term lease cost | 3 |  |  | 4 |  |
| Variable cost | 37 |  |  | 35 |  |
| Sublease income | (5) |  |  | (4) |  |
| Net lease expense | $ | 177 |  |  | $ | 182 |  |

[0000068505-21-000008:notes:92]
Rental expense, net of sublease income, for the year ended December 31, 2018 was $108 million.

[0000068505-21-000008:notes:93]
Lease Assets and Liabilities

[0000068505-21-000008:notes:94]
| (in millions) |  | Statement Line Classification |  | December 31, 2020 |  | December 31, 2019 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 468 |  |  | $ | 554 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 30 |  |  | 41 |  |  |  |
|  |  |  |  | $ | 498 |  |  | $ | 595 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 126 |  |  | $ | 122 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 11 |  |  | 13 |  |  |  |
|  |  |  |  | $ | 137 |  |  | $ | 135 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 402 |  |  | $ | 497 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 5 |  |  | 16 |  |  |  |
|  |  |  |  | $ | 407 |  |  | $ | 513 |  |  |  |

[0000068505-21-000008:notes:95]
For the year ended December 31, 2020, the Company exercised a break option reducing the term of an International office lease by five years. This resulted in a reduction to both the Operating lease asset and Operating lease liabilities by approximately $47 million.

[0000068505-21-000008:notes:96]
Other Information Related to Leases

[0000068505-21-000008:notes:97]
| (in millions) | December 31, 2020 |  | December 31, 2019 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 144 |  |  | $ | 140 |  |  |  |
| Net cash used for operating activities related to finance leases | 1 |  |  | 2 |  |  |  |
| Net cash used for financing activities related to finance leases | 12 |  |  | 14 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 84 |  |  | $ | 86 |  |  |  |

[0000068505-21-000008:notes:98]
| (in millions) | December 31, 2020 |  | December 31, 2019 |  |  |
| Weighted average remaining lease terms (years): |  |  |  |  |  |
| Operating leases | 6 |  | 7 |  |  |
| Finance leases | 2 |  | 2 |  |  |
| Weighted average discount rate: |  |  |  |  |  |
| Operating leases | 3.30 | % |  | 3.61 | % |  |  |
| Finance leases | 4.21 | % |  | 4.28 | % |  |  |

[0000068505-21-000008:notes:99]
Future Lease Payments

[0000068505-21-000008:notes:100]
| As of December 31, 2020 (in millions) | Operating Leases |  | Finance Leases |  | Total |
| 2021 | $ | 141 |  |  | $ | 12 |  |  | $ | 153 |  |
| 2022 | 127 |  |  | 5 |  |  | 132 |  |
| 2023 | 73 |  |  | — |  |  | 73 |  |
| 2024 | 59 |  |  | — |  |  | 59 |  |
| 2025 | 47 |  |  | — |  |  | 47 |  |
| Thereafter | 139 |  |  | — |  |  | 139 |  |
| Total lease payments | $ | 586 |  |  | $ | 17 |  |  | $ | 603 |  |
| Less: Interest | 58 |  |  | 1 |  |  | 59 |  |
| Present value of lease liabilities | $ | 528 |  |  | $ | 16 |  |  | $ | 544 |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-21-000008:notes:101]
Components of Lease Expense


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-21-000008:notes:102]
Other Financial Data
Statement of Operations Information

[0000068505-21-000008:notes:103]
Other Charges (Income)

[0000068505-21-000008:notes:104]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-21-000008:notes:105]
| Years ended December 31 (in millions) | 2020 |  | 2019 |  | 2018 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 215 |  |  | $ | 208 |  |  | $ | 188 |  |
| Reorganization of businesses (Note 14) | 57 |  |  | 40 |  |  | 61 |  |
| Losses on legal settlements | 9 |  |  | 3 |  |  | 3 |  |
| Asset impairments | 5 |  |  | — |  |  | 1 |  |
| Gain on sale of property, plant, and equipment | (50) |  |  | — |  |  | — |  |
| Environmental reserve expense | — |  |  | — |  |  | 57 |  |
| Operating lease ROU asset impairment | — |  |  | 5 |  |  | — |  |
| Acquisition-related transaction fees | 9 |  |  | 3 |  |  | 24 |  |
| Other | 1 |  |  | 1 |  |  | — |  |
|  | $ | 246 |  |  | $ | 260 |  |  | $ | 334 |  |

[0000068505-21-000008:notes:106]
During 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe.

[0000068505-21-000008:notes:107]
During 2018, the Company recorded an environmental reserve charge of $57 million relating to a designated Superfund site due to: (i) changing the expected timeline of the remediation activities to 30 years and (ii) additional costs for further remediation efforts, increasing the reserve to $107 million.

[0000068505-21-000008:notes:108]
Other Income (Expense)

[0000068505-21-000008:notes:109]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-21-000008:notes:110]
| Years ended December 31 (in millions) | 2020 |  | 2019 |  | 2018 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (233) |  |  | $ | (237) |  |  | $ | (240) |  |
| Interest income | 13 |  |  | 17 |  |  | 18 |  |
|  | $ | (220) |  |  | $ | (220) |  |  | $ | (222) |  |
| Other: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 81 |  |  | $ | 78 |  |  | $ | 75 |  |
| Losses from the extinguishment of long-term debt (Note 5) | (56) |  |  | (50) |  |  | — |  |
| Gains from the extinguishment of 2.00% senior convertible notes (Note 5) | — |  |  | 4 |  |  | 6 |  |
| Investment impairments | (4) |  |  | (18) |  |  | (5) |  |
| Foreign currency loss | (44) |  |  | (22) |  |  | (24) |  |
| Gain (loss) on derivative instruments | 25 |  |  | (8) |  |  | (14) |  |
| Gains on equity method investments | 3 |  |  | 3 |  |  | 1 |  |
| Fair value adjustments to equity investments | 6 |  |  | (3) |  |  | 11 |  |
| U.S. pension settlement (Note 8) | — |  |  | (359) |  |  | — |  |
| Other | 2 |  |  | 10 |  |  | 3 |  |
|  | $ | 13 |  |  | $ | (365) |  |  | $ | 53 |  |

[0000068505-21-000008:notes:111]
Earnings Per Common Share

[0000068505-21-000008:notes:112]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-21-000008:notes:113]
|  |  |  |  |  |  |  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  |  |  | Net Earnings |
| Years ended December 31 |  |  |  |  |  |  | 2020 |  | 2019 |  | 2018 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 949 |  |  | $ | 868 |  |  | $ | 966 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 170.0 |  |  | 166.6 |  |  | 162.4 |  |
| Per share amount |  |  |  |  |  |  | $ | 5.58 |  |  | $ | 5.21 |  |  | $ | 5.95 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 949 |  |  | $ | 868 |  |  | $ | 966 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 170.0 |  |  | 166.6 |  |  | 162.4 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards |  |  |  |  |  |  | 4.1 |  |  | 4.7 |  |  | 4.2 |  |
| 2.00% senior convertible notes |  |  |  |  |  |  | — |  |  | 4.3 |  |  | 5.4 |  |
| 1.75% senior convertible notes |  |  |  |  |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding |  |  |  |  |  |  | 174.1 |  |  | 175.6 |  |  | 172.0 |  |
| Per share amount |  |  |  |  |  |  | $ | 5.45 |  |  | $ | 4.95 |  |  | $ | 5.62 |  |

[0000068505-21-000008:notes:114]
In the computation of diluted earnings per common share for the year ended December 31, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2019, the assumed exercise of 0.3 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2018, the assumed exercise of 0.8 million options, including 0.6 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-21-000008:notes:115]
On September 5, 2019, the Company issued $1.0 billion of 1.75% senior convertible notes which mature on September 15, 2024 ("New Senior Convertible Notes"). The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the New Senior Convertible Notes in cash, Motorola Solutions does not reflect any shares underlying the New Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. Only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $203.50. For the period ended December 31, 2020, there was no dilutive effect of the New Senior Convertible Notes on diluted earnings per share attributable to Motorola Solutions, Inc. as the average stock price for the period outstanding was below the conversion price. See further discussion in Note 5.

[0000068505-21-000008:notes:116]
Balance Sheet Information

[0000068505-21-000008:notes:117]
Accounts Receivable, Net

[0000068505-21-000008:notes:118]
Accounts receivable, net, consists of the following:

[0000068505-21-000008:notes:119]
| December 31 | 2020 |  | 2019 |
| Accounts receivable | $ | 1,465 |  |  | $ | 1,475 |  |
| Less allowance for credit losses | (75) |  |  | (63) |  |
|  | $ | 1,390 |  |  | $ | 1,412 |  |

[0000068505-21-000008:notes:120]
Inventories, Net

[0000068505-21-000008:notes:121]
Inventories, net, consist of the following:

[0000068505-21-000008:notes:122]
| December 31 | 2020 |  | 2019 |
| Finished goods | $ | 271 |  |  | $ | 209 |  |
| Work-in-process and production materials | 360 |  |  | 374 |  |
|  | 631 |  |  | 583 |  |
| Less inventory reserves | (123) |  |  | (136) |  |
|  | $ | 508 |  |  | $ | 447 |  |

[0000068505-21-000008:notes:123]
Other Current Assets

[0000068505-21-000008:notes:124]
Other current assets consist of the following:

[0000068505-21-000008:notes:125]
| December 31 | 2020 |  | 2019 |
| Current contract cost assets (Note 2) | $ | 23 |  |  | $ | 24 |  |
| Tax-related deposits | 52 |  |  | 77 |  |
| Other | 167 |  |  | 171 |  |
|  | $ | 242 |  |  | $ | 272 |  |

[0000068505-21-000008:notes:126]
Property, Plant and Equipment, Net

[0000068505-21-000008:notes:127]
Property, plant and equipment, net, consist of the following:

[0000068505-21-000008:notes:128]
| December 31 | 2020 |  | 2019 |
| Land | $ | 6 |  |  | $ | 15 |  |
| Leasehold improvements | 439 |  |  | 410 |  |
| Machinery and equipment | 2,276 |  |  | 2,051 |  |
|  | 2,721 |  |  | 2,476 |  |
| Less accumulated depreciation | (1,699) |  |  | (1,484) |  |
|  | $ | 1,022 |  |  | $ | 992 |  |

[0000068505-21-000008:notes:129]
Depreciation expense for the years ended December 31, 2020, 2019, and 2018 was $194 million, $186 million and $172 million, respectively.

[0000068505-21-000008:notes:130]
Investments

[0000068505-21-000008:notes:131]
Investments consist of the following:

[0000068505-21-000008:notes:132]
| December 31 | 2020 |  | 2019 |  |  |  |  |
| Common stock | $ | 19 |  |  | $ | 25 |  |  |  |  |  |
| Strategic investments, at cost | 46 |  |  | 40 |  |  |  |  |  |
| Company-owned life insurance policies | 77 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 16 |  |  | 20 |  |  |  |  |  |
|  | $ | 158 |  |  | $ | 159 |  |  |  |  |  |

[0000068505-21-000008:notes:133]
The Company’s common stock portfolio reflects investments in publicly-traded companies within the communications services sector and is valued utilizing active market prices for similar instruments. The Company did not recognize any significant fair value adjustments to the investments during the year ended December 31, 2020.

[0000068505-21-000008:notes:134]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the year ended December 31, 2020.

[0000068505-21-000008:notes:135]
The Company recorded a $2 million loss on the sale of investments and businesses during the year ended December 31, 2020 and gains on the sale of investments and businesses of $5 million and $16 million for the years ended December 31, 2019 and December 31, 2018, respectively. During the year ended December 31, 2019, the Company received $6 million in cash for the sale of $3 million of net assets related to a two-way communications rental business, resulting in the gain on sale of a business of $3 million.

[0000068505-21-000008:notes:136]
During the year ended December 31, 2020, the Company recorded investment impairment charges of $4 million, compared to $18 million during the year ended December 31, 2019 and $5 million during the year ended December 31, 2018, representing other-than-temporary declines in the value of the Company’s strategic equity investment portfolio.

[0000068505-21-000008:notes:137]
Other Assets

[0000068505-21-000008:notes:138]
Other assets consist of the following:

[0000068505-21-000008:notes:139]
| December 31 | 2020 |  | 2019 |
| Defined benefit plan assets (Note 8) | $ | 283 |  |  | $ | 223 |  |
| Non-current contract cost assets (Note 2) | 105 |  |  | 107 |  |
| Other | 94 |  |  | 92 |  |
|  | $ | 482 |  |  | $ | 422 |  |

[0000068505-21-000008:notes:140]
Accrued Liabilities

[0000068505-21-000008:notes:141]
Accrued liabilities consist of the following:

[0000068505-21-000008:notes:142]
| December 31 | 2020 |  | 2019 |
| Compensation | $ | 291 |  |  | $ | 347 |  |
| Tax liabilities (Note 7) | 147 |  |  | 95 |  |
| Dividend payable | 120 |  |  | 110 |  |
| Trade liabilities | 164 |  |  | 161 |  |
| Operating lease liabilities (Note 3) | 126 |  |  | 122 |  |
| Other | 463 |  |  | 521 |  |
|  | $ | 1,311 |  |  | $ | 1,356 |  |

[0000068505-21-000008:notes:143]
Other Liabilities

[0000068505-21-000008:notes:144]
Other liabilities consist of the following:

[0000068505-21-000008:notes:145]
| December 31 | 2020 |  | 2019 |
| Defined benefit plans (Note 8) | $ | 1,578 |  |  | $ | 1,524 |  |
| Non-current contract liabilities (Note 2) | 283 |  |  | 274 |  |
| Unrecognized tax benefits (Note 7) | 49 |  |  | 53 |  |
| Deferred income taxes (Note 7) | 180 |  |  | 184 |  |
| Other | 273 |  |  | 241 |  |
|  | $ | 2,363 |  |  | $ | 2,276 |  |

[0000068505-21-000008:notes:146]
Stockholders’ Equity Information

[0000068505-21-000008:notes:147]
Share Repurchase Program: Through a series of actions, the board of directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2020, the Company had used approximately $13.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $649 million of authority available for future repurchases.

[0000068505-21-000008:notes:148]
The Company's share repurchases, including transaction costs, for 2020, 2019, and 2018 can be summarized as follows:

[0000068505-21-000008:notes:149]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2020 | 3.9 |  |  | $ | 155.93 |  |  | $ | 612 |  |
| 2019 | 2.3 |  |  | 137.35 |  |  | 315 |  |
| 2018 | 1.2 |  |  | 112.42 |  |  | 132 |  |

[0000068505-21-000008:notes:150]
Payment of Dividends: On November 19, 2020, the Company announced that its board of directors approved an increase in the quarterly cash dividend from $0.64 per share to $0.71 per share of common stock. During the years ended December 31, 2020, 2019, and 2018 the Company paid $436 million, $379 million, and $337 million, respectively, in cash dividends to holders of its common stock. On January 15, 2021, the Company paid an additional $120 million in cash dividends to holders of our common stock.

[0000068505-21-000008:notes:151]
Accumulated Other Comprehensive Loss

[0000068505-21-000008:notes:152]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2020, 2019, and 2018:

[0000068505-21-000008:notes:153]
|  | Years ended December 31 |
|  | 2020 |  | 2019 |  | 2018 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (410) |  |  | $ | (444) |  |  | $ | (353) |  |
| Other comprehensive income (loss) before reclassification adjustment | 55 |  |  | 35 |  |  | (94) |  |
| Tax benefit (expense) | (5) |  |  | (1) |  |  | 3 |  |
| Other comprehensive income (loss), net of tax | 50 |  |  | 34 |  |  | (91) |  |
| Balance at end of period | $ | (360) |  |  | $ | (410) |  |  | $ | (444) |  |
| Available-for-Sale Securities: |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| Other comprehensive income (loss) before reclassification adjustment | — |  |  | — |  |  | (8) |  |
| Tax benefit | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss), net of tax | — |  |  | — |  |  | (6) |  |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (2,030) |  |  | $ | (2,321) |  |  | $ | (2,215) |  |
| Other comprehensive income (loss) before reclassification adjustment | (130) |  |  | 337 |  |  | (200) |  |
| Tax benefit (expense) | 30 |  |  | (85) |  |  | 46 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (100) |  |  | 252 |  |  | (154) |  |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 76 |  |  | 65 |  |  | 76 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (18) |  |  | (15) |  |  | (15) |  |
| Tax benefit | (14) |  |  | (11) |  |  | (13) |  |
| Reclassification adjustments into Net earnings, net of tax | 44 |  |  | 39 |  |  | 48 |  |
| Other comprehensive income (loss), net of tax | (56) |  |  | 291 |  |  | (106) |  |
| Balance at end of period | $ | (2,086) |  |  | $ | (2,030) |  |  | $ | (2,321) |  |
| Total Accumulated other comprehensive loss | $ | (2,446) |  |  | $ | (2,440) |  |  | $ | (2,765) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-21-000008:notes:154]
Debt and Credit Facilities
Long-Term Debt

[0000068505-21-000008:notes:155]
| December 31 | 2020 |  | 2019 |
| 3.75% senior notes due 2022 | $ | — |  |  | $ | 550 |  |
| 3.5% senior notes due 2023 | 323 |  |  | 597 |  |
| 4.0% senior notes due 2024 | 583 |  |  | 593 |  |
| 1.75% senior convertible notes due 2024 | 995 |  |  | 988 |  |
| 6.5% debentures due 2025 | 70 |  |  | 72 |  |
| 7.5% debentures due 2025 | 252 |  |  | 254 |  |
| 4.6% senior notes due 2028 | 692 |  |  | 691 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 804 |  |
| 2.3% senior notes due 2030 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 91 |  |
| Other long-term debt | 18 |  |  | 35 |  |
|  | 5,177 |  |  | 5,132 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (3) |  |
| Less: current portion | (12) |  |  | (16) |  |
| Long-term debt | $ | 5,163 |  |  | $ | 5,113 |  |

[0000068505-21-000008:notes:156]
In May of 2019, the Company issued $650 million of 4.60% senior notes due 2029. The Company received proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of $43 million related to this repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-21-000008:notes:157]
In August of 2019, the Company issued a follow-on offering of $150 million to the outstanding 4.60% senior notes due 2029 bringing the total outstanding principal to $800 million. The Company recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding $2 million of accrued interest. After accelerating the amortization of debt issuance costs, the Company recognized a loss of $7 million related to this repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-21-000008:notes:158]
On September 5, 2019, in connection with the Company's repurchase and settlement of the outstanding principal amount of 2.00% senior convertible notes due 2020 issued to Silver Lake Partners, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 (the "New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, the Company intends to settle the principal amount of the New Senior Convertible Notes in cash. The Company recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, the Company calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased Additional paid-in capital.

[0000068505-21-000008:notes:159]
In August of 2020, the Company issued $900 million of 2.30% senior notes due 2030. The Company recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% senior notes due 2022 for a redemption price of $582 million, excluding $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of its long-term debt under a tender offer, for a purchase price of $315 million, excluding $5 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in the Consolidated Statements of Operations.

[0000068505-21-000008:notes:160]
The Company has an unsecured commercial paper program, backed by the 2017 Motorola Solutions Credit Agreement (defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2020, the Company had no outstanding debt under the commercial paper program.

[0000068505-21-000008:notes:161]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2021—$12 million; 2022—$4 million; 2023—$326 million; 2024—$1.6 billion; and 2025—$322 million.

[0000068505-21-000008:notes:162]
Credit Facilities

[0000068505-21-000008:notes:163]
As of December 31, 2020, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. Following the turmoil in the financial markets caused by the COVID-19 pandemic, the Company borrowed $800 million under the facility to bolster its cash holdings out of precaution in the first quarter of 2020 which was repaid as of December 31, 2020. The weighted average borrowing rate for amounts outstanding during the year ended December 31, 2020 was 1.70%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-21-000008:notes:164]
Risk Management
Foreign Currency Risk

[0000068505-21-000008:notes:165]
At December 31, 2020, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.2 billion, compared to $1.1 billion outstanding at December 31, 2019. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-21-000008:notes:166]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2020 and the corresponding positions as of December 31, 2019:

[0000068505-21-000008:notes:167]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2020 |  | 2019 |
| Euro | $ | 177 |  |  | $ | 134 |  |
| British pound | 86 |  |  | 107 |  |
| Canadian dollar | 61 |  |  | 8 |  |
| Chinese renminbi | (90) |  |  | (79) |  |
| Australian dollar | (88) |  |  | (123) |  |

[0000068505-21-000008:notes:168]
Net Investment Hedges

[0000068505-21-000008:notes:169]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. The Company has elected to exclude the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight-line basis and recognized through interest expense. As of December 31, 2020, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £100 million of net investment hedges in certain British pound functional subsidiaries. During the year ended December 31, 2020, the Company amortized $3 million of income from the excluded components through interest expense.

[0000068505-21-000008:notes:170]
Counterparty Risk

[0000068505-21-000008:notes:171]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2020, all of the counterparties had investment grade credit ratings. As of December 31, 2020, the credit risk with all derivative counterparties was approximately $14 million.

[0000068505-21-000008:notes:172]
Derivative Financial Instruments

[0000068505-21-000008:notes:173]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2020 and 2019:

[0000068505-21-000008:notes:174]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2020 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 5 |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 14 |  |  | Other assets |  | $ | 3 |  |  | Accrued liabilities |

[0000068505-21-000008:notes:175]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2019 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | Other assets |  | $ | — |  |  | Accrued liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | Other assets |  | $ | 5 |  |  | Accrued liabilities |

[0000068505-21-000008:notes:176]
The following table summarizes the effect of derivatives designated as hedging instruments, for the years ended December 31, 2020, 2019 and 2018:

[0000068505-21-000008:notes:177]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2020 |  | 2019 |  | 2018 |
| Foreign exchange contracts | $ | (7) |  |  | $ | 8 |  |  | $ | — |  | Other comprehensive income (loss) |

[0000068505-21-000008:notes:178]
The following table summarizes the effect of derivatives not designated as hedging instruments, for the years ended December 31, 2020, 2019 and 2018:

[0000068505-21-000008:notes:179]
|  | December 31 | Financial Statement Location |
| Gain (Loss) on Derivative Instruments | 2020 |  | 2019 |  | 2018 |
| Foreign exchange contracts | $ | 25 |  |  | $ | (8) |  |  | $ | (14) |  | Other income (expense) |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-21-000008:notes:180]
Income Taxes
Components of Income Tax Expense

[0000068505-21-000008:notes:181]
Components of earnings before income taxes are as follows:

[0000068505-21-000008:notes:182]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| United States | $ | 1,029 |  |  | $ | 714 |  |  | $ | 980 |  |
| Other nations | 145 |  |  | 287 |  |  | 122 |  |
|  | $ | 1,174 |  |  | $ | 1,001 |  |  | $ | 1,102 |  |

[0000068505-21-000008:notes:183]
Components of income tax expense (benefit) are as follows:

[0000068505-21-000008:notes:184]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| United States | $ | 117 |  |  | $ | 94 |  |  | $ | 16 |  |
| Other nations | 98 |  |  | 93 |  |  | 88 |  |
| States (U.S.) | 31 |  |  | 27 |  |  | 20 |  |
| Current income tax expense | 246 |  |  | 214 |  |  | 124 |  |
| United States | (21) |  |  | (61) |  |  | 39 |  |
| Other nations | 8 |  |  | (22) |  |  | (18) |  |
| States (U.S.) | (12) |  |  | (1) |  |  | (12) |  |
| Deferred income tax expense (benefit) | (25) |  |  | (84) |  |  | 9 |  |
| Total income tax expense | $ | 221 |  |  | $ | 130 |  |  | $ | 133 |  |

[0000068505-21-000008:notes:185]
Differences between income tax expense computed at the U.S. federal statutory tax rate of 21% and income tax expense as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-21-000008:notes:186]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| Income tax expense at statutory rate | $ | 246 |  | 21.0 | % |  | $ | 210 |  | 21.0 | % |  | $ | 231 |  | 21.0 | % |
| State income taxes, net of federal benefit | 39 |  | 3.3 | % |  | 32 |  | 3.2 | % |  | 11 |  | 1.0 | % |
| U.S. tax expense (benefit) on undistributed non-U.S. earnings | (2) |  | (0.2) | % |  | 6 |  | 0.6 | % |  | 6 |  | 0.5 | % |
| Non-U.S. tax expense on non-U.S. earnings | 5 |  | 0.5 | % |  | 4 |  | 0.4 | % |  | 7 |  | 0.6 | % |
| U.S. tax reform | — |  | — | % |  | — |  | — | % |  | (79) |  | (7.2) | % |
| Reserve for uncertain tax positions | — |  | — | % |  | (3) |  | (0.3) | % |  | 2 |  | 0.2 | % |
| Other tax expense (benefit) | 5 |  | 0.4 | % |  | (3) |  | (0.3) | % |  | 8 |  | 0.7 | % |
| Research credits | (28) |  | (2.4) | % |  | (10) |  | (1.0) | % |  | (9) |  | (0.8) | % |
| Stock compensation | (48) |  | (4.1) | % |  | (27) |  | (2.7) | % |  | (30) |  | (2.7) | % |
| Valuation allowances | 4 |  | 0.3 | % |  | (79) |  | (7.9) | % |  | (14) |  | (1.3) | % |
|  | $ | 221 |  | 18.8 | % |  | $ | 130 |  | 13.0 | % |  | $ | 133 |  | 12.0 | % |

[0000068505-21-000008:notes:187]
The effective tax rate for 2020 was below the current U.S. federal statutory rate of 21% primarily due to the recognition of excess tax benefits of share-based compensation and increased benefit of research and development tax credits.

[0000068505-21-000008:notes:188]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are the result of retirement benefit adjustments, currency translation adjustments, and fair value adjustments to available-for-sale securities. The adjustments were benefits of $11 million for the year ended December 31, 2020, charges of $97 million for the year ended December 31, 2019 and benefits of $38 million for the year ended December 31, 2018.

[0000068505-21-000008:notes:189]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the 2017 U.S. Tax Cuts and Jobs Act ("the Tax Act"), dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-21-000008:notes:190]
Undistributed foreign earnings that the Company intends to reinvest indefinitely amounted to, in the aggregate, $1.9 billion at December 31, 2020. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-21-000008:notes:191]
Gross deferred tax assets were $2.1 billion and $2.0 billion for December 31, 2020 and December 31, 2019, respectively. Deferred tax assets, net of valuation allowances, were $1.7 billion and $1.6 billion at December 31, 2020 and December 31, 2019, respectively. Gross deferred tax liabilities were $926 million and $854 million at December 31, 2020 and 2019, respectively.

[0000068505-21-000008:notes:192]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-21-000008:notes:193]
| December 31 | 2020 |  | 2019 |
| Inventory | $ | 22 |  |  | $ | 45 |  |
| Accrued liabilities and allowances | 67 |  |  | 65 |  |
| Employee benefits | 372 |  |  | 392 |  |
| Capitalized items | (61) |  |  | (129) |  |
| Tax basis differences on investments | (3) |  |  | 2 |  |
| Depreciation tax basis differences on fixed assets | 52 |  |  | 68 |  |
| Undistributed non-U.S. earnings | (33) |  |  | (27) |  |
| Tax attribute carryforwards | 449 |  |  | 471 |  |
| Business reorganization | 16 |  |  | 10 |  |
| Warranty and customer liabilities | 24 |  |  | 33 |  |
| Deferred revenue and costs | 203 |  |  | 165 |  |
| Valuation allowances | (341) |  |  | (349) |  |
| Operating lease assets | (103) |  |  | (125) |  |
| Operating lease liabilities | 119 |  |  | 139 |  |
| Other | 3 |  |  | (1) |  |
|  | $ | 786 |  |  | $ | 759 |  |

[0000068505-21-000008:notes:194]
At December 31, 2020 and 2019, the Company had valuation allowances of $341 million and $349 million, respectively, against its deferred tax assets, including $81 million and $85 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance decreased $5 million during 2020 primarily due to the expiration of tax attributes. The Company's U.S. valuation allowance decreased $111 million during 2019 primarily due to a change in the Company's ability to utilize U.S. foreign tax credits and the expiration of tax attributes. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-21-000008:notes:195]
Tax attribute carryforwards are as follows:

[0000068505-21-000008:notes:196]
| December 31, 2020 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 48 |  |  | $ | 10 |  |  | 2028-2038 |
| Foreign tax credits | — |  |  | 282 |  |  | 2021-2023 |
| General business credits | — |  |  | 3 |  |  | 2030-2039 |
| State tax losses | — |  |  | 27 |  |  | 2021-2031 |
| State tax credits | — |  |  | 20 |  |  | 2021-2039 |
| Non-U.S. subsidiaries: |  |  |  |  |  |
| Japan tax losses | 74 |  |  | 22 |  |  | 2021-2027 |
| United Kingdom tax losses | 113 |  |  | 21 |  |  | Unlimited |
| Singapore tax losses | 12 |  |  | 2 |  |  | Unlimited |
| Canada tax losses | 20 |  |  | 5 |  |  | 2034-2038 |
| Spain tax credits | — |  |  | 24 |  |  | 2021-2028 |
| Other subsidiaries tax losses | 90 |  |  | 20 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 13 |  |  | Various |
|  |  |  | $ | 449 |  |  |  |

[0000068505-21-000008:notes:197]
The Company had unrecognized tax benefits of $64 million and $70 million at December 31, 2020 and December 31, 2019, respectively, of which approximately $53 million and $66 million, if recognized, would have affected the effective tax rate for 2020 and 2019, respectively.

[0000068505-21-000008:notes:198]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-21-000008:notes:199]
|  | 2020 |  | 2019 |
| Balance at January 1 | $ | 70 |  |  | $ | 76 |  |
| Additions based on tax positions related to current year | 8 |  |  | 4 |  |
| Additions for tax positions of prior years | 2 |  |  | 3 |  |
| Reductions for tax positions of prior years | (6) |  |  | (8) |  |
| Settlements and agreements | (8) |  |  | (1) |  |
| Lapse of statute of limitations | (2) |  |  | (4) |  |
| Balance at December 31 | $ | 64 |  |  | $ | 70 |  |

[0000068505-21-000008:notes:200]
The Company recorded $49 million and $53 million of unrecognized tax benefits in other liabilities at December 31, 2020 and December 31, 2019, respectively.

[0000068505-21-000008:notes:201]
The Internal Revenue Service ("IRS") has concluded the examination of the Company's 2014 and 2015 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-21-000008:notes:202]
| Jurisdiction | Tax Years |
| United States | 2016-2020 |
| Australia | 2016-2020 |
| Canada | 2015-2020 |
| Germany | 2016-2020 |
| India | 1997-2020 |
| Israel | 2019-2020 |
| Poland | 2016-2020 |
| Malaysia | 2013-2020 |
| United Kingdom | 2019-2020 |

[0000068505-21-000008:notes:203]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-21-000008:notes:204]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be up to a $13 million tax benefit.

[0000068505-21-000008:notes:205]
At December 31, 2020, the Company had $33 million accrued for interest and $15 million accrued for penalties on unrecognized tax benefits. At December 31, 2019, the Company had $29 million and $16 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-21-000008:notes:206]
Retirement Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-21-000008:notes:207]
U.S. Pension Benefit Plans

[0000068505-21-000008:notes:208]
The Company’s non-contributory U.S. defined benefit plan (the "U.S. Pension Plan") provides benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. In December 2008, the Company amended the U.S. Pension Plan and MSSP (together the "U.S. Pension Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-21-000008:notes:209]
In December 2019, the Company completed a voluntary lump-sum election window offered to certain participants of the U.S. Pension Plan. The aggregate dollar amount of lump-sum elections by approximately 6,300 participants was $836 million, and accordingly, this amount was paid out of plan assets prior to December 31, 2019. These actions resulted in a reduction of our projected benefit obligation, absent of actuarial losses experienced from decreases in interest rates, of $1.0 billion and a settlement loss of $359 million recorded within “Other charges” on the Consolidated Statement of Operations.

[0000068505-21-000008:notes:210]
Postretirement Health Care Benefits Plan

[0000068505-21-000008:notes:211]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of amendments, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-21-000008:notes:212]
These series of amendments to the Postretirement Health Care Benefits Plan resulted in a reduction in the postretirement benefit obligation. A substantial portion of the decrease related to prior service credits and will be amortized as a credit to the Consolidated Statements of Operations over approximately five years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan. These amendments will be fully amortized during fiscal year 2021.

[0000068505-21-000008:notes:213]
Non U.S. Pension Benefit Plans

[0000068505-21-000008:notes:214]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-21-000008:notes:215]
In June 2015, the Company amended its Non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-21-000008:notes:216]
In 2019, the Motorola Solutions United Kingdom defined benefit plan trustees decided to exercise their discretion on early retirement benefit reductions. This action resulted in a reduction of the projected benefit obligation of approximately $83 million related to prior service credits that will be amortized as a credit to the Consolidated Statements of Operations over approximately twenty-nine years, or the period in which the remaining employees eligible for the plan qualify for benefits under the plan.

[0000068505-21-000008:notes:217]
Net Periodic Cost (Benefit)

[0000068505-21-000008:notes:218]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-21-000008:notes:219]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 144 |  |  | 202 |  |  | 186 |  |  | 29 |  |  | 36 |  |  | 38 |  |  | 2 |  |  | 3 |  |  | 2 |  |
| Expected return on plan assets | (225) |  |  | (275) |  |  | (270) |  |  | (85) |  |  | (85) |  |  | (92) |  |  | (10) |  |  | (10) |  |  | (10) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 58 |  |  | 46 |  |  | 57 |  |  | 15 |  |  | 15 |  |  | 15 |  |  | 3 |  |  | 4 |  |  | 4 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (3) |  |  | — |  |  | — |  |  | (15) |  |  | (15) |  |  | (15) |  |
| Settlement loss | — |  |  | 359 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (23) |  |  | $ | 332 |  |  | $ | (27) |  |  | $ | (42) |  |  | $ | (32) |  |  | $ | (36) |  |  | $ | (20) |  |  | $ | (18) |  |  | $ | (19) |  |

[0000068505-21-000008:notes:220]
The status of the Company’s plans is as follows:

[0000068505-21-000008:notes:221]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 4,727 |  |  | $ | 4,864 |  |  | $ | 1,814 |  |  | $ | 1,654 |  |  | $ | 73 |  |  | $ | 72 |  |
| Service cost | — |  |  | — |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Interest cost | 144 |  |  | 202 |  |  | 29 |  |  | 36 |  |  | 2 |  |  | 3 |  |
| Plan amendments | — |  |  | — |  |  | 1 |  |  | (83) |  |  | — |  |  | — |  |
| Actuarial loss | 480 |  |  | 609 |  |  | 171 |  |  | 207 |  |  | 1 |  |  | 4 |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 88 |  |  | 44 |  |  | — |  |  | — |  |
| Benefit payments | (125) |  |  | (948) |  |  | (47) |  |  | (46) |  |  | (5) |  |  | (6) |  |
| Benefit obligation at December 31 | $ | 5,226 |  |  | $ | 4,727 |  |  | $ | 2,058 |  |  | $ | 1,814 |  |  | $ | 71 |  |  | $ | 73 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,601 |  |  | $ | 3,673 |  |  | $ | 1,641 |  |  | $ | 1,438 |  |  | $ | 160 |  |  | $ | 133 |  |
| Return on plan assets | 604 |  |  | 873 |  |  | 214 |  |  | 188 |  |  | 26 |  |  | 33 |  |
| Company contributions | 3 |  |  | 3 |  |  | 9 |  |  | 8 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 63 |  |  | 53 |  |  | — |  |  | — |  |
| Benefit payments | (125) |  |  | (948) |  |  | (47) |  |  | (46) |  |  | (5) |  |  | (6) |  |
| Fair value at December 31 | $ | 4,083 |  |  | $ | 3,601 |  |  | $ | 1,880 |  |  | $ | 1,641 |  |  | $ | 181 |  |  | $ | 160 |  |
| Funded status of the plan | $ | (1,143) |  |  | $ | (1,126) |  |  | $ | (178) |  |  | $ | (173) |  |  | $ | 110 |  |  | $ | 87 |  |
| Unrecognized net loss | 1,977 |  |  | 1,935 |  |  | 675 |  |  | 648 |  |  | 23 |  |  | 42 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (80) |  |  | (84) |  |  | (5) |  |  | (20) |  |
| Prepaid pension cost | $ | 834 |  |  | $ | 809 |  |  | $ | 417 |  |  | $ | 391 |  |  | $ | 128 |  |  | $ | 109 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3) |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (1,140) |  |  | (1,123) |  |  | (330) |  |  | (299) |  |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 152 |  |  | 126 |  |  | 110 |  |  | 87 |  |
| Deferred income taxes | 480 |  |  | 463 |  |  | 65 |  |  | 60 |  |  | 7 |  |  | 9 |  |
| Accumulated other comprehensive loss | 1,497 |  |  | 1,472 |  |  | 530 |  |  | 504 |  |  | 11 |  |  | 13 |  |
| Prepaid pension cost | $ | 834 |  |  | $ | 809 |  |  | $ | 417 |  |  | $ | 391 |  |  | $ | 128 |  |  | $ | 109 |  |

[0000068505-21-000008:notes:222]
For the year ended December 31, 2020, the primary driver of the increase in the U.S. Pension Benefit Plans benefit obligation was higher actuarial losses due to a decrease in the discount rate from 3.32% as of December 31, 2019 to 2.63% as of December 31, 2020. For the year ended December 31, 2019, the decrease in the U.S. Pension Benefit Plans benefit obligation was driven by the $948 million of benefit payments from the voluntary lump-sum election window offered to certain participants in 2019 which was partially offset by higher actuarial losses. The actuarial losses were primarily driven by the decrease in the discount rate from 4.47% as of December 31, 2018 to 3.32% as of December 31, 2019, partially offset by an actuarial gain from the voluntary lump-sum election offered to certain participants in 2019.

[0000068505-21-000008:notes:223]
For the year ended December 31, 2020, the most significant drivers of the increase in Non U.S. Pension Benefit Plan benefit obligation were the higher actuarial losses coupled with unfavorable foreign exchange effects. The Non U.S. Pension Benefit Plan incurred actuarial losses primarily due to decreases in the discount rates from 1.82% as of December 31, 2019 to 1.24% as of December 31, 2020. For the year ended December 31, 2019, the most significant drivers of the increase in the Non U.S. Pension Benefit Plan benefit obligation were higher actuarial losses, coupled with unfavorable foreign exchange effects, offset by a reduction of the projected benefit obligation of approximately $83 million related to prior service credits from a discretionary action on early retirement benefit reductions. The actuarial losses were driven by declines in the discount rate from 2.67% as of December 31, 2018 compared to 1.82% as of December 31, 2019.

[0000068505-21-000008:notes:224]
Actuarial Assumptions

[0000068505-21-000008:notes:225]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-21-000008:notes:226]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined pension benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-21-000008:notes:227]
The Company used "Mortality Improvement Scale MP-2018" to calculate the 2020 U.S. projected benefit obligations and the "Mortality Improvement Scale MP-2017" to calculate the 2019 U.S. projected benefit obligations.

[0000068505-21-000008:notes:228]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-21-000008:notes:229]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Discount rate | 3.10 | % |  | 4.25 | % |  | 1.61 | % |  | 2.37 | % |  | 2.66 | % |  | 3.85 | % |
| Investment return assumption | 6.85 | % |  | 6.85 | % |  | 4.66 | % |  | 5.23 | % |  | 6.90 | % |  | 6.90 | % |

[0000068505-21-000008:notes:230]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-21-000008:notes:231]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Discount rate | 2.63 | % |  | 3.32 | % |  | 1.24 | % |  | 1.82 | % |  | 2.39 | % |  | 3.15 | % |
| Future compensation increase rate | n/a |  | n/a |  | 0.43 | % |  | 0.52 | % |  | n/a |  | n/a |

[0000068505-21-000008:notes:232]
The following table presents the accumulated benefit obligation, projected benefit obligation and fair value of plan assets for our plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets:

[0000068505-21-000008:notes:233]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  |
| December 31 | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |
| Accumulated benefit obligation | $ | 5,226 |  |  | $ | 4,727 |  |  | $ | 2,055 |  |  | $ | 1,809 |  |  |  |  |
| Projected benefit obligation | 5,226 |  |  | 4,727 |  |  | 2,058 |  |  | 1,814 |  |  |  |  |
| Fair value of plan assets | 4,083 |  |  | 3,601 |  |  | 1,880 |  |  | 1,641 |  |  |  |  |

[0000068505-21-000008:notes:234]
Investment Policy

[0000068505-21-000008:notes:235]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-21-000008:notes:236]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-21-000008:notes:237]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 25 | % |  | 25 | % |  | 28 | % |  | 28 | % |
| Fixed income securities | 57 | % |  | 56 | % |  | 51 | % |  | 52 | % |
| Cash and other investments | 18 | % |  | 19 | % |  | 21 | % |  | 20 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 26 | % |  | 24 | % |  | 30 | % |  | 29 | % |
| Fixed income securities | 58 | % |  | 57 | % |  | 53 | % |  | 54 | % |
| Cash and other investments | 16 | % |  | 19 | % |  | 17 | % |  | 17 | % |

[0000068505-21-000008:notes:238]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-21-000008:notes:239]
Cash Funding

[0000068505-21-000008:notes:240]
The Company made $3 million of contributions to its U.S. Pension Benefit Plans during each of 2020 and 2019. The Company contributed $9 million and $8 million to its Non U.S. Pension Benefit Plans during 2020 and 2019, respectively. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2020 or 2019.

[0000068505-21-000008:notes:241]
Expected Future Benefit Payments

[0000068505-21-000008:notes:242]
The following benefit payments are expected to be paid:

[0000068505-21-000008:notes:243]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2021 | $ | 157 |  |  | $ | 51 |  |  | $ | 6 |  |
| 2022 | 176 |  |  | 52 |  |  | 6 |  |
| 2023 | 190 |  |  | 53 |  |  | 5 |  |
| 2024 | 205 |  |  | 55 |  |  | 5 |  |
| 2025 | 231 |  |  | 56 |  |  | 5 |  |
| 2026-2030 | 1,344 |  |  | 294 |  |  | 20 |  |

[0000068505-21-000008:notes:244]
Other Benefit Plans

[0000068505-21-000008:notes:245]
Split-Dollar Life Insurance Arrangements

[0000068505-21-000008:notes:246]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-21-000008:notes:247]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2020, 2019 and 2018. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $73 million and $67 million as of December 31, 2020 and December 31, 2019, respectively.

[0000068505-21-000008:notes:248]
Deferred Compensation Plan

[0000068505-21-000008:notes:249]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-21-000008:notes:250]
Defined Contribution Plan

[0000068505-21-000008:notes:251]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the Motorola Solutions 401(k) plan (the "401(k) plan") is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2020, 2019 and 2018 were $15 million, $32 million and $31 million, respectively.

[0000068505-21-000008:notes:252]
Due to the economic uncertainties caused by the COVID-19 pandemic, the Company took action in a number of areas to reduce its operating expenses, including by suspending all Company match contributions to the 401(k) plan for the period from May 15, 2020 through December 31, 2020.

[0000068505-21-000008:notes:253]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2020, 2019, and 2018 the Company made no discretionary contributions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-21-000008:notes:254]
Share-Based Compensation and Other Incentive Plans
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option and stock appreciation right granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-21-000008:notes:255]
Restricted stock (“RS”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees. The grants are restricted in such that they are subject to vesting conditions; however, restricted stock holders have voting rights, and the rights to earn dividends on unvested shares.

[0000068505-21-000008:notes:256]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-21-000008:notes:257]
Performance-based stock options (“performance options”), market stock units ("MSUs"), and performance stock units ("PSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years. PSUs have been granted as a portion of the Long Range Incentive Plan (“LRIP”) awards issued to certain Company executive officers. The PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual TSR compared to the S&P 500 over the three-year performance period.

[0000068505-21-000008:notes:258]
On August 25, 2015 and on March 9, 2017, the Company approved grants of performance-contingent stock options (“PCSOs”) to certain executive officers which were fully vested as of December 31, 2020. The August 25, 2015 awards have a seven-year term and a per share exercise price of $68.50. The March 9, 2017 awards have a five-and-a-half-year term and a per share exercise price of $81.37.

[0000068505-21-000008:notes:259]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended

[0000068505-21-000008:notes:260]
December 31, 2020, 2019 and 2018, employees purchased 0.7 million, 0.6 million and 0.8 million shares, respectively, at purchase prices of $112.98 and $107.18, $108.96 and $120.12, and $72.96 and $88.84, respectively.

[0000068505-21-000008:notes:261]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-21-000008:notes:262]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2020, 2019 and 2018 was $39.98, $29.14 and $23.31, respectively, using the following weighted-average assumptions:

[0000068505-21-000008:notes:263]
|  | 2020 |  | 2019 |  | 2018 |
| Expected volatility | 33.7 | % |  | 23.8 | % |  | 24.7 | % |
| Risk-free interest rate | 0.6 | % |  | 2.3 | % |  | 2.7 | % |
| Dividend yield | 2.7 | % |  | 2.5 | % |  | 2.4 | % |
| Expected life (years) | 5.9 |  | 6.0 |  | 5.9 |

[0000068505-21-000008:notes:264]
The Company calculates the value of each performance option, MSU, and PSU using a Monte Carlo simulation option pricing model, estimated on the date of grant. The fair values of performance options, MSUs, and PSUs granted during 2020 were $77.82, $112.17 and $233.96, respectively. The fair values of performance options, MSUs, and PSUs granted during 2019 were $46.15, $138.00 and $203.61, respectively. The fair value of performance options and MSUs granted during 2018 was $42.19 and $125.33, respectively. The following assumptions were used for the calculations.

[0000068505-21-000008:notes:265]
|  | 2020 |  | 2019 |  | 2018 |
|  | Performance Options |  | Performance Options |  | Performance Options |
| Expected volatility of common stock | 34.7 | % |  | 22.4 | % |  | 25.0 | % |
| Expected volatility of the S&P 500 | 29.0 | % |  | 25.1 | % |  | 25.3 | % |
| Risk-free interest rate | 0.8 | % |  | 2.3 | % |  | 2.7 | % |
| Dividend yield | 2.6 | % |  | 2.7 | % |  | 3.1 | % |
| Expected life (years) | 6.5 |  | 6.5 |  | 6.5 |

[0000068505-21-000008:notes:266]
|  | 2020 |  | 2019 |  | 2018 |
|  | Market Stock Unit |  | Market Stock Unit |  | Market Stock Units |
| Expected volatility of common stock | 34.7 | % |  | 22.4 | % |  | 25.0 | % |
| Risk-free interest rate | 0.6 | % |  | 2.2 | % |  | 2.4 | % |
| Dividend yield | 1.7 | % |  | 2.0 | % |  | 2.2 | % |

[0000068505-21-000008:notes:267]
|  | 2020 |  |  | 2019 |
|  | Performance Stock Units |  |  | Performance Stock Units |
| Expected volatility of common stock | 34.7 | % |  |  | 20.6 | % |
| Expected volatility of the S&P 500 | 29.0 | % |  |  | 25.0 | % |
| Risk-free interest rate | 0.6 | % |  |  | 2.2 | % |
| Dividend yield | 1.7 | % |  |  | 1.6 | % |

[0000068505-21-000008:notes:268]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PSUs. The selection of the implied volatility approach was based upon the availability of actively-traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. At the conclusion of each three-year PSU and performance option cycle, the Company uses the historical volatility as the expected volatility to calculate the actual TSR compared to the S&P 500.

[0000068505-21-000008:notes:269]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-21-000008:notes:270]
The Company has applied forfeiture rates, estimated based on historical data, of 10% to the stock option fair values calculated by the Black-Scholes option pricing model and 15% to RSUs. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-21-000008:notes:271]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, at December 31, 2020 (in thousands, except exercise price and years):

[0000068505-21-000008:notes:272]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| Under $50 | 520 |  |  | $ | 38 |  |  | 0 |  | 520 |  |  | $ | 38 |  |  | 0 |
| $51-$60 | 646 |  |  | 54 |  |  | 1 |  | 646 |  |  | 54 |  |  | 2 |
| $61-$70 | 1,372 |  |  | 68 |  |  | 1 |  | 1,372 |  |  | 68 |  |  | 2 |
| $71-$80 | 372 |  |  | 71 |  |  | 3 |  | 372 |  |  | 71 |  |  | 5 |
| $81-$90 | 505 |  |  | 82 |  |  | 6 |  | 502 |  |  | 82 |  |  | 6 |
| $91-$100 | 6 |  |  | 93 |  |  | 6 |  | 6 |  |  | 93 |  |  | 6 |
| $101 and over | 979 |  |  | 134 |  |  | 8 |  | 164 |  |  | 126 |  |  | 8 |
|  | 4,400 |  |  |  |  |  |  | 3,582 |  |  |  |  |  |

[0000068505-21-000008:notes:273]
As of December 31, 2020, the weighted average contractual life for options outstanding and exercisable was four and three years, respectively.

[0000068505-21-000008:notes:274]
Current Year Activity

[0000068505-21-000008:notes:275]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-21-000008:notes:276]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2020 | 2,983 |  |  | $ | 63 |  |  | 1,047 |  |  | $ | 111 |  |  | 440 |  |  | $ | 119 |  |
| Granted | 167 |  |  | 153 |  |  | 510 |  |  | 144 |  |  | 51 |  |  | 171 |  |
| Releases/Exercised | (890) |  |  | 51 |  |  | (489) |  |  | 103 |  |  | (366) |  |  | 122 |  |
| Forfeited/Canceled | (20) |  |  | 129 |  |  | (81) |  |  | 134 |  |  | — |  |  | — |  |
| Balance as of December 31, 2020 | 2,240 |  |  | $ | 74 |  |  | 987 |  |  | $ | 138 |  |  | 125 |  |  | $ | 132 |  |
| Awards exercisable | 1,845 |  |  | 60 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-21-000008:notes:277]
|  | Performance Options* |  | Market Stock Units |  | Performance Stock Units |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2020 | 2,168 |  |  | $ | 78 |  |  | 112 |  |  | $ | 123 |  |  | 27 |  |  | $ | 204 |  |
| Granted | 111 |  |  | 155 |  |  | 79 |  |  | 112 |  |  | 87 |  |  | 234 |  |
| Releases/Exercised | (491) |  |  | 75 |  |  | (94) |  |  | 114 |  |  | (59) |  |  | 184 |  |
| Adjustment for payout factor | 376 |  |  | 81 |  |  | 35 |  |  | 90 |  |  | — |  |  | — |  |
| Forfeited/Canceled | (4) |  |  | 139 |  |  | (1) |  |  | 94 |  |  | — |  |  | 204 |  |
| Balance as of December 31, 2020 | 2,160 |  |  | $ | 84 |  |  | 131 |  |  | $ | 121 |  |  | 55 |  |  | $ | 219 |  |
| Awards exercisable | 1,737 |  |  | 72 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-21-000008:notes:278]
* Inclusive of PCSO awards

[0000068505-21-000008:notes:279]
At December 31, 2020 and 2019, 5.9 million and 7.2 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-21-000008:notes:280]
Total Share-Based Compensation Expense

[0000068505-21-000008:notes:281]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-21-000008:notes:282]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 16 |  |  | $ | 14 |  |  | $ | 11 |  |
| Selling, general and administrative expenses | 73 |  |  | 62 |  |  | 45 |  |
| Research and development expenditures | 40 |  |  | 42 |  |  | 17 |  |
| Share-based compensation expense included in Operating earnings | 129 |  |  | 118 |  |  | 73 |  |
| Tax benefit | 30 |  |  | 22 |  |  | 18 |  |
| Share-based compensation expense, net of tax | $ | 99 |  |  | $ | 96 |  |  | $ | 55 |  |
| Decrease in basic earnings per share | $ | (0.58) |  |  | $ | (0.57) |  |  | $ | (0.34) |  |
| Decrease in diluted earnings per share | $ | (0.57) |  |  | $ | (0.55) |  |  | $ | (0.32) |  |

[0000068505-21-000008:notes:283]
At December 31, 2020, the Company had unrecognized compensation expense related to all share based awards of $109 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately three years and $5 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. The aggregate fair value of outstanding share based awards as of December 31, 2020 was $251 million.

[0000068505-21-000008:notes:284]
Cash received from stock option exercises and the employee stock purchase plan was $108 million, $114 million, and $168 million for the years ended December 31, 2020, 2019, and 2018, respectively. The total intrinsic value of options exercised during the years ended December 31, 2020, 2019, and 2018 was $149 million, $113 million, and $125 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2020 was $388 million and $362 million, respectively, based on a December 31, 2020 stock price of $166.98 per share.

[0000068505-21-000008:notes:285]
Motorola Solutions Incentive Plans

[0000068505-21-000008:notes:286]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2020, 2019 and 2018 was $78 million, $146 million and $143 million, respectively.

[0000068505-21-000008:notes:287]
Long-Range Incentive Plan

[0000068505-21-000008:notes:288]
The LRIP rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. The expense for LRIP for the years ended December 31, 2020, 2019 and 2018 was $9 million, $21 million and $31 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-21-000008:notes:289]
Fair Value Measurements
Investments and Derivatives

[0000068505-21-000008:notes:290]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2020 and December 31, 2019 were as follows:

[0000068505-21-000008:notes:291]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 14 |  |  |  |  | $ | 14 |  |
| Common stock and equivalents | 19 |  |  | — |  |  |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  |  |  | $ | 8 |  |

[0000068505-21-000008:notes:292]
| December 31, 2019 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  |  |  | $ | 4 |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Common stock and equivalents | 25 |  |  | — |  |  |  |  | 25 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  |  |  | $ | 5 |  |

[0000068505-21-000008:notes:293]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-21-000008:notes:294]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2020 and 2019 were as follows:

[0000068505-21-000008:notes:295]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 45 |  |  | $ | — |  |  |  |  | $ | 45 |  |
| Commingled funds | 1,603 |  |  | 463 |  |  |  |  | 2,066 |  |
| Government fixed income securities | — |  |  | 516 |  |  |  |  | 516 |  |
| Corporate fixed income securities | — |  |  | 1,070 |  |  |  |  | 1,070 |  |
| Short-term investment funds | 327 |  |  | — |  |  |  |  | 327 |  |
| Total investment securities | $ | 1,975 |  |  | $ | 2,049 |  |  |  |  | $ | 4,024 |  |
| Accrued income receivable |  |  |  |  |  |  | 44 |  |
| Cash |  |  |  |  |  |  | 15 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 4,083 |  |

[0000068505-21-000008:notes:296]
| December 31, 2019 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 12 |  |  | $ | — |  |  |  |  | $ | 12 |  |
| Commingled funds | 1,320 |  |  | 555 |  |  |  |  | 1,875 |  |
| Government fixed income securities | — |  |  | 529 |  |  |  |  | 529 |  |
| Corporate fixed income securities | — |  |  | 959 |  |  |  |  | 959 |  |
| Short-term investment funds | 179 |  |  | — |  |  |  |  | 179 |  |
| Total investment securities | $ | 1,511 |  |  | $ | 2,043 |  |  |  |  | $ | 3,554 |  |
| Accrued income receivable |  |  |  |  |  |  | 20 |  |
| Cash |  |  |  |  |  |  | 27 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 3,601 |  |

[0000068505-21-000008:notes:297]
Non-U.S. Pension Benefit Plans

[0000068505-21-000008:notes:298]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 78 |  |  | $ | — |  |  |  |  | $ | 78 |  |
| Commingled funds | 458 |  |  | 71 |  |  |  |  | 529 |  |
| Government fixed income securities | — |  |  | 1,076 |  |  |  |  | 1,076 |  |
| Short-term investment funds | 106 |  |  | — |  |  |  |  | 106 |  |
| Total investment securities | $ | 642 |  |  | $ | 1,147 |  |  |  |  | $ | 1,789 |  |
| Cash |  |  |  |  |  |  | 7 |  |
| Accrued income receivable |  |  |  |  |  |  | 30 |  |
| Insurance contracts |  |  |  |  |  |  | 54 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,880 |  |

[0000068505-21-000008:notes:299]
| December 31, 2019 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 69 |  |  | $ | — |  |  |  |  | $ | 69 |  |
| Commingled funds | 217 |  |  | 181 |  |  |  |  | 398 |  |
| Government fixed income securities | 4 |  |  | 899 |  |  |  |  | 903 |  |
| Short-term investment funds | 170 |  |  | — |  |  |  |  | 170 |  |
| Total investment securities | $ | 460 |  |  | $ | 1,080 |  |  |  |  | $ | 1,540 |  |
| Cash |  |  |  |  |  |  | 4 |  |
| Accrued income receivable |  |  |  |  |  |  | 48 |  |
| Insurance contracts |  |  |  |  |  |  | 49 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,641 |  |

[0000068505-21-000008:notes:300]
| December 31, 2020 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 2 |  |  | $ | — |  |  |  |  | $ | 2 |  |
| Commingled funds | 71 |  |  | 20 |  |  |  |  | 91 |  |
| Government fixed income securities | — |  |  | 23 |  |  |  |  | 23 |  |
| Corporate fixed income securities | — |  |  | 48 |  |  |  |  | 48 |  |
| Short-term investment funds | 15 |  |  | — |  |  |  |  | 15 |  |
| Total investment securities | $ | 88 |  |  | $ | 91 |  |  |  |  | $ | 179 |  |
| Accrued income receivable |  |  |  |  |  |  | $ | 2 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 181 |  |

[0000068505-21-000008:notes:301]
| December 31, 2019 | Level 1 |  | Level 2 |  |  |  | Total |
| Commingled funds | 59 |  |  | 25 |  |  |  |  | 84 |  |
| Government fixed income securities | — |  |  | 24 |  |  |  |  | 24 |  |
| Corporate fixed income securities | — |  |  | 43 |  |  |  |  | 43 |  |
| Short-term investment funds | 8 |  |  | — |  |  |  |  | 8 |  |
| Total investment securities | $ | 67 |  |  | $ | 92 |  |  |  |  | $ | 159 |  |
| Cash |  |  |  |  |  |  | 1 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 160 |  |

[0000068505-21-000008:notes:302]
The following is a description of the categories of investments:

[0000068505-21-000008:notes:303]
Equities — A diversified portfolio of corporate common and preferred stocks.

[0000068505-21-000008:notes:304]
Commingled funds — A diversified portfolio of assets that includes corporate common and preferred stocks, emerging market and high-yield fixed income securities among others.

[0000068505-21-000008:notes:305]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-21-000008:notes:306]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-21-000008:notes:307]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-21-000008:notes:308]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-21-000008:notes:309]
At December 31, 2020, the Company had $448 million of investments in money market government and U.S. treasury funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $322 million at December 31, 2019. The money market funds had quoted market prices that are approximately at par.

[0000068505-21-000008:notes:310]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2020 was $5.8 billion (Level 2), compared to a face value of $5.2 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-21-000008:notes:311]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-21-000008:notes:312]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-21-000008:notes:313]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-21-000008:notes:314]
| December 31 | 2020 |  | 2019 |
| Long-term receivables, gross | $ | 76 |  |  | $ | 62 |  |
| Less allowance for losses | (3) |  |  | (2) |  |
| Long-term receivables | $ | 73 |  |  | $ | 60 |  |
| Less current portion | (19) |  |  | (19) |  |
| Non-current long-term receivables | $ | 54 |  |  | $ | 41 |  |

[0000068505-21-000008:notes:315]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized interest income on long-term receivables of $1 million for each of the years ended December 31, 2020, 2019 and 2018.

[0000068505-21-000008:notes:316]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $78 million at December 31, 2020 and December 31, 2019.

[0000068505-21-000008:notes:317]
Sales of Receivables

[0000068505-21-000008:notes:318]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements.

[0000068505-21-000008:notes:319]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2020, 2019 and 2018.

[0000068505-21-000008:notes:320]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| Contract-specific discounting facility | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Accounts receivable sales proceeds | 74 |  |  | 34 |  |  | 77 |  |
| Long-term receivables sales proceeds | 181 |  |  | 265 |  |  | 270 |  |
| Total proceeds from receivable sales | $ | 483 |  |  | $ | 299 |  |  | $ | 347 |  |

[0000068505-21-000008:notes:321]
The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-21-000008:notes:322]
At December 31, 2020, the Company had retained servicing obligations for $983 million of long-term receivables, compared to $984 million of long-term receivables at December 31, 2019. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-21-000008:notes:323]
During the year ended December 31, 2020, we utilized a new cost-efficient receivable discounting facility to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe resulting in accounts receivable sales of $228 million during the year ended December 31, 2020. The net benefit to our operating cash flow from the utilization of the new receivable discounting facility during 2020 was an inflow of $61 million when adjusted for amounts that would still be collected from the customer within the period in the absence of utilizing the discounting facility. The proceeds of our receivable sales are included in "Operating Activities" within our Consolidated Statements of Cash Flows.

[0000068505-21-000008:notes:324]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-21-000008:notes:325]
An aging analysis of financing receivables at December 31, 2020 and December 31, 2019 is as follows:

[0000068505-21-000008:notes:326]
| December 31, 2020 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 50 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 26 |  |  | 2 |  |  | 1 |  |  | 4 |  |
| Long-term receivables, including current portion | $ | 76 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 4 |  |

[0000068505-21-000008:notes:327]
| December 31, 2019 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 31 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |
| Commercial loans and leases secured | 31 |  |  | 3 |  |  | — |  |  | 5 |  |
| Long-term receivables, including current portion | $ | 62 |  |  | $ | 4 |  |  | $ | 1 |  |  | $ | 5 |  |

[0000068505-21-000008:notes:328]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-21-000008:notes:329]
Commitments and Contingencies
Purchase Obligations

[0000068505-21-000008:notes:330]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow it to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancellable.

[0000068505-21-000008:notes:331]
As of December 31, 2020, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2025. The Company expects to make total payments of $209 million under these arrangements as follows: $50 million in 2021, $52 million in 2022, $50 million in 2023, $51 million in 2022, and $6 million in 2025.

[0000068505-21-000008:notes:332]
The Company outsources certain corporate functions, such as benefit administration and information technology-related services, under various contracts, the longest of which is expected to expire in 2023. The remaining payments under these contracts are approximately $41 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-21-000008:notes:333]
Legal Matters

[0000068505-21-000008:notes:334]
On February 14, 2020, the Company announced that a jury in the U.S. District Court for the Northern District of Illinois (the "Court") decided in the Company's favor in its trade secret theft and copyright infringement case against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”). In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. The royalty rate is yet to be determined, and will be set by the Court absent agreement of the parties.

[0000068505-21-000008:notes:335]
On January 11, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest, although the precise amount of interest owed to the Company by Hytera is still to be determined by the Court. Other post-trial motions are fully briefed and awaiting ruling, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in May 2020; the Company previously filed motions to dismiss the bankruptcy proceedings in July 2020.

[0000068505-21-000008:notes:336]
On January 22, 2021, the U.S. Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.

[0000068505-21-000008:notes:337]
Indemnifications

[0000068505-21-000008:notes:338]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.
The Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-21-000008:notes:339]
Information by Segment and Geographic Region
The Company conducts its business globally and manages it through the following two segments:

[0000068505-21-000008:notes:340]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security devices and infrastructure, and the implementation and integration of such systems, devices, and applications. Within LMR Mission Critical Communications, the Company is a global leader in the two-way radio category, including the Company’s Project 25 ("P25"), Terrestrial Trunked Radio ("TETRA"), Digital Mobile Radio ("DMR)", as well as other professional and commercial radio (“PCR”) solutions. The Company provides LTE solutions for public safety, government and commercial users, including infrastructure and devices operating in 700 MHz, 900 MHz and Citizens' Broadband Radio Service ("CBRS") frequencies. The Company's Video Security and Analytics technology includes network video management infrastructure, fixed security and mobile video cameras (body-worn and in-vehicle) and access control solutions. The primary customers of the Products and Systems Integration segment are government, public safety and commercial customers who operate private communications networks and video security solutions and typically manage a mobile workforce. In 2020, the segment’s net sales were $4.6 billion, representing 63% of the Company's consolidated net sales.

[0000068505-21-000008:notes:341]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and commercial customers. Software includes public safety and enterprise Command Center Software, unified communications applications, and video software solutions, delivered both on-premise and “as a service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced technologies include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer-owned or Motorola Solutions-owned networks. In 2020, the segment’s net sales were $2.8 billion, representing 37% of the Company's consolidated net sales.

[0000068505-21-000008:notes:342]
For the years ended December 31, 2020, 2019 and 2018, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-21-000008:notes:343]
Segment Information

[0000068505-21-000008:notes:344]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-21-000008:notes:345]
|  | Net Sales |  | Operating Earnings |
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Products and Systems Integration | $ | 4,634 |  |  | $ | 5,329 |  |  | $ | 5,100 |  |  | $ | 656 |  |  | $ | 994 |  |  | $ | 854 |  |
| Software and Services | 2,780 |  |  | 2,558 |  |  | 2,243 |  |  | 727 |  |  | 587 |  |  | 401 |  |
|  | $ | 7,414 |  |  | $ | 7,887 |  |  | $ | 7,343 |  |  | $ | 1,383 |  |  | $ | 1,581 |  |  | $ | 1,255 |  |
| Total other expense |  |  |  |  |  |  | (209) |  |  | (580) |  |  | (153) |  |
| Net earnings before income taxes |  |  |  |  |  |  | $ | 1,174 |  |  | $ | 1,001 |  |  | $ | 1,102 |  |

[0000068505-21-000008:notes:346]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-21-000008:notes:347]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Products and Systems Integration | $ | 91 |  |  | $ | 98 |  |  | $ | 72 |  |  | $ | 90 |  |  | $ | 82 |  |  | $ | 71 |  |
| Software and Services | 126 |  |  | 150 |  |  | 125 |  |  | 104 |  |  | 104 |  |  | 101 |  |
|  | $ | 217 |  |  | $ | 248 |  |  | $ | 197 |  |  | $ | 194 |  |  | $ | 186 |  |  | $ | 172 |  |

[0000068505-21-000008:notes:348]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-21-000008:notes:349]
Geographic Area Information

[0000068505-21-000008:notes:350]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| United States | $ | 4,770 |  |  | $ | 5,006 |  |  | $ | 4,361 |  |  | $ | 7,009 |  |  | $ | 6,749 |  |  | $ | 5,441 |  |
| United Kingdom | 740 |  |  | 692 |  |  | 638 |  |  | 2,460 |  |  | 2,460 |  |  | 2,284 |  |
| Canada | 254 |  |  | 270 |  |  | 303 |  |  | 1,016 |  |  | 1,040 |  |  | 1,014 |  |
| Other, net of eliminations | 1,650 |  |  | 1,919 |  |  | 2,041 |  |  | 391 |  |  | 393 |  |  | 670 |  |
|  | $ | 7,414 |  |  | $ | 7,887 |  |  | $ | 7,343 |  |  | $ | 10,876 |  |  | $ | 10,642 |  |  | $ | 9,409 |  |

[0000068505-21-000008:notes:351]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-21-000008:notes:352]
Reorganization of Businesses
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-21-000008:notes:353]
During 2020, 2019, and 2018 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. During 2020, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States. Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at nine months of salary, were equalized for all employment level grades and capped at a full year’s salary for the voluntary applicants. During 2018, the Company communicated its plan to close one of its manufacturing facilities in Europe resulting in a charge of $44 million and impacting 165 employees, primarily within the Products and Systems Integration segment. The remainder of the initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-21-000008:notes:354]
2020 Charges

[0000068505-21-000008:notes:355]
During 2020, the Company recorded net reorganization of business charges of $86 million, including $29 million of charges in Costs of sales and $57 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $86 million were charges of $100 million for employee separation costs, $2 million for exit costs, partially offset by $16 million of reversals of accruals no longer needed.

[0000068505-21-000008:notes:356]
The following table displays the net charges incurred by segment:

[0000068505-21-000008:notes:357]
| Year ended December 31 | 2020 |
| Products and Systems Integration | $ | 69 |  |
| Software and Services | 17 |  |
|  | $ | 86 |  |

[0000068505-21-000008:notes:358]
Reorganization of Businesses Accruals

[0000068505-21-000008:notes:359]
| Accruals atJanuary 1, 2020 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31, 2020 |
| $ | 78 |  |  | $ | 102 |  |  | $ | (16) |  |  | $ | (85) |  |  | $ | 79 |  |

[0000068505-21-000008:notes:360]
Employee Separation Costs

[0000068505-21-000008:notes:361]
At January 1, 2020, the Company had an accrual of $78 million for employee separation costs. The 2020 additional charges of $102 million include severance costs for approximately 1,200 employees, of which 800 were direct employees and 400 were indirect employees. The adjustments of $16 million reflect reversals of accruals no longer needed. The $85 million used in 2020 reflects cash payments to severed employees. The remaining accrual of $79 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2020, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 100 employees to be separated in 2021.

[0000068505-21-000008:notes:362]
2019 Charges

[0000068505-21-000008:notes:363]
During 2019, the Company recorded net reorganization of business charges of $57 million, including $17 million of charges in Costs of sales and $40 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $57 million were charges of $64 million for employee separation costs and $5 million for exit costs, partially offset by $12 million of reversals of accruals no longer needed.

[0000068505-21-000008:notes:364]
| Year ended December 31 | 2019 |
| Products and Systems Integration | $ | 45 |  |
| Software and Services | 12 |  |
|  | $ | 57 |  |

[0000068505-21-000008:notes:365]
| Accruals atJanuary 1, 2019 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31, 2019 |
| $ | 84 |  |  | $ | 69 |  |  | $ | (12) |  |  | $ | (63) |  |  | $ | 78 |  |

[0000068505-21-000008:notes:366]
At January 1, 2019, the Company had an accrual of $84 million for employee separation costs. The additional 2019 charges of $69 million represent severance costs for approximately an additional 700 employees, of which 200 were direct employees and 500 were indirect employees. The adjustments of $12 million reflect reversals of accruals no longer needed. The $63 million used in 2019 reflects cash payments to severed employees. The remaining accrual of $78 million was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2019.

[0000068505-21-000008:notes:367]
2018 Charges

[0000068505-21-000008:notes:368]
During 2018, the Company recorded net reorganization of business charges of $120 million, including $59 million of charges in Costs of sales and $61 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $120 million are charges of $122 million for employee separation costs and $16 million of charges for exit costs, partially offset by $18 million of reversals for accruals no longer needed.

[0000068505-21-000008:notes:369]
| Year ended December 31 | 2018 |
| Products and Systems integration | $ | 101 |  |
| Software and Services | 19 |  |
|  | $ | 120 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-21-000008:notes:370]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-21-000008:notes:371]
Recent Acquisitions

[0000068505-21-000008:notes:372]
On August 28, 2020, the Company acquired Callyo, a cloud-based mobile applications provider for law enforcement in North America for $63 million, inclusive of share-based compensation withheld at a fair value of $3 million that will be expensed over an average service period of two years. The acquisition was settled with $61 million in cash, net of cash acquired. This acquisition adds to Motorola Solutions’ existing Command Center Software suite critical mobile technology capabilities that enable information to flow seamlessly from the field to the command center. The Company recognized $38 million of goodwill, $31 million of identifiable intangible assets, and $8 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $27 million of customer relationships and $4 million of developed technology that will be amortized over a period of fourteen and seven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000008:notes:373]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $108 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in Video Security and Analytics, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $42 million of goodwill, $30 million of identifiable intangible assets, and $36 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000008:notes:374]
On June 16, 2020, the Company acquired IndigoVision for a purchase price of $37 million. The acquisition was settled with $35 million of cash, net of cash acquired and debt assumed. The acquisition complements the Company's Video Security and Analytics technology, providing enhanced geographical reach across a wider customer base. The Company recognized $14 million of goodwill, $22 million of identifiable intangible assets, and $1 million of net liabilities.  The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $22 million of customer relationships that will be amortized over a period of eleven years. The business is a part of both the Products and Systems Integration and Software and Services segments. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000008:notes:375]
On April 30, 2020, the Company acquired a cybersecurity services business for a purchase price of $32 million of cash, net of cash acquired. The Company recognized $23 million of goodwill, $10 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $8 million of customer relationships and $2 million of developed technology that will be amortized over a period of twelve years and three years, respectively. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, and managed services including security monitoring of network operations. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000008:notes:376]
On March 3, 2020, the Company acquired a cybersecurity services business for $40 million, inclusive of share-based compensation withheld at a fair value of $6 million that will be expensed over a service period of two years. The acquisition was settled with $33 million of cash, net of cash acquired. The Company recognized $28 million of goodwill, $7 million of intangible assets and $2 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset of $7 million was classified as a customer relationship that will be amortized over a period of thirteen years. The acquisition expands the Company’s ability to assist customers with cybersecurity needs through vulnerability assessments, cybersecurity consulting, managed services and remediation and response capabilities. The business is a part of the Software and Services segment. The purchase accounting is not yet complete and as such the final allocation between income tax accounts and goodwill may be subject to change.

[0000068505-21-000008:notes:377]
On October 16, 2019, the Company acquired a data solutions business for vehicle location information for a purchase price of $85 million in cash, net of cash acquired. The acquisition enhances the Company's Video Security and Analytics technology by adding data to the Company’s existing LPR database within the Software and Services segment. The Company recognized $54 million of goodwill, $28 million of identifiable intangible assets, and $3 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $22 million of customer relationships and $6 million of developed technology and will be amortized over a period of sixteen years and five years, respectively. The purchase accounting was completed as of the fourth quarter of 2020.

[0000068505-21-000008:notes:378]
On July 11, 2019, the Company acquired WatchGuard, a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's Video Security and Analytics technology. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $156 million of goodwill, $63 million of identifiable intangible assets, and $31 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $33 million of customer relationships and $30 million of completed technology that will be amortized over a period of thirteen years and seven years, respectively. The purchase accounting was completed as of the third quarter of 2020.

[0000068505-21-000008:notes:379]
On March 11, 2019, the Company acquired Avtec, a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of fifteen years. The purchase accounting was completed as of the third quarter of 2019.

[0000068505-21-000008:notes:380]
On January 7, 2019, the Company announced that it acquired VaaS, a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business is part of both the Products and Systems Integration and Software and Services segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of fifteen years. The purchase accounting was completed as of the first quarter of 2020.

[0000068505-21-000008:notes:381]
On March 28, 2018, the Company completed the acquisition of Avigilon, a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions. The business is part of both the Products and Systems Integration segment and the Software and Services segment. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. The Company recognized $498 million of identifiable intangible assets, $434 million of goodwill, and $42 million of net assets. Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to twenty years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them. The goodwill is not deductible for tax purposes.

[0000068505-21-000008:notes:382]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million, net of cash acquired. This acquisition expands the Company's Command Center Software technology with additional solutions for next generation 9-1-1. The business is part of the Software and Services segment. As of December 31, 2018, the Company recognized $151 million of goodwill, $80 million of identifiable intangible assets and $6 million of net assets. During 2019, the Company recorded an adjustment related to the allocation between goodwill and deferred income taxes of approximately $9 million, bringing the total goodwill acquired to $160 million. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of ten to twenty years.

[0000068505-21-000008:notes:383]
The results of operations for these acquisitions have been included in the Company’s Consolidated Statements of Operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-21-000008:notes:384]
Intangible Assets

[0000068505-21-000008:notes:385]
Amortized intangible assets are comprised of the following:

[0000068505-21-000008:notes:386]
|  | 2020 |  | 2019 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 766 |  |  | $ | 210 |  |  | $ | 738 |  |  | $ | 148 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,335 |  |  | 685 |  |  | 1,222 |  |  | 518 |  |
| Other intangibles | 78 |  |  | 50 |  |  | 75 |  |  | 42 |  |
|  | $ | 2,181 |  |  | $ | 947 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-21-000008:notes:387]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $215 million, $208 million, and $188 million for the years ended December 31, 2020, 2019, and 2018, respectively. As of December 31, 2020, future amortization expense is estimated to be $209 million in 2021, $206 million in 2022, $108 million in 2023, $83 million in 2024, and $73 million in 2025.

[0000068505-21-000008:notes:388]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-21-000008:notes:389]
|  | 2020 |  | 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 692 |  |  | $ | 129 |  |  | $ | 652 |  |  | $ | 82 |  |
| Software and Services | 1,489 |  |  | 818 |  |  | 1,385 |  |  | 628 |  |
|  | $ | 2,181 |  |  | $ | 947 |  |  | $ | 2,037 |  |  | $ | 710 |  |

[0000068505-21-000008:notes:390]
Goodwill

[0000068505-21-000008:notes:391]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2019 to December 31, 2020:

[0000068505-21-000008:notes:392]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2019 | $ | 722 |  |  | $ | 792 |  |  | $ | 1,514 |  |
| Goodwill acquired | 251 |  |  | 288 |  |  | 539 |  |
| Purchase accounting adjustments | — |  |  | 9 |  |  | 9 |  |
| Foreign currency translation | — |  |  | 5 |  |  | 5 |  |
| Balance as of December 31, 2019 | $ | 973 |  |  | $ | 1,094 |  |  | $ | 2,067 |  |
| Goodwill acquired | 46 |  |  | 100 |  |  | 146 |  |
| Foreign currency translation | — |  |  | 6 |  |  | 6 |  |
| Balance as of December 31, 2020 | $ | 1,019 |  |  | $ | 1,200 |  |  | $ | 2,219 |  |

[0000068505-21-000008:notes:393]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level which is an operating segment or one level below an operating segment.
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2020, 2019, and 2018. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2020, 2019, and 2018, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, a quantitative goodwill impairment test was not required and there was no impairment of goodwill.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-21-000008:notes:394]
Valuation and Qualifying Accounts
The following table presents the valuation and qualifying account activity for the years ended December 31, 2020, 2019, and 2018:

[0000068505-21-000008:notes:395]
|  | Balance atBeginning of Period |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atEnd of Period |
| 2020 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | $ | 63 |  |  | $ | 47 |  |  | $ | (34) |  |  | $ | (1) |  |  | $ | 75 |  |
| 2019 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 51 |  |  | 39 |  |  | (26) |  |  | (1) |  |  | 63 |  |
| 2018 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 45 |  |  | 37 |  |  | (30) |  |  | (1) |  |  | 51 |  |

[0000068505-21-000008:notes:396]
* Adjustments include translation adjustments


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-21-000008:notes:397]
Quarterly and Other Financial Data (unaudited)

[0000068505-21-000008:notes:398]
|  | Quarter Ended |
|  | 2020 |  | 2019 |
|  | Mar. 28, 2020 |  | June 27, 2020 |  | Sept. 26, 2020 |  | Dec. 31, 2020 |  | Mar. 30, 2019 |  | June 29, 2019 |  | Sept. 28, 2019 |  | Dec. 31, 2019 |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,655 |  |  | $ | 1,618 |  |  | $ | 1,868 |  |  | $ | 2,273 |  |  | $ | 1,657 |  |  | $ | 1,860 |  |  | $ | 1,994 |  |  | $ | 2,377 |  |
| Costs of sales | 868 |  |  | 852 |  |  | 959 |  |  | 1,127 |  |  | 884 |  |  | 929 |  |  | 987 |  |  | 1,157 |  |
| Gross margin | $ | 787 |  |  | $ | 766 |  |  | $ | 909 |  |  | $ | 1,146 |  |  | $ | 773 |  |  | $ | 931 |  |  | $ | 1,007 |  |  | $ | 1,220 |  |
| Selling, general and administrative expenses | 341 |  |  | 297 |  |  | 313 |  |  | 343 |  |  | 327 |  |  | 351 |  |  | 359 |  |  | 368 |  |
| Research and development expenditures | 168 |  |  | 161 |  |  | 175 |  |  | 182 |  |  | 162 |  |  | 170 |  |  | 172 |  |  | 182 |  |
| Other charges | 19 |  |  | 90 |  |  | 69 |  |  | 66 |  |  | 55 |  |  | 61 |  |  | 63 |  |  | 80 |  |
| Operating earnings | $ | 259 |  |  | $ | 218 |  |  | $ | 352 |  |  | $ | 555 |  |  | $ | 229 |  |  | $ | 349 |  |  | $ | 413 |  |  | $ | 590 |  |
| Net earnings* | 197 |  |  | 135 |  |  | 205 |  |  | 412 |  |  | 151 |  |  | 207 |  |  | 267 |  |  | 244 |  |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 1.15 |  |  | $ | 0.79 |  |  | $ | 1.21 |  |  | $ | 2.43 |  |  | $ | 0.92 |  |  | $ | 1.25 |  |  | $ | 1.60 |  |  | $ | 1.43 |  |
| Diluted earnings per common share | 1.12 |  |  | 0.78 |  |  | 1.18 |  |  | 2.37 |  |  | 0.86 |  |  | 1.18 |  |  | 1.51 |  |  | 1.39 |  |
| Dividends declared | $ | 0.64 |  |  | $ | 0.64 |  |  | $ | 0.64 |  |  | $ | 0.71 |  |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 0.64 |  |
| Dividends paid | 0.64 |  |  | 0.64 |  |  | 0.64 |  |  | 0.64 |  |  | 0.57 |  |  | 0.57 |  |  | 0.57 |  |  | 0.57 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 187.49 |  |  | $ | 159.76 |  |  | $ | 158.99 |  |  | $ | 176.92 |  |  | $ | 144.94 |  |  | $ | 169.30 |  |  | $ | 182.28 |  |  | $ | 176.95 |  |
| Low | $ | 120.77 |  |  | $ | 123.56 |  |  | $ | 127.58 |  |  | $ | 153.70 |  |  | $ | 110.61 |  |  | $ | 139.21 |  |  | $ | 160.81 |  |  | $ | 154.02 |  |

[0000068505-21-000008:notes:399]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.
