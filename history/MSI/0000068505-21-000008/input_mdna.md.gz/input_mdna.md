# MSI MD&A — 0000068505-21-000008


## mdna

[0000068505-21-000008:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-21-000008:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2020 and 2019 and results of operations for each of the three years in the period ended December 31, 2020. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-21-000008:mdna:3]
Executive Overview

[0000068505-21-000008:mdna:4]
Our Business

[0000068505-21-000008:mdna:5]
Motorola Solutions is a global leader in mission critical communications and analytics. Our technologies in Land Mobile Radio Mission Critical Communications ("LMR" or "LMR Mission Critical Communications"), Command Center Software and Video Security and Analytics, bolstered by managed and support services, make communities safer and help businesses stay productive and secure. We serve more than 100,000 public safety and commercial customers in over 100 countries, providing “purpose-built” solutions designed for their unique needs, and we have a rich heritage of innovation focusing on advancing global safety for more than 90 years.

[0000068505-21-000008:mdna:6]
We manage our business organizationally through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, the Company has principal product lines that also follow our three major technologies: LMR Mission Critical Communications, Command Center Software, and Video Security and Analytics.

[0000068505-21-000008:mdna:7]
The Company has invested across these three technologies, evolving the Company’s LMR focus to purposefully integrate software, video security and analytics solutions for public safety and enterprise customers globally.

[0000068505-21-000008:mdna:8]
Our strategy is to generate value through the integration of each technology into our ecosystem, uniting voice, software, video and analytics to interoperate. While each technology individually strives to make users safer and more productive, we believe we can enable better outcomes between individuals, businesses and agencies united as one connected system. With our interplay of technologies, our goal is to help remove silos between systems, unify data, streamline workflows, simplify management and support evolving technologies. Examples of such interplay include sharing video feeds from a school to a police command center and officers’ devices in the field to improve situational awareness, uploading field reports or crime scene photos directly into an agency’s evidence system to save administration time, and connecting teams across networks to ensure messages are easily shared and teams can work as one. Our goal is to integrate technologies according to customers’ desired operational outcomes so they can work faster, smarter and more safely. Across all three technologies, we offer cloud-based solutions, cybersecurity services and managed and support services.

[0000068505-21-000008:mdna:9]
The principal products within each segment, by technology, are described below:

[0000068505-21-000008:mdna:10]
Products and Systems Integration Segment

[0000068505-21-000008:mdna:11]
In 2020, the segment’s net sales were $4.6 billion, representing 63% of our consolidated net sales.

[0000068505-21-000008:mdna:12]
LMR Mission Critical Communications

[0000068505-21-000008:mdna:13]
Our LMR Mission Critical Communications technology includes infrastructure and devices for LMR, public safety Long Term Evolution (“LTE”) and enterprise-grade private LTE. We are a global leader in the two-way radio category, including Project 25 (“P25”), Terrestrial Trunked Radio (“TETRA”) and Digital Mobile Radio (“DMR”), as well as other professional and commercial radio (“PCR”) solutions. We also deliver LTE solutions for public safety, government and commercial users, including infrastructure and devices operating in 700 MHz, 900 MHz and Citizens’ Broadband Radio Service (“CBRS”) frequencies. Primary sources of revenue for this technology come from selling devices and building telecommunications networks, including infrastructure, installation and integration with our customers’ technology environments.

[0000068505-21-000008:mdna:14]
Our technology enables voice and multimedia collaborations across different two-way radio, WiFi or public LTE and private broadband networks. We believe that first responders continue to trust LMR communications because they are purpose-built and designed for reliability, availability, security and resiliency to withstand the most challenging conditions. By adding broadband data capabilities to our two-way radios, we strive to provide our customers greater functionality and access to the information and data they need in their workflows. Examples of such functionality include application services such as GPS location to better protect lone workers and over-the-air programming and updates to optimize device uptime.

[0000068505-21-000008:mdna:15]
The LMR technology within the Products and Systems Integration segment represented 86% of the net sales of the total segment in 2020.

[0000068505-21-000008:mdna:16]
Video Security and Analytics

[0000068505-21-000008:mdna:17]
Our Video Security and Analytics technology includes network video management infrastructure, fixed security and mobile video cameras (body-worn and in-vehicle) and access control solutions. We deploy video security solutions to thousands of government and commercial customers around the world including school campuses, transportation systems, healthcare centers, public venues, utilities, prisons, factories, casinos, airports, financial institutions, government facilities, state and local law enforcement agencies and retailers. Organizations such as these utilize video security to enable continuous monitoring that can improve situational awareness, particularly across large areas, and to visually verify critical events or incidents in real-time or investigate after they happen.

[0000068505-21-000008:mdna:18]
Our view is that government and public safety customers in particular are increasingly turning to video security technologies, including fixed street cameras, in-vehicle cameras and body-worn cameras, to increase visibility, accountability and safety for citizens, communities and first responders alike.

[0000068505-21-000008:mdna:19]
We have built our video security and analytics technology through strategic acquisitions. We acquired Avigilon Corporation (“Avigilon”) in 2018. Avigilon access control solutions, in addition to cameras, sensors and infrastructure embedded with advanced video analytics, are designed to be simple and easy to use. We expanded our fixed video security technology through our acquisitions of IndigoVision Group plc and Pelco, Inc. in 2020. We grew our mobile video security technology in 2019 through our acquisitions of WatchGuard Inc., which provides body-worn cameras and in-vehicle video systems for North America law enforcement agencies, and Edesix Ltd (acquired as part of the VaaS International Holdings acquisition), a provider of body-worn cameras in Europe for both law enforcement and commercial markets.

[0000068505-21-000008:mdna:20]
The Video Security and Analytics technology within the Products and Systems Integration segment represented 14% of the net sales of the total segment in 2020.

[0000068505-21-000008:mdna:21]
Software and Services Segment

[0000068505-21-000008:mdna:22]
In 2020, the segment’s net sales were $2.8 billion, representing 37% of our consolidated net sales.

[0000068505-21-000008:mdna:23]
LMR Mission Critical Communications

[0000068505-21-000008:mdna:24]
LMR Mission Critical Communications services include support and managed services, which offer a broad continuum of support for our customers. Support services include repair and replacement, technical support and preventative maintenance, and more advanced offerings such as system monitoring, software updates and cybersecurity services. Managed services range from partial to full operational support of customer-owned or Motorola Solutions-owned networks. Our customers’ systems often have multi-year or multi-decade lifespans that help drive demand for software upgrades, device and infrastructure refresh opportunities, as well as additional services to monitor, manage, maintain and secure these complex networks and solutions. We strive to deliver services to our customers that help improve performance across their systems, devices and applications for greater safety and productivity.

[0000068505-21-000008:mdna:25]
Given the mission-critical nature of our customers’ LMR networks, availability, security and resiliency are imperative, along with keeping pace with technological advancements. We have a comprehensive approach to system upgrades that addresses hardware, software and implementation services. As new system releases become available, we work with our customers to upgrade software, hardware, or both, with respect to site controllers, comparators, routers, LAN switches, servers, dispatch consoles, logging equipment, network management terminals, network security devices such as firewalls and intrusion detection sensors, and more, on-site or remotely.

[0000068505-21-000008:mdna:26]
The LMR technology within the Software and Services segment represented 72% of the net sales of the total segment in 2020.

[0000068505-21-000008:mdna:27]
Command Center Software

[0000068505-21-000008:mdna:28]
Our Command Center Software suite, CommandCentral, supports the complex process of the public safety workflow from "911 call to case closure," which involves an array of roles from the moment a citizen dials 911, such as dispatchers who route calls to police, fire and emergency medical services, first responders in the field, intelligence analysts who manage real-time operations, records specialists who preserve the integrity of information and evidence, crime analysts who identify patterns and accelerate investigations, and corrections officers who oversee jail and inmate management.

[0000068505-21-000008:mdna:29]
CommandCentral software supports these roles through the three phases of incident response: incident awareness, incident management and post-incident resolution. Incident awareness software includes community engagement applications for tip submissions, crime mapping and evidence submission, and 911 call-handling software (including multimedia) and next-generation core services for 911 call routing. Incident management software includes computer aided dispatch (“CAD”) for dispatch and coordinating first response, situational awareness software that shows a single, real-time view of video feeds and other alerts on a map, and field response and reporting to help frontline personnel collaborate, manage incident activity and file reports from the field. Post-incident resolution software includes centralized records and evidence management for record-keeping and judicial sharing, analytics including license plate recognition, and jail and inmate management to streamline the process and enable secure inter-agency information sharing.

[0000068505-21-000008:mdna:30]
As the public safety market continues to evolve toward software offerings that more efficiently run their operations, reduce response times and increase officer availability, we have focused on providing cloud-based software-as-a service (“SaaS”) with ancillary implementation and managed services in addition to on-premises solutions. Our PremierOne Cloud suite, hosted in Microsoft Azure Government, includes CAD, mobile and records in a single, integrated cloud-based offering. We believe that cloud deployment delivers agencies key benefits, including faster deployment, increased security, rapid scaling in the event of an emergency and a secure investment that keeps pace as technology advances.

[0000068505-21-000008:mdna:31]
Another area of public safety evolution is increasing adoption of Next Generation 911 Core Services (“NGCS”), a group of products and services needed to create infrastructure connectivity in order to process a 911 call using Next Generation (“NG”) technology. The NG infrastructure is an Emergency Service IP Network ("ESInet"), which can carry voice, data and multimedia. ESInet enables 911 call takers at public safety answering points to respond to text, video and data. Our NGCS can be offered as a managed service and includes call routing, ESInet, location services, Geographic Information Services, cybersecurity and our continuous network and security operations center dedicated to public safety. We believe that our solution is differentiated

[0000068505-21-000008:mdna:32]
through its integration with our CommandCentral software suite to simplify the agency’s workflow and ensure better incident management and real-time intelligence.

[0000068505-21-000008:mdna:33]
Additional Command Center Software includes interoperability software that ensures communication is not limited by coverage area, network technology or device type. Our solutions, including Kodiak, WAVE PTX and CriticalConnect, enable interoperability among devices across multiple networks. For example, a two-way radio network can connect with an LTE network making it possible for individuals to communicate securely and more easily across technologies.

[0000068505-21-000008:mdna:34]
The Command Center Software technology within the Software and Services segment represented 18% of the net sales of the total segment in 2020.

[0000068505-21-000008:mdna:35]
Video Security and Analytics

[0000068505-21-000008:mdna:36]
Video Security and Analytics software includes video network management software, digital evidence management software and advanced vehicle location data analysis software, including license plate recognition, each designed to complement respective video hardware systems.

[0000068505-21-000008:mdna:37]
Our video network management software is embedded with artificial intelligence (“AI”)-enabled analytics to deliver operational insights to our customers by bringing attention to important events within their video footage. Given the volume of video footage, we believe this is critical to monitor and manage to deliver meaningful, action-oriented insights. For example, AI-enabled analytics can detect unusual behavior such as a person at a facility out-of-hours, locate a missing child with our Appearance Search feature at a theme park, flag a blacklisted vehicle through license plate recognition at a school, or send an alert through access control if doors are propped open at a hospital.

[0000068505-21-000008:mdna:38]
Video Security and Analytics services include our video-as-service offering for law enforcement, simplifying procurement by bundling hardware and software into a single subscription. Body-worn cameras and in-car video systems can be paired with either on-premises or cloud-based digital evidence management software and complementary command center software products. Additionally, Avigilon fixed video systems connected to Avigilon Cloud Services (“ACS”) provide our customers with the ability to securely access video across their sites from a remote/central monitoring location and more easily integrate with their other systems.

[0000068505-21-000008:mdna:39]
The Video Security and Analytics technology within the Software and Services segment represented 10% of the net sales of the total segment in 2020.

[0000068505-21-000008:mdna:40]
2020 Financial Results

[0000068505-21-000008:mdna:41]
•Net sales were $7.4 billion in 2020 compared to $7.9 billion in 2019.

[0000068505-21-000008:mdna:42]
•Operating earnings were $1.4 billion in 2020 compared to $1.6 billion in 2019.

[0000068505-21-000008:mdna:43]
•Net earnings attributable to Motorola Solutions, Inc. were $949 million, or $5.45 per diluted common share in 2020, compared to earnings of $868 million, or $4.95 per diluted common share in 2019.

[0000068505-21-000008:mdna:44]
•Our operating cash flow was $1.6 billion in 2020 compared to $1.8 billion in 2019.

[0000068505-21-000008:mdna:45]
•We returned over $1.0 billion of capital to shareholders, in the form of $612 million in share repurchases and $436 million in dividends in 2020.

[0000068505-21-000008:mdna:46]
•We increased our quarterly dividend by 11% to $0.71 per share in November 2020.

[0000068505-21-000008:mdna:47]
•We ended 2020 with a backlog position of $11.4 billion, up $175 million compared to 2019.

[0000068505-21-000008:mdna:48]
Segment Financial Highlights

[0000068505-21-000008:mdna:49]
•In the Products and Systems Integration segment, net sales were $4.6 billion in 2020, a decrease of $695 million, or 13%, compared to $5.3 billion in 2019. On a geographic basis, net sales decreased in both North America and International primarily driven by lower public safety LMR and PCR, partially offset by growth in Video Security and Analytics. Operating earnings were $656 million in 2020, compared to $994 million in 2019. Operating margins decreased in 2020 to 14.2% from 18.7% in 2019 primarily due to lower sales and gross margin contribution, partially offset by lower operating expenses primarily driven by: lower employee incentive costs, indirect expenses, and travel expenses, and a $50 million gain from the sale of a manufacturing facility in Europe. The overall reduction in operating expenses was partially offset by: (i) $23 million higher reorganization of business expenses, (ii) $11 million higher share-based compensation expenses, and (iii) higher operating expenses from acquisitions.

[0000068505-21-000008:mdna:50]
•In the Software and Services segment, net sales were $2.8 billion in 2020, an increase of $222 million, or 9%, compared to $2.6 billion in 2019. On a geographic basis, net sales increased in both North America and International. Operating earnings were $727 million in 2020, compared to $587 million in 2019. Operating margin increased in 2020 to 26.2% from 22.9% in 2019 due to higher sales and gross margin contribution, along with reduced operating expenses primarily driven by operating leverage, inclusive of lower employee incentive costs and travel expenses. The overall reduction in operating expenses was partially offset by: (i) $6 million higher reorganization of business expenses, (ii) $5 million higher intangible amortization driven by acquisitions, and (iii) higher operating expenses from acquisitions.

[0000068505-21-000008:mdna:51]
COVID-19

[0000068505-21-000008:mdna:52]
In response to the COVID-19 pandemic, there have been a broad number of governmental and commercial actions taken to limit the spread of the virus, including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns. These actions have resulted in a significant decline in global economic activity, and accordingly, we have assessed the impact on our employees, customers, communities, liquidity and financial position.

[0000068505-21-000008:mdna:53]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including having office workers work remotely, suspending employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings, and using thermal scanning. We have continued to ensure customer continuity by fulfilling several emergency orders, completing remote software maintenance where possible, and continuing to service our mission-critical networks on-site as needed to ensure seamless operations. Our sales teams have also continued to improve virtual engagement with our customers. Additionally, our engineering teams have adapted our solutions offerings to equip our customers with the latest technology in an effort to protect their workplaces from the spread of COVID-19. Specifically, in Video Security and Analytics, we have adapted our software and hardware offerings to provide analytics addressing occupancy counting, face mask detection, and thermal detection capabilities.

[0000068505-21-000008:mdna:54]
We believe our existing balances of cash, cash equivalents and marketable securities, along with other short-term liquidity arrangements, will be sufficient to satisfy our liquidity requirements associated with our existing operations. During the first quarter of 2020, we proactively withdrew $800 million from our unsecured revolving credit facility, which we repaid during the twelve months ended December 31, 2020. We were in compliance with all applicable covenants in our unsecured revolving credit facility as of December 31, 2020. Additionally, we have no bond maturities until 2023.

[0000068505-21-000008:mdna:55]
We continue to evaluate our financial position during this economic slowdown. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impacts on net sales and operating margin will be limited in 2021. In our Products and Systems Integration segment, the impacts on net sales and operating margin were more significant during the first half of 2020 with reduced impact in the fourth quarter of 2020. Reduced demand, particularly in our PCR business, as well as delays in engagements with our state and local customers led to a decline in net sales for the Product and Systems Integration segment in 2020 as compared to 2019. Within the Products and Systems Integration segment, we are encouraged by strong LMR backlog, and the resiliency of the Video Security and Analytics technology, that has experienced growth in the year, as we enter 2021. In 2021, COVID-19 may continue to have an impact on net sales and operating margins within our Products and Systems Integration segment. However, given the prioritization of mission critical communication solutions, we do not anticipate funding at the state and local levels to have a material, negative effect on our expected net sales for 2021. We have also taken actions in a number of areas to reduce our operating expenses, including lower variable employee compensation, travel costs, contractor spend and reducing our real estate footprint to limit the negative effect on operating margins for 2020; however, a portion of these expenses, primarily variable compensation and certain travel expenses are likely to return in 2021. In addition, our supply chain partners have been supportive and continue to work to fulfill the necessary service levels to the Company and its customers.

[0000068505-21-000008:mdna:56]
We continue to closely monitor the impact of COVID-19 on our business and geographies, including how it is impacting our customers, suppliers, and business partners. However, the future impact that COVID-19 will have on our financial position and operating results may be affected by numerous uncertainties, including the severity of the virus, the duration of the outbreak, governmental, business or other actions, impacts on our supply chain, the effect on customer demand, or changes to our operations. The impacts of a potential worsening of global economic conditions and the continued disruptions to, and volatility in, the credit and financial markets, as well as other unanticipated consequences, remain unknown. Further, additional outbreaks of COVID-19 in fiscal 2021 or beyond would cause many of the impacts described herein to return or be exacerbated.

[0000068505-21-000008:mdna:57]
Recent Acquisitions

[0000068505-21-000008:mdna:58]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Command Center Software | Software and Services | Callyo | Provider of cloud-based mobile applications for law enforcement in North America, including critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. | $63 million, inclusive of share-based compensation of $3 million | August 28, 2020 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | Pelco, Inc. | Global provider of video security solutions, adding a broad range of products for a variety of commercial and industrial environments and use cases. | $110 million | July 31, 2020 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | IndigoVision Group plc | Provider of video security solutions to enhance geographical reach across a wider customer base. | $37 million | June 16, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, and managed services, including security monitoring of network operations. | $32 million | April 30, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, managed services, and remediation and response capabilities. | $40 million, inclusive of share-based compensation of $6 million | March 3, 2020 |
| Video Security and Analytics | Software and Services | Unnamed data solutions business for vehicle location information | Provider of additional data to our existing license plate recognition database. | $85 million | October 16, 2019 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | WatchGuard, Inc. | Provider of in-car and body-worn video solutions. | $271 million, inclusive of share-based compensation of $16 million | July 11, 2019 |
| LMR | Products and Systems IntegrationSoftware and Services | Avtec, Inc. | Provider of dispatch communications for U.S. public safety and commercial customers to communicate, coordinate resources, and secure their facilities. | $136 million | March 11, 2019 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | VaaS International Holdings | Global provider of data and image analytics for vehicle location. | $445 million, inclusive of share-based compensation of $38 million | January 7, 2019 |
| Video Security and Analytics | Products and Systems IntegrationSoftware and Services | Avigilon Corporation | Provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras, and access control solutions. | $974 million | March 28, 2018 |
| Command Center Software | Software and Services | Plant Holdings, Inc. | Provider of next generation 911 solutions. | $237 million | March 7, 2018 |

[0000068505-21-000008:mdna:59]
31

[0000068505-21-000008:mdna:60]
Change in Presentation

[0000068505-21-000008:mdna:61]
During the first quarter of 2020, the Company restructured to realize more operational efficiencies, combining our Europe, Middle East and Africa ("EMEA"), Asia Pacific ("AP"), and Latin America ("LA") regions into one region, which is now reflected as "International." Accordingly, the Company now reports net sales in the following two geographic regions: North America, which includes the United States and Canada, and International. In addition, during the fourth quarter of 2020, the Company updated its presentation of major products and services to provide a more comprehensive view of our technologies within our reporting segments. Accordingly, the Company now reports net sales in the following three major products and services: LMR Mission Critical Communications, Video Security, and Command Center Software. The Company has updated all periods presented to reflect this change in presentation. Refer to Note 2 of our Consolidated Financial Statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information.

[0000068505-21-000008:mdna:62]
Looking Forward

[0000068505-21-000008:mdna:63]
We continue to focus on growth opportunities across our portfolio of technologies.

[0000068505-21-000008:mdna:64]
We expect continued growth within our global LMR installed base as a number of events such as natural disasters and large-scale incidents continue to reinforce the importance of having secure, reliable LMR for public safety. We believe our augmentation of LMR with broadband solutions will also drive growth, as we expect our customers will look to integrate valuable data capabilities. We expect to provide additional services to existing LMR customers as communication networks become more complex, software-centric and data-driven.

[0000068505-21-000008:mdna:65]
As public safety needs continue to evolve, we anticipate growth opportunities within the command center as our Command Center Software suite covers the mission critical workflow, from 911 intake to case closure and management. We expect increased growth in our integrated software next generation core services and our cloud-based solutions, such as the PremierOne Cloud suite.

[0000068505-21-000008:mdna:66]
Within Video Security and Analytics, we expect growth across our portfolio of fixed and mobile security solutions embedded with advanced analytics, and access control solutions. We believe drivers include expansion of traditional video sales beyond commercial customers to government and public safety customers. Additionally, we expect customers to continue to embrace analytics that convert video into data and the scalability of the cloud to run their operations, and we also expect continued expansion of offerings such as video-as-a-service and Avigilon Cloud Services.

[0000068505-21-000008:mdna:67]
Finally, we anticipate new opportunities from the investments we are making to integrate our LMR, Command Center Software and Video Security and Analytics technologies into one unified ecosystem. We have made go-to-market and research and development investments in both Video Security and Analytics and our Command Center Software technologies with growth in mind. We have made a number of acquisitions and we see opportunities to continue to rationalize costs within both segments of our business, further driving operating leverage in our businesses. We believe our integrated ecosystem for public and enterprise safety can enable strong collaboration by removing system silos, simplifying management and automating workflows.

[0000068505-21-000008:mdna:68]
Refer to “COVID-19” set forth in “Part II. Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” of this Form 10-K for a discussion of our outlook with respect to the continuing impact of COVID-19 on the Company’s financial condition and results of operations.

[0000068505-21-000008:mdna:69]
32

[0000068505-21-000008:mdna:70]
Results of Operations

[0000068505-21-000008:mdna:71]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2020 |  | % ofSales ** |  | 2019 |  | % ofSales ** |  | 2018 |  | % ofSales ** |
| Net sales from products | $ | 4,087 |  |  |  |  | $ | 4,746 |  |  |  |  | $ | 4,463 |  |  |  |
| Net sales from services | 3,327 |  |  |  |  | 3,141 |  |  |  |  | 2,880 |  |  |  |
| Net sales | 7,414 |  |  |  |  | 7,887 |  |  |  |  | 7,343 |  |  |  |
| Costs of product sales | 1,872 |  |  | 45.8 | % |  | 2,049 |  |  | 43.2 | % |  | 2,035 |  |  | 45.6 | % |
| Costs of services sales | 1,934 |  |  | 58.1 | % |  | 1,907 |  |  | 60.7 | % |  | 1,828 |  |  | 63.5 | % |
| Costs of sales | 3,806 |  |  | 51.3 | % |  | 3,956 |  |  | 50.2 | % |  | 3,863 |  |  | 52.6 | % |
| Gross margin | 3,608 |  |  | 48.7 | % |  | 3,931 |  |  | 49.8 | % |  | 3,480 |  |  | 47.4 | % |
| Selling, general and administrative expenses | 1,293 |  |  | 17.4 | % |  | 1,403 |  |  | 17.8 | % |  | 1,254 |  |  | 17.1 | % |
| Research and development expenditures | 686 |  |  | 9.3 | % |  | 687 |  |  | 8.7 | % |  | 637 |  |  | 8.7 | % |
| Other charges | 246 |  |  | 3.3 | % |  | 260 |  |  | 3.3 | % |  | 334 |  |  | 4.5 | % |
| Operating earnings | 1,383 |  |  | 18.7 | % |  | 1,581 |  |  | 20.0 | % |  | 1,255 |  |  | 17.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (220) |  |  | (3.0) | % |  | (220) |  |  | (2.8) | % |  | (222) |  |  | (3.0) | % |
| Gains (losses) on sales of investments and businesses, net | (2) |  |  | — | % |  | 5 |  |  | 0.1 | % |  | 16 |  |  | 0.2 | % |
| Other | 13 |  |  | 0.2 | % |  | (365) |  |  | (4.6) | % |  | 53 |  |  | 0.7 | % |
| Total other expense | (209) |  |  | (2.8) | % |  | (580) |  |  | (7.4) | % |  | (153) |  |  | (2.1) | % |
| Net earnings before income taxes | 1,174 |  |  | 15.8 | % |  | 1,001 |  |  | 12.7 | % |  | 1,102 |  |  | 15.0 | % |
| Income tax expense | 221 |  |  | 3.0 | % |  | 130 |  |  | 1.6 | % |  | 133 |  |  | 1.8 | % |
| Net earnings | 953 |  |  | 12.9 | % |  | 871 |  |  | 11.0 | % |  | 969 |  |  | 13.2 | % |
| Less: Earnings attributable to noncontrolling interests | 4 |  |  | 0.1 | % |  | 3 |  |  | — | % |  | 3 |  |  | — | % |
| Net earnings* | $ | 949 |  |  | 12.8 | % |  | $ | 868 |  |  | 11.0 | % |  | $ | 966 |  |  | 13.2 | % |
| Earnings per diluted common share* | $ | 5.45 |  |  |  |  | $ | 4.95 |  |  |  |  | $ | 5.62 |  |  |  |

[0000068505-21-000008:mdna:72]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-21-000008:mdna:73]
**    Percentages may not add due to rounding.

[0000068505-21-000008:mdna:74]
Geographic Market Sales by Locale of End Customer

[0000068505-21-000008:mdna:75]
|  | 2020 |  | 2019 |  | 2018 |
| North America | 68 | % |  | 67 | % |  | 64 | % |
| International | 32 | % |  | 33 | % |  | 36 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-21-000008:mdna:76]
33

[0000068505-21-000008:mdna:77]
Results of Operations—2020 Compared to 2019

[0000068505-21-000008:mdna:78]
Net Sales

[0000068505-21-000008:mdna:79]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Net sales from Products and Systems Integration | $ | 4,634 |  |  | $ | 5,329 |  |  | (13) | % |
| Net sales from Software and Services | 2,780 |  |  | 2,558 |  |  | 9 | % |
| Net sales | $ | 7,414 |  |  | $ | 7,887 |  |  | (6) | % |

[0000068505-21-000008:mdna:80]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in 2020, compared to 68% in 2019. The Software and Services segment’s net sales represented 37% of our net sales in 2020, compared to 32% in 2019.

[0000068505-21-000008:mdna:81]
Net sales decreased by $473 million, or 6%, compared to 2019. The 13% decline in net sales within the Products and Systems Integration segment was driven by an 11% decline in the North America region and an 18% decline in the International region. The 9% increase in the Software and Services segment was driven by a 12% increase in the North America region and a 4% increase in the International region. The decrease in net sales included:

[0000068505-21-000008:mdna:82]
•a decline in the Products and Systems Integration segment, inclusive of $119 million of revenue from acquisitions, driven by a decline in public safety LMR and PCR, partially offset by growth in Video Security;

[0000068505-21-000008:mdna:83]
•growth in the Software and Services segment, inclusive of $84 million of revenue from acquisitions, driven by an increase in Video Security and Analytics, Command Center Software, and LMR services due to strong demand in the North America region; and

[0000068505-21-000008:mdna:84]
•$12 million from unfavorable currency rates.

[0000068505-21-000008:mdna:85]
Regional results included:

[0000068505-21-000008:mdna:86]
•a 5% decline in the North America region, inclusive of revenue from acquisitions, driven by declines in public safety LMR and PCR, partially offset by growth in Video Security and Analytics, LMR services, and Command Center Software; and

[0000068505-21-000008:mdna:87]
•a 9% decline in the International region, inclusive of revenue from acquisitions, driven by declines in public safety LMR and PCR, partially offset by growth in Video Security and Analytics, Command Center Software, and LMR public safety services.

[0000068505-21-000008:mdna:88]
Products and Systems Integration

[0000068505-21-000008:mdna:89]
The 13% decrease in the Products and Systems Integration segment was driven by the following:

[0000068505-21-000008:mdna:90]
•17% decline in public safety LMR and PCR, inclusive of revenue from acquisitions, in both the International and North America regions, primarily driven by a delay in customer engagement due to the COVID-19 pandemic;

[0000068505-21-000008:mdna:91]
•partially offset by $143 million, or 29%, growth in Video Security and Analytics, inclusive of revenue from acquisitions, in both the International and North America regions; and

[0000068505-21-000008:mdna:92]
•$3 million from favorable currency rates.

[0000068505-21-000008:mdna:93]
Software and Services

[0000068505-21-000008:mdna:94]
The 9% increase in the Software and Services segment was driven by the following:

[0000068505-21-000008:mdna:95]
•6% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America region;

[0000068505-21-000008:mdna:96]
•36% growth in Video Security and Analytics, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000008:mdna:97]
•7% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000008:mdna:98]
•partially offset by $15 million from unfavorable currency rates.

[0000068505-21-000008:mdna:99]
Gross Margin

[0000068505-21-000008:mdna:100]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Gross margin | $ | 3,608 |  |  | $ | 3,931 |  |  | (8) | % |

[0000068505-21-000008:mdna:101]
34

[0000068505-21-000008:mdna:102]
Gross margin was 48.7% of net sales in 2020 and 49.8% of net sales in 2019. The decrease was driven by:

[0000068505-21-000008:mdna:103]
•lower gross margin contribution in Products and Systems Integration segment as a result of the decline in public safety LMR and PCR sales, as well as lower margins on projects driven by a delay in engagements from COVID-19, partially offset by lower incentive costs; and

[0000068505-21-000008:mdna:104]
•partially offset by higher gross margins within the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth, driven by improved mix of service offerings and lower travel and incentive costs.

[0000068505-21-000008:mdna:105]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-21-000008:mdna:106]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Selling, general and administrative expenses | $ | 1,293 |  |  | $ | 1,403 |  |  | (8) | % |

[0000068505-21-000008:mdna:107]
SG&A expenses decreased 8% in 2020 compared to 2019. SG&A expenses were 17.4% of net sales in 2020 compared to 17.8% of net sales in 2019. The decrease in SG&A expenses was primarily due to reduced employee incentive costs, travel expenses, and indirect expenses. The overall reduction in SG&A expenses was partially offset by expenses associated with acquired businesses.

[0000068505-21-000008:mdna:108]
Research and Development ("R&D") Expenditures

[0000068505-21-000008:mdna:109]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |  | % Change |
| Research and development expenditures | $ | 686 |  |  | $ | 687 |  |  | — | % |

[0000068505-21-000008:mdna:110]
R&D expenditures remained consistent in 2020 compared to 2019. R&D expenditures were 9.3% of net sales in 2020 and 8.7% of net sales in 2019.

[0000068505-21-000008:mdna:111]
Other Charges

[0000068505-21-000008:mdna:112]
|  | Years ended December 31 |  |  |
| (In millions) | 2020 |  | 2019 |  |  |
| Other charges | $ | 246 |  |  | $ | 260 |  |  |  |

[0000068505-21-000008:mdna:113]
Other charges decreased by $16 million in 2020 compared to 2019 primarily due to the following:

[0000068505-21-000008:mdna:114]
•$50 million gain on sale of a manufacturing facility in Europe in 2020;

[0000068505-21-000008:mdna:115]
•partially offset by $57 million of net reorganization of business charges in 2020 as compared to $40 million in 2019 (see Note 14 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-21-000008:mdna:116]
•$215 million of amortization of intangibles in 2020 compared to $208 million in 2019;

[0000068505-21-000008:mdna:117]
•$9 million of legal settlements in 2020 compared to $3 million in 2019;

[0000068505-21-000008:mdna:118]
•$9 million of charges for acquisition-related transaction fees in 2020 as compared to $3 million in 2019; and

[0000068505-21-000008:mdna:119]
•$5 million of fixed asset impairments.

[0000068505-21-000008:mdna:120]
Operating Earnings

[0000068505-21-000008:mdna:121]
|  | Years ended December 31 |  |  |
| (In millions) | 2020 |  | 2019 |  |  |
| Operating earnings from Products and Systems Integration | $ | 656 |  |  | $ | 994 |  |  |  |
| Operating earnings from Software and Services | 727 |  |  | 587 |  |  |  |
| Operating earnings | $ | 1,383 |  |  | $ | 1,581 |  |  |  |

[0000068505-21-000008:mdna:122]
Operating earnings decreased $198 million, or 13%, compared to 2019. The decrease in Operating earnings was due to:

[0000068505-21-000008:mdna:123]
•Products and Systems Integration decreased by $338 million from 2020 to 2019 driven by lower sales and gross margin contribution, partially offset by lower operating expenses driven by lower employee incentive costs, indirect expenses, and travel expenses. The overall reduction in operating expenses was offset by: (i) $23 million higher reorganization of business expenses, (ii) $11 million higher share-based compensation expenses, and (iii) higher operating expenses from acquisitions.

[0000068505-21-000008:mdna:124]
•Software and Services segment increased by $140 million from 2020 to 2019 driven by higher sales and gross margin contribution, along with reduced operating expenses due to operating leverage, inclusive of lower employee incentive costs and travel expenses. The overall reduction in operating expenses was partially offset by: (i) $6 million higher reorganization of business expenses, (ii) $5 million higher intangible amortization driven by acquisitions, and (iii) higher operating expenses from acquisitions.

[0000068505-21-000008:mdna:125]
Interest Expense, net

[0000068505-21-000008:mdna:126]
|  | Years ended December 31 |  |  |
| (In millions) | 2020 |  | 2019 |  |  |
| Interest expense, net | $ | (220) |  |  | $ | (220) |  |  |  |

[0000068505-21-000008:mdna:127]
Interest expense, net in 2020 compared to 2019 remained relatively consistent due to a one-time receipt of interest income related to a tax refund and lower interest rates on debt outstanding, offset by lower interest income earned on cash due to lower interest rates.

[0000068505-21-000008:mdna:128]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-21-000008:mdna:129]
|  | Years ended December 31 |  |
| (In millions) | 2020 |  | 2019 |  |
| Gains (losses) on sales of investments and businesses, net | $ | (2) |  |  | $ | 5 |  |  |

[0000068505-21-000008:mdna:130]
The net gains (losses) in 2020 and 2019 were primarily related to the sales of various equity investments.

[0000068505-21-000008:mdna:131]
Other, net

[0000068505-21-000008:mdna:132]
|  | Years ended December 31 |
| (In millions) | 2020 |  | 2019 |
| Other, net | $ | 13 |  |  | $ | (365) |  |

[0000068505-21-000008:mdna:133]
The change in net Other income in 2020 as compared to net Other expense in 2019 was primarily comprised of:

[0000068505-21-000008:mdna:134]
•$359 million U.S pension settlement loss in 2019 (see Note 8 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-21-000008:mdna:135]
•$25 million gain on derivatives in 2020 compared to an $8 million loss on derivatives in 2019;

[0000068505-21-000008:mdna:136]
•$4 million of investment impairments in 2020 compared to $18 million in 2019;

[0000068505-21-000008:mdna:137]
•partially offset by $44 million of foreign currency losses in 2020 compared to $22 million in 2019; and

[0000068505-21-000008:mdna:138]
•$56 million of net losses from repurchases of long term debt in 2020 as compared to a loss of $46 million in 2019 (see Note 5 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-21-000008:mdna:139]
Effective Tax Rate

[0000068505-21-000008:mdna:140]
|  | Years ended December 31 |  |
| (In millions) | 2020 |  | 2019 |  |
| Income tax expense | $ | 221 |  |  | $ | 130 |  |  |

[0000068505-21-000008:mdna:141]
Income tax expense increased by $91 million in 2020 compared to 2019, for an effective tax rate of 18.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-21-000008:mdna:142]
•$48 million of benefits due to the recognition of excess tax benefits on share-based compensation; and

[0000068505-21-000008:mdna:143]
•$28 million of benefits due to the recognition of increased prior and current R&D tax credits.

[0000068505-21-000008:mdna:144]
Our effective tax rate in 2019 was 13.0%, which is lower than the current U.S. federal statutory rate of 21% primarily related to:

[0000068505-21-000008:mdna:145]
•a $77 million benefit due to the partial release of a valuation allowance to our U.S. foreign tax credit carryforward (see Note 7 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information); and

[0000068505-21-000008:mdna:146]
•$27 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-21-000008:mdna:147]
36

[0000068505-21-000008:mdna:148]
Results of Operations—2019 Compared to 2018

[0000068505-21-000008:mdna:149]
Net Sales

[0000068505-21-000008:mdna:150]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 5,329 |  |  | $ | 5,100 |  |  | 5 | % |
| Net sales from Software and Services | 2,558 |  |  | 2,243 |  |  | 14 | % |
| Net sales | $ | 7,887 |  |  | $ | 7,343 |  |  | 7 | % |

[0000068505-21-000008:mdna:151]
The Products and Systems Integration segment’s net sales represented 68% of our consolidated net sales in 2019, compared to 69% in 2018. The Software and Services segment’s net sales represented 32% of our consolidated net sales in 2019, compared to 31% in 2018.

[0000068505-21-000008:mdna:152]
Net sales increased by $544 million, or 7%, in 2019 compared to 2018. Net sales in the Software and Services segment increased approximately 14%, which was comprised of a 22% increase in the North America region and a 6% sales increase in the International region. Net sales in the Products and Systems Integration segment increased approximately 5%, which is comprised of a 10% increase in the North America region partially offset by an 8% decrease in the International region. The increase in net sales included:

[0000068505-21-000008:mdna:153]
•an increase in the Products and Systems Integration segment, inclusive of $157 million of revenue from acquisitions, driven by growth in LMR and Video Security and Analytics;

[0000068505-21-000008:mdna:154]
•growth in the Software and Services segment, inclusive of $155 million of revenue from acquisitions, driven by an increase in Video Security and Analytics, Command Center Software, and LMR services due to strong demand in the North America region; and

[0000068505-21-000008:mdna:155]
•partially offset by $113 million from unfavorable currency rates.

[0000068505-21-000008:mdna:156]
Regional results include:

[0000068505-21-000008:mdna:157]
•13% increase in the North America region, inclusive of revenue from acquisitions, across Video Security and Analytics, LMR, and Command Center Software within both the Products and Systems Integration and the Software and Services segments; and

[0000068505-21-000008:mdna:158]
•3% decline in the International region, inclusive of revenue from acquisitions, driven by declines in public safety LMR and PCR, partially offset by growth in Video Security and Analytics and Command Center Software.

[0000068505-21-000008:mdna:159]
Products and Systems Integration

[0000068505-21-000008:mdna:160]
The 5% growth in the Products and Systems Integration segment was driven by:

[0000068505-21-000008:mdna:161]
•57% growth in Video Security and Analytics, inclusive of acquisitions, driven by growth in the North America and International regions;

[0000068505-21-000008:mdna:162]
•1% growth in LMR, inclusive of acquisitions, driven by growth in the North America region and partially offset by a decline in the International region, which had two large system deployments completed in the Middle East and Africa in 2018; and

[0000068505-21-000008:mdna:163]
•partially offset by $54 million foreign currency headwinds.

[0000068505-21-000008:mdna:164]
Software and Services

[0000068505-21-000008:mdna:165]
The 14% growth in the Software and Services segment was driven by the following:

[0000068505-21-000008:mdna:166]
•223% growth in Video Security and Analytics, inclusive of acquisitions, driven by both the North America and International regions;

[0000068505-21-000008:mdna:167]
•26% growth in Command Center Software, inclusive of acquisitions, driven by both the North America and International regions;

[0000068505-21-000008:mdna:168]
•4% growth in LMR services, inclusive of acquisitions, primarily driven by the North America region; and

[0000068505-21-000008:mdna:169]
•partially offset by $59 million of foreign currency headwinds.

[0000068505-21-000008:mdna:170]
Gross Margin

[0000068505-21-000008:mdna:171]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Gross margin | $ | 3,931 |  |  | $ | 3,480 |  |  | 13 | % |

[0000068505-21-000008:mdna:172]
Gross margin was 49.8% of net sales in 2019 and 47.4% of net sales in 2018. The increase was driven by:

[0000068505-21-000008:mdna:173]
•higher margins in the Products and Systems Integration segment primarily driven by a favorable mix in LMR devices; and

[0000068505-21-000008:mdna:174]
•higher margins within the Software and Services segment primarily driven by higher software sales, inclusive of acquisitions.

[0000068505-21-000008:mdna:175]
Selling, General and Administrative Expenses

[0000068505-21-000008:mdna:176]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 1,403 |  |  | $ | 1,254 |  |  | 12 | % |

[0000068505-21-000008:mdna:177]
SG&A expenses increased 12% in 2019 compared to 2018. SG&A expenses were 17.8% of net sales in 2019 compared to 17.1% of net sales in 2018. The increase in SG&A expenses was primarily due to increased expenses associated with acquired businesses, including the deployment of additional sales resources to support Video Security and Analytics growth initiatives.

[0000068505-21-000008:mdna:178]
Research and Development Expenditures

[0000068505-21-000008:mdna:179]
|  | Years ended December 31 |
| (In millions) | 2019 |  | 2018 |  | % Change |
| Research and development expenditures | $ | 687 |  |  | $ | 637 |  |  | 8 | % |

[0000068505-21-000008:mdna:180]
R&D expenditures increased 8% in 2019 compared to 2018. R&D expenditures were 8.7% of net sales in each of 2019 and 2018. The increase in R&D expenses was primarily due to acquired businesses, specifically in Video Security and Analytics, as well as new product launches.

[0000068505-21-000008:mdna:181]
Other Charges

[0000068505-21-000008:mdna:182]
|  | Years ended December 31 |  |
| (In millions) | 2019 |  | 2018 |  |
| Other charges | $ | 260 |  |  | $ | 334 |  |  |

[0000068505-21-000008:mdna:183]
The decrease in Other charges in 2019 as compared to 2018 can be summarized as follows:

[0000068505-21-000008:mdna:184]
•a $57 million charge in 2018 related to ongoing remediation efforts for an environmental clean-up incurred by a legacy business (see Note 4 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-21-000008:mdna:185]
•$40 million of net reorganization of business charges in 2019 as compared to $61 million in 2018 (see Note 14 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information);

[0000068505-21-000008:mdna:186]
•$3 million of charges for acquisition-related transaction fees in 2019 as compared to $24 million in 2018; partially offset by

[0000068505-21-000008:mdna:187]
•$208 million of amortization of intangibles in 2019 compared to $188 million in 2018.

[0000068505-21-000008:mdna:188]
Operating Earnings

[0000068505-21-000008:mdna:189]
|  | Years ended December 31 |  |  |
| (In millions) | 2019 |  | 2018 |  |  |
| Operating earnings from Products and Systems Integration | $ | 994 |  |  | $ | 854 |  |  |  |
| Operating earnings from Software and Services | 587 |  |  | 401 |  |  |  |
| Operating earnings | $ | 1,581 |  |  | $ | 1,255 |  |  |  |

[0000068505-21-000008:mdna:190]
Operating earnings increased by $326 million, or 26%, in 2019 compared to 2018. The increase in Operating earnings was due to:

[0000068505-21-000008:mdna:191]
•Software and Services segment increased by $186 million from 2018 to 2019 due to higher sales and gross margin, as well as lower operating expenses driven by: (i) $17 million lower environmental reserve expenses, (ii) $11 million lower acquisition-related transaction fees, and (iii) $5 million lower reorganization of business expenses, partially offset by $4 million higher intangible amortization driven by acquisitions.

[0000068505-21-000008:mdna:192]
•Products and Systems Integration increased by $140 million from 2018 to 2019 due to higher sales and gross margin, as well as lower operating expenses driven by: (i) $40 million lower environmental reserve expenses, (ii) $15 million lower reorganization of business expenses, and (iii) $10 million lower acquisition-related transaction fees, partially offset by $16 million higher intangible amortization driven by acquisitions.

[0000068505-21-000008:mdna:193]
Interest Expense, net

[0000068505-21-000008:mdna:194]
|  | Years ended December 31 |  |  |
| (In millions) | 2019 |  | 2018 |  |  |
| Interest expense, net | $ | (220) |  |  | $ | (222) |  |  |  |

[0000068505-21-000008:mdna:195]
Interest expense, net in 2019 compared to 2018 remained relatively consistent given the similar average outstanding debt balance.

[0000068505-21-000008:mdna:196]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-21-000008:mdna:197]
|  | Years ended December 31 |  |
| (In millions) | 2019 |  | 2018 |  |
| Gains on sales of investments and businesses, net | $ | 5 |  |  | $ | 16 |  |  |

[0000068505-21-000008:mdna:198]
The net gains in 2019 and 2018 were primarily related to the sales of various equity investments.

[0000068505-21-000008:mdna:199]
Other, net

[0000068505-21-000008:mdna:200]
|  | Years ended December 31 |  |
| (In millions) | 2019 |  | 2018 |  |
| Other, net | $ | (365) |  |  | $ | 53 |  |  |

[0000068505-21-000008:mdna:201]
The change in net Other expense in 2019 as compared to net Other income in 2018 was primarily comprised of:

[0000068505-21-000008:mdna:202]
•$359 million U.S. pension settlement loss in 2019 (see Note 8 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information); and

[0000068505-21-000008:mdna:203]
•$46 million of net losses from repurchases of long term debt as compared to a gain of $6 million in 2018 (see Note 5 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-21-000008:mdna:204]
Effective Tax Rate

[0000068505-21-000008:mdna:205]
|  | Years ended December 31 |  |  |
| (In millions) | 2019 |  | 2018 |  |  |
| Income tax expense | $ | 130 |  |  | $ | 133 |  |  |  |

[0000068505-21-000008:mdna:206]
Income tax expense decreased by $3 million in 2019 as compared to 2018, for an effective tax rate of 13.0%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-21-000008:mdna:207]
•a $77 million benefit due to the partial release of a valuation allowance to our U.S. foreign tax credit carryforward (see Note 7 of our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information); and

[0000068505-21-000008:mdna:208]
•$27 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-21-000008:mdna:209]
Our effective tax rate in 2018 was 12.1% which is lower than the current U.S. federal statutory rate of 21% primarily related to:

[0000068505-21-000008:mdna:210]
•$79 million benefits related to updates of the provisional amounts on the impact of the Tax Cuts and Jobs Act of 2017; and

[0000068505-21-000008:mdna:211]
•$30 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-21-000008:mdna:212]
Reorganization of Businesses

[0000068505-21-000008:mdna:213]
In 2020, we recorded net reorganization of business charges of $86 million relating to the separation of 1,200 employees, of which 400 were indirect employees and 800 were direct employees. The $86 million of charges included $29 million recorded to Cost of sales and $57 million recorded to Other charges. Included in the aggregate $86 million are charges of $100 million for employee separation costs and $2 million for exit costs, partially offset by $16 million of reversals for accruals no longer needed.

[0000068505-21-000008:mdna:214]
During 2019, we recorded net reorganization of business charges of $57 million relating to the separation of 700 employees, of which 500 were indirect employees and 200 were direct employees. The $57 million of charges included $17 million recorded to Cost of sales and $40 million recorded to Other charges. Included in the aggregate $57 million were charges of $64 million for employee separation costs and $5 million for exit costs, partially offset by $12 million of reversals for accruals no longer needed.

[0000068505-21-000008:mdna:215]
During 2018, we recorded net reorganization of business charges of $120 million relating to the separation of 1,200 employees, of which 700 were indirect employees and 500 were direct employees. The $120 million of charges included $59 million recorded to Cost of sales and $61 million recorded to Other charges. Included in the aggregate $120 million are charges of $122 million for employee separation costs and $16 million for exit costs, partially offset by $18 million of reversals for accruals no longer needed. Also, included in the $120 million of charges for 2018 was a $44 million charge related to the announcement of our plan to close our Europe manufacturing facility which impacted 165 employees primarily within the Products and Systems Integration segment. The remainder of the initiatives impacted both of our segments and affected employees located in all geographic regions.

[0000068505-21-000008:mdna:216]
The following table displays the net charges incurred by business segment due to such reorganizations:

[0000068505-21-000008:mdna:217]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| Products and Systems Integration | $ | 69 |  |  | $ | 45 |  |  | $ | 101 |  |
| Software and Services | 17 |  |  | 12 |  |  | 19 |  |
|  | 86 |  |  | $ | 57 |  |  | $ | 120 |  |

[0000068505-21-000008:mdna:218]
Cash payments for employee severance in connection with the reorganization of business plans were $85 million, $63 million, and $65 million in 2020, 2019, and 2018, respectively. The reorganization of business accruals for employee separation costs at December 31, 2020 were $79 million which we expect to pay within one year.

[0000068505-21-000008:mdna:219]
Liquidity and Capital Resources

[0000068505-21-000008:mdna:220]
|  | Years Ended December 31 |
|  | 2020 |  | 2019 |  | 2018 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 1,613 |  |  | $ | 1,823 |  |  | $ | 1,075 |  |
| Investing activities | (437) |  |  | (934) |  |  | (1,266) |  |
| Financing activities | (966) |  |  | (1,144) |  |  | 220 |  |
| Effect of exchange rates on cash and cash equivalents | 43 |  |  | (1) |  |  | (40) |  |
| Increase (decrease) in cash and cash equivalents | $ | 253 |  |  | $ | (256) |  |  | $ | (11) |  |

[0000068505-21-000008:mdna:221]
Cash and Cash Equivalents

[0000068505-21-000008:mdna:222]
At December 31, 2020, $672 million of our $1.3 billion cash and cash equivalents balance was held in the U.S. and $582 million was held in other countries, with $203 million held in the United Kingdom. Restricted cash was $2 million at December 31, 2020 and December 31, 2019.

[0000068505-21-000008:mdna:223]
In 2020, we repatriated $395 million in cash to the U.S. from international jurisdictions. We routinely repatriate a portion of non-U.S. earnings each year. We have recorded income tax expense for foreign withholding tax and distribution taxes on such earnings and, under current U.S. tax laws, do not expect to incur material incremental U.S. tax on repatriation.

[0000068505-21-000008:mdna:224]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay due to local country approvals.

[0000068505-21-000008:mdna:225]
Operating Activities

[0000068505-21-000008:mdna:226]
The decrease in operating cash flows from 2019 to 2020 was driven by:

[0000068505-21-000008:mdna:227]
•a reduction of operating earnings as a result of lower sales volume;

[0000068505-21-000008:mdna:228]
•$43 million of higher income tax payments; and

[0000068505-21-000008:mdna:229]
•partially offset by improvements in working capital.

[0000068505-21-000008:mdna:230]
The increase in operating cash flows from 2018 to 2019 was driven by:

[0000068505-21-000008:mdna:231]
•$500 million debt-funded voluntary contribution to our U.S. pension plan in 2018 compared to no material contributions to our U.S. pension plan in 2019;

[0000068505-21-000008:mdna:232]
•higher operating earnings in 2019 as compared to 2018;

[0000068505-21-000008:mdna:233]
•$51 million settlement arising from a legacy business in 2018; and

[0000068505-21-000008:mdna:234]
•partially offset by $19 million of higher tax payments and $17 million of higher interest payments in 2019 compared to 2018.

[0000068505-21-000008:mdna:235]
Investing Activities

[0000068505-21-000008:mdna:236]
The decrease in net cash used by investing activities from 2019 to 2020 was primarily due to:

[0000068505-21-000008:mdna:237]
•$422 million decrease in acquisitions and investments, driven by acquisitions of $287 million in 2020 compared to $709 million in 2019;

[0000068505-21-000008:mdna:238]
•$56 million increase in proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in 2020; and

[0000068505-21-000008:mdna:239]
•$31 million decrease in capital expenditures in 2020 compared 2019 due to lower expenditures for the Airwave and ESN networks.

[0000068505-21-000008:mdna:240]
The decrease in net cash used by investing activities from 2018 to 2019 was primarily due to:

[0000068505-21-000008:mdna:241]
•$455 million decrease in acquisitions and investments, primarily driven by acquisitions of $709 million in 2019 compared to $1.2 billion in 2018;

[0000068505-21-000008:mdna:242]
•$79 million decrease in proceeds from sales of investments and businesses, driven by $60 million of excess cash received from Company-sponsored life insurance investments in 2018; and

[0000068505-21-000008:mdna:243]
•partially offset by $51 million higher capital expenditures in 2019 compared 2018, due to higher spend associated with revenue-generating networks within our Software and Services segment.

[0000068505-21-000008:mdna:244]
Financing Activities

[0000068505-21-000008:mdna:245]
The decrease in cash used by financing activities in 2020 compared to cash used by financing activities in 2019 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" in this section below):

[0000068505-21-000008:mdna:246]
•$400 million used for the repayment of the term loan in 2019;

[0000068505-21-000008:mdna:247]
•$1.0 billion received from the issuance of 1.75% senior convertible notes due 2024 in 2019 which was subsequently used for the settlement of $1.1 billion of the 2.00% senior convertible notes, inclusive of the $326 million conversion premium in 2019;

[0000068505-21-000008:mdna:248]
•$804 million net proceeds from the issuance of $800 million of 4.6% senior notes due 2029 in 2019, which was subsequently used to repurchase $614 million principal amount of long-term debt under a tender offer and $150 million principal amount for the 3.5% senior notes due 2021 for a total purchase price of $809 million in 2019;

[0000068505-21-000008:mdna:249]
•$892 million net proceeds from the issuance of $900 million of 2.30% senior notes due 2030 in the third quarter of 2020, which was subsequently used to repurchase $552 million principal amount of 2.75% senior notes due 2022 and $293 million principal amount of long-term debt under a tender offer for a total purchase price of $897 million in 2020;

[0000068505-21-000008:mdna:250]
•$800 million net proceeds from the draw on our syndicated, unsecured revolving credit facility during 2020 which was subsequently repaid during the year; and

[0000068505-21-000008:mdna:251]
•partially offset by $612 million used for purchases under our share repurchase program in 2020 as compared to $315 million in 2019; and

[0000068505-21-000008:mdna:252]
•$436 million cash used for the payment of dividends in 2020 as compared to $379 million in 2019.

[0000068505-21-000008:mdna:253]
The increase in cash from financing activities in 2019, as compared to cash used in financing activities in 2018 was driven by:

[0000068505-21-000008:mdna:254]
•$1.1 billion used for the settlement of the 2.00% senior convertible notes, inclusive of the $326 million conversion premium compared to the settlement of $369 million during 2018, inclusive of the $169 million conversion premium;

[0000068505-21-000008:mdna:255]
•$400 million used in 2019 for the repayment of the term loan, compared to the $400 million of proceeds received from the issuance of the term loan in 2018;

[0000068505-21-000008:mdna:256]
•$379 million of cash used for the payment of dividends in 2019 as compared to $337 million in 2018;

[0000068505-21-000008:mdna:257]
•$315 million used for purchases under our share repurchase program in 2019 as compared to $132 million in 2018; and

[0000068505-21-000008:mdna:258]
•partially offset by $1.0 billion received from the issuance of 1.75% senior convertible notes due 2024 in 2019;

[0000068505-21-000008:mdna:259]
•$700 million of proceeds received from the issuance of 4.6% senior notes due 2028 in 2018;

[0000068505-21-000008:mdna:260]
•$804 million net proceeds from the issuance of $800 million of 4.6% senior notes due 2029 in 2019, which was subsequently used to repurchase $614 million principal amount of long-term debt under a tender offer and $150 million principal amount for the 3.5% senior notes due 2021 for a total purchase price of $809 million in 2019; and

[0000068505-21-000008:mdna:261]
•$114 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2019, as compared to $168 million in 2018.

[0000068505-21-000008:mdna:262]
Sales of Receivables

[0000068505-21-000008:mdna:263]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-21-000008:mdna:264]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2020, 2019, and 2018:

[0000068505-21-000008:mdna:265]
| Years ended December 31 | 2020 |  | 2019 |  | 2018 |
| Contract-specific discounting facility | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Accounts receivable sales proceeds | 74 |  |  | 34 |  |  | 77 |  |
| Long-term receivables sales proceeds | 181 |  |  | 265 |  |  | 270 |  |
| Total proceeds from receivable sales | $ | 483 |  |  | $ | 299 |  |  | $ | 347 |  |

[0000068505-21-000008:mdna:266]
During the year ended December 31, 2020, we utilized a new cost-efficient receivable discounting facility to neutralize the impact of increased payment terms under a renegotiated and extended long-term contract in Europe resulting in accounts receivable sales of $228 million during the year ended December 31, 2020. The net benefit to our operating cash flow from the utilization of the new receivable discounting facility during 2020, was an inflow of $61 million when adjusted for amounts that would still be collected from the customer within the period in the absence of utilizing the discounting facility. The proceeds of our receivable sales are included in "Operating Activities" within our Consolidated Statements of Cash Flows.

[0000068505-21-000008:mdna:267]
At December 31, 2020, the Company had retained servicing obligations for $983 million of long-term receivables, compared to $984 million of long-term receivables at December 31, 2019. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-21-000008:mdna:268]
Debt

[0000068505-21-000008:mdna:269]
We had outstanding long-term debt of $5.2 billion and $5.1 billion, including the current portions of $12 million and $16 million, at December 31, 2020 and December 31, 2019, respectively.

[0000068505-21-000008:mdna:270]
In May of 2019, we issued $650 million of 4.60% senior notes due 2029. We received proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to repurchase $614 million in principal amount of our outstanding long-term debt for a purchase price of $654 million, excluding $3 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of $43 million related to this repurchase in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-21-000008:mdna:271]
In August of 2019, we issued a follow-on of $150 million to the outstanding 4.60% senior notes due 2029 bringing the total outstanding principal to $800 million. We recognized net proceeds of $159 million after debt premiums and debt issuance costs. These proceeds were then used to repurchase the remaining $150 million principal amount of the 3.5% senior notes due 2021 for a purchase price of $155 million, excluding $2 million of accrued interest. After accelerating the amortization of debt issuance costs, we recognized a loss of $7 million related to this repurchase in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-21-000008:mdna:272]
On September 5, 2019, in connection with our repurchase and settlement of the outstanding principal amount of 2.00% senior convertible notes due 2020 issued to Silver Lake Partners, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 (the "New Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share). In the event of conversion, we intend to settle the principal amount of the New Senior Convertible Notes in cash. We recorded a debt liability associated with the New Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.45%, which was determined based on a review of relevant market data, we calculated the debt liability to be $986 million, indicating a $14 million discount to be amortized over the expected life of the debt instrument. The remaining proceeds of $14 million were allocated to the conversion option and accordingly, increased our additional paid-in capital.

[0000068505-21-000008:mdna:273]
In August of 2020, we issued $900 million of 2.30% senior notes due 2030. We recognized net proceeds of $892 million after debt issuance costs and debt discounts. A portion of these proceeds were then used to redeem $552 million in principal amount outstanding of the 3.75% senior notes due 2022 for a redemption price of $582 million, excluding $7 million of accrued interest. The remaining proceeds were used to repurchase $293 million in principal amount outstanding of our long-term debt under a tender offer, for a purchase price of $315 million, excluding $5 million of accrued interest. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of $56 million related to the redemption and the repurchase in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-21-000008:mdna:274]
We have an unsecured commercial paper program, backed by the revolving credit facility described below, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2020, we had no outstanding debt under the commercial paper program.

[0000068505-21-000008:mdna:275]
Credit Facilities

[0000068505-21-000008:mdna:276]
As of December 31, 2020, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. Following the turmoil in the financial markets caused by the COVID-19 pandemic, we borrowed $800 million under the facility to bolster our cash holdings out of precaution in the first quarter of 2020, of which the full $800 million was repaid during the year ended December 31, 2020. The weighted average borrowing rate for amounts outstanding during the year ended December 31, 2020 was 1.70%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with the financial covenants as of December 31, 2020.

[0000068505-21-000008:mdna:277]
Share Repurchase Program

[0000068505-21-000008:mdna:278]
Through a series of actions, the board of directors has authorized an aggregate share repurchase amount of up to $14.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2020, we used approximately $13.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $649 million of authority available for future repurchases.

[0000068505-21-000008:mdna:279]
Our share repurchases, including transaction costs, for 2020, 2019, and 2018 are summarized as follows:

[0000068505-21-000008:mdna:280]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2020 | 3.9 |  |  | $ | 155.93 |  |  | $ | 612 |  |
| 2019 | 2.3 |  |  | 137.35 |  |  | 315 |  |
| 2018 | 1.2 |  |  | 112.42 |  |  | 132 |  |

[0000068505-21-000008:mdna:281]
Dividends

[0000068505-21-000008:mdna:282]
We paid cash dividends to holders of our common stock of $436 million in 2020, $379 million in 2019, and $337 million in 2018. On January 15, 2020, we paid an additional $120 million in cash dividends to holders of our common stock.

[0000068505-21-000008:mdna:283]
Adequate Internal Funding Resources

[0000068505-21-000008:mdna:284]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the $2.2 billion revolving credit facility. Refer also to “COVID-19” in this section of the Form 10-K for a discussion of the impact of COVID-19 on our liquidity.

[0000068505-21-000008:mdna:285]
43

[0000068505-21-000008:mdna:286]
Contractual Obligations and Other Purchase Commitments

[0000068505-21-000008:mdna:287]
Summarized in the table and text below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2020.

[0000068505-21-000008:mdna:288]
|  | Payments Due by Period |
| (in millions) | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations, gross | $ | 5,228 |  |  | $ | 12 |  |  | $ | 4 |  |  | $ | 326 |  |  | $ | 1,588 |  |  | $ | 322 |  |  | $ | — |  |  | $ | 2,976 |  |
| Lease obligations | 586 |  |  | 141 |  |  | 127 |  |  | 73 |  |  | 59 |  |  | 47 |  |  | — |  |  | 139 |  |
| Purchase obligations* | 209 |  |  | 50 |  |  | 52 |  |  | 50 |  |  | 51 |  |  | 6 |  |  | — |  |  | — |  |
| Tax obligations | 64 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 64 |  |  | — |  |
| Total contractual obligations | $ | 6,087 |  |  | $ | 203 |  |  | $ | 183 |  |  | $ | 449 |  |  | $ | 1,698 |  |  | $ | 375 |  |  | $ | 64 |  |  | $ | 3,115 |  |

[0000068505-21-000008:mdna:289]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-21-000008:mdna:290]
Lease Obligations:  We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations as of December 31, 2020 totaled $586 million. Rental expense, net of sublease income, was $128 million in 2020, $133 million in 2019, and $108 million in 2018.

[0000068505-21-000008:mdna:291]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. In addition, we have entered into license agreements which are firm commitments and are not cancellable. We have entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2025. The total payments expected to be made under these agreements as of December 31, 2020 were $209 million. We do not anticipate the cancellation of any of our take-or-pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-21-000008:mdna:292]
Tax Obligations:  We had approximately $64 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years as of December 31, 2020. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact (within the next twelve months) on the effective tax rate, exclusive of valuation allowance changes, is estimated to be up to a $13 million tax benefit.

[0000068505-21-000008:mdna:293]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take-or-pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-21-000008:mdna:294]
We outsource certain corporate functions, such as benefit administration and information technology-related services, under third-party contracts, the longest of which is expected to expire in 2023. Our remaining payments under these contracts are approximately $41 million over the remaining life of the contracts as of December 31, 2020; however, these contracts can be terminated. Termination would result in penalties substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-21-000008:mdna:295]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance bonds, bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. Outstanding Performance Bonds totaled approximately $2.6 billion as of December 31, 2020 and $2.5 billion as of December 31, 2019. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-21-000008:mdna:296]
Off-Balance Sheet Arrangements:  At December 31, 2020, we had no off-balance sheet arrangements that have or are reasonably likely to have a material effect on our consolidated financial condition, changes in financial condition, results of operations, liquidity, capital expenditures or capital resources, other than our obligation to settle the conversion option under the New Senior Convertible Notes described in Note 5 to the consolidated financial statements “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-21-000008:mdna:297]
Other Contingencies

[0000068505-21-000008:mdna:298]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-21-000008:mdna:299]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us.

[0000068505-21-000008:mdna:300]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on our results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-21-000008:mdna:301]
Long-term Customer Financing Commitments

[0000068505-21-000008:mdna:302]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $78 million at December 31, 2020 and at December 31, 2019.

[0000068505-21-000008:mdna:303]
Critical Accounting Policies

[0000068505-21-000008:mdna:304]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-21-000008:mdna:305]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-21-000008:mdna:306]
Revenue Recognition

[0000068505-21-000008:mdna:307]
We enter into arrangements which consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we generally allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-21-000008:mdna:308]
We account for certain system contracts on an over-time basis, electing an input method of estimated costs as a measure of performance completed. The selection of the measurement of progress using estimated costs was based on a thorough consideration of alternatives of various output and input measures, including contract milestones and labor hours. However, we have determined that other input and output measures are not an appropriate measure of progress as they do not accurately align with the transfer of control on our customized systems. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-21-000008:mdna:309]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs at Completion”). Total Estimated Costs at Completion include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs at Completion may be complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management

[0000068505-21-000008:mdna:310]
45

[0000068505-21-000008:mdna:311]
reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of work to be performed, the availability and cost of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-21-000008:mdna:312]
Retirement Benefits

[0000068505-21-000008:mdna:313]
Our benefit obligations and net periodic pension costs (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions. The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-21-000008:mdna:314]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-21-000008:mdna:315]
There are various assumptions used in calculating the net periodic costs (benefits) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.  We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-21-000008:mdna:316]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost (benefit) and the net postretirement health care benefit. Our investment return assumption for the U.S. Pension Benefit Plans was 6.85% in each of 2020 and 2019. Our investment return assumption for the Postretirement Health Care Benefits Plan was 6.90% in each of 2020 and 2019. Our weighted average investment return assumption for the Non-U.S. Plans was 4.66% in 2020 and 5.23% in 2019.

[0000068505-21-000008:mdna:317]
A second key assumption is the discount rate. The discount rate assumptions used for the U.S. Pension Benefit Plans, the Non-U.S. Plans and the Postretirement Health Care Benefits Plan reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 2.63% and 3.32% at December 31, 2020 and 2019, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 1.24% and 1.82% at December 31, 2020 and 2019, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 2.39% and 3.15% at December 31, 2020 and 2019, respectively.

[0000068505-21-000008:mdna:318]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from ten to thirty years. Prior service costs are being amortized over periods ranging from one to twenty-nine years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-21-000008:mdna:319]
Valuation and Recoverability of Goodwill

[0000068505-21-000008:mdna:320]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: (i) adverse changes in macroeconomic conditions, (ii) adverse changes in the industry or market in which we transact, (iii) changes in cost factors negatively impacting earnings and cash flows, (iv) negative or declining overall financial performance, (v) events affecting the carrying value or composition of a reporting unit, or (vi) a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-21-000008:mdna:321]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Software and Services segments are comprised of three and two reporting units, respectively. The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2020, 2019, and 2018. In performing this qualitative assessment we assessed relevant events and

[0000068505-21-000008:mdna:322]
circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal years 2020, 2019, and 2018, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-21-000008:mdna:323]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-21-000008:mdna:324]
We use the asset and liability method of accounting for income taxes. Under this method, income tax expense is recognized for the amount of taxes payable or refundable for the current year. In addition, deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Management makes assumptions, judgments and estimates to determine our current and deferred tax provision and also the deferred tax assets and liabilities. We evaluate our deferred tax assets quarterly to determine if adjustments to our valuation allowance are required based on the consideration of all available positive and negative evidence.

[0000068505-21-000008:mdna:325]
Our assumptions, judgments and estimates for computing the income tax provision takes into account current tax laws, our interpretation of current tax law and possible outcomes of current and future audits conducted by foreign and domestic tax authorities. We believe such estimates to be reasonable; however, the final determination of certain audits could significantly impact the amounts provided for income taxes in our financial statements.

[0000068505-21-000008:mdna:326]
Recent Accounting Pronouncements

[0000068505-21-000008:mdna:327]
See “Note 1: Summary of Significant Accounting Policies” in “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-21-000008:mdna:328]
47
