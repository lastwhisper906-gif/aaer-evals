# MSI MD&A — 0000068505-17-000017


## mdna

[0000068505-17-000017:mdna:1]
[same as prior period, unchanged from 0000068505-17-000011:mdna:1]

[0000068505-17-000017:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 30, 2017 and October 1, 2016, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2016.

[0000068505-17-000017:mdna:3]
[same as prior period, unchanged from 0000068505-17-000011:mdna:3]

[0000068505-17-000017:mdna:4]
[same as prior period, unchanged from 0000068505-17-000011:mdna:4]

[0000068505-17-000017:mdna:5]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 15,000 employees worldwide, based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-17-000017:mdna:6]
[same as prior period, unchanged from 0000068505-17-000011:mdna:6]

[0000068505-17-000017:mdna:7]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the third quarter of 2017, the segment’s net sales were $989 million, representing 60% of our consolidated net sales.

[0000068505-17-000017:mdna:8]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the third quarter of 2017, the segment’s net sales were $656 million, representing 40% of our consolidated net sales.

[0000068505-17-000017:mdna:9]
[same as prior period, unchanged from 0000068505-17-000011:mdna:9]

[0000068505-17-000017:mdna:10]
[same as prior period, unchanged from 0000068505-17-000011:mdna:10]

[0000068505-17-000017:mdna:11]
Focus on Managed & Support Services and Software: Services continues to grow at a faster rate than the Products segment, driven by acquisitions and growth in Managed & Support services absent of acquisitions. While Services generally experiences lower gross margins than our Products segment, we expect revenue growth will continue to drive operating margin expansion. During the nine months ended September 30, 2017, we experienced revenue growth of 9% in our Services segment.

[0000068505-17-000017:mdna:12]
[same as prior period, unchanged from 0000068505-17-000011:mdna:12]

[0000068505-17-000017:mdna:13]
[same as prior period, unchanged from 0000068505-17-000011:mdna:13]

[0000068505-17-000017:mdna:14]
On July 28, 2017, we announced our intention to purchase Plant Holdings, Inc., the parent company of Airbus DS Communications. This acquisition will expand our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

[0000068505-17-000017:mdna:15]
Third Quarter Summary

[0000068505-17-000017:mdna:16]
| • | Net sales were $1.6 billion in the third quarter of 2017, up $113 million, or 7%, from the third quarter of 2016. |

[0000068505-17-000017:mdna:17]
| • | We generated operating earnings of $338 million, or 21% of net sales, in the third quarter of 2017, compared to $341 million, or 22% of net sales, in the third quarter of 2016. |

[0000068505-17-000017:mdna:18]
| • | We had net earnings attributable to Motorola Solutions, Inc. of $212 million, or $1.25 per diluted common share, in the third quarter of 2017, compared to $192 million, or $1.13 per diluted common share, in the third quarter of 2016. |

[0000068505-17-000017:mdna:19]
| • | We generated net cash from operating activities of $585 million during the first nine months of 2017, compared to $652 million in the first nine months of 2016. |

[0000068505-17-000017:mdna:20]
| • | We returned $588 million in capital to shareholders through dividends and share repurchases during the first nine months of 2017. |

[0000068505-17-000017:mdna:21]
[same as prior period, unchanged from 0000068505-17-000011:mdna:22]

[0000068505-17-000017:mdna:22]
| • | Products: Net sales were $989 million in the third quarter of 2017, an increase of $69 million, or 8% compared to net sales of $920 million during the third quarter of 2016. On a geographic basis, net sales increased in the Americas and Europe, Middle East and Africa ("EMEA") and were flat in Asia Pacific ("AP"), compared to the year-ago quarter. |

[0000068505-17-000017:mdna:23]
| • | Services: Net sales were $656 million in the third quarter of 2017, an increase of $44 million, or 7% compared to net sales of $612 million in the third quarter of 2016. On a geographic basis, net sales increased in the Americas and AP and decreased in EMEA, compared to the year-ago quarter. |

[0000068505-17-000017:mdna:24]
[same as prior period, unchanged from 0000068505-17-000011:mdna:25]

[0000068505-17-000017:mdna:25]
[same as prior period, unchanged from 0000068505-17-000011:mdna:26]

[0000068505-17-000017:mdna:26]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 30, 2017 |  | % ofSales* |  | October 1, 2016 |  | % ofSales* |  | September 30, 2017 |  | % ofSales* |  | October 1, 2016 |  | % ofSales* |
| Net sales from products | $ | 989 |  |  |  |  | $ | 920 |  |  |  |  | $ | 2,540 |  |  |  |  | $ | 2,423 |  |  |  |
| Net sales from services | 656 |  |  |  |  | 612 |  |  |  |  | 1,883 |  |  |  |  | 1,732 |  |  |  |
| Net sales | 1,645 |  |  |  |  | 1,532 |  |  |  |  | 4,423 |  |  |  |  | 4,155 |  |  |  |
| Costs of products sales | 428 |  |  | 43.3 | % |  | 398 |  |  | 43.3 | % |  | 1,167 |  |  | 45.9 | % |  | 1,124 |  |  | 46.4 | % |
| Costs of services sales | 423 |  |  | 64.5 | % |  | 372 |  |  | 60.8 | % |  | 1,202 |  |  | 63.8 | % |  | 1,090 |  |  | 62.9 | % |
| Costs of sales | 851 |  |  |  |  | 770 |  |  |  |  | 2,369 |  |  |  |  | 2,214 |  |  |  |
| Gross margin | 794 |  |  | 48.3 | % |  | 762 |  |  | 49.7 | % |  | 2,054 |  |  | 46.4 | % |  | 1,941 |  |  | 46.7 | % |
| Selling, general and administrative expenses | 248 |  |  | 15.1 | % |  | 247 |  |  | 16.1 | % |  | 725 |  |  | 16.4 | % |  | 722 |  |  | 17.4 | % |
| Research and development expenditures | 141 |  |  | 8.6 | % |  | 137 |  |  | 8.9 | % |  | 413 |  |  | 9.3 | % |  | 411 |  |  | 9.9 | % |
| Other charges | 67 |  |  | 4.1 | % |  | 37 |  |  | 2.4 | % |  | 146 |  |  | 3.3 | % |  | 144 |  |  | 3.5 | % |
| Operating earnings | 338 |  |  | 20.5 | % |  | 341 |  |  | 22.3 | % |  | 770 |  |  | 17.4 | % |  | 664 |  |  | 16.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (52 | ) |  | (3.2 | )% |  | (54 | ) |  | (3.5 | )% |  | (154 | ) |  | (3.5 | )% |  | (157 | ) |  | (3.8 | )% |
| Gains (losses) on sales of investments and businesses, net | — |  |  | — | % |  | 7 |  |  | 0.5 | % |  | 3 |  |  | 0.1 | % |  | (13 | ) |  | (0.3 | )% |
| Other | — |  |  | — | % |  | (1 | ) |  | (0.1 | )% |  | (9 | ) |  | (0.2 | )% |  | (12 | ) |  | (0.3 | )% |
| Total other expense | (52 | ) |  | (3.2 | )% |  | (48 | ) |  | (3.1 | )% |  | (160 | ) |  | (3.6 | )% |  | (182 | ) |  | (4.4 | )% |
| Earnings before income taxes | 286 |  |  | 17.4 | % |  | 293 |  |  | 19.1 | % |  | 610 |  |  | 13.8 | % |  | 482 |  |  | 11.6 | % |
| Income tax expense | 73 |  |  | 4.4 | % |  | 100 |  |  | 6.5 | % |  | 188 |  |  | 4.3 | % |  | 164 |  |  | 3.9 | % |
| Net earnings | 213 |  |  | 12.9 | % |  | 193 |  |  | 12.6 | % |  | 422 |  |  | 9.5 | % |  | 318 |  |  | 7.7 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 2 |  |  | — | % |  | 1 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 212 |  |  | 12.9 | % |  | $ | 192 |  |  | 12.5 | % |  | $ | 420 |  |  | 9.5 | % |  | $ | 317 |  |  | 7.6 | % |
| Earnings per diluted common share | $ | 1.25 |  |  |  |  |  | $ | 1.13 |  |  |  |  |  | $ | 2.48 |  |  |  |  | $ | 1.82 |  |  |  |

[0000068505-17-000017:mdna:27]
[same as prior period, unchanged from 0000068505-17-000011:mdna:28]

[0000068505-17-000017:mdna:28]
[same as prior period, unchanged from 0000068505-17-000011:mdna:29]

[0000068505-17-000017:mdna:29]
Results of Operations—Three months ended September 30, 2017 compared to three months ended October 1, 2016

[0000068505-17-000017:mdna:30]
The results of operations for the third quarter of 2017 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-17-000017:mdna:31]
[same as prior period, unchanged from 0000068505-17-000011:mdna:32]

[0000068505-17-000017:mdna:32]
Net sales were $1.6 billion in the third quarter of 2017, a $113 million, or 7%, increase compared to the third quarter of 2016, reflecting solid demand across the globe for our products and services. The increase in net sales is reflective of growth in every region. Systems net sales within the Products segment increased in the Americas, partially offset by decreases in EMEA and AP. Devices net sales within the Products segment increased in every region. The Services segment increased in the Americas and AP, partially offset by a decrease in EMEA. The Services segment net sales increase in the Americas was driven by the acquisition of Interexport, Spillman Technologies, Inc. and Kodiak Networks and growth in both Managed & Support services and Integration services absent of acquisitions. The Services segment net sales increase in AP was driven by growth in Integration services. The Services segment net sales decrease in EMEA was due to a decrease in Airwave related to unfavorable foreign exchange rates in the third quarter of 2017.

[0000068505-17-000017:mdna:33]
[same as prior period, unchanged from 0000068505-17-000011:mdna:34]

[0000068505-17-000017:mdna:34]
Gross margin was $794 million, or 48.3% of net sales, in the third quarter of 2017, compared to $762 million, or 49.7% of net sales, in the third quarter of 2016. The decrease in gross margin percentage was driven by margins in the Services segment returning to normalized levels.

[0000068505-17-000017:mdna:35]
[same as prior period, unchanged from 0000068505-17-000011:mdna:36]

[0000068505-17-000017:mdna:36]
SG&A expenses were $248 million, or 15.1% of net sales, in the third quarter of 2017, compared to $247 million, or 16.1% of net sales, in the third quarter of 2016.

[0000068505-17-000017:mdna:37]
[same as prior period, unchanged from 0000068505-17-000011:mdna:38]

[0000068505-17-000017:mdna:38]
R&D expenditures were $141 million, or 8.6% of net sales, in the third quarter of 2017 and $137 million, or 8.9% of net sales, in the third quarter of 2016. The increase in R&D expenditures is due to higher expenses associated with acquired businesses.

[0000068505-17-000017:mdna:39]
[same as prior period, unchanged from 0000068505-17-000011:mdna:40]

[0000068505-17-000017:mdna:40]
We recorded net charges of $67 million in the third quarter of 2017, compared to net charges of $37 million in the third quarter of 2016. The net Other charges in the third quarter of 2017 were primarily driven by: (i) $39 million of charges relating to the amortization of intangibles, (ii) $21 million of charges relating to the Non-U.S. pension settlement loss, and (iii) $6 million of net reorganization of business charges. The net charges in the third quarter of 2016 of $37 million included: (i) $31 million of charges relating to the amortization of intangibles and (ii) $6 million of net reorganization of business charges. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-17-000017:mdna:41]
[same as prior period, unchanged from 0000068505-17-000011:mdna:42]

[0000068505-17-000017:mdna:42]
Net interest expense was $52 million in the third quarter of 2017 and $54 million in the third quarter of 2016. The decrease in net interest expense in the third quarter of 2017 as compared to the third quarter of 2016 was a result of lower outstanding debt, due to the repayment of $675 million of a term loan at the end of 2016.

[0000068505-17-000017:mdna:43]
[same as prior period, unchanged from 0000068505-17-000011:mdna:44]

[0000068505-17-000017:mdna:44]
Net gains on sales of investments and businesses were de minimus in the third quarter of 2017 compared to net gains of $7 million in the third quarter of 2016. The net gains in the third quarter of 2016 were related to sales of equity investments.

[0000068505-17-000017:mdna:45]
[same as prior period, unchanged from 0000068505-17-000011:mdna:46]

[0000068505-17-000017:mdna:46]
Net Other income was de minimus in the third quarter of 2017, compared to an expense of $1 million in the third quarter of 2016. The net other income in the third quarter of 2017 was primarily comprised of: (i) a $3 million gain on derivative instruments and (ii) $3 million of other non-operating income, offset by a $7 million foreign currency loss. The net Other expense in the third quarter of 2016 was comprised of: (i) an $11 million loss on derivative instruments and (ii) a $2 million investment impairment, partially offset by: (a) a $7 million foreign currency gain and (b) $5 million of other non-operating gains.

[0000068505-17-000017:mdna:47]
[same as prior period, unchanged from 0000068505-17-000011:mdna:48]

[0000068505-17-000017:mdna:48]
We recorded $73 million of net tax expense in the third quarter of 2017, resulting in an effective tax rate of 26%, compared to $100 million of net tax expense in the third quarter of 2016, resulting in an effective tax rate of 34%. Our effective tax rate in the third quarter of 2017 was lower than the U.S. statutory tax rate of 35% primarily driven by a tax benefit due to the recognition of a U.S. capital loss. Our effective tax rate in the third quarter of 2016 was lower than the U.S. statutory tax rate of 35% partly due to favorable discrete adjustments to deferred tax assets of foreign subsidiaries.

[0000068505-17-000017:mdna:49]
[same as prior period, unchanged from 0000068505-17-000011:mdna:50]

[0000068505-17-000017:mdna:50]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $212 million, or $1.25 per diluted share, in the third quarter of 2017, compared to net earnings attributable to Motorola Solutions, Inc. of $192 million, or $1.13 per diluted share, in the third quarter of 2016.

[0000068505-17-000017:mdna:51]
The increase in net earnings in the third quarter of 2017, as compared to the third quarter of 2016, was primarily driven by higher sales in both the Products and Services segments. The increase in net earnings per diluted share was driven by higher net earnings and lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-17-000017:mdna:52]
Results of Operations—Nine months ended September 30, 2017 compared to nine months ended October 1, 2016

[0000068505-17-000017:mdna:53]
[same as prior period, unchanged from 0000068505-17-000011:mdna:54]

[0000068505-17-000017:mdna:54]
Net sales were $4.4 billion in the first nine months of 2017, a $268 million, or 6%, increase compared to the first nine months of 2016. The increase in net sales is reflective of growth in every region. Within the Products segment, Devices net sales increased in each region while Systems net sales increased in the Americas and EMEA. The Services segment increased in the Americas and EMEA, partially offset by a decrease in AP. The Services segment net sales increase in the Americas was driven by the acquisition of Interexport, Spillman Technologies, Inc. and Kodiak Networks and growth in both Managed & Support services and Integration services absent of acquisitions. The Services segment net sales increase in EMEA was driven by Airwave and growth in Managed & Support services and Integration services absent of acquisitions. The Services segment net sales decrease in AP was due to lower Integration sales.

[0000068505-17-000017:mdna:55]
[same as prior period, unchanged from 0000068505-17-000011:mdna:56]

[0000068505-17-000017:mdna:56]
Gross margin was $2.1 billion, or 46.4% of net sales, in the first nine months of 2017, compared to $1.9 billion, or 46.7% of net sales, in the first nine months of 2016.

[0000068505-17-000017:mdna:57]
[same as prior period, unchanged from 0000068505-17-000011:mdna:58]

[0000068505-17-000017:mdna:58]
SG&A expenses were $725 million, or 16.4% of net sales, in the first nine months of 2017, compared to $722 million, or 17.4% of net sales, in the first nine months of 2016. SG&A expenditures increased due to expenses associated with acquired businesses.

[0000068505-17-000017:mdna:59]
[same as prior period, unchanged from 0000068505-17-000011:mdna:60]

[0000068505-17-000017:mdna:60]
R&D expenditures were $413 million, or 9.3% of net sales, in the first nine months of 2017 and $411 million, or 9.9% of net sales, in the first nine months of 2016. R&D expenditures increased due to increased expenses associated with acquired businesses.

[0000068505-17-000017:mdna:61]
[same as prior period, unchanged from 0000068505-17-000011:mdna:62]

[0000068505-17-000017:mdna:62]
We recorded net charges of $146 million in the first nine months of 2017, compared to net charges of $144 million in the first nine months of 2016. The net Other charges in the first nine months of 2017 were primarily driven by: (i) $112 million of charges relating to the amortization of intangibles, (ii) $46 million of charges relating to the Non-U.S. pension settlement loss, (iii)  $22 million of net reorganization of business charges, and (iv) $8 million of charges related to a building impairment, partially offset by a net gain of $44 million, related to legal settlements, including the $42 million legal settlement related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to us by a former customer of our legacy Networks business. The net charges in the first nine months of 2016 of $144 million included: (i) $83 million of charges relating to the amortization of intangibles, (ii) $48 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment of the corporate aircraft, and (iii) $13 million of transaction fees on the acquisition of Airwave. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-17-000017:mdna:63]
[same as prior period, unchanged from 0000068505-17-000011:mdna:64]

[0000068505-17-000017:mdna:64]
Net interest expense was $154 million in the first nine months of 2017 and $157 million in the first nine months of 2016. The decrease in net interest expense in the first nine months of 2017 as compared to the first nine months of 2016 was a result of lower outstanding debt, due to the repayment of $675 million of a term loan at the end of 2016.

[0000068505-17-000017:mdna:65]
[same as prior period, unchanged from 0000068505-17-000011:mdna:66]

[0000068505-17-000017:mdna:66]
Net gains on sales of investments and businesses were $3 million in the first nine months of 2017 compared to net losses of $13 million in the first nine months of 2016. The net gains in the first nine months of 2017 were primarily related to the sales of various equity investments. The net losses in the first nine months of 2016 consisted of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities and (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $13 million of gains on the sale of an equity investment.

[0000068505-17-000017:mdna:67]
[same as prior period, unchanged from 0000068505-17-000011:mdna:68]

[0000068505-17-000017:mdna:68]
Net Other expense was $9 million in the first nine months of 2017, compared to $12 million in the first nine months of 2016. The net Other expense in the first nine months of 2017 was primarily comprised of a $29 million foreign currency loss offset by: (i) a $14 million gain on derivative investments and (ii) $5 million of other non-operating income. The net Other expense in the

[0000068505-17-000017:mdna:69]
first nine months of 2016 was comprised of: (i) a $41 million loss on derivative instruments, (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave, and (iii) a $2 million investment impairment, partially offset by: (a) a $34 million foreign currency gain, (b) a $2 million gain on equity method investments, and (c) $5 million of other non-operating gains.

[0000068505-17-000017:mdna:70]
[same as prior period, unchanged from 0000068505-17-000011:mdna:70]

[0000068505-17-000017:mdna:71]
We recorded $188 million of net tax expense in the first nine months of 2017, resulting in an effective tax rate of 31%, compared to $164 million of net tax expense in the first nine months of 2016, resulting in an effective tax rate of 34%. Our effective tax rate in the first nine months of 2017 was lower than the U.S. statutory tax rate of 35% primarily due to a tax benefit due to the recognition of a U.S. capital loss. Our effective tax rate in the first nine months of 2016 was lower than the U.S. statutory tax rate of 35% partly due to the recognition of excess tax benefits on share-based compensation.

[0000068505-17-000017:mdna:72]
[same as prior period, unchanged from 0000068505-17-000011:mdna:72]

[0000068505-17-000017:mdna:73]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $420 million, or $2.48 per diluted share, in the first nine months of 2017, compared to net earnings attributable to Motorola Solutions, Inc. of $317 million, or $1.82 per diluted share, in the first nine months of 2016.

[0000068505-17-000017:mdna:74]
The increase in net earnings in the first nine months of 2017, as compared to the first nine months of 2016, was primarily driven by an increase in sales in both the Products and Services segments. The increase in net earnings per diluted share was driven by an increase in net earnings and lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-17-000017:mdna:75]
[same as prior period, unchanged from 0000068505-17-000011:mdna:75]

[0000068505-17-000017:mdna:76]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and nine months ended September 30, 2017 and October 1, 2016, as detailed in Note 11, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-17-000017:mdna:77]
[same as prior period, unchanged from 0000068505-17-000011:mdna:77]

[0000068505-17-000017:mdna:78]
The segment’s net sales represented 60% of our consolidated net sales for both the third quarter of 2017 and the third quarter of 2016. For the first nine months of 2017, the segment’s net sales represented 57% of our consolidated net sales, compared to 58% of our consolidated net sales for the first nine months of 2016.

[0000068505-17-000017:mdna:79]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | September 30, 2017 |  | October 1, 2016 |  | % Change |  | September 30, 2017 |  | October 1, 2016 |  | % Change |
| Segment net sales | $ | 989 |  |  | $ | 920 |  |  | 8 | % |  | $ | 2,540 |  |  | $ | 2,423 |  |  | 5 | % |
| Operating earnings | 253 |  |  | 225 |  |  | 12 | % |  | 510 |  |  | 404 |  |  | 26 | % |

[0000068505-17-000017:mdna:80]
Three months ended September 30, 2017 compared to three months ended October 1, 2016

[0000068505-17-000017:mdna:81]
The segment’s net sales increased $69 million, to $989 million in the third quarter of 2017, as compared to $920 million during the third quarter of 2016. The increase in the segment's net sales was driven by an increase in both Systems and Devices sales. Systems net sales increased in the Americas, partially offset by decreases in EMEA and AP. Devices net sales increased in every region.

[0000068505-17-000017:mdna:82]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 75% of the segment’s net sales in both the third quarter of 2017 and the third quarter of 2016.

[0000068505-17-000017:mdna:83]
The segment had operating earnings of $253 million in the third quarter of 2017, compared to $225 million in the third quarter of 2016. The increase in operating earnings was primarily driven by higher sales and lower R&D expenditures.

[0000068505-17-000017:mdna:84]
Nine months ended September 30, 2017 compared to nine months ended October 1, 2016

[0000068505-17-000017:mdna:85]
The segment’s net sales increased $117 million, to $2.5 billion in the first nine months of 2017, as compared to $2.4 billion during the first nine months of 2016. On a geographic basis, net sales increased in all regions for the first nine months of 2017, compared to the first nine months of 2016.  Devices net sales increased in each region while Systems net sales increased in the Americas and EMEA.

[0000068505-17-000017:mdna:86]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in the first nine months of 2017 and 75% in the first nine months of 2016.

[0000068505-17-000017:mdna:87]
The segment had operating earnings of $510 million in the first nine months of 2017, compared to $404 million in the first nine months of 2016. The increase in operating earnings was primarily driven by higher net sales and lower SG&A expenses, R&D expenditures, and Other charges.

[0000068505-17-000017:mdna:88]
[same as prior period, unchanged from 0000068505-17-000011:mdna:88]

[0000068505-17-000017:mdna:89]
The segment’s net sales represented 40% of our consolidated net sales for both the third quarter of 2017 and the third quarter of 2016. For the first nine months of 2017, the segment’s net sales represented 43% of our consolidated net sales, compared to 42% of our consolidated net sales for the first nine months of 2016.

[0000068505-17-000017:mdna:90]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | September 30, 2017 |  | October 1, 2016 |  | % Change |  | September 30, 2017 |  | October 1, 2016 |  | % Change |
| Segment net sales | $ | 656 |  |  | $ | 612 |  |  | 7 | % |  | $ | 1,883 |  |  | $ | 1,732 |  |  | 9 | % |
| Operating earnings | 85 |  |  | 116 |  |  | (27 | )% |  | 260 |  |  | 260 |  |  | — | % |

[0000068505-17-000017:mdna:91]
Three months ended September 30, 2017 compared to three months ended October 1, 2016

[0000068505-17-000017:mdna:92]
The segment’s net sales increased $44 million, or 7%, to $656 million in the third quarter of 2017, as compared to $612 million in the third quarter of 2016. The increase in the segment's net sales was driven by the acquisition of Interexport, Spillman Technologies, Inc. and Kodiak Networks, as well as growth in Managed & Support services and Integration services absent of acquisitions in both the Americas and EMEA. On a geographic basis, net sales for the third quarter of 2017 increased in the Americas and AP and decreased in EMEA, compared to the third quarter of 2016. The increase in AP was due to higher sales in Integration services. The decrease in EMEA was due to a decrease in Airwave revenue related to unfavorable foreign exchange rates during the quarter.

[0000068505-17-000017:mdna:93]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the third quarter of 2017, compared to 56% of the segment’s net sales in the third quarter of 2016.

[0000068505-17-000017:mdna:94]
The segment had operating earnings of $85 million in the third quarter of 2017, compared to $116 million in the third quarter of 2016. The decrease in operating earnings in the third quarter of 2017 compared to the third quarter of 2016 was primarily driven by lower gross margin and higher SG&A expenses, R&D expenditures, and Other charges.

[0000068505-17-000017:mdna:95]
Nine months ended September 30, 2017 compared to nine months ended October 1, 2016

[0000068505-17-000017:mdna:96]
The segment’s net sales increased $151 million, or 9%, to $1.9 billion in the first nine months of 2017, as compared to $1.7 billion in the first nine months of 2016. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from the acquisition of Airwave, Interexport, Spillman Technologies, Inc. and Kodiak Networks, as well as growth in services absent of acquisitions. The acquisition of Airwave and Managed & Support services and Integration services absent of acquisitions provided an increase of net sales within EMEA, compared to the first nine months of 2016. The acquisition of Interexport, Spillman Technologies, Inc. Kodiak Networks and Managed & Support services and Integration services absent of acquisitions provided an increase in the Americas.  Net sales decreased in AP due to lower Integration sales in the first nine months of 2017 compared to the first nine months of 2016.

[0000068505-17-000017:mdna:97]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the first nine months of 2017, compared to 57% of the segment's net sales in the first nine months of 2016.

[0000068505-17-000017:mdna:98]
The segment had operating earnings of $260 million in both the first nine months of 2017 and 2016.

[0000068505-17-000017:mdna:99]
[same as prior period, unchanged from 0000068505-17-000011:mdna:99]

[0000068505-17-000017:mdna:100]
During the third quarter of 2017, we recorded net reorganization of business charges of $8 million including $6 million of charges recorded within Other charges and $2 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $8 million were charges of $7 million related to employee separation costs and $1 million related to exit costs.

[0000068505-17-000017:mdna:101]
During the first nine months of 2017, we recorded net reorganization of business charges of $30 million including $22 million of charges recorded within Other charges and $8 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $30 million were charges of $30 million related to employee separation costs and $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000017:mdna:102]
During the third quarter of 2016, we recorded net reorganization of business charges of $7 million including $6 million of charges recorded within Other charges and $1 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-17-000017:mdna:103]
During the first nine months of 2016, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first nine months of 2016, we recorded net reorganization of business charges of $74 million including charges of $48 million recorded in Other charges and $26 million in Cost of sales in our condensed consolidated statements of operations. Included in the $74 million were charges of: (i) $54 million related to employee separation costs, (ii) $20 million for impairments, including $17 million for a building

[0000068505-17-000017:mdna:104]
[same as prior period, unchanged from 0000068505-17-000011:mdna:102]

[0000068505-17-000017:mdna:105]
impairment and $3 million for the impairment of corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000017:mdna:106]
[same as prior period, unchanged from 0000068505-17-000011:mdna:105]

[0000068505-17-000017:mdna:107]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Products | $ | 6 |  |  | $ | 5 |  |  | $ | 22 |  |  | $ | 59 |  |
| Services | 2 |  |  | 2 |  |  | 8 |  |  | 15 |  |
|  | $ | 8 |  |  | $ | 7 |  |  | $ | 30 |  |  | $ | 74 |  |

[0000068505-17-000017:mdna:108]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $77 million in the first nine months of 2017 and $59 million in the first nine months of 2016. The reorganization of business accruals at September 30, 2017 were $55 million, of which $46 million relate to employee separation costs that are expected to be paid within one year and $9 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-17-000017:mdna:109]
[same as prior period, unchanged from 0000068505-17-000011:mdna:108]

[0000068505-17-000017:mdna:110]
We decreased the aggregate of our cash and cash equivalent balances by $313 million from $1.0 billion as of December 31, 2016 to $717 million as of September 30, 2017. As highlighted in the condensed consolidated statements of cash flows, our liquidity and available capital resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0000068505-17-000017:mdna:111]
[same as prior period, unchanged from 0000068505-17-000011:mdna:111]

[0000068505-17-000017:mdna:112]
At September 30, 2017, $371 million of the $717 million cash and cash equivalents balance was held in the U.S. and approximately $346 million was held by us or our subsidiaries in other countries. Restricted cash was $64 million at September 30, 2017 and $63 million December 31, 2016.

[0000068505-17-000017:mdna:113]
[same as prior period, unchanged from 0000068505-17-000011:mdna:113]

[0000068505-17-000017:mdna:114]
Net cash provided by operating activities in the first nine months of 2017 was $585 million, as compared to $652 million in the first nine months of 2016. Operating cash flows in the first nine months of 2017, as compared to the first nine months of 2016, were negatively impacted by a temporary increase in working capital as a result of managing through our ERP system implementation. We expect the temporary increase in working capital to reverse by the end of 2017.

[0000068505-17-000017:mdna:115]
[same as prior period, unchanged from 0000068505-17-000011:mdna:115]

[0000068505-17-000017:mdna:116]
Net cash used by investing activities was $415 million in the first nine months of 2017, compared to $721 million in the first nine months of 2016. The $415 million of cash used in the first nine months of 2017 included: (i) $383 million used for acquisitions and investments and (ii) $206 million in capital expenditures, partially offset by $174 million of proceeds from sales of investments and businesses. The cash usage of $721 million in the first nine months of 2016 consisted primarily of: (i) $1.2 billion cash used for acquisitions and investments and (ii) $211 million in capital expenditures, partially offset by (a) $637 million of proceeds from the sale of investments and businesses and (b) $68 million of proceeds from the sale of property, plant and equipment.

[0000068505-17-000017:mdna:117]
Acquisition and Investments:  We used net cash for acquisitions and investments of $383 million during the first nine months of 2017 compared to $1.2 billion in the first nine months of 2016. The cash used during the first nine months of 2017 was used for investment in short-term government securities, and the acquisitions of Kodiak Networks for $205 million and Interexport for $55 million, net of cash acquired. The cash used during the first nine months of 2016 consisted primarily of $1.0 billion related to the acquisition of Airwave. The remainder of the cash in 2016 was used for short-term government securities and equity investments.

[0000068505-17-000017:mdna:118]
Sales of Investments and Businesses:  We received $174 million of proceeds related to the sales of investments and businesses in the first nine months of 2017 compared to $637 million in the first nine months of 2016. The proceeds in the first nine months of 2017 primarily consisted of the sales of short-term government securities. The proceeds in the first nine months of 2016 were comprised of: (i) $382 million from the sale of United Kingdom treasury securities used to finance the acquisition of Airwave, (ii) $209 million from the sales of various short-term government and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations.

[0000068505-17-000017:mdna:119]
Capital Expenditures:  Capital expenditures decreased in the first nine months of 2017 to $206 million, compared to $211 million in the first nine months of 2016. The decrease in capital expenditures was primarily related to lower facilities spend and lower revenue-generating network expenditures, partially offset by an increase in information technology spend.

[0000068505-17-000017:mdna:120]
Sales of Property, Plant, and Equipment:  In the first nine months of 2017, there were no sales of property, plant and equipment. In the first nine months of 2016, we received $68 million of proceeds comprised of $49 million from the sale of buildings

[0000068505-17-000017:mdna:121]
and land on our Schaumburg, IL campus and $19 million received from the sale of corporate aircraft.

[0000068505-17-000017:mdna:122]
[same as prior period, unchanged from 0000068505-17-000011:mdna:121]

[0000068505-17-000017:mdna:123]
Net cash used for financing activities was $537 million in the first nine months of 2017, compared to $191 million used in the first nine months of 2016. Cash used for financing activities in the first nine months of 2017 was primarily comprised of: (i) $358 million used for purchases under our share repurchase program, (ii) $230 million of cash used for the payment of dividends, and (iii) $15 million used for the repayment of debt, partially offset by $61 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first nine months of 2016 was primarily comprised of: (i) $728 million used for purchases under our share repurchase program and (ii)  $213 million of cash used for the payment of dividends, partially offset by (a) $673 million of net proceeds from the issuance of a term loan and (b) $80 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-17-000017:mdna:124]
Long-Term Debt:  We had outstanding long-term debt of $4.5 billion and $4.4 billion, including the current portions of $47 million and $4 million at September 30, 2017 and December 31, 2016, respectively. In the acquisition of Interexport, we assumed $92 million of debt, including a current portion of $40 million, primarily related to capital leases.

[0000068505-17-000017:mdna:125]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). In the event of conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-17-000017:mdna:126]
[same as prior period, unchanged from 0000068505-17-000011:mdna:125]

[0000068505-17-000017:mdna:127]
Share Repurchase Program: During the nine months ended September 30, 2017, we paid an aggregate of $358 million, including transaction costs, to repurchase approximately 4.3 million shares at an average price of $83.22 per share. As of September 30, 2017, the Company had used approximately $12.2 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.8 billion of authority available for future repurchases.

[0000068505-17-000017:mdna:128]
Payment of Dividends: During the third quarter of 2017, we paid $76 million in cash dividends to holders of our common stock. During the first nine months of 2017, we paid $230 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $76 million in cash dividends to holders of our common stock.

[0000068505-17-000017:mdna:129]
[same as prior period, unchanged from 0000068505-17-000011:mdna:128]

[0000068505-17-000017:mdna:130]
As of September 30, 2017, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 30, 2017. During the quarter ended September 30, 2017, we had borrowings and repayments of $150 million under the 2017 Motorola Solutions Credit Agreement. Such borrowings were used to purchase Kodiak Networks, and were repaid using cash from operations within the quarter.

[0000068505-17-000017:mdna:131]
[same as prior period, unchanged from 0000068505-17-000011:mdna:130]

[0000068505-17-000017:mdna:132]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $135 million at September 30, 2017, compared to $125 million at December 31, 2016.

[0000068505-17-000017:mdna:133]
Outstanding Long-Term Receivables:  We had non-current long-term receivables of $24 million at September 30, 2017, compared to $49 million at December 31, 2016.

[0000068505-17-000017:mdna:134]
[same as prior period, unchanged from 0000068505-17-000011:mdna:133]

[0000068505-17-000017:mdna:135]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 30, 2017 and October 1, 2016:

[0000068505-17-000017:mdna:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Accounts receivable sales proceeds | $ | 99 |  |  | $ | 8 |  |  | $ | 179 |  |  | $ | 15 |  |
| Long-term receivables sales proceeds | 55 |  |  | 39 |  |  | 123 |  |  | 173 |  |
| Total proceeds from sales of accounts receivable | $ | 154 |  |  | $ | 47 |  |  | $ | 302 |  |  | $ | 188 |  |

[0000068505-17-000017:mdna:137]
At September 30, 2017, the Company had retained servicing obligations for $780 million of long-term receivables, compared to $774 million at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000017:mdna:138]
Other Contingencies

[0000068505-17-000017:mdna:139]
[same as prior period, unchanged from 0000068505-17-000011:mdna:138]

[0000068505-17-000017:mdna:140]
[same as prior period, unchanged from 0000068505-17-000011:mdna:139]

[0000068505-17-000017:mdna:141]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at September 30, 2017.

[0000068505-17-000017:mdna:142]
[same as prior period, unchanged from 0000068505-17-000011:mdna:141]

[0000068505-17-000017:mdna:143]
[same as prior period, unchanged from 0000068505-17-000011:mdna:142]

[0000068505-17-000017:mdna:144]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU No. 2014-09 by one year to January 1, 2018, as our annual reporting period begins after December 15, 2017.

[0000068505-17-000017:mdna:145]
We have continued to analyze the impact of the new standard on our financial results based on an inventory of our current contracts with customers. We have obtained an understanding of the new standard and currently believe that we will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of our contracts is currently recognized under percentage of completion accounting applying a cost-to-cost method, including contracts for radio network deployments based on the ASTRO P25, TETRA, and LTE technologies, as well as certain offerings within our Smart Public Safety Solutions requiring significant integration (collectively "network integration contracts").

[0000068505-17-000017:mdna:146]
Under the new standard, we must identify the distinct promises to transfer goods and/or services within our contracts using certain factors. For network integration contracts, we have considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard will impact our network integration contracts that include devices and accessories, with the resulting impact being revenue recognized earlier as control of the devices and accessories transfers to the customer at a point in time rather than over

[0000068505-17-000017:mdna:147]
time. For the remaining promised goods and services within our network integration contracts, we will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in our contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000017:mdna:148]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While we have contracts which fall under these rules in the current standard, we have not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, we do not anticipate a significant acceleration of revenue upon applying the new standard to our current contracts under these fact patterns.

[0000068505-17-000017:mdna:149]
The new standard also requires the concept of transfer of control to determine whether an entity must present revenue from providing goods or services at the gross amount billed to a customer (as a principal) or at the net amount retained (as an agent). Therefore, an entity must assess whether it controls the goods or services provided to a customer before they are transferred. The new standard provides three indicators to assist entities in determining control. Under the current standard, eight indicators (including the three indicators under the new standard) exist to evaluate whether an entity should present revenue gross as a principal or net as an agent. Historically, we have presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and remaining three indicators under the new standard, we have determined that we are the principal in contracts that involve a third-party sales representative. Thus, upon adoption of the new standard we will present associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses.

[0000068505-17-000017:mdna:150]
Under current accounting standards, we expense sales commissions as incurred. However, under ASU No. 2014-09, we will capitalize sales commissions as incremental costs to obtain a contract. Such costs will be classified as a contract asset and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-17-000017:mdna:151]
We continue to evaluate the impact of ASU No. 2014-09 on our financial results and prepare for the adoption of the standard on January 1, 2018, including readying our internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. We expect to adopt this standard under the modified retrospective method of adoption, which recognizes the cumulative effect of transition as an adjustment to retained earnings for contracts that are not completed as of the adoption date, without restating prior period financial statements.

[0000068505-17-000017:mdna:152]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us on January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000017:mdna:153]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for us on January 1, 2018 with early adoption permitted. We intend to adopt this ASU on January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, we do not anticipate significant changes to our existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000017:mdna:154]
In October 2016, the FASB issued ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption permitted. We intend to adopt the ASU on January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. We continue to assess the impact of this ASU but anticipate that the impact will be immaterial based on existing deferred taxes from intra-entity asset transfers other than inventory.

[0000068505-17-000017:mdna:155]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in the total cash, which is inclusive of cash and cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for us on January 1, 2018 with early adoption permitted. We intend to adopt the ASU on January 1, 2018. Upon adoption, the ASU requires retrospective application. We do not anticipate significant changes to our financial statements and related disclosures from adoption of the ASU.

[0000068505-17-000017:mdna:156]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. We intend to adopt this ASU on January 1, 2018. Upon adoption, we plan to update the presentation of net periodic cost (benefit) accordingly, noting all components of our net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of approximately $15 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.

[0000068505-17-000017:mdna:157]
In August 2017, the FASB issued ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for us on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). We are currently assessing the impact of this ASU, including transition elections and required elections, on our consolidated financial statements and the timing of adoption.

[0000068505-17-000017:mdna:158]
35
