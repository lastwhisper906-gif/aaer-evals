# MSI notes — 0000068505-17-000017


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-17-000017:notes:1]
[same as prior period, unchanged from 0000068505-17-000011:notes:1]

[0000068505-17-000017:notes:2]
| September 30, 2017 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Corporate bonds | 2 |  |  | — |  |  | 2 |  |
| Common stock | 5 |  |  | 8 |  |  | 13 |  |
|  | 12 |  |  | 8 |  |  | 20 |  |
| Other investments | 215 |  |  | — |  |  | 215 |  |
| Equity method investments | 14 |  |  | — |  |  | 14 |  |
|  | $ | 241 |  |  | $ | 8 |  |  | $ | 249 |  |

[0000068505-17-000017:notes:3]
[same as prior period, unchanged from 0000068505-17-000011:notes:3]


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-17-000017:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 30, 2017 and December 31, 2016 were as follows:

[0000068505-17-000017:notes:5]
| September 30, 2017 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  | $ | 7 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 5 |  |  | 5 |  |
| Corporate bonds | — |  |  | 2 |  |  | 2 |  |
| Common stock | 13 |  |  | — |  |  | 13 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  | $ | 8 |  |
| Interest agreements | — |  |  | 1 |  |  | 1 |  |

[0000068505-17-000017:notes:6]
[same as prior period, unchanged from 0000068505-17-000011:notes:6]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-17-000017:notes:7]
[same as prior period, unchanged from 0000068505-17-000011:notes:7]

[0000068505-17-000017:notes:8]
[same as prior period, unchanged from 0000068505-17-000011:notes:8]

[0000068505-17-000017:notes:9]
[same as prior period, unchanged from 0000068505-17-000011:notes:9]

[0000068505-17-000017:notes:10]
|  | September 30, 2017 |  | December 31, 2016 |
| Long-term receivables | $ | 43 |  |  | $ | 63 |  |
| Less current portion | (19 | ) |  | (14 | ) |
| Non-current long-term receivables | $ | 24 |  |  | $ | 49 |  |

[0000068505-17-000017:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $135 million at September 30, 2017, compared to $125 million at December 31, 2016.

[0000068505-17-000017:notes:12]
[same as prior period, unchanged from 0000068505-17-000011:notes:12]

[0000068505-17-000017:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 30, 2017 and October 1, 2016:

[0000068505-17-000017:notes:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Accounts receivable sales proceeds | $ | 99 |  |  | $ | 8 |  |  | $ | 179 |  |  | $ | 15 |  |
| Long-term receivables sales proceeds | 55 |  |  | 39 |  |  | 123 |  |  | 173 |  |
| Total proceeds from receivable sales | $ | 154 |  |  | $ | 47 |  |  | $ | 302 |  |  | $ | 188 |  |

[0000068505-17-000017:notes:15]
At September 30, 2017, the Company had retained servicing obligations for $780 million of long-term receivables, compared to $774 million at December 31, 2016. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000017:notes:16]
[same as prior period, unchanged from 0000068505-17-000011:notes:16]

[0000068505-17-000017:notes:17]
An aging analysis of financing receivables at September 30, 2017 and December 31, 2016 is as follows:

[0000068505-17-000017:notes:18]
| September 30, 2017 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Commercial loans and leases secured | 18 |  |  | 3 |  |  | 1 |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 43 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 3 |  |

[0000068505-17-000017:notes:19]
[same as prior period, unchanged from 0000068505-17-000011:notes:19]


## msi:OtherChargesTableTextBlock

[0000068505-17-000017:notes:20]
[same as prior period, unchanged from 0000068505-17-000011:notes:20]

[0000068505-17-000017:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 13) | $ | 39 |  |  | $ | 31 |  |  | $ | 112 |  |  | $ | 83 |  |
| Reorganization of business (Note 12) | 6 |  |  | 6 |  |  | 22 |  |  | 28 |  |
| Building impairment | — |  |  | — |  |  | 8 |  |  | 17 |  |
| Non-U.S. pension settlement loss (Note 6) | 21 |  |  | — |  |  | 46 |  |  | — |  |
| Asset impairment | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Gain on legal settlements | — |  |  | — |  |  | (44 | ) |  | — |  |
| Impairment of corporate aircraft | — |  |  | — |  |  | — |  |  | 3 |  |
| Acquisition-related transaction fees | — |  |  | — |  |  | 1 |  |  | 13 |  |
|  | $ | 67 |  |  | $ | 37 |  |  | $ | 146 |  |  | $ | 144 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-17-000017:notes:22]
[same as prior period, unchanged from 0000068505-17-000011:notes:22]

[0000068505-17-000017:notes:23]
| October 1, 2016 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 5 |  |  | $ | 59 |  |
| Services | 2 |  |  | 15 |  |
|  | $ | 7 |  |  | $ | 74 |  |

[0000068505-17-000017:notes:24]
| September 30, 2017 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 6 |  |  | $ | 22 |  |
| Services | 2 |  |  | 8 |  |
|  | $ | 8 |  |  | $ | 30 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-17-000017:notes:25]
[same as prior period, unchanged from 0000068505-17-000011:notes:25]

[0000068505-17-000017:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 11 |  |  | 12 |  |  | 32 |  |  | 35 |  |
| Research and development expenditures | 3 |  |  | 3 |  |  | 10 |  |  | 10 |  |
| Share-based compensation expense included in Operating earnings | 16 |  |  | 17 |  |  | 49 |  |  | 52 |  |
| Tax benefit | 5 |  |  | 5 |  |  | 16 |  |  | 16 |  |
| Share-based compensation expense, net of tax | $ | 11 |  |  | $ | 12 |  |  | $ | 33 |  |  | $ | 36 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |  | $ | (0.20 | ) |  | $ | (0.21 | ) |
| Decrease in diluted earnings per share | $ | (0.07 | ) |  | $ | (0.07 | ) |  | $ | (0.19 | ) |  | $ | (0.21 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-17-000017:notes:27]
[same as prior period, unchanged from 0000068505-17-000011:notes:27]

[0000068505-17-000017:notes:28]
|  | September 30, 2017 |  | December 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 217 |  |  | $ | 73 |  |  | $ | 178 |  |  | $ | 63 |  |
| Services | 962 |  |  | 210 |  |  | 805 |  |  | 99 |  |
|  | $ | 1,179 |  |  | $ | 283 |  |  | $ | 983 |  |  | $ | 162 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-17-000017:notes:29]
[same as prior period, unchanged from 0000068505-17-000011:notes:29]

[0000068505-17-000017:notes:30]
|  | September 30, 2017 |  | December 31, 2016 |
| Defined benefit plans | $ | 1,797 |  |  | $ | 1,799 |  |
| Deferred revenue | 158 |  |  | 115 |  |
| Unrecognized tax benefits | 40 |  |  | 39 |  |
| Deferred income taxes | 142 |  |  | 121 |  |
| Deferred consideration (Note 13) | 82 |  |  | 72 |  |
| Other | 231 |  |  | 209 |  |
|  | $ | 2,450 |  |  | $ | 2,355 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-17-000017:notes:31]
[same as prior period, unchanged from 0000068505-17-000011:notes:31]

[0000068505-17-000017:notes:32]
[same as prior period, unchanged from 0000068505-17-000011:notes:32]

[0000068505-17-000017:notes:33]
[same as prior period, unchanged from 0000068505-17-000011:notes:33]

[0000068505-17-000017:notes:34]
During the nine months ended September 30, 2017, the Company recognized a net gain of $44 million related to legal settlements. Of this amount, $42 million relates to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business. The net gain of $42 million was based on $52 million of proceeds received, net $10 million of fees owed to third parties for their involvement in the recovery.

[0000068505-17-000017:notes:35]
During the nine months ended September 30, 2017 and October 1, 2016, the Company recognized $8 million and $17 million, respectively, of building impairments related to the sale of its Basingstoke building and Schaumburg campus, respectively.

[0000068505-17-000017:notes:36]
During the nine months ended October 1, 2016, the Company expensed $13 million of transaction fees related to the acquisition of Airwave.

[0000068505-17-000017:notes:37]
[same as prior period, unchanged from 0000068505-17-000011:notes:35]

[0000068505-17-000017:notes:38]
[same as prior period, unchanged from 0000068505-17-000011:notes:36]

[0000068505-17-000017:notes:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (55 | ) |  | $ | (58 | ) |  | $ | (164 | ) |  | $ | (169 | ) |
| Interest income | 3 |  |  | 4 |  |  | 10 |  |  | 12 |  |
|  | $ | (52 | ) |  | $ | (54 | ) |  | $ | (154 | ) |  | $ | (157 | ) |
| Other: |  |  |  |  |  |  |  |
| Investment impairments | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Foreign currency gain (loss) | $ | (7 | ) |  | $ | 7 |  |  | $ | (29 | ) |  | $ | 34 |  |
| Gain (loss) on derivative instruments | 3 |  |  | (11 | ) |  | 14 |  |  | (41 | ) |
| Gains on equity method investments | 1 |  |  | — |  |  | 1 |  |  | 2 |  |
| Realized foreign currency loss on acquisition | — |  |  | — |  |  | — |  |  | (10 | ) |
| Other | 3 |  |  | 5 |  |  | 5 |  |  | 5 |  |
|  | $ | — |  |  | $ | (1 | ) |  | $ | (9 | ) |  | $ | (12 | ) |

[0000068505-17-000017:notes:40]
During the three and nine months ended September 30, 2017, the Company recognized foreign currency losses of $7 million and $29 million, respectively, primarily driven by the British pound, partially offset by gains of $3 million and $14 million, respectively, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-17-000017:notes:41]
During the three and nine months ended October 1, 2016, the Company recognized foreign currency gains of $7 million and $34 million, respectively, primarily driven by the British pound, partially offset by losses of $11 million and $41 million, respectively, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-17-000017:notes:42]
During the nine months ended October 1, 2016, the Company realized a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of Airwave.

[0000068505-17-000017:notes:43]
[same as prior period, unchanged from 0000068505-17-000011:notes:38]

[0000068505-17-000017:notes:44]
[same as prior period, unchanged from 0000068505-17-000011:notes:39]

[0000068505-17-000017:notes:45]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 212 |  |  | $ | 192 |  |  | $ | 420 |  |  | $ | 317 |  |
| Weighted average common shares outstanding | 162.3 |  |  | 166.3 |  |  | 163.2 |  |  | 171.0 |  |
| Per share amount | $ | 1.30 |  |  | $ | 1.15 |  |  | $ | 2.57 |  |  | $ | 1.85 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 212 |  |  | $ | 192 |  |  | $ | 420 |  |  | $ | 317 |  |
| Weighted average common shares outstanding | 162.3 |  |  | 166.3 |  |  | 163.2 |  |  | 171.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.4 |  |  | 2.4 |  |  | 3.3 |  |  | 2.5 |  |
| Senior Convertible Notes | 3.3 |  |  | 0.9 |  |  | 2.8 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding | 169.0 |  |  | 169.6 |  |  | 169.3 |  |  | 174.0 |  |
| Per share amount | $ | 1.25 |  |  | $ | 1.13 |  |  | $ | 2.48 |  |  | $ | 1.82 |  |

[0000068505-17-000017:notes:46]
In the computation of diluted earnings per common share for the three months ended September 30, 2017, the assumed exercise of 2.0 million options, including 1.7 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive. For the nine months ended September 30, 2017, the assumed exercise of 2.3 million options, including 1.9 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-17-000017:notes:47]
For the three months ended October 1, 2016, the assumed exercise of 2.5 million options, including 1.8 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive. For the nine months ended October 1, 2016, the assumed exercise of 2.9 million options and 0.4 million RSUs, including 2.0 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-17-000017:notes:48]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). The notes became fully convertible as of August 25, 2017. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-17-000017:notes:49]
For the three and nine months ended September 30, 2017, the dilutive impact of the Senior Convertible Notes was 3.3 million shares and 2.8 million shares, respectively. For the three and nine months ended October 1, 2016, the dilutive impact of the Senior Convertible Notes was 0.9 million shares and 0.5 million shares, respectively.

[0000068505-17-000017:notes:50]
[same as prior period, unchanged from 0000068505-17-000011:notes:45]

[0000068505-17-000017:notes:51]
[same as prior period, unchanged from 0000068505-17-000011:notes:46]

[0000068505-17-000017:notes:52]
[same as prior period, unchanged from 0000068505-17-000011:notes:47]

[0000068505-17-000017:notes:53]
|  | September 30, 2017 |  | December 31, 2016 |
| Accounts receivable | $ | 1,420 |  |  | $ | 1,454 |  |
| Less allowance for doubtful accounts | (38 | ) |  | (44 | ) |
|  | $ | 1,382 |  |  | $ | 1,410 |  |

[0000068505-17-000017:notes:54]
[same as prior period, unchanged from 0000068505-17-000011:notes:49]

[0000068505-17-000017:notes:55]
[same as prior period, unchanged from 0000068505-17-000011:notes:50]

[0000068505-17-000017:notes:56]
|  | September 30, 2017 |  | December 31, 2016 |
| Finished goods | $ | 178 |  |  | $ | 151 |  |
| Work-in-process and production materials | 315 |  |  | 253 |  |
|  | 493 |  |  | 404 |  |
| Less inventory reserves | (129 | ) |  | (131 | ) |
|  | $ | 364 |  |  | $ | 273 |  |

[0000068505-17-000017:notes:57]
As a result of our Enterprise Resource Planning ("ERP") system implementation in the second quarter of 2017, the Company maintained higher inventory levels to ensure it continued to meet customer demand over the implementation period.

[0000068505-17-000017:notes:58]
[same as prior period, unchanged from 0000068505-17-000011:notes:52]

[0000068505-17-000017:notes:59]
[same as prior period, unchanged from 0000068505-17-000011:notes:53]

[0000068505-17-000017:notes:60]
|  | September 30, 2017 |  | December 31, 2016 |
| Available-for-sale securities | $ | — |  |  | $ | 46 |  |
| Costs and earnings in excess of billings | 595 |  |  | 495 |  |
| Tax-related refunds receivable | 144 |  |  | 90 |  |
| Other | 134 |  |  | 124 |  |
|  | $ | 873 |  |  | $ | 755 |  |

[0000068505-17-000017:notes:61]
[same as prior period, unchanged from 0000068505-17-000011:notes:55]

[0000068505-17-000017:notes:62]
[same as prior period, unchanged from 0000068505-17-000011:notes:56]

[0000068505-17-000017:notes:63]
|  | September 30, 2017 |  | December 31, 2016 |
| Land | $ | 11 |  |  | $ | 12 |  |
| Building | 282 |  |  | 306 |  |
| Machinery and equipment | 2,153 |  |  | 1,921 |  |
|  | 2,446 |  |  | 2,239 |  |
| Less accumulated depreciation | (1,557 | ) |  | (1,450 | ) |
|  | $ | 889 |  |  | $ | 789 |  |

[0000068505-17-000017:notes:64]
Depreciation expense for the three months ended September 30, 2017 and October 1, 2016 was $49 million and $45 million, respectively. Depreciation expense for the nine months ended September 30, 2017 and October 1, 2016 was $142 million and $137 million, respectively.

[0000068505-17-000017:notes:65]
[same as prior period, unchanged from 0000068505-17-000011:notes:59]

[0000068505-17-000017:notes:66]
Other investments include strategic investments in non-public technology-driven startup companies recorded at cost of $74 million and $76 million, and insurance policies recorded at their cash surrender value of $141 million and $135 million, at September 30, 2017 and December 31, 2016, respectively.

[0000068505-17-000017:notes:67]
During the three months ended September 30, 2017, Gains on the sale of investments and businesses was de minimus, compared to gains of $7 million during the three months ended October 1, 2016. During the nine months ended September 30, 2017, the Company recognized Gains on the sale of investments and businesses of $3 million, compared to losses of $13 million during the nine months ended October 1, 2016, of which, $19 million was associated with the sale of United Kingdom treasury securities, partially offset by gains of $6 million.

[0000068505-17-000017:notes:68]
[same as prior period, unchanged from 0000068505-17-000011:notes:62]

[0000068505-17-000017:notes:69]
[same as prior period, unchanged from 0000068505-17-000011:notes:63]

[0000068505-17-000017:notes:70]
|  | September 30, 2017 |  | December 31, 2016 |
| Long-term receivables | 24 |  |  | 49 |  |
| Defined benefit plan assets | 138 |  |  | 102 |  |
| Other | 39 |  |  | 49 |  |
|  | $ | 201 |  |  | 200 |  |

[0000068505-17-000017:notes:71]
[same as prior period, unchanged from 0000068505-17-000011:notes:65]

[0000068505-17-000017:notes:72]
[same as prior period, unchanged from 0000068505-17-000011:notes:66]

[0000068505-17-000017:notes:73]
|  | September 30, 2017 |  | December 31, 2016 |
| Deferred revenue | $ | 469 |  |  | $ | 439 |  |
| Compensation | 232 |  |  | 250 |  |
| Billings in excess of costs and earnings | 408 |  |  | 434 |  |
| Tax liabilities | 168 |  |  | 111 |  |
| Dividend payable | 76 |  |  | 77 |  |
| Trade liabilities | 154 |  |  | 180 |  |
| Other | 536 |  |  | 620 |  |
|  | $ | 2,043 |  |  | $ | 2,111 |  |

[0000068505-17-000017:notes:74]
[same as prior period, unchanged from 0000068505-17-000011:notes:68]

[0000068505-17-000017:notes:75]
[same as prior period, unchanged from 0000068505-17-000011:notes:69]

[0000068505-17-000017:notes:76]
Share Repurchase Program:  Through a series of actions, the Board of Directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date.

[0000068505-17-000017:notes:77]
During the nine months ended September 30, 2017, the Company paid an aggregate of $358 million, including transaction costs, to repurchase approximately 4.3 million shares at an average price of $83.22 per share. As of September 30, 2017, the Company had used approximately $12.2 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.8 billion of authority available for future repurchases.

[0000068505-17-000017:notes:78]
Payment of Dividends: During the three months ended September 30, 2017 and October 1, 2016, the Company paid $76 million and $70 million, respectively, in cash dividends to holders of its common stock. During the nine months ended September 30, 2017 and October 1, 2016, the Company paid $230 million and $213 million, respectively, in cash dividends to holders of its common stock.

[0000068505-17-000017:notes:79]
[same as prior period, unchanged from 0000068505-17-000011:notes:73]

[0000068505-17-000017:notes:80]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and nine months ended September 30, 2017 and October 1, 2016:

[0000068505-17-000017:notes:81]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (413 | ) |  | $ | (351 | ) |  | $ | (494 | ) |  | $ | (266 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 49 |  |  | (47 | ) |  | 133 |  |  | (131 | ) |
| Tax expense | (3 | ) |  | (2 | ) |  | (6 | ) |  | (3 | ) |
| Other comprehensive income (loss), net of tax | 46 |  |  | (49 | ) |  | 127 |  |  | (134 | ) |
| Balance at end of period | $ | (367 | ) |  | $ | (400 | ) |  | $ | (367 | ) |  | $ | (400 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | (3 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 1 |  |  | 1 |  |  | 8 |  |  | (1 | ) |
| Tax (expense) benefit | — |  |  | — |  |  | (3 | ) |  | 1 |  |
| Other comprehensive income before reclassification adjustment, net of tax | 1 |  |  | 1 |  |  | 5 |  |  | — |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net | — |  |  | — |  |  | — |  |  | 6 |  |
| Tax benefit | — |  |  | — |  |  | — |  |  | (2 | ) |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | — |  |  | — |  |  | — |  |  | 4 |  |
| Other comprehensive income, net of tax | 1 |  |  | 1 |  |  | 5 |  |  | 4 |  |
| Balance at end of period | $ | 5 |  |  | $ | 1 |  |  | $ | 5 |  |  | $ | 1 |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | (1,790 | ) |  | (1,537 | ) |  | $ | (1,823 | ) |  | $ | (1,597 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (4 | ) |  | — |  |  | (15 | ) |  | 53 |  |
| Tax expense | — |  |  | — |  |  | — |  |  | (16 | ) |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (4 | ) |  | — |  |  | (15 | ) |  | 37 |  |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 17 |  |  | 13 |  |  | 49 |  |  | 40 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (4 | ) |  | (7 | ) |  | (12 | ) |  | (20 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other charges | 21 |  |  | — |  |  | 46 |  |  | — |  |
| Tax expense (benefit) | (4 | ) |  | (1 | ) |  | (9 | ) |  | 8 |  |
| Reclassification adjustment into Operating earnings, net of tax | 30 |  |  | 5 |  |  | 74 |  |  | 28 |  |
| Other comprehensive income, net of tax | 26 |  |  | 5 |  |  | 59 |  |  | 65 |  |
| Balance at end of period | $ | (1,764 | ) |  | $ | (1,532 | ) |  | $ | (1,764 | ) |  | $ | (1,532 | ) |
| Total Accumulated other comprehensive loss | $ | (2,126 | ) |  | $ | (1,931 | ) |  | $ | (2,126 | ) |  | $ | (1,931 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-17-000017:notes:82]
The condensed consolidated financial statements as of September 30, 2017 and for the three and nine months ended September 30, 2017 and October 1, 2016 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-17-000017:notes:83]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2016. The results of operations for the three and nine months ended September 30, 2017 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-17-000017:notes:84]
[same as prior period, unchanged from 0000068505-17-000011:notes:78]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-17-000017:notes:85]
Commitments and Contingencies

[0000068505-17-000017:notes:86]
Legal Matters

[0000068505-17-000017:notes:87]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-17-000017:notes:88]
Other Indemnifications

[0000068505-17-000017:notes:89]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-17-000017:notes:90]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at September 30, 2017.

[0000068505-17-000017:notes:91]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-17-000017:notes:92]
Debt and Credit Facilities

[0000068505-17-000017:notes:93]
As of September 30, 2017, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022, which can be used for borrowing and letters of credit (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate, at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 30, 2017. During the quarter ended September 30, 2017, the Company had borrowings and repayments of $150 million under the 2017 Motorola Solutions Credit Agreement. Such borrowings were used to purchase Kodiak Networks, and were repaid using cash from operations within the quarter.

[0000068505-17-000017:notes:94]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). In the event of conversion, the notes may be settled in either cash or stock, at the Company's discretion. The Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-17-000017:notes:95]
[same as prior period, unchanged from 0000068505-17-000011:notes:91]

[0000068505-17-000017:notes:96]
[same as prior period, unchanged from 0000068505-17-000011:notes:92]

[0000068505-17-000017:notes:97]
As of September 30, 2017, the Company had outstanding foreign exchange contracts with notional amounts totaling $541 million, compared to $717 million outstanding at December 31, 2016. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-17-000017:notes:98]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 30, 2017, and the corresponding positions as of December 31, 2016:

[0000068505-17-000017:notes:99]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 30, 2017 |  | December 31, 2016 |
| Euro | $ | 185 |  |  | $ | 122 |  |
| British Pound | 69 |  |  | 246 |  |
| Chinese Renminbi | (72 | ) |  | (108 | ) |
| Brazilian Real | (47 | ) |  | (56 | ) |
| Australian Dollar | (45 | ) |  | (51 | ) |

[0000068505-17-000017:notes:100]
During the nine months ended September 30, 2017, the Company entered into forward contracts to sell £50 million, expiring in December 2017. The Company also entered into forward contracts to sell £25 million, expiring in June 2018, as well as to sell £25 million, expiring in September 2018. The forward contracts have been designated as a net investment hedge which is in place to partially hedge the Company's British pound foreign currency exposure on its net investment in Airwave Solutions Limited. The gains and losses on the Company's net investment in British pound-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive loss. As of September 30, 2017, the fair value of the derivative contracts was a $3 million liability.

[0000068505-17-000017:notes:101]
[same as prior period, unchanged from 0000068505-17-000011:notes:97]

[0000068505-17-000017:notes:102]
The Company's subsidiaries have variable interest loans denominated in the Euro and Chilean Peso. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as hedges. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swaps was a $1 million liability at September 30, 2017 and de minimus December 31, 2016.

[0000068505-17-000017:notes:103]
[same as prior period, unchanged from 0000068505-17-000011:notes:99]

[0000068505-17-000017:notes:104]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 30, 2017, all of the counterparties have investment grade credit ratings. As of September 30, 2017, the Company had $7 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-17-000017:notes:105]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of September 30, 2017 and December 31, 2016:

[0000068505-17-000017:notes:106]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| September 30, 2017 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 3 |  |  | Other liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 7 |  |  | Other current assets |  | $ | 5 |  |  | Accrued liabilities |
| Interest agreements | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives not designated as hedging instruments | $ | 7 |  |  |  |  | $ | 6 |  |  |  |
| Total derivatives | $ | 7 |  |  |  |  | $ | 9 |  |  |  |

[0000068505-17-000017:notes:107]
[same as prior period, unchanged from 0000068505-17-000011:notes:103]

[0000068505-17-000017:notes:108]
The following table summarizes the effect of derivatives designated as hedging instruments on the Company's condensed consolidated financial statements for the three and nine months ended September 30, 2017 and October 1, 2016:

[0000068505-17-000017:notes:109]
|  | Three Months Ended |  | Nine Months Ended |  | Balance SheetLocation |
| Derivatives Designated as Hedging Instruments | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |  |
| Foreign exchange contracts | $ | (1 | ) |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | Other comprehensive income (loss) |

[0000068505-17-000017:notes:110]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated financial statements for the three and nine months ended September 30, 2017 and October 1, 2016:

[0000068505-17-000017:notes:111]
|  | Three Months Ended |  | Nine Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |  |
| Interest agreements | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | Other income (expense) |
| Foreign exchange contracts | 4 |  |  | (11 | ) |  | 15 |  |  | (41 | ) |  | Other income (expense) |
| Total derivatives | $ | 3 |  |  | $ | (11 | ) |  | $ | 14 |  |  | $ | (41 | ) |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-17-000017:notes:112]
[same as prior period, unchanged from 0000068505-17-000011:notes:108]

[0000068505-17-000017:notes:113]
During the nine months ended September 30, 2017, the Company granted 0.6 million RSUs and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $46 million and $6 million, respectively, and 0.4 million stock options and 0.6 million performance options ("POs") with an aggregate grant-date fair value of $5 million and $9 million, respectively. Share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-17-000017:notes:114]
[same as prior period, unchanged from 0000068505-17-000011:notes:110]

[0000068505-17-000017:notes:115]
[same as prior period, unchanged from 0000068505-17-000011:notes:111]

[0000068505-17-000017:notes:116]
[same as prior period, unchanged from 0000068505-17-000011:notes:112]

[0000068505-17-000017:notes:117]
[same as prior period, unchanged from 0000068505-17-000011:notes:113]

[0000068505-17-000017:notes:118]
[same as prior period, unchanged from 0000068505-17-000011:notes:114]

[0000068505-17-000017:notes:119]
[same as prior period, unchanged from 0000068505-17-000011:notes:115]

[0000068505-17-000017:notes:120]
The Company had no Level 3 holdings as of September 30, 2017 or December 31, 2016.

[0000068505-17-000017:notes:121]
At September 30, 2017 and December 31, 2016, the Company had $263 million and $309 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-17-000017:notes:122]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at September 30, 2017 and December 31, 2016 was $4.6 billion and $4.5 billion (Level 2), respectively.

[0000068505-17-000017:notes:123]
[same as prior period, unchanged from 0000068505-17-000011:notes:119]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-17-000017:notes:124]
[same as prior period, unchanged from 0000068505-17-000011:notes:120]

[0000068505-17-000017:notes:125]
[same as prior period, unchanged from 0000068505-17-000011:notes:121]

[0000068505-17-000017:notes:126]
[same as prior period, unchanged from 0000068505-17-000011:notes:122]

[0000068505-17-000017:notes:127]
[same as prior period, unchanged from 0000068505-17-000011:notes:123]

[0000068505-17-000017:notes:128]
[same as prior period, unchanged from 0000068505-17-000011:notes:124]

[0000068505-17-000017:notes:129]
[same as prior period, unchanged from 0000068505-17-000011:notes:125]

[0000068505-17-000017:notes:130]
[same as prior period, unchanged from 0000068505-17-000011:notes:126]

[0000068505-17-000017:notes:131]
[same as prior period, unchanged from 0000068505-17-000011:notes:127]

[0000068505-17-000017:notes:132]
[same as prior period, unchanged from 0000068505-17-000011:notes:128]

[0000068505-17-000017:notes:133]
[same as prior period, unchanged from 0000068505-17-000011:notes:129]

[0000068505-17-000017:notes:134]
On August 28, 2017, the Company completed the acquisition of Kodiak Networks, a provider of broadband push-to-talk (PTT) for commercial customers, for a gross purchase price of $225 million, based on cash payments of $205 million made during the third quarter of 2017 and $20 million expected to be paid in the fourth quarter of 2017. As a result of the acquisition, the Company recognized $178 million of goodwill, $44 million of identifiable intangible assets and $3 million of net other tangible assets. The identifiable intangible assets were classified as $25 million of customer-related intangibles and $19 million of completed technology and will be amortized over a period of 13 to 16 years. As of September 30, 2017, the purchase accounting is not yet complete and as such the final allocation between identifiable intangibles and goodwill may be subject to change.

[0000068505-17-000017:notes:135]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides Managed & Support services for communications systems to public safety and commercial customers in Chile, for a gross purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $7 million of goodwill, $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $9 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-17-000017:notes:136]
[same as prior period, unchanged from 0000068505-17-000011:notes:133]

[0000068505-17-000017:notes:137]
[same as prior period, unchanged from 0000068505-17-000011:notes:134]

[0000068505-17-000017:notes:138]
[same as prior period, unchanged from 0000068505-17-000011:notes:135]

[0000068505-17-000017:notes:139]
[same as prior period, unchanged from 0000068505-17-000011:notes:136]

[0000068505-17-000017:notes:140]
|  | September 30, 2017 |  | December 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 148 |  |  | $ | 50 |  |  | $ | 116 |  |  | $ | 38 |  |
| Patents | 2 |  |  | 2 |  |  | 8 |  |  | 6 |  |
| Customer-related | 973 |  |  | 209 |  |  | 810 |  |  | 101 |  |
| Other intangibles | 56 |  |  | 22 |  |  | 49 |  |  | 17 |  |
|  | $ | 1,179 |  |  | $ | 283 |  |  | $ | 983 |  |  | $ | 162 |  |

[0000068505-17-000017:notes:141]
Amortization expense on intangible assets was $39 million for the three months ended September 30, 2017 and $112 million for the nine months ended September 30, 2017. Amortization expense on intangible assets was $31 million for the three months ended October 1, 2016 and $83 million for the nine months ended October 1, 2016. As of September 30, 2017, annual amortization expense is estimated to be $151 million in 2017, $155 million in 2018, $154 million in 2019, $152 million in 2020, $150 million in 2021, and $147 million in 2022.

[0000068505-17-000017:notes:142]
[same as prior period, unchanged from 0000068505-17-000011:notes:139]

[0000068505-17-000017:notes:143]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2017 to September 30, 2017:

[0000068505-17-000017:notes:144]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2017 |  |  |  |  |  |
| Goodwill, net of impairment losses | $ | 316 |  |  | $ | 412 |  |  | $ | 728 |  |
| Goodwill acquired | — |  |  | 185 |  |  | 185 |  |
| Purchase accounting adjustments | — |  |  | 2 |  |  | 2 |  |
| Foreign currency | — |  |  | 17 |  |  | 17 |  |
| Balance as of September 30, 2017 |  |  |  |  |  |
| Goodwill, net of impairment losses | $ | 316 |  |  | $ | 616 |  |  | $ | 932 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-17-000017:notes:145]
[same as prior period, unchanged from 0000068505-17-000011:notes:142]

[0000068505-17-000017:notes:146]
[same as prior period, unchanged from 0000068505-17-000011:notes:143]

[0000068505-17-000017:notes:147]
[same as prior period, unchanged from 0000068505-17-000011:notes:144]

[0000068505-17-000017:notes:148]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Net earnings before income taxes | $ | 286 |  |  | $ | 293 |  |  | $ | 610 |  |  | $ | 482 |  |
| Income tax expense | 73 |  |  | 100 |  |  | 188 |  |  | 164 |  |
| Effective tax rate | 26 | % |  | 34 | % |  | 31 | % |  | 34 | % |

[0000068505-17-000017:notes:149]
The Company recorded $73 million of net tax expense during the three months ended September 30, 2017, resulting in an effective tax rate of 26%, compared to $100 million of net tax expense during the three months ended October 1, 2016, resulting in an effective tax rate of 34%. The effective tax rate in the third quarter of 2017 was lower than the U.S. statutory tax rate of 35% primarily driven by a tax benefit due to the recognition of a U.S. capital loss. The effective tax rate in the third quarter of 2016 was lower than the U.S. statutory tax rate of 35% partly due to favorable discrete adjustments to deferred tax assets of foreign subsidiaries.

[0000068505-17-000017:notes:150]
The Company recorded $188 million of net tax expense during the nine months ended September 30, 2017, resulting in an effective tax rate of 31%, compared to $164 million of net tax expense during the nine months ended October 1, 2016, resulting in an effective tax rate of 34%. The effective tax rate in the first nine months of 2017 was lower than the U.S. statutory tax rate of 35% primarily due to a tax benefit due to the recognition of a U.S. capital loss. The effective tax rate in the first nine months of 2016 was lower than the U.S. statutory tax rate of 35% partly due to the recognition of excess tax benefits on share-based compensation.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-17-000017:notes:151]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace the existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods and services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU No. 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

[0000068505-17-000017:notes:152]
The Company has continued to analyze the impact of the new standard on its financial results based on an inventory of the Company's current contracts with customers. The Company has obtained an understanding of the new standard and currently believes that it will retain much of the same accounting treatment used to recognize revenue under current standards. Revenue on a significant portion of the Company's contracts is currently recognized under percentage of completion accounting applying a cost-to-cost method, including contracts for radio network deployments based on the ASTRO P25, TETRA, and LTE technologies, as well as certain offerings within its Smart Public Safety Solutions requiring significant integration (collectively "network integration contracts").

[0000068505-17-000017:notes:153]
Under the new standard, the Company must identify the distinct promises to transfer goods and/or services within its contracts using certain factors. For network integration contracts, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard will impact the Company's network integration contracts that include devices and accessories, with the resulting impact being revenue recognized earlier as control of the devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's network integration contracts, it will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in the Company's contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000017:notes:154]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While the Company has contracts which fall under these rules in the current standard, it has not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, the Company does not anticipate a significant acceleration of revenue upon applying the new standard to its current contracts under these fact patterns.

[0000068505-17-000017:notes:155]
The new standard also requires the concept of transfer of control to determine whether an entity must present revenue from providing goods or services at the gross amount billed to a customer (as a principal) or at the net amount retained (as an agent). Therefore, an entity must assess whether it controls the goods or services provided to a customer before they are transferred. The new standard provides three indicators to assist entities in determining control. Under the current standard, eight indicators (including the three indicators under the new standard) exist to evaluate whether an entity should present revenue gross as a principal or net as an agent. Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and remaining three indicators under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, upon adoption of the new standard the Company will present associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses.

[0000068505-17-000017:notes:156]
Under current accounting standards, the Company expenses sales commissions as incurred. However, under ASU No. 2014-09, the Company will capitalize sales commissions as incremental costs to obtain a contract. Such costs will be classified as a contract asset and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-17-000017:notes:157]
The Company continues to evaluate the impact of ASU No. 2014-09 on its financial results and prepare for the adoption of the standard on January 1, 2018, including readying its internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. The Company expects to adopt this standard under the modified retrospective method of adoption, which recognizes the cumulative effect of transition as an adjustment to retained earnings for contracts that are not completed as of the adoption date, without restating prior period financial statements.

[0000068505-17-000017:notes:158]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000017:notes:159]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company on January 1, 2018 with early adoption permitted. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so, in which case it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000017:notes:160]
In October 2016, the FASB issued ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The Company intends to adopt the ASU on January 1, 2018. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company continues to assess the impact of this ASU but anticipates that the impact will be immaterial based on existing deferred taxes from intra-entity asset transfers other than inventory.

[0000068505-17-000017:notes:161]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash," which requires that the statement of cash flows explain the change during the period in total cash, which is inclusive of cash and cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. Restricted cash and restricted cash equivalents will be included with cash and cash equivalents when reconciling the beginning of period and end of period balances on the statement of cash flows upon adoption of this standard. The ASU is effective for the Company on January 1, 2018 with early adoption permitted. The Company intends to adopt the ASU on January 1, 2018. Upon adoption, the ASU requires retrospective application. The Company does not anticipate significant changes to the Company's financial statements and related disclosures from adoption of the ASU.

[0000068505-17-000017:notes:162]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The amendments in this update require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The amendment also allows for the service cost component of net periodic cost (benefit) to be eligible for capitalization when applicable. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The guidance on the income statement presentation of the components of net periodic cost (benefit) must be applied retrospectively, while the guidance limiting the capitalization of net periodic cost (benefit) in assets to the service cost component must be applied prospectively. The Company intends to adopt this ASU on January 1, 2018. Upon adoption, the Company plans to update the presentation of net periodic cost (benefit) accordingly, noting all components of the Company's net periodic cost (benefit), with the exception of the service cost component, will be presented outside of operating earnings. The estimated impact of adoption of the ASU will be a reclassification of certain components of net periodic benefit from operating earnings to other income (expense) in the amount of approximately $15 million and $29 million for the years ended December 31, 2017 and December 31, 2016, respectively.

[0000068505-17-000017:notes:163]
In August 2017, the FASB issued ASU No. 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and the timing of adoption.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-17-000017:notes:164]
[same as prior period, unchanged from 0000068505-17-000011:notes:158]

[0000068505-17-000017:notes:165]
[same as prior period, unchanged from 0000068505-17-000011:notes:159]

[0000068505-17-000017:notes:166]
On July 28, 2017, the Company announced its intention to purchase Plant Holdings, Inc., the parent company of Airbus DS Communications. This acquisition will expand the Company's software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

[0000068505-17-000017:notes:167]
[same as prior period, unchanged from 0000068505-17-000011:notes:160]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-17-000017:notes:168]
[same as prior period, unchanged from 0000068505-17-000011:notes:161]

[0000068505-17-000017:notes:169]
[same as prior period, unchanged from 0000068505-17-000011:notes:162]

[0000068505-17-000017:notes:170]
[same as prior period, unchanged from 0000068505-17-000011:notes:163]

[0000068505-17-000017:notes:171]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 46 |  |  | 10 |  |  | 13 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (57 | ) |  | (55 | ) |  | (24 | ) |  | (23 | ) |  | (3 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 11 |  |  | 9 |  |  | 4 |  |  | 3 |  |  | 2 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (7 | ) |
| Settlement loss | — |  |  | — |  |  | 21 |  |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | — |  |  | $ | — |  |  | $ | 12 |  |  | $ | (5 | ) |  | $ | (4 | ) |  | $ | (7 | ) |

[0000068505-17-000017:notes:172]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 138 |  |  | 138 |  |  | 30 |  |  | 41 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (172 | ) |  | (165 | ) |  | (71 | ) |  | (71 | ) |  | (9 | ) |  | (7 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 33 |  |  | 27 |  |  | 12 |  |  | 9 |  |  | 4 |  |  | 4 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (12 | ) |  | (20 | ) |
| Settlement loss | — |  |  | — |  |  | 46 |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (1 | ) |  | $ | — |  |  | $ | 20 |  |  | $ | (15 | ) |  | $ | (14 | ) |  | $ | (20 | ) |

[0000068505-17-000017:notes:173]
During the nine months ended September 30, 2017, the Company offered lump-sum settlements to certain participants in the Non-U.S. defined benefit plan within the United Kingdom. The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments. The window for the participant registration in the program closed during the second quarter. However, the Company accounted for settlements through the third quarter of 2017, as remaining lump-sum settlements were paid to participants. As a result of the actions taken through the first nine months of 2017, the Company recorded a settlement loss of $21 million and $46 million during the three and nine months ended September 30, 2017, which is recorded within Other Charges within the condensed consolidated statement of operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-17-000017:notes:174]
[same as prior period, unchanged from 0000068505-17-000011:notes:168]

[0000068505-17-000017:notes:175]
[same as prior period, unchanged from 0000068505-17-000011:notes:169]

[0000068505-17-000017:notes:176]
During the three months ended September 30, 2017, the Company recorded net reorganization of business charges of $8 million including $6 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $8 million were charges of $7 million related to employee separation costs and $1 million related to exit costs.

[0000068505-17-000017:notes:177]
During the nine months ended September 30, 2017, the Company recorded net reorganization of business charges of $30 million including $22 million of charges in Other charges and $8 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $30 million were charges of $30 million related to employee separation costs and $5 million related to exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000017:notes:178]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2017 to September 30, 2017:

[0000068505-17-000017:notes:179]
|  | January 1, 2017 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | September 30, 2017 |
| Exit costs | $ | 7 |  |  | $ | 5 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | 9 |  |
| Employee separation costs | 95 |  |  | 30 |  |  | (5 | ) |  | (74 | ) |  | 46 |  |
|  | $ | 102 |  |  | $ | 35 |  |  | $ | (5 | ) |  | $ | (77 | ) |  | $ | 55 |  |

[0000068505-17-000017:notes:180]
[same as prior period, unchanged from 0000068505-17-000011:notes:174]

[0000068505-17-000017:notes:181]
At January 1, 2017, the Company had $7 million of accruals for exit costs. During the nine months ended September 30, 2017, there were $5 million of additional charges and $3 million of cash payments related to the exit of leased facilities. The remaining accrual of $9 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at September 30, 2017, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-17-000017:notes:182]
[same as prior period, unchanged from 0000068505-17-000011:notes:176]

[0000068505-17-000017:notes:183]
At January 1, 2017, the Company had an accrual of $95 million for employee separation costs. The 2017 additional charges of $30 million represent severance costs for approximately 400 employees. The adjustment of $5 million reflects reversals for accruals no longer needed. The $74 million used reflects cash payments to severed employees. The remaining accrual of $46 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at September 30, 2017, is expected to be paid, primarily within one year, to approximately 500 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-17-000017:notes:184]
[same as prior period, unchanged from 0000068505-17-000011:notes:178]

[0000068505-17-000017:notes:185]
During the three months ended October 1, 2016, the Company recorded net reorganization of business charges of $7 million including $6 million of charges in Other charges and $1 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-17-000017:notes:186]
During the nine months ended October 1, 2016, the Company recorded net reorganization of business charges of $74 million including $48 million of charges in Other charges and $26 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $74 million were charges of: (i) $54 million related to employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-17-000017:notes:187]
[same as prior period, unchanged from 0000068505-17-000011:notes:181]

[0000068505-17-000017:notes:188]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Products | $ | 989 |  |  | $ | 920 |  |  | $ | 2,540 |  |  | $ | 2,423 |  |
| Services | 656 |  |  | 612 |  |  | 1,883 |  |  | 1,732 |  |
|  | $ | 1,645 |  |  | $ | 1,532 |  |  | $ | 4,423 |  |  | $ | 4,155 |  |

[0000068505-17-000017:notes:189]
[same as prior period, unchanged from 0000068505-17-000011:notes:183]

[0000068505-17-000017:notes:190]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Products | $ | 253 |  |  | $ | 225 |  |  | $ | 510 |  |  | $ | 404 |  |
| Services | 85 |  |  | 116 |  |  | 260 |  |  | 260 |  |
| Operating earnings | 338 |  |  | 341 |  |  | 770 |  |  | 664 |  |
| Total other expense | (52 | ) |  | (48 | ) |  | (160 | ) |  | (182 | ) |
| Earnings before income taxes | $ | 286 |  |  | $ | 293 |  |  | $ | 610 |  |  | $ | 482 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-17-000017:notes:191]
[same as prior period, unchanged from 0000068505-17-000011:notes:185]

[0000068505-17-000017:notes:192]
[same as prior period, unchanged from 0000068505-17-000011:notes:186]

[0000068505-17-000017:notes:193]
[same as prior period, unchanged from 0000068505-17-000011:notes:187]

[0000068505-17-000017:notes:194]
[same as prior period, unchanged from 0000068505-17-000011:notes:188]
