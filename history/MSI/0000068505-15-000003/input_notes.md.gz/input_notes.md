# MSI notes — 0000068505-15-000003


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-15-000003:notes:1]
Investments consist of the following:

[0000068505-15-000003:notes:2]
|  | Recorded Value |  | Less |  |  |
| December 31, 2014 | Investments |  | Unrealized Gains |  | Cost Basis |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Corporate bonds | 16 |  |  | — |  |  | 16 |  |
| Mutual funds | 2 |  |  | — |  |  | 2 |  |
| Common stock and equivalents | 71 |  |  | 70 |  |  | 1 |  |
|  | 103 |  |  | 70 |  |  | 33 |  |
| Other investments, at cost | 191 |  |  | — |  |  | 191 |  |
| Equity method investments | 22 |  |  | — |  |  | 22 |  |
|  | $ | 316 |  |  | $ | 70 |  |  | $ | 246 |  |

[0000068505-15-000003:notes:3]
|  | Recorded Value |
| December 31, 2013 | Investments |
| Available-for-sale securities: |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 15 |  |
| Corporate bonds | 7 |  |
| Mutual funds | 11 |  |
| Common stock and equivalents | 2 |  |
|  | 35 |  |
| Other investments, at cost | 182 |  |
| Equity method investments | 15 |  |
|  | $ | 232 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-15-000003:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2014 and 2013 were as follows:

[0000068505-15-000003:notes:5]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 14 |  |  | 14 |  |
| Corporate bonds | — |  |  | 16 |  |  | 16 |  |
| Mutual funds | — |  |  | 2 |  |  | 2 |  |
| Common stock and equivalents | 71 |  |  | — |  |  | 71 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Interest agreement derivative contracts | — |  |  | 2 |  |  | 2 |  |

[0000068505-15-000003:notes:6]
| December 31, 2013 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | — |  |  | 4 |  |  | 4 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 15 |  |  | 15 |  |
| Corporate bonds | — |  |  | 7 |  |  | 7 |  |
| Mutual funds | — |  |  | 11 |  |  | 11 |  |
| Common stock and equivalents | 2 |  |  | — |  |  | 2 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest agreement derivative contracts | — |  |  | 3 |  |  | 3 |  |


## msi:LongTermCustomerFinancingAndSalesOfReceivablesTextBlock

[0000068505-15-000003:notes:7]
Long-term Customer Financing and Sales of Receivables

[0000068505-15-000003:notes:8]
Long-term Customer Financing

[0000068505-15-000003:notes:9]
Long-term receivables consist of trade receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-15-000003:notes:10]
| December 31 | 2014 |  | 2013 |
| Long-term receivables | $ | 49 |  |  | $ | 27 |  |
| Less current portion | (18 | ) |  | (26 | ) |
| Non-current long-term receivables, net | $ | 31 |  |  | $ | 1 |  |

[0000068505-15-000003:notes:11]
The current portion of long-term receivables is included in Accounts receivable and the non-current portion of long-term receivables is included in Other assets in the Company’s consolidated balance sheets. There was $1 million Interest income recognized on long-term receivables for the year ended December 31, 2014. There was no interest income recognized on long-term receivables for the year ended 2013 and $5 million for the year ended 2012.

[0000068505-15-000003:notes:12]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $293 million at December 31, 2014, compared to $50 million at December 31, 2013.

[0000068505-15-000003:notes:13]
Sales of Receivables

[0000068505-15-000003:notes:14]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements while others are sold to third-parties. The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-15-000003:notes:15]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2014, 2013 and 2012.

[0000068505-15-000003:notes:16]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Cumulative annual proceeds received from sales: |  |  |  |  |  |
| Accounts receivable sales proceeds | $ | 50 |  |  | $ | 14 |  |  | $ | 12 |  |
| Long-term receivables sales proceeds | 124 |  |  | 131 |  |  | 178 |  |
| Total proceeds from receivable sales | $ | 174 |  |  | $ | 145 |  |  | $ | 190 |  |

[0000068505-15-000003:notes:17]
At December 31, 2014, the Company had retained servicing obligations for $496 million of long-term receivables, compared to $434 million of long-term receivables at December 31, 2013.  Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-15-000003:notes:18]
Credit Quality of Customer Financing Receivables and Allowance for Credit Losses

[0000068505-15-000003:notes:19]
An aging analysis of financing receivables at December 31, 2014 and December 31, 2013 is as follows:

[0000068505-15-000003:notes:20]
| December 31, 2014 | TotalLong-termReceivable |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 14 |  |  | $ | — |  |
| Commercial loans and leases secured | 35 |  |  | 12 |  |
| Total gross long-term receivables, including current portion | $ | 49 |  |  | $ | 12 |  |

[0000068505-15-000003:notes:21]
| December 31, 2013 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 26 |  |  | 10 |  |  | 2 |  |  | 10 |  |
| Total gross long-term receivables, including current portion | $ | 27 |  |  | $ | 10 |  |  | $ | 2 |  |  | $ | 10 |  |

[0000068505-15-000003:notes:22]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned and comparable to the rating systems utilized by independent rating agencies.

[0000068505-15-000003:notes:23]
The Company’s policy for valuing the allowance for credit losses is to review all customer financing receivables for collectability on an individual receivable basis.  For those receivables where collection risk is probable, the Company calculates the value of impairment based on the net present value of expected future cash flows from the customer.

[0000068505-15-000003:notes:24]
The Company had a total of $12 million of financing receivables past due over 90 days as of December 31, 2014 in relation to two loans. The Company is not accruing interest on these loans as of December 31, 2014, which are adequately reserved.


## msi:OtherChargesTableTextBlock

[0000068505-15-000003:notes:25]
Other charges (income) included in Operating earnings (loss) consist of the following:

[0000068505-15-000003:notes:26]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (see Note 14) | $ | 4 |  |  | $ | 1 |  |  | $ | 1 |  |
| Reorganization of businesses (see Note 13) | 64 |  |  | 70 |  |  | 27 |  |
| Settlement of pension plan, including transaction fees (see Note 7) | 1,917 |  |  | — |  |  | — |  |
| Legal and related insurance matters, net | 8 |  |  | — |  |  | (16 | ) |
| Gain on sale of building and land | (21 | ) |  | — |  |  | — |  |
|  | $ | 1,972 |  |  | $ | 71 |  |  | $ | 12 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-15-000003:notes:27]
The following table displays the net charges incurred by segment:

[0000068505-15-000003:notes:28]
| Year ended December 31 | 2013 |
| Products | $ | 57 |  |
| Services | 29 |  |
|  | $ | 86 |  |

[0000068505-15-000003:notes:29]
| Year ended December 31 | 2014 |
| Products | $ | 48 |  |
| Services | 25 |  |
|  | $ | 73 |  |

[0000068505-15-000003:notes:30]
| Year ended December 31 | 2012 |
| Products | $ | 22 |  |
| Services | 11 |  |
|  | $ | 33 |  |


## msi:RetirementBenefitsPolicyPolicyTextBlock

[0000068505-15-000003:notes:31]
Retirement Benefits:    The Company records annual expenses relating to its pension benefit and postretirement plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, turnover rates and health care cost trend rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s consolidated balance sheets using a December 31 measurement date.


## msi:SalesAndUseTaxesPolicyTextBlock

[0000068505-15-000003:notes:32]
Sales and Use Taxes:     The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes, on a net basis with such taxes excluded from revenue.


## msi:ScheduleOfAccumulatedBenefitObligationsForPlansTableTextBlock

[0000068505-15-000003:notes:33]
The accumulated benefit obligations for the plans were as follows:

[0000068505-15-000003:notes:34]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |
| December 31 | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Accumulated benefit obligation | $ | 4,536 |  |  | $ | 7,317 |  |  | $ | 2,059 |  |  | $ | 1,900 |  |


## msi:ScheduleOfAccumulatedOtherComprehensiveIncomeLossWithInConsolidatedStatementsOfStockHoldersEquityTableTextBlock

[0000068505-15-000003:notes:35]
Derivative instruments activity, net of tax, included in Accumulated other comprehensive loss within the consolidated statements of stockholders’ equity for the years ended December 31, 2014, 2013 and 2012 were as follows:

[0000068505-15-000003:notes:36]
|  | 2014 |  | 2013 |  | 2012 |
| Balance at January 1 | $ | (1 | ) |  | $ | 1 |  |  | $ | (3 | ) |
| Increase (decrease) in fair value | — |  |  | (1 | ) |  | 3 |  |
| Reclassifications to earnings, net of tax | 1 |  |  | (1 | ) |  | 1 |  |
| Balance at December 31 | $ | — |  |  | $ | (1 | ) |  | $ | 1 |  |


## msi:ScheduleOfComponentsOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0000068505-15-000003:notes:37]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-15-000003:notes:38]
| December 31 | 2014 |  | 2013 |
| Inventory | $ | 34 |  |  | $ | 46 |  |
| Accrued liabilities and allowances | 148 |  |  | 129 |  |
| Employee benefits | 799 |  |  | 814 |  |
| Capitalized items | 379 |  |  | 144 |  |
| Tax basis differences on investments | (10 | ) |  | 17 |  |
| Depreciation tax basis differences on fixed assets | 52 |  |  | 12 |  |
| Undistributed non-U.S. earnings | (18 | ) |  | (6 | ) |
| Tax carryforwards | 1,246 |  |  | 1,294 |  |
| Business reorganization | 22 |  |  | 39 |  |
| Warranty and customer liabilities | 19 |  |  | 19 |  |
| Deferred revenue and costs | 136 |  |  | 159 |  |
| Valuation allowances | (226 | ) |  | (200 | ) |
| Deferred charges | 39 |  |  | 38 |  |
| Other | (38 | ) |  | (64 | ) |
|  | $ | 2,582 |  |  | $ | 2,441 |  |


## msi:ScheduleOfCorporateRelatedExpensesAndAssetsTableTextBlock

[0000068505-15-000003:notes:39]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Products | $ | 87 |  |  | $ | 90 |  |  | $ | 90 |  |  | $ | 94 |  |  | $ | 93 |  |  | $ | 87 |  |
| Services | 94 |  |  | 79 |  |  | 80 |  |  | 75 |  |  | 64 |  |  | 63 |  |
|  | $ | 181 |  |  | $ | 169 |  |  | $ | 170 |  |  | $ | 169 |  |  | $ | 157 |  |  | $ | 150 |  |


## msi:ScheduleOfDefinedBenefitPlanTargetandActualAssetAllocationTableTextBlock

[0000068505-15-000003:notes:40]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-15-000003:notes:41]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 41 | % |  | 55 | % |  | 37 | % |  | 57 | % |
| Fixed income securities | 44 | % |  | 43 | % |  | 42 | % |  | 42 | % |
| Cash and other investments | 15 | % |  | 2 | % |  | 21 | % |  | 1 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 43 | % |  | 55 | % |  | 20 | % |  | 58 | % |
| Fixed income securities | 44 | % |  | 42 | % |  | 20 | % |  | 40 | % |
| Cash and other investments | 13 | % |  | 3 | % |  | 60 | % |  | 2 | % |


## msi:ScheduleOfEarningsFromContinuingOperationsBeforeIncomeTaxesTableTextBlock

[0000068505-15-000003:notes:42]
Components of earnings (loss) from continuing operations before income taxes are as follows:

[0000068505-15-000003:notes:43]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| United States | $ | (1,355 | ) |  | $ | 585 |  |  | $ | 566 |  |
| Other nations | 194 |  |  | 295 |  |  | 315 |  |
|  | $ | (1,161 | ) |  | $ | 880 |  |  | $ | 881 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-15-000003:notes:44]
Compensation expense for the Company’s employee stock options, stock appreciation rights, employee stock purchase plans, RS and RSUs was as follows:

[0000068505-15-000003:notes:45]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 10 |  |  | $ | 16 |  |  | $ | 20 |  |
| Selling, general and administrative expenses | 61 |  |  | 73 |  |  | 88 |  |
| Research and development expenditures | 23 |  |  | 31 |  |  | 38 |  |
| Share-based compensation expense included in Operating earnings | 94 |  |  | 120 |  |  | 146 |  |
| Tax benefit | 30 |  |  | 37 |  |  | 49 |  |
| Share-based compensation expense, net of tax | $ | 64 |  |  | $ | 83 |  |  | $ | 97 |  |
| Decrease in basic earnings per share | $ | (0.28 | ) |  | $ | (0.31 | ) |  | $ | (0.33 | ) |
| Decrease in diluted earnings per share | $ | (0.28 | ) |  | $ | (0.31 | ) |  | $ | (0.33 | ) |
| Share-based compensation expense in discontinued operations | $ | 20 |  |  | $ | 33 |  |  | $ | 38 |  |


## msi:ScheduleOfExpectedFutureServiceBenefitPaymentsTableTextBlock

[0000068505-15-000003:notes:46]
The following benefit payments are expected to be paid:

[0000068505-15-000003:notes:47]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2015 | $ | 95 |  |  | $ | 42 |  |  | $ | 20 |  |
| 2016 | 93 |  |  | 43 |  |  | 19 |  |
| 2017 | 108 |  |  | 44 |  |  | 18 |  |
| 2018 | 122 |  |  | 45 |  |  | 17 |  |
| 2019 | 143 |  |  | 46 |  |  | 16 |  |
| 2020-2024 | 1,030 |  |  | 245 |  |  | 67 |  |


## msi:ScheduleOfFederalStatutoryTaxRateAndIncomeTaxExpenseTableTextBlock

[0000068505-15-000003:notes:48]
Differences between income tax expense (benefit) computed at the U.S. federal statutory tax rate of 35% and income tax expense (benefit) as reflected in the consolidated statements of operations are as follows:

[0000068505-15-000003:notes:49]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Income tax expense at statutory rate | $ | (406 | ) |  | $ | 308 |  |  | $ | 308 |  |
| Tax on non-U.S. earnings | (27 | ) |  | 17 |  |  | (10 | ) |
| State income taxes, net of federal benefit | (30 | ) |  | 8 |  |  | (32 | ) |
| Recognition of previously unrecognized income tax benefits | (29 | ) |  | 6 |  |  | — |  |
| Other provisions | 9 |  |  | (4 | ) |  | (10 | ) |
| Valuation allowances | 55 |  |  | (3 | ) |  | (60 | ) |
| Section 199 deduction | (12 | ) |  | (14 | ) |  | (14 | ) |
| Tax on undistributed non-U.S. earnings | (19 | ) |  | (22 | ) |  | 29 |  |
| Research credits | (6 | ) |  | (18 | ) |  | — |  |
| Tax benefit of repatriated non-U.S. earnings | — |  |  | (337 | ) |  | — |  |
|  | $ | (465 | ) |  | $ | (59 | ) |  | $ | 211 |  |


## msi:ScheduleOfIncomeTaxExpenseBenefitTableTextBlock

[0000068505-15-000003:notes:50]
Components of income tax expense (benefit) are as follows:

[0000068505-15-000003:notes:51]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| United States | $ | 14 |  |  | $ | 29 |  |  | $ | 5 |  |
| Other nations | 67 |  |  | 234 |  |  | 91 |  |
| States (U.S.) | 11 |  |  | 12 |  |  | 1 |  |
| Current income tax expense | 92 |  |  | 275 |  |  | 97 |  |
| United States | (503 | ) |  | (368 | ) |  | 192 |  |
| Other nations | (11 | ) |  | 35 |  |  | (29 | ) |
| States (U.S.) | (43 | ) |  | (1 | ) |  | (49 | ) |
| Deferred income tax expense (benefit) | (557 | ) |  | (334 | ) |  | 114 |  |
| Total income tax expense (benefit) | $ | (465 | ) |  | $ | (59 | ) |  | $ | 211 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-15-000003:notes:52]
Other liabilities consist of the following:

[0000068505-15-000003:notes:53]
| December 31 | 2014 |  | 2013 |
| Defined benefit plans | $ | 1,611 |  |  | $ | 1,751 |  |
| Postretirement health care benefit plan | 49 |  |  | 117 |  |
| Deferred revenue | 139 |  |  | 162 |  |
| Unrecognized tax benefits | 54 |  |  | 99 |  |
| Other | 158 |  |  | 185 |  |
|  | $ | 2,011 |  |  | $ | 2,314 |  |


## msi:ScheduleOfPensionAndPostretirementHealthCarePlanAssetsTextBlockTableTextBlock

[0000068505-15-000003:notes:54]
Non-U.S. Pension Benefit Plans

[0000068505-15-000003:notes:55]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 194 |  |  | $ | — |  |  | $ | 194 |  |
| Commingled equity funds | — |  |  | 569 |  |  | 569 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 26 |  |  | 26 |  |
| Corporate bonds | — |  |  | 316 |  |  | 316 |  |
| Commingled bond funds | — |  |  | 399 |  |  | 399 |  |
| Commingled short-term investment funds | — |  |  | 9 |  |  | 9 |  |
| Total investment securities | $ | 194 |  |  | $ | 1,319 |  |  | $ | 1,513 |  |
| Cash |  |  |  |  | 233 |  |
| Accrued income receivable |  |  |  |  | 5 |  |
| Insurance contracts |  |  |  |  | 55 |  |
| Fair value plan assets |  |  |  |  | $ | 1,806 |  |

[0000068505-15-000003:notes:56]
The table above includes securities on loan as part of a securities lending arrangement of $16 million of common stock and equivalents and $12 million of corporate bonds. All securities on loan are fully collateralized.

[0000068505-15-000003:notes:57]
The following table summarizes the changes in fair value of the Level 3 assets:

[0000068505-15-000003:notes:58]
|  | 2014 |
| Balance at January 1 | $ | 26 |  |
| Transfers to Level 2 | (14 | ) |
| Loss on assets held | (1 | ) |
| Payments received for securities sold | (10 | ) |
| Purchases | 1 |  |
| Other | (2 | ) |
| Balance at December 31 | $ | — |  |

[0000068505-15-000003:notes:59]
| December 31, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Common stock and equivalents | $ | 172 |  |  | $ | — |  |  | $ | — |  |  | $ | 172 |  |
| Commingled equity funds | — |  |  | 558 |  |  | — |  |  | 558 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 21 |  |  | 3 |  |  | 24 |  |
| Corporate bonds | — |  |  | 289 |  |  | 23 |  |  | 312 |  |
| Commingled bond funds | — |  |  | 361 |  |  | — |  |  | 361 |  |
| Commingled short-term investment funds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total investment securities | $ | 172 |  |  | $ | 1,240 |  |  | $ | 26 |  |  | $ | 1,438 |  |
| Accrued income receivable |  |  |  |  |  |  | 61 |  |
| Insurance contracts |  |  |  |  |  |  | 14 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,513 |  |

[0000068505-15-000003:notes:60]
Postretirement Health Care Benefits Plan

[0000068505-15-000003:notes:61]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Commingled equity funds | — |  |  | 13 |  |  | 13 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 11 |  |  | 11 |  |
| Other government bonds | — |  |  | 2 |  |  | 2 |  |
| Corporate bonds | — |  |  | 18 |  |  | 18 |  |
| Commingled bond funds | — |  |  | — |  |  | — |  |
| Commingled short-term investment funds | — |  |  | 99 |  |  | 99 |  |
| Fair value plan assets | $ | 20 |  |  | $ | 143 |  |  | $ | 163 |  |

[0000068505-15-000003:notes:62]
The table above includes no securities on loan as part of a securities lending arrangement.

[0000068505-15-000003:notes:63]
| December 31, 2013 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 38 |  |  | $ | — |  |  | $ | 38 |  |
| Commingled equity funds | — |  |  | 55 |  |  | 55 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 6 |  |  | 6 |  |
| Other government bonds | — |  |  | 1 |  |  | 1 |  |
| Corporate bonds | — |  |  | 9 |  |  | 9 |  |
| Commingled bond funds | — |  |  | 49 |  |  | 49 |  |
| Commingled short-term investment funds | — |  |  | 3 |  |  | 3 |  |
| Fair value plan assets | $ | 38 |  |  | $ | 123 |  |  | $ | 161 |  |

[0000068505-15-000003:notes:64]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2014 and 2013 were as follows:

[0000068505-15-000003:notes:65]
U.S. Pension Benefit Plans

[0000068505-15-000003:notes:66]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 902 |  |  | $ | — |  |  | $ | 902 |  |
| Commingled equity funds | — |  |  | 565 |  |  | 565 |  |
| Preferred stock | 3 |  |  | — |  |  | 3 |  |
| Government, agency and government-sponsored enterprise obligations | — |  |  | 520 |  |  | 520 |  |
| Other government bonds | — |  |  | 91 |  |  | 91 |  |
| Corporate bonds | — |  |  | 795 |  |  | 795 |  |
| Mortgage-backed bonds | — |  |  | 16 |  |  | 16 |  |
| Commingled short-term investment funds | — |  |  | 422 |  |  | 422 |  |
| Total investment securities | $ | 905 |  |  | $ | 2,409 |  |  | $ | 3,314 |  |
| Accrued income receivable |  |  |  |  | 3 |  |
| Fair value plan assets |  |  |  |  | $ | 3,317 |  |

[0000068505-15-000003:notes:67]
| December 31, 2013 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 1,424 |  |  | $ | — |  |  | $ | 1,424 |  |
| Commingled equity funds | — |  |  | 2,045 |  |  | 2,045 |  |
| Preferred stock | 6 |  |  | — |  |  | 6 |  |
| Government, agency and government-sponsored enterprise obligations | — |  |  | 238 |  |  | 238 |  |
| Other government bonds | — |  |  | 42 |  |  | 42 |  |
| Corporate bonds | — |  |  | 336 |  |  | 336 |  |
| Mortgage-backed bonds | — |  |  | 15 |  |  | 15 |  |
| Commingled bond funds | — |  |  | 1,862 |  |  | 1,862 |  |
| Commingled short-term investment funds | — |  |  | 96 |  |  | 96 |  |
| Total investment securities | $ | 1,430 |  |  | $ | 4,634 |  |  | $ | 6,064 |  |
| Accrued income receivable |  |  |  |  | 7 |  |
| Fair value plan assets |  |  |  |  | $ | 6,071 |  |


## msi:ScheduleOfStatusOfCompanyPensionPlansTableTextBlock

[0000068505-15-000003:notes:68]
The status of the Company’s plans are as follows:

[0000068505-15-000003:notes:69]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 7,317 |  |  | $ | 8,288 |  |  | $ | 1,904 |  |  | $ | 1,771 |  |  | $ | 278 |  |  | $ | 322 |  |
| Service cost | — |  |  | — |  |  | 15 |  |  | 11 |  |  | 2 |  |  | 2 |  |
| Interest cost | 370 |  |  | 352 |  |  | 80 |  |  | 69 |  |  | 10 |  |  | 11 |  |
| Plan amendments | — |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | — |  |
| Settlements | (4,227 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss (gain) | 1,357 |  |  | (1,012 | ) |  | 263 |  |  | 91 |  |  | (14 | ) |  | (37 | ) |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (146 | ) |  | (1 | ) |  | — |  |  | — |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Benefit payments | (281 | ) |  | (311 | ) |  | (43 | ) |  | (39 | ) |  | (23 | ) |  | (20 | ) |
| Benefit obligation at December 31 | 4,536 |  |  | 7,317 |  |  | 2,075 |  |  | 1,904 |  |  | 212 |  |  | 278 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | 6,071 |  |  | 5,426 |  |  | 1,513 |  |  | 1,343 |  |  | 161 |  |  | 155 |  |
| Return on plan assets | 642 |  |  | 806 |  |  | 191 |  |  | 182 |  |  | 21 |  |  | 22 |  |
| Company contributions | 1,112 |  |  | 150 |  |  | 237 |  |  | 32 |  |  | — |  |  | — |  |
| Settlements | (3,196 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (96 | ) |  | (8 | ) |  | — |  |  | — |  |
| Lump sum settlements | (1,031 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Benefit payments | (281 | ) |  | (311 | ) |  | (41 | ) |  | (38 | ) |  | (19 | ) |  | (16 | ) |
| Fair value at December 31 | 3,317 |  |  | 6,071 |  |  | 1,806 |  |  | 1,513 |  |  | 163 |  |  | 161 |  |
| Funded status of the plan | (1,219 | ) |  | (1,246 | ) |  | (269 | ) |  | (391 | ) |  | (49 | ) |  | (117 | ) |
| Unrecognized net loss | 1,846 |  |  | 2,732 |  |  | 593 |  |  | 483 |  |  | 109 |  |  | 143 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (35 | ) |  | (44 | ) |  | (83 | ) |  | (92 | ) |
| Prepaid (accrued) pension cost | $ | 627 |  |  | $ | 1,486 |  |  | $ | 289 |  |  | $ | 48 |  |  | $ | (23 | ) |  | $ | (66 | ) |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Non-current benefit liability | $ | (1,219 | ) |  | $ | (1,246 | ) |  | $ | (269 | ) |  | $ | (391 | ) |  | $ | (49 | ) |  | $ | (117 | ) |
| Deferred income taxes | 701 |  |  | 1,002 |  |  | 51 |  |  | 28 |  |  | 10 |  |  | 19 |  |
| Accumulated other comprehensive loss | 1,145 |  |  | 1,730 |  |  | 507 |  |  | 411 |  |  | 16 |  |  | 32 |  |
| Prepaid (accrued) pension cost | $ | 627 |  |  | $ | 1,486 |  |  | $ | 289 |  |  | $ | 48 |  |  | $ | (23 | ) |  | $ | (66 | ) |


## msi:ScheduleOfSummaryOfOpenTaxYearsByMajorJurisdictionTableTextBlock

[0000068505-15-000003:notes:70]
A summary of open tax years by major jurisdiction is presented below:

[0000068505-15-000003:notes:71]
| Jurisdiction | Tax Years |
| United States | 2008-2014 |
| China | 2002-2014 |
| France | 2010-2014 |
| Germany | 2008-2014 |
| India | 1997-2014 |
| Israel | 2012-2014 |
| Japan | 2011-2014 |
| Malaysia | 2009-2014 |
| Singapore | 2010-2014 |
| United Kingdom | 2008-2014 |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineBenefitObligationsForPlansTableTextBlock

[0000068505-15-000003:notes:72]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-15-000003:notes:73]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Discount rate | 4.30 | % |  | 5.15 | % |  | 3.19 | % |  | 4.24 | % |  | 3.90 | % |  | 4.65 | % |
| Future compensation increase rate | n/a |  |  | n/a |  |  | 2.54 | % |  | 2.58 | % |  | n/a |  |  | n/a |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineCostsForPlansTableTextBlock

[0000068505-15-000003:notes:74]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-15-000003:notes:75]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Discount rate | 5.15 | % |  | 4.35 | % |  | 4.24 | % |  | 4.20 | % |  | 4.65 | % |  | 3.80 | % |
| Investment return assumption | 7.00 | % |  | 7.00 | % |  | 5.92 | % |  | 6.13 | % |  | 7.00 | % |  | 7.00 | % |


## msi:ShareBasedCompensationCostsPolicyTextBlock

[0000068505-15-000003:notes:76]
Share-Based Compensation Costs:    The Company has incentive plans that reward employees with stock options, stock appreciation rights, restricted stock and restricted stock units, as well as an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.


## msi:SigmaFundPolicyTextBlock

[0000068505-15-000003:notes:77]
Sigma Fund:    Prior to December 2013, the Company invested most of its U.S. dollar-denominated cash in a fund (the “Sigma Fund”) which was managed by independent investment management firms under specific investment guidelines restricting the type of investments held and their time to maturity. In December 2013, the Company completed the liquidation of the Sigma Fund and migrated the international U.S. dollar denominated cash to a U.S. dollar cash pool invested primarily in U.S. dollar prime money market funds.


## msi:UseOfEstimatesPolicyTextBlock

[0000068505-15-000003:notes:78]
Use of Estimates:   The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates


## msi:ValuationAndQualifyingAccountsTableTextBlock

[0000068505-15-000003:notes:79]
The following table presents the valuation and qualifying account activity for the years ended December 31, 2014, 2013 and 2012:

[0000068505-15-000003:notes:80]
|  | Balance atJanuary 1 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31 |
| 2014 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 53 |  |  | $ | 19 |  |  | $ | (35 | ) |  | $ | (2 | ) |  | $ | 35 |  |
| Inventory reserves | 125 |  |  | 24 |  |  | (15 | ) |  | (3 | ) |  | 131 |  |
| 2013 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 50 |  |  | 13 |  |  | (8 | ) |  | (2 | ) |  | 53 |  |
| Inventory reserves | 112 |  |  | 25 |  |  | (14 | ) |  | 2 |  |  | 125 |  |
| 2012 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 44 |  |  | 7 |  |  | (3 | ) |  | 2 |  |  | 50 |  |
| Inventory reserves | 126 |  |  | 17 |  |  | (31 | ) |  | — |  |  | 112 |  |

[0000068505-15-000003:notes:81]
* Adjustments include translation adjustments


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-15-000003:notes:82]
Other Financial Data

[0000068505-15-000003:notes:83]
Statement of Operations Information

[0000068505-15-000003:notes:84]
Other Charges (income)

[0000068505-15-000003:notes:85]
During 2014, the Company completed the sale of a building and parcel of land on its Schaumburg, Illinois campus with a net book value of $3 million for net cash proceeds of $24 million resulting in a gain on sale of $21 million. Also, the Company recognized an $8 million loss related to the settlement of a legal matter.

[0000068505-15-000003:notes:86]
During 2012, the Company recorded a $16 million gain in connection with the settlement of a legal matter involving the legacy paging business.

[0000068505-15-000003:notes:87]
Other Income (Expense)

[0000068505-15-000003:notes:88]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-15-000003:notes:89]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (147 | ) |  | $ | (132 | ) |  | $ | (108 | ) |
| Interest income | 21 |  |  | 19 |  |  | 42 |  |
|  | $ | (126 | ) |  | $ | (113 | ) |  | $ | (66 | ) |
| Other: |  |  |  |  |  |
| Loss from the extinguishment of long-term debt | $ | (37 | ) |  | $ | — |  |  | $ | (6 | ) |
| Investment impairments | — |  |  | (3 | ) |  | (4 | ) |
| Foreign currency loss | (7 | ) |  | (9 | ) |  | (1 | ) |
| Gains on equity method investments | 16 |  |  | 10 |  |  | 3 |  |
| Other | (6 | ) |  | 11 |  |  | 9 |  |
|  | $ | (34 | ) |  | $ | 9 |  |  | $ | 1 |  |

[0000068505-15-000003:notes:90]
Earnings Per Common Share

[0000068505-15-000003:notes:91]
Basic and diluted earnings per common share from both continuing operations and net earnings attributable to Motorola Solutions, Inc. is computed as follows:

[0000068505-15-000003:notes:92]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings (loss) from Continuing Operations |  | Net Earnings |
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | (697 | ) |  | $ | 933 |  |  | $ | 670 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |  | $ | 881 |  |
| Weighted average common shares outstanding | 245.6 |  |  | 266.0 |  |  | 292.1 |  |  | 245.6 |  |  | 266.0 |  |  | 292.1 |  |
| Per share amount | $ | (2.84 | ) |  | $ | 3.51 |  |  | $ | 2.29 |  |  | $ | 5.29 |  |  | $ | 4.13 |  |  | $ | 3.02 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | (697 | ) |  | $ | 933 |  |  | $ | 670 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |  | $ | 881 |  |
| Weighted average common shares outstanding | 245.6 |  |  | 266.0 |  |  | 292.1 |  |  | 245.6 |  |  | 266.0 |  |  | 292.1 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards | — |  |  | 4.5 |  |  | 5.3 |  |  | — |  |  | 4.5 |  |  | 5.3 |  |
| Diluted weighted average common shares outstanding | 245.6 |  |  | 270.5 |  |  | 297.4 |  |  | 245.6 |  |  | 270.5 |  |  | 297.4 |  |
| Per share amount | $ | (2.84 | ) |  | $ | 3.45 |  |  | $ | 2.25 |  |  | $ | 5.29 |  |  | $ | 4.06 |  |  | $ | 2.96 |  |

[0000068505-15-000003:notes:93]
For the year ended December 31, 2014, the Company had a net loss from continuing operations and, accordingly, the basic and diluted weighted average shares outstanding are equal because any increase to the basic shares would be antidilutive, including the assumed exercise of 6.3 million stock options and the assumed vesting of 1.1 million restricted stock units. In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the years ended December 31, 2013 and December 31, 2012, the assumed exercise of 5.6 million and 5.9 million stock options, respectively, were excluded because their inclusion would have been antidilutive.

[0000068505-15-000003:notes:94]
Balance Sheet Information

[0000068505-15-000003:notes:95]
Investments

[0000068505-15-000003:notes:96]
During the years ended December 31, 2013 and 2012, the Company recorded investment impairment charges of $3 million and $4 million, respectively, representing other-than-temporary declines in the value of the Company’s equity investment portfolio. Investment impairment charges are included in Other within Other income (expense) in the Company’s consolidated statements of operations.

[0000068505-15-000003:notes:97]
Accounts Receivable, Net

[0000068505-15-000003:notes:98]
Accounts receivable, net, consist of the following:

[0000068505-15-000003:notes:99]
| December 31 | 2014 |  | 2013 |
| Accounts receivable | $ | 1,444 |  |  | $ | 1,422 |  |
| Less allowance for doubtful accounts | (35 | ) |  | (53 | ) |
|  | $ | 1,409 |  |  | $ | 1,369 |  |

[0000068505-15-000003:notes:100]
Inventories, Net

[0000068505-15-000003:notes:101]
Inventories, net, consist of the following:

[0000068505-15-000003:notes:102]
| December 31 | 2014 |  | 2013 |
| Finished goods | $ | 163 |  |  | $ | 157 |  |
| Work-in-process and production materials | 313 |  |  | 315 |  |
|  | 476 |  |  | 472 |  |
| Less inventory reserves | (131 | ) |  | (125 | ) |
|  | $ | 345 |  |  | $ | 347 |  |

[0000068505-15-000003:notes:103]
Other Current Assets

[0000068505-15-000003:notes:104]
Other current assets consist of the following:

[0000068505-15-000003:notes:105]
| December 31 | 2014 |  | 2013 |
| Costs and earnings in excess of billings | $ | 417 |  |  | $ | 405 |  |
| Tax-related deposits and refunds receivable | 103 |  |  | 107 |  |
| Zebra receivable for cash transferred | 49 |  |  | — |  |
| Other | 171 |  |  | 123 |  |
|  | $ | 740 |  |  | $ | 635 |  |

[0000068505-15-000003:notes:106]
In conjunction with the sale of the Enterprise business to Zebra, the Company transfered legal entities which maintained cash balances. Approximately $49 million of cash balances will be reimbursed by Zebra in accordance with the Acquisition Agreement.

[0000068505-15-000003:notes:107]
Property, Plant and Equipment, Net

[0000068505-15-000003:notes:108]
Property, plant and equipment, net, consist of the following:

[0000068505-15-000003:notes:109]
| December 31 | 2014 |  | 2013 |
| Land | $ | 18 |  |  | $ | 22 |  |
| Building | 559 |  |  | 582 |  |
| Machinery and equipment | 1,672 |  |  | 1,642 |  |
|  | 2,249 |  |  | 2,246 |  |
| Less accumulated depreciation | (1,700 | ) |  | (1,636 | ) |
|  | $ | 549 |  |  | $ | 610 |  |

[0000068505-15-000003:notes:110]
Depreciation expense for the years ended December 31, 2014, 2013 and 2012 was $169 million, $157 million and $150 million, respectively.

[0000068505-15-000003:notes:111]
Other Assets

[0000068505-15-000003:notes:112]
Other assets consist of the following:

[0000068505-15-000003:notes:113]
| December 31 | 2014 |  | 2013 |
| Intangible assets | $ | 23 |  |  | $ | 6 |  |
| Long-term receivables | 31 |  |  | 1 |  |
| Other | 91 |  |  | 82 |  |
|  | $ | 145 |  |  | $ | 89 |  |

[0000068505-15-000003:notes:114]
Accrued Liabilities

[0000068505-15-000003:notes:115]
Accrued liabilities consist of the following:

[0000068505-15-000003:notes:116]
| December 31 | 2014 |  | 2013 |
| Deferred revenue | $ | 355 |  |  | $ | 359 |  |
| Compensation | 190 |  |  | 315 |  |
| Billings in excess of costs and earnings | 358 |  |  | 295 |  |
| Tax liabilities | 91 |  |  | 85 |  |
| Customer liabilities | 55 |  |  | 52 |  |
| Dividend payable | 75 |  |  | 79 |  |
| Other | 582 |  |  | 578 |  |
|  | $ | 1,706 |  |  | $ | 1,763 |  |

[0000068505-15-000003:notes:117]
Other Liabilities

[0000068505-15-000003:notes:118]
Stockholders’ Equity Information

[0000068505-15-000003:notes:119]
Share Repurchase Program:  During 2014, the Company paid an aggregate of $2.5 billion, including transaction costs, to repurchase 39.4 million shares at an average price of $64.63 per share. During 2013, the Company paid an aggregate of $1.7 billion, including transaction costs, to repurchase 28.6 million shares at an average price of $59.30.  During 2012, the Company paid an aggregate of $2.4 billion, including transaction costs, to repurchase 49.6 million shares at an average price of $49.14.

[0000068505-15-000003:notes:120]
On November 4, 2014, the Company announced that its Board of Directors authorized up to $5.0 billion in additional funds for share repurchases, bringing the aggregate amount of the share repurchase program to $12.0 billion.  As of December 31, 2014, the Company had used approximately $7.8 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $4.2 billion of authority available for future repurchases.

[0000068505-15-000003:notes:121]
Payment of Dividends:  On July 31, 2014, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.31 per share to $0.34 per share of common stock.  During the years ended December 31, 2014, 2013, and 2012 the Company paid $318 million, $292 million, and $270 million respectively, in cash dividends to holders of its common stock.

[0000068505-15-000003:notes:122]
Accumulated Other Comprehensive Loss

[0000068505-15-000003:notes:123]
The following table displays the changes in Accumulated other comprehensive loss, net of tax, by component from January 1, 2014 to December 31, 2014:

[0000068505-15-000003:notes:124]
|  | Gains and Losses on Cash Flow Hedges |  | Unrealized Gains and Losses on Available-for-Sale Securities |  | Retirement Benefit Items |  | Foreign Currency Translation Adjustments |  | Total |
| Balance as of December 31, 2013 | $ | (1 | ) |  | $ | (2 | ) |  | $ | (2,188 | ) |  | $ | (96 | ) |  | $ | (2,287 | ) |
| Other comprehensive income (loss) before reclassifications | — |  |  | 46 |  |  | (718 | ) |  | (49 | ) |  | (721 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | 1 |  |  | — |  |  | 1,211 |  |  | (59 | ) |  | 1,153 |  |
| Net current-period other comprehensive income (loss) | 1 |  |  | 46 |  |  | 493 |  |  | (108 | ) |  | 432 |  |
| Balance as of December 31, 2014 | $ | — |  |  | $ | 44 |  |  | $ | (1,695 | ) |  | $ | (204 | ) |  | $ | (1,855 | ) |

[0000068505-15-000003:notes:125]
The following table displays the amounts reclassified from Accumulated other comprehensive loss and the affected line item in the consolidated statements of operations during 2014:

[0000068505-15-000003:notes:126]
| Years ended December 31 | 2014 |  | 2013 |  | Statement of Operations Location |
| Loss (gain) on cash flow hedges: |  |  |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | (1 | ) |  | Cost of sales |
|  | $ | 1 |  |  | $ | (1 | ) |  | Net of tax |
| Unrealized Gains and Losses on Available-for-Sale Securities: |  |  |  |  |  |
| Realized gain | $ | — |  |  | $ | (4 | ) |  | Gains on sales of investments and businesses, net |
|  | — |  |  | 1 |  |  | Tax benefit |
|  | $ | — |  |  | $ | (3 | ) |  | Net of tax |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Disposition of the Enterprise business | $ | (75 | ) |  | $ | — |  |  | Earnings from discontinued operations |
|  | 16 |  |  | — |  |  | Tax expense |
|  | $ | (59 | ) |  | $ | — |  |  | Net of tax |
| Retirement Benefit Items: |  |  |  |  |  |
| Amortization of prior-service costs | $ | (57 | ) |  | $ | (49 | ) |  | Selling, general, and administrative expenses |
| Amortization of actuarial net losses | 118 |  |  | 159 |  |  | Selling, general, and administrative expenses |
| Settlement of pension plan | 1,883 |  |  | — |  |  | Other charges |
| Disposition of the Enterprise business retirement benefits | (1 | ) |  | — |  |  | Earnings from discontinued operations |
|  | 1,943 |  |  | 110 |  |  | Total before tax |
|  | (732 | ) |  | (40 | ) |  | Tax benefit |
|  | $ | 1,211 |  |  | $ | 70 |  |  | Net of tax |
| Total reclassifications for the period, net of tax | $ | 1,153 |  |  | $ | 66 |  |  |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000068505-15-000003:notes:127]
Advertising Expense:    Advertising expenses, which are the external costs of marketing the Company’s products, are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000068505-15-000003:notes:128]
Cash Equivalents:    The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-15-000003:notes:129]
Commitments and Contingencies

[0000068505-15-000003:notes:130]
Lease Obligations

[0000068505-15-000003:notes:131]
The Company leases certain office, factory and warehouse space, land, and information technology and other equipment under principally non-cancelable operating leases. Rental expense, net of sublease income, for the years ended December 31, 2014, 2013 and 2012 was $62 million, $51 million, and $45 million, respectively.

[0000068505-15-000003:notes:132]
At December 31, 2014, future minimum lease obligations, net of minimum sublease rentals, for the next five years and beyond are as follows:

[0000068505-15-000003:notes:133]
| Year |  |
| 2015 | $ | 68 |  |
| 2016 | 56 |  |
| 2017 | 45 |  |
| 2018 | 35 |  |
| 2019 | 33 |  |
| Beyond | 217 |  |

[0000068505-15-000003:notes:134]
Purchase Obligations

[0000068505-15-000003:notes:135]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  In addition, we have entered into software license agreements which are firm commitments and are not cancelable.  As of December 31, 2014, the Company had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2017. The Company expects to make total payments of $40 million under these arrangements as follows: $23 million in 2015, $14 million in 2016, and $3 million in 2017.

[0000068505-15-000003:notes:136]
The Company outsources certain corporate functions, such as benefit administration and information technology related services, the longest of which is expected to expire in 2019. The remaining payments under these contracts are approximately $319 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-15-000003:notes:137]
Legal

[0000068505-15-000003:notes:138]
The Company is a defendant in various lawsuits, claims and actions that arise in the normal course of business.  While the outcome of these matters is currently not determinable, the Company does not expect the ultimate disposition of these matters to have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations.

[0000068505-15-000003:notes:139]
Indemnifications

[0000068505-15-000003:notes:140]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters.  In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third-parties for certain payments made by the Company.

[0000068505-15-000003:notes:141]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. The Company had no pending claims at December 31, 2014.

[0000068505-15-000003:notes:142]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.


## us-gaap:ConsolidationPolicyTextBlock

[0000068505-15-000003:notes:143]
Principles of Consolidation:    The consolidated financial statements include the accounts of  Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-15-000003:notes:144]
The consolidated financial statements as of December 31, 2014 and 2013 and for the years ended December 31, 2014, 2013 and 2012, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, statement of stockholder's equity, and cash flows for all periods presented.


## us-gaap:DebtDisclosureTextBlock

[0000068505-15-000003:notes:145]
Debt and Credit Facilities

[0000068505-15-000003:notes:146]
Long-Term Debt

[0000068505-15-000003:notes:147]
| December 31 | 2014 |  | 2013 |
| 6.0% senior notes due 2017 | $ | — |  |  | $ | 399 |  |
| 3.5% senior notes due 2021 | 395 |  |  | — |  |
| 3.75% senior notes due 2022 | 748 |  |  | 747 |  |
| 3.5% senior notes due 2023 | 594 |  |  | 593 |  |
| 4.0% senior notes due 2024 | 589 |  |  | — |  |
| 6.5% debentures due 2025 | 118 |  |  | 118 |  |
| 7.5% debentures due 2025 | 346 |  |  | 346 |  |
| 6.5% debentures due 2028 | 36 |  |  | 36 |  |
| 6.625% senior notes due 2037 | 54 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 400 |  |  | — |  |
| 5.22% debentures due 2097 | 91 |  |  | 89 |  |
| Other long-term debt | 36 |  |  | 58 |  |
|  | 3,407 |  |  | 2,440 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (7 | ) |  | 21 |  |
| Less: current portion | (4 | ) |  | (4 | ) |
| Long-term debt | $ | 3,396 |  |  | $ | 2,457 |  |

[0000068505-15-000003:notes:148]
During the year ended December 31, 2014, the Company redeemed $400 million aggregate principal amount outstanding of its 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, the Company recognized a loss of $37 million related to the redemption within Other income (expense) in the consolidated statement of operations. The Company issued an aggregate face principal amount of $1.4 billion including: (i) $600 million of 4.000% Senior Notes due 2024, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior Notes due 2021, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior Notes due 2044, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $394 million.

[0000068505-15-000003:notes:149]
During the year ended December 31, 2013, the Company issued an aggregate face principal amount of $600 million of 3.500% Senior Notes due March 1, 2023, recognizing net proceeds of $588 million, after debt issuance costs and debt discounts.

[0000068505-15-000003:notes:150]
During the year ended December 31, 2012, the Company issued an aggregate face principal amount of $750 million of 3.750% Senior Notes due 2022 (the “2022 Senior Notes”).  The Company also redeemed $400 million aggregate principal amount outstanding of its 5.375% Senior Notes due November 2012 for an aggregate purchase price of approximately $408 million.  After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $6 million related to this redemption within Other income (expense) in the consolidated statements of operations.  This debt was repurchased with a portion of the proceeds from the issuance of the 2022 Senior Notes.

[0000068505-15-000003:notes:151]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2015—$4 million; 2016—$5 million; 2017—$5 million; 2018—$6 million; and 2019—$11 million.

[0000068505-15-000003:notes:152]
Credit Facilities

[0000068505-15-000003:notes:153]
As of December 31, 2014, the Company had a $2.1 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019 which replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”). The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of December 31, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the twelve months ended December 31, 2014.

[0000068505-15-000003:notes:154]
As of December 31, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of December 31, 2014.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-15-000003:notes:155]
Risk Management

[0000068505-15-000003:notes:156]
Foreign Currency Risk

[0000068505-15-000003:notes:157]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate price fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure. Instruments that are designated as part of a hedging relationship must be effective at reducing the risk associated with the exposure being hedged and are designated as part of a hedging relationship at the inception of the contract. Accordingly, changes in the market values of hedge instruments must be highly correlated with changes in market values of the underlying hedged items both at the inception of the hedge and over the life of the hedge contract.

[0000068505-15-000003:notes:158]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows or investments based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company enters into derivative contracts for some forecasted transactions, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-15-000003:notes:159]
At December 31, 2014, the Company had outstanding foreign exchange contracts totaling $628 million, compared to $837 million outstanding at December 31, 2013.  Management believes that these financial instruments should not subject the Company to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset losses and gains on the underlying assets, liabilities and transactions, except for the ineffective portion of the instruments, which is charged to Other within Other income (expense) in the Company’s consolidated statements of operations.

[0000068505-15-000003:notes:160]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2014 and the corresponding positions as of December 31, 2013:

[0000068505-15-000003:notes:161]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2014 |  | 2013 |
| Euro | $ | 214 |  |  | $ | (132 | ) |
| Chinese Renminbi | (161 | ) |  | (181 | ) |
| Norwegian Krone | (90 | ) |  | (95 | ) |
| Australian Dollar | (42 | ) |  | (17 | ) |
| British Pound | 34 |  |  | 257 |  |

[0000068505-15-000003:notes:162]
Interest Rate Risk

[0000068505-15-000003:notes:163]
As part of its liability management program, one of the Company's European subsidiaries has outstanding interest rate agreements (“Interest Agreements”) relating to Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Interest Agreements change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The Interest Agreements are not accounted for as a part of a hedging relationship and, accordingly, the changes in the fair value of the Interest Agreements are included in Other income (expense) in the Company's consolidated statements of operations. The weighted average fixed rate payment on the Interest Agreements for the year ended December 31, 2014 was 4.02%. The fair value of the Interest Agreements was a liability position of $2 million at December 31, 2014, compared to a liability position of $3 million at December 31, 2013.

[0000068505-15-000003:notes:164]
Counterparty Risk

[0000068505-15-000003:notes:165]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of nonperformance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. At present time, all of the counterparties have investment grade credit ratings. The Company is not exposed to material credit risk with any single counterparty. As of December 31, 2014, the Company was exposed to an aggregate credit risk of approximately $1 million with all counterparties.

[0000068505-15-000003:notes:166]
Derivative Financial Instruments

[0000068505-15-000003:notes:167]
The following tables summarize the fair values and location in the consolidated balance sheets of all derivative financial instruments held by the Company at December 31, 2014 and 2013:

[0000068505-15-000003:notes:168]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2014 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 1 |  |  | Other assets |  | 5 |  |  | Other liabilities |
| Interest agreements | — |  |  | Other assets |  | 2 |  |  | Other liabilities |
| Total derivatives | $ | 1 |  |  |  |  | $ | 7 |  |  |  |

[0000068505-15-000003:notes:169]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2013 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 1 |  |  | Other liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 4 |  |  | Other assets |  | 1 |  |  | Other liabilities |
| Interest agreements | — |  |  | Other assets |  | 3 |  |  | Other liabilities |
| Total derivatives not designated as hedging instruments | 4 |  |  |  |  | 4 |  |  |  |
| Total derivatives | $ | 4 |  |  |  |  | $ | 5 |  |  |  |

[0000068505-15-000003:notes:170]
The following table summarizes the effect of derivative instruments in the Company's consolidated statements of operations, including immaterial amounts related to discontinued operations, for the years ended December 31, 2014, 2013 and 2012:

[0000068505-15-000003:notes:171]
|  | December 31 | Statement ofOperations Location |
| Gain (Loss) on Derivative Instruments | 2014 |  | 2013 |  | 2012 |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |
| Interest rate contracts | $ | 1 |  |  | $ | 2 |  |  | $ | (1 | ) | Other income (expense) |
| Foreign exchange contracts | (5 | ) |  | 6 |  |  | (13 | ) | Other income (expense) |
| Total derivatives not designated as hedging instruments | $ | (4 | ) |  | $ | 8 |  |  | $ | (14 | ) |  |

[0000068505-15-000003:notes:172]
The following table summarizes the gains and losses reclassified from Accumulated other comprehensive loss into Net earnings (loss), including immaterial amounts related to discontinued operations, for the years ended December 31, 2014, 2013 and 2012:

[0000068505-15-000003:notes:173]
|  | December 31 | Financial StatementLocation |
| Foreign Exchange Contracts | 2014 |  | 2013 |  | 2012 |
| Derivatives in cash flow hedging relationships |  |  |  |  |  |  |
| Other comprehensive gains (losses) before reclassifications | $ | — |  |  | $ | (1 | ) |  | $ | 3 |  | Accumulated othercomprehensive loss |
| Gains (losses) reclassified from Accumulated other comprehensive loss into Net earnings (loss) | (1 | ) |  | 1 |  |  | (1 | ) | Cost of sales |


## us-gaap:DerivativesPolicyTextBlock

[0000068505-15-000003:notes:174]
Derivative Instruments:    Gains and losses on hedges of existing assets or liabilities are marked-to-market and the result is included in Other within Other income (expense) within the Company’s consolidated statements of operations. Certain financial instruments are used to hedge firm future commitments or forecasted transactions.  Gains and losses pertaining to those instruments that qualify for hedge accounting are deferred until such time as the underlying transactions are recognized and subsequently recognized in the same line within the consolidated statements of operations as the hedged item. Gains and losses pertaining to those instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the consolidated statements of operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-15-000003:notes:175]
Share-Based Compensation Plans and Other Incentive Plans

[0000068505-15-000003:notes:176]
Stock Options, Stock Appreciation Rights and Employee Stock Purchase Plan

[0000068505-15-000003:notes:177]
The Company grants options to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option granted and stock appreciation right has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to fifteen years and vest over two to four years. Stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights in conjunction with a change in control of the Company only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or quits for good reason within 24 months of a change in control.

[0000068505-15-000003:notes:178]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2014, 2013 and 2012, employees purchased 1.4 million, 1.5 million and 1.4 million shares, respectively, at purchase prices of $51.76 and $53.79, $43.02 and $50.47, and $34.52 and $42.96, respectively.

[0000068505-15-000003:notes:179]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2014, 2013 and 2012 was $11.02, $9.52 and $9.60, respectively, using the following weighted-average assumptions:

[0000068505-15-000003:notes:180]
|  | 2014 |  | 2013 |  | 2012 |
| Expected volatility | 21.7 | % |  | 22.1 | % |  | 24.0 | % |
| Risk-free interest rate | 1.6 | % |  | 0.9 | % |  | 0.8 | % |
| Dividend yield | 2.5 | % |  | 2.4 | % |  | 2.2 | % |
| Expected life (years) | 5.2 |  |  | 5.9 |  |  | 6.1 |  |

[0000068505-15-000003:notes:181]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption required in the Black-Scholes model. The selection of the implied volatility approach was based upon the availability of actively traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility.

[0000068505-15-000003:notes:182]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the option. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life of employee stock options represents the average of the contractual term of the options and the weighted-average vesting period for all option tranches.

[0000068505-15-000003:notes:183]
The Company has applied forfeiture rates, estimated based on historical data, of 10%-50% to the option fair values calculated by the Black-Scholes option pricing model. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-15-000003:notes:184]
Stock option activity was as follows (in thousands, except exercise price and employee data):

[0000068505-15-000003:notes:185]
|  | 2014 |  | 2013 |  | 2012 |
| Years ended December 31 | SharesSubject toOptions |  | Wtd. Avg.ExercisePrice |  | SharesSubject toOptions |  | Wtd. Avg.ExercisePrice |  | SharesSubject toOptions |  | Wtd. Avg.ExercisePrice |
| Options outstanding at January 1 | 10,937 |  |  | $ | 79 |  |  | 13,132 |  |  | $ | 70 |  |  | 15,729 |  |  | $ | 63 |  |
| Options granted | 1,340 |  |  | 66 |  |  | 1,652 |  |  | 57 |  |  | 1,286 |  |  | 51 |  |
| Options exercised | (1,526 | ) |  | 39 |  |  | (2,950 | ) |  | 31 |  |  | (2,831 | ) |  | 29 |  |
| Options terminated, cancelled or expired | (1,067 | ) |  | 65 |  |  | (897 | ) |  | 65 |  |  | (1,052 | ) |  | 60 |  |
| Options outstanding at December 31 | 9,684 |  |  | 85 |  |  | 10,937 |  |  | 79 |  |  | 13,132 |  |  | 70 |  |
| Options exercisable at December 31 | 7,282 |  |  | 94 |  |  | 7,628 |  |  | 91 |  |  | 9,242 |  |  | 81 |  |
| Approx. number of employees granted options | 118 |  |  |  |  | 123 |  |  |  |  | 115 |  |  |  |

[0000068505-15-000003:notes:186]
At December 31, 2014, the Company had $21 million of total unrecognized compensation expense, net of estimated forfeitures, related to stock option plans and the employee stock purchase plan that will be recognized over the weighted average period of approximately two years. Cash received from stock option exercises and the employee stock purchase plan was $135 million, $165 million and $133 million for the years ended December 31, 2014, 2013 and 2012, respectively. The total intrinsic value of options exercised during the years ended December 31, 2014, 2013 and 2012 was $38 million, $85 million and $59 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2014 was $119 million and $103 million, respectively, based on a December 31, 2014 stock price of $67.08 per share.

[0000068505-15-000003:notes:187]
The following table summarizes information about stock options outstanding and exercisable at December 31, 2014 (in thousands, except exercise price and years):

[0000068505-15-000003:notes:188]
|  | Options Outstanding |  | OptionsExercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |
| Under $30 | 699 |  |  | $ | 27 |  |  | 5 |  | 699 |  |  | $ | 27 |  |
| $30-$40 | 2,222 |  |  | 39 |  |  | 5 |  | 2,222 |  |  | 39 |  |
| $41-$50 | 231 |  |  | 45 |  |  | 6 |  | 222 |  |  | 45 |  |
| $51-$60 | 1,786 |  |  | 54 |  |  | 8 |  | 584 |  |  | 54 |  |
| $61-$70 | 1,430 |  |  | 66 |  |  | 8 |  | 239 |  |  | 65 |  |
| $71-$80 | 197 |  |  | 74 |  |  | 2 |  | 197 |  |  | 74 |  |
| $81 and over | 3,119 |  |  | 161 |  |  | 0 |  | 3,119 |  |  | 161 |  |
|  | 9,684 |  |  |  |  |  |  | 7,282 |  |  |  |

[0000068505-15-000003:notes:189]
As of December 31, 2014 and 2013, the weighted average contractual life for options outstanding and exercisable was five and four years, respectively.

[0000068505-15-000003:notes:190]
Restricted Stock and Restricted Stock Units

[0000068505-15-000003:notes:191]
Restricted stock (“RS”) and restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. Shares of RS and RSUs assumed or replaced with comparable shares of RS or RSUs in conjunction with a change in control will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or quits for good reason within 24 months of a change in control.

[0000068505-15-000003:notes:192]
Restricted stock and restricted stock unit activity was as follows (in thousands, except fair value and employee data):

[0000068505-15-000003:notes:193]
|  | 2014 |  | 2013 |  | 2012 |
| Years ended December 31 | RS and RSU |  | Wtd. Avg.GrantDate FairValue |  | RS and RSU |  | Wtd Avg.GrantDate FairValue |  | RS and RSU |  | Wtd Avg.GrantDate FairValue |
| RS and RSU outstanding at January 1 | 3,728 |  |  | $ | 49 |  |  | 6,299 |  |  | $ | 41 |  |  | 8,990 |  |  | $ | 40 |  |
| Granted | 1,235 |  |  | 63 |  |  | 1,558 |  |  | 54 |  |  | 1,657 |  |  | 49 |  |
| Vested | (2,445 | ) |  | 48 |  |  | (3,610 | ) |  | 38 |  |  | (3,845 | ) |  | 41 |  |
| Terminated, canceled or expired | (765 | ) |  | 54 |  |  | (519 | ) |  | 45 |  |  | (503 | ) |  | 33 |  |
| RS and RSU outstanding at December 31 | 1,753 |  |  | 58 |  |  | 3,728 |  |  | 49 |  |  | 6,299 |  |  | 41 |  |
| Approx. number of employees granted RS and RSUs | 1,979 |  |  |  |  | 2,295 |  |  |  |  | 2,355 |  |  |  |

[0000068505-15-000003:notes:194]
At December 31, 2014, the Company had unrecognized compensation expense related to RS and RSUs of $65 million net of estimated forfeitures, expected to be recognized over the weighted average period of approximately two years. The total fair value of RS and RSU shares vested during the years ended December 31, 2014, 2013 and 2012 was $160 million, $138 million and $144 million, respectively. The aggregate fair value of outstanding RS and RSUs as of December 31, 2014 was $110 million.

[0000068505-15-000003:notes:195]
Total Share-Based Compensation Expense

[0000068505-15-000003:notes:196]
At December 31, 2014 and 2013, 19.7 million and 20.4 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-15-000003:notes:197]
Motorola Solutions Incentive Plans

[0000068505-15-000003:notes:198]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2014, 2013 and 2012 was $53 million, $87 million and $145 million, respectively.

[0000068505-15-000003:notes:199]
Long-Range Incentive Plan

[0000068505-15-000003:notes:200]
The Long-Range Incentive Plan (“LRIP”) rewards participating elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three year period. The expense for LRIP for the years ended December 31, 2014, 2013 and 2012 was $3 million, $4 million and $9 million, respectively.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-15-000003:notes:201]
Discontinued Operations

[0000068505-15-000003:notes:202]
On April 14, 2014, the Company entered into a Master Acquisition Agreement (the “Acquisition Agreement”) with Zebra Technologies Corporation ("Zebra") to sell the Company’s Enterprise business for $3.5 billion in cash. The transaction closed on October 27, 2014. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-15-000003:notes:203]
On January 1, 2012, the Company completed a series of transactions which resulted in exiting the amateur, marine and airband radio businesses.  The operating results of the amateur, marine and airband radio businesses are reported as discontinued operations in the consolidated statements of operations for the year ended December 31, 2012.

[0000068505-15-000003:notes:204]
The following table displays summarized activity in the Company’s consolidated statements of operations for discontinued operations during the years ended December 31, 2014, 2013, and 2012.

[0000068505-15-000003:notes:205]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Net sales | $ | 1,904 |  |  | $ | 2,469 |  |  | $ | 2,429 |  |
| Operating earnings | 203 |  |  | 268 |  |  | 347 |  |
| Gains on sales of investments and businesses, net | 1,888 |  |  | 3 |  |  | 7 |  |
| Earnings before income taxes | 2,074 |  |  | 266 |  |  | 341 |  |
| Income tax expense | 78 |  |  | 100 |  |  | 130 |  |
| Earnings from discontinued operations, net of tax | 1,996 |  |  | 166 |  |  | 211 |  |

[0000068505-15-000003:notes:206]
The following table displays a summary of the assets and liabilities held for sale as of December 31, 2013:

[0000068505-15-000003:notes:207]
|  | 2013 |
| Assets |  |
| Accounts receivable, net | $ | 551 |  |
| Deferred income taxes | 219 |  |
| Inventories, net | 175 |  |
| Other current assets | 134 |  |
| Property, plant and equipment, net | 201 |  |
| Investments | 19 |  |
| Goodwill | 1,149 |  |
| Other assets | 94 |  |
|  | $ | 2,542 |  |
| Liabilities |  |
| Accounts payable | $ | 231 |  |
| Accrued liabilities | 639 |  |
| Other liabilities | 171 |  |
|  | $ | 1,041 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000068505-15-000003:notes:208]
Earnings Per Share:    The Company calculates its basic earnings (loss) per share based on the weighted-average effect of all common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for earnings (loss) from continuing operations and net earnings attributable to Motorola Solutions, Inc. for all periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-15-000003:notes:209]
Fair Value Measurements

[0000068505-15-000003:notes:210]
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements on a recurring basis. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date.  Fair value is measured using the fair value hierarchy and related valuation methodologies as defined in the authoritative literature. This guidance specifies a hierarchy of valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies as they pertain to the Company are as follows:

[0000068505-15-000003:notes:211]
Level 1 - Quoted market prices in active markets are available for investments in common and preferred stock and common stock equivalents.

[0000068505-15-000003:notes:212]
Level 2 - The securities classified as Level 2 are comprised primarily of corporate, government, agency, and government sponsored enterprise fixed income securities. Our pension plan assets also include commingled equities classified as Level 2. These securities are priced using pricing services, bid/offer, and last trade.  Prices may also be obtained from brokers, counterparties, fund administrators, online securities data services, or investment managers. Fixed income securities and commingled equities, including short-term instruments, may be priced using pricing models comprised of observable inputs which include, but are not limited to, market quotations, yields, maturities, call features, and the security's terms and conditions.

[0000068505-15-000003:notes:213]
In determining the fair value of the Company's foreign currency derivatives, the Company uses forward contract and option valuation models employing market observable inputs, such as spot currency rates, time value and option volatilities. Since the Company primarily uses observable inputs in its valuation of its derivative assets and liabilities, they are classified as Level 2 assets.

[0000068505-15-000003:notes:214]
Level 3 - The securities classified as Level 3 primarily consist of corporate bonds held in one of our non-U.S. pension plans.  These corporate bonds are valued using pricing models which contain unobservable inputs and have limited liquidity.  Determining the fair value of these securities requires the use of unobservable inputs, such as indicative quotes from dealers, extrapolated data, proprietary models and qualitative input from investment advisors.

[0000068505-15-000003:notes:215]
Investments and Derivatives

[0000068505-15-000003:notes:216]
There were no significant transfers between Level 1 and Level 2 during 2014 or 2013.

[0000068505-15-000003:notes:217]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-15-000003:notes:218]
The table above includes securities on loan as part of a securities lending arrangement of $125 million of common stock and equivalents, $199 million of government, agency, and government-sponsored enterprise obligations, and $19 million of corporate bonds. All securities on loan are fully cash collateralized.

[0000068505-15-000003:notes:219]
The table above includes securities on loan as part of a securities lending arrangement of $8 million of common stock and equivalents, and $13 million of corporate bonds. All securities on loan are fully collateralized.

[0000068505-15-000003:notes:220]
The table above includes securities on loan as part of a securities lending arrangement of $3 million of common stock and equivalents and $5 million of government, agency, and government-sponsored enterprise obligations. All securities on loan are fully cash collateralized.

[0000068505-15-000003:notes:221]
At December 31, 2014, the Company had $3.3 billion of investments in money market funds (Level 2) classified as Cash and cash equivalents in its consolidated balance sheet, compared to $2.1 billion at December 31, 2013. The money market funds had quoted market prices that are equivalent to par.

[0000068505-15-000003:notes:222]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2014 was $3.6 billion (Level 2), compared to a face value of $3.5 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-15-000003:notes:223]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000068505-15-000003:notes:224]
Foreign Currency:    Certain of the Company’s non-U.S. operations use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive loss in the Company’s consolidated balance sheets. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-15-000003:notes:225]
Intangible Assets and Goodwill

[0000068505-15-000003:notes:226]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition. The pro forma effects of the acquisitions completed in 2014, 2013, and 2012 were not significant individually or in the aggregate. The Company did not have any significant acquisitions during the years ended December 31, 2014, 2013 and 2012.

[0000068505-15-000003:notes:227]
Intangible Assets

[0000068505-15-000003:notes:228]
Amortized intangible assets are comprised of the following:

[0000068505-15-000003:notes:229]
|  | 2014 |  | 2013 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 37 |  |  | $ | 27 |  |  | $ | 24 |  |  | $ | 24 |  |
| Patents | 8 |  |  | 4 |  |  | 8 |  |  | 3 |  |
| Customer-related | 15 |  |  | 8 |  |  | 6 |  |  | 6 |  |
| Other intangibles | 17 |  |  | 15 |  |  | 15 |  |  | 14 |  |
|  | $ | 77 |  |  | $ | 54 |  |  | $ | 53 |  |  | $ | 47 |  |

[0000068505-15-000003:notes:230]
Amortization expense on intangible assets, which is included within Other charges in the consolidated statements of operations, was $4 million, $1 million and $1 million for the years ended December 31, 2014, 2013 and 2012, respectively.  As of December 31, 2014, future amortization expense is estimated to be $4 million in 2015, 2016, and 2017, and $3 million in 2018 and 2019.

[0000068505-15-000003:notes:231]
As of both December 31, 2014, and December 31, 2013, all of the Company's amortized intangible assets, excluding goodwill, were aligned with the Products segment.

[0000068505-15-000003:notes:232]
Goodwill

[0000068505-15-000003:notes:233]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2013 to December 31, 2014:

[0000068505-15-000003:notes:234]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2013 |  |  |  |  |  |
| Aggregate goodwill acquired | $ | 249 |  |  | $ | 112 |  |  | $ | 361 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | 249 |  |  | 112 |  |  | 361 |  |
| Balance as of December 31, 2013 |  |  |  |  |  |
| Aggregate goodwill acquired/disposed | 249 |  |  | 112 |  |  | 361 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | 249 |  |  | 112 |  |  | 361 |  |
| Goodwill acquired | 15 |  |  | 7 |  |  | 22 |  |
| Balance as of December 31, 2014 |  |  |  |  |  |
| Aggregate goodwill acquired | 264 |  |  | 119 |  |  | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |

[0000068505-15-000003:notes:235]
On December 31, 2013, the Company completed the acquisition of a communication software provider in push-to-talk-over-broadband applications for a gross purchase price of $48 million. As a result of the acquisition, the Company recognized $22 million of goodwill and $20 million of identifiable intangible assets.

[0000068505-15-000003:notes:236]
On November 18, 2014, the Company completed the acquisition of an equipment provider for a gross purchase price of $22 million with $3 million of net tangible assets. The Company will complete the purchase price allocation for this acquisition during the first quarter of 2015, pending completion.  As of December 31, 2014, $19 million is included in Other assets in the Company’s consolidated balance sheet.

[0000068505-15-000003:notes:237]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment. The Company has determined that the Products segment and Services segment each meet the definition of a reporting unit.

[0000068505-15-000003:notes:238]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2014, 2013, and 2012.  In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2014, 2013, and 2012, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000068505-15-000003:notes:239]
Goodwill and Intangible Assets:    Goodwill is assessed for impairment at least annually at the reporting unit level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year.  The annual assessment is performed using the two-step goodwill test which may also include the optional qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount prior to performing the two-step goodwill impairment test.  If this is the case, the two-step goodwill impairment test is required. If it is more-likely-than-not that the fair value of a reporting unit is greater than its carrying amount, the two-step goodwill impairment test is not required.

[0000068505-15-000003:notes:240]
If the two-step goodwill impairment test is performed, first, the fair value of each reporting unit is compared to its book value. If the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-15-000003:notes:241]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to ten years. The Company has no intangible assets with indefinite useful lives.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000068505-15-000003:notes:242]
Impairment of Long-Lived Assets:    Long-lived assets, which include intangible assets, held and used by the Company, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparables. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-15-000003:notes:243]
Income Taxes

[0000068505-15-000003:notes:244]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s consolidated balance sheets resulted from retirement benefit adjustments, currency translation adjustments, net gains (losses) on derivative instruments and fair value adjustments to available-for-sale securities. The adjustments were $286 million, $606 million and $(272) million for the years ended December 31, 2014, 2013 and 2012, respectively.

[0000068505-15-000003:notes:245]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. During the fourth quarter of 2014, the Company reassessed its unremitted earnings position and concluded that certain of its non-U.S. subsidiaries’ earnings were permanently reinvested overseas.  The Company intends to utilize these offshore earnings for working capital needs in its international operations. During 2014, the Company recorded a net tax benefit of $19 million related to reversals of deferred tax liabilities related to undistributed foreign earnings due to the change in permanent reinvestment assertion. During 2013, the Company reassessed its unremitted earnings position concluding that certain of its non-U.S. subsidiaries' earnings were permanently reinvested overseas. As a result, the Company recognized a tax benefit of $25 million during 2013 for the reversal of related deferred tax liabilities.

[0000068505-15-000003:notes:246]
Undistributed earnings that the Company intends to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.5 billion December 31, 2014. The Company currently has no plans to repatriate the foreign earnings permanently reinvested and therefore, the time and manner of repatriation is uncertain.  If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary; however, given the uncertain repatriation time and manner at December 31, 2014, it is not practicable to estimate the amount of any additional income tax charge on permanently reinvested earnings.  On a cash basis, these repatriations from the Company's non-U.S. subsidiaries could require the payment of additional taxes. The portion of earnings not reinvested indefinitely may be distributed without an additional charge given the U.S. federal and foreign income tax accrued on undistributed earnings and the utilization of available foreign tax credits. At December 31, 2014, the Company has approximately $400 million of foreign earnings not considered permanently reinvested and which may be repatriated without an additional tax charge.

[0000068505-15-000003:notes:247]
In 2013, the Company reorganized certain of its non-U.S. subsidiaries under a holding company structure in order to facilitate the efficient movement of non-U.S. cash and provide a platform to fund foreign investments, such as potential acquisitions and capital expenditures. During 2013, the Company recognized a $337 million tax benefit associated with the excess tax credits relating to the earnings of certain non-U.S. subsidiaries reorganized under the holding company structure.

[0000068505-15-000003:notes:248]
Gross deferred tax assets were $3.6 billion and $3.7 billion at December 31, 2014 and 2013, respectively. Deferred tax assets, net of valuation allowances, were $3.4 billion and $3.5 billion at December 31, 2014 and 2013, respectively. Gross deferred tax liabilities were $774 million and $1.1 billion at December 31, 2014 and 2013, respectively.

[0000068505-15-000003:notes:249]
At December 31, 2014 and 2013, the Company had valuation allowances of $226 million and $200 million, respectively, against its deferred tax assets, including $195 million and $178 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s valuation allowances for its non-U.S. subsidiaries had a net increase of $17 million during 2014 and a net decrease of $56 million during 2013. The increase in the valuation allowance relating to deferred tax assets of non-U.S. subsidiaries during 2014 relates to deferred tax assets that are not more-likely-than-not to be realizable based on estimates of future taxable income. The decrease in the valuation allowance relating to deferred tax assets of non-U.S. subsidiaries during 2013 reflects current year deferred tax movements, expiration of loss carryforwards and exchange rate variances.

[0000068505-15-000003:notes:250]
The Company’s U.S. valuation allowance had a net increase of $9 million during 2014 and a net decrease of $4 million during 2013. The U.S. valuation allowance of $31 million as of December 31, 2014 primarily relates to state tax carryforwards. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-15-000003:notes:251]
Tax carryforwards are as follows:

[0000068505-15-000003:notes:252]
| December 31, 2014 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | 76 |  |  | $ | 26 |  |  | 2021-2033 |
| Foreign tax credits | — |  |  | 686 |  |  | 2018-2023 |
| General business credits | — |  |  | 174 |  |  | 2025-2034 |
| Minimum tax credits | — |  |  | 100 |  |  | Unlimited |
| State tax losses | 1,502 |  |  | 41 |  |  | 2015-2031 |
| State tax credits | — |  |  | 27 |  |  | 2018-2026 |
| Non-U.S. Subsidiaries: |  |  |  |  |  |
| China tax losses | 212 |  |  | 53 |  |  | 2015-2016 |
| Japan tax losses | 93 |  |  | 33 |  |  | 2017-2021 |
| Germany tax losses | 108 |  |  | 31 |  |  | Unlimited |
| United Kingdom tax losses | 102 |  |  | 21 |  |  | Unlimited |
| Singapore tax losses | 50 |  |  | 8 |  |  | Unlimited |
| Other subsidiaries tax losses | 70 |  |  | 18 |  |  | Various |
| Spain tax credits | — |  |  | 27 |  |  | 2017-2021 |
| Other subsidiaries tax credits | — |  |  | 1 |  |  | Various |
|  |  |  | $ | 1,246 |  |  |  |

[0000068505-15-000003:notes:253]
The Company had unrecognized tax benefits of $96 million and $147 million at December 31, 2014 and December 31, 2013, respectively, of which approximately $76 million and $125 million, respectively, if recognized, would affect the effective tax rate, net of resulting changes to valuation allowances.

[0000068505-15-000003:notes:254]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-15-000003:notes:255]
|  | 2014 |  | 2013 |
| Balance at January 1 | $ | 147 |  |  | $ | 157 |  |
| Additions based on tax positions related to current year | 4 |  |  | 13 |  |
| Additions for tax positions of prior years | 21 |  |  | 70 |  |
| Reductions for tax positions of prior years | (55 | ) |  | (10 | ) |
| Settlements and agreements | (19 | ) |  | (82 | ) |
| Lapse of statute of limitations | (2 | ) |  | (1 | ) |
| Balance at December 31 | $ | 96 |  |  | $ | 147 |  |

[0000068505-15-000003:notes:256]
The IRS is currently examining the Company's 2012 and 2013 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-15-000003:notes:257]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations in the periods in which the matters are ultimately resolved.

[0000068505-15-000003:notes:258]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $50 million tax charge to a $50 million tax benefit, with cash payments not to exceed $25 million.

[0000068505-15-000003:notes:259]
At December 31, 2014, the Company had $26 million accrued for interest and $26 million accrued for penalties on unrecognized tax benefits. At December 31, 2013, the Company had $25 million and $27 million accrued for interest and penalties, respectively, on unrecognized tax benefits.


## us-gaap:IncomeTaxPolicyTextBlock

[0000068505-15-000003:notes:260]
Income Taxes:    Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities from a change in tax rates is recognized in the period that includes the enactment date.

[0000068505-15-000003:notes:261]
Deferred tax assets are reduced by valuation allowances if, based on the consideration of all available evidence, it is more-likely-than-not that all or some portion of the deferred tax asset will not be realized. Significant weight is given to evidence that can be objectively verified. The Company evaluates deferred tax assets on a quarterly basis to determine if valuation allowances are required by considering available evidence. Deferred tax assets are realized by having sufficient future taxable income to allow the related tax benefits to reduce taxes otherwise payable. The sources of taxable income that may be available to realize the benefit of deferred tax assets are future reversals of existing taxable temporary differences, future taxable income, exclusive of reversing temporary differences and carryforwards, taxable income in carry-back years and tax planning strategies that are both prudent and feasible.

[0000068505-15-000003:notes:262]
The Company recognizes the effect of income tax positions only if sustaining those positions is more-likely-than-not. Changes in recognition or measurement are reflected in the period in which a change in judgment occurs. The Company records interest related to unrecognized tax benefits in Interest expense and penalties in Selling, general and administrative expenses in the Company’s consolidated statements of operations.


## us-gaap:InventoryPolicyTextBlock

[0000068505-15-000003:notes:263]
Inventories:    Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or market (net realizable value or replacement cost).


## us-gaap:InvestmentPolicyTextBlock

[0000068505-15-000003:notes:264]
Investments:    Investments in equity and debt securities classified as available-for-sale are carried at fair value.  When applicable, debt securities classified as held-to-maturity are carried at amortized cost. Equity securities that are restricted for more than one year or that are not publicly traded are carried at cost. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-15-000003:notes:265]
The Company assesses declines in the fair value of investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s consolidated statements of operations in the period in which they become impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-15-000003:notes:266]
Recent Accounting Pronouncements:  In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates, and changes in those estimates. The ASU will be effective for the Company beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-15-000003:notes:267]
Retirement Benefits

[0000068505-15-000003:notes:268]
Pension and Postretirement Health Care Benefits Plans

[0000068505-15-000003:notes:269]
The Company’s noncontributory pension plan (the “Regular Pension Plan”) covered U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The benefit formula was dependent upon employee earnings and years of service. During 2014, the Company terminated this plan. The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the United Kingdom and Germany (the “Non U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-15-000003:notes:270]
The Company had a noncontributory supplemental retirement benefit plan (the “Officers’ Plan”) for its officers elected prior to December 31, 1999. The Officers’ Plan contained provisions for vesting and funding the participants’ expected retirement benefits when the participants met the minimum age and years of service requirements. Elected officers who were not yet vested in the Officers’ Plan as of December 31, 1999 had the option to remain in the Officers’ Plan or elect to have their benefit bought out in restricted stock units. Effective December 31, 1999, newly elected officers were not eligible to participate in the Officers’ Plan. Effective June 30, 2005, salaries were frozen for this plan. During 2013, the Company settled and terminated the Officers' Plan.

[0000068505-15-000003:notes:271]
The Company has an additional noncontributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan (“MSPP”), which provides supplemental benefits to individuals by replacing the Regular Pension Plan benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. However, elected officers who were covered under the Officers’ Plan were not eligible to participate in the MSPP. Effective January 1, 2007, eligible compensation was capped at the IRS limit plus $175,000 (the “Cap”) or, for those already in excess of the Cap as of January 1, 2007, the eligible compensation used to compute such employee’s MSPP benefit for all future years is the greater of: (i) such employee’s eligible compensation as of January 1, 2007 (frozen at that amount) or (ii) the relevant Cap for the given year. Effective January 1, 2009, the MSPP was closed to new participants unless such participation was required under a prior contractual entitlement.

[0000068505-15-000003:notes:272]
In February 2007, the Company amended the Regular Pension Plan and the MSPP, modifying the definition of average earnings. For the years ended prior to December 31, 2007, benefits were calculated using the rolling average of the highest annual earnings in any five years within the previous ten calendar year period. Beginning in January 2008, the benefit calculation was based on the set of the five highest years of earnings within the ten calendar years prior to December 31, 2007, averaged with earnings from each year after 2007. In addition, effective January 2008, the Company amended the Regular Pension Plan, modifying the vesting period from five years to three years.

[0000068505-15-000003:notes:273]
In December 2008, the Company amended the Regular Pension Plan, the Officers’ Plan and the MSPP (collectively, the “U.S. Pension Benefit Plans”) such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-15-000003:notes:274]
Certain health care benefits are available to eligible domestic employees meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). For eligible employees hired prior to January 1, 2002, the Company offsets a portion of the postretirement medical costs to the retired participant. As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants.  During 2012, the Postretirement Health Care Benefits Plan was amended ("the Original Amendment"). As of January 1, 2013, benefits under the Postretirement Health Care Benefits Plan, are paid to a retiree health reimbursement account instead of directly providing health insurance coverage to certain participants.  Covered retirees are now able to use the annual subsidy they receive through this account toward the purchase of their own health care coverage from private insurance companies and for reimbursement of eligible health care expenses.  The Original Amendment to the Postretirement Health Care Benefits Plan effective January 1, 2013 resulted in a remeasurement of the plan generating an $87 million decrease in accumulated other comprehensive loss, net of taxes. The majority of that $87 million decrease will be recognized by the end of 2015.

[0000068505-15-000003:notes:275]
In September 2014, the Postretirement Health Care Benefits Plan was amended (“the New Amendment”).  As a result of the New Amendment, beginning March 1, 2015, all eligible retirees under the age of 65, will be able to use the annual subsidy they receive through their retiree health reimbursement account toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.  Additionally, the New Amendment eliminated dental benefits under the plan.  The New Amendment required a remeasurement of the plan, resulting in a $45 million decrease in Accumulated other comprehensive loss, net of taxes.  A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the consolidated statements of operations over almost three years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.

[0000068505-15-000003:notes:276]
During the years ended December 31, 2014, 2013, and 2012, $50 million, $43 million, and $16 million of prior service cost credit, respectively, was recognized into the Company’s consolidated statements of operations for amendments to the Postretirement Health Care Benefits Plan.

[0000068505-15-000003:notes:277]
In September 2014, the Company entered into a Definitive Purchase Agreement (the “Agreement”) by and among the Company, The Prudential Insurance Company of America (“PICA”), Prudential Financial, Inc. and State Street Bank and Trust Company, as Independent Fiduciary of the Company’s Regular Pension Plan. Under the Agreement, the Regular Pension Plan planned to purchase from PICA a group annuity contract that requires PICA to pay and administer certain future annuity payments to approximately 30,000 of the Company’s retirees. In anticipation of the Agreement, the Company established a new pension plan with substantially the same terms as the Regular Pension Plan (the “New Plan”) to accommodate the Company's remaining active employees and non-retirees. The establishment of the New Plan resulted in a mid-year remeasurement. On December 3, 2014, the Regular Pension Plan closed its planned purchase of a group annuity from PICA. The total premium paid by the Regular Pension Plan to PICA was the transfer of approximately $3.2 billion in plan assets, and is subject to customary post-closing true-ups. The Regular Pension Plan was then terminated.

[0000068505-15-000003:notes:278]
Also in September 2014, the Company announced that the New Plan was offering a maximum of $1.0 billion of lump-sum distributions to certain participants who had accrued a pension benefit, had left the Company prior to June 30, 2014, and had not yet started receiving pension benefit payments (the “Eligible Participants”).  The aggregate amount of lump-sum elections accepted by Eligible Participants exceeded the maximum of $1.0 billion, and $1.0 billion was paid out from plan assets in December 2014.

[0000068505-15-000003:notes:279]
As a result of the actions taken to the Plans, the Company recorded a settlement loss of $1.9 billion in 2014 which is recorded in "Other charges" within the statement of operations.

[0000068505-15-000003:notes:280]
Net Periodic Cost (Benefit)

[0000068505-15-000003:notes:281]
The net periodic costs (benefit) for pension and Postretirement Health Care Benefits plans were as follows:

[0000068505-15-000003:notes:282]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |  | $ | 11 |  |  | $ | 10 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |
| Interest cost | 370 |  |  | 352 |  |  | 349 |  |  | 80 |  |  | 69 |  |  | 73 |  |  | 10 |  |  | 11 |  |  | 16 |  |
| Expected return on plan assets | (381 | ) |  | (364 | ) |  | (421 | ) |  | (90 | ) |  | (77 | ) |  | (77 | ) |  | (10 | ) |  | (10 | ) |  | (12 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 97 |  |  | 130 |  |  | 260 |  |  | 12 |  |  | 13 |  |  | 22 |  |  | 9 |  |  | 14 |  |  | 12 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (7 | ) |  | (6 | ) |  | (3 | ) |  | (50 | ) |  | (43 | ) |  | (16 | ) |
| Settlement/loss | 1,883 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | 1,969 |  |  | $ | 118 |  |  | $ | 188 |  |  | $ | 10 |  |  | $ | 10 |  |  | $ | 25 |  |  | $ | (39 | ) |  | $ | (26 | ) |  | $ | 3 |  |

[0000068505-15-000003:notes:283]
The benefit obligation and plan assets for the Company's plans are measured as of December 31, 2014.  The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-15-000003:notes:284]
Prior to 2013, unrecognized gains and losses were amortized over periods ranging from three to thirteen years. At the close of fiscal 2012, the Company determined that the majority of the Company's plan participants in its Regular Pension Plan and United Kingdom pension plan were no longer actively employed by the Company due to significant employee exits as a result of the Company's divestitures. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from four to thirty-six years. Prior service costs are amortized over periods ranging from six to twelve years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-15-000003:notes:285]
The net periodic cost for 2015 will include amortization of the unrecognized net loss and prior service costs for the U.S. Pension Benefit Plans and Non U.S. Pension Benefit Plans, currently included in Accumulated other comprehensive loss, of $47 million and $11 million, respectively.  It is estimated that the 2015 net periodic expense for the Postretirement Health Care Benefits Plan will include amortization of a net credit of $49 million, comprised of the unrecognized prior service gain and unrecognized actuarial loss, currently included in Accumulated other comprehensive loss.

[0000068505-15-000003:notes:286]
Actuarial Assumptions

[0000068505-15-000003:notes:287]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-15-000003:notes:288]
In September 2014, as a result of establishing the New Plan, the Company remeasured the Regular Pension Plan using a weighted average discount rate and expected long-term rate of return on assets of 4.25%. The Regular Pension Plan was subsequently terminated. The New Plan, which is the surviving plan, was measured using a discount rate and expected long-term rate of return on assets of 4.70% and 7.00%, respectively.

[0000068505-15-000003:notes:289]
In September 2014, as a result of retiree healthcare design plan changes, the company remeasured the retiree healthcare plan using a weighted average discount rate and expected long-term rates of return on assets of 4.15% and 7.00%, respectively.

[0000068505-15-000003:notes:290]
During 2014, the Company adopted the "RP 2014 White Collar" mortality table for purposes of calculating the projected benefit obligation for the Company's New Plan.

[0000068505-15-000003:notes:291]
The health care cost trend rate used to determine the December 31, 2014 accumulated postretirement benefit obligation and 2015 net periodic benefit for the Postretirement Health Care Benefits Plan was 7.75%, grading down to a rate of 5.00% in 2021. The health care cost trend rate used to determine the December 31, 2013 accumulated postretirement benefit obligation and 2014 net periodic benefit was 8.50%, remaining flat at 8.50% through 2015, then grading down to a rate of 5.00% in 2020.

[0000068505-15-000003:notes:292]
The effect of changing the health care trend rate by one percentage point on the accumulated postretirement benefit obligation and the net periodic cost of the Postretirement Health Care Benefits Plan is de minimis. The Company maintains a lifetime cap on postretirement health care costs, which reduces the liability duration of the plan. A result of this lower duration, is a decreased sensitivity to a change in the discount rate trend and health care cost assumptions with respect to the liability and related expense.

[0000068505-15-000003:notes:293]
Investment Policy

[0000068505-15-000003:notes:294]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but are not limited to, equity, fixed income securities, cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. In addition, some plans invest in insurance contracts. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes for all plans, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-15-000003:notes:295]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including U.S. Treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to, cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-15-000003:notes:296]
Cash Funding

[0000068505-15-000003:notes:297]
The Company contributed $1.1 billion to its U.S. Pension Benefit Plans during 2014, compared to $150 million contributed in 2013. The Company contributed $237 million to its Non U.S. Pension Benefit Plans during 2014, compared to $32 million contributed in 2013. The Company expects to make no cash contributions to its U.S. Pension Benefit Plans and approximately $12 million to its Non U.S. Pension Benefit Plans in 2015.  The Company does not expect to make cash contributions to the Postretirement Health Care Benefits Plan in 2015.

[0000068505-15-000003:notes:298]
Expected Future Benefit Payments

[0000068505-15-000003:notes:299]
Other Benefit Plans

[0000068505-15-000003:notes:300]
Split-Dollar Life Insurance Arrangements

[0000068505-15-000003:notes:301]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a plan that was frozen prior to December 31, 2004. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-15-000003:notes:302]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2014, 2013 and 2012. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $66 million and $51 million as of December 31, 2014 and December 31, 2013, respectively.

[0000068505-15-000003:notes:303]
Deferred Compensation Plan

[0000068505-15-000003:notes:304]
The Company amended and reinstated its deferred compensation plan (“the Plan”) effective June 1, 2013 to reopen the Plan to certain participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations.  Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the Board of Directors.

[0000068505-15-000003:notes:305]
Defined Contribution Plan

[0000068505-15-000003:notes:306]
The Company and certain subsidiaries have various defined contribution plans, in which all eligible employees may participate. In the U.S., the 401(k) plan is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions.  The Company’s expenses for material defined contribution plans for the years ended December 31, 2014, 2013 and 2012 were $31 million, $32 million and $30 million, respectively.

[0000068505-15-000003:notes:307]
Beginning January 1, 2012, the Company may make an additional discretionary 401(k) plan matching contribution to eligible employees.  For the years ended December 31, 2014, 2013, and 2012 the Company made no discretionary matching contributions.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000068505-15-000003:notes:308]
Property, Plant and Equipment:    Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (buildings and building equipment, five to forty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-15-000003:notes:309]
Quarterly and Other Financial Data (unaudited)

[0000068505-15-000003:notes:310]
|  | 2014 |  | 2013 |
|  | 1st |  | 2nd |  | 3rd |  | 4th |  | 1st |  | 2nd |  | 3rd |  | 4th |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,228 |  |  | $ | 1,393 |  |  | $ | 1,436 |  |  | $ | 1,824 |  |  | $ | 1,396 |  |  | $ | 1,497 |  |  | $ | 1,517 |  |  | $ | 1,817 |  |
| Costs of sales | 651 |  |  | 737 |  |  | 751 |  |  | 911 |  |  | 703 |  |  | 747 |  |  | 752 |  |  | 916 |  |
| Gross margin | 577 |  |  | 656 |  |  | 685 |  |  | 913 |  |  | 693 |  |  | 750 |  |  | 765 |  |  | 901 |  |
| Selling, general and administrative expenses | 307 |  |  | 308 |  |  | 287 |  |  | 282 |  |  | 325 |  |  | 339 |  |  | 319 |  |  | 347 |  |
| Research and development expenditures | 174 |  |  | 176 |  |  | 166 |  |  | 165 |  |  | 187 |  |  | 195 |  |  | 183 |  |  | 196 |  |
| Other charges | (11 | ) |  | 34 |  |  | 25 |  |  | 1,924 |  |  | 7 |  |  | 13 |  |  | 17 |  |  | 34 |  |
| Operating earnings (loss) | 107 |  |  | 138 |  |  | 207 |  |  | (1,458 | ) |  | 174 |  |  | 203 |  |  | 246 |  |  | 324 |  |
| Earnings (loss) from continuing operations* | 85 |  |  | 78 |  |  | 66 |  |  | (926 | ) |  | 157 |  |  | 223 |  |  | 261 |  |  | 292 |  |
| Net earnings* | 127 |  |  | 824 |  |  | 147 |  |  | 201 |  |  | 192 |  |  | 258 |  |  | 307 |  |  | 342 |  |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from Continuing operations*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per common share | $ | 0.33 |  |  | $ | 0.31 |  |  | $ | 0.27 |  |  | $ | (4.02 | ) |  | $ | 0.57 |  |  | $ | 0.83 |  |  | $ | 1.00 |  |  | $ | 1.13 |  |
| Diluted earnings (loss) per common share | 0.33 |  |  | 0.30 |  |  | 0.27 |  |  | (4.02 | ) |  | 0.56 |  |  | 0.81 |  |  | 0.98 |  |  | 1.12 |  |
| Net earnings*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 0.50 |  |  | $ | 3.25 |  |  | $ | 0.60 |  |  | $ | 0.87 |  |  | $ | 0.70 |  |  | $ | 0.96 |  |  | $ | 1.17 |  |  | $ | 1.33 |  |
| Diluted earnings per common share | 0.49 |  |  | 3.22 |  |  | 0.59 |  |  | 0.87 |  |  | 0.68 |  |  | 0.94 |  |  | 1.16 |  |  | 1.31 |  |
| Dividends declared | $ | 0.31 |  |  | $ | 0.31 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.26 |  |  | $ | 0.26 |  |  | $ | 0.31 |  |  | $ | 0.31 |  |
| Dividends paid | 0.31 |  |  | 0.31 |  |  | 0.31 |  |  | 0.34 |  |  | 0.26 |  |  | 0.26 |  |  | 0.26 |  |  | 0.31 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 67.11 |  |  | $ | 67.80 |  |  | $ | 67.41 |  |  | $ | 67.87 |  |  | $ | 64.03 |  |  | $ | 64.69 |  |  | $ | 60.39 |  |  | $ | 67.50 |  |
| Low | $ | 62.72 |  |  | $ | 62.50 |  |  | $ | 58.89 |  |  | $ | 58.50 |  |  | $ | 55.94 |  |  | $ | 55.50 |  |  | $ | 54.01 |  |  | $ | 59.38 |  |

[0000068505-15-000003:notes:311]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.


## us-gaap:ReceivablesPolicyTextBlock

[0000068505-15-000003:notes:312]
Long-term Receivables:    Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under a workout or restructuring for four consecutive quarters.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-15-000003:notes:313]
Reorganization of Businesses

[0000068505-15-000003:notes:314]
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits.  In addition to the Involuntary Severance Plan, during the year ended December 31, 2013, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States.  Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan; however, termination benefits, which are normally capped at six months of salary, were capped at a full year’s salary.

[0000068505-15-000003:notes:315]
The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the consolidated statements of operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-15-000003:notes:316]
During 2014, 2013, and 2012 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. Both of the Company’s segments were impacted by these plans. The employees affected were located in all geographic regions.

[0000068505-15-000003:notes:317]
2014 Charges

[0000068505-15-000003:notes:318]
During 2014, the Company recorded net reorganization of business charges of $73 million, including $9 million of charges in Costs of sales and $64 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the aggregate $73 million are charges of $67 million for employee separation costs and, $7 million for exit costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-15-000003:notes:319]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2014 to December 31, 2014:

[0000068505-15-000003:notes:320]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 6 |  |  | $ | 7 |  |  | $ | — |  |  | $ | (13 | ) |  | $ | — |  |
| Employee separation costs | 103 |  |  | 93 |  |  | (4 | ) |  | (135 | ) |  | 57 |  |
|  | $ | 109 |  |  | $ | 100 |  |  | $ | (4 | ) |  | $ | (148 | ) |  | $ | 57 |  |

[0000068505-15-000003:notes:321]
Exit Costs

[0000068505-15-000003:notes:322]
At January 1, 2014, the Company had an accrual of $6 million for exit costs attributable to lease terminations. There were $7 million of additional charges in 2014.  The $13 million used in 2014 reflects cash payments. There is no remaining accrual as of December 31, 2014.

[0000068505-15-000003:notes:323]
Employee Separation Costs

[0000068505-15-000003:notes:324]
At January 1, 2014, the Company had an accrual of $103 million for employee separation costs. The 2014 additional charges of $93 million represent severance costs for approximately an additional 1,200 employees, of which 300 were direct employees and 900 were indirect employees. The adjustments of $4 million reflect reversals of accruals no longer needed. The $135 million used in 2014 reflects cash payments to separated employees, including $50 million related to employees of the Enterprise business and included in cash flow from discontinued operations. The remaining accrual of $57 million, which is included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2014, is expected to be paid, generally, within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 500 employees to be separated in 2015.

[0000068505-15-000003:notes:325]
2013 Charges

[0000068505-15-000003:notes:326]
During 2013, the Company recorded net reorganization of business charges of $86 million, including $16 million of charges in Costs of sales and $70 million of charges under Other charges in the Company’s consolidated statements of operations. Included in the aggregate $86 million are charges of (i) $94 million for employee separation costs, and (ii) $2 million of charges for exit costs, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-15-000003:notes:327]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2013 to December 31, 2013:

[0000068505-15-000003:notes:328]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 4 |  |  | $ | 3 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 6 |  |
| Employee separation costs | 31 |  |  | 146 |  |  | (16 | ) |  | (58 | ) |  | 103 |  |
|  | $ | 35 |  |  | $ | 149 |  |  | $ | (16 | ) |  | $ | (59 | ) |  | $ | 109 |  |

[0000068505-15-000003:notes:329]
At January 1, 2013, the Company had an accrual of $4 million for exit costs attributable to lease terminations. There were $3 million of additional charges in 2013. The $1 million used in 2013 reflects cash payments. The remaining accrual of $6 million, which is included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2013, represents future cash payments, primarily for lease termination obligations.

[0000068505-15-000003:notes:330]
At January 1, 2013, the Company had an accrual of $31 million for employee separation costs, representing the severance costs for approximately 400 employees. The additional 2013 charges of $146 million represent severance costs for approximately an additional 2,200 employees, of which 800 were direct employees and 1,400 were indirect employees. The adjustments of $16 million reflect accruals no longer needed. The $58 million used in 2013 reflects cash payments to these separated employees, including $20 million related to employees of the Enterprise business and included in cash flow from discontinued operations. The remaining accrual of $103 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2013.

[0000068505-15-000003:notes:331]
2012 Charges

[0000068505-15-000003:notes:332]
The Company recorded net reorganization of business charges of $33 million, including $6 million of charges in Costs of sales and $27 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the aggregate $33 million are charges of $35 million for employee separation costs and $5 million for building impairment charges, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-15-000003:notes:333]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2012 to December 31, 2012:

[0000068505-15-000003:notes:334]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 14 |  |  | $ | — |  |  | $ | 1 |  |  | $ | (11 | ) |  | $ | 4 |  |
| Employee separation costs | 30 |  |  | 54 |  |  | (9 | ) |  | (44 | ) |  | 31 |  |
|  | $ | 44 |  |  | $ | 54 |  |  | $ | (8 | ) |  | $ | (55 | ) |  | $ | 35 |  |

[0000068505-15-000003:notes:335]
At January 1, 2012, the Company had an accrual of $14 million for exit costs attributable to lease terminations. The adjustment of $1 million reflects an adjustment for additional accruals needed. The $11 million used in 2012 reflects cash payments. The remaining accrual of $4 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2012, represented future cash payments, primarily for lease termination obligations.

[0000068505-15-000003:notes:336]
At January 1, 2012, the Company had an accrual of $30 million for employee separation costs, representing the severance costs for approximately 700 employees. The additional 2012 charges of $54 million were severance costs for approximately an additional 1,000 employees, of which 300 were direct employees and 700 were indirect employees. The adjustments of $9 million reflect accruals no longer required. The $44 million used in 2012 reflects cash payments to these separated employees, including $20 million related to employees of the Enterprise business and included in cash flow from discontinued operations. The remaining accrual of $31 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2012.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000068505-15-000003:notes:337]
Revenue Recognition:   Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its products and services due to the needs of its customers. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. The Company recognizes revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  The Company recognizes revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) standalone sales of software products or software upgrades, (ii) standalone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-15-000003:notes:338]
Products

[0000068505-15-000003:notes:339]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. The Company bases its estimates of these allowances on historical experience taking into consideration the type of products sold, the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, the Company defers revenue until the incentive has been finalized with the customer.  The Company includes shipping charges billed to customers in net revenue, and includes the related shipping costs in cost of sales.

[0000068505-15-000003:notes:340]
The Company sells software and equipment obtained from other companies.  The Company establishes its own pricing and retains related inventory risk, is the primary obligor in sales transactions with customers, and assumes the credit risk for amounts billed to customers. Accordingly, the Company generally recognizes revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-15-000003:notes:341]
Long-Term Contracts

[0000068505-15-000003:notes:342]
For long-term contracts that involve customization of equipment and/or software, the Company generally recognizes revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). The components of estimated costs to complete a contract and management’s process for reviewing Estimated Costs at Completion and progress toward completion is discussed further below.  Contracts may be combined or segmented in accordance with the applicable criteria under contract accounting principles.  In certain instances, when revenues or costs associated with long-term contracts cannot be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained.

[0000068505-15-000003:notes:343]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs.  Due to the nature of the work required to be performed under many of the Company’s long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables.  The Company has a standard and disciplined quarterly Estimated Costs at Completion process in which management reviews the progress and performance of open contracts. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. These adjustments may result from positive project performance, and may result in an increase in operating income during the performance of individual contracts. Likewise, these adjustments may result in a decrease in operating income if Estimated Costs at Completion increase. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on Operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2014, 2013, and 2012.  When estimates of total costs to be incurred on a contract exceed total estimates of revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-15-000003:notes:344]
Hardware and Software Services Support

[0000068505-15-000003:notes:345]
Revenue under equipment and software maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term as services are performed.

[0000068505-15-000003:notes:346]
Software and Licenses

[0000068505-15-000003:notes:347]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other relevant revenue recognition criteria are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period that the licensee uses the license.

[0000068505-15-000003:notes:348]
Multiple-Element Arrangements

[0000068505-15-000003:notes:349]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements that include products containing software that functions together with the equipment to deliver its essential functionality, undelivered software elements that relate to the product's essential software, and undelivered non-software services deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in the control of the Company.

[0000068505-15-000003:notes:350]
In these arrangements, the Company allocates revenue to all deliverables based on their relative selling prices.  The Company uses the following hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of selling price (“ESP”).

[0000068505-15-000003:notes:351]
The Company determines VSOE based on its normal pricing and discounting practices for the specific product or service when that same product or service is sold separately. In determining VSOE, the Company requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate.

[0000068505-15-000003:notes:352]
When VSOE does not exist, the Company attempts to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, the Company's go-to-market strategy for many of its products differs from that of its competitors and its offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold by other companies cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE.

[0000068505-15-000003:notes:353]
When both VSOE and TPE are unavailable, the Company uses ESP. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0000068505-15-000003:notes:354]
The Company also considers the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE, TPE, and ESP.

[0000068505-15-000003:notes:355]
Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above.

[0000068505-15-000003:notes:356]
The Company's arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. The revenue for these multiple-element arrangements is allocated to the software deliverable(s) and the non-software deliverable(s) based on the relative selling prices of all of the deliverables in the arrangement using the fair value hierarchy outlined above. In circumstances where the Company cannot determine VSOE or TPE of the selling price for any of the deliverables in the arrangement, ESP is used for the purpose of allocating the arrangement consideration between software and non-software deliverables.

[0000068505-15-000003:notes:357]
The Company allocates arrangement consideration to multiple software or software-related deliverables, including the sale of software upgrades or software support agreements to previously sold software, in accordance with software accounting guidance. For such arrangements, revenue is allocated to the deliverables based on the relative fair value of each element, and fair value is determined using VSOE. Where VSOE does not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established, whichever occurs first. When the final undelivered software element is post contract support, service revenue is recognized on a ratable basis over the remaining service period.  When VSOE of a delivered element has not been established, but VSOE exists for the undelivered elements, the Company uses the residual method to recognize revenue when the fair value of all undelivered elements is determinable. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the arrangement consideration is allocated to the delivered elements and is recognized as revenue.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000068505-15-000003:notes:358]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013* |  | 2012* |
| United States | $ | 3,354 |  |  | $ | 3,648 |  |  | $ | 3,685 |  |  | $ | 8,468 |  |  | $ | 6,201 |  |  | $ | 6,268 |  |
| China | 160 |  |  | 203 |  |  | 198 |  |  | 382 |  |  | 420 |  |  | 552 |  |
| United Kingdom | 128 |  |  | 112 |  |  | 118 |  |  | 966 |  |  | 1,607 |  |  | 1,323 |  |
| Israel | 95 |  |  | 94 |  |  | 107 |  |  | 131 |  |  | 186 |  |  | 797 |  |
| Other, net of eliminations | 2,144 |  |  | 2,170 |  |  | 2,161 |  |  | 476 |  |  | 895 |  |  | 1,203 |  |
|  | $ | 5,881 |  |  | $ | 6,227 |  |  | $ | 6,269 |  |  | $ | 10,423 |  |  | $ | 9,309 |  |  | $ | 10,143 |  |

[0000068505-15-000003:notes:359]
* Excluding assets held for disposition


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-15-000003:notes:360]
|  | Net Sales |  | Operating Earnings (Loss) |
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Products | $ | 3,807 |  |  | $ | 4,109 |  |  | $ | 4,236 |  |  | $ | (667 | ) |  | $ | 639 |  |  | $ | 656 |  |
| Services | 2,074 |  |  | 2,118 |  |  | 2,033 |  |  | (339 | ) |  | 308 |  |  | 264 |  |
|  | $ | 5,881 |  |  | $ | 6,227 |  |  | $ | 6,269 |  |  | (1,006 | ) |  | 947 |  |  | 920 |  |
| Total other expense |  |  |  |  |  |  | (155 | ) |  | (67 | ) |  | (39 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  |  |  |  |  | $ | (1,161 | ) |  | $ | 880 |  |  | $ | 881 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-15-000003:notes:361]
Valuation and Qualifying Accounts


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-15-000003:notes:362]
Information by Segment and Geographic Region

[0000068505-15-000003:notes:363]
The Company conducts its business globally and manages through following two segments:

[0000068505-15-000003:notes:364]
Products: The Products segment offers an extensive portfolio of infrastructure, devices, accessories, and software. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle-mounted radios, accessories, software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. In 2014, the segment’s net sales were $3.8 billion, representing 65% of the Company's consolidated net sales.

[0000068505-15-000003:notes:365]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Lifecycle Support services, (iii) Managed services, (iv) Smart Public Safety Solutions, and (v) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications.  Lifecycle Support services includes lifecycle planning, software and hardware maintenance, security patches and upgrades, call center support, network monitoring, and repair services.  Managed services includes managing and operating customer systems and devices at defined services levels. Smart Public Safety Solutions includes software and hardware solutions for our customers’ "Command & Control" centers providing video monitoring support, data analytics, and content management with the objective of enabling smart policing.  iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2014, the segment’s net sales were $2.1 billion, representing 35% of the Company's consolidated net sales.

[0000068505-15-000003:notes:366]
For the years ended December 31, 2014, 2013 and 2012, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-15-000003:notes:367]
Segment Information

[0000068505-15-000003:notes:368]
The Company's "chief operating decision maker" does not review and allocate resources by segment assets.

[0000068505-15-000003:notes:369]
Geographic Area Information


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-15-000003:notes:370]
Summary of Significant Accounting Policies

[0000068505-15-000003:notes:371]
Use of Estimates:   The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-15-000003:notes:372]
Cash Equivalents:    The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $63 million at both December 31, 2014 and December 31, 2013.

[0000068505-15-000003:notes:373]
Sigma Fund:    Prior to December 2013, the Company invested most of its U.S. dollar-denominated cash in a fund (the “Sigma Fund”) which was managed by independent investment management firms under specific investment guidelines restricting the type of investments held and their time to maturity. In December 2013, the Company completed the liquidation of the Sigma Fund and migrated the international U.S. dollar denominated cash to a U.S. dollar cash pool invested primarily in U.S. dollar prime money market funds. These money market funds are classified as Cash and cash equivalents within the consolidated balance sheet as of both December 31, 2014 and 2013

[0000068505-15-000003:notes:374]
Advertising Expense:    Advertising expenses, which are the external costs of marketing the Company’s products, are expensed as incurred. Advertising expenses were $61 million, $76 million and $80 million for the years ended December 31, 2014, 2013 and 2012, respectively.
