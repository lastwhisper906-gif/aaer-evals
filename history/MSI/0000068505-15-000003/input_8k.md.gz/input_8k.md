# MSI 8-K — 0001193125-15-032592 filed 2015-02-04

## item codes, every 8-K on or before 2015-02-13

- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2015-02-13

- none on or before 2015-02-13

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-032592:8k_2_02:1]
EX-99.1
2
d865180dex991.htm
EX-99.1

[0001193125-15-032592:8k_2_02:2]
EX-99.1

[0001193125-15-032592:8k_2_02:3]
Exhibit 99.1

[0001193125-15-032592:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year 2014 Financial Results

[0001193125-15-032592:8k_2_02:5]
FOURTH-QUARTER HIGHLIGHTS

[0001193125-15-032592:8k_2_02:6]
|  | • |  | Fourth-quarter sales flat from a year ago, including $27 million of unfavorable foreign currency impact |

[0001193125-15-032592:8k_2_02:7]
|  | • |  | North America sales grew 4 percent from a year ago, driven by record Product sales |

[0001193125-15-032592:8k_2_02:8]
|  | • |  | Completed $4.2 billion U.S. pension de-risking transaction, including a $1.9 billion non-recurring charge, resulting in fourth-quarter GAAP loss per share from continuing operations* of $4.02 |

[0001193125-15-032592:8k_2_02:9]
|  | • |  | Non-GAAP** earnings per share (EPS) from continuing operations of $1.25 driven by North America sales growth and lower overall operating expenses |

[0001193125-15-032592:8k_2_02:10]
|  | • |  | Returned $1.5 billion to shareholders in share repurchases and dividends in the quarter; $2.9 billion for the full year |

[0001193125-15-032592:8k_2_02:11]
SCHAUMBURG, Ill. – Feb. 4, 2015 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth
quarter and full year of 2014. Click here for a printable news release and financial tables.

[0001193125-15-032592:8k_2_02:12]
SUPPORTING QUOTE

[0001193125-15-032592:8k_2_02:13]
“Our fourth-quarter results demonstrate a solid finish to a transformational year,” said Greg Brown, chairman and CEO of Motorola Solutions.
“The business continues to show signs of improvement, driven by growth in North America and significantly higher backlog. Our ongoing progress to simplify our organization and rationalize our cost structure will further position us for
long-term success.”

[0001193125-15-032592:8k_2_02:14]
KEY FINANCIAL RESULTS

[0001193125-15-032592:8k_2_02:15]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2014 |  |  | 2013 |  |  | Change |  |  | 2014 |  |  | 2013 |  |  | Change |  |
| Motorola Solutions, Inc. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 1,823 |  |  | $ | 1,817 |  |  |  | 0 | % |  | $ | 5,881 |  |  | $ | 6,227 |  |  |  | -6 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings (loss) ($M) |  | -$ | 1,459 |  |  | $ | 325 |  |  |  | -549 | % |  | -$ | 1,006 |  |  | $ | 947 |  |  |  | -206 | % |
| Percent of sales |  |  | -80.0 | % |  |  | 17.9 | % |  |  |  |  |  |  | -17.1 | % |  |  | 15.2 | % |  |  |  |  |
| EPS from continuing operations |  | -$ | 4.02 |  |  | $ | 1.12 |  |  |  | -459 | % |  | -$ | 2.84 |  |  | $ | 3.45 |  |  |  | -182 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings ($M) |  | $ | 483 |  |  | $ | 396 |  |  |  | 22 | % |  | $ | 1,069 |  |  | $ | 1,156 |  |  |  | -8 | % |
| Percent of sales |  |  | 26.5 | % |  |  | 21.8 | % |  |  |  |  |  |  | 18.2 | % |  |  | 18.6 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 1.25 |  |  | $ | 1.37 |  |  |  | -9 | % |  | $ | 2.58 |  |  | $ | 3.86 |  |  |  | -33 | % |
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 1,246 |  |  | $ | 1,212 |  |  |  | 3 | % |  | $ | 3,807 |  |  | $ | 4,109 |  |  |  | -7 | % |
| GAAP operating earnings (loss) ($M) |  | -$ | 944 |  |  | $ | 237 |  |  |  | -498 | % |  | -$ | 667 |  |  | $ | 639 |  |  |  | -204 | % |
| Percent of sales |  |  | -75.8 | % |  |  | 19.6 | % |  |  |  |  |  |  | -17.5 | % |  |  | 15.6 | % |  |  |  |  |
| Non-GAAP operating earnings ($M) |  | $ | 394 |  |  | $ | 283 |  |  |  | 39 | % |  | $ | 754 |  |  | $ | 775 |  |  |  | -3 | % |
| Percent of sales |  |  | 31.6 | % |  |  | 23.3 | % |  |  |  |  |  |  | 19.8 | % |  |  | 18.9 | % |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales ($M) |  | $ | 577 |  |  | $ | 605 |  |  |  | -5 | % |  | $ | 2,074 |  |  | $ | 2,118 |  |  |  | -2 | % |
| GAAP operating earnings (loss) ($M) |  | -$ | 515 |  |  | $ | 88 |  |  |  | -685 | % |  | -$ | 339 |  |  | $ | 308 |  |  |  | -210 | % |
| Percent of sales |  |  | -89.3 | % |  |  | 14.5 | % |  |  |  |  |  |  | -16.3 | % |  |  | 14.5 | % |  |  |  |  |
| Non-GAAP operating earnings ($M) |  | $ | 89 |  |  | $ | 113 |  |  |  | -21 | % |  | $ | 315 |  |  | $ | 381 |  |  |  | -17 | % |
| Percent of sales |  |  | 15.4 | % |  |  | 18.7 | % |  |  |  |  |  |  | 15.2 | % |  |  | 18.0 | % |  |  |  |  |

[0001193125-15-032592:8k_2_02:16]
Non-GAAP financial information excludes after-tax charges of approximately $5.27 per diluted share related to
share-based compensation and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0001193125-15-032592:8k_2_02:17]
OTHER SELECTED FOURTH-QUARTER FINANCIAL RESULTS

[0001193125-15-032592:8k_2_02:18]
|  | • |  | Revenue – Fourth-quarter sales were flat, including $27 million of unfavorable foreign currency impact, primarily reflecting growth in North America. Fourth-quarter Product sales grew 3 percent driven primarily by an improvement in devices, while Services declined 5 percent driven by lower iDEN and system integration sales. |

[0001193125-15-032592:8k_2_02:19]
|  | • |  | Operating margin – Fourth-quarter GAAP operating margin was -80 percent of sales. GAAP operating earnings were impacted by a $1.9 billion non-recurring charge related to the U.S. pension de-risking activity. Non-GAAP operating margin was 26.5 percent of sales reflecting $86 million in lower operating expenses compared with the fourth quarter of 2013, primarily due to staff reductions across all functions and lower pension and variable compensation expense. |

[0001193125-15-032592:8k_2_02:20]
|  | • |  | Taxes – The fourth-quarter 2014 GAAP effective tax rate from continuing operations resulted in a benefit of 38 percent, driven by the loss from continuing operations, as well as other benefits recorded throughout the year. The fourth quarter 2014 non-GAAP tax rate from continuing operations was 35 percent. This compares with a negative GAAP effective tax rate of 7 percent and a non-GAAP tax rate of 5 percent in the fourth quarter of 2013. The GAAP and non-GAAP tax rates in the fourth quarter of 2013 include the favorable impact of $113 million or $0.42 per share of net tax benefits associated with the recognition of certain foreign tax credits as a result of the implementation of a holding company structure for certain non-U.S. subsidiaries. |

[0001193125-15-032592:8k_2_02:21]
|  | • |  | Cash flow – The company used $700 million in operating cash from continuing operations during the quarter largely driven by incremental pension contributions of $846 million. |

[0001193125-15-032592:8k_2_02:22]
|  | • |  | Cash and cash equivalents – The company completed the sale of its Enterprise business to Zebra Technologies for $3.45 billion and ended the year with total cash of $4 billion. The company returned $1.5 billion to shareholders through share repurchases and cash dividends during the quarter and $2.9 billion for the full year. |

[0001193125-15-032592:8k_2_02:23]
OTHER
SELECTED FULL-YEAR FINANCIAL RESULTS

[0001193125-15-032592:8k_2_02:24]
|  | • |  | Revenue – Full-year sales declined 6 percent to $5.9 billion. The decrease in sales reflects a $302 million, or 7 percent, decrease in the Products segment driven by first-half declines in North America and lower Asia Pacific results. |

[0001193125-15-032592:8k_2_02:25]
|  | • |  | Operating margin – For the full year, GAAP operating margin was -17.1 percent of sales, driven by a $1.9 billion non-recurring charge related to the U.S. pension de-risking activities. Non-GAAP operating margin was 18.2 percent of sales, driven by $208 million in operating expense reductions for the full year. Pension expense and variable compensation were lower compared to the previous year. |

[0001193125-15-032592:8k_2_02:26]
|  | • |  | Taxes – The 2014 non-GAAP effective tax rate from continuing operations was 32 percent, compared with a non-GAAP effective tax rate from continuing operations of 2 percent in the fourth quarter of 2013. The 2013 GAAP and non-GAAP full-year tax rates include the favorable impact of $337 million or $1.25 per share of net tax benefits associated with the recognition of certain foreign tax credits as a result of the implementation of a holding company structure for certain non-U.S. subsidiaries. |

[0001193125-15-032592:8k_2_02:27]
|  | • |  | Cash flow – The company used $685 million in operating cash from continuing operations during the year largely driven by pension contributions of $1.3 billion. |

[0001193125-15-032592:8k_2_02:28]
KEY HIGHLIGHTS

[0001193125-15-032592:8k_2_02:29]
Sales Growth

[0001193125-15-032592:8k_2_02:30]
|  | • |  | Secured significant projects that demonstrate strength in core products and services, including a $148 million statewide public safety network, radios and services agreement with the state of Michigan |

[0001193125-15-032592:8k_2_02:31]
|  | • |  | Demonstrated growing demand for services offerings with a 10-year, $62 million services agreement with Prince George’s County in Maryland; a two-year, $36 million managed services contract extension with the Victorian Mobile Data Network in Australia; a 10-year, $31 million lifecycle services agreement with Las Vegas Metropolitan Police Department in Nevada; and a multi-year, $15 million managed services contract with Forestal Mininco in Chile |

[0001193125-15-032592:8k_2_02:32]
|  | • |  | Showed strength in commercial markets with a multimillion dollar TETRA digital radio system for Dow Chemical Netherlands, a $12 million ASTRO® digital radio system for a U.S. chemical company, and a $2 million WAVE® push-to-talk over broadband contract with a Mexico petroleum company |

[0001193125-15-032592:8k_2_02:33]
Innovation and Product Growth

[0001193125-15-032592:8k_2_02:34]
|  | • |  | Expanded Public Safety LTE portfolio with LEX L10 mission-critical handheld device, which comes equipped with Motorola Solutions’ new Public Safety Experience that provides first responders with the right information at their fingertips |

[0001193125-15-032592:8k_2_02:35]
|  | • |  | Introduced ASTRO 25 Cloud Core Managed Service offering, which enables public safety agencies to access the latest Project 25 land mobile radio technology as well as provide a communications platform for long-term growth and new capabilities |

[0001193125-15-032592:8k_2_02:36]
|  | • |  | Expanded MOTOTRBO™ digital portable radio portfolio with slim, lightweight SL300 and SL1600 models ideal for everyday use in industries such as education, retail, hospitality, event management and private security |

[0001193125-15-032592:8k_2_02:37]
BUSINESS OUTLOOK***

[0001193125-15-032592:8k_2_02:38]
|  | • |  | First quarter 2015 – Motorola Solutions expects a revenue decline of 2 to 4 percent compared with the first quarter of 2014. This assumes a $40 million**** unfavorable currency impact, which translates to revenue growth of -1 to 1 percent in constant currency. The company’s outlook assumes growth in North America, contraction in Europe and a decline in iDEN revenues. The company expects non-GAAP earnings per share from continuing operations in the range of $0.22 to $0.27 per share. |

[0001193125-15-032592:8k_2_02:39]
|  | • |  | Full-year 2015 – The company expects revenue to be flat to down 2 percent compared to 2014. This assumes a $160 million**** unfavorable currency impact, which translates to revenue growth of 1 to 3 percent in constant currency. The company’s outlook assumes growth in North America, contraction in Europe and a decline in iDEN revenues. The company expects non-GAAP earnings per share from continuing operations in the range of $3.15 to $3.35 per share. |

[0001193125-15-032592:8k_2_02:40]
| **** | Based on currency rates as of Feb. 2, 2015. |

[0001193125-15-032592:8k_2_02:41]
CONFERENCE CALL AND WEBCAST

[0001193125-15-032592:8k_2_02:42]
Motorola Solutions will host its quarterly conference call beginning at 7 a.m. U.S. Central Standard Time (8 a.m. U.S. Eastern Standard Time) Wednesday, Feb.
4. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-15-032592:8k_2_02:43]
CONSOLIDATED GAAP RESULTS

[0001193125-15-032592:8k_2_02:44]
A comparison of results from operations is as follows:

[0001193125-15-032592:8k_2_02:45]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net sales ($M) |  | $ | 1,823 |  |  | $ | 1,817 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |
| Gross margin ($M) |  |  | 912 |  |  |  | 901 |  |  |  | 2,831 |  |  |  | 3,109 |  |
| Operating earnings (loss) ($M) |  |  | -1,459 |  |  |  | 325 |  |  |  | -1,006 |  |  |  | 947 |  |
| Earnings (loss) from continuing operations ($M) |  |  | -926 |  |  |  | 293 |  |  |  | -696 |  |  |  | 939 |  |
| Net earnings ($M) |  |  | 201 |  |  |  | 343 |  |  |  | 1,299 |  |  |  | 1,099 |  |
| Diluted EPS from continuing operations |  | -$ | 4.02 |  |  | $ | 1.12 |  |  | -$ | 2.84 |  |  | $ | 3.45 |  |
| Weighted average diluted common shares outstanding |  |  | 230.5 |  |  |  | 261.2 |  |  |  | 245.6 |  |  |  | 270.5 |  |

[0001193125-15-032592:8k_2_02:46]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-15-032592:8k_2_02:47]
The table below includes highlighted items and share-based compensation expense for the fourth quarter of 2014.

[0001193125-15-032592:8k_2_02:48]
|  |  | Fourth Quarter |  |
| (per diluted common share) |  | 2014 |  |
| GAAP Earnings from Continuing Operations |  | -$ | 4.02 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.05 |  |
| Reorganization of business charges |  |  | 0.04 |  |
| Tax expense on legal entity reorganization |  |  | 0.04 |  |
| Reduction in net deferred tax liability for undistributed earnings |  |  | (0.06 | ) |
| Revaluation of deferred taxes for change in effective state tax rates |  |  | 0.05 |  |
| Pension settlement loss, including related expenses |  |  | 5.15 |  |
| Total Highlighted Items |  |  | 5.27 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 1.25 |  |

[0001193125-15-032592:8k_2_02:49]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-15-032592:8k_2_02:50]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-15-032592:8k_2_02:51]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-15-032592:8k_2_02:52]
Share-based compensation expense: The company has excluded share-based compensation expense from its
non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods
presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense.
Share-based compensation expense will recur in future periods.

[0001193125-15-032592:8k_2_02:53]
Details of the above items and reconciliations of the non-GAAP measurements to the
corresponding GAAP measurements can be found at the end of this press release.

[0001193125-15-032592:8k_2_02:54]
BUSINESS RISKS

[0001193125-15-032592:8k_2_02:55]
the company’s ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s
purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (10) the impact on the company’s performance and financial results from strategic
acquisitions or divestitures; (11) risks related to the company’s manufacturing and business operations in foreign countries; (12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large
infrastructure systems; (13) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period;
(14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company’s intellectual property
to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar
proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the
company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in
governmental policies, laws or regulations; (21) negative consequences from the company’s outsourcing of various activities, including certain business operations, information technology and administrative functions; (22) the impact
of the sale of the company’s enterprise legacy information systems, including components of the enterprise Resource planning (ERP) system and the implementation of a new ERP system; and (23) the company’s ability to return proceeds of
the sale of the Enterprise business to shareholders and the timing thereof. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or
otherwise.

[0001193125-15-032592:8k_2_02:56]
DEFINITIONS

[0001193125-15-032592:8k_2_02:57]
| * | Amounts attributable to Motorola Solutions, Inc. common shareholders. |

[0001193125-15-032592:8k_2_02:58]
| ** | Non-GAAP financial information excludes from GAAP results the effects of share-based compensation expense, intangible assets amortization expense and highlighted items. |

[0001193125-15-032592:8k_2_02:59]
| *** | Business outlook excludes share-based compensation, intangible amortization and charges associated with items typically highlighted by the company in its quarterly earnings releases. |

[0001193125-15-032592:8k_2_02:60]
ABOUT MOTOROLA SOLUTIONS

[0001193125-15-032592:8k_2_02:61]
Motorola Solutions (NYSE: MSI)
creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to
a news feed.

[0001193125-15-032592:8k_2_02:62]
MEDIA CONTACT

[0001193125-15-032592:8k_2_02:63]
Kurt Ebenhoch

[0001193125-15-032592:8k_2_02:64]
Motorola Solutions

[0001193125-15-032592:8k_2_02:65]
+1 847-576-1341

[0001193125-15-032592:8k_2_02:66]
kurt.ebenhoch@motorolasolutions.com

[0001193125-15-032592:8k_2_02:67]
INVESTOR CONTACTS

[0001193125-15-032592:8k_2_02:68]
Shep Dunlap

[0001193125-15-032592:8k_2_02:69]
Motorola Solutions

[0001193125-15-032592:8k_2_02:70]
+1 847-576-6899

[0001193125-15-032592:8k_2_02:71]
shep.dunlap@motorolasolutions.com

[0001193125-15-032592:8k_2_02:72]
Chris Kutsor

[0001193125-15-032592:8k_2_02:73]
Motorola Solutions

[0001193125-15-032592:8k_2_02:74]
+1 847-576-4995

[0001193125-15-032592:8k_2_02:75]
chris.kutsor@motorolasolutions.com

[0001193125-15-032592:8k_2_02:76]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license.
All other trademarks are the property of their respective owners. ©2015 Motorola Solutions, Inc. All rights reserved.

[0001193125-15-032592:8k_2_02:77]
GAAP-1

[0001193125-15-032592:8k_2_02:78]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:79]
Condensed Consolidated Statements of Operations

[0001193125-15-032592:8k_2_02:80]
(In millions, except per share amounts)

[0001193125-15-032592:8k_2_02:81]
|  |  | Three Months Ended |  |
|  |  | December 31, 2014 |  |  | December 31, 2013 |  |
| Net sales from products |  | $ | 1,246 |  |  | $ | 1,212 |  |
| Net sales from services |  |  | 577 |  |  |  | 605 |  |
| Net sales |  |  | 1,823 |  |  |  | 1,817 |  |
| Costs of products sales |  |  | 513 |  |  |  | 529 |  |
| Costs of services sales |  |  | 398 |  |  |  | 387 |  |
| Costs of sales |  |  | 911 |  |  |  | 916 |  |
| Gross margin |  |  | 912 |  |  |  | 901 |  |
| Selling, general and administrative expenses |  |  | 283 |  |  |  | 346 |  |
| Research and development expenditures |  |  | 165 |  |  |  | 196 |  |
| Other charges |  |  | 1,922 |  |  |  | 34 |  |
| Intangibles amortization |  |  | 1 |  |  |  | — |  |
| Operating earnings (loss) |  |  | (1,459 | ) |  |  | 325 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (41 | ) |  |  | (28 | ) |
| Gains on sales of investments and businesses, net |  |  | 2 |  |  |  | 3 |  |
| Other |  |  | — |  |  |  | 6 |  |
| Total other expense |  |  | (39 | ) |  |  | (19 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  | (1,498 | ) |  |  | 306 |  |
| Income tax expense (benefit) |  |  | (572 | ) |  |  | 13 |  |
| Earnings (loss) from continuing operations |  |  | (926 | ) |  |  | 293 |  |
| Earnings from discontinued operations, net of tax |  |  | 1,127 |  |  |  | 50 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 201 |  |  | $ | 343 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  | $ | (926 | ) |  | $ | 293 |  |
| Earnings from discontinued operations, net of tax |  |  | 1,127 |  |  |  | 50 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 201 |  |  | $ | 343 |  |
| Earnings per common share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | (4.02 | ) |  | $ | 1.14 |  |
| Discontinued operations |  |  | 4.89 |  |  |  | 0.19 |  |
|  |  | $ | 0.87 |  |  | $ | 1.33 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | (4.02 | ) |  | $ | 1.12 |  |
| Discontinued operations |  |  | 4.89 |  |  |  | 0.19 |  |
|  |  | $ | 0.87 |  |  | $ | 1.31 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 230.5 |  |  |  | 257.5 |  |
| Diluted |  |  | 230.5 |  |  |  | 261.2 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 68.3 | % |  |  | 66.7 | % |
| Net sales from services |  |  | 31.7 | % |  |  | 33.3 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 41.2 | % |  |  | 43.6 | % |
| Costs of services sales |  |  | 69.0 | % |  |  | 64.0 | % |
| Costs of sales |  |  | 50.0 | % |  |  | 50.4 | % |
| Gross margin |  |  | 50.0 | % |  |  | 49.6 | % |
| Selling, general and administrative expenses |  |  | 15.5 | % |  |  | 19.0 | % |
| Research and development expenditures |  |  | 9.1 | % |  |  | 10.8 | % |
| Other charges |  |  | 105.4 | % |  |  | 1.9 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.0 | % |
| Operating earnings (loss) |  |  | -80.0 | % |  |  | 17.9 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -2.2 | % |  |  | -1.5 | % |
| Gains on sales of investments and businesses, net |  |  | 0.1 | % |  |  | 0.2 | % |
| Other |  |  | 0.0 | % |  |  | 0.3 | % |
| Total other expense |  |  | -2.1 | % |  |  | -1.0 | % |
| Earnings (loss) from continuing operations before income taxes |  |  | -82.2 | % |  |  | 16.8 | % |
| Income tax expense (benefit) |  |  | -31.4 | % |  |  | 0.7 | % |
| Earnings from continuing operations |  |  | -50.8 | % |  |  | 16.1 | % |
| Earnings from discontinued operations, net of tax |  |  | 61.8 | % |  |  | 2.8 | % |
| Net earnings |  |  | 11.0 | % |  |  | 18.9 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.0 | % |  |  | 0.0 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 11.0 | % |  |  | 18.9 | % |

[0001193125-15-032592:8k_2_02:82]
| * | Percentages may not add up due to rounding |

[0001193125-15-032592:8k_2_02:83]
GAAP-2

[0001193125-15-032592:8k_2_02:84]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:85]
Consolidated Statements of Operations

[0001193125-15-032592:8k_2_02:86]
(In millions, except per share amounts)

[0001193125-15-032592:8k_2_02:87]
|  |  | Years Ended |  |
|  |  | December 31, 2014 |  |  | December 31, 2013 |  |  | December 31, 2012 |  |
| Net sales from products |  | $ | 3,807 |  |  | $ | 4,109 |  |  | $ | 4,236 |  |
| Net sales from services |  |  | 2,074 |  |  |  | 2,118 |  |  |  | 2,033 |  |
| Net sales |  |  | 5,881 |  |  |  | 6,227 |  |  |  | 6,269 |  |
| Costs of products sales |  |  | 1,678 |  |  |  | 1,808 |  |  |  | 1,795 |  |
| Costs of services sales |  |  | 1,372 |  |  |  | 1,310 |  |  |  | 1,280 |  |
| Costs of sales |  |  | 3,050 |  |  |  | 3,118 |  |  |  | 3,075 |  |
| Gross margin |  |  | 2,831 |  |  |  | 3,109 |  |  |  | 3,194 |  |
| Selling, general and administrative expenses |  |  | 1,184 |  |  |  | 1,330 |  |  |  | 1,472 |  |
| Research and development expenditures |  |  | 681 |  |  |  | 761 |  |  |  | 790 |  |
| Other charges |  |  | 1,968 |  |  |  | 70 |  |  |  | 11 |  |
| Intangibles amortization |  |  | 4 |  |  |  | 1 |  |  |  | 1 |  |
| Operating earnings (loss) |  |  | (1,006 | ) |  |  | 947 |  |  |  | 920 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | (126 | ) |  |  | (113 | ) |  |  | (66 | ) |
| Gains on sales of investments and businesses, net |  |  | 5 |  |  |  | 37 |  |  |  | 26 |  |
| Other |  |  | (34 | ) |  |  | 9 |  |  |  | 1 |  |
| Total other expense |  |  | (155 | ) |  |  | (67 | ) |  |  | (39 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  | (1,161 | ) |  |  | 880 |  |  |  | 881 |  |
| Income tax expense (benefit) |  |  | (465 | ) |  |  | (59 | ) |  |  | 211 |  |
| Earnings (loss) from continuing operations |  |  | (696 | ) |  |  | 939 |  |  |  | 670 |  |
| Earnings from discontinued operations, net of tax |  |  | 1,996 |  |  |  | 166 |  |  |  | 211 |  |
| Net earnings |  |  | 1,300 |  |  |  | 1,105 |  |  |  | 881 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 6 |  |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 1,299 |  |  | $ | 1,099 |  |  | $ | 881 |  |
| Amounts attributable to Motorola Solutions, Inc. common shareholders |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  | $ | (697 | ) |  | $ | 933 |  |  | $ | 670 |  |
| Earnings from discontinued operations, net of tax |  |  | 1,996 |  |  |  | 166 |  |  |  | 211 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 1,299 |  |  | $ | 1,099 |  |  | $ | 881 |  |
| Earnings (loss) per common share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | (2.84 | ) |  | $ | 3.51 |  |  | $ | 2.29 |  |
| Discontinued operations |  |  | 8.13 |  |  |  | 0.62 |  |  |  | 0.73 |  |
|  |  | $ | 5.29 |  |  | $ | 4.13 |  |  | $ | 3.02 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | (2.84 | ) |  | $ | 3.45 |  |  | $ | 2.25 |  |
| Discontinued operations |  |  | 8.13 |  |  |  | 0.61 |  |  |  | 0.71 |  |
|  |  | $ | 5.29 |  |  | $ | 4.06 |  |  | $ | 2.96 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 245.6 |  |  |  | 266.0 |  |  |  | 292.1 |  |
| Diluted |  |  | 245.6 |  |  |  | 270.5 |  |  |  | 297.4 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 64.7 | % |  |  | 66.0 | % |  |  | 67.6 | % |
| Net sales from services |  |  | 35.3 | % |  |  | 34.0 | % |  |  | 32.4 | % |
| Net sales |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Costs of products sales |  |  | 44.1 | % |  |  | 44.0 | % |  |  | 42.4 | % |
| Costs of services sales |  |  | 66.2 | % |  |  | 61.9 | % |  |  | 63.0 | % |
| Costs of sales |  |  | 51.9 | % |  |  | 50.1 | % |  |  | 49.1 | % |
| Gross margin |  |  | 48.1 | % |  |  | 49.9 | % |  |  | 50.9 | % |
| Selling, general and administrative expenses |  |  | 20.1 | % |  |  | 21.4 | % |  |  | 23.5 | % |
| Research and development expenditures |  |  | 11.6 | % |  |  | 12.2 | % |  |  | 12.6 | % |
| Other charges |  |  | 33.5 | % |  |  | 1.1 | % |  |  | 0.2 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.0 | % |  |  | 0.0 | % |
| Operating earnings (loss) |  |  | -17.1 | % |  |  | 15.2 | % |  |  | 14.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net: |  |  | -2.1 | % |  |  | -1.8 | % |  |  | -1.1 | % |
| Gains on sales of investments and businesses, net |  |  | 0.1 | % |  |  | 0.6 | % |  |  | 0.4 | % |
| Other |  |  | -0.6 | % |  |  | 0.1 | % |  |  | 0.0 | % |
| Total other expense |  |  | -2.6 | % |  |  | -1.1 | % |  |  | -0.6 | % |
| Earnings (loss) from continuing operations before income taxes |  |  | -19.7 | % |  |  | 14.1 | % |  |  | 14.1 | % |
| Income tax expense (benefit) |  |  | -7.9 | % |  |  | -0.9 | % |  |  | 3.4 | % |
| Earnings (loss) from continuing operations |  |  | -11.8 | % |  |  | 15.1 | % |  |  | 10.7 | % |
| Earnings from discontinued operations, net of tax |  |  | 33.9 | % |  |  | 2.7 | % |  |  | 3.4 | % |
| Net earnings |  |  | 22.1 | % |  |  | 17.7 | % |  |  | 14.1 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.0 | % |  |  | 0.1 | % |  |  | 0.0 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 22.1 | % |  |  | 17.6 | % |  |  | 14.1 | % |

[0001193125-15-032592:8k_2_02:88]
| * | Percentages may not add up due to rounding |

[0001193125-15-032592:8k_2_02:89]
GAAP-3

[0001193125-15-032592:8k_2_02:90]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:91]
Consolidated Balance Sheets

[0001193125-15-032592:8k_2_02:92]
(In millions)

[0001193125-15-032592:8k_2_02:93]
|  |  | December 31,2014 |  |  | December 31,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,954 |  |  | $ | 3,225 |  |
| Accounts receivable, net |  |  | 1,409 |  |  |  | 1,369 |  |
| Inventories, net |  |  | 345 |  |  |  | 347 |  |
| Deferred income taxes |  |  | 431 |  |  |  | 451 |  |
| Other current assets |  |  | 740 |  |  |  | 635 |  |
| Current assets held for disposition |  |  | — |  |  |  | 993 |  |
| Total current assets |  |  | 6,879 |  |  |  | 7,020 |  |
| Property, plant and equipment, net |  |  | 549 |  |  |  | 610 |  |
| Investments |  |  | 316 |  |  |  | 232 |  |
| Deferred income taxes |  |  | 2,151 |  |  |  | 1,990 |  |
| Goodwill |  |  | 383 |  |  |  | 361 |  |
| Other assets |  |  | 145 |  |  |  | 89 |  |
| Non-current assets held for disposition |  |  | — |  |  |  | 1,549 |  |
| Total assets |  | $ | 10,423 |  |  | $ | 11,851 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 540 |  |  |  | 583 |  |
| Accrued liabilities |  |  | 1,706 |  |  |  | 1,763 |  |
| Current liabilities held for disposition |  |  | — |  |  |  | 870 |  |
| Total current liabilities |  |  | 2,250 |  |  |  | 3,220 |  |
| Long-term debt |  |  | 3,396 |  |  |  | 2,457 |  |
| Other liabilities |  |  | 2,011 |  |  |  | 2,314 |  |
| Non-current liabilities held for disposition |  |  | — |  |  |  | 171 |  |
| Total Motorola Solutions, Inc. stockholders’ equity |  |  | 2,735 |  |  |  | 3,659 |  |
| Noncontrolling interests |  |  | 31 |  |  |  | 30 |  |
| Total liabilities and stockholders’ equity |  | $ | 10,423 |  |  | $ | 11,851 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash** |  | $ | 554 |  |  | $ | 764 |  |

[0001193125-15-032592:8k_2_02:94]
| * | Net cash = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-15-032592:8k_2_02:95]
GAAP-4

[0001193125-15-032592:8k_2_02:96]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:97]
Condensed Consolidated Statements of Cash Flows

[0001193125-15-032592:8k_2_02:98]
(In millions)

[0001193125-15-032592:8k_2_02:99]
|  |  | Three Months Ended |  |
|  |  | December 31, 2014 |  |  | December 31, 2013 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 201 |  |  | $ | 343 |  |
| Earnings from discontinued operations, net of tax |  |  | 1,127 |  |  |  | 50 |  |
| Earnings (loss) from continuing operations, net of tax |  |  | (926 | ) |  |  | 293 |  |
| Adjustments to reconcile Earnings to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 42 |  |  |  | 43 |  |
| Non-cash other charges (income) |  |  | 2 |  |  |  | (3 | ) |
| Loss on pension settlement |  |  | 1,883 |  |  |  | — |  |
| Gains on sales of investments and businesses, net |  |  | (2 | ) |  |  | (3 | ) |
| Share-based compensation expense |  |  | 20 |  |  |  | 29 |  |
| Deferred income taxes |  |  | (626 | ) |  |  | (25 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (264 | ) |  |  | (55 | ) |
| Inventories |  |  | (17 | ) |  |  | 1 |  |
| Other current assets |  |  | (38 | ) |  |  | 38 |  |
| Accounts payable and accrued liabilities |  |  | 50 |  |  |  | 269 |  |
| Other assets and liabilities |  |  | (824 | ) |  |  | (7 | ) |
| Net cash provided by (used for) operating activities |  |  | (700 | ) |  |  | 580 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (26 | ) |  |  | (37 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 3,380 |  |  |  | 13 |  |
| Capital expenditures |  |  | (51 | ) |  |  | (59 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 3 |  |  |  | 51 |  |
| Proceeds from sales of Sigma Fund and short-term investments, net |  |  | — |  |  |  | 1,167 |  |
| Net cash provided by investing activities |  |  | 3,306 |  |  |  | 1,135 |  |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (4 | ) |  |  | (1 | ) |
| Issuance of common stock |  |  | 41 |  |  |  | 56 |  |
| Repurchase of common stock |  |  | (1,423 | ) |  |  | (362 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 5 |  |
| Payments of dividends |  |  | (82 | ) |  |  | (80 | ) |
| Distributions from discontinued operations |  |  | 27 |  |  |  | 153 |  |
| Net cash used for financing activities |  |  | (1,441 | ) |  |  | (229 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | 32 |  |  |  | 162 |  |
| Net cash used for investing activities from discontinued operations |  |  | (1 | ) |  |  | (8 | ) |
| Net cash used for financing activities from discontinued operations |  |  | (27 | ) |  |  | (153 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | (4 | ) |  |  | (1 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (56 | ) |  |  | 18 |  |
| Net increase in cash and cash equivalents |  |  | 1,109 |  |  |  | 1,504 |  |
| Cash and cash equivalents, beginning of period |  |  | 2,845 |  |  |  | 1,721 |  |
| Cash and cash equivalents, end of period |  | $ | 3,954 |  |  | $ | 3,225 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | (751 | ) |  | $ | 521 |  |

[0001193125-15-032592:8k_2_02:100]
| * | Free cash flow = Net cash provided by operating activities - Capital expenditures |

[0001193125-15-032592:8k_2_02:101]
GAAP-5

[0001193125-15-032592:8k_2_02:102]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:103]
Consolidated Statements of Cash Flows

[0001193125-15-032592:8k_2_02:104]
(In millions)

[0001193125-15-032592:8k_2_02:105]
|  |  | Years Ended |  |
|  |  | December 31, 2014 |  |  | December 31, 2013 |  |  | December 31, 2012 |  |
| Operating |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 1,299 |  |  | $ | 1,099 |  |  | $ | 881 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 6 |  |  |  | — |  |
| Net earnings |  |  | 1,300 |  |  |  | 1,105 |  |  |  | 881 |  |
| Earnings from discontinued operations, net of tax |  |  | 1,996 |  |  |  | 166 |  |  |  | 211 |  |
| Earnings (loss) from continuing operations, net of tax |  |  | (696 | ) |  |  | 939 |  |  |  | 670 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 173 |  |  |  | 158 |  |  |  | 151 |  |
| Non-cash other income |  |  | — |  |  |  | (14 | ) |  |  | — |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | — |  |  |  | — |  |
| Loss on pension settlement |  |  | 1,883 |  |  |  | — |  |  |  | — |  |
| Loss from the extinguishment of long term debt |  |  | 37 |  |  |  | — |  |  |  | 6 |  |
| Share-based compensation expense |  |  | 94 |  |  |  | 120 |  |  |  | 146 |  |
| Gains on sales of investments and businesses, net |  |  | (5 | ) |  |  | (37 | ) |  |  | (26 | ) |
| Deferred income taxes |  |  | (557 | ) |  |  | (334 | ) |  |  | 114 |  |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (62 | ) |  |  | (36 | ) |  |  | 81 |  |
| Inventories |  |  | (5 | ) |  |  | (8 | ) |  |  | (2 | ) |
| Other current assets |  |  | (47 | ) |  |  | 50 |  |  |  | (112 | ) |
| Accounts payable and accrued liabilities |  |  | (120 | ) |  |  | (232 | ) |  |  | (106 | ) |
| Other assets and liabilities |  |  | (1,359 | ) |  |  | (51 | ) |  |  | (248 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | (685 | ) |  |  | 555 |  |  |  | 674 |  |
| Investing |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (47 | ) |  |  | (57 | ) |  |  | 83 |  |
| Proceeds from (used for) sales of investments and businesses, net |  |  | 3,403 |  |  |  | 61 |  |  |  | (58 | ) |
| Capital expenditures |  |  | (181 | ) |  |  | (169 | ) |  |  | (170 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 33 |  |  |  | 66 |  |  |  | 40 |  |
| Proceeds from sales of Sigma Fund and short-term investments, net |  |  | — |  |  |  | 2,133 |  |  |  | 1,075 |  |
| Net cash provided by investing activities from continuing operations |  |  | 3,208 |  |  |  | 2,034 |  |  |  | 970 |  |
| Financing |  |  |  |  |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (465 | ) |  |  | (4 | ) |  |  | (413 | ) |
| Net proceeds from issuance of debt |  |  | 1,375 |  |  |  | 593 |  |  |  | 747 |  |
| Issuance of common stock |  |  | 135 |  |  |  | 165 |  |  |  | 133 |  |
| Repurchase of common stock |  |  | (2,546 | ) |  |  | (1,694 | ) |  |  | (2,438 | ) |
| Excess tax benefit from share-based compensation |  |  | 11 |  |  |  | 25 |  |  |  | 20 |  |
| Payments of dividends |  |  | (318 | ) |  |  | (292 | ) |  |  | (270 | ) |
| Contributions to Motorola Mobility |  |  | — |  |  |  | — |  |  |  | (73 | ) |
| Distributions from discontinued operations |  |  | 93 |  |  |  | 365 |  |  |  | 217 |  |
| Net cash used for financing activities from continuing operations |  |  | (1,715 | ) |  |  | (842 | ) |  |  | (2,077 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | 95 |  |  |  | 389 |  |  |  | 396 |  |
| Net cash provided by (used for) investing activities from discontinued operations |  |  | 4 |  |  |  | (24 | ) |  |  | (173 | ) |
| Net cash used for financing activities from discontinued operations |  |  | (93 | ) |  |  | (365 | ) |  |  | (217 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | (6 | ) |  |  | — |  |  |  | (6 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (79 | ) |  |  | 10 |  |  |  | 20 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 729 |  |  |  | 1,757 |  |  |  | (413 | ) |
| Cash and cash equivalents, beginning of period |  |  | 3,225 |  |  |  | 1,468 |  |  |  | 1,881 |  |
| Cash and cash equivalents, end of period |  | $ | 3,954 |  |  | $ | 3,225 |  |  | $ | 1,468 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | (866 | ) |  | $ | 386 |  |  | $ | 504 |  |

[0001193125-15-032592:8k_2_02:106]
| * | Free cash flow = Net cash provided by operating activities - Capital expenditures |

[0001193125-15-032592:8k_2_02:107]
GAAP-6

[0001193125-15-032592:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:109]
Segment Information

[0001193125-15-032592:8k_2_02:110]
(In
millions)

[0001193125-15-032592:8k_2_02:111]
Net Sales

[0001193125-15-032592:8k_2_02:112]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | 1,246 |  |  | $ | 1,212 |  |  |  | 3 | % |
| Services |  |  | 577 |  |  |  | 605 |  |  |  | -5 | % |
| Total Motorola Solutions |  | $ | 1,823 |  |  | $ | 1,817 |  |  |  | 0 | % |

[0001193125-15-032592:8k_2_02:113]
|  |  | Year Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | 3,807 |  |  | $ | 4,109 |  |  |  | -7 | % |
| Services |  |  | 2,074 |  |  |  | 2,118 |  |  |  | -2 | % |
| Total Motorola Solutions |  | $ | 5,881 |  |  | $ | 6,227 |  |  |  | -6 | % |

[0001193125-15-032592:8k_2_02:114]
Operating Earnings (loss)

[0001193125-15-032592:8k_2_02:115]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | (944 | ) |  | $ | 237 |  |  |  | -498 | % |
| Services |  |  | (515 | ) |  |  | 88 |  |  |  | -685 | % |
| Total Motorola Solutions |  | $ | (1,459 | ) |  | $ | 325 |  |  |  | -549 | % |

[0001193125-15-032592:8k_2_02:116]
|  |  | Year Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | (667 | ) |  | $ | 639 |  |  |  | -204 | % |
| Services |  |  | (339 | ) |  |  | 308 |  |  |  | -210 | % |
| Total Motorola Solutions |  | $ | (1,006 | ) |  | $ | 947 |  |  |  | -206 | % |

[0001193125-15-032592:8k_2_02:117]
Operating Earnings %

[0001193125-15-032592:8k_2_02:118]
|  |  | Three Months Ended |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |
| Products |  |  | -75.8 | % |  |  | 19.6 | % |
| Services |  |  | -89.3 | % |  |  | 14.5 | % |
| Total Motorola Solutions |  |  | -80.0 | % |  |  | 17.9 | % |

[0001193125-15-032592:8k_2_02:119]
|  |  | Year Ended |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |
| Products |  |  | -17.5 | % |  |  | 15.6 | % |
| Services |  |  | -16.3 | % |  |  | 14.5 | % |
| Total Motorola Solutions |  |  | -17.1 | % |  |  | 15.2 | % |

[0001193125-15-032592:8k_2_02:120]
Non-GAAP-1

[0001193125-15-032592:8k_2_02:121]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:122]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-15-032592:8k_2_02:123]
Q1 2014

[0001193125-15-032592:8k_2_02:124]
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPS impact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 29 |  |  |  | 9 |  |  |  | 20 |  |  |  | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 10 |  |  |  | 2 |  |  |  | 8 |  |  |  | 0.03 |  |
| Gain on sale of building and land |  | Other charges |  |  | (21 | ) |  |  | (8 | ) |  |  | (13 | ) |  |  | (0.05 | ) |
| Recognition of previously unrecognized income tax benefits |  | Income tax expense |  |  | — |  |  |  | 29 |  |  |  | (29 | ) |  |  | (0.11 | ) |
| Total impact on Net earnings |  |  |  | $ | 19 |  |  | $ | 32 |  |  | $ | (13 | ) |  | $ | (0.05 | ) |

[0001193125-15-032592:8k_2_02:125]
Q2 2014

[0001193125-15-032592:8k_2_02:126]
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPS impact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 26 |  |  |  | 9 |  |  |  | 17 |  |  |  | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 28 |  |  |  | 8 |  |  |  | 20 |  |  |  | 0.08 |  |
| Legal settlement |  | Other charges |  |  | 8 |  |  |  | 3 |  |  |  | 5 |  |  |  | 0.02 |  |
| Total impact on Net earnings |  |  |  | $ | 63 |  |  | $ | 20 |  |  | $ | 43 |  |  | $ | 0.17 |  |

[0001193125-15-032592:8k_2_02:127]
Q3 2014

[0001193125-15-032592:8k_2_02:128]
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPS impact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 20 |  |  |  | 6 |  |  |  | 14 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 20 |  |  |  | 6 |  |  |  | 14 |  |  |  | 0.06 |  |
| Pension settlement related expenses |  | Other charges |  |  | 11 |  |  |  | 4 |  |  |  | 7 |  |  |  | 0.03 |  |
| Loss from the extinguishment of long-term debt |  | Other expense (income) |  |  | 37 |  |  |  | 14 |  |  |  | 23 |  |  |  | 0.09 |  |
| Gain on investment |  | Other expense (income) |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |  |  | (0.04 | ) |
| Tax expense to establish foreign valuation allowance |  | Income tax expense |  |  | — |  |  |  | (55 | ) |  |  | 55 |  |  |  | 0.22 |  |
| Revaluation of deferred taxes for change in effective state tax rates |  | Income tax expense |  |  | — |  |  |  | 16 |  |  |  | (16 | ) |  |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 79 |  |  | $ | (9 | ) |  | $ | 88 |  |  | $ | 0.35 |  |

[0001193125-15-032592:8k_2_02:129]
Q4 2014

[0001193125-15-032592:8k_2_02:130]
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPS impact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  |  | — |  |
| Stock-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 20 |  |  |  | 8 |  |  |  | 12 |  |  |  | 0.05 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 15 |  |  |  | 5 |  |  |  | 10 |  |  |  | 0.04 |  |
| Tax expense on legal entity reorganization |  | Income tax expense |  |  | — |  |  |  | (8 | ) |  |  | 8 |  |  |  | 0.04 |  |
| Reduction in net deferred tax liability for undistributed earnings |  | Income tax expense |  |  | — |  |  |  | 14 |  |  |  | (14 | ) |  |  | (0.06 | ) |
| Revaluation of deferred taxes for change in effective state tax rates |  | Income tax expense |  |  | — |  |  |  | (12 | ) |  |  | 12 |  |  |  | 0.05 |  |
| Pension settlement loss, including related expenses |  | Other charges |  |  | 1,906 |  |  |  | 721 |  |  |  | 1,185 |  |  |  | 5.15 |  |
| Total impact on Net earnings |  |  |  | $ | 1,942 |  |  | $ | 728 |  |  | $ | 1,214 |  |  | $ | 5.27 |  |

[0001193125-15-032592:8k_2_02:131]
FY 2014

[0001193125-15-032592:8k_2_02:132]
| Highlighted Items |  | Statement Line |  | PBT (Inc)/Exp |  |  | Tax Inc/(Exp) |  |  | PAT (Inc)/Exp |  |  | EPS impact |  |
| Intangibles amortization expense |  | Intangibles amortization |  | $ | 4 |  |  | $ | — |  |  |  | 4 |  |  |  | 0.02 |  |
| Stock-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 94 |  |  |  | 32 |  |  |  | 62 |  |  |  | 0.26 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 73 |  |  |  | 21 |  |  |  | 52 |  |  |  | 0.21 |  |
| Gain on sale of building and land |  | Other charges |  |  | (21 | ) |  |  | (8 | ) |  |  | (13 | ) |  |  | (0.05 | ) |
| Recognition of previously unrecognized income tax benefits |  | Income tax expense |  |  | — |  |  |  | 29 |  |  |  | (29 | ) |  |  | (0.12 | ) |
| Legal settlement |  | Other charges |  |  | 8 |  |  |  | 3 |  |  |  | 5 |  |  |  | 0.02 |  |
| Loss from the extinguishment of long-term debt |  | Other expense (income) |  |  | 37 |  |  |  | 14 |  |  |  | 23 |  |  |  | 0.09 |  |
| Gain on investment |  | Other expense (income) |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |  |  | (0.04 | ) |
| Tax expense to establish foreign valuation allowance |  | Income tax expense |  |  | — |  |  |  | (55 | ) |  |  | 55 |  |  |  | 0.22 |  |
| Tax expense on legal entity reorganization |  | Income tax expense |  |  | — |  |  |  | (8 | ) |  |  | 8 |  |  |  | 0.03 |  |
| Reduction in net deferred tax liability for undistributed earnings |  | Income tax expense |  |  | — |  |  |  | 14 |  |  |  | (14 | ) |  |  | (0.06 | ) |
| Revaluation of deferred taxes for change in effective state tax rates |  | Income tax expense |  |  | — |  |  |  | 4 |  |  |  | (4 | ) |  |  | (0.02 | ) |
| Pension settlement loss, including related expenses |  | Other charges |  |  | 1,917 |  |  |  | 725 |  |  |  | 1,192 |  |  |  | 4.86 |  |
| Total impact on Net earnings |  |  |  | $ | 2,102 |  |  | $ | 771 |  |  | $ | 1,331 |  |  | $ | 5.42 |  |

[0001193125-15-032592:8k_2_02:133]
Non-GAAP-2

[0001193125-15-032592:8k_2_02:134]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:135]
Non-GAAP Segment Information

[0001193125-15-032592:8k_2_02:136]
(In millions)

[0001193125-15-032592:8k_2_02:137]
Net
Sales

[0001193125-15-032592:8k_2_02:138]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | 1,246 |  |  | $ | 1,212 |  |  |  | 3 | % |
| Services |  |  | 577 |  |  |  | 605 |  |  |  | -5 | % |
| Total Motorola Solutions |  | $ | 1,823 |  |  | $ | 1,817 |  |  |  | 0 | % |

[0001193125-15-032592:8k_2_02:139]
|  |  | Year Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | 3,807 |  |  | $ | 4,109 |  |  |  | -7 | % |
| Services |  |  | 2,074 |  |  |  | 2,118 |  |  |  | -2 | % |
| Total Motorola Solutions |  | $ | 5,881 |  |  | $ | 6,227 |  |  |  | -6 | % |

[0001193125-15-032592:8k_2_02:140]
Non-GAAP Operating Earnings

[0001193125-15-032592:8k_2_02:141]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | 394 |  |  | $ | 283 |  |  |  | 39 | % |
| Services |  |  | 89 |  |  |  | 113 |  |  |  | -21 | % |
| Total Motorola Solutions |  | $ | 483 |  |  | $ | 396 |  |  |  | 22 | % |

[0001193125-15-032592:8k_2_02:142]
|  |  | Year Ended |  |  |  |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |  | % Change |  |
| Products |  | $ | 754 |  |  | $ | 775 |  |  |  | -3 | % |
| Services |  |  | 315 |  |  |  | 381 |  |  |  | -17 | % |
| Total Motorola Solutions |  | $ | 1,069 |  |  | $ | 1,156 |  |  |  | -8 | % |

[0001193125-15-032592:8k_2_02:143]
Non-GAAP Operating Earnings %

[0001193125-15-032592:8k_2_02:144]
|  |  | Three Months Ended |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |
| Products |  |  | 31.6 | % |  |  | 23.3 | % |
| Services |  |  | 15.4 | % |  |  | 18.7 | % |
| Total Motorola Solutions |  |  | 26.5 | % |  |  | 21.8 | % |

[0001193125-15-032592:8k_2_02:145]
|  |  | Year Ended |  |
|  |  | December 31,2014 |  |  | December 31,2013 |  |
| Products |  |  | 19.8 | % |  |  | 18.9 | % |
| Services |  |  | 15.2 | % |  |  | 18.0 | % |
| Total Motorola Solutions |  |  | 18.2 | % |  |  | 18.6 | % |

[0001193125-15-032592:8k_2_02:146]
Non-GAAP-3

[0001193125-15-032592:8k_2_02:147]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-15-032592:8k_2_02:148]
Operating Earnings after Non-GAAP Adjustments

[0001193125-15-032592:8k_2_02:149]
Q1 2014

[0001193125-15-032592:8k_2_02:150]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,228 |  |  | $ | 753 |  |  | $ | 475 |  |
| Operating earnings (“OE”) |  | $ | 107 |  |  | $ | 39 |  |  | $ | 68 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 29 |  |  |  | 19 |  |  |  | 10 |  |
| Reorganization of business charges |  |  | 10 |  |  |  | 6 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | (14 | ) |  |  | (7 | ) |
| Total above-OE non-GAAP adjustments |  |  | 19 |  |  |  | 12 |  |  |  | 7 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 126 |  |  | $ | 51 |  |  | $ | 75 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 8.7 | % |  |  | 5.2 | % |  |  | 14.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 10.3 | % |  |  | 6.8 | % |  |  | 15.8 | % |

[0001193125-15-032592:8k_2_02:151]
Q2 2014

[0001193125-15-032592:8k_2_02:152]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,393 |  |  | $ | 887 |  |  | $ | 506 |  |
| Operating earnings (“OE”) |  | $ | 138 |  |  | $ | 95 |  |  | $ | 43 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 26 |  |  |  | 14 |  |  |  | 12 |  |
| Reorganization of business charges |  |  | 28 |  |  |  | 18 |  |  |  | 10 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Legal settlement |  |  | 8 |  |  |  | 5 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 63 |  |  |  | 38 |  |  |  | 25 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 201 |  |  | $ | 133 |  |  | $ | 68 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 9.9 | % |  |  | 10.7 | % |  |  | 8.5 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 14.4 | % |  |  | 15.0 | % |  |  | 13.4 | % |

[0001193125-15-032592:8k_2_02:153]
Q3 2014

[0001193125-15-032592:8k_2_02:154]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,436 |  |  | $ | 921 |  |  | $ | 515 |  |
| Operating earnings (“OE”) |  | $ | 207 |  |  | $ | 141 |  |  | $ | 66 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 20 |  |  |  | 11 |  |  |  | 9 |  |
| Reorganization of business charges |  |  | 20 |  |  |  | 14 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Pension settlement related expenses |  |  | 11 |  |  |  | 8 |  |  |  | 3 |  |
| Total above-OE non-GAAP adjustments |  |  | 52 |  |  |  | 34 |  |  |  | 18 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 259 |  |  | $ | 175 |  |  | $ | 84 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 14.4 | % |  |  | 15.3 | % |  |  | 12.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 18.8 | % |  |  | 19.4 | % |  |  | 17.7 | % |

[0001193125-15-032592:8k_2_02:155]
Q4 2014

[0001193125-15-032592:8k_2_02:156]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,823 |  |  | $ | 1,246 |  |  | $ | 577 |  |
| Operating earnings |  | $ | (1,459 | ) |  | $ | (944 | ) |  | $ | (515 | ) |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 20 |  |  |  | 12 |  |  |  | 8 |  |
| Reorganization of business charges |  |  | 15 |  |  |  | 10 |  |  |  | 5 |  |
| Intangibles amortization expense |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Pension settlement loss, including related expenses |  |  | 1,906 |  |  |  | 1,315 |  |  |  | 591 |  |
| Total above-OE non-GAAP adjustments |  |  | 1,942 |  |  |  | 1,338 |  |  |  | 604 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 483 |  |  | $ | 394 |  |  | $ | 89 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | -80.0 | % |  |  | -75.8 | % |  |  | -89.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 26.5 | % |  |  | 31.6 | % |  |  | 15.4 | % |

[0001193125-15-032592:8k_2_02:157]
FY 2014

[0001193125-15-032592:8k_2_02:158]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 5,881 |  |  | $ | 3,807 |  |  | $ | 2,074 |  |
| Operating earnings |  | $ | (1,006 | ) |  | $ | (667 | ) |  | $ | (339 | ) |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 94 |  |  |  | 55 |  |  |  | 39 |  |
| Reorganization of business charges |  |  | 73 |  |  |  | 48 |  |  |  | 25 |  |
| Intangibles amortization expense |  |  | 4 |  |  |  | 4 |  |  |  | — |  |
| Gain on sale of building and land |  |  | (21 | ) |  |  | (14 | ) |  |  | (7 | ) |
| Legal settlement |  |  | 8 |  |  |  | 5 |  |  |  | 3 |  |
| Pension settlement loss, including related expenses |  |  | 1,917 |  |  |  | 1,323 |  |  |  | 594 |  |
| Total above-OE non-GAAP adjustments |  |  | 2,075 |  |  |  | 1,421 |  |  |  | 654 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,069 |  |  | $ | 754 |  |  | $ | 315 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | -17.1 | % |  |  | -17.5 | % |  |  | -16.3 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 18.2 | % |  |  | 19.8 | % |  |  | 15.2 | % |
