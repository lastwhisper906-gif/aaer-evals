# MSI MD&A — 0000068505-15-000003


## mdna

[0000068505-15-000003:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-15-000003:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2014 and 2013 and results of operations for each of the three years in the period ended December 31, 2014. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-15-000003:mdna:3]
Executive Overview

[0000068505-15-000003:mdna:4]
Recent Developments

[0000068505-15-000003:mdna:5]
On April 14, 2014, we entered into a Master Acquisition Agreement (the “Acquisition Agreement”) with Zebra Technologies Corporation to sell our Enterprise business for $3.5 billion in cash. The transaction closed on October 27, 2014. As a result of the sale, we have reported the Enterprise business as a discontinued operation in our consolidated financial statements and footnotes for all periods presented.

[0000068505-15-000003:mdna:6]
Our Business

[0000068505-15-000003:mdna:7]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-15-000003:mdna:8]
We conduct our business globally and manage it by two segments:

[0000068505-15-000003:mdna:9]
Products: The Products segment offers an extensive portfolio of infrastructure, devices, accessories, and software. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. Our Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. In 2014, the segment’s net sales were $3.8 billion, representing 65% of our consolidated net sales.

[0000068505-15-000003:mdna:10]
Services: The Services segment provides a full set of service offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Lifecycle Support services, (iii) Managed services, (iv) Smart Public Safety Solutions, and (v) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications.  Lifecycle Support services includes lifecycle planning, software and hardware maintenance, security patches and upgrades, call center support, network monitoring, and repair services.  Managed services includes managing and operating customer systems and devices at defined services levels. Smart Public Safety Solutions includes software and hardware solutions for our customers' "Command & Control" centers providing video monitoring support, data analytics, and content management with the objective of enabling smart policing. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2014, the segment’s net sales were $2.1 billion, representing 35% of our consolidated net sales.

[0000068505-15-000003:mdna:11]
What were our 2014 financial results?

[0000068505-15-000003:mdna:12]
| • | Net sales were $5.9 billion in 2014 compared to $6.2 billion in 2013. |

[0000068505-15-000003:mdna:13]
| • | We had an operating loss of $1.0 billion in 2014, compared to operating earnings of $947 million in 2013. Included in the 2014 operating loss was a $1.9 billion pension settlement loss, including related expenses. |

[0000068505-15-000003:mdna:14]
| • | Loss from continuing operations was $697 million, or $(2.84) per diluted common share in 2014, compared to earnings of $933 million, or $3.45 per diluted common share in 2013. |

[0000068505-15-000003:mdna:15]
| • | Cash used for operating activities was $685 million in 2014, compared to cash provided by operating activities of $555 million in 2013. We contributed $1.3 billion to our pension plans during 2014, compared to $182 million in 2013. |

[0000068505-15-000003:mdna:16]
| • | We provided cash to shareholders through repurchases of $2.5 billion in shares and $318 million in cash dividends during 2014. |

[0000068505-15-000003:mdna:17]
What were the financial results for our two segments in 2014?

[0000068505-15-000003:mdna:18]
| • | In the Products segment, net sales were $3.8 billion in 2014, a decrease of $302 million, or 7%, compared to $4.1 billion in 2013. On a geographic basis, net sales decreased in North America, Latin America and Asia Pacific and Middle East ("APME") and increased in Europe and Africa ("EA") compared to 2013. Operating losses were $667 million in 2014, compared to operating earnings of $639 million in 2013. Operating margin decreased in 2014 to (17.5)% from 15.6% in 2013. Approximately $1.3 billion of pension settlement losses were allocated to the Products segment in 2014. |

[0000068505-15-000003:mdna:19]
| • | In the Services segment, net sales were $2.1 billion in 2014, a decrease of $44 million, or 2%, compared to $2.1 billion in 2013. On a geographic basis, net sales decreased in North America, Latin America and APME and increased in EA, compared to 2013. Operating losses were $339 million in 2014, compared to operating earnings of $308 million in |

[0000068505-15-000003:mdna:20]
25

[0000068505-15-000003:mdna:21]
2013.  Operating margin decreased in 2014 to (16.3)% from 14.5% in 2013. Approximately $584 million of pension settlement losses were allocated to the Services segment in 2014.

[0000068505-15-000003:mdna:22]
What were our major accomplishments in 2014?

[0000068505-15-000003:mdna:23]
2014 was a transformational year both structurally and financially.  In addition to selling our Enterprise business for $3.5 billion, we restructured our operations and financial profile to become a more focused, streamlined business.  We had pockets of growth in 2014, most notably in EA, while the North America downturn during the first half of the year pressured overall top-line growth.  North America ended 2014 with growth driven by record fourth quarter sales and backlog.  Finally, our overall financial profile improved with a lower structural cost base, growing backlog position, significantly lower share count and a material reduction in our pension obligations, reducing volatility.

[0000068505-15-000003:mdna:24]
Structural highlights

[0000068505-15-000003:mdna:25]
| • | Sold our Enterprise business for $3.5 billion, enabling us to focus on the core government and public safety mission-critical communications business and associated expansion opportunities; |

[0000068505-15-000003:mdna:26]
| • | De-risked our U.S. Pension plan by significantly reducing the total liability of the plan and cutting the number of participants by approximately half, with the effect of reducing expected future contributions and volatility; |

[0000068505-15-000003:mdna:27]
| • | Reduced operating expenses by more than $200 million as compared to 2013, including reorganizing our R&D and SG&A functions. This reorganization both reduced costs and enabled efficiencies that shifted more investment into key areas such as Services and Public Safety LTE solutions; and |

[0000068505-15-000003:mdna:28]
| • | Returned approximately $2.9 billion in capital to shareholders through share repurchases and dividends. |

[0000068505-15-000003:mdna:29]
Business highlights

[0000068505-15-000003:mdna:30]
| • | Ended 2014 with a record backlog position of $5.8 billion, up 6% compared to 2013; |

[0000068505-15-000003:mdna:31]
| • | Services backlog up over $250 million versus 2013, including: |

[0000068505-15-000003:mdna:32]
| ◦ | Significant growth in multi-year software & hardware maintenance contracts; |

[0000068505-15-000003:mdna:33]
| ◦ | Significant growth in managed services orders and pipeline opportunities; and |

[0000068505-15-000003:mdna:34]
| ◦ | Won six public safety accounts for our Smart Public Safety Solutions. |

[0000068505-15-000003:mdna:35]
| • | Awarded largest public safety LTE system in the world for $175 million; |

[0000068505-15-000003:mdna:36]
| • | North America ended 2014 with record fourth quarter sales and orders; and |

[0000068505-15-000003:mdna:37]
| • | EA grew sales 5% year-over-year on a difficult comparison. |

[0000068505-15-000003:mdna:38]
Looking Forward

[0000068505-15-000003:mdna:39]
Entering 2015, we believe we are well-positioned to compete in both our core markets and adjacent growth areas. We have a broad, compelling product and services portfolio specifically tailored for our mission-critical communications customer base that spans many layers of governments, public safety, and first responders, as well as commercial and industrial customers in a number of key verticals. As we add new products, features, and software upgrades, we ensure our solutions are interoperable and backward-compatible, enabling customers to confidently invest for their future needs while allowing them to utilize their prior investment in our technology.

[0000068505-15-000003:mdna:40]
Our backlog position has improved as compared to last year, and we believe the funding environment of our largest government customers and the economics surrounding our commercial customers appears to be relatively healthy, although we are experiencing some challenges relating to currency fluctuations, particularly in Europe and Asia.

[0000068505-15-000003:mdna:41]
We expect our core business serving existing private network customers to continue to provide opportunity for growth into new systems, as there are thousands of old, analog systems still being used today that require upgrades for customers to experience full voice, data and video capabilities. These systems are typically converted from analog into new digital systems, and are upgraded for reasons that include: spectrum-efficiency mandates, capacity constraints, coverage expansion, or new feature upgrades. We will continue to offer devices and systems that meet our customers' specific needs for private mission-critical communications around the world.

[0000068505-15-000003:mdna:42]
Supplementing our traditional core business is our Services business, which has been a focus area for us in recent years. As communication networks have become increasingly complex, software-centric, and data-driven, we have shifted our offerings to align with this technology trend, and our customers have shown interest in these offerings. Thus, we expect to continue to see growing demand for our Managed services, Lifecycle Support services offerings, and Smart Public Safety Solutions. These services offerings help customers manage, support, and upgrade their networks as well as utilize features, applications, and data in new ways including predictive policing, proactive support, or smarter response strategies. We expect our overall revenue mix to continue to shift towards services overtime.

[0000068505-15-000003:mdna:43]
Another key technology trend complementing our existing business is the use of broadband LTE by our customers. We have been proactively investing in next generation public safety broadband solutions for years, as we believe public safety LTE solutions are the next generation tool for our public safety first-responder customers. We believe our expertise in both public and private networks makes us uniquely qualified to provide these LTE solutions to this customer base. We have won the three

[0000068505-15-000003:mdna:44]
26

[0000068505-15-000003:mdna:45]
largest public safety LTE network deals awarded and we expect these deals, among others, to begin to generate revenue in 2015.

[0000068505-15-000003:mdna:46]
We expect our iDEN revenues to continue to decline in accordance with our contractual service arrangements over the next two to three years. The majority of iDEN sales are accounted for in our Services segment.

[0000068505-15-000003:mdna:47]
We remain committed to employing disciplined financial policies, including an additional reduction of over $100 million in selling, general, administrative, research, and development expenses in 2015, brining our cumulative reduction in these operating expenses to over $300 million during 2014 and 2015. We continue to explore opportunities to transition our capital structure in a way that is reflective of our ability to generate solid operating cash flow and prioritize targeted investments in the business. We expect to continue the quarterly dividends that were initiated in 2011 and intend to continue to invest organically in capital expenditures and R&D. We will also evaluate acquisition opportunities along with the opportunities to return capital to shareholders via share repurchases in accordance with our share repurchase program. As of December 31, 2014, we had approximately $4.2 billion of authority available for share repurchases.

[0000068505-15-000003:mdna:48]
27

[0000068505-15-000003:mdna:49]
Results of Operations

[0000068505-15-000003:mdna:50]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2014 |  | % ofSales ** |  | 2013 |  | % ofSales ** |  | 2012 |  | % ofSales ** |
| Net sales from products | $ | 3,807 |  |  |  |  | $ | 4,109 |  |  |  |  | $ | 4,236 |  |  |  |
| Net sales from services | 2,074 |  |  |  |  | 2,118 |  |  |  |  | 2,033 |  |  |  |
| Net sales | 5,881 |  |  |  |  | 6,227 |  |  |  |  | 6,269 |  |  |  |
| Costs of product sales | 1,678 |  |  | 44.1 | % |  | 1,808 |  |  | 44.0 | % |  | 1,795 |  |  | 42.4 | % |
| Costs of services sales | 1,372 |  |  | 66.2 | % |  | 1,310 |  |  | 61.9 | % |  | 1,280 |  |  | 63.0 | % |
| Costs of sales | 3,050 |  |  | 51.9 | % |  | 3,118 |  |  | 50.1 | % |  | 3,075 |  |  | 49.1 | % |
| Gross margin | 2,831 |  |  | 48.1 | % |  | 3,109 |  |  | 49.9 | % |  | 3,194 |  |  | 50.9 | % |
| Selling, general and administrative expenses | 1,184 |  |  | 20.1 | % |  | 1,330 |  |  | 21.4 | % |  | 1,472 |  |  | 23.5 | % |
| Research and development expenditures | 681 |  |  | 11.6 | % |  | 761 |  |  | 12.2 | % |  | 790 |  |  | 12.6 | % |
| Other charges | 1,972 |  |  | 33.5 | % |  | 71 |  |  | 1.1 | % |  | 12 |  |  | 0.2 | % |
| Operating earnings (loss) | (1,006 | ) |  | (17.1 | )% |  | 947 |  |  | 15.2 | % |  | 920 |  |  | 14.7 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (126 | ) |  | (2.1 | )% |  | (113 | ) |  | (1.8 | )% |  | (66 | ) |  | (1.1 | )% |
| Gains on sales of investments | 5 |  |  | 0.1 | % |  | 37 |  |  | 0.6 | % |  | 26 |  |  | 0.4 | % |
| Other | (34 | ) |  | (0.6 | )% |  | 9 |  |  | 0.1 | % |  | 1 |  |  | — | % |
| Total other expense | (155 | ) |  | (2.6 | )% |  | (67 | ) |  | (1.1 | )% |  | (39 | ) |  | (0.6 | )% |
| Earnings (loss) from continuing operations before income taxes | (1,161 | ) |  | (19.7 | )% |  | 880 |  |  | 14.1 | % |  | 881 |  |  | 14.1 | % |
| Income tax expense (benefit) | (465 | ) |  | (7.9 | )% |  | (59 | ) |  | (0.9 | )% |  | 211 |  |  | 3.4 | % |
| Earnings (loss) from continuing operations | (696 | ) |  | (11.8 | )% |  | 939 |  |  | 15.1 | % |  | 670 |  |  | 10.7 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | — | % |  | 6 |  |  | 0.1 | % |  | — |  |  | — | % |
| Earnings (loss) from continuing operations* | (697 | ) |  | (11.9 | )% |  | 933 |  |  | 15.0 | % |  | 670 |  |  | 10.7 | % |
| Earnings from discontinued operations, net of tax | 1,996 |  |  | 33.9 | % |  | 166 |  |  | 2.7 | % |  | 211 |  |  | 3.4 | % |
| Net earnings* | $ | 1,299 |  |  | 22.1 | % |  | $ | 1,099 |  |  | 17.6 | % |  | $ | 881 |  |  | 14.1 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | (2.84 | ) |  |  |  | $ | 3.45 |  |  |  |  | $ | 2.25 |  |  |  |
| Discontinued operations | 8.13 |  |  |  |  | 0.61 |  |  |  |  | 0.71 |  |  |  |
| Earnings per diluted common share* | $ | 5.29 |  |  |  |  | $ | 4.06 |  |  |  |  | $ | 2.96 |  |  |  |

[0000068505-15-000003:mdna:51]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-15-000003:mdna:52]
**    Percentages may not add due to rounding.

[0000068505-15-000003:mdna:53]
Geographic Market Sales by Locale of End Customer

[0000068505-15-000003:mdna:54]
|  | 2014 |  | 2013 |  | 2012 |
| North America | 61 | % |  | 63 | % |  | 62 | % |
| Latin America | 9 | % |  | 8 | % |  | 9 | % |
| EA | 17 | % |  | 16 | % |  | 14 | % |
| APME | 13 | % |  | 13 | % |  | 15 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-15-000003:mdna:55]
Results of Operations—2014 Compared to 2013

[0000068505-15-000003:mdna:56]
Net Sales

[0000068505-15-000003:mdna:57]
Net sales were $5.9 billion in 2014, down $346 million, or 6%, compared to $6.2 billion in 2013. The decrease in net sales reflects a $302 million, or 7%, decrease in the Products segment driven by declines in: (i) North America and APME, reflecting lower devices and systems sales and (ii) Latin America, reflecting lower devices sales, partially offset by single-digit growth in EA

[0000068505-15-000003:mdna:58]
as a result of higher devices sales. In addition, the decrease in net sales includes a $44 million, or 2%, decrease in net sales relating to the Services segment driven by declines in: (i) North America, as a result of declines in iDEN services and integration services, (ii) APME, reflecting lower sales in Lifecycle Support services and Integration services, and (iii) Latin America, reflecting a decrease in iDEN services, partially offset by an increase in EA, as a result of increased Integration and Managed services sales. Sales in 2014 were positively impacted in the fourth quarter by increased order activity and faster-than-expected conversion of certain orders.

[0000068505-15-000003:mdna:59]
Gross Margin

[0000068505-15-000003:mdna:60]
Gross margin was $2.8 billion, or 48.1% of net sales in 2014, compared to $3.1 billion, or 49.9% of net sales, in 2013. The decrease in gross margin percentage is driven primarily by: (i) a decline in gross margin as a percentage of sales in North America and Latin America, as a result of lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the Services portfolio and (ii) a decline in gross margin as a percentage of sales in EA, as a result of the mix of projects in the field.

[0000068505-15-000003:mdna:61]
Selling, General and Administrative Expenses

[0000068505-15-000003:mdna:62]
Selling, general and administrative (“SG&A”) expenses decreased 11% to $1.2 billion, or 20.1% of net sales in 2014, compared to $1.3 billion, or 21.4% of net sales in 2013. The decrease in SG&A expenditures is primarily due to: (i) the reduction of sales support costs by lowering our overall non-quota carrying employee base, (ii) lower pension expenses, (iii) lower incentive compensation expenses, and (iv) reduced costs through the increased use of centralized services.

[0000068505-15-000003:mdna:63]
Research and Development Expenditures

[0000068505-15-000003:mdna:64]
R&D expenditures decreased 11% to $681 million, or 11.6% of net sales in 2014, compared to $761 million, or 12.2% of net sales in 2013. The decrease in R&D expenditures is primarily due to: (i) headcount reductions enacted during previous periods, (ii) lower incentive compensation expenses, (iii) the consolidation of testing processes and lab sites, and (iv) the movement of employees to lower cost work sites.

[0000068505-15-000003:mdna:65]
Other Charges

[0000068505-15-000003:mdna:66]
We recorded net charges of $2.0 billion in Other charges in 2014, compared to net charges of $71 million in 2013. The charges in 2014 included: (i) a $1.9 billion charge related to the settlement of a U.S. pension plan, (ii) $64 million of net reorganization of business charges, and (iii) $8 million of legal settlement charges, partially offset by a $21 million gain on the sale of a building and land. The charges in 2013 included $70 million of charges related to the reorganization of business. The net reorganization of business charges and the settlement of a U.S. pension plan are discussed in further detail in the “Reorganization of Businesses” and "Liquidity and Capital Resources" sections, respectively.

[0000068505-15-000003:mdna:67]
Net Interest Expense

[0000068505-15-000003:mdna:68]
Net interest expense was $126 million in 2014, compared to net interest expense of $113 million in 2013. Net interest expense in 2014 included interest expense of $147 million, partially offset by interest income of $21 million. Net interest expense in 2013 included interest expense of $132 million, partially offset by interest income of $19 million. The increase in interest expense in 2014 compared to 2013 is primarily attributable to an increase in average debt outstanding during 2014 compared to 2013.

[0000068505-15-000003:mdna:69]
Gains on Sales of Investments

[0000068505-15-000003:mdna:70]
Gains on sales of investments were $5 million in 2014, compared to $37 million in 2013. These gains consist of gains on the sale of multiple equity investments in both 2014 and 2013.

[0000068505-15-000003:mdna:71]
Other

[0000068505-15-000003:mdna:72]
Net Other expense was $34 million in 2014, compared to net Other income of $9 million in 2013. The net Other expense in 2014 was primarily comprised of: (i) a $37 million loss on the extinguishment of debt, (ii) a $7 million foreign currency loss, and (iii) $6 million of other non-operating losses, partially offset by $16 million of equity method investment earnings. Net Other income in 2013 was primarily comprised of: (i) $11 million of other non-operating gains and (ii) $10 million of equity method investment earnings, partially offset by: (i) a $9 million foreign currency loss and (ii) investment impairments of $3 million.

[0000068505-15-000003:mdna:73]
Effective Tax Rate

[0000068505-15-000003:mdna:74]
We recorded a $465 million net tax benefit, resulting in a 40% effective tax rate, in 2014 on our pre-tax loss compared to $59 million of net tax benefit, resulting in an effective tax rate of negative 7%, in 2013.  Our effective tax rate in 2014 was favorably impacted by: (i) state tax benefits on the pension settlement loss, (ii) $29 million in tax benefits associated with the net reduction in unrecognized tax benefits and (iii) $19 million in net reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions. These benefits were partially offset by tax expense for the establishment of a $55 million valuation allowance on certain foreign deferred tax assets.

[0000068505-15-000003:mdna:75]
Our negative effective tax rate in 2013 was lower than the U.S. statutory tax rate of 35% due to: (i) $337 million associated with excess foreign tax credits on undistributed foreign earnings, (ii) a $25 million reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions, and (iii) a $9 million tax benefit for R&D tax credits.

[0000068505-15-000003:mdna:76]
29

[0000068505-15-000003:mdna:77]
Our effective tax rate will change from period to period based on non-recurring events, such as the settlement of income tax audits, changes in valuation allowances and the tax impact of significant unusual or extraordinary items, as well as recurring factors including changes in the geographic mix of income and effects of various global income tax strategies.

[0000068505-15-000003:mdna:78]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-15-000003:mdna:79]
We had a net loss from continuing operations attributable to Motorola Solutions, Inc. of $697 million, or $2.84 per diluted share, in 2014, compared to net earnings from continuing operations attributable to Motorola Solutions, Inc. of $933 million, or $3.45 per diluted share, in 2013.

[0000068505-15-000003:mdna:80]
The decrease in net earnings (loss) from continuing operations attributable to Motorola Solutions, Inc. in 2014, as compared to 2013, was primarily driven by: (i) a $1.9 billion charge related to the settlement of a U.S. pension plan and (ii) a $278 million decrease in gross margin primarily due to sales declines and a change in sales mix, partially offset by: (i) a $146 million decrease in SG&A and (ii) an $80 million decrease in R&D.  The decrease in earnings (loss) per diluted share from continuing operations was driven by lower net earnings, partially offset by a reduction in shares outstanding as a result of our share repurchase program.

[0000068505-15-000003:mdna:81]
Earnings from Discontinued Operations

[0000068505-15-000003:mdna:82]
In 2014, we had $2.0 billion in earnings from discontinued operations, net of tax, or $8.13 per diluted share, compared to $166 million of earnings from discontinued operations, net of tax, or $0.61 per diluted share, in 2013. The earnings from discontinued operations in both 2014 and 2013 were related to the Enterprise business. The increase in 2014, as compared to 2013 is primarily related to the gain from the sale of the Enterprise business of $1.9 billion.

[0000068505-15-000003:mdna:83]
Results of Operations—2013 Compared to 2012

[0000068505-15-000003:mdna:84]
Net Sales

[0000068505-15-000003:mdna:85]
Net sales were $6.2 billion in 2013 compared to $6.3 billion in 2012. The slight decrease in net sales reflects a $127 million, or 3%, decrease in the Products segment driven by declines in: (i) North America, reflecting lower devices sales, (ii) APME, as a result of lower devices and systems sales, and (iii) Latin America, reflecting lower Systems sales, partially offset by double-digit growth in EA as a result of higher systems sales. The decrease in net sales was offset by an $85 million, or 4%, increase in net sales relating to the Services segment driven by increases in: (i) North America, as a result of higher net sales in Lifecycle Support services and Integration services and (ii) EA, reflecting higher Integration services sales, partially offset by a decline in APME as a result of lower Integration and Managed services sales.

[0000068505-15-000003:mdna:86]
Gross Margin

[0000068505-15-000003:mdna:87]
Gross margin was $3.1 billion, or 49.9% of net sales in 2013, compared to $3.2 billion, or 50.9% of net sales, in 2012. The decrease in gross margin percentage is driven primarily by: (i) a decline in gross margin as a percentage of sales in North America, as a result of sales mix between the Products and Services segments, (ii) a decline in gross margin as a percentage of sales in APME, relating to lower gross margin as a percentage of sales in devices and systems, and (iii) a decline in gross margin as a percentage of sales in EA, as a result of lower gross margin as a percentage of sales in Integration services.

[0000068505-15-000003:mdna:88]
Selling, General and Administrative Expenses

[0000068505-15-000003:mdna:89]
SG&A expenses decreased 10% to $1.3 billion, or 21.4% of net sales in 2013, compared to $1.5 billion, or 23.5% of net sales in 2012. The decrease in SG&A is primarily driven by: (i) a number of structural cost improvements, including defined benefit expenses, and (ii) decreases in variable compensation expenses.

[0000068505-15-000003:mdna:90]
Research and Development Expenditures

[0000068505-15-000003:mdna:91]
R&D expenditures decreased 4% to $761 million, or 12.2% of net sales in 2013, compared to $790 million, or 12.6% of net sales in 2012.  The decrease in R&D expenditures is primarily due to: (i) reduced compensation expenses and (ii) reduced spending in certain development programs, such as iDEN.

[0000068505-15-000003:mdna:92]
Other Charges

[0000068505-15-000003:mdna:93]
We recorded net charges of $71 million in Other charges in 2013, compared to net charges of $12 million in 2012. The charges in 2013 included: (i) $70 million of net reorganization of business charges and (ii) $1 million of charges relating to amortization of intangibles. The charges in 2012 included: (i) $27 million of charges relating to reorganization of business charges and (ii) $1 million of charges relating to amortization of intangibles, partially offset by $16 million of income related to a legal matter. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-15-000003:mdna:94]
Net Interest Expense

[0000068505-15-000003:mdna:95]
Net interest expense was $113 million in 2013, compared to net interest expense of $66 million in 2012. Net interest expense in 2013 included interest expense of $132 million, partially offset by interest income of $19 million. Net interest expense in 2012 included interest expense of $108 million, partially offset by interest income of $42 million. The increase in net interest expense in 2013 compared to 2012 is primarily attributable to: (i) higher interest expense driven by an increase in average debt outstanding and $5 million of income tax-related interest charges and (ii) a decrease in interest income due to lower average cash and cash equivalents during 2013 compared to 2012.

[0000068505-15-000003:mdna:96]
Gains on Sales of Investments

[0000068505-15-000003:mdna:97]
Gains on sales of investments and businesses were $37 million in 2013, compared to $26 million in 2012. These gains consist of gains on the sale of multiple equity investments in both 2013 and 2012.

[0000068505-15-000003:mdna:98]
Other

[0000068505-15-000003:mdna:99]
Net Other income was $9 million in 2013, compared to net Other income of $1 million in 2012. The net Other income in 2013 was primarily comprised of: (i) $10 million of equity method investment earnings and (ii) $11 million of other non-operating gains, partially offset by: (i) a $9 million loss on foreign currency and (ii) investment impairments of $3 million.  The net Other income in 2012 was primarily comprised of: (i) $3 million of equity method investment earnings and (ii) $9 million of other non-operating gains, partially offset by: (i) $6 million loss from the extinguishment of debt and (ii) investment impairments of $4 million.

[0000068505-15-000003:mdna:100]
Effective Tax Rate

[0000068505-15-000003:mdna:101]
We recorded $59 million of net tax benefit in 2013, resulting in a negative effective tax rate of 7%, compared to $211 million of net tax expense in 2012, resulting in an effective tax rate of 24%. Our effective tax rate in 2013 was favorably impacted by: (i) $337 million of net tax benefit, or $1.25 of diluted earnings per share from continuing operations, associated with excess foreign tax credits, (ii) a $25 million reduction in our deferred tax liability for undistributed foreign earnings primarily due to our assertion that certain earnings are now permanently reinvested, and (iii) a $9 million tax benefit for prior year R&D tax credits.  The tax benefit associated with the excess foreign tax credits relates to the earnings of certain non-U.S. subsidiaries reorganized under our holding company structure implemented during 2013. Our effective tax rate in 2013 was unfavorably impacted by a $20 million tax charge associated with the liquidation of the Sigma Fund, as discussed within "Liquidity and Capital Resources."

[0000068505-15-000003:mdna:102]
Our effective tax rate in 2012 was lower than the U.S. statutory tax rate of 35% primarily due to: (i) a $60 million tax benefit related to the reversal of a significant portion of the valuation allowance established on certain foreign deferred tax assets and (ii) a $13 million reduction in unrecognized tax benefits for facts that then indicated the extent to which certain tax positions were more-likely-than-not of being sustained.

[0000068505-15-000003:mdna:103]
Earnings from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-15-000003:mdna:104]
We had net earnings from continuing operations attributable to Motorola Solutions, Inc. of $933 million, or $3.45 per diluted share, in 2013, compared to $670 million, or $2.25 per diluted share, in 2012.

[0000068505-15-000003:mdna:105]
The increase in net earnings from continuing operations attributable to Motorola Solutions, Inc. in 2013, as compared to 2012, was primarily driven by: (i) a lower effective tax rate due to the $337 million net tax benefit associated with foreign tax credits and (ii) decreased defined benefit expenses of over $100 million, partially offset by: (i) a $85 million decrease in gross margin, (ii) a $43 million increase in reorganization of business charges, and (iii) a $47 million increase in net interest expense.  The increase in earnings per diluted share from continuing operations was driven by higher net earnings as well as the reduction in shares outstanding as a result of our share repurchase program.

[0000068505-15-000003:mdna:106]
Earnings from Discontinued Operations

[0000068505-15-000003:mdna:107]
In 2013, we had $166 million in earnings from discontinued operations, net of tax, or $0.61 per diluted share, compared to $211 million of earnings from discontinued operations, net of tax, or $0.71 per diluted share, in 2012. The earnings from discontinued operations in 2013 and 2012 were primarily from the Enterprise business. The decrease from 2012 to 2013 is primarily related to an increase in amortization of intangible assets, as a result of the purchase of Psion at the end of 2012.

[0000068505-15-000003:mdna:108]
Segment Information

[0000068505-15-000003:mdna:109]
The following commentary should be read in conjunction with the financial results of each operating business segment as detailed in Note 12, “Information by Segment and Geographic Region,” to our consolidated financial statements. Net sales and operating results for our two segments for 2014, 2013, and 2012 are presented below.

[0000068505-15-000003:mdna:110]
Products Segment

[0000068505-15-000003:mdna:111]
In 2014, the Products segment’s net sales represented 65% of our consolidated net sales, compared to 66% in 2013 and 68% in 2012.

[0000068505-15-000003:mdna:112]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2014 |  | 2013 |  | 2012 |  | 2014—2013 |  | 2013—2012 |
| Segment net sales | $ | 3,807 |  |  | $ | 4,109 |  |  | $ | 4,236 |  |  | (7 | )% |  | (3 | )% |
| Operating earnings (loss) | (667 | ) |  | 639 |  |  | 656 |  |  | (204 | )% |  | (3 | )% |

[0000068505-15-000003:mdna:113]
Segment Results—2014 Compared to 2013

[0000068505-15-000003:mdna:114]
In 2014, the segment’s net sales were $3.8 billion, a 7% decrease compared to 2013 reflecting a decrease in: (i) devices sales in North America, Latin America, and APME, partially offset by an increase in devices sales within EA and (ii) system sales in North America, APME and EA, partially offset by an increase in system sales in Latin America. On a geographic basis, net sales declined in North America, Latin America and APME, and increased in EA in 2014 compared to 2013. The fourth quarter of 2014 was positively impacted by a return to growth in the North America region, as compared to the fourth quarter of 2013, and

[0000068505-15-000003:mdna:115]
reflected increased order activity and faster-than-expected conversion of certain orders. The segment’s backlog was $1.2 billion at December 31, 2014 and $1.1 billion at December 31, 2013.

[0000068505-15-000003:mdna:116]
The segment had an operating loss of $667 million in 2014, compared to operating earnings of $639 million in 2013 driven by an allocation of $1.3 billion of expense related to the settlement of a U.S pension plan. As a percentage of net sales in 2014 compared to 2013, gross margin decreased, SG&A expenditures decreased, R&D expenditures decreased, and Other charges increased. The decrease in operating earnings was primarily driven by: (i) an increase in Other charges, reflecting $1.3 billion of allocated charges related to the settlement of a U.S. pension plan and (ii) a decrease in net sales, resulting in lower gross margin, partially offset by lower SG&A and R&D expenditures as a result of cost savings actions taken and lower variable compensation expenses.

[0000068505-15-000003:mdna:117]
Segment Results—2013 Compared to 2012

[0000068505-15-000003:mdna:118]
In 2013, the segment’s net sales were $4.1 billion, a 3% decrease compared to 2012 reflecting a decrease in: (i) devices sales in North America and APME, partially offset by an increase in devices sales within EA and Latin America and (ii) system sales in Latin America and APME, partially offset by an increase within North America and EA. On a geographic basis, net sales declined in North America, Latin America and APME, and increased in EA in 2013 compared to 2012. The segment’s backlog was $1.1 billion at December 31, 2013 and $1.6 billion at December 31, 2012.

[0000068505-15-000003:mdna:119]
The segment had operating earnings of $639 million in 2013, compared to operating earnings of $656 million in 2012. As a percentage of net sales in 2013 as compared to 2012, gross margin was down slightly, SG&A, and R&D expenditures decreased. The decrease in operating earnings was primarily due to an increase in Other charges as a result of increased reorganization of business charges in 2013 as compared to 2012, partially offset by a decrease in SG&A expenses as a result of lower variable compensation expenses and reduced defined benefit plan expenses.

[0000068505-15-000003:mdna:120]
Services Segment

[0000068505-15-000003:mdna:121]
In 2014, the Services segment’s net sales represented 35% of our consolidated net sales, compared to 34% in 2013 and 32% in 2012.

[0000068505-15-000003:mdna:122]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2014 |  | 2013 |  | 2012 |  | 2014—2013 |  | 2013—2012 |
| Segment net sales | $ | 2,074 |  |  | $ | 2,118 |  |  | $ | 2,033 |  |  | (2 | )% |  | 4 | % |
| Operating earnings (loss) | (339 | ) |  | 308 |  |  | 264 |  |  | (210 | )% |  | 17 | % |

[0000068505-15-000003:mdna:123]
Segment Results—2014 Compared to 2013

[0000068505-15-000003:mdna:124]
In 2014, the segment’s net sales were $2.1 billion, a 2% decrease compared to 2013 reflecting a decrease in sales of: (i) iDEN services in North America and Latin America and (iii) Lifecycle Support services in APME and EA, partially offset by an increase in Managed services sales in APME and EA. On a geographic basis, net sales for 2014 declined in North America and APME, increased in EA, and remained relatively constant in Latin America, compared to 2013. Overall, Integration services remained flat due to the timing of certain projects in 2014, as compared to 2013. Lifecycle Support services decreased slightly; however, demand increased in the fourth quarter of 2014 for our software maintenance and hardware upgrade offerings. Managed services grew modestly as increasing complexity and the need for enhanced capabilities to support software-centric, information technology-based networks continued to drive demand in all regions. The segment’s backlog was $4.6 billion at December 31, 2014, compared to $4.3 billion at December 31, 2013.

[0000068505-15-000003:mdna:125]
The segment had an operating loss of $339 million in 2014, compared to operating earnings of $308 million in 2013.   As a percentage of net sales in 2014 as compared to 2013, gross margin, SG&A expenditures, and R&D expenditures decreased, and Other charges increased. The decrease in operating earnings was primarily driven by: (i) an increase in Other charges, reflecting $584 million of allocated charges related to the settlement of a U.S. pension plan and (ii) a decrease in net sales, resulting in lower gross margin, partially offset by lower SG&A and R&D expenditures as a result of cost savings actions taken and lower variable compensation expenses.

[0000068505-15-000003:mdna:126]
Segment Results—2013 Compared to 2012

[0000068505-15-000003:mdna:127]
In 2013, the segment’s net sales were $2.1 billion, a 4% increase compared to 2012 reflecting an increase in sales of: (i) Integration services in North America and EA, and (ii) Lifecycle Support services in North America, partially offset by a decrease in sales of Managed services in APME. On a geographic basis, net sales for 2013 increased in North America, EA and Latin America and decreased in APME, compared to 2012. The segment’s backlog was $4.3 billion at December 31, 2013, compared to $3.4 billion at December 31, 2012.

[0000068505-15-000003:mdna:128]
The segment had operating earnings of $308 million in 2013, compared to operating earnings of $264 million in 2012.   As a percentage of net sales in 2013 as compared to 2012, gross margin was slightly higher and SG&A and R&D expenditures decreased. The increase in operating earnings was primarily due to: (i) an increase in gross margin as a result of higher margin from Integration services and (ii) decreases in SG&A expenses as a result of lower variable compensation expenses and reduced defined benefit plan expenses, partially offset by higher Other charges as a result of higher reorganization of business charges.

[0000068505-15-000003:mdna:129]
Reorganization of Businesses

[0000068505-15-000003:mdna:130]
During 2014 we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. In 2014, we recorded net reorganization of business charges of $96 million relating to the separation of 1,200 employees, of which 900 were indirect employees and 300 were direct employees. Of these charges, $23 million related to discontinued operations. The remaining $73 million of charges in earnings (loss) from continuing operations included $9 million recorded to Cost of sales and $64 million recorded to Other charges. Included in the aggregate $73 million are charges of: (i) $67 million for employee separation costs and (ii) $7 million for exit costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-15-000003:mdna:131]
We realized cost-saving benefits of approximately $26 million in 2014 from the plans that were initiated during 2014, primarily in operating expenses. Beyond 2014, we expect the reorganization plans initiated during 2014 to provide annualized cost savings of approximately $90 million, consisting of $12 million of savings in Cost of sales, and $78 million of savings in operating expenses. These cost savings include reduced payroll and other operating expenses; however, as we continue to outsource manufacturing and other functions, some of these cost savings may not be realizable as variable outsourced manufacturing and other activities increase.

[0000068505-15-000003:mdna:132]
During 2013, we recorded net reorganization of business charges of $133 million relating to the separation of 2,200 employees, of which 1,400 were indirect employees and 800 were direct employees. Of these charges, $47 million related to discontinued operations. The remaining $86 million of charges in earnings from continuing operations included $16 million recorded to Cost of sales and $70 million recorded to Other charges. Included in the aggregate $86 million are charges of: (i) $94 million for employee separation costs and (ii) $2 million related to charges for exit costs, partially offset by $10 million for reversals of accruals no longer needed.

[0000068505-15-000003:mdna:133]
During 2012, we recorded net reorganization of business charges of $50 million relating to the separation of 1,000 employees, of which 700 were indirect employees and 300 were direct employees. Of these charges, $17 million related to discontinued operations. The remaining $33 million of charges in earnings from continuing operations included $6 million recorded to Cost of sales and $27 million recorded to Other charges. Included in the aggregate $33 million are charges of: (i) $35 million for employee separation costs and (ii) $5 million for building impairments, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-15-000003:mdna:134]
The following table displays the net charges incurred by business segment:

[0000068505-15-000003:mdna:135]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Products | $ | 48 |  |  | $ | 57 |  |  | $ | 22 |  |
| Services | 25 |  |  | 29 |  |  | 11 |  |
|  | $ | 73 |  |  | $ | 86 |  |  | $ | 33 |  |

[0000068505-15-000003:mdna:136]
Cash payments for exit costs and employee separations in connection with these reorganization plans were $148 million,$59 million, and $55 million in 2014, 2013, and 2012, respectively. The cash payments included $50 million in 2014, $20 million in 2013, and $20 million in 2012 related to employees of discontinued operations. The $57 million reorganization of businesses accrual remaining at December 31, 2014, relates entirely to employee separation costs that are expected to be paid in 2015. As part of the sale of its Enterprise business, the Company retained the reorganization of business charges accruals and the responsibility to pay affected employees for those charges incurred prior to the closing of the sale of the Enterprise business.

[0000068505-15-000003:mdna:137]
Liquidity and Capital Resources

[0000068505-15-000003:mdna:138]
At December 31, 2014, our cash and cash equivalents (which are highly-liquid investments purchased with an original maturity of three months or less) were $4.0 billion, an increase of $729 million, compared to $3.2 billion at December 31, 2013. The increase in cash and cash equivalents is primarily due to: (i) $3.4 billion of cash generated from the sale of the Enterprise business and (ii) the issuance of $1.4 billion of Senior Notes, partially offset by: (i) the return of $2.9 billion of capital to shareholders through share repurchases and dividends paid during 2014, (ii) $685 million of cash used for operating activity, including pension contributions of $1.3 billion, and (iii) $465 million of debt repayment. At December 31, 2014, $3.3 billion of the $4.0 billion cash and cash equivalents balance was held in the U.S. and $647 million was held in other countries. Subsequent to December 31, 2014, we transferred $423 million of cash proceeds from the sale of the Enterprise business from the U.S to our foreign subsidiaries. At both December 31, 2014 and December 31, 2013, restricted cash was $63 million.

[0000068505-15-000003:mdna:139]
We continue to analyze and review various repatriation strategies to efficiently repatriate cash. In 2014, we repatriated approximately $570 million in cash to the U.S. from international jurisdictions. At December 31, 2014, we had approximately $400 million of foreign earnings that are not permanently reinvested and may be repatriated without an additional tax charge to our consolidated statements of operations, given the U.S. federal and foreign income tax accrued on the undistributed earnings and the utilization of available foreign tax credits.  Undistributed earnings that we intend to reinvest indefinitely, and for which no income taxes have been provided, aggregate to $1.5 billion at December 31, 2014. We currently have no plans to repatriate the foreign earnings permanently reinvested.  If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-15-000003:mdna:140]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy.  While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact,

[0000068505-15-000003:mdna:141]
33

[0000068505-15-000003:mdna:142]
repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-15-000003:mdna:143]
Operating Activities

[0000068505-15-000003:mdna:144]
Cash used for operating activities from continuing operations in 2014 was $685 million, compared to cash provided by operating activities from continuing operations of $555 million in 2013 and $674 million in 2012. Operating cash flows in 2014, as compared to 2013, were negatively impacted by contributions to our pension plans of $1.3 billion, an increase of $1.1 billion compared to 2013, primarily related to a U.S. pension plan settlement. Operating cash flows in 2013, as compared to 2012, were negatively impacted by: (i) higher cash tax payments, including Indian tax deposits of $43 million, and (ii) lower collections and sales of long-term receivables, including receivables related to the Networks divestiture that were retained after the sale and sold or collected in 2012, partially offset by approximately $190 million of lower defined benefit plan contributions in 2012 as compared to 2013.

[0000068505-15-000003:mdna:145]
In September 2014, we entered into a Definitive Purchase Agreement (“the Agreement”) by and among Motorola Solutions, The Prudential Insurance Company of America (“PICA”), Prudential Financial, Inc. and State Street Bank and Trust Company, as Independent Fiduciary of one of our U.S. Pension Plans (the “Regular Pension Plan”, as defined in Note 7 to our consolidated financial statements).  Under the Agreement, the Regular Pension Plan planned to purchase from PICA a group annuity contract that requires PICA to pay and administer certain future annuity payments to approximately 30,000 of our retirees.  In anticipation of the Agreement, we established a new pension plan with substantially the same terms as the Regular Pension Plan (the “New Plan") to accommodate our remaining active employees and non-retirees.  On December 3, 2014, the Regular Pension Plan closed its planned purchase of a group annuity from PICA.  The total premium paid by the Regular Pension Plan to PICA was the transfer of approximately $3.2 billion in plan assets, and is subject to customary post-closing true-ups. The Regular Pension Plan was then terminated.

[0000068505-15-000003:mdna:146]
Also in September 2014, we announced that the New Plan was offering a maximum of $1.0 billion of lump-sum distributions to certain participants who had accrued a pension benefit, had left the Company prior to June 30, 2014, and had not yet started receiving pension benefit payments (“the Eligible Participants”).  The aggregate amount of lump-sum elections accepted by Eligible Participants exceeded the maximum of $1.0 billion, and $1.0 billion was paid from plan assets in December 2014.

[0000068505-15-000003:mdna:147]
We contributed $1.1 billion, $150 million, and $340 million to our U.S. pension plans during 2014, 2013, and 2012, respectively. In addition, we contributed $237 million, $32 million, and $31 million to our Non-U.S. Pension Plans during 2014, 2013, and 2012, respectively. We expect to make no cash contributions to our U.S. Pension Benefit Plans and approximately $12 million to our Non-U.S. Pension Benefit Plans in 2015.

[0000068505-15-000003:mdna:148]
Investing Activities

[0000068505-15-000003:mdna:149]
Net cash provided by investing activities from continuing operations was $3.2 billion in 2014, compared to $2.0 billion in 2013 and $1.0 billion in 2012. The $1.2 billion increase in net cash provided by investing activities from 2013 to 2014 was primarily due to a $3.3 billion increase of proceeds from sales of investments and businesses, related to the sale of our Enterprise business, partially offset by a $2.1 billion decrease in proceeds from sales of Sigma Fund investments, which we exited in the fourth quarter of 2013. The $1.1 billion increase in net cash provided by investing activities from 2012 to 2013 was primarily due to a $1.1 billion increase in proceeds from net sales of Sigma Fund investments.

[0000068505-15-000003:mdna:150]
Sigma Fund:  Prior to December 2013, we invested most of our U.S. dollar-denominated cash in a fund (the “Sigma Fund”) that was managed by independent investment management firms under specific investment guidelines restricting the type of investments held and their time to maturity. In December 2013, we completed the liquidation of the Sigma Fund and migrated the international U.S dollar-denominated cash to a U.S. dollar cash pool invested primarily in U.S. dollar prime money market funds. The creation of the international cash pool enhances our flexibility to repatriate excess overseas cash and fund global operations.  These money market funds are classified as Cash and cash equivalents within the consolidated balance sheets as of December 31, 2014 and 2013. We had net proceeds of $2.1 billion in 2013 compared to $1.1 billion in net proceeds of Sigma Fund investments in 2012.

[0000068505-15-000003:mdna:151]
Acquisitions and Investments:  We used cash of $47 million for acquisitions and new investment activities in 2014, compared to $57 million in 2013 and receiving cash of $83 million in 2012. The cash used in 2014 was for the acquisition of an equipment provider for $22 million and a number of equity investments. The cash used in 2013 was for the acquisition of a communications software provider in push-to-talk-over-broadband applications for a purchase price, net of cash acquired, of $36 million, and other small strategic equity investments.  The cash received in 2012 was primarily for the agreement with Nokia Siemens Networks ("NSN") to take over responsibility to implement Norway´s TETRA public safety network, offset by other small strategic investments.

[0000068505-15-000003:mdna:152]
In accordance with the Acquisition Agreement, the sale of our Enterprise business is subject to certain customary purchase price adjustments.  Among those adjustments for which we expect reimbursement is the refund of $49 million of cash from Zebra for legal entities that had cash balances which were effected through a stock sale.  The $49 million, and other purchase price adjustments, are expected to be settled in 2015.

[0000068505-15-000003:mdna:153]
Capital Expenditures:  Capital expenditures were $181 million in 2014, compared to $169 million in 2013, and $170 million in 2012.  Capital spending in 2014, 2013, and 2012 was primarily comprised of: (i) updates to our information technology infrastructure, (ii) network build out expenditures related to our Services segment and (iii) facility renovations. The increase in

[0000068505-15-000003:mdna:154]
capital spending in 2014, as compared to 2013 and 2012, was primarily driven by an increase in revenue-generating network build out expenditures.

[0000068505-15-000003:mdna:155]
Sales of Property, Plant, and Equipment:  We had $33 million of proceeds related to the sale of property, plant, and equipment in 2014, compared to $66 million in 2013 and $40 million in 2012.  The proceeds in all periods were primarily comprised of sales of buildings and land.

[0000068505-15-000003:mdna:156]
Sales of Investments and Businesses:  We received $3.4 billion of proceeds in 2014 compared to $61 million in 2013 and disbursements of $58 million in 2012. The $3.4 billion of proceeds received in 2014 were primarily comprised of proceeds from the sale of the Enterprise business. The $61 million of cash received in 2013 was primarily comprised of proceeds from sales of equity investments. The $58 million in disbursements in 2012 were primarily comprised of payments to NSN related to the purchase price adjustment from the sale of the Networks business completed in 2011, partially offset by proceeds from sales of certain equity investments.

[0000068505-15-000003:mdna:157]
Financing Activities

[0000068505-15-000003:mdna:158]
Net cash used for financing activities was $1.7 billion in 2014 compared to $842 million in 2013 and $2.1 billion in 2012.  Cash used for financing activities in 2014 was primarily comprised of: (i) $2.5 billion used for purchases of common stock under our share repurchase program, (ii) $465 million of cash used for the repayment of debt, and (iii) $318 million of cash used for the payment of dividends, partially offset by: (i) $1.4 billion of net proceeds from the issuance of debt, (ii) $135 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans, and (iii) $93 million of distributions received from discontinued operations.

[0000068505-15-000003:mdna:159]
Cash used for financing activities in 2013 was primarily comprised of: (i) $1.7 billion used for purchases of our common stock under our share repurchase program and (ii) $292 million of cash used for the payment of dividends, partially offset by: (i) $593 million of net proceeds from the issuance of debt, (ii) $365 million of distributions received from discontinued operations, and (iii) $165 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-15-000003:mdna:160]
Cash used for financing activities in 2012 was primarily comprised of: (i) $2.4 billion used for purchases of our common stock under our share repurchase program, (ii) $413 million of cash used for the repayment of debt, and (iii) $270 million of cash used for the payment of dividends, partially offset by: (i) $747 million of net proceeds from the issuance of debt, (ii) $217 million of distributions received from discontinued operations, and (iii) $133 million of net cash received from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-15-000003:mdna:161]
Current and Long-Term Debt:  At both December 31, 2014 and 2013, our current portion of long-term debt was $4 million.  We had outstanding long-term debt of $3.4 billion and $2.5 billion at December 31, 2014 and December 31, 2013, respectively.

[0000068505-15-000003:mdna:162]
During the year ended December 31, 2014, we redeemed $400 million aggregate principal amount outstanding of our 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, we recognized a loss of $37 million related to the redemption within Other income (expense) in the consolidated statements of operations. In addition, we issued an aggregate face principal amount of $1.4 billion including: (i) $600 million of 4.000% Senior Notes due 2024, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior Notes due 2021, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior notes due 2044, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $394 million.

[0000068505-15-000003:mdna:163]
During 2013, we issued an aggregate face principal amount of $600 million of 3.50% Senior Notes due March 1, 2023, recognizing net proceeds of $588 million, after debt discount and issuance costs.

[0000068505-15-000003:mdna:164]
During 2012, we issued an aggregate face principal amount of $750 million of 3.75% Senior Notes due May 15, 2022 (the “2022 Senior Notes”).  We also redeemed $400 million aggregate principal amount outstanding of our 5.375% Senior Notes due November 2012 (the “2012 Senior Notes”).  All of the 2012 Senior Notes were redeemed for an aggregate purchase price of approximately $408 million.  This debt was repurchased with a portion of the proceeds from the issuance of the 2022 Senior Notes.

[0000068505-15-000003:mdna:165]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. We believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty or volatility in the capital markets may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-15-000003:mdna:166]
We may, from time to time, seek to retire certain of our outstanding debt through open market cash purchases, privately-negotiated transactions or otherwise. Such repurchases, if any, will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors.

[0000068505-15-000003:mdna:167]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, and November 4, 2014, the Board of Directors has authorized an aggregate share repurchase amount of up to $12.0 billion of our outstanding shares of common stock (the “share repurchase program”).  The share repurchase program does not have an expiration date.  As of December 31, 2014, we have used approximately $7.8 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $4.2 billion of authority available for future repurchases.

[0000068505-15-000003:mdna:168]
We paid an aggregate of $2.5 billion during 2014, including transaction costs, to repurchase approximately 39.4 million shares at an average price of $64.63 per share. During 2013, we paid an aggregate of $1.7 billion, including transaction costs, to

[0000068505-15-000003:mdna:169]
35

[0000068505-15-000003:mdna:170]
repurchase approximately 28.6 million shares at an average price of $59.30 per share. During 2012, we paid an aggregate of $2.4 billion, including transaction costs, to repurchase approximately 49.6 million shares at an average price of $49.14 per share.  All repurchased shares have been retired.

[0000068505-15-000003:mdna:171]
Payment of Dividends:  We paid cash dividends to holders of our common stock of $318 million in 2014, $292 million in 2013, and $270 million in 2012.

[0000068505-15-000003:mdna:172]
Credit Facilities

[0000068505-15-000003:mdna:173]
As of December 31, 2014, we had a $2.1 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019 which replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”). We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We are no longer subject to a minimum interest coverage covenant under the new facility. We were in compliance with our financial covenants as of December 31, 2014. We did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the twelve months ended December 31, 2014.

[0000068505-15-000003:mdna:174]
As of December 31, 2014, we had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of December 31, 2014.

[0000068505-15-000003:mdna:175]
Contractual Obligations and Other Purchase Commitments

[0000068505-15-000003:mdna:176]
Summarized in the table below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2014.

[0000068505-15-000003:mdna:177]
|  | Payments Due by Period |
| (in millions) | Total |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations | $ | 3,456 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 3,425 |  |
| Lease obligations | 454 |  |  | 68 |  |  | 56 |  |  | 45 |  |  | 35 |  |  | 33 |  |  | — |  |  | 217 |  |
| Purchase obligations* | 40 |  |  | 23 |  |  | 14 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Tax obligations | 96 |  |  | 25 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 71 |  |  |  |  |
| Total contractual obligations | $ | 4,046 |  |  | $ | 120 |  |  | $ | 75 |  |  | $ | 53 |  |  | $ | 41 |  |  | $ | 44 |  |  | $ | 71 |  |  | $ | 3,642 |  |

[0000068505-15-000003:mdna:178]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-15-000003:mdna:179]
Lease Obligations:  We lease certain office, factory and warehouse space, land, information technology and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations, net of minimum sublease rentals, totaled $454 million.  Rental expense, net of sublease income, was $62 million in 2014, $51 million in 2013, and $45 million in 2012.

[0000068505-15-000003:mdna:180]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements.  In addition, we have entered into software license agreements which are firm commitments and are not cancelable.  As of December 31, 2014, we had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2017. The total payments expected to be made under these agreements are $40 million, of which $38 million relate to take or pay obligations from arrangements with suppliers for the sourcing of inventory supplies and materials and $2 million relate to information technology software and services arrangements. We do not anticipate the cancellation of any of our take or pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-15-000003:mdna:181]
Tax Obligations:  We have approximately $96 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $50 million tax charge to a $50 million tax benefit, with cash payments not expected to exceed $25 million.

[0000068505-15-000003:mdna:182]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take or pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-15-000003:mdna:183]
We outsource certain corporate functions, such as benefit administration and information technology-related services, the longest of which is expected to expire in 2019. Our remaining payments under these contracts are approximately $319 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in a penalty

[0000068505-15-000003:mdna:184]
substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-15-000003:mdna:185]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance/bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. At December 31, 2014, outstanding Performance Bonds totaled approximately $1.6 billion, compared to $1.8 billion at December 31, 2013. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-15-000003:mdna:186]
Off-Balance Sheet Arrangements:  Under the definition contained in Item 303(a)(4)(ii) of Regulation S-K, we do not have any off-balance sheet arrangements.

[0000068505-15-000003:mdna:187]
Long-term Customer Financing Commitments

[0000068505-15-000003:mdna:188]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $293 million at December 31, 2014, compared to $50 million at December 31, 2013.

[0000068505-15-000003:mdna:189]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $31 million at December 31, 2014, compared to net non-current long-term receivables of $1 million (net of allowances for losses of $14 million) at December 31, 2013. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 13%.

[0000068505-15-000003:mdna:190]
Sales of Receivables

[0000068505-15-000003:mdna:191]
From time to time, we sell accounts receivable and long-term receivables to third-parties under one-time arrangements while others have been sold to third-parties. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-15-000003:mdna:192]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2014, 2013, and 2012:

[0000068505-15-000003:mdna:193]
| Years ended December 31 | 2014 |  | 2013 |  | 2012 |
| Accounts receivable sales proceeds | $ | 50 |  |  | $ | 14 |  |  | $ | 12 |  |
| Long-term receivables sales proceeds | 124 |  |  | 131 |  |  | 178 |  |
| Total proceeds from receivable sales | $ | 174 |  |  | $ | 145 |  |  | $ | 190 |  |

[0000068505-15-000003:mdna:194]
At December 31, 2014, the Company had retained servicing obligations for $496 million of long-term receivables, compared to $434 million of long-term receivables at December 31, 2013.  Servicing obligations are limited to collection activities for sold accounts receivables and long-term receivables.

[0000068505-15-000003:mdna:195]
Adequate Internal Funding Resources

[0000068505-15-000003:mdna:196]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S. and the ability to repatriate funds from foreign jurisdictions.

[0000068505-15-000003:mdna:197]
Other Contingencies

[0000068505-15-000003:mdna:198]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, our businesses may enter into contracts with customers pursuant to which the damages that could be claimed by the other party for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damage provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a damage claim by a counterparty to one of these contracts could result in expenses to us that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-15-000003:mdna:199]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims.  In some instances we may have recourse against third-

[0000068505-15-000003:mdna:200]
37

[0000068505-15-000003:mdna:201]
parties for certain payments made by us.  Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 18 months, and for amounts not in excess of a percentage of the contract value.

[0000068505-15-000003:mdna:202]
Legal Matters:  We are a defendant in various lawsuits, claims and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on our consolidated financial position, liquidity or results of operations in the periods in which the matters are ultimately resolved.

[0000068505-15-000003:mdna:203]
Significant Accounting Policies

[0000068505-15-000003:mdna:204]
Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-15-000003:mdna:205]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-15-000003:mdna:206]
Revenue Recognition

[0000068505-15-000003:mdna:207]
Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. We enter into revenue arrangements that may consist of multiple deliverables of our products and services due to the needs of our customers. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. We recognize revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  We recognize revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) standalone sales of software products or software upgrades, (ii) standalone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-15-000003:mdna:208]
Products

[0000068505-15-000003:mdna:209]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. We base our estimates of these allowances on historical experience taking into consideration the type of products sold, the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, we defer revenue until the incentive has been finalized with the customer.  We include shipping charges billed to customers in net revenue, and include the related shipping costs in cost of sales.

[0000068505-15-000003:mdna:210]
We sell software and equipment obtained from other companies.  We establish our own pricing and retain related inventory risk, are the primary obligor in sales transactions with customers, and assume the credit risk for amounts billed to customers. Accordingly, we generally recognize revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-15-000003:mdna:211]
Long-Term Contracts

[0000068505-15-000003:mdna:212]
For long-term contracts that involve customization of equipment and/or software, we generally recognize revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). The components of estimated costs to complete a contract and management’s process for reviewing Estimated Costs at Completion and progress toward completion is discussed further below.  Contracts may be combined or segmented in accordance with the applicable criteria under contract accounting principles.  In certain instances, when revenues or costs associated with long-term contracts cannot be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained.

[0000068505-15-000003:mdna:213]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs.  Due to the nature of the work required to be performed under many of our long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables.  We have a standard and disciplined quarterly Estimated Costs at Completion process in which management reviews the progress and performance of open contracts. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity

[0000068505-15-000003:mdna:214]
of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. These adjustments may result from positive project performance, and may result in an increase in operating income during the performance of individual contracts. Likewise, these adjustments may result in a decrease in operating income if Estimated Costs at Completion increase. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on Operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2014, 2013, and 2012.  When estimates of total costs to be incurred on a contract exceed total estimates of revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-15-000003:mdna:215]
Hardware and Software Services Support

[0000068505-15-000003:mdna:216]
Revenue under equipment and software support and maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term as services are performed.

[0000068505-15-000003:mdna:217]
Software and Licenses

[0000068505-15-000003:mdna:218]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other relevant revenue recognition criteria are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period that the licensee uses the license.

[0000068505-15-000003:mdna:219]
Multiple-Element Arrangements

[0000068505-15-000003:mdna:220]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements that include products containing software that functions together with the equipment to deliver its essential functionality, undelivered software elements that relate to the product's essential software, and undelivered non-software services, deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in our control.

[0000068505-15-000003:mdna:221]
In these arrangements, we allocate revenue to all deliverables based on their relative selling prices.  We use the following hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of selling price (“ESP”).

[0000068505-15-000003:mdna:222]
We determine VSOE based on our normal pricing and discounting practices for the specific product or service when that same product or service is sold separately. In determining VSOE, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate.

[0000068505-15-000003:mdna:223]
When VSOE does not exist, we attempt to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy for many of our products differs from that of our competitors and our offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold by other companies cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE.

[0000068505-15-000003:mdna:224]
When both VSOE and TPE are unavailable, we use ESP. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0000068505-15-000003:mdna:225]
We also consider the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE, TPE, and ESP.

[0000068505-15-000003:mdna:226]
Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above.

[0000068505-15-000003:mdna:227]
Our arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. The revenue for these multiple-element arrangements is allocated to the software deliverable(s) and the non-software deliverable(s) based on the relative selling prices of all of the deliverables in the arrangement using the fair value hierarchy outlined above. In circumstances where we cannot determine VSOE or TPE for any of the deliverables in the arrangement, ESP is used for the purpose of allocating the arrangement consideration between software and non-software deliverables.

[0000068505-15-000003:mdna:228]
We allocate arrangement consideration to multiple software or software-related deliverables, including the sale of software upgrades or software support agreements to previously sold software, in accordance with software accounting guidance. For such arrangements, revenue is allocated to the deliverables based on the relative fair value of each element, and fair value is determined using VSOE. Where VSOE does not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established, whichever occurs first. When the final undelivered software element is post contract support, service revenue is recognized on a ratable basis over the remaining service period. When VSOE of a delivered element has not been established, but VSOE exists for the undelivered elements, we use the residual method to recognize revenue when the fair value of all undelivered elements is determinable. Under the residual method, the fair value of

[0000068505-15-000003:mdna:229]
the undelivered elements is deferred and the remaining portion of the arrangement consideration is allocated to the delivered elements and is recognized as revenue.

[0000068505-15-000003:mdna:230]
Inventory Valuation

[0000068505-15-000003:mdna:231]
We record valuation reserves on our inventory for estimated excess or obsolescence. The amount of the reserve is equal to the difference between the cost of the inventory and the estimated market value based upon assumptions about future demand and market conditions. On a quarterly basis, management performs an analysis based on future demand requirement estimates of the underlying inventory to identify reserves needed for excess and obsolescence. We use our best judgment to estimate appropriate reserves based on this analysis. In addition, we adjust the carrying value of inventory if the current market value of that inventory is below our cost.

[0000068505-15-000003:mdna:232]
At December 31, 2014 and 2013, Inventories consisted of the following:

[0000068505-15-000003:mdna:233]
| December 31 | 2014 |  | 2013 |
| Finished goods | $ | 163 |  |  | $ | 157 |  |
| Work-in-process and production materials | 313 |  |  | 315 |  |
|  | 476 |  |  | 472 |  |
| Less inventory reserves | (131 | ) |  | (125 | ) |
|  | $ | 345 |  |  | $ | 347 |  |

[0000068505-15-000003:mdna:234]
We balance the need to maintain strategic inventory levels to ensure competitive delivery performance to our customers against the risk of inventory obsolescence due to rapidly changing technology and customer requirements. As reflected above, our inventory reserves represented 28% of the gross inventory balance at December 31, 2014, compared to 26% of the gross inventory balance at December 31, 2013. We have inventory reserves for excess inventory, pending cancellations of product lines due to technology changes, long-life cycle products, lifetime buys at the end of supplier production runs, business exits, and a shift of production to outsourced manufacturing.

[0000068505-15-000003:mdna:235]
If future demand or market conditions are less favorable than those projected by management, additional inventory writedowns may be required.

[0000068505-15-000003:mdna:236]
Income Taxes

[0000068505-15-000003:mdna:237]
Our effective tax rate is based on pre-tax income and the tax rates applicable to such income in the various jurisdictions in which we operate. An estimated effective tax rate for the year is applied to our quarterly operating results. In the event that there is a significant unusual or discrete item recognized, or expected to be recognized, in our quarterly operating results, the tax attributable to that item is separately calculated and recorded at the same time as the unusual or discrete item. We consider the resolution of prior year tax matters to be such items. Significant judgment is required in determining our effective tax rate and in evaluating our tax positions. We adjust reserves for unrecognized income tax benefits in light of changing facts and circumstances. We recognize the tax benefit of a tax position only if it is more-likely-than-not to be sustained.

[0000068505-15-000003:mdna:238]
Tax regulations may require items of income and expense to be included in a tax return in different periods than the items are reflected in the consolidated financial statements. As a result, the effective tax rate reflected in the consolidated financial statements may be different than the tax rate reported in the income tax return. Some of these differences are permanent, such as expenses that are not deductible on the tax return, and some are temporary differences, such as depreciation expense. Temporary differences create deferred tax assets and liabilities. Deferred tax assets generally represent items that can be used as a tax deduction or credit in the tax return in future years for which we have already recorded the tax benefit in the consolidated financial statements. Deferred tax liabilities generally represent tax expense recognized in the consolidated financial statements for which the tax payment has been deferred or expense for which we have already taken a deduction on an income tax return, but has not yet been recognized in the consolidated financial statements.

[0000068505-15-000003:mdna:239]
We account for income taxes by recognizing deferred tax assets and liabilities using enacted tax rates for the effect of the temporary differences between the book and tax basis of recorded assets and liabilities. We make estimates and judgments with regard to the calculation of certain income tax assets and liabilities. Deferred tax assets are reduced by valuation allowances if, based on the consideration of all available evidence, it is more-likely-than-not that all or some portion of the deferred tax asset will not be realized. Significant weight is given to evidence that can be objectively verified.

[0000068505-15-000003:mdna:240]
We evaluate deferred income taxes on a quarterly basis to determine if valuation allowances are required by considering available evidence, including historical and projected taxable income and tax planning strategies that are both prudent and feasible.

[0000068505-15-000003:mdna:241]
During 2014, the movement in our deferred tax valuation allowances primarily relates to deferred tax assets that are not more-likely-than-not to be realizable based on estimates of future taxable income, net of expiration of carryforwards. During 2013, our deferred tax valuation allowances were adjusted primarily for current year movement in deferred taxes and expiration of carryforwards.

[0000068505-15-000003:mdna:242]
We have a total deferred tax asset valuation allowance of approximately $226 million against gross deferred tax assets of approximately $3.6 billion as of December 31, 2014, compared to total deferred tax asset valuation allowance of approximately $200 million against net deferred tax assets of approximately $3.7 billion as of December 31, 2013.

[0000068505-15-000003:mdna:243]
40

[0000068505-15-000003:mdna:244]
Retirement Benefits

[0000068505-15-000003:mdna:245]
Our benefit obligations and net periodic pension cost (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions.  The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-15-000003:mdna:246]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-15-000003:mdna:247]
There are various assumptions used in calculating the net periodic benefit expense and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.   We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-15-000003:mdna:248]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost and the net retirement healthcare expense. Our investment return assumption for the U.S. Pension Benefit Plans and Postretirement Healthcare Benefits Plan was 7.00% in both 2014 and 2013. At December 31, 2014, the pension plans and the Postretirement Health Care Benefits Plan investment portfolios were comprised of approximately 43 percent and 20 percent equity investments, respectively.

[0000068505-15-000003:mdna:249]
A second key assumption is the discount rate. The discount rate assumptions used for pension benefits and postretirement health care benefits reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. pension benefit obligations were 4.30% and 5.15% at December 2014 and 2013, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 3.90% and 4.65% at December 31, 2014 and 2013, respectively.

[0000068505-15-000003:mdna:250]
A final set of assumptions involves the cost drivers of the underlying benefits. The rate of compensation increase is a key assumption used in the actuarial model for pension accounting and is determined by us based upon our long-term plans for such increases. Our 2014 and 2013 rate for future compensation increase for the U.S. Pension Benefit Plans was 0%, as the salaries to be utilized for calculation of benefits under these plans have been frozen. For the Postretirement Health Care Benefits Plan, we review external data and our own historical trends for health care costs to determine the health care cost trend rates. The health care cost trend rate used to determine the accumulated postretirement benefit obligation and 2015 net periodic benefit was 7.75%, then grading down to a rate of 5.00% in 2021.  The health care cost trend rate used to determine the December 31, 2013 accumulated postretirement benefit obligation was 8.50% for 2014, remaining flat at 8.50% through 2015, then grading down to a rate of 5.00% in 2020.

[0000068505-15-000003:mdna:251]
Prior to 2013, unrecognized gains and losses were amortized over periods ranging from three to thirteen years. At the close of fiscal 2012, we determined that the majority of the plan participants in our Regular and United Kingdom pension plans were no longer actively employed due to significant employee exits as a result of our recent divestitures. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant.  As such, depending on the specific plan, we amortize gains and losses over periods ranging from four to thirty-six years. Prior service costs are being amortized over periods ranging from six to twelve years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-15-000003:mdna:252]
Our pension deficit is impacted by the volatility of corporate bond rates which are used to determine the plan discount rate as well as returns on the pension plan asset portfolio.  The discount rate used to measure the New Plan liability at the end of 2014 was 4.30%, compared to 5.15% in the prior year. As of December 31, 2014, changing the New Plan discount rate by one percentage point would change the net periodic pension cost in 2015 as follows:

[0000068505-15-000003:mdna:253]
|  | 1% PointIncrease |  | 1% PointDecrease |
| Increase (decrease) in: |  |  |  |
| New Plans' net periodic pension costs | $ | (7 | ) |  | $ | 4 |  |

[0000068505-15-000003:mdna:254]
Valuation and Recoverability of Goodwill

[0000068505-15-000003:mdna:255]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: adverse changes in macroeconomic conditions, adverse changes in the entity's industry or market, changes in cost factors negatively impacting earnings and cash flows, negative or declining overall financial performance, events affecting the carrying

[0000068505-15-000003:mdna:256]
41

[0000068505-15-000003:mdna:257]
value or composition of a reporting unit, or a sustained decrease in share price, among others.  Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-15-000003:mdna:258]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Services segments each meet the definition of a reporting unit. We performed a qualitative assessment of goodwill and determined that it was not more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2014, 2013, and 2012. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2014, 2013, and 2012, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.

[0000068505-15-000003:mdna:259]
Recent Accounting Pronouncements

[0000068505-15-000003:mdna:260]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers."  This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. The ASU will be effective for us beginning January 1, 2017, and allows for both retrospective and modified-retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-15-000003:mdna:261]
Forward-Looking Statements

[0000068505-15-000003:mdna:262]
Except for historical matters, the matters discussed in this Form 10-K are forward-looking statements that involve risks and uncertainties. Forward-looking statements include, but are not limited to, statements under the following headings: (1) “Business,” about: (a) industry growth and demand, including opportunities resulting from such growth, (b) future product development and the demand for new products, (c) customer spending, (d) the impact of our strategy and focus areas, (e) the impact from the loss of key customers, (f) competitive position and our ability to maintain a leadership position in our core products, (g) increased competition, (h) the impact of regulatory matters, (i) the impact from the allocation and regulation of spectrum, particularly with respect to broadband spectrum, (j) the firmness of each segment's backlog, (k) the competitiveness of the patent portfolio, (l) the impact of research and development (m) the availability of materials and components, energy supplies and labor, and (n) the seasonality of the business,; (2) “Properties,” about the sufficiency of our manufacturing capacity and the consequences of a disruption in manufacturing; (3) “Legal Proceedings,” about the ultimate disposition of pending legal matters and timing; (4) “Management's Discussion and Analysis,” about: (a) market growth/contraction, demand, spending and resulting opportunities, (b) the increase in public safety LTE revenues in 2015, (c) the decline in iDEN, (d) the return of capital to shareholders through dividends and/or repurchasing shares, (e) the success of our business strategy and portfolio, (f) future payments, charges, use of accruals and expected cost-saving and profitability benefits associated with our reorganization of business programs and employee separation costs, (g) our ability and cost to repatriate funds, (h) the impact of the timing and level of sales and the geographic location of such sales, (i) the impact of maintaining inventory, (j) future cash contributions to pension plans or retiree health benefit plans, (k) the liquidity of our investments, (l) our ability and cost to access the capital markets, (m) our ability to borrow and the amount available under our credit facilities, (n) our ability to retire outstanding debt, (o) our ability and cost to obtain Performance Bonds, (p) adequacy of internal resources to fund expected working capital and capital expenditure measurements, (q) expected payments pursuant to commitments under long-term agreements, (r) the ability to meet minimum purchase obligations, (s) our ability to sell accounts receivable and the terms and amounts of such sales, (t) the outcome and effect of ongoing and future legal proceedings, (u) the impact of recent accounting pronouncements on our financial statements, (v) the impact of the loss of key customers, and (w) the expected effective tax rate and deductibility of certain items; and (5) “Quantitative and Qualitative Disclosures about Market Risk,” about: (a) the impact of foreign currency exchange risks, (b) future hedging activity and expectations of the Company, and (c) the ability of counterparties to financial instruments to perform their obligations.

[0000068505-15-000003:mdna:263]
Some of the risk factors that affect our business and financial results are discussed in “Item 1A: Risk Factors.” We wish to caution the reader that the risk factors discussed in “Item 1A: Risk Factors,” and those described elsewhere in this report or in our other Securities and Exchange Commission filings, could cause our actual results to differ materially from those stated in the forward-looking statements.
