# MSI note change history — 0000068505-14-000010 → 0000068505-14-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-11-04):
[0000068505-14-000016:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representation and warranties in connection with prior divestitures not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at September 27, 2014.

- changed (2014-11-04):
[0000068505-14-000016:note_history:2]
Also, pursuant to the Master Separation and Distribution Agreement and certain other agreements entered into in connection with the separation of Motorola Mobility Holdings, Inc. ("Motorola Mobility"),  Motorola Mobility agreed to indemnify the Company for certain liabilities, and the Company agreed to indemnify Motorola Mobility for certain liabilities, in each case for uncapped amounts.
  (was, 2014-08-05, similarity 0.9949):
[0000068505-14-000010:note_history:2]
Also, pursuant to the Master Separation and Distribution Agreement and certain other agreements entered into in connection with the separating of Motorola Mobility Holdings, Inc. ("Motorola Mobility"),  Motorola Mobility agreed to indemnify the Company for certain liabilities, and the Company agreed to indemnify Motorola Mobility for certain liabilities, in each case for uncapped amounts.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-04):
[0000068505-14-000016:note_history:3]
The condensed consolidated financial statements as of September 27, 2014 and for the three and nine months ended September 27, 2014 and September 28, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2014-08-05, similarity 0.9321):
[0000068505-14-000010:note_history:3]
The condensed consolidated financial statements as of June 28, 2014 and for the three and six months ended June 28, 2014 and June 29, 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2014-11-04):
[0000068505-14-000016:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013 and Form 8-K filed on August 7, 2014.  The results of operations for the three and nine months ended September 27, 2014 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2014-08-05, similarity 0.7161):
[0000068505-14-000010:note_history:4]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2013.  The results of operations for the three and six months ended June 28, 2014 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2014-11-04):
[0000068505-14-000016:note_history:5]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company does not believe this ASU will have a material impact to its consolidated its financial statements.
  (was, 2014-08-05, similarity 0.8955):
[0000068505-14-000010:note_history:5]
In January 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-05, “Service Concession Arrangements.” The ASU clarifies that an operating entity should not account for a services concession arrangement with a public-sector grantor as a lease if:  (i) the grantor controls or has the ability to modify or approve the services the operating entity must provide, to whom it must provide them, and at what price and (ii) the grantor controls any residual interest in the infrastructure at the end of the arrangement. In addition, the infrastructure used in a service concession arrangement would not be recognized as property, plant and equipment of the operating entity. The ASU is to be applied on a modified retrospective basis to service concession arrangements outstanding upon adoption and will be effective for the Company beginning January 1, 2015. The Company is currently assessing the impact of this standard on its consolidated financial statements and footnote disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-11-04):
[0000068505-14-000016:note_history:6]
During the third quarter of 2014, the Company redeemed $400 million aggregate principal amount outstanding of its 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, the Company recognized a loss of $37 million related to the redemption within Other income (expense) in the condensed consolidated statement of operations. The Company issued an aggregate face principal amount of $1.4 billion including: (i) $600 million of 4.000% Senior notes due 2024, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior notes due 2021, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior notes due 2044, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $394 million.

- changed (2014-11-04):
[0000068505-14-000016:note_history:7]
As of September 27, 2014, the Company had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of September 27, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the three and nine months ended September 27, 2014.
  (was, 2014-08-05, similarity 0.9245):
[0000068505-14-000010:note_history:7]
As of June 28, 2014, the Company had a $2.0 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. Effective May 29, 2014, this facility replaced the previous $1.5 billion unsecured syndicated revolving credit facility (the “2011 Motorola Solutions Credit Agreement”) which was scheduled to mature on June 30, 2014. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company is no longer subject to a minimum interest coverage covenant under the new facility. The Company was in compliance with its financial covenants as of June 28, 2014. The Company did not borrow under the 2011 Motorola Solutions Credit Agreement or the 2014 Motorola Solutions Credit Agreement during the three and six months ended June 28, 2014.

- changed (2014-11-04):
[0000068505-14-000016:note_history:8]
As of September 27, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of September 27, 2014.
  (was, 2014-08-05, similarity 0.9194):
[0000068505-14-000010:note_history:8]
As of June 28, 2014, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of June 28, 2014.
