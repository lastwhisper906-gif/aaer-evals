# MSI note change history — 0000068505-19-000013 → 0000068505-19-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000068505-19-000019:note_history:1]
Commitments and Contingencies
Legal Matters
  (was, 2019-05-03, similarity 0.8056):
[0000068505-19-000013:note_history:1]
Commitments and Contingencies

- changed (2019-08-02):
[0000068505-19-000019:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at June 29, 2019.
  (was, 2019-05-03, similarity 0.9925):
[0000068505-19-000013:note_history:2]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at March 30, 2019.

- removed (2019-08-02):
[0000068505-19-000013:note_history:3]
Legal Matters


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000068505-19-000019:note_history:4]
The condensed consolidated financial statements as of June 29, 2019 and for the three and six months ended June 29, 2019 and June 30, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2019-05-03, similarity 0.943):
[0000068505-19-000013:note_history:4]
The condensed consolidated financial statements as of March 30, 2019 and for the three months ended March 30, 2019 and March 31, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statements of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2019-08-02):
[0000068505-19-000019:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three and six months ended June 29, 2019 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2019-05-03, similarity 0.811):
[0000068505-19-000013:note_history:5]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three months ended March 30, 2019 are not necessarily indicative of the operating results to be expected for the full year.

- added (2019-08-02):
[0000068505-19-000019:note_history:6]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security solutions platform.

- changed (2019-08-02):
[0000068505-19-000019:note_history:7]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities.
  (was, 2019-05-03, similarity 0.8796):
[0000068505-19-000013:note_history:7]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communications for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Services and Software segments.

- changed (2019-08-02):
[0000068505-19-000019:note_history:8]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million.
  (was, 2019-05-03, similarity 0.8989):
[0000068505-19-000013:note_history:8]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million. This acquisition expands the Company's command center software portfolio under the Services and Software segment.

- changed (2019-08-02):
[0000068505-19-000019:note_history:9]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash, net of cash acquired, debt assumed, and transaction costs paid.
  (was, 2019-05-03, similarity 0.9042):
[0000068505-19-000013:note_history:9]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash.

- changed (2019-08-02):
[0000068505-19-000019:note_history:10]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash, net of cash acquired. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.
  (was, 2019-05-03, similarity 0.9656):
[0000068505-19-000013:note_history:10]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.

- added (2019-08-02):
[0000068505-19-000019:note_history:11]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020. The ASU requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

- changed (2019-08-02):
[0000068505-19-000019:note_history:12]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1, 2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.
  (was, 2019-05-03, similarity 0.9969):
[0000068505-19-000013:note_history:12]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1,2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

- changed (2019-08-02):
[0000068505-19-000019:note_history:13]
As of January 1, 2019, the Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition.
  (was, 2019-05-03, similarity 0.9213):
[0000068505-19-000013:note_history:13]
The Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition. In future periods such balances will not be presented separately.

- changed (2019-08-02):
[0000068505-19-000019:note_history:14]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.
  (was, 2019-05-03, similarity 0.9967):
[0000068505-19-000013:note_history:14]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (1) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (2) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 Revenue from Contract with Customers and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.

- removed (2019-08-02):
[0000068505-19-000013:note_history:15]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. This was subsequently amended by ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” which clarifies that receivables arising from operating leases are not within the scope of the ASU and amends the transition requirements. The ASU is effective for the Company on January 1, 2020 with early adoption permitted beginning as of January 1, 2019. The ASU requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-08-02):
[0000068505-19-000019:note_history:16]
|  | June 29, 2019 |  | December 31, 2018 |
| 2.0% Senior Convertible Notes due 2020 | $ | 800 |  |  | $ | 800 |  |
| Term Loan due 2021 | 399 |  |  | 399 |  |
| 3.5% senior notes due 2021 | 149 |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 690 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 645 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 52 |  |  | 62 |  |
|  | 5,347 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (4 | ) |  | (4 | ) |
| Less: current portion | (28 | ) |  | (31 | ) |
| Long-term debt | $ | 5,315 |  |  | $ | 5,289 |  |

- changed (2019-08-02):
[0000068505-19-000019:note_history:17]
As of June 29, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 29, 2019. During the first quarter of 2018, the Company borrowed $400 million to facilitate the Avigilon acquisition which was re-paid by December 31, 2018. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2018 and June 29, 2019.
  (was, 2019-05-03, similarity 0.9455):
[0000068505-19-000013:note_history:17]
As of March 30, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 30, 2019. During the first quarter of 2018, the Company borrowed $400 million to facilitate the Avigilon acquisition. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of March 30, 2019.

- changed (2019-08-02):
[0000068505-19-000019:note_history:18]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan. During the second half of 2018, the Company issued an additional $200 million on the outstanding notes. The Company recognized net proceeds of $196 million after debt issuance costs and debt discounts.
  (was, 2019-05-03, similarity 0.7335):
[0000068505-19-000013:note_history:18]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan.

- changed (2019-08-02):
[0000068505-19-000019:note_history:19]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 29, 2019 were 3.72% and 3.74%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.
  (was, 2019-05-03, similarity 0.6959):
[0000068505-19-000013:note_history:19]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three months ended March 30, 2019 was 3.75%. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- changed (2019-08-02):
[0000068505-19-000019:note_history:20]
In May of 2019, the Company issued $650 million of 4.60% Senior notes due 2029. The Company recognized net proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to fund a tender offer which resulted in the repurchase of $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest, all of which occurred during the three months ended June 29, 2019. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $43 million related to this debt tender in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.
As of June 29, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of June 29, 2019 was $1.1 billion. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.
  (was, 2019-05-03, similarity 0.6279):
[0000068505-19-000013:note_history:20]
As of March 30, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of March 30, 2019 was $876 million. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2019-08-02):
[0000068505-19-000019:note_history:21]
|  | June 29, 2019 |  | December 31, 2018 |
| 2.0% Senior Convertible Notes due 2020 | $ | 800 |  |  | $ | 800 |  |
| Term Loan due 2021 | 399 |  |  | 399 |  |
| 3.5% senior notes due 2021 | 149 |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 690 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 645 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 52 |  |  | 62 |  |
|  | 5,347 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (4 | ) |  | (4 | ) |
| Less: current portion | (28 | ) |  | (31 | ) |
| Long-term debt | $ | 5,315 |  |  | $ | 5,289 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000068505-19-000019:note_history:22]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 29, 2019 and June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2019-05-03, similarity 0.9219):
[0000068505-19-000013:note_history:22]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 30, 2019 and March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- added (2019-08-02):
[0000068505-19-000019:note_history:23]
|  | Three Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 969 |  |  | $ | 378 |  |  | $ | 878 |  |  | $ | 331 |  |
| EMEA | 152 |  |  | 204 |  |  | 188 |  |  | 194 |  |
| Asia Pacific | 117 |  |  | 40 |  |  | 123 |  |  | 46 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 809 |  |  | $ | — |  |  | $ | 725 |  |  | $ | — |  |
| Systems and Systems Integration | 429 |  |  | — |  |  | 464 |  |  | — |  |
| Services | — |  |  | 469 |  |  | — |  |  | 456 |  |
| Software | — |  |  | 153 |  |  | — |  |  | 115 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 771 |  |  | $ | 582 |  |  | $ | 740 |  |  | $ | 537 |  |
| Indirect | 467 |  |  | 40 |  |  | 449 |  |  | 34 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |

- added (2019-08-02):
[0000068505-19-000019:note_history:24]
|  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,782 |  |  | $ | 730 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 317 |  |  | 402 |  |  | 345 |  |  | 375 |  |
| Asia Pacific | 208 |  |  | 78 |  |  | 220 |  |  | 84 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,495 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 812 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 921 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 289 |  |  | — |  |  | 184 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,429 |  |  | $ | 1,135 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 878 |  |  | 75 |  |  | 784 |  |  | 44 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

- removed (2019-08-02):
[0000068505-19-000013:note_history:25]
|  | March 30, 2019 |  | March 31, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 813 |  |  | $ | 352 |  |  | $ | 699 |  |  | $ | 296 |  |
| EMEA | 164 |  |  | 199 |  |  | 156 |  |  | 182 |  |
| Asia Pacific | 92 |  |  | 37 |  |  | 97 |  |  | 38 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 686 |  |  | $ | — |  |  | $ | 632 |  |  | $ | — |  |
| Systems and Systems Integration | 383 |  |  | — |  |  | 320 |  |  | — |  |
| Services | — |  |  | 452 |  |  | — |  |  | 446 |  |
| Software | — |  |  | 136 |  |  | — |  |  | 70 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 657 |  |  | $ | 553 |  |  | $ | 617 |  |  | $ | 506 |  |
| Indirect | 412 |  |  | 35 |  |  | 335 |  |  | 10 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000068505-19-000019:note_history:26]
Revenue from Contracts with Customers
Disaggregation of Revenue
  (was, 2019-05-03, similarity 0.74):
[0000068505-19-000013:note_history:26]
Revenue from Contracts with Customers

- changed (2019-08-02):
[0000068505-19-000019:note_history:27]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 29, 2019 and June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2019-05-03, similarity 0.9219):
[0000068505-19-000013:note_history:27]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 30, 2019 and March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- added (2019-08-02):
[0000068505-19-000019:note_history:28]
|  | Three Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 969 |  |  | $ | 378 |  |  | $ | 878 |  |  | $ | 331 |  |
| EMEA | 152 |  |  | 204 |  |  | 188 |  |  | 194 |  |
| Asia Pacific | 117 |  |  | 40 |  |  | 123 |  |  | 46 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 809 |  |  | $ | — |  |  | $ | 725 |  |  | $ | — |  |
| Systems and Systems Integration | 429 |  |  | — |  |  | 464 |  |  | — |  |
| Services | — |  |  | 469 |  |  | — |  |  | 456 |  |
| Software | — |  |  | 153 |  |  | — |  |  | 115 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 771 |  |  | $ | 582 |  |  | $ | 740 |  |  | $ | 537 |  |
| Indirect | 467 |  |  | 40 |  |  | 449 |  |  | 34 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |

- added (2019-08-02):
[0000068505-19-000019:note_history:29]
|  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,782 |  |  | $ | 730 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 317 |  |  | 402 |  |  | 345 |  |  | 375 |  |
| Asia Pacific | 208 |  |  | 78 |  |  | 220 |  |  | 84 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,495 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 812 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 921 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 289 |  |  | — |  |  | 184 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,429 |  |  | $ | 1,135 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 878 |  |  | 75 |  |  | 784 |  |  | 44 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

- changed (2019-08-02):
[0000068505-19-000019:note_history:30]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 29, 2019 is $7.3 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.2 billion is from Services and Software performance obligations that are not yet satisfied as of June 29, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2019-05-03, similarity 0.9932):
[0000068505-19-000013:note_history:30]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 30, 2019 is $7.0 billion. A total of $3.0 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.6 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.0 billion is from Services and Software performance obligations that are not yet satisfied as of March 30, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.3 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

- added (2019-08-02):
[0000068505-19-000019:note_history:31]
|  | June 29, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,206 |  |  | $ | 1,293 |  |
| Contract assets | 913 |  |  | 1,012 |  |
| Contract liabilities | 1,187 |  |  | 1,263 |  |
| Non-current contract liabilities | 263 |  |  | 214 |  |

- added (2019-08-02):
[0000068505-19-000019:note_history:32]
Revenue recognized during the three months ended June 29, 2019 which was previously included in Contract liabilities as of March 30, 2019 is $340 million, compared to $365 million of revenue recognized during the three months ended June 30, 2018 which was previously included in Contract liabilities as of April 1, 2018. Revenue recognized during the six months ended June 29, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $600 million, compared to $541 million of revenue recognized during the six months ended June 30, 2018 which was previously included in Contract liabilities as of January 1, 2018. Adjustments to revenue for the three and six months ended June 29, 2019 and June 30, 2018 driven by changes in the estimates of progress on system contracts was immaterial.

- changed (2019-08-02):
[0000068505-19-000019:note_history:33]
There were no material impairment losses recognized on contract assets during the three and six months ended June 29, 2019 and June 30, 2018.
  (was, 2019-05-03, similarity 0.8976):
[0000068505-19-000013:note_history:33]
There were no material impairment losses recognized on contract assets during the three months ended March 30, 2019 and March 31, 2018.

- changed (2019-08-02):
[0000068505-19-000019:note_history:34]
|  | June 29, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 37 |  |  | $ | 30 |  |
| Non-current contract cost assets | 98 |  |  | 98 |  |
  (was, 2019-05-03, similarity 0.9673):
[0000068505-19-000013:note_history:34]
|  | March 30, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 36 |  |  | $ | 30 |  |
| Non-current contract cost assets | 99 |  |  | 98 |  |

- changed (2019-08-02):
[0000068505-19-000019:note_history:35]
Amortization of contract cost assets was $11 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and $22 million and $23 million for the six months ended June 29, 2019 and June 30, 2018, respectively.
  (was, 2019-05-03, similarity 0.6488):
[0000068505-19-000013:note_history:35]
Amortization of contract cost assets was $11 million and $12 million for the three months ended March 30, 2019 and March 31, 2018, respectively.

- removed (2019-08-02):
[0000068505-19-000013:note_history:36]
Disaggregation of Revenue

- removed (2019-08-02):
[0000068505-19-000013:note_history:37]
|  | March 30, 2019 |  | March 31, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 813 |  |  | $ | 352 |  |  | $ | 699 |  |  | $ | 296 |  |
| EMEA | 164 |  |  | 199 |  |  | 156 |  |  | 182 |  |
| Asia Pacific | 92 |  |  | 37 |  |  | 97 |  |  | 38 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 686 |  |  | $ | — |  |  | $ | 632 |  |  | $ | — |  |
| Systems and Systems Integration | 383 |  |  | — |  |  | 320 |  |  | — |  |
| Services | — |  |  | 452 |  |  | — |  |  | 446 |  |
| Software | — |  |  | 136 |  |  | — |  |  | 70 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 657 |  |  | $ | 553 |  |  | $ | 617 |  |  | $ | 506 |  |
| Indirect | 412 |  |  | 35 |  |  | 335 |  |  | 10 |  |
| Total | $ | 1,069 |  |  | $ | 588 |  |  | $ | 952 |  |  | $ | 516 |  |

- removed (2019-08-02):
[0000068505-19-000013:note_history:38]
|  | March 30, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,150 |  |  | $ | 1,293 |  |
| Contract assets | 878 |  |  | 1,012 |  |
| Contract liabilities | 1,158 |  |  | 1,263 |  |
| Non-current contract liabilities | 239 |  |  | 214 |  |

- removed (2019-08-02):
[0000068505-19-000013:note_history:39]
Revenue recognized during the three months ended March 30, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $393 million, compared to $297 million of revenue recognized during the three months ended March 31, 2018 which was previously included in Contract liabilities as of January 1, 2018. Revenue of $9 million was reversed during the three months ended March 30, 2019 and $9 million of revenue was recognized during the three months ended March 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.
