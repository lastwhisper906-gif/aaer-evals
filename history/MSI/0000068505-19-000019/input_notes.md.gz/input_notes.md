# MSI notes — 0000068505-19-000019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-19-000019:notes:1]
[same as prior period, unchanged from 0000068505-19-000013:notes:172]

[0000068505-19-000019:notes:2]
The condensed consolidated financial statements as of June 29, 2019 and for the three and six months ended June 29, 2019 and June 30, 2018 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-19-000019:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2018. The results of operations for the three and six months ended June 29, 2019 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-19-000019:notes:4]
The preparation of financial statements in conformity with U.S. GAAP requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-19-000019:notes:5]
Recent Acquisitions

[0000068505-19-000019:notes:6]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands the Company's video security solutions platform.

[0000068505-19-000019:notes:7]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities.

[0000068505-19-000019:notes:8]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million.

[0000068505-19-000019:notes:9]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash, net of cash acquired, debt assumed, and transaction costs paid.

[0000068505-19-000019:notes:10]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash, net of cash acquired. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-19-000019:notes:11]
Recent Accounting Pronouncements

[0000068505-19-000019:notes:12]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for the Company on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. The Company does not believe the ASU will have a material impact on its financial statement disclosures.

[0000068505-19-000019:notes:13]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires the Company to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,” “ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ” “Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for the Company on January 1, 2020. The ASU requires a modified retrospective adoption method. The Company is still evaluating the impact of adoption on its financial statements and disclosures.

[0000068505-19-000019:notes:14]
Recently Adopted Accounting Pronouncements

[0000068505-19-000019:notes:15]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-19-000019:notes:16]
The Company adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1, 2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

[0000068505-19-000019:notes:17]
ASC 842 provides for a number of optional practical expedients in transition. The Company elected the practical expedients, which permit the Company to not reassess prior conclusions about lease identification, lease classification and initial direct costs under ASC 842. The Company did not elect the "use-of hindsight" practical expedient to determine the lease term or in assessing the likelihood that a lease purchase option will be exercised, allowing it to carry forward the lease term as determined prior to adoption of ASC 842. Finally, the Company also elected the practical expedient related to land easements, which enabled it to continue its accounting treatment for land easements on existing agreements as of January 1, 2019.

[0000068505-19-000019:notes:18]
ASC 842 also provides practical expedients for an entity’s ongoing accounting. The Company elected the short-term lease recognition exemption for all leases that qualify. A short-term lease is one with a term of 12 months or less, including any optional periods that are reasonably certain of exercise. For those leases that qualify, the exemption allows the Company to not recognize ROU assets or lease liabilities, including not recognizing ROU assets or lease liabilities for existing short-term leases at transition. Short-term lease costs are recognized as rent expense on a straight-line basis over the lease term consistent with the Company’s prior accounting. The Company also elected the practical expedient to not separate lease and non-lease components for all current lease categories.

[0000068505-19-000019:notes:19]
As of January 1, 2019, the Company recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition.

[0000068505-19-000019:notes:20]
For arrangements where the Company is the lessor, the adoption of ASC 842 did not have a material impact on its financial statements as the majority of its leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. The Company has elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-19-000019:notes:21]
Revenue from Contracts with Customers
Disaggregation of Revenue

[0000068505-19-000019:notes:22]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 29, 2019 and June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-19-000019:notes:23]
|  | Three Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 969 |  |  | $ | 378 |  |  | $ | 878 |  |  | $ | 331 |  |
| EMEA | 152 |  |  | 204 |  |  | 188 |  |  | 194 |  |
| Asia Pacific | 117 |  |  | 40 |  |  | 123 |  |  | 46 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 809 |  |  | $ | — |  |  | $ | 725 |  |  | $ | — |  |
| Systems and Systems Integration | 429 |  |  | — |  |  | 464 |  |  | — |  |
| Services | — |  |  | 469 |  |  | — |  |  | 456 |  |
| Software | — |  |  | 153 |  |  | — |  |  | 115 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 771 |  |  | $ | 582 |  |  | $ | 740 |  |  | $ | 537 |  |
| Indirect | 467 |  |  | 40 |  |  | 449 |  |  | 34 |  |
|  | $ | 1,238 |  |  | $ | 622 |  |  | $ | 1,189 |  |  | $ | 571 |  |

[0000068505-19-000019:notes:24]
|  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
|  | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions: |  |  |  |  |  |  |  |
| Americas | $ | 1,782 |  |  | $ | 730 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 317 |  |  | 402 |  |  | 345 |  |  | 375 |  |
| Asia Pacific | 208 |  |  | 78 |  |  | 220 |  |  | 84 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services: |  |  |  |  |  |  |  |
| Devices | $ | 1,495 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 812 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 921 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 289 |  |  | — |  |  | 184 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type: |  |  |  |  |  |  |  |
| Direct | $ | 1,429 |  |  | $ | 1,135 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 878 |  |  | 75 |  |  | 784 |  |  | 44 |  |
|  | $ | 2,307 |  |  | $ | 1,210 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

[0000068505-19-000019:notes:25]
[same as prior period, unchanged from 0000068505-19-000013:notes:193]

[0000068505-19-000019:notes:26]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 29, 2019 is $7.3 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.2 billion is from Services and Software performance obligations that are not yet satisfied as of June 29, 2019. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.2 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-19-000019:notes:27]
[same as prior period, unchanged from 0000068505-19-000013:notes:195]

[0000068505-19-000019:notes:28]
|  | June 29, 2019 |  | December 31, 2018 |
| Accounts receivable, net | $ | 1,206 |  |  | $ | 1,293 |  |
| Contract assets | 913 |  |  | 1,012 |  |
| Contract liabilities | 1,187 |  |  | 1,263 |  |
| Non-current contract liabilities | 263 |  |  | 214 |  |

[0000068505-19-000019:notes:29]
Revenue recognized during the three months ended June 29, 2019 which was previously included in Contract liabilities as of March 30, 2019 is $340 million, compared to $365 million of revenue recognized during the three months ended June 30, 2018 which was previously included in Contract liabilities as of April 1, 2018. Revenue recognized during the six months ended June 29, 2019 which was previously included in Contract liabilities as of December 31, 2018 is $600 million, compared to $541 million of revenue recognized during the six months ended June 30, 2018 which was previously included in Contract liabilities as of January 1, 2018. Adjustments to revenue for the three and six months ended June 29, 2019 and June 30, 2018 driven by changes in the estimates of progress on system contracts was immaterial.

[0000068505-19-000019:notes:30]
There were no material impairment losses recognized on contract assets during the three and six months ended June 29, 2019 and June 30, 2018.

[0000068505-19-000019:notes:31]
Contract Cost Balances

[0000068505-19-000019:notes:32]
|  | June 29, 2019 |  | December 31, 2018 |
| Current contract cost assets | $ | 37 |  |  | $ | 30 |  |
| Non-current contract cost assets | 98 |  |  | 98 |  |

[0000068505-19-000019:notes:33]
Amortization of contract cost assets was $11 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and $22 million and $23 million for the six months ended June 29, 2019 and June 30, 2018, respectively.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-19-000019:notes:34]
Leases
The Company leases certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases.

[0000068505-19-000019:notes:35]
[same as prior period, unchanged from 0000068505-19-000013:notes:155]

[0000068505-19-000019:notes:36]
[same as prior period, unchanged from 0000068505-19-000013:notes:156]

[0000068505-19-000019:notes:37]
[same as prior period, unchanged from 0000068505-19-000013:notes:157]

[0000068505-19-000019:notes:38]
[same as prior period, unchanged from 0000068505-19-000013:notes:158]

[0000068505-19-000019:notes:39]
The components of lease expense are as follows:

[0000068505-19-000019:notes:40]
| June 29, 2019 |  | Three Months Ended |  | Six Months Ended |
| Lease expense: |  |  |  |  |
| Operating lease cost |  | $ | 33 |  |  | $ | 65 |  |
| Finance lease cost |  |  |  |  |
| Amortization of right-of-use assets |  | 3 |  |  | 6 |  |
| Interest on lease liabilities |  | — |  |  | 1 |  |
| Total finance lease cost |  | 3 |  |  | 7 |  |
| Short-term lease cost |  | 1 |  |  | 3 |  |
| Variable cost |  | 8 |  |  | 17 |  |
| Sublease income |  | (1 | ) |  | (2 | ) |
| Net lease expense |  | $ | 44 |  |  | $ | 90 |  |

[0000068505-19-000019:notes:41]
Lease assets and liabilities consist of the following:

[0000068505-19-000019:notes:42]
|  |  | Statement Line Classification |  | June 29, 2019 |
| Assets: |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 567 |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 50 |  |
|  |  |  |  | $ | 617 |  |
| Current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 118 |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 14 |  |
|  |  |  |  | $ | 132 |  |
| Non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 504 |  |
| Finance lease liabilities |  | Long-term debt |  | 22 |  |
|  |  |  |  | $ | 526 |  |

[0000068505-19-000019:notes:43]
Other information related to leases is as follows:

[0000068505-19-000019:notes:44]
|  | Six Months Ended |
|  | June 29, 2019 |
| Supplemental cash flow information: |  |
| Net cash used for operating activities related to operating leases | $ | 80 |  |
| Net cash used for operating activities related to finance leases | 1 |  |
| Net cash used for financing activities related to finance leases | 8 |  |
| Assets obtained in exchange for lease liabilities: |  |
| Operating leases | $ | 45 |  |

[0000068505-19-000019:notes:45]
|  | June 29, 2019 |
| Weighted average remaining lease terms (years): |  |
| Operating leases | 8 |  |
| Finance leases | 3 |  |
| Weighted average discount rate: |  |
| Operating leases | 3.76 | % |
| Finance leases | 4.97 | % |

[0000068505-19-000019:notes:46]
Future lease payments as of June 29, 2019 are as follows:

[0000068505-19-000019:notes:47]
|  | Operating Leases |  | Finance Leases |  | Total |
| 2019 | $ | 58 |  |  | $ | 8 |  |  | $ | 66 |  |
| 2020 | 136 |  |  | 14 |  |  | 150 |  |
| 2021 | 121 |  |  | 12 |  |  | 133 |  |
| 2022 | 105 |  |  | 5 |  |  | 110 |  |
| 2023 | 55 |  |  | — |  |  | 55 |  |
| Thereafter | 247 |  |  | — |  |  | 247 |  |
| Total lease payments | 722 |  |  | 39 |  |  | 761 |  |
| Less: Interest | 100 |  |  | 3 |  |  | 103 |  |
| Present value of lease liabilities | $ | 622 |  |  | $ | 36 |  |  | $ | 658 |  |

[0000068505-19-000019:notes:48]
[same as prior period, unchanged from 0000068505-19-000013:notes:159]

[0000068505-19-000019:notes:49]
[same as prior period, unchanged from 0000068505-19-000013:notes:160]

[0000068505-19-000019:notes:50]
[same as prior period, unchanged from 0000068505-19-000013:notes:161]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-19-000019:notes:51]
Other Financial Data
Statements of Operations Information

[0000068505-19-000019:notes:52]
[same as prior period, unchanged from 0000068505-19-000013:notes:30]

[0000068505-19-000019:notes:53]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-19-000019:notes:54]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 52 |  |  | $ | 53 |  |  | $ | 102 |  |  | $ | 94 |  |
| Reorganization of business (Note 14) | 8 |  |  | 18 |  |  | 12 |  |  | 26 |  |
| Legal settlements | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Acquisition-related transaction fees | — |  |  | — |  |  | 2 |  |  | 17 |  |
|  | $ | 61 |  |  | $ | 71 |  |  | $ | 116 |  |  | $ | 138 |  |

[0000068505-19-000019:notes:55]
During the six months ended June 29, 2019, the Company recognized $2 million of acquisition-related transaction fees for the VaaS and Avtec acquisitions and $17 million for the Avigilon and Plant acquisitions during the six months ended June 30, 2018.

[0000068505-19-000019:notes:56]
[same as prior period, unchanged from 0000068505-19-000013:notes:32]

[0000068505-19-000019:notes:57]
[same as prior period, unchanged from 0000068505-19-000013:notes:33]

[0000068505-19-000019:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (59 | ) |  | $ | (63 | ) |  | $ | (119 | ) |  | $ | (117 | ) |
| Interest income | 3 |  |  | 5 |  |  | 8 |  |  | 13 |  |
|  | $ | (56 | ) |  | $ | (58 | ) |  | $ | (111 | ) |  | $ | (104 | ) |
| Other,net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 17 |  |  | $ | 20 |  |  | $ | 33 |  |  | $ | 40 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (43 | ) |  | — |  |  | (43 | ) |  | — |  |
| Investment impairments | (3 | ) |  | — |  |  | (11 | ) |  | — |  |
| Foreign currency gain (loss) | (7 | ) |  | 11 |  |  | (11 | ) |  | — |  |
| Loss on derivative instruments | (3 | ) |  | (19 | ) |  | (7 | ) |  | (23 | ) |
| Gains on equity method investments | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Fair value adjustments to equity investments | 16 |  |  | — |  |  | 15 |  |  | — |  |
| Other | 2 |  |  | 1 |  |  | 11 |  |  | (2 | ) |
|  | $ | (21 | ) |  | $ | 13 |  |  | $ | (12 | ) |  | $ | 16 |  |

[0000068505-19-000019:notes:59]
During the three months ended June 29, 2019, the Company recognized a foreign currency loss of $7 million, primarily driven by the Pakistani rupee, the Euro, and the Israeli Shekel, and a loss of $3 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations. During the six months ended June 29, 2019, the Company recognized a foreign currency loss of $11 million, primarily related to the British pound, Pakistani rupee, the Euro, and the Israeli Shekel, and a loss of $7 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-19-000019:notes:60]
During the three months ended June 30, 2018, the Company recognized a foreign currency gain of $11 million, primarily driven by the Euro and British pound, and a loss of $19 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations. During the six months ended June 30, 2018, the Company recognized a loss of $23 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations, which included a loss of $14 million on foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the acquisition of Avigilon.

[0000068505-19-000019:notes:61]
[same as prior period, unchanged from 0000068505-19-000013:notes:37]

[0000068505-19-000019:notes:62]
[same as prior period, unchanged from 0000068505-19-000013:notes:38]

[0000068505-19-000019:notes:63]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 207 |  |  | $ | 180 |  |  | $ | 358 |  |  | $ | 297 |  |
| Weighted average common shares outstanding | 164.9 |  |  | 162.2 |  |  | 164.4 |  |  | 161.7 |  |
| Per share amount | $ | 1.25 |  |  | $ | 1.11 |  |  | $ | 2.18 |  |  | $ | 1.83 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 207 |  |  | $ | 180 |  |  | $ | 358 |  |  | $ | 297 |  |
| Weighted average common shares outstanding | 164.9 |  |  | 162.2 |  |  | 164.4 |  |  | 161.7 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 4.6 |  |  | 3.8 |  |  | 4.7 |  |  | 4.0 |  |
| Senior Convertible Notes | 6.6 |  |  | 5.7 |  |  | 6.2 |  |  | 5.4 |  |
| Diluted weighted average common shares outstanding | 176.1 |  |  | 171.7 |  |  | 175.3 |  |  | 171.1 |  |
| Per share amount | $ | 1.18 |  |  | $ | 1.05 |  |  | $ | 2.04 |  |  | $ | 1.73 |  |

[0000068505-19-000019:notes:64]
In the computation of diluted earnings per common share for the three and six months ended June 29, 2019, the assumed exercise of 0.5 million options, including 0.3 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-19-000019:notes:65]
For the three months ended June 30, 2018, the assumed exercise of 1.4 million options, including 1.2 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the six months ended June 30, 2018, the assumed exercise of 2.9 million options, including 2.4 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-19-000019:notes:66]
As of June 29, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding which mature in September 2020 (the "Senior Convertible Notes"), and are fully convertible. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash and accordingly, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) are included in our computation of diluted earnings per share. The conversion price is adjusted for dividends declared through the date of settlement. Diluted earnings per share has been calculated based upon the amount by which the average stock price exceeds the conversion price.

[0000068505-19-000019:notes:67]
[same as prior period, unchanged from 0000068505-19-000013:notes:42]

[0000068505-19-000019:notes:68]
[same as prior period, unchanged from 0000068505-19-000013:notes:43]

[0000068505-19-000019:notes:69]
[same as prior period, unchanged from 0000068505-19-000013:notes:44]

[0000068505-19-000019:notes:70]
|  | June 29, 2019 |  | December 31, 2018 |
| Accounts receivable | $ | 1,264 |  |  | $ | 1,344 |  |
| Less allowance for doubtful accounts | (58 | ) |  | (51 | ) |
|  | $ | 1,206 |  |  | $ | 1,293 |  |

[0000068505-19-000019:notes:71]
[same as prior period, unchanged from 0000068505-19-000013:notes:46]

[0000068505-19-000019:notes:72]
[same as prior period, unchanged from 0000068505-19-000013:notes:47]

[0000068505-19-000019:notes:73]
|  | June 29, 2019 |  | December 31, 2018 |
| Finished goods | $ | 233 |  |  | $ | 206 |  |
| Work-in-process and production materials | 335 |  |  | 293 |  |
|  | 568 |  |  | 499 |  |
| Less inventory reserves | (144 | ) |  | (143 | ) |
|  | $ | 424 |  |  | $ | 356 |  |

[0000068505-19-000019:notes:74]
[same as prior period, unchanged from 0000068505-19-000013:notes:49]

[0000068505-19-000019:notes:75]
[same as prior period, unchanged from 0000068505-19-000013:notes:50]

[0000068505-19-000019:notes:76]
|  | June 29, 2019 |  | December 31, 2018 |
| Current contract cost assets (Note 2) | $ | 37 |  |  | $ | 30 |  |
| Tax-related deposits | 106 |  |  | 138 |  |
| Other | 181 |  |  | 186 |  |
|  | $ | 324 |  |  | $ | 354 |  |

[0000068505-19-000019:notes:77]
[same as prior period, unchanged from 0000068505-19-000013:notes:52]

[0000068505-19-000019:notes:78]
[same as prior period, unchanged from 0000068505-19-000013:notes:53]

[0000068505-19-000019:notes:79]
|  | June 29, 2019 |  | December 31, 2018 |
| Land | $ | 10 |  |  | $ | 10 |  |
| Leasehold improvements | 377 |  |  | 362 |  |
| Machinery and equipment | 1,938 |  |  | 1,886 |  |
|  | 2,325 |  |  | 2,258 |  |
| Less accumulated depreciation | (1,385 | ) |  | (1,363 | ) |
|  | $ | 940 |  |  | $ | 895 |  |

[0000068505-19-000019:notes:80]
Depreciation expense for the three months ended June 29, 2019 and June 30, 2018 was $44 million and $43 million, respectively. Depreciation expense for the six months ended June 29, 2019 and June 30, 2018 was $89 million and $84 million, respectively.

[0000068505-19-000019:notes:81]
[same as prior period, unchanged from 0000068505-19-000013:notes:56]

[0000068505-19-000019:notes:82]
Investments consist of the following:

[0000068505-19-000019:notes:83]
|  | June 29, 2019 |  | December 31, 2018 |
| Corporate bonds | $ | — |  |  | $ | 1 |  |
| Common stock | 42 |  |  | 19 |  |
| Strategic investments, at cost | 40 |  |  | 62 |  |
| Company-owned life insurance policies | 76 |  |  | 75 |  |
| Equity method investments | 17 |  |  | 12 |  |
|  | $ | 175 |  |  | $ | 169 |  |

[0000068505-19-000019:notes:84]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have a readily determinable fair value and are recorded at cost, less any impairment, and adjusted for changes resulting from observable, orderly transactions for identical or similar securities. The Company did not recognize any significant adjustments to the recorded cost basis during the six months ended June 29, 2019, with the exception of one company becoming publicly-traded during the second quarter, which required the investment to be reclassified to common stock.

[0000068505-19-000019:notes:85]
The Company’s common stock portfolio reflects investments in publicly-traded companies within the communications services sector and is valued utilizing active market prices for similar instruments. During the three and six months ended

[0000068505-19-000019:notes:86]
June 29, 2019, the Company recognized $15 million and $14 million, respectively, in Other income (expense) related to an increase in the fair value of the investments.

[0000068505-19-000019:notes:87]
During the three months ended June 29, 2019, Gains on the sale of investments and businesses, net were $3 million, related to the sale of a business, compared to losses of $1 million, related to the sale of various strategic investments during the three months ended June 30, 2018. During the three months ended June 29, 2019, the Company received $6 million in cash for the sale of $3 million of net assets related to a two-way communications rental business, resulting in the gain on the sale of a business of $3 million.

[0000068505-19-000019:notes:88]
During the six months ended June 29, 2019, Gains on the sale of investments and businesses, net were $4 million, related to the sale of the two-way communications rental business and various equity method investments, compared to $10 million, related to the sale of various strategic and equity method investments during the six months ended June 30, 2018.

[0000068505-19-000019:notes:89]
During the three months ended and six months ended June 29, 2019, the Company recorded investment impairment charges of $3 million and $11 million, respectively, representing other-than-temporary declines in the value of the Company’s strategic investments portfolio. There were no investment impairments recorded during the three months ended and six months ended June 30, 2018. Investment impairment charges are included in Other within Other income (expense) in the Company’s Condensed Consolidated Statements of Operations.

[0000068505-19-000019:notes:90]
[same as prior period, unchanged from 0000068505-19-000013:notes:60]

[0000068505-19-000019:notes:91]
[same as prior period, unchanged from 0000068505-19-000013:notes:61]

[0000068505-19-000019:notes:92]
|  | June 29, 2019 |  | December 31, 2018 |
| Defined benefit plan assets (Note 8) | $ | 163 |  |  | $ | 135 |  |
| Tax receivable | 39 |  |  | 39 |  |
| Non-current contract cost assets (Note 2) | 98 |  |  | 98 |  |
| Other | 64 |  |  | 72 |  |
|  | $ | 364 |  |  | $ | 344 |  |

[0000068505-19-000019:notes:93]
[same as prior period, unchanged from 0000068505-19-000013:notes:63]

[0000068505-19-000019:notes:94]
[same as prior period, unchanged from 0000068505-19-000013:notes:64]

[0000068505-19-000019:notes:95]
|  | June 29, 2019 |  | December 31, 2018 |
| Compensation | $ | 224 |  |  | $ | 324 |  |
| Tax liabilities | 91 |  |  | 111 |  |
| Dividend payable | 94 |  |  | 93 |  |
| Trade liabilities | 146 |  |  | 185 |  |
| Operating lease liabilities (Note 3) | 118 |  |  | — |  |
| Other | 444 |  |  | 497 |  |
|  | $ | 1,117 |  |  | $ | 1,210 |  |

[0000068505-19-000019:notes:96]
[same as prior period, unchanged from 0000068505-19-000013:notes:66]

[0000068505-19-000019:notes:97]
Other liabilities consist of the following:

[0000068505-19-000019:notes:98]
|  | June 29, 2019 |  | December 31, 2018 |
| Defined benefit plans (Note 8) | $ | 1,509 |  |  | $ | 1,557 |  |
| Non-current contract liabilities (Note 2) | 263 |  |  | 214 |  |
| Unrecognized tax benefits | 52 |  |  | 51 |  |
| Deferred income taxes | 180 |  |  | 201 |  |
| Other | 229 |  |  | 277 |  |
|  | $ | 2,233 |  |  | $ | 2,300 |  |

[0000068505-19-000019:notes:99]
[same as prior period, unchanged from 0000068505-19-000013:notes:67]

[0000068505-19-000019:notes:100]
Share Repurchase Program: During the three and six months ended June 29, 2019, the Company paid an aggregate of $25 million and $170 million, including transaction costs, to repurchase approximately 0.2 million and 1.4 million shares at an average price of $146.65 and $122.31 per share, respectively. As of June 29, 2019, the Company had used approximately $12.6 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-19-000019:notes:101]
Payment of Dividends: During the three months ended June 29, 2019 and June 30, 2018, the Company paid $94 million and $84 million, respectively, in cash dividends to holders of its common stock. During the six months ended June 29, 2019 and June 30, 2018, the Company paid $187 million and $168 million, respectively, in cash dividends to holders of its common stock.

[0000068505-19-000019:notes:102]
[same as prior period, unchanged from 0000068505-19-000013:notes:70]

[0000068505-19-000019:notes:103]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended June 29, 2019 and June 30, 2018:

[0000068505-19-000019:notes:104]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (414 | ) |  | $ | (305 | ) |  | $ | (444 | ) |  | $ | (353 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (24 | ) |  | (81 | ) |  | 10 |  |  | (30 | ) |
| Tax benefit (expense) | 1 |  |  | (5 | ) |  | (3 | ) |  | (8 | ) |
| Other comprehensive income (loss), net of tax | (23 | ) |  | (86 | ) |  | 7 |  |  | (38 | ) |
| Balance at end of period | $ | (437 | ) |  | $ | (391 | ) |  | $ | (437 | ) |  | $ | (391 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | — |  |  | — |  |  | — |  |  | (8 | ) |
| Tax benefit | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive loss, net of tax | — |  |  | — |  |  | — |  |  | (6 | ) |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,310 | ) |  | $ | (2,203 | ) |  | $ | (2,321 | ) |  | $ | (2,215 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 17 |  |  | 18 |  |  | 33 |  |  | 36 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4 | ) |  | (4 | ) |  | (7 | ) |  | (7 | ) |
| Tax expense | (3 | ) |  | — |  |  | (5 | ) |  | (3 | ) |
| Other comprehensive income, net of tax | 10 |  |  | 14 |  |  | 21 |  |  | 26 |  |
| Balance at end of period | $ | (2,300 | ) |  | $ | (2,189 | ) |  | $ | (2,300 | ) |  | $ | (2,189 | ) |
| Total Accumulated other comprehensive loss | $ | (2,737 | ) |  | $ | (2,580 | ) |  | $ | (2,737 | ) |  | $ | (2,580 | ) |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0000068505-19-000019:notes:105]
Long-term receivables consist of receivables with payment terms greater than twelve months and long-term loans. Long-term receivables consist of the following:

[0000068505-19-000019:notes:106]
|  | June 29, 2019 |  | December 31, 2018 |
| Long-term receivables, gross | $ | 28 |  |  | $ | 33 |  |
| Less allowance for losses | (2 | ) |  | (2 | ) |
| Long-term receivables | 26 |  |  | 31 |  |
| Less current portion | (10 | ) |  | (7 | ) |
| Non-current long-term receivables | $ | 16 |  |  | $ | 24 |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-19-000019:notes:107]
Debt and Credit Facilities

[0000068505-19-000019:notes:108]
|  | June 29, 2019 |  | December 31, 2018 |
| 2.0% Senior Convertible Notes due 2020 | $ | 800 |  |  | $ | 800 |  |
| Term Loan due 2021 | 399 |  |  | 399 |  |
| 3.5% senior notes due 2021 | 149 |  |  | 397 |  |
| 3.75% senior notes due 2022 | 550 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 596 |  |  | 596 |  |
| 4.0% senior notes due 2024 | 592 |  |  | 591 |  |
| 6.5% debentures due 2025 | 72 |  |  | 118 |  |
| 7.5% debentures due 2025 | 254 |  |  | 346 |  |
| 4.6% senior notes due 2028 | 690 |  |  | 690 |  |
| 6.5% debentures due 2028 | 24 |  |  | 36 |  |
| 4.6% senior notes due 2029 | 645 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 52 |  |  | 62 |  |
|  | 5,347 |  |  | 5,324 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (4 | ) |  | (4 | ) |
| Less: current portion | (28 | ) |  | (31 | ) |
| Long-term debt | $ | 5,315 |  |  | $ | 5,289 |  |

[0000068505-19-000019:notes:109]
As of June 29, 2019, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 29, 2019. During the first quarter of 2018, the Company borrowed $400 million to facilitate the Avigilon acquisition which was re-paid by December 31, 2018. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of December 31, 2018 and June 29, 2019.

[0000068505-19-000019:notes:110]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan. During the second half of 2018, the Company issued an additional $200 million on the outstanding notes. The Company recognized net proceeds of $196 million after debt issuance costs and debt discounts.

[0000068505-19-000019:notes:111]
In conjunction with the Avigilon acquisition in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable, indexed to LIBOR, and paid monthly. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 29, 2019 were 3.72% and 3.74%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-19-000019:notes:112]
In May of 2019, the Company issued $650 million of 4.60% Senior notes due 2029. The Company recognized net proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to fund a tender offer which resulted in the repurchase of $614 million in principal amount of its outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest, all of which occurred during the three months ended June 29, 2019. After accelerating the amortization of debt issuance costs and debt discounts, the Company recognized a loss of approximately $43 million related to this debt tender in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.
As of June 29, 2019, the Company had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of June 29, 2019 was $1.1 billion. In the event of a conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-19-000019:notes:113]
Risk Management
Foreign Currency Risk

[0000068505-19-000019:notes:114]
As of June 29, 2019, the Company had outstanding foreign exchange contracts with notional amounts totaling $1.0 billion, compared to $819 million outstanding at December 31, 2018. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-19-000019:notes:115]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of June 29, 2019, and the corresponding positions as of December 31, 2018:

[0000068505-19-000019:notes:116]
|  | Notional Amount |
| Net Buy (Sell) by Currency | June 29, 2019 |  | December 31, 2018 |
| Euro | $ | 155 |  |  | $ | 89 |  |
| British pound | 46 |  |  | 139 |  |
| Canadian dollar | 42 |  |  | (39 | ) |
| Australian dollar | (107 | ) |  | (105 | ) |
| Chinese renminbi | (55 | ) |  | (55 | ) |

[0000068505-19-000019:notes:117]
[same as prior period, unchanged from 0000068505-19-000013:notes:96]

[0000068505-19-000019:notes:118]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of June 29, 2019, all of the counterparties have investment grade credit ratings. As of June 29, 2019, the Company had $12 million of exposure to aggregate credit risk with all counterparties.

[0000068505-19-000019:notes:119]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of June 29, 2019 and December 31, 2018:

[0000068505-19-000019:notes:120]
|  | Fair Values of Derivative Instruments |
| June 29, 2019 | Other Current Assets | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 8 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 4 |  |  | $ | 3 |  |
| Total derivatives | $ | 12 |  |  | $ | 3 |  |

[0000068505-19-000019:notes:121]
[same as prior period, unchanged from 0000068505-19-000013:notes:100]

[0000068505-19-000019:notes:122]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended June 29, 2019 and June 30, 2018:

[0000068505-19-000019:notes:123]
|  | Three Months Ended |  | Six Months Ended |  | Financial Statement Location |
| Foreign Exchange Contracts | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |  |
| Effective portion | $ | 6 |  |  | $ | 5 |  |  | $ | 8 |  |  | $ | 2 |  |  | Accumulated othercomprehensive income |
| Forward points recognized | 2 |  |  | — |  |  | 3 |  |  | — |  |  | Other income |
| Undesignated derivatives recognized | (3 | ) |  | (19 | ) |  | (7 | ) |  | (23 | ) |  | Other expense |

[0000068505-19-000019:notes:124]
[same as prior period, unchanged from 0000068505-19-000013:notes:103]

[0000068505-19-000019:notes:125]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investment being hedged, until the investment is sold or liquidated. In accordance with ASU 2017-02, the Company has elected to exclude the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. As of June 29, 2019, the Company had €95 million of net investment hedges in certain Euro functional subsidiaries and £100 million of net investment hedges in certain British pound functional subsidiaries. During the three and six months ended June 29, 2019, the Company amortized $2 million and $3 million, respectively, of income from the excluded components through interest expense.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-19-000019:notes:126]
Income Taxes
At the end of each interim reporting period, the Company makes an estimate of its annual effective income tax rate. Tax expense in interim periods is calculated at the estimated annual effective tax rate plus or minus the tax effects of items of income and expense that are discrete to the period. The estimate used in providing for income taxes on a year-to-date basis may change in subsequent interim periods.

[0000068505-19-000019:notes:127]
[same as prior period, unchanged from 0000068505-19-000013:notes:145]

[0000068505-19-000019:notes:128]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Net earnings before income taxes | $ | 275 |  |  | $ | 227 |  |  | $ | 460 |  |  | $ | 367 |  |
| Income tax expense | 67 |  |  | 46 |  |  | 100 |  |  | 69 |  |
| Effective tax rate | 24 | % |  | 20 | % |  | 22 | % |  | 19 | % |

[0000068505-19-000019:notes:129]
During the three and six months ended June 29, 2019, the Company recorded $67 million and $100 million of net tax expense, resulting in effective tax rates of 24% and 22%, respectively. During the three and six months ended June 30, 2018, the Company recorded $46 million and $69 million of net tax expense, resulting in effective tax rates of 20% and 19%, respectively. The three and six months ended June 29, 2019 effective tax rates include state tax expense, offset by excess tax benefits on share-based compensation. The effective tax rates for the three and six months ended June 29, 2019 of 24% and 22%, respectively, is higher than the effective tax rates for the three and six months ended June 30, 2018 of 20% and 19%, respectively, primarily due to a favorable settlement of a state audit in 2018.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-19-000019:notes:130]
Retirement and Other Employee Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-19-000019:notes:131]
The net periodic benefits for Pension and Postretirement Health Care Benefits Plans were as follows:

[0000068505-19-000019:notes:132]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 51 |  |  | 46 |  |  | 10 |  |  | 10 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (69 | ) |  | (68 | ) |  | (21 | ) |  | (24 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 12 |  |  | 14 |  |  | 4 |  |  | 3 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Net periodic pension benefits | $ | (6 | ) |  | $ | (8 | ) |  | $ | (6 | ) |  | $ | (10 | ) |  | $ | (5 | ) |  | $ | (5 | ) |

[0000068505-19-000019:notes:133]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 102 |  |  | 92 |  |  | 20 |  |  | 20 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (138 | ) |  | (136 | ) |  | (42 | ) |  | (48 | ) |  | (5 | ) |  | (5 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 23 |  |  | 28 |  |  | 8 |  |  | 6 |  |  | 2 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | (7 | ) |
| Net periodic pension benefits | $ | (13 | ) |  | $ | (16 | ) |  | $ | (12 | ) |  | $ | (20 | ) |  | $ | (9 | ) |  | $ | (9 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-19-000019:notes:134]
Share-Based Compensation Plans
Compensation expense for the Company’s share-based plans was as follows:

[0000068505-19-000019:notes:135]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 3 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 5 |  |
| Selling, general and administrative expenses | 15 |  |  | 11 |  |  | 31 |  |  | 21 |  |
| Research and development expenditures | 12 |  |  | 4 |  |  | 19 |  |  | 8 |  |
| Share-based compensation expense included in Operating earnings | 30 |  |  | 17 |  |  | 57 |  |  | 34 |  |
| Tax benefit | (5 | ) |  | (4 | ) |  | (10 | ) |  | (8 | ) |
| Share-based compensation expense, net of tax | $ | 25 |  |  | $ | 13 |  |  | $ | 47 |  |  | $ | 26 |  |
| Decrease in basic earnings per share | $ | (0.15 | ) |  | $ | (0.08 | ) |  | $ | (0.29 | ) |  | $ | (0.16 | ) |
| Decrease in diluted earnings per share | $ | (0.14 | ) |  | $ | (0.08 | ) |  | $ | (0.27 | ) |  | $ | (0.15 | ) |

[0000068505-19-000019:notes:136]
During the six months ended June 29, 2019, the Company granted 0.5 million restricted stock units ("RSUs") and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $64 million and $7 million, respectively, and

[0000068505-19-000019:notes:137]
0.2 million stock options and 0.2 million performance options ("POs") with an aggregate grant-date fair value of $6 million and $7 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.

[0000068505-19-000019:notes:138]
During the six months ended June 29, 2019, the Company granted an additional 0.4 million of restricted stock in connection with the acquisition of VaaS, with an aggregate grant-date fair value of $38 million related to compensation withheld from the purchase price that will be expensed over an average service period of one year.

[0000068505-19-000019:notes:139]
During the three months ended June 29, 2019, the Company approved the grant of performance stock units ("PSUs") as a portion of the Long Range Incentive Plan ("LRIP") awards issued to certain Company executive officers with an aggregate grant-date fair value of $5.5 million. The 2019 PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual total shareholder return ("TSR") compared to the S&P 500 over the three-year performance period.

[0000068505-19-000019:notes:140]
The Company calculates the value of each PSU using the Monte Carlo simulation, estimated on the date of grant. Each PSU was granted with a fair value of $203.61. The following assumptions were used for the calculations.

[0000068505-19-000019:notes:141]
|  | 2019 PSUs |
| Expected volatility of common stock | 20.6 | % |
| Expected volatility of the S&P 500 | 25.0 | % |
| Risk-free interest rate | 2.2 | % |
| Dividend yield | 1.6 | % |

[0000068505-19-000019:notes:142]
Subsequent to the six months ended June 29, 2019, the Company granted restricted stock and restricted stock units in connection with the acquisition of WatchGuard for an aggregate grant date fair value of $16 million that will be expensed over an average service period of two years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-19-000019:notes:143]
Fair Value Measurements
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-19-000019:notes:144]
[same as prior period, unchanged from 0000068505-19-000013:notes:112]

[0000068505-19-000019:notes:145]
[same as prior period, unchanged from 0000068505-19-000013:notes:113]

[0000068505-19-000019:notes:146]
[same as prior period, unchanged from 0000068505-19-000013:notes:114]

[0000068505-19-000019:notes:147]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of June 29, 2019 and December 31, 2018 were as follows:

[0000068505-19-000019:notes:148]
| June 29, 2019 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 12 |  |  | $ | 12 |  |
| Common stock | 42 |  |  | — |  |  | 42 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |

[0000068505-19-000019:notes:149]
| December 31, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Corporate bonds | 1 |  |  | — |  |  | 1 |  |
| Common stock | 19 |  |  | — |  |  | 19 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |

[0000068505-19-000019:notes:150]
The Company had no Level 3 holdings as of June 29, 2019 or December 31, 2018.

[0000068505-19-000019:notes:151]
At June 29, 2019 and December 31, 2018, the Company had $419 million and $734 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-19-000019:notes:152]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at June 29, 2019 and December 31, 2018 was $5.6 billion and $5.4 billion (Level 2), respectively.

[0000068505-19-000019:notes:153]
[same as prior period, unchanged from 0000068505-19-000013:notes:118]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-19-000019:notes:154]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-19-000019:notes:155]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Condensed Consolidated Balance Sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $53 million at June 29, 2019, compared to $62 million at December 31, 2018.

[0000068505-19-000019:notes:156]
[same as prior period, unchanged from 0000068505-19-000013:notes:13]

[0000068505-19-000019:notes:157]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended June 29, 2019 and June 30, 2018:

[0000068505-19-000019:notes:158]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Accounts receivable sales proceeds | $ | 3 |  |  | $ | 22 |  |  | $ | 27 |  |  | $ | 76 |  |
| Long-term receivables sales proceeds | 55 |  |  | 15 |  |  | 76 |  |  | 28 |  |
| Total proceeds from receivable sales | $ | 58 |  |  | $ | 37 |  |  | $ | 103 |  |  | $ | 104 |  |

[0000068505-19-000019:notes:159]
At June 29, 2019, the Company had retained servicing obligations for $971 million of long-term receivables, compared to $970 million at December 31, 2018. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-19-000019:notes:160]
Commitments and Contingencies
Legal Matters

[0000068505-19-000019:notes:161]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-19-000019:notes:162]
Other Indemnifications

[0000068505-19-000019:notes:163]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-19-000019:notes:164]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at June 29, 2019.

[0000068505-19-000019:notes:165]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-19-000019:notes:166]
Segment Information
The following table summarizes Net sales by segment:

[0000068505-19-000019:notes:167]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Products and Systems Integration | $ | 1,238 |  |  | $ | 1,189 |  |  | $ | 2,307 |  |  | $ | 2,141 |  |
| Services and Software | 622 |  |  | 571 |  |  | 1,210 |  |  | 1,086 |  |
|  | $ | 1,860 |  |  | $ | 1,760 |  |  | $ | 3,517 |  |  | $ | 3,227 |  |

[0000068505-19-000019:notes:168]
The following table summarizes the Operating earnings by segment:

[0000068505-19-000019:notes:169]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Products and Systems Integration | $ | 201 |  |  | $ | 175 |  |  | $ | 310 |  |  | $ | 265 |  |
| Services and Software | 148 |  |  | 98 |  |  | 269 |  |  | 180 |  |
| Operating earnings | 349 |  |  | 273 |  |  | 579 |  |  | 445 |  |
| Total other expense | (74 | ) |  | (46 | ) |  | (119 | ) |  | (78 | ) |
| Earnings before income taxes | $ | 275 |  |  | $ | 227 |  |  | $ | 460 |  |  | $ | 367 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-19-000019:notes:170]
Reorganization of Business
2019 Charges

[0000068505-19-000019:notes:171]
During the three months ended June 29, 2019, the Company recorded net reorganization of business charges of $12 million including $8 million of charges in Other charges and $4 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $12 million were charges of $18 million related to employee separation, partially offset by $6 million of reversals for accruals no longer needed.

[0000068505-19-000019:notes:172]
During the six months ended June 29, 2019, the Company recorded net reorganization of business charges of $20 million including $12 million of charges in Other charges and $8 million of charges in Costs of sales in the Company's Condensed

[0000068505-19-000019:notes:173]
Consolidated Statements of Operations. Included in the $20 million were charges of $30 million related to employee separation, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-19-000019:notes:174]
The following table displays the net charges incurred by segment:

[0000068505-19-000019:notes:175]
| June 29, 2019 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 9 |  |  | $ | 16 |  |
| Services and Software | 3 |  |  | 4 |  |
|  | $ | 12 |  |  | $ | 20 |  |

[0000068505-19-000019:notes:176]
The following table displays a rollforward of the reorganization of business accruals established for employee separation costs from January 1, 2019 to June 29, 2019:

[0000068505-19-000019:notes:177]
|  | January 1, 2019 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | June 29, 2019 |
| Employee separation costs | $ | 84 |  |  | $ | 30 |  |  | $ | (10 | ) |  | $ | (28 | ) |  | $ | 76 |  |

[0000068505-19-000019:notes:178]
[same as prior period, unchanged from 0000068505-19-000013:notes:186]

[0000068505-19-000019:notes:179]
At January 1, 2019, the Company had an accrual of $84 million for employee separation costs. The 2019 additional charges of $30 million represent severance costs for approximately 300 employees. The adjustment of $10 million reflects reversals for accruals no longer needed. The $28 million used reflects cash payments to severed employees. The remaining accrual of $76 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at June 29, 2019, is expected to be paid, primarily within one year, to approximately 900 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-19-000019:notes:180]
As of January 1, 2019, accruals for exit costs are included in Operating lease liabilities with an offsetting impairment to the Company's ROU assets; all within its Condensed Consolidated Balance Sheets (see Note 3).

[0000068505-19-000019:notes:181]
[same as prior period, unchanged from 0000068505-19-000013:notes:189]

[0000068505-19-000019:notes:182]
During the three months ended June 30, 2018, the Company recorded net reorganization of business charges of $25 million including $18 million of charges in Other charges and $7 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $27 million related to employee separation costs and $1 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-19-000019:notes:183]
During the six months ended June 30, 2018, the Company recorded net reorganization of business charges of $38 million including $26 million of charges in Other charges and $12 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $38 million were charges of $49 million related to employee separation costs and $3 million related to exit costs, partially offset by $14 million of reversals for accruals no longer needed.

[0000068505-19-000019:notes:184]
| June 30, 2018 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 19 |  |  | $ | 28 |  |
| Services and Software | 6 |  |  | 10 |  |
|  | $ | 25 |  |  | $ | 38 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-19-000019:notes:185]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company's condensed consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-19-000019:notes:186]
On July 11, 2019, the Company acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million, net of cash acquired. The acquisition expands the Company's video security solutions platform. The business will be part of both the Products and Systems Integration and Services and Software segments. The purchase accounting for this acquisition will commence in the third quarter of 2019.

[0000068505-19-000019:notes:187]
On March 11, 2019, the Company announced that it acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands the Company's commercial portfolio with new capabilities, allowing it to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities. The business will be part of both the Products and Systems Integration and Services and Software segments. The Company recognized $68 million of goodwill, $64 million of identifiable intangible assets, and $4 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $43 million of completed technology and $21 million of customer relationship intangibles and will be amortized over a period of 15 years. The purchase accounting is not yet complete and as such the final allocation between goodwill and net assets may be subject to change based on the finalization of working capital considerations.

[0000068505-19-000019:notes:188]
On January 7, 2019, the Company announced that it acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million to be utilized in the purchase price allocation. The business will be part of both the Products and Systems Integration and Services and Software segments. The Company recognized $261 million of goodwill, $141 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $99 million of completed technology that will be amortized over a period of ten years and $42 million of customer relationship intangibles that will be amortized over a period of 15 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts, goodwill, and net liabilities may be subject to change based on the settlement of working capital considerations.

[0000068505-19-000019:notes:189]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. Prior to the end of the first quarter of 2018, $35 million of the assumed debt was repaid with the remaining $40 million repaid during the second quarter of 2018. The Company recognized $498 million of identifiable intangible assets, $434 million of goodwill, and$42 million of net assets. Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to twenty years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them. Goodwill was calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. The goodwill is not deductible for tax purposes.

[0000068505-19-000019:notes:190]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million in cash, net cash acquired. This acquisition expanded the Company's software portfolio in the command center with additional solutions for Next Generation 9-1-1. The Company recognized $160 million of goodwill, $80 million of identifiable intangible assets, and $3 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of ten to twenty years.

[0000068505-19-000019:notes:191]
[same as prior period, unchanged from 0000068505-19-000013:notes:126]

[0000068505-19-000019:notes:192]
Any devices from these acquisitions are included within the Products and Systems Integration segment and services and software offerings from these acquisitions are included in the Services and Software segment.

[0000068505-19-000019:notes:193]
[same as prior period, unchanged from 0000068505-19-000013:notes:136]

[0000068505-19-000019:notes:194]
[same as prior period, unchanged from 0000068505-19-000013:notes:137]

[0000068505-19-000019:notes:195]
|  | June 29, 2019 |  | December 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 701 |  |  | $ | 119 |  |  | $ | 558 |  |  | $ | 92 |  |
| Customer-related | 1,147 |  |  | 434 |  |  | 1,085 |  |  | 364 |  |
| Other intangibles | 76 |  |  | 39 |  |  | 76 |  |  | 33 |  |
|  | $ | 1,924 |  |  | $ | 592 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-19-000019:notes:196]
Amortization expense on intangible assets was $52 million for the three months ended June 29, 2019 and $102 million for the six months ended June 29, 2019. Amortization expense on intangible assets was $53 million for the three months ended June 30, 2018 and $94 million for the six months ended June 30, 2018. As of June 29, 2019, annual amortization expense is

[0000068505-19-000019:notes:197]
estimated to be $204 million in 2019, $200 million 2020, $198 million in 2021, $195 million in 2022, $98 million in 2023, and $73 million in 2024.

[0000068505-19-000019:notes:198]
Amortized intangible assets were comprised of the following by segment:

[0000068505-19-000019:notes:199]
|  | June 29, 2019 |  | December 31, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 610 |  |  | $ | 59 |  |  | $ | 510 |  |  | $ | 38 |  |
| Services and Software | 1,314 |  |  | 533 |  |  | 1,209 |  |  | 451 |  |
|  | $ | 1,924 |  |  | $ | 592 |  |  | $ | 1,719 |  |  | $ | 489 |  |

[0000068505-19-000019:notes:200]
[same as prior period, unchanged from 0000068505-19-000013:notes:140]

[0000068505-19-000019:notes:201]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2019 to June 29, 2019:

[0000068505-19-000019:notes:202]
|  | Products and Systems Integration |  | Services and Software |  | Total |
| Balance as of January 1, 2019 | $ | 722 |  |  | $ | 792 |  |  | $ | 1,514 |  |
| Goodwill acquired | 146 |  |  | 183 |  |  | 329 |  |
| Purchase accounting adjustments | — |  |  | 9 |  |  | 9 |  |
| Balance as of June 29, 2019 | $ | 868 |  |  | $ | 984 |  |  | $ | 1,852 |  |
