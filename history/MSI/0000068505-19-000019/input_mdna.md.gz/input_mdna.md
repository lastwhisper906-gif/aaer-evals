# MSI MD&A — 0000068505-19-000019


## mdna

[0000068505-19-000019:mdna:1]
[same as prior period, unchanged from 0000068505-19-000013:mdna:1]

[0000068505-19-000019:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended June 29, 2019 and June 30, 2018, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2018.

[0000068505-19-000019:mdna:3]
[same as prior period, unchanged from 0000068505-19-000013:mdna:4]

[0000068505-19-000019:mdna:4]
[same as prior period, unchanged from 0000068505-19-000013:mdna:5]

[0000068505-19-000019:mdna:5]
On July 11, 2019, we acquired WatchGuard, Inc. ("WatchGuard"), a provider of in-car and body-worn video solutions for $271 million, inclusive of share-based compensation withheld at a fair value of $16 million that will be expensed over an average service period of two years. The acquisition was settled with $250 million of cash, net of cash acquired. The acquisition expands our video security solutions platform.

[0000068505-19-000019:mdna:6]
On March 11, 2019, we announced that we acquired Avtec, Inc. ("Avtec"), a provider of dispatch communication equipment for U.S. public safety and commercial customers for a purchase price of $136 million in cash, net of cash acquired. This acquisition expands our commercial portfolio with new capabilities, allowing us to offer an enhanced platform for customers to communicate, coordinate resources, and secure their facilities.

[0000068505-19-000019:mdna:7]
On January 7, 2019, we announced that we acquired VaaS International Holdings ("VaaS"), a company that is a global provider of data and image analytics for vehicle location for $445 million, inclusive of share-based compensation withheld at a fair value of $38 million that will be expensed over an average service period of one year. The acquisition was settled with $231 million of cash, net of cash acquired, and 1.4 million of shares issued at a fair value of $160 million for a purchase price of $391 million.

[0000068505-19-000019:mdna:8]
We reached an agreement with the U.K. Home Office during the third quarter of 2018 on terms for the new direction of the U.K. Emergency Services Network (“ESN”). During the second quarter of 2019, we finalized an extension, through 2024, of $200 million for the ESN contract.

[0000068505-19-000019:mdna:9]
On March 28, 2018, we completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced security and video solutions including video analytics, network video management hardware and software, video cameras and access control solutions for a purchase price of $974 million in cash, net of cash acquired, debt assumed, and transaction costs paid.

[0000068505-19-000019:mdna:10]
On March 7, 2018, we completed the acquisition of Plant Holdings, Inc. ("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million in cash, net of cash acquired. This acquisition expanded our software portfolio in the command center with additional solutions for Next Generation 9-1-1.

[0000068505-19-000019:mdna:11]
[same as prior period, unchanged from 0000068505-19-000013:mdna:11]

[0000068505-19-000019:mdna:12]
We are a leading global provider of mission-critical communications. Our technology platforms in communications, software, video security, and services make cities safer and help communities and businesses thrive. We serve our customers with a global footprint of sales in more than 100 countries and 17,000 employees worldwide based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-19-000019:mdna:13]
[same as prior period, unchanged from 0000068505-19-000013:mdna:13]

[0000068505-19-000019:mdna:14]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video security solutions, such as video cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video security solutions typically managing a mobile workforce. In the second quarter of 2019, the segment’s net sales were $1.2 billion, representing 67% of our consolidated net sales.

[0000068505-19-000019:mdna:15]
Services and Software: The Services and Software segment provides a broad range of solution offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer or Motorola Solutions-owned networks. Software includes a public safety and enterprise command center software suite, unified communications applications, and video software solutions, delivered both on premise and “as a service.” In the second quarter of 2019, the segment’s net sales were $622 million, representing 33% of our consolidated net sales.

[0000068505-19-000019:mdna:16]
28

[0000068505-19-000019:mdna:17]
Second Quarter Financial Results

[0000068505-19-000019:mdna:18]
| • | Net sales were $1.9 billion in the second quarter of 2019 compared to $1.8 billion in the second quarter of 2018. The increase is driven by growth in the Americas. |

[0000068505-19-000019:mdna:19]
| • | Operating earnings were $349 million in the second quarter of 2019 compared to $273 million in the second quarter of 2018. |

[0000068505-19-000019:mdna:20]
| • | Earnings attributable to Motorola Solutions, Inc. were $207 million, or $1.18 per diluted common share, in the second quarter of 2019, compared to $180 million, or $1.05 per diluted common share, in the second quarter of 2018. |

[0000068505-19-000019:mdna:21]
| • | Our operating cash flow increased $577 million to $502 million in the first half of 2019 compared to the first half of 2018. The increase is primarily driven by the $500 million debt-funded, voluntary contribution to our U.S. pension plan in the first half of 2018, compared to no material contributions to our U.S. pension plans in the first half of 2019. |

[0000068505-19-000019:mdna:22]
| • | We repurchased $170 million of common stock and paid $187 million in dividends in the first half of 2019. |

[0000068505-19-000019:mdna:23]
[same as prior period, unchanged from 0000068505-19-000013:mdna:22]

[0000068505-19-000019:mdna:24]
A summary of our segment results for the second quarter of 2019 is as follows:

[0000068505-19-000019:mdna:25]
| • | In the Products and Systems Integration segment, net sales were $1.2 billion in the second quarter of 2019, an increase of $49 million, or 4%, compared to $1.2 billion in the second quarter of 2018. On a geographic basis, net sales increased in the Americas, partially offset by a decline in sales in the other regions, compared to the year-ago quarter. Operating earnings were $201 million in the second quarter of 2019, compared to $175 million in the second quarter of 2018. Operating margin increased in 2019 to 16.2% from 14.7% in 2018 driven by higher sales and gross margin, partially offset by higher operating expenses related to acquisitions and our video security solutions portfolio. |

[0000068505-19-000019:mdna:26]
| • | In the Services and Software segment, net sales were $622 million in the second quarter of 2019, an increase of $51 million, or 9%, compared to net sales of $571 million in the second quarter of 2018. On a geographic basis, net sales increased in the Americas and EMEA, partially offset by a decline in sales in AP, compared to the year-ago quarter. Operating earnings were $148 million in the second quarter of 2019, compared to $98 million in the second quarter of 2018. Operating margin increased in 2019 to 23.8% from 17.2% in 2018 driven by higher sales and gross margin. |

[0000068505-19-000019:mdna:27]
29

[0000068505-19-000019:mdna:28]
[same as prior period, unchanged from 0000068505-19-000013:mdna:27]

[0000068505-19-000019:mdna:29]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | June 29, 2019 |  | % ofSales* |  | June 30, 2018 |  | % ofSales* |  | June 29, 2019 |  | % ofSales* |  | June 30, 2018 |  | % ofSales* |
| Net sales from products | $ | 1,118 |  |  |  |  | $ | 1,042 |  |  |  |  | $ | 2,063 |  |  |  |  | $ | 1,842 |  |  |  |
| Net sales from services | 742 |  |  |  |  | 718 |  |  |  |  | 1,454 |  |  |  |  | 1,385 |  |  |  |
| Net sales | 1,860 |  |  |  |  | 1,760 |  |  |  |  | 3,517 |  |  |  |  | 3,227 |  |  |  |
| Costs of products sales | 490 |  |  | 43.8 | % |  | 485 |  |  | 46.5 | % |  | 934 |  |  | 45.3 | % |  | 867 |  |  | 47.1 | % |
| Costs of services sales | 439 |  |  | 59.2 | % |  | 453 |  |  | 63.1 | % |  | 879 |  |  | 60.5 | % |  | 869 |  |  | 62.7 | % |
| Costs of sales | 929 |  |  |  |  | 938 |  |  |  |  | 1,813 |  |  |  |  | 1,736 |  |  |  |
| Gross margin | 931 |  |  | 50.1 | % |  | 822 |  |  | 46.7 | % |  | 1,704 |  |  | 48.5 | % |  | 1,491 |  |  | 46.2 | % |
| Selling, general and administrative expenses | 351 |  |  | 18.9 | % |  | 316 |  |  | 18.0 | % |  | 676 |  |  | 19.2 | % |  | 594 |  |  | 18.4 | % |
| Research and development expenditures | 170 |  |  | 9.1 | % |  | 162 |  |  | 9.2 | % |  | 333 |  |  | 9.5 | % |  | 314 |  |  | 9.7 | % |
| Other charges | 61 |  |  | 3.3 | % |  | 71 |  |  | 4.0 | % |  | 116 |  |  | 3.3 | % |  | 138 |  |  | 4.3 | % |
| Operating earnings | 349 |  |  | 18.8 | % |  | 273 |  |  | 15.5 | % |  | 579 |  |  | 16.5 | % |  | 445 |  |  | 13.8 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (56 | ) |  | (3.0 | )% |  | (58 | ) |  | (3.3 | )% |  | (111 | ) |  | (3.2 | )% |  | (104 | ) |  | (3.2 | )% |
| Gains (losses) on sales of investments and businesses, net | 3 |  |  | 0.2 | % |  | (1 | ) |  | (0.1 | )% |  | 4 |  |  | 0.1 | % |  | 10 |  |  | 0.3 | % |
| Other, net | (21 | ) |  | (1.1 | )% |  | 13 |  |  | 0.7 | % |  | (12 | ) |  | (0.3 | )% |  | 16 |  |  | 0.5 | % |
| Total other expense | (74 | ) |  | (4.0 | )% |  | (46 | ) |  | (2.6 | )% |  | (119 | ) |  | (3.4 | )% |  | (78 | ) |  | (2.4 | )% |
| Net earnings before income taxes | 275 |  |  | 14.8 | % |  | 227 |  |  | 12.9 | % |  | 460 |  |  | 13.1 | % |  | 367 |  |  | 11.4 | % |
| Income tax expense | 67 |  |  | 3.6 | % |  | 46 |  |  | 2.6 | % |  | 100 |  |  | 2.8 | % |  | 69 |  |  | 2.1 | % |
| Net earnings | 208 |  |  | 11.2 | % |  | 181 |  |  | 10.3 | % |  | 360 |  |  | 10.2 | % |  | 298 |  |  | 9.2 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |  | 1 |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 207 |  |  | 11.1 | % |  | $ | 180 |  |  | 10.2 | % |  | $ | 358 |  |  | 10.2 | % |  | $ | 297 |  |  | 9.2 | % |
| Earnings per diluted common share | $ | 1.18 |  |  |  |  |  | $ | 1.05 |  |  |  |  |  | $ | 2.04 |  |  |  |  | $ | 1.73 |  |  |  |

[0000068505-19-000019:mdna:30]
[same as prior period, unchanged from 0000068505-19-000013:mdna:29]

[0000068505-19-000019:mdna:31]
[same as prior period, unchanged from 0000068505-19-000013:mdna:89]

[0000068505-19-000019:mdna:32]
Results of Operations—Three months ended June 29, 2019 compared to three months ended June 30, 2018

[0000068505-19-000019:mdna:33]
The results of operations for the second quarter of 2019 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-19-000019:mdna:34]
[same as prior period, unchanged from 0000068505-19-000013:mdna:33]

[0000068505-19-000019:mdna:35]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 1,238 |  |  | $ | 1,189 |  |  | 4 | % |
| Net sales from Services and Software | 622 |  |  | 571 |  |  | 9 | % |
| Net sales | $ | 1,860 |  |  | $ | 1,760 |  |  | 6 | % |

[0000068505-19-000019:mdna:36]
The Products and Systems Integration segment’s net sales represented 67% of our consolidated net sales in the second quarter of 2019 and 68% in the second quarter of 2018. The Services and Software segment’s net sales represented 33% of our consolidated net sales in the second quarter of 2019 and 32% in the second quarter of 2018.

[0000068505-19-000019:mdna:37]
Net sales were up $100 million, or 6%, compared to the second quarter of 2018. The increase in net sales was driven by the Americas, partially offset by a sales decline in EMEA and AP, with a 4% increase in the Products and Systems Integration segment and a 9% increase in the Services and Software segment. This growth includes:

[0000068505-19-000019:mdna:38]
| • | growth in Devices primarily due to strong demand in the Americas inclusive of acquisitions; |

[0000068505-19-000019:mdna:39]
| • | $33 million of revenue from the acquisitions of VaaS and Avtec; and |

[0000068505-19-000019:mdna:40]
| • | partially offset by $37 million from unfavorable currency rates. |

[0000068505-19-000019:mdna:41]
[same as prior period, unchanged from 0000068505-19-000013:mdna:39]

[0000068505-19-000019:mdna:42]
| • | growth in the Americas region of 11% across both the Products and Systems Integration and the Services and Software segments, inclusive of revenue from acquisitions; |

[0000068505-19-000019:mdna:43]
| • | a decline in the EMEA region of 7% primarily due to two large system deployments in the Middle East and Africa within the Systems and Systems Integration portion of our Products and Systems Integration segment in the second quarter of 2018 and currency headwinds, partially offset by growth within Europe; and |

[0000068505-19-000019:mdna:44]
| • | a decline in the AP region of 7% due to currency headwinds and lower sales in China. |

[0000068505-19-000019:mdna:45]
[same as prior period, unchanged from 0000068505-19-000013:mdna:43]

[0000068505-19-000019:mdna:46]
The 4% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000019:mdna:47]
| • | $16 million of revenue from the acquisitions of VaaS and Avtec which closed in the first quarter of 2019; |

[0000068505-19-000019:mdna:48]
| • | 12% growth in Devices revenue primarily due to strong demand for land mobile radio ("LMR") and video cameras in the Americas inclusive of revenue from acquisitions; and |

[0000068505-19-000019:mdna:49]
| • | partially offset by an 8% decline in Systems and Systems Integration revenue in the second quarter of 2019, as compared to the second quarter of 2018 primarily due to two large system deployments in the Middle East and Africa in the second quarter of 2018. |

[0000068505-19-000019:mdna:50]
[same as prior period, unchanged from 0000068505-19-000013:mdna:48]

[0000068505-19-000019:mdna:51]
The 9% increase in the Services and Software segment was driven by the following:

[0000068505-19-000019:mdna:52]
| • | $17 million of revenue from the acquisitions of VaaS and Avtec, which closed in the first quarter of 2019; |

[0000068505-19-000019:mdna:53]
| • | 34% growth in Software, driven primarily by growth in our video security solutions portfolio and command center software sales inclusive of acquisitions; and |

[0000068505-19-000019:mdna:54]
| • | 3% growth in Services, driven by growth in maintenance revenue, partially offset by unfavorable currency headwinds. |

[0000068505-19-000019:mdna:55]
[same as prior period, unchanged from 0000068505-19-000013:mdna:53]

[0000068505-19-000019:mdna:56]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Gross margin | $ | 931 |  |  | $ | 822 |  |  | 13 | % |

[0000068505-19-000019:mdna:57]
Gross margin was 50.1% of net sales in the second quarter of 2019 compared to 46.7% in the second quarter of 2018. The primary drivers of the increase are as follows:

[0000068505-19-000019:mdna:58]
| • | higher margins in the Products and Systems Integration segment driven by a favorable mix of Devices to Systems and Systems Integration, as well as higher margin contribution from the acquisitions of VaaS and Avtec; and |

[0000068505-19-000019:mdna:59]
| • | higher margins within the Services and Software segment primarily driven by operational efficiencies in service delivery costs of our Services portfolio and higher margin contribution within our Software portfolio from acquisitions. |

[0000068505-19-000019:mdna:60]
[same as prior period, unchanged from 0000068505-19-000013:mdna:58]

[0000068505-19-000019:mdna:61]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 351 |  |  | $ | 316 |  |  | 11 | % |

[0000068505-19-000019:mdna:62]
SG&A expenses increased 11% compared to the second quarter of 2018. SG&A expenses were 18.9% of net sales compared to 18.0% of net sales in the second quarter of 2018. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses and our video security solutions portfolio.

[0000068505-19-000019:mdna:63]
[same as prior period, unchanged from 0000068505-19-000013:mdna:61]

[0000068505-19-000019:mdna:64]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Research and development expenditures | $ | 170 |  |  | $ | 162 |  |  | 5 | % |

[0000068505-19-000019:mdna:65]
R&D expenditures increased 5% primarily due to increased expenses associated with acquired businesses. R&D expenditures were 9.1% of net sales compared to 9.2% of net sales in the second quarter of 2018.

[0000068505-19-000019:mdna:66]
[same as prior period, unchanged from 0000068505-19-000013:mdna:64]

[0000068505-19-000019:mdna:67]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Other charges | $ | 61 |  |  | $ | 71 |  |

[0000068505-19-000019:mdna:68]
The reduction of Other charges in the second quarter of 2019 as compared to the second quarter of 2018 is due to $8 million of net reorganization of business charges in the second quarter of 2019 as compared to $18 million in the second quarter of 2018, (see further detail in “Reorganization of Businesses” section).

[0000068505-19-000019:mdna:69]
[same as prior period, unchanged from 0000068505-19-000013:mdna:70]

[0000068505-19-000019:mdna:70]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Operating earnings from Products and Systems Integration | $ | 201 |  |  | $ | 175 |  |
| Operating earnings from Services and Software | 148 |  |  | 98 |  |
| Operating earnings | $ | 349 |  |  | $ | 273 |  |

[0000068505-19-000019:mdna:71]
Operating earnings were up $76 million, or 28%, compared to the second quarter of 2018. The increase in Operating earnings was due to:

[0000068505-19-000019:mdna:72]
| • | Services and Software segment, which was up $50 million from the second quarter of 2018 compared to the second quarter of 2019, primarily driven by higher sales and gross margin; and |

[0000068505-19-000019:mdna:73]
| • | Products and Systems Integration, which was up $26 million from the second quarter of 2018 compared to the second quarter of 2019, driven by higher sales and gross margin, partially offset by higher operating expenses related to acquisitions and our video security solutions portfolio. |

[0000068505-19-000019:mdna:74]
Interest Expense, net

[0000068505-19-000019:mdna:75]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Interest expense, net | $ | (56 | ) |  | $ | (58 | ) |

[0000068505-19-000019:mdna:76]
The decrease in net interest expense in the second quarter of 2019 compared to the second quarter of 2018 was a result of less average debt outstanding as of and for the period ending June 29, 2019 as compared to the period ending June 30, 2018.

[0000068505-19-000019:mdna:77]
[same as prior period, unchanged from 0000068505-19-000013:mdna:78]

[0000068505-19-000019:mdna:78]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Gains (losses) on sales of investments and businesses, net | $ | 3 |  |  | $ | (1 | ) |

[0000068505-19-000019:mdna:79]
Net gains on sales of investments and businesses were $3 million in the second quarter of 2019 compared to losses of $1 million during the second quarter of 2018. The net gain in the second quarter of 2019 was related to the sale of our two-way communications rental business while the net losses in the second quarter of 2018 were related to the sale of various strategic investments.

[0000068505-19-000019:mdna:80]
Other, net

[0000068505-19-000019:mdna:81]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Other, net | $ | (21 | ) |  | $ | 13 |  |

[0000068505-19-000019:mdna:82]
The net Other expense in the second quarter of 2019 as compared to the net Other income in the second quarter of 2018 was primarily driven by:

[0000068505-19-000019:mdna:83]
| • | a $43 million loss from the extinguishment of long-term debt in the second quarter of 2019; |

[0000068505-19-000019:mdna:84]
| • | foreign currency losses of $7 million in the second quarter of 2019 as compared to $11 million of gains in the second quarter of 2018; |

[0000068505-19-000019:mdna:85]
| • | $17 million of net periodic pension and postretirement benefit in the second quarter of 2019 as compared to $20 million in the second quarter of 2018; and |

[0000068505-19-000019:mdna:86]
| • | $3 million of investment impairments in the second quarter of 2019; |

[0000068505-19-000019:mdna:87]
| • | partially offset by a $3 million loss on derivative instruments in the second quarter of 2019 as compared to $19 million in the second quarter of 2018; and |

[0000068505-19-000019:mdna:88]
| • | $16 million of fair value adjustments to equity investments in the second quarter of 2019. |

[0000068505-19-000019:mdna:89]
[same as prior period, unchanged from 0000068505-19-000013:mdna:90]

[0000068505-19-000019:mdna:90]
|  | Three Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Income tax expense | $ | 67 |  |  | $ | 46 |  |

[0000068505-19-000019:mdna:91]
Income tax expense increased by $21 million compared to the second quarter of 2018, for an effective tax rate of 24%. Our effective tax rate for the three months ended June 29, 2019 of 24% is higher than the effective tax rate for the three months ended June 30, 2018 of 20%, primarily due to a favorable settlement of a state audit in 2018.

[0000068505-19-000019:mdna:92]
Results of Operations—Six months ended June 29, 2019 compared to six months ended June 30, 2018

[0000068505-19-000019:mdna:93]
Net Sales

[0000068505-19-000019:mdna:94]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Net sales from Products and Systems Integration | $ | 2,307 |  |  | $ | 2,141 |  |  | 8 | % |
| Net sales from Services and Software | 1,210 |  |  | 1,086 |  |  | 11 | % |
| Net sales | $ | 3,517 |  |  | $ | 3,227 |  |  | 9 | % |

[0000068505-19-000019:mdna:95]
The Products and Systems Integration segment’s net sales represented 66% of our consolidated net sales in the first half of 2019 and 2018. The Services and Software segment’s net sales represented 34% of our consolidated net sales in the first half of 2019 and 2018.

[0000068505-19-000019:mdna:96]
Net sales were up $290 million, or 9%, compared to the first half of 2018. The increase in net sales was driven by the Americas, partially offset by a sales decline in AP, with an 8% increase in the Products and Systems Integration segment and an 11% increase in the Services and Software segment. This growth includes:

[0000068505-19-000019:mdna:97]
| • | $170 million of revenue from the acquisitions of VaaS and Avtec which closed in the first quarter of 2019 and Avigilon and Plant which were acquired towards the end of the first quarter of 2018; |

[0000068505-19-000019:mdna:98]
| • | growth in Devices due to strong demand across all regions inclusive of acquisitions; and |

[0000068505-19-000019:mdna:99]
| • | partially offset by $75 million from unfavorable currency rates. |

[0000068505-19-000019:mdna:100]
Regional results include:

[0000068505-19-000019:mdna:101]
| • | growth in the Americas region of 14% across both the Products and Systems Integration and the Services and Software segments, inclusive of revenue from acquisitions; |

[0000068505-19-000019:mdna:102]
| • | flat sales in the EMEA region primarily due to growth in both Services and Software within our Services and Software segment and Devices within our Products and Systems Integration segment, inclusive of revenue from acquisitions, offset by currency headwinds and a decline in Systems and Systems Integration within our Products and Systems Integration segment due to two large system deployments in the Middle East and Africa during the first half of 2018; and |

[0000068505-19-000019:mdna:103]
| • | a decline in the AP region of 6% due to currency headwinds and lower sales in China. |

[0000068505-19-000019:mdna:104]
Products and Systems Integration

[0000068505-19-000019:mdna:105]
The 8% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-19-000019:mdna:106]
| • | $91 million of revenue from the acquisitions of Avtec and VaaS which closed in the first quarter of 2019 and Avigilon and Plant which were acquired near the end of the first quarter of 2018; |

[0000068505-19-000019:mdna:107]
| • | 10% growth in Devices revenue primarily due to strong demand for LMR across all regions inclusive of acquisitions; and |

[0000068505-19-000019:mdna:108]
| • | 3% growth in Systems and Systems Integration revenue in the first half of 2019, as compared to the first half of 2018 driven by system deployments in the Americas and incremental revenue from Avigilon which was acquired towards the end of the first quarter of 2018. |

[0000068505-19-000019:mdna:109]
Services and Software

[0000068505-19-000019:mdna:110]
The 11% increase in the Services and Software segment was driven by the following:

[0000068505-19-000019:mdna:111]
| • | $79 million of revenue from the acquisitions of VaaS, which closed in the first quarter of 2019, and Avigilon and Plant, which were acquired near the end of the first quarter of 2018; |

[0000068505-19-000019:mdna:112]
| • | 57% growth in Software, driven primarily by revenue from our video security solutions portfolio and growth in our command center software sales inclusive of acquisitions; and |

[0000068505-19-000019:mdna:113]
| • | 2% growth in Services, driven by growth in maintenance revenues, and revenue from the acquisition of Plant, partially offset by unfavorable currency headwinds. |

[0000068505-19-000019:mdna:114]
Gross Margin

[0000068505-19-000019:mdna:115]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Gross margin | $ | 1,704 |  |  | $ | 1,491 |  |  | 14 | % |

[0000068505-19-000019:mdna:116]
Gross margin was 48.5% of net sales in the first half of 2019 compared to 46.2% in the first half of 2018. The primary drivers of the increase are as follows:

[0000068505-19-000019:mdna:117]
| • | higher margins in the Products and Systems Integration segment driven by both Devices and Systems and Systems Integration, as well as higher margin contribution from the acquisitions of VaaS and Avtec; and |

[0000068505-19-000019:mdna:118]
| • | higher margins within the Services and Software segment primarily driven by higher margin contribution within our Software portfolio from acquisitions and operational efficiencies in service delivery costs of our Services portfolio. |

[0000068505-19-000019:mdna:119]
Selling, General and Administrative Expenses

[0000068505-19-000019:mdna:120]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Selling, general and administrative expenses | $ | 676 |  |  | $ | 594 |  |  | 14 | % |

[0000068505-19-000019:mdna:121]
SG&A expenses increased 14% compared to the first half of 2018. SG&A expenses were 19.2% of net sales compared to 18.4% of net sales in the first half quarter of 2018. The increase in SG&A expenditures is primarily due to increased expenses associated with acquired businesses and our video security solutions portfolio.

[0000068505-19-000019:mdna:122]
Research and Development Expenditures

[0000068505-19-000019:mdna:123]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |  | % Change |
| Research and development expenditures | $ | 333 |  |  | $ | 314 |  |  | 6 | % |

[0000068505-19-000019:mdna:124]
R&D expenditures increased 6% primarily due to increased expenses associated with acquired businesses. R&D expenditures were 9.5% of net sales compared to 9.7% of net sales in the first half of 2018.

[0000068505-19-000019:mdna:125]
Other Charges

[0000068505-19-000019:mdna:126]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Other charges | $ | 116 |  |  | $ | 138 |  |

[0000068505-19-000019:mdna:127]
The reduction of Other charges in the first half of 2019 as compared to the first half of 2018 can be summarized as follows:

[0000068505-19-000019:mdna:128]
| • | $2 million of charges for acquisition-related transaction fees in the first half of 2019 as compared to $17 million in the first half of 2018; and |

[0000068505-19-000019:mdna:129]
| • | $12 million of net reorganization of business charges in the first half of 2019 as compared to $26 million in the first half of 2018, (see further detail in “Reorganization of Businesses” section); |

[0000068505-19-000019:mdna:130]
| • | partially offset by $102 million of amortization of intangibles in the first half of 2019 compared to $94 million in the first half of 2018, driven by acquisitions. |

[0000068505-19-000019:mdna:131]
Operating Earnings

[0000068505-19-000019:mdna:132]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Operating earnings from Products and Systems Integration | $ | 310 |  |  | $ | 265 |  |
| Operating earnings from Services and Software | 269 |  |  | 180 |  |
| Operating earnings | $ | 579 |  |  | $ | 445 |  |

[0000068505-19-000019:mdna:133]
Operating earnings were up $134 million, or 30%, compared to the first half of 2018. The increase in Operating earnings was due to:

[0000068505-19-000019:mdna:134]
| • | Services and Software segment, which was up $89 million from the first half of 2018 compared to the first half of 2019, driven by higher sales and gross margin, and partially offset by higher operating expenses related to acquisitions; and |

[0000068505-19-000019:mdna:135]
| • | Products and Systems Integration, which was up $45 million from the first half of 2018 compared to the first half of 2019, driven by higher sales and gross margin, and partially offset by higher operating expenses related to acquisitions and our video security solutions portfolio. |

[0000068505-19-000019:mdna:136]
Interest Expense, net

[0000068505-19-000019:mdna:137]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Interest expense, net | $ | (111 | ) |  | $ | (104 | ) |

[0000068505-19-000019:mdna:138]
The increase in net interest expense in the first half of 2019 compared to the first half of 2018 was a result of less average debt outstanding as of and for the period ending June 30, 2018 as compared to the period ending June 29, 2019 due to the issuance of $1.3 billion of debt towards the end of the first quarter of 2018.

[0000068505-19-000019:mdna:139]
Gains on Sales of Investments and Businesses, net

[0000068505-19-000019:mdna:140]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Gains on sales of investments and businesses, net | $ | 4 |  |  | $ | 10 |  |

[0000068505-19-000019:mdna:141]
Net gains on sales of investments and businesses were $4 million in the first half of 2019 compared to $10 million during the first half of 2018. The net gains in the first half of 2019 were related to the sale of our two-way communications rental business and various equity method investments. The net gains in the first half of 2018 were related to the sale of various strategic and equity method investments.

[0000068505-19-000019:mdna:142]
Other, net

[0000068505-19-000019:mdna:143]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Other, net | $ | (12 | ) |  | $ | 16 |  |

[0000068505-19-000019:mdna:144]
The net Other expense in the first half of 2019 as compared to the net Other income in the first half of 2018 was primarily driven by:

[0000068505-19-000019:mdna:145]
| • | a $43 million loss from the extinguishment of long-term debt in the first half of 2019; |

[0000068505-19-000019:mdna:146]
| • | foreign currency losses of $11 million in the first half of 2019; |

[0000068505-19-000019:mdna:147]
| • | $11 million of investment impairments in the first half of 2019; and |

[0000068505-19-000019:mdna:148]
| • | $33 million of net periodic pension and postretirement benefit in the first half of 2019 as compared to $40 million in the first half of 2018; |

[0000068505-19-000019:mdna:149]
| • | partially offset by a $7 million loss on derivative instruments in the first half of 2019 as compared to $23 million in the first half of 2018; |

[0000068505-19-000019:mdna:150]
| • | $15 million of fair value adjustments to equity investments in the first half of 2019; and |

[0000068505-19-000019:mdna:151]
| • | $11 million of other non-operating income in the first half of 2019 as compared to expense of $2 million in the first half of 2018. |

[0000068505-19-000019:mdna:152]
Effective Tax Rate

[0000068505-19-000019:mdna:153]
|  | Six Months Ended |
| (In millions) | June 29, 2019 |  | June 30, 2018 |
| Income tax expense | $ | 100 |  |  | $ | 69 |  |

[0000068505-19-000019:mdna:154]
Income tax expense increased by $31 million compared to the first half of 2018, for an effective tax rate of 22%. Our effective tax rate for the six months ended June 29, 2019 of 22% is higher than the effective tax rate for the six months ended June 30, 2018 of 19%, primarily due to a favorable settlement of a state tax audit in 2018.

[0000068505-19-000019:mdna:155]
[same as prior period, unchanged from 0000068505-19-000013:mdna:93]

[0000068505-19-000019:mdna:156]
During the second quarter of 2019, we recorded net reorganization of business charges of $12 million including $8 million of charges recorded within Other charges and $4 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $12 million were charges of $18 million related to employee separation costs, partially offset by $6 million of reversals for accruals no longer needed.

[0000068505-19-000019:mdna:157]
During the first half of 2019, we recorded net reorganization of business charges of $20 million including $12 million of charges in Other charges and $8 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $20 million were charges of $30 million related to employee separation, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-19-000019:mdna:158]
During the second quarter of 2018, we recorded net reorganization of business charges of $25 million including $18 million of charges in Other charges and $7 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $25 million were charges of $27 million related to employee separation costs and $1 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-19-000019:mdna:159]
During the first half of 2018, we recorded net reorganization of business charges of $38 million including $26 million of charges recorded within Other charges and $12 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $38 million were charges of $49 million related to employee separation costs and $3 million related to exit costs, partially offset by $14 million of reversals for accruals no longer needed.

[0000068505-19-000019:mdna:160]
[same as prior period, unchanged from 0000068505-19-000013:mdna:96]

[0000068505-19-000019:mdna:161]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Products and Systems Integration | $ | 9 |  |  | $ | 19 |  |  | $ | 16 |  |  | $ | 28 |  |
| Services and Software | 3 |  |  | 6 |  |  | 4 |  |  | 10 |  |
|  | $ | 12 |  |  | $ | 25 |  |  | $ | 20 |  |  | $ | 38 |  |

[0000068505-19-000019:mdna:162]
Cash payments for employee severance in connection with the reorganization of business plans were $28 million in the first half of 2019 and employee severance and exit costs were $36 million in the first half of 2018. The reorganization of business accrual at June 29, 2019 was $76 million, of which relate to employee separation costs that are expected to be paid within one year.

[0000068505-19-000019:mdna:163]
[same as prior period, unchanged from 0000068505-19-000013:mdna:99]

[0000068505-19-000019:mdna:164]
37

[0000068505-19-000019:mdna:165]
[same as prior period, unchanged from 0000068505-19-000013:mdna:100]

[0000068505-19-000019:mdna:166]
|  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 502 |  |  | $ | (75 | ) |
| Investing activities | (490 | ) |  | (1,156 | ) |
| Financing activities | (311 | ) |  | 922 |  |
| Effect of exchange rates on cash and cash equivalents | 6 |  |  | (18 | ) |
| Decrease in cash and cash equivalents | $ | (293 | ) |  | $ | (327 | ) |

[0000068505-19-000019:mdna:167]
[same as prior period, unchanged from 0000068505-19-000013:mdna:102]

[0000068505-19-000019:mdna:168]
At June 29, 2019, $552 million of the $964 million cash and cash equivalents balance was held in the U.S. and $412 million was held by us or our subsidiaries in other countries, with approximately $76 million held in the United Kingdom. Restricted cash was $11 million at June 29, 2019 and December 31, 2018.

[0000068505-19-000019:mdna:169]
[same as prior period, unchanged from 0000068505-19-000013:mdna:104]

[0000068505-19-000019:mdna:170]
The increase in operating cash flows from the first half of 2018 to the first half of 2019 was driven by (see additional discussion under "Sales of Receivables" below):

[0000068505-19-000019:mdna:171]
| • | a $500 million debt-funded voluntary contribution to our U.S. pension plan in the first half of 2018, compared to no material contributions to our U.S. pension plans in the first half of 2019; and |

[0000068505-19-000019:mdna:172]
| • | higher earnings in the first half of 2019 as compared to the first half of 2018; |

[0000068505-19-000019:mdna:173]
| • | partially offset by $19 million of higher interest payments in the first half of 2019 as compared to the first half of 2018 driven by additional debt issued towards the end of first quarter of 2018; and |

[0000068505-19-000019:mdna:174]
| • | $14 million of higher tax payments in the first half of 2019 as compared to the first half of 2018. |

[0000068505-19-000019:mdna:175]
[same as prior period, unchanged from 0000068505-19-000013:mdna:110]

[0000068505-19-000019:mdna:176]
The decrease in net cash used by investing activities from the first half of 2018 to the first half of 2019 was primarily due to:

[0000068505-19-000019:mdna:177]
| • | a $782 million decrease in acquisitions and investments, primarily driven by cash used for the purchases of VaaS and Avtec for $231 million and $136 million, respectively, as compared to the first half of 2018 when we made acquisitions of Avigilon and Plant Holdings for $903 million and $237 million, respectively; and |

[0000068505-19-000019:mdna:178]
| • | $69 million of lower proceeds from sales of investments and businesses, primarily driven by $60 million of excess cash withdrawn from company-sponsored life insurance investments in the first half of 2018; and |

[0000068505-19-000019:mdna:179]
| • | partially offset by a $47 million increase in capital expenditures in the first half of 2019 as compared to the first half of 2018, primarily due to the network builds including Airwave and ESN, as well as expenditures for Avigilon, information technology, and supply chain. |

[0000068505-19-000019:mdna:180]
[same as prior period, unchanged from 0000068505-19-000013:mdna:115]

[0000068505-19-000019:mdna:181]
The increase in cash used for financing activities in the first half of 2019 as compared to the cash provided by financing activities in the first half of 2018 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" below):

[0000068505-19-000019:mdna:182]
| • | a $650 million decrease in debt issuance in the first half of 2019 as compared to the first half of 2018; |

[0000068505-19-000019:mdna:183]
| • | a $469 million increase in the repayment of debt in the first half of 2019 as compared to the first half of 2018; |

[0000068505-19-000019:mdna:184]
| • | a $104 million increase in our share repurchases in the first half of 2019 as compared to the first half of 2018; and |

[0000068505-19-000019:mdna:185]
| • | a $19 million increase in payments of dividends in the first half of 2019 as compared to the first half of 2018. |

[0000068505-19-000019:mdna:186]
38

[0000068505-19-000019:mdna:187]
[same as prior period, unchanged from 0000068505-19-000013:mdna:119]

[0000068505-19-000019:mdna:188]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended June 29, 2019 and June 30, 2018:

[0000068505-19-000019:mdna:189]
|  | Three Months Ended |  | Six Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Accounts receivable sales proceeds | $ | 3 |  |  | $ | 22 |  |  | $ | 27 |  |  | $ | 76 |  |
| Long-term receivables sales proceeds | 55 |  |  | 15 |  |  | 76 |  |  | 28 |  |
| Total proceeds from sales of accounts receivable | $ | 58 |  |  | $ | 37 |  |  | $ | 103 |  |  | $ | 104 |  |

[0000068505-19-000019:mdna:190]
[same as prior period, unchanged from 0000068505-19-000013:mdna:122]

[0000068505-19-000019:mdna:191]
[same as prior period, unchanged from 0000068505-19-000013:mdna:124]

[0000068505-19-000019:mdna:192]
We had outstanding long-term debt of $5.3 billion, including the current portions of $28 million and $31 million at June 29, 2019 and December 31, 2018, respectively.

[0000068505-19-000019:mdna:193]
In February of 2018, we issued $500 million of 4.60% Senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan in the first quarter of 2018. During the second half of 2018, we issued an additional $200 million on the outstanding notes. We recognized net proceeds of $196 million after debt issuance costs and debt discounts.

[0000068505-19-000019:mdna:194]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million with a maturity date of March 26, 2021 (the "Term Loan"). Interest on the Term Loan is variable, indexed to London Inter-bank Offered Rate ("LIBOR"), and paid monthly. The weighted average borrowing rate for amounts outstanding during the three and six months ended June 29, 2019 was 3.72% and 3.74%, respectively. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-19-000019:mdna:195]
In May of 2019, we issued $650 million of 4.60% Senior notes due 2029. We recognized net proceeds of $645 million after debt issuance costs and debt discounts. These proceeds were then used to fund a tender offer which resulted in the repurchase of $614 million in principal amount of our outstanding long-term debt for a purchase price of $654 million, excluding approximately $3 million of accrued interest, all of which occurred during the three months ended June 29, 2019. After accelerating the amortization of debt issuance costs and debt discounts, we recognized a loss of approximately $43 million related to this debt tender in Other within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-19-000019:mdna:196]
As of June 29, 2019, we had $800 million of 2.0% Senior Convertible Notes outstanding with Silver Lake Partners which mature in September 2020 and are fully convertible. The notes are convertible based on a conversion rate of 14.8968, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a published conversion price of $67.13 per share). The exercise price adjusts automatically for dividends. In the event of a conversion, the notes may be settled in either cash or stock, at our discretion. We intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-19-000019:mdna:197]
[same as prior period, unchanged from 0000068505-19-000013:mdna:129]

[0000068505-19-000019:mdna:198]
[same as prior period, unchanged from 0000068505-19-000013:mdna:130]

[0000068505-19-000019:mdna:199]
As of June 29, 2019, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above LIBOR, at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of June 29, 2019. During the first quarter of 2018, we borrowed $400 million to facilitate the Avigilon acquisition. There were no borrowings outstanding or letters of credit issued under the revolving credit facility as of June 29, 2019.

[0000068505-19-000019:mdna:200]
[same as prior period, unchanged from 0000068505-19-000013:mdna:132]

[0000068505-19-000019:mdna:201]
During the three and six months ended June 29, 2019, we paid an aggregate of $25 million and $170 million, including transaction costs, to repurchase approximately 0.2 million and 1.4 million shares at an average price of $146.65 and $122.31 per share, respectively. As of June 29, 2019, we had used approximately $12.6 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.4 billion of authority available for future repurchases.

[0000068505-19-000019:mdna:202]
[same as prior period, unchanged from 0000068505-19-000013:mdna:134]

[0000068505-19-000019:mdna:203]
During the second quarter of 2019, we paid $94 million in cash dividends to holders of our common stock. During the first half of 2019, we paid $187 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $94 million in cash dividends to holders of our common stock.

[0000068505-19-000019:mdna:204]
[same as prior period, unchanged from 0000068505-19-000013:mdna:136]

[0000068505-19-000019:mdna:205]
We had outstanding commitments to provide long-term financing to third parties totaling $53 million at June 29, 2019, compared to $62 million at December 31, 2018.

[0000068505-19-000019:mdna:206]
Other Contingencies

[0000068505-19-000019:mdna:207]
There were no significant changes impacting our commitments and contingencies during the three months ended June 29, 2019.

[0000068505-19-000019:mdna:208]
[same as prior period, unchanged from 0000068505-19-000013:mdna:140]

[0000068505-19-000019:mdna:209]
In August 2018, the FASB issued ASU No. 2018-14, “Compensation - Retirement Benefits - Defined Benefit Plans - General (Subtopic 715-20) - Changes to the Disclosure Requirements for Defined Benefit Plans,” which modifies the disclosure requirements for the defined benefit pension plans and other postretirement plans. The ASU is effective for us on January 1, 2021 with early adoption permitted. The ASU requires a retrospective adoption method. We do not believe the ASU will have a material impact on our financial statement disclosures.

[0000068505-19-000019:mdna:210]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which requires us to measure and recognize expected credit losses for financial assets held and not accounted for at fair value through net income. In November 2018, April 2019 and May 2019, the FASB issued ASU No. 2018-19, “Codification Improvements to Topic 326, Financial Instruments - Credit Losses,”“ASU No. 2019-04, Codification Improvements to Topic 326, Financial Instruments - Credit Losses, ”“Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments,” and “ASU No. 2019-05, Financial Instruments - Credit Losses (Topic 326): Targeted Transition Relief,” which provided additional implementation guidance on the previously issued ASU. The ASU is effective for us on January 1, 2020. The ASU requires a modified retrospective adoption method. We are still evaluating the impact of adoption on our financial statements and disclosures.

[0000068505-19-000019:mdna:211]
Recently Adopted Accounting Pronouncements

[0000068505-19-000019:mdna:212]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. This was subsequently amended by ASU No. 2018-01, “Land Easement Practical Expedient for Transition to Topic 842,” ASU No. 2018-10, “Codification Improvements to Topic 842, Leases,” and ASU No. 2018-11, “Targeted Improvements” (collectively "ASC 842"). ASC 842 establishes a right-of-use model ("ROU") that requires a lessee to recognize a ROU asset and lease liability on the balance sheet for all leases with an initial term longer than twelve months. Leases will be classified as finance or operating, with classification affecting the pattern and presentation of expense recognition in the income statement.

[0000068505-19-000019:mdna:213]
We adopted ASC 842 as of January 1, 2019 using a modified retrospective transition approach for all leases existing at January 1, 2019, the date of the initial application. Consequently, financial information will not be updated and disclosures required under ASC 842 will not be provided for dates and periods before January 1, 2019.

[0000068505-19-000019:mdna:214]
[same as prior period, unchanged from 0000068505-19-000013:mdna:148]

[0000068505-19-000019:mdna:215]
[same as prior period, unchanged from 0000068505-19-000013:mdna:149]

[0000068505-19-000019:mdna:216]
As of January 1, 2019, we recognized operating lease liabilities of $648 million based on the present value of the remaining minimum rental payments determined under prior lease accounting standards and corresponding ROU assets of $588 million. The $60 million difference between operating lease liabilities and ROU assets recognized is due to deferred rent and exit cost accruals recorded under prior lease accounting standards. ASC 842 requires such balances to be reclassified against ROU assets at transition.

[0000068505-19-000019:mdna:217]
For arrangements where we are the lessor, the adoption of ASC 842 did not have a material impact on our financial statements as the majority of our leases are operating leases embedded within managed services contracts. ASC 842 provides a practical expedient for lessors in which the lessor may elect, by class of underlying asset, to not separate non-lease components from the associated lease component and, instead, to account for these components as a single component if both of the following are met: (i) the timing and pattern of transfer of the non-lease component(s) and associated lease component are the same and (ii) the lease component, if accounted for separately, would be classified as an operating lease. The accounting under the practical expedient depends on which component(s) is predominant in the contract. If the non-lease component is predominant, the single component is accounted under ASC Topic 606 "Revenue from Contracts with Customers" and accounting and disclosure under ASC 842 is not applicable. We have elected the above practical expedient and determined that non-lease components are predominant and is accounting for the single components as managed service contracts under ASC Topic 606.

[0000068505-19-000019:mdna:218]
41
