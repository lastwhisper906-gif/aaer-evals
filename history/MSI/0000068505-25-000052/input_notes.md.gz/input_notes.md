# MSI notes — 0000068505-25-000052


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-25-000052:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of September 27, 2025 and for the three and nine months ended September 27, 2025 and September 28, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-25-000052:notes:2]
[same as prior period, unchanged from 0000068505-25-000040:notes:2]

[0000068505-25-000052:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three and nine months ended September 27, 2025 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-25-000052:notes:4]
[same as prior period, unchanged from 0000068505-25-000040:notes:4]

[0000068505-25-000052:notes:5]
[same as prior period, unchanged from 0000068505-25-000040:notes:5]

[0000068505-25-000052:notes:6]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services". Within these segments the Company has three principal product lines in which the Company reports net sales: Mission Critical Networks (“MCN”), Video Security and Access Control ("Video"), and Command Center. With the acquisition of Silvus Technologies Holdings Inc. (“Silvus”) in August 2025, the Company will now report net sales from its principal product lines by combining the former Land Mobile Radio Communications and newly acquired Silvus under the new technology name Mission Critical Networks. This name change does not require any financial information to be reclassified from previous periods.

[0000068505-25-000052:notes:7]
•MCN: Infrastructure, mobile ad-hoc network technology ("MANET"), devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software, inclusive of installation and integration, and backed by managed and support services to help assure mission-critical communications availability, security and resiliency.

[0000068505-25-000052:notes:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence ("AI")-powered analytics that enable visibility to what's happening and bring attention to what’s important to help inform decisions and actions.

[0000068505-25-000052:notes:9]
•Command Center: Command center solutions and software applications, including AI-powered analytics, that unify voice, video and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents to help accelerate workflows and improve the accuracy and speed of decisions.

[0000068505-25-000052:notes:10]
[same as prior period, unchanged from 0000068505-25-000040:notes:11]

[0000068505-25-000052:notes:11]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million. Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be paid in shares of common stock. This business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-25-000052:notes:12]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $174 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services segment.

[0000068505-25-000052:notes:13]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $240 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. This business is part of the Software and Services segment.

[0000068505-25-000052:notes:14]
[same as prior period, unchanged from 0000068505-25-000040:notes:15]

[0000068505-25-000052:notes:15]
[same as prior period, unchanged from 0000068505-25-000040:notes:16]

[0000068505-25-000052:notes:16]
[same as prior period, unchanged from 0000068505-25-000040:notes:17]

[0000068505-25-000052:notes:17]
[same as prior period, unchanged from 0000068505-25-000040:notes:18]

[0000068505-25-000052:notes:18]
[same as prior period, unchanged from 0000068505-25-000040:notes:19]

[0000068505-25-000052:notes:19]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software" to modernize the accounting for internal-use software costs. The ASU is effective for fiscal years beginning after December 15, 2027 and interim periods with annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-25-000052:notes:20]
In July 2025, the FASB issued ASU No. 2025-05, "Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets" to introduce a practical expedient in the estimation of expected credit losses for current accounts receivable and current contract assets. The ASU is effective for fiscal years beginning after December 15, 2025 and interim periods with annual reporting periods beginning after December 15, 2025, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-25-000052:notes:21]
In November 2024, the FASB issued ASU No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date," which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-25-000052:notes:22]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.

[0000068505-25-000052:notes:23]
Recently Adopted Accounting Pronouncements
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The Company adopted ASU No. 2023-07 for the year ended December 31, 2024 and applied the required retrospective transition method. Refer to Note 13, "Segment Information" in this "Part 1 — Financial Information" of this Form 10-Q for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-25-000052:notes:24]
[same as prior period, unchanged from 0000068505-25-000040:notes:23]

[0000068505-25-000052:notes:25]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 27, 2025 and September 28, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-25-000052:notes:26]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,360 |  |  | $ | 761 |  |  | $ | 2,121 |  |  | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |
| International | 537 |  |  | 351 |  |  | 888 |  |  | 480 |  |  | 303 |  |  | 783 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,598 |  |  | $ | 643 |  |  | $ | 2,241 |  |  | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |
| Video | 299 |  |  | 235 |  |  | 534 |  |  | 292 |  |  | 208 |  |  | 500 |  |
| Command Center | — |  |  | 234 |  |  | 234 |  |  | — |  |  | 202 |  |  | 202 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,187 |  |  | $ | 1,006 |  |  | 2,193 |  |  | $ | 1,108 |  |  | $ | 917 |  |  | $ | 2,025 |  |
| Indirect | 710 |  |  | 106 |  |  | 816 |  |  | 676 |  |  | 89 |  |  | 765 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |

[0000068505-25-000052:notes:27]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,789 |  |  | $ | 2,211 |  |  | $ | 6,000 |  |  | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |
| International | 1,306 |  |  | 996 |  |  | 2,302 |  |  | 1,302 |  |  | 888 |  |  | 2,190 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 4,269 |  |  | $ | 1,878 |  |  | $ | 6,147 |  |  | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |
| Video | 826 |  |  | 672 |  |  | 1,498 |  |  | 821 |  |  | 553 |  |  | 1,374 |  |
| Command Center | — |  |  | 657 |  |  | 657 |  |  | — |  |  | 581 |  |  | 581 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 3,233 |  |  | $ | 2,929 |  |  | $ | 6,162 |  |  | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |
| Indirect | 1,862 |  |  | 278 |  |  | 2,140 |  |  | 1,964 |  |  | 256 |  |  | 2,220 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |

[0000068505-25-000052:notes:28]
[same as prior period, unchanged from 0000068505-25-000040:notes:27]

[0000068505-25-000052:notes:29]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 27, 2025 was $8.9 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 27, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of September 27, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-25-000052:notes:30]
[same as prior period, unchanged from 0000068505-25-000040:notes:29]

[0000068505-25-000052:notes:31]
| (In millions) | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 2,018 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,515 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 2,074 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 670 |  |  | 496 |  |  |  |  |  |

[0000068505-25-000052:notes:32]
[same as prior period, unchanged from 0000068505-25-000040:notes:31]

[0000068505-25-000052:notes:33]
Revenue recognized during the three months ended September 27, 2025 which was previously included in Contract liabilities as of June 28, 2025 was $637 million, compared to $572 million of revenue recognized during the three months ended September 28, 2024 which was previously included in Contract liabilities as of June 29, 2024. The Company recognized revenue of $1.2 billion during each of the nine months ended September 27, 2025 and September 28, 2024, which was previously included in Contract liabilities as of December 31, 2024 and December 31, 2023, respectively. Revenue of $7 million was recognized during the three months ended September 27, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $6 million recognized for the three months ended September 28, 2024, primarily driven by changes in the estimates of progress on system contracts. Revenue of $7 million was reversed during the nine months ended September 27, 2025 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $11 million of reversals for the nine months ended September 28, 2024.

[0000068505-25-000052:notes:34]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 27, 2025 and September 28, 2024.

[0000068505-25-000052:notes:35]
[same as prior period, unchanged from 0000068505-25-000040:notes:34]

[0000068505-25-000052:notes:36]
| (In millions) | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 77 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 134 |  |  | 141 |  |  |  |  |  |

[0000068505-25-000052:notes:37]
Amortization of contract cost assets was $13 million and $39 million for the three and nine months ended September 27, 2025, respectively, and $13 million and $38 million for the three and nine months ended September 28, 2024, respectively.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-25-000052:notes:38]
[same as prior period, unchanged from 0000068505-25-000040:notes:37]

[0000068505-25-000052:notes:39]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 39 |  |  | $ | 34 |  |  | $ | 114 |  |  | $ | 103 |  |
| Variable cost | 9 |  |  | 12 |  |  | 37 |  |  | 34 |  |
| Sublease income | (1) |  |  | (1) |  |  | (5) |  |  | (4) |  |
| Net lease expense from operating leases | $ | 47 |  |  | $ | 45 |  |  | $ | 146 |  |  | $ | 133 |  |

[0000068505-25-000052:notes:40]
[same as prior period, unchanged from 0000068505-25-000040:notes:39]

[0000068505-25-000052:notes:41]
| (in millions) |  | Statement Line Classification |  | September 27, 2025 |  | December 31, 2024 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 577 |  |  | $ | 529 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | 128 |  |  | 127 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | 469 |  |  | 427 |  |  |  |

[0000068505-25-000052:notes:42]
[same as prior period, unchanged from 0000068505-25-000040:notes:41]

[0000068505-25-000052:notes:43]
|  | Nine Months Ended |  |  |
| (in millions) | September 27, 2025 |  | September 28, 2024 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 121 |  |  | $ | 118 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | 84 |  |  | 123 |  |  |  |

[0000068505-25-000052:notes:44]
|  | September 27, 2025 |  | December 31, 2024 |
| Weighted average remaining lease terms (years) | 6 |  | 5 |
| Weighted average discount rate: | 4.17 | % |  | 3.97 | % |

[0000068505-25-000052:notes:45]
[same as prior period, unchanged from 0000068505-25-000040:notes:44]

[0000068505-25-000052:notes:46]
|  | September 27, 2025 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2025 | $ | 26 |  |  |  |  |  |
| 2026 | 148 |  |  |  |  |  |
| 2027 | 146 |  |  |  |  |  |
| 2028 | 120 |  |  |  |  |  |
| 2029 | 90 |  |  |  |  |  |
| Thereafter | 143 |  |  |  |  |  |
| Total lease payments | 673 |  |  |  |  |  |
| Less: interest | 76 |  |  |  |  |  |
| Present value of lease liabilities | $ | 597 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-25-000052:notes:47]
[same as prior period, unchanged from 0000068505-25-000040:notes:46]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-25-000052:notes:48]
[same as prior period, unchanged from 0000068505-25-000040:notes:47]

[0000068505-25-000052:notes:49]
[same as prior period, unchanged from 0000068505-25-000040:notes:48]

[0000068505-25-000052:notes:50]
[same as prior period, unchanged from 0000068505-25-000040:notes:49]

[0000068505-25-000052:notes:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 66 |  |  | $ | 38 |  |  | $ | 142 |  |  | $ | 114 |  |
| Reorganization of business (Note 14) | 12 |  |  | 5 |  |  | 33 |  |  | 16 |  |
| Operating lease asset impairments | 1 |  |  | 1 |  |  | 1 |  |  | 5 |  |
| Acquisition-related transaction fees | 55 |  |  | 4 |  |  | 63 |  |  | 11 |  |
| Legal settlements | 2 |  |  | 1 |  |  | 7 |  |  | 7 |  |
| Gain on Hytera litigation | (74) |  |  | — |  |  | (94) |  |  | — |  |
|  | $ | 62 |  |  | $ | 49 |  |  | $ | 152 |  |  | $ | 153 |  |

[0000068505-25-000052:notes:52]
During the three and nine months ended September 27, 2025, the Company recognized a gain on the Hytera litigation of $74 million and $94 million, respectively, for amounts recovered through legal proceedings due to theft of the Company's trade secrets. Refer to "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" in this "Part 1 — Financial Information" of this Form 10-Q.

[0000068505-25-000052:notes:53]
[same as prior period, unchanged from 0000068505-25-000040:notes:52]

[0000068505-25-000052:notes:54]
[same as prior period, unchanged from 0000068505-25-000040:notes:53]

[0000068505-25-000052:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Interest, net: |  |  |  |  |  |  |  |
| Interest expense | $ | (103) |  |  | $ | (73) |  |  | $ | (243) |  |  | $ | (221) |  |
| Interest income | 17 |  |  | 15 |  |  | 51 |  |  | 50 |  |
|  | $ | (86) |  |  | $ | (58) |  |  | $ | (192) |  |  | $ | (171) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 31 |  |  | $ | 32 |  |  | $ | 92 |  |  | $ | 95 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | — |  |  | — |  |  | — |  |  | (585) |  |
| Investment impairments | (2) |  |  | — |  |  | (2) |  |  | (3) |  |
| Foreign currency gain (loss) | 4 |  |  | (26) |  |  | (57) |  |  | (22) |  |
| Gain (loss) on derivative instruments (Note 6) | (6) |  |  | 22 |  |  | 41 |  |  | 7 |  |
| Fair value adjustments to equity investments | 8 |  |  | 9 |  |  | 21 |  |  | (4) |  |
| Assessments on uncertain tax positions | — |  |  | — |  |  | — |  |  | (11) |  |
| Other | 6 |  |  | 5 |  |  | 5 |  |  | 4 |  |
|  | $ | 41 |  |  | $ | 42 |  |  | $ | 100 |  |  | $ | (519) |  |

[0000068505-25-000052:notes:56]
[same as prior period, unchanged from 0000068505-25-000040:notes:55]

[0000068505-25-000052:notes:57]
[same as prior period, unchanged from 0000068505-25-000040:notes:56]

[0000068505-25-000052:notes:58]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 562 |  |  | $ | 562 |  |  | $ | 1,505 |  |  | $ | 966 |  |
| Weighted average common shares outstanding | 166.6 |  |  | 167.1 |  |  | 166.8 |  |  | 166.7 |  |
| Per share amount | $ | 3.37 |  |  | $ | 3.36 |  |  | $ | 9.02 |  |  | $ | 5.79 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 562 |  |  | $ | 562 |  |  | $ | 1,505 |  |  | $ | 966 |  |
| Weighted average common shares outstanding | 166.6 |  |  | 167.1 |  |  | 166.8 |  |  | 166.7 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.4 |  |  | 3.8 |  |  | 2.4 |  |  | 3.9 |  |
| Diluted weighted average common shares outstanding | 169.0 |  |  | 170.9 |  |  | 169.2 |  |  | 170.6 |  |
| Per share amount | $ | 3.33 |  |  | $ | 3.29 |  |  | $ | 8.89 |  |  | $ | 5.66 |  |

[0000068505-25-000052:notes:59]
In the computation of diluted earnings per common share for the three months ended September 27, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000052:notes:60]
In the computation of diluted earnings per common share for the nine months ended September 27, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000052:notes:61]
In the computation of diluted earnings per common share for the three months ended September 28, 2024, the assumed exercise of 0.1 million options were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000052:notes:62]
In the computation of diluted earnings per common share for the nine months ended September 28, 2024, a total of 0.3 million shares related to the 1.75% senior convertible notes issued to Silver Lake Partners ("Silver Lake Convertible Debt") were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In addition, the assumed exercise of 0.1 million options were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000052:notes:63]
In connection with the acquisition of Silvus, the Seller will have the potential to earn contingent earnout consideration upon the achievement of certain financial targets payable in shares of common stock of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The estimated fair value of the total contingent earnout consideration at the acquisition date was $38 million. The shares required to settle the contingent earnout consideration will only be reflected within diluted earnings per share when and if the earnout financial targets have been achieved, in each of the two respective periods.

[0000068505-25-000052:notes:64]
[same as prior period, unchanged from 0000068505-25-000040:notes:62]

[0000068505-25-000052:notes:65]
[same as prior period, unchanged from 0000068505-25-000040:notes:63]

[0000068505-25-000052:notes:66]
[same as prior period, unchanged from 0000068505-25-000040:notes:64]

[0000068505-25-000052:notes:67]
|  | September 27, 2025 |  | December 31, 2024 |
| Accounts receivable | $ | 2,101 |  |  | $ | 2,035 |  |
| Less allowance for credit losses | (83) |  |  | (83) |  |
|  | $ | 2,018 |  |  | $ | 1,952 |  |

[0000068505-25-000052:notes:68]
[same as prior period, unchanged from 0000068505-25-000040:notes:66]

[0000068505-25-000052:notes:69]
[same as prior period, unchanged from 0000068505-25-000040:notes:67]

[0000068505-25-000052:notes:70]
|  | September 27, 2025 |  | December 31, 2024 |
| Finished goods | $ | 474 |  |  | $ | 396 |  |
| Work-in-process and production materials | 591 |  |  | 498 |  |
|  | 1,065 |  |  | 894 |  |
| Less inventory reserves | (122) |  |  | (128) |  |
|  | $ | 943 |  |  | $ | 766 |  |

[0000068505-25-000052:notes:71]
[same as prior period, unchanged from 0000068505-25-000040:notes:69]

[0000068505-25-000052:notes:72]
[same as prior period, unchanged from 0000068505-25-000040:notes:70]

[0000068505-25-000052:notes:73]
|  | September 27, 2025 |  | December 31, 2024 |
| Current contract cost assets (Note 2) | $ | 77 |  |  | $ | 70 |  |
| Contractor receivables | 43 |  |  | 44 |  |
| Tax-related deposits | 36 |  |  | 54 |  |
| Other | 285 |  |  | 261 |  |
|  | $ | 441 |  |  | $ | 429 |  |

[0000068505-25-000052:notes:74]
[same as prior period, unchanged from 0000068505-25-000040:notes:72]

[0000068505-25-000052:notes:75]
[same as prior period, unchanged from 0000068505-25-000040:notes:73]

[0000068505-25-000052:notes:76]
|  | September 27, 2025 |  | December 31, 2024 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 465 |  |  | 441 |  |
| Machinery and equipment | 2,528 |  |  | 2,243 |  |
|  | 2,998 |  |  | 2,689 |  |
| Less accumulated depreciation | (1,899) |  |  | (1,667) |  |
|  | $ | 1,099 |  |  | $ | 1,022 |  |

[0000068505-25-000052:notes:77]
Depreciation expense was $49 million and $46 million for the three months ended September 27, 2025 and September 28, 2024, respectively. Depreciation expense for the nine months ended September 27, 2025 and September 28, 2024 was $140 million and $136 million, respectively.

[0000068505-25-000052:notes:78]
[same as prior period, unchanged from 0000068505-25-000040:notes:76]

[0000068505-25-000052:notes:79]
[same as prior period, unchanged from 0000068505-25-000040:notes:77]

[0000068505-25-000052:notes:80]
|  | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Common stock | $ | 45 |  |  | $ | 23 |  |  |  |  |  |
| Strategic investments | 54 |  |  | 26 |  |  |  |  |  |
| Company-owned life insurance policies | 83 |  |  | 75 |  |  |  |  |  |
| Equity method investments | 10 |  |  | 11 |  |  |  |  |  |
|  | $ | 192 |  |  | $ | 135 |  |  |  |  |  |

[0000068505-25-000052:notes:81]
[same as prior period, unchanged from 0000068505-25-000040:notes:79]

[0000068505-25-000052:notes:82]
[same as prior period, unchanged from 0000068505-25-000040:notes:80]

[0000068505-25-000052:notes:83]
|  | September 27, 2025 |  | December 31, 2024 |
| Defined benefit plan assets | $ | 216 |  |  | $ | 162 |  |
| Non-current contract cost assets (Note 2) | 134 |  |  | 141 |  |
| Other | 96 |  |  | 72 |  |
|  | $ | 446 |  |  | $ | 375 |  |

[0000068505-25-000052:notes:84]
[same as prior period, unchanged from 0000068505-25-000040:notes:82]

[0000068505-25-000052:notes:85]
[same as prior period, unchanged from 0000068505-25-000040:notes:83]

[0000068505-25-000052:notes:86]
The Company's outstanding amounts related to the suppliers participating in this program was $38 million as of both September 27, 2025 and December 31, 2024. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-25-000052:notes:87]
[same as prior period, unchanged from 0000068505-25-000040:notes:85]

[0000068505-25-000052:notes:88]
[same as prior period, unchanged from 0000068505-25-000040:notes:86]

[0000068505-25-000052:notes:89]
|  | September 27, 2025 |  | December 31, 2024 |
| Compensation | $ | 425 |  |  | $ | 406 |  |
| Tax liabilities | 144 |  |  | 217 |  |
| Dividend payable | 182 |  |  | 182 |  |
| Trade liabilities | 187 |  |  | 160 |  |
| Operating lease liabilities (Note 3) | 128 |  |  | 127 |  |
| Customer reserves | 98 |  |  | 97 |  |
| Other | 553 |  |  | 454 |  |
|  | $ | 1,717 |  |  | $ | 1,643 |  |

[0000068505-25-000052:notes:90]
[same as prior period, unchanged from 0000068505-25-000040:notes:88]

[0000068505-25-000052:notes:91]
[same as prior period, unchanged from 0000068505-25-000040:notes:89]

[0000068505-25-000052:notes:92]
|  | September 27, 2025 |  | December 31, 2024 |
| Defined benefit plans (Note 8) | $ | 711 |  |  | $ | 768 |  |
| Non-current contract liabilities (Note 2) | 670 |  |  | 496 |  |
| Unrecognized tax benefits (Note 7) | 38 |  |  | 39 |  |
| Deferred income taxes (Note 7) | 106 |  |  | 87 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Deferred compensation | 107 |  |  | 89 |  |
| Other | 165 |  |  | 121 |  |
|  | $ | 1,916 |  |  | $ | 1,719 |  |

[0000068505-25-000052:notes:93]
[same as prior period, unchanged from 0000068505-25-000040:notes:91]

[0000068505-25-000052:notes:94]
Share Repurchase Program: During the three and nine months ended September 27, 2025, the Company repurchased approximately 0.3 million and 1.5 million shares at an average price of $467.10 and $434.41 per share for an aggregate amount of $121 million and $664 million, respectively.

[0000068505-25-000052:notes:95]
Payment of Dividends: During the three months ended September 27, 2025 and September 28, 2024, the Company paid $182 million and $164 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $182 million in cash dividends to holders of its common stock. During the nine months ended September 27, 2025 and September 28, 2024, the Company paid $546 million and $490 million, respectively, in cash dividends to holders of its common stock.

[0000068505-25-000052:notes:96]
[same as prior period, unchanged from 0000068505-25-000040:notes:94]

[0000068505-25-000052:notes:97]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended September 27, 2025 and September 28, 2024:

[0000068505-25-000052:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (428) |  |  | $ | (509) |  |  | $ | (546) |  |  | $ | (482) |  |
| Other comprehensive income (loss) before reclassification adjustment | (13) |  |  | 73 |  |  | 100 |  |  | 44 |  |
| Tax benefit (expense) | — |  |  | (1) |  |  | 5 |  |  | 1 |  |
| Other comprehensive income (loss), net of tax | (13) |  |  | 72 |  |  | 105 |  |  | 45 |  |
| Balance at end of period | $ | (441) |  |  | $ | (437) |  |  | $ | (441) |  |  | $ | (437) |  |
| Derivative Instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (7) |  |  | $ | (8) |  |  | $ | (7) |  |  | $ | (12) |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | — |  |  | 4 |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | — |  |  | 4 |  |
| Other comprehensive income, net of tax | — |  |  | — |  |  | $ | — |  |  | $ | 4 |  |
| Balance at end of period | $ | (7) |  |  | $ | (8) |  |  | $ | (7) |  |  | $ | (8) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,977) |  |  | $ | (2,032) |  |  | $ | (1,986) |  |  | $ | (2,046) |  |
| Other comprehensive loss before reclassification adjustment | — |  |  | — |  |  | (8) |  |  | — |  |
| Tax benefit | — |  |  | — |  |  | 2 |  |  | — |  |
| Other comprehensive loss before reclassification adjustment, net of tax | — |  |  | — |  |  | (6) |  |  | — |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 10 |  |  | 9 |  |  | 28 |  |  | 25 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | — |  |  | — |  |  | — |  |  | 2 |  |
| Tax expense | (2) |  |  | (2) |  |  | (5) |  |  | (6) |  |
| Reclassification adjustments into Net earnings, net of tax | 8 |  |  | 7 |  |  | 23 |  |  | 21 |  |
| Other comprehensive income, net of tax | 8 |  |  | 7 |  |  | 17 |  |  | 21 |  |
| Balance at end of period | $ | (1,969) |  |  | $ | (2,025) |  |  | $ | (1,969) |  |  | $ | (2,025) |  |
| Total Accumulated other comprehensive loss | $ | (2,417) |  |  | $ | (2,470) |  |  | $ | (2,417) |  |  | $ | (2,470) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-25-000052:notes:99]
Debt and Credit Facilities

[0000068505-25-000052:notes:100]
|  | September 27, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | — |  |  | 70 |  |
| 364-day term loan | 749 |  |  | — |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| Term loan due 2028 | 748 |  |  | — |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 597 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
| Other short-term borrowings | 179 |  |  | — |  |
|  | 9,340 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (928) |  |  | (322) |  |
| Long-term debt | $ | 8,411 |  |  | $ | 5,675 |  |

[0000068505-25-000052:notes:101]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032 and $900 million of 5.55% senior notes due 2035. The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-25-000052:notes:102]
On August 6, 2025 the Company borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. The Company was in compliance with its financial covenants as of September 27, 2025. During the three months ended September 27, 2025, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 5.30% and 5.25%, respectively.

[0000068505-25-000052:notes:103]
During the three months ended September 27, 2025, the Company repaid the $70 million aggregate principal amount of the 6.5% debentures due 2025. Additionally, during the nine months ended September 27, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% debentures due 2025.

[0000068505-25-000052:notes:104]
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 27, 2025. 
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 27, 2025, the Company had outstanding other short-term borrowings of $179 million, inclusive of the commercial paper program, with a weighted-average interest rate of 4.52% during the three months ended September 27, 2025.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-25-000052:notes:105]
[same as prior period, unchanged from 0000068505-25-000040:notes:105]

[0000068505-25-000052:notes:106]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.3 billion and $1.0 billion for the periods ended September 27, 2025 and December 31, 2024, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-25-000052:notes:107]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of September 27, 2025, and the corresponding positions as of December 31, 2024:

[0000068505-25-000052:notes:108]
|  | Notional Amount |
| Net Buy (Sell) by Currency | September 27, 2025 |  | December 31, 2024 |
| Euro | $ | 190 |  |  | $ | 150 |  |
| British Pound | 179 |  |  | 124 |  |
| Australian dollar | (147) |  |  | (136) |  |
| Canadian dollar | 68 |  |  | 70 |  |
| Brazilian Real | (50) |  |  | (23) |  |

[0000068505-25-000052:notes:109]
[same as prior period, unchanged from 0000068505-25-000040:notes:109]

[0000068505-25-000052:notes:110]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of September 27, 2025, all of the counterparties had investment grade credit ratings. As of September 27, 2025, the Company had $1 million of exposure to aggregate credit risk with all counterparties.

[0000068505-25-000052:notes:111]
[same as prior period, unchanged from 0000068505-25-000040:notes:111]

[0000068505-25-000052:notes:112]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of September 27, 2025 and December 31, 2024:

[0000068505-25-000052:notes:113]
|  | Fair Values of Derivative Instruments |
| September 27, 2025 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 20 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 3 |  |
| Equity swap contracts | 1 |  |  | — |  |
| Total derivatives | $ | 1 |  |  | $ | 23 |  |

[0000068505-25-000052:notes:114]
|  | Fair Values of Derivative Instruments |
| December 31, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 7 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | $ | 9 |  |
| Equity swap contracts | — |  |  | 1 |  |
| Total derivatives | $ | 10 |  |  | $ | 10 |  |

[0000068505-25-000052:notes:115]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended September 27, 2025 and September 28, 2024:

[0000068505-25-000052:notes:116]
|  | Financial Statement Location | Three Months Ended |  | Nine Months Ended |
| Derivatives | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | (1) |  |  | $ | (9) |  |  | $ | (24) |  |  | $ | 3 |  |
| Amortized hedge income | Other income (expense) | 2 |  |  | — |  |  | 4 |  |  | 1 |  |
| Treasury rate lock | Accumulated other comprehensive income (loss) | — |  |  | — |  |  | — |  |  | 4 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | (6) |  |  | $ | 22 |  |  | $ | 41 |  |  | $ | 7 |  |
| Equity swap contracts | Selling, general and administrative expenses | 2 |  |  | 1 |  |  | 1 |  |  | 3 |  |

[0000068505-25-000052:notes:117]
[same as prior period, unchanged from 0000068505-25-000040:notes:117]

[0000068505-25-000052:notes:118]
The Company uses foreign exchange forward and option contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of Foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of September 27, 2025, the Company had €160 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in a British pound functional subsidiary.

[0000068505-25-000052:notes:119]
[same as prior period, unchanged from 0000068505-25-000040:notes:119]

[0000068505-25-000052:notes:120]
[same as prior period, unchanged from 0000068505-25-000040:notes:120]

[0000068505-25-000052:notes:121]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of September 27, 2025 was $21 million.

[0000068505-25-000052:notes:122]
[same as prior period, unchanged from 0000068505-25-000040:notes:122]

[0000068505-25-000052:notes:123]
In 2023, the Company entered into treasury rate agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the nine months ended September 28, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated other comprehensive income (loss) will be reclassified to interest expense on a straight-line basis over the ten year term of the 2034 notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-25-000052:notes:124]
[same as prior period, unchanged from 0000068505-25-000040:notes:124]

[0000068505-25-000052:notes:125]
[same as prior period, unchanged from 0000068505-25-000040:notes:125]

[0000068505-25-000052:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net earnings before income taxes | $ | 725 |  |  | $ | 695 |  |  | $ | 1,952 |  |  | $ | 1,184 |  |
| Income tax expense | 161 |  |  | 132 |  |  | 442 |  |  | 214 |  |
| Effective tax rate | 22 | % |  | 19 | % |  | 23 | % |  | 18 | % |

[0000068505-25-000052:notes:127]
The effective tax rate for the three months ended September 27, 2025 of 22% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, partially offset by excess tax benefits of share-based compensation. The effective tax rate for the nine months ended September 27, 2025 of 23% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, partially offset by excess tax benefits of share-based compensation.

[0000068505-25-000052:notes:128]
The effective tax rate for the three months ended September 28, 2024 of 19% was lower than the U.S. federal statutory tax rate of 21% primarily due to favorable U.S. return-to-provision adjustments, excess tax benefits of share-based compensation, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions, partially offset by state tax expense. The effective tax rate for the nine months ended September 28, 2024 of 18% was lower than the U.S. federal statutory tax rate of 21% primarily due to favorable U.S. return-to-provision adjustments (inclusive of the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return), excess tax benefits of share-based compensation, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions, partially offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in 2024 and state tax expense.

[0000068505-25-000052:notes:129]
The effective tax rate for the three months ended September 27, 2025 of 22% was higher than the effective tax rate for the three months ended September 28, 2024 of 19%, primarily due to non-deductible transaction costs related to the acquisition of Silvus, favorable U.S. return-to-provision adjustments from implementing a business initiative in 2024, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, partially offset by higher excess tax benefits of share-based compensation in 2025. The effective tax rate for the nine months ended September 27, 2025 of 23% was higher than the effective tax rate for the nine months ended September 28, 2024 of 18%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, partially offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in 2024.

[0000068505-25-000052:notes:130]
On July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law, introducing a broad range of changes to the U.S. corporate income tax framework. The legislation includes business provisions that impact the Company's tax position, including tax cut extensions and modifications to the international tax framework and corporate income tax deductions. The Company has evaluated the effects of these changes on its income tax provision, income tax payable, and deferred tax asset balances, which are reflected in this quarter's results. As of the three months ended September 27, 2025, the 2025 impact of the enacted legislation on the Company's tax position was not material. The Company will continue to recognize the effects of the legislation in accordance with the effective dates of the applicable provisions, and plans to continue to assess the ongoing impact of this legislation as further guidance is made available.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-25-000052:notes:131]
[same as prior period, unchanged from 0000068505-25-000040:notes:131]

[0000068505-25-000052:notes:132]
[same as prior period, unchanged from 0000068505-25-000040:notes:132]

[0000068505-25-000052:notes:133]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Interest cost | $ | 50 |  |  | $ | 47 |  |  | $ | 15 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 1 |  |
| Expected return on plan assets | (76) |  |  | (75) |  |  | (28) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 7 |  |  | 6 |  |  | 2 |  |  | 2 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | (1) |  |  | 1 |  |  | 1 |  |
| Net periodic pension benefits | $ | (19) |  |  | $ | (22) |  |  | $ | (12) |  |  | $ | (11) |  |  | $ | — |  |  | $ | — |  |

[0000068505-25-000052:notes:134]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Interest cost | 150 |  |  | 141 |  |  | 43 |  |  | 42 |  |  | 4 |  |  | 4 |  |
| Expected return on plan assets | (229) |  |  | (223) |  |  | (81) |  |  | (78) |  |  | (9) |  |  | (9) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 19 |  |  | 17 |  |  | 5 |  |  | 5 |  |  | 4 |  |  | 3 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (2) |  |  | (2) |  |  | 2 |  |  | 4 |  |
| Net periodic pension cost (benefits) | $ | (60) |  |  | $ | (65) |  |  | $ | (35) |  |  | $ | (33) |  |  | $ | 1 |  |  | $ | 2 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-25-000052:notes:135]
[same as prior period, unchanged from 0000068505-25-000040:notes:135]

[0000068505-25-000052:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 14 |  |  | $ | 12 |  |  | $ | 42 |  |  | $ | 36 |  |
| Selling, general and administrative expenses | 41 |  |  | 33 |  |  | 116 |  |  | 97 |  |
| Research and development expenditures | 18 |  |  | 16 |  |  | 55 |  |  | 47 |  |
| Share-based compensation expense included in Operating earnings | 73 |  |  | 61 |  |  | 213 |  |  | 180 |  |
| Tax benefit | (16) |  |  | (13) |  |  | (45) |  |  | (37) |  |
| Share-based compensation expense, net of tax | $ | 57 |  |  | $ | 48 |  |  | $ | 168 |  |  | $ | 143 |  |
| Decrease in basic earnings per share | $ | (0.34) |  |  | $ | (0.29) |  |  | $ | (1.01) |  |  | $ | (0.86) |  |
| Decrease in diluted earnings per share | $ | (0.34) |  |  | $ | (0.28) |  |  | $ | (0.99) |  |  | $ | (0.84) |  |

[0000068505-25-000052:notes:137]
During the nine months ended September 27, 2025, the Company granted 0.6 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $271 million, $24 million and $17 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $9 million and $17 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-25-000052:notes:138]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of September 27, 2025 and December 31, 2024 were as follows:

[0000068505-25-000052:notes:139]
| September 27, 2025 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Equity swap contracts | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Common stock | 45 |  |  | — |  |  | — |  |  | 45 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Contingent earnout consideration (Note 15) | — |  |  | — |  |  | 38 |  |  | 38 |  |

[0000068505-25-000052:notes:140]
| December 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Common stock | 23 |  |  | — |  |  | — |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Equity swap contracts | 1 |  |  | — |  |  | — |  |  | 1 |  |

[0000068505-25-000052:notes:141]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of September 27, 2025 or December 31, 2024.

[0000068505-25-000052:notes:142]
At September 27, 2025 and December 31, 2024, the Company had $568 million and $1.2 billion, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-25-000052:notes:143]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of September 27, 2025 was $9.4 billion. The fair value of long-term debt as of December 31, 2024 was $5.8 billion.

[0000068505-25-000052:notes:144]
In connection with the acquisition of Silvus, contingent earnout consideration reflects the estimated fair value of the contingent future payments to the Seller following the achievement of certain financial targets. Refer to Note 15, “Intangible Assets and Goodwill” in this “Part 1 – Financial Information” of this Form 10-Q for more information regarding the details of the contingent earnout consideration. The Company determines the fair value of its contingent earnout consideration liability using a Monte Carlo simulation model, which requires the use of Level 3 inputs, such as projected future net sales, gross margin and cash flows. At the acquisition date, the Company recorded a contingent liability of approximately $38 million, related to the estimated fair value of the contingent earnout consideration, which was included in the purchase price. For the three months ended September 27, 2025, the fair value adjustment related to the contingent earnout consideration was de minimis.

[0000068505-25-000052:notes:145]
[same as prior period, unchanged from 0000068505-25-000040:notes:144]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-25-000052:notes:146]
[same as prior period, unchanged from 0000068505-25-000040:notes:145]

[0000068505-25-000052:notes:147]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended September 27, 2025 and September 28, 2024:

[0000068505-25-000052:notes:148]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Accounts receivable sales proceeds | $ | 19 |  |  | $ | 15 |  |  | $ | 19 |  |  | $ | 15 |  |
| Long-term receivables sales proceeds | 58 |  |  | 56 |  |  | 171 |  |  | 82 |  |
| Total proceeds from receivable sales | $ | 77 |  |  | $ | 71 |  |  | $ | 190 |  |  | $ | 97 |  |

[0000068505-25-000052:notes:149]
At September 27, 2025, the Company had retained servicing obligations for $856 million of long-term receivables, compared to $794 million at December 31, 2024. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $218 million at September 27, 2025, compared to $105 million at December 31, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-25-000052:notes:150]
Commitments and Contingencies
Legal Matters

[0000068505-25-000052:notes:151]
Hytera Civil Litigation

[0000068505-25-000052:notes:152]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for the Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor and awarded the Company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-25-000052:notes:153]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products ("I-Series") that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The Company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations. Hytera has made de minimis royalty payments related to the I-Series products directly to the Company between January 2025 and July 2025.

[0000068505-25-000052:notes:154]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation, turnover of Hytera assets to the Company, and injunction are currently briefed. On October 14-15, 2025, the District Court held hearings on these issues, but has not yet issued any rulings.

[0000068505-25-000052:notes:155]
In 2025, Hytera made payments towards amounts awarded to the Company and owed by Hytera pursuant to court orders related to I-Series products. In the third quarter of 2025, the Company received payments of $74 million, resulting in an aggregate of $94 million of payments received in the nine months ended September 27, 2025. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-25-000052:notes:156]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products ("H-Series"). On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain H-Series products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions.

[0000068505-25-000052:notes:157]
The District Court held hearings in August 2024, concerning whether Hytera's currently shipping H-Series products continue to misuse the Company's trade secrets and copyrighted source code. On August 25, 2025, the District Court held Hytera in civil contempt for violation of the District Court’s royalty order and ordered Hytera to pay the Company approximately $70 million for unpaid royalties and interest for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera's H-Series products. Hytera has appealed the District Court’s order to the Court of Appeals. Hytera’s appeal does not automatically stay its obligation to pay the $70 million. On October 14-15, 2025, the District Court heard arguments on whether Hytera must pay the $70 million into escrow, or directly to the Company as a payment towards amounts awarded to the Company and owed by Hytera pursuant to prior court orders, but has not yet issued a ruling.

[0000068505-25-000052:notes:158]
Hytera Criminal Litigation

[0000068505-25-000052:notes:159]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 24th and 25th, 2025. Pursuant to the plea agreement, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-25-000052:notes:160]
[same as prior period, unchanged from 0000068505-25-000040:notes:158]

[0000068505-25-000052:notes:161]
|  | Three Months Ended |
|  | September 27, 2025 |  |  |  |  |  | September 28, 2024 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  |  |  |  |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  |  |  |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Cost of sales | 878 |  | 577 |  | 1,455 |  |  |  |  |  | 822 |  | 535 |  | 1,357 |
| Gross margin | 1,019 |  | 535 |  | 1,554 |  |  |  |  |  | 962 |  | 471 |  | 1,433 |
| Selling, general and administrative expenses | 384 |  | 101 |  | 485 |  |  |  |  |  | 346 |  | 93 |  | 439 |
| Research and development expenditures | 146 |  | 91 |  | 237 |  |  |  |  |  | 146 |  | 88 |  | 234 |
| Other charges | 31 |  | 31 |  | 62 |  |  |  |  |  | 24 |  | 25 |  | 49 |
| Operating earnings | $ | 458 |  |  | $ | 312 |  |  | $ | 770 |  |  |  |  |  |  | $ | 446 |  |  | $ | 265 |  |  | $ | 711 |  |
| Total other expense |  |  |  |  | (45) |  |  |  |  |  |  |  |  |  | (16) |
| Earnings before income taxes |  |  |  |  | $ | 725 |  |  |  |  |  |  |  |  |  |  | $ | 695 |  |

[0000068505-25-000052:notes:162]
|  | Nine Months Ended |
|  | September 27, 2025 |  |  |  |  |  | September 28, 2024 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  |  |  |  |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  |  |  |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Cost of sales | 2,349 |  | 1,686 |  | 4,035 |  |  |  |  |  | 2,322 |  | 1,521 |  | 3,843 |
| Gross margin | 2,746 |  | 1,521 |  | 4,267 |  |  |  |  |  | 2,611 |  | 1,352 |  | 3,963 |
| Selling, general and administrative expenses | 1,079 |  | 292 |  | 1,371 |  |  |  |  |  | 1,000 |  | 265 |  | 1,265 |
| Research and development expenditures | 430 |  | 270 |  | 700 |  |  |  |  |  | 422 |  | 249 |  | 671 |
| Other charges | 64 |  | 88 |  | 152 |  |  |  |  |  | 54 |  | 99 |  | 153 |
| Operating earnings | $ | 1,173 |  |  | $ | 871 |  |  | $ | 2,044 |  |  |  |  |  |  | $ | 1,135 |  |  | $ | 739 |  |  | $ | 1,874 |  |
| Total other expense |  |  |  |  | (92) |  |  |  |  |  |  |  |  |  | (690) |
| Earnings before income taxes |  |  |  |  | $ | 1,952 |  |  |  |  |  |  |  |  |  |  | $ | 1,184 |  |

[0000068505-25-000052:notes:163]
[same as prior period, unchanged from 0000068505-25-000040:notes:161]

[0000068505-25-000052:notes:164]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Products and Systems Integration | $ | 34 |  |  | $ | 24 |  |  | 72 |  | $ | 64 |  |
| Software and Services | 32 |  | 33 |  | 79 |  | 107 |
|  | $ | 66 |  |  | $ | 57 |  |  | 151 |  | $ | 171 |  |

[0000068505-25-000052:notes:165]
[same as prior period, unchanged from 0000068505-25-000040:notes:163]

[0000068505-25-000052:notes:166]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Products and Systems Integration | $ | 23 |  |  | $ | 23 |  |  | $ | 68 |  |  | $ | 67 |  |
| Software and Services | 26 |  | 23 |  | 72 |  | 69 |
|  | $ | 49 |  |  | $ | 46 |  |  | $ | 140 |  |  | $ | 136 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-25-000052:notes:167]
[same as prior period, unchanged from 0000068505-25-000040:notes:165]

[0000068505-25-000052:notes:168]
During the three months ended September 27, 2025, the Company recorded net reorganization of business charges of $14 million, including $12 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $13 million related to employee separation costs and $1 million related to exit costs.

[0000068505-25-000052:notes:169]
During the nine months ended September 27, 2025, the Company recorded net reorganization of business charges of $45 million, including $33 million of charges in Other charges and $12 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $45 million were charges of $46 million related to employee separation costs and $2 million related to exit costs, partially offset by $3 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000052:notes:170]
[same as prior period, unchanged from 0000068505-25-000040:notes:168]

[0000068505-25-000052:notes:171]
| September 27, 2025 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 9 |  |  | $ | 31 |  |
| Software and Services | 5 |  |  | 14 |  |
|  | $ | 14 |  |  | $ | 45 |  |

[0000068505-25-000052:notes:172]
[same as prior period, unchanged from 0000068505-25-000040:notes:170]

[0000068505-25-000052:notes:173]
|  | January 1, 2025 |  | Additional Charges |  | Adjustments |  | Amount Used |  | September 27, 2025 |
| Employee separation costs | $ | 27 |  |  | $ | 46 |  |  | $ | (3) |  |  | $ | (48) |  |  | $ | 22 |  |
| Exit costs | 1 |  |  | 2 |  |  | — |  |  | (2) |  |  | 1 |  |
|  | $ | 28 |  |  | $ | 48 |  |  | $ | (3) |  |  | $ | (50) |  |  | $ | 23 |  |

[0000068505-25-000052:notes:174]
[same as prior period, unchanged from 0000068505-25-000040:notes:172]

[0000068505-25-000052:notes:175]
At January 1, 2025, the Company had an accrual of $1 million for exit costs, related to the Company's exit of the Emergency Service Network contract with the U.K. Home Office. The $1 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at September 27, 2025, and are expected to be paid within one year.

[0000068505-25-000052:notes:176]
[same as prior period, unchanged from 0000068505-25-000040:notes:174]

[0000068505-25-000052:notes:177]
At January 1, 2025, the Company had an accrual of $27 million for employee separation costs. The 2025 additional charges of $46 million represent severance costs for approximately 630 employees. The adjustment of $3 million reflects reversals for accruals no longer needed. The $48 million used reflects cash payments to severed employees. The remaining accrual of $22 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at September 27, 2025, is expected to be paid, primarily within one year, to approximately 660 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-25-000052:notes:178]
[same as prior period, unchanged from 0000068505-25-000040:notes:176]

[0000068505-25-000052:notes:179]
During the three months ended September 28, 2024, the Company recorded net reorganization of business charges of $7 million, consisting of $5 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for employee separation accruals that are no longer needed.

[0000068505-25-000052:notes:180]
During the nine months ended September 28, 2024, the Company recorded net reorganization of business charges of $21 million, including $16 million of charges in Other charges and $5 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $21 million were charges of $30 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000052:notes:181]
| September 28, 2024 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 20 |  |
| Software and Services | 1 |  |  | 1 |  |
|  | $ | 7 |  |  | $ | 21 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-25-000052:notes:182]
Intangible Assets and Goodwill
Silvus Acquisition

[0000068505-25-000052:notes:183]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired and customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million.

[0000068505-25-000052:notes:184]
Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn a catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The contingent earnout consideration, if any, will be paid in shares of common stock. The Company valued the contingent earnout consideration using a Monte Carlo methodology which resulted in the Company recognizing $38 million in purchase consideration at the date of close in Other liabilities on the Company’s Condensed Consolidated Balance Sheet. Contingent earnout consideration will continue to be valued at fair value throughout the earnout term and until paid. Changes to the fair value of the contingent earnout consideration will be recorded as a component of operating income within Other income, net in the Company's Consolidated Statement of Operations.

[0000068505-25-000052:notes:185]
The Company recognized goodwill of $3.0 billion which was allocated primarily to the Products and Systems Integration segment. In addition, the Company recognized $1.8 billion of intangible assets and $387 million of net liabilities, inclusive of $438 million of deferred tax liabilities and $51 million of net tangible assets. Goodwill represents the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized including future customer relationships, new technology and the assembled workforce. The goodwill is not deductible for tax purposes.

[0000068505-25-000052:notes:186]
The identifiable intangible assets were classified as $135 million of trade names, $790 million of customer relationships and $910 million of developed technology which will be amortized over a period of twelve, twelve and eight years, respectively. The fair values of all intangible assets were estimated using the income approach. Customer relationships was valued under the excess earnings method, which assumes that the value of intangible assets is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible assets. Developed technology and trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-25-000052:notes:187]
This business is part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net tangible assets and goodwill may be subject to change.

[0000068505-25-000052:notes:188]
Other Acquisitions

[0000068505-25-000052:notes:189]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $174 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value price of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. The Company recognized $117 million of goodwill, $48 million of identifiable intangible assets and $9 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $15 million of customer relationships and $32 million of developed technology and will be amortized over a period of three, nineteen and eleven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000052:notes:190]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $240 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. The Company recognized $138 million of goodwill, $117 million of identifiable intangible assets, and $15 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $6 million of trade names, $36 million of customer relationships and $75 million of developed technology and will be amortized over a period of nine, nineteen and eighteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000052:notes:191]
[same as prior period, unchanged from 0000068505-25-000040:notes:182]

[0000068505-25-000052:notes:192]
On July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $92 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The Company recognized $49 million of goodwill, $53 million of identifiable intangible assets, and $10 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $7 million of customer relationships and $45 million of developed technology and will be amortized over a period of three, fifteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the third quarter of 2025.

[0000068505-25-000052:notes:193]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The Company recognized $62 million of goodwill, $65 million of identifiable intangible assets and $5 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $11 million of trade names, $51 million of customer relationships and $3 million of developed technology and will be amortized over a period of nine, eighteen and six years, respectively. The acquisition expands the Company's video solutions within the Software and Services segment. The purchase accounting was completed as of the third quarter of 2025.

[0000068505-25-000052:notes:194]
[same as prior period, unchanged from 0000068505-25-000040:notes:185]

[0000068505-25-000052:notes:195]
[same as prior period, unchanged from 0000068505-25-000040:notes:186]

[0000068505-25-000052:notes:196]
[same as prior period, unchanged from 0000068505-25-000040:notes:187]

[0000068505-25-000052:notes:197]
|  | September 27, 2025 |  | December 31, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 2,260 |  |  | $ | 624 |  |  | $ | 1,226 |  |  | $ | 535 |  |
| Customer-related | 2,515 |  |  | 1,198 |  |  | 1,609 |  |  | 1,093 |  |
| Other intangibles | 264 |  |  | 86 |  |  | 118 |  |  | 76 |  |
|  | $ | 5,039 |  |  | $ | 1,908 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-25-000052:notes:198]
Amortization expense on intangible assets was $66 million and $142 million for the three and nine months ended September 27, 2025, respectively. Amortization expense on intangible assets was $38 million and $114 million for the three and nine months ended September 28, 2024, respectively. As of September 27, 2025, annual amortization expense is estimated to be $229 million in 2025, $339 million in 2026, $329 million in 2027, $328 million in 2028, $317 million in 2029 and $313 million in 2030.

[0000068505-25-000052:notes:199]
[same as prior period, unchanged from 0000068505-25-000040:notes:190]

[0000068505-25-000052:notes:200]
|  | September 27, 2025 |  | December 31, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 2,671 |  |  | $ | 488 |  |  | $ | 1,017 |  |  | $ | 409 |  |
| Software and Services | 2,368 |  |  | 1,420 |  |  | 1,936 |  |  | 1,295 |  |
|  | $ | 5,039 |  |  | $ | 1,908 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-25-000052:notes:201]
[same as prior period, unchanged from 0000068505-25-000040:notes:192]

[0000068505-25-000052:notes:202]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2025 to September 27, 2025:

[0000068505-25-000052:notes:203]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2025 | $ | 1,573 |  |  | $ | 1,953 |  |  | $ | 3,526 |  |
| Goodwill acquired | 2,677 |  |  | 552 |  |  | 3,229 |  |
| Purchase accounting adjustments | — |  |  | (5) |  |  | (5) |  |
| Foreign currency | 2 |  |  | 24 |  |  | 26 |  |
| Balance as of September 27, 2025 | $ | 4,252 |  |  | $ | 2,524 |  |  | $ | 6,776 |  |

[0000068505-25-000052:notes:204]
The pro forma financial information assuming fiscal 2025 acquisitions had occurred as of the beginning of 2024 or 2025, was not material for disclosure purposes both individually and in the aggregate for any period.
