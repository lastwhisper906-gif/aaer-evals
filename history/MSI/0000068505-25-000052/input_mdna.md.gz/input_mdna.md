# MSI MD&A — 0000068505-25-000052


## mdna

[0000068505-25-000052:mdna:1]
[same as prior period, unchanged from 0000068505-25-000040:mdna:1]

[0000068505-25-000052:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and nine months ended September 27, 2025 and September 28, 2024, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2024 (the "Form 10-K").

[0000068505-25-000052:mdna:3]
[same as prior period, unchanged from 0000068505-25-000040:mdna:3]

[0000068505-25-000052:mdna:4]
[same as prior period, unchanged from 0000068505-25-000040:mdna:4]

[0000068505-25-000052:mdna:5]
[same as prior period, unchanged from 0000068505-25-000040:mdna:5]

[0000068505-25-000052:mdna:6]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services." Within these segments the Company has three principal product lines in which the Company reports net sales: Mission Critical Networks ("MCN"), Video Security and Access Control ("Video") and Command Center. With the acquisition of Silvus Technologies Holdings Inc. (“Silvus”) in August 2025, the Company will now report net sales from its principal product lines by combining the former Land Mobile Radio Communications and newly acquired Silvus under the new technology name Mission Critical Networks. This name change does not require any financial information to be reclassified from previous periods.

[0000068505-25-000052:mdna:7]
•MCN: Infrastructure, mobile ad-hoc network technology ("MANET"), devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software inclusive of installation and integration, and backed by managed and support services to help assure mission-critical communications availability, security and resiliency.

[0000068505-25-000052:mdna:8]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence ("AI")-powered analytics that help enable visibility to what's happening and bring attention to what’s important to help inform decisions and actions.

[0000068505-25-000052:mdna:9]
•Command Center: Command center solutions and software applications, including AI-powered analytics, that unify voice, video, and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents to help accelerate workflows and improve the accuracy and speed of decisions.

[0000068505-25-000052:mdna:10]
Third Quarter Financial Results

[0000068505-25-000052:mdna:11]
•Net sales were $3.0 billion in the third quarter of 2025 compared to $2.8 billion in the third quarter of 2024.

[0000068505-25-000052:mdna:12]
•Operating earnings were $770 million in the third quarter of 2025 compared to $711 million in the third quarter of 2024.

[0000068505-25-000052:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. was $562 million, or $3.33 per diluted common share, in the third quarter of 2025, compared to $562 million, or $3.29 per diluted common share, in the third quarter of 2024.

[0000068505-25-000052:mdna:14]
•Operating cash flow increased $260 million to $1.6 billion in the first nine months of 2025 compared to $1.3 billion in the first nine months of 2024.

[0000068505-25-000052:mdna:15]
•We repurchased $664 million of common stock and paid $546 million in dividends in the first nine months of 2025.

[0000068505-25-000052:mdna:16]
[same as prior period, unchanged from 0000068505-25-000040:mdna:17]

[0000068505-25-000052:mdna:17]
[same as prior period, unchanged from 0000068505-25-000040:mdna:18]

[0000068505-25-000052:mdna:18]
The current global trade environment is complex and evolving. In early 2025, the U.S. initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, contributing to a global trade landscape subject to evolving tariffs, import/export regulations, including restrictions around rare earth minerals, trade barriers and trade disputes. As a result, we continue to observe elevated volatility and uncertainty around the global supply chain.

[0000068505-25-000052:mdna:19]
We engage with global suppliers across a diverse network of locations around the world. We continue to work with our global supply base to mitigate our exposure to the risks to global reciprocal (and sectoral) tariffs and import/export regulations that have developed, and which may continue to develop, in order to ensure supply continues at levels in order to meet our current customer demand. As a result of the dynamic tariff environment, we have experienced increased costs on materials and components, which we have substantially mitigated during the year and for which we expect to continue to develop mitigation actions going forward.

[0000068505-25-000052:mdna:20]
We continue to see demand for our products and services supported by a multitude of funding sources. In July 2025, the “One Big Beautiful Bill Act” (“OBBB”) was enacted into law by the President of the United States, which provided a number of changes, including funding over the next four years for border security, national security and other opportunities. We expect OBBB to provide an additional source of funding to our federal government customers over the four-year period available through OBBB.

[0000068505-25-000052:mdna:21]
As of October 1, 2025 the U.S. government entered into a shutdown, which, as of October 30, 2025, is still ongoing. A prolonged shutdown may impact our ability to ship and fulfill contracts for certain federal government customers, which may negatively impact our results of operations.

[0000068505-25-000052:mdna:22]
[same as prior period, unchanged from 0000068505-25-000040:mdna:45]

[0000068505-25-000052:mdna:23]
[same as prior period, unchanged from 0000068505-25-000040:mdna:21]

[0000068505-25-000052:mdna:24]
| Segment(s) | Technology | Acquisition | Description | Purchase Price | Date of Acquisition |
| Products and Systems Integration&Software and Services | Mission Critical Networks | Silvus Technologies | Designer and developer of software-defined high-speed MANET technology. | $4.4 billion and share-based compensation of $20 million | August 6, 2025 |
| Software and Services | Command Center | Theatro | Creator of AI and voice-powered communication and digital workflow software for frontline workers. | $174 million and share-based compensation of $5 million | March 6, 2025 |
| Software and Services | Command Center | RapidDeploy | Provider of cloud-native 911 solutions. | $240 million and share-based compensation of $6 million | February 21, 2025 |
| Software and Services | Command Center | 3tc Software | Provider of control room software solutions. | $23 million and share-based compensation of $4 million | October 29, 2024 |
| Software and Services | Command Center | Noggin | Provider of cloud-based business continuity planning, operational resilience and critical event management software. | $92 million and share-based compensation of $19 million | July 1, 2024 |
| Software and Services | Video Security and Access Control | Unnamed vehicle location and management solutions business | Provider of vehicle location and management solutions. | $132 million and share-based compensation of $3 million | July 1, 2024 |
| Products and Systems Integration | Video Security and Access Control | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |

[0000068505-25-000052:mdna:25]
[same as prior period, unchanged from 0000068505-25-000040:mdna:68]

[0000068505-25-000052:mdna:26]
[same as prior period, unchanged from 0000068505-25-000040:mdna:24]

[0000068505-25-000052:mdna:27]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | September 27, 2025 |  | % ofSales* |  | September 28, 2024 |  | % ofSales* |  | September 27, 2025 |  | % ofSales* |  | September 28, 2024 |  | % ofSales* |
| Net sales from products | $ | 1,751 |  |  |  |  | $ | 1,670 |  |  |  |  | $ | 4,731 |  |  |  |  | $ | 4,639 |  |  |  |
| Net sales from services | 1,258 |  |  |  |  | 1,120 |  |  |  |  | 3,571 |  |  |  |  | 3,167 |  |  |  |
| Net sales | 3,009 |  |  |  |  | 2,790 |  |  |  |  | 8,302 |  |  |  |  | 7,806 |  |  |  |
| Costs of products sales | 728 |  |  | 41.6 | % |  | 688 |  |  | 41.2 | % |  | 1,948 |  |  | 41.2 | % |  | 1,941 |  |  | 41.8 | % |
| Costs of services sales | 727 |  |  | 57.8 | % |  | 669 |  |  | 59.7 | % |  | 2,087 |  |  | 58.4 | % |  | 1,902 |  |  | 60.1 | % |
| Costs of sales | 1,455 |  |  |  |  | 1,357 |  |  |  |  | 4,035 |  |  |  |  | 3,843 |  |  |  |
| Gross margin | 1,554 |  |  | 51.6 | % |  | 1,433 |  |  | 51.4 | % |  | 4,267 |  |  | 51.4 | % |  | 3,963 |  |  | 50.8 | % |
| Selling, general and administrative expenses | 485 |  |  | 16.1 | % |  | 439 |  |  | 15.7 | % |  | 1,371 |  |  | 16.5 | % |  | 1,265 |  |  | 16.2 | % |
| Research and development expenditures | 237 |  |  | 7.9 | % |  | 234 |  |  | 8.4 | % |  | 700 |  |  | 8.4 | % |  | 671 |  |  | 8.6 | % |
| Other charges | 62 |  |  | 2.1 | % |  | 49 |  |  | 1.8 | % |  | 152 |  |  | 1.8 | % |  | 153 |  |  | 2.0 | % |
| Operating earnings | 770 |  |  | 25.6 | % |  | 711 |  |  | 25.5 | % |  | 2,044 |  |  | 24.6 | % |  | 1,874 |  |  | 24.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (86) |  |  | (2.9) | % |  | (58) |  |  | (2.1) | % |  | (192) |  |  | (2.3) | % |  | (171) |  |  | (2.2) | % |
| Other, net | 41 |  |  | 1.4 | % |  | 42 |  |  | 1.5 | % |  | 100 |  |  | 1.2 | % |  | (519) |  |  | (6.6) | % |
| Total other expense | (45) |  |  | (1.5) | % |  | (16) |  |  | (0.6) | % |  | (92) |  |  | (1.1) | % |  | (690) |  |  | (8.8) | % |
| Net earnings before income taxes | 725 |  |  | 24.1 | % |  | 695 |  |  | 24.9 | % |  | 1,952 |  |  | 23.5 | % |  | 1,184 |  |  | 15.2 | % |
| Income tax expense | 161 |  |  | 5.4 | % |  | 132 |  |  | 4.7 | % |  | 442 |  |  | 5.3 | % |  | 214 |  |  | 2.7 | % |
| Net earnings | 564 |  |  | 18.7 | % |  | 563 |  |  | 20.2 | % |  | 1,510 |  |  | 18.2 | % |  | 970 |  |  | 12.4 | % |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 0.1 | % |  | 1 |  |  | — | % |  | 5 |  |  | 0.1 | % |  | 4 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 562 |  |  | 18.7 | % |  | $ | 562 |  |  | 20.2 | % |  | $ | 1,505 |  |  | 18.1 | % |  | $ | 966 |  |  | 12.3 | % |
| Earnings per diluted common share | $ | 3.33 |  |  |  |  | $ | 3.29 |  |  |  |  | $ | 8.89 |  |  |  |  | $ | 5.66 |  |  |  |

[0000068505-25-000052:mdna:28]
[same as prior period, unchanged from 0000068505-25-000040:mdna:26]

[0000068505-25-000052:mdna:29]
33

[0000068505-25-000052:mdna:30]
Results of Operations—Three months ended September 27, 2025 compared to three months ended September 28, 2024

[0000068505-25-000052:mdna:31]
The results of operations for the third quarter of 2025 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-25-000052:mdna:32]
[same as prior period, unchanged from 0000068505-25-000040:mdna:30]

[0000068505-25-000052:mdna:33]
[same as prior period, unchanged from 0000068505-25-000040:mdna:31]

[0000068505-25-000052:mdna:34]
[same as prior period, unchanged from 0000068505-25-000040:mdna:32]

[0000068505-25-000052:mdna:35]
[same as prior period, unchanged from 0000068505-25-000040:mdna:33]

[0000068505-25-000052:mdna:36]
[same as prior period, unchanged from 0000068505-25-000040:mdna:34]

[0000068505-25-000052:mdna:37]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,360 |  |  | $ | 761 |  |  | $ | 2,121 |  |  | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |
| International | 537 |  |  | 351 |  |  | 888 |  |  | 480 |  |  | 303 |  |  | 783 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,598 |  |  | $ | 643 |  |  | $ | 2,241 |  |  | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |
| Video | 299 |  |  | 235 |  |  | 534 |  |  | 292 |  |  | 208 |  |  | 500 |  |
| Command Center | — |  |  | 234 |  |  | 234 |  |  | — |  |  | 202 |  |  | 202 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Operating earnings | $ | 458 |  |  | $ | 312 |  |  | $ | 770 |  |  | $ | 446 |  |  | $ | 265 |  |  | $ | 711 |  |
| Operating margins | 24.1 | % |  | 28.1 | % |  | 25.6 | % |  | 25.0 | % |  | 26.3 | % |  | 25.5 | % |

[0000068505-25-000052:mdna:38]
[same as prior period, unchanged from 0000068505-25-000040:mdna:36]

[0000068505-25-000052:mdna:39]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in the third quarter of 2025 and 64% in the third quarter of 2024. The Software and Services segment’s net sales represented 37% of our net sales in the third quarter of 2025 and 36% in the third quarter of 2024.

[0000068505-25-000052:mdna:40]
Net sales increased $219 million, or 8%, in the third quarter of 2025 compared to the third quarter of 2024. The $113 million, or 6% increase in net sales within the Products and Systems Integration segment was driven by an increase of 12% in the International region and an increase of 4% in the North America region. The $106 million, or 11%, increase in net sales within the Software and Services segment was driven by an increase of 8% in the North America region and an increase of 16% in the International region. Net sales includes:

[0000068505-25-000052:mdna:41]
•an increase in the Products and Systems Integration segment, inclusive of $111 million of revenue from acquisitions, driven by an increase in MCN and Video;

[0000068505-25-000052:mdna:42]
•an increase in the Software and Services segment, inclusive of $12 million of revenue from acquisitions, driven by an increase in MCN, Command Center and Video; and

[0000068505-25-000052:mdna:43]
•inclusive of $21 million from favorable currency rates.

[0000068505-25-000052:mdna:44]
[same as prior period, unchanged from 0000068505-25-000040:mdna:42]

[0000068505-25-000052:mdna:45]
•a 6% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in MCN, Command Center and Video; and

[0000068505-25-000052:mdna:46]
•a 13% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in MCN, Video and Command Center.

[0000068505-25-000052:mdna:47]
[same as prior period, unchanged from 0000068505-25-000040:mdna:46]

[0000068505-25-000052:mdna:48]
The 6% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-25-000052:mdna:49]
•$106 million, or 7%, growth in MCN, inclusive of revenue from acquisitions, driven by the International and North America regions;

[0000068505-25-000052:mdna:50]
•$7 million, or 2%, growth in Video, driven by the North America and International regions; and

[0000068505-25-000052:mdna:51]
•inclusive of $11 million from favorable currency rates.

[0000068505-25-000052:mdna:52]
[same as prior period, unchanged from 0000068505-25-000040:mdna:51]

[0000068505-25-000052:mdna:53]
The 11% increase in the Software and Services segment was driven by the following:

[0000068505-25-000052:mdna:54]
•$47 million, or 8%, growth in MCN, inclusive of revenue from acquisitions, driven by the International and North America regions;

[0000068505-25-000052:mdna:55]
•$32 million, or 16%, growth in Command Center, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-25-000052:mdna:56]
•$27 million, or 13%, growth in Video, driven by the International and North America regions; and

[0000068505-25-000052:mdna:57]
•inclusive of $10 million from favorable currency rates.

[0000068505-25-000052:mdna:58]
[same as prior period, unchanged from 0000068505-25-000040:mdna:57]

[0000068505-25-000052:mdna:59]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 1,019 |  |  | $ | 962 |  |  | 6 | % |
| Gross margin from Software and Services | 535 |  |  | 471 |  |  | 14 | % |
| Gross margin | $ | 1,554 |  |  | $ | 1,433 |  |  | 8 | % |

[0000068505-25-000052:mdna:60]
Gross margin was 51.6% of net sales in the third quarter of 2025 compared to 51.4% in the third quarter of 2024. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000052:mdna:61]
•a 1.3% increase in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales; partially offset by

[0000068505-25-000052:mdna:62]
•a 0.2% decrease in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher tariffs.

[0000068505-25-000052:mdna:63]
[same as prior period, unchanged from 0000068505-25-000040:mdna:62]

[0000068505-25-000052:mdna:64]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 384 |  |  | $ | 346 |  |  | 11 | % |
| SG&A expenses from Software and Services | 101 |  |  | 93 |  |  | 9 | % |
| SG&A expenses | $ | 485 |  |  | $ | 439 |  |  | 10 | % |

[0000068505-25-000052:mdna:65]
SG&A expenses increased 10% in the third quarter of 2025 compared to the third quarter of 2024 primarily driven by:

[0000068505-25-000052:mdna:66]
•a $38 million, or 11%, increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses; and

[0000068505-25-000052:mdna:67]
•an $8 million, or 9%, increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses and higher employee incentive costs.

[0000068505-25-000052:mdna:68]
SG&A expenses were 16.1% of net sales in the third quarter of 2025 compared to 15.7% of net sales in the third quarter of 2024.

[0000068505-25-000052:mdna:69]
[same as prior period, unchanged from 0000068505-25-000040:mdna:69]

[0000068505-25-000052:mdna:70]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 146 |  |  | $ | 146 |  |  | — | % |
| R&D expenditures from Software and Services | 91 |  |  | 88 |  |  | 3 | % |
| R&D expenditures | $ | 237 |  |  | $ | 234 |  |  | 1 | % |

[0000068505-25-000052:mdna:71]
R&D expenditures increased $3 million, or 1%, in the third quarter of 2025 compared to the third quarter of 2024 primarily driven by higher expenses associated with acquired businesses. R&D expenditures were 7.9% of net sales in the third quarter of 2025 and 8.4% of net sales in the third quarter of 2024.

[0000068505-25-000052:mdna:72]
[same as prior period, unchanged from 0000068505-25-000040:mdna:72]

[0000068505-25-000052:mdna:73]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Other charges from Products and Systems Integration | $ | 31 |  |  | $ | 24 |  |
| Other charges from Software and Services | 31 |  |  | 25 |  |
| Other charges | $ | 62 |  |  | $ | 49 |  |

[0000068505-25-000052:mdna:74]
Other charges increased $13 million in the third quarter of 2025 compared to the third quarter of 2024. The increase was primarily driven by:

[0000068505-25-000052:mdna:75]
•$55 million of acquisition related transaction fees, primarily related to the acquisition of Silvus, in the third quarter of 2025 compared to $4 million of acquisition related transaction fees in the third quarter of 2024;

[0000068505-25-000052:mdna:76]
•$66 million of intangible amortization expense in the third quarter of 2025 compared to $38 million of intangible amortization expense in the third quarter of 2024; and

[0000068505-25-000052:mdna:77]
•$12 million of reorganization of business expenses in the third quarter of 2025 compared to $5 million of reorganization of business expenses in the third quarter of 2024; partially offset by

[0000068505-25-000052:mdna:78]
•$74 million of gains on the Hytera litigation for amounts recovered through legal proceedings due to the theft of our trade secrets in the third quarter of 2025 that did not occur in the third quarter of 2024.

[0000068505-25-000052:mdna:79]
[same as prior period, unchanged from 0000068505-25-000040:mdna:79]

[0000068505-25-000052:mdna:80]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Operating earnings from Products and Systems Integration | $ | 458 |  |  | $ | 446 |  |
| Operating earnings from Software and Services | 312 |  |  | 265 |  |
| Operating earnings | $ | 770 |  |  | $ | 711 |  |

[0000068505-25-000052:mdna:81]
Operating earnings increased $59 million, or 8%, in the third quarter of 2025 compared to the third quarter of 2024. The increase in Operating earnings was due to:

[0000068505-25-000052:mdna:82]
•a $47 million increase in the Software and Services segment, primarily driven by higher sales and improved operating leverage, partially offset by higher expenses associated with acquired businesses and higher employee incentive costs, including share-based compensation; and

[0000068505-25-000052:mdna:83]
•a $12 million increase in the Products and Systems Integration segment, primarily driven by higher sales, improved operating leverage, and a $74 million gain on the Hytera litigation for amounts recovered through legal proceedings due to the theft of our trade secrets, partially offset by an increase in acquisition related transaction fees related to the Silvus acquisition, higher intangible amortization expense, higher employee incentive costs, including share-based compensation, higher expenses associated with acquired businesses, and higher tariffs.

[0000068505-25-000052:mdna:84]
[same as prior period, unchanged from 0000068505-25-000040:mdna:84]

[0000068505-25-000052:mdna:85]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Interest expense, net | $ | (86) |  |  | $ | (58) |  |

[0000068505-25-000052:mdna:86]
The $28 million increase in Interest expense, net in the third quarter of 2025 compared to the third quarter of 2024 was primarily driven by higher outstanding debt, partially offset by higher interest income.

[0000068505-25-000052:mdna:87]
[same as prior period, unchanged from 0000068505-25-000040:mdna:87]

[0000068505-25-000052:mdna:88]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Other, net | $ | 41 |  |  | $ | 42 |  |

[0000068505-25-000052:mdna:89]
The $1 million decrease in Other, net in the third quarter of 2025 compared to the third quarter of 2024 was primarily driven by:

[0000068505-25-000052:mdna:90]
•a $4 million gain on foreign currency in the third quarter of 2025 compared to a $26 million loss on foreign currency in the third quarter of 2024; partially offset by

[0000068505-25-000052:mdna:91]
•a $6 million loss on derivatives in the third quarter of 2025 compared to a $22 million gain on derivatives in the third quarter of 2024.

[0000068505-25-000052:mdna:92]
[same as prior period, unchanged from 0000068505-25-000040:mdna:94]

[0000068505-25-000052:mdna:93]
|  | Three Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Income tax expense | $ | 161 |  |  | $ | 132 |  |

[0000068505-25-000052:mdna:94]
The effective tax rate for the three months ended September 27, 2025 of 22% was higher than the effective tax rate for the three months ended September 28, 2024 of 19%, primarily due to non-deductible transaction costs related to the acquisition of Silvus, favorable U.S. return-to-provision adjustments from implementing a business initiative in 2024, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, partially offset by higher excess tax benefits of share-based compensation in 2025.

[0000068505-25-000052:mdna:95]
On July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law, introducing a broad range of changes to the U.S. corporate income tax framework. The legislation includes business provisions that impact our tax position, including tax cut extensions and modifications to the international tax framework and corporate income tax deductions. We have evaluated the effects of these changes on our income tax provision, income tax payable, and deferred tax asset balances, which are reflected in this quarter's results. As of the three months ended September 27, 2025, the 2025 impact of the enacted legislation on our tax position was not material. We will continue to recognize the effects of the legislation in accordance with the effective dates of the applicable provisions, and plan to continue to assess the ongoing impact of this legislation as further guidance is made available.

[0000068505-25-000052:mdna:96]
Results of Operations—Nine months ended September 27, 2025 compared to Nine months ended September 28, 2024

[0000068505-25-000052:mdna:97]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,789 |  |  | $ | 2,211 |  |  | $ | 6,000 |  |  | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |
| International | 1,306 |  |  | 996 |  |  | 2,302 |  |  | 1,302 |  |  | 888 |  |  | 2,190 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 4,269 |  |  | $ | 1,878 |  |  | $ | 6,147 |  |  | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |
| Video | 826 |  |  | 672 |  |  | 1,498 |  |  | 821 |  |  | 553 |  |  | 1,374 |  |
| Command Center | — |  |  | 657 |  |  | 657 |  |  | — |  |  | 581 |  |  | 581 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Operating earnings | $ | 1,173 |  |  | $ | 871 |  |  | $ | 2,044 |  |  | $ | 1,135 |  |  | $ | 739 |  |  | $ | 1,874 |  |
| Operating margins | 23.0 | % |  | 27.2 | % |  | 24.6 | % |  | 23.0 | % |  | 25.7 | % |  | 24.0 | % |

[0000068505-25-000052:mdna:98]
[same as prior period, unchanged from 0000068505-25-000040:mdna:100]

[0000068505-25-000052:mdna:99]
The Products and Systems Integration segment's net sales represented 61% of our net sales in the first nine months of 2025 and 63% in the first nine months of 2024. Net sales from the Software and Services segment represented 39% of our net sales in the first nine months of 2025 and 37% in the first nine months of 2024.

[0000068505-25-000052:mdna:100]
Net sales increased $496 million, or 6%, in the first nine months of 2025 compared to the first nine months of 2024. The $334 million, or 12%, increase in net sales within the Software and Services segment was driven by an increase of 11% in the North America region and an increase of 12% in the International region. The $162 million, or 3%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 4% in the North America region and an increase of $4 million in the International region. Net sales includes:

[0000068505-25-000052:mdna:101]
•an increase in the Software and Services segment, inclusive of $83 million of revenue from acquisitions, driven by an increase in MCN, Video and Command Center;

[0000068505-25-000052:mdna:102]
•an increase in the Products and Systems Integration segment, inclusive of $111 million of revenue from acquisitions, driven by an increase in MCN and Video; and

[0000068505-25-000052:mdna:103]
•inclusive of $5 million from favorable currency rates.

[0000068505-25-000052:mdna:104]
[same as prior period, unchanged from 0000068505-25-000040:mdna:106]

[0000068505-25-000052:mdna:105]
•a 7% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in MCN, Video and Command Center; and

[0000068505-25-000052:mdna:106]
•a 5% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in MCN, Video and Command Center.

[0000068505-25-000052:mdna:107]
[same as prior period, unchanged from 0000068505-25-000040:mdna:109]

[0000068505-25-000052:mdna:108]
The 3% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-25-000052:mdna:109]
•$157 million, or 4% growth in MCN, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-25-000052:mdna:110]
•$5 million, or 1% growth in Video, driven by the North America region, partially offset by International region; and

[0000068505-25-000052:mdna:111]
•inclusive of $1 million from favorable currency rates.

[0000068505-25-000052:mdna:112]
[same as prior period, unchanged from 0000068505-25-000040:mdna:114]

[0000068505-25-000052:mdna:113]
[same as prior period, unchanged from 0000068505-25-000040:mdna:115]

[0000068505-25-000052:mdna:114]
•$139 million, or 8% growth in MCN, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-25-000052:mdna:115]
•$119 million, or 22% growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-25-000052:mdna:116]
•$76 million, or 13% growth in Command Center, inclusive of revenue from acquisitions, driven by the North America and International regions; and

[0000068505-25-000052:mdna:117]
•inclusive of $4 million from favorable currency rates.

[0000068505-25-000052:mdna:118]
[same as prior period, unchanged from 0000068505-25-000040:mdna:120]

[0000068505-25-000052:mdna:119]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 2,746 |  |  | $ | 2,611 |  |  | 5 | % |
| Gross margin from Software and Services | 1,521 |  |  | 1,352 |  |  | 13 | % |
| Gross margin | $ | 4,267 |  |  | $ | 3,963 |  |  | 8 | % |

[0000068505-25-000052:mdna:120]
Gross margin was 51.4% of net sales in the first nine months of 2025 compared to 50.8% in the first nine months of 2024. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000052:mdna:121]
•a 1.0% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, favorable mix and lower direct material costs, despite higher tariffs; and

[0000068505-25-000052:mdna:122]
•a 0.3% increase in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales and improved operating leverage.

[0000068505-25-000052:mdna:123]
[same as prior period, unchanged from 0000068505-25-000040:mdna:125]

[0000068505-25-000052:mdna:124]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 1,079 |  |  | $ | 1,000 |  |  | 8 | % |
| SG&A expenses from Software and Services | 292 |  |  | 265 |  |  | 10 | % |
| SG&A expenses | $ | 1,371 |  |  | $ | 1,265 |  |  | 8 | % |

[0000068505-25-000052:mdna:125]
SG&A expenses increased 8% in the first nine months of 2025 compared to the first nine months of 2024 primarily driven by:

[0000068505-25-000052:mdna:126]
•a $79 million, or 8%, increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share-based compensation and investments in video, higher expenses related to legal matters, including Hytera-related legal expenses, increased reorganization expenses and higher expenses associated with acquired businesses; and

[0000068505-25-000052:mdna:127]
•a $27 million, or 10%, increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses and higher employee incentive costs, including investments in video.

[0000068505-25-000052:mdna:128]
SG&A expenses were 16.5% of net sales in the first nine months of 2025 compared to 16.2% of net sales in the first nine months of 2024.

[0000068505-25-000052:mdna:129]
[same as prior period, unchanged from 0000068505-25-000040:mdna:131]

[0000068505-25-000052:mdna:130]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 430 |  |  | $ | 422 |  |  | 2 | % |
| R&D expenditures from Software and Services | 270 |  |  | 249 |  |  | 8 | % |
| R&D expenditures | $ | 700 |  |  | $ | 671 |  |  | 4 | % |

[0000068505-25-000052:mdna:131]
R&D expenditures increased 4% in the first nine months of 2025 compared to the first nine months of 2024 primarily driven by:

[0000068505-25-000052:mdna:132]
•a $21 million, or 8%, increase in Software and Services R&D expenditures primarily due to higher employee incentive costs, including investments in video and share-based compensation, and higher expenses associated with acquired businesses; and

[0000068505-25-000052:mdna:133]
•an $8 million, or 2%, increase in Products and Systems Integration R&D expenditures primarily due to higher employee incentive costs, and higher expenses associated with acquired businesses.

[0000068505-25-000052:mdna:134]
R&D expenditures were 8.4% of net sales in the first nine months of 2025 compared to 8.6% of net sales in the first nine months of 2024.

[0000068505-25-000052:mdna:135]
[same as prior period, unchanged from 0000068505-25-000040:mdna:137]

[0000068505-25-000052:mdna:136]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Other charges from Products and Systems Integration | $ | 64 |  |  | $ | 54 |  |
| Other charges from Software and Services | 88 |  |  | 99 |  |
| Other charges | $ | 152 |  |  | $ | 153 |  |

[0000068505-25-000052:mdna:137]
Other charges decreased by $1 million in the first nine months of 2025 compared to the first nine months of 2024. The decrease was driven primarily by:

[0000068505-25-000052:mdna:138]
•$94 million of gains on the Hytera litigation for the amounts recovered through legal proceedings due to the theft of our trade secrets in the first nine months of 2025 that did not occur in the first nine months of 2024; partially offset by

[0000068505-25-000052:mdna:139]
•$63 million of acquisition related transaction fees, primarily related to the acquisition of Silvus, in the first nine months of 2025 compared to $11 million of acquisition related transaction fees in the first nine months of 2024;

[0000068505-25-000052:mdna:140]
•$142 million of intangible amortization expense in the first nine months of 2025 compared to $114 million of intangible amortization expense in the first nine months of 2024; and

[0000068505-25-000052:mdna:141]
•$33 million of reorganization of business expense in the first nine months of 2025 compared to $16 million in the first nine months of 2024.

[0000068505-25-000052:mdna:142]
[same as prior period, unchanged from 0000068505-25-000040:mdna:143]

[0000068505-25-000052:mdna:143]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Operating earnings from Products and Systems Integration | $ | 1,173 |  |  | $ | 1,135 |  |
| Operating earnings from Software and Services | 871 |  |  | 739 |  |
| Operating earnings | $ | 2,044 |  |  | $ | 1,874 |  |

[0000068505-25-000052:mdna:144]
Operating earnings increased $170 million, or 9%, in the first nine months of 2025 compared to the first nine months of 2024. The increase in Operating earnings was due to:

[0000068505-25-000052:mdna:145]
•a $132 million increase in the Software and Services segment, primarily driven by higher sales, partially offset by higher expenses associated with acquired businesses, higher employee incentive costs, including investments in video and share-based compensation, and increased reorganization expenses; and

[0000068505-25-000052:mdna:146]
•a $38 million increase in the Products and Systems Integration segment, primarily driven by higher sales, $94 million of gains on the Hytera litigation for amounts recovered through legal proceedings due to the theft of our trade secrets, favorable mix, and lower direct material costs, despite higher tariffs, partially offset by higher employee incentive costs, including share-based compensation and investments in video, an increase in acquisition related transaction fees primarily related to the Silvus acquisition, increased intangible amortization expenses, higher expenses related to legal matters, including Hytera-related legal expenses, higher expenses associated with acquired businesses and increased reorganization expenses.

[0000068505-25-000052:mdna:147]
[same as prior period, unchanged from 0000068505-25-000040:mdna:148]

[0000068505-25-000052:mdna:148]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Interest expense, net | $ | (192) |  |  | $ | (171) |  |

[0000068505-25-000052:mdna:149]
The $21 million increase in Interest expense, net in the first nine months of 2025 compared to the first nine months of 2024 was primarily driven by higher outstanding debt, partially offset by interest accruals related to audits with tax authorities in foreign jurisdictions in 2024 and higher interest income.

[0000068505-25-000052:mdna:150]
[same as prior period, unchanged from 0000068505-25-000040:mdna:151]

[0000068505-25-000052:mdna:151]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Other, net | $ | 100 |  |  | $ | (519) |  |

[0000068505-25-000052:mdna:152]
The $619 million increase in Other, net in the first nine months of 2025 compared to the first nine months of 2024 was primarily driven by:

[0000068505-25-000052:mdna:153]
•a $585 million loss from the extinguishment of the $1.0 billion of 1.75% senior convertible notes issued to Silver Lake Partners (the "Silver Lake Convertible Debt") which was recognized in the first nine months of 2024;

[0000068505-25-000052:mdna:154]
•a $41 million gain on derivative instruments in the first nine months of 2025 compared to a $7 million gains on derivative instruments in the first nine months of 2024;

[0000068505-25-000052:mdna:155]
•a $21 million gain on fair value adjustments to equity investments in the first nine months of 2025 compared to a $4 million loss on fair value adjustments to equity investments in the first nine months of 2024; and

[0000068505-25-000052:mdna:156]
•an $11 million loss on assessments of uncertain tax positions in the first nine months of 2024 that did not occur in the first nine months of 2025; partially offset by

[0000068505-25-000052:mdna:157]
•a $57 million loss on foreign currency in the first nine months of 2025 compared to a $22 million losses on foreign currency in the first nine months of 2024.

[0000068505-25-000052:mdna:158]
[same as prior period, unchanged from 0000068505-25-000040:mdna:159]

[0000068505-25-000052:mdna:159]
|  | Nine Months Ended |
| (In millions) | September 27, 2025 |  | September 28, 2024 |
| Income tax expense | $ | 442 |  |  | $ | 214 |  |

[0000068505-25-000052:mdna:160]
The effective tax rate for the nine months ended September 27, 2025 of 23% was higher than the effective tax rate for the nine months ended September 28, 2024 of 18%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, partially offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in 2024.

[0000068505-25-000052:mdna:161]
On July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law, introducing a broad range of changes to the U.S. corporate income tax framework. The legislation includes business provisions that impact our tax position, including tax cut extensions and modifications to the international tax framework and corporate income tax deductions. We have evaluated the effects of these changes on our income tax provision, income tax payable, and deferred tax asset balances, which are reflected in this quarter's results. As of September 27, 2025, the 2025 impact of the enacted legislation on our tax position was not material. We will continue to recognize the effects of the legislation in accordance with the effective dates of the applicable provisions, and plan to continue to assess the ongoing impact of this legislation as further guidance is made available.

[0000068505-25-000052:mdna:162]
[same as prior period, unchanged from 0000068505-25-000040:mdna:163]

[0000068505-25-000052:mdna:163]
During the third quarter of 2025, we recorded net reorganization of business charges of $14 million, consisting of $12 million of charges in Other charges and $2 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $13 million related to employee separation costs and $1 million related to exit costs.

[0000068505-25-000052:mdna:164]
During the first nine months of 2025, we recorded net reorganization of business charges of $45 million, including $33 million of charges recorded within Other charges and $12 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $45 million were charges of $46 million related to employee separation costs and $2 million related to exit costs, partially offset by $3 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000052:mdna:165]
41

[0000068505-25-000052:mdna:166]
During the third quarter of 2024, we recorded net reorganization of business charges of $7 million, including $5 million of charges recorded within Other charges and $2 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations. Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for employee separation accruals that are no longer needed.

[0000068505-25-000052:mdna:167]
During the first nine months of 2024, we recorded net reorganization of business charges of $21 million, including $16 million of charges recorded within Other charges and $5 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $21 million were charges of $30 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $5 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000052:mdna:168]
[same as prior period, unchanged from 0000068505-25-000040:mdna:168]

[0000068505-25-000052:mdna:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Products and Systems Integration | $ | 9 |  |  | $ | 6 |  |  | $ | 31 |  |  | $ | 20 |  |
| Software and Services | 5 |  |  | 1 |  |  | 14 |  |  | 1 |  |
|  | $ | 14 |  |  | $ | 7 |  |  | $ | 45 |  |  | $ | 21 |  |

[0000068505-25-000052:mdna:170]
Cash payments for employee severance in connection with the reorganization of business plans were $48 million in the first nine months of 2025 and $27 million in the first nine months of 2024. The reorganization of business accrual at September 27, 2025 was $22 million related to employee separation costs that are expected to be paid primarily within one year.

[0000068505-25-000052:mdna:171]
At January 1, 2025, we had an accrual of $1 million for exit costs related to our exit of the ESN contract with the U.K. Home Office. The $1 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at September 27, 2025, and are expected to be paid within one year.

[0000068505-25-000052:mdna:172]
[same as prior period, unchanged from 0000068505-25-000040:mdna:172]

[0000068505-25-000052:mdna:173]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 1,581 |  |  | $ | 1,321 |  |
| Investing activities | (4,972) |  |  | (400) |  |
| Financing activities | 2,111 |  |  | (1,234) |  |
| Effect of exchange rates on cash and cash equivalents | 72 |  |  | 12 |  |
| Decrease in cash and cash equivalents | $ | (1,208) |  |  | $ | (301) |  |

[0000068505-25-000052:mdna:174]
[same as prior period, unchanged from 0000068505-25-000040:mdna:174]

[0000068505-25-000052:mdna:175]
At September 27, 2025, $645 million of the $894 million cash and cash equivalents balance was held in the U.S. and $249 million was held in other countries.

[0000068505-25-000052:mdna:176]
[same as prior period, unchanged from 0000068505-25-000040:mdna:176]

[0000068505-25-000052:mdna:177]
The increase in cash flows provided by operating activities from the first nine months of 2024 to the first nine months of 2025 was driven primarily by higher earnings, net of non-cash charges.

[0000068505-25-000052:mdna:178]
[same as prior period, unchanged from 0000068505-25-000040:mdna:178]

[0000068505-25-000052:mdna:179]
The increase in cash flows used for investing activities in the first nine months of 2025 compared to the first nine months of 2024 was primarily due to the $4.4 billion in cash used in the acquisition of Silvus.

[0000068505-25-000052:mdna:180]
42

[0000068505-25-000052:mdna:181]
[same as prior period, unchanged from 0000068505-25-000040:mdna:180]

[0000068505-25-000052:mdna:182]
The increase in cash flows provided by financing activities in the first nine months of 2025 compared to the cash flows used for financing activities in the first nine months of 2024 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-25-000052:mdna:183]
•$1.4 billion increase in net proceeds from the issuance of debt in the first nine months of 2025 driven by the issuance of our 4.85% senior notes due 2030, 5.2% senior notes due 2032, 5.55% senior notes due 2035, 364-day delayed draw term loan and our three-year delayed draw term loan ("term loan due 2028") compared to the issuance of debt in the first nine months of 2024 driven by the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034;

[0000068505-25-000052:mdna:184]
•$1.6 billion decrease in the repayment of debt driven by the repayment of our 7.5% debentures and 6.5% debentures in the first nine months of 2025 compared to the repurchase of the Silver Lake Convertible Debt in the first nine months of 2024; and

[0000068505-25-000052:mdna:185]
•$923 million increase in net proceeds from short-term borrowings, including commercial paper, in the first nine months of 2025 which did not occur in the first nine months of 2024; partially offset by

[0000068505-25-000052:mdna:186]
•$523 million increase in share repurchases in the first nine months of 2025 compared to the first nine months of 2024;

[0000068505-25-000052:mdna:187]
•$56 million increase in the payment of dividends in the first nine months of 2025 compared to the first nine months of 2024; and

[0000068505-25-000052:mdna:188]
•$22 million increase in cash used for the issuance of common stock primarily driven by an increase in tax withholdings in the first nine months of 2025 compared to the first nine months of 2024.

[0000068505-25-000052:mdna:189]
[same as prior period, unchanged from 0000068505-25-000040:mdna:187]

[0000068505-25-000052:mdna:190]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended September 27, 2025 and September 28, 2024:

[0000068505-25-000052:mdna:191]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Accounts receivable sales proceeds | $ | 19 |  |  | $ | 15 |  |  | $ | 19 |  |  | $ | 15 |  |
| Long-term receivables sales proceeds | $ | 58 |  |  | $ | 56 |  |  | 171 |  |  | 82 |  |
| Total proceeds from receivable sales | $ | 77 |  |  | $ | 71 |  |  | $ | 190 |  |  | $ | 97 |  |

[0000068505-25-000052:mdna:192]
[same as prior period, unchanged from 0000068505-25-000040:mdna:190]

[0000068505-25-000052:mdna:193]
We had outstanding debt of $9.3 billion at September 27, 2025, of which $928 million was current. We had outstanding debt of $6.0 billion at December 31, 2024, of which $322 million was current.

[0000068505-25-000052:mdna:194]
On June 16, 2025, we issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032, $900 million of 5.55% senior notes due 2035. We recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-25-000052:mdna:195]
On August 6, 2025 we borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million term loan due 2028 to fund a portion of the acquisition of Silvus. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and the Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. We were in compliance with our financial covenants as of September 27, 2025. During the three months ended September 27, 2025, the weighted average interest rate of the 364-day facility and term loan due 2028 was 5.30% and 5.25%, respectively.

[0000068505-25-000052:mdna:196]
During the three months ended September 27, 2025, we repaid the $70 million aggregate principal amount of the 6.5% debentures due 2025. Additionally, during the nine months ended September 27, 2025, we repaid the $252 million aggregate principal amount of the 7.5% debentures due 2025.

[0000068505-25-000052:mdna:197]
On April 25, 2025, we entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced our $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of September 27, 2025.

[0000068505-25-000052:mdna:198]
We have an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of September 27, 2025 we had outstanding other short-term borrowings of $179 million, inclusive of the commercial paper program, with a weighted-average interest rate of 4.52% during the three months ended September 27, 2025.

[0000068505-25-000052:mdna:199]
[same as prior period, unchanged from 0000068505-25-000040:mdna:196]

[0000068505-25-000052:mdna:200]
[same as prior period, unchanged from 0000068505-25-000040:mdna:197]

[0000068505-25-000052:mdna:201]
During the three and nine months ended September 27, 2025, we repurchased approximately 0.3 million and 1.5 million shares at an average price of $467.10 and $434.41 per share for an aggregate amount of $121 million and $664 million, excluding transaction costs and excise tax. As of September 27, 2025, we had used approximately $16.4 billion of the share repurchase authority to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-25-000052:mdna:202]
[same as prior period, unchanged from 0000068505-25-000040:mdna:199]

[0000068505-25-000052:mdna:203]
During the three and nine months ended of 2025 we paid $182 million and $546 million, respectively, in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $182 million in cash dividends to holders of our common stock.

[0000068505-25-000052:mdna:204]
[same as prior period, unchanged from 0000068505-25-000040:mdna:201]

[0000068505-25-000052:mdna:205]
[same as prior period, unchanged from 0000068505-25-000040:mdna:202]

[0000068505-25-000052:mdna:206]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases.

[0000068505-25-000052:mdna:207]
[same as prior period, unchanged from 0000068505-25-000040:mdna:205]

[0000068505-25-000052:mdna:208]
[same as prior period, unchanged from 0000068505-25-000040:mdna:206]

[0000068505-25-000052:mdna:209]
We had outstanding commitments to provide long-term financing to third parties totaling $218 million at September 27, 2025, compared to $105 million at December 31, 2024.

[0000068505-25-000052:mdna:210]
[same as prior period, unchanged from 0000068505-25-000040:mdna:208]

[0000068505-25-000052:mdna:211]
See “Recent Accounting Pronouncements” and "Recently Adopted Accounting Pronouncements" in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
