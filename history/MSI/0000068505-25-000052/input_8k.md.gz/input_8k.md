# MSI 8-K — 0000068505-25-000050 filed 2025-10-30

## item codes, every 8-K on or before 2025-10-30

- 2025-10-30 0000068505-25-000050 — 2.02, 9.01
- 2025-08-07 0000068505-25-000038 — 2.02, 9.01
- 2025-08-06 0001193125-25-174512 — 2.01, 2.03, 7.01, 9.01
- 2025-07-21 0001193125-25-161886 — 1.01, 9.01
- 2025-06-16 0001193125-25-141449 — 8.01, 9.01
- 2025-05-27 0001193125-25-127588 — 1.01, 3.02, 7.01, 9.01
- 2025-05-19 0001193125-25-122455 — 5.07, 8.01
- 2025-05-01 0000068505-25-000022 — 2.02, 9.01
- 2025-04-25 0001193125-25-096928 — 1.01, 1.02, 2.03, 9.01
- 2025-02-13 0000068505-25-000008 — 2.02, 9.01
- 2024-11-07 0000068505-24-000032 — 2.02, 9.01
- 2024-10-09 0001193125-24-235267 — 5.02
- 2024-08-26 0001193125-24-207088 — 5.02, 9.01
- 2024-08-01 0000068505-24-000022 — 2.02, 9.01
- 2024-05-17 0001193125-24-141186 — 5.07
- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2025-10-30

- none on or before 2025-10-30

## item 2.02 — earnings release, exhibit 99.1

[0000068505-25-000050:8k_2_02:1]
EX-99.1
2
msiq32025pressrelease.htm
EX-99.1

[0000068505-25-000050:8k_2_02:2]
Document

[0000068505-25-000050:8k_2_02:3]
Exhibit 99.1

[0000068505-25-000050:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2025 Financial Results

[0000068505-25-000050:8k_2_02:5]
Company raises full-year earnings outlook following record Q3 revenue, earnings and operating cash flow

[0000068505-25-000050:8k_2_02:6]
•Sales of $3.0 billion, up 8% versus a year ago

[0000068505-25-000050:8k_2_02:7]
◦Products and Systems Integration sales up 6%

[0000068505-25-000050:8k_2_02:8]
◦Software and Services sales up 11%

[0000068505-25-000050:8k_2_02:9]
•GAAP earnings per share ("EPS") of $3.33; up 1% versus a year ago

[0000068505-25-000050:8k_2_02:10]
•Non-GAAP EPS* of $4.06, up 9% versus a year ago

[0000068505-25-000050:8k_2_02:11]
•Record Q3 operating cash flow of $799 million, up $40 million versus a year ago

[0000068505-25-000050:8k_2_02:12]
•Record Q3 ending backlog of $14.6 billion, up $467 million versus a year ago

[0000068505-25-000050:8k_2_02:13]
•Acquired Silvus Technologies ("Silvus") for $4.4 billion

[0000068505-25-000050:8k_2_02:14]
CHICAGO – October 30, 2025 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of 2025.

[0000068505-25-000050:8k_2_02:15]
"Our Q3 was outstanding, with record third-quarter revenue, earnings and cash flow,” said Greg Brown, chairman and CEO, Motorola Solutions. “Demand for our safety and security solutions remains robust and our Silvus acquisition is off to a strong start. As a result, we’re again raising our earnings expectations for the year.”

[0000068505-25-000050:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-25-000050:8k_2_02:17]
|  | Q3 2025 |  | Q3 2024 | % Change |
| Sales | $3,009 |  | $2,790 | 8 | % |
| GAAP |  |  |  |  |
| Operating Earnings | $770 |  | $711 | 8 | % |
| % of Sales | 25.6 | % |  | 25.5 | % |  |
| EPS | $3.33 |  | $3.29 | 1 | % |
| Non-GAAP* |  |  |  |  |
| Operating Earnings | $918 |  | $830 | 11 | % |
| % of Sales | 30.5 | % |  | 29.7 | % |  |
| EPS | $4.06 |  | $3.74 | 9 | % |
| Products and Systems Integration Segment |  |  |  |  |
| Sales | $1,897 |  | $1,784 | 6 | % |
| GAAP Operating Earnings | $458 |  | $446 | 3 | % |
| % of Sales | 24.1 | % |  | 25.0 | % |  |
| Non-GAAP* Operating Earnings | $555 |  | $522 | 6 | % |
| % of Sales | 29.3 | % |  | 29.3 | % |  |
| Software and Services Segment |  |  |  |  |
| Sales | $1,112 |  | $1,006 | 11 | % |
| GAAP Operating Earnings | $312 |  | $265 | 18 | % |
| % of Sales | 28.1 | % |  | 26.3 | % |  |
| Non-GAAP* Operating Earnings | $363 |  | $308 | 18 | % |
| % of Sales | 32.6 | % |  | 30.6 | % |  |

[0000068505-25-000050:8k_2_02:18]
* Non-GAAP financial information excludes the after-tax impact of approximately $0.73 per diluted share related to highlighted items, share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-25-000050:8k_2_02:19]
1

[0000068505-25-000050:8k_2_02:20]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-25-000050:8k_2_02:21]
•Revenue - Sales were $3.0 billion, up 8% from the year-ago quarter driven by growth in North America and International. Revenue from acquisitions was $123 million and foreign currency tailwinds were $21 million in the quarter. The Products and Systems Integration segment grew 6% driven by growth in Mission Critical Networks ("MCN") and Video Security and Access Control ("Video"). The Software and Services segment grew 11% driven by growth in MCN, Command Center and Video.

[0000068505-25-000050:8k_2_02:22]
•Operating margin - GAAP operating margin was 25.6% of sales, up from 25.5% in the year-ago quarter. Non-GAAP operating margin was 30.5% of sales, up 80 basis points from 29.7% in the year-ago quarter. The increase in non-GAAP operating margin was driven by higher sales and improved operating leverage, partially offset by higher tariffs.

[0000068505-25-000050:8k_2_02:23]
•Taxes - The GAAP effective tax rate during the quarter was 22.2%, versus 19.0% in the year-ago quarter driven by non-deductible transaction costs from the Silvus acquisition this quarter and tax benefits from settling foreign tax audits in the year-ago quarter. The non-GAAP effective tax rate was 20.7%, versus 20.6% in the year-ago quarter.

[0000068505-25-000050:8k_2_02:24]
•Cash flow - Operating cash flow was $799 million, compared to $759 million in the year-ago quarter and free cash flow was $733 million, up from $702 million in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings, net of non-cash charges.

[0000068505-25-000050:8k_2_02:25]
•Capital allocation - During the quarter, the company paid $182 million in cash dividends, repurchased $121 million of common stock and incurred $66 million of capital expenditures.  Additionally, the company settled $70 million of 6.5% debentures that were due within the quarter.

[0000068505-25-000050:8k_2_02:26]
During the quarter, the company also closed the acquisition of Silvus for $4.4 billion, which was primarily funded through $2.0 billion of long-term senior notes issued during the second quarter and $1.5 billion of new term loans. The remaining consideration of approximately $900 million was settled through a combination of cash on hand and issuance of commercial paper.

[0000068505-25-000050:8k_2_02:27]
•Backlog - The company ended the quarter with record Q3 backlog of $14.6 billion, up 3% or $467 million from the year-ago quarter driven by record Q3 orders. Products and Systems Integration segment backlog was down $604 million, or 14%, driven primarily by strong MCN shipments. Software and Services segment backlog was up $1.1 billion, or 11%, driven by strong demand across all three technologies and favorable foreign currency impacts, partially offset by revenue recognition from the U.K. Home Office.

[0000068505-25-000050:8k_2_02:28]
2

[0000068505-25-000050:8k_2_02:29]
NOTABLE WINS AND ACHIEVEMENTS

[0000068505-25-000050:8k_2_02:30]
Software and Services

[0000068505-25-000050:8k_2_02:31]
•$57 million P25 services order for the State of Louisiana

[0000068505-25-000050:8k_2_02:32]
•$25 million Command Center order for the State of Idaho

[0000068505-25-000050:8k_2_02:33]
•$20 million P25 services order for a U.S. state and local customer

[0000068505-25-000050:8k_2_02:34]
•$14 million mobile video order for the New York State Park Police

[0000068505-25-000050:8k_2_02:35]
•$13 million P25 services order for the Buenos Aires Police

[0000068505-25-000050:8k_2_02:36]
•$10 million mobile video order for the Bulgarian Ministry of Interior

[0000068505-25-000050:8k_2_02:37]
Products and Systems Integration

[0000068505-25-000050:8k_2_02:38]
•$110 million P25 system upgrade for the State of Colorado

[0000068505-25-000050:8k_2_02:39]
•$84 million P25 system upgrade for the Tennessee Department of Safety

[0000068505-25-000050:8k_2_02:40]
•$82 million P25 system upgrade for a U.S. state and local customer

[0000068505-25-000050:8k_2_02:41]
•$40 million P25 device order for a U.S. federal customer

[0000068505-25-000050:8k_2_02:42]
•$14 million P25 device and mobile video order for Arlington, TX

[0000068505-25-000050:8k_2_02:43]
•$10 million Silvus order for a NATO country

[0000068505-25-000050:8k_2_02:44]
BUSINESS OUTLOOK

[0000068505-25-000050:8k_2_02:45]
•Fourth quarter 2025 - The company expects revenue growth of approximately 11% compared to the fourth quarter of 2024 and non-GAAP EPS between $4.30 to $4.36 per share. This assumes approximately 169 million of fully diluted shares and a non-GAAP effective tax rate of approximately 24%.

[0000068505-25-000050:8k_2_02:46]
•Full-year 2025 - The company is maintaining its prior revenue guidance of approximately $11.65 billion or 7.7% growth, and raising non-GAAP EPS guidance to between $15.09 and $15.15 per share, up from its prior guidance of between $14.88 and $14.98 per share. This outlook assumes approximately 169 million of fully diluted shares and a non-GAAP effective tax rate of approximately 22.5%.

[0000068505-25-000050:8k_2_02:47]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP metrics to their most comparable GAAP measures because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial metric is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-25-000050:8k_2_02:48]
3

[0000068505-25-000050:8k_2_02:49]
RECENT EVENTS

[0000068505-25-000050:8k_2_02:50]
MACROECONOMIC ENVIRONMENT UPDATE

[0000068505-25-000050:8k_2_02:51]
The current global trade environment is complex and evolving. In early 2025, the U.S. initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, contributing to a global trade landscape subject to evolving tariffs, import/export regulations, including restrictions around rare earth minerals, trade barriers and trade disputes. As a result, the company continues to observe elevated volatility and uncertainty around the global supply chain.

[0000068505-25-000050:8k_2_02:52]
The company engages with global suppliers across a diverse network of locations around the world. The company continues to work with its global supply base to mitigate its exposure to the risks to global reciprocal (and sectoral) tariffs and import/export regulations that have developed, and which may continue to develop, in order to ensure supply continues at levels in order to meet the company's current customer demand. As a result of the dynamic tariff environment, the company has experienced increased costs on materials and components, which the company has substantially mitigated during the year and for which the company expects to continue to develop mitigation actions going forward.

[0000068505-25-000050:8k_2_02:53]
The company continues to see demand for our products and services supported by a multitude of funding sources. In July 2025, the “One Big Beautiful Bill Act” (“OBBB”) was enacted into law by the President of the United States, which provided a number of changes, including funding over the next four years for border security, national security and other opportunities. The company expects OBBB to provide an additional source of funding to its federal government customers over the four-year period available through OBBB.

[0000068505-25-000050:8k_2_02:54]
As of October 1, 2025 the U.S. government entered into a shutdown, which, as of October 30, 2025, is still ongoing. A prolonged shutdown may impact the company's ability to ship and fulfill contracts for certain federal government customers, which may negatively impact its results of operations.

[0000068505-25-000050:8k_2_02:55]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Time (5 p.m. U.S. Eastern Time) on Thursday, October 30. The conference call will be webcast live at www.motorolasolutions.com/investor. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-25-000050:8k_2_02:56]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-25-000050:8k_2_02:57]
A comparison of results from operations is as follows:

[0000068505-25-000050:8k_2_02:58]
|  | Q3 2025 | Q3 2024 |
| Net sales | $3,009 | $2,790 |
| Gross margin | $1,554 | $1,433 |
| Operating earnings | $770 | $711 |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | $562 | $562 |
| Diluted EPS | $3.33 | $3.29 |
| Weighted average diluted common shares outstanding | 169.0 |  | 170.9 |  |

[0000068505-25-000050:8k_2_02:59]
4

[0000068505-25-000050:8k_2_02:60]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-25-000050:8k_2_02:61]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP tax rate, and organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of its operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate the performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-25-000050:8k_2_02:62]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-25-000050:8k_2_02:63]
Free cash flow: Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-25-000050:8k_2_02:64]
Organic revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters. The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-25-000050:8k_2_02:65]
Non-GAAP operating earnings, non-GAAP EPS and non-GAAP operating margin each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-25-000050:8k_2_02:66]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-25-000050:8k_2_02:67]
Hytera-Related Legal Expenses: In 2017, the company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), in the U.S. District Court for the Northern District of Illinois (the “District Court”), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In

[0000068505-25-000050:8k_2_02:68]
5

[0000068505-25-000050:8k_2_02:69]
2020, a jury decided in the company's favor and awarded the company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-25-000050:8k_2_02:70]
Subsequently, the District Court ordered Hytera to pay the company a forward-looking reasonable royalty on products ("I-Series") that use the company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations. Hytera has made de minimis royalty payments related to the I-Series products directly to the company between January 2025 and July 2025.

[0000068505-25-000050:8k_2_02:71]
Following the initial District Court judgment in the company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera’s motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation, turnover of Hytera assets to the company, and injunction are currently briefed. On October 14-15, 2025, the District Court held hearings on these issues, but has not yet issued any rulings.

[0000068505-25-000050:8k_2_02:72]
In 2025, Hytera made payments towards amounts awarded to the company and owed by Hytera pursuant to court orders related to I-Series products. In the third quarter of 2025, the company received payments of $74 million, resulting in an aggregate of $94 million of payments received in the nine months ended September 27, 2025. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-25-000050:8k_2_02:73]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the company’s trade secrets in Hytera’s currently shipping products ("H-Series"). On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain H-Series products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions.

[0000068505-25-000050:8k_2_02:74]
6

[0000068505-25-000050:8k_2_02:75]
The District Court held hearings in August 2024, concerning whether Hytera's currently shipping H-Series products continue to misuse the company's trade secrets and copyrighted source code. On August 25, 2025, the District Court held Hytera in civil contempt for violation of the District Court’s royalty order and ordered Hytera to pay the company approximately $70 million for unpaid royalties and interest for Hytera’s continued use of the company’s trade secrets and copyrighted source code in Hytera's H-Series products. Hytera has appealed the District Court’s order to the Court of Appeals. Hytera’s appeal does not automatically stay its obligation to pay the $70 million. On October 14-15, 2025, the District Court heard arguments on whether Hytera must pay the $70 million into escrow, or directly to the company as a payment towards amounts awarded to the company and owed by Hytera pursuant to prior court orders, but has not yet issued a ruling.

[0000068505-25-000050:8k_2_02:76]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring” and accordingly, Hytera-related legal expenses were included in both the company's GAAP and non-GAAP operating income for fiscal years 2017, 2018 and 2019. The company anticipates further expenses associated with Hytera-related litigation; however, as of 2020, the company believes that these expenses are no longer a part of the “normal and recurring” legal expenses incurred to operate its business. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the $15 million of proceeds realized in 2022, $61 million realized in 2024 and $94 million realized in 2025. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-25-000050:8k_2_02:77]
Share-based compensation expenses: The company has excluded share-based compensation expenses from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expenses primarily because it represents a significant non-cash expense. Share-based compensation expenses will recur in future periods.

[0000068505-25-000050:8k_2_02:78]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net income measurements primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-25-000050:8k_2_02:79]
FORWARD LOOKING STATEMENTS

[0000068505-25-000050:8k_2_02:80]
7

[0000068505-25-000050:8k_2_02:81]
on the company and its federal government customers; and the impact of a prolonged U.S. government shutdown on the company. Motorola Solutions cautions the reader that the risks and uncertainties below, as well as those in Part I Item 1A of Motorola Solutions’ 2024 Annual Report on Form 10-K and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at www.motorolasolutions.com/investors, could cause Motorola Solutions’ actual results to differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (i) impact of current global economic and political conditions in the markets in which we operate (including, but not limited to, with respect to tariffs and the U.S. government shutdown); (ii) increased areas of risk, increased competition and additional compliance obligations associated with the introduction of new or enhanced products and services in our segments; (iii) impact of catastrophic events on our business or our customers' or suppliers' business; (iv) social, ethical, environmental and competitive risks relating to the use of artificial intelligence ("AI") in our products and services; (v) the effectiveness of our strategic acquisitions, including the integrations of such acquired businesses and the resulting impact on our financial results and operations; (vi) the inability of our products to meet our customers’ expectations or regulatory or industry standards; (vii) our inability to purchase a sufficient amount of materials, parts, and components, as well as software and services, at acceptable prices to meet the demands of our customers, and any disruption to our suppliers or significant increase in the price of supplies; (viii) risks related to our large, multi-year system and services contracts; (ix) the global nature of our employees, customers, suppliers and outsource partners; (x) our use of third-parties to develop, design and/or manufacture many of our components and some of our products, and to perform portions of our business operations; (xi) the inability of our subcontractors to perform in a timely and compliant manner or adhere to our Human Rights Policy; (xii) increasing scrutiny and evolving expectations from investors, customers, lawmakers, regulators and other stakeholders regarding environmental, social and governance (“ESG”) related practices and disclosures, as well as recent U.S. based anti-ESG efforts; (xiii) challenges relating to existing or future legislation and regulations pertaining to AI, AI-enabled products and the use of biometrics and other video analytics; (xiv) the impact, including increased costs and potential liabilities, associated with changes in laws and regulations regarding cybersecurity, privacy, data protection, and information security; (xv) the impact of government regulation of radio frequencies; (xvi) regulations, laws and other compliance requirements applicable to our U.S. government customer contracts and grants; (xvii) the impact, including increased costs and additional compliance obligations, associated with existing or future telecommunications-related laws and regulations; (xviii) impact of product regulatory and safety, consumer, worker safety and environmental product compliance and remediation laws; (xix) the evolving state of environmental regulation relating to climate change, and the physical risks of climate change; (xx) impact of tax matters; (xxi) increased cybersecurity threats, a security breach or other significant disruption of our IT systems or those of our outsource partners, suppliers or customers; (xxii) our inability to protect our intellectual property or potential infringement of intellectual property rights of third parties; (xxiii) risks relating to intellectual property licenses and intellectual property indemnities in our customer and supplier contracts; (xxiv) our license of the MOTOROLA, MOTO, MOTOROLA SOLUTIONS and the Stylized M logo and all derivatives and formatives thereof from Motorola Trademark Holdings, LLC; (xxv) inability to attract and retain senior management and key employees; (xxvi) inability to access the capital markets for financing on acceptable terms and conditions; (xxvii) exposure to exchange rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; (xxviii) impact of returns on pension and retirement plan assets and interest rate changes; and (xix) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-25-000050:8k_2_02:82]
About Motorola Solutions | Solving for safer

[0000068505-25-000050:8k_2_02:83]
Safety and security are at the heart of everything we do at Motorola Solutions. We build and connect technologies to help protect people, property and places. Our solutions foster the collaboration that’s critical for safer communities, safer schools, safer hospitals, safer businesses, and ultimately, safer nations. Learn more about our commitment to innovating for a safer future for us all at www.motorolasolutions.com.

[0000068505-25-000050:8k_2_02:84]
8

[0000068505-25-000050:8k_2_02:85]
MEDIA CONTACT

[0000068505-25-000050:8k_2_02:86]
Alexandra Reynolds

[0000068505-25-000050:8k_2_02:87]
Motorola Solutions

[0000068505-25-000050:8k_2_02:88]
+1 312-965-3968

[0000068505-25-000050:8k_2_02:89]
alexandra.reynolds@motorolasolutions.com

[0000068505-25-000050:8k_2_02:90]
INVESTOR CONTACT

[0000068505-25-000050:8k_2_02:91]
Tim Yocum

[0000068505-25-000050:8k_2_02:92]
Motorola Solutions

[0000068505-25-000050:8k_2_02:93]
+1 847-576-6899

[0000068505-25-000050:8k_2_02:94]
Tim.Yocum@motorolasolutions.com

[0000068505-25-000050:8k_2_02:95]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2025 Motorola Solutions, Inc. All rights reserved.

[0000068505-25-000050:8k_2_02:96]
9

[0000068505-25-000050:8k_2_02:97]
GAAP-1

[0000068505-25-000050:8k_2_02:98]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:99]
Condensed Consolidated Statements of Operations

[0000068505-25-000050:8k_2_02:100]
(In millions, except per share amounts)

[0000068505-25-000050:8k_2_02:101]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| Net sales from products | $ | 1,751 |  |  | $ | 1,670 |  |
| Net sales from services | 1,258 |  |  | 1,120 |  |
| Net sales | 3,009 |  |  | 2,790 |  |
| Costs of products sales | 728 |  |  | 688 |  |
| Costs of services sales | 727 |  |  | 669 |  |
| Costs of sales | 1,455 |  |  | 1,357 |  |
| Gross margin | 1,554 |  |  | 1,433 |  |
| Selling, general and administrative expenses | 485 |  |  | 439 |  |
| Research and development expenditures | 237 |  |  | 234 |  |
| Other charges (income) | (4) |  |  | 11 |  |
| Intangibles amortization | 66 |  |  | 38 |  |
| Operating earnings | 770 |  |  | 711 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (86) |  |  | (58) |  |
| Other, net | 41 |  |  | 42 |  |
| Total other expense | (45) |  |  | (16) |  |
| Net earnings before income taxes | 725 |  |  | 695 |  |
| Income tax expense | 161 |  |  | 132 |  |
| Net earnings | 564 |  |  | 563 |  |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 562 |  |  | $ | 562 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.37 |  |  | $ | 3.36 |  |
| Diluted | $ | 3.33 |  |  | $ | 3.29 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.6 |  |  | 167.1 |  |
| Diluted | 169.0 |  |  | 170.9 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 58.2 | % |  | 59.9 | % |
| Net sales from services | 41.8 | % |  | 40.1 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.6 | % |  | 41.2 | % |
| Costs of services sales | 57.8 | % |  | 59.7 | % |
| Costs of sales | 48.4 | % |  | 48.6 | % |
| Gross margin | 51.6 | % |  | 51.4 | % |
| Selling, general and administrative expenses | 16.1 | % |  | 15.7 | % |
| Research and development expenditures | 7.9 | % |  | 8.4 | % |
| Other charges (income) | (0.1) | % |  | 0.4 | % |
| Intangibles amortization | 2.2 | % |  | 1.4 | % |
| Operating earnings | 25.6 | % |  | 25.5 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.9) | % |  | (2.1) | % |
| Other, net | 1.4 | % |  | 1.5 | % |
| Total other expense | (1.5) | % |  | (0.6) | % |
| Net earnings before income taxes | 24.1 | % |  | 24.9 | % |
| Income tax expense | 5.4 | % |  | 4.7 | % |
| Net earnings | 18.7 | % |  | 20.2 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 18.7 | % |  | 20.2 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-25-000050:8k_2_02:102]
10

[0000068505-25-000050:8k_2_02:103]
GAAP-2

[0000068505-25-000050:8k_2_02:104]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:105]
Condensed Consolidated Statements of Operations

[0000068505-25-000050:8k_2_02:106]
(In millions, except per share amounts)

[0000068505-25-000050:8k_2_02:107]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| Net sales from products | $ | 4,731 |  |  | $ | 4,639 |  |
| Net sales from services | 3,571 |  |  | 3,167 |  |
| Net sales | 8,302 |  |  | 7,806 |  |
| Costs of products sales | 1,948 |  |  | 1,941 |  |
| Costs of services sales | 2,087 |  |  | 1,902 |  |
| Costs of sales | 4,035 |  |  | 3,843 |  |
| Gross margin | 4,267 |  |  | 3,963 |  |
| Selling, general and administrative expenses | 1,371 |  |  | 1,265 |  |
| Research and development expenditures | 700 |  |  | 671 |  |
| Other charges (income) | 10 |  |  | 39 |  |
| Intangibles amortization | 142 |  |  | 114 |  |
| Operating earnings | 2,044 |  |  | 1,874 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (192) |  |  | (171) |  |
| Other, net | 100 |  |  | (519) |  |
| Total other expense | (92) |  |  | (690) |  |
| Net earnings before income taxes | 1,952 |  |  | 1,184 |  |
| Income tax expense | 442 |  |  | 214 |  |
| Net earnings | 1,510 |  |  | 970 |  |
| Less: Earnings attributable to non-controlling interests | 5 |  |  | 4 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 1,505 |  |  | $ | 966 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 9.02 |  |  | $ | 5.79 |  |
| Diluted | $ | 8.89 |  |  | $ | 5.66 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.8 |  |  | 166.7 |  |
| Diluted | 169.2 |  |  | 170.6 |  |
|  | Percentage of Net Sales* |
| Net sales from products | 57.0 | % |  | 59.4 | % |
| Net sales from services | 43.0 | % |  | 40.6 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.2 | % |  | 41.8 | % |
| Costs of services sales | 58.4 | % |  | 60.1 | % |
| Costs of sales | 48.6 | % |  | 49.2 | % |
| Gross margin | 51.4 | % |  | 50.8 | % |
| Selling, general and administrative expenses | 16.5 | % |  | 16.2 | % |
| Research and development expenditures | 8.4 | % |  | 8.6 | % |
| Other charges (income) | 0.1 | % |  | 0.5 | % |
| Intangibles amortization | 1.7 | % |  | 1.5 | % |
| Operating earnings | 24.6 | % |  | 24.0 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (2.3) | % |  | (2.2) | % |
| Other, net | 1.2 | % |  | (6.6) | % |
| Total other expense | (1.1) | % |  | (8.8) | % |
| Net earnings before income taxes | 23.5 | % |  | 15.2 | % |
| Income tax expense | 5.3 | % |  | 2.7 | % |
| Net earnings | 18.2 | % |  | 12.4 | % |
| Less: Earnings attributable to non-controlling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 18.1 | % |  | 12.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-25-000050:8k_2_02:108]
11

[0000068505-25-000050:8k_2_02:109]
GAAP-3

[0000068505-25-000050:8k_2_02:110]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:111]
Condensed Consolidated Balance Sheets

[0000068505-25-000050:8k_2_02:112]
(In millions)

[0000068505-25-000050:8k_2_02:113]
|  | September 27, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 894 |  |  | $ | 2,102 |  |
| Accounts receivable, net | 2,018 |  |  | 1,952 |  |
| Contract assets | 1,515 |  |  | 1,230 |  |
| Inventories, net | 943 |  |  | 766 |  |
| Other current assets | 441 |  |  | 429 |  |
| Total current assets | 5,811 |  |  | 6,479 |  |
| Property, plant and equipment, net | 1,099 |  |  | 1,022 |  |
| Operating lease assets | 577 |  |  | 529 |  |
| Investments | 192 |  |  | 135 |  |
| Deferred income taxes | 767 |  |  | 1,280 |  |
| Goodwill | 6,776 |  |  | 3,526 |  |
| Intangible assets, net | 3,131 |  |  | 1,249 |  |
| Other assets | 446 |  |  | 375 |  |
| Total assets | $ | 18,799 |  |  | $ | 14,595 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | — |  |  | $ | 322 |  |
| Short-term borrowings | 928 |  |  | — |  |
| Accounts payable | 940 |  |  | 1,018 |  |
| Contract liabilities | 2,074 |  |  | 2,072 |  |
| Accrued liabilities | 1,717 |  |  | 1,643 |  |
| Total current liabilities | 5,659 |  |  | 5,055 |  |
| Long-term debt | 8,411 |  |  | 5,675 |  |
| Operating lease liabilities | 469 |  |  | 427 |  |
| Other liabilities | 1,916 |  |  | 1,719 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 2,327 |  |  | 1,703 |  |
| Non-controlling interests | 17 |  |  | 16 |  |
| Total liabilities and stockholders’ equity | $ | 18,799 |  |  | $ | 14,595 |  |

[0000068505-25-000050:8k_2_02:114]
12

[0000068505-25-000050:8k_2_02:115]
GAAP-4

[0000068505-25-000050:8k_2_02:116]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:117]
Condensed Consolidated Statements of Cash Flows

[0000068505-25-000050:8k_2_02:118]
(In millions)

[0000068505-25-000050:8k_2_02:119]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| Operating |  |  |  |
| Net earnings | $ | 564 |  |  | $ | 563 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 115 |  |  | 84 |  |
| Non-cash other charges (income) | 1 |  |  | (3) |  |
| Share-based compensation expenses | 73 |  |  | 61 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (128) |  |  | (64) |  |
| Inventories | (23) |  |  | (8) |  |
| Other current assets and contract assets | (108) |  |  | (96) |  |
| Accounts payable, accrued liabilities and contract liabilities | 175 |  |  | 206 |  |
| Other assets and liabilities | 52 |  |  | 1 |  |
| Deferred income taxes | 78 |  |  | 15 |  |
| Net cash provided by operating activities | 799 |  |  | 759 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (4,370) |  |  | (226) |  |
| Proceeds from sales of investments and businesses, net | 2 |  |  | 1 |  |
| Capital expenditures | (66) |  |  | (57) |  |
| Net cash used for investing activities | (4,434) |  |  | (282) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | 750 |  |  | — |  |
| Net proceeds from short-term borrowings | 923 |  |  | — |  |
| Repayments of debt | (70) |  |  | (313) |  |
| Issuances of common stock, net of tax | 32 |  |  | 18 |  |
| Purchases of common stock | (121) |  |  | (31) |  |
| Payments of dividends | (182) |  |  | (164) |  |
| Payments of dividends to non-controlling interests | (1) |  |  | (1) |  |
| Net cash provided by (used for) financing activities | 1,331 |  |  | (491) |  |
| Effect of exchange rate changes on total cash and cash equivalents | (8) |  |  | 37 |  |
| Net increase (decrease) in total cash and cash equivalents | (2,312) |  |  | 23 |  |
| Cash and cash equivalents, beginning of period | 3,206 |  |  | 1,381 |  |
| Cash and cash equivalents, end of period | $ | 894 |  |  | $ | 1,404 |  |

[0000068505-25-000050:8k_2_02:120]
GAAP-5

[0000068505-25-000050:8k_2_02:121]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:122]
Condensed Consolidated Statements of Cash Flows

[0000068505-25-000050:8k_2_02:123]
(In millions)

[0000068505-25-000050:8k_2_02:124]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| Operating |  |  |  |
| Net earnings | $ | 1,510 |  |  | $ | 970 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 282 |  |  | 250 |  |
| Non-cash other charges (income) | (4) |  |  | 12 |  |
| Share-based compensation expenses | 213 |  |  | 180 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | — |  |  | 585 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | 1 |  |  | (121) |  |
| Inventories | (107) |  |  | 21 |  |
| Other current assets and contract assets | (230) |  |  | (279) |  |
| Accounts payable, accrued liabilities and contract liabilities | (280) |  |  | (125) |  |
| Other assets and liabilities | 101 |  |  | (17) |  |
| Deferred income taxes | 95 |  |  | (155) |  |
| Net cash provided by operating activities | 1,581 |  |  | 1,321 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (4,835) |  |  | (268) |  |
| Proceeds from sales of investments and businesses, net | 14 |  |  | 39 |  |
| Capital expenditures | (151) |  |  | (171) |  |
| Net cash used for investing activities | (4,972) |  |  | (400) |  |
| Financing |  |  |  |
| Net proceeds from issuance of debt | 2,733 |  |  | 1,288 |  |
| Net proceeds from short-term borrowings | 923 |  |  | — |  |
| Repayments of debt | (322) |  |  | (1,906) |  |
| Revolving credit facility renewal fees | (5) |  |  | — |  |
| Issuances of common stock, net of tax | (3) |  |  | 19 |  |
| Purchases of common stock | (664) |  |  | (141) |  |
| Payments of dividends | (546) |  |  | (490) |  |
| Payments of dividends to non-controlling interests | (5) |  |  | (4) |  |
| Net cash provided by (used for) financing activities | 2,111 |  |  | (1,234) |  |
| Effect of exchange rate changes on total cash and cash equivalents | 72 |  |  | 12 |  |
| Net decrease in total cash and cash equivalents | (1,208) |  |  | (301) |  |
| Cash and cash equivalents, beginning of period | 2,102 |  |  | 1,705 |  |
| Cash and cash equivalents, end of period | $ | 894 |  |  | $ | 1,404 |  |

[0000068505-25-000050:8k_2_02:125]
14

[0000068505-25-000050:8k_2_02:126]
Non-GAAP-1

[0000068505-25-000050:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:128]
Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow

[0000068505-25-000050:8k_2_02:129]
(In millions)

[0000068505-25-000050:8k_2_02:130]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net cash provided by operating activities |  | $ | 799 |  |  | $ | 759 |  |  | $ | 1,581 |  |  | $ | 1,321 |  |
| Capital expenditures |  | (66) |  |  | (57) |  |  | (151) |  |  | (171) |  |
| Free cash flow |  | $ | 733 |  |  | $ | 702 |  |  | $ | 1,430 |  |  | $ | 1,150 |  |

[0000068505-25-000050:8k_2_02:131]
15

[0000068505-25-000050:8k_2_02:132]
Non-GAAP-2

[0000068505-25-000050:8k_2_02:133]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:134]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-25-000050:8k_2_02:135]
(In millions)

[0000068505-25-000050:8k_2_02:136]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  | Statement Line |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net earnings attributable to MSI |  |  |  | $ | 562 |  |  | $ | 562 |  |  | $ | 1,505 |  |  | $ | 966 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 73 |  |  | $ | 61 |  |  | $ | 213 |  |  | $ | 180 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 66 |  |  | 38 |  |  | 142 |  |  | 114 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 55 |  |  | 4 |  |  | 63 |  |  | 11 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 14 |  |  | 7 |  |  | 45 |  |  | 21 |  |
| Hytera-related legal expenses |  | SG&A |  | 11 |  |  | 7 |  |  | 31 |  |  | 14 |  |
| Legal settlements |  | Other charges (income) |  | 2 |  |  | 1 |  |  | 7 |  |  | 7 |  |
| Investment impairments |  | Other (income) expense |  | 2 |  |  | — |  |  | 2 |  |  | 3 |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 1 |  |  | 1 |  |  | 2 |  |  | 22 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 1 |  |  | 1 |  |  | 1 |  |  | 5 |  |
| Loss on financing issuance costs |  | Other (income) expense |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | 585 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (8) |  |  | (9) |  |  | (21) |  |  | 4 |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (74) |  |  | — |  |  | (94) |  |  | — |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 143 |  |  | $ | 111 |  |  | $ | 393 |  |  | $ | 966 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 19 |  | 34 |  | 70 |  | 259 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 124 |  | 77 |  | 323 |  | 707 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 686 |  |  | $ | 639 |  |  | $ | 1,828 |  |  | $ | 1,673 |  |

[0000068505-25-000050:8k_2_02:137]
Calculation of Non-GAAP Tax Rate

[0000068505-25-000050:8k_2_02:138]
(In millions)

[0000068505-25-000050:8k_2_02:139]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net earnings before income taxes |  | $ | 725 |  |  | $ | 695 |  |  | $ | 1,952 |  |  | $ | 1,184 |  |
| Total Non-GAAP adjustments before income taxes* |  | 143 |  |  | 111 |  |  | 393 |  |  | 966 |  |
| Non-GAAP Net earnings before income taxes |  | 868 |  |  | 806 |  |  | 2,345 |  |  | 2,150 |  |
| Income tax expense |  | 161 |  |  | 132 |  |  | 442 |  |  | 214 |  |
| Income tax expense on Non-GAAP adjustments** |  | 19 |  |  | 34 |  |  | 70 |  |  | 259 |  |
| Total Non-GAAP Income tax expense |  | $ | 180 |  |  | $ | 166 |  |  | 512 |  |  | 473 |  |
| Non-GAAP Tax rate |  | 20.7 | % |  | 20.6 | % |  | 21.8 | % |  | 22.0 | % |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |

[0000068505-25-000050:8k_2_02:140]
16

[0000068505-25-000050:8k_2_02:141]
Non-GAAP-2

[0000068505-25-000050:8k_2_02:142]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-25-000050:8k_2_02:143]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  | Statement Line |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net earnings attributable to MSI |  |  |  | $ | 3.33 |  |  | $ | 3.29 |  |  | $ | 8.89 |  |  | $ | 5.66 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | $ | 0.43 |  |  | $ | 0.35 |  |  | $ | 1.26 |  |  | $ | 1.05 |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | 0.39 |  |  | 0.22 |  |  | 0.84 |  |  | 0.67 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.33 |  |  | 0.02 |  |  | 0.37 |  |  | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.08 |  |  | 0.04 |  |  | 0.27 |  |  | 0.12 |  |
| Hytera-related legal expenses |  | SG&A |  | 0.07 |  |  | 0.04 |  |  | 0.18 |  |  | 0.08 |  |
| Legal settlements |  | Other charges (income) |  | 0.01 |  |  | 0.01 |  |  | 0.04 |  |  | 0.04 |  |
| Investment impairments |  | Other (income) expense |  | 0.01 |  |  | — |  |  | 0.01 |  |  | 0.02 |  |
| Assessments of uncertain tax positions |  | Interest income, net, Other (income) expense |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.13 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.03 |  |
| Loss on financing issuance costs |  | Other (income) expense |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | 3.42 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | (0.05) |  |  | (0.05) |  |  | (0.12) |  |  | 0.02 |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (0.44) |  |  | — |  |  | (0.56) |  |  | — |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.85 |  |  | $ | 0.65 |  |  | $ | 2.32 |  |  | $ | 5.65 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.12 |  | 0.20 |  | 0.41 |  | 1.52 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.73 |  | 0.45 |  | 1.91 |  | 4.13 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 4.06 |  |  | $ | 3.74 |  |  | $ | 10.80 |  |  | $ | 9.79 |  |
| GAAP Diluted Weighted Average Common Shares |  |  |  | 169.0 |  |  | 170.9 |  |  | 169.2 |  |  | 170.6 |  |
| Adjusted for dilutive shares outstanding** |  |  |  | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Non-GAAP Diluted Weighted Average Common Shares |  |  |  | 169.0 |  |  | 170.9 |  |  | 169.2 |  |  | 170.9 |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |
| ** Under U.S. GAAP, the Silver Lake shares were considered anti-dilutive to earnings per share for the nine months ended September 28, 2024 and were excluded from the computation of GAAP diluted weighted average common shares and diluted earnings per share. The shares are considered dilutive for non-GAAP earnings per share for the nine months ended September 28, 2024 and an adjustment is reflected to include these shares for non-GAAP diluted earnings per share. |

[0000068505-25-000050:8k_2_02:144]
17

[0000068505-25-000050:8k_2_02:145]
Non-GAAP-3

[0000068505-25-000050:8k_2_02:146]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:147]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-25-000050:8k_2_02:148]
(In millions)

[0000068505-25-000050:8k_2_02:149]
|  |  | Three Months Ended |
|  |  | September 27, 2025 |  | September 28, 2024 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Operating earnings ("OE") |  | 458 |  |  | 312 |  |  | 770 |  |  | 446 |  |  | 265 |  |  | 711 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 53 |  |  | 20 |  |  | 73 |  |  | 43 |  |  | 18 |  |  | 61 |  |
| Intangible assets amortization expense |  | 44 |  |  | 22 |  |  | 66 |  |  | 18 |  |  | 20 |  |  | 38 |  |
| Acquisition-related transaction fees |  | 52 |  |  | 3 |  |  | 55 |  |  | 2 |  |  | 2 |  |  | 4 |  |
| Reorganization of business charges |  | 9 |  |  | 5 |  |  | 14 |  |  | 6 |  |  | 1 |  |  | 7 |  |
| Hytera-related legal expenses |  | 11 |  |  | — |  |  | 11 |  |  | 7 |  |  | — |  |  | 7 |  |
| Legal settlements |  | 1 |  |  | 1 |  |  | 2 |  |  | — |  |  | 1 |  |  | 1 |  |
| Operating lease asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Gain on Hytera litigation |  | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 97 |  |  | 51 |  |  | 148 |  |  | 76 |  |  | 43 |  |  | 119 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 555 |  |  | $ | 363 |  |  | $ | 918 |  |  | $ | 522 |  |  | $ | 308 |  |  | $ | 830 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 24.1 | % |  | 28.1 | % |  | 25.6 | % |  | 25.0 | % |  | 26.3 | % |  | 25.5 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 29.3 | % |  | 32.6 | % |  | 30.5 | % |  | 29.3 | % |  | 30.6 | % |  | 29.7 | % |

[0000068505-25-000050:8k_2_02:150]
18

[0000068505-25-000050:8k_2_02:151]
Non-GAAP-4

[0000068505-25-000050:8k_2_02:152]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:153]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-25-000050:8k_2_02:154]
(In millions)

[0000068505-25-000050:8k_2_02:155]
|  |  | Nine Months Ended |
|  |  | September 27, 2025 |  | September 28, 2024 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Operating earnings ("OE") |  | 1,173 |  |  | 871 |  |  | 2,044 |  |  | 1,135 |  |  | 739 |  |  | 1,874 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 155 |  |  | 58 |  |  | 213 |  |  | 126 |  |  | 54 |  |  | 180 |  |
| Intangible assets amortization expense |  | 76 |  |  | 66 |  |  | 142 |  |  | 35 |  |  | 79 |  |  | 114 |  |
| Acquisition-related transaction fees |  | 54 |  |  | 9 |  |  | 63 |  |  | 3 |  |  | 8 |  |  | 11 |  |
| Reorganization of business charges |  | 31 |  |  | 14 |  |  | 45 |  |  | 20 |  |  | 1 |  |  | 21 |  |
| Hytera-related legal expenses |  | 31 |  |  | — |  |  | 31 |  |  | 14 |  |  | — |  |  | 14 |  |
| Legal settlements |  | 4 |  |  | 3 |  |  | 7 |  |  | 1 |  |  | 6 |  |  | 7 |  |
| Operating lease asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | 3 |  |  | 2 |  |  | 5 |  |
| Gain on Hytera litigation |  | (94) |  |  | — |  |  | (94) |  |  | — |  |  | — |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 258 |  |  | 150 |  |  | 408 |  |  | 202 |  |  | 150 |  |  | 352 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,431 |  |  | $ | 1,021 |  |  | $ | 2,452 |  |  | $ | 1,337 |  |  | $ | 889 |  |  | $ | 2,226 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 23.0 | % |  | 27.2 | % |  | 24.6 | % |  | 23.0 | % |  | 25.7 | % |  | 24.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.1 | % |  | 31.8 | % |  | 29.5 | % |  | 27.1 | % |  | 30.9 | % |  | 28.5 | % |

[0000068505-25-000050:8k_2_02:156]
19

[0000068505-25-000050:8k_2_02:157]
Non-GAAP-5

[0000068505-25-000050:8k_2_02:158]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-25-000050:8k_2_02:159]
Reconciliation of Revenue to Non-GAAP Organic Revenue

[0000068505-25-000050:8k_2_02:160]
(In millions)

[0000068505-25-000050:8k_2_02:161]
|  |  | Three Months Ended |  |  |
|  |  | September 27, 2025 |  | September 28, 2024 |  | % Change |
| Net sales |  | $ | 3,009 |  |  | $ | 2,790 |  |  | 8 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 123 |  |  | — |  |  |  |
| Organic revenue |  | $ | 2,886 |  |  | $ | 2,790 |  |  | 3 | % |
|  |  | Nine Months Ended |  |  |
|  |  | September 27, 2025 |  | September 28, 2024 |  | % Change |
| Net sales |  | $ | 8,302 |  |  | $ | 7,806 |  |  | 6 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 194 |  |  | — |  |  |  |
| Organic revenue |  | $ | 8,108 |  |  | $ | 7,806 |  |  | 4 | % |

[0000068505-25-000050:8k_2_02:162]
20
