# MSI 8-K — 0000068505-26-000006 filed 2026-02-11

## item codes, every 8-K on or before 2026-02-12

- 2026-02-11 0000068505-26-000006 — 2.02, 9.01
- 2025-11-18 0001193125-25-286239 — 5.02, 9.01
- 2025-10-30 0000068505-25-000050 — 2.02, 9.01
- 2025-08-07 0000068505-25-000038 — 2.02, 9.01
- 2025-08-06 0001193125-25-174512 — 2.01, 2.03, 7.01, 9.01
- 2025-07-21 0001193125-25-161886 — 1.01, 9.01
- 2025-06-16 0001193125-25-141449 — 8.01, 9.01
- 2025-05-27 0001193125-25-127588 — 1.01, 3.02, 7.01, 9.01
- 2025-05-19 0001193125-25-122455 — 5.07, 8.01
- 2025-05-01 0000068505-25-000022 — 2.02, 9.01
- 2025-04-25 0001193125-25-096928 — 1.01, 1.02, 2.03, 9.01
- 2025-02-13 0000068505-25-000008 — 2.02, 9.01
- 2024-11-07 0000068505-24-000032 — 2.02, 9.01
- 2024-10-09 0001193125-24-235267 — 5.02
- 2024-08-26 0001193125-24-207088 — 5.02, 9.01
- 2024-08-01 0000068505-24-000022 — 2.02, 9.01
- 2024-05-17 0001193125-24-141186 — 5.07
- 2024-05-02 0000068505-24-000014 — 2.02, 9.01
- 2024-03-25 0001193125-24-076470 — 8.01, 9.01
- 2024-02-21 0001193125-24-041481 — 5.02, 9.01
- 2024-02-15 0001193125-24-037018 — 8.01, 9.01
- 2024-02-08 0000068505-24-000004 — 2.02, 9.01
- 2023-11-16 0001193125-23-278932 — 8.01, 9.01
- 2023-11-02 0000068505-23-000043 — 2.02, 9.01
- 2023-08-03 0000068505-23-000035 — 2.02, 9.01
- 2023-05-19 0001193125-23-149339 — 5.07, 9.01
- 2023-05-04 0000068505-23-000025 — 2.02, 9.01
- 2023-03-13 0001193125-23-069113 — 5.02
- 2023-02-10 0001193125-23-032815 — 1.01, 9.01
- 2023-02-09 0000068505-23-000009 — 2.02, 9.01
- 2023-02-01 0001193125-23-021048 — 5.02, 8.01
- 2022-11-18 0001193125-22-289030 — 5.03, 9.01
- 2022-11-03 0000068505-22-000030 — 2.02, 9.01
- 2022-08-04 0000068505-22-000024 — 2.02, 9.01
- 2022-06-15 0001193125-22-174773 — 8.01
- 2022-06-01 0001193125-22-164709 — 8.01, 9.01
- 2022-05-20 0001193125-22-156157 — 5.02, 5.07, 9.01
- 2022-05-12 0000068505-22-000017 — 2.02, 9.01
- 2022-03-14 0001193125-22-074705 — 5.02
- 2022-02-09 0000068505-22-000006 — 2.02, 9.01
- 2022-01-18 0001193125-22-010643 — 5.02, 8.01, 9.01
- 2021-12-15 0001193125-21-357320 — 8.01
- 2021-11-30 0001193125-21-343098 — 5.02, 8.01
- 2021-11-04 0000068505-21-000025 — 2.02, 9.01
- 2021-08-16 0001193125-21-247751 — 8.01
- 2021-08-05 0000068505-21-000019 — 2.02, 9.01
- 2021-06-01 0001193125-21-178579 — 5.02, 8.01
- 2021-05-24 0001193125-21-170850 — 8.01, 9.01
- 2021-05-24 0001193125-21-170827 — 8.01
- 2021-05-20 0001193125-21-167759 — 5.07
- 2021-05-12 0001193125-21-159046 — 8.01
- 2021-05-06 0000068505-21-000013 — 2.02, 7.01, 9.01
- 2021-03-25 0001193125-21-094457 — 1.01, 1.02, 2.03, 9.01
- 2021-03-15 0001193125-21-081385 — 8.01
- 2021-03-10 0001193125-21-076237 — 5.02
- 2021-02-04 0000068505-21-000005 — 2.02, 9.01
- 2020-11-17 0001193125-20-296104 — 8.01
- 2020-10-29 0000068505-20-000026 — 2.02, 9.01
- 2020-08-27 0001193125-20-233177 — 5.03, 9.01
- 2020-08-14 0001193125-20-220569 — 8.01, 9.01
- 2020-08-06 0000068505-20-000018 — 2.02, 9.01
- 2020-07-24 0001193125-20-198554 — 5.02
- 2020-06-30 0001193125-20-184064 — 2.02, 5.02, 9.01
- 2020-06-02 0001193125-20-158499 — 8.01
- 2020-05-13 0001193125-20-141640 — 5.07
- 2020-05-07 0000068505-20-000011 — 2.02, 9.01
- 2020-03-13 0001193125-20-072947 — 5.02
- 2020-03-12 0001193125-20-071696 — 8.01
- 2020-02-06 0000068505-20-000003 — 2.02, 9.01
- 2019-10-30 0000068505-19-000023 — 2.02, 9.01
- 2019-09-23 0001193125-19-251774 — 8.01
- 2019-09-09 0001193125-19-240528 — 1.01, 9.01
- 2019-09-05 0001193125-19-238375 — 8.01, 9.01
- 2019-09-05 0001193125-19-238161 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2019-08-07 0001193125-19-215363 — 8.01, 9.01
- 2019-08-01 0000068505-19-000017 — 2.02, 9.01
- 2019-05-28 0001193125-19-158385 — 8.01, 9.01
- 2019-05-15 0001193125-19-148154 — 5.07, 8.01
- 2019-05-02 0000068505-19-000011 — 2.02, 9.01
- 2019-03-18 0001193125-19-078344 — 8.01
- 2019-02-07 0000068505-19-000003 — 2.02, 9.01
- 2019-01-07 0001193125-19-003488 — 8.01, 9.01
- 2018-11-01 0000068505-18-000027 — 2.02, 9.01
- 2018-10-05 0001193125-18-294780 — 8.01, 9.01
- 2018-10-02 0001193125-18-290867 — 8.01, 9.01
- 2018-09-14 0001193125-18-274208 — 8.01
- 2018-09-10 0001193125-18-270156 — 5.02
- 2018-09-06 0001193125-18-267629 — 8.01, 9.01
- 2018-08-28 0001193125-18-260643 — 5.02, 8.01
- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2026-02-12

- none on or before 2026-02-12

## item 2.02 — earnings release, exhibit 99.1

[0000068505-26-000006:8k_2_02:1]
EX-99.1
2
msiq42025pressrelease.htm
EX-99.1

[0000068505-26-000006:8k_2_02:2]
Document

[0000068505-26-000006:8k_2_02:3]
Exhibit 99.1

[0000068505-26-000006:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year Financial Results

[0000068505-26-000006:8k_2_02:5]
Company achieves record full-year revenue, earnings, cash flow and ending backlog

[0000068505-26-000006:8k_2_02:6]
•Sales of $3.4 billion, up 12% from Q4 in the prior year; up 8% for full year

[0000068505-26-000006:8k_2_02:7]
◦Products and Systems Integration sales grew 11% in Q4; up 5% for full year

[0000068505-26-000006:8k_2_02:8]
◦Software and Services sales grew 15% in Q4; up 13% for full year

[0000068505-26-000006:8k_2_02:9]
•GAAP Q4 earnings per share (EPS) of $3.86, up 8%; $12.75 for full year, up 38%

[0000068505-26-000006:8k_2_02:10]
•Non-GAAP Q4 EPS* of $4.59, up 14%; $15.38 for full year, up 11%

[0000068505-26-000006:8k_2_02:11]
•Generated $1.3 billion of operating cash flow in Q4; $2.8 billion for full year, up 19%

[0000068505-26-000006:8k_2_02:12]
•Repurchased $490 million of shares and paid $182 million in dividends in Q4

[0000068505-26-000006:8k_2_02:13]
•Record ending backlog of $15.7 billion, up $1 billion versus the prior year, driven by record orders

[0000068505-26-000006:8k_2_02:14]
CHICAGO - February 11, 2026 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2025.

[0000068505-26-000006:8k_2_02:15]
“Our outstanding 2025 performance demonstrates the resilience and strength of our business,” said Greg Brown, chairman and CEO, Motorola Solutions. “We had record sales, earnings and cash flow. Our record backlog and strong demand gives us continued momentum for another excellent year."

[0000068505-26-000006:8k_2_02:16]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-26-000006:8k_2_02:17]
|  | Fourth Quarter | Full Year |
|  | Q4 2025 | Q4 2024 | % Change | 2025 | 2024 | % Change |
| Sales | $3,380 | $3,010 | 12 | % | $11,682 | $10,817 | 8 | % |
| GAAP |  |  |  |  |  |  |
| Operating Earnings | $944 | $814 | 16 | % | $2,988 | $2,688 | 11 | % |
| % of Sales | 27.9 | % | 27.0 | % |  | 25.6 | % | 24.8 | % |  |
| EPS | $3.86 | $3.56 | 8 | % | $12.75 | $9.23 | 38 | % |
| Non-GAAP* |  |  |  |  |  |  |
| Operating Earnings | $1,086 | $916 | 19 | % | $3,537 | $3,142 | 13 | % |
| % of Sales | 32.1 | % | 30.4 | % |  | 30.3 | % | 29.0 | % |  |
| EPS | $4.59 | $4.04 | 14 | % | $15.38 | $13.84 | 11 | % |
| Products and Systems Integration Segment |  |  |  |  |  |  |
| Sales | $2,158 | $1,949 | 11 | % | $7,253 | $6,883 | 5 | % |
| GAAP Operating Earnings | $588 | $541 | 9 | % | $1,761 | $1,676 | 5 | % |
| % of Sales | 27.2 | % | 27.8 | % |  | 24.3 | % | 24.3 | % |  |
| Non-GAAP Operating Earnings* | $667 | $594 | 12 | % | $2,098 | $1,931 | 9 | % |
| % of Sales | 30.9 | % | 30.5 | % |  | 28.9 | % | 28.1 | % |  |
| Software and Services Segment |  |  |  |  |  |  |
| Sales | $1,222 | $1,061 | 15 | % | $4,429 | $3,934 | 13 | % |
| GAAP Operating Earnings | $356 | $273 | 30 | % | $1,227 | $1,012 | 21 | % |
| % of Sales | 29.1 | % | 25.7 | % |  | 27.7 | % | 25.7 | % |  |
| Non-GAAP Operating Earnings* | $419 | $322 | 30 | % | $1,439 | $1,211 | 19 | % |
| % of Sales | 34.3 | % | 30.3 | % |  | 32.5 | % | 30.8 | % |  |

[0000068505-26-000006:8k_2_02:18]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.73 for Q4 and $2.63 for FY per diluted share related to highlighted items, including share-based compensation expense and intangible assets amortization expense. Details regarding these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-26-000006:8k_2_02:19]
1

[0000068505-26-000006:8k_2_02:20]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0000068505-26-000006:8k_2_02:21]
•Revenue - Fourth-quarter sales were $3.4 billion, up 12% from the year-ago quarter driven by growth in International and North America. Revenue from acquisitions was $188 million and the impact of favorable foreign currency rates was $30 million. The Products and Systems Integration segment grew 11% with growth in Mission Critical Networks ("MCN") and Video Security and Access Control ("Video"). The Software and Services segment grew 15% driven by growth in all three technologies.

[0000068505-26-000006:8k_2_02:22]
•Operating margin - GAAP operating margin was 27.9% of sales, up from 27.0% in the year-ago quarter and non-GAAP operating margin was 32.1% of sales, up from 30.4% in the year-ago quarter. The increase in both GAAP and non-GAAP operating margin was driven by higher sales, favorable mix and improving operating leverage, partially offset by higher tariffs.

[0000068505-26-000006:8k_2_02:23]
•Taxes - The GAAP effective tax rate was 24.5%, up from 22.2% in the year-ago quarter and the non-GAAP effective tax rate was 23.6%, up from 22.0% in the year-ago quarter, driven by lower benefits from share-based compensation recognized in the current quarter.

[0000068505-26-000006:8k_2_02:24]
•Cash flow - Operating cash flow was $1.3 billion during the quarter, compared with $1.1 billion in the year-ago quarter and free cash flow was $1.1 billion in the quarter, compared with $1.0 billion in the year-ago quarter. Both the operating cash flow and free cash flow for the quarter increased primarily due to higher earnings, net of non-cash charges.

[0000068505-26-000006:8k_2_02:25]
•Capital allocation - During the quarter, the company repurchased $490 million of its common stock at an average price of $402.40, paid $182 million in dividends and invested $114 million in capital expenditures. Additionally, the company closed the acquisition of Blue Eye, a provider of AI-powered enterprise remote video monitoring services, for $79 million, net of cash acquired, and repaid $179 million of short-term borrowings, primarily commercial paper.

[0000068505-26-000006:8k_2_02:26]
Subsequent to quarter end the company repaid $200 million of the $1.5 billion term loans issued to fund the Silvus acquisition, leaving a balance of $1.3 billion outstanding.

[0000068505-26-000006:8k_2_02:27]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0000068505-26-000006:8k_2_02:28]
•Revenue - Full-year sales were $11.7 billion, up 8% driven by growth in North America and International. Revenue from acquisitions was $382 million and the impact of favorable foreign currency rates was $35 million. The Products and Systems Integration segment increased 5% driven by growth in MCN and Video. The Software and Services segment increased 13% driven by growth in all three technologies.

[0000068505-26-000006:8k_2_02:29]
•Operating margin - For the full year, GAAP operating margin was 25.6% of sales, compared to 24.8% for the prior year driven primarily by higher sales, improved operating leverage, and a recovery related to the Hytera litigation, partially offset by higher expenses associated with acquisitions and higher employee incentive costs. Non-GAAP operating margin was 30.3% of sales, up from 29.0% in the prior year driven by higher sales, favorable mix and improved operating leverage.

[0000068505-26-000006:8k_2_02:30]
•Taxes - The 2025 GAAP effective tax rate was 23.2%, compared with 19.8% in the prior year driven by the utilization of foreign tax credit carryovers, partially offset by the non-deductible loss on the extinguishment of Silver Lake convertible debt, both in the prior year. The non-GAAP effective tax rate was 22.3%, up from 22.0% in the previous year.

[0000068505-26-000006:8k_2_02:31]
•Cash flow - The company generated record operating cash flow of $2.8 billion, up 19% versus the prior year, and record free cash flow of $2.6 billion, up 21% versus the prior year. The increase in both operating and free cash flow was primarily driven by higher earnings, net of non-cash charges.

[0000068505-26-000006:8k_2_02:32]
2

[0000068505-26-000006:8k_2_02:33]
•Capital allocation - In 2025, the company closed four acquisitions for $4.9 billion, net of cash acquired, repurchased $1.2 billion of its common stock at an average price of $420.21 per share, paid $728 million in dividends and invested $265 million in capital expenditures. In addition, the company issued $2 billion of long-term senior notes and entered into $1.5 billion of term loans to fund the Silvus acquisition and settled $322 million of debentures due in 2025. Subsequent to the year, the company repaid $200 million of the $1.5 billion term loans issued to fund the Silvus acquisition, leaving a balance of $1.3 billion outstanding.

[0000068505-26-000006:8k_2_02:34]
Additionally, in 2025 the company entered into a new five-year $2.25 billion revolving credit facility maturing in April 2030, replacing the prior $2.25 billion revolving credit facility which was scheduled to mature in March 2026.

[0000068505-26-000006:8k_2_02:35]
•Backlog - The company ended the year with record backlog of $15.7 billion, up $1 billion from the prior year, inclusive of $458 million of favorable foreign currency rates. Products and Systems Integrations segment backlog was down 8% or $323 million primarily driven by strong MCN shipments during the first half of the year. Software and Services segment backlog was up 13%, or $1.4 billion, driven by strong demand in all three technologies and favorable foreign currency rates of $381 million.

[0000068505-26-000006:8k_2_02:36]
NOTABLE WINS & ACHIEVEMENTS IN Q4

[0000068505-26-000006:8k_2_02:37]
Products and Systems Integration

[0000068505-26-000006:8k_2_02:38]
•$180 million P25 system expansion for the State of Tennessee

[0000068505-26-000006:8k_2_02:39]
•$162 million P25 device and body-worn assistant (SVX) order for a U.S. federal customer

[0000068505-26-000006:8k_2_02:40]
•$81 million TETRA system for a customer in North Africa

[0000068505-26-000006:8k_2_02:41]
•$20 million Silvus order for an unmanned systems provider

[0000068505-26-000006:8k_2_02:42]
•$20 million fixed video order for a customer in Argentina

[0000068505-26-000006:8k_2_02:43]
Software and Services

[0000068505-26-000006:8k_2_02:44]
•$201 million ten-year P25 services renewal for the State of Maryland

[0000068505-26-000006:8k_2_02:45]
•$86 million command center order for an international customer

[0000068505-26-000006:8k_2_02:46]
•$79 million P25 services and command center order for Prince George County, MD

[0000068505-26-000006:8k_2_02:47]
•$61 million TETRA services order for the London Underground, U.K.

[0000068505-26-000006:8k_2_02:48]
•$29 million TETRA services order for a European customer

[0000068505-26-000006:8k_2_02:49]
BUSINESS OUTLOOK

[0000068505-26-000006:8k_2_02:50]
•First-quarter 2026 - The company expects revenue growth between 6% and 7% compared to the first quarter of 2025. The company expects non-GAAP EPS in the range of $3.20 to $3.25 per share. This assumes approximately 168 million fully diluted shares and a non-GAAP effective tax rate of approximately 20.5%.

[0000068505-26-000006:8k_2_02:51]
•Full-year 2026 - The company expects revenue of approximately $12.7 billion and non-GAAP EPS in the range of $16.70 to $16.85 per share. This assumes approximately 168 million fully diluted shares and a non-GAAP effective tax rate of approximately 22.5%.

[0000068505-26-000006:8k_2_02:52]
The company has not quantitatively reconciled its guidance for forward-looking non-GAAP measurements in this news release to their most comparable GAAP measurements because the company does not provide specific guidance for the various reconciling items as certain items that impact these measures have not occurred, are out of the company’s control, or cannot be reasonably predicted. Accordingly, a reconciliation to the most comparable GAAP financial measurement is not available without unreasonable effort. Please note that the unavailable reconciling items could significantly impact the company’s results.

[0000068505-26-000006:8k_2_02:53]
3

[0000068505-26-000006:8k_2_02:54]
RECENT EVENTS

[0000068505-26-000006:8k_2_02:55]
MACROECONOMIC ENVIRONMENT UPDATE

[0000068505-26-000006:8k_2_02:56]
The current global trade environment is complex and evolving. In 2025, the U.S. initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, contributing to a global trade landscape subject to evolving tariffs, import/export regulations, including restrictions around rare earth minerals, trade barriers and trade disputes. The company continues to monitor the impact of the current trade environment, including tariffs implemented under the International Emergency Economic Powers Act (IEEPA), for the impacts of policy volatility, pending judicial outcomes, and evolving geopolitical events that may impact its supply chain costs and operational efficiency. In addition, the company is observing shifting dynamics in the memory market driven by substantial demand from the AI data center sector. As a result, the company continues to observe elevated volatility and uncertainty around the global supply chain.

[0000068505-26-000006:8k_2_02:57]
The company engages with global suppliers across a diverse network of locations around the world, and continues to work with its global supply base to mitigate its exposure to the risks to global reciprocal (and sectoral) tariffs, navigate import/export regulations that have developed, and which may continue to develop, and mitigate its exposure to rising costs to facilitate continued supply at levels in order to meet its current customer demand. As a result of the dynamic global supply chain environment, the company has experienced increased costs on materials and components, which it has substantially mitigated during 2025 and for which it expects to continue to develop mitigation actions going forward.

[0000068505-26-000006:8k_2_02:58]
The company continues to see demand for its products and services supported by a multitude of funding sources. In July 2025, the “One Big Beautiful Bill Act” (“OBBBA”) was enacted into law by the President of the United States, which provided a number of changes including funding over the next four years for border security, national security and other opportunities. The company expects OBBBA to provide an additional source of funding to its federal government customers over the four-year period available through OBBBA.

[0000068505-26-000006:8k_2_02:59]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) on Wednesday, February 11. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investors. An archive of the webcast will be available for a limited period of time thereafter.

[0000068505-26-000006:8k_2_02:60]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-26-000006:8k_2_02:61]
A comparison of results from operations is as follows:

[0000068505-26-000006:8k_2_02:62]
|  | Fourth Quarter | Full Year |
|  | 2025 | 2024 | 2025 | 2024 |
| Net sales | $3,380 | $3,010 | $11,682 | $10,817 |
| Gross margin | 1,768 |  | 1,548 |  | 6,035 |  | 5,512 |  |
| Operating earnings | 944 |  | 814 |  | 2,988 |  | 2,688 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |
| Net earnings | 649 |  | 611 |  | 2,154 |  | 1,577 |  |
| Diluted EPS from continuing operations | $3.86 | $3.56 | $12.75 | $9.23 |
| Weighted average diluted common shares outstanding | 168.1 |  | 171.4 |  | 169.0 |  | 170.8 |  |

[0000068505-26-000006:8k_2_02:63]
4

[0000068505-26-000006:8k_2_02:64]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-26-000006:8k_2_02:65]
In addition to the results presented in accordance with accounting principles generally accepted in the U.S. ("GAAP") included in this news release, Motorola Solutions also has included non-GAAP measurements of results, including free cash flow, non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin, non-GAAP net earnings attributable to MSI, non-GAAP tax rate, organic revenue. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period-to-period and allow better comparisons of operating performance to that of its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of its businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes these measurements enable it to make better period-to-period evaluations of the financial performance of its core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, GAAP measurements.

[0000068505-26-000006:8k_2_02:66]
Reconciliations: Details and reconciliations of such non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this news release.

[0000068505-26-000006:8k_2_02:67]
Free cash flow:  Free cash flow represents net cash provided by operating activities less capital expenditures. The company believes that free cash flow is useful to investors as the basis for comparing its performance and coverage ratios with other companies in the company's industries, although the company's measure of free cash flow may not be directly comparable to similar measures used by other companies. This measure is also used as a component of incentive compensation.

[0000068505-26-000006:8k_2_02:68]
Organic Revenue: Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters.  The company believes organic revenue provides useful information for evaluating the periodic growth of the business on a consistent basis and provides for a meaningful period-to-period comparison and analysis of trends in the business.

[0000068505-26-000006:8k_2_02:69]
Non-GAAP operating earnings, non-GAAP EPS, non-GAAP operating margin and non-GAAP net earnings attributable to MSI each excludes highlighted items, including share-based compensation expenses and intangible assets amortization expense, as follows:

[0000068505-26-000006:8k_2_02:70]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction fees, tangible and intangible asset impairments, reorganization of business charges, certain non-cash pension adjustments, legal settlements and other contingencies, gains and losses on investments and businesses, Hytera-related legal expenses, gains and losses on the extinguishment of debt, adjustments to contingent earnout and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-26-000006:8k_2_02:71]
Hytera-Related Legal Expenses: In 2017, the company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), in the U.S. District Court for Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the company's favor and awarded the company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-26-000006:8k_2_02:72]
5

[0000068505-26-000006:8k_2_02:73]
Subsequently, the District Court ordered Hytera to pay the company a forward-looking reasonable royalty on products ("I-Series") that use the company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward.  In 2024, amounts paid into escrow of approximately $61 million were released to the company and recorded as a gain within Other charges within the Consolidated Statement of Operations. Hytera made quarterly de minimis royalty payments related to the I-Series products directly to the company in 2025.

[0000068505-26-000006:8k_2_02:74]
Following the initial District Court judgment in the company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation, turnover of Hytera assets to the company, and injunction are currently briefed. On October 14-15, 2025, the District Court held hearings on these issues, but has not yet issued any rulings.

[0000068505-26-000006:8k_2_02:75]
In 2025, Hytera made payments towards amounts awarded to the company and owed by Hytera pursuant to court orders related to I-Series products. In 2025, Hytera made payments of $157 million, of which the company received $141 million, net of withholding taxes. Subsequent to year-end, in January 2026, Hytera made a payment of $40 million, of which the company received $36 million, net of withholding taxes. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. The company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-26-000006:8k_2_02:76]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the company’s trade secrets in Hytera’s currently shipping products ("H-Series"). On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain H-Series products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions.

[0000068505-26-000006:8k_2_02:77]
The District Court held hearings in August 2024, concerning whether Hytera's currently shipping H-Series products continue to misuse the company's trade secrets and copyrighted source code. On August 25, 2025, the District Court held Hytera in civil contempt for violation of the District Court’s royalty order and ordered Hytera to pay the Company approximately $70 million for unpaid royalties and interest for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera's H-Series products. The District Courts subsequently ordered Hytera to pay additional royalties of $31 million accrued from the August 2024 hearings and the August 25, 2025 order. Hytera has appealed the District Court’s order to the Court of Appeals. Hytera’s appeal does not automatically stay its obligation to pay the $101 million. On October 14-15, 2025, the District Court heard arguments on whether Hytera must pay the $101 million into escrow, or directly to the Company as a payment towards amounts awarded to the Company and owed by Hytera pursuant to prior court orders, but has not yet issued a ruling.

[0000068505-26-000006:8k_2_02:78]
6

[0000068505-26-000006:8k_2_02:79]
Management typically considers legal expenses associated with defending the company's intellectual property as “normal and recurring.” Since 2020, the company has believed that Hytera-related legal expenses have not been part of its “normal and recurring” legal expenses incurred to operate its business and has accordingly excluded such expenses from its GAAP operating Income. In addition, as any contingent or actual gains associated with the Hytera litigation are recognized, they will be similarly excluded from the company's non-GAAP operating income, consistent with the company's treatment of the approximately $61 million realized in 2024 and $157 million realized in 2025. The company believes after the jury award, the presentation of excluding both Hytera-related legal expenses and gains related to awards better aligns with how management evaluates the company's ongoing underlying business performance.

[0000068505-26-000006:8k_2_02:80]
Share-based compensation expenses: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-26-000006:8k_2_02:81]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-26-000006:8k_2_02:82]
7

[0000068505-26-000006:8k_2_02:83]
FORWARD LOOKING STATEMENTS

[0000068505-26-000006:8k_2_02:84]
8

[0000068505-26-000006:8k_2_02:85]
rate fluctuations on cross-border transactions and the translation of local currency results into U.S. dollars; (xxvii) impact of returns on pension and retirement plan assets and interest rate changes; and (xxviii) the return of capital to shareholders through dividends and/or repurchasing shares. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0000068505-26-000006:8k_2_02:86]
ABOUT MOTOROLA SOLUTIONS | SOLVING FOR SAFER

[0000068505-26-000006:8k_2_02:87]
Safety and security are at the heart of everything we do at Motorola Solutions. We build and connect technologies to help protect people, property and places. Our solutions foster the collaboration that’s critical for safer communities, safer schools, safer hospitals, safer businesses, and ultimately, safer nations. Learn more about our commitment to innovating for a safer future for us all at www.motorolasolutions.com.

[0000068505-26-000006:8k_2_02:88]
MEDIA CONTACT

[0000068505-26-000006:8k_2_02:89]
Alexandra Reynolds

[0000068505-26-000006:8k_2_02:90]
Motorola Solutions

[0000068505-26-000006:8k_2_02:91]
+1 312-965-3968

[0000068505-26-000006:8k_2_02:92]
alexandra.reynolds@motorolasolutions.com

[0000068505-26-000006:8k_2_02:93]
INVESTOR CONTACT

[0000068505-26-000006:8k_2_02:94]
Tim Yocum

[0000068505-26-000006:8k_2_02:95]
Motorola Solutions

[0000068505-26-000006:8k_2_02:96]
+1 847-576-6899

[0000068505-26-000006:8k_2_02:97]
Tim.Yocum@motorolasolutions.com

[0000068505-26-000006:8k_2_02:98]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2026 Motorola Solutions, Inc. All rights reserved.

[0000068505-26-000006:8k_2_02:99]
9

[0000068505-26-000006:8k_2_02:100]
GAAP-1

[0000068505-26-000006:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:102]
Consolidated Statements of Operations

[0000068505-26-000006:8k_2_02:103]
(In millions, except per share amount)

[0000068505-26-000006:8k_2_02:104]
|  | Three Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |
| Net sales from products | $ | 2,038 |  |  | $ | 1,815 |  |
| Net sales from services | 1,342 |  |  | 1,195 |  |
| Net sales | 3,380 |  |  | 3,010 |  |
| Costs of products sales | 828 |  |  | 733 |  |
| Costs of services sales | 784 |  |  | 729 |  |
| Costs of sales | 1,612 |  |  | 1,462 |  |
| Gross margin | 1,768 |  |  | 1,548 |  |
| Selling, general and administrative expenses | 499 |  |  | 487 |  |
| Research and development expenditures | 270 |  |  | 246 |  |
| Other charges | (37) |  |  | (38) |  |
| Intangibles amortization | 92 |  |  | 39 |  |
| Operating earnings | 944 |  |  | 814 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (110) |  |  | (56) |  |
| Other, net | 27 |  |  | 29 |  |
| Total other expense | (83) |  |  | (27) |  |
| Net earnings before income taxes | 861 |  |  | 787 |  |
| Income tax expense | 211 |  |  | 175 |  |
| Net earnings | 650 |  |  | 612 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 649 |  |  | $ | 611 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 3.90 |  |  | $ | 3.66 |  |
| Diluted | $ | 3.86 |  |  | $ | 3.56 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 166.2 |  | 167.1 |
| Diluted | 168.1 |  | 171.4 |

[0000068505-26-000006:8k_2_02:105]
|  | Percentage of Net Sales* |
| Net sales from products | 60.3 | % |  | 60.3 | % |
| Net sales from services | 39.7 | % |  | 39.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 40.6 | % |  | 40.4 | % |
| Costs of services sales | 58.4 | % |  | 61.0 | % |
| Costs of sales | 47.7 | % |  | 48.6 | % |
| Gross margin | 52.3 | % |  | 51.4 | % |
| Selling, general and administrative expenses | 14.8 | % |  | 16.2 | % |
| Research and development expenditures | 8.0 | % |  | 8.2 | % |
| Other charges | (1.1) | % |  | (1.3) | % |
| Intangibles amortization | 2.7 | % |  | 1.3 | % |
| Operating earnings | 27.9 | % |  | 27.0 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.3) | % |  | (1.9) | % |
| Other, net | 0.8 | % |  | 1.0 | % |
| Total other expense | (2.5) | % |  | (0.9) | % |
| Net earnings before income taxes | 25.5 | % |  | 26.1 | % |
| Income tax expense | 6.2 | % |  | 5.8 | % |
| Net earnings | 19.2 | % |  | 20.3 | % |
| Less: Earnings attributable to non-controlling interests | — | % |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. | 19.2 | % |  | 20.3 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-26-000006:8k_2_02:106]
10

[0000068505-26-000006:8k_2_02:107]
GAAP-2

[0000068505-26-000006:8k_2_02:108]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:109]
Consolidated Statements of Operations

[0000068505-26-000006:8k_2_02:110]
(In millions, except per share amounts)

[0000068505-26-000006:8k_2_02:111]
|  | Years Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2023 |
| Net sales from products | $ | 6,770 |  |  | $ | 6,454 |  |  | $ | 5,814 |  |
| Net sales from services | 4,912 |  |  | 4,363 |  |  | 4,164 |  |
| Net sales | 11,682 |  |  | 10,817 |  |  | 9,978 |  |
| Costs of products sales | 2,776 |  |  | 2,674 |  |  | 2,591 |  |
| Costs of services sales | 2,871 |  |  | 2,631 |  |  | 2,417 |  |
| Costs of sales | 5,647 |  |  | 5,305 |  |  | 5,008 |  |
| Gross margin | 6,035 |  |  | 5,512 |  |  | 4,970 |  |
| Selling, general and administrative expenses | 1,870 |  |  | 1,752 |  |  | 1,561 |  |
| Research and development expenditures | 970 |  |  | 917 |  |  | 858 |  |
| Other charges | (27) |  |  | 3 |  |  | 80 |  |
| Intangibles amortization | 234 |  |  | 152 |  |  | 177 |  |
| Operating earnings | 2,988 |  |  | 2,688 |  |  | 2,294 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (302) |  |  | (227) |  |  | (216) |  |
| Other, net | 126 |  |  | (489) |  |  | 68 |  |
| Total other expense | (176) |  |  | (716) |  |  | (148) |  |
| Net earnings before income taxes | 2,812 |  |  | 1,972 |  |  | 2,146 |  |
| Income tax expense | 652 |  |  | 390 |  |  | 432 |  |
| Net earnings | 2,160 |  |  | 1,582 |  |  | 1,714 |  |
| Less: Earnings attributable to noncontrolling interests | 6 |  |  | 5 |  |  | 5 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 2,154 |  |  | $ | 1,577 |  |  | $ | 1,709 |  |
| Earnings per common share: |  |  |  |  |  |
| Basic | $ | 12.93 |  |  | $ | 9.45 |  |  | $ | 10.23 |  |
| Diluted | $ | 12.75 |  |  | $ | 9.23 |  |  | $ | 9.93 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 166.6 |  |  | 166.8 |  |  | 167.0 |  |
| Diluted | 169.0 |  |  | 170.8 |  |  | 172.1 |  |

[0000068505-26-000006:8k_2_02:112]
|  | Percentage of Net Sales* |
| Net sales from products | 58.0 | % |  | 59.7 | % |  | 58.3 | % |
| Net sales from services | 42.0 | % |  | 40.3 | % |  | 41.7 | % |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 41.0 | % |  | 41.4 | % |  | 44.6 | % |
| Costs of services sales | 58.4 | % |  | 60.3 | % |  | 58.0 | % |
| Costs of sales | 48.3 | % |  | 49.0 | % |  | 50.2 | % |
| Gross margin | 51.7 | % |  | 51.0 | % |  | 49.8 | % |
| Selling, general and administrative expenses | 16.0 | % |  | 16.2 | % |  | 15.6 | % |
| Research and development expenditures | 8.3 | % |  | 8.5 | % |  | 8.6 | % |
| Other charges | (0.2) | % |  | — | % |  | 0.8 | % |
| Intangibles amortization | 2.0 | % |  | 1.4 | % |  | 1.8 | % |
| Operating earnings | 25.6 | % |  | 24.8 | % |  | 23.0 | % |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (2.6) | % |  | (2.1) | % |  | (2.2) | % |
| Other, net | 1.1 | % |  | (4.5) | % |  | 0.7 | % |
| Total other expense | (1.5) | % |  | (6.6) | % |  | (1.5) | % |
| Net earnings before income taxes | 24.1 | % |  | 18.2 | % |  | 21.5 | % |
| Income tax expense | 5.6 | % |  | 3.6 | % |  | 4.3 | % |
| Net earnings | 18.5 | % |  | 14.6 | % |  | 17.2 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 18.4 | % |  | 14.6 | % |  | 17.1 | % |
| * Percentages may not add up due to rounding |  |  |  |  |  |

[0000068505-26-000006:8k_2_02:113]
11

[0000068505-26-000006:8k_2_02:114]
GAAP-3

[0000068505-26-000006:8k_2_02:115]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:116]
Consolidated Balance Sheets

[0000068505-26-000006:8k_2_02:117]
(In millions)

[0000068505-26-000006:8k_2_02:118]
|  | December 31, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,165 |  |  | $ | 2,102 |  |
| Accounts receivable, net | 2,200 |  |  | 1,952 |  |
| Contract assets | 1,574 |  |  | 1,230 |  |
| Inventories, net | 983 |  |  | 766 |  |
| Other current assets | 378 |  |  | 429 |  |
| Total current assets | 6,300 |  |  | 6,479 |  |
| Property, plant and equipment, net | 1,165 |  |  | 1,022 |  |
| Operating lease assets | 581 |  |  | 529 |  |
| Investments | 187 |  |  | 135 |  |
| Deferred income taxes | 761 |  |  | 1,280 |  |
| Goodwill | 6,800 |  |  | 3,526 |  |
| Intangible assets, net | 3,104 |  |  | 1,249 |  |
| Other assets | 491 |  |  | 375 |  |
| Total assets | $ | 19,389 |  |  | $ | 14,595 |  |
| Liabilities and Stockholders' Equity |  |  |  |
| Current portion of long-term debt | $ | — |  |  | $ | 322 |  |
| Short-term borrowings | 749 |  |  | — |  |
| Accounts payable | 1,134 |  |  | 1,018 |  |
| Contract liabilities | 2,265 |  |  | 2,072 |  |
| Accrued liabilities | 1,930 |  |  | 1,643 |  |
| Total current liabilities | 6,078 |  |  | 5,055 |  |
| Long-term debt | 8,413 |  |  | 5,675 |  |
| Operating lease liabilities | 471 |  |  | 427 |  |
| Other liabilities | 2,000 |  |  | 1,719 |  |
| Total Motorola Solutions, Inc. stockholders’ equity | 2,410 |  |  | 1,703 |  |
| Noncontrolling interests | 17 |  |  | 16 |  |
| Total liabilities and stockholders’ equity | $ | 19,389 |  |  | $ | 14,595 |  |

[0000068505-26-000006:8k_2_02:119]
12

[0000068505-26-000006:8k_2_02:120]
GAAP-4

[0000068505-26-000006:8k_2_02:121]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:122]
Consolidated Statements of Cash Flows

[0000068505-26-000006:8k_2_02:123]
(In millions)

[0000068505-26-000006:8k_2_02:124]
|  | Three Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |
| Operating |  |  |  |
| Net earnings | $ | 650 |  |  | $ | 612 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 143 |  |  | 87 |  |
| Non-cash other charges | 7 |  |  | 4 |  |
| Share-based compensation expenses | 80 |  |  | 63 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable | (174) |  |  | (125) |  |
| Inventories | (38) |  |  | 41 |  |
| Other current assets and contract assets | 9 |  |  | 66 |  |
| Accounts payable, accrued liabilities, and contract liabilities | 560 |  |  | 427 |  |
| Other assets and liabilities | 20 |  |  | (46) |  |
| Deferred income taxes | (1) |  |  | (59) |  |
| Net cash provided by operating activities | 1,256 |  |  | 1,070 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (81) |  |  | (22) |  |
| Proceeds from sales of investments | 3 |  |  | 2 |  |
| Capital expenditures | (114) |  |  | (87) |  |
| Net cash used for investing activities | (192) |  |  | (107) |  |
| Financing |  |  |  |
| Repayment of short-term borrowings | (179) |  |  | — |  |
| Issuances of common stock, net of tax | 50 |  |  | 57 |  |
| Purchases of common stock | (490) |  |  | (106) |  |
| Payment of dividends | (182) |  |  | (164) |  |
| Net cash used for financing activities | (801) |  |  | (213) |  |
| Effect of exchange rate changes on cash and cash equivalents | 8 |  |  | (52) |  |
| Net increase in cash and cash equivalents | 271 |  |  | 698 |  |
| Cash and cash equivalents, beginning of period | 894 |  |  | 1,404 |  |
| Cash and cash equivalents, end of period | $ | 1,165 |  |  | $ | 2,102 |  |

[0000068505-26-000006:8k_2_02:125]
13

[0000068505-26-000006:8k_2_02:126]
GAAP-5

[0000068505-26-000006:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:128]
Consolidated Statements of Cash Flows

[0000068505-26-000006:8k_2_02:129]
(In millions)

[0000068505-26-000006:8k_2_02:130]
|  | Years Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2023 |
| Operating |  |  |  |  |  |
| Net earnings | $ | 2,160 |  |  | $ | 1,582 |  |  | $ | 1,714 |  |
| Adjustments to reconcile Net earnings to Net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization | 425 |  |  | 336 |  |  | 356 |  |
| Non-cash other charges | 3 |  |  | 16 |  |  | 14 |  |
| Exit of video manufacturing operations | — |  |  | — |  |  | 24 |  |
| Share-based compensation expenses | 293 |  |  | 243 |  |  | 212 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | — |  |  | 585 |  |  | — |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |
| Accounts receivable | (173) |  |  | (246) |  |  | (180) |  |
| Inventories | (145) |  |  | 62 |  |  | 200 |  |
| Other current assets and contract assets | (221) |  |  | (213) |  |  | (82) |  |
| Accounts payable, accrued liabilities, and contract liabilities | 280 |  |  | 302 |  |  | (144) |  |
| Other assets and liabilities | 121 |  |  | (61) |  |  | (38) |  |
| Deferred income taxes | 94 |  |  | (215) |  |  | (32) |  |
| Net cash provided by operating activities | 2,837 |  |  | 2,391 |  |  | 2,044 |  |
| Investing |  |  |  |  |  |
| Acquisitions and investments, net | (4,916) |  |  | (290) |  |  | (180) |  |
| Proceeds from sales of investments | 17 |  |  | 40 |  |  | 19 |  |
| Capital expenditures | (265) |  |  | (257) |  |  | (253) |  |
| Net cash used for investing activities | (5,164) |  |  | (507) |  |  | (414) |  |
| Financing |  |  |  |  |  |
| Net proceeds from issuance of debt | 2,733 |  |  | 1,288 |  |  | — |  |
| Net proceeds from short-term borrowings | 923 |  |  | — |  |  | — |  |
| Repayment of debt | (322) |  |  | (1,906) |  |  | (1) |  |
| Repayment of short-term borrowings | (179) |  |  | — |  |  | — |  |
| Revolving credit facility renewal fees | (5) |  |  | — |  |  | — |  |
| Issuances of common stock, net of tax | 46 |  |  | 75 |  |  | 104 |  |
| Purchases of common stock | (1,154) |  |  | (247) |  |  | (804) |  |
| Payment of dividends | (728) |  |  | (654) |  |  | (589) |  |
| Payment of dividends to noncontrolling interest | (5) |  |  | (4) |  |  | (5) |  |
| Net cash provided by (used for) financing activities | 1,309 |  |  | (1,448) |  |  | (1,295) |  |
| Effect of exchange rate changes on cash and cash equivalents | 81 |  |  | (39) |  |  | 45 |  |
| Net increase (decrease) in cash and cash equivalents | (937) |  |  | 397 |  |  | 380 |  |
| Cash and cash equivalents, beginning of period | 2,102 |  |  | 1,705 |  |  | 1,325 |  |
| Cash and cash equivalents, end of period | $ | 1,165 |  |  | $ | 2,102 |  |  | $ | 1,705 |  |

[0000068505-26-000006:8k_2_02:131]
14

[0000068505-26-000006:8k_2_02:132]
Non-GAAP-1

[0000068505-26-000006:8k_2_02:133]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Net Cash Provided by Operating Activities to Free Cash Flow |
| (In millions) |

[0000068505-26-000006:8k_2_02:134]
|  |  | Three Months Ended |  | Years Ended |  |  |  |  |
|  |  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 1,256 |  |  | $ | 1,070 |  |  | $ | 2,837 |  |  | $ | 2,391 |  |  |  |  |  |  |  |
| Capital expenditures |  | (114) |  |  | (87) |  |  | (265) |  |  | (257) |  |  |  |  |  |  |  |
| Free cash flow |  | $ | 1,142 |  |  | $ | 983 |  |  | $ | 2,572 |  |  | $ | 2,134 |  |  |  |  |  |  |  |

[0000068505-26-000006:8k_2_02:135]
15

[0000068505-26-000006:8k_2_02:136]
Non-GAAP-2

[0000068505-26-000006:8k_2_02:137]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:138]
Reconciliation of Net Earnings Attributable to MSI to Non-GAAP Net Earnings Attributable to MSI

[0000068505-26-000006:8k_2_02:139]
(In millions)

[0000068505-26-000006:8k_2_02:140]
|  |  |  |  | Three Months Ended |  | Years Ended |
|  |  | Statement Line |  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Net earnings attributable to MSI |  |  |  | $ | 649 |  |  | $ | 611 |  |  | $ | 2,154 |  |  | $ | 1,577 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 92 |  |  | $ | 39 |  |  | $ | 234 |  |  | $ | 152 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 80 |  |  | 63 |  |  | 293 |  |  | 243 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 15 |  |  | 17 |  |  | 60 |  |  | 38 |  |
| Legal settlements |  | Other charges (Income) |  | 8 |  |  | — |  |  | 15 |  |  | 7 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 4 |  |  | 8 |  |  | 66 |  |  | 20 |  |
| Assessments of uncertain tax positions |  | Interest income, net |  | 4 |  |  | — |  |  | 6 |  |  | 22 |  |
| Hytera-related legal expenses |  | SG&A |  | 3 |  |  | 31 |  |  | 34 |  |  | 45 |  |
| Environmental reserve expense |  | Other charges (income) |  | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 2 |  |  | 1 |  |  | (19) |  |  | 5 |  |
| Investment impairments |  | Other (income) expense |  | 1 |  |  | — |  |  | 4 |  |  | 3 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 1 |  |  | 1 |  |  | 2 |  |  | 6 |  |
| Loss on financing issuance costs |  | Other (income) expense) |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | 585 |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (63) |  |  | (61) |  |  | (157) |  |  | (61) |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 149 |  |  | $ | 103 |  |  | $ | 542 |  |  | $ | 1,069 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 27 |  |  | 21 |  | 97 |  | 280 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 122 |  | 82 |  | 445 |  |  | 789 |
| Non-GAAP Net earnings attributable to MSI |  |  |  | $ | 771 |  |  | $ | 693 |  |  | $ | 2,599 |  |  | $ | 2,366 |  |

[0000068505-26-000006:8k_2_02:141]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:142]
Calculation of Non-GAAP Tax Rate

[0000068505-26-000006:8k_2_02:143]
(In millions)

[0000068505-26-000006:8k_2_02:144]
|  |  | Three Months Ended |  | Years Ended |  |  |  |
|  |  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |  |  |  |  |  |  |
| Net earnings before income taxes |  | $ | 861 |  |  | $ | 787 |  |  | $ | 2,812 |  |  | $ | 1,972 |  |  |  |  |  |  |  |
| Total Non-GAAP adjustments before income taxes* |  | 149 |  |  | 103 |  |  | 542 |  |  | 1,069 |  |  |  |  |  |  |  |
| Non-GAAP Net earnings before income taxes |  | 1,010 |  |  | 890 |  |  | 3,354 |  |  | 3,041 |  |  |  |  |  |  |  |
| Income tax expense |  | 211 |  |  | 175 |  |  | 652 |  |  | 390 |  |  |  |  |  |  |  |
| Income tax expense on Non-GAAP adjustments** |  | 27 |  |  | 21 |  |  | 97 |  |  | 280 |  |  |  |  |  |  |  |
| Total Non-GAAP Income tax expense |  | 238 |  |  | 196 |  |  | 749 |  |  | 670 |  |  |  |  |  |  |  |
| Non-GAAP Tax rate |  | 23.6 | % |  | 22.0 | % |  | 22.3 | % |  | 22.0 | % |  |  |  |  |  |  |
| *See reconciliation on Non-GAAP-2 table above for detail on Non-GAAP adjustments before income taxes |  |  |  |  |  |  |  |  |  |  |
| **Income tax impact of highlighted items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000068505-26-000006:8k_2_02:145]
16

[0000068505-26-000006:8k_2_02:146]
Non-GAAP-2

[0000068505-26-000006:8k_2_02:147]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:148]
Reconciliation of Earnings Per Share to Non-GAAP Earnings Per Share*

[0000068505-26-000006:8k_2_02:149]
|  |  |  |  | Three Months Ended |  | Years Ended |
|  |  | Statement Line |  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Earnings per share attributable to MSI |  |  |  | $ | 3.86 |  |  | $ | 3.56 |  |  | $ | 12.75 |  |  | $ | 9.23 |  |
| Non-GAAP adjustments before income taxes: |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | Intangibles amortization |  | $ | 0.55 |  |  | $ | 0.23 |  |  | $ | 1.39 |  |  | $ | 0.89 |  |
| Share-based compensation expenses |  | Cost of sales, SG&A and R&D |  | 0.47 |  |  | 0.37 |  |  | 1.73 |  |  | 1.42 |  |
| Reorganization of business charges |  | Cost of sales and Other charges (income) |  | 0.09 |  |  | 0.10 |  |  | 0.36 |  |  | 0.22 |  |
| Legal settlements |  | Other charges (Income) |  | 0.05 |  |  | — |  |  | 0.09 |  |  | 0.04 |  |
| Acquisition-related transaction fees |  | Other charges (income) |  | 0.02 |  |  | 0.04 |  |  | 0.39 |  |  | 0.12 |  |
| Assessments of uncertain tax positions |  | Interest income, net |  | 0.02 |  |  | — |  |  | 0.04 |  |  | 0.13 |  |
| Hytera-related legal expenses |  | SG&A |  | 0.02 |  |  | 0.18 |  |  | 0.20 |  |  | 0.27 |  |
| Environmental reserve expense |  | Other charges (income) |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| Fair value adjustments to equity investments |  | Other (income) expense |  | 0.01 |  |  | 0.01 |  |  | (0.11) |  |  | 0.03 |  |
| Investment impairments |  | Other (income) expense |  | 0.01 |  |  | — |  |  | 0.02 |  |  | 0.02 |  |
| Operating lease asset impairments |  | Other charges (income) |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.04 |  |
| Loss on financing issuance costs | 0 | Other (income) expense) |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Fixed asset impairments |  | Other charges (income) |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt |  | Other (income) expense |  | — |  |  | — |  |  | — |  |  | 3.42 |  |
| Gain on Hytera litigation |  | Other charges (income) |  | (0.37) |  |  | (0.36) |  |  | (0.93) |  |  | (0.36) |  |
| Total Non-GAAP adjustments before income taxes |  |  |  | $ | 0.89 |  |  | $ | 0.60 |  |  | $ | 3.21 |  |  | $ | 6.26 |  |
| Income tax expense on Non-GAAP adjustments |  |  |  | 0.16 |  |  | 0.12 |  | 0.58 |  | 1.65 |
| Total Non-GAAP adjustments after income taxes |  |  |  | 0.73 |  | 0.48 |  | 2.63 |  |  | 4.61 |
| Non-GAAP Earnings per share attributable to MSI |  |  |  | $ | 4.59 |  |  | $ | 4.04 |  |  | $ | 15.38 |  |  | $ | 13.84 |  |
| GAAP Diluted Weighted Average Common Shares |  |  |  | 168.1 |  |  | 171.4 |  |  | 169.0 |  |  | 170.8 |  |
| Adjusted for dilutive shares outstanding** |  |  |  | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Non-GAAP Diluted Weighted Average Common Shares |  |  |  | 168.1 |  |  | 171.4 |  |  | 169.0 |  |  | 171.0 |  |
| *Indicates Non-GAAP Diluted EPS |  |  |  |  |  |  |  |  |  |  |
| ** Under U.S. GAAP, the Silver Lake shares were considered anti-dilutive to earnings per share for the year ended December 31, 2024 and were excluded from the computation of GAAP diluted weighted average common shares and diluted earnings per share. The shares are considered dilutive for non-GAAP earnings per share for the year ended December 31, 2024 and an adjustment is reflected to include these shares for non-GAAP diluted earnings per share. |

[0000068505-26-000006:8k_2_02:150]
17

[0000068505-26-000006:8k_2_02:151]
Non-GAAP-3

[0000068505-26-000006:8k_2_02:152]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:153]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-26-000006:8k_2_02:154]
(In millions)

[0000068505-26-000006:8k_2_02:155]
|  |  | Three Months Ended |
|  |  | December 31, 2025 |  | December 31, 2024 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 2,158 |  |  | $ | 1,222 |  |  | $ | 3,380 |  |  | $ | 1,949 |  |  | $ | 1,061 |  |  | $ | 3,010 |  |
| Operating earnings |  | $ | 588 |  |  | $ | 356 |  |  | $ | 944 |  |  | $ | 541 |  |  | $ | 273 |  |  | $ | 814 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intangible assets amortization expense |  | 60 |  |  | 32 |  |  | 92 |  |  | 19 |  |  | 20 |  |  | 39 |  |
| Share-based compensation expenses |  | 59 |  |  | 21 |  |  | 80 |  |  | 46 |  |  | 17 |  |  | 63 |  |
| Reorganization of business charges |  | 11 |  |  | 4 |  |  | 15 |  |  | 12 |  |  | 5 |  |  | 17 |  |
| Legal settlements |  | 6 |  |  | 2 |  |  | 8 |  |  | — |  |  | — |  |  | — |  |
| Acquisition-related transaction fees |  | 1 |  |  | 3 |  |  | 4 |  |  | 1 |  |  | 7 |  |  | 8 |  |
| Hytera-related legal expenses |  | 3 |  |  | — |  |  | 3 |  |  | 31 |  |  | — |  |  | 31 |  |
| Environmental reserve expense |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |  | — |  |  | 2 |  |
| Operating lease asset impairments |  | 1 |  |  | — |  |  | 1 |  |  | 2 |  |  | (1) |  |  | 1 |  |
| Fixed asset impairments |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Gain on Hytera litigation |  | (63) |  |  | — |  |  | (63) |  |  | (61) |  |  | — |  |  | (61) |  |
| Total above-OE non-GAAP adjustments |  | 79 |  |  | 63 |  |  | 142 |  |  | 53 |  |  | 49 |  |  | 102 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 667 |  |  | $ | 419 |  |  | $ | 1,086 |  |  | $ | 594 |  |  | $ | 322 |  |  | $ | 916 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 27.2 | % |  | 29.1 | % |  | 27.9 | % |  | 27.8 | % |  | 25.7 | % |  | 27.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 30.9 | % |  | 34.3 | % |  | 32.1 | % |  | 30.5 | % |  | 30.3 | % |  | 30.4 | % |

[0000068505-26-000006:8k_2_02:156]
18

[0000068505-26-000006:8k_2_02:157]
Non-GAAP-4

[0000068505-26-000006:8k_2_02:158]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-26-000006:8k_2_02:159]
Reconciliations of Operating Earnings to Non-GAAP Operating Earnings and Operating Margin to Non-GAAP Operating Margin

[0000068505-26-000006:8k_2_02:160]
(In millions)

[0000068505-26-000006:8k_2_02:161]
|  |  | Years Ended |
|  |  | December 31, 2025 |  | December 31, 2024 |
|  |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales |  | $ | 7,253 |  |  | $ | 4,429 |  |  | $ | 11,682 |  |  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |
| Operating earnings ("OE") |  | $ | 1,761 |  |  | $ | 1,227 |  |  | $ | 2,988 |  |  | $ | 1,676 |  |  | $ | 1,012 |  |  | $ | 2,688 |  |
| Above OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  | 214 |  |  | 79 |  |  | 293 |  |  | 172 |  |  | 71 |  |  | 243 |  |
| Intangible assets amortization expense |  | 136 |  |  | 98 |  |  | 234 |  |  | 54 |  |  | 98 |  |  | 152 |  |
| Acquisition-related transaction fees |  | 55 |  |  | 11 |  |  | 66 |  |  | 4 |  |  | 16 |  |  | 20 |  |
| Reorganization of business charges |  | 42 |  |  | 18 |  |  | 60 |  |  | 32 |  |  | 6 |  |  | 38 |  |
| Hytera-related legal expenses |  | 34 |  |  | — |  |  | 34 |  |  | 45 |  |  | — |  |  | 45 |  |
| Legal settlements |  | 10 |  |  | 5 |  |  | 15 |  |  | 1 |  |  | 6 |  |  | 7 |  |
| Operating lease asset impairments |  | 2 |  |  | — |  |  | 2 |  |  | 5 |  |  | 1 |  |  | 6 |  |
| Environmental reserve expense |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |  | — |  |  | 2 |  |
| Fixed asset impairments |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Gain on Hytera litigation |  | (157) |  |  | — |  |  | (157) |  |  | (61) |  |  | — |  |  | (61) |  |
| Total above-OE non-GAAP adjustments |  | 337 |  |  | 212 |  |  | 549 |  |  | 255 |  |  | 199 |  |  | 454 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 2,098 |  |  | $ | 1,439 |  |  | $ | 3,537 |  |  | $ | 1,931 |  |  | $ | 1,211 |  |  | $ | 3,142 |  |
| Operating earnings as a percentage of net sales - GAAP |  | 24.3 | % |  | 27.7 | % |  | 25.6 | % |  | 24.3 | % |  | 25.7 | % |  | 24.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 28.9 | % |  | 32.5 | % |  | 30.3 | % |  | 28.1 | % |  | 30.8 | % |  | 29.0 | % |

[0000068505-26-000006:8k_2_02:162]
19

[0000068505-26-000006:8k_2_02:163]
Non-GAAP-5

[0000068505-26-000006:8k_2_02:164]
| Motorola Solutions, Inc. and Subsidiaries |
| Reconciliation of Revenue to Non-GAAP Organic Revenue |
| (In millions) |

[0000068505-26-000006:8k_2_02:165]
|  |  | Three Months Ended |  |  |
|  |  | December 31, 2025 |  | December 31, 2024 |  | % Change |
| Net sales |  | $ | 3,380 |  |  | $ | 3,010 |  |  | 12 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 188 |  |  | — |  |  |  |
| Organic revenue |  | $ | 3,192 |  |  | $ | 3,010 |  |  | 6 | % |

[0000068505-26-000006:8k_2_02:166]
|  |  | Years Ended |  |  |
|  |  | December 31, 2025 |  | December 31, 2024 |  | % Change |
| Net sales |  | $ | 11,682 |  |  | $ | 10,817 |  |  | 8 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Sales from acquisitions |  | 382 |  |  | — |  |  |  |
| Organic revenue |  | $ | 11,300 |  |  | $ | 10,817 |  |  | 4 | % |

[0000068505-26-000006:8k_2_02:167]
20
