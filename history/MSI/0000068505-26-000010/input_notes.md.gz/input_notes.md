# MSI notes — 0000068505-26-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000068505-26-000010:notes:1]
Portions of the registrant’s definitive Proxy Statement to be delivered to stockholders in connection with its 2026 Annual Meeting of Shareholders (the "Proxy Statement"), to be filed within 120 days of the end of the fiscal year ended December 31, 2025, are incorporated by reference into Part III of this Annual Report on Form 10-K (this "Form 10-K").


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000068505-26-000010:notes:2]
We assess, identify and manage material risks from cybersecurity threats through various protective policies, procedures and processes, including through: (1) the monitoring responsibilities of our cybersecurity program; (2) our information security policies and standards, including our global incident response procedure; (3) our audit services department’s annual enterprise risk management (“ERM”) assessment; (4) our third-party cybersecurity risk assessment program; and (5) cybersecurity insurance.

[0000068505-26-000010:notes:3]
Designed to maintain the confidentiality, integrity and availability of customer and internal company information, our cybersecurity program focuses on protecting our enterprise information systems and the secure development and deployment of our products. We monitor for critical vulnerabilities and threat actor activity, and work to create a unified view to prioritize protecting our critical infrastructure (including potential impacts to key third-party service providers to the Company). The cybersecurity program, which is led by our Vice President of Cybersecurity & Information Technology Infrastructure, holds regular meetings to review ongoing internal information security operations, including by reviewing the Company's information security policies, controls, investigations, and responses. We assess the effectiveness of our cybersecurity program using self-assessments and independent third-party analyses, and evaluate our program using frameworks such as the National Institute of Standards and Technology (“NIST”) Cybersecurity Framework. In addition to these independent third-party analyses, third-parties also provide services to support our cybersecurity in several ways, such as through penetration testing and commercial information security threat sharing networks, and by assisting with tabletop exercises and certain monitoring activities.

[0000068505-26-000010:notes:4]
We have designed and implemented a global incident response procedure, which helps enable us to quickly detect, respond to, and recover from third-party malicious attacks and potential security incidents. This procedure includes formal steps to review incidents and implement improvements, including steps to involve the Vice President of Cybersecurity & Information Technology Infrastructure, as appropriate. In addition, we have other specific information security policies and standards, organized to align with various NIST frameworks, which we use to manage our cybersecurity risks.

[0000068505-26-000010:notes:5]
Assessing, identifying and managing cybersecurity risks are integrated into our audit services department’s annual ERM assessment, which is designed to identify, assess, prioritize, mitigate and monitor our principal risks. The ERM assessment considers the probability, impact and velocity of potential risks, providing management and the Audit Committee with an overarching and objective view of the Company's risk management activities. Audit services identifies and conducts engagements utilizing inputs from the ERM assessment. The engagements span financial, operational, strategic and compliance risks, with a view to assessing risks over a two-year time horizon. The engagement results assist management in maintaining acceptable risk levels. The Vice President of Audit Services reports directly to the Audit Committee as well as to the Chief Financial Officer and meets regularly with the Audit Committee and its chairperson, including in executive sessions. Separately, the Vice President of Audit Services and Vice President of Ethics & Compliance head an internal cross-functional team (including members from our cybersecurity and data privacy programs, among others) that holds regular meetings to discuss the key risks facing the Company and related mitigation efforts, including cybersecurity risks. Cybersecurity risk is tracked as a principal risk within the context of the ERM assessment.

[0000068505-26-000010:notes:6]
In addition, we have processes designed to oversee and identify risks from cybersecurity threats associated with our use of third-party service providers. Pursuant to our third-party cybersecurity risk assessment program, any outsource partners and suppliers that have access to the Company’s data or customer data complete a risk assessment prior to the Company engaging with such parties. Using the assessments, our cybersecurity program looks to determine any gaps and identified risks, and then appropriate teams within the Company work to track and remediate such risks. These third-party risk assessments are foundational for how we manage and monitor our software supply chain and service providers.

[0000068505-26-000010:notes:7]
To further complement the processes described above, we maintain insurance related to cybersecurity risks. We maintain a broad portfolio of insurance coverage, leveraging the products of multiple companies to help ensure appropriate protection.

[0000068505-26-000010:notes:8]
We are subject to attempts to compromise our information technology systems from both internal and external sources. Like all information technology systems, our systems have been in the past, and could be in the future, vulnerable to damage, unauthorized access or interruption from a variety of sources. As of the filing of this Form 10-K, we are not aware of any such attacks that have occurred since the beginning of 2025 that have materially affected, or are reasonably likely to materially affect, us, including our business strategy, results of operations or financial condition. However, if as a result of any future attacks our information technology systems are significantly damaged, cease to function properly or are subject to a significant cybersecurity breach, we may suffer an interruption in our ability to manage and operate our business, and our business strategy, results of operations or financial condition could be adversely affected. Such attacks, whether or not successful, could damage our reputation and result in significant costs related to, for example, repairing or replacing our IT systems; the loss of critical data; interruptions or delays in our ability, or that of our customers, to perform critical functions; defending against claims for breach of contracts, tort and other civil claims without adequate indemnification from our suppliers; providing time-sensitive notification requirements; and providing modifications or replacements to our products and services. In addition, the volume, frequency and sophistication of these threats (including through the use of AI) continues to grow and the complexity and scale of the systems to be protected continues to increase. See “Risks Related to Information Technology and Intellectual Property” in “Part I. Item 1A. Risk Factors” of this Form 10-K for further information.


## cyd:CybersecurityRiskBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0000068505-26-000010:notes:9]
The Vice President of Audit Services reports directly to the Audit Committee as well as to the Chief Financial Officer and meets regularly with the Audit Committee and its chairperson, including in executive sessions.Our Vice President of Cybersecurity & Information Technology Infrastructure, along with the respective teams, are in charge of assessing and managing our risks related to cybersecurity, including by setting our strategy, policies, standards and processes in these areas, as further described above under “Risk Management & Strategy.” Utilizing the processes noted above, these teams remain informed about and monitor the prevention, detection, mitigation and remediation of cybersecurity incidents.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000068505-26-000010:notes:10]
Our Board has delegated to the Audit Committee the responsibility to oversee risks related to cybersecurity threats. Specifically, subject to oversight by the full Board, the Vice President of Cybersecurity & Information Technology Infrastructure provides the Audit Committee with periodic cybersecurity and information security reports, including recent cybersecurity incidents and the potential threat landscape pertaining to the cybersecurity of our products and operations. Annually, the Vice President of Audit Services also reviews the results of the ERM assessment with the Audit Committee. In addition, a subset or the full group of certain individuals, such as our Chief Information Officer, Vice President of Cybersecurity & Information Technology Infrastructure, and Data Protection Officer, present at least once per year to the Audit Committee regarding cybersecurity and data privacy risk topics. The full Board is regularly informed about such risks through Audit Committee reports and presentations.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0000068505-26-000010:notes:11]
Our Vice President of Cybersecurity & Information Technology Infrastructure, along with the respective teams, are in charge of assessing and managing our risks related to cybersecurity, including by setting our strategy, policies, standards and processes in these areas, as further described above under “Risk Management & Strategy.” Utilizing the processes noted above, these teams remain informed about and monitor the prevention, detection, mitigation and remediation of cybersecurity incidents.

[0000068505-26-000010:notes:12]
Our Vice President of Cybersecurity & Information Technology Infrastructure has over thirty years of work experience in the information technology field, specifically information security. This individual began their career as a security engineer, progressing to a security architect, and then to overall leader of the Cybersecurity and Information Technology Infrastructure functions at the Company. This individual holds a Master of Computer Science degree. This individual also maintains a Certified Information Security Manager (CISM) certification from ISACA, an international professional organization focused on IT governance, as well as a Certified Information Systems Security Professional (CISSP) certification from the International Information System Security Certification Consortium (ISC2), a leading member association for cybersecurity professionals.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-26-000010:notes:13]
Summary of Significant Accounting Policies
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-26-000010:notes:14]
The consolidated financial statements as of December 31, 2025 and 2024 and for the years ended December 31, 2025, 2024 and 2023, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.

[0000068505-26-000010:notes:15]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-26-000010:notes:16]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of products, systems and system integration as well as offering software and service solutions. The Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services.

[0000068505-26-000010:notes:17]
The Products and Systems Integration segment is comprised of devices, systems, and systems integration for our Mission Critical Networks ("MCN") and Video Security and Access Control ("Video") technologies. Direct customers of the Products and Systems Integration segment are typically government, including defense, public safety agencies, procuring at state, local, and federal levels as well as large enterprise customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional and commercial radios and video security, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications systems and video security are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our government customers, funded through appropriations. The Company records consideration from shipping and handling on a gross basis within Net sales. In limited instances where the Company is not the principal in the arrangement, the Company will recognize revenue on a net basis.

[0000068505-26-000010:notes:18]
MCN and Video devices include two-way portable and vehicle-mounted radios, video cameras and accessories. Devices are considered capable of being distinct and distinct within the context of the Company's contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-26-000010:notes:19]
The Products and Systems Integration segment includes both customized communications systems and video security solutions, including the integration of these networks with devices, software, and applications within both MCN and Video technologies. For systems contracts, revenue for the year ended December 31, 2025 was $2.2 billion compared to $2.0 billion for the year ended December 31, 2024 and $1.9 billion for the year ended December 31, 2023. The communications systems include the aggregation of promises to the customer to provide i) a communications network core and central processing software, base stations, consoles, and repeaters or ii) a video security solution including video analytics, network video management hardware and software, and access control solutions. The individual promises within a communications network contract are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The communications network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Products and Systems Integration revenue for communications network systems is recognized over an average duration of approximately one to two years. Individual promises of the video security solution are capable of being distinct and distinct in the context of the contract. Video security solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-26-000010:notes:20]
The Software and Services segment provides solutions for government, public safety and enterprise communications systems. Direct customers of the Software and Services segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are enterprise customers who distribute our software solutions to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-26-000010:notes:21]
Software offerings primarily include Command Center and Video software and services which can be delivered either as an “as-a-service”, on-premise, or hybrid solution. Solutions delivered as-a-service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. Solutions delivered as-a-service are recognized over time on a straight-line basis as a series of distinct services.

[0000068505-26-000010:notes:22]
On-premise and hybrid offerings generally consist of multiple promises primarily including software licenses and post-contract customer support. The promises are generally each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is generally recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis. In certain situations when the software license is not distinct within the context of the contract, revenue for the software license is recognized over time following the transfer of control under the arrangement. For hybrid arrangements, the on-premise software, cloud-based software, and implementation services are a single performance obligation, wherein over time revenue recognition begins at the point of service activation when the customer can access the system and begin beneficial use.

[0000068505-26-000010:notes:23]
Services include a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer-owned or Motorola Solutions-owned communications systems. Services are provided across all technologies and are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-26-000010:notes:24]
The Company enters into arrangements which generally consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We use list price as the standalone selling price for indirect sales sold through our channel partners. Given the unique nature of the goods and services we provide to direct customers, sufficient standalone sales of our products generally do not exist. Therefore, the Company determines ESP by: (i) collecting all reasonably available historical data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points for similar customers and circumstances, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-26-000010:notes:25]
The Company accounts for certain system contracts without an alternative use on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-26-000010:notes:26]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract ("Estimated Costs to Complete"). Estimated Costs to Complete include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs to Complete may be complex and subject to many variables. The Company has a standard and disciplined process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs to Complete. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor cost, inclusive of subcontractors, and the cost of materials, among other variables. Based on this analysis, any adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-26-000010:notes:27]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $2 million and $3 million as of December 31, 2025 and December 31, 2024, respectively.

[0000068505-26-000010:notes:28]
Business Combinations: The Company includes the results of operations from the businesses the Company acquires as of the acquisition date. The Company allocates the purchase price of the acquisition to the assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of identifiable assets and liabilities is recorded as goodwill. Acquisition related expenses are recognized separately from the business combination and are expensed as incurred.

[0000068505-26-000010:notes:29]
Investments: The Company generally invests in equity securities of a strategic nature.

[0000068505-26-000010:notes:30]
The Company applies the equity method of accounting for equity investments if the Company has significant influence over the issuing entity. The Company’s share of the investee’s underlying net income or loss is recorded to Other, net within Other income (expense).

[0000068505-26-000010:notes:31]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other, net within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded to Other, net within Other income (expense).

[0000068505-26-000010:notes:32]
Inventories: Inventories are valued at the lower of cost (which approximates cost on a first-in, first-out basis) and net realizable value.

[0000068505-26-000010:notes:33]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, one to twenty years; machinery and equipment, one to fifteen years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-26-000010:notes:34]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit level, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment as of the last day of the third quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and selling, general and administrative costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it is determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform a quantitative goodwill impairment test, which compares the fair value of the reporting unit to its carrying value. A quantitative assessment includes the assignment of assets and liabilities to each of the Company's reporting units and an assessment of the fair value of each of the Company's reporting units. The Company utilizes an income approach (discounted cash flows) to estimate the fair value of each reporting unit, which is corroborated by market multiples when available and as appropriate. Key assumptions in the quantitative analysis include revenue growth rates (including long-term growth rates for terminal value assumptions), operating margin estimates, discount rates, and where applicable, the comparable multiples from publicly traded companies in the Company's industry.

[0000068505-26-000010:notes:35]
If the carrying amount of a reporting unit exceeds its fair value, the Company would recognize an impairment loss in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0000068505-26-000010:notes:36]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.

[0000068505-26-000010:notes:37]
Leases: The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-26-000010:notes:38]
The Company determines if an arrangement is a lease at inception of the contract. The Company’s key considerations in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company’s contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the right to operate the asset at its discretion during the term of the contract.

[0000068505-26-000010:notes:39]
Right-of-use ("ROU") assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company’s lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in lease payments. For the Company’s leases consisting of land and other equipment (i.e. “communications network sites”), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage. ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-26-000010:notes:40]
As the majority of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company’s incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-26-000010:notes:41]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communications network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-26-000010:notes:42]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-26-000010:notes:43]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expenses and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-26-000010:notes:44]
Long-Term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. Long-term receivables are considered past due if payments have not been received according to the contractual terms of the note agreement, including principal and interest. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-26-000010:notes:45]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the Accrued liabilities statement line and the non-current portion is included in the Other liabilities statement line within the Company’s Consolidated Balance Sheet.

[0000068505-26-000010:notes:46]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have transactions denominated in local currency which differs from functional currency, transactions denominated in the local currency are measured in their functional currency using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-26-000010:notes:47]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-26-000010:notes:48]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-26-000010:notes:49]
Derivative Instruments: For Foreign exchange contracts, not designated as hedging instruments, gains and losses are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. For Equity swap contracts, which do not qualify for hedge accounting, gains and losses are recorded immediately in Selling, general and administrative expenses within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income. Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income at their initial value and amortized into Interest expense, net on a straight-line basis. Gains and losses pertaining to instruments designated as cash flow hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income.

[0000068505-26-000010:notes:50]
Fair Value Measurements: The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-26-000010:notes:51]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-26-000010:notes:52]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-26-000010:notes:53]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-26-000010:notes:54]
Earnings Per Share: The Company calculates its basic earnings per share-based on the weighted-average number of common shares issued and outstanding. Net earnings attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings per share. Diluted earnings per share is calculated by dividing net earnings attributable to Motorola Solutions, by the sum of the weighted-average number of common shares used in the basic earnings per share calculation and the weighted-average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings per share calculation. Both basic and diluted earnings per share amounts are calculated for net earnings attributable to Motorola Solutions for all periods presented.

[0000068505-26-000010:notes:55]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair value of stock options is generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk-free rate, dividend yield, and expected life. Performance-based stock options, performance stock units, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-26-000010:notes:56]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from eight to twenty-five years. Prior service costs are amortized over periods ranging from fourteen to twenty-four years. Benefits under all pension plans are valued based on the projected unit credit cost method. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-26-000010:notes:57]
The benefit obligation and plan assets for the Company's defined benefit plans are presented on a net basis according to the plans' net funded status and measured as of December 31, 2025.

[0000068505-26-000010:notes:58]
Recent Acquisitions:

[0000068505-26-000010:notes:59]
On November 18, 2025, the Company acquired Blue Eye, a provider of AI-powered enterprise remote video monitoring ("RVM") services for $79 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's video security portfolio, serving a wide range of enterprises with real-time intelligence to help reduce loss and damage, mitigate risk and boost profitability. This business is part of the Software and Services segment.

[0000068505-26-000010:notes:60]
On August 6, 2025, the Company acquired Silvus Technologies Holdings Inc. ("Silvus") from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired and customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million. Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be paid in shares of common stock. This business is part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-26-000010:notes:61]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $174 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services segment.

[0000068505-26-000010:notes:62]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $240 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. This business is part of the Software and Services segment.

[0000068505-26-000010:notes:63]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.

[0000068505-26-000010:notes:64]
On July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $92 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

[0000068505-26-000010:notes:65]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

[0000068505-26-000010:notes:66]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

[0000068505-26-000010:notes:67]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is a part of the Products and Systems Integration segment.

[0000068505-26-000010:notes:68]
Recent Accounting Pronouncements:

[0000068505-26-000010:notes:69]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software" to modernize the accounting for internal-use software costs. The ASU is effective for fiscal years beginning after December 15, 2027 and interim periods with annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-26-000010:notes:70]
In July 2025, the FASB issued ASU No. 2025-05, "Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets" to introduce a practical expedient in the estimation of expected credit losses for current accounts receivable and current contract assets. The ASU is effective for fiscal years beginning after December 15, 2025 and interim periods with annual reporting periods beginning after December 15, 2025, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-26-000010:notes:71]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods beginning in 2028, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-26-000010:notes:72]
Recently Adopted Accounting Pronouncements:

[0000068505-26-000010:notes:73]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company adopted ASU No. 2023-09 for the year ended December 31, 2025 and applied the retrospective transition method. Refer to "Note 7: Income Taxes" to our consolidated financial statements in this "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-26-000010:notes:74]
Revenue from Contracts with Customers
Disaggregation of Revenue

[0000068505-26-000010:notes:75]
Following the acquisition of Silvus Technologies Holdings Inc. (“Silvus”) in August 2025, we renamed our "Land Mobile Radio Communications" technology to MCN. We combined our legacy Land Mobile Radio portfolio with the newly acquired Silvus and now report net sales under MCN. This name change does not require any financial information to be reclassified from previous periods.

[0000068505-26-000010:notes:76]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the years ended December 31, 2025, 2024 and 2023, consistent with the information reviewed by our chief operating decision maker, the chief executive officer, for evaluating the financial performance of reportable segments:

[0000068505-26-000010:notes:77]
|  | Years Ended |
|  | 2025 |  | 2024 |  | 2023 |
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions |
| North America | $ | 5,318 |  |  | $ | 3,044 |  |  | $ | 8,362 |  |  | $ | 5,097 |  |  | $ | 2,723 |  |  | $ | 7,820 |  |  | $ | 4,507 |  |  | $ | 2,425 |  |  | $ | 6,932 |  |
| International | 1,935 |  |  | 1,385 |  |  | 3,320 |  |  | 1,786 |  |  | 1,211 |  |  | 2,997 |  |  | 1,735 |  |  | 1,311 |  |  | 3,046 |  |
|  | $ | 7,253 |  |  | $ | 4,429 |  |  | $ | 11,682 |  |  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |
| Major Products and Services |
| Mission Critical Networks (MCN) | $ | 6,066 |  |  | $ | 2,581 |  |  | $ | 8,647 |  |  | $ | 5,739 |  |  | $ | 2,361 |  |  | $ | 8,100 |  |  | $ | 5,127 |  |  | $ | 2,399 |  |  | $ | 7,526 |  |
| Video | 1,187 |  |  | 933 |  |  | 2,120 |  |  | 1,144 |  |  | 776 |  |  | 1,920 |  |  | 1,115 |  |  | 611 |  |  | 1,726 |  |
| Command Center | — |  |  | 915 |  |  | 915 |  |  | — |  |  | 797 |  |  | 797 |  |  | — |  |  | 726 |  |  | 726 |  |
|  | $ | 7,253 |  |  | $ | 4,429 |  |  | $ | 11,682 |  |  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |
| Customer Type |
| Direct | $ | 4,618 |  |  | $ | 4,037 |  |  | $ | 8,655 |  |  | $ | 4,238 |  |  | $ | 3,586 |  |  | $ | 7,824 |  |  | $ | 3,619 |  |  | $ | 3,396 |  |  | $ | 7,015 |  |
| Indirect | 2,635 |  |  | 392 |  |  | 3,027 |  |  | 2,645 |  |  | 348 |  |  | 2,993 |  |  | 2,623 |  |  | 340 |  |  | 2,963 |  |
|  | $ | 7,253 |  |  | $ | 4,429 |  |  | $ | 11,682 |  |  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |

[0000068505-26-000010:notes:78]
Remaining Performance Obligations

[0000068505-26-000010:notes:79]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. Remaining performance obligations are equal to disclosed backlog, except within our Software and Services contracts where multi-year contract terms may be limited by the customer's ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The transaction value associated with remaining performance obligations which were not yet satisfied as of December 31, 2025 was $9.6 billion, of which $4.0 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented and services are performed.

[0000068505-26-000010:notes:80]
Contract Balances

[0000068505-26-000010:notes:81]
| December 31 (in millions) | 2025 |  | 2024 |  | 2023 |  |  |  |  |
| Accounts receivable, net | $ | 2,200 |  |  | $ | 1,952 |  |  | $ | 1,710 |  |  |  |  |  |
| Contract assets | 1,574 |  |  | 1,230 |  |  | 1,102 |  |  |  |  |  |
| Contract liabilities | 2,265 |  |  | 2,072 |  |  | 2,037 |  |  |  |  |  |
| Non-current contract liabilities | 751 |  |  | 496 |  |  | 424 |  |  |  |  |  |

[0000068505-26-000010:notes:82]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a Contract asset or Contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-26-000010:notes:83]
The Company recognized revenue of $1.3 billion during the years ended December 31, 2025, 2024 and 2023 which was previously included in Contract liabilities as of January 1, 2025, 2024 and 2023. Revenue of $7 million was reversed during the year ended December 31, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $28 million reversed during the year ended December 31, 2024 and $37 million reversed during the year ended December 31, 2023.

[0000068505-26-000010:notes:84]
There have been no material expected credit losses recognized on contract assets during the year ended December 31, 2025.

[0000068505-26-000010:notes:85]
Contract Cost Balances

[0000068505-26-000010:notes:86]
| December 31 (in millions) | 2025 |  | 2024 |  | 2023 |  |  |  |  |
| Current contract cost assets | $ | 72 |  |  | $ | 70 |  |  | $ | 56 |  |  |  |  |  |
| Non-current contract cost assets | 152 |  |  | 141 |  |  | 119 |  |  |  |  |  |

[0000068505-26-000010:notes:87]
Contract cost assets include incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one year to eight years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $52 million for the year ended December 31, 2025, compared to $51 million as of the year ended December 31, 2024 and $61 million as of the year ended December 31, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-26-000010:notes:88]
Leases
The Company leases certain office, factory and warehouse space, land and other equipment under various operating leases.

[0000068505-26-000010:notes:89]
Components of Lease Expense

[0000068505-26-000010:notes:90]
| (in millions) | December 31, 2025 |  | December 31, 2024 | December 31, 2023 |
| Lease expense: |  |  |  |  |
| Operating lease cost | $ | 146 |  |  | $ | 140 |  | $ | 140 |  |
| Short-term lease cost | 2 |  |  | 1 |  | 1 |  |
| Variable cost | 47 |  |  | 47 |  | 36 |  |
| Sublease income | (6) |  |  | (5) |  | (5) |  |
| Net lease expense from operating leases | $ | 189 |  |  | $ | 183 |  | $ | 172 |  |

[0000068505-26-000010:notes:91]
Operating Lease Assets and Liabilities

[0000068505-26-000010:notes:92]
| (in millions) | Statement Line Classification |  | December 31, 2025 |  | December 31, 2024 |  |  |
| Right-of-use lease assets | Operating lease assets |  | $ | 581 |  |  | $ | 529 |  |  |  |
| Current lease liabilities | Accrued liabilities |  | 133 |  |  | 127 |  |  |  |
| Operating lease liabilities | Operating lease liabilities |  | 471 |  |  | 427 |  |  |  |

[0000068505-26-000010:notes:93]
Other Information Related to Leases

[0000068505-26-000010:notes:94]
| (in millions) | December 31, 2025 |  | December 31, 2024 |  | December 31, 2023 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 156 |  |  | $ | 152 |  |  | $ | 147 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | $ | 143 |  |  | $ | 150 |  |  | $ | 98 |  |  |  |

[0000068505-26-000010:notes:95]
During the year ended December 31, 2025, assets obtained in exchange for lease liabilities were primarily driven by new and renewed real estate leases. During the year ended December 31, 2024, the Company recorded $80 million of assets obtained in exchange for lease liabilities due to an assumption that it is reasonably certain that renewal options will be extended on its radio tower site leases operated within the Airwave radio network, consistent with the Home Office's notice of contract extension for the Airwave service through December 31, 2029. During the year ended December 31, 2023, the Company included $66 million of additional leases due to renewals of three large managed service contracts due to an assumption that it is reasonably certain that renewal options will be extended on the associated radio tower site leases.

[0000068505-26-000010:notes:96]
|  | December 31, 2025 |  | December 31, 2024 |  |  |
| Weighted average remaining lease terms (years) | 5 |  | 5 |  |  |
| Weighted average discount rate | 4.21 | % |  | 3.97 | % |  |  |

[0000068505-26-000010:notes:97]
Future Lease Payments

[0000068505-26-000010:notes:98]
| December 31 (in millions) | Amount |  |
| 2026 | $ | 155 |  |  |
| 2027 | 153 |  |  |
| 2028 | 125 |  |  |
| 2029 | 93 |  |  |
| 2030 | 43 |  |  |
| Thereafter | 107 |  |  |
| Total lease payments | $ | 676 |  |  |
| Less: Interest | 72 |  |  |
| Present value of operating lease liabilities | $ | 604 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-26-000010:notes:99]
Other Financial Data
Statement of Operations Information

[0000068505-26-000010:notes:100]
Other Charges (Income)

[0000068505-26-000010:notes:101]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-26-000010:notes:102]
| Years ended December 31 (in millions) | 2025 |  | 2024 |  | 2023 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 234 |  |  | $ | 152 |  |  | $ | 177 |  |
| Reorganization of businesses (Note 14) | 44 |  |  | 26 |  |  | 22 |  |
| Legal settlements | 15 |  |  | 7 |  |  | 4 |  |
| Fixed asset impairments | — |  |  | 2 |  |  | 3 |  |
| Environmental reserve expense | 2 |  |  | 2 |  |  | 15 |  |
| Exit of video manufacturing operations | — |  |  | — |  |  | 24 |  |
| Operating lease asset impairments | 2 |  |  | 6 |  |  | 6 |  |
| Acquisition-related transaction fees | 66 |  |  | 20 |  |  | 7 |  |
| Gain on Hytera litigation (Note 12) | (157) |  |  | (61) |  |  | — |  |
| Other | 1 |  |  | 1 |  |  | (1) |  |
|  | $ | 207 |  |  | $ | 155 |  |  | $ | 257 |  |

[0000068505-26-000010:notes:103]
During the years ended December 31, 2025 and 2024, the Company recognized gains on the Hytera litigation of $157 million and $61 million, respectively, for amounts recovered through legal proceedings due to theft of the Company's trade secrets. Refer to "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" to our consolidated financial statements in this "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further discussion regarding the Hytera litigation.

[0000068505-26-000010:notes:104]
During the year ended December 31, 2023, the Company entered into an arrangement to sell its video manufacturing operations in Richmond, British Columbia and Richardson, Texas, and recognized an impairment loss of $24 million within Other charges in the Consolidated Statements of Operations, as the carrying value of the asset group was below the expected selling price.

[0000068505-26-000010:notes:105]
Other Income (Expense)

[0000068505-26-000010:notes:106]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-26-000010:notes:107]
| Years ended December 31 (in millions) | 2025 |  | 2024 |  | 2023 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (360) |  |  | $ | (295) |  |  | $ | (249) |  |
| Interest income | 58 |  |  | 68 |  |  | 33 |  |
|  | $ | (302) |  |  | $ | (227) |  |  | $ | (216) |  |
| Other, net: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 124 |  |  | $ | 132 |  |  | $ | 99 |  |
| Loss from the extinguishment of long-term debt (Note 5) | — |  |  | (585) |  |  | — |  |
| Investment impairments | (4) |  |  | (3) |  |  | (16) |  |
| Foreign currency gain (loss) | (55) |  |  | 2 |  |  | (53) |  |
| Gain (loss) on derivative instruments (Note 6) | 42 |  |  | (19) |  |  | 20 |  |
| Fair value adjustments to equity investments | 19 |  |  | (5) |  |  | 13 |  |
| Assessments of uncertain tax positions (Note 7) | — |  |  | (11) |  |  | — |  |
| Other | — |  |  | — |  |  | 5 |  |
|  | $ | 126 |  |  | $ | (489) |  |  | $ | 68 |  |

[0000068505-26-000010:notes:108]
Earnings Per Common Share

[0000068505-26-000010:notes:109]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-26-000010:notes:110]
|  |  |  |  |  |  |  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  |  |  | Net Earnings |
| Years ended December 31 |  |  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 2,154 |  |  | $ | 1,577 |  |  | $ | 1,709 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 166.6 |  |  | 166.8 |  |  | 167.0 |  |
| Per share amount |  |  |  |  |  |  | $ | 12.93 |  |  | $ | 9.45 |  |  | $ | 10.23 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 2,154 |  |  | $ | 1,577 |  |  | $ | 1,709 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 166.6 |  |  | 166.8 |  |  | 167.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards |  |  |  |  |  |  | 2.4 |  |  | 4.0 |  |  | 3.7 |  |
| 1.75% senior convertible notes |  |  |  |  |  |  | — |  |  | — |  |  | 1.5 |  |
| Diluted weighted average common shares outstanding |  |  |  |  |  |  | 169.0 |  |  | 170.8 |  |  | 172.1 |  |
| Per share amount |  |  |  |  |  |  | $ | 12.75 |  |  | $ | 9.23 |  |  | $ | 9.93 |  |

[0000068505-26-000010:notes:111]
In the computation of diluted earnings per common share for the year ended December 31, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2024, the assumed exercise of 0.1 million options were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2023, the assumed exercise of 0.1 million options and 0.2 million awards subject to performance conditions were excluded because their inclusion would have been antidilutive.

[0000068505-26-000010:notes:112]
In connection with the acquisition of Silvus, the Seller will have the potential to earn contingent earnout consideration upon the achievement of certain financial targets payable in shares of common stock of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The estimated fair value of the total contingent earnout consideration was $37 million as of December 31, 2025. The shares required to settle the contingent earnout consideration will only be reflected within diluted earnings per share when and if the earnout financial targets have been achieved, in each of the two respective periods.

[0000068505-26-000010:notes:113]
In 2023, the Company had $1.0 billion of 1.75% senior convertible notes outstanding (the “Silver Lake Convertible Debt”). The notes were convertible based on a rate of 4.9670 per $1,000 principal amount as of December 31, 2023 (equal to a conversion price of $201.33 per share), adjusted for dividends declared through the date of settlement. In 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the Silver Lake Convertible Debt to be in cash. Because the Company irrevocably decided to settle the principal amount of the Silver Lake Convertible Debt in cash, the Company did not reflect any shares underlying the Silver Lake Convertible Debt in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price. For the years ended December 31, 2023, the Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price. In 2024, the Company repurchased the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium, recognizing a loss on the extinguishment of $585 million. Accordingly, in the computation of diluted earnings per common share for the year ended December 31, 2024, a total of 0.2 million shares related to the Silver Lake Convertible Debt were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. Refer to "Note 5: Debt and Credit Facilities" to our consolidated financial statements in this "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for more information regarding the repurchase.

[0000068505-26-000010:notes:114]
Balance Sheet Information

[0000068505-26-000010:notes:115]
Accounts Receivable, Net

[0000068505-26-000010:notes:116]
Accounts receivable, net, consists of the following:

[0000068505-26-000010:notes:117]
| December 31 | 2025 |  | 2024 |
| Accounts receivable | $ | 2,283 |  |  | $ | 2,035 |  |
| Less allowance for credit losses | (83) |  |  | (83) |  |
|  | $ | 2,200 |  |  | $ | 1,952 |  |

[0000068505-26-000010:notes:118]
Inventories, Net

[0000068505-26-000010:notes:119]
Inventories, net, consist of the following:

[0000068505-26-000010:notes:120]
| December 31 | 2025 |  | 2024 |
| Finished goods | $ | 455 |  |  | $ | 396 |  |
| Work-in-process and production materials | 644 |  |  | 498 |  |
|  | 1,099 |  |  | 894 |  |
| Less inventory reserves | (116) |  |  | (128) |  |
|  | $ | 983 |  |  | $ | 766 |  |

[0000068505-26-000010:notes:121]
Other Current Assets

[0000068505-26-000010:notes:122]
Other current assets consist of the following:

[0000068505-26-000010:notes:123]
| December 31 | 2025 |  | 2024 |
| Current contract cost assets (Note 2) | $ | 72 |  |  | $ | 70 |  |
| Contractor receivables | 19 |  |  | 44 |  |
| Tax-related deposits (Note 7) | 41 |  |  | 54 |  |
| Other | 246 |  |  | 261 |  |
|  | $ | 378 |  |  | $ | 429 |  |

[0000068505-26-000010:notes:124]
Property, Plant and Equipment, Net

[0000068505-26-000010:notes:125]
Property, plant and equipment, net, consist of the following:

[0000068505-26-000010:notes:126]
| December 31 | 2025 |  | 2024 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 479 |  |  | 441 |  |
| Machinery and equipment | 2,655 |  |  | 2,243 |  |
|  | 3,139 |  |  | 2,689 |  |
| Less accumulated depreciation | (1,974) |  |  | (1,667) |  |
|  | $ | 1,165 |  |  | $ | 1,022 |  |

[0000068505-26-000010:notes:127]
Depreciation expense for the years ended December 31, 2025, 2024, and 2023 was $191 million, $184 million and $179 million, respectively.

[0000068505-26-000010:notes:128]
Investments

[0000068505-26-000010:notes:129]
Investments consist of the following:

[0000068505-26-000010:notes:130]
| December 31 | 2025 |  | 2024 |  |  |  |  |
| Common stock | $ | 42 |  |  | $ | 23 |  |  |  |  |  |
| Strategic investments, at cost | 54 |  |  | 26 |  |  |  |  |  |
| Company-owned life insurance policies | 83 |  |  | 75 |  |  |  |  |  |
| Equity method investments | 8 |  |  | 11 |  |  |  |  |  |
|  | $ | 187 |  |  | $ | 135 |  |  |  |  |  |

[0000068505-26-000010:notes:131]
Other Assets

[0000068505-26-000010:notes:132]
Other assets consist of the following:

[0000068505-26-000010:notes:133]
| December 31 | 2025 |  | 2024 |
| Defined benefit plan assets (Note 8) | $ | 228 |  |  | $ | 162 |  |
| Non-current contract cost assets (Note 2) | 152 |  |  | 141 |  |
| Non-current long-term receivables (Note 11) | 59 |  |  | 41 |  |
| Other | 52 |  |  | 31 |  |
|  | $ | 491 |  |  | $ | 375 |  |

[0000068505-26-000010:notes:134]
Accounts Payable

[0000068505-26-000010:notes:135]
The Company utilizes a supplier finance program that provides suppliers with the ability to accelerate payment on the Company's invoices beyond the stated payment terms. Under the terms of this program, the Company agrees to pay an intermediary the stated amount of confirmed invoices on the stated maturity dates of the invoices, and the supplier is able to negotiate earlier payment terms with the intermediary. The Company or the intermediary may terminate the agreement at any time upon 60 days' notice. The Company does not provide any forms of guarantees under this arrangement. Supplier participation in the program is solely at the supplier's discretion, and the participating suppliers negotiate their arrangements directly with the intermediary. The Company has no economic interest in a supplier's decision to participate in the program, and their participation has no bearing on our payment terms or amounts due. The stated invoice payment terms range from 75 to 120 days from the invoice date and are considered commercially reasonable.

[0000068505-26-000010:notes:136]
The Company's outstanding amounts related to the suppliers participating in this program was $34 million and $38 million as of December 31, 2025 and December 31, 2024, respectively. Supplier finance program obligations are classified as Accounts payable within the Consolidated Balance Sheets. The following table displays a rollforward of the confirmed amount of supplier finance obligations from January 1, 2024 to December 31, 2025:

[0000068505-26-000010:notes:137]
| (in millions) | 2025 |  | 2024 |
| Confirmed obligations at the beginning of the year | $ | 38 |  |  | $ | 35 |  |
| Invoices confirmed during the year | 137 |  |  | 139 |  |
| Confirmed invoices paid during the year | (141) |  |  | (136) |  |
| Confirmed obligations outstanding at the end of the year | $ | 34 |  |  | $ | 38 |  |

[0000068505-26-000010:notes:138]
Accrued Liabilities

[0000068505-26-000010:notes:139]
Accrued liabilities consist of the following:

[0000068505-26-000010:notes:140]
| December 31 | 2025 |  | 2024 |
| Compensation | $ | 479 |  |  | $ | 406 |  |
| Tax liabilities (Note 7) | 225 |  |  | 217 |  |
| Dividend payable | 201 |  |  | 182 |  |
| Trade liabilities | 194 |  |  | 160 |  |
| Operating lease liabilities (Note 3) | 133 |  |  | 127 |  |
| Customer reserves | 125 |  |  | 97 |  |
| External interest liabilities | 113 |  |  | 52 |  |
| Other | 460 |  |  | 402 |  |
|  | $ | 1,930 |  |  | $ | 1,643 |  |

[0000068505-26-000010:notes:141]
Other Liabilities

[0000068505-26-000010:notes:142]
Other liabilities consist of the following:

[0000068505-26-000010:notes:143]
| December 31 | 2025 |  | 2024 |
| Defined benefit plans (Note 8) | $ | 683 |  |  | $ | 768 |  |
| Non-current contract liabilities (Note 2) | 751 |  |  | 496 |  |
| Unrecognized tax benefits (Note 7) | 41 |  |  | 39 |  |
| Deferred income taxes (Note 7) | 124 |  |  | 87 |  |
| Environmental Reserve | 119 |  |  | 119 |  |
| Deferred compensation | 111 |  |  | 89 |  |
| Other | 171 |  |  | 121 |  |
|  | $ | 2,000 |  |  | $ | 1,719 |  |

[0000068505-26-000010:notes:144]
Stockholders’ Equity Information

[0000068505-26-000010:notes:145]
Share Repurchase Program: Through a series of actions, the Board of Directors has authorized the Company to repurchase in the aggregate up to $18.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2025, the Company had used approximately $16.9 billion of the share repurchase authority to repurchase shares, leaving approximately $1.1 billion of authority available for future repurchases. During the year ended December 31, 2024, the Company paid $3 million of 1% excise tax pursuant to the Inflation Reduction Act of 2022, related to its 2023 share repurchases in excess of issuances.

[0000068505-26-000010:notes:146]
The Company's share repurchases for 2025, 2024, and 2023 can be summarized as follows:

[0000068505-26-000010:notes:147]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2025 | 2.7 |  |  | $ | 420.21 |  |  | $ | 1,154 |  |
| 2024 | 0.6 |  |  | 396.69 |  |  | 244 |  |
| 2023 | 2.9 |  |  | 278.56 |  |  | 804 |  |

[0000068505-26-000010:notes:148]
Payment of Dividends: On November 18, 2025, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $1.09 per share of common stock to $1.21 per share of common stock. During the years ended December 31, 2025, 2024, and 2023 the Company paid $728 million, $654 million, and $589 million, respectively, in cash dividends to holders of its common stock. On January 15, 2026, the Company paid an additional $201 million in cash dividends to holders of its common stock.

[0000068505-26-000010:notes:149]
Accumulated Other Comprehensive Loss

[0000068505-26-000010:notes:150]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2025, 2024, and 2023:

[0000068505-26-000010:notes:151]
|  | Years ended December 31 |
|  | 2025 |  | 2024 |  | 2023 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (546) |  |  | $ | (482) |  |  | $ | (539) |  |
| Other comprehensive income (loss) before reclassification adjustment | 103 |  |  | (64) |  |  | 64 |  |
| Reclassification adjustment into Net earnings | (6) |  |  | (2) |  |  | (3) |  |
| Tax benefit (expense) | 4 |  |  | 2 |  |  | (4) |  |
| Other comprehensive income (loss), net of tax | 101 |  |  | (64) |  |  | 57 |  |
| Balance at end of period | $ | (445) |  |  | $ | (546) |  |  | $ | (482) |  |
| Derivative instruments: |  |  |  |  |  |
| Balance at beginning of period | $ | (7) |  |  | $ | (12) |  |  | $ | — |  |
| Other comprehensive income (loss) before reclassification adjustment | — |  |  | 4 |  |  | (12) |  |
| Reclassification adjustment into Interest expense, net | 1 |  |  | 1 |  |  | — |  |
| Other comprehensive income (loss), net of tax | 1 |  |  | 5 |  |  | (12) |  |
| Balance at end of period | $ | (6) |  |  | $ | (7) |  |  | $ | (12) |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (1,986) |  |  | $ | (2,046) |  |  | $ | (1,996) |  |
| Other comprehensive income (loss) before reclassification adjustment | (13) |  |  | 44 |  |  | (130) |  |
| Tax benefit (expense) | 3 |  |  | (9) |  |  | 34 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (10) |  |  | 35 |  |  | (96) |  |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 37 |  |  | 34 |  |  | 61 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | — |  |  | — |  |  | 1 |  |
| Tax expense | (10) |  |  | (9) |  |  | (16) |  |
| Reclassification adjustments into Net earnings, net of tax | 27 |  |  | 25 |  |  | 46 |  |
| Other comprehensive income (loss), net of tax | 17 |  |  | 60 |  |  | (50) |  |
| Balance at end of period | $ | (1,969) |  |  | $ | (1,986) |  |  | $ | (2,046) |  |
| Total Accumulated other comprehensive loss | $ | (2,420) |  |  | $ | (2,539) |  |  | $ | (2,540) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-26-000010:notes:152]
Debt and Credit Facilities
Debt

[0000068505-26-000010:notes:153]
| December 31 | 2025 |  | 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | — |  |  | 70 |  |
| 364 day term loan | 749 |  |  | — |  |
| 4.6% senior notes due 2028 | 698 |  |  | 696 |  |
| Term loan due 2028 | 748 |  |  | — |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 847 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 597 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 9,163 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (749) |  |  | (322) |  |
| Long-term debt | $ | 8,413 |  |  | $ | 5,675 |  |

[0000068505-26-000010:notes:154]
During the year ended December 31, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% debentures due 2025 and $70 million aggregate principal amount of the 6.5% debentures due 2025. Furthermore, during the year ended December 31, 2025 the Company borrowed and repaid $179 million of short-term borrowings, including commercial paper which had a weighted-average interest rate of 4.29%.

[0000068505-26-000010:notes:155]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032 and $900 million of 5.55% senior notes due 2035. The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-26-000010:notes:156]
On August 6, 2025, the Company borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. The Company was in compliance with its financial covenants as of December 31, 2025. During the year ended December 31, 2025, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 5.10% and 5.25%, respectively. As of December 31, 2025, $749 million of the 364-day term loan was presented as short-term borrowings within the Company's Consolidated Balance Sheets. Subsequent to year-end, on January 30, 2026, the Company repaid $200 million of the $750 million 364-day term loan, reducing the outstanding principal balance to $550 million.

[0000068505-26-000010:notes:157]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue the Silver Lake Convertible Debt, which became fully convertible on September 5, 2021. In 2024, the Company repurchased the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Consolidated Statements of Operations during the year ended December 31, 2024.

[0000068505-26-000010:notes:158]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement (defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the commercial paper notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2025 the Company had no outstanding debt under the commercial paper program.

[0000068505-26-000010:notes:159]
Aggregate requirements for debt maturities during the next five years are as follows: $750 million in 2026, no maturities in 2027, $1.5 billion in 2028, $1.2 billion in 2029 and $1.5 billion in 2030.

[0000068505-26-000010:notes:160]
Credit Facilities
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement which was scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2025.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-26-000010:notes:161]
Risk Management
Foreign Currency Risk

[0000068505-26-000010:notes:162]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.6 billion and $1.0 billion at December 31, 2025 and December 31, 2024, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-26-000010:notes:163]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2025 and the corresponding positions as of December 31, 2024:

[0000068505-26-000010:notes:164]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2025 |  | 2024 |
| British pound | $ | 301 |  |  | $ | 124 |  |
| Euro | 191 |  |  | 150 |  |
| Australian dollar | (160) |  |  | (136) |  |
| Canadian dollar | 115 |  |  | 70 |  |
| Danish krone | 58 |  |  | 23 |  |

[0000068505-26-000010:notes:165]
Counterparty Risk

[0000068505-26-000010:notes:166]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2025, all of the counterparties had investment grade credit ratings. As of December 31, 2025, the credit risk with all derivative counterparties was approximately $10 million.

[0000068505-26-000010:notes:167]
Derivative Financial Instruments

[0000068505-26-000010:notes:168]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2025 and 2024:

[0000068505-26-000010:notes:169]
|  | Fair Values of Derivative Instruments |
| December 31, 2025 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 19 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 10 |  |  | $ | — |  |
| Total derivatives | $ | 10 |  |  | $ | 19 |  |

[0000068505-26-000010:notes:170]
|  | Fair Values of Derivative Instruments |
| December 31, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 7 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | $ | 9 |  |
| Equity swap contracts | — |  |  | 1 |  |
| Total derivatives | $ | 10 |  |  | $ | 10 |  |

[0000068505-26-000010:notes:171]
The following table summarizes the effect of derivatives on the Company's consolidated financial statements for the years ended December 31, 2025, 2024 and 2023:

[0000068505-26-000010:notes:172]
|  | Financial Statement Location |  |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated other comprehensive income (loss) | $ | (24) |  |  | $ | 9 |  |  | $ | (4) |  |
| Amortized hedge income | Other income (expense) | 6 |  |  | 2 |  |  | 3 |  |
| Treasury rate lock settlement | Accumulated other comprehensive income (loss) | — |  |  | 4 |  |  | (12) |  |
| Amortization of treasury rate lock | Other income (expense) | (1) |  |  | (1) |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | 42 |  |  | $ | (19) |  |  | $ | 20 |  |
| Equity swap contracts | Selling, general and administrative expenses | 2 |  |  | 3 |  |  | 1 |  |

[0000068505-26-000010:notes:173]
Net Investment Hedges

[0000068505-26-000010:notes:174]
The Company uses foreign exchange forward option contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of December 31, 2025, the Company had €160 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-26-000010:notes:175]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the forward points recognized is amortized on a straight line basis and recognized through interest expense within Other income (expense) in the Consolidated Statement of Operations.

[0000068505-26-000010:notes:176]
Equity Swap Contracts

[0000068505-26-000010:notes:177]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Consolidated Statements of Operations. The notional amount of these contracts as of December 31, 2025 was $22 million.

[0000068505-26-000010:notes:178]
Treasury Rate Lock
In 2023, the Company entered into treasury rate lock agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the year ended December 31, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated Other Comprehensive Income (AOCI) will be reclassified to Interest expense, net on a straight-line basis over the 10-year term of the 2034 notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-26-000010:notes:179]
Income Taxes
The Company adopted ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures" under the retrospective transition method for the year ended December 31, 2025; as a result, amounts disclosed throughout this footnote have been revised for the years ended December 31, 2024 and December 31, 2023.

[0000068505-26-000010:notes:180]
Components of Income Tax Expense

[0000068505-26-000010:notes:181]
Components of earnings before income taxes are as follows:

[0000068505-26-000010:notes:182]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| United States | $ | 2,130 |  |  | $ | 1,741 |  |  | $ | 1,791 |  |
| Foreign | 682 |  |  | 231 |  |  | 355 |  |
|  | $ | 2,812 |  |  | $ | 1,972 |  |  | $ | 2,146 |  |

[0000068505-26-000010:notes:183]
Components of income tax expenses are as follows:

[0000068505-26-000010:notes:184]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| Current income tax expense |  |
| United States Federal | $ | 259 |  |  | $ | 410 |  |  | $ | 253 |  |
| Foreign | 183 |  |  | 62 |  |  | 141 |  |
| States (U.S.) | 116 |  |  | 133 |  |  | 70 |  |
| Total current income tax expense | $ | 558 |  |  | $ | 605 |  |  | $ | 464 |  |
| Deferred income tax expense (benefit) |  |
| United States Federal | $ | 101 |  |  | $ | (207) |  |  | $ | (24) |  |
| Foreign | 7 |  |  | 23 |  |  | (17) |  |
| States (U.S.) | (14) |  |  | (31) |  |  | 9 |  |
| Total deferred income tax expense (benefit) | $ | 94 |  |  | $ | (215) |  |  | $ | (32) |  |
| Total income tax expense | $ | 652 |  |  | $ | 390 |  |  | $ | 432 |  |

[0000068505-26-000010:notes:185]
Differences between income tax expense computed at the U.S. federal statutory tax rate of 21% and income tax expense as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-26-000010:notes:186]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| U.S. Federal Statutory Tax Rate | $ | 591 |  | 21.0 | % |  | $ | 414 |  | 21.0 | % |  | $ | 450 |  | 21.0 | % |
| State and Local Income Taxes, Net of Federal Income tax effect (1) | 80 |  | 2.8 | % |  | 81 |  | 4.1 | % |  | 62 |  | 2.9 | % |
| Foreign Tax Effects |  |  |  |  |  |  |  |  |
| Other foreign jurisdictions | 40 |  | 1.4 | % |  | 24 |  | 1.2 | % |  | 40 |  | 1.9 | % |
| Effect of Cross-Border Tax Laws |  |  |  |  |  |  |  |  |
| Foreign-derived intangible income | (14) |  | (0.5) | % |  | (99) |  | (5.0) | % |  | (38) |  | (1.8) | % |
| Other | 6 |  | 0.2 | % |  | (1) |  | (0.1) | % |  | 7 |  | 0.3 | % |
| Tax Credits |  |  |  |  |  |  |  |  |
| Foreign tax credit | (24) |  | (0.8) | % |  | (113) |  | (5.7) | % |  | (26) |  | (1.2) | % |
| Research & development credit | (17) |  | (0.6) | % |  | (22) |  | (1.1) | % |  | (19) |  | (0.9) | % |
| Changes in Valuation Allowances | — |  | — | % |  | 2 |  | 0.1 | % |  | (16) |  | (0.7) | % |
| Nontaxable or Nondeductible Items |  |  |  |  |  |  |  |  |
| Excess tax benefits on share-based payments | (38) |  | (1.4) | % |  | (35) |  | (1.8) | % |  | (29) |  | (1.4) | % |
| Extinguishment of Silver Lake convertible debt | — |  | — | % |  | 124 |  | 6.3 | % |  | — |  | — | % |
| Other | 24 |  | 0.8 | % |  | 17 |  | 0.8 | % |  | 5 |  | 0.2 | % |
| Changes in Unrecognized Tax Benefits | 3 |  | 0.1 | % |  | (6) |  | (0.3) | % |  | (3) |  | (0.1) | % |
| Other Adjustments | 1 |  | — | % |  | 4 |  | 0.2 | % |  | (1) |  | (0.1) | % |
| Effective Tax Rate | $ | 652 |  | 23.2 | % |  | $ | 390 |  | 19.8 | % |  | $ | 432 |  | 20.1 | % |
| (1) The States that contribute to the majority (greater than 50%) of the tax effect in this category include Illinois, California, New York, Florida, New Jersey, and Pennsylvania for all years, as well as Virginia for 2025.*Percentages may not add due to rounding. |

[0000068505-26-000010:notes:187]
The effective tax rate for 2025 was higher than the current U.S. federal statutory rate of 21% primarily due to 2025 estimated U.S. state income taxes, partially offset by the recognition of excess tax benefits on share-based compensation.

[0000068505-26-000010:notes:188]
In 2021, the Organization of Economic Cooperation and Development ("OECD") introduced its Pillar Two Framework Model Rules ("Pillar 2"), that was supported by over 130 countries worldwide, which is designed to impose a 15% global minimum tax on adjusted financial results. The Company continues to monitor developments in the Pillar 2 framework, including the recent release of the Side-by-Side Package by the OECD, and to assess the potential impact of Pillar 2 on its business as the countries in which it operates continue to enact legislation implementing Pillar 2. Pillar 2 did not materially impact the Company's 2025 tax liability.

[0000068505-26-000010:notes:189]
Cash payments for income and withholding taxes (net of refunds) are as follows:

[0000068505-26-000010:notes:190]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| United States Federal | $ | 349 |  |  | $ | 431 |  |  | $ | 335 |  |
| States (U.S.) | 109 |  |  | 130 |  |  | 92 |  |
| Foreign: |  |  |  |  |  |
| Canada* | * |  | * |  | 83 |  |
| Other | 111 |  |  | 66 |  |  | 77 |  |
| Total | $ | 569 |  |  | $ | 627 |  |  | $ | 587 |  |
| *The amount of income taxes paid during the year does not meet the 5% disaggregation threshold. |

[0000068505-26-000010:notes:191]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are the result of retirement benefit adjustments and currency translation adjustments. The adjustments were charges of $3 million for the year ended December 31, 2025, charges of $16 million for the year ended December 31, 2024, and benefits of $14 million for the year ended December 31, 2023.

[0000068505-26-000010:notes:192]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the 2017 U.S. Tax Cuts and Jobs Act ("the Tax Act"), dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-26-000010:notes:193]
Undistributed foreign earnings of certain foreign subsidiaries continue to be indefinitely reinvested outside the U.S. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-26-000010:notes:194]
Gross deferred tax assets were $2.5 billion and $2.4 billion for December 31, 2025 and December 31, 2024, respectively. Deferred tax assets, net of valuation allowances, were $2.4 billion at both December 31, 2025 and December 31, 2024. Gross deferred tax liabilities were $1.8 billion and $1.2 billion at December 31, 2025 and December 31, 2024, respectively.

[0000068505-26-000010:notes:195]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-26-000010:notes:196]
| December 31 | 2025 |  | 2024 |
| Inventory | $ | 30 |  |  | $ | 30 |  |
| Accrued liabilities and allowances | 105 |  |  | 87 |  |
| Employee benefits | 212 |  |  | 221 |  |
| Capitalized items | (237) |  |  | 391 |  |
| Tax basis differences on investments | 5 |  |  | 2 |  |
| Depreciation tax basis differences on fixed assets | (62) |  |  | (31) |  |
| Undistributed non-U.S. earnings | (28) |  |  | (23) |  |
| Tax attribute carryforwards | 152 |  |  | 98 |  |
| Business reorganization | 6 |  |  | 7 |  |
| Warranty and customer liabilities | 28 |  |  | 24 |  |
| Deferred revenue and costs | 457 |  |  | 420 |  |
| Valuation allowances | (59) |  |  | (62) |  |
| Operating lease assets | (142) |  |  | (128) |  |
| Operating lease liabilities | 147 |  |  | 134 |  |
| Other | 23 |  |  | 24 |  |
|  | $ | 637 |  |  | $ | 1,194 |  |

[0000068505-26-000010:notes:197]
At December 31, 2025 and December 31, 2024, the Company had valuation allowances of $59 million and $62 million, respectively, against its deferred tax assets, including $40 million and $42 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance decreased $1 million during 2025 primarily due to the utilization and expiration of state tax attributes. The Company's Non-U.S. valuation allowance decreased $2 million during 2025 primarily due to the expiration of tax attributes. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-26-000010:notes:198]
Tax attribute carryforwards are as follows:

[0000068505-26-000010:notes:199]
| December 31, 2025 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 245 |  |  | $ | 52 |  |  | 2026-2038 |
| Foreign tax credits | — |  |  | 6 |  |  | 2028-2035 |
| General business credits | — |  |  | 1 |  |  | 2030-2036 |
| Minimum tax credits | — |  |  | 25 |  |  | Unlimited |
| State tax losses | — |  |  | 10 |  |  | 2028-2045 |
| State tax credits | — |  |  | 3 |  |  | 2026-2039 |
| Non-U.S. subsidiaries: |  |  |  |  |  |
| United Kingdom tax losses | 152 |  |  | 38 |  |  | Unlimited |
| Canada tax losses | 17 |  |  | 5 |  |  | 2035-2045 |
| Canada tax credits | — |  |  | 3 |  |  | 2042-2045 |
| Other subsidiaries tax losses | 47 |  |  | 9 |  |  | Various |
|  | $ | 461 |  |  | $ | 152 |  |  |  |

[0000068505-26-000010:notes:200]
The Company had unrecognized tax benefits of $44 million and $42 million at December 31, 2025 and December 31, 2024, respectively, of which approximately $42 million and $40 million, if recognized, would have affected the effective tax rate for 2025 and 2024, respectively.

[0000068505-26-000010:notes:201]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-26-000010:notes:202]
| (in millions) | 2025 |  | 2024 |
| Balance at January 1 | $ | 42 |  |  | $ | 32 |  |
| Additions based on tax positions related to current year | 2 |  |  | 1 |  |
| Additions for tax positions of prior years | 3 |  |  | 18 |  |
| Reductions for tax positions of prior years | (1) |  |  | (1) |  |
| Settlements and agreements | (1) |  |  | (5) |  |
| Lapse of statute of limitations | (1) |  |  | (3) |  |
| Balance at December 31 | $ | 44 |  |  | $ | 42 |  |

[0000068505-26-000010:notes:203]
The Company recorded $41 million and $39 million of unrecognized tax benefits in Other liabilities at December 31, 2025 and December 31, 2024, respectively.

[0000068505-26-000010:notes:204]
The Company has several U.S. federal, U.S. state, and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-26-000010:notes:205]
| Jurisdiction | Tax Years |
| United States | 2021-2025 |
| Australia | 2021-2025 |
| Canada | 2021-2025 |
| Germany | 2018-2025 |
| India | 1997-2025 |
| Ireland | 2021-2025 |
| Israel | 2023-2025 |
| Poland | 2020-2025 |
| Malaysia | 2018-2025 |
| United Kingdom | 2023-2025 |

[0000068505-26-000010:notes:206]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-26-000010:notes:207]
At December 31, 2025, the Company had $32 million accrued for interest and $23 million accrued for penalties on unrecognized tax benefits. At December 31, 2024, the Company had $30 million and $23 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-26-000010:notes:208]
Retirement Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-26-000010:notes:209]
U.S. Pension Benefit Plans

[0000068505-26-000010:notes:210]
The Company’s non-contributory U.S. defined benefit plans (the "U.S. Pension Plans") provide benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. In December 2008, the Company amended the U.S. Pension Plans and MSPP (together the "U.S. Pension Benefit Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-26-000010:notes:211]
Postretirement Health Care Benefits Plan

[0000068505-26-000010:notes:212]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment or retirement eligibility (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of amendments, all eligible retirees under the age of 65 are provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-26-000010:notes:213]
Non-U.S. Pension Benefit Plans

[0000068505-26-000010:notes:214]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-26-000010:notes:215]
In June 2015, the Company amended its non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-26-000010:notes:216]
Net Periodic Cost (Benefit)

[0000068505-26-000010:notes:217]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-26-000010:notes:218]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 201 |  |  | 189 |  |  | 190 |  |  | 58 |  |  | 57 |  |  | 56 |  |  | 5 |  |  | 4 |  |  | 5 |  |
| Expected return on plan assets | (305) |  |  | (298) |  |  | (293) |  |  | (108) |  |  | (104) |  |  | (108) |  |  | (13) |  |  | (13) |  |  | (13) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 25 |  |  | 25 |  |  | 22 |  |  | 7 |  |  | 6 |  |  | 37 |  |  | 5 |  |  | 3 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (3) |  |  | (3) |  |  | (2) |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Net periodic cost (benefit) | $ | (79) |  |  | $ | (84) |  |  | $ | (81) |  |  | $ | (45) |  |  | $ | (43) |  |  | $ | (16) |  |  | $ | — |  |  | $ | (3) |  |  | $ | (3) |  |

[0000068505-26-000010:notes:219]
The status of the Company’s plans is as follows:

[0000068505-26-000010:notes:220]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 3,755 |  |  | $ | 3,928 |  |  | $ | 1,163 |  |  | $ | 1,347 |  |  | $ | 105 |  |  | $ | 96 |  |
| Service cost | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Interest cost | 201 |  |  | 189 |  |  | 58 |  |  | 57 |  |  | 5 |  |  | 4 |  |
| Actuarial loss (gain) | 76 |  |  | (220) |  |  | (51) |  |  | (156) |  |  | (4) |  |  | 17 |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 100 |  |  | (32) |  |  | — |  |  | — |  |
| Benefit payments | (167) |  |  | (142) |  |  | (60) |  |  | (54) |  |  | (11) |  |  | (12) |  |
| Benefit obligation at December 31 | $ | 3,865 |  |  | $ | 3,755 |  |  | $ | 1,211 |  |  | $ | 1,163 |  |  | $ | 95 |  |  | $ | 105 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,249 |  |  | $ | 3,273 |  |  | $ | 1,083 |  |  | $ | 1,172 |  |  | $ | 128 |  |  | $ | 134 |  |
| Return on plan assets | 360 |  |  | 112 |  |  | 54 |  |  | (23) |  |  | 15 |  |  | 6 |  |
| Company contributions | 7 |  |  | 6 |  |  | 11 |  |  | 9 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | 84 |  |  | (21) |  |  | — |  |  | — |  |
| Benefit payments | (167) |  |  | (142) |  |  | (60) |  |  | (54) |  |  | (11) |  |  | (12) |  |
| Fair value at December 31 | $ | 3,449 |  |  | $ | 3,249 |  |  | $ | 1,172 |  |  | $ | 1,083 |  |  | $ | 132 |  |  | $ | 128 |  |
| Funded status of the plan | $ | (416) |  |  | $ | (506) |  |  | $ | (39) |  |  | $ | (80) |  |  | $ | 37 |  |  | $ | 23 |  |
| Unrecognized net loss | 1,631 |  |  | 1,635 |  |  | 790 |  |  | 796 |  |  | 76 |  |  | 88 |  |
| Unrecognized prior service benefit (cost) | — |  |  | — |  |  | (61) |  |  | (64) |  |  | 38 |  |  | 41 |  |
| Prepaid pension cost | $ | 1,215 |  |  | $ | 1,129 |  |  | $ | 690 |  |  | $ | 652 |  |  | $ | 151 |  |  | $ | 152 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (2) |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (414) |  |  | (503) |  |  | (196) |  |  | (194) |  |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 157 |  |  | 114 |  |  | 37 |  |  | 23 |  |
| Deferred income taxes | 388 |  |  | 388 |  |  | 94 |  |  | 95 |  |  | 31 |  |  | 35 |  |
| Accumulated other comprehensive loss | 1,243 |  |  | 1,247 |  |  | 635 |  |  | 637 |  |  | 83 |  |  | 94 |  |
| Prepaid pension cost | $ | 1,215 |  |  | $ | 1,129 |  |  | $ | 690 |  |  | $ | 652 |  |  | $ | 151 |  |  | $ | 152 |  |

[0000068505-26-000010:notes:221]
For the year ended December 31, 2025, the primary driver of the increase in the U.S. Pension Benefit Plans' benefit obligation was higher actuarial losses due to a decrease in the discount rate from 5.70% as of December 31, 2024 to 5.50% as of December 31, 2025, partially offset by actuarial gains in the benefit obligation due to updated lump-sum interest rates. For the year ended December 31, 2024, the primary driver of the decrease in the U.S. Pension Benefit Plans' benefit obligation was higher actuarial gains due to an increase in the discount rate from 5.01% as of December 31, 2023 to 5.70% as of December 31, 2024, partially offset by actuarial losses in the benefit obligation due to updated lump-sum interest rates and updated demographic assumption changes.

[0000068505-26-000010:notes:222]
For the year ended December 31, 2025, the most significant driver of the increase in Non-U.S. Pension Benefit Plans' benefit obligation was the unfavorable foreign exchange rate effects, partially offset by lower actuarial gains. The Non-U.S. Pension Benefit Plans incurred actuarial gains primarily due to an increase in the discount rate from 5.07% as of December 31, 2024 to 5.25% as of December 31, 2025. For the year ended December 31, 2024, the most significant drivers of the decrease in Non-U.S. Pension Benefit Plans' benefit obligation were the higher actuarial gains coupled with favorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial gains primarily due to an increase in the discount rate from 4.30% as of December 31, 2023 to 5.07% as of December 31, 2024.

[0000068505-26-000010:notes:223]
Actuarial Assumptions

[0000068505-26-000010:notes:224]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-26-000010:notes:225]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-26-000010:notes:226]
The Company used "Mortality Improvement Scale MP-2021" to calculate both the 2025 U.S. projected benefit obligations and the 2024 U.S. projected benefit obligations.

[0000068505-26-000010:notes:227]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-26-000010:notes:228]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Discount rate | 5.46 | % |  | 4.90 | % |  | 4.87 | % |  | 4.27 | % |  | 5.18 | % |  | 4.89 | % |
| Investment return assumption | 8.01 | % |  | 7.74 | % |  | 6.29 | % |  | 5.84 | % |  | 8.55 | % |  | 8.30 | % |

[0000068505-26-000010:notes:229]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-26-000010:notes:230]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Discount rate | 5.50 | % |  | 5.70 | % |  | 5.25 | % |  | 5.07 | % |  | 5.12 | % |  | 5.49 | % |
| Future compensation increase rate | n/a |  | n/a |  | 0.61 | % |  | 0.67 | % |  | n/a |  | n/a |

[0000068505-26-000010:notes:231]
The following table presents the accumulated benefit obligation, projected benefit obligation and fair value of plan assets for our plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets:

[0000068505-26-000010:notes:232]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  |
| December 31 | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |
| Accumulated benefit obligation | $ | 3,865 |  |  | $ | 3,775 |  |  | $ | 1,210 |  |  | $ | 1,162 |  |  |  |  |
| Projected benefit obligation | 3,865 |  |  | 3,755 |  |  | 1,211 |  |  | 1,163 |  |  |  |  |
| Fair value of plan assets | 3,449 |  |  | 3,249 |  |  | 1,172 |  |  | 1,083 |  |  |  |  |

[0000068505-26-000010:notes:233]
Investment Policy

[0000068505-26-000010:notes:234]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-26-000010:notes:235]
The weighted-average asset allocations by asset categories for all pension plans and the Postretirement Health Care Benefits Plan were as follows:

[0000068505-26-000010:notes:236]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 22 | % |  | 23 | % |  | 25 | % |  | 25 | % |
| Fixed income securities | 61 | % |  | 61 | % |  | 56 | % |  | 57 | % |
| Cash and other investments | 17 | % |  | 16 | % |  | 19 | % |  | 18 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 21 | % |  | 22 | % |  | 24 | % |  | 24 | % |
| Fixed income securities | 61 | % |  | 60 | % |  | 56 | % |  | 56 | % |
| Cash and other investments | 18 | % |  | 18 | % |  | 20 | % |  | 20 | % |

[0000068505-26-000010:notes:237]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-26-000010:notes:238]
Cash Funding

[0000068505-26-000010:notes:239]
The Company made $7 million and $6 million of contributions to its U.S. Pension Benefit Plans during 2025 and 2024, respectively. The Company contributed $11 million and $9 million to its Non U.S. Pension Benefit Plans during 2025 and 2024, respectively. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2025 or 2024.

[0000068505-26-000010:notes:240]
Expected Future Benefit Payments

[0000068505-26-000010:notes:241]
The following benefit payments are expected to be paid:

[0000068505-26-000010:notes:242]
| Year | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2026 | $ | 189 |  |  | $ | 63 |  |  | $ | 13 |  |
| 2027 | 205 |  |  | 64 |  |  | 12 |  |
| 2028 | 222 |  |  | 65 |  |  | 11 |  |
| 2029 | 239 |  |  | 66 |  |  | 10 |  |
| 2030 | 255 |  |  | 67 |  |  | 10 |  |
| 2031-2035 | 1,445 |  |  | 351 |  |  | 36 |  |

[0000068505-26-000010:notes:243]
Other Benefit Plans

[0000068505-26-000010:notes:244]
Split-Dollar Life Insurance Arrangements

[0000068505-26-000010:notes:245]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-26-000010:notes:246]
The net periodic pension cost for these split-dollar life insurance arrangements was $2 million, $3 million and $5 million for the years ended December 31, 2025, 2024 and 2023, respectively. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $47 million and $46 million as of December 31, 2025 and December 31, 2024, respectively.

[0000068505-26-000010:notes:247]
Deferred Compensation Plan

[0000068505-26-000010:notes:248]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the 401(k) plan (as defined below). The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for officers elected by the board of directors of the Company, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-26-000010:notes:249]
Defined Contribution Plan

[0000068505-26-000010:notes:250]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the Motorola Solutions 401(k) plan (the "401(k) plan") is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. In 2026, the Company began making the matching contributions in Company stock. The Company’s expenses for material defined contribution plans for the years ended December 31, 2025, 2024 and 2023 were $33 million, $53 million and $45 million, respectively.

[0000068505-26-000010:notes:251]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2025, 2024, and 2023 the Company made no discretionary contributions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-26-000010:notes:252]
Share-Based Compensation and Other Incentive Plans
The Company grants options to acquire shares of common stock to certain employees. Each option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options assumed or replaced with comparable stock options only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-26-000010:notes:253]
Restricted stock grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees. The grants are restricted in such that they are subject to vesting conditions; however, restricted stock holders have voting rights, and the rights to earn dividends on unvested shares.

[0000068505-26-000010:notes:254]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-26-000010:notes:255]
Performance-based stock options (“performance options”) and market stock units ("MSUs") have been granted to certain Company executive officers, and performance stocks units ("PSUs") have been granted to executives participating in the Long Range Incentive Plan ("LRIP"), including Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor requires a minimum of 60% of the share price on the award date with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years. PSUs have been granted as a portion of the LRIP awards. The PSUs have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual TSR compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date.

[0000068505-26-000010:notes:256]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For each of the years ended December 31, 2025, 2024 and 2023, employees purchased 0.3 million shares, at purchase prices of $372.14 and $370.59 in 2025, $231.98 and $300.55 in 2024, and $194.62 and $231.40 in 2023.

[0000068505-26-000010:notes:257]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-26-000010:notes:258]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2025, 2024 and 2023 was $112.52, $92.20 and $73.04, respectively, using the following weighted-average assumptions:

[0000068505-26-000010:notes:259]
|  | 2025 |  | 2024 |  | 2023 |
| Expected volatility | 24.4 | % |  | 21.4 | % |  | 24.4 | % |
| Risk-free interest rate | 3.9 | % |  | 4.3 | % |  | 4.2 | % |
| Dividend yield | 1.3 | % |  | 1.4 | % |  | 1.6 | % |
| Expected life (years) | 5.9 |  | 5.9 |  | 5.9 |

[0000068505-26-000010:notes:260]
The Company calculates the value of each performance option, MSU, and PSU using a Monte Carlo simulation option pricing model, estimated on the date of grant. The fair values of performance options, MSUs, and PSUs granted during 2025 were $171.79, $449.80 and $446.9, respectively. The fair values of performance options, MSUs, and PSUs granted during 2024 were $141.51, $396.90 and $515.85, respectively. The fair value of performance options, MSUs and PSUs granted during 2023 was $122.55, $299.32 and $348.27, respectively. The following assumptions were used for the calculations.

[0000068505-26-000010:notes:261]
|  | 2025 |  | 2024 |  | 2023 |
|  | Performance Options |  | Performance Options |  | Performance Options |
| Expected volatility of common stock | 24.9 | % |  | 21.7 | % |  | 25.1 | % |
| Expected volatility of the S&P 500 | 29.8 | % |  | 30.5 | % |  | 33.3 | % |
| Risk-free interest rate | 4.1 | % |  | 4.3 | % |  | 4.1 | % |
| Dividend yield | 1.3 | % |  | 1.4 | % |  | 1.7 | % |
| Expected life (years) | 6.5 |  | 6.5 |  | 6.5 |

[0000068505-26-000010:notes:262]
|  | 2025 |  | 2024 |  | 2023 |
|  | Market Stock Unit |  | Market Stock Unit |  | Market Stock Units |
| Expected volatility of common stock | 24.9 | % |  | 21.7 | % |  | 25.1 | % |
| Risk-free interest rate | 3.9 | % |  | 4.4 | % |  | 4.5 | % |
| Dividend yield | 1.1 | % |  | 1.3 | % |  | 1.5 | % |

[0000068505-26-000010:notes:263]
|  | 2025 |  |  | 2024 | 2023 |
|  | Performance Stock Units |  |  | Performance Stock Units | Performance Stock Units |
| Expected volatility of common stock | 24.9 | % |  |  | 21.7 | % | 25.1 | % |
| Expected volatility of the S&P 500 | 29.8 | % |  |  | 30.8 | % | 33.3 | % |
| Risk-free interest rate | 3.9 | % |  |  | 4.3 | % | 4.6 | % |
| Dividend yield | 1.1 | % |  |  | 1.1 | % | 1.4 | % |

[0000068505-26-000010:notes:264]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PSUs. The selection of the implied volatility approach was based upon the availability of actively-traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. At the conclusion of each three-year PSU and performance option cycle, the Company uses the historical volatility as the expected volatility to calculate the actual TSR compared to the S&P 500.

[0000068505-26-000010:notes:265]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-26-000010:notes:266]
The Company has applied forfeiture rates, estimated based on historical data, of 10% to the stock option fair values calculated by the Black-Scholes option pricing model and 15% to RSUs. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-26-000010:notes:267]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, at December 31, 2025 (in thousands, except exercise price and years):

[0000068505-26-000010:notes:268]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| $70-$100 | 495 |  |  | $ | 79 |  |  | 1 |  | 495 |  |  | $ | 79 |  |  | 1 |
| $101-$200 | 797 |  |  | 146 |  |  | 4 |  | 797 |  |  | 146 |  |  | 4 |
| $201-$300 | 526 |  |  | 237 |  |  | 6 |  | 390 |  |  | 227 |  |  | 6 |
| $301-$400 | 199 |  |  | 345 |  |  | 8 |  | 28 |  |  | 341 |  |  | 8 |
| $401 and over | 182 |  |  | 422 |  |  | 9 |  | 9 |  |  | 448 |  |  | 9 |
|  | 2,199 |  |  |  |  |  |  | 1,719 |  |  |  |  |  |

[0000068505-26-000010:notes:269]
As of December 31, 2025, the weighted average contractual life for options outstanding and exercisable was five and four years, respectively.

[0000068505-26-000010:notes:270]
Current Year Activity

[0000068505-26-000010:notes:271]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-26-000010:notes:272]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2025 | 491 |  |  | $ | 230 |  |  | 1,275 |  |  | $ | 275 |  |  | 65 |  |  | $ | 397 |  |
| Granted | 93 |  |  | 414 |  |  | 685 |  |  | 418 |  |  | 74 |  |  | 434 |  |
| Releases/Exercised | (115) |  |  | 226 |  |  | (626) |  |  | 268 |  |  | (39) |  |  | 166 |  |
| Forfeited/Canceled | (7) |  |  | 362 |  |  | (50) |  |  | 337 |  |  | — |  |  | — |  |
| Balance as of December 31, 2025 | 462 |  |  | $ | 267 |  |  | 1,284 |  |  | $ | 352 |  |  | 100 |  |  | $ | 420 |  |
| Awards exercisable | 288 |  |  | 205 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-26-000010:notes:273]
|  | Performance Options |  | Market Stock Units |  | Performance Stock Units |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2025 | 1,731 |  |  | $ | 144 |  |  | 79 |  |  | $ | 331 |  |  | 264 |  |  | $ | 407 |  |
| Granted | 96 |  |  | 414 |  |  | 37 |  |  | 450 |  |  | 54 |  |  | 446 |  |
| Releases/Exercised | (268) |  |  | 99 |  |  | (67) |  |  | 296 |  |  | (166) |  |  | 416 |  |
| Adjustment for payout factor | 178 |  |  | 222 |  |  | 27 |  |  | 228 |  |  | 99 |  |  | 381 |  |
| Forfeited/Canceled | — |  |  | — |  |  | — |  |  | — |  |  | (3) |  |  | 422 |  |
| Balance as of December 31, 2025 | 1,737 |  |  | $ | 174 |  |  | 76 |  |  | $ | 402 |  |  | 248 |  |  | $ | 457 |  |
| Awards exercisable | 1,431 |  |  | 139 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-26-000010:notes:274]
At December 31, 2025 and 2024, 4.8 million and 6.0 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-26-000010:notes:275]
Total Share-Based Compensation Expense

[0000068505-26-000010:notes:276]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-26-000010:notes:277]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 57 |  |  | $ | 48 |  |  | $ | 40 |  |
| Selling, general and administrative expenses | 162 |  |  | 132 |  |  | 116 |  |
| Research and development expenditures | 74 |  |  | 63 |  |  | 56 |  |
| Share-based compensation expense included in Operating earnings | 293 |  |  | 243 |  |  | 212 |  |
| Tax benefit | 62 |  |  | 51 |  |  | 43 |  |
| Share-based compensation expense, net of tax | $ | 231 |  |  | $ | 192 |  |  | $ | 169 |  |
| Decrease in basic earnings per share | $ | (1.39) |  |  | $ | (1.15) |  |  | $ | (1.01) |  |
| Decrease in diluted earnings per share | $ | (1.37) |  |  | $ | (1.12) |  |  | $ | (0.98) |  |

[0000068505-26-000010:notes:278]
At December 31, 2025, the Company had unrecognized compensation expense related to all share-based awards of $421 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately three years and $8 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. The aggregate fair value of outstanding share-based awards as of December 31, 2025 was $784 million.

[0000068505-26-000010:notes:279]
Cash received from stock option exercises and the employee stock purchase plan was $159 million, $161 million, and $157 million, offset by tax withholdings of $113 million, $86 million, and $53 million for the years ended December 31, 2025, 2024, and 2023, respectively. The total intrinsic value of options exercised during the years ended December 31, 2025, 2024, and 2023 was $95 million, $164 million, and $152 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2025 was $424 million and $402 million, respectively, based on a December 31, 2025 stock price of $383.32 per share.

[0000068505-26-000010:notes:280]
Motorola Solutions Incentive Plans

[0000068505-26-000010:notes:281]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2025, 2024 and 2023 was $224 million, $218 million and $205 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-26-000010:notes:282]
Fair Value Measurements
Investments and Derivatives

[0000068505-26-000010:notes:283]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2025 and December 31, 2024 were as follows:

[0000068505-26-000010:notes:284]
| December 31, 2025 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Common stock and equivalents | 42 |  |  | — |  |  | — |  |  | 42 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |
| Contingent earnout consideration (Note 15) | — |  |  | — |  |  | 37 |  |  | 37 |  |

[0000068505-26-000010:notes:285]
| December 31, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  |  |  | $ | 10 |  |
| Common stock and equivalents | 23 |  |  | — |  |  |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |

[0000068505-26-000010:notes:286]
In connection with the acquisition of Silvus, contingent earnout consideration reflects the estimated fair value of the contingent future payments to the Seller following the achievement of certain financial targets. Refer to "Note 15: Intangible Assets and Goodwill” to our consolidated financial statements in this “Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for more information regarding the details of the contingent earnout consideration. The Company determines the fair value of its contingent earnout consideration liability using a Monte Carlo simulation model, which requires the use of Level 3 inputs, such as projected future net sales, gross margin and cash flows. At the acquisition date, the Company recorded a contingent liability of approximately $38 million, related to the estimated fair value of the contingent earnout consideration, which was included in the purchase price. For the year ended December 31, 2025, the fair value adjustment related to the contingent earnout consideration was $1 million which was recorded to Other income, net in the Company's Consolidated Statement of Operations.

[0000068505-26-000010:notes:287]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-26-000010:notes:288]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2025 and 2024 were as follows:

[0000068505-26-000010:notes:289]
| December 31, 2025 | Level 1 |  | Level 2 |  | Level 3 |  |  |  | Total |
| Equities | $ | 24 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 24 |  |
| Commingled funds | 1,200 |  |  | 422 |  |  | — |  |  |  |  | 1,622 |  |
| Government fixed income securities | — |  |  | 347 |  |  | — |  |  |  |  | 347 |  |
| Corporate fixed income securities | — |  |  | 919 |  |  | — |  |  |  |  | 919 |  |
| Short-term investment funds | 231 |  |  | — |  |  | — |  |  |  |  | 231 |  |
| Private assets | — |  |  | — |  |  | 238 |  |  |  |  | 238 |  |
| Total investment securities | $ | 1,455 |  |  | $ | 1,688 |  |  | $ | 238 |  |  |  |  | $ | 3,381 |  |
| Accrued income receivable |  |  |  |  |  |  |  |  | 51 |  |
| Cash |  |  |  |  |  |  |  |  | 17 |  |
| Fair value plan assets |  |  |  |  |  |  |  |  | $ | 3,449 |  |

[0000068505-26-000010:notes:290]
The following table summarizes the changes in fair value of the Level 3 assets:

[0000068505-26-000010:notes:291]
|  | 2025 |
| Fair value at January 1, 2025 | $ | 203 |  |
| Actual return on plan assets | 27 |  |
| Purchases | 8 |  |
| Fair value at December 31, 2025 | $ | 238 |  |

[0000068505-26-000010:notes:292]
| December 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |  |
| Equities | $ | 23 |  |  | $ | — |  |  | $ | — |  |  | $ | 23 |  |  |  |
| Commingled funds | 1,039 |  |  | 404 |  |  | — |  |  | 1,443 |  |  |  |
| Government fixed income securities | — |  |  | 239 |  |  | — |  |  | 239 |  |  |  |
| Corporate fixed income securities | — |  |  | 905 |  |  | — |  |  | 905 |  |  |  |
| Short-term investment funds | 258 |  |  | — |  |  | — |  |  | 258 |  |  |  |
| Private Assets | — |  |  | — |  |  | 203 |  |  | 203 |  |  |  |
| Total investment securities | $ | 1,320 |  |  | $ | 1,548 |  |  | $ | 203 |  |  | $ | 3,071 |  |  |  |
| Accrued income receivable |  |  |  |  |  |  | 162 |  |  |  |
| Cash |  |  |  |  |  |  | 16 |  |  |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 3,249 |  |  |  |

[0000068505-26-000010:notes:293]
| December 31, 2025 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 64 |  |  | $ | — |  |  |  |  | $ | 64 |  |
| Commingled funds | 205 |  |  | 33 |  |  |  |  | 238 |  |
| Government fixed income securities | — |  |  | 755 |  |  |  |  | 755 |  |
| Short-term investment funds | 41 |  |  | — |  |  |  |  | 41 |  |
| Total investment securities | $ | 310 |  |  | $ | 788 |  |  |  |  | $ | 1,098 |  |
| Cash |  |  |  |  |  |  | 5 |  |
| Accrued income receivable |  |  |  |  |  |  | 21 |  |
| Insurance contracts |  |  |  |  |  |  | 48 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,172 |  |

[0000068505-26-000010:notes:294]
| December 31, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 53 |  |  | $ | — |  |  |  |  | $ | 53 |  |
| Commingled funds | 236 |  |  | 35 |  |  |  |  | 271 |  |
| Government fixed income securities | — |  |  | 615 |  |  |  |  | 615 |  |
| Short-term investment funds | 56 |  |  | — |  |  |  |  | 56 |  |
| Total investment securities | $ | 345 |  |  | $ | 650 |  |  |  |  | $ | 995 |  |
| Cash |  |  |  |  |  |  | 4 |  |
| Accrued income receivable |  |  |  |  |  |  | 42 |  |
| Insurance contracts |  |  |  |  |  |  | 42 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,083 |  |

[0000068505-26-000010:notes:295]
| December 31, 2025 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equities | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Commingled funds | 44 |  |  | 17 |  |  | — |  |  | 61 |  |
| Government fixed income securities | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Corporate fixed income securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Short-term investment funds | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Private funds | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Total investment securities | $ | 54 |  |  | $ | 67 |  |  | $ | 9 |  |  | $ | 130 |  |
| Accrued income receivable |  |  |  |  |  |  | 2 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 132 |  |

[0000068505-26-000010:notes:296]
|  | 2025 |
| Fair value at January 1, 2025 | $ | 8 |  |
| Actual return on plan assets | 1 |  |
| Fair value at December 31, 2025 | $ | 9 |  |

[0000068505-26-000010:notes:297]
| December 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Equities | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  |
| Commingled funds | 40 |  |  | 16 |  |  | — |  |  | 56 |  |  |
| Government fixed income securities | — |  |  | 10 |  |  | — |  |  | 10 |  |  |
| Corporate fixed income securities | — |  |  | 37 |  |  | — |  |  | 37 |  |  |
| Short-term investment funds | 10 |  |  | — |  |  | — |  |  | 10 |  |  |
| Private funds | — |  |  | — |  |  | 8 |  |  | 8 |  |  |
| Total investment securities | $ | 51 |  |  | $ | 63 |  |  | $ | 8 |  |  | $ | 122 |  |  |
| Accrued income receivable |  |  |  |  |  |  | 6 |  |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 128 |  |  |

[0000068505-26-000010:notes:298]
The following is a description of the categories of investments:

[0000068505-26-000010:notes:299]
Equities — A diversified portfolio of corporate common and preferred stocks.

[0000068505-26-000010:notes:300]
Commingled funds — A diversified portfolio of assets that includes corporate common and preferred stocks, emerging market and high-yield fixed income securities among others.

[0000068505-26-000010:notes:301]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-26-000010:notes:302]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-26-000010:notes:303]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-26-000010:notes:304]
Private funds — A diversified portfolio of assets that includes private equity funds and private loans.

[0000068505-26-000010:notes:305]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. Level 3 investments include securities with valuations derived from valuation techniques, in which one or more significant inputs are unobservable. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-26-000010:notes:306]
At December 31, 2025, the Company had $735 million of investments in money market government and U.S. treasury funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $1.2 billion at December 31, 2024. The money market funds had quoted market prices that are approximately at par.

[0000068505-26-000010:notes:307]
Using quoted market prices and market interest rates, the Company determined that the fair value of its debt at December 31, 2025 was $9.2 billion. The fair value of long-term debt at December 31, 2024 was $5.8 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange. Refer to "Note 5: Debt and Credit Facilities" to our consolidated financial statements in this “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for a further discussion of the Company's debt.

[0000068505-26-000010:notes:308]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-26-000010:notes:309]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-26-000010:notes:310]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-26-000010:notes:311]
| December 31 | 2025 |  | 2024 |
| Long-term receivables, gross | $ | 93 |  |  | $ | 65 |  |
| Less allowance for losses | (2) |  |  | (2) |  |
| Long-term receivables | $ | 91 |  |  | $ | 63 |  |
| Less current portion | (32) |  |  | (22) |  |
| Non-current long-term receivables | $ | 59 |  |  | $ | 41 |  |

[0000068505-26-000010:notes:312]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized $1 million in interest income on long-term receivables for both of the years ended December 31, 2025 and 2024, compared to no interest income for the year ended December 31, 2023.

[0000068505-26-000010:notes:313]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $179 million at December 31, 2025 and $105 million at December 31, 2024.

[0000068505-26-000010:notes:314]
Sales of Receivables

[0000068505-26-000010:notes:315]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements.

[0000068505-26-000010:notes:316]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2025, 2024 and 2023.

[0000068505-26-000010:notes:317]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| Accounts receivable sales proceeds | $ | 156 |  |  | $ | 15 |  |  | $ | 96 |  |
| Long-term receivables sales proceeds | 258 |  |  | 205 |  |  | 182 |  |
| Total proceeds from receivable sales | $ | 414 |  |  | $ | 220 |  |  | $ | 278 |  |

[0000068505-26-000010:notes:318]
The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-26-000010:notes:319]
At December 31, 2025, the Company had retained servicing obligations for $814 million of long-term receivables, compared to $794 million of long-term receivables at December 31, 2024. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-26-000010:notes:320]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-26-000010:notes:321]
An aging analysis of financing receivables at December 31, 2025 and December 31, 2024 is as follows:

[0000068505-26-000010:notes:322]
| December 31, 2025 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 58 |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 1 |  |
| Commercial loans and leases secured | 35 |  |  | 3 |  |  | — |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 93 |  |  | $ | 12 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000068505-26-000010:notes:323]
| December 31, 2024 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 31 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 1 |  |
| Commercial loans and leases secured | 34 |  |  | 3 |  |  | — |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 65 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000068505-26-000010:notes:324]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-26-000010:notes:325]
Commitments and Contingencies
Purchase Obligations

[0000068505-26-000010:notes:326]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow it to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancellable.

[0000068505-26-000010:notes:327]
As of December 31, 2025, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2033. The Company expects to make total payments of $771 million under these arrangements as follows: $250 million in 2026, $197 million in 2027, $127 million in 2028, $108 million in 2029, $46 million in 2030 and $43 million thereafter.

[0000068505-26-000010:notes:328]
Legal Matters

[0000068505-26-000010:notes:329]
Hytera Civil Litigation

[0000068505-26-000010:notes:330]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor and awarded the Company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-26-000010:notes:331]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products ("I-Series") that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. In 2024, amounts paid into escrow of approximately $61 million were released to the Company and recorded as a gain within Other charges within the Consolidated Statement of Operations. Hytera made quarterly de minimis royalty payments related to the I-Series products directly to the Company in 2025.

[0000068505-26-000010:notes:332]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation, turnover of Hytera assets to the Company, and injunction are currently briefed. On October 14-15, 2025, the District Court held hearings on these issues, but has not yet issued any rulings.

[0000068505-26-000010:notes:333]
In 2025, Hytera made payments towards amounts awarded to the Company and owed by Hytera pursuant to court orders related to I-Series products. In 2025, Hytera made payments of $157 million, of which the Company received $141 million, net of withholding taxes. Subsequent to year-end, in January 2026, Hytera made a payment of $40 million, of which the Company received $36 million, net of withholding taxes. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-26-000010:notes:334]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products ("H-Series"). On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain H-Series products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions.

[0000068505-26-000010:notes:335]
The District Court held hearings in August 2024, concerning whether Hytera's currently shipping H-Series products continue to misuse the Company's trade secrets and copyrighted source code. On August 25, 2025, the District Court held Hytera in civil contempt for violation of the District Court’s royalty order and ordered Hytera to pay the Company approximately $70 million for unpaid royalties and interest for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera's H-Series products. The District Court subsequently ordered Hytera to pay additional royalties of $31 million accrued from the August 2024 hearings and the August 25, 2025 order. Hytera has appealed the District Court’s order to the Court of Appeals. Hytera’s appeal does not automatically stay its obligation to pay the $101 million. On October 14-15, 2025, the District Court heard arguments on whether Hytera must pay the $101 million into escrow, or directly to the Company as a payment towards amounts awarded to the Company and owed by Hytera pursuant to prior court orders, but has not yet issued a ruling.

[0000068505-26-000010:notes:336]
Hytera Criminal Litigation

[0000068505-26-000010:notes:337]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. On November 24-25, December 15, 2025, and January 29, 2026, the District Court held hearings related to Hytera's sentencing. The District Court is expected to issue its ruling on March 5, 2026. Pursuant to the plea agreement reached between Hytera and the government, it is expected that Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in an amount to be determined by the District Court.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-26-000010:notes:338]
Information by Segment and Geographic Region
The Company conducts its business globally and manages it through the following two segments:

[0000068505-26-000010:notes:339]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, and the implementation and integration of such systems, devices and applications. Within MCN, the Company is a global leader in the two-way radio category, including the Company’s Project 25 (P25), Terrestrial Trunked Radio (TETRA), Digital Mobile Radio (DMR), as well as other professional and commercial radio (“PCR”) solutions. The Company provides LTE solutions for public safety, government, including defense, and enterprise users, including devices that operate in both low-band and mid-band frequencies. Additionally, through the Company's MANET and High Frequency (HF) and Very High Frequency (VHF) communications technologies, it supports defense, government and disaster relief agency customers that require dynamic, mobile and tactical point-to-point voice and data communications in remote or contested environments without the need for fixed infrastructure. The Company's Video technology includes network video management infrastructure, fixed security, certain mobile video equipment and access control solutions. The primary customers of the Products and Systems Integration segment are government, including defense, public safety and enterprise customers who operate private communications systems and video security solutions and typically manage a mobile workforce. In 2025, the segment’s net sales were $7.3 billion, representing 62% of the Company's consolidated net sales.

[0000068505-26-000010:notes:340]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and enterprise customers. Software includes public safety and enterprise Command Center, unified communications applications, certain mobile video equipment, and video software solutions, delivered both on-premise and “as-a-service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced technologies include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer-owned or Motorola Solutions-owned communications systems. In 2025, the segment’s net sales were $4.4 billion, representing 38% of the Company's consolidated net sales.

[0000068505-26-000010:notes:341]
For the years ended December 31, 2025, 2024 and 2023, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-26-000010:notes:342]
Segment Information

[0000068505-26-000010:notes:343]
The Company's chief operating decision maker, the chief executive officer, uses both segment gross margin and segment operating earnings to assess performance and allocate resources (including employees, property, and financial or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances on a monthly basis for both profit measures when making decisions about allocating capital and personnel to the segments.

[0000068505-26-000010:notes:344]
The accounting policies of the reportable segments are the same as those described in the summary of significant accounting policies. See “Note 1: Summary of Significant Accounting Policies” to our consolidated financial statements in this “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-26-000010:notes:345]
The following table summarizes Net sales, significant expenses, Gross margin and Operating earnings by segment:

[0000068505-26-000010:notes:346]
|  | 2025 |  | 2024 |  | 2023 |
| Years ended December 31 | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 7,253 |  |  | $ | 4,429 |  |  | $ | 11,682 |  |  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |
| Costs of sales | 3,338 |  |  | 2,309 |  |  | 5,647 |  |  | 3,215 |  |  | 2,090 |  |  | 5,305 |  |  | 3,115 |  |  | 1,893 |  |  | 5,008 |  |
| Gross margin | 3,915 |  |  | 2,120 |  |  | 6,035 |  |  | 3,668 |  |  | 1,844 |  |  | 5,512 |  |  | 3,127 |  |  | 1,843 |  |  | 4,970 |  |
| Selling, general and administrative expenses | 1,478 |  |  | 392 |  | 1,870 |  |  | 1,392 |  |  | 360 |  |  | 1,752 |  |  | 1,239 |  |  | 322 |  |  | 1,561 |  |
| Research and development expenditures | 598 |  | 372 |  | 970 |  | 575 |  |  | 342 |  |  | 917 |  |  | 551 |  |  | 307 |  |  | 858 |  |
| Other charges | 78 |  | 129 |  | 207 |  | 25 |  |  | 130 |  |  | 155 |  |  | 93 |  |  | 163 |  |  | 257 |  |
| Operating earnings | $ | 1,761 |  |  | $ | 1,227 |  |  | $ | 2,988 |  |  | $ | 1,676 |  |  | $ | 1,012 |  |  | $ | 2,688 |  |  | $ | 1,244 |  |  | $ | 1,050 |  |  | $ | 2,294 |  |
| Total other expense |  |  |  |  | (176) |  |  |  |  |  |  | (716) |  |  |  |  |  |  | (148) |  |
| Net earnings before income taxes |  |  |  |  | $ | 2,812 |  |  |  |  |  |  | $ | 1,972 |  |  |  |  |  |  | $ | 2,146 |  |

[0000068505-26-000010:notes:347]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-26-000010:notes:348]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| Products and Systems Integration | $ | 131 |  |  | $ | 103 |  |  | $ | 97 |  |  | $ | 92 |  |  | $ | 90 |  |  | $ | 83 |  |
| Software and Services | 134 |  |  | 154 |  |  | 156 |  |  | 99 |  |  | 94 |  |  | 96 |  |
|  | $ | 265 |  |  | $ | 257 |  |  | $ | 253 |  |  | $ | 191 |  |  | $ | 184 |  |  | $ | 179 |  |

[0000068505-26-000010:notes:349]
The Company's chief operating decision maker does not review or allocate resources based on segment assets.

[0000068505-26-000010:notes:350]
Geographic Area Information

[0000068505-26-000010:notes:351]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| United States | $ | 7,929 |  |  | $ | 7,432 |  |  | $ | 6,559 |  |  | $ | 15,365 |  |  | $ | 11,456 |  |  | $ | 10,207 |  |
| United Kingdom | 603 |  |  | 572 |  |  | 769 |  |  | 2,538 |  |  | 2,190 |  |  | 2,034 |  |
| Canada | 433 |  |  | 388 |  |  | 373 |  |  | 435 |  |  | 383 |  |  | 362 |  |
| Other | 2,717 |  |  | 2,425 |  |  | 2,277 |  |  | 1,051 |  |  | 566 |  |  | 733 |  |
|  | $ | 11,682 |  |  | $ | 10,817 |  |  | $ | 9,978 |  |  | $ | 19,389 |  |  | $ | 14,595 |  |  | $ | 13,336 |  |

[0000068505-26-000010:notes:352]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-26-000010:notes:353]
Reorganization of Businesses
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of contractual lease termination costs, costs to exit committed contracts and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-26-000010:notes:354]
During 2025, 2024, and 2023 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. These initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-26-000010:notes:355]
2025 Charges

[0000068505-26-000010:notes:356]
During 2025, the Company recorded net reorganization of business charges of $60 million, including $16 million of charges in Costs of sales and $44 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $60 million were charges of $62 million related to employee separation costs and $2 million related to exit costs, partially offset by $4 million of reversals for employee separation accruals no longer needed.

[0000068505-26-000010:notes:357]
The following table displays the net charges incurred by segment:

[0000068505-26-000010:notes:358]
| Year ended December 31 | 2025 |
| Products and Systems Integration | $ | 42 |  |
| Software and Services | 18 |  |
|  | $ | 60 |  |

[0000068505-26-000010:notes:359]
Reorganization of Businesses Accruals

[0000068505-26-000010:notes:360]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Reorganization costs | $ | 27 |  |  | $ | 62 |  |  | $ | (4) |  |  | $ | (61) |  |  | $ | 24 |  |
| Exit costs | 1 |  |  | 2 |  |  | — |  |  | (3) |  |  | — |  |
|  | $ | 28 |  |  | $ | 64 |  |  | $ | (4) |  |  | $ | (64) |  |  | $ | 24 |  |

[0000068505-26-000010:notes:361]
Exit Costs

[0000068505-26-000010:notes:362]
At January 1, 2025, the Company had an accrual of $1 million for exit costs related to the Company's exit of the Emergency Services Network ("ESN") contract with the Home Office. During the year, the Company used $1 million reflecting related cash payments to exit certain committed contracts.

[0000068505-26-000010:notes:363]
Employee Separation Costs

[0000068505-26-000010:notes:364]
At January 1, 2025, the Company had an accrual of $27 million for employee separation costs. The 2025 additional charges of $62 million include severance costs for approximately 830 employees, of which 590 were direct employees and 240 were indirect employees. The adjustments of $4 million reflect reversals of accruals no longer needed. The $61 million used in 2025 reflects cash payments to severed employees. The remaining accrual of $24 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2025, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 115 employees to be separated in 2026.

[0000068505-26-000010:notes:365]
2024 Charges

[0000068505-26-000010:notes:366]
During 2024, the Company recorded net reorganization of business charges of $38 million, including $12 million of charges in Costs of sales and $26 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $38 million were charges of $48 million for employee separation costs, partially offset by $6 million of reversals for employee separation accruals no longer needed and $4 million of reversals for exit cost accruals no longer needed.

[0000068505-26-000010:notes:367]
| Year ended December 31 | 2024 |
| Products and Systems Integration | $ | 32 |  |
| Software and Services | 6 |  |
|  | $ | 38 |  |

[0000068505-26-000010:notes:368]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Reorganization costs | $ | 23 |  |  | $ | 48 |  |  | $ | (6) |  |  | $ | (38) |  |  | $ | 27 |  |
| Exit costs | 5 |  |  | — |  |  | (4) |  |  | — |  |  | 1 |  |
|  | $ | 28 |  |  | $ | 48 |  |  | $ | (10) |  |  | $ | (38) |  |  | $ | 28 |  |

[0000068505-26-000010:notes:369]
At January 1, 2024, the Company had an accrual of $5 million for exit costs related to the Company's exit of the ESN contract with the Home Office. During the year, the Company recorded a $4 million reversal for accruals no longer needed. The remaining $1 million of exit costs are recorded in Accrued liabilities in the Company's Consolidated Balance Sheet at December 31, 2024, and are expected to be paid within one year.

[0000068505-26-000010:notes:370]
At January 1, 2024, the Company had an accrual of $23 million for employee separation costs. The 2024 additional charges of $48 million include severance costs for approximately 720 employees, of which 460 were direct employees and 260 were indirect employees. The adjustments of $6 million reflect reversals of accruals no longer needed. The $38 million used in 2024 reflects cash payments to severed employees. The remaining accrual of $27 million, which was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2024, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 140 employees to be separated in 2025.

[0000068505-26-000010:notes:371]
2023 Charges

[0000068505-26-000010:notes:372]
During 2023, the Company recorded net reorganization of business charges of $53 million, including $7 million of charges in Costs of sales and $46 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the $53 million were charges of $41 million for employee separation costs and a $24 million impairment loss related to the exit of video manufacturing operations, partially offset by $7 million of reversals of accruals no longer needed and $5 million of reversals for exit cost accruals no longer needed.

[0000068505-26-000010:notes:373]
| Year ended December 31 | 2023 |
| Products and Systems integration | $ | 45 |  |
| Software and Services | 8 |  |
|  | $ | 53 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-26-000010:notes:374]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-26-000010:notes:375]
Silvus Acquisition

[0000068505-26-000010:notes:376]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired and customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million.

[0000068505-26-000010:notes:377]
Under the terms of the transaction, the Seller will have the potential to earn contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The contingent earnout consideration, if any, will be paid in shares of common stock. The Company valued the contingent earnout consideration using a Monte Carlo methodology which resulted in the Company recognizing $38 million in purchase consideration at the date of close in Other liabilities on the Company’s Condensed Consolidated Balance Sheet. Contingent earnout consideration will continue to be valued at fair value throughout the earnout term and until paid. Changes to the fair value of the contingent earnout consideration will be recorded as a component of operating income within Other income, net in the Company's Consolidated Statement of Operations. Refer to "Note 10: Fair Value Measurements" in this "Part II. Item 8, Financial Statements and Supplementary Data" of this form 10-K for more information regarding the change in fair value.

[0000068505-26-000010:notes:378]
The Company recognized goodwill of $2.9 billion which was allocated primarily to the Products and Systems Integration segment. In addition, the Company recognized $1.9 billion of intangible assets and $401 million of net liabilities, inclusive of $454 million of deferred tax liabilities and $53 million of net tangible assets. Goodwill represents the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized including future customer relationships, new technology and the assembled workforce. The goodwill is not deductible for tax purposes.

[0000068505-26-000010:notes:379]
The identifiable intangible assets were each classified primarily as one asset as follows: $135 million of trade names, $820 million of customer relationships and $920 million of developed technology which will be amortized over a period of twelve, twelve and eight years, respectively. The fair values of all intangible assets were estimated using the income approach. Customer relationships was valued under the excess earnings method, which assumes that the value of intangible assets is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible assets. Developed technology and trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them. The Company applies significant judgment in determining the estimates and assumptions used to estimate the fair values of the intangible assets, including the forecasted revenue growth rates, customer attrition rate, and discount rate for customer relationships and the forecasted revenue growth rates, royalty rate, and discount rate for developed technology.

[0000068505-26-000010:notes:380]
This business is part of both the Products and Systems Integration segment and the Software and Services segment. Between the acquisition date and December 31, 2025, the Company recorded a net reduction of $26 million in goodwill and an increase primarily to intangible assets related to purchase accounting adjustments during the measurement period. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net tangible assets and goodwill may be subject to change.

[0000068505-26-000010:notes:381]
Recent Acquisitions

[0000068505-26-000010:notes:382]
On November 18, 2025, the Company acquired Blue Eye, a provider of AI-powered enterprise remote video monitoring ("RVM") services for $79 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of two years. The acquisition enhances the Company's video security portfolio, serving a wide range of enterprises with real-time intelligence to help reduce loss and damage, mitigate risk and boost profitability. The Company recognized $59 million of goodwill, $24 million of identifiable intangible assets and $4 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of customer relationships and $15 million of developed technology and will be amortized over a period of twenty and eleven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-26-000010:notes:383]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $174 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value price of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. The Company recognized $119 million of goodwill, $48 million of identifiable intangible assets and $7 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $15 million of customer relationships and $32 million of developed technology and will be amortized over a period of three, nineteen and eleven years, respectively. The business is part of the Software and Services segment. Between the acquisition date and December 31, 2025, the Company recorded a net reduction of $7 million in goodwill and an increase primarily to intangible assets related to purchase accounting adjustments during the measurement period. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-26-000010:notes:384]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $240 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. The Company recognized $132 million of goodwill, $117 million of identifiable intangible assets and $9 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $6 million of trade names, $36 million of customer relationships and $75 million of developed technology and will be amortized over a period of nine, nineteen and eighteen years, respectively. Between the acquisition date and December 31, 2025, the Company recorded a net reduction of $54 million in goodwill and an increase primarily to intangible assets related to purchase accounting adjustments during the measurement period. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-26-000010:notes:385]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing CAD for the U.K.'s public safety agencies. The Company recognized $15 million of goodwill, $11 million of identifiable intangible assets, and $3 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $11 million of developed technology and will be amortized over a period of seven years. The business is part of the Software and Services segment. The purchase accounting was completed as of the fourth quarter of 2025.

[0000068505-26-000010:notes:386]
On July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $92 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The Company recognized $49 million of goodwill, $53 million of identifiable intangible assets, and $10 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $7 million of customer relationships and $45 million of developed technology and will be amortized over a period of three, fifteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the third quarter of 2025.

[0000068505-26-000010:notes:387]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The Company recognized $62 million of goodwill, $65 million of identifiable intangible assets and $5 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $11 million of trade names, $51 million of customer relationships and $3 million of developed technology and will be amortized over a period of nine, eighteen and six years, respectively. The acquisition expands the Company's video solutions within the Software and Services segment. The purchase accounting was completed as of the third quarter of 2025.

[0000068505-26-000010:notes:388]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The Company recognized $16 million of goodwill, $22 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $10 million of customer relationships and $11 million of developed technology and will be amortized over a period of two, fourteen and ten years, respectively. The business is part of the Products and System Integration segment. The purchase accounting was completed as of the first quarter of 2025.

[0000068505-26-000010:notes:389]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. The transaction also included the potential for the Company to make contingent earn-out payments of up to $15 million based on IPVideo's achievement of certain financial targets from January 1, 2024 through December 31, 2024. As of the acquisition date, the Company estimated the fair value of the contingent earn-out to be $2 million, which was included in the purchase price. However, as of December 31, 2024, the Company concluded that the contingent earn-out targets were not achieved. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The Company recognized $100 million of goodwill, $83 million of identifiable intangible assets and $13 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $8 million of trade names, $6 million of customer relationships and $69 million of developed technology and will be amortized over a period of eight, twelve and fifteen years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting was completed as of the fourth quarter of 2024.

[0000068505-26-000010:notes:390]
Intangible Assets

[0000068505-26-000010:notes:391]
Amortized intangible assets are comprised of the following:

[0000068505-26-000010:notes:392]
|  | 2025 |  | 2024 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Developed technology | $ | 2,285 |  |  | $ | 679 |  |  | $ | 1,226 |  |  | $ | 535 |  |
| Customer-related | 2,515 |  |  | 1,190 |  |  | 1,609 |  |  | 1,093 |  |
| Trade name | 247 |  |  | 74 |  |  | 103 |  |  | 61 |  |
| Other intangibles | 15 |  |  | 15 |  |  | 15 |  |  | 15 |  |
|  | $ | 5,062 |  |  | $ | 1,958 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-26-000010:notes:393]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $234 million, $152 million, and $177 million for the years ended December 31, 2025, 2024, and 2023, respectively. The increase in amortization expense during 2025 was a result of the amortization of intangible assets acquired in the Silvus acquisition. As of December 31, 2025, future amortization expense is estimated to be $345 million in 2026, $335 million in 2027, $334 million in 2028, $322 million in 2029, and $319 million in 2030.

[0000068505-26-000010:notes:394]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-26-000010:notes:395]
|  | 2025 |  | 2024 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 2,707 |  |  | $ | 552 |  |  | $ | 1,017 |  |  | $ | 409 |  |
| Software and Services | 2,355 |  |  | 1,406 |  |  | 1,936 |  |  | 1,295 |  |
|  | $ | 5,062 |  |  | $ | 1,958 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-26-000010:notes:396]
Goodwill

[0000068505-26-000010:notes:397]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2024 to December 31, 2025:

[0000068505-26-000010:notes:398]
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2024 | $ | 1,568 |  |  | $ | 1,833 |  |  | $ | 3,401 |  |
| Goodwill acquired | 16 |  |  | 128 |  |  | 144 |  |
| Purchase accounting adjustments | (9) |  |  | 3 |  |  | (6) |  |
| Foreign currency translation | (2) |  |  | (11) |  |  | (13) |  |
| Balance as of December 31, 2024 | $ | 1,573 |  |  | $ | 1,953 |  |  | $ | 3,526 |  |
| Goodwill acquired | 2,654 |  |  | 606 |  |  | 3,260 |  |
| Purchase accounting adjustments | — |  |  | (4) |  |  | (4) |  |
| Foreign currency translation | 2 |  |  | 16 |  |  | 18 |  |
| Balance as of December 31, 2025 | $ | 4,229 |  |  | $ | 2,571 |  |  | $ | 6,800 |  |

[0000068505-26-000010:notes:399]
The Company conducts its annual assessment of goodwill for impairment as of the last day of the third quarter of each fiscal year. The goodwill impairment assessment is performed at the reporting unit level which is an operating segment or one level below an operating segment.

[0000068505-26-000010:notes:400]
In 2025 and 2024, the Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal year 2025 and 2024, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, a quantitative goodwill impairment test was not required and there was no impairment of goodwill in 2025 or 2024.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-26-000010:notes:401]
Valuation and Qualifying Accounts
The following table presents the valuation and qualifying account activity for the years ended December 31, 2025, 2024, and 2023:

[0000068505-26-000010:notes:402]
|  | Balance atBeginning of Period |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atEnd of Period |
| 2025 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | $ | 83 |  |  | $ | 39 |  |  | $ | (39) |  |  | $ | — |  |  | $ | 83 |  |
| 2024 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 69 |  |  | 49 |  |  | (35) |  |  | — |  |  | 83 |  |
| 2023 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 61 |  |  | 29 |  |  | (21) |  |  | — |  |  | 69 |  |

[0000068505-26-000010:notes:403]
* Adjustments include translation adjustments
