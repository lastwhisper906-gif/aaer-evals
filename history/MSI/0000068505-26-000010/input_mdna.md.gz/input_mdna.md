# MSI MD&A — 0000068505-26-000010


## mdna

[0000068505-26-000010:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-26-000010:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2025 and 2024 and results of operations and cash flows for each of the three years in the period ended December 31, 2025. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-26-000010:mdna:3]
Executive Overview

[0000068505-26-000010:mdna:4]
Our Business

[0000068505-26-000010:mdna:5]
Motorola Solutions is a global leader in mission-critical safety and security technologies for public safety, government, including defense, and enterprise customers. Our business is focused on safety and security driven by our commitment to help create safer communities, safer schools, safer hospitals, safer businesses, and ultimately, safer nations. Grounded in nearly 100 years of close customer and community collaboration, we design and advance technology for more than 100,000 customers in over 100 countries, with the goal of making everywhere safer for all.

[0000068505-26-000010:mdna:6]
Our ecosystem of safety and security technologies is managed through two segments: "Products and Systems Integration" and Software and Services". Within these segments, we have three principal product lines in which we report net sales: Mission Critical Networks ("MCN"), Video Security and Access Control ("Video") and Command Center. Our strategy is to generate value through our technologies that help meet the changing needs of our customers around the world in protecting people, property and places. While each technology individually strives to make users safer and more productive, we believe we can enable better outcomes for our customers by uniting these technologies as a comprehensive integrated safety and security system. Our goal is to help dismantle silos and barriers between people and systems, so that data unifies, information flows, operations run and collaboration improves to help strengthen safety and security everywhere.

[0000068505-26-000010:mdna:7]
We have invested across these three technologies organically and through acquisitions to evolve our land mobile radio ("LMR") focus and expand our ecosystem of safety and security products and services. Across all three technologies, we offer artificial intelligence ("AI")-powered capabilities and software solutions, services such as cybersecurity subscription services and managed and support services.

[0000068505-26-000010:mdna:8]
We support public safety and defense agencies in their mission to help protect communities and countries. We additionally serve our growing base of enterprise customers, including schools, hospitals, businesses and stadiums, as the criticality of safety and security becomes increasingly important. Across these diverse sectors, our technologies facilitate the connection between those in need and those who can help, enabling the collaboration that is critical for a more proactive approach to safety and security.

[0000068505-26-000010:mdna:9]
This collaboration is clearly illustrated in a school setting: When a teacher presses a panic button, our technologies can automatically notify local law enforcement, trigger a lockdown to secure all entries, share live video feeds with first responders and send mass notifications to key stakeholders. This integrated workflow helps schools to detect, respond to and resolve safety and security threats faster and more effectively.

[0000068505-26-000010:mdna:10]
The principal products within each segment, by technology, are described below:

[0000068505-26-000010:mdna:11]
Products and Systems Integration Segment

[0000068505-26-000010:mdna:12]
In 2025, the segment’s net sales were $7.3 billion, representing 62% of our consolidated net sales.

[0000068505-26-000010:mdna:13]
MCN

[0000068505-26-000010:mdna:14]
Our MCN technology includes infrastructure and devices for LMR, mobile ad-hoc network ("MANET") technology, as well as devices for public safety Long Term Evolution (“LTE”) and public carrier LTE. Our technology enables voice and multimedia collaborations across two-way radio, Wi-Fi and public and private broadband networks. We are a global leader in the two-way radio category, including Project 25 (P25), Terrestrial Trunked Radio (TETRA) and Digital Mobile Radio (DMR), as well as other professional and commercial radio ("PCR") solutions. We also deliver LTE solutions for public safety, government, including defense, and enterprise users, with our portfolio of devices operating in both low-band and mid-band frequencies. Additionally, through our MANET and High Frequency (HF) and Very High Frequency (VHF) communications technologies, we support defense, government and disaster relief agency customers that require dynamic, mobile and tactical point-to-point voice and data communications in remote or contested environments without the need for fixed infrastructure.

[0000068505-26-000010:mdna:15]
We believe that public safety, government agencies, including defense, and enterprises continue to trust mission-critical communications systems and devices because they are purpose-built and designed for reliability, availability, security and resiliency to help keep people connected even during the most challenging conditions.

[0000068505-26-000010:mdna:16]
By extending our two-way radios with broadband data capabilities, we strive to provide our customers with greater functionality and multimedia access to the information and data they need in their workflows. Examples include application services such as GPS location to better protect lone workers, job dispatch to assign work orders and over-the-air programming to optimize device uptime. Our view is that complementary data applications such as these enable our customers to work more efficiently and safely, while maintaining their mission-critical voice communications to remain connected and working in collaboration with others.

[0000068505-26-000010:mdna:17]
Primary sources of revenue for this technology come from selling devices and building communications systems, including the installation and integration of our infrastructure equipment within our customers’ operations. The MCN technology within the Products and Systems Integration segment represented 84% of the net sales of the total segment in 2025.

[0000068505-26-000010:mdna:18]
Video

[0000068505-26-000010:mdna:19]
Our Video technology includes video management infrastructure, AI-powered security cameras including fixed and certain mobile video equipment, as well as on-premises and cloud-based access control solutions. We deploy video security and access control solutions to thousands of government, public safety and enterprise customers around the world, including schools, transportation systems, healthcare centers, public venues, commercial real estate, utilities, prisons, factories, casinos, airports, financial institutions, government facilities, state and local law enforcement agencies and retailers.

[0000068505-26-000010:mdna:20]
Organizations utilize video security and access control to verify critical events or incidents in real-time and to provide evidentiary data to investigate an event after it occurs. Our view is that government and public safety customers are increasingly turning to video security technologies to increase visibility, accountability and safety for communities and first responders alike.

[0000068505-26-000010:mdna:21]
The Video technology within the Products and Systems Integration segment represented 16% of the net sales of the total segment in 2025.

[0000068505-26-000010:mdna:22]
Software and Services Segment

[0000068505-26-000010:mdna:23]
In 2025, the segment’s net sales were $4.4 billion, representing 38% of our consolidated net sales.

[0000068505-26-000010:mdna:24]
MCN

[0000068505-26-000010:mdna:25]
MCN services include support and managed services, which offer a broad continuum of support for our customers. Support services include repair and replacement, technical support and preventative maintenance, and more advanced offerings such as system monitoring, software updates and cybersecurity services. Managed services range from partial to full operational support of customer-owned or Motorola Solutions-owned communications systems. Our customers’ systems often have multi-year or multi-decade lifespans that help drive demand for software upgrades, as well as additional services to monitor, manage, maintain and secure these complex networks and solutions. We strive to deliver services to our customers that help improve performance across their systems, devices and applications for greater safety and productivity.

[0000068505-26-000010:mdna:26]
Given the mission-critical nature of our customers’ operational environments, we aim to design the mission-critical networks they rely on for reliability, availability, security and resiliency. We have a comprehensive approach to system upgrades that addresses hardware, software and implementation services. As new system releases and data security updates become available, we work with our customers to upgrade software, hardware, or both. This may include site controllers, comparators, routers, LAN switches, servers, dispatch consoles, logging equipment, network management terminals, network security devices such as firewalls and intrusion detection sensors, on-site or remotely.

[0000068505-26-000010:mdna:27]
The MCN technology within the Software and Services segment represented 58% of the net sales of the total segment in 2025.

[0000068505-26-000010:mdna:28]
Video

[0000068505-26-000010:mdna:29]
Video software includes video network management and access control software, decision management and digital evidence management software, certain mobile video equipment and advanced vehicle location data analysis software, including license plate recognition, site protection, and mailroom and visitor management software. Our software is designed to complement video hardware systems, providing end-to-end video security to help keep people, property and places safe.

[0000068505-26-000010:mdna:30]
Our video network management software integrates AI-powered analytics to deliver operational insights to our customers by bringing attention to important events within their video footage. Given the growing volume of video content, we believe that AI-powered analytics are critical to delivering meaningful, action-oriented insights. Our view is that these insights can help to proactively detect an important event in real time as well as reactively search video content to investigate an important event that occurred in the past. For example, AI-powered analytics can highlight a person at a facility out of hours (unusual activity), locate a missing child at a theme park (appearance search), automate video verification workflows for building access (site protection), flag a vehicle of interest at a school (license plate recognition), send an alert if doors to a restricted area are propped open at a hospital (access control), trigger a school's customized lockdown plan while simultaneously alerting first responders and sharing the school's video footage (decision management) or redact people and objects in video evidence for investigations (digital evidence management).

[0000068505-26-000010:mdna:31]
Our cloud technologies can offer organizations the ability to access, search and manage their video security intrusion, access control, mailroom and visitor management systems from a centralized dashboard, accessible on remote devices such as smartphones and laptops via web browser or mobile app. Additionally, our on-premises fixed video systems can be connected to the cloud, enabling our customers to securely access and manage video across their sites from a remote or central monitoring location. We believe that governments, public safety agencies and enterprises are increasingly turning to scalable, cloud-based multi-factor authentication access control to make their facilities more secure.

[0000068505-26-000010:mdna:32]
Our Video services include our "hardware-as-a-subscription" offerings for law enforcement, simplifying procurement by offering cameras in a predictable subscription. Our body cameras can be paired with either on-premises or cloud-based digital evidence management software and complementary command center products. Our cloud solutions are also sold as-a-service, available from single-year to multi-year hosted services, supporting our customers with upgrades and software enhancements to help ensure system performance and technological advancement. We also provide central monitoring services for customers who prefer a turnkey offering.

[0000068505-26-000010:mdna:33]
The Video technology within the Software and Services segment represented 21% of the net sales of the total segment in 2025.

[0000068505-26-000010:mdna:34]
Command Center

[0000068505-26-000010:mdna:35]
Our Command Center portfolio offers cloud-native, on-premises and hybrid software solutions that support the entire public safety workflow, from the initial 911 call through case closure. Our portfolio includes software applications and AI-powered capabilities that unify voice and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents while helping to accelerate workflows and improve the accuracy, speed and trust of decisions. Our software serves call takers, dispatchers, first responders, intelligence analysts, records and evidence specialists, detectives, crime analysts, and corrections officers.

[0000068505-26-000010:mdna:36]
Command Center also includes interoperability solutions, ensuring communication across LMR and broadband networks, enabling critical connectivity solutions for both public safety and enterprise customers. We provide flexibility with both cloud-native applications for the command center and devices, as well as cloud features that augment existing on-premises applications, allowing customers to optimize technology investments and adopt a hybrid approach.

[0000068505-26-000010:mdna:37]
The Command Center technology within the Software and Services segment represented 21% of the net sales of the total segment in 2025.

[0000068505-26-000010:mdna:38]
2025 Financial Results

[0000068505-26-000010:mdna:39]
•Net sales were $11.7 billion in 2025 compared to $10.8 billion in 2024.

[0000068505-26-000010:mdna:40]
•Operating earnings were $3.0 billion in 2025 compared to $2.7 billion in 2024.

[0000068505-26-000010:mdna:41]
•Net earnings attributable to Motorola Solutions, Inc. were $2.2 billion, or $12.75 per diluted common share in 2025, compared to earnings of $1.6 billion, or $9.23 per diluted common share in 2024.

[0000068505-26-000010:mdna:42]
•Our operating cash flow was $2.8 billion in 2025 compared to $2.4 billion in 2024.

[0000068505-26-000010:mdna:43]
•We returned approximately $1.9 billion of capital to shareholders, in the form of $728 million in dividends and $1.2 billion in share repurchases in 2025.

[0000068505-26-000010:mdna:44]
•We increased our quarterly dividend by 11% to $1.21 per share in November 2025.

[0000068505-26-000010:mdna:45]
•We ended 2025 with a backlog position of $15.7 billion, up $1.0 billion compared to 2024.

[0000068505-26-000010:mdna:46]
Segment Financial Highlights

[0000068505-26-000010:mdna:47]
•In the Products and Systems Integration segment, net sales were $7.3 billion in 2025, an increase of $370 million, or 5%, compared to $6.9 billion in 2024. On a geographic basis, net sales increased in both the North America and International regions. Operating earnings were $1.8 billion in 2025, compared to $1.7 billion in 2024. Operating margins were 24.3% in both 2025 and 2024 primarily driven by higher sales, improved gross margins and a gain related to the Hytera litigation, partially offset by higher employee incentive costs and an increase in intangible amortization expenses.

[0000068505-26-000010:mdna:48]
•In the Software and Services segment, net sales were $4.4 billion in 2025, an increase of $495 million, or 13%, compared to $3.9 billion in 2024. On a geographic basis, net sales increased in both the North America and International regions. Operating earnings were $1.2 billion in 2025, compared to $1.0 billion in 2024. Operating margins increased in 2025 to 27.7% from 25.7% in 2024 primarily driven by higher sales and improved operating leverage, partially offset by higher expenses associated with acquired businesses and higher employee incentive costs.

[0000068505-26-000010:mdna:49]
Recent Events

[0000068505-26-000010:mdna:50]
Macroeconomic Environment Update

[0000068505-26-000010:mdna:51]
The current global trade environment is complex and evolving. In 2025, the U.S. initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, contributing to a global trade landscape subject to evolving tariffs, import/export regulations, including restrictions around rare earth minerals, trade barriers and trade disputes. We continue to monitor the impact of the current trade environment, including tariffs implemented under the International Emergency Economic Powers Act (IEEPA), for the impacts of policy volatility, pending judicial outcomes, and evolving geopolitical events that may impact our supply chain costs and operational efficiency. In addition, we are observing shifting dynamics in the memory market driven by substantial demand from the AI data center sector. As a result, we continue to observe elevated volatility and uncertainty around the global supply chain.

[0000068505-26-000010:mdna:52]
We engage with global suppliers across a diverse network of locations around the world. We continue to work with our global supply base to mitigate our exposure to the risks to global reciprocal (and sectoral) tariffs, navigate import/export regulations that have developed, and which may continue to develop, and mitigate our exposure to rising costs to facilitate continued supply at levels in order to meet our current customer demand. As a result of the dynamic global supply chain environment, we have experienced increased costs on materials and components, which we have substantially mitigated during 2025 and for which we expect to continue to develop mitigation actions going forward.

[0000068505-26-000010:mdna:53]
We continue to see demand for our products and services supported by a multitude of funding sources. In July 2025, the “One Big Beautiful Bill Act” (“OBBBA”) was enacted into law by the President of the United States, which provided a number of changes including funding over the next four years for border security, national security and other opportunities. We expect OBBBA to provide an additional source of funding to our federal government customers over the four-year period available through OBBBA.

[0000068505-26-000010:mdna:54]
Recent Acquisitions

[0000068505-26-000010:mdna:55]
| Segment | Technology | Acquisition | Description | Purchase Price | Date of Acquisition |
| Software and Services | Video Security and Access Control | Blue Eye | Provider of AI-powered enterprise remote video monitoring ("RVM") services. | $79 million and share-based compensation of $1 million | November 18, 2025 |
| Products and Systems Integration&Software and Services | Mission Critical Networks | Silvus | Designer and developer of software-defined high-speed MANET technology. | $4.4 billion and share-based compensation of $20 million | August 6, 2025 |
| Software and Services | Command Center | Theatro | Creator of AI and voice-powered communication and digital workflow software for frontline workers. | $174 million and share-based compensation of $5 million | March 6, 2025 |
| Software and Services | Command Center | RapidDeploy | Provider of cloud-native 911 solutions. | $240 million and share-based compensation of $6 million | February 21, 2025 |
| Software and Services | Command Center | 3tc Software | Provider of control room software solutions. | $23 million and share-based compensation of $4 million | October 29, 2024 |
| Software and Services | Command Center | Noggin | Provider of cloud-based business continuity planning, operational resilience and critical event management software. | $92 million and share-based compensation of $19 million | July 1, 2024 |
| Software and Services | Video Security and Access Control | Unnamed vehicle location and management solutions business | Provider of vehicle location and management solutions. | $132 million and share-based compensation of $3 million | July 1, 2024 |
| Products and Systems Integration | Video Security and Access Control | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |
| Products and Systems Integration | Video Security and Access Control | IPVideo | Creator of a multifunctional safety and security device. | $170 million and share-based compensation of $5 million | December 15, 2023 |

[0000068505-26-000010:mdna:56]
Looking Forward

[0000068505-26-000010:mdna:57]
We expect continued growth opportunities spanning public safety, government, including defense, and enterprise industries, driven by investments, including acquisitions, in our integrated ecosystem of MCN, Video and Command Center technologies. We believe uniting these safety and security technologies into a tightly integrated workflow enables better outcomes and drives long-term growth. We expect customers will increasingly turn to these integrated solutions to modernize operations and bridge data silos, streamlining workflows to enhance productivity, speed and safety.

[0000068505-26-000010:mdna:58]
36

[0000068505-26-000010:mdna:59]
As global threats and large-scale incidents rise, we believe our foundational communications backbone provides the scale, security and reliability that our customers depend on. Grounded in our mission-critical communications expertise, we enable the connectivity platform and services that integrate LMR, broadband and MANET that allows customers to operationalize intelligence across diverse environments, underscoring the necessity for secure, resilient networks. We further expect our investments in our intelligent network footprint will position us well within the defense sector as global investments in drones, unmanned systems and resilient tactical networks rise.

[0000068505-26-000010:mdna:60]
Within Video, we expect growth across our fixed and mobile solutions as we converge video with other mission-critical technologies. Our SVX body-worn assistant exemplifies this strategy by converging secure voice, video and AI into a single device to offer a highly differentiated solution. We believe other growth drivers include the expansion of advanced analytics and "video-as-a-service" beyond traditional enterprise markets to government, including defense, and public safety customers, and the continued adoption of cloud video security solutions. Additionally, we anticipate increasing demand for scalable, cloud-based access control and multi-factor authentication as facilities seek real time, centralized monitoring capabilities to enhance site security.

[0000068505-26-000010:mdna:61]
We believe our Command Center portfolio will continue to serve as the central operational hub for our customers, unifying technologies to streamline workflows from "911 call to case closure" and across complex enterprise environments, while accelerating the transition to our cloud solutions. Assist, our mission-critical AI, operationalizes intelligence across the command center to enable automation and deliver high-fidelity insights. In public safety, Assist enables 911 transcription, live translation and narrative development to accelerate response and enhance reporting accuracy. In enterprise settings, Assist enables proactive threat detection and operational efficiency to help protect personnel and assets.

[0000068505-26-000010:mdna:62]
We expect that our customers will continue to turn to cloud-based integrated solutions which will drive increased growth across our portfolio of native cloud and hybrid solutions. We remain focused on providing customers the flexibility to deploy technology with the model that best fits their sovereignty and operational needs. As the digital threat landscape evolves, we expect customers to increasingly rely on our cybersecurity protection and 24/7 managed and support services.

[0000068505-26-000010:mdna:63]
Results of Operations

[0000068505-26-000010:mdna:64]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2025 |  | % ofSales ** |  | 2024 |  | % ofSales ** |  | 2023 |  | % ofSales ** |
| Net sales from products | $ | 6,770 |  |  |  |  | $ | 6,454 |  |  |  |  | $ | 5,814 |  |  |  |
| Net sales from services | 4,912 |  |  |  |  | 4,363 |  |  |  |  | 4,164 |  |  |  |
| Net sales | 11,682 |  |  |  |  | 10,817 |  |  |  |  | 9,978 |  |  |  |
| Costs of product sales | 2,776 |  |  | 41.0 | % |  | 2,674 |  |  | 41.4 | % |  | 2,591 |  |  | 44.6 | % |
| Costs of services sales | 2,871 |  |  | 58.4 | % |  | 2,631 |  |  | 60.3 | % |  | 2,417 |  |  | 58.0 | % |
| Costs of sales | 5,647 |  |  | 48.3 | % |  | 5,305 |  |  | 49.0 | % |  | 5,008 |  |  | 50.2 | % |
| Gross margin | 6,035 |  |  | 51.7 | % |  | 5,512 |  |  | 51.0 | % |  | 4,970 |  |  | 49.8 | % |
| Selling, general and administrative expenses | 1,870 |  |  | 16.0 | % |  | 1,752 |  |  | 16.2 | % |  | 1,561 |  |  | 15.6 | % |
| Research and development expenditures | 970 |  |  | 8.3 | % |  | 917 |  |  | 8.5 | % |  | 858 |  |  | 8.6 | % |
| Other charges | 207 |  |  | 1.8 | % |  | 155 |  |  | 1.4 | % |  | 257 |  |  | 2.6 | % |
| Operating earnings | 2,988 |  |  | 25.6 | % |  | 2,688 |  |  | 24.8 | % |  | 2,294 |  |  | 23.0 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (302) |  |  | (2.6) | % |  | (227) |  |  | (2.1) | % |  | (216) |  |  | (2.2) | % |
| Other, net | 126 |  |  | 1.1 | % |  | (489) |  |  | (4.5) | % |  | 68 |  |  | 0.7 | % |
| Total other expense | (176) |  |  | (1.5) | % |  | (716) |  |  | (6.6) | % |  | (148) |  |  | (1.5) | % |
| Net earnings before income taxes | 2,812 |  |  | 24.1 | % |  | 1,972 |  |  | 18.2 | % |  | 2,146 |  |  | 21.5 | % |
| Income tax expense | 652 |  |  | 5.6 | % |  | 390 |  |  | 3.6 | % |  | 432 |  |  | 4.3 | % |
| Net earnings | 2,160 |  |  | 18.5 | % |  | 1,582 |  |  | 14.6 | % |  | 1,714 |  |  | 17.2 | % |
| Less: Earnings attributable to noncontrolling interests | 6 |  |  | 0.1 | % |  | 5 |  |  | — | % |  | 5 |  |  | 0.1 | % |
| Net earnings* | $ | 2,154 |  |  | 18.4 | % |  | $ | 1,577 |  |  | 14.6 | % |  | $ | 1,709 |  |  | 17.1 | % |
| Earnings per diluted common share* | $ | 12.75 |  |  |  |  | $ | 9.23 |  |  |  |  | $ | 9.93 |  |  |  |

[0000068505-26-000010:mdna:65]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-26-000010:mdna:66]
**    Percentages may not add due to rounding.

[0000068505-26-000010:mdna:67]
Geographic Market Sales by Locale of End Customer

[0000068505-26-000010:mdna:68]
|  | 2025 |  | 2024 |  | 2023 |
| North America | 72 | % |  | 72 | % |  | 69 | % |
| International | 28 | % |  | 28 | % |  | 31 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-26-000010:mdna:69]
Results of Operations—2025 Compared to 2024

[0000068505-26-000010:mdna:70]
Net Sales

[0000068505-26-000010:mdna:71]
|  | Years ended December 31 |
| (In millions) | 2025 |  | 2024 |  | % Change |
| Net sales from Products and Systems Integration | $ | 7,253 |  |  | $ | 6,883 |  |  | 5 | % |
| Net sales from Software and Services | 4,429 |  |  | 3,934 |  |  | 13 | % |
| Net sales | $ | 11,682 |  |  | $ | 10,817 |  |  | 8 | % |

[0000068505-26-000010:mdna:72]
The Products and Systems Integration segment’s net sales represented 62% of our net sales in 2025, compared to 64% of our net sales in 2024. The Software and Services segment’s net sales represented 38% of our net sales in 2025, compared to 36% of our net sales in 2024.

[0000068505-26-000010:mdna:73]
Net sales increased by $865 million, or 8%, compared to 2024. The 13% increase in the Software and Services segment was driven by a 12% increase in the North America region and a 14% increase within the International region. The 5% increase in net sales within the Products and Systems Integration segment was driven by a 4% increase in the North America region and a 8% increase in the International region. The increase in net sales included:

[0000068505-26-000010:mdna:74]
•an increase in the Software and Services segment, inclusive of $120 million of revenue from acquisitions, driven by an increase in MCN, Video and Command Center; and

[0000068505-26-000010:mdna:75]
•an increase in the Products and Systems Integration segment, inclusive of $262 million of revenue from acquisitions, driven by growth in MCN and Video;

[0000068505-26-000010:mdna:76]
•inclusive of $35 million from favorable currency rates.

[0000068505-26-000010:mdna:77]
Regional results included:

[0000068505-26-000010:mdna:78]
•a 7% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in MCN, Video and Command Center; and

[0000068505-26-000010:mdna:79]
•a 11% increase in the International region, inclusive of revenue from acquisitions, driven by growth in MCN, Video and Command Center.

[0000068505-26-000010:mdna:80]
Products and Systems Integration

[0000068505-26-000010:mdna:81]
The 5% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-26-000010:mdna:82]
•a $327 million, or 6% growth in MCN, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-26-000010:mdna:83]
•a $43 million, or 4% growth in Video, driven by the North America region; and

[0000068505-26-000010:mdna:84]
•inclusive of $20 million from favorable currency rates.

[0000068505-26-000010:mdna:85]
Software and Services

[0000068505-26-000010:mdna:86]
The 13% increase in the Software and Services segment was driven by the following:

[0000068505-26-000010:mdna:87]
•a $220 million, or 9% growth in MCN, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-26-000010:mdna:88]
•a $157 million, or 20% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-26-000010:mdna:89]
•a $118 million, or 15% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-26-000010:mdna:90]
•inclusive of $15 million from favorable currency rates.

[0000068505-26-000010:mdna:91]
38

[0000068505-26-000010:mdna:92]
Gross Margin

[0000068505-26-000010:mdna:93]
|  | Years ended December 31 |
| (In millions) | 2025 |  | 2024 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 3,915 |  |  | $ | 3,668 |  |  | 7 | % |
| Gross margin from Software and Services | 2,120 |  |  | 1,844 |  |  | 15 | % |
| Gross margin | $ | 6,035 |  |  | $ | 5,512 |  |  | 9 | % |

[0000068505-26-000010:mdna:94]
Gross margin was 51.7% of net sales in 2025 compared to 51.0% of net sales in 2024. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-26-000010:mdna:95]
•a 1.0% increase in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales and expanded margins, including favorable mix; and

[0000068505-26-000010:mdna:96]
•a 0.7% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales and lower direct material costs, despite higher tariffs.

[0000068505-26-000010:mdna:97]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-26-000010:mdna:98]
|  | Years ended December 31 |
| (In millions) | 2025 |  | 2024 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 1,478 |  |  | $ | 1,392 |  |  | 6 | % |
| SG&A expenses from Software and Services | 392 |  |  | 360 |  |  | 9 | % |
| SG&A expenses | $ | 1,870 |  |  | $ | 1,752 |  |  | 7 | % |

[0000068505-26-000010:mdna:99]
SG&A expenses increased $118 million, or 7% in 2025 compared to 2024 primarily due to:

[0000068505-26-000010:mdna:100]
•an $86 million, or 6% increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share-based compensation and investments in video, and higher expenses associated with acquired businesses, partially offset by lower expenses related to legal matters, including Hytera-related legal expenses; and

[0000068505-26-000010:mdna:101]
•a $32 million, or 9% increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses and employee incentive costs, partially offset by lower expenses related to legal matters.

[0000068505-26-000010:mdna:102]
SG&A expenses were 16.0% of net sales in 2025 compared to 16.2% of net sales in 2024.

[0000068505-26-000010:mdna:103]
Research and Development ("R&D") Expenditures

[0000068505-26-000010:mdna:104]
|  | Years ended December 31 |
| (In millions) | 2025 |  | 2024 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 598 |  |  | $ | 575 |  |  | 4 | % |
| R&D expenditures from Software and Services | 372 |  |  | 342 |  |  | 9 | % |
| R&D expenditures | $ | 970 |  |  | $ | 917 |  |  | 6 | % |

[0000068505-26-000010:mdna:105]
R&D expenditures increased $53 million, or 6% in 2025 compared to 2024 primarily due to:

[0000068505-26-000010:mdna:106]
•a $30 million, or 9% increase in Software and Services R&D expenditures primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses; and

[0000068505-26-000010:mdna:107]
•a $23 million, or 4% increase in Products and Systems Integration R&D expenditures primarily due to higher employee incentive costs and higher expenses associated with acquired businesses.

[0000068505-26-000010:mdna:108]
R&D expenditures were 8.3% of net sales in 2025 and 8.5% of net sales in 2024.

[0000068505-26-000010:mdna:109]
Other Charges

[0000068505-26-000010:mdna:110]
|  | Years ended December 31 |  |  |
| (In millions) | 2025 |  | 2024 |  |  |
| Other charges from Products and Systems Integration | $ | 78 |  |  | $ | 25 |  |  |  |
| Other charges from Software and Services | 129 |  |  | $ | 130 |  |  |  |
| Other charges | $ | 207 |  |  | $ | 155 |  |  |  |

[0000068505-26-000010:mdna:111]
Other charges increased $52 million, or 34% in 2025 compared to 2024 due to a $53 million, or 212% increase in Products and System Integration and a $1 million, or 1% decrease in Software and Services. The increase was primarily driven by:

[0000068505-26-000010:mdna:112]
•$234 million of intangible asset amortization expense in 2025 compared to $152 million of intangible asset amortization expense in 2024, an increase primarily due to amortization of intangible assets from the acquisition of Silvus;

[0000068505-26-000010:mdna:113]
•$66 million of acquisition-related transaction fees in 2025, primarily due to the acquisition of Silvus, compared to $20 million of acquisition-related transaction fees in 2024;

[0000068505-26-000010:mdna:114]
•$44 million of reorganization of business expenses in 2025 compared to $26 million of reorganization of business expenses in 2024; and

[0000068505-26-000010:mdna:115]
•$15 million of legal settlements in 2025 compared to $7 million of legal settlements in 2024; partially offset by

[0000068505-26-000010:mdna:116]
•$157 million of gains on the Hytera litigation in 2025 compared to $61 million of gains in 2024 for the amounts recovered through legal proceedings due to theft of our trade secrets (see "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information).

[0000068505-26-000010:mdna:117]
Operating Earnings

[0000068505-26-000010:mdna:118]
|  | Years ended December 31 |  |  |
| (In millions) | 2025 |  | 2024 |  |  |
| Operating earnings from Products and Systems Integration | $ | 1,761 |  |  | $ | 1,676 |  |  |  |
| Operating earnings from Software and Services | 1,227 |  |  | 1,012 |  |  |  |
| Operating earnings | $ | 2,988 |  |  | $ | 2,688 |  |  |  |

[0000068505-26-000010:mdna:119]
Operating earnings increased $300 million, or 11% in 2025 compared to 2024. The increase in operating earnings was due to:

[0000068505-26-000010:mdna:120]
•a $215 million increase in the Software and Services segment from 2024 to 2025, primarily driven by higher sales, expanded margins, including favorable mix, improved operating leverage and lower expenses related to legal matters, partially offset by higher expenses associated with acquired businesses and higher employee incentive costs, including share-based compensation; and

[0000068505-26-000010:mdna:121]
•a $85 million increase in the Products and Systems Integration segment from 2024 to 2025, primarily driven by higher sales, a gain on the Hytera litigation (for further information regarding the Hytera litigation, refer to “Hytera Civil Litigation” within "Note 12: Commitments and Contingencies" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K), improved gross margins driven by lower direct material costs, despite higher tariffs, partially offset by higher employee incentive costs, including share-based compensation and investments in video, an increase in intangible amortization expense, an increase in acquisition related transaction fees, primarily related to the Silvus acquisition, and higher expenses associated with acquired businesses.

[0000068505-26-000010:mdna:122]
Interest Expense, net

[0000068505-26-000010:mdna:123]
|  | Years ended December 31 |  |  |
| (In millions) | 2025 |  | 2024 |  |  |
| Interest expense, net | $ | (302) |  |  | $ | (227) |  |  |  |

[0000068505-26-000010:mdna:124]
The $75 million increase in net interest expense in 2025 compared to 2024 was primarily driven by higher outstanding debt partially offset by interest accruals related to audits with taxing authorities in foreign jurisdictions in 2024, which did not recur in 2025.

[0000068505-26-000010:mdna:125]
Other, net

[0000068505-26-000010:mdna:126]
|  | Years ended December 31 |
| (In millions) | 2025 |  | 2024 |
| Other, net | $ | 126 |  |  | $ | (489) |  |

[0000068505-26-000010:mdna:127]
The $615 million change in Other, net income in 2025 compared to Other, net expense in 2024 was primarily due to:

[0000068505-26-000010:mdna:128]
•$585 million of loss from the extinguishment of the $1.0 billion of 1.75% senior convertible notes issued to Silver Lake Partners (the "Silver Lake Convertible Debt") which was recognized in 2024 and did not recur in 2025;

[0000068505-26-000010:mdna:129]
•$42 million of gains on derivatives in 2025 compared to $19 million of losses on derivatives in 2024;

[0000068505-26-000010:mdna:130]
•$19 million of gains on fair value adjustments to equity investments in 2025 compared to $5 million of losses on fair value adjustments to equity investments in 2024; and

[0000068505-26-000010:mdna:131]
•$11 million of losses on assessments of uncertain tax positions recognized in 2024 that did not recur in 2025; partially offset by

[0000068505-26-000010:mdna:132]
•$55 million of foreign currency losses in 2025 compared to $2 million of foreign currency gains in 2024; and

[0000068505-26-000010:mdna:133]
•$124 million of net periodic pension and postretirement benefit in 2025 compared to $132 million of net periodic pension and postretirement benefit in 2024.

[0000068505-26-000010:mdna:134]
Effective Tax Rate

[0000068505-26-000010:mdna:135]
|  | Years ended December 31 |  |
| (In millions) | 2025 |  | 2024 |  |
| Income tax expense | $ | 652 |  |  | $ | 390 |  |  |

[0000068505-26-000010:mdna:136]
Income tax expense increased by $262 million in 2025 compared to 2024, for an effective tax rate of 23.2%, which is higher than the current U.S. federal statutory rate of 21% primarily due to $80 million of tax expense for estimated 2025 U.S. state income taxes, partially offset by $38 million of benefits due to the recognition of excess tax benefits on share-based compensation.

[0000068505-26-000010:mdna:137]
Our effective tax rate in 2024 was 19.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-26-000010:mdna:138]
•$113 million benefit from our decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards on our 2023 U.S. tax return and current year generation of foreign tax credits;

[0000068505-26-000010:mdna:139]
•$99 million benefit from the foreign derived intangible income deduction inclusive of a higher foreign derived intangible income deduction on our 2023 U.S. tax return due to our decision to implement a business initiative in 2024;

[0000068505-26-000010:mdna:140]
•$35 million benefit from the recognition of excess tax benefits on share-based compensation; and

[0000068505-26-000010:mdna:141]
•$22 million benefit from the generation of U.S. federal research and development tax credits; partially offset by

[0000068505-26-000010:mdna:142]
•$124 million tax expense due to the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt; and

[0000068505-26-000010:mdna:143]
•$81 million tax expense for estimated 2024 U.S. state income taxes.

[0000068505-26-000010:mdna:144]
Our 2024 reconciliation between our effective tax rate and the U.S. federal statutory rate has been revised as a result of our election to apply the retrospective transition method of ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," with descriptions now presented to align with the new disclosure requirements. For further information, see "Note 7: Income Taxes" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-26-000010:mdna:145]
Results of Operations—2024 Compared to 2023

[0000068505-26-000010:mdna:146]
Net Sales

[0000068505-26-000010:mdna:147]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| Net sales from Products and Systems Integration | $ | 6,883 |  |  | $ | 6,242 |  |  | 10 | % |
| Net sales from Software and Services | 3,934 |  |  | 3,736 |  |  | 5 | % |
| Net sales | $ | 10,817 |  |  | $ | 9,978 |  |  | 8 | % |

[0000068505-26-000010:mdna:148]
The Products and Systems Integration segment’s net sales represented 64% of our net sales in 2024, compared to 63% of our net sales in 2023. The Software and Services segment’s net sales represented 36% of our net sales in 2024, compared to 37% of our net sales in 2023.

[0000068505-26-000010:mdna:149]
Net sales increased by $839 million, or 8%, in 2024 compared to 2023. The 10% increase in net sales within the Products and Systems Integration segment was driven by a 13% increase in the North America region and a 3% increase in the International region. The 5% increase in the Software and Services segment was driven by a 12% increase in the North America region partially offset by an 8% decline within the International region. The increase in net sales included:

[0000068505-26-000010:mdna:150]
•an increase in the Products and Systems Integration segment, inclusive of $43 million of revenue from acquisitions, driven by growth in MCN and Video;

[0000068505-26-000010:mdna:151]
•an increase in the Software and Services segment, inclusive of $52 million of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by MCN due to the revenue reduction on Airwave services in accordance with the legal order imposed by the Competition and Markets Authority (CMA) which implemented a prospective price control on Airwave (the "Charge Control") and the Company's exit of the Emergency Services Network contract with the Home Office in 2022, inclusive of twelve months of transition services through the end of 2023 (the "ESN Exit"); and

[0000068505-26-000010:mdna:152]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-26-000010:mdna:153]
Regional results included:

[0000068505-26-000010:mdna:154]
•a 13% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in MCN, Video and Command Center; and

[0000068505-26-000010:mdna:155]
•a 2% decline in the International region, inclusive of revenue from acquisitions, driven by the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by growth in MCN, Video and Command Center.

[0000068505-26-000010:mdna:156]
Products and Systems Integration

[0000068505-26-000010:mdna:157]
The 10% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-26-000010:mdna:158]
•a $612 million, or 12% growth in MCN, driven by both the North America and International regions;

[0000068505-26-000010:mdna:159]
•a $29 million, or 3% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-26-000010:mdna:160]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-26-000010:mdna:161]
Software and Services

[0000068505-26-000010:mdna:162]
The 5% increase in the Software and Services segment was driven by the following:

[0000068505-26-000010:mdna:163]
•a $165 million, or 27% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-26-000010:mdna:164]
•a $71 million, or 10% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions; partially offset by

[0000068505-26-000010:mdna:165]
•a $38 million, or 2% decrease in MCN, driven by the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by an increase in both the North America and International regions.

[0000068505-26-000010:mdna:166]
42

[0000068505-26-000010:mdna:167]
Gross Margin

[0000068505-26-000010:mdna:168]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 3,668 |  |  | $ | 3,127 |  |  | 17 | % |
| Gross margin from Software and Services | 1,844 |  |  | 1,843 |  |  | — | % |
| Gross margin | $ | 5,512 |  |  | $ | 4,970 |  |  | 11 | % |

[0000068505-26-000010:mdna:169]
Gross margin was 51.0% of net sales in 2024 compared to 49.8% of net sales in 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-26-000010:mdna:170]
•a 3.2% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, favorable mix and lower direct material costs; partially offset by

[0000068505-26-000010:mdna:171]
•a 2.4% decrease in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, driven by the revenue reduction on Airwave services in accordance with the Charge Control.

[0000068505-26-000010:mdna:172]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-26-000010:mdna:173]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 1,392 |  |  | $ | 1,239 |  |  | 12 | % |
| SG&A expenses from Software and Services | 360 |  |  | 322 |  |  | 12 | % |
| SG&A expenses | $ | 1,752 |  |  | $ | 1,561 |  |  | 12 | % |

[0000068505-26-000010:mdna:174]
SG&A expenses increased $191 million, or 12% in 2024 compared to 2023 primarily due to:

[0000068505-26-000010:mdna:175]
•a $153 million, or 12% increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters, including Hytera-related legal expenses; and

[0000068505-26-000010:mdna:176]
•a $38 million, or 12% increase in Software and Services SG&A expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters.

[0000068505-26-000010:mdna:177]
SG&A expenses were 16.2% of net sales in 2024 compared to 15.6% of net sales in 2023.

[0000068505-26-000010:mdna:178]
Research and Development ("R&D") Expenditures

[0000068505-26-000010:mdna:179]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 575 |  |  | $ | 551 |  |  | 4 | % |
| R&D expenditures from Software and Services | 342 |  |  | 307 |  |  | 11 | % |
| R&D expenditures | $ | 917 |  |  | $ | 858 |  |  | 7 | % |

[0000068505-26-000010:mdna:180]
R&D expenditures increased $59 million, or 7% in 2024 compared to 2023 primarily due to:

[0000068505-26-000010:mdna:181]
•a $35 million, or 11% increase in Software and Services R&D expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses; and

[0000068505-26-000010:mdna:182]
•a $24 million, or 4% increase in Products and Systems Integration R&D expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses.

[0000068505-26-000010:mdna:183]
R&D expenditures were 8.5% of net sales in 2024 and 8.6% of net sales in 2023.

[0000068505-26-000010:mdna:184]
Other Charges

[0000068505-26-000010:mdna:185]
|  | Years ended December 31 |  |
| (In millions) | 2024 |  | 2023 |  |
| Other charges from Products and Systems Integration | $ | 25 |  |  | $ | 94 |  |  |
| Other charges from Software and Services | 130 |  |  | 163 |  |  |
| Other charges | $ | 155 |  |  | $ | 257 |  |  |

[0000068505-26-000010:mdna:186]
Other charges decreased $102 million, or 40% in 2024 compared to 2023 due to a $69 million, or 73% decrease in Products and Systems Integration and a $33 million, or 20% decrease in Software and Services. The decrease was primarily due to:

[0000068505-26-000010:mdna:187]
•$61 million of gains on the Hytera litigation in 2024 for the amounts recovered through legal proceedings due to theft of our trade secrets that did not occur in 2023 (see "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information);

[0000068505-26-000010:mdna:188]
•$152 million of intangible asset amortization expense in 2024 compared to $177 million of intangible asset amortization expense in 2023;

[0000068505-26-000010:mdna:189]
•$24 million of impairment loss related to the exit of video manufacturing operations in 2023 that did not occur in 2024 (see "Property, Plant and Equipment, Net" within "Note 4: Other Financial Data" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information); and

[0000068505-26-000010:mdna:190]
•$2 million of environmental reserve expense in 2024 compared to $15 million in 2023; partially offset by

[0000068505-26-000010:mdna:191]
•$20 million of acquisition-related transaction fees in 2024 compared to $7 million of acquisition-related transaction fees.

[0000068505-26-000010:mdna:192]
Operating Earnings

[0000068505-26-000010:mdna:193]
|  | Years ended December 31 |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Operating earnings from Products and Systems Integration | $ | 1,676 |  |  | $ | 1,244 |  |  |  |
| Operating earnings from Software and Services | 1,012 |  |  | 1,050 |  |  |  |
| Operating earnings | $ | 2,688 |  |  | $ | 2,294 |  |  |  |

[0000068505-26-000010:mdna:194]
Operating earnings increased $394 million, or 17% in 2024 compared to 2023. The increase in Operating earnings was due to:

[0000068505-26-000010:mdna:195]
•a $432 million increase in the Products and Systems Integration segment from 2023 to 2024, primarily driven by higher sales, favorable mix and a gain on the Hytera litigation (for further information regarding the Hytera litigation, refer to “Hytera Civil Litigation” within "Note 12: Commitments and Contingencies" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K), partially offset by higher employee incentive costs, including share-based compensation, higher expenses related to legal matters, including Hytera related expenses, and higher expenses associated with acquired businesses; partially offset by

[0000068505-26-000010:mdna:196]
•a $38 million decrease in the Software and Services segment from 2023 to 2024, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control, higher employee incentive costs, including share-based compensation, higher expenses associated with acquired businesses and higher expenses related to legal matters, partially offset by higher sales and a reduction in intangible amortization expenses.

[0000068505-26-000010:mdna:197]
Interest Expense, net

[0000068505-26-000010:mdna:198]
|  | Years ended December 31 |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Interest expense, net | $ | (227) |  |  | $ | (216) |  |  |  |

[0000068505-26-000010:mdna:199]
The $11 million increase in net interest expense in 2024 compared to 2023 was primarily driven by higher interest rates on outstanding debt and an interest accrual related to audits with taxing authorities in foreign jurisdictions, partially offset by higher interest income.

[0000068505-26-000010:mdna:200]
Other, net

[0000068505-26-000010:mdna:201]
|  | Years ended December 31 |  |
| (In millions) | 2024 |  | 2023 |  |
| Other, net | $ | (489) |  |  | $ | 68 |  |  |

[0000068505-26-000010:mdna:202]
The $557 million change in Other, net expense in 2024 compared to Other, net income 2023 was primarily due to:

[0000068505-26-000010:mdna:203]
•$585 million of loss from the extinguishment of the Silver Lake Convertible Debt which was recognized in 2024;

[0000068505-26-000010:mdna:204]
•$19 million of losses on derivatives in 2024 compared to $20 million of gains on derivatives in 2023;

[0000068505-26-000010:mdna:205]
•$5 million of losses on fair value adjustments to equity investments in 2024 compared to an $13 million of gains on fair value adjustments to equity investments in 2023; and

[0000068505-26-000010:mdna:206]
•$11 million of losses on assessments of uncertain tax positions recognized in 2024; partially offset by

[0000068505-26-000010:mdna:207]
•$2 million of foreign currency gains in 2024 compared to $53 million of foreign currency losses in 2023;

[0000068505-26-000010:mdna:208]
•$132 million of net periodic pension and postretirement benefit in 2024 compared to $99 million of net periodic pension and postretirement benefit in 2023; and

[0000068505-26-000010:mdna:209]
•$3 million of investment impairments in 2024 compared to $16 million of investment impairments in 2023.

[0000068505-26-000010:mdna:210]
Effective Tax Rate

[0000068505-26-000010:mdna:211]
|  | Years ended December 31 |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Income tax expense | $ | 390 |  |  | $ | 432 |  |  |  |

[0000068505-26-000010:mdna:212]
Income tax expense decreased by $42 million in 2024 compared to 2023, for an effective tax rate of 19.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-26-000010:mdna:213]
•$113 million benefit from our decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards on our 2023 U.S. tax return and current year generation of foreign tax credits;

[0000068505-26-000010:mdna:214]
•$99 million benefit from the foreign derived intangible income deduction inclusive of a higher foreign derived intangible income deduction on our 2023 U.S. tax return due to our decision to implement a business initiative in 2024;

[0000068505-26-000010:mdna:215]
•$35 million benefit from the recognition of excess tax benefits on share-based compensation; and

[0000068505-26-000010:mdna:216]
•$22 million benefit from the generation of U.S. federal research and development tax credits; partially offset by

[0000068505-26-000010:mdna:217]
•$124 million tax expense due to the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt; and

[0000068505-26-000010:mdna:218]
•$81 million tax expense for estimated 2024 U.S. state income taxes.

[0000068505-26-000010:mdna:219]
Our effective tax rate in 2023 was 20.1%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-26-000010:mdna:220]
•$38 million benefit from the foreign derived intangible income deduction;

[0000068505-26-000010:mdna:221]
•$29 million benefit from the recognition of excess tax benefits on share-based compensation; and

[0000068505-26-000010:mdna:222]
•$19 million benefit from the generation of U.S. federal research and development tax credits; partially offset by

[0000068505-26-000010:mdna:223]
•$62 million tax expense for estimated 2023 U.S. state income taxes.

[0000068505-26-000010:mdna:224]
The information set forth above in "Effective Tax Rate" has been revised to reflect our election to apply the retrospective transition method of ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosure."

[0000068505-26-000010:mdna:225]
45

[0000068505-26-000010:mdna:226]
Reorganization of Businesses

[0000068505-26-000010:mdna:227]
In 2025, we recorded net reorganization of business charges of $60 million relating to the separation of 830 employees, of which 590 were direct employees and 240 were indirect employees. The $60 million of charges included $16 million of charges in Cost of sales and $44 million of charges in Other charges. Included in the $60 million were charges of $62 million related to employee separation costs and $2 million related to exit costs, partially offset by $4 million of reversals for employee separation accruals no longer needed.

[0000068505-26-000010:mdna:228]
During 2024, we recorded net reorganization of business charges of $38 million relating to the separation of 720 employees, of which 460 were direct employees and 260 were indirect employees. The $38 million of charges included $12 million of charges in Cost of sales and $26 million of charges in Other charges. Included in the $38 million were charges of $48 million related to employee separation costs, partially offset by $6 million of reversals for employee separation accruals no longer needed and $4 million of reversals for exit cost accruals no longer needed.

[0000068505-26-000010:mdna:229]
During 2023, we recorded net reorganization of business charges of $53 million relating to the separation of 700 employees, of which 420 were direct employees and 280 were indirect employees. The $53 million of charges included $7 million of charges in Cost of sales and $46 million of charges in Other charges. Included in the aggregate $53 million were charges of $41 million related to employee separation costs and a $24 million impairment loss related to the exit of video manufacturing operations, partially offset by $7 million of reversals for employee separation accruals no longer needed and $5 million of reversals for exit cost accruals no longer needed.

[0000068505-26-000010:mdna:230]
The following table displays the net charges incurred by business segment due to such reorganizations:

[0000068505-26-000010:mdna:231]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| Products and Systems Integration | $ | 42 |  |  | $ | 32 |  |  | $ | 45 |  |
| Software and Services | 18 |  |  | 6 |  |  | 8 |  |
|  | $ | 60 |  |  | $ | 38 |  |  | $ | 53 |  |

[0000068505-26-000010:mdna:232]
Cash payments for employee severance in connection with the reorganization of business plans were $61 million, $38 million, and $37 million in 2025, 2024, and 2023, respectively. The reorganization of business accruals for employee separation costs at December 31, 2025 were $24 million which we expect to pay within one year.

[0000068505-26-000010:mdna:233]
At January 1, 2025, we had an accrual of $1 million for exit costs related to our exit of the ESN contract with the Home Office. During the year, we used $1 million reflecting related cash payments.

[0000068505-26-000010:mdna:234]
Liquidity and Capital Resources

[0000068505-26-000010:mdna:235]
|  | Years Ended December 31 |
|  | 2025 |  | 2024 |  | 2023 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 2,837 |  |  | $ | 2,391 |  |  | $ | 2,044 |  |
| Investing activities | (5,164) |  |  | (507) |  |  | (414) |  |
| Financing activities | 1,309 |  |  | (1,448) |  |  | (1,295) |  |
| Effect of exchange rates on cash and cash equivalents | 81 |  |  | (39) |  |  | 45 |  |
| Increase (decrease) in cash and cash equivalents | $ | (937) |  |  | $ | 397 |  |  | $ | 380 |  |

[0000068505-26-000010:mdna:236]
Cash and Cash Equivalents

[0000068505-26-000010:mdna:237]
At December 31, 2025, $832 million of our $1.2 billion cash and cash equivalents balance was held in the U.S. and $333 million was held in other countries. Restricted cash was $2 million as of December 31, 2025 and $3 million as of December 31, 2024.

[0000068505-26-000010:mdna:238]
We routinely repatriate a portion of non-U.S. earnings each year. We have recorded income tax expense for foreign withholding tax and distribution taxes on such earnings and, under current U.S. tax laws, do not expect to incur material incremental U.S. tax on repatriation.

[0000068505-26-000010:mdna:239]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay due to local country approvals.

[0000068505-26-000010:mdna:240]
Operating Activities

[0000068505-26-000010:mdna:241]
The increase in operating cash flows from both 2023 to 2024 and 2024 to 2025 was primarily driven by higher earnings, net of non-cash charges.

[0000068505-26-000010:mdna:242]
Investing Activities

[0000068505-26-000010:mdna:243]
The increase in net cash used for investing activities from 2024 to 2025 was primarily due to:

[0000068505-26-000010:mdna:244]
•$4.6 billion increase in acquisitions and investments in 2025 compared to 2024, primarily driven by the acquisition of Silvus for $4.4 billion;

[0000068505-26-000010:mdna:245]
•$23 million decrease in proceeds from the sale of investments in 2025 compared to 2024; and

[0000068505-26-000010:mdna:246]
•$8 million increase in capital expenditures in 2025 compared to 2024.

[0000068505-26-000010:mdna:247]
The increase in net cash used for investing activities from 2023 to 2024 was primarily due to:

[0000068505-26-000010:mdna:248]
•$110 million increase in acquisitions and investments in 2024 compared to 2023; and

[0000068505-26-000010:mdna:249]
•$4 million increase in capital expenditures in 2024 compared to 2023; partially offset by

[0000068505-26-000010:mdna:250]
•$21 million increase in proceeds from the sale of investments in 2024 compared to 2023.

[0000068505-26-000010:mdna:251]
Financing Activities

[0000068505-26-000010:mdna:252]
The increase in cash flows provided by financing activities in 2025 compared to cash used for financing activities in 2024 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" in this section below):

[0000068505-26-000010:mdna:253]
•$1.6 billion decrease in repayments of debt primarily driven by the repayment of our 7.5% and 6.5% debentures in 2025 compared to the repurchase of the Silver Lake Convertible Debt and repayment of our 4.0% senior notes due 2024; and

[0000068505-26-000010:mdna:254]
•$2.7 billion in net proceeds from the issuance of debt in 2025 driven by the issuance of debt to fund a portion of the acquisition of Silvus, including the 4.85% senior notes due 2030, 5.2% senior notes due 2032, 5.55% senior notes due 2035 and our three-year delayed draw term loan ("term loan due 2028"), compared to $1.3 billion in net proceeds from the issuance of debt in 2024 driven by the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; and

[0000068505-26-000010:mdna:255]
•$923 million in net proceeds from short-term borrowings, including commercial paper, in 2025 which was used to fund a portion of the acquisition of Silvus, including our 364-day delayed draw term loan; partially offset by

[0000068505-26-000010:mdna:256]
•$1.2 billion used for purchases under our share repurchase program in 2025 compared to $247 million in 2024;

[0000068505-26-000010:mdna:257]
•$179 million cash used for the repayment of short-term borrowings, including commercial paper;

[0000068505-26-000010:mdna:258]
•$728 million cash used for the payment of dividends in 2025 compared to $654 million in 2024; and

[0000068505-26-000010:mdna:259]
•$46 million in proceeds from the issuance of common stock, net of tax, in connection with our employee stock option and employee stock purchase plans in 2025 compared to $75 million in 2024.

[0000068505-26-000010:mdna:260]
The increase in cash used for financing activities in 2024 compared to cash used for financing activities in 2023 was driven by:

[0000068505-26-000010:mdna:261]
•$1.9 billion increase in repayments of debt in 2024 primarily driven by the repurchase of the Silver Lake Convertible Debt and repayment of our 4.0% senior notes due 2024;

[0000068505-26-000010:mdna:262]
•$654 million cash used for the payment of dividends in 2024 compared to $589 million in 2023; and

[0000068505-26-000010:mdna:263]
•$75 million in proceeds from the issuance of common stock, net of tax, in connection with our employee stock option and employee stock purchase plans in 2024 compared to $104 million in 2023; partially offset by

[0000068505-26-000010:mdna:264]
•$1.3 billion in net proceeds in 2024 driven by the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; and

[0000068505-26-000010:mdna:265]
•$247 million used for purchases under our share repurchase program in 2024 compared to $804 million in 2023.

[0000068505-26-000010:mdna:266]
Sales of Receivables

[0000068505-26-000010:mdna:267]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-26-000010:mdna:268]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2025, 2024, and 2023:

[0000068505-26-000010:mdna:269]
| Years ended December 31 | 2025 |  | 2024 |  | 2023 |
| Accounts receivable sales proceeds | $ | 156 |  |  | $ | 15 |  |  | $ | 96 |  |
| Long-term receivables sales proceeds | 258 |  |  | 205 |  |  | 182 |  |
| Total proceeds from receivable sales | $ | 414 |  |  | $ | 220 |  |  | $ | 278 |  |

[0000068505-26-000010:mdna:270]
At December 31, 2025, the Company had retained servicing obligations for $814 million of long-term receivables, compared to $794 million of long-term receivables at December 31, 2024. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-26-000010:mdna:271]
Debt

[0000068505-26-000010:mdna:272]
We had outstanding debt of $9.2 billion and $6.0 billion at December 31, 2025 and 2024, respectively, of which $749 million and $322 million was current, at December 31, 2025 and December 31, 2024, respectively.

[0000068505-26-000010:mdna:273]
During the year ended December 31, 2025, we repaid $252 million aggregate principal amount of the 7.5% debentures due 2025 and $70 million aggregate principal amount of the 6.5% debentures due 2025. Furthermore, during the year ended December 31, 2025 we borrowed and repaid $179 million of short-term borrowings, including commercial paper which had a weighted-average interest rate of 4.29%.

[0000068505-26-000010:mdna:274]
On June 16, 2025, we issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032 and $900 million of 5.55% senior notes due 2035. We recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-26-000010:mdna:275]
On August 6, 2025, we borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a 750 million 364-day facility and a $750 million term loan due 2028 to fund a portion of the acquisition of Silvus. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. We were in compliance with our financial covenants as of December 31, 2025. During the year ended December 31, 2025, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 5.10% and 5.25%, respectively. As of December 31, 2025, $749 million of the 364-day term loan was presented as short-term borrowings within the Company's Consolidated Balance Sheets. Subsequent to year-end, on January 30, 2026, we repaid $200 million of the $750 million principal amount of the 364-day term loan, reducing the outstanding principal balance to $550 million.

[0000068505-26-000010:mdna:276]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue the Silver Lake Convertible Debt, which became fully convertible on September 5, 2021. On February 14, 2024, we agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded upon settlement, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Consolidated Statements of Operations during the year ended December 31, 2024.

[0000068505-26-000010:mdna:277]
We have an unsecured commercial paper program, backed by the revolving credit facility described below, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2025, we had no outstanding debt under the commercial paper program.

[0000068505-26-000010:mdna:278]
Credit Facilities

[0000068505-26-000010:mdna:279]
On April 25, 2025, we entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced our $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2025.

[0000068505-26-000010:mdna:280]
We have investment grade ratings on our senior unsecured long-term debt. During the year ended December 31, 2025, Fitch Ratings and S&P Global Ratings reaffirmed our BBB credit ratings, and Moody's Investors Service reaffirmed our Baa2 credit rating. We continue to believe that we will be able to maintain sufficient access to the capital markets in the next twelve months and the foreseeable future.

[0000068505-26-000010:mdna:281]
Share Repurchase Program

[0000068505-26-000010:mdna:282]
Through a series of actions, the Board of Directors has authorized an aggregate share repurchase amount of up to $18.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2025, we used approximately $16.9 billion of the share repurchase authority to repurchase shares, leaving approximately $1.1 billion of authority available for future repurchases. During the year ended December 31, 2024, we paid $3 million of 1% excise tax pursuant to the Inflation Reduction Act of 2022, related to our 2023 share repurchases in excess of issuances.

[0000068505-26-000010:mdna:283]
Our share repurchases for 2025, 2024, and 2023 are summarized as follows:

[0000068505-26-000010:mdna:284]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2025 | 2.7 |  |  | $ | 420.21 |  |  | $ | 1,154 |  |
| 2024 | 0.6 |  |  | 396.69 |  |  | 244 |  |
| 2023 | 2.9 |  |  | 278.56 |  |  | 804 |  |

[0000068505-26-000010:mdna:285]
Dividends

[0000068505-26-000010:mdna:286]
We paid cash dividends to holders of our common stock of $728 million in 2025, $654 million in 2024, and $589 million in 2023. On January 15, 2026, we paid an additional $201 million in cash dividends to holders of our common stock.

[0000068505-26-000010:mdna:287]
Adequate Internal Funding Resources

[0000068505-26-000010:mdna:288]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2025 Motorola Solutions Credit Agreement.

[0000068505-26-000010:mdna:289]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer also to "Part I. Item 1A. Risk Factors" of this Form 10-K for further discussion regarding access to the capital markets.

[0000068505-26-000010:mdna:290]
Material Cash Requirements from Contractual and Other Obligations

[0000068505-26-000010:mdna:291]
Summarized in the table and text below are our short-term (within the next twelve months) and long-term material cash requirements as of December 31, 2025, which we expect to fund with a combination of operating cash flows, existing cash balances or, as needed, borrowings under new or existing debt:

[0000068505-26-000010:mdna:292]
|  | Payments Due by Period |
| (in millions) |  | Short-term |  | Long-term |
| Debt obligations, gross(1) |  | $ | 750 |  |  | $ | 8,476 |  |
| Lease obligations(2) |  | 155 |  |  | 521 |  |
| Purchase obligations(3) |  | 250 |  |  | 521 |  |
| Total obligations |  | $ | 1,155 |  |  | $ | 9,518 |  |

[0000068505-26-000010:mdna:293]
(1)Amounts included represent the estimated principal payments applicable to outstanding debt. Refer to "Note 5: Debt and Credit Facilities" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for discussion related to our long-term debt obligations.

[0000068505-26-000010:mdna:294]
(2)We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. We are evaluating our real estate needs in order to identify opportunities to reduce long-term cash requirements for office space where practicable. Refer to "Note 3: Leases" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further discussion of these material lease obligations.

[0000068505-26-000010:mdna:295]
(3)Amounts included represent firm, non-cancelable commitments. Such commitments include license agreements and agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. We do not anticipate the cancellation of any of our take-or-pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-26-000010:mdna:296]
Other Contingencies

[0000068505-26-000010:mdna:297]
Potential Contractual Damage Claims in Excess of Underlying Contract Value: In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-26-000010:mdna:298]
Indemnification Provisions: We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us.

[0000068505-26-000010:mdna:299]
Legal Matters: We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on our results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-26-000010:mdna:300]
Long-term Customer Financing Commitments

[0000068505-26-000010:mdna:301]
Outstanding Commitments: Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $179 million at December 31, 2025 and $105 million at December 31, 2024.

[0000068505-26-000010:mdna:302]
Critical Accounting Estimates

[0000068505-26-000010:mdna:303]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-26-000010:mdna:304]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. We believe that the following discussion addresses our most critical accounting estimates, which are those that are most important to the portrayal of our financial condition and results of operations and require management’s most difficult, subjective and complex judgments.

[0000068505-26-000010:mdna:305]
Revenue Recognition

[0000068505-26-000010:mdna:306]
We enter into arrangements which generally consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We use list price as the standalone selling price for sales sold through our channel partners. Given the unique nature of the goods and services we provide to direct customers, standalone sales of our products generally do not exist. Therefore, we determine ESP by: (i) collecting all reasonably available data points including historical sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points for similar customers and circumstances, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-26-000010:mdna:307]
We account for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-26-000010:mdna:308]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs to Complete”). Estimated Costs to Complete include direct labor, equipment and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs to Complete may be complex and subject to many variables. We have a standard and disciplined process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs to Complete. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor costs, inclusive of subcontractors, and the cost of materials, among other variables. Based on this analysis, any adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-26-000010:mdna:309]
Retirement Benefits

[0000068505-26-000010:mdna:310]
Our benefit obligations and net periodic pension costs (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits Plan”), are determined using actuarial assumptions. The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-26-000010:mdna:311]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases. As such, depending on the specific plan, we amortize gains and losses over periods ranging from eight to twenty-five years. Prior service costs are being amortized over periods ranging from fourteen to twenty-four years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-26-000010:mdna:312]
There are various assumptions used in calculating the net periodic costs (benefits) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns. We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-26-000010:mdna:313]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost (benefit) and the net postretirement health care benefit. Our investment return assumption for the U.S. Pension Benefit Plans was 8.01% in 2025 and 7.74% in 2024. Our investment return assumption for the Postretirement Health Care Benefits Plan was 8.55% in 2025 and 8.30% in 2024. Our weighted average investment return assumption for the Non-U.S. Plans was 6.29% in 2025 and 5.84% in 2024. For the U.S. and Non-U.S. Pension Benefit plans, a 25 bps change in expected return on plan assets would result in a $9 million and $4 million, respectively, change in net period pension benefit in 2025. For the Postretirement Health Care Benefits Plan, a 25 bps change in expected return on plan assets would have a de minimis impact to net periodic pension benefit in 2025.

[0000068505-26-000010:mdna:314]
A second key assumption is the discount rate. The discount rate assumptions used for the U.S. Pension Benefit Plans, the Non-U.S. Plans and the Postretirement Health Care Benefits Plan reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our weighted average discount rates for measuring our U.S. Pension Benefit Plans obligations were 5.50% and 5.70% at December 31, 2025 and 2024, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 5.25% and 5.07% at December 31, 2025 and 2024, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 5.12% and 5.49% at December 31, 2025 and 2024, respectively.

[0000068505-26-000010:mdna:315]
For the U.S. Pension Benefit Plans, a 25 bps increase in the discount rate on the projected benefit obligation would result in a $107 million reduction of the projected benefit obligation and a 25 bps decrease would result in $111 million of additional projected benefit obligation as of December 31, 2025. For the Non-U.S. Pension Benefit Plans and the Postretirement Health Care Benefits Plan, a 25 bps change in our discount rate would be de minimis as of December 31, 2025.

[0000068505-26-000010:mdna:316]
Valuation and Recoverability of Goodwill

[0000068505-26-000010:mdna:317]
We assess the recorded amount of goodwill for recovery on an annual basis as of the last day of the third quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: (i) adverse changes in macroeconomic conditions, (ii) adverse changes in the industry or market in which we transact, (iii) changes in cost factors negatively impacting earnings and cash flows, (iv) negative or declining overall financial performance, (v) events affecting the carrying value or composition of a reporting unit, or (vi) a sustained decrease in share price, among others. Any

[0000068505-26-000010:mdna:318]
such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-26-000010:mdna:319]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Software and Services segments are comprised of four and two reporting units, respectively.

[0000068505-26-000010:mdna:320]
We performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2025 and 2024. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value and entity-specific events. For fiscal years 2025 and 2024, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-26-000010:mdna:321]
Valuation of Acquired Intangible Assets

[0000068505-26-000010:mdna:322]
In connection with the acquisition of Silvus, we exercised significant judgment in determining the fair value of the acquired intangible assets. The assets and liabilities of acquired businesses are measured at their estimated fair values at the dates of acquisition. The excess of the purchase price over the estimated fair value of the net assets or liabilities acquired, including identified intangible assets, is recorded as goodwill. The determination and allocation of fair value to the assets acquired and liabilities assumed is based on various assumptions and valuation methodologies requiring considerable significant judgment in determining the estimates and assumptions used to estimate the fair values. Customer relationships were valued under the excess earnings method, which assumes that the value of intangible assets is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible assets. Developed technology and trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from it. We engaged a third-party valuation specialist to assist with the allocation of the total purchase price for the Silvus acquisition to the fair value of the net assets acquired, which required the use of several significant judgments and estimates related to the assumptions associated with the intangible assets, including the forecasted revenue growth rates, customer attrition rate, and the discount rate for customer relationships and the forecasted revenue growth rates, royalty rate, and discount rate for developed technology. We believe the significant judgments and estimates used associated with the valuation of intangible assets acquired in the Silvus acquisition are reasonable.

[0000068505-26-000010:mdna:323]
Recent Accounting Pronouncements and Recently Adopted Accounting Pronouncements

[0000068505-26-000010:mdna:324]
See “Note 1: Summary of Significant Accounting Policies” to our consolidated financial statements in “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.
