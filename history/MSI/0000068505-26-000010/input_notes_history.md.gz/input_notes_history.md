# MSI note change history — 0000068505-25-000040 → 0000068505-25-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0000068505-25-000052:note_history:1]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products ("I-Series") that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The Company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations. Hytera has made de minimis royalty payments related to the I-Series products directly to the Company between January 2025 and July 2025.
  (was, 2025-08-07, similarity 0.9353):
[0000068505-25-000040:note_history:1]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The Company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations.

- changed (2025-10-30):
[0000068505-25-000052:note_history:2]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation, turnover of Hytera assets to the Company, and injunction are currently briefed. On October 14-15, 2025, the District Court held hearings on these issues, but has not yet issued any rulings.
  (was, 2025-08-07, similarity 0.8721):
[0000068505-25-000040:note_history:2]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation and injunction are currently briefed. The District Court is seeking to schedule a hearing on these issues for sometime later in 2025.

- added (2025-10-30):
[0000068505-25-000052:note_history:3]
In 2025, Hytera made payments towards amounts awarded to the Company and owed by Hytera pursuant to court orders related to I-Series products. In the third quarter of 2025, the Company received payments of $74 million, resulting in an aggregate of $94 million of payments received in the nine months ended September 27, 2025. These payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. The Company continues to seek collection of the judgment through the ongoing legal process.

- changed (2025-10-30):
[0000068505-25-000052:note_history:4]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products ("H-Series"). On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain H-Series products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions.
  (was, 2025-08-07, similarity 0.8282):
[0000068505-25-000040:note_history:4]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings in August 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.

- added (2025-10-30):
[0000068505-25-000052:note_history:5]
The District Court held hearings in August 2024, concerning whether Hytera's currently shipping H-Series products continue to misuse the Company's trade secrets and copyrighted source code. On August 25, 2025, the District Court held Hytera in civil contempt for violation of the District Court’s royalty order and ordered Hytera to pay the Company approximately $70 million for unpaid royalties and interest for Hytera’s continued use of the Company’s trade secrets and copyrighted source code in Hytera's H-Series products. Hytera has appealed the District Court’s order to the Court of Appeals. Hytera’s appeal does not automatically stay its obligation to pay the $70 million. On October 14-15, 2025, the District Court heard arguments on whether Hytera must pay the $70 million into escrow, or directly to the Company as a payment towards amounts awarded to the Company and owed by Hytera pursuant to prior court orders, but has not yet issued a ruling.

- removed (2025-10-30):
[0000068505-25-000040:note_history:6]
On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million, and an additional payment of approximately $10 million on April 25, 2025. Both payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. Subsequent to quarter end, the Company received additional payments of approximately $41 million. The Company continues to seek collection of the judgment through the ongoing legal process.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0000068505-25-000052:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of September 27, 2025 and for the three and nine months ended September 27, 2025 and September 28, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2025-08-07, similarity 0.9346):
[0000068505-25-000040:note_history:7]
Basis of Presentation
The condensed consolidated financial statements as of June 28, 2025 and for the three and six months ended June 28, 2025 and June 29, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2025-10-30):
[0000068505-25-000052:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three and nine months ended September 27, 2025 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2025-08-07, similarity 0.8162):
[0000068505-25-000040:note_history:8]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three and six months ended June 28, 2025 are not necessarily indicative of the operating results to be expected for the full year.

- added (2025-10-30):
[0000068505-25-000052:note_history:9]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services". Within these segments the Company has three principal product lines in which the Company reports net sales: Mission Critical Networks (“MCN”), Video Security and Access Control ("Video"), and Command Center. With the acquisition of Silvus Technologies Holdings Inc. (“Silvus”) in August 2025, the Company will now report net sales from its principal product lines by combining the former Land Mobile Radio Communications and newly acquired Silvus under the new technology name Mission Critical Networks. This name change does not require any financial information to be reclassified from previous periods.

- changed (2025-10-30):
[0000068505-25-000052:note_history:10]
•MCN: Infrastructure, mobile ad-hoc network technology ("MANET"), devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software, inclusive of installation and integration, and backed by managed and support services to help assure mission-critical communications availability, security and resiliency.
  (was, 2025-08-07, similarity 0.7411):
[0000068505-25-000040:note_history:10]
•LMR Communications: Infrastructure, devices (two-way radio and broadband, including both for public safety and professional and commercial radio (PCR)) and software that enable communications, inclusive of installation and integration, backed by services, to assure availability, security and resiliency.

- changed (2025-10-30):
[0000068505-25-000052:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence ("AI")-powered analytics that enable visibility to what's happening and bring attention to what’s important to help inform decisions and actions.
  (was, 2025-08-07, similarity 0.7252):
[0000068505-25-000040:note_history:11]
•Video: Cameras (fixed, body-worn, in-vehicle), access control, sensors, infrastructure, video management, software and artificial intelligence (AI)-powered analytics that help enable visibility and bring attention to what’s important.

- added (2025-10-30):
[0000068505-25-000052:note_history:12]
•Command Center: Command center solutions and software applications, including AI-powered analytics, that unify voice, video and data from public safety agencies, enterprises and the community, enabling a broad informational view of operations and incidents to help accelerate workflows and improve the accuracy and speed of decisions.

- added (2025-10-30):
[0000068505-25-000052:note_history:13]
On August 6, 2025, the Company acquired Silvus from Silvus Technologies Group LLC (the "Seller"). Silvus designs and develops software-defined high-speed MANET technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. The purchase price of $4.4 billion consisted of cash payments of $4.4 billion, net of cash acquired customary purchase price adjustments, and contingent earnout consideration that had an estimated fair value as of the acquisition date of $38 million. Under the terms of the transaction, the Seller will have the potential to earn the contingent earnout consideration upon the achievement of certain financial targets of up to $600 million in total, comprised of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be paid in shares of common stock. This business is part of both the Products and Systems Integration segment and the Software and Services segment.

- added (2025-10-30):
[0000068505-25-000052:note_history:14]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software" to modernize the accounting for internal-use software costs. The ASU is effective for fiscal years beginning after December 15, 2027 and interim periods with annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

- added (2025-10-30):
[0000068505-25-000052:note_history:15]
In July 2025, the FASB issued ASU No. 2025-05, "Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets" to introduce a practical expedient in the estimation of expected credit losses for current accounts receivable and current contract assets. The ASU is effective for fiscal years beginning after December 15, 2025 and interim periods with annual reporting periods beginning after December 15, 2025, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its financial statements and disclosures.

- changed (2025-10-30):
[0000068505-25-000052:note_history:16]
In November 2024, the FASB issued ASU No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date," which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.
  (was, 2025-08-07, similarity 0.9282):
[0000068505-25-000040:note_history:16]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date," which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

- removed (2025-10-30):
[0000068505-25-000040:note_history:17]
The Company manages the business organizationally through two segments: “Products and Systems Integration” and “Software and Services". Within these segments the Company has three principal product lines in which the Company reports net sales: Land Mobile Radio Communications (“LMR” or “LMR Communications”), Video Security and Access Control ("Video"), and Command Center.

- removed (2025-10-30):
[0000068505-25-000040:note_history:18]
•Command Center: Command center solutions and software applications that unify voice, video and data analytics from public safety agencies, enterprises and the community to create a broad informational view to help simplify workflows and improve the accuracy and speed of decisions.

- removed (2025-10-30):
[0000068505-25-000040:note_history:19]
Subsequent to the quarter end, with the acquisition of Silvus Technologies Holdings Inc. (“Silvus”), the Company will now report net sales from its principal product lines by combining the former LMR Communications and newly acquired Silvus under the new technology name Mission Critical Networks (MCN).

- removed (2025-10-30):
[0000068505-25-000040:note_history:20]
On May 27, 2025, the Company entered into a purchase and sale agreement with Silvus Technologies Group LLC ("Seller") to acquire Silvus Technologies Holdings Inc. (“Silvus”), which subsequent to the quarter end closed on August 6, 2025, for $4.4 billion in upfront consideration, comprising $4.38 billion in cash, subject to customary adjustments for cash, net working capital, transaction expenses and indebtedness, and $20 million in restricted stock to certain employee equity holders. Additionally, under the terms of the transaction, the Seller will have the potential to earn earnout consideration following the achievement of certain financial targets of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn a catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be made in shares of common stock. Silvus designs and develops software-defined high-speed mobile ad-hoc network (MANET) technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. This business will be part of both the Products and Systems Integration segment and the Software and Services segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0000068505-25-000052:note_history:21]
|  | September 27, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | — |  |  | 70 |  |
| 364-day term loan | 749 |  |  | — |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| Term loan due 2028 | 748 |  |  | — |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 597 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
| Other short-term borrowings | 179 |  |  | — |  |
|  | 9,340 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (928) |  |  | (322) |  |
| Long-term debt | $ | 8,411 |  |  | $ | 5,675 |  |

- changed (2025-10-30):
[0000068505-25-000052:note_history:22]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030, $500 million of 5.2% senior notes due 2032 and $900 million of 5.55% senior notes due 2035. The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.
  (was, 2025-08-07, similarity 0.9463):
[0000068505-25-000040:note_history:22]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030 (“2030 Notes”), $500 million of 5.2% senior notes due 2032 (“2032 Notes”) and $900 million of 5.55% senior notes due 2035 (“2035 Notes”). The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

- added (2025-10-30):
[0000068505-25-000052:note_history:23]
On August 6, 2025 the Company borrowed $1.5 billion of senior delayed draw term loan facilities comprised of a $750 million 364-day facility and a $750 million three-year facility ("term loan due 2028") to fund a portion of the acquisition of Silvus. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 364-Day Term Loan Credit Agreement and Three-Year Term Loan Credit Agreement, each entered into on July 21, 2025. The Company was in compliance with its financial covenants as of September 27, 2025. During the three months ended September 27, 2025, the weighted average interest rate of the 364-day facility and the term loan due 2028 was 5.30% and 5.25%, respectively.

- added (2025-10-30):
[0000068505-25-000052:note_history:24]
During the three months ended September 27, 2025, the Company repaid the $70 million aggregate principal amount of the 6.5% debentures due 2025. Additionally, during the nine months ended September 27, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% debentures due 2025.

- changed (2025-10-30):
[0000068505-25-000052:note_history:25]
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of September 27, 2025. 
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of September 27, 2025, the Company had outstanding other short-term borrowings of $179 million, inclusive of the commercial paper program, with a weighted-average interest rate of 4.52% during the three months ended September 27, 2025.
  (was, 2025-08-07, similarity 0.6866):
[0000068505-25-000040:note_history:25]
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 28, 2025.

- removed (2025-10-30):
[0000068505-25-000040:note_history:26]
|  | June 28, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 596 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 893 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 7,732 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (70) |  |  | (322) |  |
| Long-term debt | $ | 7,661 |  |  | $ | 5,675 |  |

- removed (2025-10-30):
[0000068505-25-000040:note_history:27]
On May 27, 2025, the Company obtained financing commitments for $2.5 billion of senior unsecured delayed draw term loan facilities, comprised of a $1.75 billion 364-day facility and a $750 million three year facility. Upon issuance of 2030 Notes, 2032 Notes, and 2035 Notes, the financing commitments under the 364-day facility were reduced to $750 million. Subsequent to the quarter, on July 21, 2025 the Company entered into credit agreements for a $750 million 364-day delayed draw term loan and a $750 million three year delayed draw term loan, and on August 6, 2025 the Company borrowed $750 million under the 364-day delayed draw term loan and $750 million under the three year delayed draw term loan to fund a portion of the acquisition of Silvus.

- removed (2025-10-30):
[0000068505-25-000040:note_history:28]
During the three months ended June 28, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% senior notes due 2025.

- removed (2025-10-30):
[0000068505-25-000040:note_history:29]
As of June 28, 2025, $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

- removed (2025-10-30):
[0000068505-25-000040:note_history:30]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 28, 2025 the Company had no outstanding debt under the commercial paper program. Subsequent to the quarter, the Company utilized its commercial paper program as a source of short-term liquidity to partially fund the acquisition of Silvus.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0000068505-25-000052:note_history:31]
|  | September 27, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | — |  |  | 70 |  |
| 364-day term loan | 749 |  |  | — |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| Term loan due 2028 | 748 |  |  | — |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 597 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 894 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
| Other short-term borrowings | 179 |  |  | — |  |
|  | 9,340 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (928) |  |  | (322) |  |
| Long-term debt | $ | 8,411 |  |  | $ | 5,675 |  |

- removed (2025-10-30):
[0000068505-25-000040:note_history:32]
|  | June 28, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 596 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 893 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 7,732 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (70) |  |  | (322) |  |
| Long-term debt | $ | 7,661 |  |  | $ | 5,675 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0000068505-25-000052:note_history:33]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 27, 2025 and September 28, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2025-10-30):
[0000068505-25-000052:note_history:34]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,360 |  |  | $ | 761 |  |  | $ | 2,121 |  |  | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |
| International | 537 |  |  | 351 |  |  | 888 |  |  | 480 |  |  | 303 |  |  | 783 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,598 |  |  | $ | 643 |  |  | $ | 2,241 |  |  | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |
| Video | 299 |  |  | 235 |  |  | 534 |  |  | 292 |  |  | 208 |  |  | 500 |  |
| Command Center | — |  |  | 234 |  |  | 234 |  |  | — |  |  | 202 |  |  | 202 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,187 |  |  | $ | 1,006 |  |  | 2,193 |  |  | $ | 1,108 |  |  | $ | 917 |  |  | $ | 2,025 |  |
| Indirect | 710 |  |  | 106 |  |  | 816 |  |  | 676 |  |  | 89 |  |  | 765 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
  (was, 2025-08-07, similarity 0.9579):
[0000068505-25-000040:note_history:34]
|  | Three Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,251 |  |  | $ | 776 |  |  | $ | 2,027 |  |  | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |
| International | 402 |  |  | 336 |  |  | 738 |  |  | 413 |  |  | 298 |  |  | 711 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,356 |  |  | $ | 649 |  |  | $ | 2,005 |  |  | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |
| Video | 297 |  |  | 226 |  |  | 523 |  |  | 295 |  |  | 181 |  |  | 476 |  |
| Command Center | — |  |  | 237 |  |  | 237 |  |  | — |  |  | 211 |  |  | 211 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,030 |  |  | $ | 1,016 |  |  | 2,046 |  |  | $ | 1,000 |  |  | $ | 880 |  |  | $ | 1,880 |  |
| Indirect | 623 |  |  | 96 |  |  | 719 |  |  | 658 |  |  | 90 |  |  | 748 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |

- changed (2025-10-30):
[0000068505-25-000052:note_history:35]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,789 |  |  | $ | 2,211 |  |  | $ | 6,000 |  |  | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |
| International | 1,306 |  |  | 996 |  |  | 2,302 |  |  | 1,302 |  |  | 888 |  |  | 2,190 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 4,269 |  |  | $ | 1,878 |  |  | $ | 6,147 |  |  | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |
| Video | 826 |  |  | 672 |  |  | 1,498 |  |  | 821 |  |  | 553 |  |  | 1,374 |  |
| Command Center | — |  |  | 657 |  |  | 657 |  |  | — |  |  | 581 |  |  | 581 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 3,233 |  |  | $ | 2,929 |  |  | $ | 6,162 |  |  | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |
| Indirect | 1,862 |  |  | 278 |  |  | 2,140 |  |  | 1,964 |  |  | 256 |  |  | 2,220 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
  (was, 2025-08-07, similarity 0.9548):
[0000068505-25-000040:note_history:35]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,429 |  |  | $ | 1,450 |  |  | $ | 3,879 |  |  | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |
| International | 770 |  |  | 644 |  |  | 1,414 |  |  | 821 |  |  | 586 |  |  | 1,407 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,671 |  |  | $ | 1,235 |  |  | $ | 3,906 |  |  | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |
| Video | 528 |  |  | 436 |  |  | 964 |  |  | 529 |  |  | 345 |  |  | 874 |  |
| Command Center | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 379 |  |  | 379 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,046 |  |  | $ | 1,923 |  |  | $ | 3,969 |  |  | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |
| Indirect | 1,153 |  |  | 171 |  |  | 1,324 |  |  | 1,288 |  |  | 167 |  |  | 1,455 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |

- removed (2025-10-30):
[0000068505-25-000040:note_history:36]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 28, 2025 and June 29, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-30):
[0000068505-25-000052:note_history:37]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended September 27, 2025 and September 28, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2025-10-30):
[0000068505-25-000052:note_history:38]
|  | Three Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,360 |  |  | $ | 761 |  |  | $ | 2,121 |  |  | $ | 1,304 |  |  | $ | 703 |  |  | $ | 2,007 |  |
| International | 537 |  |  | 351 |  |  | 888 |  |  | 480 |  |  | 303 |  |  | 783 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 1,598 |  |  | $ | 643 |  |  | $ | 2,241 |  |  | $ | 1,492 |  |  | $ | 596 |  |  | $ | 2,088 |  |
| Video | 299 |  |  | 235 |  |  | 534 |  |  | 292 |  |  | 208 |  |  | 500 |  |
| Command Center | — |  |  | 234 |  |  | 234 |  |  | — |  |  | 202 |  |  | 202 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,187 |  |  | $ | 1,006 |  |  | 2,193 |  |  | $ | 1,108 |  |  | $ | 917 |  |  | $ | 2,025 |  |
| Indirect | 710 |  |  | 106 |  |  | 816 |  |  | 676 |  |  | 89 |  |  | 765 |  |
|  | $ | 1,897 |  |  | $ | 1,112 |  |  | $ | 3,009 |  |  | $ | 1,784 |  |  | $ | 1,006 |  |  | $ | 2,790 |  |
  (was, 2025-08-07, similarity 0.9579):
[0000068505-25-000040:note_history:38]
|  | Three Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,251 |  |  | $ | 776 |  |  | $ | 2,027 |  |  | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |
| International | 402 |  |  | 336 |  |  | 738 |  |  | 413 |  |  | 298 |  |  | 711 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,356 |  |  | $ | 649 |  |  | $ | 2,005 |  |  | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |
| Video | 297 |  |  | 226 |  |  | 523 |  |  | 295 |  |  | 181 |  |  | 476 |  |
| Command Center | — |  |  | 237 |  |  | 237 |  |  | — |  |  | 211 |  |  | 211 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,030 |  |  | $ | 1,016 |  |  | 2,046 |  |  | $ | 1,000 |  |  | $ | 880 |  |  | $ | 1,880 |  |
| Indirect | 623 |  |  | 96 |  |  | 719 |  |  | 658 |  |  | 90 |  |  | 748 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |

- changed (2025-10-30):
[0000068505-25-000052:note_history:39]
|  | Nine Months Ended |
|  | September 27, 2025 |  | September 28, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 3,789 |  |  | $ | 2,211 |  |  | $ | 6,000 |  |  | $ | 3,631 |  |  | $ | 1,985 |  |  | $ | 5,616 |  |
| International | 1,306 |  |  | 996 |  |  | 2,302 |  |  | 1,302 |  |  | 888 |  |  | 2,190 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| Mission Critical Networks (MCN) | $ | 4,269 |  |  | $ | 1,878 |  |  | $ | 6,147 |  |  | $ | 4,112 |  |  | $ | 1,739 |  |  | $ | 5,851 |  |
| Video | 826 |  |  | 672 |  |  | 1,498 |  |  | 821 |  |  | 553 |  |  | 1,374 |  |
| Command Center | — |  |  | 657 |  |  | 657 |  |  | — |  |  | 581 |  |  | 581 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 3,233 |  |  | $ | 2,929 |  |  | $ | 6,162 |  |  | $ | 2,969 |  |  | $ | 2,617 |  |  | $ | 5,586 |  |
| Indirect | 1,862 |  |  | 278 |  |  | 2,140 |  |  | 1,964 |  |  | 256 |  |  | 2,220 |  |
|  | $ | 5,095 |  |  | $ | 3,207 |  |  | $ | 8,302 |  |  | $ | 4,933 |  |  | $ | 2,873 |  |  | $ | 7,806 |  |
  (was, 2025-08-07, similarity 0.9548):
[0000068505-25-000040:note_history:39]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,429 |  |  | $ | 1,450 |  |  | $ | 3,879 |  |  | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |
| International | 770 |  |  | 644 |  |  | 1,414 |  |  | 821 |  |  | 586 |  |  | 1,407 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,671 |  |  | $ | 1,235 |  |  | $ | 3,906 |  |  | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |
| Video | 528 |  |  | 436 |  |  | 964 |  |  | 529 |  |  | 345 |  |  | 874 |  |
| Command Center | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 379 |  |  | 379 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,046 |  |  | $ | 1,923 |  |  | $ | 3,969 |  |  | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |
| Indirect | 1,153 |  |  | 171 |  |  | 1,324 |  |  | 1,288 |  |  | 167 |  |  | 1,455 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |

- changed (2025-10-30):
[0000068505-25-000052:note_history:40]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of September 27, 2025 was $8.9 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of September 27, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of September 27, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.
  (was, 2025-08-07, similarity 0.9893):
[0000068505-25-000040:note_history:40]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of June 28, 2025 was $8.8 billion. A total of $3.4 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of June 28, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.4 billion was from Software and Services performance obligations that were not yet satisfied as of June 28, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- changed (2025-10-30):
[0000068505-25-000052:note_history:41]
| (In millions) | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 2,018 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,515 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 2,074 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 670 |  |  | 496 |  |  |  |  |  |
  (was, 2025-08-07, similarity 0.9295):
[0000068505-25-000040:note_history:41]
| (In millions) | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 1,852 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,380 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 2,016 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 616 |  |  | 496 |  |  |  |  |  |

- added (2025-10-30):
[0000068505-25-000052:note_history:42]
Revenue recognized during the three months ended September 27, 2025 which was previously included in Contract liabilities as of June 28, 2025 was $637 million, compared to $572 million of revenue recognized during the three months ended September 28, 2024 which was previously included in Contract liabilities as of June 29, 2024. The Company recognized revenue of $1.2 billion during each of the nine months ended September 27, 2025 and September 28, 2024, which was previously included in Contract liabilities as of December 31, 2024 and December 31, 2023, respectively. Revenue of $7 million was recognized during the three months ended September 27, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $6 million recognized for the three months ended September 28, 2024, primarily driven by changes in the estimates of progress on system contracts. Revenue of $7 million was reversed during the nine months ended September 27, 2025 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $11 million of reversals for the nine months ended September 28, 2024.

- changed (2025-10-30):
[0000068505-25-000052:note_history:43]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended September 27, 2025 and September 28, 2024.
  (was, 2025-08-07, similarity 0.9078):
[0000068505-25-000040:note_history:43]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended June 28, 2025 and June 29, 2024.

- changed (2025-10-30):
[0000068505-25-000052:note_history:44]
| (In millions) | September 27, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 77 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 134 |  |  | 141 |  |  |  |  |  |
  (was, 2025-08-07, similarity 0.969):
[0000068505-25-000040:note_history:44]
| (In millions) | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 130 |  |  | 141 |  |  |  |  |  |

- changed (2025-10-30):
[0000068505-25-000052:note_history:45]
Amortization of contract cost assets was $13 million and $39 million for the three and nine months ended September 27, 2025, respectively, and $13 million and $38 million for the three and nine months ended September 28, 2024, respectively.
  (was, 2025-08-07, similarity 0.7798):
[0000068505-25-000040:note_history:45]
Amortization of contract cost assets was $13 million and $26 million for the three and six months ended June 28, 2025, respectively, and $12 million and $25 million for the three and six months ended June 29, 2024, respectively.

- removed (2025-10-30):
[0000068505-25-000040:note_history:46]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 28, 2025 and June 29, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- removed (2025-10-30):
[0000068505-25-000040:note_history:47]
Revenue recognized during the three months ended June 28, 2025 which was previously included in Contract liabilities as of March 29, 2025 was $663 million, compared to $553 million of revenue recognized during the three months ended June 29, 2024 which was previously included in Contract liabilities as of March 30, 2024. Revenue recognized during the six months ended June 28, 2025 which was previously included in Contract liabilities as of December 31, 2024 was $886 million, compared to $908 million recognized during the six months ended June 29, 2024 which was previously included in Contract liabilities as of December 31, 2023. Revenue of $5 million was recognized during the three months ended June 28, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $11 million of reversals for the three months ended June 29, 2024, primarily driven by changes in the estimates of progress on system contracts. Revenue of $6 million was reversed during the six months ended June 28, 2025 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $18 million of reversals for the six months ended June 29, 2024.
