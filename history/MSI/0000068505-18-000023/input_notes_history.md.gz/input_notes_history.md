# MSI note change history — 0000068505-18-000017 → 0000068505-18-000023


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000068505-18-000023:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at June 30, 2018.
  (was, 2018-05-04, similarity 0.9925):
[0000068505-18-000017:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at March 31, 2018.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000068505-18-000023:note_history:2]
The condensed consolidated financial statements as of June 30, 2018 and for the three and six months ended June 30, 2018 and July 1, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2018-05-04, similarity 0.9429):
[0000068505-18-000017:note_history:2]
The condensed consolidated financial statements as of March 31, 2018 and for the three months ended March 31, 2018 and April 1, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2018-08-03):
[0000068505-18-000023:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three and six months ended June 30, 2018 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2018-05-04, similarity 0.8081):
[0000068505-18-000017:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three months ended March 31, 2018 are not necessarily indicative of the operating results to be expected for the full year.

- added (2018-08-03):
[0000068505-18-000023:note_history:4]
During the second quarter of 2018, the Company modified its internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership, in part, as a result of recent acquisitions contributing to the growth within the newly aligned Services and Software segment. Previously, the Company had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration related revenue and costs moving from the old Services segment into the newly presented Products and Systems Integration segment and Software related revenue and costs moving from the old Products segment into the newly presented Services and Software segment.

- added (2018-08-03):
[0000068505-18-000023:note_history:5]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The Company will adopt the ASU on January 1, 2019, utilizing the modified retrospective method upon adoption. The Company has begun to assess the impact of the ASU on its financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects a material impact to its balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards.

- changed (2018-08-03):
[0000068505-18-000023:note_history:6]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The guidance related to cash flow and net investment hedges existing at the date of adoption should be applied using the modified retrospective method by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption. The guidance related to presentation and disclosure should be applied prospectively. The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and disclosures.
  (was, 2018-05-04, similarity 0.7159):
[0000068505-18-000017:note_history:6]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements.

- changed (2018-08-03):
[0000068505-18-000023:note_history:7]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company recorded $20 million and $4 million in the three months ended June 30, 2018 and July 1, 2017, respectively, and $40 million and $1 million in the six months ended June 30, 2018 and July 1, 2017, respectively.
  (was, 2018-05-04, similarity 0.9537):
[0000068505-18-000017:note_history:7]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company reclassified $20 million and $3 million in the three months ended March 31, 2018 and April 1, 2017, respectively.

- changed (2018-08-03):
[0000068505-18-000023:note_history:8]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.
  (was, 2018-05-04, similarity 0.9978):
[0000068505-18-000017:note_history:8]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers", and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

- changed (2018-08-03):
[0000068505-18-000023:note_history:9]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.
  (was, 2018-05-04, similarity 0.985):
[0000068505-18-000017:note_history:9]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Managed & Support services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

- changed (2018-08-03):
[0000068505-18-000023:note_history:10]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 is as follows:
  (was, 2018-05-04, similarity 0.986):
[0000068505-18-000017:note_history:10]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 are as follows:

- changed (2018-08-03):
[0000068505-18-000023:note_history:11]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three and six months ended June 30, 2018 is as follows:
  (was, 2018-05-04, similarity 0.9399):
[0000068505-18-000017:note_history:11]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three months ended March 31, 2018 is as follows:

- changed (2018-08-03):
[0000068505-18-000023:note_history:12]
|  | Three Months Ended |
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,760 |  |  | $ | (24 | ) |  | $ | 1,736 |  |
| Gross margin | 822 |  |  | (24 | ) |  | 798 |  |
| Selling, general and administrative expenses | 316 |  |  | (16 | ) |  | 300 |  |
| Operating Earnings | 273 |  |  | (8 | ) |  | 265 |  |
| Net earnings before income taxes | 227 |  |  | (8 | ) |  | 219 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 180 |  |  | $ | (8 | ) |  | $ | 172 |  |
  (was, 2018-05-04, similarity 0.9232):
[0000068505-18-000017:note_history:12]
| (In millions) | March 31, 2018 |  | Adjustments due to ASC 606 |  | March 31, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,468 |  |  | $ | (15 | ) |  | $ | 1,453 |  |
| Gross margin | 669 |  |  | (15 | ) |  | 654 |  |
| Selling, general and administrative expenses | 279 |  |  | (13 | ) |  | 266 |  |
| Operating Earnings | 171 |  |  | (2 | ) |  | 169 |  |
| Net earnings before income taxes | 140 |  |  | (2 | ) |  | 138 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 117 |  |  | $ | (2 | ) |  | $ | 115 |  |

- added (2018-08-03):
[0000068505-18-000023:note_history:13]
|  | Six Months Ended |
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Net sales | 3,227 |  |  | (39 | ) |  | 3,188 |  |
| Gross margin | 1,491 |  |  | (39 | ) |  | 1,452 |  |
| Selling, general and administrative expenses | 594 |  |  | (29 | ) |  | 565 |  |
| Operating Earnings | 445 |  |  | (10 | ) |  | 435 |  |
| Net earnings before income taxes | 367 |  |  | (10 | ) |  | 357 |  |
| Net earnings attributable to Motorola Solutions Inc. | 297 |  |  | (10 | ) |  | 287 |  |

- changed (2018-08-03):
[0000068505-18-000023:note_history:14]
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Accounts receivable, net | $ | 1,159 |  |  | $ | 205 |  |  | $ | 1,364 |  |
| Contract assets | 760 |  |  | (760 | ) |  | — |  |
| Other current assets | 330 |  |  | 491 |  |  | 821 |  |
| Deferred income taxes | 945 |  |  | 41 |  |  | 986 |  |
| Other assets | 420 |  |  | (92 | ) |  | 328 |  |
| Contract liabilities | $ | 1,049 |  |  | $ | (1,049 | ) |  | $ | — |  |
| Accrued liabilities | 1,096 |  |  | 1,061 |  |  | 2,157 |  |
| Other liabilities | 2,153 |  |  | 10 |  |  | 2,163 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 627 |  |  | (137 | ) |  | 490 |  |
  (was, 2018-05-04, similarity 0.965):
[0000068505-18-000017:note_history:14]
| (In millions) | March 31, 2018 |  | Adjustments due to ASC 606 |  | March 31, 2018 Balances Under ASC 605 |
| Accounts receivable, net | $ | 1,179 |  |  | $ | 222 |  |  | $ | 1,401 |  |
| Contract assets | 800 |  |  | (800 | ) |  | — |  |
| Other current assets | 343 |  |  | 520 |  |  | 863 |  |
| Deferred income taxes | 973 |  |  | 41 |  |  | 1,014 |  |
| Other assets | 412 |  |  | (86 | ) |  | 326 |  |
| Contract liabilities | $ | 1,069 |  |  | $ | (1,069 | ) |  | $ | — |  |
| Accrued liabilities | 1,072 |  |  | 1,086 |  |  | 2,158 |  |
| Other liabilities | 2,190 |  |  | 9 |  |  | 2,199 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 531 |  |  | (129 | ) |  | 402 |  |

- removed (2018-08-03):
[0000068505-18-000017:note_history:15]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation ("Avigilon"), a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions for a purchase price of $974 million.

- removed (2018-08-03):
[0000068505-18-000017:note_history:16]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc.("Plant"), the parent company of Airbus DS Communications for a purchase price of $237 million. This acquisition expands our software portfolio in the Command Center with additional solutions for Next Generation 9-1-1.

- removed (2018-08-03):
[0000068505-18-000017:note_history:17]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The ASU prescribes the use of a modified retrospective method upon adoption, which requires all prior periods presented in the financial statements to be restated, with a cumulative adjustment to retained earnings as of the beginning of the earliest period presented. The Company has begun to assess the impact of the ASU on its financial statements and expects a material impact to its balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards. The Company has also begun to catalog its existing lease contracts and identify changes needed to systems and processes.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-08-03):
[0000068505-18-000023:note_history:18]
As of June 30, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). During the first quarter of 2018, $400 million was borrowed under this facility for the Avigilon acquisition, of which $100 million was repaid during the three months ended June 30, 2018. As of June 30, 2018, the outstanding loan amount was $300 million. Subsequent to the quarter, the Company paid an additional $50 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts was 3.75%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 30, 2018.

- changed (2018-08-03):
[0000068505-18-000023:note_history:19]
To complete the acquisition of Avigilon in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable monthly, subject to the Company's discretion. The weighted average borrowing rate for amounts outstanding during the six months ended June 30, 2018 was 3.35%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.
  (was, 2018-05-04, similarity 0.7893):
[0000068505-18-000017:note_history:19]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, the Company entered into a term loan for $400 million and a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable quarterly. The weighted average borrowing rate for amounts outstanding during the quarter ended March 31, 2018 was 3.54%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

- added (2018-08-03):
[0000068505-18-000023:note_history:20]
Also in conjunction with the acquisition of Avigilon in March 2018, the Company assumed $75 million of borrowings under Avigilon's revolving credit facility, of which $35 million was repaid during the first quarter of 2018 with the remaining $40 million paid during the second quarter of 2018, resulting in the closure of the facility.

- changed (2018-08-03):
[0000068505-18-000023:note_history:21]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of June 30, 2018 was $682 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.
  (was, 2018-05-04, similarity 0.9936):
[0000068505-18-000017:note_history:21]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of March 31, 2018 was $590 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- removed (2018-08-03):
[0000068505-18-000017:note_history:22]
As of March 31, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"), of which $400 million was borrowed as of March 31, 2018 to facilitate the Avigilon acquisition. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts was 3.25%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 31, 2018.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000068505-18-000023:note_history:23]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2018-05-04, similarity 0.9327):
[0000068505-18-000017:note_history:23]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- added (2018-08-03):
[0000068505-18-000023:note_history:24]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 878 |  |  | $ | 331 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 188 |  |  | 194 |  |  | 345 |  |  | 375 |  |
| AP | 123 |  |  | 46 |  |  | 220 |  |  | 84 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 725 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 464 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 456 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 115 |  |  | — |  |  | 184 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 740 |  |  | $ | 537 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 449 |  |  | 34 |  |  | 784 |  |  | 44 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

- removed (2018-08-03):
[0000068505-18-000017:note_history:25]
| (in millions) | Products |  | Services |
| Regions |  |  |  |
| Americas | $ | 599 |  |  | $ | 396 |  |
| EMEA | 118 |  |  | 220 |  |
| AP | 84 |  |  | 51 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Major Products and Services |  |  |  |
| Systems and Integration | $ | 182 |  |  | $ | 168 |  |
| Devices | 619 |  |  | — |  |
| Managed & Support Services | — |  |  | 499 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Customer Type |  |  |  |
| Direct | $ | 466 |  |  | $ | 657 |  |
| Indirect | 335 |  |  | 10 |  |
| Total | $ | 801 |  |  | $ | 667 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000068505-18-000023:note_history:26]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:
  (was, 2018-05-04, similarity 0.9327):
[0000068505-18-000017:note_history:26]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three months ended March 31, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

- added (2018-08-03):
[0000068505-18-000023:note_history:27]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 878 |  |  | $ | 331 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 188 |  |  | 194 |  |  | 345 |  |  | 375 |  |
| AP | 123 |  |  | 46 |  |  | 220 |  |  | 84 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 725 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 464 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 456 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 115 |  |  | — |  |  | 184 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 740 |  |  | $ | 537 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 449 |  |  | 34 |  |  | 784 |  |  | 44 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |

- changed (2018-08-03):
[0000068505-18-000023:note_history:28]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.
  (was, 2018-05-04, similarity 0.9033):
[0000068505-18-000017:note_history:28]
Products: The Products segment is comprised of Systems and Devices. Direct customers of the Products segment are typically government public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products sales, it records consideration from shipping and handling on a gross basis with Net sales.

- added (2018-08-03):
[0000068505-18-000023:note_history:29]
Systems and Systems Integration: Systems and Systems Integration include customized end-to-end radio network, video solutions and implementation, optimization, and integration of networks, devices, software, and applications. Radio network includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, and repeaters. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents distinct performance obligations for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Systems and Systems Integration revenue is recognized over an average duration of approximately one to two years.

- changed (2018-08-03):
[0000068505-18-000023:note_history:30]
Systems also includes Avigilon end-to-end security and surveillance solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.
  (was, 2018-05-04, similarity 0.9992):
[0000068505-18-000017:note_history:30]
Systems also includes Avigilon end-to-end security and surveillance solutions including video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

- added (2018-08-03):
[0000068505-18-000023:note_history:31]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

- changed (2018-08-03):
[0000068505-18-000023:note_history:32]
Services:  Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer or Motorola Solutions owned networks. Services are provided across all radio network technologies. Services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.
  (was, 2018-05-04, similarity 0.8949):
[0000068505-18-000017:note_history:32]
Managed & Support Services:  Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions. Managed & Support services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since Managed & Support services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly it does not constrain its contract price. Certain contracts may also contain variable consideration driven by number of users. Revenue is typically recognized on Managed & Support services over time as a series of services performed over the contract term on a straight-line basis.

- added (2018-08-03):
[0000068505-18-000023:note_history:33]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

- added (2018-08-03):
[0000068505-18-000023:note_history:34]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over-time as the customer simultaneously receives and consumes the services on a straight-line basis.

- changed (2018-08-03):
[0000068505-18-000023:note_history:35]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 30, 2018 is $6.2 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.1 billion is from Services and Software performance obligations that are not yet satisfied as of June 30, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.1 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.
  (was, 2018-05-04, similarity 0.8566):
[0000068505-18-000017:note_history:35]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of March 31, 2018 is $6.5 billion. A total of $1.7 billion is from Product performance obligations that are not yet satisfied, of which $1.0 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $4.8 billion is from Services performance obligations that are not yet satisfied as of March 31, 2018. The determination of Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Managed & Support services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.7 billion from unsatisfied Services performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed.

- changed (2018-08-03):
[0000068505-18-000023:note_history:36]
| (in millions) | January 1, 2018 |  |  | June 30, 2018 |  |
| Receivables | $ | 1,198 |  |  | $ | 1,159 |  |
| Contract assets | 931 |  |  | 760 |  |
| Contract liabilities | 1,082 |  |  | 1,049 |  |
| Non-current contract liabilities | 162 |  |  | 180 |  |
  (was, 2018-05-04, similarity 0.6521):
[0000068505-18-000017:note_history:36]
| (in millions) | January 1, 2018 |  |  | March 31, 2018 |  |
| Current contract cost assets | $ | 62 |  |  | $ | 62 |  |
| Non-current contract cost assets | 85 |  |  | 92 |  |

- changed (2018-08-03):
[0000068505-18-000023:note_history:37]
Contract assets consist of amounts formerly classified as Costs and earnings in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of costs and earnings recognized, Customer downpayments and Deferred revenue.
  (was, 2018-05-04, similarity 0.913):
[0000068505-18-000017:note_history:37]
Contract assets consist of amounts formerly classified as Revenue in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of revenue recognized, Customer downpayments and Deferred revenue.

- changed (2018-08-03):
[0000068505-18-000023:note_history:38]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over-time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.
  (was, 2018-05-04, similarity 0.9423):
[0000068505-18-000017:note_history:38]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over-time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Managed & Support services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year, applying practical expedients available under the accounting standards.

- added (2018-08-03):
[0000068505-18-000023:note_history:39]
Revenue recognized during the three months ended June 30, 2018 which was previously included in Contract liabilities as of April 1, 2018 is $365 million. Revenue recognized during the six months ended June 30, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $541 million. Revenue of $6 million was reversed during the three months ended June 30, 2018 and $3 million of revenue was recognized during the six months ended June 30, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

- changed (2018-08-03):
[0000068505-18-000023:note_history:40]
There have been no material impairment losses recognized on contract assets during the six months ended June 30, 2018.
  (was, 2018-05-04, similarity 0.7934):
[0000068505-18-000017:note_history:40]
There have been no impairment losses recognized on customer receivables or contract assets during the three months ended March 31, 2018.

- added (2018-08-03):
[0000068505-18-000023:note_history:41]
| (in millions) | January 1, 2018 |  |  | June 30, 2018 |  |
| Current contract cost assets | $ | 62 |  |  | $ | 47 |  |
| Non-current contract cost assets | 85 |  |  | 90 |  |

- changed (2018-08-03):
[0000068505-18-000023:note_history:42]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $11 million and $23 million for the three and six months ended June 30, 2018, respectively.
  (was, 2018-05-04, similarity 0.9358):
[0000068505-18-000017:note_history:42]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $12 million for the three months ended March 31, 2018.

- removed (2018-08-03):
[0000068505-18-000017:note_history:43]
| (in millions) | Products |  | Services |
| Regions |  |  |  |
| Americas | $ | 599 |  |  | $ | 396 |  |
| EMEA | 118 |  |  | 220 |  |
| AP | 84 |  |  | 51 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Major Products and Services |  |  |  |
| Systems and Integration | $ | 182 |  |  | $ | 168 |  |
| Devices | 619 |  |  | — |  |
| Managed & Support Services | — |  |  | 499 |  |
| Total | $ | 801 |  |  | $ | 667 |  |
| Customer Type |  |  |  |
| Direct | $ | 466 |  |  | $ | 657 |  |
| Indirect | 335 |  |  | 10 |  |
| Total | $ | 801 |  |  | $ | 667 |  |

- removed (2018-08-03):
[0000068505-18-000017:note_history:44]
Systems: Systems include customized end-to-end radio network, command center, and video solutions. Radio network and command center solutions includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised, as described in Integration Services below. The radio network and command center solutions represent distinct performance obligations for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. System revenue is recognized over an average duration of approximately one to two years.

- removed (2018-08-03):
[0000068505-18-000017:note_history:45]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including Integration services and Managed & Support services. Direct customers of the Services segment are typically government public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

- removed (2018-08-03):
[0000068505-18-000017:note_history:46]
Integration Services:  Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Integration services are typically sold under a fixed price contract and bundled with other hardware or software offerings. The services can be sold in a contract as a distinct performance obligation. However, integration services typically are not distinct in the context of the contract as they represent a component of the system performance obligation subject to customization and integration services on hardware and software solutions. Revenue recognition on integration services is recognized over time based on input measures of costs incurred or units completed. Integration services are typically project implementations with an average duration of approximately one to two years.

- removed (2018-08-03):
[0000068505-18-000017:note_history:47]
| (in millions) | January 1, 2018 |  |  | March 31, 2018 |  |
| Receivables | $ | 1,198 |  |  | $ | 1,179 |  |
| Contract assets | 931 |  |  | 800 |  |
| Contract liabilities | 1,082 |  |  | 1,069 |  |
| Non-current contract liabilities | 162 |  |  | 167 |  |

- removed (2018-08-03):
[0000068505-18-000017:note_history:48]
Revenue recognized during the three months ended March 31, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $332 million. Revenue of $9 million was recognized during the three months ended March 31, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts. During the three months ended March 31, 2018, the Company added Accounts receivable of $87 million, Contract assets of $26 million, and Contract liabilities of $48 million related to acquisitions.
