# MSI MD&A — 0000068505-18-000023


## mdna

[0000068505-18-000023:mdna:1]
[same as prior period, unchanged from 0000068505-18-000017:mdna:1]

[0000068505-18-000023:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and six months ended June 30, 2018 and July 1, 2017, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2017.

[0000068505-18-000023:mdna:3]
[same as prior period, unchanged from 0000068505-18-000017:mdna:3]

[0000068505-18-000023:mdna:4]
[same as prior period, unchanged from 0000068505-18-000017:mdna:4]

[0000068505-18-000023:mdna:5]
During the second quarter of 2018, we modified our internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership in part as a result of recent acquisitions contributing to the growth within the newly aligned Services and Software segment. Previously, we had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration related revenue and costs moving from the old Services segment into the newly presented Products and Systems Integration segment and Software related revenue and costs moving from the old Products segment into the newly presented Services and Software segment.

[0000068505-18-000023:mdna:6]
[same as prior period, unchanged from 0000068505-18-000017:mdna:8]

[0000068505-18-000023:mdna:7]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 16,000 employees worldwide, based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-18-000023:mdna:8]
[same as prior period, unchanged from 0000068505-18-000017:mdna:10]

[0000068505-18-000023:mdna:9]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, such as video surveillance cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions and manage a mobile workforce. In the second quarter of 2018, the segment’s net sales were $1.2 billion, representing 68% of our consolidated net sales.

[0000068505-18-000023:mdna:10]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services offerings range from partial to full operation of customer or Motorola Solutions owned networks. Software includes public safety and enterprise command center solutions, unified communications applications, and video software solutions, delivered both on premise and “as a service.” In the second quarter of 2018, the segment’s net sales were $571 million, representing 32% of our consolidated net sales.

[0000068505-18-000023:mdna:11]
Second Quarter Summary

[0000068505-18-000023:mdna:12]
| • | Net sales were $1.8 billion in the second quarter of 2018, up $263 million, or 18%, from the second quarter of 2017. |

[0000068505-18-000023:mdna:13]
| • | We generated operating earnings of $273 million, or 16% of net sales, in the second quarter of 2018, compared to $261 million, or 17% of net sales, in the second quarter of 2017. |

[0000068505-18-000023:mdna:14]
| • | We had net earnings attributable to Motorola Solutions, Inc. of $180 million, or $1.05 per diluted common share, in the second quarter of 2018, compared to $131 million, or $0.78 per diluted common share, in the second quarter of 2017. |

[0000068505-18-000023:mdna:15]
| • | We used net cash for operating activities of $75 million during the first half of 2018, primarily driven by the $500 million contribution to our U.S. pension plan, compared to $315 million of cash provided by operating activities in the first half of 2017. |

[0000068505-18-000023:mdna:16]
| • | We returned $234 million in capital to shareholders through dividends and share repurchases during the first half of 2018. |

[0000068505-18-000023:mdna:17]
| • | We repaid $140 million of debt in the second quarter of 2018 related to the Avigilon acquisition. |

[0000068505-18-000023:mdna:18]
[same as prior period, unchanged from 0000068505-18-000017:mdna:19]

[0000068505-18-000023:mdna:19]
| • | Products and Systems Integration: Net sales were $1.2 billion in the second quarter of 2018, an increase of $142 million, or 14% compared to net sales of $1.0 billion during the second quarter of 2017. On a geographic basis, net sales increased in the Americas and EMEA and decreased in AP, compared to the year-ago quarter. |

[0000068505-18-000023:mdna:20]
| • | Services and Software: Net sales were $571 million in the second quarter of 2018, an increase of $121 million, or 27% compared to net sales of $450 million in the second quarter of 2017. On a geographic basis, net sales increased in every region, compared to the year-ago quarter. |

[0000068505-18-000023:mdna:21]
[same as prior period, unchanged from 0000068505-18-000017:mdna:22]

[0000068505-18-000023:mdna:22]
[same as prior period, unchanged from 0000068505-18-000017:mdna:23]

[0000068505-18-000023:mdna:23]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | June 30, 2018 |  | % ofSales* |  | July 1, 2017 |  | % ofSales* |  | June 30, 2018 |  | % ofSales* |  | July 1, 2017 |  | % ofSales* |
| Net sales from products | $ | 1,042 |  |  |  |  | $ | 848 |  |  |  |  | $ | 1,842 |  |  |  |  | $ | 1,551 |  |  |  |
| Net sales from services | 718 |  |  |  |  | 649 |  |  |  |  | 1,385 |  |  |  |  | 1,226 |  |  |  |
| Net sales | 1,760 |  |  |  |  | 1,497 |  |  |  |  | 3,227 |  |  |  |  | 2,777 |  |  |  |
| Costs of products sales | 485 |  |  | 46.5 | % |  | 392 |  |  | 46.2 | % |  | 867 |  |  | 47.1 | % |  | 739 |  |  | 47.6 | % |
| Costs of services sales | 453 |  |  | 63.1 | % |  | 415 |  |  | 63.9 | % |  | 869 |  |  | 62.7 | % |  | 778 |  |  | 63.5 | % |
| Costs of sales | 938 |  |  |  |  | 807 |  |  |  |  | 1,736 |  |  |  |  | 1,517 |  |  |  |
| Gross margin | 822 |  |  | 46.7 | % |  | 690 |  |  | 46.1 | % |  | 1,491 |  |  | 46.2 | % |  | 1,260 |  |  | 45.4 | % |
| Selling, general and administrative expenses | 316 |  |  | 18.0 | % |  | 254 |  |  | 17.0 | % |  | 594 |  |  | 18.4 | % |  | 500 |  |  | 18.0 | % |
| Research and development expenditures | 162 |  |  | 9.2 | % |  | 138 |  |  | 9.2 | % |  | 314 |  |  | 9.7 | % |  | 273 |  |  | 9.8 | % |
| Other charges | 71 |  |  | 4.0 | % |  | 37 |  |  | 2.5 | % |  | 138 |  |  | 4.3 | % |  | 54 |  |  | 1.9 | % |
| Operating earnings | 273 |  |  | 15.5 | % |  | 261 |  |  | 17.4 | % |  | 445 |  |  | 13.8 | % |  | 433 |  |  | 15.6 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (58 | ) |  | (3.3 | )% |  | (51 | ) |  | (3.4 | )% |  | (104 | ) |  | (3.2 | )% |  | (102 | ) |  | (3.7 | )% |
| Gains (losses) on sales of investments and businesses, net | (1 | ) |  | (0.1 | )% |  | (1 | ) |  | (0.1 | )% |  | 10 |  |  | 0.3 | % |  | 2 |  |  | 0.1 | % |
| Other | 13 |  |  | 0.7 | % |  | (4 | ) |  | (0.3 | )% |  | 16 |  |  | 0.5 | % |  | (9 | ) |  | (0.3 | )% |
| Total other expense | (46 | ) |  | (2.6 | )% |  | (56 | ) |  | (3.7 | )% |  | (78 | ) |  | (2.4 | )% |  | (109 | ) |  | (3.9 | )% |
| Earnings before income taxes | 227 |  |  | 12.9 | % |  | 205 |  |  | 13.7 | % |  | 367 |  |  | 11.4 | % |  | 324 |  |  | 11.7 | % |
| Income tax expense | 46 |  |  | 2.6 | % |  | 73 |  |  | 4.9 | % |  | 69 |  |  | 2.1 | % |  | 114 |  |  | 4.1 | % |
| Net earnings | 181 |  |  | 10.3 | % |  | 132 |  |  | 8.8 | % |  | 298 |  |  | 9.2 | % |  | 210 |  |  | 7.6 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | 1 |  |  | 0.1 | % |  | 1 |  |  | — | % |  | 2 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 180 |  |  | 10.2 | % |  | $ | 131 |  |  | 8.8 | % |  | $ | 297 |  |  | 9.2 | % |  | $ | 208 |  |  | 7.5 | % |
| Earnings per diluted common share | $ | 1.05 |  |  |  |  |  | $ | 0.78 |  |  |  |  |  | $ | 1.73 |  |  |  |  | $ | 1.23 |  |  |  |

[0000068505-18-000023:mdna:24]
[same as prior period, unchanged from 0000068505-18-000017:mdna:25]

[0000068505-18-000023:mdna:25]
[same as prior period, unchanged from 0000068505-18-000017:mdna:26]

[0000068505-18-000023:mdna:26]
Results of Operations—Three months ended June 30, 2018 compared to three months ended July 1, 2017

[0000068505-18-000023:mdna:27]
The results of operations for the second quarter of 2018 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-18-000023:mdna:28]
[same as prior period, unchanged from 0000068505-18-000017:mdna:29]

[0000068505-18-000023:mdna:29]
Net sales were $1.8 billion in the second quarter of 2018, a $263 million, or 18%, increase compared to the second quarter of 2017, reflecting solid demand across the globe for our products and services. The net sales increase for the second quarter of 2018 included $154 million from acquisitions, $26 million from favorable foreign currency rates and $24 million from the adoption of ASC 606. The increase in net sales is reflective of growth in every region. Devices net sales within the Products and Systems Integration segment increased in the Americas and EMEA and decreased in AP. Systems and Systems Integration net sales within the Products and Systems Integration segment increased in every region. The Services and Software segment net sales increased in every region. The Services and Software segment net sales increase in the Americas was driven by the acquisitions of Plant and Kodiak Networks within the Software business and growth absent of acquisitions in both Services and Software. The Services and Software segment net sales increase in EMEA was primarily driven by growth absent of acquisitions in Services. The Services and Software segment net sales increase in AP was driven by the acquisition of Kodiak Networks in the Software business and growth absent of acquisitions in both Services and Software.

[0000068505-18-000023:mdna:30]
[same as prior period, unchanged from 0000068505-18-000017:mdna:31]

[0000068505-18-000023:mdna:31]
Gross margin was $822 million, or 46.7% of net sales, in the second quarter of 2018, compared to $690 million, or 46.1% of net sales, in the second quarter of 2017. The increase in gross margin percentage was primarily driven by improved margins in Services, the adoption of ASC 606, and a favorable mix.

[0000068505-18-000023:mdna:32]
[same as prior period, unchanged from 0000068505-18-000017:mdna:33]

[0000068505-18-000023:mdna:33]
SG&A expenses were $316 million, or 18.0% of net sales, in the second quarter of 2018, compared to $254 million, or 17.0% of net sales, in the second quarter of 2017. The increase in SG&A expenditures is primarily due to the change in classification of our third-party sales commissions from the adoption of ASC 606 and increased expenses associated with acquired businesses.

[0000068505-18-000023:mdna:34]
[same as prior period, unchanged from 0000068505-18-000017:mdna:35]

[0000068505-18-000023:mdna:35]
R&D expenditures were $162 million, or 9.2% of net sales, in the second quarter of 2018 and $138 million, or 9.2% of net sales, in the second quarter of 2017. The increase in R&D expenditures is primarily due to increased expenses associated with acquired businesses.

[0000068505-18-000023:mdna:36]
[same as prior period, unchanged from 0000068505-18-000017:mdna:37]

[0000068505-18-000023:mdna:37]
We recorded net charges of $71 million in the second quarter of 2018, compared to net charges of $37 million in the second quarter of 2017. The net Other charges in the second quarter of 2018 were driven by $53 million of charges relating to the amortization of intangibles and $18 million of net reorganization of business charges. The net charges in the second quarter of 2017 of $37 million were primarily from $37 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-18-000023:mdna:38]
[same as prior period, unchanged from 0000068505-18-000017:mdna:40]

[0000068505-18-000023:mdna:39]
Net interest expense was $58 million in the second quarter of 2018 and $51 million in the second quarter of 2017. The increase in net interest expense in the second quarter of 2018 as compared to the second quarter of 2017 was a result of increases in outstanding debt issued during the first quarter of 2018.

[0000068505-18-000023:mdna:40]
[same as prior period, unchanged from 0000068505-18-000017:mdna:44]

[0000068505-18-000023:mdna:41]
Net Other income was $13 million in the second quarter of 2018, compared to an expense of $4 million in the second quarter of 2017. The net other income in the second quarter of 2018 was primarily comprised of $20 million of net periodic postretirement benefit and a $11 million foreign currency gain, partially offset by a $19 million loss on derivative instruments. The net Other expense in the second quarter of 2017 was primarily comprised of a $20 million foreign currency loss and $16 million of charges relating to the Non-U.S. pension settlement loss, partially offset by a $18 million gain on derivative instruments and  $12 million of net periodic postretirement benefit.

[0000068505-18-000023:mdna:42]
[same as prior period, unchanged from 0000068505-18-000017:mdna:46]

[0000068505-18-000023:mdna:43]
We recorded $46 million of net tax expense in the second quarter of 2018, resulting in an effective tax rate of 20%, compared to $73 million of net tax expense in the second quarter of 2017, resulting in an effective tax rate of 36%. Our effective tax rate for the three months ended June 30, 2018 of 20% is lower than our effective tax rate for the three months ended July 1, 2017 of 35%, primarily due to the corporate income tax rate decrease from 35% to 21%, as a result of the U.S. Tax Cuts and Jobs Act (the “Tax Act”) enacted December 22, 2017. Our effective tax rate in the second quarter of 2018 was lower than the U.S. statutory tax rate of 21% primarily due to a favorable settlement of a state audit, resulting in a tax benefit. Our effective tax rate in the second quarter of 2017 was greater than the U.S. statutory tax rate of 35% partly due to change of estimates between provision and the filing of tax returns in foreign jurisdictions.

[0000068505-18-000023:mdna:44]
[same as prior period, unchanged from 0000068505-18-000017:mdna:48]

[0000068505-18-000023:mdna:45]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $180 million, or $1.05 per diluted share, in the second quarter of 2018, compared to net earnings attributable to Motorola Solutions, Inc. of $131 million, or $0.78 per diluted share, in the second quarter of 2017.

[0000068505-18-000023:mdna:46]
The increase in net earnings and net earnings per diluted share in the second quarter of 2018, as compared to the second quarter of 2017, was primarily driven by: (i) higher sales in both the Products and Systems Integration and Services and Software segments, (ii) lower Other non-operating expenses, net, and (iii) lower income tax expense, partially offset by higher operating expenses.

[0000068505-18-000023:mdna:47]
Results of Operations—Six months ended June 30, 2018 compared to six months ended July 1, 2017

[0000068505-18-000023:mdna:48]
Net Sales

[0000068505-18-000023:mdna:49]
Net sales were $3.2 billion in the first half of 2018, a $450 million, or 16%, increase compared to the first half of 2017. The net sales increase for the first half of 2018 included $201 million from acquisitions, $65 million from favorable foreign currency rates and $39 million from the adoption of ASC 606.The increase in net sales is reflective of growth in every region. Within the Products and Systems Integration segment, Devices net sales increased in the Americas and EMEA and decreased in AP and Systems and Systems Integration net sales increased in every region. The Services and Software segment increased in every region. The Services and Software segment net sales increase in the Americas was driven by the acquisitions of Plant and Kodiak Networks within the Software business, the acquisition of Interexport in Services and growth absent of acquisitions in both Services and Software. The Services and Software segment net sales increase in EMEA was primarily driven by growth absent of acquisitions in Services. The Services and Software segment net sales increase in AP was driven by the acquisition of Kodiak Networks in the Software business and growth absent of acquisitions in both Services and the Software business.

[0000068505-18-000023:mdna:50]
Gross Margin

[0000068505-18-000023:mdna:51]
Gross margin was $1.5 billion, or 46.2% of net sales, in the first half of 2018, compared to $1.3 billion, or 45.4% of net sales, in the first half of 2017. The increase in gross margin percentage was primarily driven by favorable mix, the adoption of ASC 606, and improved margins in Services.

[0000068505-18-000023:mdna:52]
Selling, General and Administrative Expenses

[0000068505-18-000023:mdna:53]
SG&A expenses were $594 million, or 18.4% of net sales, in the first half of 2018, compared to $500 million, or 18.0% of net sales, in the first half of 2017. The increase in SG&A expenditures is primarily due to the change in classification of our third-party sales commissions from the adoption of ASC 606 and increased expenses associated with acquired businesses.

[0000068505-18-000023:mdna:54]
Research and Development Expenditures

[0000068505-18-000023:mdna:55]
R&D expenditures were $314 million, or 9.7% of net sales, in the first half of 2018 and $273 million, or 9.8% of net sales, in the first half of 2017. R&D expenditures increased due to increased expenses associated with acquired businesses.

[0000068505-18-000023:mdna:56]
Other Charges

[0000068505-18-000023:mdna:57]
We recorded net charges of $138 million in the first half of 2018, compared to net charges of $54 million in the first half of 2017. The net Other charges in the first half of 2018 were primarily driven by: (i) $94 million of charges relating to the amortization of intangibles, (ii) $26 million of net reorganization of business charges, and (iii) $17 million of acquisition related transaction fees. The net charges in the first half of 2017 of $54 million primarily consisted of: (i) $73 million of charges relating to the amortization of intangibles, (ii) $16 million of net reorganization of business charges and (iii) $8 million of charges related to a building impairment, partially offset by a net gain of $42 million, related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer. The net reorganization of business charges are discussed in further detail in the Reorganization of Businesses section.

[0000068505-18-000023:mdna:58]
Net Interest Expense

[0000068505-18-000023:mdna:59]
Net interest expense was $104 million in the first half of 2018 and $102 million in the first half of 2017. The increase in net interest expense in the first half of 2018 as compared to the first half of 2017 was a result of increases in outstanding debt.

[0000068505-18-000023:mdna:60]
[same as prior period, unchanged from 0000068505-18-000017:mdna:42]

[0000068505-18-000023:mdna:61]
Net gains on sales of investments and businesses were $10 million in the first half of 2018 compared to net gains of $2 million in the first half of 2017. The net gains in the first half of 2018 and 2017 were primarily related to the sales of various equity investments.

[0000068505-18-000023:mdna:62]
Other

[0000068505-18-000023:mdna:63]
Net Other income was $16 million in the first half of 2018, compared to expense of $9 million in the first half of 2017. The net Other income in the first half of 2018 was primarily comprised of $40 million net periodic postretirement benefit, partially offset by a $23 million loss on derivative investments, including losses of $14 million associated with foreign currency derivative contracts related to the acquisition of Avigilon. The net Other expense in the first half of 2017 was comprised of $25 million of charges relating to the Non-U.S. pension settlement loss and a $22 million foreign currency loss, partially offset by: (i) $24

[0000068505-18-000023:mdna:64]
million of net periodic postretirement benefit, (ii) a $11 million gain on derivative instruments, and (iii) $3 million of other non-operating gains.

[0000068505-18-000023:mdna:65]
Effective Tax Rate

[0000068505-18-000023:mdna:66]
We recorded $69 million of net tax expense in the first half of 2018, resulting in an effective tax rate of 19%, compared to $114 million of net tax expense in the first half of 2017, resulting in an effective tax rate of 35%. Our effective tax rate for the six months ended June 30, 2018 of 19% is lower than our effective tax rate for the six months ended July 1, 2017 of 35%, primarily due to the corporate income tax rate decrease from 35% to 21%, as a result of the Tax Act. Our effective tax rate in the first half of 2018 was lower than the U.S. statutory tax rate of 21% primarily due to the recognition of excess tax benefits on share-based compensation and a tax benefit due to a favorable settlement of a state audit. Our effective tax rate in the first half of 2017 was equal to the U.S. statutory tax rate of 35%.

[0000068505-18-000023:mdna:67]
Net Earnings Attributable to Motorola Solutions, Inc.

[0000068505-18-000023:mdna:68]
After taxes, we had net earnings attributable to Motorola Solutions, Inc. of $297 million, or $1.73 per diluted share, in the first half of 2018, compared to net earnings attributable to Motorola Solutions, Inc. of $208 million, or $1.23 per diluted share, in the first half of 2017.

[0000068505-18-000023:mdna:69]
The increase in net earnings in the first half of 2018, as compared to the first half of 2017, was primarily driven by: (i) higher sales in both the Products and Systems Integration and Services and Software segments, (ii) lower Other non-operating expenses, net, and (iii) lower income tax expense, partially offset by higher operating expenses. The increase in net earnings per diluted share was driven by an increase in net earnings.

[0000068505-18-000023:mdna:70]
[same as prior period, unchanged from 0000068505-18-000017:mdna:51]

[0000068505-18-000023:mdna:71]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and six months ended June 30, 2018 and July 1, 2017, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-18-000023:mdna:72]
Products and Systems Integration Segment

[0000068505-18-000023:mdna:73]
For the second quarter of 2018, the segment’s net sales represented 68% of our consolidated net sales, compared to 70% of our consolidated net sales for the second quarter of 2017. For the first half of 2018, the segment's net sales represented 66% of our consolidated net sales, compared to 68% of our consolidated net sales for the first half of 2017.

[0000068505-18-000023:mdna:74]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Segment net sales | $ | 1,189 |  |  | $ | 1,047 |  |  | 14 | % |  | $ | 2,141 |  |  | $ | 1,901 |  |  | 13 | % |
| Operating earnings | 175 |  |  | 190 |  |  | (8 | )% |  | 265 |  |  | 287 |  |  | (8 | )% |

[0000068505-18-000023:mdna:75]
Three months ended June 30, 2018 compared to three months ended July 1, 2017

[0000068505-18-000023:mdna:76]
The segment’s net sales increased $142 million, to $1.2 billion in the second quarter of 2018, as compared to $1.0 billion during the second quarter of 2017. The increase in the segment's net sales was driven by an increase in Devices and Systems and Systems Integration sales. Devices net sales increased in the Americas and EMEA due to the acquisition of Avigilon and growth absent of acquisitions and decreased in AP. Systems and Systems Integration net sales increased in the Americas due to the acquisition of Avigilon and growth absent of acquisitions. Systems and Systems Integration net sales increased in EMEA and AP due to the acquisition of Avigilon.

[0000068505-18-000023:mdna:77]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in the second quarter of 2018, compared to 72% of the segment's net sales in the second quarter of 2017.

[0000068505-18-000023:mdna:78]
The segment had operating earnings of $175 million in the second quarter of 2018, compared to $190 million in the second quarter of 2017. The decrease in operating earnings in the second quarter of 2018 compared to the second quarter of 2017 was driven by higher SG&A expenses, R&D expenditures, and Other charges driven by the change in classification of our third-party sales commissions from the adoption of ASC 606, increased expenses associated with acquired businesses, and increases in amortization of intangibles and reorganization of business charges, partially offset by higher net sales.

[0000068505-18-000023:mdna:79]
Six months ended June 30, 2018 compared to six months ended July 1, 2017

[0000068505-18-000023:mdna:80]
The segment’s net sales increased $240 million, to $2.1 billion in the first half of 2018, as compared to $1.9 billion during the first half of 2017. The increase in the segment's net sales was driven by an increase in Devices and Systems and Systems Integration sales. Devices net sales increased in the Americas and EMEA due to the acquisition of Avigilon and growth absent of acquisitions and decreased in AP. Systems and Systems Integration net sales increased in the Americas due to the acquisition of Avigilon. Systems and Systems Integration net sales increased in EMEA and AP due to the acquisition of Avigilon and growth absent of acquisitions.

[0000068505-18-000023:mdna:81]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 74% of the segment’s net sales in the first half of 2018, compared to 73% of the segment's net sales in the first half of 2017.

[0000068505-18-000023:mdna:82]
The segment had operating earnings of $265 million in the first half of 2018, compared to $287 million in the first half of 2017. The decrease in operating earnings in the first half of 2018 compared to the first half of 2017 was driven by higher SG&A expenses, R&D expenditures, and Other charges driven by the change in classification of our third-party sales commissions from the adoption of ASC 606, increased expenses associated with acquired businesses, and increases in amortization of intangibles, reorganization of business charges and acquisition-related transaction fees, partially offset by higher net sales.

[0000068505-18-000023:mdna:83]
Services and Software Segment

[0000068505-18-000023:mdna:84]
For second quarter of 2018, the segment’s net sales represented 32% of our consolidated net sales, compared to 30% of our consolidated net sales for the second quarter of 2017. For the first half of 2018, the segment's net sales represented 34% of our consolidated net sales, compared to 32% of our consolidated net sales for the first half of 2017.

[0000068505-18-000023:mdna:85]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Segment net sales | $ | 571 |  |  | $ | 450 |  |  | 27 | % |  | $ | 1,086 |  |  | $ | 876 |  |  | 24 | % |
| Operating earnings | 98 |  |  | 71 |  |  | 38 | % |  | 180 |  |  | 146 |  |  | 23 | % |

[0000068505-18-000023:mdna:86]
Three months ended June 30, 2018 compared to three months ended July 1, 2017

[0000068505-18-000023:mdna:87]
The segment’s net sales increased $121 million, or 27%, to $571 million in the second quarter of 2018, as compared to $450 million in the second quarter of 2017. The increase in the segment's net sales was driven by the Plant and Kodiak Networks acquisitions within the Software business, as well as growth absent of acquisitions in both Services and Software. On a geographic basis, net sales for the second quarter of 2018 increased in every region, compared to the second quarter of 2017.

[0000068505-18-000023:mdna:88]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the second quarter of 2018, compared to 55% of the segment’s net sales in the second quarter of 2017.

[0000068505-18-000023:mdna:89]
The segment had operating earnings of $98 million in the second quarter of 2018, compared to $71 million in the second quarter of 2017. The increase in operating earnings in the second quarter of 2018 compared to the second quarter of 2017 was driven by higher sales, partially offset by higher SG&A expenses, R&D expenditures, and Other charges driven by the change in classification of our third-party sales commissions from the adoption of ASC 606, increased expenses associated with acquired businesses, and increases in amortization of intangibles and reorganization of business charges.

[0000068505-18-000023:mdna:90]
Six months ended June 30, 2018 compared to six months ended July 1, 2017

[0000068505-18-000023:mdna:91]
The segment’s net sales increased $210 million, or 24%, to $1.1 billion in the first half of 2018, as compared to $876 million in the first half of 2017. The increase in the segment's net sales was driven by the Plant and Kodiak Networks acquisitions within the Software business and the Interexport acquisition within Services, as well as growth absent of acquisitions in both Services and Software. On a geographic basis, net sales for the first half of 2018 increased in every region, compared to the first half of 2017.

[0000068505-18-000023:mdna:92]
Net sales in the Americas continued to comprise a significant portion of the segment’s business, accounting for approximately 58% of the segment’s net sales in the first half of 2018, compared to 54% of the segment’s net sales in the first half of 2017.

[0000068505-18-000023:mdna:93]
The segment had operating earnings of $180 million in the first half of 2018, compared to $146 million in the first half of 2017. The increase in operating earnings in the first half of 2018 compared to the first half of 2017 was driven by higher sales, partially offset by higher SG&A expenses, R&D expenditures, and Other charges driven by the change in classification of our third-party sales commissions from the adoption of ASC 606, increased expenses associated with acquired businesses, and increases in amortization of intangibles, reorganization of business charges and acquisition-related transaction fees.

[0000068505-18-000023:mdna:94]
[same as prior period, unchanged from 0000068505-18-000017:mdna:67]

[0000068505-18-000023:mdna:95]
During the second quarter of 2018, we recorded net reorganization of business charges of $25 million including $18 million of charges recorded within Other charges and $7 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $25 million were charges of $27 million related to employee separation costs and $1 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-18-000023:mdna:96]
During the first half of 2018, we recorded net reorganization of business charges of $38 million including $26 million of charges recorded within Other charges and $12 million in Cost of sales in our condensed consolidated statements of operations. Included in the $38 million were charges of $49 million related to employee separation costs and $3 million related to exit costs, partially offset by $14 million of reversals for accruals no longer needed.

[0000068505-18-000023:mdna:97]
During the second quarter of 2017, we recorded net reorganization of business charges of $3 million including $1 million of charges recorded within Other charges and $2 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $3 million were charges of $8 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-18-000023:mdna:98]
During the first half of 2017, we recorded net reorganization of business charges of $22 million including $16 million of charges recorded within Other charges and $6 million in Cost of sales in our condensed consolidated statements of operations. Included in the $22 million were charges of $23 million related to employee separation costs and $4 million related to exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-18-000023:mdna:99]
[same as prior period, unchanged from 0000068505-18-000017:mdna:70]

[0000068505-18-000023:mdna:100]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Products and Systems Integration | $ | 19 |  |  | $ | 2 |  |  | $ | 28 |  |  | $ | 16 |  |
| Services and Software | 6 |  |  | 1 |  |  | 10 |  |  | 6 |  |
|  | $ | 25 |  |  | $ | 3 |  |  | $ | 38 |  |  | $ | 22 |  |

[0000068505-18-000023:mdna:101]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $36 million in the first half of 2018 and $56 million in the first half of 2017. The reorganization of business accruals at June 30, 2018 were $52 million, of which $43 million relate to employee separation costs that are expected to be paid within one year and $9 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-18-000023:mdna:102]
[same as prior period, unchanged from 0000068505-18-000017:mdna:73]

[0000068505-18-000023:mdna:103]
We decreased the aggregate of our cash and cash equivalent balances by $327 million from $1.3 billion as of December 31, 2017 to $941 million as of June 30, 2018. As highlighted in the condensed consolidated statements of cash flows, our liquidity and available capital resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0000068505-18-000023:mdna:104]
[same as prior period, unchanged from 0000068505-18-000017:mdna:75]

[0000068505-18-000023:mdna:105]
At June 30, 2018, $513 million of the $941 million cash and cash equivalents balance was held in the U.S. and $428 million was held by us or our subsidiaries in other countries. Restricted cash was $63 million at June 30, 2018 and December 31, 2017.

[0000068505-18-000023:mdna:106]
[same as prior period, unchanged from 0000068505-18-000017:mdna:77]

[0000068505-18-000023:mdna:107]
Net cash used for operating activities in the first half of 2018 was $75 million, as compared to $315 million provided by operating activities in the first half of 2017. Operating cash flows in the first half of 2018, as compared to the first half of 2017, were negatively impacted by the $500 million contribution to our U.S. pension plan, higher incentive payments, higher tax payments and the recovery of financial receivables owed to us in the first quarter of 2017. The contribution to our U.S. pension plan moves the next anticipated required contribution to 2024, or beyond.

[0000068505-18-000023:mdna:108]
[same as prior period, unchanged from 0000068505-18-000017:mdna:79]

[0000068505-18-000023:mdna:109]
Net cash used by investing activities was $1.2 billion in the first half of 2018, compared to $189 million in the first half of 2017. The $1.2 billion of cash used in the first half of 2018 included $1.2 billion used for acquisitions and investments and $82 million in capital expenditures, partially offset by $79 million of proceeds from sales of investments and businesses. The cash usage of $189 million in the first half of 2017 consisted primarily of $140 million cash used for acquisitions and investments and $121 million in capital expenditures, partially offset by $72 million of proceeds from the sale of investments and businesses.

[0000068505-18-000023:mdna:110]
Acquisition and Investments:  We used net cash for acquisitions and investments of $1.2 billion during the first half of 2018 compared to $140 million in the first half of 2017. The cash used during the first half of 2018 was primarily used for the acquisitions of Avigilon for a total of $903 million, net of cash acquired, and Plant for total of $237 million, net of cash acquired. The cash used during the first half of 2017 was used for several debt and equity investments and the acquisition of Interexport for $55 million, net of cash acquired.

[0000068505-18-000023:mdna:111]
Sales of Investments and Businesses:  We received $79 million of proceeds related to the sales of investments and businesses in the first half of 2018 compared to $72 million in the first half of 2017. The proceeds in the first half of 2018 primarily consisted of $60 million of excess cash withdrawn from company-sponsored life insurance investments. The proceeds from the first quarter of 2017 primarily consisted of the sales of various debt and equity investments.

[0000068505-18-000023:mdna:112]
Capital Expenditures:  Capital expenditures decreased in the first half of 2018 to $82 million, compared to $121 million in the first half of 2017. The decrease in capital expenditures was primarily related to lower information technology spend.

[0000068505-18-000023:mdna:113]
37

[0000068505-18-000023:mdna:114]
[same as prior period, unchanged from 0000068505-18-000017:mdna:84]

[0000068505-18-000023:mdna:115]
Net cash provided by financing activities was $922 million in the first half of 2018, compared to $385 million used in the first half of 2017. Cash provided by financing activities in the first half of 2018 was primarily comprised of $1.3 billion of proceeds from the issuance of debt and $59 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan, partially offset by: (i) $197 million used for the repayment of debt, (ii) $168 million of cash used for the payment of dividends, and (iii) $66 million used for purchases under our share repurchase program. Net cash used for financing activities in the first half of 2017 was primarily comprised of $258 million used for purchases under our share repurchase program and $154 million of cash used for the payment of dividends, partially offset by $28 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-18-000023:mdna:116]
Current and Long-Term Debt:  We had outstanding long-term debt of $5.6 billion and $4.5 billion, including the current portions of $347 million and $52 million at June 30, 2018 and December 31, 2017, respectively.

[0000068505-18-000023:mdna:117]
To complete the acquisition of Avigilon during the quarter ended March 31, 2018, we entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable monthly, subject to our discretion. The weighted average borrowing rate for amounts outstanding during the quarter ended June 30, 2018 was 3.35%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-18-000023:mdna:118]
Also in conjunction with the acquisition of Avigilon in March 2018, we assumed $75 million of borrowings under Avigilon's revolving credit facility, of which $35 million was repaid during the first quarter of 2018 with the remaining $40 million paid during the second quarter of 2018, resulting in the closure of the facility.

[0000068505-18-000023:mdna:119]
In February of 2018, we issued $500 million of 4.60% Senior notes due 2028. After debt issuance costs and debt discounts, we recognized net proceeds of $497 million. These proceeds were then used to make a $500 million contribution to our U.S. pension plan in the first quarter of 2018.

[0000068505-18-000023:mdna:120]
[same as prior period, unchanged from 0000068505-18-000017:mdna:89]

[0000068505-18-000023:mdna:121]
[same as prior period, unchanged from 0000068505-18-000017:mdna:90]

[0000068505-18-000023:mdna:122]
Share Repurchase Program: During the six months ended June 30, 2018, we paid an aggregate of $66 million, including transaction costs, to repurchase approximately 0.6 million shares at an average price of $101.54 per share. As of June 30, 2018, the Company had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-18-000023:mdna:123]
Payment of Dividends: During the second quarter of 2018, we paid $84 million in cash dividends to holders of our common stock. During the first half of 2018, we paid $168 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $84 million in cash dividends to holders of our common stock.

[0000068505-18-000023:mdna:124]
Anticipated Activity:  We currently have an $83 million deferred consideration related to the Airwave acquisition within Accrued liabilities. This will be paid in the fourth quarter of 2018.

[0000068505-18-000023:mdna:125]
[same as prior period, unchanged from 0000068505-18-000017:mdna:93]

[0000068505-18-000023:mdna:126]
As of June 30, 2018, we had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). During the first quarter of 2018, $400 million was borrowed under this facility for the Avigilon acquisition, of which $100 million was repaid during the three months ended June 30, 2018. As of June 30, 2018, the outstanding loan amounted to $300 million. Subsequent to the quarter, we paid an additional $50 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The weighted average borrowing rate on outstanding amounts was 3.75%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of June 30, 2018.

[0000068505-18-000023:mdna:127]
[same as prior period, unchanged from 0000068505-18-000017:mdna:95]

[0000068505-18-000023:mdna:128]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $128 million at June 30, 2018, compared to $93 million at December 31, 2017.

[0000068505-18-000023:mdna:129]
38

[0000068505-18-000023:mdna:130]
[same as prior period, unchanged from 0000068505-18-000017:mdna:97]

[0000068505-18-000023:mdna:131]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended June 30, 2018 and July 1, 2017:

[0000068505-18-000023:mdna:132]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Accounts receivable sales proceeds | $ | 22 |  |  | $ | 61 |  |  | $ | 76 |  |  | $ | 80 |  |
| Long-term receivables sales proceeds | 15 |  |  | 22 |  |  | 28 |  |  | 68 |  |
| Total proceeds from sales of accounts receivable | $ | 37 |  |  | $ | 83 |  |  | $ | 104 |  |  | $ | 148 |  |

[0000068505-18-000023:mdna:133]
At June 30, 2018, the Company had retained servicing obligations for $844 million of long-term receivables, compared to $873 million at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000023:mdna:134]
Other Contingencies

[0000068505-18-000023:mdna:135]
[same as prior period, unchanged from 0000068505-18-000017:mdna:102]

[0000068505-18-000023:mdna:136]
[same as prior period, unchanged from 0000068505-18-000017:mdna:103]

[0000068505-18-000023:mdna:137]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at June 30, 2018.

[0000068505-18-000023:mdna:138]
[same as prior period, unchanged from 0000068505-18-000017:mdna:105]

[0000068505-18-000023:mdna:139]
[same as prior period, unchanged from 0000068505-18-000017:mdna:106]

[0000068505-18-000023:mdna:140]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. We will adopt the ASU on January 1, 2019, utilizing the modified retrospective method upon adoption. We have begun to assess the impact of the ASU on our financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, we expect a material impact to our balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards.

[0000068505-18-000023:mdna:141]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for us on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The guidance related to cash flow and net investment hedges existing at the date of adoption should be applied using the modified retrospective method by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption. The guidance related to presentation and disclosure should be applied prospectively. We are currently assessing the impact of this ASU, including transition elections and required elections, on our consolidated financial statements and disclosures.

[0000068505-18-000023:mdna:142]
Recently Adopted Accounting Pronouncements

[0000068505-18-000023:mdna:143]
We adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. We recognized $30 million related to the cumulative effect of applying the ASU as an adjustment to our opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, we will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-18-000023:mdna:144]
We adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. We have restated our comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of our net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. We recorded $20 million and $4 million in the three months ended June 30, 2018 and July 1, 2017, respectively, and $40 million and $1 million in the six months ended June 30, 2018 and July 1, 2017, respectively.

[0000068505-18-000023:mdna:145]
We adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. We recognized the cumulative effect of initially applying the new revenue standard as an adjustment to our opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-18-000023:mdna:146]
We retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of our System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as we stand ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-18-000023:mdna:147]
[same as prior period, unchanged from 0000068505-18-000017:mdna:114]

[0000068505-18-000023:mdna:148]
[same as prior period, unchanged from 0000068505-18-000017:mdna:115]

[0000068505-18-000023:mdna:149]
Historically, we presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, we have determined that we are the principal in contracts that involve a third-party sales representative. Thus, we present associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for our cost of third-party commissions.

[0000068505-18-000023:mdna:150]
[same as prior period, unchanged from 0000068505-18-000017:mdna:118]

[0000068505-18-000023:mdna:151]
[same as prior period, unchanged from 0000068505-18-000017:mdna:119]

[0000068505-18-000023:mdna:152]
41
