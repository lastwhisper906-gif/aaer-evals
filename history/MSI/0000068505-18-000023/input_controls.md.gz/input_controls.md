# MSI 10-Q controls and the auditor's report


## item_4_controls

[0000068505-18-000023:item_4_controls:1]
Item 4. Controls and Procedures

[0000068505-18-000023:item_4_controls:2]
(a) Evaluation of disclosure controls and procedures. Under the supervision and with the participation of our senior management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), as of the end of the period covered by this quarterly report (the “Evaluation Date”). Based on this evaluation, our chief executive officer and chief financial officer concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to Motorola Solutions, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (“SEC”) reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms and (ii) is accumulated and communicated to Motorola Solutions’ management, including our chief executive officer and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000068505-18-000023:item_4_controls:3]
(b) Changes in internal control over financial reporting. Effective January 1, 2018, we adopted the new revenue standard ASC 606. We have implemented new accounting processes related to revenue recognition and related disclosures, including related control activities. There were no changes in our internal control over financial reporting that occurred during the quarter ended June 30, 2018, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.

[0000068505-18-000023:item_4_controls:4]
We are in the process of a multi-year phased upgrade and consolidation of our ERP systems into a single global platform across our businesses. In April 2017, we implemented our new ERP system which is functioning as designed and continuing to support our business. Our new ERP system includes the replacement of regional systems supporting our product based business and back end finance processes including our general ledger. The system also includes the replacement of our current indirect procurement and service contract systems. We have made appropriate changes to our internal controls over financial reporting as we have implemented the new system. We plan to continue to migrate the remaining parts of the business off regional systems as we work towards a single global platform. We will continue to modify our internal controls in response to changes in the underlying ERP on future phases as needed.

[0000068505-18-000023:item_4_controls:5]
43
