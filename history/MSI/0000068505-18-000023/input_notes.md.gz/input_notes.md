# MSI notes — 0000068505-18-000023


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-18-000023:notes:1]
[same as prior period, unchanged from 0000068505-18-000017:notes:1]

[0000068505-18-000023:notes:2]
|  | June 30, 2018 |  | December 31, 2017 |
| Corporate bonds | $ | 2 |  |  | $ | 2 |  |
| Common stock | 10 |  |  | 13 |  |
|  | 12 |  |  | 15 |  |
| Strategic investments, at cost | 65 |  |  | 78 |  |
| Company-owned life insurance policies | 81 |  |  | 141 |  |
| Equity method investments | 14 |  |  | 13 |  |
|  | $ | 172 |  |  | $ | 247 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-18-000023:notes:3]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of June 30, 2018 and December 31, 2017 were as follows:

[0000068505-18-000023:notes:4]
| June 30, 2018 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Corporate bonds | — |  |  | 2 |  |  | 2 |  |
| Common stock | — |  |  | 10 |  |  | 10 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 8 |  |  | $ | 8 |  |

[0000068505-18-000023:notes:5]
[same as prior period, unchanged from 0000068505-18-000017:notes:5]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-18-000023:notes:6]
[same as prior period, unchanged from 0000068505-18-000017:notes:6]

[0000068505-18-000023:notes:7]
[same as prior period, unchanged from 0000068505-18-000017:notes:7]

[0000068505-18-000023:notes:8]
[same as prior period, unchanged from 0000068505-18-000017:notes:8]

[0000068505-18-000023:notes:9]
|  | June 30, 2018 |  | December 31, 2017 |
| Long-term receivables | $ | 30 |  |  | $ | 37 |  |
| Less current portion | (16 | ) |  | (18 | ) |
| Non-current long-term receivables | $ | 14 |  |  | $ | 19 |  |

[0000068505-18-000023:notes:10]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $128 million at June 30, 2018, compared to $93 million at December 31, 2017.

[0000068505-18-000023:notes:11]
[same as prior period, unchanged from 0000068505-18-000017:notes:11]

[0000068505-18-000023:notes:12]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended June 30, 2018 and July 1, 2017:

[0000068505-18-000023:notes:13]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Accounts receivable sales proceeds | $ | 22 |  |  | $ | 61 |  |  | $ | 76 |  |  | $ | 80 |  |
| Long-term receivables sales proceeds | 15 |  |  | 22 |  |  | 28 |  |  | 68 |  |
| Total proceeds from receivable sales | $ | 37 |  |  | $ | 83 |  |  | $ | 104 |  |  | $ | 148 |  |

[0000068505-18-000023:notes:14]
At June 30, 2018, the Company had retained servicing obligations for $844 million of long-term receivables, compared to $873 million at December 31, 2017. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-18-000023:notes:15]
[same as prior period, unchanged from 0000068505-18-000017:notes:15]

[0000068505-18-000023:notes:16]
An aging analysis of financing receivables at June 30, 2018 and December 31, 2017 is as follows:

[0000068505-18-000023:notes:17]
| June 30, 2018 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 17 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Commercial loans and leases secured | 13 |  |  | 1 |  |  | — |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 30 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 3 |  |

[0000068505-18-000023:notes:18]
[same as prior period, unchanged from 0000068505-18-000017:notes:18]


## msi:OtherChargesTableTextBlock

[0000068505-18-000023:notes:19]
[same as prior period, unchanged from 0000068505-18-000017:notes:19]

[0000068505-18-000023:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 14) | $ | 53 |  |  | $ | 37 |  |  | $ | 94 |  |  | $ | 73 |  |
| Reorganization of business (Note 13) | 18 |  |  | 1 |  |  | 26 |  |  | 16 |  |
| Building impairment | — |  |  | — |  |  | — |  |  | 8 |  |
| Loss (Gain) on legal settlements | — |  |  | (1 | ) |  | 1 |  |  | (2 | ) |
| Gain on recovery of financial receivables | — |  |  | — |  |  | — |  |  | (42 | ) |
| Acquisition-related transaction fees | — |  |  | — |  |  | 17 |  |  | 1 |  |
|  | $ | 71 |  |  | $ | 37 |  |  | $ | 138 |  |  | $ | 54 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-18-000023:notes:21]
[same as prior period, unchanged from 0000068505-18-000017:notes:21]

[0000068505-18-000023:notes:22]
| June 30, 2018 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 19 |  |  | $ | 28 |  |
| Services and Software | 6 |  |  | 10 |  |
|  | $ | 25 |  |  | $ | 38 |  |

[0000068505-18-000023:notes:23]
| July 1, 2017 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 2 |  |  | $ | 16 |  |
| Services and Software | 1 |  |  | 6 |  |
|  | $ | 3 |  |  | $ | 22 |  |


## msi:RevenuefromContractWithCustomerPolicyTextBlock

[0000068505-18-000023:notes:24]
In accordance with ASC 606, the Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services. The Company records revenue following the five steps below:

[0000068505-18-000023:notes:25]
1.Identify the contract with customers: A contract is an agreement between two or more parties that creates               enforceable rights and obligations and specifies that enforceability is a matter of law. Contracts shall be accounted for when: (i) the parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations, (ii) the Company can identify each party’s rights regarding the goods or services to be transferred, (iii) the Company can identify the payment terms for the goods or services to be transferred, (iv) the contract has commercial substance (that is, the risk, timing, or amount of the Company’s future cash flow is expected to change as a result of the contract), and (v) it is probable that the Company will collect substantially all of the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. It is the Company’s customary business practice to obtain a signed legal document as evidence of an arrangement.

[0000068505-18-000023:notes:26]
2.Identify performance obligations in contracts: The goods or services promised in a contract must be evaluated at inception to identify as a performance obligation each promise to transfer to the customer either: (i) a distinct good or service, or (ii) a series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer.

[0000068505-18-000023:notes:27]
3.Determine the transaction price: The transaction price is the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to a customer, excluding amounts collected on behalf of third parties. In determining the transaction price, the Company considers the following components: (i) variable consideration, (ii) significant financing, (iii) noncash consideration, and (iv) consideration payable to a customer.

[0000068505-18-000023:notes:28]
4.Allocate the transaction price: For a contract that has more than one distinct performance obligation, the Company must allocate the transaction price to each distinct performance obligation in an amount that depicts the amount of consideration to which the Company expects to be entitled in exchange for satisfying that specific performance obligation.

[0000068505-18-000023:notes:29]
5.Recognize revenue when or as the entity satisfies a performance obligation: The Company recognizes revenue when, or as, it satisfies a performance obligation by transferring control of a promised good or service to a customer.


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-18-000023:notes:30]
[same as prior period, unchanged from 0000068505-18-000017:notes:24]

[0000068505-18-000023:notes:31]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 4 |  |
| Selling, general and administrative expenses | 11 |  |  | 11 |  |  | 21 |  |  | 22 |  |
| Research and development expenditures | 4 |  |  | 3 |  |  | 8 |  |  | 7 |  |
| Share-based compensation expense included in Operating earnings | 17 |  |  | 16 |  |  | 34 |  |  | 33 |  |
| Tax benefit | 4 |  |  | 5 |  |  | 8 |  |  | 11 |  |
| Share-based compensation expense, net of tax | $ | 13 |  |  | $ | 11 |  |  | $ | 26 |  |  | $ | 22 |  |
| Decrease in basic earnings per share | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.16 | ) |  | $ | (0.13 | ) |
| Decrease in diluted earnings per share | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.15 | ) |  | $ | (0.13 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-18-000023:notes:32]
[same as prior period, unchanged from 0000068505-18-000017:notes:26]

[0000068505-18-000023:notes:33]
|  | June 30, 2018 |  | December 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 510 |  |  | $ | 19 |  |  | $ | 12 |  |  | $ | 8 |  |
| Services and Software | 1,238 |  |  | 389 |  |  | 1,171 |  |  | 314 |  |
|  | $ | 1,748 |  |  | $ | 408 |  |  | $ | 1,183 |  |  | $ | 322 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-18-000023:notes:34]
[same as prior period, unchanged from 0000068505-18-000017:notes:28]

[0000068505-18-000023:notes:35]
|  | June 30, 2018 |  | December 31, 2017 |
| Defined benefit plans | $ | 1,464 |  |  | $ | 2,019 |  |
| Non-current contract liabilities (Note 2) | 180 |  |  | — |  |
| Deferred revenue (Note 1) | — |  |  | 169 |  |
| Unrecognized tax benefits | 52 |  |  | 54 |  |
| Deferred income taxes | 240 |  |  | 115 |  |
| Other | 217 |  |  | 228 |  |
|  | $ | 2,153 |  |  | $ | 2,585 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-18-000023:notes:36]
[same as prior period, unchanged from 0000068505-18-000017:notes:30]

[0000068505-18-000023:notes:37]
[same as prior period, unchanged from 0000068505-18-000017:notes:31]

[0000068505-18-000023:notes:38]
[same as prior period, unchanged from 0000068505-18-000017:notes:32]

[0000068505-18-000023:notes:39]
During the six months ending June 30, 2018, the Company recognized $17 million of acquisition-related transaction fees for the Avigilon and Plant acquisitions.

[0000068505-18-000023:notes:40]
During the six months ended July 1, 2017, the Company recognized $8 million of building impairments related to the sale of its Basingstoke building.

[0000068505-18-000023:notes:41]
During the six months ended July 1, 2017, the Company recognized a net gain of $42 million related to the recovery, through legal procedures to seize and liquidate assets, of financial receivables owed to the Company by a former customer of its legacy Networks business.

[0000068505-18-000023:notes:42]
[same as prior period, unchanged from 0000068505-18-000017:notes:36]

[0000068505-18-000023:notes:43]
[same as prior period, unchanged from 0000068505-18-000017:notes:37]

[0000068505-18-000023:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (63 | ) |  | $ | (55 | ) |  | $ | (117 | ) |  | $ | (109 | ) |
| Interest income | 5 |  |  | 4 |  |  | 13 |  |  | 7 |  |
|  | $ | (58 | ) |  | $ | (51 | ) |  | $ | (104 | ) |  | $ | (102 | ) |
| Other: |  |  |  |  |  |  |  |
| Net periodic postretirement benefit (Note 7) | $ | 20 |  |  | $ | 12 |  |  | $ | 40 |  |  | $ | 24 |  |
| Non-U.S. pension settlement loss (Note 7) | — |  |  | (16 | ) |  | — |  |  | (25 | ) |
| Foreign currency gain (loss) | 11 |  |  | (20 | ) |  | — |  |  | (22 | ) |
| Gain (loss) on derivative instruments | (19 | ) |  | 18 |  |  | (23 | ) |  | 11 |  |
| Gains on equity method investments | — |  |  | 1 |  |  | 1 |  |  | — |  |
| Other | 1 |  |  | 1 |  |  | (2 | ) |  | 3 |  |
|  | $ | 13 |  |  | $ | (4 | ) |  | $ | 16 |  |  | $ | (9 | ) |

[0000068505-18-000023:notes:45]
During the three months ended June 30, 2018, the Company recognized a foreign currency gain of $11 million, primarily driven by the Euro and British pound, and a loss of $19 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-18-000023:notes:46]
During the six months ended June 30, 2018, the Company recognized a loss of $23 million on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations. The loss includes a loss of $14 million on foreign currency derivatives put in place to minimize the exposure to the Canadian dollar related to the purchase of Avigilon.

[0000068505-18-000023:notes:47]
During the three and six months ended July 1, 2017, the Company recognized foreign currency losses of $20 million and $22 million, respectively, primarily driven by the Euro and British Pound, partially offset by gains of $18 million and $11 million, respectively, on derivative instruments put in place to minimize the foreign exchange risk related to currency fluctuations.

[0000068505-18-000023:notes:48]
[same as prior period, unchanged from 0000068505-18-000017:notes:41]

[0000068505-18-000023:notes:49]
[same as prior period, unchanged from 0000068505-18-000017:notes:42]

[0000068505-18-000023:notes:50]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 180 |  |  | $ | 131 |  |  | $ | 297 |  |  | $ | 208 |  |
| Weighted average common shares outstanding | 162.2 |  |  | 163.1 |  |  | 161.7 |  |  | 163.7 |  |
| Per share amount | $ | 1.11 |  |  | $ | 0.80 |  |  | $ | 1.83 |  |  | $ | 1.27 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 180 |  |  | $ | 131 |  |  | $ | 297 |  |  | $ | 208 |  |
| Weighted average common shares outstanding | 162.2 |  |  | 163.1 |  |  | 161.7 |  |  | 163.7 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 3.8 |  |  | 3.1 |  |  | 4.0 |  |  | 3.2 |  |
| Senior Convertible Notes | 5.7 |  |  | 2.8 |  |  | 5.4 |  |  | 2.6 |  |
| Diluted weighted average common shares outstanding | 171.7 |  |  | 169.0 |  |  | 171.1 |  |  | 169.5 |  |
| Per share amount | $ | 1.05 |  |  | $ | 0.78 |  |  | $ | 1.73 |  |  | $ | 1.23 |  |

[0000068505-18-000023:notes:51]
In the computation of diluted earnings per common share for the three months ended June 30, 2018, the assumed exercise of 1.4 million options, including 1.2 million subject to market-based contingent stock agreements, was excluded because their inclusion would have been antidilutive. For the six months ended June 30, 2018, the assumed exercise of 2.9 million options, including 2.4 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-18-000023:notes:52]
For the three months ended July 1, 2017, the assumed exercise of 2.1 million options, including 1.8 million subject to market-based contingent stock agreements, was excluded because their inclusion would have been antidilutive. For the six months ended July 1, 2017, the assumed exercise of 2.4 million options, including 2.0 million subject to market-based contingent stock agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-18-000023:notes:53]
[same as prior period, unchanged from 0000068505-18-000017:notes:45]

[0000068505-18-000023:notes:54]
[same as prior period, unchanged from 0000068505-18-000017:notes:46]

[0000068505-18-000023:notes:55]
[same as prior period, unchanged from 0000068505-18-000017:notes:47]

[0000068505-18-000023:notes:56]
[same as prior period, unchanged from 0000068505-18-000017:notes:48]

[0000068505-18-000023:notes:57]
|  | June 30, 2018 |  | December 31, 2017 |
| Accounts receivable | $ | 1,203 |  |  | $ | 1,568 |  |
| Less allowance for doubtful accounts | (44 | ) |  | (45 | ) |
|  | $ | 1,159 |  |  | $ | 1,523 |  |

[0000068505-18-000023:notes:58]
During the six months ended June 30, 2018, $297 million of Unbilled accounts receivable were reclassified to Contract assets and $24 million of non-customer miscellaneous receivables were reclassified to Other current assets as a result of the adoption of ASC 606. In addition, $87 million of receivables were acquired with the purchases of Avigilon and Plant.

[0000068505-18-000023:notes:59]
[same as prior period, unchanged from 0000068505-18-000017:notes:51]

[0000068505-18-000023:notes:60]
[same as prior period, unchanged from 0000068505-18-000017:notes:52]

[0000068505-18-000023:notes:61]
|  | June 30, 2018 |  | December 31, 2017 |
| Finished goods | $ | 215 |  |  | $ | 178 |  |
| Work-in-process and production materials | 307 |  |  | 282 |  |
|  | 522 |  |  | 460 |  |
| Less inventory reserves | (131 | ) |  | (133 | ) |
|  | $ | 391 |  |  | $ | 327 |  |

[0000068505-18-000023:notes:62]
During the six months ended June 30, 2018, the increase in Inventories, net was primarily driven by the acquisitions of Avigilon and Plant.

[0000068505-18-000023:notes:63]
[same as prior period, unchanged from 0000068505-18-000017:notes:55]

[0000068505-18-000023:notes:64]
[same as prior period, unchanged from 0000068505-18-000017:notes:56]

[0000068505-18-000023:notes:65]
|  | June 30, 2018 |  | December 31, 2017 |
| Costs and earnings in excess of billings (Note 1) | $ | — |  |  | $ | 549 |  |
| Current contract cost assets (Note 2) | 47 |  |  | 62 |  |
| Tax-related refunds receivable | 103 |  |  | 90 |  |
| Other | 180 |  |  | 131 |  |
|  | $ | 330 |  |  | $ | 832 |  |

[0000068505-18-000023:notes:66]
[same as prior period, unchanged from 0000068505-18-000017:notes:58]

[0000068505-18-000023:notes:67]
[same as prior period, unchanged from 0000068505-18-000017:notes:59]

[0000068505-18-000023:notes:68]
|  | June 30, 2018 |  | December 31, 2017 |
| Land | $ | 11 |  |  | $ | 11 |  |
| Building | 354 |  |  | 316 |  |
| Machinery and equipment | 2,190 |  |  | 2,122 |  |
|  | 2,555 |  |  | 2,449 |  |
| Less accumulated depreciation | (1,660 | ) |  | (1,593 | ) |
|  | $ | 895 |  |  | $ | 856 |  |

[0000068505-18-000023:notes:69]
During the six months ended June 30, 2018, the increase in Property, plant and equipment was primarily driven by the acquisitions of Avigilon and Plant.

[0000068505-18-000023:notes:70]
Depreciation expense for the three months ended June 30, 2018 and July 1, 2017 was $43 million and $49 million, respectively. Depreciation expense for the six months ended June 30, 2018 and July 1, 2017 was $84 million and $93 million, respectively.

[0000068505-18-000023:notes:71]
[same as prior period, unchanged from 0000068505-18-000017:notes:63]

[0000068505-18-000023:notes:72]
Strategic investments include investments in non-public technology-driven startup companies. Strategic investments do not have readily determinable fair values and are recorded at cost less impairments and adjusted for observable fair value movements. The Company did not recognize any impairments or adjustments to fair value during the six months ended June 30, 2018.

[0000068505-18-000023:notes:73]
Company-owned life insurance policies were recorded at their cash surrender value of $81 million and $141 million, at June 30, 2018 and December 31, 2017, respectively. During the six months ended June 30, 2018, the Company withdrew $60 million of excess cash from its company-sponsored life insurance investments.

[0000068505-18-000023:notes:74]
As of December 31, 2017, the Company had unrealized gains of $8 million related to available-for-sale securities, which were realized upon the sale of the investment in the first half of 2018.

[0000068505-18-000023:notes:75]
During the three months ended June 30, 2018 and July 1, 2017, Losses on the sale of investments and businesses were $1 million. During the six months ended June 30, 2018, Gains on the sale of investments and businesses were $10 million, compared to gains of $2 million during the six months ended July 1, 2017.

[0000068505-18-000023:notes:76]
[same as prior period, unchanged from 0000068505-18-000017:notes:68]

[0000068505-18-000023:notes:77]
[same as prior period, unchanged from 0000068505-18-000017:notes:69]

[0000068505-18-000023:notes:78]
|  | June 30, 2018 |  | December 31, 2017 |
| Defined benefit plan assets | 166 |  |  | 133 |  |
| Tax receivable | 101 |  |  | 101 |  |
| Non-current contract cost assets (Note 2) | 90 |  |  | — |  |
| Other | 63 |  |  | 99 |  |
|  | $ | 420 |  |  | $ | 333 |  |

[0000068505-18-000023:notes:79]
[same as prior period, unchanged from 0000068505-18-000017:notes:71]

[0000068505-18-000023:notes:80]
[same as prior period, unchanged from 0000068505-18-000017:notes:72]

[0000068505-18-000023:notes:81]
|  | June 30, 2018 |  | December 31, 2017 |
| Deferred revenue (Note 1) | $ | — |  |  | $ | 613 |  |
| Compensation | 196 |  |  | 273 |  |
| Billings in excess of costs and earnings (Note 1) | — |  |  | 428 |  |
| Tax liabilities | 105 |  |  | 107 |  |
| Deferred consideration on Airwave acquisition | 83 |  |  | 83 |  |
| Dividend payable | 84 |  |  | 84 |  |
| Trade liabilities | 150 |  |  | 151 |  |
| Other | 478 |  |  | 547 |  |
|  | $ | 1,096 |  |  | $ | 2,286 |  |

[0000068505-18-000023:notes:82]
[same as prior period, unchanged from 0000068505-18-000017:notes:74]

[0000068505-18-000023:notes:83]
[same as prior period, unchanged from 0000068505-18-000017:notes:75]

[0000068505-18-000023:notes:84]
The Company made a $500 million contribution to our U.S. Pension Plans during the six months ended June 30, 2018.

[0000068505-18-000023:notes:85]
During the six months ended June 30, 2018, the deferred income taxes increase was primarily driven by the acquisition of Avigilon.

[0000068505-18-000023:notes:86]
[same as prior period, unchanged from 0000068505-18-000017:notes:78]

[0000068505-18-000023:notes:87]
[same as prior period, unchanged from 0000068505-18-000017:notes:79]

[0000068505-18-000023:notes:88]
During the six months ended June 30, 2018, the Company paid an aggregate of $66 million, including transaction costs, to repurchase approximately 0.6 million shares at an average price of $101.54 per share. As of June 30, 2018, the Company had used approximately $12.4 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.6 billion of authority available for future repurchases.

[0000068505-18-000023:notes:89]
Payment of Dividends: During the three months ended June 30, 2018 and July 1, 2017, the Company paid $84 million and $77 million, respectively, in cash dividends to holders of its common stock. During the six months ended June 30, 2018 and July 1, 2017, the Company paid $168 million and $154 million, respectively, in cash dividends to holders of its common stock.

[0000068505-18-000023:notes:90]
[same as prior period, unchanged from 0000068505-18-000017:notes:82]

[0000068505-18-000023:notes:91]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and six months ended June 30, 2018 and July 1, 2017:

[0000068505-18-000023:notes:92]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (305 | ) |  | $ | (460 | ) |  | $ | (353 | ) |  | $ | (494 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (81 | ) |  | 47 |  |  | (30 | ) |  | 84 |  |
| Tax expense | (5 | ) |  | — |  |  | (8 | ) |  | (3 | ) |
| Other comprehensive income (loss), net of tax | (86 | ) |  | 47 |  |  | (38 | ) |  | 81 |  |
| Balance at end of period | $ | (391 | ) |  | $ | (413 | ) |  | $ | (391 | ) |  | $ | (413 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |
| Other comprehensive income before reclassification adjustment | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Tax expense | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net | — |  |  | — |  |  | (8 | ) |  | — |  |
| Tax expense | — |  |  | — |  |  | 2 |  |  | — |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | — |  |  | — |  |  | (6 | ) |  | — |  |
| Other comprehensive income (loss), net of tax | — |  |  | 4 |  |  | (6 | ) |  | 4 |  |
| Balance at end of period | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,203 | ) |  | $ | (1,804 | ) |  | $ | (2,215 | ) |  | $ | (1,823 | ) |
| Other comprehensive loss before reclassification adjustment, net of tax | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 18 |  |  | 16 |  |  | 36 |  |  | 32 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | (4 | ) |  | (4 | ) |  | (7 | ) |  | (8 | ) |
| Reclassification adjustment - Non-U.S. pension settlement loss into Other income (expense) | — |  |  | 16 |  |  | — |  |  | 25 |  |
| Tax benefit | — |  |  | (3 | ) |  | (3 | ) |  | (5 | ) |
| Reclassification adjustment into Net earnings, net of tax | 14 |  |  | 25 |  |  | 26 |  |  | 44 |  |
| Other comprehensive income, net of tax | 14 |  |  | 14 |  |  | 26 |  |  | 33 |  |
| Balance at end of period | $ | (2,189 | ) |  | $ | (1,790 | ) |  | $ | (2,189 | ) |  | $ | (1,790 | ) |
| Total Accumulated other comprehensive loss | $ | (2,580 | ) |  | $ | (2,199 | ) |  | $ | (2,580 | ) |  | $ | (2,199 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-18-000023:notes:93]
The condensed consolidated financial statements as of June 30, 2018 and for the three and six months ended June 30, 2018 and July 1, 2017 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-18-000023:notes:94]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2017. The results of operations for the three and six months ended June 30, 2018 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-18-000023:notes:95]
[same as prior period, unchanged from 0000068505-18-000017:notes:87]


## us-gaap:CapitalizedContractCostTableTextBlock

[0000068505-18-000023:notes:96]
| (in millions) | January 1, 2018 |  |  | June 30, 2018 |  |
| Current contract cost assets | $ | 62 |  |  | $ | 47 |  |
| Non-current contract cost assets | 85 |  |  | 90 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-18-000023:notes:97]
Commitments and Contingencies

[0000068505-18-000023:notes:98]
Legal Matters

[0000068505-18-000023:notes:99]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-18-000023:notes:100]
Other Indemnifications

[0000068505-18-000023:notes:101]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-18-000023:notes:102]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at June 30, 2018.

[0000068505-18-000023:notes:103]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000068505-18-000023:notes:104]
| (in millions) | January 1, 2018 |  |  | June 30, 2018 |  |
| Receivables | $ | 1,198 |  |  | $ | 1,159 |  |
| Contract assets | 931 |  |  | 760 |  |
| Contract liabilities | 1,082 |  |  | 1,049 |  |
| Non-current contract liabilities | 162 |  |  | 180 |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-18-000023:notes:105]
Debt and Credit Facilities

[0000068505-18-000023:notes:106]
As of June 30, 2018, the Company had a $2.2 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2022 (the "2017 Motorola Solutions Credit Agreement"). During the first quarter of 2018, $400 million was borrowed under this facility for the Avigilon acquisition, of which $100 million was repaid during the three months ended June 30, 2018. As of June 30, 2018, the outstanding loan amount was $300 million. Subsequent to the quarter, the Company paid an additional $50 million. The 2017 Motorola Solutions Credit Agreement includes a $500 million letter of credit sub-limit with $450 million of fronting commitments. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The weighted average borrowing rate on outstanding amounts was 3.75%. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2017 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 30, 2018.

[0000068505-18-000023:notes:107]
To complete the acquisition of Avigilon in the first quarter of 2018, the Company entered into a term loan for $400 million with a maturity date of March 26, 2021 (the “Term Loan”). Interest on the Term Loan is variable and indexed to LIBOR. Interest is payable monthly, subject to the Company's discretion. The weighted average borrowing rate for amounts outstanding during the six months ended June 30, 2018 was 3.35%. Net proceeds after issuance costs were $399 million. No additional borrowings are permitted and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-18-000023:notes:108]
Also in conjunction with the acquisition of Avigilon in March 2018, the Company assumed $75 million of borrowings under Avigilon's revolving credit facility, of which $35 million was repaid during the first quarter of 2018 with the remaining $40 million paid during the second quarter of 2018, resulting in the closure of the facility.

[0000068505-18-000023:notes:109]
In February of 2018, the Company issued $500 million of 4.60% Senior notes due 2028. The Company recognized net proceeds of $497 million after debt issuance costs and debt discounts. These proceeds were then used to make a $500 million contribution to the Company's U.S. pension plan.

[0000068505-18-000023:notes:110]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2.00% Senior Convertible Notes which mature in September 2020. The notes became fully convertible as of August 25, 2017. The notes are convertible based on a conversion rate of 14.7476, as may be adjusted for dividends declared, per $1,000 principal amount (which is currently equal to a conversion price of $67.81 per share). The exercise price adjusts automatically for dividends. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of June 30, 2018 was $682 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-18-000023:notes:111]
[same as prior period, unchanged from 0000068505-18-000017:notes:102]

[0000068505-18-000023:notes:112]
[same as prior period, unchanged from 0000068505-18-000017:notes:103]

[0000068505-18-000023:notes:113]
As of June 30, 2018, the Company had outstanding foreign exchange contracts with notional amounts totaling $681 million, compared to $507 million outstanding at December 31, 2017. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-18-000023:notes:114]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of June 30, 2018, and the corresponding positions as of December 31, 2017:

[0000068505-18-000023:notes:115]
|  | Notional Amount |
| Net Buy (Sell) by Currency | June 30, 2018 |  | December 31, 2017 |
| Euro | $ | 245 |  |  | $ | 149 |  |
| British Pound | 162 |  |  | 72 |  |
| Chinese Renminbi | (68 | ) |  | (73 | ) |
| Australian Dollar | (66 | ) |  | (64 | ) |
| Brazilian Real | (39 | ) |  | (45 | ) |

[0000068505-18-000023:notes:116]
As of the six months ended June 30, 2018, the Company had entered into forward contracts to sell £25 million, expiring in September 2018. The forward contracts have been designated as a net investment hedge which is in place to partially hedge the Company's British pound foreign currency exposure on its net investment in Airwave Solutions Limited. The gains and losses on the Company's net investment in British pound-denominated foreign operations, driven by changes in foreign exchange rates, are economically offset by movements in the fair values of the forward contracts designated as net investment hedges. Any changes in fair value of the net investment hedges are reflected as a component of Accumulated other comprehensive loss. As of June 30, 2018, the fair value of the derivative contracts was a $2 million liability.

[0000068505-18-000023:notes:117]
[same as prior period, unchanged from 0000068505-18-000017:notes:108]

[0000068505-18-000023:notes:118]
Certain of the Company's subsidiaries have variable interest loans denominated in the Euro and Chilean Peso. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as hedges. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swaps was de minimus at June 30, 2018 and December 31, 2017.

[0000068505-18-000023:notes:119]
[same as prior period, unchanged from 0000068505-18-000017:notes:110]

[0000068505-18-000023:notes:120]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of June 30, 2018, all of the counterparties have investment grade credit ratings. As of June 30, 2018, the Company had $4 million of exposure to aggregate net credit risk with all counterparties.

[0000068505-18-000023:notes:121]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of June 30, 2018 and December 31, 2017:

[0000068505-18-000023:notes:122]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| June 30, 2018 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other assets |  | $ | 2 |  |  | Other liabilities |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 4 |  |  | Other current assets |  | $ | 6 |  |  | Accrued liabilities |
| Total derivatives | $ | 4 |  |  |  |  | $ | 8 |  |  |  |

[0000068505-18-000023:notes:123]
[same as prior period, unchanged from 0000068505-18-000017:notes:114]

[0000068505-18-000023:notes:124]
The following table summarizes the effect of derivatives designated as hedging instruments on the Company's condensed consolidated financial statements for the three and six months ended June 30, 2018 and July 1, 2017:

[0000068505-18-000023:notes:125]
|  | Three Months Ended |  | Six Months Ended |  | Balance SheetLocation |
| Loss on Derivative Instruments | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |  |
| Foreign exchange contracts | $ | 5 |  |  | $ | (2 | ) |  | $ | 2 |  |  | $ | (2 | ) |  | Other comprehensive income (loss) |

[0000068505-18-000023:notes:126]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated financial statements for the three and six months ended June 30, 2018 and July 1, 2017:

[0000068505-18-000023:notes:127]
|  | Three Months Ended |  | Six Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |  |
| Foreign exchange contracts | $ | (19 | ) |  | $ | 18 |  |  | $ | (23 | ) |  | $ | 11 |  |  | Other income (expense) |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000068505-18-000023:notes:128]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the three and six months ended June 30, 2018, consistent with the information reviewed by our chief operating decision maker for evaluating the financial performance of operating segments:

[0000068505-18-000023:notes:129]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | Products and Systems Integration |  | Services and Software |  | Products and Systems Integration |  | Services and Software |
| Regions |  |  |  |  |  |  |  |
| Americas | $ | 878 |  |  | $ | 331 |  |  | $ | 1,576 |  |  | $ | 627 |  |
| EMEA | 188 |  |  | 194 |  |  | 345 |  |  | 375 |  |
| AP | 123 |  |  | 46 |  |  | 220 |  |  | 84 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Major Products and Services |  |  |  |  |  |  |  |
| Devices | $ | 725 |  |  | $ | — |  |  | $ | 1,356 |  |  | $ | — |  |
| Systems and Systems Integration | 464 |  |  | — |  |  | 785 |  |  | — |  |
| Services | — |  |  | 456 |  |  | — |  |  | 902 |  |
| Software | — |  |  | 115 |  |  | — |  |  | 184 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |
| Customer Type |  |  |  |  |  |  |  |
| Direct | $ | 740 |  |  | $ | 537 |  |  | $ | 1,357 |  |  | $ | 1,042 |  |
| Indirect | 449 |  |  | 34 |  |  | 784 |  |  | 44 |  |
| Total | $ | 1,189 |  |  | $ | 571 |  |  | $ | 2,141 |  |  | $ | 1,086 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-18-000023:notes:130]
[same as prior period, unchanged from 0000068505-18-000017:notes:121]

[0000068505-18-000023:notes:131]
During the six months ended June 30, 2018, the Company granted 0.4 million RSUs and 0.1 million market stock units ("MSUs") with an aggregate grant-date fair value of $42 million and $7 million, respectively, and 0.2 million stock options and 0.2 million performance options ("POs") with an aggregate grant-date fair value of $5 million and $7 million, respectively. Share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-18-000023:notes:132]
[same as prior period, unchanged from 0000068505-18-000017:notes:123]

[0000068505-18-000023:notes:133]
[same as prior period, unchanged from 0000068505-18-000017:notes:124]

[0000068505-18-000023:notes:134]
[same as prior period, unchanged from 0000068505-18-000017:notes:125]

[0000068505-18-000023:notes:135]
[same as prior period, unchanged from 0000068505-18-000017:notes:126]

[0000068505-18-000023:notes:136]
[same as prior period, unchanged from 0000068505-18-000017:notes:127]

[0000068505-18-000023:notes:137]
[same as prior period, unchanged from 0000068505-18-000017:notes:128]

[0000068505-18-000023:notes:138]
The Company had no Level 3 holdings as of June 30, 2018 or December 31, 2017.

[0000068505-18-000023:notes:139]
At June 30, 2018 and December 31, 2017, the Company had $399 million and $633 million, respectively, of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-18-000023:notes:140]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at June 30, 2018 and December 31, 2017 was $5.7 billion and $4.6 billion (Level 2), respectively.

[0000068505-18-000023:notes:141]
[same as prior period, unchanged from 0000068505-18-000017:notes:132]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-18-000023:notes:142]
[same as prior period, unchanged from 0000068505-18-000017:notes:133]

[0000068505-18-000023:notes:143]
[same as prior period, unchanged from 0000068505-18-000017:notes:134]

[0000068505-18-000023:notes:144]
[same as prior period, unchanged from 0000068505-18-000017:notes:135]

[0000068505-18-000023:notes:145]
On March 28, 2018, the Company completed the acquisition of Avigilon Corporation, a provider of advanced end-to-end security and surveillance solutions including video analytics, network video management hardware and software, surveillance cameras and access control solutions. The purchase price of $974 million, consisted of cash payments of $980 million for outstanding common stock, restricted stock units and employee held stock options, net of cash acquired of $107 million, debt assumed of $75 million and transaction costs of $26 million. Prior to the end of the first quarter, $35 million of the assumed debt was repaid with the remaining $40 million repaid during the second quarter of 2018.

[0000068505-18-000023:notes:146]
The acquisition of Avigilon has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change. The following table summarizes fair values of assets acquired and liabilities assumed as of the March 28, 2018 acquisition date:

[0000068505-18-000023:notes:147]
| Accounts receivable, net |  | $ | 67 |  |
| Inventory |  | 93 |  |
| Other current assets |  | 24 |  |
| Property, plant and equipment, net |  | 33 |  |
| Deferred income taxes |  | 4 |  |
| Accounts payable |  | (21 | ) |
| Accrued liabilities |  | (28 | ) |
| Deferred income tax liabilities |  | (134 | ) |
| Goodwill |  | 438 |  |
| Intangible assets |  | 498 |  |
| Total consideration |  | $ | 974 |  |

[0000068505-18-000023:notes:148]
Acquired intangible assets consist of $110 million of customer relationships, $380 million of developed technology and $8 million of trade names and will have useful lives of two to 20 years. The fair values of all intangible assets were estimated using the income approach. Customer relationships and developed technology were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-18-000023:notes:149]
[same as prior period, unchanged from 0000068505-18-000017:notes:140]

[0000068505-18-000023:notes:150]
[same as prior period, unchanged from 0000068505-18-000017:notes:141]

[0000068505-18-000023:notes:151]
[same as prior period, unchanged from 0000068505-18-000017:notes:142]

[0000068505-18-000023:notes:152]
On April 9, 2018, the Company completed the acquisition of a provider of two-way radio communications for a gross purchase price of $11 million, recognizing $7 million of identifiable intangible assets, which will be amortized over a period of seven years. The results of operations for this acquisition have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date.

[0000068505-18-000023:notes:153]
On March 7, 2018, the Company completed the acquisition of Plant Holdings, Inc., the parent company of Airbus DS Communications for a purchase price of $237 million net cash. This acquisition will expand the Company's software portfolio in the Command Center with additional solutions for Next Generation 9-1-1. The Company recognized $155 million of goodwill, $80 million of identifiable intangible assets and $2 million of net assets acquired. The identifiable intangible assets were classified as $41 million of customer-related intangibles, $27 million of completed technology and $12 million of trade names. The identifiable intangible assets will be amortized over a period of 10 to 20 years. The purchase accounting is not yet complete and as such the final allocation between deferred income tax accounts and goodwill may be subject to change.

[0000068505-18-000023:notes:154]
[same as prior period, unchanged from 0000068505-18-000017:notes:144]

[0000068505-18-000023:notes:155]
On March 13, 2017, the Company completed the acquisition of Interexport, a company that provides Services for communications systems to public safety and commercial customers in Chile, for a gross purchase price of $98 billion Chilean pesos, or approximately $147 million U.S. dollars based on cash payments of $55 million, net of cash acquired, and assumed liabilities of $92 million, primarily related to capital leases. As a result of the acquisition, the Company recognized $61 million of identifiable intangible assets, $70 million of acquired property, plant and equipment and $16 million of net other tangible assets. The estimated identifiable intangible assets were classified as $56 million of customer-related intangibles and $5 million of other intangibles and will be amortized over a period of seven years.

[0000068505-18-000023:notes:156]
[same as prior period, unchanged from 0000068505-18-000017:notes:146]

[0000068505-18-000023:notes:157]
[same as prior period, unchanged from 0000068505-18-000017:notes:147]

[0000068505-18-000023:notes:158]
[same as prior period, unchanged from 0000068505-18-000017:notes:148]

[0000068505-18-000023:notes:159]
|  | June 30, 2018 |  | December 31, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 555 |  |  | $ | 71 |  |  | $ | 148 |  |  | $ | 55 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,116 |  |  | 310 |  |  | 977 |  |  | 242 |  |
| Other intangibles | 75 |  |  | 25 |  |  | 56 |  |  | 23 |  |
|  | $ | 1,748 |  |  | $ | 408 |  |  | $ | 1,183 |  |  | $ | 322 |  |

[0000068505-18-000023:notes:160]
Amortization expense on intangible assets was $53 million for the three months ended June 30, 2018 and $94 million for the six months ended June 30, 2018. Amortization expense on intangible assets was $37 million for the three months ended July 1, 2017 and $73 million for the six months ended July 1, 2017. As of June 30, 2018, annual amortization expense is estimated to be $98 million in 2018, $193 million in 2019, $190 million in 2020, $186 million in 2021, $184 million in 2022, and $83 million in 2023.

[0000068505-18-000023:notes:161]
[same as prior period, unchanged from 0000068505-18-000017:notes:151]

[0000068505-18-000023:notes:162]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2018 to June 30, 2018:

[0000068505-18-000023:notes:163]
|  | Products and Systems Integration |  | Services and Software |  | Total |
| Balance as of January 1, 2018 | $ | 362 |  |  | $ | 576 |  |  | $ | 938 |  |
| Goodwill acquired | 359 |  |  | 231 |  |  | 590 |  |
| Purchase accounting adjustments | 5 |  |  | (1 | ) |  | 4 |  |
| Foreign currency | — |  |  | (4 | ) |  | (4 | ) |
| Balance as of June 30, 2018 | $ | 726 |  |  | $ | 802 |  |  | $ | 1,528 |  |

[0000068505-18-000023:notes:164]
During the second quarter of 2018, the Company modified its internal reporting structure to better align the way financial information is reported to and analyzed by executive leadership, in part, as a result of recent acquisitions contributing to the growth within the newly aligned Services and Software segment. Previously, the Company had two reporting segments: Products and Services. The changes in reporting structure consist of Systems Integration related revenue and costs moving from the old Services segment into the newly presented Products and Systems Integration segment and Software related revenue and costs moving from the old Products segment into the newly presented Services and Software segment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-18-000023:notes:165]
[same as prior period, unchanged from 0000068505-18-000017:notes:154]

[0000068505-18-000023:notes:166]
[same as prior period, unchanged from 0000068505-18-000017:notes:155]

[0000068505-18-000023:notes:167]
[same as prior period, unchanged from 0000068505-18-000017:notes:156]

[0000068505-18-000023:notes:168]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Net earnings before income taxes | $ | 227 |  |  | $ | 205 |  |  | $ | 367 |  |  | $ | 324 |  |
| Income tax expense | 46 |  |  | 73 |  |  | 69 |  |  | 114 |  |
| Effective tax rate | 20 | % |  | 36 | % |  | 19 | % |  | 35 | % |

[0000068505-18-000023:notes:169]
The Company recorded $46 million of net tax expense during the three months ended June 30, 2018, resulting in an effective tax rate of 20%, compared to $73 million of net tax expense during the three months ended July 1, 2017, resulting in an effective tax rate of 36%. The effective tax rate for the three months ended June 30, 2018 of 20% is lower than the effective tax rate for the three months ended July 1, 2017 of 36%, primarily due to the corporate income tax rate decrease from 35% to 21%, as a result of the U.S. Tax Cuts and Jobs Act (the “Tax Act”) enacted December 22, 2017. The effective tax rate in the second quarter of 2018 was lower than the U.S. statutory tax rate of 21% primarily due to a favorable settlement of a state audit, resulting in a tax benefit. The effective tax rate in the second quarter of 2017 was greater than the U.S. statutory tax rate of 35% partly due to change of estimates between provision and the filing of tax returns in foreign jurisdictions.

[0000068505-18-000023:notes:170]
The Company recorded $69 million of net tax expense during the six months ended June 30, 2018, resulting in an effective tax rate of 19%, compared to $114 million of net tax expense during the six months ended July 1, 2017, resulting in an effective tax rate of 35%. The effective tax rate for the six months ended June 30, 2018 of 19% is lower than the effective tax rate for the six months ended July 1, 2017 of 35%, primarily due to the corporate income tax rate decrease from 35% to 21%, as a result of the Tax Act. The effective tax rate for six months ended June 30, 2018 was lower than the U.S. statutory tax rate of 21% primarily due to the recognition of excess tax benefits on share-based compensation and a tax benefit due to a favorable settlement of a state audit. The effective tax rate for the six months ended July 1, 2017 was equal to the U.S. statutory tax rate of 35%.

[0000068505-18-000023:notes:171]
Under the guidance in the U.S. Securities and Exchange Commission's Staff Accounting Bulletin No. 118 that addresses the FASB's ASC Topic 740, "Income Taxes," the Company recorded provisional amounts for the impact of the Tax Act in 2017. The Company is continuing to analyze the impact of the recently issued IRS Notices related to the Tax Act. For the six months ended June 30, 2018, the Company has not recorded any material adjustments to the previously recorded provisional tax amounts.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-18-000023:notes:172]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company on January 1, 2019 and interim periods within that reporting period, with early adoption permitted. The Company will adopt the ASU on January 1, 2019, utilizing the modified retrospective method upon adoption. The Company has begun to assess the impact of the ASU on its financial statements, including the package of available practical expedients, required disclosures, and changes to internal controls. Based on the preliminary work completed, the Company expects a material impact to its balance sheet through the recording of right-of-use assets and lease obligations that were not required to be recorded within the balance sheet under current accounting standards.

[0000068505-18-000023:notes:173]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities," which is intended to simplify the application of hedge accounting and better portray the economic results of risk management strategies in the consolidated financial statements. The ASU expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. The ASU is effective for the Company on January 1, 2019 with adoption permitted immediately in any interim or annual period (including the current period). The guidance related to cash flow and net investment hedges existing at the date of adoption should be applied using the modified retrospective method by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption. The guidance related to presentation and disclosure should be applied prospectively. The Company is currently assessing the impact of this ASU, including transition elections and required elections, on its consolidated financial statements and disclosures.

[0000068505-18-000023:notes:174]
Recently Adopted Accounting Pronouncements

[0000068505-18-000023:notes:175]
The Company adopted ASU No. 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory” on January 1, 2018 using the modified retrospective method of adoption. The Company recognized $30 million related to the cumulative effect of applying the ASU as an adjustment to its opening retained earnings balance. The comparative information has not been restated and continues to be reported under accounting standards in effect in those periods. This ASU eliminates the prior application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use. Under the ASU, the Company will recognize tax expense when intra-entity transfers of assets other than inventory occur.

[0000068505-18-000023:notes:176]
The Company adopted ASU No. 2017-07, “Compensation - Retirement Benefits (Topic 715) - Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” on January 1, 2018 using the retrospective method of adoption. The amendments in the ASU require that an employer disaggregate the service cost component from the other components of net periodic cost (benefit) and report that component in the same line item as other compensation costs arising from services rendered by employees during the period. The other components of net periodic cost (benefit) are required to be presented in the statement of operations separately from the service cost component and outside of operating earnings. The Company has restated its comparative period results to reflect the application of the presentation guidance of the ASU. As a result of the ASU, the presentation of net periodic cost (benefit) has been updated to classify all components of the Company’s net periodic benefit, with the exception of the service cost component, within Other in Other income (expense) on the statement of operations. The Company recorded $20 million and $4 million in the three months ended June 30, 2018 and July 1, 2017, respectively, and $40 million and $1 million in the six months ended June 30, 2018 and July 1, 2017, respectively.

[0000068505-18-000023:notes:177]
The Company adopted ASU No. 2014-09, "Revenue from Contracts with Customers," and all the related amendments (collectively “ASC 606”) on January 1, 2018 using the modified retrospective method. The Company recognized the cumulative effect of initially applying the new revenue standard as an adjustment to its opening retained earnings. The comparative information has not been restated and continues to be reported under the accounting standards in effect in those periods.

[0000068505-18-000023:notes:178]
The Company has retained much of the same accounting treatment used to recognize revenue under ASC 606 as under accounting standards in effect in prior periods. Revenue on a significant portion of its System and Integration services contracts continues to be recognized under percentage of completion accounting, applying a cost-to-cost method. Services contracts continue to be recognized ratably over relevant contract terms as the Company stands ready to perform. Finally, revenue on equipment sales continues to be recognized based on delivery terms as aligned with the transfer of control.

[0000068505-18-000023:notes:179]
Under the new standard, the Company identified distinct promises to transfer goods and services within its contracts. For system contracts that are recognized under percentage of completion accounting, the Company has considered the factors used to determine whether promises made in the contract are distinct and determined that devices and accessories represent distinct goods. Accordingly, adoption of the new standard impacts the Company's system contracts, with the result being revenue recognized earlier as control of devices and accessories transfers to the customer at a point in time rather than over time. For the remaining promised goods and services within the Company's system contracts, it continues to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time.

[0000068505-18-000023:notes:180]
Under the new standard, revenue recognition for software sales is accelerated based on when control of software licenses and related support services are transferred to the customer. Amounts deferred under previous software accounting rules due to lack of vendor-specific objective evidence have been recognized as an adjustment through opening retained earnings.

[0000068505-18-000023:notes:181]
Historically, the Company presented transactions that involved a third-party sales representative on a net basis. After considering the control concept and the remaining three indicators of gross presentation under the new standard, the Company has determined that it is the principal in contracts that involve a third-party sales representative. Thus, under the new standard, the Company presents associated revenues on a gross basis, with the affect being an equal increase to selling, general and administrative expenses for its cost of third-party commissions.

[0000068505-18-000023:notes:182]
Under prior accounting standards, the Company expensed sales commissions and other costs to obtain a contract as incurred. However, under the new standard, the Company capitalizes sales commissions and certain other costs as incremental costs to obtain a contract. Such costs are classified as a non-current contract cost assets within Other assets and amortized over a period that approximates the timing of revenue recognition on the underlying contracts.

[0000068505-18-000023:notes:183]
The new standard clarified the definition of a receivable and requires the Company to present its net position in a contract with a customer on the balance sheet. The position is presented as either a receivable, contract asset, or a contract liability. Under the new definition, accounts receivable are unconditional rights to consideration from a customer. Contract assets represent rights to consideration from a customer in exchange for transferred goods and services that are conditional on events other than the passage of time. Contract liabilities represent obligations to transfer goods and services for which the Company has received, or is due, consideration from a customer respectively. The Company reclassified its customer positions to align with the new definitions and presentation guidance. Accordingly, Unbilled accounts receivable and Costs and earnings in excess of billings have been reclassified from Accounts receivable and Other current assets, respectively, and are presented as Contract assets. Accounts receivable which are not due from customers have been reclassified into Other current assets. Deferred revenue, Billings in excess of costs and earnings, and Customer downpayments have been reclassified from Accrued liabilities and are presented as Contract liabilities. Non-current deferred revenue has been reclassified from Deferred revenue to Non-current contract liabilities within Other liabilities.

[0000068505-18-000023:notes:184]
The cumulative effect of the changes made to our consolidated opening balance sheet as of January 1, 2018 due to the modified retrospective method of adoption of ASC 606 is as follows:

[0000068505-18-000023:notes:185]
Balance Sheet (Selected captions)

[0000068505-18-000023:notes:186]
| (In millions) | December 31, 2017 |  | Reclassification of Contract Assets |  | Reclassification of Non-customer receivables |  | Reclassification of Contract Liabilities |  | Impact of Adoption on Open Contracts |  | January 1, 2018 |
|  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |
| ASSETS |
| Accounts receivable, net | $ | 1,523 |  |  | $ | (297 | ) |  | $ | (24 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | 1,198 |  |
| Contract assets | — |  |  | 846 |  |  | — |  |  | — |  |  | 85 |  |  | 931 |  |
| Inventories, net | 327 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 328 |  |
| Other current assets | 832 |  |  | (549 | ) |  | 24 |  |  | — |  |  | (23 | ) |  | 284 |  |
| Deferred income taxes | 1,023 |  |  | — |  |  | — |  |  | — |  |  | (41 | ) |  | 982 |  |
| Other assets | 333 |  |  | — |  |  | — |  |  | — |  |  | 85 |  |  | 418 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Contract liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | (17 | ) |  | $ | 1,082 |  |
| Accrued liabilities | 2,286 |  |  | — |  |  | — |  |  | (1,099 | ) |  | — |  |  | 1,187 |  |
| Other liabilities | 2,585 |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | 2,578 |  |
| Stockholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings | 467 |  |  | — |  |  | — |  |  | — |  |  | 127 |  |  | 594 |  |

[0000068505-18-000023:notes:187]
Adoption Impact to Financial Statements

[0000068505-18-000023:notes:188]
The impact of the adoption of ASC 606 to the condensed consolidated financial statements for the three and six months ended June 30, 2018 is as follows:

[0000068505-18-000023:notes:189]
Statements of Operations (Selected captions)

[0000068505-18-000023:notes:190]
|  | Three Months Ended |
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Net sales | $ | 1,760 |  |  | $ | (24 | ) |  | $ | 1,736 |  |
| Gross margin | 822 |  |  | (24 | ) |  | 798 |  |
| Selling, general and administrative expenses | 316 |  |  | (16 | ) |  | 300 |  |
| Operating Earnings | 273 |  |  | (8 | ) |  | 265 |  |
| Net earnings before income taxes | 227 |  |  | (8 | ) |  | 219 |  |
| Net earnings attributable to Motorola Solutions Inc. | $ | 180 |  |  | $ | (8 | ) |  | $ | 172 |  |

[0000068505-18-000023:notes:191]
|  | Six Months Ended |
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Net sales | 3,227 |  |  | (39 | ) |  | 3,188 |  |
| Gross margin | 1,491 |  |  | (39 | ) |  | 1,452 |  |
| Selling, general and administrative expenses | 594 |  |  | (29 | ) |  | 565 |  |
| Operating Earnings | 445 |  |  | (10 | ) |  | 435 |  |
| Net earnings before income taxes | 367 |  |  | (10 | ) |  | 357 |  |
| Net earnings attributable to Motorola Solutions Inc. | 297 |  |  | (10 | ) |  | 287 |  |

[0000068505-18-000023:notes:192]
| (In millions) | June 30, 2018 |  | Adjustments due to ASC 606 |  | June 30, 2018 Balances Under ASC 605 |
| Accounts receivable, net | $ | 1,159 |  |  | $ | 205 |  |  | $ | 1,364 |  |
| Contract assets | 760 |  |  | (760 | ) |  | — |  |
| Other current assets | 330 |  |  | 491 |  |  | 821 |  |
| Deferred income taxes | 945 |  |  | 41 |  |  | 986 |  |
| Other assets | 420 |  |  | (92 | ) |  | 328 |  |
| Contract liabilities | $ | 1,049 |  |  | $ | (1,049 | ) |  | $ | — |  |
| Accrued liabilities | 1,096 |  |  | 1,061 |  |  | 2,157 |  |
| Other liabilities | 2,153 |  |  | 10 |  |  | 2,163 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Retained earnings | 627 |  |  | (137 | ) |  | 490 |  |

[0000068505-18-000023:notes:193]
There is no impact to the Statement of comprehensive income or the Statement of cash flows, with the exception of changes to Net earnings and changes within assets and liabilities as presented on the balance sheet and disclosed above.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-18-000023:notes:194]
[same as prior period, unchanged from 0000068505-18-000017:notes:181]

[0000068505-18-000023:notes:195]
[same as prior period, unchanged from 0000068505-18-000017:notes:182]

[0000068505-18-000023:notes:196]
[same as prior period, unchanged from 0000068505-18-000017:notes:185]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-18-000023:notes:197]
[same as prior period, unchanged from 0000068505-18-000017:notes:186]

[0000068505-18-000023:notes:198]
[same as prior period, unchanged from 0000068505-18-000017:notes:187]

[0000068505-18-000023:notes:199]
[same as prior period, unchanged from 0000068505-18-000017:notes:188]

[0000068505-18-000023:notes:200]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 46 |  |  | 10 |  |  | 10 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (68 | ) |  | (57 | ) |  | (24 | ) |  | (24 | ) |  | (3 | ) |  | (3 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 14 |  |  | 11 |  |  | 3 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Settlement loss | — |  |  | — |  |  | — |  |  | 16 |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | (8 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 7 |  |  | $ | (5 | ) |  | $ | (5 | ) |

[0000068505-18-000023:notes:201]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 92 |  |  | 92 |  |  | 20 |  |  | 20 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (136 | ) |  | (115 | ) |  | (48 | ) |  | (47 | ) |  | (5 | ) |  | (6 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 28 |  |  | 22 |  |  | 6 |  |  | 8 |  |  | 2 |  |  | 2 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | (8 | ) |
| Settlement loss | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (16 | ) |  | $ | (1 | ) |  | $ | (20 | ) |  | $ | 8 |  |  | $ | (9 | ) |  | $ | (10 | ) |

[0000068505-18-000023:notes:202]
The Company made a $500 million contribution to its U.S. Pension Plans during the six months ended June 30, 2018.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-18-000023:notes:203]
[same as prior period, unchanged from 0000068505-18-000017:notes:191]

[0000068505-18-000023:notes:204]
[same as prior period, unchanged from 0000068505-18-000017:notes:192]

[0000068505-18-000023:notes:205]
During the three months ended June 30, 2018, the Company recorded net reorganization of business charges of $25 million including $18 million of charges in Other charges and $7 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $25 million were charges of $27 million related to employee separation costs and $1 million related to exit costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-18-000023:notes:206]
During the six months ended June 30, 2018, the Company recorded net reorganization of business charges of $38 million including $26 million of charges in Other charges and $12 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $38 million were charges of $49 million related to employee separation costs and $3 million related to exit costs, partially offset by $14 million of reversals for accruals no longer needed.

[0000068505-18-000023:notes:207]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2018 to June 30, 2018:

[0000068505-18-000023:notes:208]
|  | January 1, 2018 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | June 30, 2018 |
| Exit costs | $ | 9 |  |  | $ | 3 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | 9 |  |
| Employee separation costs | 41 |  |  | 49 |  |  | (14 | ) |  | (33 | ) |  | 43 |  |
|  | $ | 50 |  |  | $ | 52 |  |  | $ | (14 | ) |  | $ | (36 | ) |  | $ | 52 |  |

[0000068505-18-000023:notes:209]
[same as prior period, unchanged from 0000068505-18-000017:notes:196]

[0000068505-18-000023:notes:210]
At January 1, 2018, the Company had $9 million of accruals for exit costs. During the six months ended June 30, 2018, there were $3 million of additional charges and $3 million of cash payments related to the exit of leased facilities. The remaining accrual of $9 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at June 30, 2018, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-18-000023:notes:211]
[same as prior period, unchanged from 0000068505-18-000017:notes:198]

[0000068505-18-000023:notes:212]
At January 1, 2018, the Company had an accrual of $41 million for employee separation costs. The 2018 additional charges of $49 million represent severance costs for approximately 600 employees. The adjustment of $14 million reflects reversals for accruals no longer needed. The $33 million used reflects cash payments to severed employees. The remaining accrual of $43 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at June 30, 2018, is expected to be paid, primarily within one year, to approximately 600 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-18-000023:notes:213]
[same as prior period, unchanged from 0000068505-18-000017:notes:200]

[0000068505-18-000023:notes:214]
During the three months ended July 1, 2017, the Company recorded net reorganization of business charges of $3 million including $1 million of charges in Other charges and $2 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $3 million were charges of $8 million related to employee separation costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-18-000023:notes:215]
During the six months ended July 1, 2017, the Company recorded net reorganization of business charges of $22 million including $16 million of charges in Other charges and $6 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $22 million were charges of $23 million related to employee separation costs and $4 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-18-000023:notes:216]
[same as prior period, unchanged from 0000068505-18-000017:notes:202]

[0000068505-18-000023:notes:217]
[same as prior period, unchanged from 0000068505-18-000017:notes:203]

[0000068505-18-000023:notes:218]
[same as prior period, unchanged from 0000068505-18-000017:notes:210]

[0000068505-18-000023:notes:219]
Products and Systems Integration: The Products and Systems Integration segment is comprised of Systems, Devices and Systems Integration. Direct customers of the Products and Systems Integration segment are typically government public safety and first-responder agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission critical needs. Indirect customers are defined as customers purchasing professional commercial radios and Avigilon video solutions, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications networks and video solutions are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations. On the Company's Products and Systems Integration sales, it records consideration from shipping and handling on a gross basis within Net sales.

[0000068505-18-000023:notes:220]
[same as prior period, unchanged from 0000068505-18-000017:notes:214]

[0000068505-18-000023:notes:221]
Systems and Systems Integration: Systems and Systems Integration include customized end-to-end radio network, video solutions and implementation, optimization, and integration of networks, devices, software, and applications. Radio network includes the aggregation of promises to the customer to provide the radio network core and central processing software, base stations, consoles, and repeaters. These individual promises are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The radio network represents distinct performance obligations for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Systems and Systems Integration revenue is recognized over an average duration of approximately one to two years.

[0000068505-18-000023:notes:222]
Systems also includes Avigilon end-to-end security and surveillance solutions including: video analytics, network video management hardware and software, and access control solutions, which are capable of being distinct and distinct in the context of the contract. Avigilon security and surveillance video solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Provisions for returns are determined on a portfolio basis using historical data. Revenue is recognized upon the transfer of control of the end-to-end video solution to the reseller partners, typically upon shipment.

[0000068505-18-000023:notes:223]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Direct customers of the Services and Software segment are typically government public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute broadband push-to-talk services to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-18-000023:notes:224]
Services:  Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer or Motorola Solutions owned networks. Services are provided across all radio network technologies. Services are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-18-000023:notes:225]
Software: Software offerings include public safety and enterprise command solutions, unified communications applications, and video software solutions delivered either “as a service” or on-premise. Solutions delivered as a service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. The hosted software, technical support, and right to unspecified future software enhancements each represent a series of distinct services that are delivered concurrently using the same over-time method. As such, the promises are accounted for as a single performance obligation with revenue recognized on a straight-line basis.

[0000068505-18-000023:notes:226]
On-premise offerings consist of multiple promises primarily including software licenses and post-contract customer support. The promises are each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over-time as the customer simultaneously receives and consumes the services on a straight-line basis.

[0000068505-18-000023:notes:227]
[same as prior period, unchanged from 0000068505-18-000017:notes:218]

[0000068505-18-000023:notes:228]
The Company enters into arrangements which consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company generally allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-18-000023:notes:229]
[same as prior period, unchanged from 0000068505-18-000017:notes:220]

[0000068505-18-000023:notes:230]
[same as prior period, unchanged from 0000068505-18-000017:notes:221]

[0000068505-18-000023:notes:231]
[same as prior period, unchanged from 0000068505-18-000017:notes:222]

[0000068505-18-000023:notes:232]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction price associated with remaining performance obligations which are not yet satisfied as of June 30, 2018 is $6.2 billion. A total of $3.1 billion is from Products and Systems Integration performance obligations that are not yet satisfied, of which $1.7 billion is expected to be recognized in the next 12 months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.1 billion is from Services and Software performance obligations that are not yet satisfied as of June 30, 2018. The determination of Services and Software performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's Services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.1 billion from unsatisfied Services and Software performance obligations over the next 12 months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-18-000023:notes:233]
[same as prior period, unchanged from 0000068505-18-000017:notes:224]

[0000068505-18-000023:notes:234]
Contract assets consist of amounts formerly classified as Costs and earnings in excess of billings and Unbilled accounts receivable where the Company does not yet have an unconditional right to bill. Contract liabilities consist of amounts formerly classified Billings in excess of costs and earnings recognized, Customer downpayments and Deferred revenue.

[0000068505-18-000023:notes:235]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over-time based on a cost-to-cost method of measuring performance. The Company may recognize a contract asset or contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-18-000023:notes:236]
Revenue recognized during the three months ended June 30, 2018 which was previously included in Contract liabilities as of April 1, 2018 is $365 million. Revenue recognized during the six months ended June 30, 2018 which was previously included in Contract liabilities as of January 1, 2018 is $541 million. Revenue of $6 million was reversed during the three months ended June 30, 2018 and $3 million of revenue was recognized during the six months ended June 30, 2018 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts.

[0000068505-18-000023:notes:237]
There have been no material impairment losses recognized on contract assets during the six months ended June 30, 2018.

[0000068505-18-000023:notes:238]
[same as prior period, unchanged from 0000068505-18-000017:notes:229]

[0000068505-18-000023:notes:239]
Contract cost assets represent incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one to four years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $11 million and $23 million for the three and six months ended June 30, 2018, respectively.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-18-000023:notes:240]
[same as prior period, unchanged from 0000068505-18-000017:notes:231]

[0000068505-18-000023:notes:241]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Products and Systems Integration | $ | 1,189 |  |  | $ | 1,047 |  |  | $ | 2,141 |  |  | $ | 1,901 |  |
| Services and Software | 571 |  |  | 450 |  |  | 1,086 |  |  | 876 |  |
|  | $ | 1,760 |  |  | $ | 1,497 |  |  | $ | 3,227 |  |  | $ | 2,777 |  |

[0000068505-18-000023:notes:242]
[same as prior period, unchanged from 0000068505-18-000017:notes:233]

[0000068505-18-000023:notes:243]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Products and Systems Integration | $ | 175 |  |  | $ | 190 |  |  | $ | 265 |  |  | $ | 287 |  |
| Services and Software | 98 |  |  | 71 |  |  | 180 |  |  | 146 |  |
| Operating earnings | 273 |  |  | 261 |  |  | 445 |  |  | 433 |  |
| Total other expense | (46 | ) |  | (56 | ) |  | (78 | ) |  | (109 | ) |
| Earnings before income taxes | $ | 227 |  |  | $ | 205 |  |  | $ | 367 |  |  | $ | 324 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-18-000023:notes:244]
[same as prior period, unchanged from 0000068505-18-000017:notes:235]

[0000068505-18-000023:notes:245]
[same as prior period, unchanged from 0000068505-18-000017:notes:236]

[0000068505-18-000023:notes:246]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video solutions, and the implementation, optimization, and integration of such systems, devices, and applications, including the Company’s: (i) “ASTRO” products, which meet the Association of Public Safety Communications Officials Project 25 standard, (ii) “Dimetra” products which meet the European Telecommunications Standards Institute Terrestrial Trunked Radio “TETRA” standard, (iii) Professional and Commercial Radio (“PCR”) products, (iv) broadband technology products, such as Long-Term Evolution (“LTE”), and (v) video solutions, such as video surveillance cameras. The primary customers of the Products and Systems Integration segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and video solutions and manage a mobile workforce.

[0000068505-18-000023:notes:247]
Services and Software: The Services and Software segment provides a full set of offerings for government, public safety and commercial communication networks. Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include monitoring, software updates and cybersecurity services. Managed services offerings range from partial to full operation of customer or Motorola Solutions owned networks. Software includes public safety and enterprise command center solutions, unified communications applications, video software solutions, delivered both on premise and “as a service.”
