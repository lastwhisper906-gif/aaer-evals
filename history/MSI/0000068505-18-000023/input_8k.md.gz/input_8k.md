# MSI 8-K — 0000068505-18-000022 filed 2018-08-02

## item codes, every 8-K on or before 2018-08-03

- 2018-08-02 0001193125-18-236570 — 7.01, 9.01
- 2018-08-02 0000068505-18-000022 — 2.02, 9.01
- 2018-05-17 0001193125-18-166592 — 4.01, 5.07, 9.01
- 2018-05-03 0000068505-18-000015 — 2.02, 9.01
- 2018-03-28 0001193125-18-098524 — 5.02
- 2018-03-28 0001193125-18-098438 — 2.01, 8.01, 9.01
- 2018-02-23 0001193125-18-055991 — 8.01, 9.01
- 2018-02-01 0001193125-18-029347 — 7.01, 8.01, 9.01
- 2018-02-01 0000068505-18-000004 — 2.02, 9.01
- 2017-11-17 0001193125-17-346958 — 8.01
- 2017-11-02 0000068505-17-000015 — 2.02, 8.01, 9.01
- 2017-08-03 0001193125-17-247458 — 2.02, 9.01
- 2017-05-17 0001193125-17-173496 — 5.07
- 2017-05-04 0001193125-17-158741 — 2.02, 9.01
- 2017-04-27 0001193125-17-143234 — 1.01, 1.02, 2.03, 9.01
- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2018-08-03

- none on or before 2018-08-03

## item 2.02 — earnings release, exhibit 99.1

[0000068505-18-000022:8k_2_02:1]
EX-99.1
2
msiq22018pressrelease.htm
EXHIBIT 99.1

[0000068505-18-000022:8k_2_02:2]
Exhibit

[0000068505-18-000022:8k_2_02:3]
Exhibit 99.1

[0000068505-18-000022:8k_2_02:4]
Motorola Solutions Reports Second-Quarter 2018 Financial Results

[0000068505-18-000022:8k_2_02:5]
Company raises full-year revenue and earnings outlook

[0000068505-18-000022:8k_2_02:6]
| • | Sales of $1.8 billion, up 18 percent from a year ago |

[0000068505-18-000022:8k_2_02:7]
| • | Organic revenue1 growth of 6 percent |

[0000068505-18-000022:8k_2_02:8]
| • | Backlog of $9.4 billion, up $919 million or 11 percent from a year ago |

[0000068505-18-000022:8k_2_02:9]
| • | GAAP earnings per share (EPS) of $1.05, up 35 percent |

[0000068505-18-000022:8k_2_02:10]
| • | Non-GAAP EPS* of $1.46, up 30 percent |

[0000068505-18-000022:8k_2_02:11]
CHICAGO – Aug. 2, 2018 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the second quarter of 2018. Click here for a printable news release and financial tables.

[0000068505-18-000022:8k_2_02:12]
"Our outstanding second-quarter results highlight the continued strength of our land-mobile radio business and momentum in services and software," said Greg Brown, chairman and CEO of Motorola Solutions. "With our strong earnings, cash generation and highest Q2 backlog position ever, we are well positioned for continued growth."

[0000068505-18-000022:8k_2_02:13]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0000068505-18-000022:8k_2_02:14]
|  | Q2 2018 |  | Q2 2017 |  | % Change |
| Sales | $1,760 | $1,497 | 18 | % |
| GAAP |  |  |  |
| Operating Earnings | $273 | $261 | 5 | % |
| % of Sales | 15.5 | % | 17.4 | % |  |
| EPS | $1.05 | $0.78 | 35 | % |
| Non-GAAP |  |  |  |
| Operating Earnings | $378 | $316 | 20 | % |
| % of Sales | 21.5 | % | 21.1 | % |  |
| EPS | $1.46 |  | $1.12 |  | 30% |  |
| Products and Systems Integration Segment |  |  |  |
| Sales | $1,189 | $1,047 | 14 | % |
| GAAP Operating Earnings | $175 | $190 | (8 | )% |
| % of Sales | 14.7 | % | 18.1 | % |  |
| Non-GAAP Operating Earnings | $226 | $204 | 11 | % |
| % of Sales | 19.0 | % | 19.5 | % |  |
| Services and Software Segment |  |  |  |
| Sales | $571 | $450 | 27 | % |
| GAAP Operating Earnings | $98 | $71 | 38 | % |
| % of Sales | 17.2 | % | 15.8 | % |  |
| Non-GAAP Operating Earnings | $152 | $112 | 36 | % |
| % of Sales | 26.6 | % | 24.9 | % |  |

[0000068505-18-000022:8k_2_02:15]
*Non-GAAP financial information excludes the after-tax impact of approximately $0.41 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release.

[0000068505-18-000022:8k_2_02:16]
OTHER SELECTED FINANCIAL RESULTS

[0000068505-18-000022:8k_2_02:17]
| • | Revenue - Sales increased $263 million, or 18 percent from the year-ago quarter, driven by growth in all regions. Approximately $154 million of revenue growth was related to acquisitions, and $24 million was related to the adoption of accounting standard ASC 606. The Products and Systems Integration segment grew 14 percent driven by the Americas and EMEA. The Services and Software segment grew 27 percent led by the Americas and EMEA. |

[0000068505-18-000022:8k_2_02:18]
| • | Operating margin - GAAP operating margin was 15.5 percent of sales, compared with 17.4 percent in the year-ago quarter. The decline reflects higher operating expenses related to acquisitions, partially offset by higher gross margins in Services, the adoption of ASC 606 and favorable mix. Non-GAAP operating margin was 21.5 percent of sales, compared with 21.1 percent in the year-ago quarter driven by higher gross margin partially offset by higher operating expenses related to acquisitions. |

[0000068505-18-000022:8k_2_02:19]
| • | Cash flow - Operating cash flow was $425 million, compared with $173 million of operating cash generated in the year-ago quarter. Free cash flow2 was $384 million, compared with $120 million of free cash flow generated in the year-ago quarter. Cash flow for the quarter was higher on improved working capital and higher earnings. |

[0000068505-18-000022:8k_2_02:20]
| • | Capital allocation - The company paid $84 million in cash dividends. From a debt perspective, the company repaid $100 million on the revolving credit facility ahead of schedule, leaving an outstanding balance of $300 million. The company also repaid the remaining $40 million revolver balance assumed in the Avigilon acquisition and closed this credit facility. |

[0000068505-18-000022:8k_2_02:21]
| • | Backlog - The company ended the quarter with backlog of $9.4 billion, up $919 million from the year-ago quarter. Products and Systems Integration segment backlog was up 13 percent or $367 million, and Services and Software was up 10 percent or $552 million. Land mobile radio demand led by the Americas continues to drive backlog growth. |

[0000068505-18-000022:8k_2_02:22]
KEY HIGHLIGHTS

[0000068505-18-000022:8k_2_02:23]
Services and Software wins

[0000068505-18-000022:8k_2_02:24]
| • | $50 million for a multi-year services agreement for a county wide P25 system in North America |

[0000068505-18-000022:8k_2_02:25]
| • | $41 million for command center software and 10-year services award in Asia |

[0000068505-18-000022:8k_2_02:26]
| • | $16 million multi-year services renewal in Chile |

[0000068505-18-000022:8k_2_02:27]
Products and Systems Integration wins

[0000068505-18-000022:8k_2_02:28]
| • | $71 million P25 system upgrade in Northern Africa |

[0000068505-18-000022:8k_2_02:29]
| • | $35 million P25 expansion for New South Wales Telco Authority in Australia |

[0000068505-18-000022:8k_2_02:30]
| • | $15 million P25 system replacement for Flagler County, Florida |

[0000068505-18-000022:8k_2_02:31]
| • | $495 million five-year IDIQ (indefinite delivery, indefinite quantity) P25 radio upgrade for U.S. Army |

[0000068505-18-000022:8k_2_02:32]
BUSINESS OUTLOOK

[0000068505-18-000022:8k_2_02:33]
| • | Third-quarter 2018 - Motorola Solutions expects revenue growth of approximately 13 percent compared with the third quarter of 2017. The company expects non-GAAP earnings in the range of $1.67 to $1.72 per share. This assumes 173 million fully diluted shares. |

[0000068505-18-000022:8k_2_02:34]
| • | Full-year 2018 - The company now expects revenue growth of approximately 14.5 percent, up from the prior outlook of 14 percent including $40 million of unfavorable currency impact since our prior guidance. The company now expects non-GAAP earnings per share in the range of $6.79 to $6.89, up from the prior guidance of $6.70 to $6.85. This assumes current foreign exchange rates, approximately 172 million fully diluted shares and a 25 percent effective tax rate. |

[0000068505-18-000022:8k_2_02:35]
CONFERENCE CALL AND WEBCAST Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, Aug. 2. The conference call will be webcast live at www.motorolasolutions.com/investor.

[0000068505-18-000022:8k_2_02:36]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0000068505-18-000022:8k_2_02:37]
A comparison of results from operations is as follows:

[0000068505-18-000022:8k_2_02:38]
|  | Q2 2018 |  | Q2 2017 |  |
| Net sales | $1,760 | $1,497 |
| Gross margin | 822 |  | 690 |  |
| Operating earnings | 273 |  | 261 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |
| Net earnings | 180 |  | 131 |  |
| Diluted EPS | $1.05 | $0.78 |
| Weighted average diluted common shares outstanding | 171.7 |  | 169.0 |  |

[0000068505-18-000022:8k_2_02:39]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0000068505-18-000022:8k_2_02:40]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the second quarter of 2018.

[0000068505-18-000022:8k_2_02:41]
| (per diluted common share) | Q2 2018 |  |
| GAAP Earnings | $1.05 |
| Highlighted Items: |  |
| Share-based compensation expense | $0.08 |
| Reorganization of business charges | 0.10 |  |
| Intangibles amortization expense | 0.23 |  |
| Avigilon purchase accounting adjustment | 0.04 |  |
| Sale of investments | 0.01 |  |
| Loss on foreign currency related to Avigilon purchase | 0.01 |  |
| FIN 48 reserve | 0.01 |  |
| State audit settlement | (0.07 | ) |
| Non-GAAP Diluted EPS | $1.46 |

[0000068505-18-000022:8k_2_02:42]
USE OF NON-GAAP FINANCIAL INFORMATION

[0000068505-18-000022:8k_2_02:43]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0000068505-18-000022:8k_2_02:44]
Organic revenue:  Reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters, and excludes the affects of ASC 606. Management believes organic revenue helps it and investors better identify the underlying trends of established and ongoing operations by excluding the effects of acquisitions and accounting adjustments which can obscure period to period comparisons.

[0000068505-18-000022:8k_2_02:45]
Highlighted items: The company has excluded the effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments, significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance. For the purposes of management's internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a meaningful evaluation of the company's current operating performance or comparisons to the company's past operating performance.

[0000068505-18-000022:8k_2_02:46]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0000068505-18-000022:8k_2_02:47]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0000068505-18-000022:8k_2_02:48]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0000068505-18-000022:8k_2_02:49]
BUSINESS RISKS

[0000068505-18-000022:8k_2_02:50]
estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola Solutions, and factors that may impact forward-looking statements include, but are not limited to: (1) the economic outlook for the government communications industry; (2) the impact of foreign currency fluctuations on the company; (3) the level of demand for the company's products; (4) the company's ability to refresh existing and introduce new products and technologies in a timely manner; (5) exposure under large systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (6) negative impact on the company's business from global economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company's products; (iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company's suppliers that may no longer have access to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company's pension plan and other defined benefit plans, which could impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (7) the impact of a security breach or other significant disruption in the company’s IT systems, those of its partners or suppliers or those it sells to or operates or maintains for its customers; (8) the outcome of ongoing and future tax matters; (9) the company's ability to purchase sufficient materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (10) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (11) the impact on the company's performance and financial results from strategic acquisitions or divestitures; (12) risks related to the company's manufacturing and business operations in foreign countries; (13) the creditworthiness of the company's customers and distributors, particularly purchasers of large infrastructure systems; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company's intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to complete acquisitions or repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company's use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; and (22) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise

[0000068505-18-000022:8k_2_02:51]
DEFINITIONS

[0000068505-18-000022:8k_2_02:52]
1 Organic revenue reflects net sales calculated under GAAP excluding net sales from acquired business owned for less than four full quarters and excluding the effects of ASC 606.

[0000068505-18-000022:8k_2_02:53]
2  Free cash flow represents operating cash flow less capital expenditures.

[0000068505-18-000022:8k_2_02:54]
ABOUT MOTOROLA SOLUTIONS

[0000068505-18-000022:8k_2_02:55]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0000068505-18-000022:8k_2_02:56]
MEDIA CONTACT

[0000068505-18-000022:8k_2_02:57]
Tama McWhinney

[0000068505-18-000022:8k_2_02:58]
Motorola Solutions

[0000068505-18-000022:8k_2_02:59]
+1 847-538-1865

[0000068505-18-000022:8k_2_02:60]
tama.mcwhinney@motorolasolutions.com

[0000068505-18-000022:8k_2_02:61]
INVESTOR CONTACT

[0000068505-18-000022:8k_2_02:62]
Chris Kutsor

[0000068505-18-000022:8k_2_02:63]
Motorola Solutions

[0000068505-18-000022:8k_2_02:64]
+1 847-576-4995

[0000068505-18-000022:8k_2_02:65]
chris.kutsor@motorolasolutions.com

[0000068505-18-000022:8k_2_02:66]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners. ©2018 Motorola Solutions, Inc. All rights reserved.

[0000068505-18-000022:8k_2_02:67]
GAAP-1

[0000068505-18-000022:8k_2_02:68]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:69]
Condensed Consolidated Statements of Operations

[0000068505-18-000022:8k_2_02:70]
(In millions, except per share amounts)

[0000068505-18-000022:8k_2_02:71]
|  | Three Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Net sales from products | $ | 1,042 |  |  | $ | 848 |  |
| Net sales from services | 718 |  |  | 649 |  |
| Net sales | 1,760 |  |  | 1,497 |  |
| Costs of products sales | 485 |  |  | 392 |  |
| Costs of services sales | 453 |  |  | 415 |  |
| Costs of sales | 938 |  |  | 807 |  |
| Gross margin | 822 |  |  | 690 |  |
| Selling, general and administrative expenses | 316 |  |  | 254 |  |
| Research and development expenditures | 162 |  |  | 138 |  |
| Other charges | 18 |  |  | — |  |
| Intangibles amortization | 53 |  |  | 37 |  |
| Operating earnings | 273 |  |  | 261 |  |
| Other income (expense): |  |  |  |  |  |
| Interest expense, net | (58 | ) |  | (51 | ) |
| Losses on sales of investments and businesses, net | (1 | ) |  | (1 | ) |
| Other | 13 |  |  | (4 | ) |
| Total other expense | (46 | ) |  | (56 | ) |
| Net earnings before income taxes | 227 |  |  | 205 |  |
| Income tax expense | 46 |  |  | 73 |  |
| Net earnings | 181 |  |  | 132 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 180 |  |  | $ | 131 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.11 |  |  | $ | 0.80 |  |
| Diluted | $ | 1.05 |  |  | $ | 0.78 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |
| Basic | 162.2 |  |  | 163.1 |  |
| Diluted | 171.7 |  |  | 169.0 |  |

[0000068505-18-000022:8k_2_02:72]
|  | Percentage of Net Sales* |
| Net sales from products | 59.2 | % |  | 56.6 | % |
| Net sales from services | 40.8 | % |  | 43.4 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 46.5 | % |  | 46.2 | % |
| Costs of services sales | 63.1 | % |  | 63.9 | % |
| Costs of sales | 53.3 | % |  | 53.9 | % |
| Gross margin | 46.7 | % |  | 46.1 | % |
| Selling, general and administrative expenses | 18.0 | % |  | 17.0 | % |
| Research and development expenditures | 9.2 | % |  | 9.2 | % |
| Other charges | 1.0 | % |  | — | % |
| Intangibles amortization | 3.0 | % |  | 2.5 | % |
| Operating earnings | 15.5 | % |  | 17.4 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.3 | )% |  | (3.4 | )% |
| Losses on sales of investments and businesses, net | (0.1 | )% |  | (0.1 | )% |
| Other | 0.7 | % |  | (0.3 | )% |
| Total other expense | (2.6 | )% |  | (3.7 | )% |
| Net earnings before income taxes | 12.9 | % |  | 13.7 | % |
| Income tax expense | 2.6 | % |  | 4.9 | % |
| Net earnings | 10.3 | % |  | 8.8 | % |
| Less: Earnings attributable to noncontrolling interests | 0.1 | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 10.2 | % |  | 8.8 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-18-000022:8k_2_02:73]
GAAP-2

[0000068505-18-000022:8k_2_02:74]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:75]
Condensed Consolidated Statements of Operations

[0000068505-18-000022:8k_2_02:76]
(In millions, except per share amounts)

[0000068505-18-000022:8k_2_02:77]
|  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Net sales from products | $ | 1,842 |  |  | $ | 1,551 |  |
| Net sales from services | 1,385 |  |  | 1,226 |  |
| Net sales | 3,227 |  |  | 2,777 |  |
| Costs of products sales | 867 |  |  | 739 |  |
| Costs of services sales | 869 |  |  | 778 |  |
| Costs of sales | 1,736 |  |  | 1,517 |  |
| Gross margin | 1,491 |  |  | 1,260 |  |
| Selling, general and administrative expenses | 594 |  |  | 500 |  |
| Research and development expenditures | 314 |  |  | 273 |  |
| Other charges | 44 |  |  | (19 | ) |
| Intangibles amortization | 94 |  |  | 73 |  |
| Operating earnings | 445 |  |  | 433 |  |
| Other income (expense): |  |  |  |
| Interest expense, net | (104 | ) |  | (102 | ) |
| Gains on sales of investments and businesses, net | 10 |  |  | 2 |  |
| Other | 16 |  |  | (9 | ) |
| Total other expense | (78 | ) |  | (109 | ) |
| Net earnings before income taxes | 367 |  |  | 324 |  |
| Income tax expense | 69 |  |  | 114 |  |
| Net earnings | 298 |  |  | 210 |  |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 297 |  |  | $ | 208 |  |
| Earnings per common share: |  |  |  |
| Basic | $ | 1.83 |  |  | $ | 1.27 |  |
| Diluted | $ | 1.73 |  |  | $ | 1.23 |  |
| Weighted average common shares outstanding: |  |  |  |
| Basic | 161.7 |  |  | 163.7 |  |
| Diluted | 171.1 |  |  | 169.5 |  |

[0000068505-18-000022:8k_2_02:78]
|  | Percentage of Net Sales* |
| Net sales from products | 57.1 | % |  | 55.9 | % |
| Net sales from services | 42.9 | % |  | 44.1 | % |
| Net sales | 100.0 | % |  | 100.0 | % |
| Costs of products sales | 47.1 | % |  | 47.6 | % |
| Costs of services sales | 62.7 | % |  | 63.5 | % |
| Costs of sales | 53.8 | % |  | 54.6 | % |
| Gross margin | 46.2 | % |  | 45.4 | % |
| Selling, general and administrative expenses | 18.4 | % |  | 18.0 | % |
| Research and development expenditures | 9.7 | % |  | 9.8 | % |
| Other charges | 1.4 | % |  | (0.7 | )% |
| Intangibles amortization | 2.9 | % |  | 2.6 | % |
| Operating earnings | 13.8 | % |  | 15.6 | % |
| Other income (expense): |  |  |  |
| Interest expense, net | (3.2 | )% |  | (3.7 | )% |
| Gains on sales of investments and businesses, net | 0.3 | % |  | 0.1 | % |
| Other | 0.5 | % |  | (0.3 | )% |
| Total other expense | (2.4 | )% |  | (3.9 | )% |
| Net earnings before income taxes | 11.4 | % |  | 11.7 | % |
| Income tax expense | 2.1 | % |  | 4.1 | % |
| Net earnings | 9.2 | % |  | 7.6 | % |
| Less: Earnings attributable to noncontrolling interests | — | % |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | 9.2 | % |  | 7.5 | % |
| * Percentages may not add up due to rounding |  |  |  |

[0000068505-18-000022:8k_2_02:79]
GAAP-3

[0000068505-18-000022:8k_2_02:80]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:81]
Condensed Consolidated Balance Sheets

[0000068505-18-000022:8k_2_02:82]
(In millions)

[0000068505-18-000022:8k_2_02:83]
|  |  | June 30, 2018 |  | December 31, 2017 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 878 |  |  | $ | 1,205 |  |
| Restricted cash |  | 63 |  |  | 63 |  |
| Total cash and cash equivalents |  | 941 |  |  | 1,268 |  |
| Accounts receivable, net |  | 1,159 |  |  | 1,523 |  |
| Contract assets |  | 760 |  |  | — |  |
| Inventories, net |  | 391 |  |  | 327 |  |
| Other current assets |  | 330 |  |  | 832 |  |
| Total current assets |  | 3,581 |  |  | 3,950 |  |
| Property, plant and equipment, net |  | 895 |  |  | 856 |  |
| Investments |  | 172 |  |  | 247 |  |
| Deferred income taxes |  | 945 |  |  | 1,023 |  |
| Goodwill |  | 1,528 |  |  | 938 |  |
| Intangible assets |  | 1,340 |  |  | 861 |  |
| Other assets |  | 420 |  |  | 333 |  |
| Total assets |  | $ | 8,881 |  |  | $ | 8,208 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Current portion of long-term debt |  | $ | 347 |  |  | $ | 52 |  |
| Accounts payable |  | 430 |  |  | 593 |  |
| Contract liabilities |  | 1,049 |  |  | — |  |
| Accrued liabilities |  | 1,096 |  |  | 2,286 |  |
| Total current liabilities |  | 2,922 |  |  | 2,931 |  |
| Long-term debt |  | 5,298 |  |  | 4,419 |  |
| Other liabilities |  | 2,153 |  |  | 2,585 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  | (1,507 | ) |  | (1,742 | ) |
| Noncontrolling interests |  | 15 |  |  | 15 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,881 |  |  | $ | 8,208 |  |

[0000068505-18-000022:8k_2_02:84]
GAAP-4

[0000068505-18-000022:8k_2_02:85]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:86]
Condensed Consolidated Statements of Cash Flows

[0000068505-18-000022:8k_2_02:87]
(In millions)

[0000068505-18-000022:8k_2_02:88]
|  | Three Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 180 |  |  | $ | 131 |  |
| Earnings attributable to noncontrolling interests | 1 |  |  | 1 |  |
| Net earnings | 181 |  |  | 132 |  |
| Adjustments to reconcile Net earnings to Net cash provided by (used for) operating activities: |  |  |  |
| Depreciation and amortization | 96 |  |  | 86 |  |
| Non-cash other charges | 3 |  |  | 6 |  |
| Non-U.S. pension settlement loss | — |  |  | 16 |  |
| Share-based compensation expense | 17 |  |  | 16 |  |
| Losses on sales of investments and businesses, net | 1 |  |  | 1 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable, contract assets and contract liabilities | 11 |  |  | (117 | ) |
| Inventories | 46 |  |  | (43 | ) |
| Other current assets | 41 |  |  | 38 |  |
| Accounts payable and accrued liabilities | 10 |  |  | (33 | ) |
| Other assets and liabilities | (5 | ) |  | 31 |  |
| Deferred income taxes | 24 |  |  | 40 |  |
| Net cash (used for) provided by operating activities | 425 |  |  | 173 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (28 | ) |  | (34 | ) |
| Proceeds from sales of investments and businesses, net | 2 |  |  | 19 |  |
| Capital expenditures | (41 | ) |  | (53 | ) |
| Net cash used for investing activities | (67 | ) |  | (68 | ) |
| Financing |  |  |  |
| Repayment of debt | (147 | ) |  | (5 | ) |
| Net proceeds from issuance of debt | (1 | ) |  | — |  |
| Proceeds from financing through capital leases | — |  |  | 7 |  |
| Issuance of common stock | 6 |  |  | 6 |  |
| Purchases of common stock | — |  |  | (80 | ) |
| Payments of dividends | (84 | ) |  | (77 | ) |
| Payments of dividend to non-controlling interest | (1 | ) |  | (2 | ) |
| Net cash used for financing activities | (227 | ) |  | (151 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (48 | ) |  | 22 |  |
| Net increase (decrease) in cash and cash equivalents | 83 |  |  | (24 | ) |
| Cash and cash equivalents, beginning of period | 858 |  |  | 829 |  |
| Cash and cash equivalents, end of period | $ | 941 |  |  | $ | 805 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | 384 |  |  | $ | 120 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-18-000022:8k_2_02:89]
GAAP-5

[0000068505-18-000022:8k_2_02:90]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:91]
Condensed Consolidated Statements of Cash Flows

[0000068505-18-000022:8k_2_02:92]
(In millions)

[0000068505-18-000022:8k_2_02:93]
|  | Six Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Operating |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 297 |  |  | $ | 208 |  |
| Earnings attributable to noncontrolling interests | 1 |  |  | 2 |  |
| Net earnings | 298 |  |  | 210 |  |
| Adjustments to reconcile Net earnings to Net cash provided by (used for) operating activities: |  |  |  |
| Depreciation and amortization | 178 |  |  | 166 |  |
| Non-cash other charges | 6 |  |  | 21 |  |
| Non-U.S. pension settlement loss | — |  |  | 25 |  |
| Share-based compensation expense | 34 |  |  | 33 |  |
| Gains on sales of investments and businesses, net | (10 | ) |  | (2 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |
| Accounts receivable, contract assets and contract liabilities | 206 |  |  | 251 |  |
| Inventories | 37 |  |  | (112 | ) |
| Other current assets | 43 |  |  | (21 | ) |
| Accounts payable and accrued liabilities | (340 | ) |  | (340 | ) |
| Other assets and liabilities | (558 | ) |  | 21 |  |
| Deferred income taxes | 31 |  |  | 63 |  |
| Net cash provided by (used for) operating activities | (75 | ) |  | 315 |  |
| Investing |  |  |  |
| Acquisitions and investments, net | (1,153 | ) |  | (140 | ) |
| Proceeds from sales of investments and businesses, net | 79 |  |  | 72 |  |
| Capital expenditures | (82 | ) |  | (121 | ) |
| Net cash used for investing activities | (1,156 | ) |  | (189 | ) |
| Financing |  |  |  |
| Repayment of debt | (197 | ) |  | (6 | ) |
| Net proceeds from issuance of debt | 1,295 |  |  | — |  |
| Proceeds from financing through capital leases | — |  |  | 7 |  |
| Issuance of common stock | 59 |  |  | 28 |  |
| Purchases of common stock | (66 | ) |  | (258 | ) |
| Payments of dividends | (168 | ) |  | (154 | ) |
| Payments of dividend to non-controlling interest | (1 | ) |  | (2 | ) |
| Net cash provided by (used for) financing activities | 922 |  |  | (385 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (18 | ) |  | 34 |  |
| Net decrease in cash and cash equivalents | (327 | ) |  | (225 | ) |
| Cash and cash equivalents, beginning of period | 1,268 |  |  | 1,030 |  |
| Cash and cash equivalents, end of period | $ | 941 |  |  | $ | 805 |  |
| Financial Ratios: |  |  |  |
| Free cash flow* | $ | (157 | ) |  | $ | 194 |  |
| *Free cash flow = Net cash provided by operating activities - Capital Expenditures |  |  |  |

[0000068505-18-000022:8k_2_02:94]
GAAP-6

[0000068505-18-000022:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:96]
Segment Information

[0000068505-18-000022:8k_2_02:97]
(In millions)

[0000068505-18-000022:8k_2_02:98]
| Net Sales |
|  | Three Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 1,189 |  |  | $ | 1,047 |  |  | 14 | % |
| Services and software | 571 |  |  | 450 |  |  | 27 | % |
| Total Motorola Solutions | $ | 1,760 |  |  | $ | 1,497 |  |  | 18 | % |
|  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 2,141 |  |  | $ | 1,901 |  |  | 13 | % |
| Services and software | 1,086 |  |  | 876 |  |  | 24 | % |
| Total Motorola Solutions | $ | 3,227 |  |  | $ | 2,777 |  |  | 16 | % |
| Operating Earnings |
|  | Three Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 175 |  |  | $ | 190 |  |  | (8 | )% |
| Services and software | 98 |  |  | 71 |  |  | 38 | % |
| Total Motorola Solutions | $ | 273 |  |  | $ | 261 |  |  | 5 | % |
|  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 265 |  |  | $ | 287 |  |  | (8 | )% |
| Services and software | 180 |  |  | 146 |  |  | 23 | % |
| Total Motorola Solutions | $ | 445 |  |  | $ | 433 |  |  | 3 | % |

[0000068505-18-000022:8k_2_02:99]
| Operating Earnings % |
|  | Three Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  |  |
| Products and systems integration | 14.7 | % |  | 18.1 | % |  |  |
| Services and software | 17.2 | % |  | 15.8 | % |  |  |
| Total Motorola Solutions | 15.5 | % |  | 17.4 | % |  |  |
|  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  |  |
| Products and systems integration | 12.4 | % |  | 15.1 | % |  |  |
| Services and software | 16.6 | % |  | 16.7 | % |  |  |
| Total Motorola Solutions | 13.8 | % |  | 15.6 | % |  |  |

[0000068505-18-000022:8k_2_02:100]
Non-GAAP-1

[0000068505-18-000022:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:102]
Non-GAAP Adjustments (Intangibles Amortization Expenses, Share-Based Compensation Expense, and Highlighted Items)

[0000068505-18-000022:8k_2_02:103]
| Q1 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 13 |  |  | 3 |  |  | 10 |  |  | 0.06 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 41 |  |  | 8 |  |  | 33 |  |  | 0.19 |  |
| Loss on legal settlements |  | Other charges |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on derivative instruments related to Avigilon |  | Other expense |  | 14 |  |  | 4 |  |  | 10 |  |  | 0.06 |  |
| Release of FIN 48 reserve |  | Income tax benefit |  | — |  |  | 1 |  |  | (1 | ) |  | (0.01 | ) |
| Sale of investments |  | Sale of Investment or Business (Gain) or Loss |  | (11 | ) |  | (3 | ) |  | (8 | ) |  | (0.05 | ) |
| Acquisition-related transaction fees |  | Other charges |  | 17 |  |  | 5 |  |  | 12 |  |  | 0.07 |  |
| Total impact on Net earnings |  |  |  | $ | 92 |  |  | $ | 22 |  |  | $ | 70 |  |  | $ | 0.41 |  |
| Q2 2018 |
| Non-GAAP Adjustments |  | Statement Line |  | PBT (Inc)/Exp |  | Tax Inc/(Exp) |  | PAT (Inc)/Exp |  | EPS impact |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  | 25 |  |  | 6 |  |  | 19 |  |  | 0.10 |  |
| Intangibles amortization expense |  | Intangibles amortization |  | 53 |  |  | 12 |  |  | 41 |  |  | 0.23 |  |
| Avigilon purchase accounting adjustment |  | Cost of sales |  | 10 |  |  | 3 |  |  | 7 |  |  | 0.04 |  |
| Sale of investments |  | Sale of Investment or Business (Gain) or Loss |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| Loss on foreign currency related to Avigilon purchase |  | Other expense |  | 1 |  |  | — |  |  | 1 |  |  | 0.01 |  |
| FIN 48 reserve |  | Income tax expense |  | — |  |  | (1 | ) |  | 1 |  |  | 0.01 |  |
| State audit settlement |  | Income tax benefit |  | — |  |  | 12 |  |  | (12 | ) |  | (0.07 | ) |
| Total impact on Net earnings |  |  |  | $ | 107 |  |  | $ | 36 |  |  | $ | 71 |  |  | $ | 0.41 |  |

[0000068505-18-000022:8k_2_02:104]
Non-GAAP-2

[0000068505-18-000022:8k_2_02:105]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:106]
Non-GAAP Segment Information

[0000068505-18-000022:8k_2_02:107]
(In millions)

[0000068505-18-000022:8k_2_02:108]
| Net Sales |
|  | Three Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 1,189 |  |  | $ | 1,047 |  |  | 14 | % |
| Services and software | 571 |  |  | 450 |  |  | 27 | % |
| Total Motorola Solutions | $ | 1,760 |  |  | $ | 1,497 |  |  | 18 | % |
|  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 2,141 |  |  | $ | 1,901 |  |  | 13 | % |
| Services and software | 1,086 |  |  | 876 |  |  | 24 | % |
| Total Motorola Solutions | $ | 3,227 |  |  | $ | 2,777 |  |  | 16 | % |
| Non-GAAP Operating Earnings |
|  | Three Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 226 |  |  | $ | 204 |  |  | 11 | % |
| Services and software | 152 |  |  | 112 |  |  | 36 | % |
| Total Motorola Solutions | $ | 378 |  |  | $ | 316 |  |  | 20 | % |
|  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Products and systems integration | $ | 350 |  |  | $ | 306 |  |  | 14 | % |
| Services and software | 287 |  |  | 222 |  |  | 29 | % |
| Total Motorola Solutions | $ | 637 |  |  | $ | 528 |  |  | 21 | % |

[0000068505-18-000022:8k_2_02:109]
| Non-GAAP Operating Earnings % |
|  | Three Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  |  |
| Products and systems integration | 19.0 | % |  | 19.5 | % |  |  |
| Services and software | 26.6 | % |  | 24.9 | % |  |  |
| Total Motorola Solutions | 21.5 | % |  | 21.1 | % |  |  |
|  | Six Months Ended |  |  |
|  | June 30, 2018 |  | July 1, 2017 |  |  |
| Products and systems integration | 16.3 | % |  | 16.1 | % |  |  |
| Services and software | 26.4 | % |  | 25.3 | % |  |  |
| Total Motorola Solutions | 19.7 | % |  | 19.0 | % |  |  |

[0000068505-18-000022:8k_2_02:110]
Non-GAAP-3

[0000068505-18-000022:8k_2_02:111]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:112]
Operating Earnings after Non-GAAP Adjustments

[0000068505-18-000022:8k_2_02:113]
| Q1 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,468 |  |  | $ | 952 |  |  | $ | 516 |  |
| Operating earnings ("OE") |  | $ | 171 |  |  | $ | 90 |  |  | $ | 81 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 13 |  |  | 9 |  |  | 4 |  |
| Intangibles amortization expense |  | 41 |  |  | 1 |  |  | 40 |  |
| Acquisition-related transaction fees |  | 17 |  |  | 12 |  |  | 5 |  |
| Loss on legal settlements |  | 1 |  |  | 1 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 89 |  |  | 35 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 260 |  |  | $ | 125 |  |  | $ | 135 |  |

[0000068505-18-000022:8k_2_02:114]
| Operating earnings as a percentage of net sales - GAAP |  | 11.6 | % |  | 9.5 | % |  | 15.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 17.7 | % |  | 13.1 | % |  | 26.2 | % |

[0000068505-18-000022:8k_2_02:115]
| Q2 2018 |
|  |  | TOTAL |  | Products and Systems Integration |  | Services and Software |
| Net sales |  | $ | 1,760 |  |  | $ | 1,189 |  |  | $ | 571 |  |
| Operating earnings ("OE") |  | $ | 273 |  |  | $ | 175 |  |  | $ | 98 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 17 |  |  | 12 |  |  | 5 |  |
| Reorganization of business charges |  | 25 |  |  | 19 |  |  | 6 |  |
| Intangibles amortization expense |  | 53 |  |  | 10 |  |  | 43 |  |
| Avigilon purchase accounting adjustment |  | 10 |  |  | 10 |  |  | — |  |
| Total above-OE non-GAAP adjustments |  | 105 |  |  | 51 |  |  | 54 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 378 |  |  | $ | 226 |  |  | $ | 152 |  |

[0000068505-18-000022:8k_2_02:116]
| Operating earnings as a percentage of net sales - GAAP |  | 15.5 | % |  | 14.7 | % |  | 17.2 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  | 21.5 | % |  | 19.0 | % |  | 26.6 | % |

[0000068505-18-000022:8k_2_02:117]
Non-GAAP-4

[0000068505-18-000022:8k_2_02:118]
Motorola Solutions, Inc. and Subsidiaries

[0000068505-18-000022:8k_2_02:119]
Non-GAAP Organic Revenue

[0000068505-18-000022:8k_2_02:120]
| Total Motorola Solutions |
|  |  | Three Months Ended |  |  |
|  |  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Net sales |  | $ | 1,760 |  |  | $ | 1,497 |  |  | 18 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (154 | ) |  | — |  |  |  |
| ASC 606 impact |  | (24 | ) |  | — |  |  |  |
| Organic revenue |  | 1,582 |  |  | 1,497 |  |  | 6 | % |
| Less foreign exchange impact |  | (26 | ) |  | — |  |  |  |
| Organic revenue in constant currency |  | $ | 1,556 |  |  | $ | 1,497 |  |  | 4 | % |

[0000068505-18-000022:8k_2_02:121]
| Total Motorola Solutions |
|  |  | Six Months Ended |  |  |
|  |  | June 30, 2018 |  | July 1, 2017 |  | % Change |
| Net sales |  | $ | 3,227 |  |  | $ | 2,777 |  |  | 16 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Acquisitions |  | (206 | ) |  | (5 | ) |  |  |
| ASC 606 impact |  | (39 | ) |  | — |  |  |  |
| Organic revenue |  | 2,982 |  |  | 2,772 |  |  | 8 | % |
| Less foreign exchange impact |  | (65 | ) |  | — |  |  |  |
| Organic revenue in constant currency |  | $ | 2,917 |  |  | $ | 2,772 |  |  | 5 | % |
