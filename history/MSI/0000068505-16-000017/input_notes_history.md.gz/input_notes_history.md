# MSI note change history — 0000068505-15-000010 → 0000068505-15-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0000068505-15-000013:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at October 3, 2015.
  (was, 2015-08-05, similarity 0.9908):
[0000068505-15-000010:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations.  The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value.  The Company had no accruals for any such obligations at July 4, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0000068505-15-000013:note_history:2]
The condensed consolidated financial statements as of October 3, 2015 and for the three and nine months ended October 3, 2015 and September 27, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2015-08-05, similarity 0.9355):
[0000068505-15-000010:note_history:2]
The condensed consolidated financial statements as of July 4, 2015 and for the three and six months ended July 4, 2015 and June 28, 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2015-11-04):
[0000068505-15-000013:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three and nine months ended October 3, 2015 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2015-08-05, similarity 0.849):
[0000068505-15-000010:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2014. The results of operations for the three and six months ended July 4, 2015 are not necessarily indicative of the operating results to be expected for the full year.

- changed (2015-11-04):
[0000068505-15-000013:note_history:4]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers: Deferral of the Effective Date that delayed the effective date of ASU 2014-09 by one year to January 1, 2018 as the Company’s annual reporting period begins after December 15, 2017. ASU 2014-09 allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.
  (was, 2015-08-05, similarity 0.6065):
[0000068505-15-000010:note_history:4]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. This ASU will be effective for the Company beginning January 1, 2018. This ASU allows for both retrospective and modified-retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- changed (2015-11-04):
[0000068505-15-000013:note_history:5]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of October 3, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $44 million.
  (was, 2015-08-05, similarity 0.9942):
[0000068505-15-000010:note_history:5]
In April 2015, the FASB issued ASU No. 2015-03, Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of July 4, 2015, debt issuance costs, net of accumulated amortization, recognized in the condensed consolidated balance sheet were $18 million.

- changed (2015-11-04):
[0000068505-15-000013:note_history:6]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, where net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for the Company beginning January 1, 2017 with early adoption permitted. The Company does not expect this ASU will have a material impact on its consolidated financial statements.
  (was, 2015-08-05, similarity 0.8441):
[0000068505-15-000010:note_history:6]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 340): Simplifying the Measurement of Inventory. Under this guidance, entities utilizing the FIFO or average cost method should measure inventory at the lower of cost or net realizable value, whereas net realizable value is defined as the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This ASU should be applied prospectively and will be effective for the Company beginning January 1, 2017 with early adoption permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0000068505-15-000013:note_history:7]
As of October 3, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 3, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the nine months ended October 3, 2015.
  (was, 2015-08-05, similarity 0.8939):
[0000068505-15-000010:note_history:7]
As of July 4, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 4, 2015. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the six months ended July 4, 2015.

- added (2015-11-04):
[0000068505-15-000013:note_history:8]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% Senior Convertible Notes which mature in September 2020 (the "Senior Convertible Notes"). Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

- added (2015-11-04):
[0000068505-15-000013:note_history:9]
The Company has recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. The total of proceeds received in excess of the fair value of the debt liability of $8 million has been recorded within Additional paid-in capital.

- removed (2015-11-04):
[0000068505-15-000010:note_history:10]
On August 4, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1 billion of 2% convertible notes which mature in September 2020. Interest on the notes will be payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.59854 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). The Company may, at its option, elect to settle the amount due upon conversion in cash, common stock, or a combination of cash and common stock. The Company expects to close this transaction on August 25, 2015.
