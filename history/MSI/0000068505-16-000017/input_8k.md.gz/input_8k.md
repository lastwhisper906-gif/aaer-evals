# MSI 8-K — 0001193125-16-471662 filed 2016-02-22

## item codes, every 8-K on or before 2016-02-23

- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2016-02-23

- none on or before 2016-02-23

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-471662:8k_2_02:1]
EX-99.1
2
d129690dex991.htm
EX-99.1

[0001193125-16-471662:8k_2_02:2]
EX-99.1

[0001193125-16-471662:8k_2_02:3]
Exhibit 99.1

[0001193125-16-471662:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year 2015 Financial Results

[0001193125-16-471662:8k_2_02:5]
Company closes acquisition of Airwave, leading public safety managed services provider

[0001193125-16-471662:8k_2_02:6]
FOURTH-QUARTER HIGHLIGHTS

[0001193125-16-471662:8k_2_02:7]
|  | • |  | Sales of $1.7 billion, down 8 percent, including $54 million of unfavorable foreign currency impact |

[0001193125-16-471662:8k_2_02:8]
|  | • |  | GAAP earnings per share (EPS) from continuing operations1 of $1.56 |

[0001193125-16-471662:8k_2_02:9]
|  | • |  | Non-GAAP EPS from continuing operations* of $1.58, up 26 percent driven by lower operating expenses |

[0001193125-16-471662:8k_2_02:10]
|  | • |  | Generated $414 million in operating cash flow; $1.0 billion for the full year |

[0001193125-16-471662:8k_2_02:11]
|  | • |  | Generated $370 million in free cash flow2; $830 million for the full year |

[0001193125-16-471662:8k_2_02:12]
|  | • |  | Returned $239 million to shareholders in share repurchase and dividends; $3.5 billion for full year |

[0001193125-16-471662:8k_2_02:13]
SCHAUMBURG, Ill. - Feb. 22, 2016 - Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter
and full year of 2015. Click here for a printable news release and financial tables.

[0001193125-16-471662:8k_2_02:14]
SUPPORTING QUOTE “The fourth quarter
capped off a year of disciplined execution from our team with strong earnings growth and cash flow performance,” said Greg Brown, chairman and CEO of Motorola Solutions. “We grew in North America and grew in Managed & Support
services across all regions while increasing backlog by nearly $700 million. Additionally, we achieved more than $200 million in structural cost savings and returned $3.5 billion of capital to shareholders.”

[0001193125-16-471662:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0001193125-16-471662:8k_2_02:16]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Sales |  | $ | 1,682 |  |  | $ | 1,823 |  |  |  | (8 | )% |  | $ | 5,695 |  |  | $ | 5,881 |  |  |  | (3 | )% |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings (loss) |  | $ | 389 |  |  | $ | (1,459 | ) |  |  | N/M |  |  | $ | 994 |  |  | $ | (1,006 | ) |  |  | N/M |  |
| % of Sales |  |  | 23.1 | % |  |  | (80.0 | )% |  |  |  |  |  |  | 17.5 | % |  |  | (17.1 | )% |  |  |  |  |
| EPS from continuing operations |  | $ | 1.56 |  |  | $ | (4.02 | ) |  |  | N/M |  |  | $ | 3.17 |  |  | $ | (2.84 | ) |  |  | N/M |  |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings |  | $ | 458 |  |  | $ | 483 |  |  |  | (5 | )% |  | $ | 1,166 |  |  | $ | 1,069 |  |  |  | 9 | % |
| % of Sales |  |  | 27.2 | % |  |  | 26.5 | % |  |  |  |  |  |  | 20.5 | % |  |  | 18.2 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 1.58 |  |  | $ | 1.25 |  |  |  | 26 | % |  | $ | 3.33 |  |  | $ | 2.58 |  |  |  | 29 | % |
| Product Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 1,125 |  |  | $ | 1,246 |  |  |  | (10 | )% |  | $ | 3,676 |  |  | $ | 3,807 |  |  |  | (3 | )% |
| GAAP Operating earnings (loss) |  | $ | 291 |  |  | $ | (944 | ) |  |  | N/M |  |  | $ | 704 |  |  | $ | (667 | ) |  |  | N/M |  |
| % of Sales |  |  | 25.9 | % |  |  | (75.8 | )% |  |  |  |  |  |  | 19.2 | % |  |  | (17.5 | )% |  |  |  |  |
| Non-GAAP Operating earnings |  | $ | 340 |  |  | $ | 394 |  |  |  | (14 | )% |  | $ | 827 |  |  | $ | 754 |  |  |  | 10 | % |
| % of Sales |  |  | 30.2 | % |  |  | 31.6 | % |  |  |  |  |  |  | 22.5 | % |  |  | 19.8 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 557 |  |  | $ | 577 |  |  |  | (3 | )% |  | $ | 2,019 |  |  | $ | 2,074 |  |  |  | (3 | )% |
| GAAP Operating earnings (loss) |  | $ | 98 |  |  | $ | (515 | ) |  |  | N/M |  |  | $ | 290 |  |  | $ | (339 | ) |  |  | N/M |  |
| % of Sales |  |  | 17.6 | % |  |  | (89.3 | )% |  |  |  |  |  |  | 14.4 | % |  |  | (16.3 | )% |  |  |  |  |
| Non-GAAP Operating earnings |  | $ | 118 |  |  | $ | 89 |  |  |  | 33 | % |  | $ | 339 |  |  | $ | 315 |  |  |  | 8 | % |
| % of Sales |  |  | 21.2 | % |  |  | 15.4 | % |  |  |  |  |  |  | 16.8 | % |  |  | 15.2 | % |  |  |  |  |

[0001193125-16-471662:8k_2_02:17]
| * | Q4 Non-GAAP financial information excludes the after-tax impact of approximately $0.02 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items for the fourth-quarter. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-16-471662:8k_2_02:18]
OTHER
SELECTED FOURTH-QUARTER FINANCIAL RESULTS

[0001193125-16-471662:8k_2_02:19]
|  | • |  | Revenue - Sales decreased 8 percent, including $54 million of unfavorable foreign currency impact. These results reflect a 1 percent decline in North America, or flat when excluding the impact of currency. Overall company product sales declined 10 percent due primarily to weakness in Latin America and Europe. The Services business declined 3 percent due to currency headwinds, lower iDEN revenue and a decline in systems integration revenues in Norway. |

[0001193125-16-471662:8k_2_02:20]
|  | • |  | Operating margin - GAAP operating margin was 23.1 percent of sales in the fourth quarter of 2015; non-GAAP operating margin was 27.2 percent of sales, compared with 26.5 percent in the fourth quarter of 2014. Improved non-GAAP results reflect $45 million in lower operating expenses compared with the fourth quarter of 2014, due to the company’s cost reduction initiatives, lower pension expense and a stronger dollar. |

[0001193125-16-471662:8k_2_02:21]
|  | • |  | Taxes - The fourth quarter of 2015 GAAP effective tax rate was 26 percent. This compares with a tax rate of 38 percent in the fourth quarter of 2014, which was driven by the loss from continuing operations. The fourth quarter of 2015 non-GAAP tax rate was 31 percent compared with a tax rate of 35 percent in the fourth quarter of 2014. |

[0001193125-16-471662:8k_2_02:22]
|  | • |  | Cash flow - The company generated $414 million in operating cash flow from continuing operations during the quarter, reflecting solid execution across all working capital accounts. Free cash flow was $370 million in the quarter. The increase was largely driven by lower pension contributions and improved cost structure. |

[0001193125-16-471662:8k_2_02:23]
|  | • |  | Cash and cash equivalents - The company ended the quarter with cash and cash equivalents of $2.03 billion and a net debt position of approximately $2.4 billion4. The company repurchased approximately $179 million of its common stock in the fourth quarter of 2015 and paid approximately $60 million in cash dividends. |

[0001193125-16-471662:8k_2_02:24]
OTHER SELECTED FULL-YEAR FINANCIAL RESULTS

[0001193125-16-471662:8k_2_02:25]
|  | • |  | Revenue - Sales decreased 3 percent, including $201 million of unfavorable foreign currency impact. These results reflect 3 percent growth in North America, which delivered improvements in both Products and Services sales in state and local governments. Overall company product sales declined 3 percent due to currency headwinds and weakness in Latin America and Europe. The Services business declined 3 percent primarily due to currency headwinds, lower iDEN revenue and a decline in systems integration revenues in Norway. |

[0001193125-16-471662:8k_2_02:26]
|  | • |  | Operating margin - For the full year, GAAP operating margin was 17.5 percent of sales in 2015, compared with (17.1) percent for the full year of 2014. 2014 results include a $1.9 billion non-recurring charge related to U.S. pension de-risking actions. For the full year, non-GAAP operating margin was 20.5 percent of sales in 2015, compared with 18.2 percent for the full year of 2014 driven primarily by lower operating expenses. |

[0001193125-16-471662:8k_2_02:27]
|  | • |  | Taxes - The 2015 GAAP effective tax rate was 30 percent. This compares with a full-year GAAP effective tax rate of 40 percent in 2014. The full year 2015 non-GAAP tax rate was 33 percent, compared with a tax rate of 32 percent in 2014. |

[0001193125-16-471662:8k_2_02:28]
|  | • |  | Cash flow - The company generated $1.0 billion in operating cash from continuing operations, reflecting an increase of $1.7 billion over the prior year. Free cash flow was $830 million in the year. The increase was largely driven by lower pension contributions and improved earnings performance. |

[0001193125-16-471662:8k_2_02:29]
KEY HIGHLIGHTS

[0001193125-16-471662:8k_2_02:30]
Strategic wins

[0001193125-16-471662:8k_2_02:31]
|  | • |  | $430 million contract for the fourth major public safety long-term evolution (LTE) award as the Lot 2 winner of the United Kingdom’s Emergency Network System |

[0001193125-16-471662:8k_2_02:32]
|  | • |  | $170 million covering four separate U.S. statewide networks to provide both network upgrades and Managed & Support services over multiyear periods |

[0001193125-16-471662:8k_2_02:33]
|  | • |  | $21 million Smart Public Safety win with our local partner serving the Royal Malaysia Police enabling the integration of computer-aided dispatch, video management, command & control center dispatch and equipping police cars with video systems to enable dispatch with situational awareness |

[0001193125-16-471662:8k_2_02:34]
Innovation and investments in growth

[0001193125-16-471662:8k_2_02:35]
|  | • |  | Completed our $1 billion acquisition of Airwave Communications. Airwave is the largest private operator of a public safety network in the world, delivering mission-critical voice and data communications to more than 300 public service agencies in Great Britain |

[0001193125-16-471662:8k_2_02:36]
|  | • |  | Released new P25 software upgrade “Software Defined Core” enabling customers to more easily add features, software updates and licensing capabilities |

[0001193125-16-471662:8k_2_02:37]
|  | • |  | Introduced our next-generation digital mobile radio solution for commercial customers that extends our industry leading MOTOTRBO capabilities and complies with the DMR III standard. Also introduced new devices purpose built for commercial customers in hazardous locations in both P25 and TETRA technologies |

[0001193125-16-471662:8k_2_02:38]
|  | • |  | Executed successful public safety LTE trials around the world that span devices, land-mobile radio & LTE interoperability, applications, and deployable networks |

[0001193125-16-471662:8k_2_02:39]
BUSINESS OUTLOOK

[0001193125-16-471662:8k_2_02:40]
|  | • |  | First quarter 2016 - Motorola Solutions expects a revenue decline of 3 to 5 percent compared with the first quarter of 2015. This assumes a $20 million5 unfavorable currency impact and includes approximately $55 million in revenues associated with the Airwave acquisition. The company expects non-GAAP earnings per share from continuing operations in the range of $0.37 to $0.42 per share. |

[0001193125-16-471662:8k_2_02:41]
|  | • |  | Full-year 2016 - The company expects revenue to increase 5 to 7 percent compared to 2015. This assumes a $60 million5 unfavorable currency impact. The company’s outlook assumes growth in North America and contraction in Europe and Latin America, including iDEN revenues. This revenue outlook includes approximately $450 million in revenues associated with the Airwave acquisition. The company expects non-GAAP earnings per share from continuing operations in the range of $4.45 to $4.65 per share. |

[0001193125-16-471662:8k_2_02:42]
CONFERENCE CALL AND WEBCAST

[0001193125-16-471662:8k_2_02:43]
Motorola Solutions will host its quarterly conference call beginning at 4:00 p.m. U.S. Central Standard Time (5:00 p.m. U.S. Eastern Standard Time) Monday,
February 22. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-16-471662:8k_2_02:44]
CONSOLIDATED GAAP
RESULTS (presented in millions, except per share data)

[0001193125-16-471662:8k_2_02:45]
A comparison of results from operations is as follows:

[0001193125-16-471662:8k_2_02:46]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 1,682 |  |  | $ | 1,823 |  |  | $ | 5,695 |  |  | $ | 5,881 |  |
| Gross margin |  |  | 838 |  |  |  | 912 |  |  |  | 2,719 |  |  |  | 2,831 |  |
| Operating earnings (loss) |  |  | 389 |  |  |  | (1,459 | ) |  |  | 994 |  |  |  | (1,006 | ) |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  |  | 277 |  |  |  | (926 | ) |  |  | 640 |  |  |  | (697 | ) |
| Net earnings |  |  | 279 |  |  |  | 201 |  |  |  | 610 |  |  |  | 1,299 |  |
| Diluted EPS from continuing operations |  | $ | 1.56 |  |  | $ | (4.02 | ) |  | $ | 3.17 |  |  | $ | (2.84 | ) |
| Weighted average diluted common shares outstanding |  |  | 177.5 |  |  |  | 230.5 |  |  |  | 201.8 |  |  |  | 245.6 |  |

[0001193125-16-471662:8k_2_02:47]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-16-471662:8k_2_02:48]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the fourth quarter of 2015.

[0001193125-16-471662:8k_2_02:49]
| (per diluted common share) |  | Q4 2015 |  |
| GAAP Earnings from Continuing Operations |  | $ | 1.56 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  | $ | 0.08 |  |
| Reorganization of business charges |  | $ | 0.16 |  |
| Intangibles amortization expense |  |  | — |  |
| Gain on sale of equity investment |  | $ | (0.14 | ) |
| Impairment of corporate aircraft |  | $ | 0.02 |  |
| Decrease in net deferred tax liability for undistributed earnings |  | $ | (0.07 | ) |
| Tax benefit for foreign tax credit |  | $ | (0.03 | ) |
| Total Highlighted Items |  | $ | 0.02 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 1.58 |  |

[0001193125-16-471662:8k_2_02:50]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-16-471662:8k_2_02:51]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-16-471662:8k_2_02:52]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of highlighted items recorded in prior periods) from
its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s
current operating performance or comparisons to the company’s past operating performance.

[0001193125-16-471662:8k_2_02:53]
Share-based compensation expense: The
company has excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such
compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation
expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-16-471662:8k_2_02:54]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its Non-GAAP operating expenses and net
earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but
is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented and will contribute to the
company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-16-471662:8k_2_02:55]
Constant Currency: We
evaluate our results of operations on both an as reported and a constant currency basis. The constant currency presentation, which is a non-GAAP measure, excludes the impact of fluctuations in foreign currency exchange rates. We calculate
constant currency percentages by converting our current period local currency results using prior-period exchange rates, and then comparing these adjusted values to prior period reported results.

[0001193125-16-471662:8k_2_02:56]
Details of the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press
release.

[0001193125-16-471662:8k_2_02:57]
BUSINESS RISKS

[0001193125-16-471662:8k_2_02:58]
of various activities, including certain manufacturing operations, information technology and administrative functions; (22) the impact of the sale of the company’s legacy information
systems, including components of the enterprise resource planning (ERP) system and the implementation of a new ERP system; and (23) the company’s ability to settle the par value of the Senior Convertible Notes in cash. Motorola Solutions
undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-16-471662:8k_2_02:59]
DEFINITIONS

[0001193125-16-471662:8k_2_02:60]
| 1 | Amounts attributable to Motorola Solutions, Inc. common shareholders. |

[0001193125-16-471662:8k_2_02:61]
| 2 | Free cash flow represents operating cash flow less capex |

[0001193125-16-471662:8k_2_02:62]
| 3 | Ending cash excludes $400 million of UK treasury securities purchased in association with the Airwave transaction |

[0001193125-16-471662:8k_2_02:63]
| 4 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-16-471662:8k_2_02:64]
| 5 | Based on currency rates as of Feb. 19, 2016 |

[0001193125-16-471662:8k_2_02:65]
ABOUT MOTOROLA SOLUTIONS

[0001193125-16-471662:8k_2_02:66]
Motorola Solutions (NYSE: MSI)
creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to
a news feed.

[0001193125-16-471662:8k_2_02:67]
MEDIA CONTACT

[0001193125-16-471662:8k_2_02:68]
Tama McWhinney

[0001193125-16-471662:8k_2_02:69]
Motorola Solutions

[0001193125-16-471662:8k_2_02:70]
+1 847-538-1865

[0001193125-16-471662:8k_2_02:71]
tama.mcwhinney@motorolasolutions.com

[0001193125-16-471662:8k_2_02:72]
INVESTOR
CONTACTS

[0001193125-16-471662:8k_2_02:73]
Shep Dunlap

[0001193125-16-471662:8k_2_02:74]
Motorola Solutions

[0001193125-16-471662:8k_2_02:75]
+1 847-576-6899

[0001193125-16-471662:8k_2_02:76]
shep.dunlap@motorolasolutions.com

[0001193125-16-471662:8k_2_02:77]
Chris Kutsor

[0001193125-16-471662:8k_2_02:78]
Motorola Solutions

[0001193125-16-471662:8k_2_02:79]
+1 847-576-4995

[0001193125-16-471662:8k_2_02:80]
chris.kutsor@motorolasolutions.com

[0001193125-16-471662:8k_2_02:81]
MOTOROLA, MOTOROLA SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license.
All other trademarks are the property of their respective owners. ©2015 Motorola Solutions, Inc. All rights reserved.

[0001193125-16-471662:8k_2_02:82]
GAAP-1

[0001193125-16-471662:8k_2_02:83]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:84]
Consolidated Statements of Operations

[0001193125-16-471662:8k_2_02:85]
(In millions, except per share amounts)

[0001193125-16-471662:8k_2_02:86]
|  |  | Three Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Net sales from products |  | $ | 1,125 |  |  | $ | 1,246 |  |
| Net sales from services |  |  | 557 |  |  |  | 577 |  |
| Net sales |  |  | 1,682 |  |  |  | 1,823 |  |
| Costs of products sales |  |  | 485 |  |  |  | 513 |  |
| Costs of services sales |  |  | 359 |  |  |  | 398 |  |
| Costs of sales |  |  | 844 |  |  |  | 911 |  |
| Gross margin |  |  | 838 |  |  |  | 912 |  |
| Selling, general and administrative expenses |  |  | 252 |  |  |  | 283 |  |
| Research and development expenditures |  |  | 152 |  |  |  | 165 |  |
| Other charges |  |  | 43 |  |  |  | 1,922 |  |
| Intangibles amortization |  |  | 2 |  |  |  | 1 |  |
| Operating earnings (loss) |  |  | 389 |  |  |  | (1,459 | ) |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (51 | ) |  |  | (41 | ) |
| Gains on sales of investments |  |  | 47 |  |  |  | 2 |  |
| Other |  |  | (8 | ) |  |  | — |  |
| Total other expense |  |  | (12 | ) |  |  | (39 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  | 377 |  |  |  | (1,498 | ) |
| Income tax expense (benefit) |  |  | 99 |  |  |  | (572 | ) |
| Earnings (loss) from continuing operations |  |  | 278 |  |  |  | (926 | ) |
| Earnings from discontinued operations, net of tax |  |  | 2 |  |  |  | 1,127 |  |
| Net earnings |  |  | 280 |  |  |  | 201 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 279 |  |  | $ | 201 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  | $ | 277 |  |  | $ | (926 | ) |
| Earnings from discontinued operations, net of tax |  |  | 2 |  |  |  | 1,127 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 279 |  |  | $ | 201 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.58 |  |  | $ | (4.02 | ) |
| Discontinued operations |  |  | 0.02 |  |  |  | 4.89 |  |
|  |  | $ | 1.60 |  |  | $ | 0.87 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.56 |  |  | $ | (4.02 | ) |
| Discontinued operations |  |  | 0.01 |  |  |  | 4.89 |  |
|  |  | $ | 1.57 |  |  | $ | 0.87 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 174.9 |  |  |  | 230.5 |  |
| Diluted |  |  | 177.5 |  |  |  | 230.5 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 66.9 | % |  |  | 68.3 | % |
| Net sales from services |  |  | 33.1 | % |  |  | 31.7 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 43.1 | % |  |  | 41.2 | % |
| Costs of services sales |  |  | 64.5 | % |  |  | 69.0 | % |
| Costs of sales |  |  | 50.2 | % |  |  | 50.0 | % |
| Gross margin |  |  | 49.8 | % |  |  | 50.0 | % |
| Selling, general and administrative expenses |  |  | 15.0 | % |  |  | 15.5 | % |
| Research and development expenditures |  |  | 9.0 | % |  |  | 9.1 | % |
| Other charges |  |  | 2.6 | % |  |  | 105.4 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.1 | % |
| Operating earnings (loss) |  |  | 23.1 | % |  |  | (80.0 | )% |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.0 | )% |  |  | (2.2 | )% |
| Gains on sales of investments |  |  | 2.8 | % |  |  | 0.1 | % |
| Other |  |  | (0.5 | )% |  |  | — | % |
| Total other expense |  |  | (0.7 | )% |  |  | (2.1 | )% |
| Earnings (loss) from continuing operations before income taxes |  |  | 22.4 | % |  |  | (82.2 | )% |
| Income tax expense (benefit) |  |  | 5.9 | % |  |  | (31.4 | )% |
| Earnings (loss) from continuing operations |  |  | 16.5 | % |  |  | (50.8 | )% |
| Earnings from discontinued operations, net of tax |  |  | 0.1 | % |  |  | 61.8 | % |
| Net earnings |  |  | 16.6 | % |  |  | 11.0 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 16.6 | % |  |  | 11.0 | % |

[0001193125-16-471662:8k_2_02:87]
| * | Percentages may not add up due to rounding |

[0001193125-16-471662:8k_2_02:88]
GAAP-2

[0001193125-16-471662:8k_2_02:89]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:90]
Consolidated Statements of Operations

[0001193125-16-471662:8k_2_02:91]
(In millions, except per share amounts)

[0001193125-16-471662:8k_2_02:92]
|  |  | Years Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2013 |  |
| Net sales from products |  | $ | 3,676 |  |  | $ | 3,807 |  |  | $ | 4,109 |  |
| Net sales from services |  |  | 2,019 |  |  |  | 2,074 |  |  |  | 2,118 |  |
| Net sales |  |  | 5,695 |  |  |  | 5,881 |  |  |  | 6,227 |  |
| Costs of products sales |  |  | 1,625 |  |  |  | 1,678 |  |  |  | 1,808 |  |
| Costs of services sales |  |  | 1,351 |  |  |  | 1,372 |  |  |  | 1,310 |  |
| Costs of sales |  |  | 2,976 |  |  |  | 3,050 |  |  |  | 3,118 |  |
| Gross margin |  |  | 2,719 |  |  |  | 2,831 |  |  |  | 3,109 |  |
| Selling, general and administrative expenses |  |  | 1,021 |  |  |  | 1,184 |  |  |  | 1,330 |  |
| Research and development expenditures |  |  | 620 |  |  |  | 681 |  |  |  | 761 |  |
| Other charges |  |  | 76 |  |  |  | 1,968 |  |  |  | 70 |  |
| Intangibles amortization |  |  | 8 |  |  |  | 4 |  |  |  | 1 |  |
| Operating earnings (loss) |  |  | 994 |  |  |  | (1,006 | ) |  |  | 947 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (173 | ) |  |  | (126 | ) |  |  | (113 | ) |
| Gains on sales of investments |  |  | 107 |  |  |  | 5 |  |  |  | 37 |  |
| Other |  |  | (11 | ) |  |  | (34 | ) |  |  | 9 |  |
| Total other expense |  |  | (77 | ) |  |  | (155 | ) |  |  | (67 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  | 917 |  |  |  | (1,161 | ) |  |  | 880 |  |
| Income tax expense (benefit) |  |  | 274 |  |  |  | (465 | ) |  |  | (59 | ) |
| Earnings (loss) from continuing operations |  |  | 643 |  |  |  | (696 | ) |  |  | 939 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (30 | ) |  |  | 1,996 |  |  |  | 166 |  |
| Net earnings |  |  | 613 |  |  |  | 1,300 |  |  |  | 1,105 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 3 |  |  |  | 1 |  |  |  | 6 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 610 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  | $ | 640 |  |  | $ | (697 | ) |  | $ | 933 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (30 | ) |  |  | 1,996 |  |  |  | 166 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 610 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 3.21 |  |  | $ | (2.84 | ) |  | $ | 3.51 |  |
| Discontinued operations |  |  | (0.15 | ) |  |  | 8.13 |  |  |  | 0.62 |  |
|  |  | $ | 3.06 |  |  | $ | 5.29 |  |  | $ | 4.13 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 3.17 |  |  | $ | (2.84 | ) |  | $ | 3.45 |  |
| Discontinued operations |  |  | (0.15 | ) |  |  | 8.13 |  |  |  | 0.61 |  |
|  |  | $ | 3.02 |  |  | $ | 5.29 |  |  | $ | 4.06 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 199.6 |  |  |  | 245.6 |  |  |  | 266.0 |  |
| Diluted |  |  | 201.8 |  |  |  | 245.6 |  |  |  | 270.5 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 64.5 | % |  |  | 64.7 | % |  |  | 66.0 | % |
| Net sales from services |  |  | 35.5 | % |  |  | 35.3 | % |  |  | 34.0 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 44.2 | % |  |  | 44.1 | % |  |  | 44.0 | % |
| Costs of services sales |  |  | 66.9 | % |  |  | 66.2 | % |  |  | 61.9 | % |
| Costs of sales |  |  | 52.3 | % |  |  | 51.9 | % |  |  | 50.1 | % |
| Gross margin |  |  | 47.7 | % |  |  | 48.1 | % |  |  | 49.9 | % |
| Selling, general and administrative expenses |  |  | 17.9 | % |  |  | 20.1 | % |  |  | 21.4 | % |
| Research and development expenditures |  |  | 10.9 | % |  |  | 11.6 | % |  |  | 12.2 | % |
| Other charges |  |  | 1.3 | % |  |  | 33.5 | % |  |  | 1.1 | % |
| Intangibles amortization |  |  | 0.1 | % |  |  | 0.1 | % |  |  | — | % |
| Operating earnings (loss) |  |  | 17.5 | % |  |  | (17.1 | )% |  |  | 15.2 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.0 | )% |  |  | (2.1 | )% |  |  | (1.8 | )% |
| Gains on sales of investments |  |  | 1.9 | % |  |  | 0.1 | % |  |  | 0.6 | % |
| Other |  |  | (0.2 | )% |  |  | (0.6 | )% |  |  | 0.1 | % |
| Total other expense |  |  | (1.4 | )% |  |  | (2.6 | )% |  |  | (1.1 | )% |
| Earnings (loss) from continuing operations before income taxes |  |  | 16.1 | % |  |  | (19.7 | )% |  |  | 14.1 | % |
| Income tax expense (benefit) |  |  | 4.8 | % |  |  | (7.9 | )% |  |  | (0.9 | )% |
| Earnings (loss) from continuing operations |  |  | 11.3 | % |  |  | (11.8 | )% |  |  | 15.1 | % |
| Earnings (loss) from discontinued operations, net of tax |  |  | (0.5 | )% |  |  | 33.9 | % |  |  | 2.7 | % |
| Net earnings |  |  | 10.8 | % |  |  | 22.1 | % |  |  | 17.7 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | — | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 10.7 | % |  |  | 22.1 | % |  |  | 17.6 | % |

[0001193125-16-471662:8k_2_02:93]
| * | Percentages may not add up due to rounding |

[0001193125-16-471662:8k_2_02:94]
GAAP-3

[0001193125-16-471662:8k_2_02:95]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:96]
Consolidated Balance Sheets

[0001193125-16-471662:8k_2_02:97]
(In millions)

[0001193125-16-471662:8k_2_02:98]
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,980 |  |  | $ | 3,954 |  |
| Accounts receivable, net |  |  | 1,362 |  |  |  | 1,409 |  |
| Inventories, net |  |  | 296 |  |  |  | 345 |  |
| Deferred income taxes |  |  | — |  |  |  | 431 |  |
| Other current assets |  |  | 917 |  |  |  | 740 |  |
| Current assets held for disposition |  |  | 27 |  |  |  | — |  |
| Total current assets |  |  | 4,582 |  |  |  | 6,879 |  |
| Property, plant and equipment, net |  |  | 487 |  |  |  | 549 |  |
| Investments |  |  | 268 |  |  |  | 316 |  |
| Deferred income taxes |  |  | 2,278 |  |  |  | 2,151 |  |
| Goodwill |  |  | 420 |  |  |  | 383 |  |
| Other assets |  |  | 312 |  |  |  | 145 |  |
| Non-current assets held for disposition |  |  | 40 |  |  |  | — |  |
| Total assets |  | $ | 8,387 |  |  | $ | 10,423 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 518 |  |  |  | 540 |  |
| Accrued liabilities |  |  | 1,671 |  |  |  | 1,706 |  |
| Total current liabilities |  |  | 2,193 |  |  |  | 2,250 |  |
| Long-term debt |  |  | 4,386 |  |  |  | 3,396 |  |
| Other liabilities |  |  | 1,904 |  |  |  | 2,011 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (106 | ) |  |  | 2,735 |  |
| Noncontrolling interests |  |  | 10 |  |  |  | 31 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,387 |  |  | $ | 10,423 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (2,410 | ) |  | $ | 554 |  |

[0001193125-16-471662:8k_2_02:99]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-16-471662:8k_2_02:100]
GAAP-4

[0001193125-16-471662:8k_2_02:101]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:102]
Consolidated Statements of Cash Flows

[0001193125-16-471662:8k_2_02:103]
(In millions)

[0001193125-16-471662:8k_2_02:104]
|  |  | Three Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 279 |  |  | $ | 201 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings |  |  | 280 |  |  |  | 201 |  |
| Earnings from discontinued operations, net of tax |  |  | 2 |  |  |  | 1,127 |  |
| Earnings (loss) from continuing operations, net of tax |  |  | 278 |  |  |  | (926 | ) |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by (used for) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 37 |  |  |  | 42 |  |
| Non-cash other charges |  |  | 9 |  |  |  | 2 |  |
| Loss on pension plan settlement |  |  | — |  |  |  | 1,883 |  |
| Share-based compensation expense |  |  | 20 |  |  |  | 20 |  |
| Gains on sales of investments and businesses, net |  |  | (47 | ) |  |  | (2 | ) |
| Deferred income taxes |  |  | 33 |  |  |  | (626 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (146 | ) |  |  | (264 | ) |
| Inventories |  |  | 37 |  |  |  | (17 | ) |
| Other current assets |  |  | 54 |  |  |  | (38 | ) |
| Accounts payable and accrued liabilities |  |  | 178 |  |  |  | 50 |  |
| Other assets and liabilities |  |  | (39 | ) |  |  | (824 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 414 |  |  |  | (700 | ) |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (436 | ) |  |  | (26 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 80 |  |  |  | 3,380 |  |
| Capital expenditures |  |  | (44 | ) |  |  | (51 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 1 |  |  |  | 3 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (399 | ) |  |  | 3,306 |  |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (4 | ) |
| Net proceeds from issuance of debt |  |  | (5 | ) |  |  | — |  |
| Issuance of common stock |  |  | 15 |  |  |  | 41 |  |
| Purchase of common stock |  |  | (179 | ) |  |  | (1,423 | ) |
| Excess tax benefit from share-based compensation |  |  | 4 |  |  |  | — |  |
| Payment of dividends |  |  | (60 | ) |  |  | (82 | ) |
| Distributions from discontinued operations |  |  | — |  |  |  | 27 |  |
| Net cash used for financing activities from continuing operations |  |  | (226 | ) |  |  | (1,441 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | — |  |  |  | 32 |  |
| Net cash used for investing activities from discontinued operations |  |  | — |  |  |  | (1 | ) |
| Net cash used for financing activities from discontinued operations |  |  | — |  |  |  | (27 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | (4 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (9 | ) |  |  | (56 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (220 | ) |  |  | 1,109 |  |
| Cash and cash equivalents, beginning of period |  |  | 2,200 |  |  |  | 2,845 |  |
| Cash and cash equivalents, end of period |  | $ | 1,980 |  |  | $ | 3,954 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 370 |  |  | $ | (751 | ) |

[0001193125-16-471662:8k_2_02:105]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-471662:8k_2_02:106]
GAAP-5

[0001193125-16-471662:8k_2_02:107]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:108]
Consolidated Statements of Cash Flows

[0001193125-16-471662:8k_2_02:109]
(In millions)

[0001193125-16-471662:8k_2_02:110]
|  |  | Years Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | December 31, 2013 |  |
| Operating |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 610 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |
| Earnings attributable to noncontrolling interests |  |  | 3 |  |  |  | 1 |  |  |  | 6 |  |
| Net earnings |  |  | 613 |  |  |  | 1,300 |  |  |  | 1,105 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | (30 | ) |  |  | 1,996 |  |  |  | 166 |  |
| Earnings (loss) from continuing operations, net of tax |  |  | 643 |  |  |  | (696 | ) |  |  | 939 |  |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by (used for) operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 150 |  |  |  | 173 |  |  |  | 158 |  |
| Non-cash other charges (income) |  |  | 52 |  |  |  | — |  |  |  | (14 | ) |
| Non-U.S. pension curtailment gain |  |  | (32 | ) |  |  | — |  |  |  | — |  |
| Gain on sale of building and land |  |  | — |  |  |  | (21 | ) |  |  | — |  |
| Loss on pension plan settlement |  |  | — |  |  |  | 1,883 |  |  |  | — |  |
| Share-based compensation expense |  |  | 78 |  |  |  | 94 |  |  |  | 120 |  |
| Gains on sales of investments and businesses, net |  |  | (107 | ) |  |  | (5 | ) |  |  | (37 | ) |
| Loss from the extinguishment of long-term debt |  |  | — |  |  |  | 37 |  |  |  | — |  |
| Deferred income taxes |  |  | 160 |  |  |  | (557 | ) |  |  | (334 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 21 |  |  |  | (62 | ) |  |  | (36 | ) |
| Inventories |  |  | 16 |  |  |  | (5 | ) |  |  | (8 | ) |
| Other current assets |  |  | 92 |  |  |  | (47 | ) |  |  | 50 |  |
| Accounts payable and accrued liabilities |  |  | 10 |  |  |  | (120 | ) |  |  | (232 | ) |
| Other assets and liabilities |  |  | (78 | ) |  |  | (1,359 | ) |  |  | (51 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 1,005 |  |  |  | (685 | ) |  |  | 555 |  |
| Investing |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (586 | ) |  |  | (47 | ) |  |  | (57 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 230 |  |  |  | 3,403 |  |  |  | 61 |  |
| Capital expenditures |  |  | (175 | ) |  |  | (181 | ) |  |  | (169 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 3 |  |  |  | 33 |  |  |  | 66 |  |
| Proceeds from sales of Sigma Fund investments and short-term investments, net |  |  | — |  |  |  | — |  |  |  | 2,133 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (528 | ) |  |  | 3,208 |  |  |  | 2,034 |  |
| Financing |  |  |  |  |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (4 | ) |  |  | (465 | ) |  |  | (4 | ) |
| Net proceeds from issuance of debt |  |  | 971 |  |  |  | 1,375 |  |  |  | 593 |  |
| Issuance of common stock |  |  | 100 |  |  |  | 135 |  |  |  | 165 |  |
| Purchase of common stock |  |  | (3,177 | ) |  |  | (2,546 | ) |  |  | (1,694 | ) |
| Excess tax benefit from share-based compensation |  |  | 5 |  |  |  | 11 |  |  |  | 25 |  |
| Payment of dividends |  |  | (277 | ) |  |  | (318 | ) |  |  | (292 | ) |
| Distributions from discontinued operations |  |  | — |  |  |  | 93 |  |  |  | 365 |  |
| Net cash used for financing activities from continuing operations |  |  | (2,382 | ) |  |  | (1,715 | ) |  |  | (842 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | — |  |  |  | 95 |  |  |  | 389 |  |
| Net cash provided by (used for) investing activities from discontinued operations |  |  | — |  |  |  | 4 |  |  |  | (24 | ) |
| Net cash used for financing activities from discontinued operations |  |  | — |  |  |  | (93 | ) |  |  | (365 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (69 | ) |  |  | (79 | ) |  |  | 10 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (1,974 | ) |  |  | 729 |  |  |  | 1,757 |  |
| Cash and cash equivalents, beginning of period |  |  | 3,954 |  |  |  | 3,225 |  |  |  | 1,468 |  |
| Cash and cash equivalents, end of period |  | $ | 1,980 |  |  | $ | 3,954 |  |  | $ | 3,225 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 830 |  |  | $ | (866 | ) |  | $ | 386 |  |

[0001193125-16-471662:8k_2_02:111]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-471662:8k_2_02:112]
GAAP-6

[0001193125-16-471662:8k_2_02:113]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:114]
Segment Information

[0001193125-16-471662:8k_2_02:115]
(In
millions)

[0001193125-16-471662:8k_2_02:116]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 1,125 |  |  | $ | 1,246 |  |  |  | (10 | )% |
| Services |  |  | 557 |  |  |  | 577 |  |  |  | (3 | )% |
| Total Motorola Solutions |  | $ | 1,682 |  |  | $ | 1,823 |  |  |  | (8 | )% |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 3,676 |  |  | $ | 3,807 |  |  |  | (3 | )% |
| Services |  |  | 2,019 |  |  |  | 2,074 |  |  |  | (3 | )% |
| Total Motorola Solutions |  | $ | 5,695 |  |  | $ | 5,881 |  |  |  | (3 | )% |
| Operating Earnings (loss) |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 291 |  |  | $ | (944 | ) |  |  | N/M |  |
| Services |  |  | 98 |  |  |  | (515 | ) |  |  | N/M |  |
| Total Motorola Solutions |  | $ | 389 |  |  | $ | (1,459 | ) |  |  | N/M |  |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 704 |  |  | $ | (667 | ) |  |  | N/M |  |
| Services |  |  | 290 |  |  |  | (339 | ) |  |  | N/M |  |
| Total Motorola Solutions |  | $ | 994 |  |  | $ | (1,006 | ) |  |  | N/M |  |
| * N/M = % Change is not meaningful due to the comparison using prior year operating losses as a basis for the calculation. |  |
| Operating Earnings % |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  |  |  |
| Products |  |  | 25.9 | % |  |  | (75.8 | )% |  |  |  |  |
| Services |  |  | 17.6 | % |  |  | (89.3 | )% |  |  |  |  |
| Total Motorola Solutions |  |  | 23.1 | % |  |  | (80.0 | )% |  |  |  |  |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  |  |  |
| Products |  |  | 19.2 | % |  |  | (17.5 | )% |  |  |  |  |
| Services |  |  | 14.4 | % |  |  | (16.3 | )% |  |  |  |  |
| Total Motorola Solutions |  |  | 17.5 | % |  |  | (17.1 | )% |  |  |  |  |

[0001193125-16-471662:8k_2_02:117]
Non-GAAP-1

[0001193125-16-471662:8k_2_02:118]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:119]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense, and Highlighted Items)

[0001193125-16-471662:8k_2_02:120]
| Q1 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 21 |  |  |  | 7 |  |  | $ | 14 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 14 |  |  |  | 4 |  |  |  | 10 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of equity investment |  | Gains on sales of investments and businesses, net |  |  | (46 | ) |  |  | (17 | ) |  |  | (29 | ) |  |  | (0.13 | ) |
| Total impact on Net earnings |  |  |  | $ | (9 | ) |  | $ | (5 | ) |  | $ | (4 | ) |  | $ | (0.02 | ) |
| Q2 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 19 |  |  |  | 6 |  |  | $ | 13 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 16 |  |  |  | 6 |  |  | $ | 10 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 3 |  |  |  | 1 |  |  | $ | 2 |  |  |  | — |  |
| Non-U.S. pension curtailment gain |  | Other charges |  |  | (32 | ) |  |  | — |  |  | $ | (32 | ) |  |  | (0.15 | ) |
| Total impact on Net earnings |  |  |  | $ | 6 |  |  | $ | 13 |  |  | $ | (7 | ) |  | $ | (0.04 | ) |
| Q3 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 18 |  |  |  | 6 |  |  |  | 12 |  |  |  | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 15 |  |  |  | 4 |  |  |  | 11 |  |  |  | 0.05 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Impairment of corporate aircraft |  | Other charges |  |  | 26 |  |  |  | 10 |  |  |  | 16 |  |  |  | 0.08 |  |
| Total impact on Net earnings |  |  |  | $ | 61 |  |  | $ | 21 |  |  | $ | 40 |  |  | $ | 0.19 |  |
| Q4 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 20 |  |  |  | 6 |  |  |  | 14 |  |  |  | 0.08 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 42 |  |  |  | 13 |  |  |  | 29 |  |  |  | 0.16 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Gain on sale of equity investment |  | Gains on sales of investments and businesses, net |  |  | (39 | ) |  |  | (14 | ) |  |  | (25 | ) |  |  | (0.14 | ) |
| Impairment of corporate aircraft |  | Other charges |  |  | 5 |  |  |  | 2 |  |  |  | 3 |  |  |  | 0.02 |  |
| Decrease in net deferred tax liability for undistributed earnings |  | Income tax expense |  |  | — |  |  |  | 13 |  |  |  | (13 | ) |  |  | (0.07 | ) |
| Tax benefit for foreign tax credit |  | Income tax expense |  |  | — |  |  |  | 6 |  |  |  | (6 | ) |  |  | (0.03 | ) |
| Total impact on Net earnings |  |  |  | $ | 30 |  |  | $ | 27 |  |  | $ | 3 |  |  |  | 0.02 |  |
| FY 2015 |  |
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  |  | 78 |  |  |  | 25 |  |  |  | 53 |  |  |  | 0.26 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 87 |  |  |  | 27 |  |  |  | 60 |  |  |  | 0.30 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 8 |  |  |  | 3 |  |  |  | 5 |  |  |  | 0.02 |  |
| Gain on sale of equity investment |  | Gains on sales of investments and businesses, net |  |  | (85 | ) |  |  | (32 | ) |  |  | (53 | ) |  |  | (0.27 | ) |
| Non-U.S. pension curtailment gain |  | Other charges |  |  | (32 | ) |  |  | — |  |  |  | (32 | ) |  |  | (0.16 | ) |
| Impairment of corporate aircraft |  | Other charges |  |  | 31 |  |  |  | 12 |  |  |  | 19 |  |  |  | 0.10 |  |
| Decrease in net deferred tax liability for undistributed earnings |  | Income tax expense |  |  | — |  |  |  | 13 |  |  |  | (13 | ) |  |  | (0.06 | ) |
| Tax benefit for foreign tax credit |  | Income tax expense |  |  | — |  |  |  | 6 |  |  |  | (6 | ) |  |  | (0.03 | ) |
| Total impact on Net earnings |  |  |  | $ | 87 |  |  | $ | 54 |  |  | $ | 33 |  |  | $ | 0.16 |  |

[0001193125-16-471662:8k_2_02:121]
Non-GAAP-2

[0001193125-16-471662:8k_2_02:122]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:123]
Non-GAAP Segment Information

[0001193125-16-471662:8k_2_02:124]
(In millions)

[0001193125-16-471662:8k_2_02:125]
| Net Sales |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 1,125 |  |  | $ | 1,246 |  |  |  | (10 | )% |
| Services |  |  | 557 |  |  |  | 577 |  |  |  | (3 | )% |
| Total Motorola Solutions |  | $ | 1,682 |  |  | $ | 1,823 |  |  |  | (8 | )% |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 3,676 |  |  | $ | 3,807 |  |  |  | (3 | )% |
| Services |  |  | 2,019 |  |  |  | 2,074 |  |  |  | (3 | )% |
| Total Motorola Solutions |  | $ | 5,695 |  |  | $ | 5,881 |  |  |  | (3 | )% |
| Non-GAAP Operating Earnings |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 340 |  |  | $ | 394 |  |  |  | (14 | )% |
| Services |  |  | 118 |  |  |  | 89 |  |  |  | 33 | % |
| Total Motorola Solutions |  | $ | 458 |  |  | $ | 483 |  |  |  | (5 | )% |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  | % Change |  |
| Products |  | $ | 827 |  |  | $ | 754 |  |  |  | 10 | % |
| Services |  |  | 339 |  |  |  | 315 |  |  |  | 8 | % |
| Total Motorola Solutions |  | $ | 1,166 |  |  | $ | 1,069 |  |  |  | 9 | % |
| Non-GAAP Operating Earnings % |  |
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  |  |  |
| Products |  |  | 30.2 | % |  |  | 31.6 | % |  |  |  |  |
| Services |  |  | 21.2 | % |  |  | 15.4 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 27.2 | % |  |  | 26.5 | % |  |  |  |  |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2015 |  |  | December 31, 2014 |  |  |  |  |
| Products |  |  | 22.5 | % |  |  | 19.8 | % |  |  |  |  |
| Services |  |  | 16.8 | % |  |  | 15.2 | % |  |  |  |  |
| Total Motorola Solutions |  |  | 20.5 | % |  |  | 18.2 | % |  |  |  |  |

[0001193125-16-471662:8k_2_02:126]
Non-GAAP-3

[0001193125-16-471662:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-471662:8k_2_02:128]
Operating Earnings after Non-GAAP Adjustments

[0001193125-16-471662:8k_2_02:129]
| Q1 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,223 |  |  | $ | 758 |  |  | $ | 465 |  |
| Operating earnings (“OE”) |  | $ | 119 |  |  | $ | 64 |  |  | $ | 55 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21 |  |  |  | 14 |  |  |  | 7 |  |
| Reorganization of business charges |  |  | 14 |  |  |  | 10 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Total above-OE non-GAAP adjustments |  |  | 37 |  |  |  | 26 |  |  |  | 11 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 156 |  |  | $ | 90 |  |  | $ | 66 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 9.7 | % |  |  | 8.4 | % |  |  | 11.8 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 12.8 | % |  |  | 11.9 | % |  |  | 14.2 | % |
| Q2 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,368 |  |  | $ | 867 |  |  | $ | 501 |  |
| Operating earnings (“OE”) |  | $ | 254 |  |  | $ | 171 |  |  | $ | 83 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 19 |  |  |  | 12 |  |  |  | 7 |  |
| Reorganization of business charges |  |  | 16 |  |  |  | 12 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Non-U.S. pension curtailment gain |  |  | (32 | ) |  |  | (22 | ) |  |  | (10 | ) |
| Total above-OE non-GAAP adjustments |  |  | 6 |  |  |  | 5 |  |  |  | 1 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 260 |  |  | $ | 176 |  |  | $ | 84 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 18.6 | % |  |  | 19.7 | % |  |  | 16.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 19.0 | % |  |  | 20.3 | % |  |  | 16.8 | % |
| Q3 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,422 |  |  | $ | 925 |  |  | $ | 497 |  |
| Operating earnings (“OE”) |  | $ | 231 |  |  | $ | 178 |  |  | $ | 53 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 18 |  |  |  | 12 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 15 |  |  |  | 11 |  |  |  | 4 |  |
| Intangibles amortization expense |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Impairment of corporate aircraft |  |  | 26 |  |  |  | 18 |  |  |  | 8 |  |
| Total above-OE non-GAAP adjustments |  |  | 61 |  |  |  | 43 |  |  |  | 18 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 292 |  |  | $ | 221 |  |  | $ | 71 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 16.2 | % |  |  | 19.2 | % |  |  | 10.7 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 20.5 | % |  |  | 23.9 | % |  |  | 14.3 | % |
| Q4 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,682 |  |  | $ | 1,125 |  |  | $ | 557 |  |
| Operating earnings (“OE”) |  | $ | 389 |  |  | $ | 291 |  |  | $ | 98 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 20 |  |  |  | 13 |  |  |  | 7 |  |
| Reorganization of business charges |  |  | 42 |  |  |  | 31 |  |  |  | 11 |  |
| Intangibles amortization expense |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Impairment of corporate aircraft |  |  | 5 |  |  |  | 3 |  |  |  | 2 |  |
| Total above-OE non-GAAP adjustments |  |  | 69 |  |  |  | 49 |  |  |  | 20 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 458 |  |  | $ | 340 |  |  | $ | 118 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 23.1 | % |  |  | 25.9 | % |  |  | 17.6 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 27.2 | % |  |  | 30.2 | % |  |  | 21.2 | % |
| FY 2015 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 5,695 |  |  | $ | 3,676 |  |  | $ | 2,019 |  |
| Operating earnings (“OE”) |  | $ | 994 |  |  | $ | 704 |  |  | $ | 290 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 78 |  |  |  | 51 |  |  |  | 27 |  |
| Reorganization of business charges |  |  | 87 |  |  |  | 65 |  |  |  | 22 |  |
| Intangibles amortization expense |  |  | 8 |  |  |  | 8 |  |  |  | — |  |
| Non-U.S. pension curtailment gain |  |  | (32 | ) |  |  | (22 | ) |  |  | (10 | ) |
| Impairment of corporate aircraft |  |  | 31 |  |  |  | 21 |  |  |  | 10 |  |
| Total above-OE non-GAAP adjustments |  |  | 172 |  |  |  | 123 |  |  |  | 49 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,166 |  |  | $ | 827 |  |  | $ | 339 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 17.5 | % |  |  | 19.2 | % |  |  | 14.4 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 20.5 | % |  |  | 22.5 | % |  |  | 16.8 | % |
