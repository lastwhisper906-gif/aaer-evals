# MSI notes — 0000068505-16-000017


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-16-000017:notes:1]
Investments consist of the following:

[0000068505-16-000017:notes:2]
| December 31, 2015 | Cost Basis |  | Unrealized Gains |  | Unrealized Loss |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 455 |  |  | $ | — |  |  | $ | (11 | ) |  | $ | 444 |  |
| Corporate bonds | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Common stock and equivalents | — |  |  | 6 |  |  | — |  |  | 6 |  |
|  | 462 |  |  | 6 |  |  | (11 | ) |  | 457 |  |
| Other investments, at cost | 203 |  |  | — |  |  | — |  |  | 203 |  |
| Equity method investments | 9 |  |  | — |  |  | — |  |  | 9 |  |
|  | 674 |  |  | 6 |  |  | (11 | ) |  | 669 |  |
| Less: current portion of available-for-sale securities |  |  |  |  |  |  | 401 |  |
|  |  |  |  |  |  |  | $ | 268 |  |

[0000068505-16-000017:notes:3]
In December 2015, the Company invested $401 million in United Kingdom treasury securities in order to partially offset the risk associated with fluctuations in the British Pound Sterling in the period before the closing of the purchase of Airwave. The Company liquidated these investments in February 2016 to partially fund the acquisition of Airwave. The investments are recorded within Other current assets in the Company's consolidated balance sheets.

[0000068505-16-000017:notes:4]
| December 31, 2014 | Cost Basis |  | Unrealized Gains |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 14 |  |  | $ | — |  |  | 14 |  |
| Corporate bonds | 16 |  |  | — |  |  | 16 |  |
| Mutual funds | 2 |  |  | — |  |  | 2 |  |
| Common stock and equivalents | 1 |  |  | 70 |  |  | 71 |  |
|  | 33 |  |  | 70 |  |  | 103 |  |
| Other investments, at cost | 191 |  |  | — |  |  | 191 |  |
| Equity method investments | 22 |  |  | — |  |  | 22 |  |
|  | $ | 246 |  |  | $ | 70 |  |  | $ | 316 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-16-000017:notes:5]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2015 and 2014 were as follows:

[0000068505-16-000017:notes:6]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 444 |  |  | 444 |  |
| Corporate bonds | — |  |  | 7 |  |  | 7 |  |
| Common stock and equivalents | 6 |  |  | — |  |  | 6 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest agreement derivative contracts | — |  |  | 1 |  |  | 1 |  |

[0000068505-16-000017:notes:7]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 14 |  |  | 14 |  |
| Corporate bonds | — |  |  | 16 |  |  | 16 |  |
| Mutual funds | — |  |  | 2 |  |  | 2 |  |
| Common stock and equivalents | 71 |  |  | — |  |  | 71 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Interest agreement derivative contracts | — |  |  | 2 |  |  | 2 |  |


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-16-000017:notes:8]
Long-term receivables consist of trade receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-16-000017:notes:9]
| December 31 | 2015 |  | 2014 |
| Long-term receivables | $ | 60 |  |  | $ | 49 |  |
| Less current portion | (13 | ) |  | (18 | ) |
| Non-current long-term receivables, net | $ | 47 |  |  | $ | 31 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-16-000017:notes:10]
Long-term Customer Financing and Sales of Receivables

[0000068505-16-000017:notes:11]
Long-term Customer Financing

[0000068505-16-000017:notes:12]
The current portion of long-term receivables is included in Accounts receivable and the non-current portion of long-term receivables is included in Other assets in the Company’s consolidated balance sheets. There was $2 million of interest income recognized on long-term receivables for the year ended December 31, 2015. There was $1 million of interest income recognized on long-term receivables for the year ended 2014 and no interest income recognized on long-term receivables for the year ended 2013.

[0000068505-16-000017:notes:13]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $112 million at December 31, 2015, compared to $293 million at December 31, 2014. Outstanding commitments decreased during the year ended December 31, 2015 primarily as a result of two large customer contracts, one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-16-000017:notes:14]
Sales of Receivables

[0000068505-16-000017:notes:15]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements. The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-16-000017:notes:16]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2015, 2014 and 2013.

[0000068505-16-000017:notes:17]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Cumulative annual proceeds received from sales: |  |  |  |  |  |
| Accounts receivable sales proceeds | $ | 29 |  |  | $ | 50 |  |  | $ | 14 |  |
| Long-term receivables sales proceeds | 196 |  |  | 124 |  |  | 131 |  |
| Total proceeds from receivable sales | $ | 225 |  |  | $ | 174 |  |  | $ | 145 |  |

[0000068505-16-000017:notes:18]
At December 31, 2015, the Company had retained servicing obligations for $668 million of long-term receivables, compared to $496 million of long-term receivables at December 31, 2014.  Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-16-000017:notes:19]
Credit Quality of Customer Financing Receivables and Allowance for Credit Losses

[0000068505-16-000017:notes:20]
An aging analysis of financing receivables at December 31, 2015 and December 31, 2014 is as follows:

[0000068505-16-000017:notes:21]
| December 31, 2015 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 35 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 25 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Total gross long-term receivables, including current portion | $ | 60 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-16-000017:notes:22]
| December 31, 2014 | TotalLong-termReceivable |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 14 |  |  | $ | — |  |
| Commercial loans and leases secured | 35 |  |  | 12 |  |
| Total gross long-term receivables, including current portion | $ | 49 |  |  | $ | 12 |  |

[0000068505-16-000017:notes:23]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.

[0000068505-16-000017:notes:24]
The Company’s policy for valuing the allowance for credit losses is to review all customer financing receivables for collectibility on an individual receivable basis.  For those receivables where collection risk is probable, the Company calculates the value of impairment based on the net present value of expected future cash flows from the customer.

[0000068505-16-000017:notes:25]
The Company had a total of $1 million of financing receivables over 90 days past due as of December 31, 2015 in relation to one loan. As of December 31, 2015, the Company is not accruing interest on this loan, and the past due amount is adequately reserved.


## msi:OtherChargesTableTextBlock

[0000068505-16-000017:notes:26]
Other charges (income) included in Operating earnings (loss) consist of the following:

[0000068505-16-000017:notes:27]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization | $ | 8 |  |  | $ | 4 |  |  | $ | 1 |  |
| Reorganization of businesses | 77 |  |  | 64 |  |  | 70 |  |
| Legal settlement | — |  |  | 8 |  |  | — |  |
| Non-U.S. pension curtailment gain | (32 | ) |  | — |  |  | — |  |
| Settlement of pension plan | — |  |  | 1,917 |  |  | — |  |
| Impairment of corporate aircraft | 31 |  |  | — |  |  | — |  |
| Gain on sale of building and land | — |  |  | (21 | ) |  | — |  |
|  | $ | 84 |  |  | $ | 1,972 |  |  | $ | 71 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-16-000017:notes:28]
The following table displays the net charges incurred by segment:

[0000068505-16-000017:notes:29]
| Year ended December 31 | 2013 |
| Products | $ | 57 |  |
| Services | 29 |  |
|  | $ | 86 |  |

[0000068505-16-000017:notes:30]
| Year ended December 31 | 2014 |
| Products | $ | 48 |  |
| Services | 25 |  |
|  | $ | 73 |  |

[0000068505-16-000017:notes:31]
| Year ended December 31 | 2015 |
| Products | $ | 84 |  |
| Services | 33 |  |
|  | $ | 117 |  |


## msi:RetirementBenefitsPolicyPolicyTextBlock

[0000068505-16-000017:notes:32]
Retirement Benefits:    The Company records annual expenses relating to its pension benefit and postretirement plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s consolidated balance sheets using a December 31 measurement date.


## msi:SalesAndUseTaxesPolicyTextBlock

[0000068505-16-000017:notes:33]
Sales and Use Taxes:     The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes, on a net basis with such taxes excluded from revenue.


## msi:ScheduleOfAccumulatedBenefitObligationsForPlansTableTextBlock

[0000068505-16-000017:notes:34]
The accumulated benefit obligations for the plans were as follows:

[0000068505-16-000017:notes:35]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |
| December 31 | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Accumulated benefit obligation | $ | 4,304 |  |  | $ | 4,536 |  |  | $ | 1,809 |  |  | $ | 2,059 |  |


## msi:ScheduleOfCorporateRelatedExpensesAndAssetsTableTextBlock

[0000068505-16-000017:notes:36]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Products | $ | 76 |  |  | $ | 87 |  |  | $ | 90 |  |  | $ | 82 |  |  | $ | 94 |  |  | $ | 93 |  |
| Services | 99 |  |  | 94 |  |  | 79 |  |  | 60 |  |  | 75 |  |  | 64 |  |
|  | $ | 175 |  |  | $ | 181 |  |  | $ | 169 |  |  | $ | 142 |  |  | $ | 169 |  |  | $ | 157 |  |


## msi:ScheduleOfDefinedBenefitPlanTargetandActualAssetAllocationTableTextBlock

[0000068505-16-000017:notes:37]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-16-000017:notes:38]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 37 | % |  | 41 | % |  | 36 | % |  | 37 | % |
| Fixed income securities | 45 | % |  | 44 | % |  | 42 | % |  | 42 | % |
| Cash and other investments | 18 | % |  | 15 | % |  | 22 | % |  | 21 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 37 | % |  | 43 | % |  | 37 | % |  | 20 | % |
| Fixed income securities | 44 | % |  | 44 | % |  | 41 | % |  | 20 | % |
| Cash and other investments | 19 | % |  | 13 | % |  | 22 | % |  | 60 | % |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-16-000017:notes:39]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-16-000017:notes:40]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 9 |  |  | $ | 10 |  |  | $ | 16 |  |
| Selling, general and administrative expenses | 52 |  |  | 61 |  |  | 73 |  |
| Research and development expenditures | 17 |  |  | 23 |  |  | 31 |  |
| Share-based compensation expense included in Operating earnings | 78 |  |  | 94 |  |  | 120 |  |
| Tax benefit | 24 |  |  | 30 |  |  | 37 |  |
| Share-based compensation expense, net of tax | $ | 54 |  |  | $ | 64 |  |  | $ | 83 |  |
| Decrease in basic earnings per share | $ | (0.25 | ) |  | $ | (0.28 | ) |  | $ | (0.31 | ) |
| Decrease in diluted earnings per share | $ | (0.25 | ) |  | $ | (0.28 | ) |  | $ | (0.31 | ) |
| Share-based compensation expense in discontinued operations | $ | — |  |  | $ | 20 |  |  | $ | 33 |  |


## msi:ScheduleOfExpectedFutureServiceBenefitPaymentsTableTextBlock

[0000068505-16-000017:notes:41]
The following benefit payments are expected to be paid:

[0000068505-16-000017:notes:42]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2016 | $ | 94 |  |  | $ | 47 |  |  | $ | 19 |  |
| 2017 | 108 |  |  | 46 |  |  | 18 |  |
| 2018 | 124 |  |  | 52 |  |  | 17 |  |
| 2019 | 141 |  |  | 55 |  |  | 16 |  |
| 2020 | 162 |  |  | 62 |  |  | 15 |  |
| 2021-2025 | 1,128 |  |  | 376 |  |  | 63 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-16-000017:notes:43]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-16-000017:notes:44]
|  | 2015 |  | 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 89 |  |  | $ | 60 |  |  | $ | 77 |  |  | $ | 54 |  |
| Services | 22 |  |  | 2 |  |  | — |  |  | — |  |
|  | $ | 111 |  |  | $ | 62 |  |  | $ | 77 |  |  | $ | 54 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-16-000017:notes:45]
Other liabilities consist of the following:

[0000068505-16-000017:notes:46]
| December 31 | 2015 |  | 2014 |
| Defined benefit plans | $ | 1,512 |  |  | $ | 1,611 |  |
| Postretirement health care benefit plan | 49 |  |  | 49 |  |
| Deferred revenue | 113 |  |  | 139 |  |
| Unrecognized tax benefits | 50 |  |  | 54 |  |
| Other | 180 |  |  | 158 |  |
|  | $ | 1,904 |  |  | $ | 2,011 |  |


## msi:ScheduleOfPensionAndPostretirementHealthCarePlanAssetsTextBlockTableTextBlock

[0000068505-16-000017:notes:47]
Non-U.S. Pension Benefit Plans

[0000068505-16-000017:notes:48]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Commingled equity funds | — |  |  | 293 |  |  | 293 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 811 |  |  | 811 |  |
| Commingled bond funds | — |  |  | 56 |  |  | 56 |  |
| Commingled short-term investment funds | — |  |  | 7 |  |  | 7 |  |
| Total investment securities | $ | 21 |  |  | $ | 1,167 |  |  | $ | 1,188 |  |
| Cash |  |  |  |  | 457 |  |
| Accrued income receivable |  |  |  |  | 2 |  |
| Insurance contracts |  |  |  |  | 49 |  |
| Fair value plan assets |  |  |  |  | $ | 1,696 |  |

[0000068505-16-000017:notes:49]
The table above includes no securities on loan as part of a securities lending arrangement.

[0000068505-16-000017:notes:50]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 194 |  |  | $ | — |  |  | $ | 194 |  |
| Commingled equity funds | — |  |  | 569 |  |  | 569 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 26 |  |  | 26 |  |
| Corporate bonds | — |  |  | 316 |  |  | 316 |  |
| Commingled bond funds | — |  |  | 399 |  |  | 399 |  |
| Commingled short-term investment funds | — |  |  | 9 |  |  | 9 |  |
| Total investment securities | $ | 194 |  |  | $ | 1,319 |  |  | $ | 1,513 |  |
| Cash |  |  |  |  | 233 |  |
| Accrued income receivable |  |  |  |  | 5 |  |
| Insurance contracts |  |  |  |  | 55 |  |
| Fair value plan assets |  |  |  |  | $ | 1,806 |  |

[0000068505-16-000017:notes:51]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2015 and 2014 were as follows:

[0000068505-16-000017:notes:52]
U.S. Pension Benefit Plans

[0000068505-16-000017:notes:53]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 89 |  |  | $ | — |  |  | $ | 89 |  |
| Commingled equity funds | — |  |  | 1,541 |  |  | 1,541 |  |
| Preferred stock | 2 |  |  | — |  |  | 2 |  |
| Government, agency and government-sponsored enterprise obligations | — |  |  | 120 |  |  | 120 |  |
| Other government bonds | — |  |  | 70 |  |  | 70 |  |
| Corporate bonds | — |  |  | 862 |  |  | 862 |  |
| Mortgage-backed bonds | — |  |  | 2 |  |  | 2 |  |
| Commingled short-term investment funds | — |  |  | 435 |  |  | 435 |  |
| Total investment securities | $ | 91 |  |  | $ | 3,030 |  |  | $ | 3,121 |  |
| Accrued income receivable |  |  |  |  | 9 |  |
| Fair value plan assets |  |  |  |  | $ | 3,130 |  |

[0000068505-16-000017:notes:54]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 902 |  |  | $ | — |  |  | $ | 902 |  |
| Commingled equity funds | — |  |  | 565 |  |  | 565 |  |
| Preferred stock | 3 |  |  | — |  |  | 3 |  |
| Government, agency and government-sponsored enterprise obligations | — |  |  | 520 |  |  | 520 |  |
| Other government bonds | — |  |  | 91 |  |  | 91 |  |
| Corporate bonds | — |  |  | 795 |  |  | 795 |  |
| Mortgage-backed bonds | — |  |  | 16 |  |  | 16 |  |
| Commingled short-term investment funds | — |  |  | 422 |  |  | 422 |  |
| Total investment securities | $ | 905 |  |  | $ | 2,409 |  |  | $ | 3,314 |  |
| Accrued income receivable |  |  |  |  | 3 |  |
| Fair value plan assets |  |  |  |  | $ | 3,317 |  |

[0000068505-16-000017:notes:55]
Postretirement Health Care Benefits Plan

[0000068505-16-000017:notes:56]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Commingled equity funds | — |  |  | 71 |  |  | 71 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 5 |  |  | 5 |  |
| Other government bonds | — |  |  | 3 |  |  | 3 |  |
| Corporate bonds | — |  |  | 40 |  |  | 40 |  |
| Commingled short-term investment funds | — |  |  | 14 |  |  | 14 |  |
| Invested cash | — |  |  | 6 |  |  | 6 |  |
| Fair value plan assets | $ | 4 |  |  | $ | 139 |  |  | $ | 143 |  |

[0000068505-16-000017:notes:57]
| December 31, 2014 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Commingled equity funds | — |  |  | 13 |  |  | 13 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 11 |  |  | 11 |  |
| Other government bonds | — |  |  | 2 |  |  | 2 |  |
| Corporate bonds | — |  |  | 18 |  |  | 18 |  |
| Commingled short-term investment funds | — |  |  | 99 |  |  | 99 |  |
| Fair value plan assets | $ | 20 |  |  | $ | 143 |  |  | $ | 163 |  |


## msi:ScheduleOfStatusOfCompanyPensionPlansTableTextBlock

[0000068505-16-000017:notes:58]
The status of the Company’s plans is as follows:

[0000068505-16-000017:notes:59]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 4,536 |  |  | $ | 7,317 |  |  | $ | 2,075 |  |  | $ | 1,904 |  |  | $ | 212 |  |  | $ | 278 |  |
| Service cost | — |  |  | — |  |  | 12 |  |  | 15 |  |  | 1 |  |  | 2 |  |
| Interest cost | 193 |  |  | 370 |  |  | 66 |  |  | 80 |  |  | 8 |  |  | 10 |  |
| Plan amendments | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | (41 | ) |
| Settlements/curtailments | — |  |  | (4,227 | ) |  | (5 | ) |  | — |  |  | — |  |  | — |  |
| Actuarial loss (gain) | (319 | ) |  | 1,357 |  |  | (151 | ) |  | 263 |  |  | (12 | ) |  | (14 | ) |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (123 | ) |  | (146 | ) |  | — |  |  | — |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Benefit payments | (106 | ) |  | (281 | ) |  | (62 | ) |  | (43 | ) |  | (17 | ) |  | (23 | ) |
| Benefit obligation at December 31 | 4,304 |  |  | 4,536 |  |  | 1,815 |  |  | 2,075 |  |  | 192 |  |  | 212 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | 3,317 |  |  | 6,071 |  |  | 1,806 |  |  | 1,513 |  |  | 163 |  |  | 161 |  |
| Return on plan assets | (84 | ) |  | 642 |  |  | 33 |  |  | 191 |  |  | (6 | ) |  | 21 |  |
| Company contributions | 3 |  |  | 1,112 |  |  | 10 |  |  | 237 |  |  | — |  |  | — |  |
| Settlements | — |  |  | (3,196 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (93 | ) |  | (96 | ) |  | — |  |  | — |  |
| Lump sum settlements | — |  |  | (1,031 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Benefit payments | (106 | ) |  | (281 | ) |  | (62 | ) |  | (41 | ) |  | (14 | ) |  | (19 | ) |
| Fair value at December 31 | 3,130 |  |  | 3,317 |  |  | 1,696 |  |  | 1,806 |  |  | 143 |  |  | 163 |  |
| Funded status of the plan | (1,174 | ) |  | (1,219 | ) |  | (119 | ) |  | (269 | ) |  | (49 | ) |  | (49 | ) |
| Unrecognized net loss | 1,777 |  |  | 1,846 |  |  | 453 |  |  | 593 |  |  | 104 |  |  | 109 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (35 | ) |  | (24 | ) |  | (83 | ) |
| Prepaid (accrued) pension cost | $ | 603 |  |  | $ | 627 |  |  | $ | 334 |  |  | $ | 289 |  |  | $ | 31 |  |  | $ | (23 | ) |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Non-current benefit liability | $ | (1,174 | ) |  | $ | (1,219 | ) |  | $ | (119 | ) |  | $ | (269 | ) |  | $ | (49 | ) |  | $ | (49 | ) |
| Deferred income taxes | 657 |  |  | 701 |  |  | 46 |  |  | 51 |  |  | 31 |  |  | 10 |  |
| Accumulated other comprehensive loss | 1,120 |  |  | 1,145 |  |  | 407 |  |  | 507 |  |  | 49 |  |  | 16 |  |
| Prepaid (accrued) pension cost | $ | 603 |  |  | $ | 627 |  |  | $ | 334 |  |  | $ | 289 |  |  | $ | 31 |  |  | $ | (23 | ) |


## msi:ScheduleOfSummaryOfOpenTaxYearsByMajorJurisdictionTableTextBlock

[0000068505-16-000017:notes:60]
A summary of open tax years by major jurisdiction is presented below:

[0000068505-16-000017:notes:61]
| Jurisdiction | Tax Years |
| United States | 2008-2015 |
| China | 2002-2015 |
| France | 2010-2015 |
| Germany | 2008-2015 |
| India | 1997-2015 |
| Israel | 2012-2015 |
| Japan | 2011-2015 |
| Malaysia | 2010-2015 |
| Singapore | 2013-2015 |
| United Kingdom | 2008-2015 |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineBenefitObligationsForPlansTableTextBlock

[0000068505-16-000017:notes:62]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-16-000017:notes:63]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Discount rate | 4.73 | % |  | 4.30 | % |  | 3.57 | % |  | 3.19 | % |  | 4.26 | % |  | 3.90 | % |
| Future compensation increase rate | n/a |  |  | n/a |  |  | 0.41 | % |  | 2.54 | % |  | n/a |  |  | n/a |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineCostsForPlansTableTextBlock

[0000068505-16-000017:notes:64]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-16-000017:notes:65]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Discount rate | 4.30 | % |  | 5.15 | % |  | 3.19 | % |  | 4.24 | % |  | 3.90 | % |  | 4.65 | % |
| Investment return assumption | 7.00 | % |  | 7.00 | % |  | 5.90 | % |  | 5.92 | % |  | 7.00 | % |  | 7.00 | % |


## msi:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanEmployeeStockOptionsValuationAssumptionsTableTextBlock

[0000068505-16-000017:notes:66]
The fair value of performance options, MSUs, and PCSOs granted during 2015 was $17.42, $60.37, and $3.97, respectively, using the following assumptions:

[0000068505-16-000017:notes:67]
|  | Performance Options |  | Market Stock Units |  | PCSOs |
| Expected volatility of common stock | 21.0 | % |  | 19.3 | % |  | 26.0 | % |
| Expected volatility of the S&P 500 | 23.3 | % |  | n/a |  |  | n/a |  |
| Risk-free interest rate | 1.8 | % |  | 1.1 | % |  | 1.5 | % |
| Dividend yield | 2.9 | % |  | 2.9 | % |  | 3.1 | % |
| Expected life (years) | 6.5 |  |  | n/a |  |  | 5 |  |


## msi:ShareBasedCompensationCostsPolicyTextBlock

[0000068505-16-000017:notes:68]
Share-Based Compensation Costs:    The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period.


## msi:ValuationAndQualifyingAccountsTableTextBlock

[0000068505-16-000017:notes:69]
The following table presents the valuation and qualifying account activity for the years ended December 31, 2015, 2014, and 2013:

[0000068505-16-000017:notes:70]
|  | Balance atJanuary 1 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31 |
| 2015 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 35 |  |  | $ | 9 |  |  | $ | (17 | ) |  | $ | 1 |  |  | $ | 28 |  |
| Inventory reserves | 131 |  |  | 24 |  |  | (13 | ) |  | — |  |  | 142 |  |
| 2014 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 53 |  |  | 19 |  |  | (35 | ) |  | (2 | ) |  | 35 |  |
| Inventory reserves | 125 |  |  | 24 |  |  | (15 | ) |  | (3 | ) |  | 131 |  |
| 2013 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 50 |  |  | 13 |  |  | (8 | ) |  | (2 | ) |  | 53 |  |
| Inventory reserves | 112 |  |  | 25 |  |  | (14 | ) |  | 2 |  |  | 125 |  |

[0000068505-16-000017:notes:71]
* Adjustments include translation adjustments


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-16-000017:notes:72]
Other Financial Data

[0000068505-16-000017:notes:73]
Statement of Operations Information

[0000068505-16-000017:notes:74]
Other Charges (Income)

[0000068505-16-000017:notes:75]
Other Income (Expense)

[0000068505-16-000017:notes:76]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-16-000017:notes:77]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (186 | ) |  | $ | (147 | ) |  | $ | (132 | ) |
| Interest income | 13 |  |  | 21 |  |  | 19 |  |
|  | $ | (173 | ) |  | $ | (126 | ) |  | $ | (113 | ) |
| Other: |  |  |  |  |  |
| Loss from the extinguishment of long-term debt | $ | — |  |  | $ | (37 | ) |  | $ | — |  |
| Investment impairments | (6 | ) |  | — |  |  | (3 | ) |
| Foreign currency loss | (23 | ) |  | (3 | ) |  | (17 | ) |
| Gain (loss) on derivative instruments | 7 |  |  | (4 | ) |  | 8 |  |
| Gains on equity method investments | 6 |  |  | 16 |  |  | 10 |  |
| Other | 5 |  |  | (6 | ) |  | 11 |  |
|  | $ | (11 | ) |  | $ | (34 | ) |  | $ | 9 |  |

[0000068505-16-000017:notes:78]
Earnings Per Common Share

[0000068505-16-000017:notes:79]
Basic and diluted earnings per common share from both continuing operations and net earnings attributable to Motorola Solutions, Inc. is computed as follows:

[0000068505-16-000017:notes:80]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings (loss) from Continuing Operations |  | Net Earnings |
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | 640 |  |  | $ | (697 | ) |  | $ | 933 |  |  | $ | 610 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |
| Weighted average common shares outstanding | 199.6 |  |  | 245.6 |  |  | 266.0 |  |  | 199.6 |  |  | 245.6 |  |  | 266.0 |  |
| Per share amount | $ | 3.21 |  |  | $ | (2.84 | ) |  | $ | 3.51 |  |  | $ | 3.06 |  |  | $ | 5.29 |  |  | $ | 4.13 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | 640 |  |  | $ | (697 | ) |  | $ | 933 |  |  | $ | 610 |  |  | $ | 1,299 |  |  | $ | 1,099 |  |
| Weighted average common shares outstanding | 199.6 |  |  | 245.6 |  |  | 266.0 |  |  | 199.6 |  |  | 245.6 |  |  | 266.0 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards | 2.1 |  |  | — |  |  | 4.5 |  |  | 2.1 |  |  | — |  |  | 4.5 |  |
| Senior Convertible Notes | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 201.8 |  |  | 245.6 |  |  | 270.5 |  |  | 201.8 |  |  | 245.6 |  |  | 270.5 |  |
| Per share amount | $ | 3.17 |  |  | $ | (2.84 | ) |  | $ | 3.45 |  |  | $ | 3.02 |  |  | $ | 5.29 |  |  | $ | 4.06 |  |

[0000068505-16-000017:notes:81]
In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2015, the assumed exercise of 2.7 million options and the assumed vesting of 0.3 million RSUs were excluded because their inclusion would have been antidilutive. For the year ended December 31, 2014, the Company recorded a net loss from continuing operations and, accordingly, the basic and diluted weighted average shares outstanding are equal because any increase to the basic shares would be antidilutive, including the assumed exercise of 6.3 million stock options and the assumed vesting of 1.1 million RSUs. In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2013, the assumed exercise of 5.6 million stock options and the assumed vesting of 0.2 million RSUs were excluded because their inclusion would have been antidilutive.

[0000068505-16-000017:notes:82]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes (the "Senior Convertible Notes") which mature in September 2020. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). See discussion in Note 4. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-16-000017:notes:83]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the year ended December 31, 2015, the dilutive impact of the Senior Convertible Notes was 67 thousand shares.

[0000068505-16-000017:notes:84]
Balance Sheet Information

[0000068505-16-000017:notes:85]
Cash and Cash Equivalents

[0000068505-16-000017:notes:86]
The Company’s cash and cash equivalents were $2.0 billion at December 31, 2015 and $4.0 billion at December 31, 2014. Of these amounts, $63 million was restricted at both December 31, 2015 and December 31, 2014.

[0000068505-16-000017:notes:87]
Accounts Receivable, Net

[0000068505-16-000017:notes:88]
Accounts receivable, net, consist of the following:

[0000068505-16-000017:notes:89]
| December 31 | 2015 |  | 2014 |
| Accounts receivable | $ | 1,390 |  |  | $ | 1,444 |  |
| Less allowance for doubtful accounts | (28 | ) |  | (35 | ) |
|  | $ | 1,362 |  |  | $ | 1,409 |  |

[0000068505-16-000017:notes:90]
Inventories, Net

[0000068505-16-000017:notes:91]
Inventories, net, consist of the following:

[0000068505-16-000017:notes:92]
| December 31 | 2015 |  | 2014 |
| Finished goods | $ | 151 |  |  | $ | 163 |  |
| Work-in-process and production materials | 287 |  |  | 313 |  |
|  | 438 |  |  | 476 |  |
| Less inventory reserves | (142 | ) |  | (131 | ) |
|  | $ | 296 |  |  | $ | 345 |  |

[0000068505-16-000017:notes:93]
Other Current Assets

[0000068505-16-000017:notes:94]
Other current assets consist of the following:

[0000068505-16-000017:notes:95]
| December 31 | 2015 |  | 2014 |
| Available-for-sale securities | $ | 401 |  |  | $ | — |  |
| Costs and earnings in excess of billings | 374 |  |  | 417 |  |
| Tax-related refunds receivable | 44 |  |  | 103 |  |
| Zebra receivable for cash transferred | — |  |  | 49 |  |
| Other | 98 |  |  | 171 |  |
|  | $ | 917 |  |  | $ | 740 |  |

[0000068505-16-000017:notes:96]
In conjunction with the sale of the Enterprise business to Zebra, the Company transfered legal entities which maintained cash balances. During the year ended December 31, 2015, approximately $49 million of transferred cash balances were reimbursed by Zebra in accordance with the sales agreement.

[0000068505-16-000017:notes:97]
Property, Plant and Equipment, Net

[0000068505-16-000017:notes:98]
Property, plant and equipment, net, consist of the following:

[0000068505-16-000017:notes:99]
| December 31 | 2015 |  | 2014 |
| Land | $ | 17 |  |  | $ | 18 |  |
| Building | 523 |  |  | 559 |  |
| Machinery and equipment | 1,585 |  |  | 1,672 |  |
|  | 2,125 |  |  | 2,249 |  |
| Less accumulated depreciation | (1,638 | ) |  | (1,700 | ) |
|  | $ | 487 |  |  | $ | 549 |  |

[0000068505-16-000017:notes:100]
Depreciation expense for the years ended December 31, 2015, 2014, and 2013 was $142 million, $169 million and $157 million, respectively.

[0000068505-16-000017:notes:101]
During the year ended December 31, 2015, the Company entered into an arrangement to sell its Penang, Malaysia manufacturing operations, including the land, building, equipment, inventory, and employees to a contract manufacturer. During the year ended December 31, 2015, the Company recognized an impairment loss of $6 million on the building within Other charges in its consolidated statements of operations, and presented the assets as held for sale in its consolidated balance sheets. The sale of the Penang, Malaysia facility and manufacturing operations was completed on February 1, 2016.

[0000068505-16-000017:notes:102]
During the year ended December 31, 2015, the Company entered into an agreement to broker the sale of its corporate aircraft. During the year ended December 31, 2015, the Company recognized an impairment loss of $31 million within Other charges based on the indicated market value of the aircraft and presented the aircraft as held for sale in its consolidated balance sheets.

[0000068505-16-000017:notes:103]
Investments

[0000068505-16-000017:notes:104]
Gains on sales of investments, net for the years ended December 31, 2015, 2014, and 2013 were $107 million, $5 million, and $37 million, respectively. During the years ended December 31, 2015 and December 31, 2013, the Company recorded investment impairment charges of $6 million and $3 million, respectively, representing other-than-temporary declines in the value of the Company’s equity investment portfolio. There were no investment impairments recorded during the year ended December 31, 2014. Investment impairment charges are included in Other within Other income (expense) in the Company’s consolidated statements of operations.

[0000068505-16-000017:notes:105]
Other Assets

[0000068505-16-000017:notes:106]
Other assets consist of the following:

[0000068505-16-000017:notes:107]
| December 31 | 2015 |  | 2014 |
| Intangible assets | $ | 49 |  |  | $ | 23 |  |
| Long-term receivables | 47 |  |  | 31 |  |
| Defined benefit plan assets | 128 |  |  | — |  |
| Other | 88 |  |  | 91 |  |
|  | $ | 312 |  |  | $ | 145 |  |

[0000068505-16-000017:notes:108]
Defined benefit plan assets at December 31, 2015 included the overfunded status of the United Kingdom pension plan of $105 million, compared to a net liability position in previous periods.

[0000068505-16-000017:notes:109]
Accrued Liabilities

[0000068505-16-000017:notes:110]
Accrued liabilities consist of the following:

[0000068505-16-000017:notes:111]
| December 31 | 2015 |  | 2014 |
| Deferred revenue | $ | 390 |  |  | $ | 355 |  |
| Compensation | 241 |  |  | 190 |  |
| Billings in excess of costs and earnings | 337 |  |  | 358 |  |
| Tax liabilities | 48 |  |  | 91 |  |
| Dividend payable | 71 |  |  | 75 |  |
| Trade liabilities | 135 |  |  | 131 |  |
| Other | 449 |  |  | 506 |  |
|  | $ | 1,671 |  |  | $ | 1,706 |  |

[0000068505-16-000017:notes:112]
Other Liabilities

[0000068505-16-000017:notes:113]
Stockholders’ Equity Information

[0000068505-16-000017:notes:114]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, and November 3, 2014, the Board of Directors has authorized the Company to repurchase in the aggregate up to $12.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date.

[0000068505-16-000017:notes:115]
On August 4, 2015, the Board of Directors authorized the Company to commence a modified "Dutch auction" tender offer to repurchase up to $2.0 billion of its outstanding shares of common stock. The repurchase of these shares was authorized under the existing share repurchase authority, as outlined above. The tender offer commenced on August 7, 2015 and expired on September 3, 2015. The Company paid $2.0 billion, including transaction costs, to repurchase approximately 30.1 million shares at a tender price of $66.50 per share.

[0000068505-16-000017:notes:116]
During 2015, the Company paid an aggregate of $3.2 billion (including the Dutch auction tender offer), including transaction costs, to repurchase 48.0 million shares at an average price of $66.22 per share. During 2014, the Company paid an aggregate of $2.5 billion, including transaction costs, to repurchase 39.4 million shares at an average price of $64.63. During 2013, the Company paid an aggregate of $1.7 billion, including transaction costs, to repurchase 28.6 million shares at an average price of $59.30. As of December 31, 2015, the Company had used approximately $11.0 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $1.0 billion of authority available for future repurchases.

[0000068505-16-000017:notes:117]
Payment of Dividends:  On November 17, 2015, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.34 per share to $0.41 per share of common stock.  During the years ended December 31, 2015, 2014, and 2013 the Company paid $277 million, $318 million, and $292 million, respectively, in cash dividends to holders of its common stock.

[0000068505-16-000017:notes:118]
Accumulated Other Comprehensive Loss

[0000068505-16-000017:notes:119]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the consolidated statements of operations during the years ended December 31, 2015, 2014, and 2013:

[0000068505-16-000017:notes:120]
|  | Years ended December 31 |
|  | 2015 |  | 2014 |  | 2013 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (204 | ) |  | $ | (96 | ) |  | $ | (92 | ) |
| Other comprehensive loss before reclassification adjustment | (82 | ) |  | (58 | ) |  | (11 | ) |
| Tax benefit | 20 |  |  | 9 |  |  | 7 |  |
| Other comprehensive income before reclassification adjustment, net of tax | (62 | ) |  | (49 | ) |  | (4 | ) |
| Reclassification adjustment into Earnings from discontinued operations | — |  |  | (75 | ) |  | — |  |
| Tax expense | — |  |  | 16 |  |  | — |  |
| Reclassification adjustment into Earnings from discontinued operations, net of tax | — |  |  | (59 | ) |  | — |  |
| Other comprehensive loss, net of tax | (62 | ) |  | (108 | ) |  | (4 | ) |
| Balance at end of period | $ | (266 | ) |  | $ | (204 | ) |  | $ | (96 | ) |
| Derivative instruments: |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | (1 | ) |  | $ | 1 |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | — |  |
| Tax expense | — |  |  | — |  |  | (1 | ) |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | (1 | ) |
| Reclassification adjustment into Cost of sales | — |  |  | 1 |  |  | (1 | ) |
| Tax expense | — |  |  | — |  |  | — |  |
| Reclassification adjustment into Cost of sales, net of tax | — |  |  | 1 |  |  | (1 | ) |
| Other comprehensive income, net of tax | — |  |  | 1 |  |  | (2 | ) |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |
| Balance at beginning of period | $ | 44 |  |  | $ | (2 | ) |  | $ | 2 |  |
| Other comprehensive income before reclassification adjustment | (15 | ) |  | 72 |  |  | 1 |  |
| Tax benefit (expense) | 5 |  |  | (26 | ) |  | (2 | ) |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (10 | ) |  | 46 |  |  | (1 | ) |
| Reclassification adjustment into Gains on sales of investments and businesses, net | (61 | ) |  | — |  |  | (4 | ) |
| Tax expense | 24 |  |  | — |  |  | 1 |  |
| Reclassification adjustment into Gains on sales of investments and businesses, net of tax | (37 | ) |  | — |  |  | (3 | ) |
| Other comprehensive income, net of tax | (47 | ) |  | 46 |  |  | (4 | ) |
| Balance at end of period | $ | (3 | ) |  | $ | 44 |  |  | $ | (2 | ) |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | (1,695 | ) |  | (2,188 | ) |  | (3,211 | ) |
| Other comprehensive income (loss) before reclassification adjustment | 108 |  |  | (1,165 | ) |  | 1,524 |  |
| Tax benefit (expense) | 12 |  |  | 447 |  |  | (571 | ) |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 120 |  |  | (718 | ) |  | 953 |  |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 71 |  |  | 118 |  |  | 159 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (62 | ) |  | (57 | ) |  | (49 | ) |
| Reclassification adjustment - Other charges | — |  |  | 1,883 |  |  | — |  |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Selling, general, and administrative expenses | (32 | ) |  | — |  |  | — |  |
| Disposition of the Enterprise business retirement benefits | — |  |  | (1 | ) |  | — |  |
| Tax expense (benefit) | 1 |  |  | (732 | ) |  | (40 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | (22 | ) |  | 1,211 |  |  | 70 |  |
| Other comprehensive income, net of tax | 98 |  |  | 493 |  |  | 1,023 |  |
| Balance at end of period | $ | (1,597 | ) |  | $ | (1,695 | ) |  | $ | (2,188 | ) |
| Total Accumulated other comprehensive loss | $ | (1,866 | ) |  | $ | (1,855 | ) |  | $ | (2,287 | ) |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000068505-16-000017:notes:121]
Cash Equivalents:    The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-16-000017:notes:122]
Commitments and Contingencies

[0000068505-16-000017:notes:123]
Lease Obligations

[0000068505-16-000017:notes:124]
The Company leases certain office, factory and warehouse space, land, and information technology and other equipment under principally non-cancelable operating leases. Rental expense, net of sublease income, for the years ended December 31, 2015, 2014 and 2013 was $42 million, $62 million, and $51 million, respectively.

[0000068505-16-000017:notes:125]
At December 31, 2015, future minimum lease obligations, net of minimum sublease rentals, for the next five years and beyond are as follows:

[0000068505-16-000017:notes:126]
| (in millions) | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Beyond |  |
|  | $ | 67 |  | $ | 57 |  | $ | 48 |  | $ | 42 |  | $ | 37 |  | $ | 233 |  |

[0000068505-16-000017:notes:127]
Purchase Obligations

[0000068505-16-000017:notes:128]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. As of December 31, 2015, the Company had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2017. The Company expects to make total payments of $73 million under these arrangements as follows: $57 million in 2016, $14 million in 2017, and $2 million in 2018.

[0000068505-16-000017:notes:129]
The Company outsources certain corporate functions, such as benefit administration and information technology related services, under various contracts, the longest of which is expected to expire in 2019. The remaining payments under these contracts are approximately $246 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-16-000017:notes:130]
Legal

[0000068505-16-000017:notes:131]
The Company is a defendant in various lawsuits, claims, and actions that arise in the normal course of business. While the outcome of these matters is currently not determinable, the Company does not expect the ultimate disposition of these matters to have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations.

[0000068505-16-000017:notes:132]
Indemnifications

[0000068505-16-000017:notes:133]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third-parties for certain payments made by the Company.

[0000068505-16-000017:notes:134]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. The Company had no pending claims at December 31, 2015.

[0000068505-16-000017:notes:135]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.


## us-gaap:ConsolidationPolicyTextBlock

[0000068505-16-000017:notes:136]
Principles of Consolidation:    The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-16-000017:notes:137]
The consolidated financial statements as of December 31, 2015 and 2014 and for the years ended December 31, 2015, 2014 and 2013, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.


## us-gaap:DebtDisclosureTextBlock

[0000068505-16-000017:notes:138]
Debt and Credit Facilities

[0000068505-16-000017:notes:139]
Long-Term Debt

[0000068505-16-000017:notes:140]
| December 31 | 2015 |  | 2014 |
| 2% Senior Convertible Notes due 2020 | 993 |  |  | — |  |
| 3.5% senior notes due 2021 | 396 |  |  | 395 |  |
| 3.75% senior notes due 2022 | 748 |  |  | 748 |  |
| 3.5% senior notes due 2023 | 595 |  |  | 594 |  |
| 4.0% senior notes due 2024 | 590 |  |  | 589 |  |
| 6.5% debentures due 2025 | 118 |  |  | 118 |  |
| 7.5% debentures due 2025 | 346 |  |  | 346 |  |
| 6.5% debentures due 2028 | 36 |  |  | 36 |  |
| 6.625% senior notes due 2037 | 54 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 400 |  |  | 400 |  |
| 5.22% debentures due 2097 | 91 |  |  | 91 |  |
| Other long-term debt | 29 |  |  | 36 |  |
|  | 4,396 |  |  | 3,407 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (6 | ) |  | (7 | ) |
| Less: current portion | (4 | ) |  | (4 | ) |
| Long-term debt | $ | 4,386 |  |  | $ | 3,396 |  |

[0000068505-16-000017:notes:141]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). The value by which the Senior Convertible Notes exceeded their principal amount if converted as of December 31, 2015 was $21 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-16-000017:notes:142]
The Company has recorded a debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. As of December 31, 2015, the remaining unamortized debt discount was $7 million, which will be amortized over two years as a component of interest expense. For the year ended December 31, 2015, total interest expense relating to both the contractual interest coupon and amortization of debt discount was $8 million. The total of proceeds received in excess of the fair value of the debt liability of $8 million has been recorded within Additional paid-in capital.

[0000068505-16-000017:notes:143]
During the year ended December 31, 2014, the Company redeemed $400 million aggregate principal amount outstanding of its 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, the Company recognized a loss of $37 million related to the redemption within Other income (expense) in the consolidated statement of operations. During the year ended December 31, 2014, the Company issued an aggregate principal amount of $1.4 billion consisting of: (i) $600 million of 4.000% Senior Notes due 2024, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior Notes due 2021, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior Notes due 2044, of which, after debt issuance costs and debt discounts, the Company recognized net proceeds of $394 million.

[0000068505-16-000017:notes:144]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2016—$4 million; 2017—$5 million; 2018—$5 million; 2019—$5 million; and 2020—$1 billion.

[0000068505-16-000017:notes:145]
In connection with the completion of the acquisition of Airwave, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a term loan (the “Term Loan”) with an initial principal amount of $675 million. Interest on the Term Loan is variable and indexed to LIBOR. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. The Company's borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited at the end of the first quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan.

[0000068505-16-000017:notes:146]
Credit Facilities

[0000068505-16-000017:notes:147]
As of December 31, 2015, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2015. The Company did not borrow under the 2014 Motorola Solutions Credit Agreement during the twelve months ended December 31, 2015.

[0000068505-16-000017:notes:148]
As of December 31, 2015, the Company had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of December 31, 2015.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-16-000017:notes:149]
Risk Management

[0000068505-16-000017:notes:150]
Foreign Currency Risk

[0000068505-16-000017:notes:151]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure. Instruments that are designated as part of a hedging relationship must be effective at reducing the risk associated with the exposure being hedged and are designated as part of a hedging relationship at the inception of the contract. Accordingly, changes in the market values of hedge instruments must be highly correlated with changes in market values of the underlying hedged items both at the inception of the hedge and over the life of the hedge contract.

[0000068505-16-000017:notes:152]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows or investments based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-16-000017:notes:153]
At December 31, 2015, the Company had outstanding foreign exchange contracts totaling $494 million, compared to $628 million outstanding at December 31, 2014. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-16-000017:notes:154]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2015 and the corresponding positions as of December 31, 2014:

[0000068505-16-000017:notes:155]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2015 |  | 2014 |
| Chinese Renminbi | $ | (114 | ) |  | $ | (161 | ) |
| Euro | 99 |  |  | 214 |  |
| British Pound | 62 |  |  | 34 |  |
| Australian Dollar | (60 | ) |  | (42 | ) |
| Brazilian Real | (44 | ) |  | (28 | ) |

[0000068505-16-000017:notes:156]
Interest Rate Risk

[0000068505-16-000017:notes:157]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, the changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s consolidated statements of operations. The fair value of the interest rate swaps was a liability position of $1 million at December 31, 2015 and a liability position of $2 million at December 31, 2014.

[0000068505-16-000017:notes:158]
Counterparty Risk

[0000068505-16-000017:notes:159]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of nonperformance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2015, all of the counterparties have investment grade credit ratings. As of December 31, 2015, the Company was exposed to an aggregate credit risk of approximately $6 million with all counterparties.

[0000068505-16-000017:notes:160]
Derivative Financial Instruments

[0000068505-16-000017:notes:161]
The following tables summarize the fair values and location in the consolidated balance sheets of all derivative financial instruments held by the Company at December 31, 2015 and 2014:

[0000068505-16-000017:notes:162]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 6 |  |  | Other assets |  | 2 |  |  | Accrued liabilities |
| Interest agreements | — |  |  | Other assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | 6 |  |  |  |  | $ | 3 |  |  |  |

[0000068505-16-000017:notes:163]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2014 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | 1 |  |  | Other assets |  | 5 |  |  | Accrued liabilities |
| Interest agreements | — |  |  | Other assets |  | 2 |  |  | Accrued liabilities |
| Total derivatives not designated as hedging instruments | 1 |  |  |  |  | 7 |  |  |  |

[0000068505-16-000017:notes:164]
The following table summarizes the effect of derivative instruments in the Company's consolidated statements of operations, including immaterial amounts related to discontinued operations, for the years ended December 31, 2015, 2014 and 2013:

[0000068505-16-000017:notes:165]
|  | December 31 | Statement ofOperations Location |
| Gain (Loss) on Derivative Instruments | 2015 |  | 2014 |  | 2013 |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |
| Interest rate contracts | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  | Other income (expense) |
| Foreign exchange contracts | 6 |  |  | (5 | ) |  | 6 |  | Other income (expense) |
| Total derivatives not designated as hedging instruments | $ | 7 |  |  | $ | (4 | ) |  | $ | 8 |  |  |

[0000068505-16-000017:notes:166]
The Company had no instruments designated as hedging instruments for the year ended December 31, 2015.


## us-gaap:DerivativesPolicyTextBlock

[0000068505-16-000017:notes:167]
Derivative Instruments:    Gains and losses on hedges of existing assets or liabilities are marked-to-market and the result is included in Other within Other income (expense) within the Company’s consolidated statements of operations. Certain financial instruments are used to hedge firm future commitments or forecasted transactions.  Gains and losses pertaining to those instruments that qualify for hedge accounting are deferred until such time as the underlying transactions are recognized and subsequently recognized in the same line within the consolidated statements of operations as the hedged item. Gains and losses pertaining to those instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the consolidated statements of operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-16-000017:notes:168]
Share-Based Compensation Plans and Other Incentive Plans

[0000068505-16-000017:notes:169]
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees, including executives, and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option granted and stock appreciation right has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to four years. Stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights in conjunction with a change in control of the Company only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-16-000017:notes:170]
Restricted stock (“RS”) and restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to employees, including executives, and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. Shares of RS and RSUs assumed or replaced with comparable shares of RS or RSUs in conjunction with a change in control will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-16-000017:notes:171]
On March 9, 2015 the Compensation and Leadership Committee of the Board of Directors granted performance-based stock options (“performance options”) and market stock units ("MSUs") to the Company’s executive officers. Performance options have a three year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted in 2015 are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three year performance period based on a payout factor that corresponds to actual TSR results as established for 2015. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years.

[0000068505-16-000017:notes:172]
On August 24, 2015, in conjunction with the issuance of the Senior Convertible Notes, the Company approved a grant of performance-contingent stock options (“PCSOs”) to certain executive officers. The total number of PCSOs granted is designed to represent approximately 1% of the fully-diluted equity of the Company. The PCSOs vest upon satisfaction of the following stock price hurdles which must be maintained for 10-consecutive trading days during the three-year period following the grant date: 20% of the total award will vest at an $85 stock price; an additional 30% of the total award will vest at a $102.50 stock price; and the final 50% of the total award will vest at a $120 stock price. If any stock price hurdles are not met during the three-year period, the corresponding portion of the options will not vest and will be forfeited. The awards have a seven-year term and a per share exercise price of $68.50.

[0000068505-16-000017:notes:173]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2015, 2014 and 2013, employees purchased 1.0 million, 1.4 million and 1.5 million shares, respectively, at purchase prices of $52.99 and $56.67, $51.76 and $53.79, and $43.02 and $50.47, respectively.

[0000068505-16-000017:notes:174]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-16-000017:notes:175]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2015, 2014 and 2013 was $10.21, $11.02 and $9.52, respectively, using the following weighted-average assumptions:

[0000068505-16-000017:notes:176]
|  | 2015 |  | 2014 |  | 2013 |
| Expected volatility | 20.0 | % |  | 21.7 | % |  | 22.1 | % |
| Risk-free interest rate | 1.6 | % |  | 1.6 | % |  | 0.9 | % |
| Dividend yield | 2.9 | % |  | 2.5 | % |  | 2.4 | % |
| Expected life (years) | 6.0 |  |  | 5.2 |  |  | 5.9 |  |

[0000068505-16-000017:notes:177]
The Company calculates the value of each performance option, MSU, and PCSO using the Monte Carlo Simulation, estimated on the date of grant. The fair value of performance options, MSUs, and PCSOs granted during 2015 was $17.42, $60.37, and $3.97, respectively, using the following assumptions:

[0000068505-16-000017:notes:178]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, MSUs, and PCSOs. The selection of the implied volatility approach was based upon the availability of actively traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. The Company uses the historical volatility as the expected volatility assumption in the valuation of performance options in order to calculate the correlation coefficients between the S&P 500 and the Company's stock, which can only be calculated using historical data.

[0000068505-16-000017:notes:179]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted-average vesting period for all option tranches.

[0000068505-16-000017:notes:180]
The Company has applied forfeiture rates, estimated based on historical data, of 10%-50% to the stock option fair values calculated by the Black-Scholes option pricing model. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-16-000017:notes:181]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, including performance options and PCSOs, at December 31, 2015 (in thousands, except exercise price and years):

[0000068505-16-000017:notes:182]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| Under $30 | 551 |  |  | $ | 27 |  |  | 4 |  | 551 |  |  | $ | 27 |  |  | 4 |
| $30-$40 | 2,047 |  |  | 39 |  |  | 4 |  | 2,047 |  |  | 39 |  |  | 4 |
| $41-$50 | 106 |  |  | 45 |  |  | 5 |  | 106 |  |  | 45 |  |  | 5 |
| $51-$60 | 1,482 |  |  | 55 |  |  | 7 |  | 1,119 |  |  | 54 |  |  | 7 |
| $61-$70 | 3,593 |  |  | 67 |  |  | 9 |  | 213 |  |  | 65 |  |  | 8 |
| $71-$80 | 165 |  |  | 74 |  |  | 2 |  | 158 |  |  | 74 |  |  | 1 |
| $81 and over | 127 |  |  | 89 |  |  | 0 |  | 127 |  |  | 89 |  |  | 0 |
|  | 8,071 |  |  |  |  |  |  | 4,321 |  |  |  |  |  |

[0000068505-16-000017:notes:183]
As of December 31, 2015, the weighted average contractual life for options outstanding and exercisable was 7 and 5 years, respectively.

[0000068505-16-000017:notes:184]
Current Year Activity

[0000068505-16-000017:notes:185]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-16-000017:notes:186]
|  | Stock Options |  | Performance Options* |  | Restricted Stock Units |  | Market Stock Units |
| Shares in Thousands | Number of Options Outstanding |  | Weighted Average Exercise Price of Shares |  | Number of Options Outstanding |  | Weighted Average Exercise Price of Shares |  | Number of Non-Vested Awards |  | Weighted Average Grant Date Fair Value |  | Number of Non-Vested Awards |  | Weighted Average Grant Date Fair Value |
| Balance as of January 1, 2015 | 9,684 |  |  | $ | 85 |  |  | — |  |  | $ | — |  |  | 1,753 |  |  | $ | 58 |  |  | — |  |  | $ | — |  |
| Granted | 550 |  |  | 66 |  |  | 2,042 |  |  | 68 |  |  | 797 |  |  | 62 |  |  | 84 |  |  | 60 |  |
| Releases/Exercised | (892 | ) |  | 47 |  |  | — |  |  | — |  |  | (885 | ) |  | 53 |  |  | — |  |  | — |  |
| Adjustments for actual payouts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Forfeited/Canceled | (3,313 | ) |  | 155 |  |  | — |  |  | — |  |  | (149 | ) |  | 60 |  |  | — |  |  | — |  |
| Balance as of December 31, 2015 | 6,029 |  |  | $ | 51 |  |  | 2,042 |  |  | $ | 68 |  |  | 1,516 |  |  | $ | 59 |  |  | 84 |  |  | $ | 60 |  |
| Vested or expected to vest | 4,604 |  |  | 46 |  |  | — |  |  | — |  |  | 885 |  |  | 53 |  |  | — |  |  | — |  |

[0000068505-16-000017:notes:187]
* Inclusive of PCSO awards

[0000068505-16-000017:notes:188]
At December 31, 2015 and 2014, 12.0 million and 19.7 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-16-000017:notes:189]
Total Share-Based Compensation Expense

[0000068505-16-000017:notes:190]
At December 31, 2015, the Company had unrecognized compensation expense related to RS, RSUs, and MSUs of $60 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately two years. The total fair value of RS and RSU shares vested during the years ended December 31, 2015, 2014, and 2013 was $55 million, $160 million, and $138 million, respectively. The aggregate fair value of outstanding RS, RSUs, and MSUs as of December 31, 2015 was $95 million.

[0000068505-16-000017:notes:191]
At December 31, 2015, the Company had $20 million of total unrecognized compensation expense, net of estimated forfeitures, related to stock option plans that will be recognized over the weighted average period of approximately two years, and $4 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. Cash received from stock option exercises and the employee stock purchase plan was $100 million, $135 million, and $165 million for the years ended December 31, 2015, 2014, and 2013, respectively. The total intrinsic value of options exercised during the years ended December 31, 2015, 2014, and 2013 was $15 million, $38 million, and $85 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2015 was $110 million and $102 million, respectively, based on a December 31, 2015 stock price of $68.45 per share.

[0000068505-16-000017:notes:192]
Motorola Solutions Incentive Plans

[0000068505-16-000017:notes:193]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2015, 2014 and 2013 was $119 million, $53 million and $87 million, respectively.

[0000068505-16-000017:notes:194]
Long-Range Incentive Plan

[0000068505-16-000017:notes:195]
The Long-Range Incentive Plan (“LRIP”) rewards participating elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three year period. The expense for LRIP for the years ended December 31, 2015, 2014 and 2013 was $12 million, $3 million and $4 million, respectively.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-16-000017:notes:196]
Discontinued Operations

[0000068505-16-000017:notes:197]
On October 27, 2014, the Company completed the sale of its Enterprise business to Zebra Technologies Corporation ("Zebra") for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by the Company, including the Company’s iDEN business. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-16-000017:notes:198]
The following table displays summarized activity in the Company’s consolidated statements of operations for discontinued operations during the years ended December 31, 2015, 2014, and 2013.

[0000068505-16-000017:notes:199]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Net sales | $ | — |  |  | $ | 1,904 |  |  | $ | 2,469 |  |
| Operating earnings | — |  |  | 203 |  |  | 268 |  |
| Gains (losses) on sales of investments and businesses, net | (24) |  |  | 1,888 |  |  | 3 |  |
| Earnings (loss) before income taxes | (24 | ) |  | 2,074 |  |  | 266 |  |
| Income tax expense | 6 |  |  | 78 |  |  | 100 |  |
| Earnings (loss) from discontinued operations, net of tax | (30 | ) |  | 1,996 |  |  | 166 |  |

[0000068505-16-000017:notes:200]
During the year ended December 31, 2015, the Company recorded adjustments to the gain on the sale of the Enterprise business, including additional tax expense on the sale of the Enterprise business to reflect actual amounts filed in the income tax return. During the year ended December 31, 2015, the Company also settled the working capital true-up with Zebra for $12 million.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000068505-16-000017:notes:201]
Earnings Per Share:    The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for earnings (loss) from continuing operations and net earnings attributable to Motorola Solutions, Inc. for all periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-16-000017:notes:202]
Fair Value Measurements

[0000068505-16-000017:notes:203]
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements on a recurring basis. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date.  Fair value is measured using the fair value hierarchy and related valuation methodologies as defined in the authoritative literature. This guidance specifies a hierarchy of valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies as they pertain to the Company are as follows:

[0000068505-16-000017:notes:204]
Level 1—Quoted prices for identical instruments in active markets.

[0000068505-16-000017:notes:205]
Level 2—Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-16-000017:notes:206]
Level 3—Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-16-000017:notes:207]
Investments and Derivatives

[0000068505-16-000017:notes:208]
There were no significant transfers between Level 1 and Level 2 during 2015 or 2014.

[0000068505-16-000017:notes:209]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-16-000017:notes:210]
The table above includes securities on loan as part of a securities lending arrangement of $16 million of common stock and equivalents, and $12 million of corporate bonds. All securities on loan were fully collateralized.

[0000068505-16-000017:notes:211]
At December 31, 2015, the Company had $1.3 billion of investments in money market funds (Level 2) classified as Cash and cash equivalents in its consolidated balance sheet, compared to $3.3 billion at December 31, 2014. The money market funds had quoted market prices that are equivalent to par.

[0000068505-16-000017:notes:212]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2015 was $4.1 billion (Level 2), compared to a face value of $4.4 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-16-000017:notes:213]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000068505-16-000017:notes:214]
Foreign Currency:    Certain of the Company’s non-U.S. operations use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive loss in the Company’s consolidated balance sheets. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-16-000017:notes:215]
Intangible Assets and Goodwill

[0000068505-16-000017:notes:216]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition. The pro forma effects of the acquisitions completed in 2015, 2014, and 2013 were not significant individually or in the aggregate. The Company did not have any significant acquisitions during the years ended December 31, 2015, 2014, and 2013.

[0000068505-16-000017:notes:217]
Intangible Assets

[0000068505-16-000017:notes:218]
Amortized intangible assets are comprised of the following:

[0000068505-16-000017:notes:219]
|  | 2015 |  | 2014 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 60 |  |  | $ | 32 |  |  | $ | 37 |  |  | $ | 27 |  |
| Patents | 8 |  |  | 5 |  |  | 8 |  |  | 4 |  |
| Customer-related | 23 |  |  | 10 |  |  | 15 |  |  | 8 |  |
| Other intangibles | 20 |  |  | 15 |  |  | 17 |  |  | 15 |  |
|  | $ | 111 |  |  | $ | 62 |  |  | $ | 77 |  |  | $ | 54 |  |

[0000068505-16-000017:notes:220]
Amortization expense on intangible assets, which is included within Other charges in the consolidated statements of operations, was $8 million, $4 million, and $1 million for the years ended December 31, 2015, 2014, and 2013, respectively.  As of December 31, 2015, future amortization expense is estimated to be $9 million in 2016 and 2017, $8 million in 2018, and $7 million in 2019, and $4 million in 2020.

[0000068505-16-000017:notes:221]
Goodwill

[0000068505-16-000017:notes:222]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2014 to December 31, 2015:

[0000068505-16-000017:notes:223]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2014 |  |  |  |  |  |
| Aggregate goodwill acquired | $ | 249 |  |  | $ | 112 |  |  | $ | 361 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | 249 |  |  | 112 |  |  | 361 |  |
| Goodwill acquired | 15 |  |  | 7 |  |  | 22 |  |
| Balance as of December 31, 2014 |  |  |  |  |  |
| Aggregate goodwill acquired/disposed | 264 |  |  | 119 |  |  | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | 264 |  |  | 119 |  |  | 383 |  |
| Goodwill acquired | 6 |  |  | 31 |  |  | 37 |  |
| Balance as of December 31, 2015 |  |  |  |  |  |
| Aggregate goodwill acquired | 270 |  |  | 150 |  |  | 420 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |

[0000068505-16-000017:notes:224]
On December 31, 2013, the Company completed the acquisition of a communication software provider in push-to-talk-over-broadband applications for a gross purchase price of $48 million. As a result of the acquisition, the Company recognized $22 million of goodwill and $20 million of identifiable intangible assets in 2014 when the purchase accounting was completed.

[0000068505-16-000017:notes:225]
On November 18, 2014, the Company completed the acquisition of an equipment provider for a purchase price of $22 million. During the nine months ended October 3, 2015, the Company completed the purchase accounting for this acquisition, recognizing $6 million of goodwill and $12 million of identifiable intangible assets. These identifiable intangible assets were classified as completed technology to be amortized over five years.

[0000068505-16-000017:notes:226]
During the year ended December 31, 2015, the Company completed the acquisitions of two providers of public safety software-based solutions for an aggregate purchase price of $50 million, recognizing an additional $31 million of goodwill, $22 million of identifiable intangible assets, and $3 million of acquired liabilities related to these acquisitions. The $22 million of identifiable intangible assets were classified as: (i) $11 million completed technology, (ii) $8 million customer-related, and (iii) $3 million of other intangibles. These intangible assets will be amortized over periods ranging from five to ten years.

[0000068505-16-000017:notes:227]
The results of operations for these acquisitions have been included in the Company’s consolidated statements of operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-16-000017:notes:228]
On February 19, 2016, we completed the acquisition of 100% of the equity interest in Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. For the purposes of purchase accounting, the net purchase price was $1.1 billion, taking into account approximately $1 billion of net cash paid at closing and approximately $90 million of deferred consideration which will be due on November 15, 2018. The acquisition of Airwave enables the Company to grow revenue and geographically diversify its global Managed & Support services offerings within its Services segment, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. As of the date of issuance of the Company's financial statements, the purchase accounting has not been completed.

[0000068505-16-000017:notes:229]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment. The Company has determined that the Products segment and Services segment each meet the definition of a reporting unit.

[0000068505-16-000017:notes:230]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2015, 2014, and 2013. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2015, 2014, and 2013, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000068505-16-000017:notes:231]
Goodwill and Intangible Assets:    Goodwill is assessed for impairment at least annually at the reporting unit level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year.  The annual assessment is performed using the two-step goodwill test which may also include the optional qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount prior to performing the two-step goodwill impairment test.  If this is the case, the two-step goodwill impairment test is required. If it is more-likely-than-not that the fair value of a reporting unit is greater than its carrying amount, the two-step goodwill impairment test is not required.

[0000068505-16-000017:notes:232]
If the two-step goodwill impairment test is performed, first, the fair value of each reporting unit is compared to its book value. Second, if the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-16-000017:notes:233]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to ten years. The Company has no intangible assets with indefinite useful lives.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000068505-16-000017:notes:234]
Impairment of Long-Lived Assets:    Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparables. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-16-000017:notes:235]
Income Taxes

[0000068505-16-000017:notes:236]
Components of earnings (loss) from continuing operations before income taxes are as follows:

[0000068505-16-000017:notes:237]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| United States | $ | 725 |  |  | $ | (1,355 | ) |  | $ | 585 |  |
| Other nations | 192 |  |  | 194 |  |  | 295 |  |
|  | $ | 917 |  |  | $ | (1,161 | ) |  | $ | 880 |  |

[0000068505-16-000017:notes:238]
Components of income tax expense (benefit) are as follows:

[0000068505-16-000017:notes:239]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| United States | $ | 71 |  |  | $ | 14 |  |  | $ | 29 |  |
| Other nations | 30 |  |  | 67 |  |  | 234 |  |
| States (U.S.) | 13 |  |  | 11 |  |  | 12 |  |
| Current income tax expense | 114 |  |  | 92 |  |  | 275 |  |
| United States | 154 |  |  | (503 | ) |  | (368 | ) |
| Other nations | (13 | ) |  | (11 | ) |  | 35 |  |
| States (U.S.) | 19 |  |  | (43 | ) |  | (1 | ) |
| Deferred income tax expense (benefit) | 160 |  |  | (557 | ) |  | (334 | ) |
| Total income tax expense (benefit) | $ | 274 |  |  | $ | (465 | ) |  | $ | (59 | ) |

[0000068505-16-000017:notes:240]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s consolidated balance sheets resulted from retirement benefit adjustments, currency translation adjustments, net gains (losses) on derivative instruments and fair value adjustments to available-for-sale securities. The adjustments were $(62) million, $286 million, and $606 million for the years ended December 31, 2015, 2014, and 2013, respectively.

[0000068505-16-000017:notes:241]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. During the fourth quarter of 2015, the Company reassessed its unremitted earnings position and concluded that certain of its non-U.S. subsidiaries’ earnings were permanently reinvested overseas. The Company intends to utilize these offshore earnings for working capital needs in its international operations. During 2015, the Company recorded a net tax benefit of $8 million related to the reversal of related deferred tax liabilities. During 2014, the Company recorded a net tax benefit of $19 million related to the reversal of deferred tax liabilities related to undistributed foreign earnings due to the change in permanent reinvestment assertion. During 2013, the Company reassessed its unremitted earnings position concluding that certain of its non-U.S. subsidiaries' earnings were permanently reinvested overseas. As a result, the Company recognized a tax benefit of $25 million during 2013 for the reversal of related deferred tax liabilities.

[0000068505-16-000017:notes:242]
Undistributed earnings that the Company intends to reinvest indefinitely, and for which no U.S. income taxes have been provided, aggregate to $1.4 billion at December 31, 2015. The Company currently has no plans to repatriate the foreign earnings permanently reinvested and therefore, the time and manner of repatriation is uncertain. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary. However, given the uncertain repatriation time and manner at December 31, 2015, it is not practicable to estimate the amount of any additional income tax charge on the hypothetical distribution of permanently reinvested earnings. On a cash basis, these repatriations from the Company's non-U.S. subsidiaries could require the payment of additional taxes. The portion of earnings not reinvested indefinitely may be distributed without an additional charge given the U.S. federal and foreign income tax accrued on undistributed earnings and the utilization of available foreign tax credits.

[0000068505-16-000017:notes:243]
In 2013, the Company reorganized certain of its non-U.S. subsidiaries under a holding company structure in order to facilitate the efficient movement of non-U.S. cash and provide a platform to fund foreign investments, such as potential acquisitions and capital expenditures. During 2013, the Company recognized a $337 million tax benefit associated with the excess tax credits relating to the earnings of certain non-U.S. subsidiaries reorganized under the holding company structure.

[0000068505-16-000017:notes:244]
Differences between income tax expense (benefit) computed at the U.S. federal statutory tax rate of 35% and income tax expense (benefit) as reflected in the consolidated statements of operations are as follows:

[0000068505-16-000017:notes:245]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Income tax expense (benefit) at statutory rate | $ | 321 |  | 35.0 | % |  | $ | (406 | ) | 35.0 | % |  | $ | 308 |  | 35.0 | % |
| Tax on non-U.S. earnings | (46 | ) | (5.0 | )% |  | (27 | ) | 2.3 | % |  | 17 |  | 1.9 | % |
| State income taxes, net of federal benefit | 24 |  | 2.6 | % |  | (30 | ) | 2.6 | % |  | 8 |  | 0.9 | % |
| Recognition of previously unrecognized income tax benefits | 1 |  | 0.1 | % |  | (29 | ) | 2.5 | % |  | 6 |  | 0.7 | % |
| Other provisions | 14 |  | 1.6 | % |  | 9 |  | (0.7 | )% |  | (4 | ) | (0.5 | )% |
| Valuation allowances | (9 | ) | (1.0 | )% |  | 55 |  | (4.7 | )% |  | (3 | ) | (0.3 | )% |
| Section 199 deduction | (19 | ) | (2.1 | )% |  | (12 | ) | 1.0 | % |  | (14 | ) | (1.6 | )% |
| Tax on undistributed non-U.S. earnings | (7 | ) | (0.8 | )% |  | (19 | ) | 1.6 | % |  | (22 | ) | (2.5 | )% |
| Research credits | (5 | ) | (0.5 | )% |  | (6 | ) | 0.5 | % |  | (18 | ) | (2.0 | )% |
| Tax benefit of repatriated non-U.S. earnings | — |  | — | % |  | — |  | — | % |  | (337 | ) | (38.3 | )% |
|  | $ | 274 |  | 29.9 | % |  | $ | (465 | ) | 40.1 | % |  | $ | (59 | ) | (6.7 | )% |

[0000068505-16-000017:notes:246]
Gross deferred tax assets were $3.5 billion and $3.6 billion at December 31, 2015 and 2014, respectively. Deferred tax assets, net of valuation allowances, were $3.4 billion at both December 31, 2015 and 2014, respectively. Gross deferred tax liabilities were $1.2 billion and $774 million at December 31, 2015 and 2014, respectively.

[0000068505-16-000017:notes:247]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-16-000017:notes:248]
| December 31 | 2015 |  | 2014 |
| Inventory | $ | 30 |  |  | $ | 34 |  |
| Accrued liabilities and allowances | 136 |  |  | 148 |  |
| Employee benefits | 612 |  |  | 799 |  |
| Capitalized items | 357 |  |  | 379 |  |
| Tax basis differences on investments | 14 |  |  | (10 | ) |
| Depreciation tax basis differences on fixed assets | 19 |  |  | 52 |  |
| Undistributed non-U.S. earnings | (19 | ) |  | (18 | ) |
| Tax carryforwards | 1,028 |  |  | 1,246 |  |
| Business reorganization | 20 |  |  | 22 |  |
| Warranty and customer liabilities | 20 |  |  | 19 |  |
| Deferred revenue and costs | 146 |  |  | 136 |  |
| Valuation allowances | (129 | ) |  | (226 | ) |
| Deferred charges | 41 |  |  | 39 |  |
| Other | 3 |  |  | (38 | ) |
|  | $ | 2,278 |  |  | $ | 2,582 |  |

[0000068505-16-000017:notes:249]
At December 31, 2015 and 2014, the Company had valuation allowances of $129 million and $226 million, respectively, against its deferred tax assets, including $98 million and $195 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s valuation allowances for its non-U.S. subsidiaries had a net decrease of $97 million during 2015 and a net increase of $17 million during 2014. The decrease in the valuation allowance relating to deferred tax assets of non-U.S. subsidiaries during 2015 relates to the expiration of net operating losses, the release of a Singapore valuation allowance, and the change in the value of net deferreds related to pension in the United Kingdom. The increase in the valuation allowance relating to deferred tax assets of non-U.S. subsidiaries during 2014 related to deferred tax assets considered to be not more-likely-than-not to be realizable based on estimates of future taxable income.

[0000068505-16-000017:notes:250]
The Company’s U.S. valuation allowance did not change during 2015 compared to a net increase of $9 million during 2014. The U.S. valuation allowance of $31 million as of December 31, 2015 primarily relates to state tax carryforwards. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-16-000017:notes:251]
Tax carryforwards are as follows:

[0000068505-16-000017:notes:252]
| December 31, 2015 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | 66 |  |  | $ | 23 |  |  | 2022-2033 |
| Foreign tax credits | — |  |  | 584 |  |  | 2018-2025 |
| General business credits | — |  |  | 133 |  |  | 2026-2035 |
| Minimum tax credits | — |  |  | 100 |  |  | Unlimited |
| State tax losses | 1,221 |  |  | 33 |  |  | 2016-2031 |
| State tax credits | — |  |  | 28 |  |  | 2018-2029 |
| Non-U.S. Subsidiaries: |  |  |  |  |  |
| Japan tax losses | 91 |  |  | 30 |  |  | 2017-2021 |
| Germany tax losses | 86 |  |  | 25 |  |  | Unlimited |
| United Kingdom tax losses | 95 |  |  | 17 |  |  | Unlimited |
| Singapore tax losses | 40 |  |  | 7 |  |  | Unlimited |
| Other subsidiaries tax losses | 47 |  |  | 12 |  |  | Various |
| Spain tax credits | — |  |  | 24 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 12 |  |  | Various |
|  |  |  | $ | 1,028 |  |  |  |

[0000068505-16-000017:notes:253]
The Company had unrecognized tax benefits of $88 million and $96 million at December 31, 2015 and December 31, 2014, respectively, of which approximately $50 million and $76 million, respectively, if recognized, would affect the effective tax rate, net of resulting changes to valuation allowances.

[0000068505-16-000017:notes:254]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-16-000017:notes:255]
|  | 2015 |  | 2014 |
| Balance at January 1 | $ | 96 |  |  | $ | 147 |  |
| Additions based on tax positions related to current year | 2 |  |  | 4 |  |
| Additions for tax positions of prior years | 4 |  |  | 21 |  |
| Reductions for tax positions of prior years | (9 | ) |  | (55 | ) |
| Settlements and agreements | (3 | ) |  | (19 | ) |
| Lapse of statute of limitations | (2 | ) |  | (2 | ) |
| Balance at December 31 | $ | 88 |  |  | $ | 96 |  |

[0000068505-16-000017:notes:256]
The IRS is currently examining the Company's 2012 and 2013 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-16-000017:notes:257]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s consolidated financial position, liquidity, or results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-16-000017:notes:258]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $50 million tax charge to a $50 million tax benefit, with cash payments not to exceed $30 million.

[0000068505-16-000017:notes:259]
At December 31, 2015, the Company had $29 million accrued for interest and $24 million accrued for penalties on unrecognized tax benefits. At December 31, 2014, the Company had $26 million and $26 million accrued for interest and penalties, respectively, on unrecognized tax benefits.


## us-gaap:IncomeTaxPolicyTextBlock

[0000068505-16-000017:notes:260]
Income Taxes:    The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.


## us-gaap:InventoryPolicyTextBlock

[0000068505-16-000017:notes:261]
Inventories:    Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or market (net realizable value or replacement cost).


## us-gaap:InvestmentPolicyTextBlock

[0000068505-16-000017:notes:262]
Investments:    Investments in equity and debt securities classified as available-for-sale are carried at fair value.  When applicable, debt securities classified as held-to-maturity are carried at amortized cost. Equity securities that are restricted for more than one year or that are not publicly traded are carried at cost. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-16-000017:notes:263]
The Company assesses declines in the fair value of investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s consolidated statements of operations in the period in which they become impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-16-000017:notes:264]
Recent Accounting Pronouncements:  
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017. ASU 2014-09 allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-16-000017:notes:265]
In April 2015, the FASB issued ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, the Company will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of December 31, 2015, debt issuance costs, net of accumulated amortization, recognized in the consolidated balance sheet were $41 million.

[0000068505-16-000017:notes:266]
On November 20, 2015, the FASB issued ASU No. 2015-17, "Balance Sheet Classification of Deferred Taxes," which amends existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. The ASU will be effective for the Company beginning January 1, 2017, including interim periods in its fiscal year 2017, and allows for both retrospective and prospective methods of transition upon adoption. The Company has adopted the standard on a prospective basis as of December 31, 2015. Prior period amounts have not been adjusted to reflect this presentation. The standard reduces the complexity in the preparation of the income tax provision and simplifies the presentation of the deferred taxes in our consolidated balance sheet.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-16-000017:notes:267]
Retirement Benefits

[0000068505-16-000017:notes:268]
Pension and Postretirement Health Care Benefits Plans

[0000068505-16-000017:notes:269]
The Company’s noncontributory U.S. pension plan (the “Regular Pension Plan”) provides benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. In December 2008, the Company amended the Regular Pension Plan such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-16-000017:notes:270]
In September 2014, the Company entered into a Definitive Purchase Agreement (the “Agreement”) by and among the Company, The Prudential Insurance Company of America (“PICA”), Prudential Financial, Inc. and State Street Bank and Trust Company, as Independent Fiduciary of the Company’s Regular Pension Plan. Under the Agreement, the Regular Pension Plan purchased from PICA a group annuity contract that requires PICA to pay and administer certain future annuity payments to approximately 30,000 of the Company’s retirees. On December 3, 2014, the Company transfered $3.2 billion of plan assets to PICA upon the close of the Agreement and then subsequently terminated the plan. During 2014, the Company established a new pension plan with substantially the same terms as the Regular Pension Plan (the “New Plan”) to accommodate the Company's remaining active employees and non-retirees. Upon the establishment of the New Plan, the Company offered and paid out from plan assets the maximum of $1.0 billion of a lump-sum distribution to certain participants who had accrued a pension benefit, had left the Company prior to June 30, 2014, and had not yet started receiving pension benefit payments. As a result of the actions taken to the Plan, the Company recorded a settlement loss of $1.9 billion in 2014 which is recorded in "Other charges" within the statement of operations.

[0000068505-16-000017:notes:271]
The Company has an additional noncontributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan (“MSPP”), which provides supplemental benefits to individuals by replacing the Regular Pension Plan benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. Effective January 1, 2007, eligible compensation was capped at the IRS limit plus $175,000 (the “Cap”) or, for those already in excess of the Cap as of January 1, 2007, the eligible compensation used to compute such employee’s MSPP benefit for all future years is the greater of: (i) such employee’s eligible compensation as of January 1, 2007 (frozen at that amount) or (ii) the relevant Cap for the given year. Similar to the Regular Pension Plan, the Company amended the MSPP (collectively, the “U.S. Pension Benefit Plans”) in December 2008 such that effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit. Effective January 1, 2009, the MSPP was closed to new participants unless such participation was required under a prior contractual entitlement.

[0000068505-16-000017:notes:272]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants.

[0000068505-16-000017:notes:273]
During 2012, the Postretirement Health Care Benefits Plan was amended ("the Original Amendment") such that, as of January 1, 2013, retirees over the age of 65 are provided an annual subsidy to use toward the purchase of their own health care coverage from private insurance companies or for reimbursement of eligible health care expenses. The Original Amendment resulted in a remeasurement of the plan generating an $87 million decrease in accumulated other comprehensive loss, net of taxes. The majority of that $87 million decrease was recognized by the end of 2015.

[0000068505-16-000017:notes:274]
In September 2014, the Postretirement Health Care Benefits Plan was then further amended (“the New Amendment”) to provide the annual subsidy discussed as part of the Original Amendment to all participants under the plan effective March 1, 2015. Additionally, the New Amendment eliminated dental benefits that were previously provided under the plan. The New Amendment required a remeasurement, resulting in a $45 million decrease in accumulated other comprehensive loss, net of taxes.  A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the consolidated statements of operations over almost three years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.

[0000068505-16-000017:notes:275]
During the years ended December 31, 2015, 2014, and 2013, $59 million, $50 million, and $43 million of prior service cost credit, respectively, was recognized into the Company’s consolidated statements of operations for amendments to the Postretirement Health Care Benefits Plan.

[0000068505-16-000017:notes:276]
Non U.S. Pension Benefit Plans

[0000068505-16-000017:notes:277]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the United Kingdom and Germany (the “Non U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-16-000017:notes:278]
In June 2015, the Company amended its Non-US defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.  As a result, the Company recorded a curtailment gain of $32 million to “Other Charges” within the consolidated statement of operations during 2015.

[0000068505-16-000017:notes:279]
Net Periodic Cost (Benefit)

[0000068505-16-000017:notes:280]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-16-000017:notes:281]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |  | $ | 15 |  |  | $ | 11 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 193 |  |  | 370 |  |  | 352 |  |  | 66 |  |  | 80 |  |  | 69 |  |  | 8 |  |  | 10 |  |  | 11 |  |
| Expected return on plan assets | (212 | ) |  | (381 | ) |  | (364 | ) |  | (103 | ) |  | (90 | ) |  | (77 | ) |  | (9 | ) |  | (10 | ) |  | (10 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 46 |  |  | 97 |  |  | 130 |  |  | 17 |  |  | 12 |  |  | 13 |  |  | 8 |  |  | 9 |  |  | 14 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (3 | ) |  | (7 | ) |  | (6 | ) |  | (59 | ) |  | (50 | ) |  | (43 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement/loss | — |  |  | 1,883 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic pension cost (benefit) | $ | 27 |  |  | $ | 1,969 |  |  | $ | 118 |  |  | $ | (43 | ) |  | $ | 10 |  |  | $ | 10 |  |  | $ | (51 | ) |  | $ | (39 | ) |  | $ | (26 | ) |

[0000068505-16-000017:notes:282]
The net funded status of the of the Non U.S. Pension Benefit Plans primarily reflects a net underfunded status of $224 million related to Germany and a net overfunded status of $105 million related to the United Kingdom as of December 31, 2015.

[0000068505-16-000017:notes:283]
The benefit obligation and plan assets for the Company's plans are measured as of December 31, 2015. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-16-000017:notes:284]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from eleven to thirty-five years. Prior service costs are amortized over periods ranging from two to nine years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-16-000017:notes:285]
The net periodic cost for 2016 will include amortization of the unrecognized net loss and prior service costs for the U.S. Pension Benefit Plans and Non U.S. Pension Benefit Plans, currently included in Accumulated other comprehensive loss, of $38 million and $11 million, respectively. It is estimated that the 2016 net periodic expense for the Postretirement Health Care Benefits Plan will include amortization of a net credit of $16 million, comprised of the unrecognized prior service gain and unrecognized actuarial loss, currently included in Accumulated other comprehensive loss.

[0000068505-16-000017:notes:286]
Actuarial Assumptions

[0000068505-16-000017:notes:287]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-16-000017:notes:288]
In 2014, the Society of Actuaries ("SOA") released the “RP-2014 White Collar” mortality table which was utilized in calculating the 2014 projected benefit obligation. During 2015, the SOA issued an update, Mortality Improvement Scale MP-2015, which includes two additional years of mortality data and was utilized to calculate the 2015 projected benefit obligation.

[0000068505-16-000017:notes:289]
Effective on January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, accordingly, will account for it prospectively beginning in 2016.

[0000068505-16-000017:notes:290]
Investment Policy

[0000068505-16-000017:notes:291]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to, equity and fixed income securities, cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-16-000017:notes:292]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. Treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-16-000017:notes:293]
Cash Funding

[0000068505-16-000017:notes:294]
The Company made $3 million of contributions to its U.S. Pension Benefit Plans during 2015, compared to $1.1 billion contributed in 2014. The Company contributed $10 million to its Non U.S. Pension Benefit Plans during 2015, compared to $237 million contributed in 2014. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2015 or 2014.

[0000068505-16-000017:notes:295]
Expected Future Benefit Payments

[0000068505-16-000017:notes:296]
Other Benefit Plans

[0000068505-16-000017:notes:297]
Split-Dollar Life Insurance Arrangements

[0000068505-16-000017:notes:298]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a plan that was frozen prior to December 31, 2004. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-16-000017:notes:299]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2015, 2014 and 2013. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $63 million and $66 million as of December 31, 2015 and December 31, 2014, respectively.

[0000068505-16-000017:notes:300]
Deferred Compensation Plan

[0000068505-16-000017:notes:301]
The Company amended and reinstated its deferred compensation plan (“the Plan”) effective June 1, 2013 to reopen the Plan to certain participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the Board of Directors.

[0000068505-16-000017:notes:302]
Defined Contribution Plan

[0000068505-16-000017:notes:303]
The Company and certain subsidiaries have various defined contribution plans, in which all eligible employees may participate. In the U.S., the 401(k) plan is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2015, 2014 and 2013 were $28 million, $31 million and $32 million, respectively.

[0000068505-16-000017:notes:304]
Under the 401(k) plan, the Company may make an additional discretionary 401(k) plan matching contribution to eligible employees. For the years ended December 31, 2015, 2014, and 2013 the Company made no discretionary matching contributions.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000068505-16-000017:notes:305]
Property, Plant and Equipment:    Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (buildings and building equipment, five to forty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-16-000017:notes:306]
Quarterly and Other Financial Data (unaudited)

[0000068505-16-000017:notes:307]
|  | 2015 |  | 2014 |
|  | 1st |  | 2nd |  | 3rd |  | 4th |  | 1st |  | 2nd |  | 3rd |  | 4th |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,223 |  |  | $ | 1,368 |  |  | $ | 1,422 |  |  | $ | 1,682 |  |  | $ | 1,228 |  |  | $ | 1,393 |  |  | $ | 1,436 |  |  | $ | 1,824 |  |
| Costs of sales | 675 |  |  | 720 |  |  | 737 |  |  | 844 |  |  | 651 |  |  | 737 |  |  | 751 |  |  | 911 |  |
| Gross margin | 548 |  |  | 648 |  |  | 685 |  |  | 838 |  |  | 577 |  |  | 656 |  |  | 685 |  |  | 913 |  |
| Selling, general and administrative expenses | 256 |  |  | 254 |  |  | 259 |  |  | 252 |  |  | 307 |  |  | 308 |  |  | 287 |  |  | 282 |  |
| Research and development expenditures | 159 |  |  | 156 |  |  | 153 |  |  | 152 |  |  | 174 |  |  | 176 |  |  | 166 |  |  | 165 |  |
| Other charges | 14 |  |  | (16 | ) |  | 42 |  |  | 44 |  |  | (11 | ) |  | 34 |  |  | 25 |  |  | 1,924 |  |
| Operating earnings (loss) | 119 |  |  | 254 |  |  | 231 |  |  | 390 |  |  | 107 |  |  | 138 |  |  | 207 |  |  | (1,458 | ) |
| Earnings (loss) from continuing operations* | 87 |  |  | 150 |  |  | 126 |  |  | 277 |  |  | 85 |  |  | 78 |  |  | 66 |  |  | (926 | ) |
| Net earnings* | 74 |  |  | 142 |  |  | 115 |  |  | 279 |  |  | 127 |  |  | 824 |  |  | 147 |  |  | 201 |  |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from Continuing operations*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per common share | $ | 0.40 |  |  | $ | 0.72 |  |  | $ | 0.63 |  |  | $ | 1.58 |  |  | $ | 0.33 |  |  | $ | 0.31 |  |  | $ | 0.27 |  |  | $ | (4.02 | ) |
| Diluted earnings (loss) per common share | 0.40 |  |  | 0.72 |  |  | 0.63 |  |  | 1.56 |  |  | 0.33 |  |  | 0.30 |  |  | 0.27 |  |  | (4.02 | ) |
| Net earnings*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 0.34 |  |  | $ | 0.68 |  |  | $ | 0.58 |  |  | $ | 1.60 |  |  | $ | 0.50 |  |  | $ | 3.25 |  |  | $ | 0.60 |  |  | $ | 0.87 |  |
| Diluted earnings per common share | 0.34 |  |  | 0.68 |  |  | 0.57 |  |  | 1.57 |  |  | 0.49 |  |  | 3.22 |  |  | 0.59 |  |  | 0.87 |  |
| Dividends declared | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.41 |  |  | $ | 0.31 |  |  | $ | 0.31 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |
| Dividends paid | 0.34 |  |  | 0.34 |  |  | 0.34 |  |  | 0.34 |  |  | 0.31 |  |  | 0.31 |  |  | 0.31 |  |  | 0.34 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 70.00 |  |  | $ | 62.53 |  |  | $ | 69.61 |  |  | $ | 72.45 |  |  | $ | 67.11 |  |  | $ | 67.80 |  |  | $ | 67.41 |  |  | $ | 67.87 |  |
| Low | $ | 62.41 |  |  | $ | 57.14 |  |  | $ | 56.79 |  |  | $ | 65.24 |  |  | $ | 62.72 |  |  | $ | 62.50 |  |  | $ | 58.89 |  |  | $ | 58.50 |  |

[0000068505-16-000017:notes:308]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.


## us-gaap:ReceivablesPolicyTextBlock

[0000068505-16-000017:notes:309]
Long-term Receivables:    Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under a workout or restructuring for four consecutive quarters.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-16-000017:notes:310]
Reorganization of Businesses

[0000068505-16-000017:notes:311]
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits.  In addition to the Involuntary Severance Plan, during the year ended December 31, 2013, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States.  Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally capped at six months of salary, were capped at a full year’s salary.

[0000068505-16-000017:notes:312]
The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the consolidated statements of operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-16-000017:notes:313]
During 2015, 2014, and 2013 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. Both of the Company’s segments were impacted by these plans. The employees affected were located in all geographic regions.

[0000068505-16-000017:notes:314]
2015 Charges

[0000068505-16-000017:notes:315]
During 2015, the Company recorded net reorganization of business charges of $117 million, including $9 million of charges in Costs of sales and $108 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the $117 million were charges of: (i) $74 million for employee separation costs, (ii) $31 million for the impairment of the corporate aircraft, (iii) $10 million for exit costs, and (iv) a $6 million building impairment charge, partially offset by $4 million of reversals of accruals no longer needed.

[0000068505-16-000017:notes:316]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2015 to December 31, 2015:

[0000068505-16-000017:notes:317]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 9 |  |
| Employee separation costs | 57 |  |  | 74 |  |  | (10 | ) |  | (70 | ) |  | 51 |  |
|  | $ | 57 |  |  | $ | 84 |  |  | $ | (10 | ) |  | $ | (71 | ) |  | $ | 60 |  |

[0000068505-16-000017:notes:318]
Exit Costs

[0000068505-16-000017:notes:319]
At January 1, 2015, the Company had no accrual for exit costs attributable to lease terminations. There were $10 million of additional charges in 2015. The $1 million used in 2015 reflects cash payments. The remaining accrual of $9 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2015, represented future cash payments, primarily for lease termination obligations.

[0000068505-16-000017:notes:320]
Employee Separation Costs

[0000068505-16-000017:notes:321]
At January 1, 2015, the Company had an accrual of $57 million for employee separation costs. The 2015 additional charges of $74 million represent severance costs for approximately an additional 1,100 employees, of which 200 were direct employees and 900 were indirect employees. The adjustments of $10 million reflect $4 million of reversals of accruals no longer needed and $6 million of reversals of accruals held for employees separated from discontinued operations. The $70 million used in 2015 reflects cash payments to severed employees. The remaining accrual of $51 million, which is included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2015, is expected to be paid, generally, within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 300 employees to be separated in 2016.

[0000068505-16-000017:notes:322]
2014 Charges

[0000068505-16-000017:notes:323]
During 2014, the Company recorded net reorganization of business charges of $73 million, including $9 million of charges in Costs of sales and $64 million of charges under Other charges in the Company’s consolidated statements of operations. Included in the aggregate $73 million are charges of (i) $67 million for employee separation costs, and (ii) $7 million of charges for exit costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-16-000017:notes:324]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2014 to December 31, 2014:

[0000068505-16-000017:notes:325]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 6 |  |  | $ | 7 |  |  | $ | — |  |  | $ | (13 | ) |  | $ | — |  |
| Employee separation costs | 103 |  |  | 93 |  |  | (4 | ) |  | (135 | ) |  | 57 |  |
|  | $ | 109 |  |  | $ | 100 |  |  | $ | (4 | ) |  | $ | (148 | ) |  | $ | 57 |  |

[0000068505-16-000017:notes:326]
At January 1, 2014, the Company had an accrual of $6 million for exit costs attributable to lease terminations. There were $7 million of additional charges in 2014. The $13 million used in 2014 reflects cash payments. There was no remaining accrual as of December 31, 2014.

[0000068505-16-000017:notes:327]
At January 1, 2014, the Company had an accrual of $103 million for employee separation costs. The additional 2014 charges of $93 million represent severance costs for approximately an additional 1,200 employees, of which 300 were direct employees and 900 were indirect employees. The adjustments of $4 million reflect reversals of accruals no longer needed. The $135 million used in 2014 reflects cash payments to these separated employees, including $50 million related to employees of the Enterprise business and included in cash flow from discontinued operations. The remaining accrual of $57 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2014.

[0000068505-16-000017:notes:328]
2013 Charges

[0000068505-16-000017:notes:329]
The Company recorded net reorganization of business charges of $86 million, including $16 million of charges in Costs of sales and $70 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the aggregate $86 million are charges of (i) $94 million for employee separation costs and (ii) $2 million of charges for exit costs, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-16-000017:notes:330]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2013 to December 31, 2013:

[0000068505-16-000017:notes:331]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 4 |  |  | $ | 3 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 6 |  |
| Employee separation costs | 31 |  |  | 146 |  |  | (16 | ) |  | (58 | ) |  | 103 |  |
|  | $ | 35 |  |  | $ | 149 |  |  | $ | (16 | ) |  | $ | (59 | ) |  | $ | 109 |  |

[0000068505-16-000017:notes:332]
At January 1, 2013, the Company had an accrual of $4 million for exit costs attributable to lease terminations. There were $3 million of additional charges in 2013. The $1 million used in 2013 reflects cash payments. The remaining accrual of $6 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2013, represented future cash payments, primarily for lease termination obligations.

[0000068505-16-000017:notes:333]
At January 1, 2013, the Company had an accrual of $31 million for employee separation costs, representing the severance costs for approximately 400 employees. The additional 2013 charges of $146 million represent severance costs for approximately an additional 2,200 employees, of which 800 were direct employees and 1,400 were indirect employees. The adjustments of $16 million reflect accruals no longer required. The $58 million used in 2013 reflects cash payments to these separated employees, including $20 million related to employees of the Enterprise business and included in cash flow from discontinued operations. The remaining accrual of $103 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2013.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000068505-16-000017:notes:334]
Revenue Recognition:   Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its products and services due to the needs of its customers. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. The Company recognizes revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  The Company recognizes revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) stand alone sales of software products or software upgrades, (ii) stand alone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-16-000017:notes:335]
Products

[0000068505-16-000017:notes:336]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. The Company bases its estimates of these allowances on historical experience taking into consideration the type of products sold, the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, the Company defers revenue until the incentive has been finalized with the customer.  The Company includes shipping charges billed to customers in net revenue, and includes the related shipping costs in cost of sales.

[0000068505-16-000017:notes:337]
The Company sells software and equipment obtained from other companies.  The Company establishes its own pricing and retains related inventory risk, is the primary obligor in sales transactions with customers, and assumes the credit risk for amounts billed to customers. Accordingly, the Company generally recognizes revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-16-000017:notes:338]
Long-Term Contracts

[0000068505-16-000017:notes:339]
For long-term contracts that involve customization of equipment and/or software, the Company generally recognizes revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). The components of estimated costs to complete a contract and management’s process for reviewing Estimated Costs at Completion and progress toward completion are discussed further below.  Contracts may be combined or segmented in accordance with the applicable criteria under contract accounting principles.  In certain instances, when revenues or costs associated with long-term contracts cannot be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained.

[0000068505-16-000017:notes:340]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs.  Due to the nature of the work required to be performed under many of the Company’s long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables.  The Company has a standard and disciplined quarterly Estimated Costs at Completion process in which management reviews the progress and performance of open contracts. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. These adjustments may result from positive project performance, and may result in an increase in operating income during the performance of individual contracts. Likewise, these adjustments may result in a decrease in operating income if Estimated Costs at Completion increase. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on Operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2015, 2014, and 2013.  When estimates of total costs to be incurred on a contract exceed total estimates of revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-16-000017:notes:341]
Hardware and Software Services Support

[0000068505-16-000017:notes:342]
Revenue under equipment and software maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term.

[0000068505-16-000017:notes:343]
Software and Licenses

[0000068505-16-000017:notes:344]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other revenue recognition criteria are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period of the license.

[0000068505-16-000017:notes:345]
Multiple-Element Arrangements

[0000068505-16-000017:notes:346]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements that include products containing software that functions together with the equipment to deliver its essential functionality, undelivered software elements that relate to the product's essential software, and undelivered non-software services deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in the control of the Company.

[0000068505-16-000017:notes:347]
In these arrangements, the Company allocates revenue to all deliverables based on their relative selling prices.  The Company uses the following hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence (“VSOE”) of fair value, (ii) third-party evidence (“TPE”) of selling price, and (iii) best estimate of selling price (“ESP”).

[0000068505-16-000017:notes:348]
The Company determines VSOE based on its normal pricing and discounting practices for the specific product or service when that same product or service is sold separately. In determining VSOE, the Company requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate.

[0000068505-16-000017:notes:349]
When VSOE does not exist, the Company attempts to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, the Company's go-to-market strategy for many of its products differs from that of its competitors and its offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold by other companies cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE.

[0000068505-16-000017:notes:350]
When both VSOE and TPE are unavailable, the Company uses ESP. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0000068505-16-000017:notes:351]
The Company also considers the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE, TPE, and ESP.

[0000068505-16-000017:notes:352]
Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above.

[0000068505-16-000017:notes:353]
The Company's arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. The revenue for these multiple-element arrangements is allocated to the software deliverable(s) and the non-software deliverable(s) based on the relative selling prices of all of the deliverables in the arrangement using the fair value hierarchy outlined above. In circumstances where the Company cannot determine VSOE or TPE of the selling price for any of the deliverables in the arrangement, ESP is used for the purpose of allocating the arrangement consideration between software and non-software deliverables.

[0000068505-16-000017:notes:354]
The Company allocates arrangement consideration to multiple software or software-related deliverables, including the sale of software upgrades or software support agreements to previously sold software, in accordance with software accounting guidance. For such arrangements, revenue is allocated to the deliverables based on the relative fair value of each element, and fair value is determined using VSOE. Where VSOE does not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established, whichever occurs first. When the final undelivered software element is post contract support, service revenue is recognized on a ratable basis over the remaining service period.  When VSOE of a delivered element has not been established, but VSOE exists for the undelivered elements, the Company uses the residual method to recognize revenue when the fair value of all undelivered elements is determinable. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the arrangement consideration is allocated to the delivered elements and is recognized as revenue.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000068505-16-000017:notes:355]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013* |
| United States | $ | 3,473 |  |  | $ | 3,354 |  |  | $ | 3,648 |  |  | $ | 6,254 |  |  | $ | 8,468 |  |  | $ | 6,201 |  |
| United Kingdom | 96 |  |  | 128 |  |  | 112 |  |  | 1,127 |  |  | 966 |  |  | 1,607 |  |
| Other, net of eliminations | 2,126 |  |  | 2,399 |  |  | 2,467 |  |  | 1,006 |  |  | 989 |  |  | 1,501 |  |
|  | $ | 5,695 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |  | $ | 8,387 |  |  | $ | 10,423 |  |  | $ | 9,309 |  |

[0000068505-16-000017:notes:356]
* Excluding assets held for disposition


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-16-000017:notes:357]
|  | Net Sales |  | Operating Earnings (Loss) |
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Products | $ | 3,676 |  |  | $ | 3,807 |  |  | $ | 4,109 |  |  | $ | 704 |  |  | $ | (667 | ) |  | $ | 639 |  |
| Services | 2,019 |  |  | 2,074 |  |  | 2,118 |  |  | 290 |  |  | (339 | ) |  | 308 |  |
|  | $ | 5,695 |  |  | $ | 5,881 |  |  | $ | 6,227 |  |  | 994 |  |  | (1,006 | ) |  | 947 |  |
| Total other expense |  |  |  |  |  |  | (77 | ) |  | (155 | ) |  | (67 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  |  |  |  |  | $ | 917 |  |  | $ | (1,161 | ) |  | $ | 880 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-16-000017:notes:358]
Valuation and Qualifying Accounts


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-16-000017:notes:359]
Information by Segment and Geographic Region

[0000068505-16-000017:notes:360]
The Company conducts its business globally and manages it through two segments:

[0000068505-16-000017:notes:361]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In 2015, the segment’s net sales were $3.7 billion, representing 65% of the Company's consolidated net sales.

[0000068505-16-000017:notes:362]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2015, the segment’s net sales were $2.0 billion, representing 35% of the Company's consolidated net sales.

[0000068505-16-000017:notes:363]
For the years ended December 31, 2015, 2014 and 2013, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-16-000017:notes:364]
Segment Information

[0000068505-16-000017:notes:365]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-16-000017:notes:366]
Geographic Area Information


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-16-000017:notes:367]
Summary of Significant Accounting Policies

[0000068505-16-000017:notes:368]
Use of Estimates:   The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-16-000017:notes:369]
Cash Equivalents:    The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $63 million at both December 31, 2015 and December 31, 2014.

[0000068505-16-000017:notes:370]
Share-Based Compensation Costs:    The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.
