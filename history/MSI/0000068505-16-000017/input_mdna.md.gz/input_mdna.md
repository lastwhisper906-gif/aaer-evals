# MSI MD&A — 0000068505-16-000017


## mdna

[0000068505-16-000017:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-16-000017:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2015 and 2014 and results of operations for each of the three years in the period ended December 31, 2015. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-16-000017:mdna:3]
Executive Overview

[0000068505-16-000017:mdna:4]
Recent Developments

[0000068505-16-000017:mdna:5]
On February 19, 2016, we completed the acquisition of 100% of the equity interest in Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. The equity interest was acquired for the sum of £1, after which we invested into GDCL net cash of approximately £700 million, or approximately $1 billion, to settle all third party debt. We will make a deferred cash payment of £64 million, or approximately $90 million, on November 15, 2018. We funded the investment with a $675 million term loan and approximately $400 million of international cash on hand. The acquisition of Airwave enables us to grow revenue and geographically diversify our global Managed & Support services offerings within our Services segment, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers.

[0000068505-16-000017:mdna:6]
Our Business

[0000068505-16-000017:mdna:7]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety, and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-16-000017:mdna:8]
We conduct our business globally and manage it through two segments:

[0000068505-16-000017:mdna:9]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In 2015, the segment’s net sales were $3.7 billion, representing 65% of our consolidated net sales.

[0000068505-16-000017:mdna:10]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2015, the segment’s net sales were $2.0 billion, representing 35% of our consolidated net sales.

[0000068505-16-000017:mdna:11]
Trends Affecting Our Business

[0000068505-16-000017:mdna:12]
Impact of Macroeconomic Conditions: The stronger U.S. dollar has had a negative impact on sales denominated in currencies other than the U.S. dollar. In addition, weakening economic conditions and a significant drop in global commodity prices has negatively impacted sales in Latin America and Eastern Europe. The weakening dollar has reduced the purchasing power of our customers, and the lower price of commodities has negatively impacted government budgets and funds available for the purchase of our products in these regions.

[0000068505-16-000017:mdna:13]
The impact of foreign exchange rate fluctuations on net earnings is partially mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sales, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion of our operating expenses are denominated in foreign currencies as a result of our offshore R&D and selling, general, and administrative ("SG&A") footprint.

[0000068505-16-000017:mdna:14]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce SG&A and R&D expenses during 2016 by approximately $150 million in comparison to 2015.

[0000068505-16-000017:mdna:15]
Growth of Our Services Portfolio: Our Services segment is expected to grow at a higher rate than our Products segment. Overall, the Services segment has a lower gross margin percentage than the Products segment, but we expect consolidated operating margins to continue to expand.

[0000068505-16-000017:mdna:16]
iDEN: We have experienced a downward trend in iDEN product and services sales over the last three years due to decreased demand as a result of the dated nature of the technology. We expect the downward trend to continue as service contracts expire and new technology replaces iDEN equipment in the marketplace. This trend primarily relates to our Services segment as the majority of iDEN sales are hardware and software maintenance services. The expected decline in iDEN sales will impact both revenues and gross margins within the Services segment as iDEN services’ gross margins are generally higher than the remainder of our services portfolio.

[0000068505-16-000017:mdna:17]
Change in Presentation

[0000068505-16-000017:mdna:18]
During the first quarter of 2015, we restructured our regions operationally separating the Asia Pacific and Middle East region into two regions which are now reflected as Asia Pacific ("AP") and Middle East ("ME"). As a result of this change, our sales force is better aligned and focused on the growth opportunities within each geographic region. Accordingly, we now report net sales in the following five geographic regions: North America, Latin America, Europe and Africa ("EA"), AP, and ME.  We have updated all periods presented to reflect this change in presentation.

[0000068505-16-000017:mdna:19]
What were our 2015 financial results?

[0000068505-16-000017:mdna:20]
| • | Net sales were $5.7 billion in 2015 compared to $5.9 billion in 2014. Net sales in 2015 included the unfavorable impact of foreign currency fluctuations primarily within EA, AP, and Latin America, partially offset by growth in North America. |

[0000068505-16-000017:mdna:21]
| • | Operating earnings were $1.0 billion in 2015, compared to an operating loss of $1.0 billion in 2014. Included in the 2014 operating loss was a $1.9 billion pension settlement loss. |

[0000068505-16-000017:mdna:22]
| • | Earnings from continuing operations were $640 million, or $3.17 per diluted common share in 2015, compared to losses of $697 million, or $(2.84) per diluted common share in 2014. |

[0000068505-16-000017:mdna:23]
| • | Cash provided by operating activities was $1.0 billion in 2015, compared to cash used for operating activities of $685 million in 2014. Pension plan contributions were $13 million in 2015 and $1.3 billion in 2014. |

[0000068505-16-000017:mdna:24]
| • | We repurchased $3.2 billion of our shares and paid $277 million in cash dividends during 2015. |

[0000068505-16-000017:mdna:25]
What were the financial results for our two segments in 2015?

[0000068505-16-000017:mdna:26]
| • | In the Products segment, net sales were $3.7 billion in 2015, a decrease of $131 million, or 3%, compared to $3.8 billion in 2014. On a geographic basis, net sales decreased in EA and Latin America and increased in North America, AP, and ME, compared to 2014. Operating earnings were $704 million in 2015, compared to an operating loss of $667 million in 2014. Operating margin increased in 2015 to 19.2% from (17.5)% in 2014. Approximately $1.3 billion of pension settlement losses were allocated to the Products segment in 2014. |

[0000068505-16-000017:mdna:27]
| • | In the Services segment, net sales were $2.0 billion in 2015, a decrease of $55 million, or 3%, compared to $2.1 billion in 2014. On a geographic basis, net sales decreased in EA, Latin America, and AP and increased in ME and North America, compared to 2014. Operating earnings were $290 million in 2015, compared to an operating loss of $339 million in 2014. Operating margin increased in 2015 to 14.4% from (16.3)% in 2014. Approximately $584 million of pension settlement losses were allocated to the Services segment in 2014. |

[0000068505-16-000017:mdna:28]
What were our major accomplishments in 2015?

[0000068505-16-000017:mdna:29]
Structural highlights

[0000068505-16-000017:mdna:30]
| • | On August 4, 2015, the Board of Directors authorized a modified "Dutch auction" tender offer to repurchase up to $2.0 billion of our outstanding common stock under the previously existing share repurchase authority. The tender offer commenced on August 7, 2015 and expired on September 3, 2015. We paid $2.0 billion, including transaction costs, to repurchase approximately 30.1 million shares at a tender price of $66.50 per share; |

[0000068505-16-000017:mdna:31]
| • | On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes (the "Senior Convertible Notes") which mature in September 2020. The investment provides capital and a financial partnership to work together on opportunities in software and services growth areas; and |

[0000068505-16-000017:mdna:32]
| • | Reduced operating expenses by more than $200 million as compared to 2014, including reorganizing our R&D and SG&A functions. This reorganization both reduced costs and enabled efficiencies that shifted more investment into key areas such as Services and Public Safety LTE solutions. |

[0000068505-16-000017:mdna:33]
Business highlights

[0000068505-16-000017:mdna:34]
| • | Ended 2015 with a record backlog position of $6.5 billion, up 12% compared to 2014; |

[0000068505-16-000017:mdna:35]
| • | Grew revenue 3% in North America, 32% in the Middle East, and 1% in Asia Pacific; |

[0000068505-16-000017:mdna:36]
| • | Grew diluted earnings per share from continuing operations to $3.17; |

[0000068505-16-000017:mdna:37]
| • | In November 2015, we increased our quarterly dividend by 21% to $0.41 per share; |

[0000068505-16-000017:mdna:38]
| • | Grew Managed & Support services by 1%; |

[0000068505-16-000017:mdna:39]
| • | Increased operating cash flows to $1.0 billion; |

[0000068505-16-000017:mdna:40]
| • | Returned $3.5 billion in capital in the form of $3.2 billion in share repurchases and $277 million in dividends; and |

[0000068505-16-000017:mdna:41]
| • | We were awarded a portion of the largest public safety LTE contract in 2015 with the United Kingdom government covering more than 300,000 emergency and public service users at more than 300 agencies across Great Britain. |

[0000068505-16-000017:mdna:42]
Looking Forward

[0000068505-16-000017:mdna:43]
We remain committed to driving shareholder value with revenue growth, operating leverage, cash flow generation, and efficient capital deployment. We plan to demonstrate this through disciplined financial policies that will drive an additional reduction of $150 million of organic SG&A and R&D expenses in 2016, bringing the cumulative reduction in operating expenses to more than $600 million over the past three years. Likewise, we strive to optimize our capital structure to enable prioritized investments in the business and targeted acquisitions as a source of generating solid future operating cash flows. These potential investments are balanced against returning excess capital to shareholders through dividends and share repurchases. We expect to continue the quarterly dividends that were initiated in 2011 as well as the opportunity to return capital to shareholders through share repurchases. Our share repurchase program has approximately $1.0 billion of authority available as of December 31, 2015.

[0000068505-16-000017:mdna:44]
Entering 2016, we believe we are well-positioned to compete in both our core markets and adjacent growth areas. We have a broad, compelling products and services portfolio specifically tailored for our mission-critical communications customer base that spans many layers of governments, public safety, and first responders, as well as commercial and industrial customers in a number of key verticals. As we add new products, features, and software upgrades, we ensure our solutions are interoperable and backward-compatible, enabling customers to confidently invest for their future needs while allowing them to utilize their prior investment in our technology.

[0000068505-16-000017:mdna:45]
Supplementing our traditional core business is our Managed & Support services business, which has been a focus area of investment and growth in recent years. As communication networks have become increasingly complex, software-centric, and data-driven, we have shifted our offerings to align with this technology trend in serving our customers. We expect to continue to see growing demands for our Managed & Support services going forward. These services offerings help customers manage, support, and upgrade their networks as well as utilize features, applications, and data in new ways including predictive policing, proactive support, or smarter response strategies. We expect our overall revenue mix to continue to shift towards services over time. On February 19, 2016, the Company acquired Airwave, the largest private operator of a public safety network in the world, delivering mission-critical voice and data communications to more than 300 public service agencies in Great Britain. This acquisition will expand our Managed & Support services business.

[0000068505-16-000017:mdna:46]
Another key technology trend complementing our existing business is the expanded use of broadband LTE by our customers. We have been proactively investing in next-generation public safety broadband solutions for years, as we believe public safety LTE solutions are the next-generation tool for our public safety first-responder customers. We believe our expertise in both public and private networks makes us uniquely qualified to provide these public safety broadband solutions to this customer base. We have now won the four largest public safety LTE network installations awarded to date and expect LTE sales to represent a larger portion of our revenue in the coming years.

[0000068505-16-000017:mdna:47]
29

[0000068505-16-000017:mdna:48]
Results of Operations

[0000068505-16-000017:mdna:49]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2015 |  | % ofSales ** |  | 2014 |  | % ofSales ** |  | 2013 |  | % ofSales ** |
| Net sales from products | $ | 3,676 |  |  |  |  | $ | 3,807 |  |  |  |  | $ | 4,109 |  |  |  |
| Net sales from services | 2,019 |  |  |  |  | 2,074 |  |  |  |  | 2,118 |  |  |  |
| Net sales | 5,695 |  |  |  |  | 5,881 |  |  |  |  | 6,227 |  |  |  |
| Costs of product sales | 1,625 |  |  | 44.2 | % |  | 1,678 |  |  | 44.1 | % |  | 1,808 |  |  | 44.0 | % |
| Costs of services sales | 1,351 |  |  | 66.9 | % |  | 1,372 |  |  | 66.2 | % |  | 1,310 |  |  | 61.9 | % |
| Costs of sales | 2,976 |  |  | 52.3 | % |  | 3,050 |  |  | 51.9 | % |  | 3,118 |  |  | 50.1 | % |
| Gross margin | 2,719 |  |  | 47.7 | % |  | 2,831 |  |  | 48.1 | % |  | 3,109 |  |  | 49.9 | % |
| Selling, general and administrative expenses | 1,021 |  |  | 17.9 | % |  | 1,184 |  |  | 20.1 | % |  | 1,330 |  |  | 21.4 | % |
| Research and development expenditures | 620 |  |  | 10.9 | % |  | 681 |  |  | 11.6 | % |  | 761 |  |  | 12.2 | % |
| Other charges | 84 |  |  | 1.5 | % |  | 1,972 |  |  | 33.5 | % |  | 71 |  |  | 1.1 | % |
| Operating earnings (loss) | 994 |  |  | 17.5 | % |  | (1,006 | ) |  | (17.1 | )% |  | 947 |  |  | 15.2 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (173 | ) |  | (3.0 | )% |  | (126 | ) |  | (2.1 | )% |  | (113 | ) |  | (1.8 | )% |
| Gains on sales of investments | 107 |  |  | 1.9 | % |  | 5 |  |  | 0.1 | % |  | 37 |  |  | 0.6 | % |
| Other | (11 | ) |  | (0.2 | )% |  | (34 | ) |  | (0.6 | )% |  | 9 |  |  | 0.1 | % |
| Total other expense | (77 | ) |  | (1.4 | )% |  | (155 | ) |  | (2.6 | )% |  | (67 | ) |  | (1.1 | )% |
| Earnings (loss) from continuing operations before income taxes | 917 |  |  | 16.1 | % |  | (1,161 | ) |  | (19.7 | )% |  | 880 |  |  | 14.1 | % |
| Income tax expense (benefit) | 274 |  |  | 4.8 | % |  | (465 | ) |  | (7.9 | )% |  | (59 | ) |  | (0.9 | )% |
| Earnings (loss) from continuing operations | 643 |  |  | 11.3 | % |  | (696 | ) |  | (11.8 | )% |  | 939 |  |  | 15.1 | % |
| Less: Earnings attributable to noncontrolling interests | 3 |  |  | 0.1 | % |  | 1 |  |  | — | % |  | 6 |  |  | 0.1 | % |
| Earnings (loss) from continuing operations* | 640 |  |  | 11.2 | % |  | (697 | ) |  | (11.9 | )% |  | 933 |  |  | 15.0 | % |
| Earnings (loss) from discontinued operations, net of tax | (30 | ) |  | (0.5 | )% |  | 1,996 |  |  | 33.9 | % |  | 166 |  |  | 2.7 | % |
| Net earnings* | $ | 610 |  |  | 10.7 | % |  | $ | 1,299 |  |  | 22.1 | % |  | $ | 1,099 |  |  | 17.6 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 3.17 |  |  |  |  | $ | (2.84 | ) |  |  |  | $ | 3.45 |  |  |  |
| Discontinued operations | (0.15 | ) |  |  |  | 8.13 |  |  |  |  | 0.61 |  |  |  |
| Earnings per diluted common share* | $ | 3.02 |  |  |  |  | $ | 5.29 |  |  |  |  | $ | 4.06 |  |  |  |

[0000068505-16-000017:mdna:50]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-16-000017:mdna:51]
**    Percentages may not add due to rounding.

[0000068505-16-000017:mdna:52]
Geographic Market Sales by Locale of End Customer

[0000068505-16-000017:mdna:53]
|  | 2015 |  | 2014 |  | 2013 |
| North America | 65 | % |  | 61 | % |  | 63 | % |
| Latin America | 6 | % |  | 9 | % |  | 8 | % |
| EA | 15 | % |  | 17 | % |  | 16 | % |
| AP | 12 | % |  | 11 | % |  | 12 | % |
| ME | 2 | % |  | 2 | % |  | 1 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-16-000017:mdna:54]
Results of Operations—2015 Compared to 2014

[0000068505-16-000017:mdna:55]
Net Sales

[0000068505-16-000017:mdna:56]
Net sales were $5.7 billion in 2015, down $186 million, or 3%, compared to $5.9 billion in 2014. The decline in net sales is reflective of decreases in EA and Latin America, partially offset by growth in North America, ME, and AP. The decrease in EA and Latin America was primarily the result of lower Products and Services sales, driven by challenging macroeconomic conditions in Latin America and Eastern Europe, and foreign exchange rate unfavorability. North America grew on strong Products and Services sales, ME realized an increase in Services sales, and AP grew on strong Products sales.

[0000068505-16-000017:mdna:57]
Gross Margin

[0000068505-16-000017:mdna:58]
Gross margin was $2.7 billion, or 47.7% of net sales in 2015, compared to $2.8 billion, or 48.1% of net sales, in 2014. The decrease in gross margin was primarily a result of foreign exchange rate unfavorability. The decrease in gross margin percentage is primarily attributable to a decrease in gross margin as a percentage of sales within the Services segment while the gross margin percentage of the Products segment remained relatively flat. The decrease in gross margin percentage in the Services segment was primarily driven by: (i) a decrease in North America Integration services margins due to the deployment of certain large projects at lower gross margins and (ii) lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-16-000017:mdna:59]
Selling, General and Administrative Expenses

[0000068505-16-000017:mdna:60]
SG&A expenses decreased 14% to $1.0 billion, or 17.9% of net sales in 2015, compared to $1.2 billion, or 20.1% of net sales in 2014. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) lower pension expenses, and (iii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-16-000017:mdna:61]
Research and Development Expenditures

[0000068505-16-000017:mdna:62]
R&D expenditures decreased 9% to $620 million, or 10.9% of net sales in 2015, compared to $681 million, or 11.6% of net sales in 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, and the movement of employees to lower cost work sites and (ii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-16-000017:mdna:63]
Other Charges

[0000068505-16-000017:mdna:64]
We recorded net charges of $84 million in Other charges in 2015, compared to net charges of $2.0 billion in 2014. The charges in 2015 included: (i) $108 million of net reorganization of business charges, including a $31 million impairment of the corporate aircraft and (ii) $8 million of charges relating to the amortization of intangibles, partially offset by a $32 million non-U.S. pension curtailment gain. The charges in 2014 included: (i) a $1.9 billion charge related to the settlement of a U.S. pension plan, (ii) $64 million of net reorganization of business charges, (iii) $8 million of legal settlement charges, and (iv) $4 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land.

[0000068505-16-000017:mdna:65]
Net Interest Expense

[0000068505-16-000017:mdna:66]
Net interest expense was $173 million in 2015, compared to net interest expense of $126 million in 2014. The increase in interest expense in 2015 compared to 2014 was a result of higher average debt balances.

[0000068505-16-000017:mdna:67]
Gains on Sales of Investments

[0000068505-16-000017:mdna:68]
Gains on sales of investments were $107 million in 2015, compared to $5 million in 2014. The net gains in 2015 and 2014 were related to the sales of equity investments.

[0000068505-16-000017:mdna:69]
Other

[0000068505-16-000017:mdna:70]
Net Other expense was $11 million in 2015, compared to net Other expense of $34 million in 2014. The net Other expense in 2015 was primarily comprised of: (i) a $23 million foreign currency loss and (ii) a $6 million investment impairment, partially offset by: (i) a $7 million gain on derivative instruments, (ii) a $6 million gain on equity method investments, and (iii) $5 million of other non-operating gains. Net Other expense in 2014 was primarily comprised of: (i) a $37 million loss on the extinguishment of debt, (ii) a $4 million loss on derivative instruments, (iii) a $3 million foreign currency loss, and (iv) $6 million of other non-operating losses, partially offset by a $16 million gain on equity method investments.

[0000068505-16-000017:mdna:71]
Effective Tax Rate

[0000068505-16-000017:mdna:72]
We recorded a $274 million net tax expense in 2015, resulting in an effective tax rate of 30%, compared to $465 million of net tax benefit in 2014, resulting in an effective tax rate of 40%. Our effective tax rate in 2015 was lower than the U.S. statutory tax rate of 35% primarily due to lower tax rates on non-U.S. income.

[0000068505-16-000017:mdna:73]
Our effective tax rate in 2014 was favorably impacted by: (i) state tax benefits on the pension settlement loss, (ii) $29 million in tax benefits associated with the net reduction in unrecognized tax benefits and (iii) $19 million in net reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions. These benefits were partially offset by tax expense for the establishment of a $55 million valuation allowance on certain foreign deferred tax assets.

[0000068505-16-000017:mdna:74]
Our effective tax rate will change from period to period based on non-recurring events, such as the settlement of income tax audits, changes in valuation allowances, and the tax impact of significant unusual or extraordinary items, as well as recurring factors including changes in the geographic mix of income and effects of various global income tax strategies.

[0000068505-16-000017:mdna:75]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-16-000017:mdna:76]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $640 million, or $3.17 per diluted share, in 2015, compared to a net loss from continuing operations attributable to Motorola Solutions, Inc. of $697 million, or $(2.84) per diluted share, in 2014.

[0000068505-16-000017:mdna:77]
The increase in earnings from continuing operations in 2015, as compared to 2014, was primarily driven by: (i) a $1.9 billion decrease in Other charges, (ii) a $163 million decrease in SG&A, and (iii) a $61 million decrease in R&D. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding, primarily as a result of our "Dutch auction" tender offer, as well as repurchases made through our ongoing share repurchase program, and an increase in earnings from continuing operations.

[0000068505-16-000017:mdna:78]
Earnings from Discontinued Operations

[0000068505-16-000017:mdna:79]
After taxes, we had a $30 million, or $0.15 per diluted share, loss from discontinued operations in 2015, compared to earnings from discontinued operations of $2.0 billion, or $8.13 per diluted share, in 2014. The earnings from discontinued operations in both 2015 and 2014 were primarily related to the sale of the Enterprise business.

[0000068505-16-000017:mdna:80]
Results of Operations—2014 Compared to 2013

[0000068505-16-000017:mdna:81]
Net Sales

[0000068505-16-000017:mdna:82]
Net sales were $5.9 billion in 2014, down $346 million, or 6% compared to $6.2 billion in 2013. The decline in net sales is reflective of decreases in North America, AP, and Latin America, partially offset by growth in EA and ME. The decrease in North America was a result of lower Products and Services sales, driven by reduced devices and systems sales and iDen services. The decreases in Latin America and AP were primarily the result of lower Products sales. EA and ME grew on strong Products and Services sales.

[0000068505-16-000017:mdna:83]
Gross Margin

[0000068505-16-000017:mdna:84]
Gross margin was $2.8 billion, or 48.1% of net sales in 2014, compared to $3.1 billion, or 49.9% of net sales, in 2013. The  decrease in gross margin percentage is attributable to: (i) a decline in gross margin as a percentage of sales within the Services segment in North America, (ii) lower net sales of iDEN services in Latin America, which have slightly higher gross margin percentage compared to the rest of the Services portfolio, and (iii) a decrease in gross margin as a percentage of sales in EA as a result of the mix of projects in the field.

[0000068505-16-000017:mdna:85]
Selling, General and Administrative Expenses

[0000068505-16-000017:mdna:86]
SG&A expenses decreased 11% to $1.2 billion, or 20.1% of net sales in 2014, compared to $1.3 billion, or 21.4% of net sales in 2013. The decrease in SG&A is primarily due to: (i) the reduction of sales support costs by lowering our overall non-quota carrying employee base, (ii) lower pension expenses, (iii) lower incentive compensation expenses, and (iv) reduced costs through the increased use of centralized services.

[0000068505-16-000017:mdna:87]
Research and Development Expenditures

[0000068505-16-000017:mdna:88]
R&D expenditures decreased 11% to $681 million, or 11.6% of net sales in 2014, compared to $761 million, or 12.2% of net sales in 2013. The decrease in R&D expenditures is primarily due to: (i) headcount reductions enacted during previous periods, (ii) lower incentive compensation expenses, (iii) the consolidation of testing processes and lab sites, and (iv) the movement of employees to lower cost work sites.

[0000068505-16-000017:mdna:89]
Other Charges

[0000068505-16-000017:mdna:90]
We recorded net charges of $2.0 billion in Other charges in 2014, compared to net charges of $71 million in 2013. The charges in 2014 included: (i) a $1.9 billion charge related to the settlement of a U.S. pension plan, (ii) $64 million of net reorganization of business charges, (iii) $8 million of legal settlement charges, and (iv) $4 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land. The charges in 2013 included: (i) $70 million of net reorganization of business charges and (ii) $1 million of charges relating to amortization of intangibles.

[0000068505-16-000017:mdna:91]
Net Interest Expense

[0000068505-16-000017:mdna:92]
Net interest expense was $126 million in 2014, compared to net interest expense of $113 million in 2013. The increase in interest expense in 2014 compared to 2013 was a result of higher average debt balances.

[0000068505-16-000017:mdna:93]
Gains on Sales of Investments

[0000068505-16-000017:mdna:94]
Gains on sales of investments were $5 million in 2014, compared to $37 million in 2013. The net gains in 2014 and 2013 were related to the sales of equity investments.

[0000068505-16-000017:mdna:95]
Other

[0000068505-16-000017:mdna:96]
Net Other expense was $34 million in 2014, compared to net Other income of $9 million in 2013. The net Other expense in 2014 was primarily comprised of: (i) a $37 million loss on the extinguishment of debt, (ii) a $4 million loss on derivative instruments, (iii) a $3 million foreign currency loss, and (iv) $6 million of other non-operating losses, partially offset by a $16

[0000068505-16-000017:mdna:97]
million gain on equity method investments. Net Other income in 2013 was primarily comprised of: (i) a $10 million gain on equity method investments, (ii) an $8 million gain on derivative instruments, and (iii) $11 million of other non-operating gains, partially offset by (i) a $17 million foreign currency loss and (ii) a $3 million investment impairment.

[0000068505-16-000017:mdna:98]
Effective Tax Rate

[0000068505-16-000017:mdna:99]
We recorded a $465 million net tax benefit in 2014, resulting in an effective tax rate of 40%, compared to $59 million of net tax benefit in 2013, resulting in an effective tax rate of negative 7%. Our effective tax rate in 2014 was favorably impacted by: (i) state tax benefits on the pension settlement loss, (ii) $29 million in tax benefits associated with the net reduction in unrecognized tax benefits, and (iii) $19 million in net reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions. These benefits were partially offset by tax expense for the establishment of a $55 million valuation allowance on certain foreign deferred tax assets.

[0000068505-16-000017:mdna:100]
Our negative effective tax rate in 2013 was lower than the U.S. statutory tax rate of 35% due to: (i) $337 million associated with excess foreign tax credits on undistributed foreign earnings, (ii) a $25 million reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions, and (iii) a $9 million tax benefit for R&D tax credits.

[0000068505-16-000017:mdna:101]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-16-000017:mdna:102]
After taxes, we had a net loss from continuing operations attributable to Motorola Solutions, Inc. of $697 million, or $(2.84) per diluted share, in 2014, compared to net earnings from continuing operations attributable to Motorola Solutions, Inc. of $933 million, or $3.45 per diluted share, in 2013.

[0000068505-16-000017:mdna:103]
The decrease in earnings (loss) from continuing operations in 2014, as compared to 2013, was primarily driven by: (i) a $1.9 billion charge related to the settlement of a U.S. pension plan and (ii) a $278 million decrease in gross margin primarily due to sales declines and a change in sales mix, partially offset by: (i) a $146 million decrease in SG&A and (ii) an $80 million decrease in R&D. The decrease in earnings (loss) from continuing operations per diluted share was driven by lower net earnings, partially offset by a reduction in shares outstanding as a result of our share repurchase program.

[0000068505-16-000017:mdna:104]
Earnings from Discontinued Operations

[0000068505-16-000017:mdna:105]
After taxes, we had $2.0 billion, or $8.13 per diluted share, of earnings from discontinued operations in 2014, compared to earnings from discontinued operations of $166 million, or $0.61 per diluted share, in 2013. The earnings from discontinued operations in 2014 and 2013 were primarily related to the Enterprise business.

[0000068505-16-000017:mdna:106]
Segment Information

[0000068505-16-000017:mdna:107]
The following commentary should be read in conjunction with the financial results of each operating business segment as detailed in Note 12, “Information by Segment and Geographic Region,” to our consolidated financial statements. Net sales and operating results for our two segments for 2015, 2014, and 2013 are presented below.

[0000068505-16-000017:mdna:108]
Products Segment

[0000068505-16-000017:mdna:109]
The Products segment’s net sales represented 65% of our consolidated net sales in 2015 and 2014, compared to 66% in 2013.

[0000068505-16-000017:mdna:110]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2015 |  | 2014 |  | 2013 |  | 2015—2014 |  | 2014—2013 |
| Segment net sales | $ | 3,676 |  |  | $ | 3,807 |  |  | $ | 4,109 |  |  | (3 | )% |  | (7 | )% |
| Operating earnings (loss) | 704 |  |  | (667 | ) |  | 639 |  |  | N/M |  |  | (204 | )% |

[0000068505-16-000017:mdna:111]
* N/M = Percent Change is not meaningful due to the comparison using prior year operating losses as a basis for the calculation.

[0000068505-16-000017:mdna:112]
Segment Results—2015 Compared to 2014

[0000068505-16-000017:mdna:113]
The segment’s net sales decreased $131 million, or 3%, to $3.7 billion in 2015, as compared to $3.8 billion in 2014. The decrease in the segment's net sales was primarily driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, Latin America, and AP, (ii) decreases in devices and systems sales in EA and Latin America impacted by the reduced purchasing power of our customers caused by the devaluation of their local currency and macroeconomic conditions, (iii) a decrease in systems sales in North America, and (iv) declines in devices sales in AP and ME, partially offset by: (i) growth in devices sales in North America and (ii) increased systems sales in AP and ME. On a geographic basis, net sales decreased in EA and LA and increased in North America, AP, and ME in 2015, compared to 2014. The segment's backlog was $1.2 billion at both December 31, 2015 and December 31, 2014.

[0000068505-16-000017:mdna:114]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 67% of the segment’s net sales in 2015, up from 62% of the segment’s net sales in 2014.

[0000068505-16-000017:mdna:115]
33

[0000068505-16-000017:mdna:116]
The segment had operating earnings of $704 million in 2015, compared to an operating loss of $667 million in 2014. The increase in operating earnings in 2015 compared to 2014 was driven primarily by: (i) a decrease in Other charges as a result of a $1.3 billion expense related to the 2014 settlement of a U.S. pension plan, (ii) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses, and (iii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates.

[0000068505-16-000017:mdna:117]
Segment Results—2014 Compared to 2013

[0000068505-16-000017:mdna:118]
The segment's net sales decreased $302 million, or 7%, to $3.8 billion in 2014, as compared to $4.1 billion in 2013. The decrease in the segment's net sales was primarily driven by: (i) decreases in devices and systems sales in North America and AP, (ii) a decrease in devices sales Latin America, and (iii) a decrease in systems sales in EA and ME, partially offset by: (i) an increase in devices sales in EA and ME and (ii) an increase in systems sales in Latin America. On a geographic basis, net sales decreased in North America, AP, and Latin America and increased in ME and EA in 2014, compared to 2013. The segment's backlog was $1.2 billion at December 31, 2014 and $1.1 billion at December 31, 2013.

[0000068505-16-000017:mdna:119]
Net sales in North America comprised a significant portion of the segment’s business, accounting for approximately 62% of the segment’s net sales in 2014, down from 63% of the segment’s net sales in 2013.

[0000068505-16-000017:mdna:120]
The segment had an operating loss of $667 million in 2014, compared to operating earnings of $639 million in 2013. The decrease in operating earnings in 2014 compared to 2013, was driven primarily by: (i) an increase in Other charges as a result of a $1.3 billion expense related to the 2014 settlement of a U.S. pension plan and (ii) lower net sales, resulting in lower gross margin, partially offset by lower SG&A and R&D expenditures as a result of cost savings actions taken to lower variable compensation expenses.

[0000068505-16-000017:mdna:121]
Services Segment

[0000068505-16-000017:mdna:122]
The Services segment’s net sales represented 35% of our consolidated net sales in 2015 and 2014, compared to 34% in 2013.

[0000068505-16-000017:mdna:123]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2015 |  | 2014 |  | 2013 |  | 2015—2014 |  | 2014—2013 |
| Segment net sales | $ | 2,019 |  |  | $ | 2,074 |  |  | $ | 2,118 |  |  | (3 | )% |  | (2 | )% |
| Operating earnings (loss) | 290 |  |  | (339 | ) |  | 308 |  |  | N/M |  |  | (210 | )% |

[0000068505-16-000017:mdna:124]
* N/M = Percent Change is not meaningful due to the comparison using prior year operating losses as a basis for the calculation.

[0000068505-16-000017:mdna:125]
Segment Results—2015 Compared to 2014

[0000068505-16-000017:mdna:126]
The segment’s net sales decreased $55 million, or 3%, to $2.0 billion in 2015, as compared to $2.1 billion in 2014. The decrease in the segment's net sales was primarily driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EA, Latin America, and AP, (ii) lower Integration services sales, primarily in EA, related to the winding down of a large system implementation in Norway, and (iii) declining iDEN services sales in Latin America, partially offset by an increase in Managed & Support services in North America and ME. On a geographic basis, net sales for 2015 decreased in EA, Latin America, and AP and increased in ME and North America, compared to 2014. The segment's backlog was $5.2 billion at December 31, 2015 and $4.6 billion at December 31, 2014. The increase in the segment's backlog in 2015 compared to 2014 was driven in part by the United Kingdom government LTE contract awarded in 2015.

[0000068505-16-000017:mdna:127]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 62% of the segment’s net sales in 2015, up from 59% of the segment’s net sales in 2014.

[0000068505-16-000017:mdna:128]
The segment had operating earnings of $290 million in 2015, compared to an operating loss of $339 million in 2014. The increase in operating earnings in 2015 compared to 2014, was driven primarily by: (i) a decrease in Other charges as a result of a $584 million expense related to the 2014 settlement of a U.S. pension plan and (ii) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses.

[0000068505-16-000017:mdna:129]
Segment Results—2014 Compared to 2013

[0000068505-16-000017:mdna:130]
The segment's net sales decreased $44 million, or 2%, to $2.1 billion in 2014, as compared to 2013. The decrease in the segment's net sales was primarily driven by a decrease in iDEN services sales in North America and Latin America, partially offset by an increase in Managed & Support services in Latin America, North America, and EA. On a geographic basis, net sales for 2014 decreased in North America and AP, increased in EA and ME, and remained relatively constant in Latin America, compared to 2013. The segment's backlog was $4.6 billion at December 31, 2014 and $4.3 billion at December 31, 2013.

[0000068505-16-000017:mdna:131]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 59% of the segment’s net sales in 2014, down from 61% of the segment’s net sales in 2013.

[0000068505-16-000017:mdna:132]
The segment had an operating loss of $339 million in 2014, compared to operating earnings of $308 million in 2013. The decrease in operating earnings in 2014 compared to 2013, was driven primarily by: (i) an increase in Other charges as a result of a $584 million expense related to the 2014 settlement of a U.S. pension plan and (ii) lower net sales, resulting in lower gross

[0000068505-16-000017:mdna:133]
margin, partially offset by lower SG&A and R&D expenditures as a result of cost savings actions taken to lower variable compensation expenses.

[0000068505-16-000017:mdna:134]
Reorganization of Businesses

[0000068505-16-000017:mdna:135]
During 2015 we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. In 2015, we recorded net reorganization of business charges of $117 million relating to the separation of 1,100 employees, of which 900 were indirect employees and 200 were direct employees. The $117 million of charges in earnings from continuing operations included $9 million recorded to Cost of sales and $108 million recorded to Other charges. Included in the aggregate $117 million are charges of: (i) $74 million for employee separation costs, $31 million for the impairment of the corporate aircraft, (iii) $10 million for exit costs, and (iv) a $6 million building impairment charge, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-16-000017:mdna:136]
During 2014, we recorded net reorganization of business charges of $96 million relating to the separation of 1,200 employees, of which 900 were indirect employees and 300 were direct employees. Of these charges, $23 million related to discontinued operations. The remaining $73 million of charges in earnings (loss) from continuing operations included $9 million recorded to Cost of sales and $64 million recorded to Other charges. Included in the aggregate $73 million are charges of: (i) $67 million for employee separation costs and (ii) $7 million related to charges for exit costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-16-000017:mdna:137]
During 2013, we recorded net reorganization of business charges of $133 million relating to the separation of 2,200 employees, of which 1,400 were indirect employees and 800 were direct employees. Of these charges, $47 million related to discontinued operations. The remaining $86 million of charges in earnings from continuing operations included $16 million recorded to Cost of sales and $70 million recorded to Other charges. Included in the aggregate $86 million are charges of: (i) $94 million for employee separation costs and (ii) $2 million related to charges for exit costs, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-16-000017:mdna:138]
The following table displays the net charges incurred by business segment:

[0000068505-16-000017:mdna:139]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Products | $ | 84 |  |  | $ | 48 |  |  | $ | 57 |  |
| Services | 33 |  |  | 25 |  |  | 29 |  |
|  | $ | 117 |  |  | $ | 73 |  |  | $ | 86 |  |

[0000068505-16-000017:mdna:140]
Cash payments for exit costs and employee separations in connection with these reorganization plans were $71 million,$148 million, and $59 million in 2015, 2014, and 2013, respectively. The cash payments included $5 million in 2015, $50 million in 2014, and $20 million in 2013 related to employees of discontinued operations. Of the $60 million reorganization of businesses accrual remaining at December 31, 2015, $51 million relates to employee separation costs that are expected to be paid in 2016 and $9 million relates to exit costs.

[0000068505-16-000017:mdna:141]
Liquidity and Capital Resources

[0000068505-16-000017:mdna:142]
We decreased the aggregate of our cash and cash equivalent balances by $2.0 billion from $4.0 billion as of December 31, 2014 to $2.0 billion as of December 31, 2015. The decrease is primarily due to $3.5 billion of capital returned to shareholders through share repurchases and dividends paid and an investment of $401 million in United Kingdom treasury securities used to partially offset our British Pound Sterling foreign currency risk associated with the purchase of Airwave that we closed in February 2016, offset by $1.0 billion of cash provided by operating activities and $971 million of proceeds raised by the issuance of the Senior Convertible Notes (net of issuance costs paid).

[0000068505-16-000017:mdna:143]
As highlighted in the consolidated statements of cash flows, our liquidity and available capital resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0000068505-16-000017:mdna:144]
Cash and Cash Equivalents

[0000068505-16-000017:mdna:145]
At December 31, 2015, $1.1 billion of the $2.0 billion cash and cash equivalents balance was held in the U.S. and $838 million was held by the Company or its subsidiaries in other countries, with approximately $495 million held in the United Kingdom. At both December 31, 2015 and December 31, 2014, restricted cash was $63 million.

[0000068505-16-000017:mdna:146]
We continue to analyze and review various repatriation strategies to efficiently repatriate cash. In 2015, we repatriated approximately $249 million in cash to the U.S. from international jurisdictions. Undistributed earnings that we intend to reinvest indefinitely, and for which no U.S. income taxes have been provided, aggregate to $1.4 billion at December 31, 2015. We currently have no plans to repatriate the foreign earnings permanently reinvested. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-16-000017:mdna:147]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy.  While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact,

[0000068505-16-000017:mdna:148]
repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-16-000017:mdna:149]
Operating Activities

[0000068505-16-000017:mdna:150]
Cash provided by operating activities from continuing operations in 2015 was $1.0 billion, compared to cash used by operating activities from continuing operations of $685 million in 2014 and cash provided by operating activities from continuing operations of $555 million in 2013. Operating cash flows in 2015, as compared to 2014, were positively impacted by: (i) an increase in earnings from continuing operations, (ii) reduced pension contributions, and (iii) higher sales of accounts receivable. Operating cash flows in 2014, as compared to 2013, were negatively impacted by contributions to our pension plans of $1.3 billion, an increase of $1.1 billion compared to 2013.

[0000068505-16-000017:mdna:151]
We made $3 million of contributions to our U.S. pension plans during 2015, compared to $1.1 billion contributed in 2014 to fund the purchase of group annuity contracts and lump sum distributions from one of our U.S. pension plans, as described in Note 7 to our consolidated financial statements, and $150 million contributed in 2013. In addition, we contributed $10 million, $237 million, and $32 million to our Non-U.S. Pension Plans during 2015, 2014, and 2013, respectively. We expect to make approximately $12 million of cash contributions in 2016, primarily to our Non-U.S. Pension Benefit Plans in 2016.

[0000068505-16-000017:mdna:152]
Investing Activities

[0000068505-16-000017:mdna:153]
Net cash used by investing activities from continuing operations was $528 million in 2015, compared to net cash provided by investing activities from continuing operations of $3.2 billion in 2014 and $2.0 billion in 2013. The $3.7 billion decrease in net cash provided by investing activities from 2014 to 2015 was primarily due to reduced proceeds from sales of investments and businesses related to the sale of the Enterprise business and a $401 million investment in United Kingdom treasury securities. The $1.2 billion increase in net cash provided by investing activities from 2013 to 2014 was primarily due to a $3.3 billion increase of proceeds from sales of investments and businesses, related to the sale of our Enterprise business, partially offset by a $2.1 billion decrease in proceeds from sales of Sigma Fund investments, which we exited in the fourth quarter of 2013.

[0000068505-16-000017:mdna:154]
Sigma Fund:  Prior to December 2013, we invested most of our U.S. dollar-denominated cash in a fund (the “Sigma Fund”) that was managed by independent investment management firms under specific investment guidelines restricting the type of investments held and their time to maturity. In December 2013, we completed the liquidation of the Sigma Fund and migrated the international U.S dollar-denominated cash to a U.S. dollar cash pool invested primarily in U.S. dollar prime money market funds. The creation of the international cash pool enhances our flexibility to repatriate excess overseas cash and fund global operations. These money market funds are classified as Cash and cash equivalents within the consolidated balance sheets as of December 31, 2015 and 2014.

[0000068505-16-000017:mdna:155]
Acquisitions and Investments:  We used cash of $586 million for acquisitions and new investment activities in 2015, compared to $47 million in 2014, and $57 million in 2013. In December 2015, we invested $401 million in United Kingdom treasury securities in order to partially offset our British Pound Sterling foreign currency risk associated with the purchase of Airwave. We liquidated these investments in February 2016 to partially fund the acquisition of Airwave. Additionally, we paid $49 million for the acquisition of two public safety software solution providers, as well as several debt and equity investments. The cash used in 2014 was for the acquisition of an equipment provider for $22 million and a number of equity investments. The cash used in 2013 was for the acquisition of a communications software provider in push-to-talk-over-broadband applications for a purchase price, net of cash acquired, of $36 million, and other small strategic equity investments.

[0000068505-16-000017:mdna:156]
Capital Expenditures:  Capital expenditures were $175 million in 2015, compared to $181 million in 2014, and $169 million in 2013. Capital spending in 2015, 2014, and 2013 was primarily comprised of: (i) network build-out expenditures related to our Services segment, (ii) updates to our information technology infrastructure, and (iii) facility renovations. The decrease in capital spending in 2015, as compared to 2014, was primarily driven by a decrease in facilities and information technology spend. The increase in capital spending in 2014, as compared to 2013, was primarily driven by an increase in revenue-generating network build-out expenditures.

[0000068505-16-000017:mdna:157]
Sales of Property, Plant, and Equipment:  We had $3 million of proceeds related to the sale of property, plant, and equipment in 2015, compared to $33 million in 2014 and $66 million in 2013. The proceeds in all periods were primarily comprised of sales of buildings and land.

[0000068505-16-000017:mdna:158]
Sales of Investments and Businesses:  We received $230 million of proceeds in 2015 compared to $3.4 billion in 2014 and $61 million in 2013. The $230 million of proceeds received in 2015 were primarily comprised of: (i) $49 million reimbursement from Zebra for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale, (ii) $107 million from the sale of two equity investments, (iii) $13 million net cash received from Zebra for the final purchase price adjustment, as well as for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest. The $3.4 billion of cash received in 2014 was primarily comprised of proceeds from the sale of the Enterprise business. The $61 million of proceeds received in 2013 were primarily comprised of proceeds from sales of equity investments.

[0000068505-16-000017:mdna:159]
Financing Activities

[0000068505-16-000017:mdna:160]
Net cash used for financing activities was $2.4 billion in 2015 compared to $1.7 billion in 2014 and $842 million in 2013.  Cash used for financing activities in 2015 was primarily comprised of: (i) $3.2 billion used for purchases of common stock under our share repurchase program and (ii) $277 million of cash used for the payment of dividends, partially offset by: (i) $971 million of net proceeds from the issuance of the Senior Convertible Notes and (ii) $100 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-16-000017:mdna:161]
Cash used for financing activities in 2014 was primarily comprised of: (i) $2.5 billion used for purchases of our common stock under our share repurchase program, (ii) $465 million of cash used for the repayment of debt, and (iii) $318 million of cash used for the payment of dividends, partially offset by: (i) $1.4 billion of net proceeds from the issuance of debt, (ii) $135 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans, and (iii) $93 million of distributions received from discontinued operations.

[0000068505-16-000017:mdna:162]
Cash used for financing activities in 2013 was primarily comprised of: (i) $1.7 billion used for purchases of our common stock under our share repurchase program and (ii) $292 million of cash used for the payment of dividends, partially offset by: (i) $593 million of net proceeds from the issuance of debt, (ii) $365 million of distributions received from discontinued operations, and (iii) $165 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-16-000017:mdna:163]
Current and Long-Term Debt:  We had outstanding long-term debt of $4.4 billion and $3.4 billion, including the current portions of $4 million, at December 31, 2015 and December 31, 2014, respectively.

[0000068505-16-000017:mdna:164]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-16-000017:mdna:165]
During the year ended December 31, 2014, we redeemed $400 million aggregate principal amount outstanding of our 6.000% Senior Notes due November 2017 for an aggregate purchase price of approximately $456 million. After accelerating the amortization of debt issuance costs, debt discounts, and hedge adjustments, we recognized a loss of $37 million related to the redemption within Other income (expense) in the consolidated statements of operations. During the year ended December 31, 2014, we issued an aggregate principal amount of $1.4 billion consisting of: (i) $600 million of 4.000% Senior Notes due 2024, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $583 million, (ii) $400 million of 3.500% Senior Notes due 2021, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $393 million, and (iii) $400 million of 5.500% Senior notes due 2044, of which, after debt issuance costs and debt discounts, we recognized net proceeds of $394 million.

[0000068505-16-000017:mdna:166]
During 2013, we issued an aggregate principal amount of $600 million of 3.50% Senior Notes due March 1, 2023, recognizing net proceeds of $588 million, after debt discount and issuance costs.

[0000068505-16-000017:mdna:167]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. On August 5, 2015, our corporate credit and senior unsecured long-term debt ratings were downgraded by two of the three rating agencies in connection with our capital structure activities. Moody's Investors Service downgraded its Baa2 rating to Baa3 and changed its outlook from stable to negative. Standard & Poor’s Rating Services downgraded its BBB rating to BBB- and maintained its stable outlook. Fitch Ratings confirmed its BBB rating on August 5, 2015 but changed its outlook to negative from stable. We continue to believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty, or volatility in the capital markets or deterioration in our credit ratings may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-16-000017:mdna:168]
In connection with the completion of the acquisition of Airwave, we entered into a new term loan credit agreement (the “Term Loan Agreement”), under which we borrowed a term loan (the “Term Loan”) with an initial principal amount of $675 million. Interest on the Term Loan is variable and indexed to LIBOR. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. Our borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited at the end of the first quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan. However, we believe we will continue to have sufficient liquidity to operate our business.

[0000068505-16-000017:mdna:169]
We may, from time to time, seek to retire certain of our outstanding debt through open market cash purchases, privately-negotiated transactions or otherwise. Such repurchases, if any, will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors.

[0000068505-16-000017:mdna:170]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, and November 4, 2014, the Board of Directors has authorized an aggregate share repurchase amount of up to $12.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2015, we have used approximately $11.0 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $1.0 billion of authority available for future repurchases.

[0000068505-16-000017:mdna:171]
On August 4, 2015, the Board of Directors authorized the Company to commence a modified "Dutch auction" tender offer to repurchase up to $2.0 billion of its outstanding shares of common stock. The repurchase of these shares was authorized under the existing share repurchase authority. The tender offer commenced on August 7, 2015 and expired on September 3,

[0000068505-16-000017:mdna:172]
37

[0000068505-16-000017:mdna:173]
2015. The Company paid $2.0 billion, including transaction costs, to repurchase approximately 30.1 million shares at a tender price of $66.50 per share.

[0000068505-16-000017:mdna:174]
We paid an aggregate of $3.2 billion during 2015, including transaction costs, to repurchase approximately 48.0 million shares at an average price of $66.22 per share. During 2014, we paid an aggregate of $2.5 billion, including transaction costs, to repurchase approximately 39.4 million shares at an average price of $64.63 per share. During 2013, we paid an aggregate of $1.7 billion, including transaction costs, to repurchase approximately 28.6 million shares at an average price of $59.30 per share. All repurchased shares have been retired.

[0000068505-16-000017:mdna:175]
Payment of Dividends:  We paid cash dividends to holders of our common stock of $277 million in 2015, $318 million in 2014, and $292 million in 2013.

[0000068505-16-000017:mdna:176]
Credit Facilities

[0000068505-16-000017:mdna:177]
As of December 31, 2015, we had a $2.1 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2015. We did not borrow under the 2014 Motorola Solutions Credit Agreement during the twelve months ended December 31, 2015.

[0000068505-16-000017:mdna:178]
As of December 31, 2015, we had a letter of credit sub-limit of $450 million under the 2014 Motorola Solutions Credit Agreement. No letters of credit were issued under the revolving credit facility as of December 31, 2015.

[0000068505-16-000017:mdna:179]
Contractual Obligations and Other Purchase Commitments

[0000068505-16-000017:mdna:180]
Summarized in the table and text below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2015.

[0000068505-16-000017:mdna:181]
|  | Payments Due by Period |
| (in millions) | Total |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations | $ | 4,448 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 1,005 |  |  | $ | — |  |  | $ | 3,424 |  |
| Lease obligations | 484 |  |  | 67 |  |  | 57 |  |  | 48 |  |  | 42 |  |  | 37 |  |  | — |  |  | 233 |  |
| Purchase obligations* | 73 |  |  | 57 |  |  | 14 |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Tax obligations | 88 |  |  | 50 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 38 |  |  | — |  |
| Total contractual obligations | $ | 5,093 |  |  | $ | 178 |  |  | $ | 76 |  |  | $ | 55 |  |  | $ | 47 |  |  | $ | 1,042 |  |  | $ | 38 |  |  | $ | 3,657 |  |

[0000068505-16-000017:mdna:182]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-16-000017:mdna:183]
Lease Obligations:  We lease certain office, factory and warehouse space, land, information technology and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations, net of minimum sublease rentals, totaled $484 million. Rental expense, net of sublease income, was $42 million in 2015, $62 million in 2014, and $51 million in 2013.

[0000068505-16-000017:mdna:184]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. We had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2017. The total payments expected to be made under these agreements are $73 million, of which $68 million relate to take or pay obligations from arrangements with suppliers for the sourcing of inventory supplies and materials and $5 million relate to information technology software and services arrangements. We do not anticipate the cancellation of any of our take or pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-16-000017:mdna:185]
Tax Obligations:  We have approximately $88 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $50 million tax charge to a $50 million tax benefit, with cash payments not expected to exceed $30 million.

[0000068505-16-000017:mdna:186]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take or pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-16-000017:mdna:187]
We outsource certain corporate functions, such as benefit administration and information technology-related services, under third-party contracts, the longest of which is expected to expire in 2019. Our remaining payments under these contracts

[0000068505-16-000017:mdna:188]
38

[0000068505-16-000017:mdna:189]
are approximately $246 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-16-000017:mdna:190]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance/bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. At December 31, 2015, outstanding Performance Bonds totaled approximately $1.8 billion, compared to $1.6 billion at December 31, 2014. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-16-000017:mdna:191]
Off-Balance Sheet Arrangements:  At December 31, 2015, we had no significant off-balance sheet arrangements other than operating leases and guarantees to third parties as described in Note 11 to the consolidated financial statements and our obligation to settle the embedded conversion option under the Senior Convertible Notes described in Note 4 to the consolidated financial statements.

[0000068505-16-000017:mdna:192]
Long-term Customer Financing Commitments

[0000068505-16-000017:mdna:193]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $112 million at December 31, 2015, compared to $293 million at December 31, 2014. Outstanding commitments decreased during 2015 primarily as a result of two large customer contracts, one of which was converted to an order without long-term financing and the other where the financing commitment was funded and sold.

[0000068505-16-000017:mdna:194]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $47 million at December 31, 2015, compared to $31 million at December 31, 2014. There were $1 million of allowances for losses in 2015 and $14 million of allowances for losses in 2014. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 13%.

[0000068505-16-000017:mdna:195]
Sales of Receivables

[0000068505-16-000017:mdna:196]
From time to time, we sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables. Servicing obligations are limited to collection activities for sold accounts receivables and long-term receivables.

[0000068505-16-000017:mdna:197]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2015, 2014, and 2013:

[0000068505-16-000017:mdna:198]
| Years ended December 31 | 2015 |  | 2014 |  | 2013 |
| Accounts receivable sales proceeds | $ | 29 |  |  | $ | 50 |  |  | $ | 14 |  |
| Long-term receivables sales proceeds | 196 |  |  | 124 |  |  | 131 |  |
| Total proceeds from receivable sales | $ | 225 |  |  | $ | 174 |  |  | $ | 145 |  |

[0000068505-16-000017:mdna:199]
At December 31, 2015, the Company had retained servicing obligations for $668 million of long-term receivables, compared to $496 million of long-term receivables at December 31, 2014.

[0000068505-16-000017:mdna:200]
Adequate Internal Funding Resources

[0000068505-16-000017:mdna:201]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S. and the ability to repatriate funds from foreign jurisdictions.

[0000068505-16-000017:mdna:202]
Other Contingencies

[0000068505-16-000017:mdna:203]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, our businesses may enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a customer to one of these contracts could result in expenses that are far in excess of the revenue received in connection with the contract.

[0000068505-16-000017:mdna:204]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us. Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 18 months, and for amounts not in excess of a percentage of the contract value.

[0000068505-16-000017:mdna:205]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on our consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-16-000017:mdna:206]
Significant Accounting Policies

[0000068505-16-000017:mdna:207]
Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-16-000017:mdna:208]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-16-000017:mdna:209]
Revenue Recognition

[0000068505-16-000017:mdna:210]
Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. We enter into revenue arrangements that may consist of multiple deliverables of our products and services due to the needs of our customers. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. We recognize revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  We recognize revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) stand alone sales of software products or software upgrades, (ii) stand alone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-16-000017:mdna:211]
Products

[0000068505-16-000017:mdna:212]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. We base our estimates of these allowances on historical experience taking into consideration the type of products sold, the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, we defer revenue until the incentive has been finalized with the customer.  We include shipping charges billed to customers in net revenue, and include the related shipping costs in cost of sales.

[0000068505-16-000017:mdna:213]
We sell software and equipment obtained from other companies.  We establish our own pricing and retain related inventory risk, are the primary obligor in sales transactions with customers, and assume the credit risk for amounts billed to customers. Accordingly, we generally recognize revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-16-000017:mdna:214]
Long-Term Contracts

[0000068505-16-000017:mdna:215]
For long-term contracts that involve customization of equipment and/or software, we generally recognize revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). The components of estimated costs to complete a contract and management’s process for reviewing Estimated Costs at Completion and progress toward completion are discussed further below.  Contracts may be combined or segmented in accordance with the applicable criteria under contract accounting principles.  In certain instances, when revenues or costs associated with long-term contracts cannot be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained.

[0000068505-16-000017:mdna:216]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs.  Due to the nature of the work required to be performed under many of our long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. These adjustments may result from positive project performance, and may result in an increase in operating income during the performance of individual contracts. Likewise, these adjustments may result in a decrease in operating income if Estimated Costs at Completion increase. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on Operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2015, 2014, and 2013.  When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-16-000017:mdna:217]
Hardware and Software Services Support

[0000068505-16-000017:mdna:218]
Revenue under equipment and software support and maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term.

[0000068505-16-000017:mdna:219]
Software and Licenses

[0000068505-16-000017:mdna:220]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other revenue recognition criteria are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period of the license.

[0000068505-16-000017:mdna:221]
Multiple-Element Arrangements

[0000068505-16-000017:mdna:222]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements that include products containing software that function together with the equipment to deliver its essential functionality, undelivered software elements that relate to the product's essential software, and undelivered non-software services, deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in our control.

[0000068505-16-000017:mdna:223]
In these arrangements, we allocate revenue to all deliverables based on their relative selling prices.  We use the following hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence (“VSOE”) of fair value, (ii) third-party evidence (“TPE”) of selling price, and (iii) best estimate of selling price (“ESP”).

[0000068505-16-000017:mdna:224]
We determine VSOE based on our normal pricing and discounting practices for the specific product or service when that same product or service is sold separately. In determining VSOE, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate.

[0000068505-16-000017:mdna:225]
When VSOE does not exist, we attempt to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy for many of our products differs from that of our competitors and our offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold by other companies cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE.

[0000068505-16-000017:mdna:226]
When both VSOE and TPE are unavailable, we use ESP. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0000068505-16-000017:mdna:227]
We also consider the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE, TPE, and ESP.

[0000068505-16-000017:mdna:228]
Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above.

[0000068505-16-000017:mdna:229]
Our arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. The revenue for these multiple-element arrangements is allocated to the software deliverable(s) and the non-software deliverable(s) based on the relative selling prices of all of the deliverables in the arrangement using the fair value hierarchy outlined above. In circumstances where we cannot determine VSOE or TPE for any of the deliverables in the arrangement, ESP is used for the purpose of allocating the arrangement consideration between software and non-software deliverables.

[0000068505-16-000017:mdna:230]
We allocate arrangement consideration to multiple software or software-related deliverables, including the sale of software upgrades or software support agreements to previously sold software, in accordance with software accounting guidance. For such arrangements, revenue is allocated to the deliverables based on the relative fair value of each element of the software, and fair value is determined using VSOE. Where VSOE does not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established, whichever occurs first. When the final undelivered software element is post contract support, service revenue is recognized on a ratable basis over the remaining service period. When VSOE of a delivered element has not been established, but VSOE exists for the undelivered elements, we use the residual method to recognize revenue when the fair value of all undelivered elements is determinable. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the arrangement consideration is allocated to the delivered elements and is recognized as revenue.

[0000068505-16-000017:mdna:231]
Inventory Valuation

[0000068505-16-000017:mdna:232]
We record valuation reserves on our inventory for estimated excess or obsolescence. The amount of the reserve is equal to the difference between the cost of the inventory and the estimated market value based upon assumptions about future demand and market conditions. On a quarterly basis, management performs an analysis based on future demand requirement estimates of the underlying inventory to identify reserves needed for excess and obsolescence. In addition, we adjust the carrying value of inventory if the current market value of that inventory is below our cost.

[0000068505-16-000017:mdna:233]
At December 31, 2015 and 2014, Inventories consisted of the following:

[0000068505-16-000017:mdna:234]
| December 31 | 2015 |  | 2014 |
| Finished goods | $ | 151 |  |  | $ | 163 |  |
| Work-in-process and production materials | 287 |  |  | 313 |  |
|  | 438 |  |  | 476 |  |
| Less inventory reserves | (142 | ) |  | (131 | ) |
|  | $ | 296 |  |  | $ | 345 |  |

[0000068505-16-000017:mdna:235]
We balance the need to maintain strategic inventory levels to ensure competitive delivery performance to our customers against the risk of inventory obsolescence due to rapidly changing technology and customer requirements. As reflected above, our inventory reserves represented 32% of the gross inventory balance at December 31, 2015, compared to 28% of the gross inventory balance at December 31, 2014. We have inventory reserves for excess inventory, pending cancellations of product lines due to technology changes, long-life cycle products, lifetime buys at the end of supplier production runs, business exits, and a shift of production to outsourced manufacturing.

[0000068505-16-000017:mdna:236]
If future demand or market conditions are less favorable than those projected by management, additional inventory writedowns may be required.

[0000068505-16-000017:mdna:237]
Income Taxes

[0000068505-16-000017:mdna:238]
We record deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company’s deferred and other tax balances are based on management’s interpretation of the tax regulations and rulings in numerous taxing jurisdictions. Income tax expense and liabilities recognized by the Company also reflect our best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company’s various tax planning strategies and uncertain tax positions. Future tax authority rulings and changes in tax laws and projected levels of taxable income and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company. We evaluate deferred income tax asset balances on a quarterly basis to determine if valuation allowances are required by considering available evidence, including historical and projected taxable income and tax planning strategies that are both prudent and feasible. Tax related interest and penalties are classified as a component of interest expense.

[0000068505-16-000017:mdna:239]
Retirement Benefits

[0000068505-16-000017:mdna:240]
Our benefit obligations and net periodic pension cost (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions.  The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-16-000017:mdna:241]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-16-000017:mdna:242]
There are various assumptions used in calculating the net periodic benefit expense and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.   We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-16-000017:mdna:243]
42

[0000068505-16-000017:mdna:244]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost and the net retirement healthcare expense. Our investment return assumption for the U.S. Pension Benefit Plans and Postretirement Healthcare Benefits Plan was 7.00% in both 2015 and 2014. Our investment return assumption for the Non-U.S. Plan was 5.90% in 2015 and 5.92% in 2014. At December 31, 2015, the pension plans, including the U.S. Pension Benefit Plans and Non-U.S. Plan, and the Postretirement Health Care Benefits Plan investment portfolios were both comprised of approximately 37% equity investments.

[0000068505-16-000017:mdna:245]
A second key assumption is the discount rate. The discount rate assumptions used for pension benefits and postretirement health care benefits reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. pension benefit obligations were 4.73% and 4.30% at December 2015 and 2014, respectively. Our discount rates for measuring our Non-U.S. Plans were 3.57% and 3.19% at December 2015 and 2014, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 4.26% and 3.90% at December 31, 2015 and 2014, respectively.

[0000068505-16-000017:mdna:246]
A final set of assumptions involves the cost drivers of the underlying benefits. The rate of compensation increase is determined based upon long-term plans for such increases. For the Non-U.S. defined benefit plan, we assumed a weighted average rate for future compensation increases of 0.41% and 2.54% for 2015 and 2014, respectively. During 2015, the Non-U.S. defined benefit plan within the United Kingdom was amended to close future benefit accruals to all participants effective December 31, 2015 resulting in a 0% rate for future compensation, contributing to the decrease within the Non-U.S. Plans in 2015 compared to 2014. Benefits under the U.S. Pension Plans have been frozen, and therefore future compensation increases are no longer a relevant assumption in the calculation of the benefit obligation on those plans. Historically, the Company utilized health care cost trend rates to determine the accumulated benefit obligation and net periodic benefit. However, the  Postretirement Health Care Benefits Plan was amended in 2014 such that all eligible participants would receive an annual subsidy for the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.  As such, health care costs are no longer considered necessary to determine the accumulated postretirement benefit obligation.

[0000068505-16-000017:mdna:247]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from eleven to thirty-five years. Prior service costs are being amortized over periods ranging from two to nine years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-16-000017:mdna:248]
Effective on January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, accordingly, will account for it prospectively beginning in 2016. The impact of the change estimate is an anticipated reduction of the interest and service cost components within net periodic cost in 2016 by approximately $20 million for the U.S. Pension Benefit Plans, $6 million for the Non U.S. Pension Benefit Plans, and $2 million for the Postretirement Health Care Benefits Plan compared to the prior year approach.

[0000068505-16-000017:mdna:249]
Valuation and Recoverability of Goodwill

[0000068505-16-000017:mdna:250]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: adverse changes in macroeconomic conditions, adverse changes in the industry or market in which we transact, changes in cost factors negatively impacting earnings and cash flows, negative or declining overall financial performance, events affecting the carrying value or composition of a reporting unit, or a sustained decrease in share price, among others.  Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-16-000017:mdna:251]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Services segments each meet the definition of a reporting unit. We performed a qualitative assessment of goodwill and determined that it was not more-likely-than-

[0000068505-16-000017:mdna:252]
not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2015, 2014, and 2013. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2015, 2014, and 2013, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-16-000017:mdna:253]
Recent Accounting Pronouncements

[0000068505-16-000017:mdna:254]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the our annual reporting period begins after December 15, 2017. ASU 2014-09 allows for both retrospective and modified retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-16-000017:mdna:255]
In April 2015, the FASB issued ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. In adopting the ASU, we will be required to apply a full retrospective approach to all periods presented. This guidance will be effective January 1, 2016 and, upon adoption, debt issuance costs capitalized in other assets in the consolidated balance sheet will be reclassified and presented as a reduction to long-term debt. As of December 31, 2015, debt issuance costs, net of accumulated amortization, recognized in the consolidated balance sheet were $41 million.

[0000068505-16-000017:mdna:256]
In November 2015, the FASB issued ASU 2015-17 “Balance Sheet Classification of Deferred Taxes” (ASU 2015-17). ASU 2015-17 simplifies current guidance, which requires entities to separately present deferred tax assets and deferred tax liabilities as current and noncurrent in a classified balance sheet. ASU 2015-17 is effective for the Company’s fiscal year 2017, however, early adoption is allowed. We have adopted the standard on a prospective basis as of December 31, 2015. Prior period amounts have not been adjusted to reflect this presentation. The standard reduces the complexity in the preparation of the income tax provision and simplifies the presentation of the deferred taxes in our consolidated balance sheet.

[0000068505-16-000017:mdna:257]
Forward-Looking Statements

[0000068505-16-000017:mdna:258]
risks, (b) future hedging activity and expectations of the Company, and (c) the ability of counterparties to financial instruments to perform their obligations.

[0000068505-16-000017:mdna:259]
Some of the risk factors that affect our business and financial results are discussed in “Item 1A: Risk Factors.” We caution the reader that the risk factors discussed in “Item 1A: Risk Factors,” and those described elsewhere in this report or in our other Securities and Exchange Commission filings, could cause our actual results to differ materially from those stated in the forward-looking statements.
