# MSI notes — 0000068505-21-000027


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-21-000027:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of October 2, 2021 and for the three and nine months ended October 2, 2021 and September 26, 2020 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity (Deficit), and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-21-000027:notes:2]
[same as prior period, unchanged from 0000068505-21-000021:notes:2]

[0000068505-21-000027:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2020 (the "Form 10-K"). The results of operations for the three and nine months ended October 2, 2021 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-21-000027:notes:4]
[same as prior period, unchanged from 0000068505-21-000021:notes:4]

[0000068505-21-000027:notes:5]
[same as prior period, unchanged from 0000068505-21-000021:notes:5]

[0000068505-21-000027:notes:6]
As further described in the Form 10-K, during the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within the Company's reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which the Company refers to as “technologies” in this Quarterly Report on Form 10-Q (this “Form 10-Q”)): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control, and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended October 2, 2021.

[0000068505-21-000027:notes:7]
[same as prior period, unchanged from 0000068505-21-000021:notes:7]

[0000068505-21-000027:notes:8]
[same as prior period, unchanged from 0000068505-21-000021:notes:8]

[0000068505-21-000027:notes:9]
[same as prior period, unchanged from 0000068505-21-000021:notes:9]

[0000068505-21-000027:notes:10]
[same as prior period, unchanged from 0000068505-21-000021:notes:10]

[0000068505-21-000027:notes:11]
Subsequent to quarter end, on October 29, 2021, the Company acquired Envysion, Inc. ("Envysion"), a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video Security and Access Control. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete.

[0000068505-21-000027:notes:12]
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-21-000027:notes:13]
[same as prior period, unchanged from 0000068505-21-000021:notes:12]

[0000068505-21-000027:notes:14]
[same as prior period, unchanged from 0000068505-21-000021:notes:13]

[0000068505-21-000027:notes:15]
[same as prior period, unchanged from 0000068505-21-000021:notes:14]

[0000068505-21-000027:notes:16]
[same as prior period, unchanged from 0000068505-21-000021:notes:15]

[0000068505-21-000027:notes:17]
[same as prior period, unchanged from 0000068505-21-000021:notes:16]

[0000068505-21-000027:notes:18]
[same as prior period, unchanged from 0000068505-21-000021:notes:17]

[0000068505-21-000027:notes:19]
In August 2020, the FASB issued ASU No. 2020-06, "Debt - Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40) - Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity," which simplifies the accounting for certain financial instruments with characteristics of liabilities and equity, including convertible instruments. The new guidance removes the separation models for convertible debt with a cash conversion feature or a beneficial conversion feature. In addition, the new standard provides guidance on calculating the dilutive impact of convertible debt on earnings per share. The ASU clarifies that the average market price should be used to calculate the diluted earnings per share denominator when the exercise price or the number of shares that may be issued is variable. The ASU is effective for the Company on January 1, 2022, including interim periods, with early adoption permitted. The ASU permits the use of either a full or modified retrospective method of adoption. The Company is still evaluating the impact of the adoption of this ASU on its financial statements and disclosures.

[0000068505-21-000027:notes:20]
Recently Adopted Accounting Pronouncements

[0000068505-21-000027:notes:21]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740),” which simplifies the accounting for income taxes by removing certain exceptions and streamlining other areas of accounting for income taxes. Portions of the amendment within the ASU require retrospective, modified retrospective or prospective adoption methods. The Company adopted ASU No. 2019-12 as of January 1, 2021 on a prospective basis and the adoption of this standard did not have a material impact on its financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-21-000027:notes:22]
[same as prior period, unchanged from 0000068505-21-000021:notes:21]

[0000068505-21-000027:notes:23]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and nine months ended October 2, 2021 and September 26, 2020, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-21-000027:notes:24]
|  | Three Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |  | $ | 863 |  |  | $ | 405 |  |  | $ | 1,268 |  |
| International | 333 |  |  | 325 |  |  | 658 |  |  | 300 |  |  | 300 |  |  | 600 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |  | $ | 989 |  |  | $ | 510 |  |  | $ | 1,499 |  |
| Video Security and Access Control | 214 |  |  | 102 |  |  | 316 |  |  | 174 |  |  | 77 |  |  | 251 |  |
| Command Center Software | — |  |  | 133 |  |  | 133 |  |  | — |  |  | 118 |  |  | 118 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 838 |  |  | $ | 703 |  |  | $ | 1,541 |  |  | $ | 733 |  |  | $ | 637 |  |  | $ | 1,370 |  |
| Indirect | 487 |  |  | 79 |  |  | 566 |  |  | 430 |  |  | 68 |  |  | 498 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |

[0000068505-21-000027:notes:25]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |  | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 3,476 |  |
| International | 935 |  |  | 970 |  |  | 1,905 |  |  | 794 |  |  | 871 |  |  | 1,665 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |  | $ | 2,685 |  |  | $ | 1,480 |  |  | $ | 4,165 |  |
| Video Security and Access Control | 590 |  |  | 284 |  |  | 874 |  |  | 439 |  |  | 196 |  |  | 635 |  |
| Command Center Software | — |  |  | 387 |  |  | 387 |  |  | — |  |  | 341 |  |  | 341 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,148 |  |  | $ | 2,099 |  |  | $ | 4,247 |  |  | $ | 2,008 |  |  | $ | 1,869 |  |  | $ | 3,877 |  |
| Indirect | 1,390 |  |  | 214 |  |  | 1,604 |  |  | 1,116 |  |  | 148 |  |  | 1,264 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |

[0000068505-21-000027:notes:26]
[same as prior period, unchanged from 0000068505-21-000021:notes:25]

[0000068505-21-000027:notes:27]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction values associated with remaining performance obligations which were not yet satisfied as of October 2, 2021 was $7.1 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of October 2, 2021, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. A total of $3.5 billion was from Software and Services performance obligations that were not yet satisfied as of October 2, 2021. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. The Company expects to recognize $1.5 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-21-000027:notes:28]
[same as prior period, unchanged from 0000068505-21-000021:notes:27]

[0000068505-21-000027:notes:29]
| (In millions) | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Accounts receivable, net | $ | 1,196 |  |  | $ | 1,390 |  |  |  |  |  |
| Contract assets | 1,030 |  |  | 933 |  |  |  |  |  |
| Contract liabilities | 1,538 |  |  | 1,554 |  |  |  |  |  |
| Non-current contract liabilities | 309 |  |  | 283 |  |  |  |  |  |

[0000068505-21-000027:notes:30]
Revenue recognized during the three months ended October 2, 2021 which was previously included in Contract liabilities as of July 3, 2021 was $472 million, compared to $349 million of revenue recognized during the three months ended September 26, 2020 which was previously included in Contract liabilities as of June 27, 2020. Revenue recognized during the nine months ended October 2, 2021 which was previously included in Contract liabilities as of December 31, 2020 was $946 million, compared to $807 million recognized during the nine months ended September 26, 2020 which was previously included in Contract liabilities as of December 31, 2019. Revenue of $2 million and $15 million was reversed during the three and nine months ended October 2, 2021, respectively, related to performance obligations satisfied or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $12 million and $48 million of reversals for the three and nine months ended September 26, 2020, respectively.

[0000068505-21-000027:notes:31]
There were no material expected credit losses recorded on contract assets during each of the three and nine months ended October 2, 2021 and September 26, 2020.

[0000068505-21-000027:notes:32]
[same as prior period, unchanged from 0000068505-21-000021:notes:31]

[0000068505-21-000027:notes:33]
| (In millions) | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Current contract cost assets | $ | 26 |  |  | $ | 23 |  |  |  |  |  |
| Non-current contract cost assets | 113 |  |  | 105 |  |  |  |  |  |

[0000068505-21-000027:notes:34]
Amortization of non-current contract cost assets was $12 million and $37 million for the three and nine months ended October 2, 2021, respectively, and $13 million and $35 million for the three and nine months ended September 26, 2020, respectively


## us-gaap:LesseeOperatingLeasesTextBlock

[0000068505-21-000027:notes:35]
[same as prior period, unchanged from 0000068505-21-000021:notes:34]

[0000068505-21-000027:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 34 |  |  | $ | 34 |  |  | $ | 101 |  |  | $ | 101 |  |
| Finance lease cost |  |  |  |  |  |  |  |
| Amortization of right-of-use assets | 2 |  |  | 3 |  |  | 8 |  |  | 9 |  |
| Interest on lease liabilities | — |  |  | — |  |  | — |  |  | 1 |  |
| Total finance lease cost | 2 |  |  | 3 |  |  | 8 |  |  | 10 |  |
| Short-term lease cost | — |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Variable cost | 9 |  |  | 10 |  |  | 27 |  |  | 27 |  |
| Sublease income | (2) |  |  | (2) |  |  | (4) |  |  | (4) |  |
| Net lease expense | $ | 43 |  |  | $ | 46 |  |  | $ | 134 |  |  | $ | 136 |  |

[0000068505-21-000027:notes:37]
[same as prior period, unchanged from 0000068505-21-000021:notes:36]

[0000068505-21-000027:notes:38]
| (in millions) |  | Statement Line Classification |  | October 2, 2021 |  | December 31, 2020 |  |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Operating lease assets |  | $ | 405 |  |  | $ | 468 |  |  |  |
| Finance lease assets |  | Property, plant, and equipment, net |  | 19 |  |  | 30 |  |  |  |
|  |  |  |  | $ | 424 |  |  | $ | 498 |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Accrued liabilities |  | $ | 125 |  |  | $ | 126 |  |  |  |
| Finance lease liabilities |  | Current portion of long-term debt |  | 6 |  |  | 11 |  |  |  |
|  |  |  |  | $ | 131 |  |  | $ | 137 |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | $ | 321 |  |  | $ | 402 |  |  |  |
| Finance lease liabilities |  | Long-term debt |  | 1 |  |  | 5 |  |  |  |
|  |  |  |  | $ | 322 |  |  | $ | 407 |  |  |  |

[0000068505-21-000027:notes:39]
[same as prior period, unchanged from 0000068505-21-000021:notes:38]

[0000068505-21-000027:notes:40]
|  | Nine Months Ended |  |  |
| (in millions) | October 2, 2021 |  | September 26, 2020 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 124 |  |  | $ | 116 |  |  |  |
| Net cash used for operating activities related to finance leases | — |  |  | 1 |  |  |  |
| Net cash used for financing activities related to finance leases | 9 |  |  | 9 |  |  |  |
| Assets obtained in exchange for lease liabilities: |  |  |  |  |  |
| Operating leases | $ | 31 |  |  | $ | 64 |  |  |  |

[0000068505-21-000027:notes:41]
|  | October 2, 2021 |  | December 31, 2020 |
| Weighted average remaining lease terms (years): |  |  |  |
| Operating leases | 6 |  | 6 |
| Finance leases | 1 |  | 2 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.16 | % |  | 3.30 | % |
| Finance leases | 4.09 | % |  | 4.21 | % |

[0000068505-21-000027:notes:42]
[same as prior period, unchanged from 0000068505-21-000021:notes:41]

[0000068505-21-000027:notes:43]
|  | October 2, 2021 |
| (in millions) | Operating Leases |  | Finance Leases |  | Total |
| Remainder of 2021 | $ | 20 |  |  | $ | 2 |  |  | $ | 22 |  |
| 2022 | 134 |  |  | 4 |  |  | 138 |  |
| 2023 | 80 |  |  | 1 |  |  | 81 |  |
| 2024 | 66 |  |  | — |  |  | 66 |  |
| 2025 | 52 |  |  | — |  |  | 52 |  |
| Thereafter | 141 |  |  | — |  |  | 141 |  |
| Total lease payments | 493 |  |  | 7 |  |  | 500 |  |
| Less: interest | 47 |  |  | — |  |  | 47 |  |
| Present value of lease liabilities | $ | 446 |  |  | $ | 7 |  |  | $ | 453 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-21-000027:notes:44]
[same as prior period, unchanged from 0000068505-21-000021:notes:43]

[0000068505-21-000027:notes:45]
[same as prior period, unchanged from 0000068505-21-000021:notes:44]

[0000068505-21-000027:notes:46]
[same as prior period, unchanged from 0000068505-21-000021:notes:45]

[0000068505-21-000027:notes:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 56 |  |  | $ | 54 |  |  | $ | 172 |  |  | $ | 158 |  |
| Reorganization of business (Note 14) | 2 |  |  | 10 |  |  | 22 |  |  | 48 |  |
| Operating lease asset impairments | — |  |  | — |  |  | 7 |  |  | — |  |
| Acquisition-related transaction fees | 2 |  |  | 5 |  |  | 6 |  |  | 8 |  |
| Losses on legal settlements | — |  |  | — |  |  | 3 |  |  | 9 |  |
| Fixed asset impairment | — |  |  | — |  |  | — |  |  | 5 |  |
| Gain on sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | (50) |  |
| Other | — |  |  | — |  |  | (1) |  |  | — |  |
|  | $ | 60 |  |  | $ | 69 |  |  | $ | 209 |  |  | $ | 178 |  |

[0000068505-21-000027:notes:48]
During the nine months ended October 2, 2021, the Company recognized $7 million of operating lease asset impairments relating to the consolidation of acquired U.S. manufacturing and distribution facilities. This loss has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-21-000027:notes:49]
During the nine months ended September 26, 2020, the Company recorded a $50 million gain on the sale of a manufacturing facility in Europe. This gain has been recognized in Other charges in the Company's Condensed Consolidated Statements of Operations.

[0000068505-21-000027:notes:50]
[same as prior period, unchanged from 0000068505-21-000021:notes:49]

[0000068505-21-000027:notes:51]
[same as prior period, unchanged from 0000068505-21-000021:notes:50]

[0000068505-21-000027:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (58) |  |  | $ | (60) |  |  | $ | (160) |  |  | $ | (175) |  |
| Interest income | 2 |  |  | 2 |  |  | 6 |  |  | 8 |  |
|  | $ | (56) |  |  | $ | (58) |  |  | $ | (154) |  |  | (167) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 31 |  |  | $ | 20 |  |  | $ | 91 |  |  | $ | 60 |  |
| Loss from the extinguishment of long-term debt (Note 5) | — |  |  | (56) |  |  | (18) |  |  | (56) |  |
| Foreign currency gain (loss) | 5 |  |  | (15) |  |  | 13 |  |  | (19) |  |
| Gain (loss) on derivative instruments | (10) |  |  | 10 |  |  | (19) |  |  | 6 |  |
| Gains on equity method investments | 1 |  |  | 1 |  |  | 5 |  |  | 1 |  |
| Fair value adjustments to equity investments | (18) |  |  | (4) |  |  | (5) |  |  | 1 |  |
| Other | 1 |  |  | 2 |  |  | 3 |  |  | (1) |  |
|  | $ | 10 |  |  | $ | (42) |  |  | $ | 70 |  |  | $ | (8) |  |

[0000068505-21-000027:notes:53]
[same as prior period, unchanged from 0000068505-21-000021:notes:52]

[0000068505-21-000027:notes:54]
[same as prior period, unchanged from 0000068505-21-000021:notes:53]

[0000068505-21-000027:notes:55]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 307 |  |  | $ | 205 |  |  | $ | 844 |  |  | $ | 537 |  |
| Weighted average common shares outstanding | 169.2 |  |  | 169.7 |  |  | 169.3 |  |  | 170.1 |  |
| Per share amount | $ | 1.81 |  |  | $ | 1.21 |  |  | $ | 4.98 |  |  | $ | 3.16 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 307 |  |  | $ | 205 |  |  | $ | 844 |  |  | $ | 537 |  |
| Weighted average common shares outstanding | 169.2 |  |  | 169.7 |  |  | 169.3 |  |  | 170.1 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 4.3 |  |  | 3.8 |  |  | 3.9 |  |  | 4.2 |  |
| 1.75% senior convertible notes | 0.6 |  |  | — |  |  | 0.2 |  |  | — |  |
| Diluted weighted average common shares outstanding | 174.1 |  |  | 173.5 |  |  | 173.4 |  |  | 174.3 |  |
| Per share amount | $ | 1.76 |  |  | $ | 1.18 |  |  | $ | 4.87 |  |  | $ | 3.08 |  |

[0000068505-21-000027:notes:56]
In the computation of diluted earnings per common share for the nine months ended October 2, 2021, the assumed exercise of 0.2 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-21-000027:notes:57]
In the computation of diluted earnings per common share for the three months ended September 26, 2020, the assumed exercise of 0.5 million options, including 0.2 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive. For the nine months ended September 26, 2020, the assumed exercise of 0.4 million options, including 0.1 million subject to market based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-21-000027:notes:58]
As of October 2, 2021, the Company had $1.0 billion of 1.75% Senior Convertible Notes outstanding which mature on September 15, 2024 ("Senior Convertible Notes"). The notes became fully convertible as of September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash. Because of the Company’s intention to settle the principal amount of the Senior Convertible Notes in cash, the Company did not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price, which first occurred for the period ended October 2, 2021. The Company included the number of shares that would be issuable upon conversion (under the treasury stock method of accounting for share dilution) in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price for the period ended October 2, 2021. The value by which the Senior Convertible Notes exceeded their principal amount if converted as of October 2, 2021 was $188 million.

[0000068505-21-000027:notes:59]
[same as prior period, unchanged from 0000068505-21-000021:notes:59]

[0000068505-21-000027:notes:60]
[same as prior period, unchanged from 0000068505-21-000021:notes:60]

[0000068505-21-000027:notes:61]
[same as prior period, unchanged from 0000068505-21-000021:notes:61]

[0000068505-21-000027:notes:62]
|  | October 2, 2021 |  | December 31, 2020 |
| Accounts receivable | $ | 1,267 |  |  | $ | 1,465 |  |
| Less allowance for credit losses | (71) |  |  | (75) |  |
|  | $ | 1,196 |  |  | $ | 1,390 |  |

[0000068505-21-000027:notes:63]
[same as prior period, unchanged from 0000068505-21-000021:notes:63]

[0000068505-21-000027:notes:64]
[same as prior period, unchanged from 0000068505-21-000021:notes:64]

[0000068505-21-000027:notes:65]
|  | October 2, 2021 |  | December 31, 2020 |
| Finished goods | $ | 251 |  |  | $ | 271 |  |
| Work-in-process and production materials | 484 |  |  | 360 |  |
|  | 735 |  |  | 631 |  |
| Less inventory reserves | (131) |  |  | (123) |  |
|  | $ | 604 |  |  | $ | 508 |  |

[0000068505-21-000027:notes:66]
[same as prior period, unchanged from 0000068505-21-000021:notes:66]

[0000068505-21-000027:notes:67]
[same as prior period, unchanged from 0000068505-21-000021:notes:67]

[0000068505-21-000027:notes:68]
|  | October 2, 2021 |  | December 31, 2020 |
| Current contract cost assets (Note 2) | $ | 26 |  |  | $ | 23 |  |
| Tax-related deposits | 44 |  |  | 52 |  |
| Other | 182 |  |  | 167 |  |
|  | $ | 252 |  |  | $ | 242 |  |

[0000068505-21-000027:notes:69]
[same as prior period, unchanged from 0000068505-21-000021:notes:69]

[0000068505-21-000027:notes:70]
[same as prior period, unchanged from 0000068505-21-000021:notes:70]

[0000068505-21-000027:notes:71]
|  | October 2, 2021 |  | December 31, 2020 |
| Land | $ | 5 |  |  | $ | 6 |  |
| Leasehold improvements | 474 |  |  | 439 |  |
| Machinery and equipment | 2,390 |  |  | 2,276 |  |
|  | 2,869 |  |  | 2,721 |  |
| Less accumulated depreciation | (1,848) |  |  | (1,699) |  |
|  | $ | 1,021 |  |  | $ | 1,022 |  |

[0000068505-21-000027:notes:72]
Depreciation expense for both the three months ended October 2, 2021 and September 26, 2020 was $49 million. Depreciation expense for the nine months ended October 2, 2021 and September 26, 2020 was $153 million and $142 million, respectively.

[0000068505-21-000027:notes:73]
[same as prior period, unchanged from 0000068505-21-000021:notes:73]

[0000068505-21-000027:notes:74]
[same as prior period, unchanged from 0000068505-21-000021:notes:74]

[0000068505-21-000027:notes:75]
|  | October 2, 2021 |  | December 31, 2020 |  |  |  |  |
| Common stock | $ | 67 |  |  | $ | 19 |  |  |  |  |  |
| Strategic investments, at cost | 41 |  |  | 46 |  |  |  |  |  |
| Company-owned life insurance policies | 81 |  |  | 77 |  |  |  |  |  |
| Equity method investments | 25 |  |  | 16 |  |  |  |  |  |
|  | $ | 214 |  |  | $ | 158 |  |  |  |  |  |

[0000068505-21-000027:notes:76]
On July 16, 2021, the Company paid $50 million for equity securities of NewHold Investment Corp. ("NHIC"), a special purpose acquisition company (SPAC) that completed a business combination with Evolv Technologies, Inc. After the business combination, NHIC was renamed “Evolv Technologies Holdings, Inc.” (together with its subsidiaries, “Evolv”). Evolv is a global leader in weapons detection security screening. The equity securities are carried at fair value with changes in fair value recorded in Other, net within Other income (expense). During the three months ended October 2, 2021, the Company recognized a loss of $20 million in Other income (expense) related to a decrease in the fair value of the investment.

[0000068505-21-000027:notes:77]
[same as prior period, unchanged from 0000068505-21-000021:notes:77]

[0000068505-21-000027:notes:78]
[same as prior period, unchanged from 0000068505-21-000021:notes:78]

[0000068505-21-000027:notes:79]
|  | October 2, 2021 |  | December 31, 2020 |
| Defined benefit plan assets | $ | 348 |  |  | $ | 283 |  |
| Non-current contract cost assets (Note 2) | 113 |  |  | 105 |  |
| Other | 69 |  |  | 94 |  |
|  | $ | 530 |  |  | $ | 482 |  |

[0000068505-21-000027:notes:80]
[same as prior period, unchanged from 0000068505-21-000021:notes:80]

[0000068505-21-000027:notes:81]
[same as prior period, unchanged from 0000068505-21-000021:notes:81]

[0000068505-21-000027:notes:82]
|  | October 2, 2021 |  | December 31, 2020 |
| Compensation | $ | 264 |  |  | $ | 291 |  |
| Tax liabilities | 107 |  |  | 147 |  |
| Dividend payable | 120 |  |  | 120 |  |
| Trade liabilities | 185 |  |  | 164 |  |
| Operating lease liabilities (Note 3) | 125 |  |  | 126 |  |
| Other | 464 |  |  | 463 |  |
|  | $ | 1,265 |  |  | $ | 1,311 |  |

[0000068505-21-000027:notes:83]
[same as prior period, unchanged from 0000068505-21-000021:notes:83]

[0000068505-21-000027:notes:84]
[same as prior period, unchanged from 0000068505-21-000021:notes:84]

[0000068505-21-000027:notes:85]
|  | October 2, 2021 |  | December 31, 2020 |
| Defined benefit plans | $ | 1,465 |  |  | $ | 1,578 |  |
| Non-current contract liabilities (Note 2) | 309 |  |  | 283 |  |
| Deferred income taxes | 170 |  |  | 180 |  |
| Other | 289 |  |  | 322 |  |
|  | $ | 2,233 |  |  | $ | 2,363 |  |

[0000068505-21-000027:notes:86]
[same as prior period, unchanged from 0000068505-21-000021:notes:86]

[0000068505-21-000027:notes:87]
Share Repurchase Program: During the three and nine months ended October 2, 2021, the Company repurchased approximately 0.6 million and 2.0 million shares at an average price of $234.18 and $199.88 per share for an aggregate of $137 million and $409 million, respectively, including transaction costs. The Company paid $125 million and $397 million to settle share repurchases during the three and nine months ended October 2, 2021, respectively. In May of 2021, the Board of Directors approved a $2.0 billion increase to the share repurchase program. As of October 2, 2021, the Company had $2.2 billion of authority available for future repurchases.

[0000068505-21-000027:notes:88]
Payment of Dividends: During the three months ended October 2, 2021 and September 26, 2020, the Company paid $120 million and $109 million, respectively, in cash dividends to holders of its common stock. During the nine months ended October 2, 2021 and September 26, 2020, the Company paid $362 million and $327 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $120 million in cash dividends to holders of its common stock.

[0000068505-21-000027:notes:89]
[same as prior period, unchanged from 0000068505-21-000021:notes:89]

[0000068505-21-000027:notes:90]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and nine months ended October 2, 2021 and September 26, 2020:

[0000068505-21-000027:notes:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (335) |  |  | $ | (470) |  |  | $ | (360) |  |  | $ | (410) |  |
| Other comprehensive income (loss) before reclassification adjustment | (47) |  |  | 34 |  |  | (24) |  |  | (27) |  |
| Tax benefit (expense) | 3 |  |  | (4) |  |  | 5 |  |  | (3) |  |
| Other comprehensive income (loss), net of tax | (44) |  |  | 30 |  |  | (19) |  |  | (30) |  |
| Balance at end of period | $ | (379) |  |  | $ | (440) |  |  | $ | (379) |  |  | $ | (440) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (2,053) |  |  | $ | (2,005) |  |  | $ | (2,086) |  |  | $ | (2,030) |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 22 |  |  | 20 |  |  | 65 |  |  | 58 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | (2) |  |  | (4) |  |  | (6) |  |  | (12) |  |
| Tax benefit | (4) |  |  | (4) |  |  | (10) |  |  | (9) |  |
| Other comprehensive income, net of tax | 16 |  |  | 12 |  |  | 49 |  |  | 37 |  |
| Balance at end of period | $ | (2,037) |  |  | $ | (1,993) |  |  | $ | (2,037) |  |  | $ | (1,993) |  |
| Total Accumulated other comprehensive loss | $ | (2,416) |  |  | $ | (2,433) |  |  | $ | (2,416) |  |  | $ | (2,433) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-21-000027:notes:92]
Debt and Credit Facilities

[0000068505-21-000027:notes:93]
|  | October 2, 2021 |  | December 31, 2020 |
| 3.5% senior notes due 2023 | $ | — |  |  | $ | 323 |  |
| 4.0% senior notes due 2024 | 584 |  |  | 583 |  |
| 1.75% senior convertible notes due 2024 | 1,000 |  |  | 995 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 4.6% senior notes due 2028 | 693 |  |  | 692 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 4.6% senior notes due 2029 | 803 |  |  | 803 |  |
| 2.3% senior notes due 2030 | 892 |  |  | 892 |  |
| 2.75% senior notes due 2031 | 844 |  |  | — |  |
| 6.625% senior notes due 2037 | 37 |  |  | 37 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 92 |  |  | 92 |  |
| Other long-term debt | 8 |  |  | 18 |  |
|  | 5,695 |  |  | 5,177 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (2) |  |  | (2) |  |
| Less: current portion | (6) |  |  | (12) |  |
| Long-term debt | $ | 5,687 |  |  | $ | 5,163 |  |

[0000068505-21-000027:notes:94]
In May of 2021, the Company issued $850 million of 2.75% senior notes due 2031. The Company recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of its outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, the Company recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in the Condensed Consolidated Statements of Operations.

[0000068505-21-000027:notes:95]
As of October 2, 2021, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at the Company's option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing the Company to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 2, 2021.

[0000068505-21-000027:notes:96]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of October 2, 2021 the Company had no outstanding debt under the commercial paper program.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-21-000027:notes:97]
[same as prior period, unchanged from 0000068505-21-000021:notes:97]

[0000068505-21-000027:notes:98]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.2 billion for each of the periods ended October 2, 2021 and December 31, 2020. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-21-000027:notes:99]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of October 2, 2021, and the corresponding positions as of December 31, 2020:

[0000068505-21-000027:notes:100]
|  | Notional Amount |
| Net Buy (Sell) by Currency | October 2, 2021 |  | December 31, 2020 |
| Euro | $ | 169 |  |  | $ | 177 |  |
| British pound | 74 |  |  | 86 |  |
| Canadian dollar | 59 |  |  | 61 |  |
| Australian dollar | (82) |  |  | (88) |  |
| Chinese renminbi | (80) |  |  | (90) |  |

[0000068505-21-000027:notes:101]
[same as prior period, unchanged from 0000068505-21-000021:notes:101]

[0000068505-21-000027:notes:102]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of October 2, 2021, all of the counterparties had investment grade credit ratings. As of October 2, 2021, the Company had $13 million of exposure to aggregate credit risk with all counterparties.

[0000068505-21-000027:notes:103]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of October 2, 2021 and December 31, 2020:

[0000068505-21-000027:notes:104]
|  | Fair Values of Derivative Instruments |
| October 2, 2021 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 11 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 2 |  |  | 7 |  |
| Total derivatives | $ | 13 |  |  | $ | 7 |  |

[0000068505-21-000027:notes:105]
[same as prior period, unchanged from 0000068505-21-000021:notes:105]

[0000068505-21-000027:notes:106]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and nine months ended October 2, 2021 and September 26, 2020:

[0000068505-21-000027:notes:107]
|  | Financial Statement Location | Three Months Ended |  | Nine Months Ended |
| Foreign Exchange Contracts | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Effective portion | Accumulated othercomprehensive loss | $ | 7 |  |  | $ | (5) |  |  | $ | 10 |  |  | $ | 3 |  |
| Forward points recognized | Other income (expense) | — |  |  | — |  |  | 1 |  |  | 2 |  |
| Undesignated derivatives recognized | Other income (expense) | (10) |  |  | 10 |  |  | (19) |  |  | 6 |  |

[0000068505-21-000027:notes:108]
[same as prior period, unchanged from 0000068505-21-000021:notes:108]

[0000068505-21-000027:notes:109]
The Company uses foreign exchange forward contracts with contract terms of 12 to 15 months to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of October 2, 2021, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £125 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-21-000027:notes:110]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the excluded components will be amortized on a straight line basis and recognized through interest expense. During the nine months ended October 2, 2021 and September 26, 2020, the Company amortized $1 million and $2 million of income from the excluded components through interest expense, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-21-000027:notes:111]
[same as prior period, unchanged from 0000068505-21-000021:notes:111]

[0000068505-21-000027:notes:112]
[same as prior period, unchanged from 0000068505-21-000021:notes:112]

[0000068505-21-000027:notes:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Net earnings before income taxes | $ | 405 |  |  | $ | 251 |  |  | $ | 1,034 |  |  | $ | 652 |  |
| Income tax expense | 97 |  |  | 45 |  |  | 186 |  |  | 112 |  |
| Effective tax rate | 24 | % |  | 18 | % |  | 18 | % |  | 17 | % |

[0000068505-21-000027:notes:114]
The effective tax rate for the three months ended October 2, 2021 of 24% was higher than the U.S. federal statutory tax rate of 21% due to state tax expense, offset by the recognition of excess tax benefits of share-based compensation. The effective tax rate for the nine months ended October 2, 2021 of 18% was lower than the U.S. federal statutory tax rate of 21% due to state tax expense, offset by a tax benefit related to a partial release of $33 million of a valuation allowance recorded on the U.S foreign tax credit carryforward and the recognition of excess tax benefits of share-based compensation.

[0000068505-21-000027:notes:115]
The effective tax rates for the three and nine months ended September 26, 2020 of 18% and 17%, respectively, were lower than the U.S. federal statutory tax rate of 21% due to state tax expense, offset by excess tax benefits on share-based compensation and favorable U.S. return-to-provision adjustments.

[0000068505-21-000027:notes:116]
The effective tax rate for the three months ended October 2, 2021 of 24% was higher than the effective tax rate for the three months ended September 26, 2020 of 18%, primarily due to favorable U.S. return-to-provision adjustments and higher tax benefits from share-based compensation in 2020 compared to 2021. The effective tax rate for the nine months ended October 2, 2021 of 18% was higher than the effective tax rate for the nine months ended September 26, 2020 of 17%, primarily due to favorable U.S. return-to-provision adjustments and excess share-based compensation in 2020, which exceeded the tax benefit realized in 2021 related to a partial release of a valuation allowance of $33 million.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-21-000027:notes:117]
[same as prior period, unchanged from 0000068505-21-000021:notes:117]

[0000068505-21-000027:notes:118]
[same as prior period, unchanged from 0000068505-21-000021:notes:118]

[0000068505-21-000027:notes:119]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 29 |  |  | 36 |  |  | 5 |  |  | 7 |  |  | — |  |  | — |  |
| Expected return on plan assets | (59) |  |  | (57) |  |  | (25) |  |  | (21) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 17 |  |  | 15 |  |  | 4 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (1) |  |  | (1) |  |  | (1) |  |  | (3) |  |
| Net periodic pension benefits | $ | (13) |  |  | $ | (6) |  |  | $ | (17) |  |  | $ | (11) |  |  | $ | (3) |  |  | $ | (5) |  |

[0000068505-21-000027:notes:120]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 87 |  |  | 108 |  |  | 16 |  |  | 21 |  |  | 1 |  |  | 1 |  |
| Expected return on plan assets | (177) |  |  | (169) |  |  | (75) |  |  | (63) |  |  | (8) |  |  | (8) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 51 |  |  | 44 |  |  | 12 |  |  | 11 |  |  | 2 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | (2) |  |  | (1) |  |  | (4) |  |  | (11) |  |
| Net periodic pension benefits | $ | (39) |  |  | $ | (17) |  |  | $ | (48) |  |  | $ | (31) |  |  | $ | (9) |  |  | $ | (15) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-21-000027:notes:121]
[same as prior period, unchanged from 0000068505-21-000021:notes:121]

[0000068505-21-000027:notes:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 4 |  |  | $ | 3 |  |  | $ | 12 |  |  | $ | 12 |  |
| Selling, general and administrative expenses | 22 |  |  | 18 |  |  | 58 |  |  | 57 |  |
| Research and development expenditures | 8 |  |  | 10 |  |  | 24 |  |  | 31 |  |
| Share-based compensation expense included in Operating earnings | 34 |  |  | 31 |  |  | 94 |  |  | 100 |  |
| Tax benefit | (6) |  |  | (5) |  |  | (14) |  |  | (17) |  |
| Share-based compensation expense, net of tax | $ | 28 |  |  | $ | 26 |  |  | $ | 80 |  |  | $ | 83 |  |
| Decrease in basic earnings per share | $ | (0.17) |  |  | $ | (0.15) |  |  | $ | (0.47) |  |  | $ | (0.49) |  |
| Decrease in diluted earnings per share | $ | (0.16) |  |  | $ | (0.15) |  |  | $ | (0.46) |  |  | $ | (0.48) |  |

[0000068505-21-000027:notes:123]
During the nine months ended October 2, 2021, the Company granted 0.4 million restricted stock units (RSUs), 0.1 million performance stock units (PSUs) and 0.1 million market stock units (MSUs) with an aggregate grant-date fair value of $72 million, $15 million, and $10 million, respectively, and 0.2 million stock options and 0.2 million performance options (POs) with an aggregate grant-date fair value of $8 million and $10 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.
During the nine months ended October 2, 2021, the Company granted 0.1 million shares of restricted stock to certain key employees in connection with the acquisition of Openpath, for an aggregate grant-date fair value of $29 million related to compensation withheld from the purchase price, which will be expensed over an average service period of 3 years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-21-000027:notes:124]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of October 2, 2021 and December 31, 2020 were as follows:

[0000068505-21-000027:notes:125]
| October 2, 2021 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 13 |  |  |  |  | $ | 13 |  |
| Common stock | 67 |  |  | — |  |  |  |  | 67 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 7 |  |  |  |  | $ | 7 |  |

[0000068505-21-000027:notes:126]
[same as prior period, unchanged from 0000068505-21-000021:notes:126]

[0000068505-21-000027:notes:127]
The Company had no Level 3 holdings as of October 2, 2021 or December 31, 2020.

[0000068505-21-000027:notes:128]
At October 2, 2021 and December 31, 2020, the Company had $496 million and $448 million, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-21-000027:notes:129]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at October 2, 2021 and December 31, 2020 was $6.3 billion and $5.8 billion (Level 2), respectively.

[0000068505-21-000027:notes:130]
[same as prior period, unchanged from 0000068505-21-000021:notes:130]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-21-000027:notes:131]
[same as prior period, unchanged from 0000068505-21-000021:notes:131]

[0000068505-21-000027:notes:132]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended October 2, 2021 and September 26, 2020:

[0000068505-21-000027:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Contract-specific discounting facility | $ | 66 |  |  | $ | 67 |  |  | $ | 173 |  |  | $ | 165 |  |
| Accounts receivable sales proceeds | 15 |  |  | 15 |  |  | 23 |  |  | 73 |  |
| Long-term receivables sales proceeds | 56 |  |  | 45 |  |  | 140 |  |  | 115 |  |
| Total proceeds from receivable sales | $ | 137 |  |  | $ | 127 |  |  | $ | 336 |  |  | $ | 353 |  |

[0000068505-21-000027:notes:134]
At October 2, 2021, the Company had retained servicing obligations for $933 million of long-term receivables, compared to $983 million at December 31, 2020. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $79 million at October 2, 2021, compared to $78 million at December 31, 2020.

[0000068505-21-000027:notes:135]
During the three and nine months ended October 2, 2021, the Company utilized a contract-specific receivable discounting facility which began during the nine months ended September 26, 2020, resulting in accounts receivable sales of $66 million and $173 million, respectively. The proceeds of the Company's receivable sales are included in Operating activities within the Company's Condensed Consolidated Statements of Cash Flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-21-000027:notes:136]
Commitments and Contingencies
Legal Matters

[0000068505-21-000027:notes:137]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the “Court”) against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, “Hytera”), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages, and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. The Court denied Hytera’s motion for a new trial on October 20, 2020. On December 17, 2020, the Court denied the Company’s motion for a permanent injunction, finding instead that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets. As of the third quarter of 2021, the parties were unable to agree on a reasonable royalty rate. Therefore, the Court will set the rate. The issue is fully briefed by the parties and awaits the Court's determination.

[0000068505-21-000027:notes:138]
On January 8, 2021, the Court granted Hytera’s motion for certain equitable relief and reduced the $764.6 million judgment award to $543.7 million. That same day, the Court also granted the Company’s motion for pre-judgment interest. On August 10, 2021, the Court ruled that Hytera must pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs. On March 25, 2021, the Court entered rulings favorable to the Company with respect to several of the Company's post-trial motions, including the Company's motion for attorneys' fees and its motion to require Hytera to turn over certain assets in satisfaction of the Company’s judgment award. On September 29, 2021, the Company filed two additional motions with the Court, requesting the Court to reconsider its order denying the Company’s request for an injunction, and requesting that the Court enforce its ruling requiring Hytera to turn over certain assets in satisfaction of the Company's judgment award, or, in the alternative, hold Hytera in contempt. Subsequent to quarter end, on October 15, 2021, the Court granted the Company’s request for $34.2 million in attorneys’ fees against Hytera.

[0000068505-21-000027:notes:139]
On September 7, 2021, Hytera filed a notice of appeal of the Court’s judgment with the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). The parties are briefing a jurisdictional issue raised by the Court of Appeals in response to Hytera's notice of appeal.

[0000068505-21-000027:notes:140]
On May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). The Company filed motions in the Bankruptcy Court to dismiss the bankruptcy proceedings in July 2020. On January 22, 2021, the Bankruptcy Court entered an agreed order, allowing a partial sale of Hytera's U.S. assets in the bankruptcy proceedings. The proposed sale does not include Hytera inventory accused of including the Company’s intellectual property.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-21-000027:notes:141]
[same as prior period, unchanged from 0000068505-21-000021:notes:139]

[0000068505-21-000027:notes:142]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Products and Systems Integration | $ | 1,325 |  |  | $ | 1,163 |  |  | $ | 3,538 |  |  | $ | 3,124 |  |
| Software and Services | 782 |  |  | 705 |  |  | 2,313 |  |  | 2,017 |  |
|  | $ | 2,107 |  |  | $ | 1,868 |  |  | $ | 5,851 |  |  | $ | 5,141 |  |

[0000068505-21-000027:notes:143]
[same as prior period, unchanged from 0000068505-21-000021:notes:141]

[0000068505-21-000027:notes:144]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Products and Systems Integration | $ | 224 |  |  | $ | 164 |  |  | $ | 440 |  |  | $ | 305 |  |
| Software and Services | 227 |  |  | 188 |  |  | 678 |  |  | 523 |  |
| Operating earnings | 451 |  |  | 352 |  |  | 1,118 |  |  | 828 |  |
| Total other expense | (46) |  |  | (101) |  |  | (84) |  |  | (176) |  |
| Earnings before income taxes | $ | 405 |  |  | $ | 251 |  |  | $ | 1,034 |  |  | $ | 652 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-21-000027:notes:145]
[same as prior period, unchanged from 0000068505-21-000021:notes:143]

[0000068505-21-000027:notes:146]
During the three months ended October 2, 2021, the Company recorded net reorganization of business charges of $4 million, including $2 million of charges in Other charges and $2 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $6 million related to employee separation, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-21-000027:notes:147]
During the nine months ended October 2, 2021, the Company recorded net reorganization of business charges of $29 million, including $22 million of charges in Other charges and $7 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $29 million were charges of $36 million related to employee separation, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-21-000027:notes:148]
[same as prior period, unchanged from 0000068505-21-000021:notes:146]

[0000068505-21-000027:notes:149]
| October 2, 2021 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 3 |  |  | $ | 23 |  |
| Software and Services | 1 |  |  | 6 |  |
|  | $ | 4 |  |  | $ | 29 |  |

[0000068505-21-000027:notes:150]
[same as prior period, unchanged from 0000068505-21-000021:notes:148]

[0000068505-21-000027:notes:151]
| January 1, 2021 |  | Additional Charges |  | Adjustments |  | Amount Used |  | October 2, 2021 |
| $ | 79 |  |  | $ | 36 |  |  | $ | (7) |  |  | $ | (70) |  |  | $ | 38 |  |

[0000068505-21-000027:notes:152]
[same as prior period, unchanged from 0000068505-21-000021:notes:150]

[0000068505-21-000027:notes:153]
At January 1, 2021, the Company had an accrual of $79 million for employee separation costs. The 2021 additional charges of $36 million represent severance costs for approximately 500 employees. The adjustment of $7 million reflects reversals for accruals no longer needed. The $70 million used reflects cash payments to severed employees. The remaining accrual of $38 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at October 2, 2021, is expected to be paid, primarily within one year, to approximately 800 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-21-000027:notes:154]
[same as prior period, unchanged from 0000068505-21-000021:notes:152]

[0000068505-21-000027:notes:155]
During the three months ended September 26, 2020, the Company recorded net reorganization of business charges of $13 million, including $10 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $16 million related to employee separation, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-21-000027:notes:156]
During the nine months ended September 26, 2020, the Company recorded net reorganization of business charges of $72 million, including $48 million of charges in Other charges and $24 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $72 million were charges of $85 million related to employee separation costs and $13 million of reversals for accruals no longer needed.

[0000068505-21-000027:notes:157]
| September 26, 2020 | Three Months Ended |  | Nine Months Ended |
| Products and Systems Integration | $ | 10 |  |  | $ | 58 |  |
| Software and Services | 3 |  |  | 14 |  |
|  | $ | 13 |  |  | $ | 72 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-21-000027:notes:158]
Intangible Assets and GoodwillSubsequent to quarter end, on October 29, 2021, the Company acquired Envysion, a leader in enterprise video security and business analytics, for $124 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $1 million to certain key employees that will be expensed over a service period of one year. This acquisition expands the Company's presence in the industry and reinforces the Company's strategy as a global leader in end-to-end video security solutions within Video Security and Access Control. Due to the timing of the acquisition, the initial accounting for the acquisition is incomplete. As such, the Company is not able to disclose certain information relating to the acquisition, including the preliminary fair value of assets acquired and liabilities assumed.
On July 15, 2021, the Company acquired Openpath, a cloud-based mobile access control provider for $297 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $29 million to certain key employees that will be expensed over an average service period of three years. The transaction also includes the potential for the Company to make earn-out payments of up to $40 million based on Openpath's achievement of certain financial targets from January 1, 2022 through December 31, 2022. The Company estimated there will be no payout related to the earn-out payments. This acquisition expands the Company's ability to combine video security and access control solutions within Video Security and Access Control to help support enterprise customers. The Company recognized $234 million of goodwill, $73 million of identifiable intangible assets, and $10 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $57 million of developed technology and $16 million of customer relationships that will be amortized over a period of sixteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-21-000027:notes:159]
[same as prior period, unchanged from 0000068505-21-000021:notes:157]

[0000068505-21-000027:notes:160]
On July 31, 2020, the Company acquired Pelco, a global provider of video security solutions for a purchase price of $110 million. The acquisition was settled with $107 million of cash, net of cash acquired. The acquisition demonstrates Motorola Solutions’ continued investment in Video Security and Access Control, adding a broad range of products that can be used in a variety of commercial and industrial environments and use cases. The Company recognized $38 million of goodwill, $30 million of identifiable intangible assets, and $39 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $23 million of customer relationships, $4 million of developed technology, and $3 million of trade names that will be amortized over a period of fifteen, two, and five years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the third quarter of 2021.

[0000068505-21-000027:notes:161]
[same as prior period, unchanged from 0000068505-21-000021:notes:159]

[0000068505-21-000027:notes:162]
[same as prior period, unchanged from 0000068505-21-000021:notes:160]

[0000068505-21-000027:notes:163]
[same as prior period, unchanged from 0000068505-21-000021:notes:161]

[0000068505-21-000027:notes:164]
[same as prior period, unchanged from 0000068505-21-000021:notes:162]

[0000068505-21-000027:notes:165]
[same as prior period, unchanged from 0000068505-21-000021:notes:163]

[0000068505-21-000027:notes:166]
|  | October 2, 2021 |  | December 31, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 822 |  |  | $ | 258 |  |  | $ | 766 |  |  | $ | 210 |  |
| Customer-related | 1,342 |  |  | 794 |  |  | 1,335 |  |  | 685 |  |
| Other intangibles | 80 |  |  | 58 |  |  | 80 |  |  | 52 |  |
|  | $ | 2,244 |  |  | $ | 1,110 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-21-000027:notes:167]
Amortization expense on intangible assets was $56 million and $172 million for the three and nine months ended October 2, 2021, respectively. Amortization expense on intangible assets was $54 million and $158 million for the three and nine months ended September 26, 2020, respectively. As of October 2, 2021, annual amortization expense is estimated to be $232 million in 2021, $234 million in 2022, $126 million in 2023, $96 million in 2024, $85 million in 2025, and $79 million in 2026.

[0000068505-21-000027:notes:168]
[same as prior period, unchanged from 0000068505-21-000021:notes:166]

[0000068505-21-000027:notes:169]
|  | October 2, 2021 |  | December 31, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 757 |  |  | $ | 166 |  |  | $ | 692 |  |  | $ | 129 |  |
| Software and Services | 1,487 |  |  | 944 |  |  | 1,489 |  |  | 818 |  |
|  | $ | 2,244 |  |  | $ | 1,110 |  |  | $ | 2,181 |  |  | $ | 947 |  |

[0000068505-21-000027:notes:170]
[same as prior period, unchanged from 0000068505-21-000021:notes:168]

[0000068505-21-000027:notes:171]
The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2021 to October 2, 2021:

[0000068505-21-000027:notes:172]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2021 | $ | 1,019 |  |  | $ | 1,200 |  |  | $ | 2,219 |  |
| Goodwill acquired | 199 |  |  | 35 |  |  | 234 |  |
| Purchase accounting adjustments | (2) |  |  | (1) |  |  | (3) |  |
| Foreign currency | — |  |  | (1) |  |  | (1) |  |
| Balance as of October 2, 2021 | $ | 1,216 |  |  | $ | 1,233 |  |  | $ | 2,449 |  |
