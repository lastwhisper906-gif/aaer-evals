# MSI MD&A — 0000068505-21-000027


## mdna

[0000068505-21-000027:mdna:1]
[same as prior period, unchanged from 0000068505-21-000021:mdna:1]

[0000068505-21-000027:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and nine months ended October 2, 2021 and September 26, 2020, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2020 (the "Form 10-K").

[0000068505-21-000027:mdna:3]
[same as prior period, unchanged from 0000068505-21-000021:mdna:3]

[0000068505-21-000027:mdna:4]
[same as prior period, unchanged from 0000068505-21-000021:mdna:4]

[0000068505-21-000027:mdna:5]
[same as prior period, unchanged from 0000068505-21-000021:mdna:5]

[0000068505-21-000027:mdna:6]
During the fourth quarter of 2020, the Company updated its revenue disaggregation presentation of major products and services to provide a more comprehensive view of technologies within our reporting segments. Accordingly, the Company now reports net sales in the following three major products and services (which we refer to as “technologies” in this Form 10-Q): Land Mobile Radio Mission Critical Communications (“LMR” or “LMR Mission Critical Communications”), Video Security and Access Control and Command Center Software. With the Company's acquisition of Openpath Security Inc. (“Openpath”) on July 15, 2021, the Company renamed one of its three major products and services technologies from Video Security and Analytics to Video Security and Access Control to better align with its strategic growth initiatives. The change is to the name of the technology only and no financial information has been reclassified from previous periods presented or for the quarter ended October 2, 2021.

[0000068505-21-000027:mdna:7]
[same as prior period, unchanged from 0000068505-21-000021:mdna:7]

[0000068505-21-000027:mdna:8]
[same as prior period, unchanged from 0000068505-21-000021:mdna:8]

[0000068505-21-000027:mdna:9]
[same as prior period, unchanged from 0000068505-21-000021:mdna:9]

[0000068505-21-000027:mdna:10]
Third Quarter Financial Results

[0000068505-21-000027:mdna:11]
•Net sales were $2.1 billion in the third quarter of 2021 compared to $1.9 billion in the third quarter of 2020.

[0000068505-21-000027:mdna:12]
•Operating earnings were $451 million in the third quarter of 2021 compared to $352 million in the third quarter of 2020.

[0000068505-21-000027:mdna:13]
•Net earnings attributable to Motorola Solutions, Inc. were $307 million, or $1.76 per diluted common share, in the third quarter of 2021, compared to $205 million, or $1.18 per diluted common share, in the third quarter of 2020.

[0000068505-21-000027:mdna:14]
•Operating cash flow increased $225 million to $1.1 billion in the first nine months of 2021 compared to $909 million in the first nine months of 2020.

[0000068505-21-000027:mdna:15]
•We repurchased $409 million of common stock and paid $362 million in dividends in the first nine months of 2021.

[0000068505-21-000027:mdna:16]
[same as prior period, unchanged from 0000068505-21-000021:mdna:17]

[0000068505-21-000027:mdna:17]
In response to the COVID-19 pandemic, there have been a broad number of governmental and commercial actions taken to limit the spread of the virus, including social distancing measures, stay-at-home orders, travel restrictions, business shutdowns and slowdowns. The COVID-19 pandemic continues to be dynamic, and near-term challenges across the economy remain. Although vaccines are now being distributed and administered across many parts of the world, new variants of the virus have emerged and may continue to emerge that have shown to be more contagious. In particular, the highly contagious “delta variant” of the virus has caused the latest surge of COVID-19 cases in the U.S. and other countries around the world. We continue to adhere to applicable governmental and commercial restrictions and to work to mitigate the impact of COVID-19 on our employees, customers, communities, liquidity and financial position.

[0000068505-21-000027:mdna:18]
We continue to abide by a number of measures in an effort to protect the health and well-being of our employees and customers, including encouraging office workers to work remotely, reducing employee travel, withdrawing from certain industry events, increasing the frequency of cleaning services, encouraging face coverings, and using thermal scanning. We have begun to allow essential business travel; however, we continue to carefully assess conditions on a geographical basis to determine when employees can safely return to our offices. We also facilitated the process for our employees in certain locations to receive the COVID-19 vaccine, as vaccines are distributed and administered throughout the U.S. and the global community.

[0000068505-21-000027:mdna:19]
As conditions continue to fluctuate around the world, with both vaccine administration and the rates of new variants of COVID-19 (particularly the delta variant) rising in certain regions, governments and organizations have responded by adjusting their restrictions and guidelines accordingly. The health and safety of our employees remains our top priority, and we continue to monitor the daily evolution of the pandemic, including the spread of the delta variant. As of the date of this filing, we are following the U.S. Centers for Disease Control and Prevention guidance and state and local restrictions with respect to our U.S. employees, as well as guidance from corresponding international authorities with respect to our non-U.S. employees.

[0000068505-21-000027:mdna:20]
Additionally, in September 2021 the President of the United States signed an executive order, and related guidance was published that, together, require certain COVID-19 precautions for federal contractors and their subcontractors, including mandatory COVID-19 vaccines for employees (subject to medical and religious exemptions). We are classified as a federal contractor due to a number of our agreements. In October 2021, we announced to our U.S. employees that the federal vaccine mandate would require all of our U.S. employees (subject to the exemptions described above) to be vaccinated by December 8, 2021. We continue to evaluate the potential impact of this executive order on our business. As a result of the federal vaccine mandate, we may experience constraints on our workforce and the workforce of our supply chain, which could require us to adapt our operations.

[0000068505-21-000027:mdna:21]
As we have progressed through 2021, our supply chain has been increasingly impacted by global issues related to the effects of the COVID-19 pandemic, particularly with respect to materials in the semiconductor market, including part shortages, increased freight costs, diminished transportation capacity and labor constraints. This has resulted in disruptions in our supply chain, difficulty in procuring components and materials necessary for our products and services, and constraints on our ability to meet customer demand, which we anticipate will continue at least into the first half of 2022. We are closely monitoring our supply chain and have maintained an active dialogue, and in some cases developed plans, with key suppliers in an effort to mitigate supply chain risks or otherwise minimize the impact from those risks. We will continue to actively manage our supply chain in an effort to prevent major delays in selling our products and services.

[0000068505-21-000027:mdna:22]
Although the COVID-19 pandemic continued to introduce challenges in the third quarter of 2021, we are encouraged by customer demand for our products and services. Specifically, in our Software and Services segment, with the largely recurring nature of the business and our strong backlog position, we continue to expect that the impacts on net sales and operating margin will be limited for the remainder of 2021. Within the Products and Systems Integration segment, while we are encouraged by strong LMR backlog, and the resiliency of the Video Security and Access Control technology that experienced growth in the third quarter of 2021 and which we expect to continue to grow for the remainder of 2021, supply constraints continue to impact our LMR business and we expect demand for our products will continue to out-pace our ability to obtain supply for the remainder of 2021. In addition, in March 2021, the President of the United States signed into law the American Rescue Plan Act of 2021 ("ARPA"), which is intended to provide economic stimulus, specifically additional funding to state and local governments, education and healthcare, as well as other funding relief provisions, in order to address the impact of the COVID-19 pandemic. We continue to evaluate the potential impact of the ARPA on our business and results of operations, although we anticipate that the ARPA will have a positive impact on our business and results of operations during the remainder of 2021 and beyond as we expect our governmental customers to receive funding from the ARPA.

[0000068505-21-000027:mdna:23]
We believe our existing balances of cash and cash equivalents, along with other short-term liquidity arrangements, will continue to be sufficient to satisfy our liquidity requirements associated with our existing operations. We were in compliance with all applicable covenants in the 2021 unsecured revolving credit facility as of October 2, 2021. Additionally, we have no bond maturities until 2024. We continue to assess our operating expenses and identify cost reducing initiatives, including lower travel costs, contractor spend and reducing our real estate footprint.

[0000068505-21-000027:mdna:24]
Lastly, we evaluated whether there were any impairment indicators as of October 2, 2021, which included a review of our receivables and contract assets, inventory, right-of-use lease assets, long-lived assets, investments, goodwill and intangible assets. As of the end of the third quarter of 2021, we concluded our assets were fairly stated and recoverable.

[0000068505-21-000027:mdna:25]
[same as prior period, unchanged from 0000068505-21-000021:mdna:49]

[0000068505-21-000027:mdna:26]
[same as prior period, unchanged from 0000068505-21-000021:mdna:23]

[0000068505-21-000027:mdna:27]
| Technology | Segment | Acquisition | Description | Purchase Price | Date of Acquisition |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Openpath | Provider of cloud-based mobile access control, expanding our ability to combine video security and access control solutions to help support enterprise customers. | $297 million and share-based compensation of $29 million | July 15, 2021 |
| Command Center Software | Software and Services | Callyo | Provider of cloud-based mobile applications for law enforcement in North America, including critical mobile technological capabilities that enable information to flow seamlessly from the field to the command center. | $63 million, inclusive of share-based compensation of $3 million | August 28, 2020 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | Pelco, Inc. | Global provider of video security solutions, adding a broad range of products for a variety of commercial and industrial environments and use cases. | $110 million | July 31, 2020 |
| Video Security and Access Control | Products and Systems IntegrationSoftware and Services | IndigoVision Group plc | Provider of video security solutions to enhance geographical reach across a wider customer base. | $37 million | June 16, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, and managed services, including security monitoring of network operations. | $32 million | April 30, 2020 |
| LMR | Software and Services | Unnamed cybersecurity services business | Provider of vulnerability assessments, cybersecurity consulting, managed services, and remediation and response capabilities. | $40 million, inclusive of share-based compensation of $6 million | March 3, 2020 |

[0000068505-21-000027:mdna:28]
[same as prior period, unchanged from 0000068505-21-000021:mdna:73]

[0000068505-21-000027:mdna:29]
[same as prior period, unchanged from 0000068505-21-000021:mdna:26]

[0000068505-21-000027:mdna:30]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | October 2, 2021 |  | % ofSales* |  | September 26, 2020 |  | % ofSales* |  | October 2, 2021 |  | % ofSales* |  | September 26, 2020 |  | % ofSales* |
| Net sales from products | $ | 1,221 |  |  |  |  | $ | 1,044 |  |  |  |  | $ | 3,250 |  |  |  |  | $ | 2,807 |  |  |  |
| Net sales from services | 886 |  |  |  |  | 824 |  |  |  |  | 2,601 |  |  |  |  | 2,334 |  |  |  |
| Net sales | 2,107 |  |  |  |  | 1,868 |  |  |  |  | 5,851 |  |  |  |  | 5,141 |  |  |  |
| Costs of products sales | 559 |  |  | 45.8 | % |  | 487 |  |  | 46.6 | % |  | 1,516 |  |  | 46.6 | % |  | 1,325 |  |  | 47.2 | % |
| Costs of services sales | 503 |  |  | 56.8 | % |  | 472 |  |  | 57.3 | % |  | 1,478 |  |  | 56.8 | % |  | 1,354 |  |  | 58.0 | % |
| Costs of sales | 1,062 |  |  |  |  | 959 |  |  |  |  | 2,994 |  |  |  |  | 2,679 |  |  |  |
| Gross margin | 1,045 |  |  | 49.6 | % |  | 909 |  |  | 48.7 | % |  | 2,857 |  |  | 48.8 | % |  | 2,462 |  |  | 47.9 | % |
| Selling, general and administrative expenses | 351 |  |  | 16.7 | % |  | 313 |  |  | 16.7 | % |  | 985 |  |  | 16.8 | % |  | 951 |  |  | 18.5 | % |
| Research and development expenditures | 183 |  |  | 8.7 | % |  | 175 |  |  | 9.4 | % |  | 545 |  |  | 9.3 | % |  | 505 |  |  | 9.8 | % |
| Other charges | 60 |  |  | 2.8 | % |  | 69 |  |  | 3.7 | % |  | 209 |  |  | 3.6 | % |  | 178 |  |  | 3.5 | % |
| Operating earnings | 451 |  |  | 21.4 | % |  | 352 |  |  | 18.9 | % |  | 1,118 |  |  | 19.1 | % |  | 828 |  |  | 16.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (56) |  |  | (2.7) | % |  | (58) |  |  | (3.1) | % |  | (154) |  |  | (2.6) | % |  | (167) |  |  | (3.3) | % |
| Losses on sales of investments and businesses, net | — |  |  | — | % |  | (1) |  |  | (0.1) | % |  | — |  |  | — | % |  | (1) |  |  | — | % |
| Other, net | 10 |  |  | 0.5 | % |  | (42) |  |  | (2.2) | % |  | 70 |  |  | 1.2 | % |  | (8) |  |  | (0.2) | % |
| Total other expense | (46) |  |  | (2.2) | % |  | (101) |  |  | (5.4) | % |  | (84) |  |  | (1.4) | % |  | (176) |  |  | (3.4) | % |
| Net earnings before income taxes | 405 |  |  | 19.2 | % |  | 251 |  |  | 13.4 | % |  | 1,034 |  |  | 17.7 | % |  | 652 |  |  | 12.7 | % |
| Income tax expense | 97 |  |  | 4.6 | % |  | 45 |  |  | 2.4 | % |  | 186 |  |  | 3.2 | % |  | 112 |  |  | 2.2 | % |
| Net earnings | 308 |  |  | 14.6 | % |  | 206 |  |  | 11.0 | % |  | 848 |  |  | 14.5 | % |  | 540 |  |  | 10.5 | % |
| Less: Earnings attributable to non-controlling interests | 1 |  |  | — | % |  | 1 |  |  | — | % |  | 4 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 307 |  |  | 14.6 | % |  | $ | 205 |  |  | 11.0 | % |  | $ | 844 |  |  | 14.4 | % |  | $ | 537 |  |  | 10.4 | % |
| Earnings per diluted common share | $ | 1.76 |  |  |  |  | $ | 1.18 |  |  |  |  | $ | 4.87 |  |  |  |  | $ | 3.08 |  |  |  |

[0000068505-21-000027:mdna:31]
[same as prior period, unchanged from 0000068505-21-000021:mdna:28]

[0000068505-21-000027:mdna:32]
Results of Operations—Three months ended October 2, 2021 compared to three months ended September 26, 2020

[0000068505-21-000027:mdna:33]
The results of operations for the third quarter of 2021 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-21-000027:mdna:34]
[same as prior period, unchanged from 0000068505-21-000021:mdna:32]

[0000068505-21-000027:mdna:35]
[same as prior period, unchanged from 0000068505-21-000021:mdna:33]

[0000068505-21-000027:mdna:36]
[same as prior period, unchanged from 0000068505-21-000021:mdna:34]

[0000068505-21-000027:mdna:37]
[same as prior period, unchanged from 0000068505-21-000021:mdna:35]

[0000068505-21-000027:mdna:38]
[same as prior period, unchanged from 0000068505-21-000021:mdna:36]

[0000068505-21-000027:mdna:39]
|  | Three Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 992 |  |  | $ | 457 |  |  | $ | 1,449 |  |  | $ | 863 |  |  | $ | 405 |  |  | $ | 1,268 |  |
| International | 333 |  |  | 325 |  |  | 658 |  |  | 300 |  |  | 300 |  |  | 600 |  |
|  | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 1,111 |  |  | $ | 547 |  |  | $ | 1,658 |  |  | $ | 989 |  |  | $ | 510 |  |  | $ | 1,499 |  |
| Video Security and Access Control | 214 |  |  | 102 |  |  | 316 |  |  | 174 |  |  | 77 |  |  | 251 |  |
| Command Center Software | — |  |  | 133 |  |  | 133 |  |  | — |  |  | 118 |  |  | 118 |  |
| Total | $ | 1,325 |  |  | $ | 782 |  |  | $ | 2,107 |  |  | $ | 1,163 |  |  | $ | 705 |  |  | $ | 1,868 |  |
| Operating earnings | $ | 224 |  |  | $ | 227 |  |  | $ | 451 |  |  | $ | 164 |  |  | $ | 188 |  |  | $ | 352 |  |
| Operating margins | 16.9 | % |  | 29.1 | % |  | 21.4 | % |  | 14.1 | % |  | 26.7 | % |  | 18.9 | % |

[0000068505-21-000027:mdna:40]
[same as prior period, unchanged from 0000068505-21-000021:mdna:38]

[0000068505-21-000027:mdna:41]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in the third quarter of 2021 and 62% in the third quarter of 2020. The Software and Services segment’s net sales represented 37% of our net sales in the third quarter of 2021 and 38% in the third quarter of 2020.

[0000068505-21-000027:mdna:42]
Net sales increased $239 million, or 13%, in the third quarter of 2021 compared to the third quarter of 2020. The $162 million, or 14%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 15% in the North America region and an increase of 11% in the International region. The $77 million, or 11%, increase in net sales within the Software and Services segment was driven by an increase of 13% in the North America region and an increase of 8% in the International region. Net sales includes:

[0000068505-21-000027:mdna:43]
•an increase in the Products and Systems Integration segment, inclusive of $12 million of revenue from acquisitions, driven by an increase in LMR and Video Security and Access Control;

[0000068505-21-000027:mdna:44]
•an increase in the Software and Services segment, inclusive of $3 million of revenue from acquisitions, driven by an increase in LMR services, Video Security and Access Control and Command Center Software; and

[0000068505-21-000027:mdna:45]
•$25 million from favorable currency rates.

[0000068505-21-000027:mdna:46]
[same as prior period, unchanged from 0000068505-21-000021:mdna:44]

[0000068505-21-000027:mdna:47]
•a 14% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software; and

[0000068505-21-000027:mdna:48]
•a 10% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software.

[0000068505-21-000027:mdna:49]
[same as prior period, unchanged from 0000068505-21-000021:mdna:47]

[0000068505-21-000027:mdna:50]
The 14% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-21-000027:mdna:51]
•$122 million, or 12% growth in LMR, driven by both the North America and International regions;

[0000068505-21-000027:mdna:52]
•$40 million, or 23% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000027:mdna:53]
•$12 million from favorable currency rates.

[0000068505-21-000027:mdna:54]
[same as prior period, unchanged from 0000068505-21-000021:mdna:53]

[0000068505-21-000027:mdna:55]
The 11% increase in the Software and Services segment was driven by the following:

[0000068505-21-000027:mdna:56]
•$37 million, or 7% growth in LMR services, driven by both the North America and International regions;

[0000068505-21-000027:mdna:57]
•$25 million, or 32% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000027:mdna:58]
•$15 million, or 13% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000027:mdna:59]
•$13 million from favorable currency rates.

[0000068505-21-000027:mdna:60]
[same as prior period, unchanged from 0000068505-21-000021:mdna:59]

[0000068505-21-000027:mdna:61]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |  | % Change |
| Gross margin | $ | 1,045 |  |  | $ | 909 |  |  | 15 | % |

[0000068505-21-000027:mdna:62]
Gross margin was 49.6% of net sales in the third quarter of 2021 compared to 48.7% in the third quarter of 2020. The primary drivers of this increase were:

[0000068505-21-000027:mdna:63]
•higher gross margin in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales volume and product mix, partially offset by an increase in freight costs; and

[0000068505-21-000027:mdna:64]
•higher gross margin in the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth.

[0000068505-21-000027:mdna:65]
[same as prior period, unchanged from 0000068505-21-000021:mdna:64]

[0000068505-21-000027:mdna:66]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |  | % Change |
| Selling, general and administrative expenses | $ | 351 |  |  | $ | 313 |  |  | 12 | % |

[0000068505-21-000027:mdna:67]
SG&A expenses increased 12% in the third quarter of 2021 compared to the third quarter of 2020. The increase in SG&A expenses was primarily due to higher employee incentive costs, higher travel expenses, higher expenses associated with acquired businesses and higher Hytera-related legal expenses, partially offset by a reduction of reorganization of business charges. SG&A expenses were 16.7% of net sales in both the third quarter of 2021 and the third quarter of 2020.

[0000068505-21-000027:mdna:68]
[same as prior period, unchanged from 0000068505-21-000021:mdna:67]

[0000068505-21-000027:mdna:69]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |  | % Change |
| Research and development expenditures | $ | 183 |  |  | $ | 175 |  |  | 5 | % |

[0000068505-21-000027:mdna:70]
R&D expenditures increased 5% in the third quarter of 2021 compared to the third quarter of 2020 primarily due to higher employee incentive costs and higher expenses associated with acquired businesses. R&D expenditures decreased to 8.7% of net sales in the third quarter of 2021 compared to 9.4% of net sales in the third quarter of 2020.

[0000068505-21-000027:mdna:71]
[same as prior period, unchanged from 0000068505-21-000021:mdna:70]

[0000068505-21-000027:mdna:72]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Other charges | $ | 60 |  |  | $ | 69 |  |

[0000068505-21-000027:mdna:73]
Other charges decreased by $9 million in the third quarter of 2021 compared to the third quarter of 2020. The change was driven primarily by the following:

[0000068505-21-000027:mdna:74]
•$2 million of net reorganization business charges in the third quarter of 2021 compared to $10 million of net reorganization business charges in the third quarter of 2020 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q); and

[0000068505-21-000027:mdna:75]
•$2 million of acquisition-related transaction fees in the third quarter of 2021 compared to $5 million of acquisition-related transaction fees in the third quarter of 2020; partially offset by

[0000068505-21-000027:mdna:76]
•$56 million of intangible asset amortization expense in the third quarter of 2021 compared to $54 million of intangible asset amortization expense in the third quarter of 2020.

[0000068505-21-000027:mdna:77]
[same as prior period, unchanged from 0000068505-21-000021:mdna:78]

[0000068505-21-000027:mdna:78]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Operating earnings from Products and Systems Integration | $ | 224 |  |  | $ | 164 |  |
| Operating earnings from Software and Services | 227 |  |  | 188 |  |
| Operating earnings | $ | 451 |  |  | $ | 352 |  |

[0000068505-21-000027:mdna:79]
Operating earnings increased $99 million, or 28%, in the third quarter of 2021 compared to the third quarter of 2020. The increase in Operating earnings was due to:

[0000068505-21-000027:mdna:80]
•$60 million increase in the Products and Systems Integration segment, driven by higher sales and gross margin, lower reorganization of business charges and improved operating leverage, partially offset by higher employee incentive costs, higher travel expenses, higher expenses associated with acquired businesses and higher Hytera-related legal expenses; and

[0000068505-21-000027:mdna:81]
•$39 million increase in the Software and Services segment, driven by higher sales and gross margin contribution, lower reorganization of business charges and improved operating leverage, partially offset by higher expenses associated with acquired businesses.

[0000068505-21-000027:mdna:82]
[same as prior period, unchanged from 0000068505-21-000021:mdna:83]

[0000068505-21-000027:mdna:83]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Interest expense, net | $ | (56) |  |  | $ | (58) |  |

[0000068505-21-000027:mdna:84]
The $2 million decrease in interest expense, net in the third quarter of 2021 compared to the third quarter of 2020 was a result of lower interest rates on debt outstanding for the three months ended October 2, 2021 compared to the three months ended September 26, 2020.

[0000068505-21-000027:mdna:85]
[same as prior period, unchanged from 0000068505-21-000021:mdna:86]

[0000068505-21-000027:mdna:86]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Other, net | $ | 10 |  |  | $ | (42) |  |

[0000068505-21-000027:mdna:87]
The $52 million increase in Other, net in the third quarter of 2021 compared to the third quarter of 2020 was primarily driven by:

[0000068505-21-000027:mdna:88]
•$56 million loss on extinguishment of long-term debt in the third quarter of 2020;

[0000068505-21-000027:mdna:89]
•$5 million of foreign currency gains in the third quarter of 2021 compared to $15 million of foreign currency losses in the third quarter of 2020; and

[0000068505-21-000027:mdna:90]
•$31 million of net periodic pension and postretirement benefit in the third quarter of 2021 compared to $20 million of net periodic pension and postretirement benefit in the third quarter of 2020; partially offset by

[0000068505-21-000027:mdna:91]
•$10 million loss on derivatives in the third quarter of 2021 compared to a $10 million gain on derivatives in the third quarter of 2020; and

[0000068505-21-000027:mdna:92]
•$18 million of fair value adjustments to equity investments in the third quarter of 2021 compared to $4 million of fair value adjustments to equity investments in the third quarter of 2020.

[0000068505-21-000027:mdna:93]
[same as prior period, unchanged from 0000068505-21-000021:mdna:93]

[0000068505-21-000027:mdna:94]
|  | Three Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Income tax expense | $ | 97 |  |  | $ | 45 |  |

[0000068505-21-000027:mdna:95]
Income tax expense increased by $52 million in the third quarter of 2021 compared to the third quarter of 2020, primarily due to an increase in pretax earnings offset by the recognition of excess tax benefits of share-based compensation, resulting in an effective tax rate of 24%. Our effective tax rate for the three months ended October 2, 2021 of 24% was higher than the effective tax rate for the three months ended September 26, 2020 of 18%, primarily due to favorable U.S. return-to-provision adjustments and higher tax benefits from share-based compensation in 2020 compared to 2021.

[0000068505-21-000027:mdna:96]
Results of Operations—Nine months ended October 2, 2021 compared to Nine months ended September 26, 2020

[0000068505-21-000027:mdna:97]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,603 |  |  | $ | 1,343 |  |  | $ | 3,946 |  |  | $ | 2,330 |  |  | $ | 1,146 |  |  | $ | 3,476 |  |
| International | 935 |  |  | 970 |  |  | 1,905 |  |  | 794 |  |  | 871 |  |  | 1,665 |  |
|  | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Net sales by major products and services |  |  |  |  |  |  |  |  |  |  |  |
| LMR | $ | 2,948 |  |  | $ | 1,642 |  |  | $ | 4,590 |  |  | $ | 2,685 |  |  | $ | 1,480 |  |  | $ | 4,165 |  |
| Video Security and Access Control | 590 |  |  | 284 |  |  | 874 |  |  | 439 |  |  | 196 |  |  | 635 |  |
| Command Center Software | — |  |  | 387 |  |  | 387 |  |  | — |  |  | 341 |  |  | 341 |  |
| Total | $ | 3,538 |  |  | $ | 2,313 |  |  | $ | 5,851 |  |  | $ | 3,124 |  |  | $ | 2,017 |  |  | $ | 5,141 |  |
| Operating earnings | 440 |  |  | 678 |  |  | 1,118 |  |  | 305 |  |  | 523 |  |  | 828 |  |
| Operating margins | 12.4 | % |  | 29.3 | % |  | 19.1 | % |  | 9.8 | % |  | 25.9 | % |  | 16.1 | % |

[0000068505-21-000027:mdna:98]
[same as prior period, unchanged from 0000068505-21-000021:mdna:98]

[0000068505-21-000027:mdna:99]
The Products and Systems Integration segment's net sales represented 60% of our net sales in the first nine months of 2021 and 61% in the first nine months of 2020. Net sales from the Software and Services segment represented 40% of our net sales in the first nine months of 2021 and 39% in the first nine months of 2020.

[0000068505-21-000027:mdna:100]
Net sales increased $710 million, or 14%, in the first nine months of 2021 compared to the first nine months of 2020. The $414 million, or 13%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 12% in the North America region and an increase of 18% in the International region. The $296 million, or 15%, increase in net sales within the Software and Services segment was driven by an increase of 17% in the North America region and an increase of 11% in the International region. Net sales includes:

[0000068505-21-000027:mdna:101]
•an increase in the Products and Systems Integration segment, inclusive of $85 million of revenue from acquisitions, driven by an increase in LMR and Video Security and Access Control;

[0000068505-21-000027:mdna:102]
•an increase in Software and Services, inclusive of $26 million of revenue from acquisitions, driven by an increase in LMR services, Video Security and Access Control and Command Center Software; and

[0000068505-21-000027:mdna:103]
•$123 million from favorable currency rates.

[0000068505-21-000027:mdna:104]
[same as prior period, unchanged from 0000068505-21-000021:mdna:104]

[0000068505-21-000027:mdna:105]
•a 14% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software; and

[0000068505-21-000027:mdna:106]
•a 14% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video Security and Access Control and Command Center Software.

[0000068505-21-000027:mdna:107]
[same as prior period, unchanged from 0000068505-21-000021:mdna:107]

[0000068505-21-000027:mdna:108]
[same as prior period, unchanged from 0000068505-21-000021:mdna:108]

[0000068505-21-000027:mdna:109]
•$263 million, or 10% growth in LMR, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000027:mdna:110]
•$151 million, or 35% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000027:mdna:111]
•$58 million from favorable currency rates.

[0000068505-21-000027:mdna:112]
[same as prior period, unchanged from 0000068505-21-000021:mdna:112]

[0000068505-21-000027:mdna:113]
The 15% increase in the Software and Services segment was driven by the following:

[0000068505-21-000027:mdna:114]
•$162 million, or 11% growth in LMR services, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000027:mdna:115]
•$88 million, or 45% growth in Video Security and Access Control, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-21-000027:mdna:116]
•$46 million, or 14% growth in Command Center Software, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-21-000027:mdna:117]
•$65 million from favorable currency rates.

[0000068505-21-000027:mdna:118]
[same as prior period, unchanged from 0000068505-21-000021:mdna:118]

[0000068505-21-000027:mdna:119]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |  | % Change |
| Gross margin | $ | 2,857 |  |  | $ | 2,462 |  |  | 16 | % |

[0000068505-21-000027:mdna:120]
Gross margin was 48.8% of net sales in the first nine months of 2021 compared to 47.9% in the first nine months of 2020. The primary drivers of this increase were:

[0000068505-21-000027:mdna:121]
•higher gross margin in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales volume and lower reorganization of business charges, partially offset by an increase in freight costs and an increase in employee incentive costs; and

[0000068505-21-000027:mdna:122]
•higher gross margin in the Software and Services segment, inclusive of acquisitions, primarily driven by higher gross margin contribution from sales growth and improved mix of service offerings, partially offset by higher employee incentive costs.

[0000068505-21-000027:mdna:123]
[same as prior period, unchanged from 0000068505-21-000021:mdna:123]

[0000068505-21-000027:mdna:124]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |  | % Change |
| Selling, general and administrative expenses | $ | 985 |  |  | $ | 951 |  |  | 4 | % |

[0000068505-21-000027:mdna:125]
SG&A expenses increased 4% in the first nine months of 2021 compared to the first nine months of 2020. The increase in SG&A expenses was primarily due to higher employee incentive costs, higher expenses associated with acquired businesses and higher travel expenses. The overall increase in SG&A expenses was partially offset by lower Hytera-related legal expenses. SG&A expenses were 16.8% of net sales in the first nine months of 2021 compared to 18.5% of net sales in the first nine months of 2020.

[0000068505-21-000027:mdna:126]
[same as prior period, unchanged from 0000068505-21-000021:mdna:126]

[0000068505-21-000027:mdna:127]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |  | % Change |
| Research and development expenditures | $ | 545 |  |  | $ | 505 |  |  | 8 | % |

[0000068505-21-000027:mdna:128]
R&D expenditures increased 8% in the first nine months of 2021 compared to the first nine months of 2020 primarily due to higher employee incentive costs, higher expenses associated with acquired businesses, partially offset by lower share-based compensation expenses. R&D expenditures decreased to 9.3% of net sales in the first nine months of 2021 compared to 9.8% of net sales in the first nine months of 2020.

[0000068505-21-000027:mdna:129]
[same as prior period, unchanged from 0000068505-21-000021:mdna:129]

[0000068505-21-000027:mdna:130]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Other charges | $ | 209 |  |  | $ | 178 |  |

[0000068505-21-000027:mdna:131]
Other charges increased by $31 million in the first nine months of 2021 compared to the first nine months of 2020. The change was driven primarily by the following:

[0000068505-21-000027:mdna:132]
•a $50 million gain on the sale of property, plant and equipment in the first nine months of 2020 that did not recur in the first nine months of 2021;

[0000068505-21-000027:mdna:133]
•$172 million of intangible asset amortization expense in the first nine months of 2021 compared to $158 million of intangible asset amortization expense in the first nine months of 2020;

[0000068505-21-000027:mdna:134]
•$7 million of operating lease asset impairments in the first nine months of 2021 that did not occur in the first nine months of 2020; partially offset by

[0000068505-21-000027:mdna:135]
•$22 million of net reorganization business charges in the first nine months of 2021 compared to $48 million of net reorganization business charges in the first nine months of 2020 (see further detail in the “Reorganization of Business” section in this Part I, Item 2 of this Form 10-Q); and

[0000068505-21-000027:mdna:136]
•$3 million of losses on legal settlements in the first nine months of 2021 compared to $9 million of losses on legal settlements in the first nine months of 2020; and

[0000068505-21-000027:mdna:137]
•$5 million of fixed asset impairment in the first nine months of 2020 that did not recur in the first nine months of 2021.

[0000068505-21-000027:mdna:138]
[same as prior period, unchanged from 0000068505-21-000021:mdna:138]

[0000068505-21-000027:mdna:139]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Operating earnings from Products and Systems Integration | $ | 440 |  |  | $ | 305 |  |
| Operating earnings from Software and Services | 678 |  |  | 523 |  |
| Operating earnings | $ | 1,118 |  |  | $ | 828 |  |

[0000068505-21-000027:mdna:140]
Operating earnings increased $290 million, or 35%, in the first nine months of 2021 compared to the first nine months of 2020. The increase in Operating earnings was due to:

[0000068505-21-000027:mdna:141]
•$155 million increase in the Software and Services segment, driven by higher sales and gross margin contribution, improved mix of service offerings, lower reorganization of business charges, lower share-based compensation expenses and improved operating leverage, partially offset by higher expenses associated with acquired businesses and higher employee incentive costs; and

[0000068505-21-000027:mdna:142]
•$135 million increase in the Products and Systems Integration segment, primarily driven by higher gross margin due to increased sales volume, lower reorganization of business charges and lower Hytera-related legal expenses, partially offset by higher employee incentive costs, a $50 million gain on the sale of property, plant and equipment in the first nine months of 2020 that did not recur in the first nine months of 2021 and higher expenses associated with acquired businesses.

[0000068505-21-000027:mdna:143]
[same as prior period, unchanged from 0000068505-21-000021:mdna:143]

[0000068505-21-000027:mdna:144]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Interest expense, net | $ | (154) |  |  | $ | (167) |  |

[0000068505-21-000027:mdna:145]
The $13 million decrease in net interest expense in the first nine months of 2021 compared to the first nine months of 2020 was a result of the reversal of a non-cash interest accrual related to an international tax audit and lower interest rates on debt outstanding for the nine months ended October 2, 2021 compared to the nine months ended September 26, 2020.

[0000068505-21-000027:mdna:146]
[same as prior period, unchanged from 0000068505-21-000021:mdna:146]

[0000068505-21-000027:mdna:147]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Other, net | $ | 70 |  |  | $ | (8) |  |

[0000068505-21-000027:mdna:148]
The $78 million increase in Other, net in the first nine months of 2021 compared to the first nine months of 2020 was primarily driven by:

[0000068505-21-000027:mdna:149]
•$18 million loss on the extinguishment of long-term debt in the first nine months of 2021 compared to a $56 million loss on the extinguishment of long-term debt in the first nine months of 2020;

[0000068505-21-000027:mdna:150]
•$13 million of foreign currency gains in the first nine months of 2021 compared to $19 million of foreign currency losses in the first nine months of 2020; and

[0000068505-21-000027:mdna:151]
•$91 million of net periodic pension and postretirement benefit in the first nine months of 2021 compared to $60 million of net periodic pension and postretirement benefit in the first nine months of 2020; partially offset by

[0000068505-21-000027:mdna:152]
•$19 million of losses on derivative instruments in the first nine months of 2021 compared to $6 million of gains on derivative instruments in the first nine months of 2020.

[0000068505-21-000027:mdna:153]
[same as prior period, unchanged from 0000068505-21-000021:mdna:154]

[0000068505-21-000027:mdna:154]
|  | Nine Months Ended |
| (In millions) | October 2, 2021 |  | September 26, 2020 |
| Income tax expense | $ | 186 |  |  | $ | 112 |  |

[0000068505-21-000027:mdna:155]
Income tax expense increased by $74 million in the first nine months of 2021 compared to the first nine months of 2020, primarily due to an increase in pretax earnings offset by a $33 million tax benefit due to a partial release of a valuation allowance recorded on the U.S. foreign tax credit carryforward, resulting in an effective tax rate of 18%. Our effective tax rate of 18% for the nine months ended October 2, 2021 was higher than the effective tax rate for the nine months ended September 26, 2020 of 17%, primarily due to favorable U.S. return-to-provision adjustments and excess share-based compensation in 2020, which exceeded the tax benefit realized in 2021 related to a partial release of a valuation allowance of $33 million.

[0000068505-21-000027:mdna:156]
[same as prior period, unchanged from 0000068505-21-000021:mdna:157]

[0000068505-21-000027:mdna:157]
During the third quarter of 2021, we recorded net reorganization of business charges of $4 million, including $2 million of charges recorded within Other charges and $2 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $6 million related to employee separation costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-21-000027:mdna:158]
During the first nine months of 2021, we recorded net reorganization of business charges of $29 million, including $22 million of charges recorded within Other charges and $7 million in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $29 million were charges of $36 million related to employee separation costs, partially offset by $7 million of reversals for accruals no longer needed.

[0000068505-21-000027:mdna:159]
During the third quarter of 2020, we recorded net reorganization of business charges of $13 million, including $10 million of charges in Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $13 million were charges of $16 million related to employee separation costs, partially offset by $3 million of reversals for accruals no longer needed.

[0000068505-21-000027:mdna:160]
During the first nine months of 2020, we recorded net reorganization of business charges of $72 million, including $48 million of charges in Other charges and $24 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $72 million were charges of $85 million related to employee separation costs, partially offset by $13 million of reversals for accruals no longer needed.

[0000068505-21-000027:mdna:161]
[same as prior period, unchanged from 0000068505-21-000021:mdna:162]

[0000068505-21-000027:mdna:162]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Products and Systems Integration | $ | 3 |  |  | $ | 10 |  |  | $ | 23 |  |  | $ | 58 |  |
| Software and Services | 1 |  |  | 3 |  |  | 6 |  |  | 14 |  |
|  | $ | 4 |  |  | $ | 13 |  |  | $ | 29 |  |  | $ | 72 |  |

[0000068505-21-000027:mdna:163]
Cash payments for employee severance in connection with the reorganization of business plans were $70 million in the first nine months of 2021 and $63 million in the first nine months of 2020. The reorganization of business accrual at October 2, 2021 was $38 million related to employee separation costs that are expected to be paid within one year.

[0000068505-21-000027:mdna:164]
[same as prior period, unchanged from 0000068505-21-000021:mdna:165]

[0000068505-21-000027:mdna:165]
|  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 1,134 |  |  | $ | 909 |  |
| Investing activities | (525) |  |  | (369) |  |
| Financing activities | (179) |  |  | (532) |  |
| Effect of exchange rates on cash and cash equivalents | (31) |  |  | (2) |  |
| Increase in cash and cash equivalents | $ | 399 |  |  | $ | 6 |  |

[0000068505-21-000027:mdna:166]
[same as prior period, unchanged from 0000068505-21-000021:mdna:167]

[0000068505-21-000027:mdna:167]
At October 2, 2021, $1.1 billion of the $1.7 billion cash and cash equivalents balance was held in the U.S. and $578 million was held in other countries, with $205 million held in the United Kingdom.

[0000068505-21-000027:mdna:168]
[same as prior period, unchanged from 0000068505-21-000021:mdna:169]

[0000068505-21-000027:mdna:169]
The increase in cash flows provided by operating activities from the first nine months of 2020 to the first nine months of 2021 was driven primarily by an increase in earnings as a result of increased sales volume, partially offset by higher income tax payments.

[0000068505-21-000027:mdna:170]
[same as prior period, unchanged from 0000068505-21-000021:mdna:171]

[0000068505-21-000027:mdna:171]
The increase in cash flows used for investing activities from the first nine months of 2020 to the first nine months of 2021 was primarily due to:

[0000068505-21-000027:mdna:172]
•$78 million increase in cash used for acquisitions and investments;

[0000068505-21-000027:mdna:173]
•$50 million decrease in the proceeds from the sale of property, plant and equipment driven by the sale of a European manufacturing facility in the first nine months of 2020; and

[0000068505-21-000027:mdna:174]
•$24 million increase in capital expenditures due to higher payments for the Airwave and ESN networks.

[0000068505-21-000027:mdna:175]
[same as prior period, unchanged from 0000068505-21-000021:mdna:176]

[0000068505-21-000027:mdna:176]
The decrease in cash flows used for financing activities in the first nine months of 2021 as compared to the cash used for financing activities in the first nine months of 2020 was primarily driven by (also see further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-21-000027:mdna:177]
•$351 million of repayments of debt in the first nine months of 2021 compared to $911 million of repayments of debt and $600 million of repayments on the revolving credit facility in the first nine months of 2020;

[0000068505-21-000027:mdna:178]
•$44 million decrease in share repurchases in the first nine months of 2021 compared to the first nine months of 2020;

[0000068505-21-000027:mdna:179]
•$40 million increase in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in the first nine months of 2021 compared to the first nine months of 2020; partially offset by

[0000068505-21-000027:mdna:180]
•$844 million of net proceeds received from the issuance of debt in the first nine months of 2021 compared to $892 million of proceeds received from the issuance of debt and $800 million of proceeds received from the draw on our revolving credit facility during the first nine months of 2020; and

[0000068505-21-000027:mdna:181]
•$35 million increase in the payment of dividends in the first nine months of 2021 compared to the first nine months of 2020.

[0000068505-21-000027:mdna:182]
[same as prior period, unchanged from 0000068505-21-000021:mdna:182]

[0000068505-21-000027:mdna:183]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended October 2, 2021 and September 26, 2020:

[0000068505-21-000027:mdna:184]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |
| Contract-specific discounting facility | $ | 66 |  |  | $ | 67 |  |  | $ | 173 |  |  | $ | 165 |  |
| Accounts receivable sales proceeds | 15 |  |  | 15 |  |  | $ | 23 |  |  | $ | 73 |  |
| Long-term receivables sales proceeds | 56 |  |  | 45 |  |  | 140 |  |  | 115 |  |
| Total proceeds from receivable sales | $ | 137 |  |  | $ | 127 |  |  | $ | 336 |  |  | $ | 353 |  |

[0000068505-21-000027:mdna:185]
During the three and nine months ended October 2, 2021, we utilized a contract-specific receivable discounting facility which began during the nine months ended September 26, 2020, resulting in accounts receivable sales of $66 million and $173 million, respectively. The proceeds of our receivable sales are included in Operating activities within our Condensed Consolidated Statements of Cash Flows.

[0000068505-21-000027:mdna:186]
[same as prior period, unchanged from 0000068505-21-000021:mdna:186]

[0000068505-21-000027:mdna:187]
We had outstanding debt of $5.7 billion and $5.2 billion, including the current portions of $6 million and $12 million, at October 2, 2021 and December 31, 2020, respectively.

[0000068505-21-000027:mdna:188]
In May of 2021, we issued $850 million of 2.75% senior notes due 2031. We recognized net proceeds of $844 million after debt issuance costs. A portion of these proceeds were then used to redeem $324 million in principal amount of our outstanding long-term debt for a purchase price of $341 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, we recognized a loss of $18 million related to the redemption in Other, net within Other income (expense) in our Condensed Consolidated Statements of Operations.

[0000068505-21-000027:mdna:189]
In March of 2021, we entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the London Interbank Offered Rate ("LIBOR"), at our option. The 2021 Motorola Solutions Credit Agreement includes provisions allowing us to replace LIBOR with a replacement benchmark rate in the future under certain conditions defined in the agreement. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of October 2, 2021.

[0000068505-21-000027:mdna:190]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which mature in September 2024 ("Senior Convertible Notes"). Interest on these notes is payable semiannually. The Senior Convertible Notes became fully convertible on September 5, 2021. The notes are convertible based on a conversion rate of 4.9140 per $1,000 principal amount (which is equal to an initial conversion price of $203.50 per share), adjusted for dividends declared through the date of settlement. In the event of conversion, we intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-21-000027:mdna:191]
We have an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of October 2, 2021 we had no outstanding debt under the commercial paper program.

[0000068505-21-000027:mdna:192]
[same as prior period, unchanged from 0000068505-21-000021:mdna:193]

[0000068505-21-000027:mdna:193]
[same as prior period, unchanged from 0000068505-21-000021:mdna:194]

[0000068505-21-000027:mdna:194]
During the three and nine months ended October 2, 2021, we repurchased approximately 0.6 million and 2.0 million shares at an average price of $234.18 and $199.88 per share, respectively, for an aggregate of $137 million and $409 million, respectively, including transaction costs. We paid $125 million and $397 million to settle share repurchases during the three and nine months ended October 2, 2021, respectively. In May of 2021, the Board of Directors approved a $2.0 billion increase to the share repurchase program. As of October 2, 2021, we had used approximately $13.8 billion of the share repurchase authority to repurchase shares, leaving $2.2 billion of authority available for future repurchases.

[0000068505-21-000027:mdna:195]
[same as prior period, unchanged from 0000068505-21-000021:mdna:196]

[0000068505-21-000027:mdna:196]
During the third quarter of 2021 we paid $120 million in cash dividends to holders of our common stock. During the first nine months of 2021 we paid $362 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $120 million in cash dividends to holders of our common stock.

[0000068505-21-000027:mdna:197]
[same as prior period, unchanged from 0000068505-21-000021:mdna:198]

[0000068505-21-000027:mdna:198]
We had outstanding commitments to provide long-term financing to third parties totaling $79 million at October 2, 2021, compared to $78 million at December 31, 2020.

[0000068505-21-000027:mdna:199]
[same as prior period, unchanged from 0000068505-21-000021:mdna:200]

[0000068505-21-000027:mdna:200]
See “Recent Accounting Pronouncements” and “Recently Adopted Accounting Pronouncements” in Note 1, “Basis of Presentation” to our condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.
