# MSI MD&A — 0000068505-25-000012


## mdna

[0000068505-25-000012:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-25-000012:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2024 and 2023 and results of operations and cash flows for each of the three years in the period ended December 31, 2024. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-25-000012:mdna:3]
Executive Overview

[0000068505-25-000012:mdna:4]
Our Business

[0000068505-25-000012:mdna:5]
Motorola Solutions' business is safety and security. Every day we work to deliver on our commitment of helping to create safer communities, safer schools, safer hospitals and safer businesses. Our work as a global leader in public safety and enterprise security is grounded in nearly 100 years of close customer and community collaboration. We design and advance technology for more than 100,000 public safety and enterprise customers in over 100 countries, driven by our commitment to help make everywhere safer for all.

[0000068505-25-000012:mdna:6]
We manage our business organizationally through two segments: “Products and Systems Integration” and “Software and Services.” Within these segments, we have three principal product lines in which we report net sales: LMR Communications, Video and Command Center.

[0000068505-25-000012:mdna:7]
The Company has invested across these three technologies organically and through acquisitions to evolve its LMR focus and expand its safety and security products and services.

[0000068505-25-000012:mdna:8]
Our strategy is to generate value through our technologies that help meet the changing needs of our customers around the world in protecting people, property and places. While each technology individually strives to make users safer and more productive, we believe we can enable better outcomes for our customers when we unite these technologies to work together. Our goal is to help remove silos and barriers between people and technologies, so that data unifies, information flows, operations run and collaboration improves to help strengthen safety and security everywhere. Across all three technologies, we offer on-premises, cloud-based and hybrid software solutions, and services such as cybersecurity subscription services and managed and support services.

[0000068505-25-000012:mdna:9]
One example of this collaboration is highlighted by a school setting. When a teacher presses a panic button on a phone, this can automatically notify local law enforcement of an emergency, trigger a lockdown to secure all entries, share live video feeds with first responders and send mass notifications to key stakeholders inside and outside the school, helping schools to detect, respond and resolve safety and security threats.

[0000068505-25-000012:mdna:10]
The principal products within each segment, by technology, are described below:

[0000068505-25-000012:mdna:11]
Products and Systems Integration Segment

[0000068505-25-000012:mdna:12]
In 2024, the segment’s net sales were $6.9 billion, representing 64% of our consolidated net sales.

[0000068505-25-000012:mdna:13]
LMR Communications

[0000068505-25-000012:mdna:14]
Our LMR Communications technology includes infrastructure and devices for LMR, as well as devices for public safety Long Term Evolution (“LTE”) and public carrier LTE. Our technology enables voice and multimedia collaborations across two-way radio, WiFi and public and private broadband networks. We are a global leader in the two-way radio category, including Project 25 (P25), Terrestrial Trunked Radio ("TETRA") and Digital Mobile Radio (DMR), as well as other PCR solutions. We also deliver LTE solutions for public safety, government and commercial users, including devices operating in both low-band and mid-band frequencies, including Citizens’ Broadband Radio Service (CBRS) frequencies. We also offer High Frequency (HF) and Very High Frequency (VHF) communications technology to military, government and relief agency customers who require dynamic and mobile point-to-point voice communications in remote environments without the need for fixed infrastructure.

[0000068505-25-000012:mdna:15]
We believe that public safety agencies and enterprises continue to trust LMR communications systems and devices because they are purpose-built and designed for reliability, availability, security and resiliency to help keep people connected even during the most challenging conditions.

[0000068505-25-000012:mdna:16]
By extending our two-way radios with broadband data capabilities, we strive to provide our customers with greater functionality and multimedia access to the information and data they need in their workflows. Examples include application services such as GPS location to better protect lone workers, job dispatch to assign tasks and work orders and over-the-air programming to optimize device uptime. Our view is that complementary data applications such as these enable government, public safety and enterprise customers to work more efficiently and safely, while maintaining their mission-critical voice communications to remain connected and working in collaboration with others.

[0000068505-25-000012:mdna:17]
Primary sources of revenue for this technology come from selling devices and building communications systems, including infrastructure, the installation and integration of our infrastructure equipment within our customers’ technology environments. The LMR technology within the Products and Systems Integration segment represented 83% of the net sales of the total segment in 2024.

[0000068505-25-000012:mdna:18]
Video

[0000068505-25-000012:mdna:19]
Our Video technology includes video management infrastructure, AI-powered security cameras including fixed and certain mobile video equipment, as well as on-premises and cloud-based access control solutions. We deploy video security and access control solutions to thousands of government and enterprise customers around the world, including schools, transportation systems, healthcare centers, public venues, commercial real estate, utilities, prisons, factories, casinos, airports, financial institutions, government facilities, state and local law enforcement agencies and retailers. Organizations such as these utilize video security and access control to verify critical events or incidents in real-time and to provide data to investigate an event or incident after it happens.

[0000068505-25-000012:mdna:20]
Our view is that government and public safety customers are increasingly turning to video security technologies, including fixed and mobile cameras, to increase visibility, accountability and safety for communities and first responders alike.

[0000068505-25-000012:mdna:21]
The Video technology within the Products and Systems Integration segment represented 17% of the net sales of the total segment in 2024.

[0000068505-25-000012:mdna:22]
Software and Services Segment

[0000068505-25-000012:mdna:23]
In 2024, the segment’s net sales were $3.9 billion, representing 36% of our consolidated net sales.

[0000068505-25-000012:mdna:24]
LMR Communications

[0000068505-25-000012:mdna:25]
LMR Communications services include support and managed services, which offer a broad continuum of support for our customers. Support services include repair and replacement, technical support and preventative maintenance, and more advanced offerings such as system monitoring, software updates and cybersecurity services. Managed services range from partial to full operational support of customer-owned or Motorola Solutions-owned communications systems. Our customers’ systems often have multi-year or multi-decade lifespans that help drive demand for software upgrades, device and infrastructure refresh opportunities, as well as additional services to monitor, manage, maintain and secure these complex networks and solutions. We strive to deliver services to our customers that help improve performance across their systems, devices and applications for greater safety and productivity.

[0000068505-25-000012:mdna:26]
Given the mission-critical nature of our customers’ operational environments, we aim to design the LMR networks they rely on for availability, security and resiliency. We have a comprehensive approach to system upgrades that addresses hardware, software and implementation services. As new system releases become available, we work with our customers to upgrade software, hardware, or both, with respect to site controllers, comparators, routers, LAN switches, servers, dispatch consoles, logging equipment, network management terminals, network security devices such as firewalls and intrusion detection sensors, on-site or remotely.

[0000068505-25-000012:mdna:27]
The LMR technology within the Software and Services segment represented 60% of the net sales of the total segment in 2024.

[0000068505-25-000012:mdna:28]
Video

[0000068505-25-000012:mdna:29]
Video software includes video network management software, decision management and digital evidence management software, certain mobile video equipment and advanced vehicle location data analysis software, including license plate recognition. Our software is designed to complement video hardware systems, providing end-to-end video security to help keep people, property and places safe.

[0000068505-25-000012:mdna:30]
Our video network management software is embedded with AI-powered analytics to deliver operational insights to our customers by bringing attention to important events within their video footage. Given the growing volume of video content, we believe that analytics are critical to delivering meaningful, action-oriented insights. Our view is that these insights can help to proactively detect an important event in real time as well as reactively search video content to detect an important event that occurred in the past. For example, AI-powered analytics can highlight a person at a facility out of hours (unusual activity), locate a missing child at a theme park (appearance search), flag a vehicle of interest at a school (license plate recognition), send an alert if doors to a restricted area are propped open at a hospital (access control), or trigger a school's customized lockdown plan while simultaneously alerting first responders and sharing video footage from inside the school.

[0000068505-25-000012:mdna:31]
Our cloud technologies can offer organizations the ability to access, search and manage their video security intrusion and access control system from a centralized dashboard, accessible on remote devices such as smartphones and laptops. Additionally, our on-premises fixed video systems can be connected to the cloud, providing our customers with the ability to securely access and manage video across their sites from a remote or central monitoring location. We believe that governments, public safety agencies and enterprises are increasingly turning to scalable, cloud-based multi-factor authentication access control to make their facilities more secure.

[0000068505-25-000012:mdna:32]
Our Video services include our "video-as-a-service" subscription-based offerings for law enforcement, simplifying procurement by bundling hardware and software into a single subscription. For example, body cameras and in-car video systems can be paired with either on-premises or cloud-based digital evidence management software and complementary command center products. Our cloud solutions are also sold as-a-service, available as single-year to multi-year hosted services, supporting our customers with upgrades and software enhancements to help ensure system performance and technological advancement.

[0000068505-25-000012:mdna:33]
The Video technology within the Software and Services segment represented 20% of the net sales of the total segment in 2024.

[0000068505-25-000012:mdna:34]
Command Center

[0000068505-25-000012:mdna:35]
Our Command Center portfolio consists of cloud-native, on-premises and hybrid software solutions that support the complex process of the public safety workflow from "911 call to case closure." From the moment a person contacts 911, an array of individuals engage to gather information, coordinate a response and manage the incident to resolution. These individuals include call takers who answer and triage 911 calls; dispatchers who route calls to police, fire and emergency medical services to manage the response; first responders who support on scene; intelligence analysts who support the incident; records and evidence specialists who preserve information and evidence; detectives who manage cases; crime analysts who identify patterns and accelerate investigations; and corrections officers who oversee jail and inmate management.

[0000068505-25-000012:mdna:36]
To help ensure that individuals within the public safety workflow can work as efficiently, effectively and safely as possible, we believe it’s important that individuals within enterprises and communities can communicate and collaborate directly with public safety agencies, particularly during emergencies. Our Command Center portfolio offers solutions that are designed to help community members, enterprises and public safety agencies work together and share information in an effort to help prevent critical events from escalating and better inform an emergency response when an incident unfolds.

[0000068505-25-000012:mdna:37]
Our Command Center software is designed to support an emergency response. In the 911 communications center, we offer call taking and management software (including multimedia communication capabilities and AI-powered call transcription and language translation) and voice and computer-aided dispatch software to assign first responders to incidents. For emergency management teams, we offer mass notification and alerting (including panic button mobile applications) and incident collaboration software that aids in coordinating a multi-disciplinary response. In the field, we offer mobile applications that help first responders to collaborate with each other, remain connected to the information they need, manage an incident, capture critical information to support investigations, and remotely file reports. For information and support services teams, we offer integrated records and evidence management software, as well as solutions for managing tips and publishing crime maps to aid community engagement. For intelligence and investigations teams, we offer software that can unify voice, video and data in order to increase situational awareness from a single map-based view during a real-time incident response, and investigative tools to help uncover connections across records to generate leads and help close cases. For enterprises, we provide incident management and business resilience solutions that help secure people and facilities, as well as share information with public safety when an incident necessitates it.

[0000068505-25-000012:mdna:38]
Another area of public safety evolution is the increasing adoption of Next Generation 911 Core Services (“NGCS”), a group of products and services needed to create infrastructure connectivity in order to process a 911 call using Next Generation (“NG”) technology. The NG infrastructure is an Emergency Service IP Network ("ESInet"), which can carry voice, data and multimedia. ESInet enables 911 call takers at public safety answering points to respond to text, video and data. Our NGCS can be offered as a managed service and includes call routing, ESInet, location services, geographic information services, cybersecurity and our continuous communications network and security operations center dedicated to public safety.

[0000068505-25-000012:mdna:39]
Command Center also includes interoperability solutions that provide connectivity across LMR and broadband networks to help ensure that communication is not limited by coverage area, network technology or device type. Additionally, Command Center includes push-to-talk ("PTT") devices that deliver voice communications over LTE and Wi-Fi, and advanced back-end systems that enable and manage interoperable communications, capable of scaling from small enterprises to nationwide cellular networks. For example, a two-way radio network can connect with an LTE network, assisting individuals in communicating securely and more easily across technologies. These solutions can provide our public safety customers with the critical interoperability between multiple agencies' networks, facilitating a coordinated response.

[0000068505-25-000012:mdna:40]
Finally, as the Command Center market continues to evolve from on-premises to hybrid and cloud technologies to improve their operations, we offer both cloud-native applications and cloud features that enhance on-premises applications. We believe this flexibility helps our customers to optimize their investments and enhance their systems with the technologies of their choice.

[0000068505-25-000012:mdna:41]
The Command Center technology within the Software and Services segment represented 20% of the net sales of the total segment in 2024.

[0000068505-25-000012:mdna:42]
2024 Financial Results

[0000068505-25-000012:mdna:43]
•Net sales were $10.8 billion in 2024 compared to $10.0 billion in 2023.

[0000068505-25-000012:mdna:44]
•Operating earnings were $2.7 billion in 2024 compared to $2.3 billion in 2023.

[0000068505-25-000012:mdna:45]
•Net earnings attributable to Motorola Solutions, Inc. were $1.6 billion, or $9.23 per diluted common share in 2024, compared to earnings of $1.7 billion, or $9.93 per diluted common share in 2023.

[0000068505-25-000012:mdna:46]
•Our operating cash flow was $2.4 billion in 2024 compared to $2.0 billion in 2023.

[0000068505-25-000012:mdna:47]
•We returned approximately $898 million of capital to shareholders, in the form of $654 million in dividends and $244 million in share repurchases in 2024. Additionally, we repurchased the $1.0 billion aggregate principal amount of the 1.75% senior convertible notes issued to Silver Lake Partners and scheduled to mature in 2024 ("the Silver Lake Convertible Debt"), for $1.59 billion in cash, inclusive of the conversion premium.

[0000068505-25-000012:mdna:48]
•We increased our quarterly dividend by 11% to $1.09 per share in November 2024.

[0000068505-25-000012:mdna:49]
•We ended 2024 with a backlog position of $14.7 billion, up $438 million compared to 2023.

[0000068505-25-000012:mdna:50]
Segment Financial Highlights

[0000068505-25-000012:mdna:51]
•In the Products and Systems Integration segment, net sales were $6.9 billion in 2024, an increase of $641 million, or 10%, compared to $6.2 billion in 2023. On a geographic basis, net sales increased in both the North America and International regions. Operating earnings were $1.7 billion in 2024, compared to $1.2 billion in 2023. Operating margins increased in 2024 to 24.3% from 19.9% in 2023 primarily due to higher sales and favorable mix, partially offset by higher employee incentive costs, including share-based compensation, higher expenses related to legal matters, including Hytera-related expenses, and higher expenses associated with acquired businesses.

[0000068505-25-000012:mdna:52]
•In the Software and Services segment, net sales were $3.9 billion in 2024, an increase of $198 million, or 5%, compared to $3.7 billion in 2023. On a geographic basis, net sales increased in the North America region and decreased in the International region. Operating earnings were $1.0 billion in 2024, compared to $1.1 billion in 2023. Operating margins decreased in 2024 to 25.7% from 28.1% in 2023 primarily driven the revenue reduction on Airwave services in accordance with the Charge Control, higher employee incentive costs, including share-based compensation, higher expenses associated with acquired businesses and higher expenses related to legal matters, partially offset by higher sales and a reduction in intangible amortization expenses.

[0000068505-25-000012:mdna:53]
Recent Events

[0000068505-25-000012:mdna:54]
U.K. Home Office Update

[0000068505-25-000012:mdna:55]
In October 2021, the Competition and Markets Authority ("CMA") opened a market investigation into the Mobile Radio Network Services market. This investigation included Airwave, our private mobile radio communications network that we acquired in 2016. Airwave provides mission-critical voice and data communications to emergency services and other agencies in Great Britain.

[0000068505-25-000012:mdna:56]
In 2023, the CMA imposed a legal order on Airwave which implemented a prospective price control on Airwave (the "Charge Control"). After the Competition Appeal Tribunal ("CAT") dismissed our appeal of the CMA's final decision, we appealed the CAT's judgment to the United Kingdom Court of Appeal. On January 30, 2025, the United Kingdom Court of Appeal denied our application for permission to appeal the CAT's judgment. Since August 1, 2023, revenue under the Airwave contract has been, and will continue to be, recognized in accordance with the Charge Control.

[0000068505-25-000012:mdna:57]
On March 13, 2024, we received a notice of contract extension (the “Deferred National Shutdown Notice”) from the Home Office of the United Kingdom (the "Home Office"). The Deferred National Shutdown Notice extends the “national shutdown target date” of the Airwave service from December 31, 2026 to December 31, 2029, at the Charge Control rates. Our backlog for Airwave services contracted with the Home Office through December 31, 2026 was previously reduced by $777 million to align with the Charge Control. In 2024, as a result of the Home Office's notice of a contract extension pursuant to their Deferred National Shutdown Notice, we recorded additional backlog of $748 million to reflect the incremental three years of services. On April 11, 2024, we filed proceedings in the U.K. High Court challenging the decision of the Home Office to issue the Deferred National Shutdown Notice as being in breach of applicable U.K. procurement and public law. The hearing on this matter has been set to commence on April 22, 2025. The backlog related to the incremental years of service contemplated in the Deferred National Shutdown Notice could change depending on the outcome of the proceedings.

[0000068505-25-000012:mdna:58]
On December 5, 2024, a proposed class representative filed a claim with the CAT to bring collective proceedings against us, alleging that users of Airwave services during the period January 1, 2020 through July 31, 2023 suffered financial harm as a result of the pricing in effect during such time (the "Collective Proceeding"). The initial stage of the Collective Proceeding will involve "Certification" of the claim by the CAT, which we expect to be heard in 2025.

[0000068505-25-000012:mdna:59]
36

[0000068505-25-000012:mdna:60]
Recent Acquisitions

[0000068505-25-000012:mdna:61]
| Segment | Technology | Acquisition | Description | Purchase Price | Date of Acquisition |
| Software and Services | Command Center | 3tc Software | Provider of control room software solutions. | $22 million and share-based compensation of $4 million | October 29, 2024 |
| Software and Services | Command Center | Noggin | Provider of cloud-based business continuity planning, operational resilience and critical event management software. | $91 million and share-based compensation of $19 million | July 1, 2024 |
| Software and Services | Video Security and Access Control | Unnamed vehicle location and management solutions business | Provider of vehicle location and management solutions. | $132 million and share-based compensation of $3 million | July 1, 2024 |
| Products and Systems Integration | Video Security and Access Control | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |
| Products and Systems Integration | Video Security and Access Control | IPVideo | Creator of a multifunctional safety and security device. | $170 million and share-based compensation of $5 million | December 15, 2023 |
| Software and Services | Command Center | Rave Mobile | Provider of mass notification and incident management services. | $553 million and share-based compensation of $2 million | December 14, 2022 |
| Products and Systems Integration | LMR Communications | Futurecom | Provider of radio coverage extension solutions. | $30 million | October 25, 2022 |
| Products and Systems Integration | LMR Communications | Barrett Communications | Provider of specialized radio communications. | $18 million | August 8, 2022 |
| Products and Systems Integration | Video Security and Access Control | Videotec | Provider of ruggedized video security solutions. | $23 million and share-based compensation of $4 million | May 12, 2022 |
| Software and Services | Video Security and Access Control | Calipsa | Provider of cloud-native advanced video analytics. | $39 million and share-based compensation of $4 million | April 19, 2022 |
| Software and Services | LMR Communications | TETRA Ireland | Provider of Ireland's National Digital Radio Service. | $120 million | March 23, 2022 |
| Products and Systems IntegrationSoftware and Services | Video Security and Access Control | Ava | Provider of cloud-native video security and analytics. | $388 million and share-based awards and compensation of $7 million | March 3, 2022 |

[0000068505-25-000012:mdna:62]
Climate Change Regulations

[0000068505-25-000012:mdna:63]
We expect that our operations and supply chain will become increasingly subject to federal, state, local and foreign laws, regulations and international treaties and industry standards relating to climate change and other environmental and social impacts, risks and opportunities. For example, in the European Union (the “EU”), the EU Corporate Sustainability Reporting Directive, EU Corporate Sustainability Due Diligence Directive and EU taxonomy initiatives will introduce, in staggered timelines, additional due diligence and disclosure requirements addressing sustainability that will apply or we expect will apply, as applicable, to us in the coming years.

[0000068505-25-000012:mdna:64]
37

[0000068505-25-000012:mdna:65]
Looking Forward

[0000068505-25-000012:mdna:66]
We expect continued growth within our global LMR installed base as a number of events such as natural disasters and large-scale incidents continue to reinforce the importance of having secure, reliable LMR for public safety. We believe our augmentation of LMR with broadband solutions will also drive growth, as we expect our customers will look to integrate valuable data capabilities. We expect to provide additional services to existing LMR customers as communications systems become more complex, software-centric and data-driven.

[0000068505-25-000012:mdna:67]
As public safety needs continue to evolve, we anticipate growth opportunities within the command center as our Command Center portfolio supports the complex process of the public safety workflow from "911 call to case closure." We expect increased growth across our portfolio that consists of native cloud, hybrid and on-premises software solutions that provide a migration path for our customers from on-premises solutions to cloud capabilities, as well as from the increasing adoption of NGCS.

[0000068505-25-000012:mdna:68]
Within Video, we expect growth across our portfolio of fixed and mobile video security solutions embedded with advanced analytics and access control solutions. We believe drivers include the expansion of traditional video sales beyond enterprise customers to governments and public safety customers. Additionally, we believe that governments, public safety agencies and enterprises are increasingly turning to scalable, cloud-based multi-factor authentication access control to make their facilities more secure with the ability to securely access, search and manage these systems across their sites from a remote or central monitoring location. We also expect customers to continue to embrace analytics that convert video data into actionable insights and offerings such as "video-as-a-service."

[0000068505-25-000012:mdna:69]
We anticipate new opportunities from the investments we are making to integrate our LMR, Video and Command Center technologies into one unified safety and security ecosystem. We expect that our customers will continue to turn to cloud-based integrated solutions, as well as, we have made go-to-market and research and development investments in both Video and our Command Center technologies with growth in mind. We have made a number of acquisitions and we see opportunities to continue to rationalize costs within both segments of our business, further driving operating leverage in our businesses.

[0000068505-25-000012:mdna:70]
Results of Operations

[0000068505-25-000012:mdna:71]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2024 |  | % ofSales ** |  | 2023 |  | % ofSales ** |  | 2022 |  | % ofSales ** |
| Net sales from products | $ | 6,454 |  |  |  |  | $ | 5,814 |  |  |  |  | $ | 5,368 |  |  |  |
| Net sales from services | 4,363 |  |  |  |  | 4,164 |  |  |  |  | 3,744 |  |  |  |
| Net sales | 10,817 |  |  |  |  | 9,978 |  |  |  |  | 9,112 |  |  |  |
| Costs of product sales | 2,674 |  |  | 41.4 | % |  | 2,591 |  |  | 44.6 | % |  | 2,595 |  |  | 48.3 | % |
| Costs of services sales | 2,631 |  |  | 60.3 | % |  | 2,417 |  |  | 58.0 | % |  | 2,288 |  |  | 61.1 | % |
| Costs of sales | 5,305 |  |  | 49.0 | % |  | 5,008 |  |  | 50.2 | % |  | 4,883 |  |  | 53.6 | % |
| Gross margin | 5,512 |  |  | 51.0 | % |  | 4,970 |  |  | 49.8 | % |  | 4,229 |  |  | 46.4 | % |
| Selling, general and administrative expenses | 1,752 |  |  | 16.2 | % |  | 1,561 |  |  | 15.6 | % |  | 1,450 |  |  | 15.9 | % |
| Research and development expenditures | 917 |  |  | 8.5 | % |  | 858 |  |  | 8.6 | % |  | 779 |  |  | 8.5 | % |
| Other charges | 155 |  |  | 1.4 | % |  | 257 |  |  | 2.6 | % |  | 339 |  |  | 3.7 | % |
| Operating earnings | 2,688 |  |  | 24.8 | % |  | 2,294 |  |  | 23.0 | % |  | 1,661 |  |  | 18.2 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (227) |  |  | (2.1) | % |  | (216) |  |  | (2.2) | % |  | (226) |  |  | (2.5) | % |
| Gains on sales of investments and businesses, net | — |  |  | — | % |  | — |  |  | — | % |  | 3 |  |  | — | % |
| Other, net | (489) |  |  | (4.5) | % |  | 68 |  |  | 0.7 | % |  | 77 |  |  | 0.8 | % |
| Total other expense | (716) |  |  | (6.6) | % |  | (148) |  |  | (1.5) | % |  | (146) |  |  | (1.6) | % |
| Net earnings before income taxes | 1,972 |  |  | 18.2 | % |  | 2,146 |  |  | 21.5 | % |  | 1,515 |  |  | 16.6 | % |
| Income tax expense | 390 |  |  | 3.6 | % |  | 432 |  |  | 4.3 | % |  | 148 |  |  | 1.6 | % |
| Net earnings | 1,582 |  |  | 14.6 | % |  | 1,714 |  |  | 17.2 | % |  | 1,367 |  |  | 15.0 | % |
| Less: Earnings attributable to noncontrolling interests | 5 |  |  | — | % |  | 5 |  |  | 0.1 | % |  | 4 |  |  | — | % |
| Net earnings* | $ | 1,577 |  |  | 14.6 | % |  | $ | 1,709 |  |  | 17.1 | % |  | $ | 1,363 |  |  | 15.0 | % |
| Earnings per diluted common share* | $ | 9.23 |  |  |  |  | $ | 9.93 |  |  |  |  | $ | 7.93 |  |  |  |

[0000068505-25-000012:mdna:72]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-25-000012:mdna:73]
**    Percentages may not add due to rounding.

[0000068505-25-000012:mdna:74]
38

[0000068505-25-000012:mdna:75]
Geographic Market Sales by Locale of End Customer

[0000068505-25-000012:mdna:76]
|  | 2024 |  | 2023 |  | 2022 |
| North America | 72 | % |  | 69 | % |  | 70 | % |
| International | 28 | % |  | 31 | % |  | 30 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-25-000012:mdna:77]
Results of Operations—2024 Compared to 2023

[0000068505-25-000012:mdna:78]
Net Sales

[0000068505-25-000012:mdna:79]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| Net sales from Products and Systems Integration | $ | 6,883 |  |  | $ | 6,242 |  |  | 10 | % |
| Net sales from Software and Services | 3,934 |  |  | 3,736 |  |  | 5 | % |
| Net sales | $ | 10,817 |  |  | $ | 9,978 |  |  | 8 | % |

[0000068505-25-000012:mdna:80]
The Products and Systems Integration segment’s net sales represented 64% of our net sales in 2024, compared to 63% of our net sales in 2023. The Software and Services segment’s net sales represented 36% of our net sales in 2024, compared to 37% of our net sales in 2023.

[0000068505-25-000012:mdna:81]
Net sales increased by $839 million, or 8%, compared to 2023. The 10% increase in net sales within the Products and Systems Integration segment was driven by a 13% increase in the North America region and a 3% increase in the International region. The 5% increase in the Software and Services segment was driven by a 12% increase in the North America region partially offset by a 8% decline within the International region. The increase in net sales included:

[0000068505-25-000012:mdna:82]
•an increase in the Products and Systems Integration segment, inclusive of $43 million of revenue from acquisitions, driven by growth in LMR and Video; and

[0000068505-25-000012:mdna:83]
•an increase in the Software and Services segment, inclusive of $52 million of revenue from acquisitions, driven by an increase in Video and Command Center, partially offset by LMR services due to the revenue reduction on Airwave services in accordance with the Charge Control and the Company's exit of the Emergency Services Network contract with the Home Office in 2022, inclusive of the twelve months of transition services through the end of 2023 (the "ESN Exit");

[0000068505-25-000012:mdna:84]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-25-000012:mdna:85]
Regional results included:

[0000068505-25-000012:mdna:86]
•a 13% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in LMR, Video and Command Center; and

[0000068505-25-000012:mdna:87]
•a 2% decline in the International region, inclusive of revenue from acquisitions, driven by the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by growth in LMR, Video and Command Center.

[0000068505-25-000012:mdna:88]
Products and Systems Integration

[0000068505-25-000012:mdna:89]
The 10% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-25-000012:mdna:90]
•a $612 million, or 12% growth in LMR, driven by both the North America and International regions; and

[0000068505-25-000012:mdna:91]
•a $29 million, or 3% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-25-000012:mdna:92]
•inclusive of $2 million from unfavorable currency rates.

[0000068505-25-000012:mdna:93]
Software and Services

[0000068505-25-000012:mdna:94]
The 5% increase in the Software and Services segment was driven by the following:

[0000068505-25-000012:mdna:95]
•a $165 million, or 27% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-25-000012:mdna:96]
•a $71 million, or 10% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions; partially offset by

[0000068505-25-000012:mdna:97]
•a $38 million, or 2% decrease in LMR services, driven by the revenue reduction on Airwave services in accordance with the Charge Control and the ESN Exit, partially offset by an increase in both the North America and International regions.

[0000068505-25-000012:mdna:98]
Gross Margin

[0000068505-25-000012:mdna:99]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 3,668 |  |  | $ | 3,127 |  |  | 17 | % |
| Gross margin from Software and Services | 1,844 |  |  | 1,843 |  |  | — | % |
| Gross margin | $ | 5,512 |  |  | $ | 4,970 |  |  | 11 | % |

[0000068505-25-000012:mdna:100]
Gross margin was 51.0% of net sales in 2024 compared to 49.8% of net sales in 2023. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000012:mdna:101]
•a 3.2% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales, favorable mix and lower direct material costs; partially offset by

[0000068505-25-000012:mdna:102]
•a 2.4% decrease gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, driven by the revenue reduction on Airwave services in accordance with the Charge Control.

[0000068505-25-000012:mdna:103]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-25-000012:mdna:104]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 1,392 |  |  | $ | 1,239 |  |  | 12 | % |
| SG&A expenses from Software and Services | 360 |  |  | 322 |  |  | 12 | % |
| SG&A expenses | $ | 1,752 |  |  | $ | 1,561 |  |  | 12 | % |

[0000068505-25-000012:mdna:105]
SG&A expenses increased $191 million, or 12% in 2024 compared to 2023 primarily due to:

[0000068505-25-000012:mdna:106]
•a $153 million, or 12% increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters, including Hytera related legal expenses; and

[0000068505-25-000012:mdna:107]
•a $38 million, or 12% increase in Software and Services SG&A expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses related to legal matters.

[0000068505-25-000012:mdna:108]
SG&A expenses were 16.2% of net sales in 2024 compared to 15.6% of net sales in 2023.

[0000068505-25-000012:mdna:109]
Research and Development ("R&D") Expenditures

[0000068505-25-000012:mdna:110]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 575 |  |  | $ | 551 |  |  | 4 | % |
| R&D expenditures from Software and Services | 342 |  |  | 307 |  |  | 11 | % |
| R&D expenditures | $ | 917 |  |  | $ | 858 |  |  | 7 | % |

[0000068505-25-000012:mdna:111]
R&D expenditures increased $59 million, or 7% in 2024 compared to 2023 primarily due to:

[0000068505-25-000012:mdna:112]
•a $35 million, or 11% increase in Software and Services R&D expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses; and

[0000068505-25-000012:mdna:113]
•an $24 million, or 4% increase in Products and Systems Integration R&D expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses.

[0000068505-25-000012:mdna:114]
R&D expenditures were 8.5% of net sales in 2024 and 8.6% of net sales in 2023.

[0000068505-25-000012:mdna:115]
Other Charges

[0000068505-25-000012:mdna:116]
|  | Years ended December 31 |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Other charges from Products and Systems Integration | $ | 25 |  |  | $ | 94 |  |  |  |
| Other charges from Software and Services | 130 |  |  | $ | 163 |  |  |  |
| Other charges | $ | 155 |  |  | $ | 257 |  |  |  |

[0000068505-25-000012:mdna:117]
Other charges decreased $102 million, or 40% in 2024 compared to 2023 due to a $69 million, or 73% decrease in Products and System Integration and a $33 million, or 20% decrease in Software and Services. The decrease was primarily driven by:

[0000068505-25-000012:mdna:118]
•a $61 million gain on the Hytera litigation in 2024 for the amounts recovered through legal proceedings due to theft of our trade secrets that did not occur in 2023 (see "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information);

[0000068505-25-000012:mdna:119]
•$152 million of intangible asset amortization expense in 2024 compared to $177 million of intangible asset amortization expense in 2023;

[0000068505-25-000012:mdna:120]
•a $24 million impairment loss related to the exit of video manufacturing operations in 2023 that did not occur in 2024 (see "Property, Plant and Equipment, Net" within "Note 4: Other Financial Data" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information); and

[0000068505-25-000012:mdna:121]
•$2 million of environmental reserve expense in 2024 compared to $15 million in 2023; partially offset by

[0000068505-25-000012:mdna:122]
•$20 million of acquisition-related transaction fees in 2024 compared to $7 million of acquisition-related transaction fees.

[0000068505-25-000012:mdna:123]
Operating Earnings

[0000068505-25-000012:mdna:124]
|  | Years ended December 31 |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Operating earnings from Products and Systems Integration | $ | 1,676 |  |  | $ | 1,244 |  |  |  |
| Operating earnings from Software and Services | 1,012 |  |  | 1,050 |  |  |  |
| Operating earnings | $ | 2,688 |  |  | $ | 2,294 |  |  |  |

[0000068505-25-000012:mdna:125]
Operating earnings increased $394 million, or 17% in 2024 compared to 2023. The increase in Operating earnings was due to:

[0000068505-25-000012:mdna:126]
•a $432 million increase in the Products and Systems Integration segment from 2023 to 2024, primarily driven by higher sales, favorable mix and a gain on the Hytera litigation (for further information regarding the Hytera litigation, refer to “Hytera Civil Litigation” within "Note 12: Commitments and Contingencies" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K), partially offset by higher employee incentive costs, including share-based compensation, higher expenses related to legal matters, including Hytera related expenses, and higher expenses associated with acquired businesses; partially offset by

[0000068505-25-000012:mdna:127]
•a $38 million decrease in the Software and Services segment from 2023 to 2024, primarily driven by the revenue reduction on Airwave services in accordance with the Charge Control, higher employee incentive costs, including share-based compensation, higher expenses associated with acquired businesses and higher expenses related to legal matters, partially offset by higher sales and a reduction in intangible amortization expenses.

[0000068505-25-000012:mdna:128]
Interest Expense, net

[0000068505-25-000012:mdna:129]
|  | Years ended December 31 |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Interest expense, net | $ | (227) |  |  | $ | (216) |  |  |  |

[0000068505-25-000012:mdna:130]
The $11 million increase in net interest expense in 2024 compared to 2023 was primarily driven by higher interest rates on outstanding debt and an interest accrual related to audits with taxing authorities in foreign jurisdictions, partially offset by higher interest income.

[0000068505-25-000012:mdna:131]
Other, net

[0000068505-25-000012:mdna:132]
|  | Years ended December 31 |
| (In millions) | 2024 |  | 2023 |
| Other, net | $ | (489) |  |  | $ | 68 |  |

[0000068505-25-000012:mdna:133]
The $557 million change in Other, net expense in 2024 compared to Other, net income in 2023 was primarily due to:

[0000068505-25-000012:mdna:134]
•$585 million of loss from the extinguishment of the the Silver Lake Convertible Debt which was recognized in 2024;

[0000068505-25-000012:mdna:135]
•$19 million of losses on derivatives in 2024 compared to $20 million of gains on derivatives in 2023;

[0000068505-25-000012:mdna:136]
•$5 million of losses on fair value adjustments to equity investments in 2024 compared to an $13 million of gains on fair value adjustments to equity investments in 2023; and

[0000068505-25-000012:mdna:137]
•$11 million of losses on assessments of uncertain tax positions recognized in 2024; partially offset by

[0000068505-25-000012:mdna:138]
•$2 million of foreign currency gains in 2024 compared to $53 million of foreign currency losses in 2023;

[0000068505-25-000012:mdna:139]
•$132 million of net periodic pension and postretirement benefit in 2024 compared to $99 million of net periodic pension and postretirement benefit in 2023; and

[0000068505-25-000012:mdna:140]
•$3 million of investment impairments in 2024 compared to $16 million of investment impairments in 2023.

[0000068505-25-000012:mdna:141]
Effective Tax Rate

[0000068505-25-000012:mdna:142]
|  | Years ended December 31 |  |
| (In millions) | 2024 |  | 2023 |  |
| Income tax expense | $ | 390 |  |  | $ | 432 |  |  |

[0000068505-25-000012:mdna:143]
Income tax expense decreased by $42 million in 2024 compared to 2023, for an effective tax rate of 19.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-25-000012:mdna:144]
•$171 million benefit from our decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on our 2023 U.S. tax return;

[0000068505-25-000012:mdna:145]
•$45 million of benefits due to the recognition of excess tax benefits on share-based compensation;

[0000068505-25-000012:mdna:146]
•$29 million benefit from the foreign derived intangible income deduction; and

[0000068505-25-000012:mdna:147]
•$24 million of benefits due to the generation of research and development tax credits; partially offset by

[0000068505-25-000012:mdna:148]
•$148 million tax expense due to the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt; and

[0000068505-25-000012:mdna:149]
•$66 million tax expense for estimated 2024 U.S. state income taxes.

[0000068505-25-000012:mdna:150]
Our effective tax rate in 2023 was 20.1%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-25-000012:mdna:151]
•$38 million benefit from the foreign derived intangible income deduction;

[0000068505-25-000012:mdna:152]
•$33 million of benefits due to the recognition of excess tax benefits on share-based compensation; and

[0000068505-25-000012:mdna:153]
•$19 million of benefits due to the generation of research and development tax credits; partially offset by

[0000068505-25-000012:mdna:154]
•$71 million tax expense for estimated 2023 U.S. state income taxes.

[0000068505-25-000012:mdna:155]
For further information, see "Note 7: Income Taxes" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-25-000012:mdna:156]
Results of Operations—2023 Compared to 2022

[0000068505-25-000012:mdna:157]
Net Sales

[0000068505-25-000012:mdna:158]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| Net sales from Products and Systems Integration | $ | 6,242 |  |  | $ | 5,728 |  |  | 9 | % |
| Net sales from Software and Services | 3,736 |  |  | 3,384 |  |  | 10 | % |
| Net sales | $ | 9,978 |  |  | $ | 9,112 |  |  | 10 | % |

[0000068505-25-000012:mdna:159]
The Products and Systems Integration segment’s net sales represented 63% of our net sales in both 2023 and 2022. The Software and Services segment’s net sales represented 37% of our net sales in both 2023 and 2022.

[0000068505-25-000012:mdna:160]
Net sales increased by $866 million, or 10%, in 2023 compared to 2022. The 9% increase in net sales within the Products and Systems Integration segment was driven by a 20% increase in the International region and a 5% increase in the North America region. The 10% increase in the Software and Services segment was driven by a 16% increase in the North America region and a 1% increase within the International region. The increase in net sales included:

[0000068505-25-000012:mdna:161]
•an increase in the Products and Systems Integration segment, inclusive of $15 million of revenue from acquisitions, driven by growth in LMR and Video;

[0000068505-25-000012:mdna:162]
•an increase in the Software and Services segment, inclusive of $83 million of revenue from acquisitions, driven by an increase in LMR services, Command Center and Video; and

[0000068505-25-000012:mdna:163]
•inclusive of $38 million from unfavorable currency rates.

[0000068505-25-000012:mdna:164]
Regional results include:

[0000068505-25-000012:mdna:165]
•a 9% increase in the North America region, inclusive of revenue from acquisitions, driven by growth in LMR, Video and Command Center; and

[0000068505-25-000012:mdna:166]
•a 11% increase in the International region, inclusive of revenue from acquisitions, driven by growth in LMR and Video, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the Charge Control.

[0000068505-25-000012:mdna:167]
Products and Systems Integration

[0000068505-25-000012:mdna:168]
The 9% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-25-000012:mdna:169]
•$414 million, or 9% growth in LMR, inclusive of revenue from acquisitions, driven by both the International and North America regions;

[0000068505-25-000012:mdna:170]
•$100 million, or 10% growth in Video, inclusive of revenue from acquisitions, in both the North America and International regions; and

[0000068505-25-000012:mdna:171]
•inclusive of $19 million from unfavorable currency rates.

[0000068505-25-000012:mdna:172]
Software and Services

[0000068505-25-000012:mdna:173]
The 10% increase in the Software and Services segment was driven by the following:

[0000068505-25-000012:mdna:174]
•$125 million, or 5% growth in LMR services, inclusive of revenue from acquisitions, driven by the North America and International regions, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the Charge Control;

[0000068505-25-000012:mdna:175]
•$124 million, or 21% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-25-000012:mdna:176]
•$103 million, or 20% growth in Video, inclusive of revenue from acquisitions, driven by the North America region; and

[0000068505-25-000012:mdna:177]
•inclusive of $19 million from unfavorable currency rates.

[0000068505-25-000012:mdna:178]
Gross Margin

[0000068505-25-000012:mdna:179]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 3,127 |  |  | $ | 2,668 |  |  | 17 | % |
| Gross margin from Software and Services | 1,843 |  |  | 1,561 |  |  | 18 | % |
| Gross margin | $ | 4,970 |  |  | $ | 4,229 |  |  | 18 | % |

[0000068505-25-000012:mdna:180]
Gross margin was 49.8% of net sales in 2023 compared to 46.4% of net sales in 2022. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000012:mdna:181]
•a 3.5% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, inclusive of acquisitions, primarily driven by higher sales and lower direct material costs; and

[0000068505-25-000012:mdna:182]
•a 3.2% increase in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales and a $147 million fixed asset impairment loss in 2022 that did not recur in 2023 related to the ESN Exit, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the Charge Control.

[0000068505-25-000012:mdna:183]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-25-000012:mdna:184]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 1,239 |  |  | $ | 1,156 |  |  | 7 | % |
| SG&A expenses from Software and Services | 322 |  |  | 294 |  |  | 10 | % |
| SG&A expenses | $ | 1,561 |  |  | $ | 1,450 |  |  | 8 | % |

[0000068505-25-000012:mdna:185]
SG&A expenses increased $111 million, or 8% in 2023 compared to 2022 primarily due to:

[0000068505-25-000012:mdna:186]
•an $83 million, or 7% increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share-based compensation and higher expenses associated with acquired businesses, partially offset by lower Hytera-related legal expenses; and

[0000068505-25-000012:mdna:187]
•a $28 million, or 10% increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses and higher employee incentive costs, including share-based compensation.

[0000068505-25-000012:mdna:188]
SG&A expenses were 15.6% of net sales in 2023 compared to 15.9% of net sales in 2022.

[0000068505-25-000012:mdna:189]
Research and Development ("R&D") Expenditures

[0000068505-25-000012:mdna:190]
|  | Years ended December 31 |
| (In millions) | 2023 |  | 2022 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 551 |  |  | $ | 503 |  |  | 10 | % |
| R&D expenditures from Software and Services | 307 |  |  | 276 |  |  | 11 | % |
| R&D expenditures | $ | 858 |  |  | $ | 779 |  |  | 10 | % |

[0000068505-25-000012:mdna:191]
R&D expenditures increased $79 million, or 10% in 2023 compared to 2022 primarily due to:

[0000068505-25-000012:mdna:192]
•a $48 million, or 10% increase in Products and Systems Integration R&D expenses primarily due to higher employee incentive costs, including share-based compensation, and higher expenses associated with acquired businesses; and

[0000068505-25-000012:mdna:193]
•a $31 million, or 11% increase in Software and Services R&D expenses primarily due to higher expenses associated with acquired businesses and higher employee incentive costs, including share-based compensation.

[0000068505-25-000012:mdna:194]
R&D expenditures were 8.6% of net sales in 2023 and 8.5% of net sales in 2022.

[0000068505-25-000012:mdna:195]
Other Charges

[0000068505-25-000012:mdna:196]
|  | Years ended December 31 |  |
| (In millions) | 2023 |  | 2022 |  |
| Other charges from Products and Systems Integration | $ | 94 |  |  | $ | 96 |  |  |
| Other charges from Software and Services | 163 |  |  | 243 |  |  |
| Other charges | $ | 257 |  |  | $ | 339 |  |  |

[0000068505-25-000012:mdna:197]
Other charges decreased $82 million, or 24% in 2023 compared to 2022 due to an $80 million, or 33% decrease in Software and Service and a $2 million, or 2% decrease in Products and Systems Integration. The decrease was primarily due to:

[0000068505-25-000012:mdna:198]
•$177 million of intangible asset amortization expense in 2023 compared to $257 million in 2022;

[0000068505-25-000012:mdna:199]
•$4 million of legal settlements in 2023 compared to $23 million in 2022;

[0000068505-25-000012:mdna:200]
•$6 million of operating lease asset impairments in 2023 compared to $24 million in 2022;

[0000068505-25-000012:mdna:201]
•$7 million of charges for acquisition-related transaction fees in 2023 compared to $23 million in 2022; and

[0000068505-25-000012:mdna:202]
•$3 million of fixed asset impairments in 2023 compared to $12 million in 2022; partially offset by

[0000068505-25-000012:mdna:203]
•$24 million impairment loss related to the exit of video manufacturing operations in 2023 that did not occur in 2022 (see "Property, Plant and Equipment, Net" within "Note 4: Other Financial Data" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further information);

[0000068505-25-000012:mdna:204]
•$15 million of environmental reserve expense in 2023 that did not occur in 2022;

[0000068505-25-000012:mdna:205]
•$15 million of gain recoveries from the legal settlement under the Hytera bankruptcy proceedings in 2022 that did not occur in 2023; and

[0000068505-25-000012:mdna:206]
•$22 million of net reorganization of business charges in 2023 compared to $18 million in 2022 (see "Note 14: Reorganization of Businesses" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-25-000012:mdna:207]
45

[0000068505-25-000012:mdna:208]
Operating Earnings

[0000068505-25-000012:mdna:209]
|  | Years ended December 31 |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Operating earnings from Products and Systems Integration | $ | 1,244 |  |  | $ | 913 |  |  |  |
| Operating earnings from Software and Services | 1,050 |  |  | 748 |  |  |  |
| Operating earnings | $ | 2,294 |  |  | $ | 1,661 |  |  |  |

[0000068505-25-000012:mdna:210]
Operating earnings increased $633 million, or 38% in 2023 compared to 2022. The increase in Operating earnings was due to:

[0000068505-25-000012:mdna:211]
•a $331 million increase in the Products and Systems Integration segment from 2022 to 2023, primarily driven by higher sales and lower direct material costs, partially offset by higher employee incentive costs, including share-based compensation; and

[0000068505-25-000012:mdna:212]
•a $302 million increase in the Software and Services segment from 2022 to 2023, primarily driven by higher sales and a $147 million fixed asset impairment loss in 2022 that did not recur in 2023, related to the ESN Exit, and a reduction in intangible amortization expenses, partially offset by the revenue reduction on Airwave services in 2023 due to the implementation of the Charge Control, and higher expenses associated with acquired businesses.

[0000068505-25-000012:mdna:213]
Interest Expense, net

[0000068505-25-000012:mdna:214]
|  | Years ended December 31 |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Interest expense, net | $ | (216) |  |  | $ | (226) |  |  |  |

[0000068505-25-000012:mdna:215]
The $10 million decrease in net interest expense in 2023 compared to 2022 was a result of higher interest income earned on cash, partially offset by higher debt outstanding.

[0000068505-25-000012:mdna:216]
Gains on Sales of Investments and Businesses, net

[0000068505-25-000012:mdna:217]
|  | Years ended December 31 |  |
| (In millions) | 2023 |  | 2022 |  |
| Gains on sales of investments and businesses, net | $ | — |  |  | $ | 3 |  |  |

[0000068505-25-000012:mdna:218]
The net gains on sales of investments and businesses were primarily related to the sales of various equity investments that occurred in 2022.

[0000068505-25-000012:mdna:219]
Other, net

[0000068505-25-000012:mdna:220]
|  | Years ended December 31 |  |
| (In millions) | 2023 |  | 2022 |  |
| Other, net | $ | 68 |  |  | $ | 77 |  |  |

[0000068505-25-000012:mdna:221]
Other, net income decreased $9 million in 2023 compared to 2022 primarily due to:

[0000068505-25-000012:mdna:222]
•$53 million of foreign currency loss in 2023 compared to $37 million of foreign currency gain in 2022;

[0000068505-25-000012:mdna:223]
•$99 million of net periodic pension and postretirement benefit in 2023 compared to $123 million of net periodic pension and postretirement benefit in 2022;

[0000068505-25-000012:mdna:224]
•a $21 million gain on TETRA Ireland equity method investment in 2022 that did not occur in 2023; and

[0000068505-25-000012:mdna:225]
•$16 million of investment impairments in 2023 compared to $1 million of investment impairments in 2022; partially offset by

[0000068505-25-000012:mdna:226]
•a $20 million gain on derivatives in 2023 compared to a $61 million loss on derivatives in 2022;

[0000068505-25-000012:mdna:227]
•a $13 million loss on fair value adjustments to equity investments in 2023 compared to an $30 million loss on fair value adjustments to equity investments in 2022;

[0000068505-25-000012:mdna:228]
•a $6 million loss on the extinguishment of long-term debt in 2022 that did not occur in 2023; and

[0000068505-25-000012:mdna:229]
•a $3 million loss on equity method investments in 2022 that did not occur in 2023.

[0000068505-25-000012:mdna:230]
Effective Tax Rate

[0000068505-25-000012:mdna:231]
|  | Years ended December 31 |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Income tax expense | $ | 432 |  |  | $ | 148 |  |  |  |

[0000068505-25-000012:mdna:232]
Income tax expense increased by $284 million in 2023 compared to 2022, for an effective tax rate of 20.1%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-25-000012:mdna:233]
•$38 million benefit from the foreign derived intangible income deduction;

[0000068505-25-000012:mdna:234]
•$33 million of benefits due to the recognition of excess tax benefits on share-based compensation; and

[0000068505-25-000012:mdna:235]
•$19 million of benefits due to the generation of research and development tax credits, offset by:

[0000068505-25-000012:mdna:236]
•$71 million tax expense for estimated 2023 U.S. state income taxes.

[0000068505-25-000012:mdna:237]
Our effective tax rate in 2022 was 9.8%, which is lower than the current U.S. federal statutory rate of 21% primarily due to:

[0000068505-25-000012:mdna:238]
•$77 million of a non-recurring net deferred tax benefit as a result of an intra-group transfer of certain intellectual property rights;

[0000068505-25-000012:mdna:239]
•$68 million of benefits due to the recognition of excess tax benefits on share-based compensation;

[0000068505-25-000012:mdna:240]
•$59 million benefit from the foreign derived intangible income deduction; and

[0000068505-25-000012:mdna:241]
•$47 million benefit due to a change in the Company's ability to utilize tax attribute carryforwards resulting in the partial release of valuation allowances.

[0000068505-25-000012:mdna:242]
Reorganization of Businesses

[0000068505-25-000012:mdna:243]
In 2024, we recorded net reorganization of business charges of $38 million relating to the separation of 720 employees, of which 460 were direct employees and 260 were indirect employees. The $38 million of charges included $12 million of charges recorded to Cost of sales and $26 million of charges recorded to Other charges. Included in the aggregate $38 million were charges of $48 million related to employee separation costs, partially offset by $6 million of reversals for employee separation accruals no longer needed and $4 million of reversals for exit cost accruals no longer needed.

[0000068505-25-000012:mdna:244]
During 2023, we recorded net reorganization of business charges of $53 million relating to the separation of 700 employees, of which 420 were direct employees and 280 were indirect employees. The $53 million of charges included $7 million recorded to Cost of sales and $46 million recorded to Other charges. Included in the aggregate $53 million were charges of $41 million related to employee separation costs and a $24 million impairment loss related to the exit of video manufacturing operations, partially offset by $7 million of reversals for employee separation accruals no longer needed and $5 million of reversals for exit cost accruals no longer needed.

[0000068505-25-000012:mdna:245]
During 2022, we recorded net reorganization of business charges of $36 million relating to the separation of 460 employees, of which 310 were direct employees and 150 were indirect employees. The $36 million of charges included $18 million recorded to Cost of sales and $18 million recorded to Other charges. Included in the aggregate $36 million were charges of $36 million for employee separation costs and $10 million for exit costs, partially offset by $10 million of reversals for accruals no longer needed.

[0000068505-25-000012:mdna:246]
The following table displays the net charges incurred by business segment due to such reorganizations:

[0000068505-25-000012:mdna:247]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| Products and Systems Integration | $ | 32 |  |  | $ | 45 |  |  | $ | 21 |  |
| Software and Services | 6 |  |  | 8 |  |  | 15 |  |
|  | $ | 38 |  |  | $ | 53 |  |  | $ | 36 |  |

[0000068505-25-000012:mdna:248]
Cash payments for employee severance in connection with the reorganization of business plans were $38 million, $37 million, and $34 million in 2024, 2023, and 2022, respectively. The reorganization of business accruals for employee separation costs at December 31, 2024 were $27 million which we expect to pay within one year.

[0000068505-25-000012:mdna:249]
At January 1, 2024, we had an accrual of $5 million for exit costs related to our exit of the ESN contract with the Home Office. During the year, we recorded a $4 million reversal for accruals no longer needed. The remaining $1 million of exit costs are recorded in Accrued liabilities in our Consolidated Balance Sheet at December 31, 2024, and are expected to be paid within one year.

[0000068505-25-000012:mdna:250]
Liquidity and Capital Resources

[0000068505-25-000012:mdna:251]
|  | Years Ended December 31 |
|  | 2024 |  | 2023 |  | 2022 |
| Cash flows provided by (used for): |  |  |  |  |  |
| Operating activities | $ | 2,391 |  |  | $ | 2,044 |  |  | $ | 1,823 |  |
| Investing activities | (507) |  |  | (414) |  |  | (1,387) |  |
| Financing activities | (1,448) |  |  | (1,295) |  |  | (906) |  |
| Effect of exchange rates on cash and cash equivalents | (39) |  |  | 45 |  |  | (79) |  |
| Increase (decrease) in cash and cash equivalents | $ | 397 |  |  | $ | 380 |  |  | $ | (549) |  |

[0000068505-25-000012:mdna:252]
Cash and Cash Equivalents

[0000068505-25-000012:mdna:253]
At December 31, 2024, $1.8 billion of our $2.1 billion cash and cash equivalents balance was held in the U.S. and $299 million was held in other countries. Restricted cash was $3 million as of December 31, 2024 and $2 million as of December 31, 2023.

[0000068505-25-000012:mdna:254]
We routinely repatriate a portion of non-U.S. earnings each year. We have recorded income tax expense for foreign withholding tax and distribution taxes on such earnings and, under current U.S. tax laws, do not expect to incur material incremental U.S. tax on repatriation.

[0000068505-25-000012:mdna:255]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy. While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay due to local country approvals.

[0000068505-25-000012:mdna:256]
Operating Activities

[0000068505-25-000012:mdna:257]
The increase in operating cash flows from 2023 to 2024 was primarily driven by higher earnings, net of non-cash charges.

[0000068505-25-000012:mdna:258]
The increase in operating cash flows from 2022 to 2023 was driven by:

[0000068505-25-000012:mdna:259]
•higher earnings, net of non-cash charges; and

[0000068505-25-000012:mdna:260]
•improved working capital; partially offset by

[0000068505-25-000012:mdna:261]
•$280 million of higher income tax payments, including a one-time $70 million cash tax payment made in 2023 related to an intra-group transfer of certain IP rights that was completed in 2022 (see "Note 7: Income Taxes" to our consolidated financial statements in “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for further information).

[0000068505-25-000012:mdna:262]
Investing Activities

[0000068505-25-000012:mdna:263]
The increase in net cash used for investing activities from 2023 to 2024 was primarily due to:

[0000068505-25-000012:mdna:264]
•$110 million increase in acquisitions and investments, driven by acquisitions and investments of $290 million in 2024 compared to $180 million in 2023; and

[0000068505-25-000012:mdna:265]
•$4 million increase in capital expenditures in 2024 compared to 2023; partially offset by

[0000068505-25-000012:mdna:266]
•$21 million increase in proceeds from the sale of investments in 2024 compared to 2023.

[0000068505-25-000012:mdna:267]
The decrease in net cash used for investing activities from 2022 to 2023 was primarily due to:

[0000068505-25-000012:mdna:268]
•$997 million decrease in acquisitions and investments, driven by acquisitions of $180 million in 2023 compared to $1.2 billion in 2022; and

[0000068505-25-000012:mdna:269]
•$3 million decrease in capital expenditures in 2023 compared to 2022; partially offset by

[0000068505-25-000012:mdna:270]
•$27 million decrease in proceeds from the sale of investments in 2023 compared to 2022.

[0000068505-25-000012:mdna:271]
Financing Activities

[0000068505-25-000012:mdna:272]
The increase in cash used for financing activities in 2024 compared to cash used for financing activities in 2023 was driven by (also see further discussion in "Debt," "Credit Facilities," "Share Repurchase Program" and "Dividends" in this section below):

[0000068505-25-000012:mdna:273]
•$1.9 billion increase in repayments of debt in 2024 primarily driven by the repurchase of the Silver Lake Convertible Debt and repayment of our 4.0% senior notes due 2024;

[0000068505-25-000012:mdna:274]
•$654 million cash used for the payment of dividends in 2024 compared to $589 million in 2023; and

[0000068505-25-000012:mdna:275]
•$75 million in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2024 compared to $104 million in 2023; partially offset by

[0000068505-25-000012:mdna:276]
•$1.3 billion in net proceeds in 2024 driven by the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; and

[0000068505-25-000012:mdna:277]
•$247 million used for purchases under our share repurchase program in 2024 compared to $804 million in 2023.

[0000068505-25-000012:mdna:278]
The increase in cash used for financing activities in 2023 compared to cash used for financing activities in 2022 was driven by:

[0000068505-25-000012:mdna:279]
•$589 million cash used for the payment of dividends in 2023 compared to $530 million in 2022; and

[0000068505-25-000012:mdna:280]
•$104 million in net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans in 2023 compared to $156 million in 2022; partially offset by

[0000068505-25-000012:mdna:281]
•$595 million in net proceeds in 2022 from the issuance of $600 million of 5.6% senior notes due 2032, of which a portion was subsequently used to repurchase $275 million principal amount of our 4.0% senior notes due 2024 for a purchase price of $279 million, excluding $3 million of accrued interest; and

[0000068505-25-000012:mdna:282]
•$804 million used for purchases under our share repurchase program in 2023 compared to $836 million in 2022.

[0000068505-25-000012:mdna:283]
Sales of Receivables

[0000068505-25-000012:mdna:284]
We may choose to sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-25-000012:mdna:285]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2024, 2023, and 2022:

[0000068505-25-000012:mdna:286]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| Contract-specific discounting facility | $ | — |  |  | $ | — |  |  | $ | 49 |  |
| Accounts receivable sales proceeds | 15 |  |  | 96 |  |  | 179 |  |
| Long-term receivables sales proceeds | 205 |  |  | 182 |  |  | 204 |  |
| Total proceeds from receivable sales | $ | 220 |  |  | $ | 278 |  |  | $ | 432 |  |

[0000068505-25-000012:mdna:287]
At December 31, 2024, the Company had retained servicing obligations for $794 million of long-term receivables, compared to $813 million of long-term receivables at December 31, 2023. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-25-000012:mdna:288]
Debt

[0000068505-25-000012:mdna:289]
We had outstanding long-term debt of $6.0 billion at each of December 31, 2024 and 2023, including the current portions of $322 million and $1.3 billion, at December 31, 2024 and December 31, 2023, respectively.

[0000068505-25-000012:mdna:290]
During the year ended December 31, 2024, we repaid the $313 million aggregate principal amount of our 4.0% senior notes due 2024.

[0000068505-25-000012:mdna:291]
As of December 31, 2024, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were classified within the Current portion of long-term debt within the Company's Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-25-000012:mdna:292]
On September 5, 2019, we entered into an agreement with Silver Lake Partners to issue the Silver Lake Convertible Debt, which became fully convertible on September 5, 2021. On February 14, 2024, we agreed with Silver Lake Partners to repurchase $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded upon settlement, representing the excess of amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Consolidated Statements of Operations during the year ended December 31, 2024.

[0000068505-25-000012:mdna:293]
On March 25, 2024, we issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. We recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt.

[0000068505-25-000012:mdna:294]
49

[0000068505-25-000012:mdna:295]
In May of 2022, we issued $600 million of 5.6% senior notes due 2032. We recognized net proceeds of $595 million after debt issuance costs and discounts. A portion of these proceeds was then used to repurchase $275 million in principal amount of the Company's 4.0% senior notes due 2024 pursuant to a cash tender offer, for a purchase price of $279 million, excluding $3 million of accrued interest. After accelerating the amortization of debt discounts and debt issuance costs, we recognized a loss of $6 million related to the tender offer in Other, net within Other income (expense) in our Consolidated Statements of Operations.

[0000068505-25-000012:mdna:296]
We have an unsecured commercial paper program, backed by the revolving credit facility described below, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2024, we had no outstanding debt under the commercial paper program.

[0000068505-25-000012:mdna:297]
Credit Facilities

[0000068505-25-000012:mdna:298]
As of December 31, 2024, we had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate ("SOFR"), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2024.

[0000068505-25-000012:mdna:299]
We have investment grade ratings on our senior unsecured long-term debt. During the year ended December 31, 2024, Fitch Ratings and S&P Global Ratings upgraded our credit ratings to BBB from BBB-. We continue to believe that we will be able to maintain sufficient access to the capital markets in the next twelve months and the foreseeable future.

[0000068505-25-000012:mdna:300]
Share Repurchase Program

[0000068505-25-000012:mdna:301]
Through a series of actions, the Board of Directors has authorized an aggregate share repurchase amount of up to $18.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2024, we used approximately $15.8 billion of the share repurchase authority to repurchase shares, leaving approximately $2.2 billion of authority available for future repurchases. During the year ended December 31, 2024, we paid $3 million of 1% excise tax pursuant to the Inflation Reduction Act of 2022, related to our 2023 share repurchases in excess of issuances.

[0000068505-25-000012:mdna:302]
Our share repurchases for 2024, 2023, and 2022 are summarized as follows:

[0000068505-25-000012:mdna:303]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2024 | 0.6 |  |  | $ | 396.69 |  |  | $ | 244 |  |
| 2023 | 2.9 |  |  | 278.56 |  |  | 804 |  |
| 2022 | 3.7 |  |  | 225.00 |  |  | 836 |  |

[0000068505-25-000012:mdna:304]
Dividends

[0000068505-25-000012:mdna:305]
We paid cash dividends to holders of our common stock of $654 million in 2024, $589 million in 2023, and $530 million in 2022. On January 15, 2025, we paid an additional $182 million in cash dividends to holders of our common stock.

[0000068505-25-000012:mdna:306]
Adequate Internal Funding Resources

[0000068505-25-000012:mdna:307]
We believe that we have adequate internal resources available to generate adequate amounts of cash to meet our expected working capital, capital expenditure and cash requirements for the next twelve months and the foreseeable future, as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, cash provided by operations, as well as liquidity provided by our commercial paper program backed by the 2021 Motorola Solutions Credit Agreement.

[0000068505-25-000012:mdna:308]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Refer also to "Part I. Item 1A. Risk Factors" of this Form 10-K for further discussion regarding access to the capital markets.

[0000068505-25-000012:mdna:309]
Material Cash Requirements from Contractual and Other Obligations

[0000068505-25-000012:mdna:310]
Summarized in the table and text below are our short-term (within the next twelve months) and long-term material cash requirements as of December 31, 2024, which we expect to fund with a combination of operating cash flows, existing cash balances or, as needed, borrowings under new or existing debt:

[0000068505-25-000012:mdna:311]
|  | Payments Due by Period |
| (in millions) |  | Short-term |  | Long-term |
| Long-term debt obligations, gross(1) |  | $ | 322 |  |  | $ | 5,726 |  |
| Lease obligations(2) |  | 146 |  |  | 467 |  |
| Purchase obligations(3) |  | 151 |  |  | 562 |  |
| Total obligations |  | $ | 619 |  |  | $ | 6,755 |  |

[0000068505-25-000012:mdna:312]
(1)Amounts included represent the estimated principal payments applicable to outstanding debt. Refer to "Note 5: Debt and Credit Facilities" in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for discussion related to our long-term debt obligations.

[0000068505-25-000012:mdna:313]
(2)We lease certain office, factory and warehouse space, land, and other equipment, principally under non-cancelable operating leases. We are evaluating our real estate needs in order to identify opportunities to reduce long-term cash requirements for office space where practicable. Refer to "Note 3: Leases" to our consolidated financial statements in "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further discussion of these material lease obligations.

[0000068505-25-000012:mdna:314]
(3)Amounts included represent firm, non-cancelable commitments. Such commitments include license agreements and agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. We do not anticipate the cancellation of any of our take-or-pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-25-000012:mdna:315]
Other Contingencies

[0000068505-25-000012:mdna:316]
Potential Contractual Damage Claims in Excess of Underlying Contract Value: In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-25-000012:mdna:317]
Indemnification Provisions: We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us.

[0000068505-25-000012:mdna:318]
Legal Matters: We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position or liquidity. However, an unfavorable resolution could have a material adverse effect on our results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-25-000012:mdna:319]
Long-term Customer Financing Commitments

[0000068505-25-000012:mdna:320]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $105 million at December 31, 2024 and $103 million at December 31, 2023.

[0000068505-25-000012:mdna:321]
Critical Accounting Estimates

[0000068505-25-000012:mdna:322]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-25-000012:mdna:323]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. We believe that the following discussion addresses our most critical accounting estimates, which are those that are most important to the portrayal of our financial condition and results of operations and require management’s most difficult, subjective and complex judgments.

[0000068505-25-000012:mdna:324]
Revenue Recognition

[0000068505-25-000012:mdna:325]
We enter into arrangements which generally consist of multiple promises to our customers. We evaluate whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, we allocate the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We use list price as the standalone selling price for sales sold through our channel partners. Given the unique nature of the goods and services we provide to direct customers, standalone sales of our products generally do not exist. Therefore, we determine ESP by: (i) collecting all reasonably available data points including historical sales, cost and margin analyses of the product or services, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points for similar customers and circumstances, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-25-000012:mdna:326]
We account for certain system contracts on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-25-000012:mdna:327]
For system contracts accounted for over time using estimated costs as a measure of performance completed, we rely on estimates around the total estimated costs to complete the contract (“Estimated Costs to Complete”). Estimated Costs to Complete include direct labor, equipment and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs to Complete may be complex and subject to many variables. We have a standard and disciplined process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs to Complete. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor costs, inclusive of subcontractors, and the cost of materials, among other variables. Based on this analysis, any adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-25-000012:mdna:328]
Retirement Benefits

[0000068505-25-000012:mdna:329]
Our benefit obligations and net periodic pension costs (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits Plan”), are determined using actuarial assumptions. The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-25-000012:mdna:330]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases. As such, depending on the specific plan, we amortize gains and losses over periods ranging from eight to twenty-five years. Prior service costs are being amortized over periods ranging from one to fifteen years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-25-000012:mdna:331]
There are various assumptions used in calculating the net periodic costs (benefits) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns. We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-25-000012:mdna:332]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost (benefit) and the net postretirement health care benefit. Our investment return assumption for the U.S. Pension Benefit Plans was 7.74% in 2024 and 7.87% in 2023. Our investment return assumption for the Postretirement Health Care Benefits Plan was 8.30% in 2024 and 8.00% in 2023. Our weighted average investment return assumption for the Non-U.S. Plans was 5.84% in 2024 and 6.18% in 2023. For the U.S. Pension Benefit Plans, a 25 bps increase in expected return on plan assets would result in $10 million of additional net periodic pension benefit and a 25 bps decrease would result in a $10 million reduction in net periodic pension benefit in 2024. For the Non-U.S. Pension Benefit Plans, a 25 bps increase in expected return on plan assets would result in $4 million of additional net periodic pension benefit and a 25 bps decrease would result in a $4 million reduction in net periodic pension benefit in 2024. For the Postretirement Health Care Benefits Plan, a change in expected return on plan assets would have a de minimis impact to net periodic pension benefit in 2024.

[0000068505-25-000012:mdna:333]
A second key assumption is the discount rate. The discount rate assumptions used for the U.S. Pension Benefit Plans, the Non-U.S. Plans and the Postretirement Health Care Benefits Plan reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. Pension Benefit Plan obligations were 5.70% and 5.01% at December 31, 2024 and 2023, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 5.07% and 4.3% at December 31, 2024 and 2023, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 5.49% and 4.92% at December 31, 2024 and 2023, respectively.

[0000068505-25-000012:mdna:334]
For the U.S. Pension Benefit Plans, a 25 bps increase in the discount rate on the projected benefit obligation would result in a $109 million reduction of the projected benefit obligation and a 25 bps decrease would result in $115 million of additional projected benefit obligation in 2024. For the Non-U.S. Pension Benefit Plans and the Postretirement Health Care Benefits Plan, a 25 bps change in our discount rate would be de minimis in 2024.

[0000068505-25-000012:mdna:335]
Valuation and Recoverability of Goodwill

[0000068505-25-000012:mdna:336]
We assess the recorded amount of goodwill for recovery on an annual basis as of the last day of the third quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: (i) adverse changes in macroeconomic conditions, (ii) adverse changes in the industry or market in which we transact, (iii) changes in cost factors negatively impacting earnings and cash flows, (iv) negative or declining overall financial performance, (v) events affecting the carrying value or composition of a reporting unit, or (vi) a sustained decrease in share price, among others. Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-25-000012:mdna:337]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Systems Integration and Software and Services segments are comprised of three and two reporting units, respectively.

[0000068505-25-000012:mdna:338]
We performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2024 and 2023. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value and entity-specific events. For fiscal years 2024 and 2023, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-25-000012:mdna:339]
Valuation of Deferred Tax Assets and Liabilities

[0000068505-25-000012:mdna:340]
We use the asset and liability method of accounting for income taxes. Under this method, income tax expense is recognized for the amount of taxes payable or refundable for the current year. In addition, deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Management makes assumptions, judgments and estimates to determine our current and deferred tax provision and also the deferred tax assets and liabilities. We evaluate our deferred tax assets quarterly to determine if adjustments to our valuation allowance are required based on the consideration of all available positive and negative evidence.

[0000068505-25-000012:mdna:341]
Our assumptions, judgments and estimates for computing the income tax provision takes into account current tax laws, our interpretation of current tax law and possible outcomes of current and future audits conducted by foreign and domestic tax authorities. We believe such estimates to be reasonable; however, the final determination of certain audits could significantly impact the amounts provided for income taxes in our financial statements.

[0000068505-25-000012:mdna:342]
53

[0000068505-25-000012:mdna:343]
Recent Accounting Pronouncements and Recently Adopted Accounting Pronouncements

[0000068505-25-000012:mdna:344]
See “Note 1: Summary of Significant Accounting Policies” to our consolidated financial statements in “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-25-000012:mdna:345]
54
