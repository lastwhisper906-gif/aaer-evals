# MSI notes — 0000068505-25-000012


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000068505-25-000012:notes:1]
Portions of the registrant’s definitive Proxy Statement to be delivered to stockholders in connection with its 2025 Annual Meeting of Shareholders (the "Proxy Statement"), to be filed within 120 days of the end of the fiscal year ended December 31, 2024, are incorporated by reference into Part III of this Annual Report on Form 10-K (this "Form 10-K").


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000068505-25-000012:notes:2]
We assess, identify and manage material risks from cybersecurity threats through various protective policies, procedures and processes, including through: (1) the monitoring responsibilities of our cybersecurity program; (2) our information security policies and standards, including our global incident response procedure; (3) our audit services department’s annual enterprise risk management (“ERM”) assessment; (4) our third-party cybersecurity risk assessment program; and (5) cybersecurity insurance.

[0000068505-25-000012:notes:3]
Designed to maintain the confidentiality, integrity and availability of customer and internal company information, our cybersecurity program focuses on protecting our enterprise information systems and the secure development and deployment of our products. We monitor for critical vulnerabilities and threat actor activity, and work to create a unified view to prioritize protecting our critical infrastructure (including potential impacts to key third-party service providers to the Company). The cybersecurity program, which is led by our Vice President of Cybersecurity & Information Technology Infrastructure, holds regular meetings to review ongoing internal information security investigations. We assess the effectiveness of our cybersecurity program using self-assessments and independent third-party analyses, and evaluate our program using frameworks such as the National Institute of Standards and Technology (“NIST”) Cybersecurity Framework. In addition to these independent third-party analyses, third-parties also provide services to support our cybersecurity in several ways, such as through penetration testing and commercial information security threat sharing networks, and by assisting with tabletop exercises and certain monitoring activities.

[0000068505-25-000012:notes:4]
We have designed and implemented a global incident response procedure, which helps enable us to quickly detect, respond to, and recover from third-party malicious attacks and potential security incidents. This procedure includes formal steps to review incidents and implement improvements, including steps to involve the Vice President of Cybersecurity & Information Technology Infrastructure, as appropriate. In addition, we have other specific information security policies and standards, organized to align with various NIST frameworks, which we use to manage our cybersecurity risks.

[0000068505-25-000012:notes:5]
Assessing, identifying and managing cybersecurity risks are integrated into our audit services department’s annual ERM assessment, which is designed to identify, assess, prioritize, mitigate and monitor our principal risks. The ERM assessment considers the probability, impact and velocity of potential risks, providing management and the Audit Committee with an overarching and objective view of the Company's risk management activities. Audit services identifies and conducts engagements utilizing inputs from the ERM assessment. The engagements span financial, operational, strategic and compliance risks, with a view to assessing risks over a two-year time horizon. The engagement results assist management in maintaining acceptable risk levels. The Vice President of Audit Services reports directly to the Audit Committee as well as to the Chief Financial Officer and meets regularly with the Audit Committee and its chairperson, including in executive sessions. Separately, the Vice President of Audit Services and Vice President of Ethics & Compliance head an internal cross-functional team (including members from our cybersecurity and data privacy programs, among others) that holds regular meetings to discuss the key risks facing the Company and related mitigation efforts, including cybersecurity risks. Cybersecurity risk is tracked as a principal risk within the context of the ERM assessment.

[0000068505-25-000012:notes:6]
In addition, we have processes designed to oversee and identify risks from cybersecurity threats associated with our use of third-party service providers. Pursuant to our third-party cybersecurity risk assessment program, any outsource partners and suppliers that have access to the Company’s data or customer data complete a risk assessment prior to the Company engaging with such parties. Using the assessments, our cybersecurity program looks to determine any gaps and identified risks, and then appropriate teams within the Company work to track and remediate such risks. These third-party risk assessments are foundational for how we manage and monitor our supply chain.

[0000068505-25-000012:notes:7]
To further complement the processes described above, we maintain insurance related to cybersecurity risks. We maintain a broad portfolio of insurance coverage, leveraging the products of multiple companies to help ensure appropriate protection.

[0000068505-25-000012:notes:8]
We are subject to attempts to compromise our information technology systems from both internal and external sources. Like all information technology systems, our systems have been in the past, and could be in the future, vulnerable to damage, unauthorized access or interruption from a variety of sources. As of the filing of this Form 10-K, we are not aware of any such attacks that have occurred since the beginning of 2024 that have materially affected, or are reasonably likely to materially affect, us, including our business strategy, results of operations or financial condition. However, if as a result of any future attacks our information technology systems are significantly damaged, cease to function properly or are subject to a significant cybersecurity breach, we may suffer an interruption in our ability to manage and operate our business, and our business strategy, results of operations or financial condition could be adversely affected. Such attacks, whether or not successful, could damage our reputation and result in significant costs related to, for example, repairing or replacing our IT systems; the loss of critical data; interruptions or delays in our ability, or that of our customers, to perform critical functions; defending against claims for breach of contracts, tort and other civil claims without adequate indemnification from our suppliers; providing time-sensitive notification requirements; and providing modifications or replacements to our products and services. In addition, the volume, frequency and sophistication of these threats (including through the use of AI) continues to grow and the complexity and scale of the systems to be protected continues to increase. See “Risks Related to Information Technology and Intellectual Property” in “Part I. Item 1A. Risk Factors” of this Form 10-K for further information.


## cyd:CybersecurityRiskBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0000068505-25-000012:notes:9]
The Vice President of Audit Services reports directly to the Audit Committee as well as to the Chief Financial Officer and meets regularly with the Audit Committee and its chairperson, including in executive sessions.Our Vice President of Cybersecurity & Information Technology Infrastructure, along with this individual's teams, are in charge of assessing and managing our risks related to cybersecurity, including by setting our strategy, policies, standards and processes in these areas, as further described above under “Risk Management & Strategy.” Utilizing the processes noted above, these teams remain informed about and monitor the prevention, detection, mitigation and remediation of cybersecurity incidents.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000068505-25-000012:notes:10]
Our Board has delegated to the Audit Committee the responsibility to oversee risks related to cybersecurity threats. Specifically, subject to oversight by the full Board, the Vice President of Cybersecurity & Information Technology Infrastructure provides the Audit Committee with periodic cybersecurity and information security reports, including recent cybersecurity incidents and cybersecurity products and operations. Annually, the Vice President of Audit Services reviews the results of the ERM assessment with the Audit Committee as well. In addition, a subset or the full group of certain individuals, such as our Chief Information Officer, Vice President of Cybersecurity & Information Technology Infrastructure, and Data Protection Officer, present at least once per year to the Audit Committee regarding cybersecurity and data privacy risk topics. The full Board is regularly informed about such risks through Audit Committee reports and presentations.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0000068505-25-000012:notes:11]
Our Vice President of Cybersecurity & Information Technology Infrastructure, along with this individual's teams, are in charge of assessing and managing our risks related to cybersecurity, including by setting our strategy, policies, standards and processes in these areas, as further described above under “Risk Management & Strategy.” Utilizing the processes noted above, these teams remain informed about and monitor the prevention, detection, mitigation and remediation of cybersecurity incidents.

[0000068505-25-000012:notes:12]
Our Vice President of Cybersecurity & Information Technology Infrastructure has over thirty years of work experience in the information technology field, specifically information security. This individual began their career as a security engineer, progressing to a security architect, and then to overall leader of the Cybersecurity and Information Technology Infrastructure functions at the Company. This individual holds a Master of Computer Science degree. This individual also maintains a Certified Information Security Manager (CISM) certification from ISACA, an international professional organization focused on IT governance, as well as a Certified Information Systems Security Professional (CISSP) certification from the International Information System Security Certification Consortium (ISC2), a leading member association for cybersecurity professionals.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-25-000012:notes:13]
Summary of Significant Accounting Policies
Principles of Consolidation: The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-25-000012:notes:14]
The consolidated financial statements as of December 31, 2024 and 2023 and for the years ended December 31, 2024, 2023 and 2022, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.

[0000068505-25-000012:notes:15]
Use of Estimates: The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-25-000012:notes:16]
Revenue Recognition: Net sales consist of a wide range of goods and services including the delivery of products, systems and system integration as well as offering software and service solutions. The Company recognizes revenue to reflect the transfer of control of promised goods or services to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for goods or services.

[0000068505-25-000012:notes:17]
The Products and Systems Integration segment is comprised of devices, systems, and systems integration for our Land Mobile Radio Communication ("LMR" or "LMR Communications") and Video Security and Access Control ("Video") technologies. Direct customers of the Products and Systems Integration segment are typically government, public safety agencies, procuring at state, local, and federal levels as well as large commercial customers with secure mission-critical needs. Indirect customers are defined as customers purchasing professional and commercial radios and video security, which are primarily sold through the Company's reseller partners to an end-customer base, composed of various industries where private communications systems and video security are used to secure operations and enable a mobile workforce. Contracts with the Company's customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our government customers, funded through appropriations. The Company records consideration from shipping and handling on a gross basis within Net sales. In limited instances where the Company is not the principal in the arrangement, the Company will recognize revenue on a net basis.

[0000068505-25-000012:notes:18]
LMR and Video devices include two-way portable and vehicle-mounted radios, video cameras and accessories. Devices are considered capable of being distinct and distinct within the context of the Company's contracts. Revenue is recognized upon the transfer of control of the devices to the customer at a point in time, typically consistent with delivery under the applicable shipping terms. Devices are sold by both the direct sales force and through reseller partners. Revenue is generally recognized upon transfer of devices to reseller partners, rather than the end-customer, except for limited consignment arrangements. Provisions for returns and reseller discounts are made on a portfolio basis using historical data.

[0000068505-25-000012:notes:19]
The Products and Systems Integration segment includes both customized communications systems and video security solutions, including the integration of these networks with devices, software, and applications within both LMR and Video technologies. For systems contracts, revenue for the year ended December 31, 2024 was $2.0 billion compared to $1.9 billion for the year ended December 31, 2023 and $1.8 billion for the year ended December 31, 2022. The communications systems include the aggregation of promises to the customer to provide i) a communications network core and central processing software, base stations, consoles, and repeaters or ii) a video security solution including video analytics, network video management hardware and software, and access control solutions. The individual promises within a communications network contract are not distinct in the context of the contract, as the Company provides a significant service of integrating and customizing the goods and services promised. The communications network represents a distinct performance obligation for which revenue is recognized over time, as the Company creates an asset with no alternative use and has an enforceable right to payment for work performed. The Company's revenue recognition over time is based on an input measure of costs incurred, which depicts the transfer of control to its customers under its contracts. Products and Systems Integration revenue for communications network systems is recognized over an average duration of approximately one to two years. Individual promises of the video security solution are capable of being distinct and distinct in the context of the contract. Video security solutions are traditionally sold through reseller partners, with contracts negotiated under fixed pricing. Revenue is recognized upon the transfer of control of the video solution to the reseller partners, typically upon shipment.

[0000068505-25-000012:notes:20]
The Software and Services segment provides solutions for government, public safety and commercial communications systems. Direct customers of the Software and Services segment are typically government, public safety and first-responder agencies and municipalities. Indirect customers are commercial customers who distribute our software solutions to a final end customer base. Contracts with our customers are typically fixed fee, with consideration measured net of associated sales taxes, and, as it relates to our direct customers, funded through government appropriations.

[0000068505-25-000012:notes:21]
Software offerings primarily include Command Center and Video software and services which can be delivered either as an “as-a-service”, on-premise, or hybrid solution. Solutions delivered as-a-service consist of a range of promises including hosted software, technical support and the right to unspecified future software enhancements. Software is not distinct from the hosting service since the customer does not have the right to take possession of the software at any time during the term of the arrangement. Solutions delivered as-a-service are recognized over time on a straight-line basis as a series of distinct services.

[0000068505-25-000012:notes:22]
On-premise and hybrid offerings generally consist of multiple promises primarily including software licenses and post-contract customer support. The promises are generally each distinct and distinct within the context of the contract as the customer benefits from each promise individually without any significant integration or interrelationship between the promises. On-premise software revenue is generally recognized at the point in time when the customer can benefit from the software which generally aligns with the beginning of the license period. Revenue for post-contract customer support is recognized over time as the customer simultaneously receives and consumes the services on a straight-line basis. In certain situations when the software license is not distinct within the context of the contract, revenue for the software license is recognized over time following the transfer of control under the arrangement. For hybrid arrangements, the on-premise software, cloud-based software, and implementation services are a single performance obligation, where in over time revenue recognition begins at the point of service activation when the customer can access the system and begin beneficial use.

[0000068505-25-000012:notes:23]
Services include a continuum of service offerings beginning with repair, technical support and maintenance. More advanced offerings include: monitoring, software updates and cybersecurity services. Managed service offerings range from partial to full operation of customer-owned or Motorola Solutions-owned communications systems. Services are provided across all technologies and are both distinct and capable of being distinct in the context of the contract, representing a series of recurring services that the Company stands ready to perform over the contract term. Since services contracts typically allow for customers to terminate for convenience or for non-appropriations of fiscal funding, the contract term is generally considered to be limited to a monthly or annual basis, subject to customer renewal. While contracts with customers are typically fixed fee, certain managed services contracts may be subject to variable consideration related to the achievement of service level agreement performance measurements. The Company has not historically paid significant penalties under service level agreements, and accordingly, it does not constrain its contract price. Certain contracts may also contain variable consideration driven by the number of users. Revenue is typically recognized on services over time as a series of services performed over the contract term on a straight-line basis.

[0000068505-25-000012:notes:24]
The Company enters into arrangements which generally consist of multiple promises to our customers. The Company evaluates whether the promised goods and services are distinct or a series of distinct goods or services. Where contracts contain multiple performance obligations, the Company allocates the total estimated consideration to each performance obligation based on applying an estimated selling price (“ESP”) as our best estimate of standalone selling price. We use list price as the standalone selling price for indirect sales sold through our channel partners. Given the unique nature of the goods and services we provide to direct customers, sufficient standalone sales of our products generally do not exist. Therefore, the Company determines ESP by: (i) collecting all reasonably available historical data points including sales, cost and margin analyses of the product or services, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points for similar customers and circumstances, when appropriate, based on major product or service, type of customer, geographic market, and sales volume.

[0000068505-25-000012:notes:25]
The Company accounts for certain system contracts without an alternative use on an over time basis, electing an input method of estimated costs as a measure of performance completed. The selection of costs incurred as a measure of progress aligns the transfer of control to the overall production of the customized system.

[0000068505-25-000012:notes:26]
For system contracts accounted for over time using estimated costs as a measure of performance completed, the Company relies on estimates around the total estimated costs to complete the contract ("Estimated Costs to Complete"). Estimated Costs to Complete include direct labor, material and subcontracting costs. Due to the nature of the efforts required to be performed to meet the underlying performance obligation, determining Estimated Costs to Complete may be complex and subject to many variables. The Company has a standard and disciplined process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs to Complete. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of costs. The risks and opportunities include management’s judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor cost, inclusive of subcontractors, and the cost of materials, among other variables. Based on this analysis, any adjustment to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period in which the loss is determined.

[0000068505-25-000012:notes:27]
Cash Equivalents: The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $3 million and $2 million as of December 31, 2024 and December 31, 2023, respectively.

[0000068505-25-000012:notes:28]
Investments: The Company generally invests in equity securities of a strategic nature.

[0000068505-25-000012:notes:29]
The Company applies the equity method of accounting for equity investments if the Company has significant influence over the issuing entity. The Company’s share of the investee’s underlying net income or loss is recorded to Other, net within Other income (expense).

[0000068505-25-000012:notes:30]
Equity securities with readily determinable fair values are carried at fair value with changes in fair value recorded in Other, net within Other income (expense). Equity securities without readily determinable fair values are carried at cost, less impairments, if any, and adjusted for observable price changes for the identical or a similar investment of the same issuer. The Company performs a qualitative impairment assessment to determine if such investments are impaired. The qualitative assessment considers all available information, including declines in the financial performance of the issuing entity, the issuing entity’s operating environment, and general market conditions. Impairments of equity securities without readily determinable fair values are recorded to Other, net within Other income (expense).

[0000068505-25-000012:notes:31]
Inventories: Inventories are valued at the lower of cost (which approximates cost on a first-in, first-out basis) and net realizable value.

[0000068505-25-000012:notes:32]
Property, Plant and Equipment: Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (leasehold improvements, one to twenty years; machinery and equipment, one to fifteen years) and commences once the assets are ready for their intended use. When certain events or changes in operating conditions occur, useful lives of the assets may be adjusted or an impairment assessment may be performed on the recoverability of the carrying value.

[0000068505-25-000012:notes:33]
Goodwill and Intangible Assets: Goodwill is assessed for impairment at least annually at the reporting unit level, or more frequently if events or circumstances occur that would more likely than not reduce the fair value of a reporting unit below its carrying value level. The Company performs its annual assessment of goodwill for impairment as of the last day of the third quarter of each fiscal year, typically through a qualitative assessment. Indicators of impairment include: (i) macroeconomic conditions, (ii) industry and market conditions, (iii) cost factors, including product and selling, general and administrative costs, (iv) overall financial performance of the Company, (v) changes in share price, and (vi) other relevant company-specific events. If it is determined that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the Company will perform a quantitative goodwill impairment test, which compares the fair value of the reporting unit to its carrying value. A quantitative assessment includes the assignment of assets and liabilities to each of the Company's reporting units and an assessment of the fair value of each of the Company's reporting units. The Company utilizes an income approach (discounted cash flows) to estimate the fair value of each reporting unit, which is corroborated by market multiples when available and as appropriate. Key assumptions in the quantitative analysis include revenue growth rates (including long-term growth rates for terminal value assumptions), operating margin estimates, discount rates, and where applicable, the comparable multiples from publicly traded companies in the Company's industry.

[0000068505-25-000012:notes:34]
If the carrying amount of a reporting unit exceeds its fair value, the Company would recognize an impairment loss in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0000068505-25-000012:notes:35]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to twenty years. The Company has no intangible assets with indefinite useful lives.

[0000068505-25-000012:notes:36]
Leases: The Company leases certain office, factory and warehouse space, land and other equipment, principally under non-cancelable operating leases.

[0000068505-25-000012:notes:37]
The Company determines if an arrangement is a lease at inception of the contract. The Company’s key considerations in determining whether a contract is or contains a lease include establishing whether the supplier has the ability to use other assets to fulfill its service or whether the terms of the agreement enable the Company to control the use of a dedicated asset during the contract term. In the majority of the Company’s contracts where it must identify whether a lease is present, it is readily determinable that the Company controls the use of the assets and obtains substantially all of the economic benefit during the term of the contract. In those contracts where identification is not readily determinable, the Company has determined that the supplier has either the ability to use another asset to provide the service or the terms of the contract give the supplier the right to operate the asset at its discretion during the term of the contract.

[0000068505-25-000012:notes:38]
Right-of-use ("ROU") assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at the commencement date. The Company’s lease payments are typically fixed or contain fixed escalators. The Company has elected to not separate lease and non-lease components for all of its current lease categories and therefore, all consideration is included in lease payments. For the Company’s leases consisting of land and other equipment (i.e. “communications network sites”), future payments are subject to variability due to changes in indices or rates. The Company values its ROU assets and lease liabilities based on the index or rate in effect at lease commencement. Future changes in the indices or rates are accounted for as variable lease costs. Other variable lease costs include items that are not fixed at lease commencement including property taxes, insurance, and operating charges that vary based on usage. ROU assets also include lease payments made in advance and are net of lease incentives.

[0000068505-25-000012:notes:39]
As the majority of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rates based on the information available at the commencement date in determining the present value of future payments. The Company’s incremental borrowing rates are based on the term of the lease, the economic environment of the lease, and the effect of collateralization.

[0000068505-25-000012:notes:40]
The Company's lease terms range from one to twenty-one years and may include options to extend the lease by one to ten years or terminate the lease after the initial non-cancelable term. The Company does not include options in the determination of the lease term for the majority of leases as sufficient economic factors do not exist that would compel it to continue to use the underlying asset beyond the initial non-cancelable term. However, for the Company's communications network site leases that are necessary to provide services to customers under managed service arrangements, the Company includes options in the lease term to the extent of the customer contracts to which those leases relate.

[0000068505-25-000012:notes:41]
Impairment of Long-Lived Assets: Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-25-000012:notes:42]
Income Taxes: The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expenses and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-25-000012:notes:43]
Long-Term Receivables: Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. The Company estimates credit losses on accounts receivable based on historical losses and then takes into account estimates of current and future economic conditions. Long-term receivables are considered past due if payments have not been received according to the contractual terms of the note agreement, including principal and interest. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under restructuring for four consecutive quarters.

[0000068505-25-000012:notes:44]
Environmental Liabilities: The Company maintains a liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Comprehensive Environmental Response, Compensation and Liability Act (commonly known as the “Superfund Act”) incurred by a legacy business. It is the Company’s policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. When the timing and amount of the future cash payments are fixed or reliably determinable, the Company discounts the future cash flows used in estimating the accrual using a risk-free treasury rate. The current portion of the estimated environmental liability is included in the Accrued liabilities statement line and the non-current portion is included in the Other liabilities statement line within the Company’s Consolidated Balance Sheet.

[0000068505-25-000012:notes:45]
Foreign Currency: Certain non-U.S. operations within the Company use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s Consolidated Balance Sheet. For those operations that have transactions denominated in local currency which differs from functional currency, transactions denominated in the local currency are measured in their functional currency using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s Consolidated Statements of Operations.

[0000068505-25-000012:notes:46]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure.

[0000068505-25-000012:notes:47]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows, net investments or monetary assets and liabilities based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions or net investments in some of its overseas entities, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-25-000012:notes:48]
Derivative Instruments: For Foreign exchange contracts, not designated as hedging instruments, gains and losses are recorded immediately in Other income (expense) within the Consolidated Statements of Operations. For Equity swap contracts, which do not qualify for hedge accounting, gains and losses are recorded immediately in Selling, general and administrative expenses within the Consolidated Statements of Operations. Gains and losses pertaining to instruments designated as net investment hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income. Components excluded from the assessment of hedge ineffectiveness in net investment hedges are included in Accumulated other comprehensive income at their initial value and amortized into Interest expense, net on a straight-line basis. Gains and losses pertaining to instruments designated as cash flow hedges that qualify for hedge accounting are recognized as a component of Accumulated other comprehensive income.

[0000068505-25-000012:notes:49]
Fair Value Measurements: The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date and is measured using the fair value hierarchy. This hierarchy prescribes valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies are as follows:

[0000068505-25-000012:notes:50]
Level 1 — Quoted prices for identical instruments in active markets.

[0000068505-25-000012:notes:51]
Level 2 — Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-25-000012:notes:52]
Level 3 — Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-25-000012:notes:53]
Earnings Per Share: The Company calculates its basic earnings per share based on the weighted-average number of common shares issued and outstanding. Net earnings attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings per share. Diluted earnings per share is calculated by dividing net earnings attributable to Motorola Solutions, by the sum of the weighted-average number of common shares used in the basic earnings per share calculation and the weighted-average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings per share calculation. Both basic and diluted earnings per share amounts are calculated for net earnings attributable to Motorola Solutions for all periods presented.

[0000068505-25-000012:notes:54]
Share-Based Compensation Costs: The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk-free rate, dividend yield, and expected life. Performance-based stock options, performance stock units, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-25-000012:notes:55]
Defined Benefit Plans: The Company records annual expenses relating to its defined benefit plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from eight to twenty-five years. Prior service costs will be amortized over periods ranging from one to fifteen years. Benefits under all pension plans are valued based on the projected unit credit cost method. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-25-000012:notes:56]
The benefit obligation and plan assets for the Company's defined benefit plans are presented on a net basis according to the plans' net funded status and measured as of December 31, 2024.

[0000068505-25-000012:notes:57]
Recent Acquisitions:

[0000068505-25-000012:notes:58]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.

[0000068505-25-000012:notes:59]
On July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

[0000068505-25-000012:notes:60]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The acquisition expands the Company's video solutions within the Software and Services segment.

[0000068505-25-000012:notes:61]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The business is part of the Products and System Integration segment.

[0000068505-25-000012:notes:62]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The business is a part of the Products and Systems Integration segment.

[0000068505-25-000012:notes:63]
On December 14, 2022, the Company acquired Rave Mobile, a leader in mass notification and incident management, for $553 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The business is a part of the Software and Services segment.

[0000068505-25-000012:notes:64]
On October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's communications network and device portfolios. The business is a part of the Products and Systems Integration segment.

[0000068505-25-000012:notes:65]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The business is a part of the Products and Systems Integration segment.

[0000068505-25-000012:notes:66]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The business is a part of the Products and Systems Integration segment.

[0000068505-25-000012:notes:67]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The business is a part of the Software and Services segment.

[0000068505-25-000012:notes:68]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. The business is part of the Software and Services segment.

[0000068505-25-000012:notes:69]
On March 3, 2022, the Company acquired Ava, a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The business is a part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-25-000012:notes:70]
Recent Accounting Pronouncements:

[0000068505-25-000012:notes:71]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods beginning in 2028, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-25-000012:notes:72]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.

[0000068505-25-000012:notes:73]
Recently Adopted Accounting Pronouncements:
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The Company adopted ASU No. 2023-07 for the year ended December 31, 2024 and applied the required retrospective transition method. Refer to "Note 13: Information by Segment and Geographic Region" to our consolidated financial statements in this "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-25-000012:notes:74]
Revenue from Contracts with Customers
Disaggregation of Revenue

[0000068505-25-000012:notes:75]
The following table summarizes the disaggregation of our revenue by segment, geography, major product and service type and customer type for the years ended December 31, 2024, 2023 and 2022, consistent with the information reviewed by our chief operating decision maker, the chief executive officer, for evaluating the financial performance of reportable segments:

[0000068505-25-000012:notes:76]
|  | Years Ended |
|  | 2024 |  | 2023 |  | 2022 |
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions |
| North America | $ | 5,097 |  |  | $ | 2,723 |  |  | $ | 7,820 |  |  | $ | 4,507 |  |  | $ | 2,425 |  |  | $ | 6,932 |  |  | $ | 4,286 |  |  | $ | 2,088 |  |  | $ | 6,374 |  |
| International | 1,786 |  |  | 1,211 |  |  | 2,997 |  |  | 1,735 |  |  | 1,311 |  |  | 3,046 |  |  | 1,442 |  |  | 1,296 |  |  | 2,738 |  |
|  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |
| Major Products and Services |
| LMR Communications | $ | 5,739 |  |  | $ | 2,361 |  |  | $ | 8,100 |  |  | $ | 5,127 |  |  | $ | 2,399 |  |  | $ | 7,526 |  |  | $ | 4,713 |  |  | $ | 2,274 |  |  | $ | 6,987 |  |
| Video | 1,144 |  |  | 776 |  |  | 1,920 |  |  | 1,115 |  |  | 611 |  |  | 1,726 |  |  | 1,015 |  |  | 508 |  |  | 1,523 |  |
| Command Center | — |  |  | 797 |  |  | 797 |  |  | — |  |  | 726 |  |  | 726 |  |  | — |  |  | 602 |  |  | 602 |  |
|  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |
| Customer Type |
| Direct | $ | 4,238 |  |  | $ | 3,586 |  |  | $ | 7,824 |  |  | $ | 3,619 |  |  | $ | 3,396 |  |  | $ | 7,015 |  |  | $ | 3,368 |  |  | $ | 3,057 |  |  | $ | 6,425 |  |
| Indirect | 2,645 |  |  | 348 |  |  | 2,993 |  |  | 2,623 |  |  | 340 |  |  | 2,963 |  |  | 2,360 |  |  | 327 |  |  | 2,687 |  |
|  | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |

[0000068505-25-000012:notes:77]
Remaining Performance Obligations

[0000068505-25-000012:notes:78]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of December 31, 2024 was $9.4 billion. A total of $4.1 billion was from Products and Systems Integration performance obligations that were not yet satisfied, of which $2.3 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of December 31, 2024. The determination of Software and Services performance obligations that are not satisfied

[0000068505-25-000012:notes:79]
takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's services contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations to be recognized over time as services are performed and software is implemented.

[0000068505-25-000012:notes:80]
In 2023, the Competition and Markets Authority (the "CMA") imposed a legal order on Airwave which implemented a prospective price control on Airwave (the "Charge Control"). Our remaining performance obligations for Airwave services contracted with the Home Office of the United Kingdom (the "Home Office") through December 31, 2026 was reduced by $777 million and since August 1, 2023 our revenue under the Airwave contract has been recognized in accordance with the Charge Control. On March 13, 2024, the Company received notice of the contract extension (the "Deferred National Shutdown Notice") from the Home Office, recording additional remaining performance obligations of $748 million in the Software and Services segment to reflect the incremental three-years of services.

[0000068505-25-000012:notes:81]
Contract Balances

[0000068505-25-000012:notes:82]
| December 31 (in millions) | 2024 |  | 2023 |  | 2022 |  |  |  |  |
| Accounts receivable, net | $ | 1,952 |  |  | $ | 1,710 |  |  | $ | 1,518 |  |  |  |  |  |
| Contract assets | 1,230 |  |  | 1,102 |  |  | 974 |  |  |  |  |  |
| Contract liabilities | 2,072 |  |  | 2,037 |  |  | 1,859 |  |  |  |  |  |
| Non-current contract liabilities | 496 |  |  | 424 |  |  | 363 |  |  |  |  |  |

[0000068505-25-000012:notes:83]
Payment terms on system contracts are typically tied to implementation milestones associated with progress on contracts, while revenue recognition is over time based on a cost-to-cost method of measuring performance. The Company may recognize a Contract asset or Contract liability, depending on whether revenue has been recognized in excess of billings or billings in excess of revenue. Services contracts are typically billed in advance, generating Contract liabilities until the Company has performed the services. The Company does not record a financing component to contracts when it expects, at contract inception, that the period between the transfer of a promised good or service and related payment terms are less than a year.

[0000068505-25-000012:notes:84]
Revenue recognized during the years ended December 31, 2024 and 2023 which was previously included in Contract liabilities as of January 1, 2024 and 2023, respectively, was $1.3 billion, compared to $1.1 billion of revenue recognized during the year ended December 31, 2022 which was previously included in Contract liabilities as of January 1, 2022. Revenue of $28 million was reversed during the year ended December 31, 2024 related to performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $37 million during the year ended December 31, 2023 and $26 million during the year ended December 31, 2022.

[0000068505-25-000012:notes:85]
There have been no material expected credit losses recognized on contract assets during the year ended December 31, 2024.

[0000068505-25-000012:notes:86]
Contract Cost Balances

[0000068505-25-000012:notes:87]
| December 31 (in millions) | 2024 |  | 2023 |  | 2022 |  |  |  |  |
| Current contract cost assets | $ | 70 |  |  | $ | 56 |  |  | $ | 61 |  |  |  |  |  |
| Non-current contract cost assets | 141 |  |  | 119 |  |  | 130 |  |  |  |  |  |

[0000068505-25-000012:notes:88]
Contract cost assets include incremental costs to obtain a contract, primarily related to the Company's sales incentive plans, and certain costs to fulfill contracts. Contract cost assets are amortized into expense over a period that follows the passage of control to the customer over time. Incremental costs to obtain a contract with the Company's sales incentive plans are accounted for under a portfolio approach, with amortization ranging from one year to eight years to approximate the recognition of revenues over time. Where incremental costs to obtain a contract will be recognized in one year or less, the Company applies a practical expedient around expensing amounts as incurred. Amortization of contract cost assets was $51 million for the year ended December 31, 2024, compared to $61 million as of the year ended December 31, 2023 and $62 million as of the year ended December 31, 2022.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-25-000012:notes:89]
Leases
The Company leases certain office, factory and warehouse space, land and other equipment under various operating leases.

[0000068505-25-000012:notes:90]
Components of Lease Expense

[0000068505-25-000012:notes:91]
| (in millions) | December 31, 2024 |  | December 31, 2023 | December 31, 2022 |
| Lease expense: |  |  |  |  |
| Operating lease cost | $ | 140 |  |  | $ | 140 |  | $ | 130 |  |
| Short-term lease cost | 1 |  |  | 1 |  | 1 |  |
| Variable cost | 47 |  |  | 36 |  | 33 |  |
| Sublease income | (5) |  |  | (5) |  | (5) |  |
| Net lease expense from operating leases | $ | 183 |  |  | $ | 172 |  | $ | 159 |  |

[0000068505-25-000012:notes:92]
Operating Lease Assets and Liabilities

[0000068505-25-000012:notes:93]
| (in millions) | Statement Line Classification |  | December 31, 2024 |  | December 31, 2023 |  |  |
| Right-of-use lease assets | Operating lease assets |  | $ | 529 |  |  | $ | 495 |  |  |  |
| Current lease liabilities | Accrued liabilities |  | 127 |  |  | 125 |  |  |  |
| Operating lease liabilities | Operating lease liabilities |  | 427 |  |  | 407 |  |  |  |

[0000068505-25-000012:notes:94]
Other Information Related to Leases

[0000068505-25-000012:notes:95]
| (in millions) | December 31, 2024 |  | December 31, 2023 |  | December 31, 2022 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 152 |  |  | $ | 147 |  |  | $ | 145 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | $ | 150 |  |  | $ | 98 |  |  | $ | 221 |  |  |  |

[0000068505-25-000012:notes:96]
During the year ended December 31, 2024, the Company recorded $80 million of assets obtained in exchange for lease liabilities due to an assumption that it is reasonably certain that renewal options will be extended on its radio tower site leases operated within the Airwave radio network, consistent with the Home Office's notice of contract extension pursuant to their Deferred National Shutdown Notice through December 31, 2029. In addition, assets obtained in exchange for liabilities during the year ended December 31, 2024 included $24 million of additional leases due to the renewal of a large managed services contract due to an assumption that it is reasonably certain that renewal options will be extended on the associated radio tower site leases. The Company recorded $19 million of assets obtained in exchange for lease liabilities related to the ten year renewal of an International region office. During the year ended December 31, 2023, the Company included $66 million of additional leases due to renewals of three large managed service contracts due to an assumption that it is reasonably certain that renewal options will be extended on the associated radio tower site leases.

[0000068505-25-000012:notes:97]
|  | December 31, 2024 |  | December 31, 2023 |  |  |
| Weighted average remaining lease terms (years) | 5 |  | 5 |  |  |
| Weighted average discount rate | 3.97 | % |  | 4.34 | % |  |  |

[0000068505-25-000012:notes:98]
Future Lease Payments

[0000068505-25-000012:notes:99]
| December 31 (in millions) | Amount |  |
| 2025 | $ | 146 |  |  |
| 2026 | 128 |  |  |
| 2027 | 109 |  |  |
| 2028 | 84 |  |  |
| 2029 | 63 |  |  |
| Thereafter | 83 |  |  |
| Total lease payments | $ | 613 |  |  |
| Less: Interest | 59 |  |  |
| Present value of operating lease liabilities | $ | 554 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-25-000012:notes:100]
Other Financial Data
Statement of Operations Information

[0000068505-25-000012:notes:101]
Other Charges (Income)

[0000068505-25-000012:notes:102]
Other charges (income) included in Operating earnings consist of the following:

[0000068505-25-000012:notes:103]
| Years ended December 31 (in millions) | 2024 |  | 2023 |  | 2022 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 152 |  |  | $ | 177 |  |  | $ | 257 |  |
| Reorganization of businesses (Note 14) | 26 |  |  | 22 |  |  | 18 |  |
| Legal settlements | 7 |  |  | 4 |  |  | 23 |  |
| Fixed asset impairments | 2 |  |  | 3 |  |  | 12 |  |
| Environmental reserve expense | 2 |  |  | 15 |  |  | — |  |
| Exit of video manufacturing operations | — |  |  | 24 |  |  | — |  |
| Operating lease asset impairments | 6 |  |  | 6 |  |  | 24 |  |
| Acquisition-related transaction fees | 20 |  |  | 7 |  |  | 23 |  |
| Gain on Hytera litigation | (61) |  |  | — |  |  | (15) |  |
| Other | 1 |  |  | (1) |  |  | (3) |  |
|  | $ | 155 |  |  | $ | 257 |  |  | $ | 339 |  |

[0000068505-25-000012:notes:104]
During the year ended December 31, 2024, the Company recognized a gain on the Hytera litigation of $61 million for amounts recovered through legal proceedings due to theft of the Company's trade secrets. Refer to "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" to our consolidated financial statements in this "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for further discussion regarding the Hytera litigation.

[0000068505-25-000012:notes:105]
During the year ended December 31, 2023, the Company revised the estimate for its liability related to ongoing remediation efforts of environmental media such as groundwater, soil, and soil vapor, as well as related legal fees for a designated Superfund site under the Superfund Act incurred by a legacy business. It is the Company's policy to re-evaluate the reserve when certain events become known that will impact the future cash payments. During the year ended December 31, 2023, the Company became aware of incremental costs required in its remediation of the Superfund site. As such, the Company recorded a charge of $15 million, increasing the reserve balance to $127 million. The Company discounted the cash flows used in estimating this accrual using a risk-free treasury rate. As of December 31, 2024, the current portion of the estimated environmental liability is $9 million and is included in the Accrued liabilities statement line and the non-current portion is $119 million and is included in the "Other liabilities" statement line within the Company's Consolidated Balance Sheets.

[0000068505-25-000012:notes:106]
During the year ended December 31, 2023, the Company entered into an arrangement to sell its Richmond, British Columbia and Richardson, Texas video manufacturing operations, including the machinery and equipment, inventory, transfer of employees and related facility lease to a contract manufacturer. During the year ended December 31, 2023, the Company presented the assets and liabilities as held for sale in its Consolidated Balance Sheets and recognized an impairment loss of $24 million on the exit of these video manufacturing operations within Other charges in the Consolidated Statements of Operations, as the carrying value of the asset group was below the expected selling price. The transaction closed on February 1, 2024 resulting in a gain on the sale of these video manufacturing operations, which was de minimis.

[0000068505-25-000012:notes:107]
Other Income (Expense)

[0000068505-25-000012:notes:108]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-25-000012:notes:109]
| Years ended December 31 (in millions) | 2024 |  | 2023 |  | 2022 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (295) |  |  | $ | (249) |  |  | $ | (240) |  |
| Interest income | 68 |  |  | 33 |  |  | 14 |  |
|  | $ | (227) |  |  | $ | (216) |  |  | $ | (226) |  |
| Other, net: |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 132 |  |  | $ | 99 |  |  | $ | 123 |  |
| Loss from the extinguishment of long-term debt (Note 5) | (585) |  |  | — |  |  | (6) |  |
| Investment impairments | (3) |  |  | (16) |  |  | (1) |  |
| Foreign currency gain (loss) | 2 |  |  | (53) |  |  | 37 |  |
| Gain (loss) on derivative instruments (Note 6) | (19) |  |  | 20 |  |  | (61) |  |
| Loss on equity method investments | — |  |  | — |  |  | (3) |  |
| Fair value adjustments to equity investments | (5) |  |  | 13 |  |  | (30) |  |
| Gain on TETRA Ireland equity method investment | — |  |  | — |  |  | 21 |  |
| Assessments on uncertain tax positions (Note 7) | (11) |  |  | — |  |  | — |  |
| Other | — |  |  | 5 |  |  | (3) |  |
|  | $ | (489) |  |  | $ | 68 |  |  | $ | 77 |  |

[0000068505-25-000012:notes:110]
Earnings Per Common Share

[0000068505-25-000012:notes:111]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-25-000012:notes:112]
|  |  |  |  |  |  |  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  |  |  | Net Earnings |
| Years ended December 31 |  |  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 1,577 |  |  | $ | 1,709 |  |  | $ | 1,363 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 166.8 |  |  | 167.0 |  |  | 167.5 |  |
| Per share amount |  |  |  |  |  |  | $ | 9.45 |  |  | $ | 10.23 |  |  | $ | 8.14 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings |  |  |  |  |  |  | $ | 1,577 |  |  | $ | 1,709 |  |  | $ | 1,363 |  |
| Weighted average common shares outstanding |  |  |  |  |  |  | 166.8 |  |  | 167.0 |  |  | 167.5 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards |  |  |  |  |  |  | 4.0 |  |  | 3.7 |  |  | 3.7 |  |
| 1.75% senior convertible notes |  |  |  |  |  |  | — |  |  | 1.5 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding |  |  |  |  |  |  | 170.8 |  |  | 172.1 |  |  | 171.9 |  |
| Per share amount |  |  |  |  |  |  | $ | 9.23 |  |  | $ | 9.93 |  |  | $ | 7.93 |  |

[0000068505-25-000012:notes:113]
In 2022 and 2023, the Company had $1.0 billion of 1.75% senior convertible notes outstanding (the “Silver Lake Convertible Debt”). The notes were convertible based on a rate of 4.9670 per $1,000 principal amount as of December 31, 2023 (equal to a conversion price of $201.33 per share), adjusted for dividends declared through the date of settlement. In 2021, the Company's Board of Directors approved an irrevocable determination requiring the future settlement of the Silver Lake Convertible Debt to be in cash. Because the Company irrevocably decided to settle the principal amount of the Silver Lake Convertible Debt in cash, the Company did not reflect any shares underlying the Silver Lake Convertible Debt in its diluted weighted average shares outstanding until the average stock price per share for the period exceeded the conversion price. For the years ended December 31, 2022 and December 31, 2023, the Company included the number of shares that would be issuable upon conversion in the Company’s computation of diluted earnings per share, based on the amount by which the average stock price exceeded the conversion price. In 2024, the Company repurchased the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium, recognizing a loss on the extinguishment of $585 million. Accordingly, in the computation of diluted earnings per common share for the year ended December 31, 2024, a total of 0.2 million shares related to the Silver Lake Convertible Debt were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. Refer to "Note 5: Debt and Credit Facilities" to our consolidated financial statements in this "Part II. Item 8. Financial Statements and Supplementary Data" of this Form 10-K for more information regarding the repurchase.

[0000068505-25-000012:notes:114]
In the computation of diluted earnings per common share for the year ended December 31, 2024, the assumed exercise of 0.1 million options were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2023, the assumed exercise of 0.3 million options, including 0.2 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share for the year ended December 31, 2022, the assumed exercise of 0.3 million options, including 0.1 million subject to market-based contingent option agreements, were excluded because their inclusion would have been antidilutive.

[0000068505-25-000012:notes:115]
Balance Sheet Information

[0000068505-25-000012:notes:116]
Accounts Receivable, Net

[0000068505-25-000012:notes:117]
Accounts receivable, net, consists of the following:

[0000068505-25-000012:notes:118]
| December 31 | 2024 |  | 2023 |
| Accounts receivable | $ | 2,035 |  |  | $ | 1,779 |  |
| Less allowance for credit losses | (83) |  |  | (69) |  |
|  | $ | 1,952 |  |  | $ | 1,710 |  |

[0000068505-25-000012:notes:119]
Inventories, Net

[0000068505-25-000012:notes:120]
Inventories, net, consist of the following:

[0000068505-25-000012:notes:121]
| December 31 | 2024 |  | 2023 |
| Finished goods | $ | 396 |  |  | $ | 328 |  |
| Work-in-process and production materials | 498 |  |  | 640 |  |
|  | 894 |  |  | 968 |  |
| Less inventory reserves | (128) |  |  | (141) |  |
|  | $ | 766 |  |  | $ | 827 |  |

[0000068505-25-000012:notes:122]
Other Current Assets

[0000068505-25-000012:notes:123]
Other current assets consist of the following:

[0000068505-25-000012:notes:124]
| December 31 | 2024 |  | 2023 |
| Current contract cost assets (Note 2) | $ | 70 |  |  | $ | 56 |  |
| Contractor receivables | 44 |  |  | 40 |  |
| Tax-related deposits (Note 7) | 54 |  |  | 32 |  |
| Other | 261 |  |  | 229 |  |
|  | $ | 429 |  |  | $ | 357 |  |

[0000068505-25-000012:notes:125]
Property, Plant and Equipment, Net

[0000068505-25-000012:notes:126]
Property, plant and equipment, net, consist of the following:

[0000068505-25-000012:notes:127]
| December 31 | 2024 |  | 2023 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 441 |  |  | 448 |  |
| Machinery and equipment | 2,243 |  |  | 2,396 |  |
|  | 2,689 |  |  | 2,849 |  |
| Less accumulated depreciation | (1,667) |  |  | (1,885) |  |
|  | $ | 1,022 |  |  | $ | 964 |  |

[0000068505-25-000012:notes:128]
Depreciation expense for the years ended December 31, 2024, 2023, and 2022 was $184 million, $179 million and $183 million, respectively.

[0000068505-25-000012:notes:129]
Investments

[0000068505-25-000012:notes:130]
Investments consist of the following:

[0000068505-25-000012:notes:131]
| December 31 | 2024 |  | 2023 |  |  |  |  |
| Common stock | $ | 23 |  |  | $ | 28 |  |  |  |  |  |
| Strategic investments, at cost | 26 |  |  | 28 |  |  |  |  |  |
| Company-owned life insurance policies | 75 |  |  | 74 |  |  |  |  |  |
| Equity method investments | 11 |  |  | 13 |  |  |  |  |  |
|  | $ | 135 |  |  | $ | 143 |  |  |  |  |  |

[0000068505-25-000012:notes:132]
Other Assets

[0000068505-25-000012:notes:133]
Other assets consist of the following:

[0000068505-25-000012:notes:134]
| December 31 | 2024 |  | 2023 |
| Defined benefit plan assets (Note 8) | $ | 162 |  |  | $ | 98 |  |
| Non-current contract cost assets (Note 2) | 141 |  |  | 119 |  |
| Other | 72 |  |  | 57 |  |
|  | $ | 375 |  |  | $ | 274 |  |

[0000068505-25-000012:notes:135]
Accounts Payable

[0000068505-25-000012:notes:136]
The Company utilizes a supplier finance program that provides suppliers with the ability to accelerate payment on the Company's invoices beyond the stated payment terms. Under the terms of this program, the Company agrees to pay an intermediary the stated amount of confirmed invoices on the stated maturity dates of the invoices, and the supplier is able to negotiate earlier payment terms with the intermediary. The Company or the intermediary may terminate the agreement at any time upon 60 days' notice. The Company does not provide any forms of guarantees under this arrangement. Supplier participation in the program is solely at the supplier's discretion, and the participating suppliers negotiate their arrangements directly with the intermediary. The Company has no economic interest in a supplier's decision to participate in the program, and their participation has no bearing on our payment terms or amounts due. The stated invoice payment terms range from 75 to 120 days from the invoice date and are considered commercially reasonable.

[0000068505-25-000012:notes:137]
The Company's outstanding amounts related to the suppliers participating in this program was $38 million and $35 million as of December 31, 2024 and December 31, 2023, respectively. Supplier finance program obligations are classified as Accounts payable within the Consolidated Balance Sheets. The following table displays a rollforward of the confirmed amount of supplier finance obligations from January 1, 2023 to December 31, 2024:

[0000068505-25-000012:notes:138]
| (in millions) | 2024 |  | 2023 |
| Confirmed obligations at the beginning of the year | $ | 35 |  |  | $ | 37 |  |
| Invoices confirmed during the year | 139 |  |  | 114 |  |
| Confirmed invoices paid during the year | (136) |  |  | (116) |  |
| Confirmed obligations outstanding at the end of the year | $ | 38 |  |  | $ | 35 |  |

[0000068505-25-000012:notes:139]
Accrued Liabilities

[0000068505-25-000012:notes:140]
Accrued liabilities consist of the following:

[0000068505-25-000012:notes:141]
| December 31 | 2024 |  | 2023 |
| Compensation | $ | 406 |  |  | $ | 407 |  |
| Tax liabilities (Note 7) | 217 |  |  | 231 |  |
| Dividend payable | 182 |  |  | 163 |  |
| Trade liabilities | 160 |  |  | 140 |  |
| Operating lease liabilities (Note 3) | 127 |  |  | 125 |  |
| Customer reserves | 97 |  |  | 89 |  |
| Other | 454 |  |  | 349 |  |
|  | $ | 1,643 |  |  | $ | 1,504 |  |

[0000068505-25-000012:notes:142]
Other Liabilities

[0000068505-25-000012:notes:143]
Other liabilities consist of the following:

[0000068505-25-000012:notes:144]
| December 31 | 2024 |  | 2023 |
| Defined benefit plans (Note 8) | $ | 768 |  |  | $ | 939 |  |
| Non-current contract liabilities (Note 2) | 496 |  |  | 424 |  |
| Unrecognized tax benefits (Note 7) | 39 |  |  | 26 |  |
| Deferred income taxes (Note 7) | 87 |  |  | 55 |  |
| Environmental Reserve | 119 |  |  | 119 |  |
| Deferred compensation | 89 |  |  | 70 |  |
| Other | 121 |  |  | 108 |  |
|  | $ | 1,719 |  |  | $ | 1,741 |  |

[0000068505-25-000012:notes:145]
Stockholders’ Equity Information

[0000068505-25-000012:notes:146]
Share Repurchase Program: Through a series of actions, the Board of Directors has authorized the Company to repurchase in the aggregate up to $18.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2024, the Company had used approximately $15.8 billion of the share repurchase authority to repurchase shares, leaving approximately $2.2 billion of authority available for future repurchases. During the year ended December 31, 2024, the Company paid $3 million of 1% excise tax pursuant to the Inflation Reduction Act of 2022, related to its 2023 share repurchases in excess of issuances.

[0000068505-25-000012:notes:147]
The Company's share repurchases for 2024, 2023, and 2022 can be summarized as follows:

[0000068505-25-000012:notes:148]
| Year | Shares Repurchased (in millions) |  | Average Price |  | Amount (in millions) |
| 2024 | 0.6 |  |  | $ | 396.69 |  |  | $ | 244 |  |
| 2023 | 2.9 |  |  | 278.56 |  |  | 804 |  |
| 2022 | 3.7 |  |  | 225.00 |  |  | 836 |  |

[0000068505-25-000012:notes:149]
Payment of Dividends: On November 14, 2024, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.98 per share of common stock to $1.09 per share of common stock. During the years ended December 31, 2024, 2023, and 2022 the Company paid $654 million, $589 million, and $530 million, respectively, in cash dividends to holders of its common stock. On January 15, 2025, the Company paid an additional $182 million in cash dividends to holders of its common stock.

[0000068505-25-000012:notes:150]
Accumulated Other Comprehensive Loss

[0000068505-25-000012:notes:151]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Consolidated Statements of Operations during the years ended December 31, 2024, 2023, and 2022:

[0000068505-25-000012:notes:152]
|  | Years ended December 31 |
|  | 2024 |  | 2023 |  | 2022 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (482) |  |  | $ | (539) |  |  | $ | (384) |  |
| Other comprehensive income (loss) before reclassification adjustment | (66) |  |  | 61 |  |  | (156) |  |
| Tax benefit (expense) | 2 |  |  | (4) |  |  | 1 |  |
| Other comprehensive income (loss), net of tax | (64) |  |  | 57 |  |  | (155) |  |
| Balance at end of period | $ | (546) |  |  | $ | (482) |  |  | $ | (539) |  |
| Derivative instruments: |  |  |  |  |  |
| Balance at beginning of period | $ | (12) |  |  | $ | — |  |  | $ | — |  |
| Other comprehensive income (loss) before reclassification adjustment | 4 |  |  | (12) |  |  | — |  |
| Reclassification adjustment into Interest expense, net | 1 |  |  | — |  |  | — |  |
| Other comprehensive income (loss), net of tax | 5 |  |  | (12) |  |  | — |  |
| Balance at end of period | $ | (7) |  |  | $ | (12) |  |  | $ | — |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (2,046) |  |  | $ | (1,996) |  |  | $ | (1,995) |  |
| Other comprehensive income (loss) before reclassification adjustment | 44 |  |  | (130) |  |  | (76) |  |
| Tax benefit (expense) | (9) |  |  | 34 |  |  | 18 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 35 |  |  | (96) |  |  | (58) |  |
| Reclassification adjustment - Actuarial net losses into Other income (expense) | 34 |  |  | 61 |  |  | 80 |  |
| Reclassification adjustment - Prior service benefits into Other income (expense) | — |  |  | 1 |  |  | (2) |  |
| Tax expense | (9) |  |  | (16) |  |  | (21) |  |
| Reclassification adjustments into Net earnings, net of tax | 25 |  |  | 46 |  |  | 57 |  |
| Other comprehensive income (loss), net of tax | 60 |  |  | (50) |  |  | (1) |  |
| Balance at end of period | $ | (1,986) |  |  | $ | (2,046) |  |  | $ | (1,996) |  |
| Total Accumulated other comprehensive loss | $ | (2,539) |  |  | $ | (2,540) |  |  | $ | (2,535) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-25-000012:notes:153]
Debt and Credit Facilities
Long-Term Debt

[0000068505-25-000012:notes:154]
| December 31 | 2024 |  | 2023 |
| 4.0% senior notes due 2024 | $ | — |  |  | $ | 313 |  |
| 1.75% senior convertible notes due 2024 | — |  |  | 1,000 |  |
| 7.5% debentures due 2025 | 252 |  |  | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 696 |  |  | 695 |  |
| 6.5% debentures due 2028 | 24 |  |  | 25 |  |
| 5.0% senior notes due 2029 | 396 |  |  | — |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 895 |  |  | 894 |  |
| 2.75% senior notes due 2031 | 846 |  |  | 845 |  |
| 5.6% senior notes due 2032 | 596 |  |  | 595 |  |
| 5.4% senior notes due 2034 | 893 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 5,998 |  |  | 6,019 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (322) |  |  | (1,313) |  |
| Long-term debt | $ | 5,675 |  |  | $ | 4,705 |  |

[0000068505-25-000012:notes:155]
During the year ended December 31, 2024, the Company repaid the $313 million aggregate principal amount of 4.0% senior notes due 2024.

[0000068505-25-000012:notes:156]
As of December 31, 2024, $252 million of 7.5% debentures, which mature in May 2025, and $70 million of 6.5% debentures, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-25-000012:notes:157]
On September 5, 2019, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 1.75% senior convertible notes which were scheduled to mature in September 2024 (the "Silver Lake Convertible Debt"), which became fully convertible on September 5, 2021. In 2024, the Company repurchased the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt for aggregate consideration of $1.59 billion in cash, inclusive of the conversion premium. The repurchase of the Silver Lake Convertible Debt was accounted for as an extinguishment of debt, as the repurchase was negotiated under economically favorable terms outside of the original contractual conversion rate. A loss on the extinguishment of $585 million was recorded, representing the excess amounts repurchased over the carrying value of debt of $593 million, offset by accrued interest of $8 million. The loss on the extinguishment of debt was recorded within Other Income (Expense) in the Consolidated Statements of Operations during the year ended December 31, 2024.

[0000068505-25-000012:notes:158]
On March 25, 2024, the Company issued $400 million of 5.0% senior notes due 2029 and $900 million of 5.4% senior notes due 2034. The Company recognized net proceeds of $1.3 billion after debt issuance costs and discounts. A portion of proceeds from the issuance of these notes was used to repurchase the $1.0 billion aggregate principal amount of the Silver Lake Convertible Debt in 2024.

[0000068505-25-000012:notes:159]
The Company has an unsecured commercial paper program, backed by the 2021 Motorola Solutions Credit Agreement (defined below), under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the commercial paper notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of December 31, 2024 the Company had no outstanding debt under the commercial paper program.

[0000068505-25-000012:notes:160]
Aggregate requirements for long-term debt maturities during the next five years are as follows: $322 million in 2025, no maturities in 2026 or 2027, $724 million in 2028 and $1.2 billion in 2029.

[0000068505-25-000012:notes:161]
Credit Facilities
As of December 31, 2024, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million.  An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-25-000012:notes:162]
Risk Management
Foreign Currency Risk

[0000068505-25-000012:notes:163]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.0 billion and $1.3 billion at December 31, 2024 and December 31, 2023, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-25-000012:notes:164]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2024 and the corresponding positions as of December 31, 2023:

[0000068505-25-000012:notes:165]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2024 |  | 2023 |
| Euro | $ | 150 |  |  | $ | 322 |  |
| Australian dollar | (136) |  |  | (140) |  |
| British pound | 124 |  |  | 252 |  |
| Canadian dollar | 70 |  |  | 76 |  |
| Chinese renminbi | (48) |  |  | (66) |  |

[0000068505-25-000012:notes:166]
Counterparty Risk

[0000068505-25-000012:notes:167]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2024, all of the counterparties had investment grade credit ratings. As of December 31, 2024, the credit risk with all derivative counterparties was approximately $10 million.

[0000068505-25-000012:notes:168]
Derivative Financial Instruments

[0000068505-25-000012:notes:169]
The following tables summarize the fair values and location in the Consolidated Balance Sheet of all derivative financial instruments held by the Company at December 31, 2024 and 2023:

[0000068505-25-000012:notes:170]
|  | Fair Values of Derivative Instruments |
| December 31, 2024 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 7 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 3 |  |  | $ | 9 |  |
| Equity swap contracts | $ | — |  |  | $ | 1 |  |
| Total derivatives | $ | 10 |  |  | $ | 10 |  |

[0000068505-25-000012:notes:171]
|  | Fair Values of Derivative Instruments |
| December 31, 2023 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | 1 |  |  | $ | 3 |  |
| Treasury rate lock | — |  |  | 12 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 12 |  | 1 |  |
| Equity swap contracts | 1 |  | — |  |
| Total derivatives | $ | 14 |  |  | $ | 16 |  |

[0000068505-25-000012:notes:172]
The following table summarizes the effect of derivatives on the Company's consolidated financial statements for the years ended December 31, 2024, 2023 and 2022:

[0000068505-25-000012:notes:173]
|  | Financial Statement Location |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated other comprehensive income (loss) | $ | 9 |  |  | $ | (4) |  |  | $ | 12 |  |
| Forward points recognized | Other income (expense) | 2 |  |  | 3 |  |  | 2 |  |
| Treasury rate lock settlement | Accumulated other comprehensive income (loss) | 4 |  |  | (12) |  |  | — |  |
| Amortization of treasury rate lock | Other income (expense) | (1) |  |  | — |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | (19) |  |  | $ | 20 |  |  | $ | (61) |  |
| Equity swap contracts | Selling, general and administrative expenses | 3 |  |  | 1 |  |  | — |  |

[0000068505-25-000012:notes:174]
Net Investment Hedges

[0000068505-25-000012:notes:175]
The Company uses foreign exchange forward contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investment in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of December 31, 2024, the Company had €100 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in certain British pound functional subsidiaries.

[0000068505-25-000012:notes:176]
The Company excludes the difference between the spot rate and the forward rate of the forward contract from its assessment of hedge effectiveness. The effect of the forward points recognized is amortized on a straight line basis and recognized through interest expense within Other income (expense) in the Consolidated Statement of Operations.

[0000068505-25-000012:notes:177]
Equity Swap Contracts

[0000068505-25-000012:notes:178]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Consolidated Statements of Operations. The notional amount of these contracts as of December 31, 2024 was $19 million.

[0000068505-25-000012:notes:179]
Treasury Rate Lock
In 2023, the Company entered into treasury rate lock agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the year ended December 31, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated Other Comprehensive Income (AOCI) will be reclassified to Interest expense, net on a straight-line basis over the 10-year term of the 2034 notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-25-000012:notes:180]
Income Taxes
Components of Income Tax Expense

[0000068505-25-000012:notes:181]
Components of earnings before income taxes are as follows:

[0000068505-25-000012:notes:182]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| United States | $ | 1,705 |  |  | $ | 1,744 |  |  | $ | 1,312 |  |
| Other nations | 267 |  |  | 402 |  |  | 203 |  |
|  | $ | 1,972 |  |  | $ | 2,146 |  |  | $ | 1,515 |  |

[0000068505-25-000012:notes:183]
Components of income tax expense are as follows:

[0000068505-25-000012:notes:184]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| United States Federal | $ | 434 |  |  | $ | 269 |  |  | $ | 240 |  |
| Other nations | 38 |  |  | 125 |  |  | 159 |  |
| States (U.S.) | 133 |  |  | 70 |  |  | 83 |  |
| Current income tax expense | 605 |  |  | 464 |  |  | 482 |  |
| United States Federal | (221) |  |  | (30) |  |  | (179) |  |
| Other nations | 40 |  |  | (9) |  |  | (118) |  |
| States (U.S.) | (34) |  |  | 7 |  |  | (37) |  |
| Deferred income tax benefit | (215) |  |  | (32) |  |  | (334) |  |
| Total income tax expense | $ | 390 |  |  | $ | 432 |  |  | $ | 148 |  |

[0000068505-25-000012:notes:185]
Differences between income tax expense computed at the U.S. federal statutory tax rate of 21% and income tax expense as reflected in the Consolidated Statements of Operations are as follows:

[0000068505-25-000012:notes:186]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| Income tax expense at statutory rate | $ | 414 |  | 21.0 | % |  | $ | 450 |  | 21.0 | % |  | $ | 318 |  | 21.0 | % |
| State income taxes, net of federal benefit | 66 |  | 3.3 | % |  | 71 |  | 3.3 | % |  | 76 |  | 5.0 | % |
| Non-U.S. tax expense on non-U.S. earnings | 24 |  | 1.2 | % |  | 15 |  | 0.7 | % |  | 1 |  | 0.1 | % |
| U.S. tax expense (benefit) on undistributed non-U.S. earnings | (27) |  | (1.4) | % |  | (44) |  | (2.1) | % |  | (43) |  | (2.8) | % |
| IP reorganization | (171) |  | (8.7) | % |  | — |  | — | % |  | (77) |  | (5.1) | % |
| Extinguishment of Silver Lake convertible debt | 148 |  | 7.5 | % |  | — |  | — | % |  | — |  | — | % |
| Stock compensation | (45) |  | (2.3) | % |  | (33) |  | (1.5) | % |  | (68) |  | (4.5) | % |
| Valuation allowances | 5 |  | 0.3 | % |  | (13) |  | (0.6) | % |  | (51) |  | (3.4) | % |
| Research credits | (24) |  | (1.2) | % |  | (19) |  | (0.9) | % |  | (16) |  | (1.1) | % |
| Reserve for uncertain tax positions | (6) |  | (0.3) | % |  | (3) |  | (0.1) | % |  | (6) |  | (0.4) | % |
| Other tax expense (benefit) | 6 |  | 0.3 | % |  | 8 |  | 0.4 | % |  | 14 |  | 0.9 | % |
|  | $ | 390 |  | 19.8 | % |  | $ | 432 |  | 20.1 | % |  | $ | 148 |  | 9.8 | % |

[0000068505-25-000012:notes:187]
The effective tax rate for 2024 was below the current U.S. federal statutory rate of 21% primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allows for additional utilization of foreign tax credit carryforwards and a higher federal derived intangible income deduction on its 2023 U.S. tax return, the recognition of excess tax benefits on share-based compensation, the 2024 estimated foreign derived intangible income deduction, and generation of research and development credits, partially offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt and 2024 estimated U.S. state income taxes.

[0000068505-25-000012:notes:188]
In 2021, the Organization of Economic Cooperation and Development ("OECD") introduced its Pillar Two Framework Model Rules ("Pillar 2"), that was supported by over 130 countries worldwide, which is designed to impose a 15% global minimum tax on adjusted financial results. Certain aspects of Pillar 2 took effect on January 1, 2024, while other aspects go into effect on January 1, 2025. The Company continues to evaluate the potential impact of Pillar 2 on its business, as the countries in which it operates continue to enact legislation implementing Pillar 2. While many aspects of the application of Pillar 2 continue to be clarified, Pillar 2 did not materially impact the Company's 2024 tax liability, and is not expected to have a material impact in future years.

[0000068505-25-000012:notes:189]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s Consolidated Balance Sheet, rather than Income tax expense, are the result of retirement benefit adjustments and currency translation adjustments. The adjustments were charges of $16 million for the year ended December 31, 2024, benefits of $14 million for the year ended December 31, 2023, and charges of $2 million for the year ended December 31, 2022.

[0000068505-25-000012:notes:190]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and generally, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings. As a result of the 2017 U.S. Tax Cuts and Jobs Act ("the Tax Act"), dividends from foreign subsidiaries are now exempt or the earnings have been previously subject to U.S. tax. As a result, the tax accrual for undistributed foreign earnings is limited primarily to foreign withholding taxes and tax on inherent capital gains that would result from distribution of foreign earnings which are not permanently reinvested, and such earnings may be distributed without an additional charge.

[0000068505-25-000012:notes:191]
Undistributed foreign earnings that the Company intends to reinvest indefinitely amounted to, in the aggregate, $2.0 billion at December 31, 2024. It is impracticable to determine the exact amount of unrecognized deferred tax liabilities on such earnings; however, due to the above-mentioned changes made under the Tax Act, the Company believes that the additional U.S. or foreign income tax charge with respect to such earnings, if distributed, would be immaterial.

[0000068505-25-000012:notes:192]
Gross deferred tax assets were $2.4 billion and $2.1 billion for December 31, 2024 and December 31, 2023, respectively. Deferred tax assets, net of valuation allowances, were $2.4 billion and $2.0 billion at December 31, 2024 and December 31, 2023, respectively. Gross deferred tax liabilities were $1.2 billion and $1.0 billion at December 31, 2024 and December 31, 2023, respectively.

[0000068505-25-000012:notes:193]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-25-000012:notes:194]
| December 31 | 2024 |  | 2023 |
| Inventory | $ | 30 |  |  | $ | 30 |  |
| Accrued liabilities and allowances | 87 |  |  | 77 |  |
| Employee benefits | 221 |  |  | 270 |  |
| Capitalized items | 391 |  |  | 146 |  |
| Tax basis differences on investments | 2 |  |  | 4 |  |
| Depreciation tax basis differences on fixed assets | (31) |  |  | (2) |  |
| Undistributed non-U.S. earnings | (23) |  |  | (28) |  |
| Tax attribute carryforwards | 98 |  |  | 115 |  |
| Business reorganization | 7 |  |  | 9 |  |
| Warranty and customer liabilities | 24 |  |  | 22 |  |
| Deferred revenue and costs | 420 |  |  | 406 |  |
| Valuation allowances | (62) |  |  | (63) |  |
| Operating lease assets | (128) |  |  | (120) |  |
| Operating lease liabilities | 134 |  |  | 129 |  |
| Other | 24 |  |  | 10 |  |
|  | $ | 1,194 |  |  | $ | 1,005 |  |

[0000068505-25-000012:notes:195]
At December 31, 2024 and December 31, 2023, the Company had valuation allowances of $62 million and $63 million, respectively, against its deferred tax assets, including $42 million and $44 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s U.S. valuation allowance increased $1 million during 2024 primarily due to a capital loss generated in 2024 for which the Company does not have sufficient capital gains in the carryback period nor for which it expects to generate sufficient capital gains in the near future. The Company's Non-U.S. valuation allowance decreased $2 million during 2024 primarily due to the expiration of tax attributes. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-25-000012:notes:196]
Tax attribute carryforwards are as follows:

[0000068505-25-000012:notes:197]
| December 31, 2024 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 127 |  |  | $ | 27 |  |  | 2025-2037 |
| General business credits | — |  |  | 1 |  |  | 2030-2036 |
| State tax losses | — |  |  | 8 |  |  | 2027-2044 |
| State tax credits | — |  |  | 3 |  |  | 2025-2043 |
| Non-U.S. subsidiaries: |  |  |  |  |  |
| United Kingdom tax losses | 143 |  |  | 36 |  |  | Unlimited |
| Canada tax losses | 17 |  |  | 5 |  |  | 2034-2044 |
| Canada tax credits | — |  |  | 5 |  |  | 2038-2044 |
| Other subsidiaries tax losses | 66 |  |  | 13 |  |  | Various |
|  |  |  | $ | 98 |  |  |  |

[0000068505-25-000012:notes:198]
The Company had unrecognized tax benefits of $42 million and $32 million at December 31, 2024 and December 31, 2023, respectively, of which approximately $40 million and $27 million, if recognized, would have affected the effective tax rate for 2024 and 2023, respectively.

[0000068505-25-000012:notes:199]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-25-000012:notes:200]
| (in millions) | 2024 |  | 2023 |
| Balance at January 1 | $ | 32 |  |  | $ | 35 |  |
| Additions based on tax positions related to current year | 1 |  |  | 1 |  |
| Additions for tax positions of prior years | 18 |  |  | 1 |  |
| Reductions for tax positions of prior years | (1) |  |  | (1) |  |
| Settlements and agreements | (5) |  |  | — |  |
| Lapse of statute of limitations | (3) |  |  | (4) |  |
| Balance at December 31 | $ | 42 |  |  | $ | 32 |  |

[0000068505-25-000012:notes:201]
The Company recorded $39 million and $26 million of unrecognized tax benefits in Other liabilities at December 31, 2024 and December 31, 2023, respectively.

[0000068505-25-000012:notes:202]
The Company has several U.S. state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-25-000012:notes:203]
| Jurisdiction | Tax Years |
| United States | 2021-2024 |
| Australia | 2020-2024 |
| Canada | 2020-2024 |
| Germany | 2018-2024 |
| India | 1997-2024 |
| Israel | 2019-2024 |
| Poland | 2019-2024 |
| Malaysia | 2017-2024 |
| United Kingdom | 2022-2024 |

[0000068505-25-000012:notes:204]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position or liquidity. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-25-000012:notes:205]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be up to a $9 million tax benefit.

[0000068505-25-000012:notes:206]
At December 31, 2024, the Company had $30 million accrued for interest and $23 million accrued for penalties on unrecognized tax benefits. At December 31, 2023, the Company had $23 million and $12 million accrued for interest and penalties, respectively, on unrecognized tax benefits. The Company's policy is to classify the interest and penalty as a component of interest expense and other expense, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-25-000012:notes:207]
Retirement Benefits
Pension and Postretirement Health Care Benefits Plans

[0000068505-25-000012:notes:208]
U.S. Pension Benefit Plans

[0000068505-25-000012:notes:209]
The Company’s non-contributory U.S. defined benefit plans (the "U.S. Pension Plans") provide benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. The Company also has an additional non-contributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan ("MSPP"), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. In December 2008, the Company amended the U.S. Pension Plans and MSPP (together the "U.S. Pension Benefit Plans") such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-25-000012:notes:210]
Postretirement Health Care Benefits Plan

[0000068505-25-000012:notes:211]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment or retirement eligibility (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants. After a series of amendments, all eligible retirees under the age of 65 are provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses. All eligible retirees over the age of 65 are entitled to one fixed-rate subsidy capped at $560 per participant.

[0000068505-25-000012:notes:212]
Non-U.S. Pension Benefit Plans

[0000068505-25-000012:notes:213]
The Company also provides defined benefit plans which cover non-U.S. employees in certain jurisdictions, principally the U.K. and Germany (the “Non-U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-25-000012:notes:214]
In June 2015, the Company amended its non-U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.

[0000068505-25-000012:notes:215]
Net Periodic Cost (Benefit)

[0000068505-25-000012:notes:216]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-25-000012:notes:217]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 189 |  |  | 190 |  |  | 128 |  |  | 57 |  |  | 56 |  |  | 29 |  |  | 4 |  |  | 5 |  |  | 2 |  |
| Expected return on plan assets | (298) |  |  | (293) |  |  | (254) |  |  | (104) |  |  | (108) |  |  | (93) |  |  | (13) |  |  | (13) |  |  | (12) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 25 |  |  | 22 |  |  | 62 |  |  | 6 |  |  | 37 |  |  | 14 |  |  | 3 |  |  | 2 |  |  | 4 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (3) |  |  | (2) |  |  | (2) |  |  | 3 |  |  | 3 |  |  | — |  |
| Net periodic cost (benefit) | $ | (84) |  |  | $ | (81) |  |  | $ | (64) |  |  | $ | (43) |  |  | $ | (16) |  |  | $ | (51) |  |  | $ | (3) |  |  | $ | (3) |  |  | $ | (6) |  |

[0000068505-25-000012:notes:218]
The status of the Company’s plans is as follows:

[0000068505-25-000012:notes:219]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 3,928 |  |  | $ | 3,809 |  |  | $ | 1,347 |  |  | $ | 1,207 |  |  | $ | 96 |  |  | $ | 103 |  |
| Service cost | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Interest cost | 189 |  |  | 190 |  |  | 57 |  |  | 56 |  |  | 4 |  |  | 5 |  |
| Plan amendments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss (gain) | (220) |  |  | 59 |  |  | (156) |  |  | 62 |  |  | 17 |  |  | 2 |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (32) |  |  | 66 |  |  | — |  |  | — |  |
| Benefit payments | (142) |  |  | (130) |  |  | (54) |  |  | (45) |  |  | (12) |  |  | (14) |  |
| Benefit obligation at December 31 | $ | 3,755 |  |  | $ | 3,928 |  |  | $ | 1,163 |  |  | $ | 1,347 |  |  | $ | 105 |  |  | $ | 96 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,273 |  |  | $ | 3,076 |  |  | $ | 1,172 |  |  | $ | 1,092 |  |  | $ | 134 |  |  | $ | 134 |  |
| Return on plan assets | 112 |  |  | 324 |  |  | (23) |  |  | 56 |  |  | 6 |  |  | 14 |  |
| Company contributions | 6 |  |  | 3 |  |  | 9 |  |  | 9 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (21) |  |  | 60 |  |  | — |  |  | — |  |
| Benefit payments | (142) |  |  | (130) |  |  | (54) |  |  | (45) |  |  | (12) |  |  | (14) |  |
| Fair value at December 31 | $ | 3,249 |  |  | $ | 3,273 |  |  | $ | 1,083 |  |  | $ | 1,172 |  |  | $ | 128 |  |  | $ | 134 |  |
| Funded status of the plan | $ | (506) |  |  | $ | (655) |  |  | $ | (80) |  |  | $ | (175) |  |  | $ | 23 |  |  | $ | 38 |  |
| Unrecognized net loss | 1,635 |  |  | 1,695 |  |  | 796 |  |  | 829 |  |  | 88 |  |  | 68 |  |
| Unrecognized prior service benefit (cost) | — |  |  | — |  |  | (64) |  |  | (67) |  |  | 41 |  |  | 44 |  |
| Prepaid pension cost | $ | 1,129 |  |  | $ | 1,040 |  |  | $ | 652 |  |  | $ | 587 |  |  | $ | 152 |  |  | $ | 150 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3) |  |  | $ | (2) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (503) |  |  | (653) |  |  | (194) |  |  | (210) |  |  | — |  |  | — |  |
| Non-current benefit asset | — |  |  | — |  |  | 114 |  |  | 35 |  |  | 23 |  |  | 38 |  |
| Deferred income taxes | 388 |  |  | 403 |  |  | 95 |  |  | 102 |  |  | 35 |  |  | 31 |  |
| Accumulated other comprehensive loss | 1,247 |  |  | 1,292 |  |  | 637 |  |  | 660 |  |  | 94 |  |  | 81 |  |
| Prepaid pension cost | $ | 1,129 |  |  | $ | 1,040 |  |  | $ | 652 |  |  | $ | 587 |  |  | $ | 152 |  |  | $ | 150 |  |

[0000068505-25-000012:notes:220]
For the year ended December 31, 2024, the primary driver of the decrease in the U.S. Pension Benefit Plans' benefit obligation was higher actuarial gains due to a increase in the discount rate from 5.01% as of December 31, 2023 to 5.70% as of December 31, 2024, partially offset by actuarial losses in the benefit obligation due to updated lump-sum interest rates and demographic assumption changes. For the year ended December 31, 2023, the primary driver of the increase in the U.S. Pension Benefit Plans' benefit obligation was higher actuarial losses due to an decrease in the discount rate from 5.20% as of December 31, 2022 to 5.01% as of December 31, 2023, partially offset by actuarial gains in the benefit obligation due to updated lump-sum interest rates and mortality.

[0000068505-25-000012:notes:221]
For the year ended December 31, 2024, the most significant drivers of the decrease in Non-U.S. Pension Benefit Plans' benefit obligation were the higher actuarial gains coupled with favorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial gains primarily due to an increase in the discount rate from 4.30% as of December 31, 2023 to 5.07% as of December 31, 2024. For the year ended December 31, 2023, the most significant drivers of the increase in Non-U.S. Pension Benefit Plans' benefit obligation were the higher actuarial losses coupled with unfavorable foreign exchange effects. The Non-U.S. Pension Benefit Plans incurred actuarial losses primarily due to a decrease in the discount rate from 4.60% as of December 31, 2022 to 4.30% as of December 31, 2023.

[0000068505-25-000012:notes:222]
Actuarial Assumptions

[0000068505-25-000012:notes:223]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-25-000012:notes:224]
The Company uses a full yield curve approach to estimate interest and service cost components of net periodic cost (benefit) for defined benefit pension and other post-retirement benefit plans. The full yield curve approach requires the application of the specific spot rate along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows.

[0000068505-25-000012:notes:225]
The Company used "Mortality Improvement Scale MP-2021" to calculate both the 2024 U.S. projected benefit obligations and the 2023 U.S. projected benefit obligations.

[0000068505-25-000012:notes:226]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-25-000012:notes:227]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Discount rate | 4.90 | % |  | 5.09 | % |  | 4.27 | % |  | 4.68 | % |  | 4.89 | % |  | 5.05 | % |
| Investment return assumption | 7.74 | % |  | 7.87 | % |  | 5.84 | % |  | 6.18 | % |  | 8.30 | % |  | 8.00 | % |

[0000068505-25-000012:notes:228]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-25-000012:notes:229]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Discount rate | 5.70 | % |  | 5.01 | % |  | 5.07 | % |  | 4.30 | % |  | 5.49 | % |  | 4.92 | % |
| Future compensation increase rate | n/a |  | n/a |  | 0.67 | % |  | 0.67 | % |  | n/a |  | n/a |

[0000068505-25-000012:notes:230]
The following table presents the accumulated benefit obligation, projected benefit obligation and fair value of plan assets for our plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets:

[0000068505-25-000012:notes:231]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  |
| December 31 | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  |
| Accumulated benefit obligation | $ | 3,755 |  |  | $ | 3,928 |  |  | $ | 1,162 |  |  | $ | 1,346 |  |  |  |  |
| Projected benefit obligation | 3,755 |  |  | 3,928 |  |  | 1,163 |  |  | 1,347 |  |  |  |  |
| Fair value of plan assets | 3,249 |  |  | 3,273 |  |  | 1,083 |  |  | 1,172 |  |  |  |  |

[0000068505-25-000012:notes:232]
Investment Policy

[0000068505-25-000012:notes:233]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to: equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-25-000012:notes:234]
The weighted-average asset allocations by asset categories for all pension plans and the Postretirement Health Care Benefits Plan were as follows:

[0000068505-25-000012:notes:235]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 23 | % |  | 26 | % |  | 25 | % |  | 28 | % |
| Fixed income securities | 61 | % |  | 56 | % |  | 57 | % |  | 51 | % |
| Cash and other investments | 16 | % |  | 18 | % |  | 18 | % |  | 21 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 22 | % |  | 26 | % |  | 24 | % |  | 28 | % |
| Fixed income securities | 60 | % |  | 56 | % |  | 56 | % |  | 52 | % |
| Cash and other investments | 18 | % |  | 18 | % |  | 20 | % |  | 20 | % |

[0000068505-25-000012:notes:236]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-25-000012:notes:237]
Cash Funding

[0000068505-25-000012:notes:238]
The Company made $6 million and $3 million of contributions to its U.S. Pension Benefit Plans during 2024 and 2023, respectively. The Company contributed $9 million and $9 million to its Non U.S. Pension Benefit Plans during 2024 and 2023, respectively. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2024 or 2023.

[0000068505-25-000012:notes:239]
Expected Future Benefit Payments

[0000068505-25-000012:notes:240]
The following benefit payments are expected to be paid:

[0000068505-25-000012:notes:241]
| Year | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2025 | $ | 172 |  |  | $ | 54 |  |  | $ | 14 |  |
| 2026 | 189 |  |  | 55 |  |  | 14 |  |
| 2027 | 206 |  |  | 57 |  |  | 13 |  |
| 2028 | 224 |  |  | 58 |  |  | 12 |  |
| 2029 | 241 |  |  | 59 |  |  | 11 |  |
| 2030-2034 | 1,365 |  |  | 306 |  |  | 41 |  |

[0000068505-25-000012:notes:242]
Other Benefit Plans

[0000068505-25-000012:notes:243]
Split-Dollar Life Insurance Arrangements

[0000068505-25-000012:notes:244]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a frozen plan. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-25-000012:notes:245]
The net periodic pension cost for these split-dollar life insurance arrangements was $3 million for the year ended December 31, 2024, and $5 million for each of the years ended December 31, 2023 and 2022. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $46 million and $52 million as of December 31, 2024 and December 31, 2023, respectively.

[0000068505-25-000012:notes:246]
Deferred Compensation Plan

[0000068505-25-000012:notes:247]
The Company maintains a deferred compensation plan (“the Plan”) for certain eligible participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the 401(k) plan (as defined below). The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for officers elected by the board of directors of the Company, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the board of directors.

[0000068505-25-000012:notes:248]
Defined Contribution Plan

[0000068505-25-000012:notes:249]
The Company has various defined contribution plans, in which all eligible employees may participate. In the U.S., the Motorola Solutions 401(k) plan (the "401(k) plan") is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2024, 2023 and 2022 were $53 million, $45 million and $43 million, respectively.

[0000068505-25-000012:notes:250]
Under the 401(k) plan, the Company may make an additional discretionary matching contribution to eligible employees. For the years ended December 31, 2024, 2023, and 2022 the Company made no discretionary contributions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-25-000012:notes:251]
Share-Based Compensation and Other Incentive Plans
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option and stock appreciation right granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. In conjunction with a change in control, stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-25-000012:notes:252]
Restricted stock grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees. The grants are restricted in such that they are subject to vesting conditions; however, restricted stock holders have voting rights, and the rights to earn dividends on unvested shares.

[0000068505-25-000012:notes:253]
Restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to certain employees and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. In conjunction with a change in control, shares of RSUs assumed or replaced with comparable shares of RSUs will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-25-000012:notes:254]
Performance-based stock options (“performance options”), market stock units ("MSUs"), and performance stock units ("PSUs") have been granted to certain Company executive officers. Performance options have a three-year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three-year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years. PSUs have been granted as a portion of the Long Range Incentive Plan (“LRIP”) awards issued to certain Company executive officers. The PSUs have a three-year performance period and were granted at a target number of units subject to adjustment based on company performance. The number of PSUs earned will be based on the actual TSR compared to the S&P 500 over the three-year performance period.

[0000068505-25-000012:notes:255]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For each of the years ended December 31, 2024, 2023 and 2022, employees purchased 0.4 million shares, at purchase prices of $231.98 and $300.55 in 2024, $194.62 and $231.40 in 2023, and $199.16 and $190.37 in 2022.

[0000068505-25-000012:notes:256]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-25-000012:notes:257]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2024, 2023 and 2022 was $92.20, $73.04 and $67.18, respectively, using the following weighted-average assumptions:

[0000068505-25-000012:notes:258]
|  | 2024 |  | 2023 |  | 2022 |
| Expected volatility | 21.4 | % |  | 24.4 | % |  | 29.2 | % |
| Risk-free interest rate | 4.3 | % |  | 4.2 | % |  | 2.5 | % |
| Dividend yield | 1.4 | % |  | 1.6 | % |  | 1.9 | % |
| Expected life (years) | 5.9 |  | 5.9 |  | 6.6 |

[0000068505-25-000012:notes:259]
The Company calculates the value of each performance option, MSU, and PSU using a Monte Carlo simulation option pricing model, estimated on the date of grant. The fair values of performance options, MSUs, and PSUs granted during 2024 were $141.51, $396.90 and $515.85, respectively. The fair values of performance options, MSUs, and PSUs granted during 2023 were $122.55, $299.32 and $348.27, respectively. The fair value of performance options, MSUs and PSUs granted during 2022 was $84.73, $244.13 and $249.51, respectively. The following assumptions were used for the calculations.

[0000068505-25-000012:notes:260]
|  | 2024 |  | 2023 |  | 2022 |
|  | Performance Options |  | Performance Options |  | Performance Options |
| Expected volatility of common stock | 21.7 | % |  | 25.1 | % |  | 29.7 | % |
| Expected volatility of the S&P 500 | 30.5 | % |  | 33.3 | % |  | 39.2 | % |
| Risk-free interest rate | 4.3 | % |  | 4.1 | % |  | 2.0 | % |
| Dividend yield | 1.4 | % |  | 1.7 | % |  | 2.0 | % |
| Expected life (years) | 6.5 |  | 6.5 |  | 6.5 |

[0000068505-25-000012:notes:261]
|  | 2024 |  | 2023 |  | 2022 |
|  | Market Stock Unit |  | Market Stock Unit |  | Market Stock Units |
| Expected volatility of common stock | 21.7 | % |  | 25.1 | % |  | 29.7 | % |
| Risk-free interest rate | 4.4 | % |  | 4.5 | % |  | 1.9 | % |
| Dividend yield | 1.3 | % |  | 1.5 | % |  | 1.6 | % |

[0000068505-25-000012:notes:262]
|  | 2024 |  |  | 2023 | 2022 |
|  | Performance Stock Units |  |  | Performance Stock Units | Performance Stock Units |
| Expected volatility of common stock | 21.7 | % |  |  | 25.1 | % | 29.7 | % |
| Expected volatility of the S&P 500 | 30.8 | % |  |  | 33.3 | % | 39.2 | % |
| Risk-free interest rate | 4.3 | % |  |  | 4.6 | % | 1.8 | % |
| Dividend yield | 1.1 | % |  |  | 1.4 | % | 1.6 | % |

[0000068505-25-000012:notes:263]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, performance options, MSUs, and PSUs. The selection of the implied volatility approach was based upon the availability of actively-traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. At the conclusion of each three-year PSU and performance option cycle, the Company uses the historical volatility as the expected volatility to calculate the actual TSR compared to the S&P 500.

[0000068505-25-000012:notes:264]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-25-000012:notes:265]
The Company has applied forfeiture rates, estimated based on historical data, of 10% to the stock option fair values calculated by the Black-Scholes option pricing model and 15% to RSUs. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-25-000012:notes:266]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, at December 31, 2024 (in thousands, except exercise price and years):

[0000068505-25-000012:notes:267]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| $1-$100 | 713 |  |  | $ | 77 |  |  | 2 |  | 713 |  |  | $ | 77 |  |  | 2 |
| $101-$200 | 866 |  |  | 148 |  |  | 5 |  | 866 |  |  | 148 |  |  | 5 |
| $201-$300 | 430 |  |  | 244 |  |  | 8 |  | 90 |  |  | 239 |  |  | 7 |
| $301-$400 | 200 |  |  | 342 |  |  | 9 |  | 5 |  |  | 334 |  |  | 9 |
| $401 and over | 13 |  |  | 482 |  |  | 9 |  | — |  |  | — |  |  | 8 |
|  | 2,222 |  |  |  |  |  |  | 1,674 |  |  |  |  |  |

[0000068505-25-000012:notes:268]
As of December 31, 2024, the weighted average contractual life for options outstanding and exercisable was five and four years, respectively.

[0000068505-25-000012:notes:269]
Current Year Activity

[0000068505-25-000012:notes:270]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-25-000012:notes:271]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2024 | 566 |  |  | $ | 191 |  |  | 1,342 |  |  | $ | 224 |  |  | 85 |  |  | $ | 244 |  |
| Granted | 106 |  |  | 360 |  |  | 582 |  |  | 340 |  |  | 65 |  |  | 397 |  |
| Releases/Exercised | (175) |  |  | 175 |  |  | (601) |  |  | 225 |  |  | (85) |  |  | 244 |  |
| Forfeited/Canceled | (6) |  |  | 314 |  |  | (48) |  |  | 268 |  |  | — |  |  | — |  |
| Balance as of December 31, 2024 | 491 |  |  | $ | 230 |  |  | 1,275 |  |  | $ | 275 |  |  | 65 |  |  | $ | 397 |  |
| Awards exercisable | 275 |  |  | 174 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-25-000012:notes:272]
|  | Performance Options |  | Market Stock Units |  | Performance Stock Units |
|  | No. of Options Outstanding |  | Wtd. Avg. Exercise Price of Shares |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |  | No. of Non-Vested Awards |  | Wtd. Avg. Grant Date Fair Value |
| Balance as of January 1, 2024 | 1,798 |  |  | $ | 122 |  |  | 89 |  |  | $ | 254 |  |  | 213 |  |  | $ | 264 |  |
| Granted | 104 |  |  | 343 |  |  | 37 |  |  | 397 |  |  | 132 |  |  | 514 |  |
| Releases/Exercised | (316) |  |  | 101 |  |  | (69) |  |  | 230 |  |  | (147) |  |  | 335 |  |
| Adjustment for payout factor | 147 |  |  | 179 |  |  | 23 |  |  | 179 |  |  | 74 |  |  | 321 |  |
| Forfeited/Canceled | (2) |  |  | 179 |  |  | (1) |  |  | 185 |  |  | (8) |  |  | 316 |  |
| Balance as of December 31, 2024 | 1,731 |  |  | $ | 144 |  |  | 79 |  |  | $ | 331 |  |  | 264 |  |  | $ | 407 |  |
| Awards exercisable | 1,399 |  |  | 113 |  |  | — |  |  | — |  |  | — |  |  | — |  |

[0000068505-25-000012:notes:273]
At December 31, 2024 and 2023, 6.0 million and 7.2 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-25-000012:notes:274]
Total Share-Based Compensation Expense

[0000068505-25-000012:notes:275]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-25-000012:notes:276]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 48 |  |  | $ | 40 |  |  | $ | 28 |  |
| Selling, general and administrative expenses | 132 |  |  | 116 |  |  | 98 |  |
| Research and development expenditures | 63 |  |  | 56 |  |  | 46 |  |
| Share-based compensation expense included in Operating earnings | 243 |  |  | 212 |  |  | 172 |  |
| Tax benefit | 51 |  |  | 43 |  |  | 34 |  |
| Share-based compensation expense, net of tax | $ | 192 |  |  | $ | 169 |  |  | $ | 138 |  |
| Decrease in basic earnings per share | $ | (1.15) |  |  | $ | (1.01) |  |  | $ | (0.82) |  |
| Decrease in diluted earnings per share | $ | (1.12) |  |  | $ | (0.98) |  |  | $ | (0.80) |  |

[0000068505-25-000012:notes:277]
At December 31, 2024, the Company had unrecognized compensation expense related to all share based awards of $431 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately three years and $5 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. The aggregate fair value of outstanding share based awards as of December 31, 2024 was $629 million.

[0000068505-25-000012:notes:278]
Cash received from stock option exercises and the employee stock purchase plan was $75 million, $104 million, and $156 million for the years ended December 31, 2024, 2023, and 2022, respectively. The total intrinsic value of options exercised during the years ended December 31, 2024, 2023, and 2022 was $164 million, $152 million, and $292 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2024 was $664 million and $567 million, respectively, based on a December 31, 2024 stock price of $462.23 per share.

[0000068505-25-000012:notes:279]
Motorola Solutions Incentive Plans

[0000068505-25-000012:notes:280]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2024, 2023 and 2022 was $218 million, $205 million and $165 million, respectively.

[0000068505-25-000012:notes:281]
Long-Range Incentive Plan

[0000068505-25-000012:notes:282]
The LRIP rewards elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three-year period. There were no LRIP awards with cash settlement terms for the years ended December 31, 2024 and 2023. The expense for LRIP awards with cash settlement terms was $4 million for the year ended December 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-25-000012:notes:283]
Fair Value Measurements
Investments and Derivatives

[0000068505-25-000012:notes:284]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2024 and December 31, 2023 were as follows:

[0000068505-25-000012:notes:285]
| December 31, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 10 |  |  |  |  | $ | 10 |  |
| Common stock and equivalents | 23 |  |  | — |  |  |  |  | 23 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |

[0000068505-25-000012:notes:286]
| December 31, 2023 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 13 |  |  |  |  | $ | 13 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |
| Common stock and equivalents | 28 |  |  | — |  |  |  |  | 28 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 4 |  |  |  |  | $ | 4 |  |
| Treasury rate lock | — |  |  | 12 |  |  |  |  | 12 |  |

[0000068505-25-000012:notes:287]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-25-000012:notes:288]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2024 and 2023 were as follows:

[0000068505-25-000012:notes:289]
| December 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  |  |  | Total |
| Equities | $ | 23 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 23 |  |
| Commingled funds | 1,039 |  |  | 404 |  |  | — |  |  |  |  | 1,443 |  |
| Government fixed income securities | — |  |  | 239 |  |  | — |  |  |  |  | 239 |  |
| Corporate fixed income securities | — |  |  | 905 |  |  | — |  |  |  |  | 905 |  |
| Short-term investment funds | 258 |  |  | — |  |  | — |  |  |  |  | 258 |  |
| Private assets | — |  |  | — |  |  | 203 |  |  |  |  | 203 |  |
| Total investment securities | $ | 1,320 |  |  | $ | 1,548 |  |  | $ | 203 |  |  |  |  | $ | 3,071 |  |
| Accrued income receivable |  |  |  |  |  |  |  |  | 162 |  |
| Cash |  |  |  |  |  |  |  |  | 16 |  |
| Fair value plan assets |  |  |  |  |  |  |  |  | $ | 3,249 |  |

[0000068505-25-000012:notes:290]
The following table summarizes the changes in fair value of the Level 3 assets:

[0000068505-25-000012:notes:291]
|  | 2024 |
| Fair value at January 1, 2024 | $ | 157 |  |
| Actual return on plan assets | 22 |  |
| Purchases | 24 |  |
| Fair value at December 31, 2024 | $ | 203 |  |

[0000068505-25-000012:notes:292]
| December 31, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |  |
| Equities | $ | 27 |  |  | $ | — |  |  | $ | — |  |  | $ | 27 |  |  |  |
| Commingled funds | 1,230 |  |  | 479 |  |  | — |  |  | 1,709 |  |  |  |
| Government fixed income securities | — |  |  | 192 |  |  | — |  |  | 192 |  |  |  |
| Corporate fixed income securities | — |  |  | 894 |  |  | — |  |  | 894 |  |  |  |
| Short-term investment funds | 253 |  |  | — |  |  | — |  |  | 253 |  |  |  |
| Private Assets | — |  |  | — |  |  | 157 |  |  | 157 |  |  |  |
| Total investment securities | $ | 1,510 |  |  | $ | 1,565 |  |  | $ | 157 |  |  | $ | 3,232 |  |  |  |
| Accrued income receivable |  |  |  |  |  |  | 23 |  |  |  |
| Cash |  |  |  |  |  |  | 18 |  |  |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 3,273 |  |  |  |

[0000068505-25-000012:notes:293]
| December 31, 2024 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 53 |  |  | $ | — |  |  |  |  | $ | 53 |  |
| Commingled funds | 236 |  |  | 35 |  |  |  |  | 271 |  |
| Government fixed income securities | — |  |  | 615 |  |  |  |  | 615 |  |
| Short-term investment funds | 56 |  |  | — |  |  |  |  | 56 |  |
| Total investment securities | $ | 345 |  |  | $ | 650 |  |  |  |  | $ | 995 |  |
| Cash |  |  |  |  |  |  | 4 |  |
| Accrued income receivable |  |  |  |  |  |  | 42 |  |
| Insurance contracts |  |  |  |  |  |  | 42 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,083 |  |

[0000068505-25-000012:notes:294]
| December 31, 2023 | Level 1 |  | Level 2 |  |  |  | Total |
| Equities | $ | 60 |  |  | $ | — |  |  |  |  | $ | 60 |  |
| Commingled funds | 289 |  |  | 32 |  |  |  |  | 321 |  |
| Government fixed income securities | — |  |  | 663 |  |  |  |  | 663 |  |
| Short-term investment funds | 60 |  |  | — |  |  |  |  | 60 |  |
| Total investment securities | $ | 409 |  |  | $ | 695 |  |  |  |  | $ | 1,104 |  |
| Cash |  |  |  |  |  |  | 5 |  |
| Accrued income receivable |  |  |  |  |  |  | 16 |  |
| Insurance contracts |  |  |  |  |  |  | 47 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 1,172 |  |

[0000068505-25-000012:notes:295]
| December 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equities | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Commingled funds | 40 |  |  | 16 |  |  | — |  |  | 56 |  |
| Government fixed income securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Corporate fixed income securities | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Short-term investment funds | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Private funds | — |  |  | — |  |  | 8 |  |  | 8 |  |
| Total investment securities | $ | 51 |  |  | $ | 63 |  |  | $ | 8 |  |  | $ | 122 |  |
| Accrued income receivable |  |  |  |  |  |  | 6 |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 128 |  |

[0000068505-25-000012:notes:296]
|  | 2024 |
| Fair value at January 1, 2024 | $ | 7 |  |
| Purchases | 1 |  |
| Fair value at December 31, 2024 | $ | 8 |  |

[0000068505-25-000012:notes:297]
| December 31, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Equities | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  |
| Commingled funds | 49 |  |  | 20 |  |  | — |  |  | 69 |  |  |
| Government fixed income securities | — |  |  | 8 |  |  | — |  |  | 8 |  |  |
| Corporate fixed income securities | — |  |  | 38 |  |  | — |  |  | 38 |  |  |
| Short-term investment funds | 10 |  |  | — |  |  | — |  |  | 10 |  |  |
| Private funds | — |  |  | — |  |  | 7 |  |  | 7 |  |  |
| Total investment securities | $ | 60 |  |  | $ | 66 |  |  | $ | 7 |  |  | $ | 133 |  |  |
| Accrued income receivable |  |  |  |  |  |  | 1 |  |  |
| Fair value plan assets |  |  |  |  |  |  | $ | 134 |  |  |

[0000068505-25-000012:notes:298]
The following is a description of the categories of investments:

[0000068505-25-000012:notes:299]
Equities — A diversified portfolio of corporate common and preferred stocks.

[0000068505-25-000012:notes:300]
Commingled funds — A diversified portfolio of assets that includes corporate common and preferred stocks, emerging market and high-yield fixed income securities among others.

[0000068505-25-000012:notes:301]
Government fixed income securities — Securities issued by municipal, domestic and foreign government agencies, index-linked government bonds as well as interest rate derivatives.

[0000068505-25-000012:notes:302]
Corporate fixed income securities — A diversified portfolio of primarily investment grade bonds issued by corporations.

[0000068505-25-000012:notes:303]
Short-term investment funds — Investments in money market accounts and derivatives with a liquidity of less than 90 days.

[0000068505-25-000012:notes:304]
Private funds — A diversified portfolio of assets that includes private equity funds and private loans.

[0000068505-25-000012:notes:305]
Level 1 investments include securities which are valued at the closing price reported on the active market in which the individual securities are traded. Level 2 investments consist principally of securities which are valued using independent third party pricing sources. Level 3 investments include securities with valuations derived from valuation techniques, in which one or more significant inputs are unobservable. A variety of inputs are utilized by the independent pricing sources including market based inputs, binding quotes, indicative quotes, and ongoing redemption and subscription activity. Inputs may be weighted differently for any security, and not all inputs are used for each security evaluation.

[0000068505-25-000012:notes:306]
At December 31, 2024, the Company had $1.2 billion of investments in money market government and U.S. treasury funds (Level 1) classified as Cash and cash equivalents in its Consolidated Balance Sheet, compared to $863 million at December 31, 2023. The money market funds had quoted market prices that are approximately at par.

[0000068505-25-000012:notes:307]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2024 was $5.8 billion. The fair value of long-term debt at December 31, 2023 was $6.4 billion, of which the Senior Convertible Notes were $1.6 billion (Level 2). Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange. Refer to "Note 5: Debt and Credit Facilities" to our consolidated financial statements in this “Part II. Item 8. Financial Statements and Supplementary Data” of this Form 10-K for a further discussion of the Senior Convertible Notes.

[0000068505-25-000012:notes:308]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-25-000012:notes:309]
Long-term Financing and Sales of Receivables
Long-term Financing

[0000068505-25-000012:notes:310]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-25-000012:notes:311]
| December 31 | 2024 |  | 2023 |
| Long-term receivables, gross | $ | 65 |  |  | $ | 36 |  |
| Less allowance for losses | (2) |  |  | (2) |  |
| Long-term receivables | $ | 63 |  |  | $ | 34 |  |
| Less current portion | (22) |  |  | (13) |  |
| Non-current long-term receivables | $ | 41 |  |  | $ | 21 |  |

[0000068505-25-000012:notes:312]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s Consolidated Balance Sheet. The Company recognized $1 million in interest income on long-term receivables for the year ended December 31, 2024, compared to no interest income for the year ended December 31, 2023 and $1 million for the year ended December 31, 2022.

[0000068505-25-000012:notes:313]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $105 million at December 31, 2024 and $103 million at December 31, 2023.

[0000068505-25-000012:notes:314]
Sales of Receivables

[0000068505-25-000012:notes:315]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements.

[0000068505-25-000012:notes:316]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2024, 2023 and 2022.

[0000068505-25-000012:notes:317]
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |
| Contract-specific discounting facility | $ | — |  |  | $ | — |  |  | $ | 49 |  |
| Accounts receivable sales proceeds | 15 |  |  | 96 |  |  | 179 |  |
| Long-term receivables sales proceeds | 205 |  |  | 182 |  |  | 204 |  |
| Total proceeds from receivable sales | $ | 220 |  |  | $ | 278 |  |  | $ | 432 |  |

[0000068505-25-000012:notes:318]
The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-25-000012:notes:319]
At December 31, 2024, the Company had retained servicing obligations for $794 million of long-term receivables, compared to $813 million of long-term receivables at December 31, 2023. Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-25-000012:notes:320]
Credit Quality of Long-Term Receivables and Allowance for Credit Losses

[0000068505-25-000012:notes:321]
An aging analysis of financing receivables at December 31, 2024 and December 31, 2023 is as follows:

[0000068505-25-000012:notes:322]
| December 31, 2024 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 31 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 1 |  |
| Commercial loans and leases secured | 34 |  |  | 3 |  |  | — |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 65 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000068505-25-000012:notes:323]
| December 31, 2023 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 15 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Commercial loans and leases secured | 21 |  |  | 1 |  |  | — |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 36 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000068505-25-000012:notes:324]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-25-000012:notes:325]
Commitments and Contingencies
Purchase Obligations

[0000068505-25-000012:notes:326]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow it to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancellable.

[0000068505-25-000012:notes:327]
As of December 31, 2024, the Company had entered into firm, non-cancelable, and unconditional commitments under such arrangements through 2030. The Company expects to make total payments of $713 million under these arrangements as follows: $151 million in 2025, $159 million in 2026, $159 million in 2027, $130 million in 2028, $112 million in 2029 and $2 million thereafter.

[0000068505-25-000012:notes:328]
Legal Matters

[0000068505-25-000012:notes:329]
Hytera Civil Litigation

[0000068505-25-000012:notes:330]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-25-000012:notes:331]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera has made de minimis quarterly royalty payments into the third-party escrow from October 2022 up through November 2024. Future royalty payments are expected to be paid directly to the Company. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other Charges (Income) within the Consolidated Statement of Operations.

[0000068505-25-000012:notes:332]
Following the February 14, 2020, verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States. Acceptance or denial of the petition is discretionary by the Supreme Court.

[0000068505-25-000012:notes:333]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings from August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.

[0000068505-25-000012:notes:334]
Hytera Criminal Litigation

[0000068505-25-000012:notes:335]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 6, 2025. Pursuant to the plea agreement reached between Hytera and the government, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in an amount to be determined by the District Court.

[0000068505-25-000012:notes:336]
Hytera Bankruptcy Proceedings

[0000068505-25-000012:notes:337]
Separate from the Company's litigation with Hytera, on May 27, 2020, Hytera America, Inc. and Hytera Communications America (West), Inc. each filed for Chapter 11 bankruptcy protection in the U.S. Bankruptcy Court for the Central District of California (the “Bankruptcy Court”). On February 11, 2022, the Court entered an order to confirm the liquidation plan for the two Hytera entities and distributions were made on February 25, 2022 to the creditors, including a distribution of $13 million to the Company. On December 22, 2022, an additional distribution of $2 million was made to the Company as well as an assignment of various delinquent accounts receivable of the bankrupt Hytera entities. On April 4, 2024, a final de minimis distribution was made to the Company. The gains for the three monetary distributions were recorded to Other charges (income) in the Company's Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-25-000012:notes:338]
Information by Segment and Geographic Region
The Company conducts its business globally and manages it through the following two segments:

[0000068505-25-000012:notes:339]
Products and Systems Integration: The Products and Systems Integration segment offers an extensive portfolio of infrastructure, devices, accessories, video security devices and infrastructure, and the implementation and integration of such systems, devices, and applications. Within LMR Communications, the Company is a global leader in the two-way radio category, including the Company’s Project 25 ("P25"), Terrestrial Trunked Radio (TETRA), Digital Mobile Radio (DMR), as well as other professional and commercial radio (“PCR”) solutions. The Company provides LTE solutions for public safety, government and commercial users, including devices operating in 700 MHz, 900 MHz and Citizens' Broadband Radio Service (CBRS) frequencies. The Company's Video technology includes network video management infrastructure, fixed security, certain mobile video equipment and access control solutions. The primary customers of the Products and Systems Integration segment are government, public safety and commercial customers who operate private communications systems and video security solutions and typically manage a mobile workforce. In 2024, the segment’s net sales were $6.9 billion, representing 64% of the Company's consolidated net sales.

[0000068505-25-000012:notes:340]
Software and Services: The Software and Services segment provides a broad range of solution offerings for government, public safety and commercial customers. Software includes public safety and enterprise Command Center, unified communications applications, certain mobile video equipment, and video software solutions, delivered both on-premise and “as-a-service.” Services includes a continuum of service offerings beginning with repair, technical support and maintenance. More advanced technologies include monitoring, software updates and cybersecurity services. Managed services range from partial to full operation of customer-owned or Motorola Solutions-owned communications systems. In 2024, the segment’s net sales were $3.9 billion, representing 36% of the Company's consolidated net sales.

[0000068505-25-000012:notes:341]
For the years ended December 31, 2024, 2023 and 2022, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-25-000012:notes:342]
Segment Information

[0000068505-25-000012:notes:343]
The Company's chief operating decision maker, the chief executive officer, uses both segment gross margin and segment operating earnings to assess performance and allocate resources (including employees, property, and financial or capital resources) for each segment predominantly in the annual budget and forecasting process. The chief operating decision maker considers budget-to-actual variances on a monthly basis for both profit measures when making decisions about allocating capital and personnel to the segments.

[0000068505-25-000012:notes:344]
The accounting policies of the reportable segments are the same as those described in the summary of significant accounting policies. See “Note 1: Summary of Significant Accounting Policies” to our consolidated financial statements in this “Part II. Item 8: Financial Statements and Supplementary Data” of this Form 10-K.

[0000068505-25-000012:notes:345]
The following table summarizes Net sales, significant expenses, Gross margin and Operating earnings by segment:

[0000068505-25-000012:notes:346]
|  | 2024 |  | 2023 |  | 2022 |
| Years ended December 31 | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 6,883 |  |  | $ | 3,934 |  |  | $ | 10,817 |  |  | $ | 6,242 |  |  | $ | 3,736 |  |  | $ | 9,978 |  |  | $ | 5,728 |  |  | $ | 3,384 |  |  | $ | 9,112 |  |
| Costs of sales | 3,215 |  |  | 2,090 |  |  | 5,305 |  |  | 3,115 |  |  | 1,893 |  |  | 5,008 |  |  | 3,060 |  |  | 1,823 |  |  | 4,883 |  |
| Gross margin | 3,668 |  |  | 1,844 |  |  | 5,512 |  |  | 3,127 |  |  | 1,843 |  |  | 4,970 |  |  | 2,668 |  |  | 1,561 |  |  | 4,229 |  |
| Selling, general and administrative expenses | 1,392 |  |  | 360 |  | 1,752 |  |  | 1,239 |  |  | 322 |  |  | 1,561 |  |  | 1,156 |  |  | 294 |  |  | 1,450 |  |
| Research and development expenditures | 575 |  | 342 |  | 917 |  | 551 |  |  | 307 |  |  | 858 |  |  | 503 |  |  | 276 |  |  | 779 |  |
| Other charges | 25 |  | 130 |  | 155 |  | 94 |  |  | 163 |  |  | 257 |  |  | 96 |  |  | 243 |  |  | 339 |  |
| Operating earnings | $ | 1,676 |  |  | $ | 1,012 |  |  | $ | 2,688 |  |  | $ | 1,244 |  |  | $ | 1,050 |  |  | $ | 2,294 |  |  | $ | 913 |  |  | $ | 748 |  |  | $ | 1,661 |  |
| Total other expense |  |  |  |  | (716) |  |  |  |  |  |  | (148) |  |  |  |  |  |  | (146) |  |
| Net earnings before income taxes |  |  |  |  | $ | 1,972 |  |  |  |  |  |  | $ | 2,146 |  |  |  |  |  |  | $ | 1,515 |  |

[0000068505-25-000012:notes:347]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-25-000012:notes:348]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| Products and Systems Integration | $ | 103 |  |  | $ | 97 |  |  | $ | 77 |  |  | $ | 90 |  |  | $ | 83 |  |  | $ | 79 |  |
| Software and Services | 154 |  |  | 156 |  |  | 179 |  |  | 94 |  |  | 96 |  |  | 104 |  |
|  | $ | 257 |  |  | $ | 253 |  |  | $ | 256 |  |  | $ | 184 |  |  | $ | 179 |  |  | $ | 183 |  |

[0000068505-25-000012:notes:349]
The Company's chief operating decision maker does not review or allocate resources based on segment assets.

[0000068505-25-000012:notes:350]
Geographic Area Information

[0000068505-25-000012:notes:351]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 7,432 |  |  | $ | 6,559 |  |  | $ | 6,008 |  |  | $ | 11,456 |  |  | $ | 10,207 |  |  | $ | 9,227 |  |
| United Kingdom | 572 |  |  | 769 |  |  | 789 |  |  | 2,190 |  |  | 2,034 |  |  | 2,321 |  |
| Canada | 388 |  |  | 373 |  |  | 366 |  |  | 383 |  |  | 362 |  |  | 394 |  |
| Other | 2,425 |  |  | 2,277 |  |  | 1,949 |  |  | 566 |  |  | 733 |  |  | 872 |  |
|  | $ | 10,817 |  |  | $ | 9,978 |  |  | $ | 9,112 |  |  | $ | 14,595 |  |  | $ | 13,336 |  |  | $ | 12,814 |  |

[0000068505-25-000012:notes:352]
Net sales attributed to geographic area are predominately based on the ultimate destination of the Company's products and services.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-25-000012:notes:353]
Reorganization of Businesses
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of contractual lease termination costs, costs to exit committed contracts and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the Consolidated Statements of Operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-25-000012:notes:354]
During 2024, 2023, and 2022 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. These initiatives impacted both of the Company’s segments and affected employees located in all geographic regions.

[0000068505-25-000012:notes:355]
2024 Charges

[0000068505-25-000012:notes:356]
During 2024, the Company recorded net reorganization of business charges of $38 million, including $12 million of charges in Costs of sales and $26 million of charges in Other charges in the Company’s Consolidated Statements of Operations. Included in the $38 million were charges of $48 million related to employee separation costs, partially offset by $6 million of reversals for employee separation accruals no longer needed and $4 million of reversals for exit cost accruals no longer needed.

[0000068505-25-000012:notes:357]
The following table displays the net charges incurred by segment:

[0000068505-25-000012:notes:358]
| Year ended December 31 | 2024 |
| Products and Systems Integration | $ | 32 |  |
| Software and Services | 6 |  |
|  | $ | 38 |  |

[0000068505-25-000012:notes:359]
Reorganization of Businesses Accruals

[0000068505-25-000012:notes:360]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Reorganization costs | $ | 23 |  |  | $ | 48 |  |  | $ | (6) |  |  | $ | (38) |  |  | $ | 27 |  |
| Exit costs | $ | 5 |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | 1 |  |
|  | $ | 28 |  |  | $ | 48 |  |  | $ | (10) |  |  | $ | (38) |  |  | $ | 28 |  |

[0000068505-25-000012:notes:361]
Exit Costs

[0000068505-25-000012:notes:362]
At January 1, 2024, the Company had an accrual of $5 million for exit costs related to the Company's exit of the Emergency Services Network contract with the Home Office. During the year, the Company recorded a $4 million reversal for accruals no longer needed. The remaining $1 million of exit costs are recorded in Accrued liabilities in the Company's Consolidated Balance Sheet at December 31, 2024, and are expected to be paid within one year.

[0000068505-25-000012:notes:363]
Employee Separation Costs

[0000068505-25-000012:notes:364]
At January 1, 2024, the Company had an accrual of $23 million for employee separation costs. The 2024 additional charges of $48 million include severance costs for approximately 720 employees, of which 460 were direct employees and 260 were indirect employees. The adjustments of $6 million reflect reversals of accruals no longer needed. The $38 million used in 2024 reflects cash payments to severed employees. The remaining accrual of $27 million, which is included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2024, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 140 employees to be separated in 2025.

[0000068505-25-000012:notes:365]
2023 Charges

[0000068505-25-000012:notes:366]
During 2023, the Company recorded net reorganization of business charges of $53 million, including $7 million of charges in Costs of sales and $46 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the $53 million were charges of $41 million for employee separation costs and a $24 million impairment loss related to the exit of video manufacturing operations, partially offset by $7 million of reversals of accruals no longer needed and $5 million of reversals for exit cost accruals no longer needed.

[0000068505-25-000012:notes:367]
| Year ended December 31 | 2023 |
| Products and Systems Integration | $ | 45 |  |
| Software and Services | 8 |  |
|  | $ | 53 |  |

[0000068505-25-000012:notes:368]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Reorganization costs | $ | 26 |  |  | $ | 41 |  |  | $ | (7) |  |  | $ | (37) |  |  | $ | 23 |  |
| Exit costs | 10 |  |  | — |  |  | (5) |  |  | — |  |  | 5 |  |
|  | $ | 36 |  |  | $ | 41 |  |  | $ | (12) |  |  | $ | (37) |  |  | $ | 28 |  |

[0000068505-25-000012:notes:369]
At January 1, 2023, the Company had an accrual of $10 million for exit costs related to the Company's exit of the ESN contract with the Home Office. During the year, the Company recorded a $5 million reversal for accruals no longer needed. The remaining $5 million of exit costs are recorded in Accrued liabilities in the Company's Consolidated Balance Sheet at December 31, 2023, and are expected to be paid within one year.

[0000068505-25-000012:notes:370]
At January 1, 2023, the Company had an accrual of $26 million for employee separation costs. The 2023 additional charges of $41 million include severance costs for approximately 700 employees, of which 420 were direct employees and 280 were indirect employees. The adjustments of $7 million reflect reversals of accruals no longer needed. The $37 million used in 2023 reflects cash payments to severed employees. The remaining accrual of $23 million, which was included in Accrued liabilities in the Company’s Consolidated Balance Sheet at December 31, 2023, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 75 employees to be separated in 2024.

[0000068505-25-000012:notes:371]
2022 Charges

[0000068505-25-000012:notes:372]
During 2022, the Company recorded net reorganization of business charges of $36 million, including $18 million of charges in Costs of sales and $18 million of charges under Other charges in the Company’s Consolidated Statements of Operations. Included in the aggregate $36 million were charges of $36 million for employee separation costs and $10 million for exit costs, partially offset by $10 million of reversals of accruals no longer needed.

[0000068505-25-000012:notes:373]
| Year ended December 31 | 2022 |
| Products and Systems integration | $ | 21 |  |
| Software and Services | 15 |  |
|  | $ | 36 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-25-000012:notes:374]
Intangible Assets and Goodwill
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-25-000012:notes:375]
Recent Acquisitions

[0000068505-25-000012:notes:376]
On October 29, 2024, the Company acquired 3tc, a provider of control room software solutions for $22 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing CAD for the U.K.'s public safety agencies. The Company recognized $19 million of goodwill, $4 million of identifiable intangible assets, and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $4 million of developed technology and will be amortized over a period of seven years. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000012:notes:377]
On July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $91 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The Company recognized $50 million of goodwill, $53 million of identifiable intangible assets, and $12 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $7 million of customer relationships and $45 million of developed technology and will be amortized over a period of three, fifteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000012:notes:378]
On July 1, 2024, the Company acquired a company that provides vehicle location and management solutions for $132 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $3 million to certain key employees that will be expensed over a service period of three years. The Company recognized $62 million of goodwill, $65 million of identifiable intangible assets and $5 million of net assets. The goodwill is deductible for tax purposes. The identifiable intangible assets were classified as $11 million of trade names, $51 million of customer relationships and $3 million of developed technology and will be amortized over a period of nine, eighteen and six years, respectively. The acquisition expands the Company's video solutions within the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net assets and goodwill may be subject to change.

[0000068505-25-000012:notes:379]
On February 13, 2024, the Company acquired Silent Sentinel, a provider of specialized, long-range cameras, for $37 million, net of cash acquired. This acquisition complements the Company's portfolio of fixed video cameras, expanding its footprint with government and critical infrastructure customers and strengthens the Company's position as a global leader in end-to-end video security solutions. The Company recognized $16 million of goodwill, $22 million of identifiable intangible assets and $1 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $10 million of customer relationships and $11 million of developed technology and will be amortized over a period of two, fourteen and ten years, respectively. The business is part of the Products and System Integration segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-25-000012:notes:380]
On December 15, 2023, the Company acquired IPVideo, the creator of the HALO Smart Sensor, for $170 million, net of cash acquired. The transaction also included the potential for the Company to make contingent earn-out payments of up to $15 million based on IPVideo's achievement of certain financial targets from January 1, 2024 through December 31, 2024. As of the acquisition date, the Company estimated the fair value of the contingent earn-out to be $2 million, which was included in the purchase price. However, as of December 31, 2024, the Company concluded that the contingent earn-out targets were not achieved. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of one year. The HALO Smart Sensor is a multifunctional safety and security device with built-in vape detection and air quality monitoring, gunshot detection, abnormal noise and motion detection and emergency keyword detection. This acquisition adds sensor technology to the Company's physical security portfolio. The Company recognized $100 million of goodwill, $83 million of identifiable intangible assets and $13 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $8 million of trade names, $6 million of customer relationships and $69 million of developed technology and will be amortized over a period of eight, twelve and fifteen years, respectively. The business is a part of the Products and Systems Integration segment. The purchase accounting was completed as of the fourth quarter of 2024.

[0000068505-25-000012:notes:381]
On December 14, 2022, the Company acquired Rave Mobile, a leader in mass notification and incident management, for $553 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $2 million to certain key employees that will be expensed over a service period of two years. This acquisition complements the Company's portfolio with a platform specifically designed to help organizations and public safety agencies communicate and collaborate during emergencies. The Company recognized $400 million of goodwill, $212 million of identifiable intangible assets and $59 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $9 million of trade names, $82 million of developed technology and $121 million of customer relationships and will be amortized over a period of nine, seventeen years and seventeen years, respectively. The business is a part of the Software and Services segment. The purchase accounting was completed as of the fourth quarter of 2023.

[0000068505-25-000012:notes:382]
On October 25, 2022, the Company acquired Futurecom, a leading provider of radio coverage extension solutions for public safety agencies, for $30 million, net of cash acquired. Futurecom designs and manufactures radio frequency repeaters. This acquisition further expands the Company's communications network and device portfolios. The Company recognized $10 million of goodwill, $11 million of an identifiable intangible asset and $9 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of six years. The business is a part of the Products and Systems Integration segment. The purchase accounting was completed as of the fourth quarter of 2023.

[0000068505-25-000012:notes:383]
On August 8, 2022, the Company acquired Barrett Communications, a global provider of specialized radio communications, for $18 million, net of cash acquired. This acquisition complements the Company's existing radio portfolio, allowing the Company to use high frequency and very high frequency radio communications to support mission-critical operations. The Company recognized $1 million of goodwill, $3 million of identifiable intangible assets and $14 million of net assets. The identifiable intangible assets were classified as $1 million of trade names and $2 million of developed technology, both of which will be amortized over a period of seven years. The goodwill is not deductible for tax purposes. The business is part of the Products and Systems Integration segment. The purchase accounting was completed as of the third quarter of 2023.

[0000068505-25-000012:notes:384]
On May 12, 2022, the Company acquired Videotec, a global provider of ruggedized video security solutions, for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. This acquisition extends the Company's breadth of high-performance video products, reinforcing the Company's strategy to be a global leader in video security solutions. The Company recognized $9 million of goodwill, $6 million of an identifiable intangible asset and $8 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as developed technology and will be amortized over a period of four years. The business is part of the Products and Systems Integration segment. The purchase accounting was completed as of the second quarter of 2023.

[0000068505-25-000012:notes:385]
On April 19, 2022, the Company acquired Calipsa, a technology leader in cloud-native advanced video analytics, for $39 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of two years. This acquisition extends the Company's intelligent analytics across video security solutions and supports the accelerating trend of enterprises using cloud technologies to enhance safety and security. The Company recognized $24 million of goodwill, $21 million of identifiable intangible assets, and $6 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $20 million of developed technology and $1 million of customer relationships that will be amortized over a period of fifteen and three years, respectively. The business is a part of the Software and Services segment. The purchase accounting was completed as of the second quarter of 2023.

[0000068505-25-000012:notes:386]
On March 23, 2022, the Company acquired TETRA Ireland, the provider of Ireland's National Digital Radio Service, for $120 million, net of cash acquired. The Company was an initial shareholder of TETRA Ireland and acquired the remaining interest in the entity from the other shareholders. This acquisition expands the Company's portfolio of delivering mission-critical voice and data communications solutions to first responders and frontline workers. As a result of the acquisition, the Company recognized a $21 million gain recorded within Other income (expense) on the Company's initial minority interest. The Company recognized $47 million of goodwill, $90 million of identifiable intangible assets, and $6 million of net assets. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $83 million of customer relationships and $7 million of trade names that will be amortized over a period of twelve years and fourteen years, respectively. The business is part of the Software and Services segment. The purchase accounting was completed as of the first quarter of 2023.

[0000068505-25-000012:notes:387]
On March 3, 2022, the Company acquired Ava, a global provider of cloud-native video security and analytics, for $388 million, net of cash acquired. In addition, the Company issued restricted stock and restricted stock units at a fair value of $7 million to certain key employees that will be expensed over an average service period of two years. This acquisition expands the Company's portfolio of intelligent video solutions that help to enhance safety and streamline operations. The Company recognized $267 million of goodwill, $165 million of identifiable intangible assets, and $44 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $144 million of developed technology and $21 million of customer relationships that will be amortized over a period of fourteen and two years, respectively. The business is a part of both the Products and Systems Integration segment and the Software and Services segment. The purchase accounting was completed as of the first quarter of 2023.

[0000068505-25-000012:notes:388]
Intangible Assets

[0000068505-25-000012:notes:389]
Amortized intangible assets are comprised of the following:

[0000068505-25-000012:notes:390]
|  | 2024 |  | 2023 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Developed technology | $ | 1,226 |  |  | $ | 535 |  |  | $ | 1,156 |  |  | $ | 447 |  |
| Patents | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Customer-related | 1,609 |  |  | 1,093 |  |  | 1,566 |  |  | 1,055 |  |
| Other intangibles | 116 |  |  | 74 |  |  | 105 |  |  | 70 |  |
|  | $ | 2,953 |  |  | $ | 1,704 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-25-000012:notes:391]
Amortization expense on intangible assets, which is included within Other charges in the Consolidated Statements of Operations, was $152 million, $177 million, and $257 million for the years ended December 31, 2024, 2023, and 2022, respectively. As of December 31, 2024, future amortization expense is estimated to be $143 million in 2025, $134 million in 2026, $124 million in 2027, $123 million in 2028, and $112 million in 2029.

[0000068505-25-000012:notes:392]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-25-000012:notes:393]
|  | 2024 |  | 2023 |
| December 31 (in millions) | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 1,017 |  |  | $ | 409 |  |  | $ | 985 |  |  | $ | 337 |  |
| Software and Services | 1,936 |  |  | 1,295 |  |  | 1,844 |  |  | 1,237 |  |
|  | $ | 2,953 |  |  | $ | 1,704 |  |  | $ | 2,829 |  |  | $ | 1,574 |  |

[0000068505-25-000012:notes:394]
Goodwill

[0000068505-25-000012:notes:395]
The following table displays a rollforward of the carrying amount of goodwill, net of impairment losses, by segment from January 1, 2023 to December 31, 2024:

[0000068505-25-000012:notes:396]
| (in millions) | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2023 | $ | 1,461 |  |  | $ | 1,851 |  |  | $ | 3,312 |  |
| Goodwill acquired | 109 |  |  | — |  |  | 109 |  |
| Purchase accounting adjustments | (2) |  |  | (29) |  |  | (31) |  |
| Foreign currency translation | — |  |  | 11 |  |  | 11 |  |
| Balance as of December 31, 2023 | $ | 1,568 |  |  | $ | 1,833 |  |  | $ | 3,401 |  |
| Goodwill acquired | 16 |  |  | 128 |  |  | 144 |  |
| Purchase accounting adjustments | (9) |  |  | 3 |  |  | (6) |  |
| Foreign currency translation | (2) |  |  | (11) |  |  | (13) |  |
| Balance as of December 31, 2024 | $ | 1,573 |  |  | $ | 1,953 |  |  | $ | 3,526 |  |

[0000068505-25-000012:notes:397]
The Company conducts its annual assessment of goodwill for impairment as of the last day of the third quarter of each fiscal year. The goodwill impairment assessment is performed at the reporting unit level which is an operating segment or one level below an operating segment.

[0000068505-25-000012:notes:398]
In 2024 and 2023, the Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal year 2024 and 2023, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, a quantitative goodwill impairment test was not required and there was no impairment of goodwill in 2024 or 2023.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-25-000012:notes:399]
Valuation and Qualifying Accounts
The following table presents the valuation and qualifying account activity for the years ended December 31, 2024, 2023, and 2022:

[0000068505-25-000012:notes:400]
|  | Balance atBeginning of Period |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atEnd of Period |
| 2024 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | $ | 69 |  |  | $ | 49 |  |  | $ | (35) |  |  | $ | — |  |  | $ | 83 |  |
| 2023 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 61 |  |  | 29 |  |  | (21) |  |  | — |  |  | 69 |  |
| 2022 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses | 70 |  |  | 28 |  |  | (36) |  |  | (1) |  |  | 61 |  |

[0000068505-25-000012:notes:401]
* Adjustments include translation adjustments
