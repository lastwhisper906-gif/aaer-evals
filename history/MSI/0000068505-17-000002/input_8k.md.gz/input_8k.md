# MSI 8-K — 0001193125-17-029153 filed 2017-02-02

## item codes, every 8-K on or before 2017-02-21

- 2017-02-02 0001193125-17-029153 — 2.02, 5.02, 9.01
- 2016-11-14 0001193125-16-767876 — 8.01
- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2017-02-21

- none on or before 2017-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-029153:8k_2_02:1]
EX-99.1
2
d330256dex991.htm
EX-99.1

[0001193125-17-029153:8k_2_02:2]
EX-99.1

[0001193125-17-029153:8k_2_02:3]
Exhibit 99.1

[0001193125-17-029153:8k_2_02:4]
Motorola Solutions Reports Fourth-Quarter and Full-Year 2016 Financial Results

[0001193125-17-029153:8k_2_02:5]
Company achieves full-year record operating earnings, free cash flow1 and backlog

[0001193125-17-029153:8k_2_02:6]
FOURTH-QUARTER HIGHLIGHTS

[0001193125-17-029153:8k_2_02:7]
|  | • |  | Sales of $1.9 billion, up 12 percent from a year ago, including $124 million from Airwave |

[0001193125-17-029153:8k_2_02:8]
|  | • |  | Products sales of $1.2 billion, up $101 million or 9 percent |

[0001193125-17-029153:8k_2_02:9]
|  | • |  | GAAP earnings per share (EPS) from continuing operations of $1.43 |

[0001193125-17-029153:8k_2_02:10]
|  | • |  | Non-GAAP EPS from continuing operations2 of $2.03, up 28 percent |

[0001193125-17-029153:8k_2_02:11]
|  | • |  | Generated $513 million in operating cash flow; $1.2 billion for the full year |

[0001193125-17-029153:8k_2_02:12]
|  | • |  | Generated $453 million in free cash flow1; $894 million for the full year |

[0001193125-17-029153:8k_2_02:13]
|  | • |  | Acquired Spillman Technologies, expanding command center software capabilities |

[0001193125-17-029153:8k_2_02:14]
CHICAGO –
Feb. 2, 2017 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the fourth quarter and full year of 2016. Click here for a printable news release and financial tables.

[0001193125-17-029153:8k_2_02:15]
SUPPORTING QUOTE

[0001193125-17-029153:8k_2_02:16]
“We ended the year with an
outstanding fourth quarter, and I am very encouraged with our strong competitive position and record backlog entering 2017,” said Greg Brown, chairman and CEO of Motorola Solutions.

[0001193125-17-029153:8k_2_02:17]
KEY FINANCIAL RESULTS (presented in millions, except per share data and percentages)

[0001193125-17-029153:8k_2_02:18]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Sales |  | $ | 1,883 |  |  | $ | 1,682 |  |  |  | 12 | % |  | $ | 6,038 |  |  | $ | 5,695 |  |  |  | 6 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings |  | $ | 403 |  |  | $ | 389 |  |  |  | 4 | % |  | $ | 1,067 |  |  | $ | 994 |  |  |  | 7 | % |
| % of Sales |  |  | 21.4 | % |  |  | 23.1 | % |  |  |  |  |  |  | 17.7 | % |  |  | 17.5 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 1.43 |  |  | $ | 1.56 |  |  |  | (8 | )% |  | $ | 3.24 |  |  | $ | 3.17 |  |  |  | 2 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating earnings |  | $ | 541 |  |  | $ | 458 |  |  |  | 18 | % |  | $ | 1,427 |  |  | $ | 1,166 |  |  |  | 22 | % |
| % of Sales |  |  | 28.7 | % |  |  | 27.2 | % |  |  |  |  |  |  | 23.6 | % |  |  | 20.5 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 2.03 |  |  | $ | 1.58 |  |  |  | 28 | % |  | $ | 4.92 |  |  | $ | 3.33 |  |  |  | 48 | % |
| Products Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 1,226 |  |  | $ | 1,125 |  |  |  | 9 | % |  | $ | 3,649 |  |  | $ | 3,676 |  |  |  | (1 | )% |
| GAAP Operating earnings |  | $ | 330 |  |  | $ | 291 |  |  |  | 13 | % |  | $ | 734 |  |  | $ | 704 |  |  |  | 4 | % |
| % of Sales |  |  | 26.9 | % |  |  | 25.9 | % |  |  |  |  |  |  | 20.1 | % |  |  | 19.2 | % |  |  |  |  |
| Non-GAAP Operating earnings |  | $ | 407 |  |  | $ | 340 |  |  |  | 20 | % |  | $ | 910 |  |  | $ | 827 |  |  |  | 10 | % |
| % of Sales |  |  | 33.2 | % |  |  | 30.2 | % |  |  |  |  |  |  | 24.9 | % |  |  | 22.5 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 657 |  |  | $ | 557 |  |  |  | 18 | % |  | $ | 2,389 |  |  | $ | 2,019 |  |  |  | 18 | % |
| GAAP Operating earnings |  | $ | 73 |  |  | $ | 98 |  |  |  | (26 | )% |  | $ | 333 |  |  | $ | 290 |  |  |  | 15 | % |
| % of Sales |  |  | 11.1 | % |  |  | 17.6 | % |  |  |  |  |  |  | 13.9 | % |  |  | 14.4 | % |  |  |  |  |
| Non-GAAP Operating earnings |  | $ | 134 |  |  | $ | 118 |  |  |  | 14 | % |  | $ | 517 |  |  | $ | 339 |  |  |  | 53 | % |
| % of Sales |  |  | 20.4 | % |  |  | 21.2 | % |  |  |  |  |  |  | 21.6 | % |  |  | 16.8 | % |  |  |  |  |

[0001193125-17-029153:8k_2_02:19]
OTHER SELECT FOURTH-QUARTER FINANCIAL RESULTS

[0001193125-17-029153:8k_2_02:20]
|  | • |  | Revenue – Sales increased 12 percent, including $124 million in sales from Airwave. Sales grew in every region. The Products segment sales grew 9 percent, with growth in every region. The Services segment grew 18 percent including Airwave, while Managed and Support Services grew 5 percent excluding Airwave. |

[0001193125-17-029153:8k_2_02:21]
|  | • |  | Operating margin – GAAP operating margin was 21.4 percent of sales, compared to 23.1 percent of sales in the year-ago quarter. Non-GAAP operating margin was 28.7 percent of sales, compared with 27.2 percent in the year-ago quarter. The improvement is primarily the result of higher sales. |

[0001193125-17-029153:8k_2_02:22]
|  | • |  | Taxes – The GAAP effective tax rate was 33 percent, compared with 26 percent in the year-ago quarter. The prior year’s favorable rate was driven primarily by several discrete one-time items. The non-GAAP tax rate was 31 percent, compared with 31 percent in the fourth quarter of 2015. |

[0001193125-17-029153:8k_2_02:23]
|  | • |  | Cash flow – The company generated $513 million in operating cash from continuing operations, up $98 million from the year-ago quarter primarily driven by earnings from higher revenue. Free cash flow1 was up $82 million to $453 million. |

[0001193125-17-029153:8k_2_02:24]
|  | • |  | Capital allocation – The company ended the quarter with cash and cash equivalents of $1.0 billion and a net debt position of approximately $3.4 billion3. The company repaid the $675 million term loan associated with the Airwave acquisition, repurchased $114 million of common stock, paid $68 million in dividends and invested $246 million in acquisitions. |

[0001193125-17-029153:8k_2_02:25]
OTHER SELECT FULL-YEAR FINANCIAL RESULTS

[0001193125-17-029153:8k_2_02:26]
|  | • |  | Revenue – Sales increased 6 percent, including $462 million in Airwave sales. These results reflect growth in North America and Asia Pacific in both Products and Services. Growth of 33 percent in the Europe, Middle East and Africa region was driven by Airwave and partially offset by lower revenue in Norway associated with completing the implementation phase of the nationwide project. Latin America was down 20 percent, primarily on iDEN declines and first-half weakness. Products segment sales were down 1 percent compared to the prior year, while the Services segment grew 18 percent on Managed and Support Services strength. |

[0001193125-17-029153:8k_2_02:27]
|  | • |  | Operating margin – For the full year, GAAP operating margin was 17.7 percent of sales, compared with 17.5 percent for the prior year. Non-GAAP operating margin was 23.6 percent of sales, compared with 20.5 percent for the prior year, driven by higher revenue and lower operating expenses. |

[0001193125-17-029153:8k_2_02:28]
|  | • |  | Taxes – The 2016 GAAP effective tax rate was 33 percent, compared to 30 percent for the prior year. The non-GAAP tax rate was 31 percent, compared with 33 percent in the prior year. |

[0001193125-17-029153:8k_2_02:29]
|  | • |  | Cash flow – The company generated $1.2 billion in operating cash from continuing operations, reflecting an increase of $144 million from the prior year. Free cash flow1 was $894 million, up $48 million from the prior year. The increase was driven by higher sales and lower operating costs, partially offset by higher capital expenditures. |

[0001193125-17-029153:8k_2_02:30]
|  | • |  | Capital allocation – The company invested $1.3 billion in acquisitions, repurchased approximately $842 million of its common stock and paid $280 million in dividends. |

[0001193125-17-029153:8k_2_02:31]
KEY HIGHLIGHTS

[0001193125-17-029153:8k_2_02:32]
Fourth-quarter strategic wins

[0001193125-17-029153:8k_2_02:33]
|  | • |  | $140 million P25 system deployment for the Washington, D.C. Metro Area Transit Authority |

[0001193125-17-029153:8k_2_02:34]
|  | • |  | $60 million P25 system replacement and multiyear services for San Francisco |

[0001193125-17-029153:8k_2_02:35]
|  | • |  | $40 million P25 system and devices upgrade unifying eight cities in Argentina |

[0001193125-17-029153:8k_2_02:36]
|  | • |  | $17 million Smart Public Safety Solutions sale of computer-aided dispatch equipment, software and multiyear services to Indianapolis |

[0001193125-17-029153:8k_2_02:37]
Fourth-quarter innovation and investments in growth

[0001193125-17-029153:8k_2_02:38]
|  | • |  | Acquired Spillman Technologies, a leading provider of comprehensive law enforcement and public safety software solutions, which bolsters the command center portfolio |

[0001193125-17-029153:8k_2_02:39]
|  | • |  | Released new P25 and TETRA devices that provide unmatched features and functionality. In addition to form factor enhancements, the radios provide Bluetooth 4.0, Wi-Fi and enhanced location services that enable future software and services opportunities |

[0001193125-17-029153:8k_2_02:40]
|  | • |  | Following more than three years of collaboration, emergency services in Norway and Sweden conducted their first major cross-border emergency response exercise supported by fully inter-operable multi-vendor radio communications. This land mobile radio (LMR) to LMR cross-border collaboration using different vendor equipment is spurring additional interest from neighboring countries and illustrates the power of the LMR communications platform |

[0001193125-17-029153:8k_2_02:41]
BUSINESS OUTLOOK

[0001193125-17-029153:8k_2_02:42]
|  | • |  | First-quarter 2017 – Motorola Solutions expects revenue growth of 3 to 5 percent compared with the first quarter of 2016. This includes approximately $115 million from Airwave versus $61 million in the year-ago quarter. The company expects non-GAAP earnings per share from continuing operations in the range of $0.52 to $0.57 per share. |

[0001193125-17-029153:8k_2_02:43]
|  | • |  | Full-year 2017 – The company expects revenue to be up 1 to 2 percent. Airwave revenue is expected to be flat compared with the prior year due to foreign exchange rates. The company expects non-GAAP earnings per share from continuing operations in the range of $5.05 to $5.20 per share. |

[0001193125-17-029153:8k_2_02:44]
CONFERENCE CALL AND WEBCAST

[0001193125-17-029153:8k_2_02:45]
Motorola Solutions will host
its quarterly conference call beginning at 4 p.m. U.S. Central Standard Time (5 p.m. U.S. Eastern Standard Time) Thursday, Feb. 2. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-17-029153:8k_2_02:46]
CONSOLIDATED GAAP RESULTS (presented in millions, except per share data)

[0001193125-17-029153:8k_2_02:47]
A comparison of results from operations is as follows:

[0001193125-17-029153:8k_2_02:48]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 1,883 |  |  | $ | 1,682 |  |  | $ | 6,038 |  |  | $ | 5,695 |  |
| Gross margin |  |  | 928 |  |  |  | 838 |  |  |  | 2,869 |  |  |  | 2,719 |  |
| Operating earnings |  |  | 403 |  |  |  | 389 |  |  |  | 1,067 |  |  |  | 994 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  |  | 243 |  |  |  | 277 |  |  |  | 560 |  |  |  | 640 |  |
| Net earnings |  |  | 243 |  |  |  | 279 |  |  |  | 560 |  |  |  | 610 |  |
| Diluted EPS from continuing operations |  | $ | 1.43 |  |  | $ | 1.56 |  |  | $ | 3.24 |  |  | $ | 3.17 |  |
| Weighted average diluted common shares outstanding |  |  | 170.4 |  |  |  | 177.5 |  |  |  | 173.1 |  |  |  | 201.8 |  |

[0001193125-17-029153:8k_2_02:49]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-17-029153:8k_2_02:50]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the fourth quarter of 2016.

[0001193125-17-029153:8k_2_02:51]
| (per diluted common share) |  | Q4 2016 |  |
| GAAP Earnings from Continuing Operations |  | $ | 1.43 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  | $ | 0.06 |  |
| Reorganization of business charges |  | $ | 0.31 |  |
| Intangibles amortization expense |  | $ | 0.14 |  |
| Loss on pension plan settlement |  | $ | 0.15 |  |
| Release of unrecognized tax benefit from audit settlement |  | ($ | 0.06 | ) |
| Total Highlighted Items |  | $ | 0.60 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 2.03 |  |

[0001193125-17-029153:8k_2_02:52]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-17-029153:8k_2_02:53]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP
measurements of results. The company has provided these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period
to period and allow better comparisons of operating performance to its competitors. Among other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results
relative to certain incentive compensation targets. Management uses operating results excluding these items because it believes this measurement enables it to make better
period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended
only as a supplement to the comparable GAAP measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in addition to, and not in substitution for or as superior to, measurements of
financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-17-029153:8k_2_02:54]
Highlighted items: The company has excluded the
effects of highlighted items including, but not limited to, acquisition-related transaction costs, tangible and intangible asset impairments, restructuring charges, non-cash pension adjustments,
significant litigation and other contingencies, significant gains and losses on investments, and the income tax effects of significant tax matters, from its non-GAAP operating expenses and net income
measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not contribute to a meaningful evaluation of the company’s current operating performance or comparisons
to the company’s past operating performance. For the purposes of management’s internal analysis over operating performance, the company uses financial statements that exclude highlighted items, as these charges do not contribute to a
meaningful evaluation of the company’s current operating performance or comparisons to the company’s past operating performance. Specifically in regards to its restructuring plans, the company has incurred significant restructuring charges
as it reduced approximately $700 million of operating expenses in the past four years.

[0001193125-17-029153:8k_2_02:55]
Share-based compensation expense: The company has
excluded share-based compensation expense from its non-GAAP operating expenses and net income measurements. Although share-based compensation is a key incentive offered to the company’s employees and the
company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute to the generation of future period revenues, the company continues to evaluate its performance excluding
share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in future periods.

[0001193125-17-029153:8k_2_02:56]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its
Non-GAAP operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding
intangible assets amortization expense. Amortization of intangible assets is consistent in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible
assets contributed to the company’s revenues earned during the periods presented and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-17-029153:8k_2_02:57]
Constant Currency: The company evaluates its results of operations on both an as reported and a constant currency basis. The constant currency
presentation, which is a non-GAAP measure, excludes the impact of fluctuations in foreign currency exchange rates. The company calculates constant currency percentages by converting its current period
local currency results using prior-period exchange rates, and then comparing these adjusted values to prior period reported results.

[0001193125-17-029153:8k_2_02:58]
Details of the above
items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0001193125-17-029153:8k_2_02:59]
BUSINESS RISKS

[0001193125-17-029153:8k_2_02:60]
statements represent the company’s views only as of today and should not be relied upon as representing the company’s views as of any subsequent date. Readers are cautioned that such
forward-looking statements are subject to a variety of risks and uncertainties that could cause the company’s actual results to differ materially from the statements contained in this release. Such forward-looking statements include, but are
not limited to, Motorola Solutions’ financial outlook for the first quarter and full year of 2017 and incremental revenues of Airwave. Motorola Solutions cautions the reader that the risk factors below, as well as those on pages 9 through 22 in
Item 1A of Motorola Solutions 2015 Annual Report on Form 10-K and in its other SEC filings available for free on the SEC’s website at www.sec.gov and on Motorola Solutions’ website at
www.motorolasolutions.com, could cause Motorola Solutions’ actual results to differ materially from those estimated or predicted in the forward-looking statements. Many of these risks and uncertainties cannot be controlled by Motorola
Solutions, and factors that may impact forward-looking statements include, but are not limited to: (1) the economic outlook for the government communications industry; (2) the impact of foreign currency fluctuations on the company;
(3) the level of demand for the company’s products; (4) the company’s ability to refresh existing and introduce new products and technologies in a timely manner; (5) negative impact on the company’s business from global
economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company’s products;
(iii) increased demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company’s suppliers that may no longer have access
to necessary financing; (vi) counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company’s pension plan and other defined benefit plans, which could
impact future required or voluntary pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (6) the impact of a security breach or other significant disruption in the
company’s IT systems, those of its partners or suppliers or those it sells to or operates or maintains for its customers; (7) the outcome of ongoing and future tax matters; (8) the company’s ability to purchase sufficient
materials, parts and components to meet customer demand, particularly in light of global economic conditions and reductions in the company’s purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors,
third-party distributors and other representatives; (10) the impact on the company’s performance and financial results from strategic acquisitions or divestitures, including the acquisition of Airwave; (11) risks related to the
company’s manufacturing and business operations in foreign countries; (12) the creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems; (13) exposure under large
systems and managed services contracts, including risks related to the fact that certain customers require that the company build, own and operate their systems, often over a multi-year period; (14) the ownership of certain logos, trademarks,
trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15) variability in income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company
licenses intellectual property from others; (16) unexpected liabilities or expenses, including unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and
cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to
repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative
consequences from the company’s use of third party vendors for various activities, including certain manufacturing operations, information technology and administrative functions; (22) the impact of the sale of the company’s legacy
information systems, including components of the enterprise resource planning (ERP) system and the implementation of a new ERP system; and (23) the company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola
Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future events or otherwise.

[0001193125-17-029153:8k_2_02:61]
DEFINITIONS

[0001193125-17-029153:8k_2_02:62]
| 1 | Free cash flow represents operating cash flow less capital expenditures |

[0001193125-17-029153:8k_2_02:63]
| 2 | Q4 Non-GAAP financial information excludes the after-tax impact of approximately $0.60 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items for the fourth-quarter. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-17-029153:8k_2_02:64]
| 3 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-17-029153:8k_2_02:65]
ABOUT MOTOROLA SOLUTIONS

[0001193125-17-029153:8k_2_02:66]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build
safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-17-029153:8k_2_02:67]
MEDIA
CONTACT

[0001193125-17-029153:8k_2_02:68]
Tama McWhinney

[0001193125-17-029153:8k_2_02:69]
Motorola Solutions

[0001193125-17-029153:8k_2_02:70]
+1 847-538-1865

[0001193125-17-029153:8k_2_02:71]
tama.mcwhinney@motorolasolutions.com

[0001193125-17-029153:8k_2_02:72]
INVESTOR CONTACT

[0001193125-17-029153:8k_2_02:73]
Chris Kutsor

[0001193125-17-029153:8k_2_02:74]
Motorola Solutions

[0001193125-17-029153:8k_2_02:75]
+1 847-576-4995

[0001193125-17-029153:8k_2_02:76]
chris.kutsor@motorolasolutions.com

[0001193125-17-029153:8k_2_02:77]
MOTOROLA, MOTOROLA
SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners.
©2017 Motorola Solutions, Inc. All rights reserved.

[0001193125-17-029153:8k_2_02:78]
GAAP-1

[0001193125-17-029153:8k_2_02:79]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:80]
Consolidated Statements of Operations

[0001193125-17-029153:8k_2_02:81]
(In millions, except per share amounts)

[0001193125-17-029153:8k_2_02:82]
|  |  | Three Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Net sales from products |  | $ | 1,226 |  |  | $ | 1,125 |  |
| Net sales from services |  |  | 657 |  |  |  | 557 |  |
| Net sales |  |  | 1,883 |  |  |  | 1,682 |  |
| Costs of products sales |  |  | 525 |  |  |  | 485 |  |
| Costs of services sales |  |  | 430 |  |  |  | 359 |  |
| Costs of sales |  |  | 955 |  |  |  | 844 |  |
| Gross margin |  |  | 928 |  |  |  | 838 |  |
| Selling, general and administrative expenses |  |  | 277 |  |  |  | 252 |  |
| Research and development expenditures |  |  | 142 |  |  |  | 152 |  |
| Other charges |  |  | 76 |  |  |  | 43 |  |
| Intangibles amortization |  |  | 30 |  |  |  | 2 |  |
| Operating earnings |  |  | 403 |  |  |  | 389 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (48 | ) |  |  | (51 | ) |
| Gains on sales of investments and businesses, net |  |  | 7 |  |  |  | 47 |  |
| Other |  |  | — |  |  |  | (8 | ) |
| Total other expense |  |  | (41 | ) |  |  | (12 | ) |
| Earnings from continuing operations before income taxes |  |  | 362 |  |  |  | 377 |  |
| Income tax expense |  |  | 118 |  |  |  | 99 |  |
| Earnings from continuing operations |  |  | 244 |  |  |  | 278 |  |
| Earnings from discontinued operations, net of tax |  |  | — |  |  |  | 2 |  |
| Net earnings |  |  | 244 |  |  |  | 280 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 243 |  |  | $ | 279 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 243 |  |  | $ | 277 |  |
| Earnings from discontinued operations, net of tax |  |  | — |  |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 243 |  |  | $ | 279 |  |
| Earnings per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.47 |  |  | $ | 1.58 |  |
| Discontinued operations |  |  | — |  |  |  | 0.02 |  |
|  |  | $ | 1.47 |  |  | $ | 1.60 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.43 |  |  | $ | 1.56 |  |
| Discontinued operations |  |  | — |  |  |  | 0.01 |  |
|  |  | $ | 1.43 |  |  | $ | 1.57 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 165.4 |  |  |  | 174.9 |  |
| Diluted |  |  | 170.4 |  |  |  | 177.5 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 65.1 | % |  |  | 66.9 | % |
| Net sales from services |  |  | 34.9 | % |  |  | 33.1 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 42.8 | % |  |  | 43.1 | % |
| Costs of services sales |  |  | 65.4 | % |  |  | 64.5 | % |
| Costs of sales |  |  | 50.7 | % |  |  | 50.2 | % |
| Gross margin |  |  | 49.3 | % |  |  | 49.8 | % |
| Selling, general and administrative expenses |  |  | 14.7 | % |  |  | 15.0 | % |
| Research and development expenditures |  |  | 7.5 | % |  |  | 9.0 | % |
| Other charges |  |  | 4.0 | % |  |  | 2.6 | % |
| Intangibles amortization |  |  | 1.6 | % |  |  | 0.1 | % |
| Operating earnings |  |  | 21.4 | % |  |  | 23.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (2.5 | )% |  |  | (3.0 | )% |
| Gains on sales of investments and businesses, net |  |  | 0.4 | % |  |  | 2.8 | % |
| Other |  |  | — | % |  |  | (0.5 | )% |
| Total other expense |  |  | (2.2 | )% |  |  | (0.7 | )% |
| Earnings from continuing operations before income taxes |  |  | 19.2 | % |  |  | 22.4 | % |
| Income tax expense |  |  | 6.3 | % |  |  | 5.9 | % |
| Earnings from continuing operations |  |  | 13.0 | % |  |  | 16.5 | % |
| Earnings from discontinued operations, net of tax |  |  | — | % |  |  | 0.1 | % |
| Net earnings |  |  | 13.0 | % |  |  | 16.6 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 12.9 | % |  |  | 16.6 | % |

[0001193125-17-029153:8k_2_02:83]
| * | Percentages may not add up due to rounding |

[0001193125-17-029153:8k_2_02:84]
GAAP-2

[0001193125-17-029153:8k_2_02:85]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:86]
Consolidated Statements of Operations

[0001193125-17-029153:8k_2_02:87]
(In millions, except per share amounts)

[0001193125-17-029153:8k_2_02:88]
|  |  | Years Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Net sales from products |  | $ | 3,649 |  |  | $ | 3,676 |  |  | $ | 3,807 |  |
| Net sales from services |  |  | 2,389 |  |  |  | 2,019 |  |  |  | 2,074 |  |
| Net sales |  |  | 6,038 |  |  |  | 5,695 |  |  |  | 5,881 |  |
| Costs of products sales |  |  | 1,649 |  |  |  | 1,625 |  |  |  | 1,678 |  |
| Costs of services sales |  |  | 1,520 |  |  |  | 1,351 |  |  |  | 1,372 |  |
| Costs of sales |  |  | 3,169 |  |  |  | 2,976 |  |  |  | 3,050 |  |
| Gross margin |  |  | 2,869 |  |  |  | 2,719 |  |  |  | 2,831 |  |
| Selling, general and administrative expenses |  |  | 1,000 |  |  |  | 1,021 |  |  |  | 1,184 |  |
| Research and development expenditures |  |  | 553 |  |  |  | 620 |  |  |  | 681 |  |
| Other charges |  |  | 136 |  |  |  | 76 |  |  |  | 1,968 |  |
| Intangibles amortization |  |  | 113 |  |  |  | 8 |  |  |  | 4 |  |
| Operating earnings (loss) |  |  | 1,067 |  |  |  | 994 |  |  |  | (1,006 | ) |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (205 | ) |  |  | (173 | ) |  |  | (126 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | (6 | ) |  |  | 107 |  |  |  | 5 |  |
| Other |  |  | (12 | ) |  |  | (11 | ) |  |  | (34 | ) |
| Total other expense |  |  | (223 | ) |  |  | (77 | ) |  |  | (155 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  | 844 |  |  |  | 917 |  |  |  | (1,161 | ) |
| Income tax expense (benefit) |  |  | 282 |  |  |  | 274 |  |  |  | (465 | ) |
| Earnings (loss) from continuing operations |  |  | 562 |  |  |  | 643 |  |  |  | (696 | ) |
| Earnings (loss) from discontinued operations, net of tax |  |  | — |  |  |  | (30 | ) |  |  | 1,996 |  |
| Net earnings |  |  | 562 |  |  |  | 613 |  |  |  | 1,300 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 2 |  |  |  | 3 |  |  |  | 1 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 560 |  |  | $ | 610 |  |  | $ | 1,299 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  | $ | 560 |  |  | $ | 640 |  |  | $ | (697 | ) |
| Earnings (loss) from discontinued operations, net of tax |  |  | — |  |  |  | (30 | ) |  |  | 1,996 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 560 |  |  | $ | 610 |  |  | $ | 1,299 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 3.30 |  |  | $ | 3.21 |  |  | $ | (2.84 | ) |
| Discontinued operations |  |  | — |  |  |  | (0.15 | ) |  |  | 8.13 |  |
|  |  | $ | 3.30 |  |  | $ | 3.06 |  |  | $ | 5.29 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 3.24 |  |  | $ | 3.17 |  |  | $ | (2.84 | ) |
| Discontinued operations |  |  | — |  |  |  | (0.15 | ) |  |  | 8.13 |  |
|  |  | $ | 3.24 |  |  | $ | 3.02 |  |  | $ | 5.29 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 169.6 |  |  |  | 199.6 |  |  |  | 245.6 |  |
| Diluted |  |  | 173.1 |  |  |  | 201.8 |  |  |  | 245.6 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 60.4 | % |  |  | 64.5 | % |  |  | 64.7 | % |
| Net sales from services |  |  | 39.6 | % |  |  | 35.5 | % |  |  | 35.3 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 45.2 | % |  |  | 44.2 | % |  |  | 44.1 | % |
| Costs of services sales |  |  | 63.6 | % |  |  | 66.9 | % |  |  | 66.2 | % |
| Costs of sales |  |  | 52.5 | % |  |  | 52.3 | % |  |  | 51.9 | % |
| Gross margin |  |  | 47.5 | % |  |  | 47.7 | % |  |  | 48.1 | % |
| Selling, general and administrative expenses |  |  | 16.6 | % |  |  | 17.9 | % |  |  | 20.1 | % |
| Research and development expenditures |  |  | 9.2 | % |  |  | 10.9 | % |  |  | 11.6 | % |
| Other charges |  |  | 2.3 | % |  |  | 1.3 | % |  |  | 33.5 | % |
| Intangibles amortization |  |  | 1.9 | % |  |  | 0.1 | % |  |  | 0.1 | % |
| Operating earnings (loss) |  |  | 17.7 | % |  |  | 17.5 | % |  |  | (17.1 | )% |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.4 | )% |  |  | (3.0 | )% |  |  | (2.1 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | (0.1 | )% |  |  | 1.9 | % |  |  | 0.1 | % |
| Other |  |  | (0.2 | )% |  |  | (0.2 | )% |  |  | (0.6 | )% |
| Total other expense |  |  | (3.7 | )% |  |  | (1.4 | )% |  |  | (2.6 | )% |
| Earnings (loss) from continuing operations before income taxes |  |  | 14.0 | % |  |  | 16.1 | % |  |  | (19.7 | )% |
| Income tax expense (benefit) |  |  | 4.7 | % |  |  | 4.8 | % |  |  | (7.9 | )% |
| Earnings (loss) from continuing operations |  |  | 9.3 | % |  |  | 11.3 | % |  |  | (11.8 | )% |
| Earnings (loss) from discontinued operations, net of tax |  |  | — | % |  |  | (0.5 | )% |  |  | 33.9 | % |
| Net earnings |  |  | 9.3 | % |  |  | 10.8 | % |  |  | 22.1 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | — | % |  |  | 0.1 | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 9.3 | % |  |  | 10.7 | % |  |  | 22.1 | % |

[0001193125-17-029153:8k_2_02:89]
| * | Percentages may not add up due to rounding |

[0001193125-17-029153:8k_2_02:90]
GAAP-3

[0001193125-17-029153:8k_2_02:91]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:92]
Consolidated Balance Sheets

[0001193125-17-029153:8k_2_02:93]
(In millions)

[0001193125-17-029153:8k_2_02:94]
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,030 |  |  | $ | 1,980 |  |
| Accounts receivable, net |  |  | 1,372 |  |  |  | 1,362 |  |
| Inventories, net |  |  | 273 |  |  |  | 296 |  |
| Other current assets |  |  | 755 |  |  |  | 954 |  |
| Current assets held for disposition |  |  | — |  |  |  | 27 |  |
| Total current assets |  |  | 3,430 |  |  |  | 4,619 |  |
| Property, plant and equipment, net |  |  | 789 |  |  |  | 487 |  |
| Investments |  |  | 238 |  |  |  | 231 |  |
| Deferred income taxes |  |  | 2,219 |  |  |  | 2,278 |  |
| Goodwill |  |  | 728 |  |  |  | 420 |  |
| Other assets |  |  | 1,021 |  |  |  | 271 |  |
| Non-current assets held for disposition |  |  | — |  |  |  | 40 |  |
| Total assets |  | $ | 8,425 |  |  | $ | 8,346 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 4 |  |  | $ | 4 |  |
| Accounts payable |  |  | 553 |  |  |  | 518 |  |
| Accrued liabilities |  |  | 2,073 |  |  |  | 1,671 |  |
| Total current liabilities |  |  | 2,630 |  |  |  | 2,193 |  |
| Long-term debt |  |  | 4,392 |  |  |  | 4,345 |  |
| Other liabilities |  |  | 2,355 |  |  |  | 1,904 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (964 | ) |  |  | (106 | ) |
| Noncontrolling interests |  |  | 12 |  |  |  | 10 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,425 |  |  | $ | 8,346 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (3,366 | ) |  | $ | (2,369 | ) |

[0001193125-17-029153:8k_2_02:95]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-17-029153:8k_2_02:96]
GAAP-4

[0001193125-17-029153:8k_2_02:97]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:98]
Consolidated Statements of Cash Flows

[0001193125-17-029153:8k_2_02:99]
(In millions)

[0001193125-17-029153:8k_2_02:100]
|  |  | Three Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 243 |  |  | $ | 279 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 1 |  |
| Net earnings |  |  | 244 |  |  |  | 280 |  |
| Earnings from discontinued operations, net of tax |  |  | — |  |  |  | 2 |  |
| Earnings from continuing operations, net of tax |  |  | 244 |  |  |  | 278 |  |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 75 |  |  |  | 37 |  |
| Non-cash other charges |  |  | 11 |  |  |  | 9 |  |
| Loss on pension plan settlement |  |  | 26 |  |  |  | — |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 20 |  |
| Gains on sales of investments and businesses, net |  |  | (7 | ) |  |  | (47 | ) |
| Loss from the extinguishment of long-term debt |  |  | 2 |  |  |  | — |  |
| Deferred income taxes |  |  | 71 |  |  |  | 33 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (213 | ) |  |  | (146 | ) |
| Inventories |  |  | 6 |  |  |  | 37 |  |
| Other current assets |  |  | (81 | ) |  |  | 54 |  |
| Accounts payable and accrued liabilities |  |  | 427 |  |  |  | 179 |  |
| Other assets and liabilities |  |  | (64 | ) |  |  | (39 | ) |
| Net cash provided by operating activities from continuing operations |  |  | 513 |  |  |  | 415 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (259 | ) |  |  | (436 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 33 |  |  |  | 80 |  |
| Capital expenditures |  |  | (60 | ) |  |  | (44 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 4 |  |  |  | 1 |  |
| Net cash used for investing activities from continuing operations |  |  | (282 | ) |  |  | (399 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (683 | ) |  |  | (1 | ) |
| Net proceeds from issuance of debt |  |  | — |  |  |  | (5 | ) |
| Issuance of common stock |  |  | 14 |  |  |  | 14 |  |
| Purchase of common stock |  |  | (114 | ) |  |  | (179 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 4 |  |
| Payment of dividends |  |  | (68 | ) |  |  | (60 | ) |
| Net cash used for financing activities from continuing operations |  |  | (851 | ) |  |  | (227 | ) |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (37 | ) |  |  | (9 | ) |
| Net decrease in cash and cash equivalents |  |  | (657 | ) |  |  | (220 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,687 |  |  |  | 2,200 |  |
| Cash and cash equivalents, end of period |  | $ | 1,030 |  |  | $ | 1,980 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 453 |  |  | $ | 371 |  |

[0001193125-17-029153:8k_2_02:101]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-17-029153:8k_2_02:102]
GAAP-5

[0001193125-17-029153:8k_2_02:103]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:104]
Consolidated Statements of Cash Flows

[0001193125-17-029153:8k_2_02:105]
(In millions)

[0001193125-17-029153:8k_2_02:106]
|  |  | Years Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2014 |  |
| Operating |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 560 |  |  | $ | 610 |  |  | $ | 1,299 |  |
| Earnings attributable to noncontrolling interests |  |  | 2 |  |  |  | 3 |  |  |  | 1 |  |
| Net earnings |  |  | 562 |  |  |  | 613 |  |  |  | 1,300 |  |
| Earnings (loss) from discontinued operations, net of tax |  |  | — |  |  |  | (30 | ) |  |  | 1,996 |  |
| Earnings (loss) from continuing operations, net of tax |  |  | 562 |  |  |  | 643 |  |  |  | (696 | ) |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 295 |  |  |  | 150 |  |  |  | 173 |  |
| Non-cash other charges |  |  | 54 |  |  |  | 52 |  |  |  | — |  |
| Non-U.S. pension curtailment gain |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| Gain on sale of building and land |  |  | — |  |  |  | — |  |  |  | (21 | ) |
| Loss on pension plan settlement |  |  | 26 |  |  |  | — |  |  |  | 1,883 |  |
| Share-based compensation expense |  |  | 68 |  |  |  | 78 |  |  |  | 94 |  |
| Loss (gains) on sales of investments and businesses, net |  |  | 6 |  |  |  | (107 | ) |  |  | (5 | ) |
| Loss from the extinguishment of long-term debt |  |  | 2 |  |  |  | — |  |  |  | 37 |  |
| Deferred income taxes |  |  | 213 |  |  |  | 160 |  |  |  | (557 | ) |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 32 |  |  |  | 21 |  |  |  | (62 | ) |
| Inventories |  |  | 6 |  |  |  | 16 |  |  |  | (5 | ) |
| Other current assets |  |  | (185 | ) |  |  | 92 |  |  |  | (47 | ) |
| Accounts payable and accrued liabilities |  |  | 203 |  |  |  | 26 |  |  |  | (72 | ) |
| Other assets and liabilities |  |  | (117 | ) |  |  | (78 | ) |  |  | (1,359 | ) |
| Net cash provided by (used for) operating activities from continuing operations |  |  | 1,165 |  |  |  | 1,021 |  |  |  | (637 | ) |
| Investing |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (1,474 | ) |  |  | (586 | ) |  |  | (47 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 670 |  |  |  | 230 |  |  |  | 3,403 |  |
| Capital expenditures |  |  | (271 | ) |  |  | (175 | ) |  |  | (181 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 73 |  |  |  | 3 |  |  |  | 33 |  |
| Net cash provided by (used for) investing activities from continuing operations |  |  | (1,002 | ) |  |  | (528 | ) |  |  | 3,208 |  |
| Financing |  |  |  |  |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (686 | ) |  |  | (4 | ) |  |  | (465 | ) |
| Net proceeds from issuance of debt |  |  | 673 |  |  |  | 971 |  |  |  | 1,375 |  |
| Issuance of common stock |  |  | 93 |  |  |  | 84 |  |  |  | 87 |  |
| Purchase of common stock |  |  | (842 | ) |  |  | (3,177 | ) |  |  | (2,546 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 5 |  |  |  | 11 |  |
| Payment of dividends |  |  | (280 | ) |  |  | (277 | ) |  |  | (318 | ) |
| Distributions from discontinued operations |  |  | — |  |  |  | — |  |  |  | 93 |  |
| Net cash used for financing activities from continuing operations |  |  | (1,042 | ) |  |  | (2,398 | ) |  |  | (1,763 | ) |
| Discontinued Operations |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities from discontinued operations |  |  | — |  |  |  | — |  |  |  | 95 |  |
| Net cash provided by investing activities from discontinued operations |  |  | — |  |  |  | — |  |  |  | 4 |  |
| Net cash used for financing activities from discontinued operations |  |  | — |  |  |  | — |  |  |  | (93 | ) |
| Effect of exchange rate changes on cash and cash equivalents from discontinued operations |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| Net cash provided by discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |
| Effect of exchange rate changes on cash and cash equivalents from continuing operations |  |  | (71 | ) |  |  | (69 | ) |  |  | (79 | ) |
| Net decrease in cash and cash equivalents |  |  | (950 | ) |  |  | (1,974 | ) |  |  | 729 |  |
| Cash and cash equivalents, beginning of period |  |  | 1,980 |  |  |  | 3,954 |  |  |  | 3,225 |  |
| Cash and cash equivalents, end of period |  | $ | 1,030 |  |  | $ | 1,980 |  |  | $ | 3,954 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 894 |  |  | $ | 846 |  |  | $ | (818 | ) |

[0001193125-17-029153:8k_2_02:107]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-17-029153:8k_2_02:108]
GAAP-6

[0001193125-17-029153:8k_2_02:109]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:110]
Segment Information

[0001193125-17-029153:8k_2_02:111]
(In millions)

[0001193125-17-029153:8k_2_02:112]
Net Sales

[0001193125-17-029153:8k_2_02:113]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 1,226 |  |  | $ | 1,125 |  |  |  | 9 | % |
| Services |  |  | 657 |  |  |  | 557 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 1,883 |  |  | $ | 1,682 |  |  |  | 12 | % |

[0001193125-17-029153:8k_2_02:114]
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 3,649 |  |  | $ | 3,676 |  |  |  | (1 | )% |
| Services |  |  | 2,389 |  |  |  | 2,019 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 6,038 |  |  | $ | 5,695 |  |  |  | 6 | % |

[0001193125-17-029153:8k_2_02:115]
Operating Earnings

[0001193125-17-029153:8k_2_02:116]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 330 |  |  | $ | 291 |  |  |  | 13 | % |
| Services |  |  | 73 |  |  |  | 98 |  |  |  | (26 | )% |
| Total Motorola Solutions |  | $ | 403 |  |  | $ | 389 |  |  |  | 4 | % |

[0001193125-17-029153:8k_2_02:117]
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 734 |  |  | $ | 704 |  |  |  | 4 | % |
| Services |  |  | 333 |  |  |  | 290 |  |  |  | 15 | % |
| Total Motorola Solutions |  | $ | 1,067 |  |  | $ | 994 |  |  |  | 7 | % |

[0001193125-17-029153:8k_2_02:118]
Operating Earnings %

[0001193125-17-029153:8k_2_02:119]
|  |  | Three Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Products |  |  | 26.9 | % |  |  | 25.9 | % |
| Services |  |  | 11.1 | % |  |  | 17.6 | % |
| Total Motorola Solutions |  |  | 21.4 | % |  |  | 23.1 | % |

[0001193125-17-029153:8k_2_02:120]
|  |  | Years Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Products |  |  | 20.1 | % |  |  | 19.2 | % |
| Services |  |  | 13.9 | % |  |  | 14.4 | % |
| Total Motorola Solutions |  |  | 17.7 | % |  |  | 17.5 | % |

[0001193125-17-029153:8k_2_02:121]
Non-GAAP-1

[0001193125-17-029153:8k_2_02:122]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:123]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense, and
Highlighted Items)

[0001193125-17-029153:8k_2_02:124]
Q1 2016

[0001193125-17-029153:8k_2_02:125]
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 23 |  |  |  | 8 |  |  |  | 15 |  |  |  | 0.08 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 13 |  |  |  | 3 |  |  |  | 10 |  |  |  | 0.06 |  |
| Acquisition related transaction fees |  |  | Other charges |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |  |  | 0.07 |  |
| Loss on investment in United Kingdom treasuries |  |  | Other expense (income) |  |  |  | 19 |  |  |  | 7 |  |  |  | 12 |  |  |  | 0.07 |  |
| Realized foreign currency loss on acquisition |  |  | Other expense (income) |  |  |  | 10 |  |  |  | 3 |  |  |  | 7 |  |  |  | 0.04 |  |
| Loss on sale of Malaysia facility and operations |  |  | Other expense (income) |  |  |  | 7 |  |  |  | — |  |  |  | 7 |  |  |  | 0.04 |  |
| Total impact on Net earnings |  |  |  |  |  | $ | 102 |  |  | $ | 27 |  |  | $ | 75 |  |  | $ | 0.42 |  |
| Q2 2016 |  |
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 18 |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 27 |  |  |  | 7 |  |  |  | 20 |  |  |  | 0.12 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 38 |  |  |  | 8 |  |  |  | 30 |  |  |  | 0.17 |  |
| Building impairment |  |  | Other charges |  |  |  | 17 |  |  |  | 6 |  |  |  | 11 |  |  |  | 0.06 |  |
| Total impact on Net earnings |  |  |  |  |  | $ | 100 |  |  | $ | 27 |  |  | $ | 73 |  |  | $ | 0.42 |  |
| Q3 2016 |  |
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 12 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 7 |  |  |  | 2 |  |  |  | 5 |  |  |  | 0.03 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 31 |  |  |  | 7 |  |  |  | 24 |  |  |  | 0.14 |  |
| Total impact on Net earnings |  |  |  |  |  | $ | 55 |  |  | $ | 14 |  |  | $ | 41 |  |  | $ | 0.24 |  |
| Q4 2016 |  |
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 16 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 66 |  |  |  | 14 |  |  |  | 52 |  |  |  | 0.31 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 30 |  |  |  | 6 |  |  |  | 24 |  |  |  | 0.14 |  |
| Loss on Non-U.S. pension plan settlement |  |  | Other charges |  |  |  | 26 |  |  |  | — |  |  |  | 26 |  |  |  | 0.15 |  |
| Release of unrecognized tax benefit from audit settlement |  |  | Income Tax Expense (Benefit) |  |  |  | — |  |  |  | 10 |  |  |  | (10 | ) |  |  | (0.06 | ) |
| Total impact on Net earnings |  |  |  |  |  | $ | 138 |  |  | $ | 35 |  |  | $ | 103 |  |  |  | 0.60 |  |
| FY 2016 |  |
| Non-GAAP Adjustments |  | Statement Line |  |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  |  | Cost of sales, SG&A and R&D |  |  | $ | 68 |  |  | $ | 22 |  |  | $ | 46 |  |  | $ | 0.27 |  |
| Reorganization of business charges |  |  | Cost of sales and Other charges |  |  |  | 123 |  |  |  | 31 |  |  |  | 92 |  |  |  | 0.53 |  |
| Intangibles amortization expense |  |  | Intangibles amortization |  |  |  | 113 |  |  |  | 26 |  |  |  | 87 |  |  |  | 0.50 |  |
| Acquisition related transaction fees |  |  | Other charges |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |  |  | 0.08 |  |
| Loss on investment in United Kingdom treasuries |  |  | Other expense (income) |  |  |  | 19 |  |  |  | 7 |  |  |  | 12 |  |  |  | 0.07 |  |
| Realized foreign currency loss on acquisition |  |  | Other expense (income) |  |  |  | 10 |  |  |  | 3 |  |  |  | 7 |  |  |  | 0.04 |  |
| Loss on sale of Malaysia facility and operations |  |  | Other expense (income) |  |  |  | 7 |  |  |  | — |  |  |  | 7 |  |  |  | 0.04 |  |
| Building impairment |  |  | Other charges |  |  |  | 17 |  |  |  | 6 |  |  |  | 11 |  |  |  | 0.06 |  |
| Loss on Non-U.S. pension plan settlement |  |  | Other charges |  |  |  | 26 |  |  |  | — |  |  |  | 26 |  |  |  | 0.15 |  |
| Release of unrecognized tax benefit from audit settlement |  |  | Income Tax Expense (Benefit) |  |  |  | — |  |  |  | 10 |  |  |  | (10 | ) |  |  | (0.06 | ) |
| Total impact on Net earnings |  |  |  |  |  | $ | 396 |  |  | $ | 105 |  |  | $ | 291 |  |  | $ | 1.68 |  |

[0001193125-17-029153:8k_2_02:126]
Non-GAAP-2

[0001193125-17-029153:8k_2_02:127]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:128]
Non-GAAP Segment Information

[0001193125-17-029153:8k_2_02:129]
(In millions)

[0001193125-17-029153:8k_2_02:130]
Net Sales

[0001193125-17-029153:8k_2_02:131]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 1,226 |  |  | $ | 1,125 |  |  |  | 9 | % |
| Services |  |  | 657 |  |  |  | 557 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 1,883 |  |  | $ | 1,682 |  |  |  | 12 | % |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 3,649 |  |  | $ | 3,676 |  |  |  | (1 | )% |
| Services |  |  | 2,389 |  |  |  | 2,019 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 6,038 |  |  | $ | 5,695 |  |  |  | 6 | % |

[0001193125-17-029153:8k_2_02:132]
Non-GAAP Operating
Earnings

[0001193125-17-029153:8k_2_02:133]
|  |  | Three Months Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 407 |  |  | $ | 340 |  |  |  | 20 | % |
| Services |  |  | 134 |  |  |  | 118 |  |  |  | 14 | % |
| Total Motorola Solutions |  | $ | 541 |  |  | $ | 458 |  |  |  | 18 | % |
|  |  | Years Ended |  |  |  |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | % Change |  |
| Products |  | $ | 910 |  |  | $ | 827 |  |  |  | 10 | % |
| Services |  |  | 517 |  |  |  | 339 |  |  |  | 53 | % |
| Total Motorola Solutions |  | $ | 1,427 |  |  | $ | 1,166 |  |  |  | 22 | % |

[0001193125-17-029153:8k_2_02:134]
Non-GAAP Operating
Earnings %

[0001193125-17-029153:8k_2_02:135]
|  |  | Three Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Products |  |  | 33.2 | % |  |  | 30.2 | % |
| Services |  |  | 20.4 | % |  |  | 21.2 | % |
| Total Motorola Solutions |  |  | 28.7 | % |  |  | 27.2 | % |
|  |  | Years Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Products |  |  | 24.9 | % |  |  | 22.5 | % |
| Services |  |  | 21.6 | % |  |  | 16.8 | % |
| Total Motorola Solutions |  |  | 23.6 | % |  |  | 20.5 | % |

[0001193125-17-029153:8k_2_02:136]
Non-GAAP-3

[0001193125-17-029153:8k_2_02:137]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-17-029153:8k_2_02:138]
Operating Earnings after Non-GAAP Adjustments

[0001193125-17-029153:8k_2_02:139]
| Q1 2016 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,193 |  |  | $ | 702 |  |  | $ | 491 |  |
| Operating earnings (“OE”) |  | $ | 100 |  |  | $ | 51 |  |  | $ | 49 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 23 |  |  |  | 21 |  |  |  | 2 |  |
| Intangibles amortization expense |  |  | 13 |  |  |  | 1 |  |  |  | 12 |  |
| Acquisition related transaction fees |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Total above-OE non-GAAP adjustments |  |  | 66 |  |  |  | 33 |  |  |  | 33 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 166 |  |  | $ | 84 |  |  | $ | 82 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 8.4 | % |  |  | 7.3 | % |  |  | 10.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 13.9 | % |  |  | 12.0 | % |  |  | 16.7 | % |
| Q2 2016 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,430 |  |  | $ | 801 |  |  | $ | 629 |  |
| Operating earnings (“OE”) |  | $ | 224 |  |  | $ | 129 |  |  | $ | 95 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 18 |  |  |  | 12 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 27 |  |  |  | 21 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 38 |  |  |  | 2 |  |  |  | 36 |  |
| Building impairment |  |  | 17 |  |  |  | 12 |  |  |  | 5 |  |
| Total above-OE non-GAAP adjustments |  |  | 100 |  |  |  | 47 |  |  |  | 53 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 324 |  |  | $ | 176 |  |  | $ | 148 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 15.7 | % |  |  | 16.1 | % |  |  | 15.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 22.7 | % |  |  | 22.0 | % |  |  | 23.5 | % |
| Q3 2016 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,532 |  |  | $ | 920 |  |  | $ | 612 |  |
| Operating earnings (“OE”) |  | $ | 341 |  |  | $ | 225 |  |  | $ | 116 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 7 |  |  |  | 5 |  |  |  | 2 |  |
| Intangibles amortization expense |  |  | 31 |  |  |  | 2 |  |  |  | 29 |  |
| Total above-OE non-GAAP adjustments |  |  | 55 |  |  |  | 18 |  |  |  | 37 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 396 |  |  | $ | 243 |  |  | $ | 153 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 22.3 | % |  |  | 24.5 | % |  |  | 19.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 25.8 | % |  |  | 26.4 | % |  |  | 25.0 | % |
| Q4 2016 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,883 |  |  | $ | 1,226 |  |  | $ | 657 |  |
| Operating earnings (“OE”) |  | $ | 403 |  |  | $ | 330 |  |  | $ | 73 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 10 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 66 |  |  |  | 47 |  |  |  | 19 |  |
| Loss on Non-U.S. pension plan settlement |  |  | 26 |  |  |  | 18 |  |  |  | 8 |  |
| Intangibles amortization expense |  |  | 30 |  |  |  | 2 |  |  |  | 28 |  |
| Total above-OE non-GAAP adjustments |  |  | 138 |  |  |  | 77 |  |  |  | 61 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 541 |  |  | $ | 407 |  |  | $ | 134 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 21.4 | % |  |  | 26.9 | % |  |  | 11.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 28.7 | % |  |  | 33.2 | % |  |  | 20.4 | % |
| FY 2016 |  |
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 6,038 |  |  | $ | 3,649 |  |  | $ | 2,389 |  |
| Operating earnings (“OE”) |  | $ | 1,067 |  |  | $ | 734 |  |  | $ | 333 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 68 |  |  |  | 44 |  |  |  | 24 |  |
| Reorganization of business charges |  |  | 123 |  |  |  | 94 |  |  |  | 29 |  |
| Loss on Non-U.S. pension plan settlement |  |  | 26 |  |  |  | 18 |  |  |  | 8 |  |
| Intangibles amortization expense |  |  | 113 |  |  |  | 8 |  |  |  | 105 |  |
| Acquisition related transaction fees |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Building impairment |  |  | 17 |  |  |  | 12 |  |  |  | 5 |  |
| Total above-OE non-GAAP adjustments |  |  | 360 |  |  |  | 176 |  |  |  | 184 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 1,427 |  |  | $ | 910 |  |  | $ | 517 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 17.7 | % |  |  | 20.1 | % |  |  | 13.9 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 23.6 | % |  |  | 24.9 | % |  |  | 21.6 | % |

## item 5.02 — body, verbatim

[0001193125-17-029153:8k_body:1]
Item 5.02.

[0001193125-17-029153:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-17-029153:8k_body:3]
(d)

[0001193125-17-029153:8k_body:4]
On February 1, 2017, the Board of Directors of the
Company elected Kenneth D. Denman to the Board of Directors effective immediately. Mr. Denman will serve until the Company’s 2017 Annual Meeting and the election and qualification of his successor or, if earlier, his death or resignation
or removal from the Board of Directors.

[0001193125-17-029153:8k_body:5]
Mr. Denman will receive the standard compensation received by non-employee directors. This compensation
arrangement was described in the Company’s definitive proxy statement on Schedule 14A filed on March 28, 2016 with the U.S. Securities and Exchange Commission. As disclosed in the definitive proxy statement, a non-employee director will be
granted deferred stock units, pro-rated based on the number of months served with a value of $11,666.67 per month, divided by the closing price of Company Stock on the day of election.

[0001193125-17-029153:8k_body:6]
On February 1, 2017, the Board of Directors also appointed Mr. Denman as a member of the Governance and Nominating Committee.

[0001193125-17-029153:8k_body:7]
The press release announcing Mr. Denman’s election is attached as Exhibit 99.2 hereto.
