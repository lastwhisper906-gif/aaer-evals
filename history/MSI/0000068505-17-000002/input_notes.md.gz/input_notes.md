# MSI notes — 0000068505-17-000002


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-17-000002:notes:1]
Investments consist of the following:

[0000068505-17-000002:notes:2]
| December 31, 2016 | Cost Basis |  | Investments |
| Available-for-sale securities: |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 51 |  |  | $ | 51 |  |
| Corporate bonds | 5 |  |  | 5 |  |
|  | 56 |  |  | 56 |  |
| Other investments | 211 |  |  | 211 |  |
| Equity method investments | 17 |  |  | 17 |  |
|  | $ | 284 |  |  | $ | 284 |  |
| Less: current portion of available-for-sale securities |  |  | 46 |  |
|  |  |  | $ | 238 |  |

[0000068505-17-000002:notes:3]
The cost basis is equal to the fair value for all of the Company's investments as of December 31, 2016.

[0000068505-17-000002:notes:4]
| December 31, 2015 | Cost Basis |  | Unrealized Gains |  | Unrealized Loss |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 455 |  |  | $ | — |  |  | (11 | ) |  | 444 |  |
| Corporate bonds | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Common stock | — |  |  | 6 |  |  | — |  |  | 6 |  |
|  | 462 |  |  | 6 |  |  | (11 | ) |  | 457 |  |
| Other investments | 203 |  |  | — |  |  | — |  |  | 203 |  |
| Equity method investments | 9 |  |  | — |  |  | — |  |  | 9 |  |
|  | 674 |  |  | 6 |  |  | (11 | ) |  | 669 |  |
| Less: current portion of available-for-sale securities |  |  |  |  |  |  | 438 |  |
|  |  |  |  |  |  |  | $ | 231 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-17-000002:notes:5]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of December 31, 2016 and December 31, 2015 were as follows:

[0000068505-17-000002:notes:6]
| December 31, 2016 | Level 2 |  | Total |
| Assets: |  |  |  |
| Foreign exchange derivative contracts | $ | 9 |  |  | $ | 9 |  |
| Available-for-sale securities: |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | 51 |  |  | 51 |  |
| Corporate bonds | 5 |  |  | 5 |  |
| Liabilities: |  |  |  |
| Foreign exchange derivative contracts | $ | 32 |  |  | $ | 32 |  |

[0000068505-17-000002:notes:7]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 444 |  |  | 444 |  |
| Corporate bonds | — |  |  | 7 |  |  | 7 |  |
| Common stock and equivalents | 6 |  |  | — |  |  | 6 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest rate swap | — |  |  | 1 |  |  | 1 |  |


## msi:LongTermReceivableLoansAndLeaseTableTextBlock

[0000068505-17-000002:notes:8]
Long-term receivables consist of receivables with payment terms greater than twelve months, long-term loans and lease receivables under sales-type leases. Long-term receivables consist of the following:

[0000068505-17-000002:notes:9]
| December 31 | 2016 |  | 2015 |
| Long-term receivables | 63 |  |  | 60 |  |
| Less current portion | (14 | ) |  | (13 | ) |
| Non-current long-term receivables | $ | 49 |  |  | $ | 47 |  |


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-17-000002:notes:10]
Long-term Financing and Sales of Receivables

[0000068505-17-000002:notes:11]
Long-term Financing

[0000068505-17-000002:notes:12]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s consolidated balance sheets. The Company recognized Interest income on long-term receivables of $2 million, $2 million, and $1 million for the years ended December 31, 2016, 2015 and 2014.

[0000068505-17-000002:notes:13]
Certain purchasers of the Company's products and services may request that the Company provide long-term financing (defined as financing with a term greater than one year) in connection with the sale of products and services. These requests may include all or a portion of the purchase price of the products and services. The Company's obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third-parties totaling $125 million at December 31, 2016, compared to $112 million at December 31, 2015.

[0000068505-17-000002:notes:14]
Sales of Receivables

[0000068505-17-000002:notes:15]
From time to time, the Company sells accounts receivable and long-term receivables to third-parties under one-time arrangements. The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0000068505-17-000002:notes:16]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2016, 2015 and 2014.

[0000068505-17-000002:notes:17]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Accounts receivable sales proceeds | $ | 51 |  |  | $ | 29 |  |  | $ | 50 |  |
| Long-term receivables sales proceeds | 289 |  |  | 196 |  |  | 124 |  |
| Total proceeds from receivable sales | $ | 340 |  |  | $ | 225 |  |  | $ | 174 |  |

[0000068505-17-000002:notes:18]
At December 31, 2016, the Company had retained servicing obligations for $774 million of long-term receivables, compared to $668 million of long-term receivables at December 31, 2015.  Servicing obligations are limited to collection activities of sold accounts receivables and long-term receivables.

[0000068505-17-000002:notes:19]
Credit Quality of Financing Receivables and Allowance for Credit Losses

[0000068505-17-000002:notes:20]
An aging analysis of financing receivables at December 31, 2016 and December 31, 2015 is as follows:

[0000068505-17-000002:notes:21]
| December 31, 2016 | TotalLong-termReceivable |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 20 |  |  | $ | — |  |
| Commercial loans and leases secured | 43 |  |  | 2 |  |
| Long-term receivables, including current portion | $ | 63 |  |  | $ | 2 |  |

[0000068505-17-000002:notes:22]
| December 31, 2015 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 35 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 25 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Long-term receivables, including current portion | $ | 60 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-17-000002:notes:23]
The Company uses an internally developed credit risk rating system for establishing customer credit limits. This system is aligned with and comparable to the rating systems utilized by independent rating agencies.

[0000068505-17-000002:notes:24]
The Company’s policy for valuing the allowance for credit losses is to review all customer financing receivables for collectibility on an individual receivable basis.  For those receivables where collection risk is probable, the Company calculates the value of impairment based on the net present value of expected future cash flows from the customer.

[0000068505-17-000002:notes:25]
The Company had a total of $2 million of financing receivables over 90 days past due as of December 31, 2016 in relation to one loan. As of December 31, 2016, the Company is not accruing interest on this loan, and the past due amount is adequately reserved.


## msi:OtherChargesTableTextBlock

[0000068505-17-000002:notes:26]
Other charges (income) included in Operating earnings (loss) consist of the following:

[0000068505-17-000002:notes:27]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Other charges (income): |  |  |  |  |  |
| Intangibles amortization | $ | 113 |  |  | $ | 8 |  |  | $ | 4 |  |
| Reorganization of businesses | 77 |  |  | 71 |  |  | 64 |  |
| Legal settlement | — |  |  | — |  |  | 8 |  |
| Building impairment | 17 |  |  | 6 |  |  | — |  |
| Non-U.S. pension curtailment gain | — |  |  | (32 | ) |  | — |  |
| Settlement of pension plan | 26 |  |  | — |  |  | 1,917 |  |
| Impairment of corporate aircraft | 3 |  |  | 31 |  |  | — |  |
| Gain on sale of building and land | — |  |  | — |  |  | (21 | ) |
| Acquisition-related transaction fees | $ | 13 |  |  | $ | — |  |  | $ | — |  |
|  | $ | 249 |  |  | $ | 84 |  |  | $ | 1,972 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-17-000002:notes:28]
The following table displays the net charges incurred by segment:

[0000068505-17-000002:notes:29]
| Year ended December 31 | 2016 |
| Products | $ | 106 |  |
| Services | 34 |  |
|  | $ | 140 |  |

[0000068505-17-000002:notes:30]
| Year ended December 31 | 2014 |
| Products | $ | 48 |  |
| Services | 25 |  |
|  | $ | 73 |  |

[0000068505-17-000002:notes:31]
| Year ended December 31 | 2015 |
| Products | $ | 84 |  |
| Services | 33 |  |
|  | $ | 117 |  |


## msi:RetirementBenefitsPolicyPolicyTextBlock

[0000068505-17-000002:notes:32]
The Company records annual expenses relating to its pension benefit and postretirement plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s consolidated balance sheets using a December 31 measurement date.


## msi:SalesAndUseTaxesPolicyTextBlock

[0000068505-17-000002:notes:33]
The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes, on a net basis with such taxes excluded from revenue.


## msi:ScheduleOfAccumulatedBenefitObligationsForPlansTableTextBlock

[0000068505-17-000002:notes:34]
The accumulated benefit obligations for the plans were as follows:

[0000068505-17-000002:notes:35]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |
| December 31 | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Accumulated benefit obligation | $ | 4,644 |  |  | $ | 4,304 |  |  | $ | 1,785 |  |  | $ | 1,809 |  |


## msi:ScheduleOfCorporateRelatedExpensesAndAssetsTableTextBlock

[0000068505-17-000002:notes:36]
The following table summarizes the Company's capital expenditures and depreciation expense by segment:

[0000068505-17-000002:notes:37]
|  | Capital Expenditures |  | Depreciation Expense |
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Products | $ | 104 |  |  | $ | 76 |  |  | $ | 87 |  |  | $ | 68 |  |  | $ | 82 |  |  | $ | 94 |  |
| Services | 167 |  |  | 99 |  |  | 94 |  |  | 114 |  |  | 60 |  |  | 75 |  |
|  | $ | 271 |  |  | $ | 175 |  |  | $ | 181 |  |  | $ | 182 |  |  | $ | 142 |  |  | $ | 169 |  |


## msi:ScheduleOfDefinedBenefitPlanTargetandActualAssetAllocationTableTextBlock

[0000068505-17-000002:notes:38]
The weighted-average asset allocations by asset categories for all pension and the Postretirement Health Care Benefits plans were as follows:

[0000068505-17-000002:notes:39]
|  | All Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| December 31 | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Target Mix: |  |  |  |  |  |  |  |
| Equity securities | 33 | % |  | 37 | % |  | 37 | % |  | 36 | % |
| Fixed income securities | 46 | % |  | 45 | % |  | 43 | % |  | 42 | % |
| Cash and other investments | 21 | % |  | 18 | % |  | 20 | % |  | 22 | % |
| Actual Mix: |  |  |  |  |  |  |  |
| Equity securities | 34 | % |  | 37 | % |  | 37 | % |  | 37 | % |
| Fixed income securities | 47 | % |  | 44 | % |  | 43 | % |  | 41 | % |
| Cash and other investments | 19 | % |  | 19 | % |  | 20 | % |  | 22 | % |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-17-000002:notes:40]
Compensation expense for the Company’s share-based compensation plans was as follows:

[0000068505-17-000002:notes:41]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Share-based compensation expense included in: |  |  |  |  |  |
| Costs of sales | $ | 9 |  |  | $ | 9 |  |  | $ | 10 |  |
| Selling, general and administrative expenses | 45 |  |  | 52 |  |  | 61 |  |
| Research and development expenditures | 14 |  |  | 17 |  |  | 23 |  |
| Share-based compensation expense included in Operating earnings | 68 |  |  | 78 |  |  | 94 |  |
| Tax benefit | 21 |  |  | 24 |  |  | 30 |  |
| Share-based compensation expense, net of tax | $ | 47 |  |  | $ | 54 |  |  | $ | 64 |  |
| Decrease in basic earnings per share | $ | (0.28 | ) |  | $ | (0.25 | ) |  | $ | (0.28 | ) |
| Decrease in diluted earnings per share | $ | (0.27 | ) |  | $ | (0.25 | ) |  | $ | (0.28 | ) |
| Share-based compensation expense in discontinued operations | $ | — |  |  | $ | — |  |  | $ | 20 |  |


## msi:ScheduleOfExpectedFutureServiceBenefitPaymentsTableTextBlock

[0000068505-17-000002:notes:42]
The following benefit payments are expected to be paid:

[0000068505-17-000002:notes:43]
| Year | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| 2017 | $ | 114 |  |  | $ | 47 |  |  | $ | 8 |  |
| 2018 | 130 |  |  | 48 |  |  | 7 |  |
| 2019 | 146 |  |  | 49 |  |  | 7 |  |
| 2020 | 164 |  |  | 50 |  |  | 6 |  |
| 2021 | 188 |  |  | 51 |  |  | 6 |  |
| 2022-2026 | 1,241 |  |  | 270 |  |  | 26 |  |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-17-000002:notes:44]
Amortized intangible assets, excluding goodwill, were comprised of the following by segment:

[0000068505-17-000002:notes:45]
|  | 2016 |  | 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 178 |  |  | $ | 63 |  |  | $ | 89 |  |  | $ | 60 |  |
| Services | 805 |  |  | 99 |  |  | 22 |  |  | 2 |  |
|  | $ | 983 |  |  | $ | 162 |  |  | $ | 111 |  |  | $ | 62 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-17-000002:notes:46]
Other liabilities consist of the following:

[0000068505-17-000002:notes:47]
| December 31 | 2016 |  | 2015 |
| Defined benefit plans | $ | 1,799 |  |  | $ | 1,512 |  |
| Postretirement Health Care Benefit Plan | — |  |  | 49 |  |
| Deferred revenue | 115 |  |  | 113 |  |
| Unrecognized tax benefits | 39 |  |  | 50 |  |
| Deferred income taxes | 121 |  |  | 12 |  |
| Deferred consideration (Note 14) | 72 |  |  | — |  |
| Other | 209 |  |  | 168 |  |
|  | $ | 2,355 |  |  | $ | 1,904 |  |


## msi:ScheduleOfPensionAndPostretirementHealthCarePlanAssetsTextBlockTableTextBlock

[0000068505-17-000002:notes:48]
The fair values of the various pension and postretirement health care benefits plans’ assets by level in the fair value hierarchy as of December 31, 2016 and 2015 were as follows:

[0000068505-17-000002:notes:49]
U.S. Pension Benefit Plans

[0000068505-17-000002:notes:50]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 95 |  |  | $ | — |  |  | $ | 95 |  |
| Commingled equity funds | 1,096 |  |  | 493 |  |  | 1,589 |  |
| Government, agency and government-sponsored enterprise obligations | — |  |  | 125 |  |  | 125 |  |
| Other government bonds | — |  |  | 54 |  |  | 54 |  |
| Corporate bonds | — |  |  | 823 |  |  | 823 |  |
| Mortgage-backed bonds | — |  |  | 2 |  |  | 2 |  |
| Commingled bond funds | 261 |  |  | 58 |  |  | 319 |  |
| Commingled short-term investment funds | 183 |  |  | — |  |  | 183 |  |
| Total investment securities | $ | 1,635 |  |  | $ | 1,555 |  |  | $ | 3,190 |  |
| Cash |  |  |  |  | 5 |  |
| Fair value plan assets |  |  |  |  | $ | 3,195 |  |

[0000068505-17-000002:notes:51]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 89 |  |  | $ | — |  |  | $ | 89 |  |
| Commingled equity funds | — |  |  | 1,541 |  |  | 1,541 |  |
| Preferred stock | 2 |  |  | — |  |  | 2 |  |
| Government, agency and government-sponsored enterprise obligations | — |  |  | 120 |  |  | 120 |  |
| Other government bonds | — |  |  | 70 |  |  | 70 |  |
| Corporate bonds | — |  |  | 862 |  |  | 862 |  |
| Mortgage-backed bonds | — |  |  | 2 |  |  | 2 |  |
| Commingled short-term investment funds | — |  |  | 435 |  |  | 435 |  |
| Total investment securities | $ | 91 |  |  | $ | 3,030 |  |  | $ | 3,121 |  |
| Accrued income receivable |  |  |  |  | 9 |  |
| Fair value plan assets |  |  |  |  | $ | 3,130 |  |

[0000068505-17-000002:notes:52]
Postretirement Health Care Benefits Plan

[0000068505-17-000002:notes:53]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Commingled equity funds | 47 |  |  | 21 |  |  | 68 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 5 |  |  | 5 |  |
| Other government bonds | — |  |  | 2 |  |  | 2 |  |
| Corporate bonds | — |  |  | 35 |  |  | 35 |  |
| Commingled bond funds | 11 |  |  | 3 |  |  | 14 |  |
| Commingled short-term investment funds | 8 |  |  | — |  |  | 8 |  |
| Invested cash | — |  |  | — |  |  | — |  |
| Fair value plan assets | $ | 70 |  |  | $ | 66 |  |  | $ | 136 |  |

[0000068505-17-000002:notes:54]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Commingled equity funds | — |  |  | 71 |  |  | 71 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 5 |  |  | 5 |  |
| Other government bonds | — |  |  | 3 |  |  | 3 |  |
| Corporate bonds | — |  |  | 40 |  |  | 40 |  |
| Commingled short-term investment funds | — |  |  | 14 |  |  | 14 |  |
| Invested cash | — |  |  | 6 |  |  | 6 |  |
| Fair value plan assets | $ | 4 |  |  | $ | 139 |  |  | $ | 143 |  |

[0000068505-17-000002:notes:55]
Non-U.S. Pension Benefit Plans

[0000068505-17-000002:notes:56]
| December 31, 2016 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 161 |  |  | $ | — |  |  | $ | 161 |  |
| Commingled equity funds | 172 |  |  | 173 |  |  | 345 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 823 |  |  | 823 |  |
| Commingled bond funds | 107 |  |  | 36 |  |  | 143 |  |
| Commingled short-term investment funds | — |  |  | 1 |  |  | 1 |  |
| Total investment securities | 440 |  |  | 1,033 |  |  | 1,473 |  |
| Cash |  |  |  |  | 45 |  |
| Accrued income receivable |  |  |  |  | — |  |
| Insurance contracts |  |  |  |  | 47 |  |
| Fair value plan assets |  |  |  |  | $ | 1,565 |  |

[0000068505-17-000002:notes:57]
| December 31, 2015 | Level 1 |  | Level 2 |  | Total |
| Common stock and equivalents | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Commingled equity funds | — |  |  | 293 |  |  | 293 |  |
| Government, agency, and government-sponsored enterprise obligations | — |  |  | 811 |  |  | 811 |  |
| Commingled bond funds | — |  |  | 56 |  |  | 56 |  |
| Commingled short-term investment funds | — |  |  | 7 |  |  | 7 |  |
| Total investment securities | $ | 21 |  |  | $ | 1,167 |  |  | $ | 1,188 |  |
| Cash |  |  |  |  | 457 |  |
| Accrued income receivable |  |  |  |  | 2 |  |
| Insurance contracts |  |  |  |  | 49 |  |
| Fair value plan assets |  |  |  |  | $ | 1,696 |  |


## msi:ScheduleOfStatusOfCompanyPensionPlansTableTextBlock

[0000068505-17-000002:notes:58]
The status of the Company’s plans is as follows:

[0000068505-17-000002:notes:59]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at January 1 | $ | 4,304 |  |  | $ | 4,536 |  |  | $ | 1,815 |  |  | $ | 2,075 |  |  | $ | 192 |  |  | $ | 212 |  |
| Service cost | — |  |  | — |  |  | 11 |  |  | 12 |  |  | — |  |  | 1 |  |
| Interest cost | 182 |  |  | 193 |  |  | 55 |  |  | 66 |  |  | 4 |  |  | 8 |  |
| Plan amendments | — |  |  | — |  |  | — |  |  | 1 |  |  | (70 | ) |  | — |  |
| Settlements/curtailments | — |  |  | — |  |  | (103 | ) |  | (5 | ) |  | — |  |  | — |  |
| Actuarial loss (gain) | 256 |  |  | (319 | ) |  | 359 |  |  | (151 | ) |  | (27 | ) |  | (12 | ) |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (293 | ) |  | (118 | ) |  | — |  |  | — |  |
| Employee contributions | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | — |  |
| Expenses and tax payments | — |  |  | — |  |  | (7 | ) |  | (5 | ) |  | — |  |  | — |  |
| Benefit payments | (98 | ) |  | (106 | ) |  | (46 | ) |  | (62 | ) |  | (16 | ) |  | (17 | ) |
| Benefit obligation at December 31 | $ | 4,644 |  |  | $ | 4,304 |  |  | $ | 1,791 |  |  | $ | 1,815 |  |  | $ | 83 |  |  | $ | 192 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |
| Fair value at January 1 | $ | 3,130 |  |  | $ | 3,317 |  |  | $ | 1,696 |  |  | $ | 1,806 |  |  | $ | 143 |  |  | $ | 163 |  |
| Return on plan assets | 160 |  |  | (84 | ) |  | 309 |  |  | 33 |  |  | 6 |  |  | (6 | ) |
| Company contributions | 3 |  |  | 3 |  |  | 8 |  |  | 10 |  |  | — |  |  | — |  |
| Settlements | — |  |  | — |  |  | (103 | ) |  | — |  |  | — |  |  | — |  |
| Employee contributions | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | — |  |
| Foreign exchange valuation adjustment | — |  |  | — |  |  | (292 | ) |  | (88 | ) |  | — |  |  | — |  |
| Expenses and tax payments | — |  |  | — |  |  | (7 | ) |  | (5 | ) |  | — |  |  | — |  |
| Benefit payments | (98 | ) |  | (106 | ) |  | (46 | ) |  | (62 | ) |  | (13 | ) |  | (14 | ) |
| Fair value at December 31 | $ | 3,195 |  |  | $ | 3,130 |  |  | $ | 1,565 |  |  | $ | 1,696 |  |  | $ | 136 |  |  | $ | 143 |  |
| Funded status of the plan | $ | (1,449 | ) |  | $ | (1,174 | ) |  | $ | (226 | ) |  | $ | (119 | ) |  | $ | 53 |  |  | $ | (49 | ) |
| Unrecognized net loss | 2,054 |  |  | 1,777 |  |  | 559 |  |  | 453 |  |  | 75 |  |  | 104 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (67 | ) |  | (24 | ) |
| Prepaid pension cost | $ | 605 |  |  | $ | 603 |  |  | $ | 333 |  |  | $ | 334 |  |  | $ | 61 |  |  | $ | 31 |  |
| Components of prepaid (accrued) pension cost: |  |  |  |  |  |  |  |  |  |  |  |
| Current benefit liability | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-current benefit liability | (1,446 | ) |  | (1,174 | ) |  | (251 | ) |  | (224 | ) |  | — |  |  | (49 | ) |
| Non-current benefit asset | — |  |  | — |  |  | 25 |  |  | 105 |  |  | 53 |  |  | — |  |
| Deferred income taxes | 762 |  |  | 657 |  |  | 57 |  |  | 46 |  |  | 4 |  |  | 31 |  |
| Accumulated other comprehensive loss | 1,292 |  |  | 1,120 |  |  | 502 |  |  | 407 |  |  | 4 |  |  | 49 |  |
| Prepaid pension cost | $ | 605 |  |  | $ | 603 |  |  | $ | 333 |  |  | $ | 334 |  |  | $ | 61 |  |  | $ | 31 |  |


## msi:ScheduleOfSummaryOfOpenTaxYearsByMajorJurisdictionTableTextBlock

[0000068505-17-000002:notes:60]
A summary of open tax years by major jurisdiction is presented below:

[0000068505-17-000002:notes:61]
| Jurisdiction | Tax Years |
| United States | 2008-2016 |
| China | 2002-2016 |
| France | 2010-2016 |
| Germany | 2011-2016 |
| India | 1997-2016 |
| Israel | 2012-2016 |
| Japan | 2011-2016 |
| Malaysia | 2010-2016 |
| Singapore | 2015-2016 |
| United Kingdom | 2015-2016 |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineBenefitObligationsForPlansTableTextBlock

[0000068505-17-000002:notes:62]
Weighted average actuarial assumptions used to determine benefit obligations for the plans were as follows:

[0000068505-17-000002:notes:63]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Discount rate | 4.42 | % |  | 4.73 | % |  | 2.54 | % |  | 3.57 | % |  | 4.11 | % |  | 4.26 | % |
| Future compensation increase rate | n/a |  |  | n/a |  |  | 0.46 | % |  | 0.41 | % |  | n/a |  |  | n/a |  |


## msi:ScheduleOfWeightedAverageActuarialAssumptionsUsedToDetermineCostsForPlansTableTextBlock

[0000068505-17-000002:notes:64]
Weighted average actuarial assumptions used to determine costs for the plans at the beginning of the fiscal year were as follows:

[0000068505-17-000002:notes:65]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Discount rate | 4.27 | % |  | 4.30 | % |  | 3.22 | % |  | 3.19 | % |  | 3.14 | % |  | 3.90 | % |
| Investment return assumption | 7.00 | % |  | 7.00 | % |  | 5.90 | % |  | 5.90 | % |  | 7.00 | % |  | 7.00 | % |


## msi:ScheduleofSharebasedPaymentAwardEquityInstrumentsOtherthanEmployeeStockOptionsValuationAssumptionsTableTextBlock

[0000068505-17-000002:notes:66]
The following assumptions were used for the calculations.

[0000068505-17-000002:notes:67]
|  | 2016Performance Options |  | 2015Performance Options |  | 2016Market Stock Units |  | 2015Market Stock Units |  | 2015PCSOs |
| Expected volatility of common stock | 25.3 | % |  | 21.0 | % |  | 24.2 | % |  | 19.3 | % |  | 26.0 | % |
| Expected volatility of the S&P 500 | 19.8 | % |  | 23.3 | % |  | N/A |  |  | N/A |  |  | N/A |  |
| Risk-free interest rate | 1.7 | % |  | 1.8 | % |  | 1.1 | % |  | 1.1 | % |  | 1.5 | % |
| Dividend yield | 2.8 | % |  | 2.9 | % |  | 2.8 | % |  | 2.9 | % |  | 3.1 | % |
| Expected life (years) | 6.5 |  |  | 6.5 |  |  | N/A |  |  | N/A |  |  | 5 |  |


## msi:ShareBasedCompensationCostsPolicyTextBlock

[0000068505-17-000002:notes:68]
The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.


## msi:ValuationAndQualifyingAccountsTableTextBlock

[0000068505-17-000002:notes:69]
The following table presents the valuation and qualifying account activity for the years ended December 31, 2016, 2015, and 2014:

[0000068505-17-000002:notes:70]
|  | Balance atJanuary 1 |  | Charged toEarnings |  | Used |  | Adjustments* |  | Balance atDecember 31 |
| 2016 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 28 |  |  | $ | 44 |  |  | $ | (26 | ) |  | $ | (2 | ) |  | $ | 44 |  |
| Inventory reserves | 142 |  |  | 20 |  |  | (33 | ) |  | 2 |  |  | 131 |  |
| 2015 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 35 |  |  | 9 |  |  | (17 | ) |  | 1 |  |  | 28 |  |
| Inventory reserves | 131 |  |  | 24 |  |  | (13 | ) |  | — |  |  | 142 |  |
| 2014 |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 53 |  |  | 19 |  |  | (35 | ) |  | (2 | ) |  | 35 |  |
| Inventory reserves | 125 |  |  | 24 |  |  | (15 | ) |  | (3 | ) |  | 131 |  |

[0000068505-17-000002:notes:71]
* Adjustments include translation adjustments


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-17-000002:notes:72]
Other Financial Data

[0000068505-17-000002:notes:73]
Statement of Operations Information

[0000068505-17-000002:notes:74]
Other Charges (Income)

[0000068505-17-000002:notes:75]
Other Income (Expense)

[0000068505-17-000002:notes:76]
Interest expense, net, and Other both included in Other income (expense) consist of the following:

[0000068505-17-000002:notes:77]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Interest expense, net: |  |  |  |  |  |
| Interest expense | $ | (225 | ) |  | $ | (186 | ) |  | $ | (147 | ) |
| Interest income | 20 |  |  | 13 |  |  | 21 |  |
|  | $ | (205 | ) |  | $ | (173 | ) |  | $ | (126 | ) |
| Other: |  |  |  |  |  |
| Loss from the extinguishment of long-term debt | $ | (2 | ) |  | $ | — |  |  | $ | (37 | ) |
| Investment impairments | (4 | ) |  | (6 | ) |  | — |  |
| Foreign currency gain (loss) | 46 |  |  | (23 | ) |  | (3 | ) |
| Gain (loss) on derivative instruments | (56 | ) |  | 7 |  |  | (4 | ) |
| Gains on equity method investments | 5 |  |  | 6 |  |  | 16 |  |
| Realized foreign currency loss on acquisition | (10 | ) |  | — |  |  | — |  |
| Other | 9 |  |  | 5 |  |  | (6 | ) |
|  | $ | (12 | ) |  | $ | (11 | ) |  | $ | (34 | ) |

[0000068505-17-000002:notes:78]
Earnings Per Common Share

[0000068505-17-000002:notes:79]
Basic and diluted earnings per common share from both continuing operations and net earnings attributable to Motorola Solutions, Inc. is computed as follows:

[0000068505-17-000002:notes:80]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings (loss) from Continuing Operations |  | Net Earnings |
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Basic earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | 560 |  |  | $ | 640 |  |  | $ | (697 | ) |  | $ | 560 |  |  | $ | 610 |  |  | $ | 1,299 |  |
| Weighted average common shares outstanding | 169.6 |  |  | 199.6 |  |  | 245.6 |  |  | 169.6 |  |  | 199.6 |  |  | 245.6 |  |
| Per share amount | $ | 3.30 |  |  | $ | 3.21 |  |  | $ | (2.84 | ) |  | $ | 3.30 |  |  | $ | 3.06 |  |  | $ | 5.29 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) | $ | 560 |  |  | $ | 640 |  |  | $ | (697 | ) |  | $ | 560 |  |  | $ | 610 |  |  | $ | 1,299 |  |
| Weighted average common shares outstanding | 169.6 |  |  | 199.6 |  |  | 245.6 |  |  | 169.6 |  |  | 199.6 |  |  | 245.6 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based awards | 2.7 |  |  | 2.1 |  |  | — |  |  | 2.7 |  |  | 2.1 |  |  | — |  |
| Senior Convertible Notes | 0.8 |  |  | 0.1 |  |  | — |  |  | 0.8 |  |  | 0.1 |  |  | — |  |
| Diluted weighted average common shares outstanding | 173.1 |  |  | 201.8 |  |  | 245.6 |  |  | 173.1 |  |  | 201.8 |  |  | 245.6 |  |
| Per share amount | $ | 3.24 |  |  | $ | 3.17 |  |  | $ | (2.84 | ) |  | $ | 3.24 |  |  | $ | 3.02 |  |  | $ | 5.29 |  |

[0000068505-17-000002:notes:81]
In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2016, the assumed exercise of 2.8 million options and the assumed vesting of 0.3 million RSUs were excluded because their inclusion would have been antidilutive. In the computation of diluted earnings per common share from continuing operations and on a net earnings basis for the year ended December 31, 2015, the assumed exercise of 2.7 million stock options and the assumed vesting of 0.3 million RSUs were excluded because their inclusion would have been antidilutive. For the year ended December 31, 2014, the Company recorded a net loss from continuing operations and, accordingly, the basic and diluted weighted average shares outstanding are equal because any increase to the basic shares would be antidilutive, including the assumed exercise of 6.3 million stock options and the assumed vesting of 1.1 million RSUs.

[0000068505-17-000002:notes:82]
On August 25, 2015, the Company issued $1.0 billion of 2% Senior Convertible Notes (the "Senior Convertible Notes") which mature in September 2020. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). See discussion in Note 4. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-17-000002:notes:83]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the year ended December 31, 2016, the dilutive impact of the Senior Convertible Notes was 0.8 million shares and 0.1 million for December 31, 2015.

[0000068505-17-000002:notes:84]
Balance Sheet Information

[0000068505-17-000002:notes:85]
Cash and Cash Equivalents

[0000068505-17-000002:notes:86]
The Company’s cash and cash equivalents were $1.0 billion at December 31, 2016 and $2.0 billion at December 31, 2015. Of these amounts, $63 million was restricted at both December 31, 2016 and December 31, 2015.

[0000068505-17-000002:notes:87]
Accounts Receivable, Net

[0000068505-17-000002:notes:88]
Accounts receivable, net, consist of the following:

[0000068505-17-000002:notes:89]
| December 31 | 2016 |  | 2015 |
| Accounts receivable | $ | 1,454 |  |  | $ | 1,390 |  |
| Less allowance for doubtful accounts | (44 | ) |  | (28 | ) |
|  | $ | 1,410 |  |  | $ | 1,362 |  |

[0000068505-17-000002:notes:90]
Inventories, Net

[0000068505-17-000002:notes:91]
Inventories, net, consist of the following:

[0000068505-17-000002:notes:92]
| December 31 | 2016 |  | 2015 |
| Finished goods | $ | 151 |  |  | $ | 151 |  |
| Work-in-process and production materials | 253 |  |  | 287 |  |
|  | 404 |  |  | 438 |  |
| Less inventory reserves | (131 | ) |  | (142 | ) |
|  | $ | 273 |  |  | $ | 296 |  |

[0000068505-17-000002:notes:93]
Other Current Assets

[0000068505-17-000002:notes:94]
Other current assets consist of the following:

[0000068505-17-000002:notes:95]
| December 31 | 2016 |  | 2015 |
| Available-for-sale securities | $ | 46 |  |  | $ | 438 |  |
| Costs and earnings in excess of billings | 495 |  |  | 374 |  |
| Tax-related refunds receivable | 90 |  |  | 44 |  |
| Other | 124 |  |  | 98 |  |
|  | $ | 755 |  |  | $ | 954 |  |

[0000068505-17-000002:notes:96]
Property, Plant and Equipment, Net

[0000068505-17-000002:notes:97]
Property, plant and equipment, net, consist of the following:

[0000068505-17-000002:notes:98]
| December 31 | 2016 |  | 2015 |
| Land | $ | 12 |  |  | $ | 17 |  |
| Building | 306 |  |  | 523 |  |
| Machinery and equipment | 1,921 |  |  | 1,585 |  |
|  | 2,239 |  |  | 2,125 |  |
| Less accumulated depreciation | (1,450 | ) |  | (1,638 | ) |
|  | $ | 789 |  |  | $ | 487 |  |

[0000068505-17-000002:notes:99]
Depreciation expense for the years ended December 31, 2016, 2015, and 2014 was $182 million, $142 million and $169 million, respectively.

[0000068505-17-000002:notes:100]
During the year ended December 31, 2015, the Company entered into an arrangement to sell its Penang, Malaysia manufacturing operations, including the land, building, equipment, inventory, and the transfer of employees to a contract manufacturer. The Company recognized an impairment loss of $6 million on the building within Other charges in its consolidated statements of operations and presented the assets as held for sale in its consolidated balance sheets as of December 31, 2015. The sale of the Penang, Malaysia facility and manufacturing operations was completed on February 1, 2016.  During the year ended December 31, 2016, the Company incurred a loss of $7 million on the sale of its Penang, Malaysia facility and manufacturing operations, which is included within Gains (losses) on sales of investments and businesses, net.

[0000068505-17-000002:notes:101]
During the year ended December 31, 2015, the Company entered into an agreement to broker the sale of its corporate aircraft. The Company recognized an impairment loss of $31 million within Other charges based on the indicated market value of the aircraft and presented the aircraft as held for sale in its consolidated balance sheets as of December 31, 2015. During the year ended December 31, 2016, the sale of the corporate aircraft was completed.

[0000068505-17-000002:notes:102]
The Company acquired property, plant and equipment, including network-related assets, with a fair value of $245 million in the acquisition of GDCL on February 19, 2016. See discussion in Note 14.

[0000068505-17-000002:notes:103]
During the year ended December 31, 2016, Motorola Solutions relocated its global headquarters from Schaumburg, Illinois to Chicago, Illinois.  The Company sold the remaining buildings and land on its Schaumburg, IL campus, and will continue optimize the Schaumburg campus for current space requirements. A building impairment loss of $17 million has been recognized in Other charges during the year ended December 31, 2016 related to the excess carrying value of the long-lived assets in relation to the selling price.

[0000068505-17-000002:notes:104]
Investments

[0000068505-17-000002:notes:105]
In December 2015, the Company invested $401 million in United Kingdom treasury securities in order to partially offset the risk associated with fluctuations in the British Pound Sterling in the period before the closing of the purchase of GDCL. The investments were recorded within Other current assets in the Company's consolidated balance sheets. The Company liquidated these investments in February 2016 to partially fund the acquisition of GDCL. During the year ended December 31, 2016, the Company realized a loss of $19 million associated with the sale of the treasury securities, of which, $11 million was unrealized as of December 31, 2015.

[0000068505-17-000002:notes:106]
The Company recognized losses on the sale of investments and businesses of $6 million for the year ended December 31, 2016 compared to gains on the sale of investments and business of $107 million and $5 million for the years ended December 31, 2015 and 2014. During the years ended December 31, 2016 and 2015, the Company recorded investment impairment charges of $4 million and $6 million, respectively, representing other-than-temporary declines in the value of the Company’s equity investment portfolio. There were no investment impairments recorded during the year ended December 31, 2014. Investment impairment charges are included in Other within Other income (expense) in the Company’s consolidated statements of operations.

[0000068505-17-000002:notes:107]
Other Assets

[0000068505-17-000002:notes:108]
Other assets consist of the following:

[0000068505-17-000002:notes:109]
| December 31 | 2016 |  | 2015 |
| Intangible assets, net (Note 14) | $ | 821 |  |  | $ | 49 |  |
| Non-current long-term receivables | 49 |  |  | 47 |  |
| Defined benefit plan assets | 102 |  |  | 128 |  |
| Other | 49 |  |  | 47 |  |
|  | $ | 1,021 |  |  | $ | 271 |  |

[0000068505-17-000002:notes:110]
Accrued Liabilities

[0000068505-17-000002:notes:111]
Accrued liabilities consist of the following:

[0000068505-17-000002:notes:112]
| December 31 | 2016 |  | 2015 |
| Deferred revenue | $ | 439 |  |  | $ | 390 |  |
| Compensation | 250 |  |  | 241 |  |
| Billings in excess of costs and earnings | 434 |  |  | 337 |  |
| Tax liabilities | 111 |  |  | 48 |  |
| Dividend payable | 77 |  |  | 71 |  |
| Trade liabilities | 180 |  |  | 135 |  |
| Other | 620 |  |  | 449 |  |
|  | $ | 2,111 |  |  | $ | 1,671 |  |

[0000068505-17-000002:notes:113]
Other Liabilities

[0000068505-17-000002:notes:114]
Stockholders’ Equity Information

[0000068505-17-000002:notes:115]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, November 3, 2014, and August 3, 2016, the Board of Directors has authorized the Company to repurchase in the aggregate up to $14.0 billion of its outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date.  As of December 31, 2016, the Company had used approximately $11.8 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $2.2 billion of authority available for future repurchases.

[0000068505-17-000002:notes:116]
During 2016, the Company paid an aggregate of $842 million, including transaction costs, to repurchase 12.0 million shares at an average price of $70.28 per share. During 2015, the Company paid an aggregate of $3.2 billion, including transaction costs, to repurchase 48.0 million shares at an average price of $66.22. Shares repurchased in 2015 include 30.1 million shares repurchased under a modified "Dutch auction" tender offer at a tender price of $66.50 for an aggregate of $2.0 billion, including transaction costs. During 2014, the Company paid an aggregate of $2.5 billion, including transaction costs, to repurchase 39.4 million shares at an average price of $64.63.

[0000068505-17-000002:notes:117]
Payment of Dividends:  On November 3, 2016, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.41 per share to $0.47 per share of common stock.  During the years ended December 31, 2016, 2015, and 2014 the Company paid $280 million, $277 million, and $318 million, respectively, in cash dividends to holders of its common stock.

[0000068505-17-000002:notes:118]
Accumulated Other Comprehensive Loss

[0000068505-17-000002:notes:119]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the consolidated statements of operations during the years ended December 31, 2016, 2015, and 2014:

[0000068505-17-000002:notes:120]
|  | Years ended December 31 |
|  | 2016 |  | 2015 |  | 2014 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |
| Balance at beginning of period | $ | (266 | ) |  | $ | (204 | ) |  | $ | (96 | ) |
| Other comprehensive loss before reclassification adjustment | (227 | ) |  | (82 | ) |  | (58 | ) |
| Tax benefit (expense) | (1 | ) |  | 20 |  |  | 9 |  |
| Other comprehensive income before reclassification adjustment, net of tax | (228 | ) |  | (62 | ) |  | (49 | ) |
| Reclassification adjustment into Earnings from discontinued operations | — |  |  | — |  |  | (75 | ) |
| Tax expense | — |  |  | — |  |  | 16 |  |
| Reclassification adjustment into Earnings from discontinued operations, net of tax | — |  |  | — |  |  | (59 | ) |
| Other comprehensive loss, net of tax | (228 | ) |  | (62 | ) |  | (108 | ) |
| Balance at end of period | $ | (494 | ) |  | $ | (266 | ) |  | $ | (204 | ) |
| Derivative instruments: |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
| Reclassification adjustment into Cost of sales | — |  |  | — |  |  | 1 |  |
| Reclassification adjustment into Cost of sales, net of tax | — |  |  | — |  |  | 1 |  |
| Other comprehensive income, net of tax | — |  |  | — |  |  | 1 |  |
| Balance at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |
| Available-for-Sale Securities: |  |  |  |  |  |
| Balance at beginning of period | $ | (3 | ) |  | $ | 44 |  |  | $ | (2 | ) |
| Other comprehensive income before reclassification adjustment | — |  |  | (15 | ) |  | 72 |  |
| Tax benefit (expense) | — |  |  | 5 |  |  | (26 | ) |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | — |  |  | (10 | ) |  | 46 |  |
| Reclassification adjustment into Losses (Gains) on sales of investments and businesses | 5 |  |  | (61 | ) |  | — |  |
| Tax expense (benefit) | (2 | ) |  | 24 |  |  | — |  |
| Reclassification adjustment into Earnings from continuing operations, net of tax | 3 |  |  | (37 | ) |  | — |  |
| Other comprehensive income, net of tax | 3 |  |  | (47 | ) |  | 46 |  |
| Balance at end of period | $ | — |  |  | $ | (3 | ) |  | $ | 44 |  |
| Defined Benefit Plans: |  |  |  |  |  |
| Balance at beginning of period | $ | (1,597 | ) |  | $ | (1,695 | ) |  | $ | (2,188 | ) |
| Other comprehensive income (loss) before reclassification adjustment | (368 | ) |  | 108 |  |  | (1,165 | ) |
| Tax benefit | 98 |  |  | 12 |  |  | 447 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | (270 | ) |  | 120 |  |  | (718 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 53 |  |  | 71 |  |  | 118 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (27 | ) |  | (62 | ) |  | (57 | ) |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Other charges | — |  |  | (32 | ) |  | — |  |
| Reclassification adjustment - Pension settlement loss into Other charges | 26 |  |  | — |  |  | 1,883 |  |
| Disposition of the Enterprise business retirement benefits into Earnings from discontinued operations, net of tax | — |  |  | — |  |  | (1 | ) |
| Tax expense (benefit) | (8 | ) |  | 1 |  |  | (732 | ) |
| Reclassification adjustment into Net earnings | 44 |  |  | (22 | ) |  | 1,211 |  |
| Other comprehensive income (loss), net of tax | (226 | ) |  | 98 |  |  | 493 |  |
| Balance at end of period | $ | (1,823 | ) |  | $ | (1,597 | ) |  | $ | (1,695 | ) |
| Total Accumulated other comprehensive loss | $ | (2,317 | ) |  | $ | (1,866 | ) |  | $ | (1,855 | ) |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000068505-17-000002:notes:121]
The following table presents the unaudited pro forma combined results of operations of the Company and GDCL for the years ended December 31, 2016 and December 31, 2015 as if the acquisition of GDCL had occurred on January 1, 2016 and January 1, 2015, respectively, (in millions, except per share amounts):

[0000068505-17-000002:notes:122]
| Years ended December 31 | 2016 |  | 2015 |
| Revenues | $ | 6,109 |  |  | $ | 6,239 |  |
| Earnings from continuing operations | 586 |  |  | (166 | ) |
| Basic earnings per share from continuing operations | 3.46 |  |  | (0.83 | ) |
| Diluted earnings per share from continuing operations | 3.39 |  |  | (0.82 | ) |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000068505-17-000002:notes:123]
The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-17-000002:notes:124]
Commitments and Contingencies

[0000068505-17-000002:notes:125]
Lease Obligations

[0000068505-17-000002:notes:126]
The Company leases certain office, factory and warehouse space, land, and information technology and other equipment under principally non-cancelable operating leases. Rental expense, net of sublease income, for the years ended December 31, 2016, 2015 and 2014 was $84 million, $42 million, and $62 million, respectively.

[0000068505-17-000002:notes:127]
At December 31, 2016, future minimum lease obligations, net of minimum sublease rentals, for the next five years and beyond are as follows:

[0000068505-17-000002:notes:128]
| (in millions) | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Beyond |  |
|  | $ | 62 |  | $ | 58 |  | $ | 52 |  | $ | 49 |  | $ | 42 |  | $ | 218 |  |

[0000068505-17-000002:notes:129]
Purchase Obligations

[0000068505-17-000002:notes:130]
During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. As of December 31, 2016, the Company had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2017. The Company expects to make total payments of $169 million under these arrangements as follows: $125 million in 2017, $30 million in 2018, $9 million in 2019, $4 million in 2020, and $1 million in 2021.

[0000068505-17-000002:notes:131]
The Company outsources certain corporate functions, such as benefit administration and information technology related services, under various contracts, the longest of which is expected to expire in 2019. The remaining payments under these contracts are approximately $237 million over the remaining life of the contracts. However, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. The Company would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-17-000002:notes:132]
Legal Matters

[0000068505-17-000002:notes:133]
The Company is a defendant in various lawsuits, claims, and actions that arise in the normal course of business. While the outcome of these matters is currently not determinable, the Company does not expect the ultimate disposition of these matters to have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-17-000002:notes:134]
Indemnifications

[0000068505-17-000002:notes:135]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims.  In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-17-000002:notes:136]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at December 31, 2016.

[0000068505-17-000002:notes:137]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements.  Historically, the Company has not made significant payments under these agreements.


## us-gaap:ConsolidationPolicyTextBlock

[0000068505-17-000002:notes:138]
The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-17-000002:notes:139]
The consolidated financial statements as of December 31, 2016 and 2015 and for the years ended December 31, 2016, 2015 and 2014, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company's consolidated financial position, results of operations, statements of comprehensive income, and statements of stockholders' equity and cash flows for all periods presented.


## us-gaap:DebtDisclosureTextBlock

[0000068505-17-000002:notes:140]
Debt and Credit Facilities

[0000068505-17-000002:notes:141]
Long-Term Debt

[0000068505-17-000002:notes:142]
| December 31 | 2016 |  | 2015 |
| 2.0% Senior Convertible Notes due 2020 | $ | 988 |  |  | $ | 969 |  |
| 3.5% senior notes due 2021 | 395 |  |  | 394 |  |
| 3.75% senior notes due 2022 | 746 |  |  | 745 |  |
| 3.5% senior notes due 2023 | 593 |  |  | 592 |  |
| 4.0% senior notes due 2024 | 588 |  |  | 587 |  |
| 6.5% debentures due 2025 | 117 |  |  | 118 |  |
| 7.5% debentures due 2025 | 345 |  |  | 345 |  |
| 6.5% debentures due 2028 | 36 |  |  | 36 |  |
| 6.625% senior notes due 2037 | 54 |  |  | 54 |  |
| 5.5% senior notes due 2044 | 396 |  |  | 396 |  |
| 5.22% debentures due 2097 | 91 |  |  | 90 |  |
| Other long-term debt | 52 |  |  | 29 |  |
|  | 4,401 |  |  | 4,355 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (5 | ) |  | (6 | ) |
| Less: current portion | (4 | ) |  | (4 | ) |
| Long-term debt | $ | 4,392 |  |  | $ | 4,345 |  |

[0000068505-17-000002:notes:143]
On August 25, 2015, the Company entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances including, for example, if the volume weighted average price of the Company's stock exceeds $85 for ten consecutive trading days, then up to 20% of the notes may be transferred or converted to shares of Company stock. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). The value by which the Senior Convertible Notes exceeded their principal amount if converted as of December 31, 2016 was $202 million. In the event of conversion, the Company intends to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-17-000002:notes:144]
The Company recorded a long-term debt liability associated with the Senior Convertible Notes by determining the fair value of an equivalent debt instrument without a conversion option. Using a discount rate of 2.4%, which was determined based on a review of relevant market data, the Company has calculated the debt liability to be $992 million, indicating an $8 million discount to be amortized over the expected life of the debt instrument. As of December 31, 2016, the remaining unamortized debt discount was $3 million, which will be amortized over one year as a component of interest expense compared to $7 million as of December 31, 2015. For the year ended December 31, 2016, total interest expense relating to both the contractual interest coupon and amortization of the debt discount was $24 million, compared to $8 million for the year December 31, 2015. The total of proceeds received in excess of the fair value of the debt liability of $8 million has been recorded within Additional paid-in capital.

[0000068505-17-000002:notes:145]
Aggregate requirements for long-term debt maturities during the next five years are as follows: 2017—$4 million; 2018—$5 million; 2019—$5 million; 2020—$1 billion; and 2021—$400 million.

[0000068505-17-000002:notes:146]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a term loan (the “Term Loan”) with an initial principal amount of $675 million. Interest on the Term Loan is variable and indexed to LIBOR. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed.  The Company has repaid all amounts borrowed under the Term Loan as of December 31, 2016.

[0000068505-17-000002:notes:147]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, the Company has revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of December 31, 2016 and December 31, 2015, $25 million and $41 million, respectively, have been presented as a component of long-term debt.

[0000068505-17-000002:notes:148]
Credit Facilities

[0000068505-17-000002:notes:149]
As of December 31, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of December 31, 2016. The Company did not borrow under the 2014 Motorola Solutions Credit Agreement during the twelve months ended December 31, 2016.  No letters of credit were issued under the revolving credit facility as of December 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-17-000002:notes:150]
Risk Management

[0000068505-17-000002:notes:151]
Foreign Currency Risk

[0000068505-17-000002:notes:152]
The Company uses financial instruments to reduce its overall exposure to the effects of currency fluctuations on cash flows. The Company’s policy prohibits speculation in financial instruments for profit on exchange rate fluctuations, trading in currencies for which there are no underlying exposures, or entering into transactions for any currency to intentionally increase the underlying exposure. Instruments that are designated as part of a hedging relationship must be effective at reducing the risk associated with the exposure being hedged and are designated as part of a hedging relationship at the inception of the contract. Accordingly, changes in the market values of hedge instruments must be highly correlated with changes in market values of the underlying hedged items both at the inception of the hedge and over the life of the hedge contract.

[0000068505-17-000002:notes:153]
The Company’s strategy related to foreign exchange exposure management is to offset the gains or losses on the financial instruments against gains or losses on the underlying operational cash flows or investments based on the Company's assessment of risk. The Company enters into derivative contracts for some of its non-functional currency cash, receivables, and payables, which are primarily denominated in major currencies that can be traded on open markets. The Company typically uses forward contracts and options to hedge these currency exposures. In addition, the Company has entered into derivative contracts for some forecasted transactions, which are designated as part of a hedging relationship if it is determined that the transaction qualifies for hedge accounting under the provisions of the authoritative accounting guidance for derivative instruments and hedging activities. A portion of the Company’s exposure is from currencies that are not traded in liquid markets and these are addressed, to the extent reasonably possible, by managing net asset positions, product pricing and component sourcing.

[0000068505-17-000002:notes:154]
At December 31, 2016, the Company had outstanding foreign exchange contracts with notional amounts totaling $717 million, compared to $494 million outstanding at December 31, 2015. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-17-000002:notes:155]
The following table shows the Company's five largest net notional amounts of the positions to buy or sell foreign currency as of December 31, 2016 and the corresponding positions as of December 31, 2015:

[0000068505-17-000002:notes:156]
|  | Notional Amount |
| Net Buy (Sell) by Currency | 2016 |  | 2015 |
| British Pound | $ | 246 |  |  | $ | 62 |  |
| Euro | 122 |  |  | 99 |  |
| Chinese Renminbi | (108 | ) |  | (114 | ) |
| Brazilian Real | (56 | ) |  | (44 | ) |
| Australian Dollar | (51 | ) |  | (60 | ) |

[0000068505-17-000002:notes:157]
Interest Rate Risk

[0000068505-17-000002:notes:158]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, the changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s consolidated statements of operations. The fair value of the interest rate swaps liability was de minimus at December 31, 2016 and a liability position of $1 million at December 31, 2015.

[0000068505-17-000002:notes:159]
Counterparty Risk

[0000068505-17-000002:notes:160]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of December 31, 2016, all of the counterparties have investment grade credit ratings. As of December 31, 2016, the net aggregate credit risk with all counterparties was approximately $9 million.

[0000068505-17-000002:notes:161]
Derivative Financial Instruments

[0000068505-17-000002:notes:162]
The following tables summarize the fair values and location in the consolidated balance sheets of all derivative financial instruments held by the Company at December 31, 2016 and 2015:

[0000068505-17-000002:notes:163]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2016 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 9 |  |  | Other assets |  | $ | 32 |  |  | Accrued liabilities |
| Total derivatives | $ | 9 |  |  |  |  | $ | 32 |  |  |  |

[0000068505-17-000002:notes:164]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 6 |  |  | Other assets |  | $ | 2 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | 6 |  |  |  |  | $ | 3 |  |  |  |

[0000068505-17-000002:notes:165]
The following table summarizes the effect of derivative instruments in the Company's consolidated statements of operations, including immaterial amounts related to discontinued operations, for the years ended December 31, 2016, 2015 and 2014:

[0000068505-17-000002:notes:166]
|  | December 31 | Statement ofOperations Location |
| Gain (Loss) on Derivative Instruments | 2016 |  | 2015 |  | 2014 |
| Interest rate swap | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  | Other income (expense) |
| Foreign exchange contracts | (57 | ) |  | 6 |  |  | (5 | ) | Other income (expense) |
| Total derivatives | $ | (56 | ) |  | $ | 7 |  |  | $ | (4 | ) |  |

[0000068505-17-000002:notes:167]
The Company had no instruments designated as hedging instruments for the year ended December 31, 2016.


## us-gaap:DerivativesPolicyTextBlock

[0000068505-17-000002:notes:168]
Gains and losses on hedges of existing assets or liabilities are marked-to-market and the result is included in Other within Other income (expense) within the Company’s consolidated statements of operations. Certain financial instruments are used to hedge firm future commitments or forecasted transactions.  Gains and losses pertaining to those instruments that qualify for hedge accounting are deferred until such time as the underlying transactions are recognized and subsequently recognized in the same line within the consolidated statements of operations as the hedged item. Gains and losses pertaining to those instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the consolidated statements of operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-17-000002:notes:169]
Share-Based Compensation Plans and Other Incentive Plans

[0000068505-17-000002:notes:170]
The Company grants options and stock appreciation rights to acquire shares of common stock to certain employees, including executives, and to existing option holders of acquired companies in connection with the merging of option plans following an acquisition. Each option granted and stock appreciation right has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of five to ten years and vest over two to three years. Stock options and stock appreciation rights assumed or replaced with comparable stock options or stock appreciation rights in conjunction with a change in control of the Company only become exercisable if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-17-000002:notes:171]
Restricted stock (“RS”) and restricted stock unit (“RSU”) grants consist of shares or the rights to shares of the Company’s common stock which are awarded to employees, including executives, and non-employee directors. The grants are restricted such that they are subject to substantial risk of forfeiture and to restrictions on their sale or other transfer by the employee. Shares of RS and RSUs assumed or replaced with comparable shares of RS or RSUs in conjunction with a change in control will only have the restrictions lapse if the holder is also involuntarily terminated (for a reason other than cause) or resigns for good reason within 24 months of a change in control.

[0000068505-17-000002:notes:172]
Performance-based stock options (“performance options”) and market stock units ("MSUs") have been granted to the Company’s executive officers. Performance options have a three year performance period and are granted as a target number of units subject to adjustment based on company performance. Each performance option granted has an exercise price of no less than 100% of the fair market value of the common stock on the date of the grant. The awards have a contractual life of ten years. Shares ultimately issued for performance option awards granted are based on the actual total shareholder return (“TSR”) compared to the S&P 500 over the three year performance period based on a payout factor that corresponds to actual TSR results as established at the date of grant. Vesting occurs on the third anniversary of the grant date. Under the terms of the MSUs, vesting is conditioned upon continuous employment until the vesting date and the payout factor is at least 60% of the share price on the award date. The payout factor is the share price on vesting date divided by share price on award date, with a maximum of 200%. The share price used in the payout factor is calculated using an average of the closing prices on the grant or vesting date, and the 30 calendar days immediately preceding the grant or vesting date. Vesting occurs ratably over three years.

[0000068505-17-000002:notes:173]
On August 24, 2015, in conjunction with the issuance of the Senior Convertible Notes, the Company approved a grant of performance-contingent stock options (“PCSOs”) to certain executive officers. The total number of PCSOs granted is designed to represent approximately 1% of the fully-diluted equity of the Company. The PCSOs vest upon satisfaction of the following stock price hurdles which must be maintained for 10-consecutive trading days during the three-year period following the grant date: 20% of the total award will vest at an $85 stock price; an additional 30% of the total award will vest at a $102.50 stock price; and the final 50% of the total award will vest at a $120 stock price. If any stock price hurdles are not met during the three-year period, the corresponding portion of the options will not vest and will be forfeited. The awards have a seven-year term and a per share exercise price of $68.50.

[0000068505-17-000002:notes:174]
The employee stock purchase plan allows eligible participants to purchase shares of the Company’s common stock through payroll deductions of up to 20% of eligible compensation on an after-tax basis. Plan participants cannot purchase more than $25,000 of stock in any calendar year. The price an employee pays per share is 85% of the lower of the fair market value of the Company’s stock on the close of the first trading day or last trading day of the purchase period. The plan has two purchase periods, the first from October 1 through March 31 and the second from April 1 through September 30. For the years ended December 31, 2016, 2015 and 2014, employees purchased 0.9 million, 1.0 million and 1.4 million shares, respectively, at purchase prices of $57.60 and $64.69, $52.99 and $56.67, and $51.76 and $53.79, respectively.

[0000068505-17-000002:notes:175]
Significant Assumptions Used in the Estimate of Fair Value

[0000068505-17-000002:notes:176]
The Company calculates the value of each employee stock option, estimated on the date of grant, using the Black-Scholes option pricing model. The weighted-average estimated fair value of employee stock options granted during 2016, 2015 and 2014 was $13.09, $10.21 and $11.02, respectively, using the following weighted-average assumptions:

[0000068505-17-000002:notes:177]
|  | 2016 |  | 2015 |  | 2014 |
| Expected volatility | 23.7 | % |  | 20.0 | % |  | 21.7 | % |
| Risk-free interest rate | 1.4 | % |  | 1.6 | % |  | 1.6 | % |
| Dividend yield | 2.9 | % |  | 2.9 | % |  | 2.5 | % |
| Expected life (years) | 6.0 |  |  | 6.0 |  |  | 5.2 |  |

[0000068505-17-000002:notes:178]
The Company calculates the value of each performance option, MSU, and PCSO using the Monte Carlo Simulation, estimated on the date of grant. The fair value of performance options and MSUs granted during 2016 was $19.80 and $76.48, respectively.  The Fair value of performance options, MSUs and PCSOs granted during 2015 were $17.42, $60.37 and $3.97, respectively.  The following assumptions were used for the calculations.

[0000068505-17-000002:notes:179]
The Company uses the implied volatility for traded options on the Company’s stock as the expected volatility assumption in the valuation of stock options, MSUs, and PCSOs. The selection of the implied volatility approach was based upon the availability of actively traded options on the Company’s stock and the Company’s assessment that implied volatility is more representative of future stock price trends than historical volatility. The Company uses the historical volatility as the expected volatility assumption in the valuation of performance options in order to calculate the correlation coefficients between the S&P 500 and the Company's stock, which can only be calculated using historical data.

[0000068505-17-000002:notes:180]
The risk-free interest rate assumption is based upon the average daily closing rates during the year for U.S. Treasury notes that have a life which approximates the expected life of the grant. The dividend yield assumption is based on the Company’s future expectation of dividend payouts. The expected life represents the average of the contractual term of the options and the weighted average vesting period for all option tranches.

[0000068505-17-000002:notes:181]
The Company has applied forfeiture rates, estimated based on historical data, of 10%-40% to the stock option fair values calculated by the Black-Scholes option pricing model. These estimated forfeiture rates are applied to grants based on their remaining vesting term and may be revised in subsequent periods if actual forfeitures differ from these estimates.

[0000068505-17-000002:notes:182]
The following table summarizes information about the total stock options outstanding and exercisable under all stock option plans, including performance options and PCSOs, at December 31, 2016 (in thousands, except exercise price and years):

[0000068505-17-000002:notes:183]
|  | Options Outstanding |  | Options Exercisable |
| Exercise price range | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |  | No. ofoptions |  | Wtd. avg.ExercisePrice |  | Wtd. avg.contractuallife (in yrs.) |
| Under $30 | 542 |  |  | $ | 27 |  |  | 3 |  | 542 |  |  | $ | 27 |  |  | 3 |
| $30-$40 | 1,947 |  |  | 39 |  |  | 3 |  | 1,947 |  |  | 39 |  |  | 3 |
| $41-$50 | 33 |  |  | 45 |  |  | 4 |  | 34 |  |  | 45 |  |  | 4 |
| $51-$60 | 998 |  |  | 55 |  |  | 6 |  | 976 |  |  | 54 |  |  | 6 |
| $61-$70 | 3,100 |  |  | 67 |  |  | 8 |  | 654 |  |  | 66 |  |  | 7 |
| $71-$80 | 664 |  |  | 72 |  |  | 9 |  | 41 |  |  | 74 |  |  | 1 |
|  | 7,284 |  |  |  |  |  |  | 4,194 |  |  |  |  |  |

[0000068505-17-000002:notes:184]
As of December 31, 2016, the weighted average contractual life for options outstanding and exercisable was 6 and 4 years, respectively.

[0000068505-17-000002:notes:185]
Current Year Activity

[0000068505-17-000002:notes:186]
Total share-based compensation activity was as follows (in thousands, except exercise price):

[0000068505-17-000002:notes:187]
|  | Stock Options |  | Performance Options* |  | Restricted Stock Units |  | Market Stock Units |
| Shares in Thousands | Number of Options Outstanding |  | Weighted Average Exercise Price of Shares |  | Number of Options Outstanding |  | Weighted Average Exercise Price of Shares |  | Number of Non-Vested Awards |  | Weighted Average Grant Date Fair Value |  | Number of Non-Vested Awards |  | Weighted Average Grant Date Fair Value |
| Balance as of January 1, 2016 | 6,029 |  |  | $ | 51 |  |  | 2,042 |  |  | $ | 68 |  |  | 1,516 |  |  | $ | 59 |  |  | 84 |  |  | $ | 60 |  |
| Granted | 459 |  |  | 71 |  |  | 246 |  |  | 71 |  |  | 699 |  |  | 67 |  |  | 64 |  |  | 76 |  |
| Releases/Exercised | (1,005 | ) |  | 57 |  |  | — |  |  | — |  |  | (726 | ) |  | 59 |  |  | (25 | ) |  | 60 |  |
| Forfeited/Canceled | (265 | ) |  | 77 |  |  | (222 | ) |  | 68 |  |  | (156 | ) |  | 63 |  |  | (7 | ) |  | 60 |  |
| Balance as of December 31, 2016 | 5,218 |  |  | $ | 50 |  |  | 2,066 |  |  | $ | 69 |  |  | 1,333 |  |  | $ | 63 |  |  | 116 |  |  | $ | 69 |  |
| Vested or expected to vest | 4,418 |  |  | 47 |  |  | — |  |  | — |  |  | 726 |  |  | 59 |  |  | 25 |  |  | 60 |  |

[0000068505-17-000002:notes:188]
* Inclusive of PCSO awards

[0000068505-17-000002:notes:189]
At December 31, 2016 and 2015, 11.2 million and 12.0 million shares, respectively, were available for future share-based award grants under the current share-based compensation plan, covering all equity awards to employees and non-employee directors.

[0000068505-17-000002:notes:190]
Total Share-Based Compensation Expense

[0000068505-17-000002:notes:191]
At December 31, 2016, the Company had unrecognized compensation expense related to RS, RSUs, and MSUs of $50 million, net of estimated forfeitures, expected to be recognized over the weighted average period of approximately two years. The total fair value of RS, RSU and MSU shares vested during the years ended December 31, 2016, 2015, and 2014 was $54 million, $55 million, and $160 million, respectively. The aggregate fair value of outstanding RS, RSUs, and MSUs as of December 31, 2016 was $92 million.

[0000068505-17-000002:notes:192]
At December 31, 2016, the Company had $12 million of total unrecognized compensation expense, net of estimated forfeitures, related to stock option plans including performance options and PCSO's that will be recognized over the weighted average period of approximately two years, and $3 million of unrecognized compensation expense related to the employee stock purchase plan that will be recognized over the remaining purchase period. Cash received from stock option exercises and the employee stock purchase plan was $93 million, $84 million, and $87 million for the years ended December 31, 2016, 2015, and 2014, respectively. The total intrinsic value of options exercised during the years ended December 31, 2016, 2015, and 2014 was $16 million, $15 million, and $38 million, respectively. The aggregate intrinsic value for options outstanding and exercisable as of December 31, 2016 was $200 million and $156 million, respectively, based on a December 31, 2016 stock price of $82.89 per share.

[0000068505-17-000002:notes:193]
Motorola Solutions Incentive Plans

[0000068505-17-000002:notes:194]
The Company's incentive plans provide eligible employees with an annual payment, calculated as a percentage of an employee’s eligible earnings, in the year after the close of the current calendar year if specified business goals and individual performance targets are met. The expense for awards under these incentive plans for the years ended December 31, 2016, 2015 and 2014 was $114 million, $119 million and $53 million, respectively.

[0000068505-17-000002:notes:195]
Long-Range Incentive Plan

[0000068505-17-000002:notes:196]
The Long-Range Incentive Plan (“LRIP”) rewards participating elected officers for the Company’s achievement of specified business goals during the period, based on a single performance objective measured over a three year period. The expense for LRIP for the years ended December 31, 2016, 2015 and 2014 was $12 million, $12 million and $3 million, respectively.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-17-000002:notes:197]
Discontinued Operations

[0000068505-17-000002:notes:198]
On October 27, 2014, the Company completed the sale of its Enterprise business to Zebra Technologies Corporation ("Zebra") for $3.45 billion in cash. Certain assets of the Enterprise business were excluded from the transaction and retained by the Company, including the Company’s iDEN business. The historical financial results of the Enterprise business, excluding those assets and liabilities retained in the transaction, are reflected in the Company's consolidated financial statements and footnotes as discontinued operations for all periods presented.

[0000068505-17-000002:notes:199]
The following table displays summarized activity in the Company’s consolidated statements of operations for discontinued operations during the years ended 2015 and 2014.

[0000068505-17-000002:notes:200]
| Years ended December 31 |  | 2015 |  | 2014 |
| Net sales |  | $ | — |  |  | $ | 1,904 |  |
| Operating earnings |  | — |  |  | 203 |  |
| Gains (losses) on sales of investments and businesses, net |  | (24) |  |  | 1,888 |  |
| Earnings (loss) before income taxes |  | (24 | ) |  | 2,074 |  |
| Income tax expense |  | 6 |  |  | 78 |  |
| Earnings (loss) from discontinued operations, net of tax |  | (30 | ) |  | 1,996 |  |

[0000068505-17-000002:notes:201]
During the year ended December 31, 2016 the Company recognized no earnings from discontinued operations.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000068505-17-000002:notes:202]
The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for earnings (loss) from continuing operations and net earnings attributable to Motorola Solutions, Inc. for all periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-17-000002:notes:203]
Fair Value Measurements

[0000068505-17-000002:notes:204]
The Company holds certain fixed income securities, equity securities and derivatives, which are recognized and disclosed at fair value in the financial statements on a recurring basis. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants as of the measurement date.  Fair value is measured using the fair value hierarchy and related valuation methodologies as defined in the authoritative literature. This guidance specifies a hierarchy of valuation techniques based on whether the inputs to each measurement are observable or unobservable. Observable inputs reflect market data obtained from independent sources, while unobservable inputs reflect the Company's assumptions about current market conditions. The prescribed fair value hierarchy and related valuation methodologies as they pertain to the Company are as follows:

[0000068505-17-000002:notes:205]
Level 1—Quoted prices for identical instruments in active markets.

[0000068505-17-000002:notes:206]
Level 2—Quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-derived valuations, in which all significant inputs are observable, in active markets.

[0000068505-17-000002:notes:207]
Level 3—Valuations derived from valuation techniques, in which one or more significant inputs are unobservable.

[0000068505-17-000002:notes:208]
Investments and Derivatives

[0000068505-17-000002:notes:209]
Pension and Postretirement Health Care Benefits Plan Assets

[0000068505-17-000002:notes:210]
At December 31, 2016, the Company had $309 million of investments in money market prime and government funds (Level 1) classified as Cash and cash equivalents in its consolidated balance sheet, compared to $1.3 billion at December 31, 2015. The money market funds had quoted market prices that are approximately at par.

[0000068505-17-000002:notes:211]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at December 31, 2016 was $4.5 billion (Level 2), consistent with the face value of $4.5 billion. Since considerable judgment is required in interpreting market information, the fair value of the long-term debt is not necessarily indicative of the amount which could be realized in a current market exchange.

[0000068505-17-000002:notes:212]
All other financial instruments are carried at cost, which is not materially different from the instruments’ fair values.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000068505-17-000002:notes:213]
Certain of the Company’s non-U.S. operations use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s consolidated balance sheets. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-17-000002:notes:214]
Intangible Assets and Goodwill

[0000068505-17-000002:notes:215]
The Company accounts for acquisitions using purchase accounting with the results of operations for each acquiree included in the Company’s consolidated financial statements for the period subsequent to the date of acquisition.

[0000068505-17-000002:notes:216]
Guardian Digital Communications Limited Acquisition

[0000068505-17-000002:notes:217]
On February 19, 2016, the Company completed the acquisition of GDCL, a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018.

[0000068505-17-000002:notes:218]
The acquisition of GDCL enables the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. During the year ended December 31, 2016, the Company recorded $462 million within Net sales and $57 million within Net earnings from the operations of Airwave.

[0000068505-17-000002:notes:219]
The acquisition of GDCL has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value.

[0000068505-17-000002:notes:220]
The total consideration for the acquisition of GDCL was approximately $1.1 billion, consisting of cash payments of $1.0 billion, net of cash acquired, and deferred consideration valued at fair value on the date of the acquisition of $82 million. The fair value of deferred consideration has been determined based on its net present value, calculated using a discount rate of 4.2%, which is reflective of the credit standing of the combined entity. The following table summarizes fair values of assets acquired and liabilities assumed as of the February 19, 2016 acquisition date:

[0000068505-17-000002:notes:221]
| Cash |  | $ | 86 |  |
| Accounts receivable, net |  | 55 |  |
| Other current assets |  | 36 |  |
| Property, plant and equipment, net |  | 245 |  |
| Deferred income taxes |  | 82 |  |
| Accounts payable |  | (18 | ) |
| Accrued liabilities |  | (181 | ) |
| Other liabilities |  | (289 | ) |
| Goodwill |  | 191 |  |
| Intangible assets |  | 875 |  |
| Total consideration |  | $ | 1,082 |  |
| Net present value of deferred consideration payment to former owners |  | (82 | ) |
| Net cash consideration at purchase |  | $ | 1,000 |  |

[0000068505-17-000002:notes:222]
Acquired intangible assets consist of $846 million of customer relationships and $29 million of trade names. All intangibles have a useful life of seven years, over which amortization expense will be recognized on a straight line basis.

[0000068505-17-000002:notes:223]
The fair values of trade names and customer relationships were estimated using the income approach. Customer relationships were valued under the excess earnings method which assumes that the value of an intangible asset is equal to the present value of the incremental after-tax cash flows attributable specifically to the intangible asset. Trade names were valued under the relief from royalty method, which assumes value to the extent that the acquired company is relieved of the obligation to pay royalties for the benefits received from them.

[0000068505-17-000002:notes:224]
The fair value of acquired Property, plant and equipment, primarily network-related assets, was valued under the replacement cost method, which determines fair value based on the replacement cost of new property with similar capacity, adjusted for physical deterioration over the remaining useful life.

[0000068505-17-000002:notes:225]
Goodwill is calculated as the excess of the consideration transferred over the net assets recognized and represents the future economic benefits arising from the other assets acquired that could not be individually identified and separately recognized. Goodwill is not deductible for tax purposes.

[0000068505-17-000002:notes:226]
Pro Forma Financial Information

[0000068505-17-000002:notes:227]
The Company did not adjust the effects of an $884 million goodwill impairment charge reported in the historic results of GDCL for the year ended December 31, 2015 on the basis that the goodwill impairment charge was not directly attributable to the acquisition of GDCL by the Company. However, this goodwill impairment charge should be highlighted as unusual and non-recurring.

[0000068505-17-000002:notes:228]
The pro forma results are based on estimates and assumptions, which the Company believes are reasonable. They are not necessarily indicative of its consolidated results of operations in future periods or the results that actually would have been realized had we been a combined company during the periods presented. The pro forma results include adjustments primarily related to amortization of acquired intangible assets, depreciation, interest expense, and transaction costs expensed during the period.

[0000068505-17-000002:notes:229]
Other Acquisitions

[0000068505-17-000002:notes:230]
On November 18, 2014, the Company completed the acquisition of an equipment provider for a purchase price of $22 million. During the year ended December 31, 2015, the Company completed the purchase accounting for this acquisition, recognizing $6 million of goodwill and $12 million of identifiable intangible assets. These identifiable intangible assets were classified as completed technology to be amortized over five years.

[0000068505-17-000002:notes:231]
During the year ended December 31, 2015, the Company completed the acquisitions of two providers of public safety software-based solutions for an aggregate purchase price of $50 million, recognizing an additional $31 million of goodwill, $22 million of identifiable intangible assets, and $3 million of acquired liabilities related to these acquisitions. The $22 million of identifiable intangible assets were classified as: (i) $11 million completed technology, (ii) $8 million customer-related intangibles, and (iii) $3 million of other intangibles. These intangible assets will be amortized over periods ranging from five to ten years.

[0000068505-17-000002:notes:232]
On November 10, 2016, the Company completed the acquisition of Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions, for a gross purchase price of $217 million.  As a result of the acquisition, the Company recognized $140 million of goodwill, $115 million of identifiable intangible assets, and $38 million of acquired liabilities. The identifiable intangible assets were classified as $49 million of completed technology, $59 million of customer-related intangibles, and $7 million of other intangibles and will be amortized over a period of seven to ten years. As of December 31, 2016, the purchase accounting is not yet complete.  The final allocation may include: (i) changes in fair values of acquired goodwill and (ii) changes to assets and liabilities.

[0000068505-17-000002:notes:233]
During the year ended December 31, 2016, the Company completed the acquisition of several software and service-based providers for a total of $30 million, recognizing $6 million of goodwill, $15 million of intangible assets, and $9 million of tangible net assets related to the these acquisitions.  The $15 million of identifiable intangible assets were classified as: (i) $7 million of completed technology and (ii) $8 million of customer-related intangibles and will be amortized over a period of five years. As of December 31, 2016, the purchase accounting has not been completed for one acquisition which was purchased in late 2016.  As such, an amount of $11 million has been recorded within Other Assets as of December 31, 2016.  The purchase accounting is expected to be completed in the first quarter of 2017.

[0000068505-17-000002:notes:234]
The results of operations for these acquisitions have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date. The pro forma effects of these acquisitions are not significant individually or in the aggregate.

[0000068505-17-000002:notes:235]
Intangible Assets

[0000068505-17-000002:notes:236]
Amortized intangible assets are comprised of the following:

[0000068505-17-000002:notes:237]
|  | 2016 |  | 2015 |
| December 31 | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Intangible assets: |  |  |  |  |  |  |  |
| Completed technology | $ | 116 |  |  | $ | 38 |  |  | $ | 60 |  |  | $ | 32 |  |
| Patents | 8 |  |  | 6 |  |  | 8 |  |  | 5 |  |
| Customer-related | 810 |  |  | 101 |  |  | 23 |  |  | 10 |  |
| Other intangibles | 49 |  |  | 17 |  |  | 20 |  |  | 15 |  |
|  | $ | 983 |  |  | $ | 162 |  |  | $ | 111 |  |  | $ | 62 |  |

[0000068505-17-000002:notes:238]
Amortization expense on intangible assets, which is included within Other charges in the consolidated statements of operations, was $113 million, $8 million, and $4 million for the years ended December 31, 2016, 2015, and 2014, respectively.  As of December 31, 2016, future amortization expense is estimated to be $132 million in 2017, $130 million in 2018, $129 million in 2019, $126 million in 2020, and $125 million in 2021.

[0000068505-17-000002:notes:239]
Goodwill

[0000068505-17-000002:notes:240]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2015 to December 31, 2016:

[0000068505-17-000002:notes:241]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2015 |  |  |  |  |  |
| Aggregate goodwill | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 264 |  |  | $ | 119 |  |  | $ | 383 |  |
| Goodwill acquired | 6 |  |  | 31 |  |  | 37 |  |
| Balance as of December 31, 2015 |  |  |  |  |  |
| Aggregate goodwill | 270 |  |  | 150 |  |  | 420 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Goodwill acquired | 46 |  |  | 291 |  |  | 337 |  |
| Foreign currency translation | — |  |  | (29 | ) |  | (29 | ) |
| Balance as of December 31, 2016 |  |  |  |  |  |
| Aggregate goodwill | 316 |  |  | 412 |  |  | 728 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 316 |  |  | $ | 412 |  |  | $ | 728 |  |

[0000068505-17-000002:notes:242]
The Company conducts its annual assessment of goodwill for impairment in the fourth quarter of each year. The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment. The Company has determined that the Products segment and Services segment each meet the definition of a reporting unit.

[0000068505-17-000002:notes:243]
The Company performed a qualitative assessment to determine whether it was more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2016, 2015, and 2014. In performing this qualitative assessment the Company assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in share price, and entity-specific events. For fiscal years 2016, 2015, and 2014, the Company concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value. Therefore, the two-step goodwill impairment test was not required and there was no impairment of goodwill.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000068505-17-000002:notes:244]
Goodwill is assessed for impairment at least annually at the reporting unit level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year.  The annual assessment is performed using the two-step goodwill test which may also include the optional qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount prior to performing the two-step goodwill impairment test.  If this is the case, the two-step goodwill impairment test is required. If it is more-likely-than-not that the fair value of a reporting unit is greater than its carrying amount, the two-step goodwill impairment test is not required.

[0000068505-17-000002:notes:245]
If the two-step goodwill impairment test is performed, first, the fair value of each reporting unit is compared to its book value. Second, if the fair value of the reporting unit is less than its book value, the Company performs a hypothetical purchase price allocation based on the reporting unit's fair value to determine the fair value of the reporting unit's goodwill. Fair value is determined using a combination of present value techniques and market prices of comparable businesses.

[0000068505-17-000002:notes:246]
Intangible assets are amortized on a straight line basis over their respective estimated useful lives ranging from one to ten years. The Company has no intangible assets with indefinite useful lives.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000068505-17-000002:notes:247]
Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-17-000002:notes:248]
Income Taxes

[0000068505-17-000002:notes:249]
Components of earnings (loss) from continuing operations before income taxes are as follows:

[0000068505-17-000002:notes:250]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| United States | $ | 651 |  |  | $ | 725 |  |  | $ | (1,355 | ) |
| Other nations | 193 |  |  | 192 |  |  | 194 |  |
|  | $ | 844 |  |  | $ | 917 |  |  | $ | (1,161 | ) |

[0000068505-17-000002:notes:251]
Components of income tax expense (benefit) are as follows:

[0000068505-17-000002:notes:252]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| United States | $ | 20 |  |  | $ | 71 |  |  | $ | 14 |  |
| Other nations | 31 |  |  | 30 |  |  | 67 |  |
| States (U.S.) | 18 |  |  | 13 |  |  | 11 |  |
| Current income tax expense | 69 |  |  | 114 |  |  | 92 |  |
| United States | 180 |  |  | 154 |  |  | (503 | ) |
| Other nations | 36 |  |  | (13 | ) |  | (11 | ) |
| States (U.S.) | (3 | ) |  | 19 |  |  | (43 | ) |
| Deferred income tax expense (benefit) | 213 |  |  | 160 |  |  | (557 | ) |
| Total income tax expense (benefit) | $ | 282 |  |  | $ | 274 |  |  | $ | (465 | ) |

[0000068505-17-000002:notes:253]
Deferred tax balances that were recorded within Accumulated other comprehensive loss in the Company’s consolidated balance sheets resulted from retirement benefit adjustments, currency translation adjustments, net gains and losses on derivative instruments and fair value adjustments to available-for-sale securities. The adjustments were charges of $87 million, benefits of $62 million, and charges of $286 million for the years ended December 31, 2016, 2015, and 2014, respectively.

[0000068505-17-000002:notes:254]
The Company evaluates its permanent reinvestment assertions with respect to foreign earnings at each reporting period and, except for certain earnings that the Company intends to reinvest indefinitely due to the capital requirements of the foreign subsidiaries or due to local country restrictions, accrues for the U.S. federal and foreign income tax applicable to the earnings.  The Company assessed its unremitted earnings position and concluded that certain of its non-U.S. subsidiaries’ earnings  continue to be permanently reinvested overseas. The Company intends to utilize the offshore earnings for working capital needs in its international operations. During 2016, the Company made no changes to its permanent reinvestment assertion. During 2015, the Company recorded a net tax benefit of $8 million related to the reversal of deferred tax liabilities due to the change in permanent reinvestment assertion. During 2014, the Company recorded a net tax benefit of $19 million related to the reversal of deferred tax liabilities related to undistributed foreign earnings due to the change in permanent reinvestment assertion.

[0000068505-17-000002:notes:255]
Undistributed earnings that the Company intends to reinvest indefinitely, and for which no U.S. income taxes have been provided, aggregate to $1.6 billion at December 31, 2016. The Company currently has no plans to repatriate the foreign earnings permanently reinvested and therefore, the time and manner of repatriation is uncertain. If circumstances change and it becomes apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary. However, given the uncertain repatriation time and manner at December 31, 2016, it is not practicable to estimate the amount of any additional income tax charge on the hypothetical distribution of permanently reinvested earnings. On a cash basis, these repatriations from the Company's non-U.S. subsidiaries could require the payment of additional taxes. The portion of earnings not reinvested indefinitely may be distributed without an additional charge given the U.S. federal and foreign income tax accrued on undistributed earnings and the utilization of available foreign tax credits.

[0000068505-17-000002:notes:256]
Differences between income tax expense (benefit) computed at the U.S. federal statutory tax rate of 35% and income tax expense (benefit) as reflected in the consolidated statements of operations are as follows:

[0000068505-17-000002:notes:257]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Income tax expense (benefit) at statutory rate | $ | 295 |  | 35.0 | % |  | $ | 321 |  | 35.0 | % |  | $ | (406 | ) | 35.0 | % |
| Tax on non-U.S. earnings | (25 | ) | (3.0 | )% |  | (46 | ) | (5.0 | )% |  | (27 | ) | 2.3 | % |
| State income taxes, net of federal benefit | 26 |  | 3.1 | % |  | 24 |  | 2.6 | % |  | (30 | ) | 2.6 | % |
| Recognition of previously unrecognized income tax benefits | (13 | ) | (1.6 | )% |  | 1 |  | 0.1 | % |  | (29 | ) | 2.5 | % |
| Other provisions | (2 | ) | (0.4 | )% |  | 14 |  | 1.6 | % |  | 9 |  | (0.7 | )% |
| Valuation allowances | (7 | ) | (0.8 | )% |  | (9 | ) | (1.0 | )% |  | 55 |  | (4.7 | )% |
| Section 199 deduction | (15 | ) | (1.7 | )% |  | (19 | ) | (2.1 | )% |  | (12 | ) | 1.0 | % |
| Tax on undistributed non-U.S. earnings | 25 |  | 3.0 | % |  | (7 | ) | (0.8 | )% |  | (19 | ) | 1.6 | % |
| Research credits | (2 | ) | (0.2 | )% |  | (5 | ) | (0.5 | )% |  | (6 | ) | 0.5 | % |
|  | $ | 282 |  | 33.4 | % |  | $ | 274 |  | 29.9 | % |  | $ | (465 | ) | 40.1 | % |

[0000068505-17-000002:notes:258]
Gross deferred tax assets were $3.1 billion and $3.5 billion at December 31, 2016 and 2015, respectively. Deferred tax assets, net of valuation allowances, were $3.0 billion at December 31, 2016 and $3.4 billion at December 31, 2015, respectively. Gross deferred tax liabilities were $900 million and $1.2 billion at December 31, 2016 and 2015, respectively.

[0000068505-17-000002:notes:259]
Significant components of deferred tax assets (liabilities) are as follows:

[0000068505-17-000002:notes:260]
| December 31 | 2016 |  | 2015 |
| Inventory | $ | 29 |  |  | $ | 30 |  |
| Accrued liabilities and allowances | 136 |  |  | 136 |  |
| Employee benefits | 693 |  |  | 612 |  |
| Capitalized items | 169 |  |  | 357 |  |
| Tax basis differences on investments | 7 |  |  | 14 |  |
| Depreciation tax basis differences on fixed assets | 74 |  |  | 19 |  |
| Undistributed non-U.S. earnings | (27 | ) |  | (19 | ) |
| Tax carryforwards | 927 |  |  | 1,028 |  |
| Business reorganization | 36 |  |  | 20 |  |
| Warranty and customer liabilities | 21 |  |  | 20 |  |
| Deferred revenue and costs | 122 |  |  | 146 |  |
| Valuation allowances | (118 | ) |  | (129 | ) |
| Deferred charges | 37 |  |  | 41 |  |
| Other | (8 | ) |  | 3 |  |
|  | $ | 2,098 |  |  | $ | 2,278 |  |

[0000068505-17-000002:notes:261]
At December 31, 2016 and 2015, the Company had valuation allowances of $118 million and $129 million, respectively, against its deferred tax assets, including $85 million and $98 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. The Company’s valuation allowances for its non-U.S. subsidiaries had a net decrease of $13 million during 2016 and a net decrease of $97 million during 2015. The decrease in the valuation allowance relating to deferred tax assets of non-U.S. subsidiaries during 2016 relates to the expiration of net operating losses and the change in the value of net deferreds related to the Company's defined benefit plan in the United Kingdom. The decrease in the valuation allowance relating to deferred tax assets of non-U.S. subsidiaries during 2015 relates to the expiration of net operating losses, the release of a Singapore valuation allowance, and the change in the value of net deferreds related to the Company's defined benefit plan in the United Kingdom.

[0000068505-17-000002:notes:262]
The Company’s U.S. valuation allowance increased $2 million during 2016 while it did not change during 2015. The U.S. valuation allowance of $33 million as of December 31, 2016 primarily relates to state tax carryforwards. The Company believes that the remaining deferred tax assets are more-likely-than-not to be realizable based on estimates of future taxable income and the implementation of tax planning strategies.

[0000068505-17-000002:notes:263]
Tax carryforwards are as follows:

[0000068505-17-000002:notes:264]
| December 31, 2016 | GrossTax Loss |  | TaxEffected |  | ExpirationPeriod |
| United States: |  |  |  |  |  |
| U.S. tax losses | $ | 51 |  |  | $ | 18 |  |  | 2022-2033 |
| Foreign tax credits | — |  |  | 510 |  |  | 2018-2023 |
| General business credits | — |  |  | 115 |  |  | 2026-2036 |
| Minimum tax credits | — |  |  | 101 |  |  | Unlimited |
| State tax losses | 1,174 |  |  | 34 |  |  | 2017-2029 |
| State tax credits | — |  |  | 26 |  |  | 2018-2030 |
| Non-U.S. Subsidiaries: |  |  |  |  |  |
| Japan tax losses | 98 |  |  | 30 |  |  | 2017-2021 |
| Germany tax losses | 53 |  |  | 15 |  |  | Unlimited |
| United Kingdom tax losses | 84 |  |  | 14 |  |  | Unlimited |
| Singapore tax losses | 40 |  |  | 7 |  |  | Unlimited |
| Other subsidiaries tax losses | — |  |  | 26 |  |  | Various |
| Spain tax credits | — |  |  | 23 |  |  | Various |
| Other subsidiaries tax credits | — |  |  | 8 |  |  | Various |
|  |  |  | $ | 927 |  |  |  |

[0000068505-17-000002:notes:265]
The Company had unrecognized tax benefits of $68 million and $88 million at December 31, 2016 and December 31, 2015, respectively, of which approximately $50 million, if recognized, would affect the effective tax rate for both 2016 and 2015, net of resulting changes to valuation allowances.

[0000068505-17-000002:notes:266]
A roll-forward of unrecognized tax benefits is as follows:

[0000068505-17-000002:notes:267]
|  | 2016 |  | 2015 |
| Balance at January 1 | $ | 88 |  |  | $ | 96 |  |
| Additions based on tax positions related to current year | — |  |  | 2 |  |
| Additions for tax positions of prior years | 2 |  |  | 4 |  |
| Reductions for tax positions of prior years | (15 | ) |  | (9 | ) |
| Settlements and agreements | (3 | ) |  | (3 | ) |
| Lapse of statute of limitations | (4 | ) |  | (2 | ) |
| Balance at December 31 | $ | 68 |  |  | $ | 88 |  |

[0000068505-17-000002:notes:268]
The IRS has completed its examination of the Company's 2012 and 2013 tax years. The Company also has several state and non-U.S. audits pending. A summary of open tax years by major jurisdiction is presented below:

[0000068505-17-000002:notes:269]
Although the final resolution of the Company’s global tax disputes is uncertain, based on current information, in the opinion of the Company’s management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations. However, an unfavorable resolution of the Company’s global tax disputes could have a material adverse effect on the Company’s consolidated financial position, liquidity, or results of operations in the periods, and as of the dates, on which the matters are ultimately resolved.

[0000068505-17-000002:notes:270]
Based on the potential outcome of the Company’s global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $50 million tax charge to a $30 million tax benefit, with cash payments not to exceed $30 million.

[0000068505-17-000002:notes:271]
At December 31, 2016, the Company had $26 million accrued for interest and $18 million accrued for penalties on unrecognized tax benefits. At December 31, 2015, the Company had $29 million and $24 million accrued for interest and penalties, respectively, on unrecognized tax benefits.


## us-gaap:IncomeTaxPolicyTextBlock

[0000068505-17-000002:notes:272]
The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.


## us-gaap:InventoryPolicyTextBlock

[0000068505-17-000002:notes:273]
Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or market (net realizable value or replacement cost).


## us-gaap:InvestmentPolicyTextBlock

[0000068505-17-000002:notes:274]
Investments in equity and debt securities classified as available-for-sale are carried at fair value.  When applicable, debt securities classified as held-to-maturity are carried at amortized cost. Equity securities that are restricted for more than one year or that are not publicly traded are carried at cost. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-17-000002:notes:275]
The Company assesses declines in the fair value of investments to determine whether such declines are other-than-temporary. This assessment is made considering all available evidence, including changes in general market conditions, specific industry and individual company data, the length of time and the extent to which the fair value has been less than cost, the financial condition and the near-term prospects of the entity issuing the security, and the Company’s ability and intent to hold the investment until recovery. Other-than-temporary impairments of investments are recorded to Other within Other income (expense) in the Company’s consolidated statements of operations in the period in which they become impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-17-000002:notes:276]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods or services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

[0000068505-17-000002:notes:277]
The Company has begun to analyze the impact of the new standard on its financial results based on an inventory of the Company’s current contracts with customers. The Company has obtained an understanding of the new standard and currently believes that it will retain much of the same accounting treatment as used to recognize revenue under current standards. Revenue on a significant portion of its contracts is currently recognized under percentage of completion accounting, applying a cost-to-cost method. Under the new standard the Company will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in the Company's contracts is demonstrated by creating a customized asset for customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000002:notes:278]
In addition, the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by software revenue recognition rules. While the Company may have contracts which fall under these accounting rules in the current standard, it has not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, the Company does not anticipate a significant acceleration of revenue upon applying the new standard to its current contracts under these fact patterns.

[0000068505-17-000002:notes:279]
The Company continues to evaluate the impact of ASU No. 2014-09 on our financial results and prepare for the adoption of the standard on January 1, 2018, including readying its internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and the impact on our consolidated financial statements and footnote disclosures, and will continue to provide enhanced disclosures as we continue our assessment.

[0000068505-17-000002:notes:280]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000002:notes:281]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so in which case it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000002:notes:282]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-17-000002:notes:283]
The Company elected to adopt ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” as of January 1, 2016. ASU 2016-09, which was issued by the FASB in March 2016, simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $5 million income tax benefit during the year ended December 31, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $17 million, $16 million, and $48 million for the years ended December 31, 2016, 2015 and 2014. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $6 million for the year ended December 31, 2016.

[0000068505-17-000002:notes:284]
The Company adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs," effective January 1, 2016. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. The Company retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of December 31, 2016 and December 31, 2015, $25 million and $41 million of debt issuance costs, respectively, have been presented as a component of long-term debt.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-17-000002:notes:285]
Retirement Benefits

[0000068505-17-000002:notes:286]
Pension and Postretirement Health Care Benefits Plans

[0000068505-17-000002:notes:287]
The Company’s noncontributory U.S. pension plan (the “Regular Pension Plan”) provides benefits to U.S. employees hired prior to January 1, 2005, who became eligible after one year of service. In December 2008, the Company amended the Regular Pension Plan such that, effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit.

[0000068505-17-000002:notes:288]
In September 2014, the Company entered into a Definitive Purchase Agreement (the “Agreement”) by and among the Company, The Prudential Insurance Company of America (“PICA”), Prudential Financial, Inc. and State Street Bank and Trust Company, as Independent Fiduciary of the Company’s Regular Pension Plan. Under the Agreement, the Regular Pension Plan purchased from PICA a group annuity contract that requires PICA to pay and administer certain future annuity payments to approximately 30,000 of the Company’s retirees. On December 3, 2014, the Company transfered $3.2 billion of plan assets to PICA upon the close of the Agreement and then subsequently terminated the plan. During 2014, the Company established a new pension plan with substantially the same terms as the Regular Pension Plan (the “New Plan”) to accommodate the Company's remaining active employees and non-retirees. Upon the establishment of the New Plan, the Company offered and paid out from plan assets the maximum of $1.0 billion of lump-sum distributions to certain participants who had accrued a pension benefit, had left the Company prior to June 30, 2014, and had not yet started receiving pension benefit payments. As a result of the actions taken to the Regular Pension Plan and the New Plan, the Company recorded a settlement loss of $1.9 billion in 2014 which is recorded in "Other charges" within the statement of operations.

[0000068505-17-000002:notes:289]
The Company has an additional noncontributory supplemental retirement benefit plan, the Motorola Supplemental Pension Plan (“MSPP”), which provided supplemental benefits to individuals by replacing benefits that are lost by such individuals under the retirement formula due to application of the limitations imposed by the Internal Revenue Code. Effective January 1, 2007, eligible compensation was capped at the IRS limit plus $175,000 (the “Cap”) or, for those already in excess of the Cap as of January 1, 2007, the eligible compensation used to compute such employee’s MSPP benefit for all future years is the greater of: (i) such employee’s eligible compensation as of January 1, 2007 (frozen at that amount) or (ii) the relevant Cap for the given year. The Company amended the MSPP (collectively the with the New Plan, the “U.S. Pension Benefit Plans”) in December 2008 such that effective March 1, 2009: (i) no participant shall accrue any benefit or additional benefit on or after March 1, 2009, and (ii) no compensation increases earned by a participant on or after March 1, 2009 shall be used to compute any accrued benefit. Effective January 1, 2009, the MSPP was closed to new participants unless such participation was required under a prior contractual entitlement.

[0000068505-17-000002:notes:290]
Certain health care benefits are available to eligible domestic employees hired prior to January 1, 2002 and meeting certain age and service requirements upon termination of employment (the “Postretirement Health Care Benefits Plan”). As of January 1, 2005, the Postretirement Health Care Benefits Plan was closed to new participants.

[0000068505-17-000002:notes:291]
During 2012, the Postretirement Health Care Benefits Plan was amended ("the Original Amendment") such that, as of January 1, 2013, retirees over the age of 65 are provided an annual subsidy to use toward the purchase of their own health care coverage from private insurance companies or for reimbursement of eligible health care expenses.  During 2014, the Postretirement Health Care Benefits Plan was then further amended ("The New Amendment") to provide the annual subsidy discussed as part of the Original Amendment to all participants remaining under the plan effective March 1, 2015. Additionally, the New Amendment eliminated dental benefits that were previously provided under the plan.

[0000068505-17-000002:notes:292]
During the year ended December 31, 2016, the Company made two amendments to the Postretirement Health Care Benefits Plan (the “Amendments”). As a result of the first Amendment, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.  The second amendment modified the annual subsidy such that all retirees over the age of 65 were entitled to one fixed rate subsidy, capped at $560 per participant.

[0000068505-17-000002:notes:293]
The Amendments to the Postretirement Health Care Benefits Plan required remeasurement of the plan, resulting in a reduction in the Postretirement Benefit Obligation. A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the condensed consolidated statements of operations over approximately five years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.

[0000068505-17-000002:notes:294]
Non U.S. Pension Benefit Plans

[0000068505-17-000002:notes:295]
The Company also provides defined benefit plans which cover non U.S. employees in certain jurisdictions, principally the United Kingdom and Germany (the “Non U.S. Pension Benefit Plans”). Other pension plans outside of the U.S. are not material to the Company either individually or in the aggregate.

[0000068505-17-000002:notes:296]
In June 2015, the Company amended its Non U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.  As a result, the Company recorded a curtailment gain of $32 million to Other Charges within the Company's consolidated statement of operations during 2015.

[0000068505-17-000002:notes:297]
During the year ended December 31, 2016, the Company offered lump-sum settlements to certain participants in the Non-US defined benefit plan within the United Kingdom.  The lump-sum settlements were targeted to certain participants who had accrued a pension benefit, but had not yet started receiving pension benefit payments.  As a result of the actions taken, the company recorded a settlement loss of $26 million in 2016, which is recorded within "Other Charges" within the consolidated statement of operations.

[0000068505-17-000002:notes:298]
Net Periodic Cost (Benefit)

[0000068505-17-000002:notes:299]
The net periodic cost (benefit) for pension and Postretirement Health Care Benefits plans was as follows:

[0000068505-17-000002:notes:300]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  |  | $ | 12 |  |  | $ | 15 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |
| Interest cost | 182 |  |  | 193 |  |  | 370 |  |  | 55 |  |  | 66 |  |  | 80 |  |  | 4 |  |  | 8 |  |  | 10 |  |
| Expected return on plan assets | (220 | ) |  | (212 | ) |  | (381 | ) |  | (93 | ) |  | (103 | ) |  | (90 | ) |  | (9 | ) |  | (9 | ) |  | (10 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 37 |  |  | 46 |  |  | 97 |  |  | 11 |  |  | 17 |  |  | 12 |  |  | 5 |  |  | 8 |  |  | 9 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |  | (7 | ) |  | (27 | ) |  | (59 | ) |  | (50 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement loss | — |  |  | — |  |  | 1,883 |  |  | 26 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | (1 | ) |  | $ | 27 |  |  | $ | 1,969 |  |  | $ | 10 |  |  | $ | (43 | ) |  | $ | 10 |  |  | $ | (27 | ) |  | $ | (51 | ) |  | $ | (39 | ) |

[0000068505-17-000002:notes:301]
The benefit obligation and plan assets for the Company's U.S. Pension Benefit Plan and Postretirement Health Care Benefit Plan are measured as of December 31, 2016. The Company utilizes a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-17-000002:notes:302]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized gains and losses changes from the average remaining service period to the average remaining lifetime of the participants. As such, depending on the specific plan, the Company amortizes gains and losses over periods ranging from eleven to thirty-four years. Prior service costs are amortized over periods ranging from one to eight years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-17-000002:notes:303]
The net periodic cost for 2017 will include amortization of the unrecognized net loss and prior service costs for the U.S. Pension Benefit Plans and Non U.S. Pension Benefit Plans, currently included in Accumulated other comprehensive loss, of $44 million and $15 million, respectively. It is estimated that the 2017 net periodic expense for the Postretirement Health Care Benefits Plan will include amortization of a net credit of $13 million, comprised of the unrecognized prior service gain and unrecognized actuarial loss, currently included in Accumulated other comprehensive loss.

[0000068505-17-000002:notes:304]
Actuarial Assumptions

[0000068505-17-000002:notes:305]
Certain actuarial assumptions such as the discount rate and the long-term rate of return on plan assets have a significant effect on the amounts reported for net periodic cost and the benefit obligation. The assumed discount rates reflect the prevailing market rates of a universe of high-quality, non-callable, corporate bonds currently available that, if the obligation were settled at the measurement date, would provide the necessary future cash flows to pay the benefit obligation when due. The long-term rates of return on plan assets represent an estimate of long-term returns on an investment portfolio consisting of a mixture of equities, fixed income, cash and other investments similar to the actual investment mix. In determining the long-term return on plan assets, the Company considers long-term rates of return on the asset classes (both historical and forecasted) in which the Company expects the plan funds to be invested.

[0000068505-17-000002:notes:306]
Effective January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, therefore, has accounted for it prospectively beginning January 1, 2016. Based on the change in estimate, the Company experienced no reduction in service costs and a $28 million reduction in interest costs for the year ended December 31, 2016 compared to the prior approach. The overall reduction in the interest cost for the year ended December 31, 2016 is comprised of $18 million related to the U.S. Pension Benefit Plans, $4 million related to the Postretirement Health Care Benefit Plans, and $6 million related to the Non U.S. Pension Benefits Plan.

[0000068505-17-000002:notes:307]
In 2014, the Society of Actuaries ("SOA") released the “RP-2014 White Collar” mortality table which was utilized in calculating the 2014 projected benefit obligation. During 2016, the SOA issued an update, Mortality Improvement Scale MP-2016, which includes two additional years of mortality data and was utilized to calculate the 2016 projected benefit obligation.

[0000068505-17-000002:notes:308]
Investment Policy

[0000068505-17-000002:notes:309]
The individual plans have adopted an investment policy designed to meet or exceed the expected rate of return on plan assets assumption. To achieve this, the plans retain professional advisors and investment managers that invest plan assets into various classes including, but not limited to, equity and fixed income securities, cash, cash equivalents, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate. The Company uses long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop its expected rate of return assumption used in calculating the net periodic cost. The individual plans have target mixes for these asset classes, which are readjusted periodically when an asset class weighting deviates from the target mix, with the goal of achieving the required return at a reasonable risk level.

[0000068505-17-000002:notes:310]
Within the equity securities asset class, the investment policy provides for investments in a broad range of publicly-traded securities including both domestic and foreign equities. Within the fixed income securities asset class, the investment policy provides for investments in a broad range of publicly-traded debt securities including: U.S. Treasury issues, corporate debt securities, mortgage and asset-backed securities, as well as foreign debt securities. In the cash and other investments asset class, investments may include, but are not limited to: cash, cash equivalents, commodities, hedge funds, infrastructure/utilities, insurance contracts, leveraged loan funds and real estate.

[0000068505-17-000002:notes:311]
Cash Funding

[0000068505-17-000002:notes:312]
The Company made $3 million of contributions to its U.S. Pension Benefit Plans during 2016, compared to $3 million contributed in 2015. The Company contributed $8 million to its Non U.S. Pension Benefit Plans during 2016, compared to $10 million contributed in 2015. The Company made no contributions to its Postretirement Health Care Benefits Plan in 2016 or 2015.

[0000068505-17-000002:notes:313]
Expected Future Benefit Payments

[0000068505-17-000002:notes:314]
Other Benefit Plans

[0000068505-17-000002:notes:315]
Split-Dollar Life Insurance Arrangements

[0000068505-17-000002:notes:316]
The Company maintains a number of endorsement split-dollar life insurance policies on now-retired officers under a plan that was frozen prior to December 31, 2004. The Company had purchased the life insurance policies to insure the lives of employees and then entered into a separate agreement with the employees that split the policy benefits between the Company and the employee. Motorola Solutions owns the policies, controls all rights of ownership, and may terminate the insurance policies. To effect the split-dollar arrangement, Motorola Solutions endorsed a portion of the death benefits to the employee and upon the death of the employee, the employee’s beneficiary typically receives the designated portion of the death benefits directly from the insurance company and the Company receives the remainder of the death benefits. It is currently expected that minimal cash payments will be required to fund these policies.

[0000068505-17-000002:notes:317]
The net periodic pension cost for these split-dollar life insurance arrangements was $5 million for the years ended December 31, 2016, 2015 and 2014. The Company has recorded a liability representing the actuarial present value of the future death benefits as of the employees’ expected retirement date of $58 million and $63 million as of December 31, 2016 and December 31, 2015, respectively.

[0000068505-17-000002:notes:318]
Deferred Compensation Plan

[0000068505-17-000002:notes:319]
The Company amended and reinstated its deferred compensation plan (“the Plan”) effective June 1, 2013 to reopen the Plan to certain participants. Under the Plan, participants may elect to defer base salary and cash incentive compensation in excess of 401(k) plan limitations. Participants under the Plan may choose to invest their deferred amounts in the same investment alternatives available under the Company's 401(k) plan. The Plan also allows for Company matching contributions for the following: (i) the first 4% of compensation deferred under the Plan, subject to a maximum of $50,000 for board officers, (ii) lost matching amounts that would have been made under the 401(k) plan if participants had not participated in the Plan, and (iii) discretionary amounts as approved by the Compensation and Leadership Committee of the Board of Directors.

[0000068505-17-000002:notes:320]
Defined Contribution Plan

[0000068505-17-000002:notes:321]
The Company and certain subsidiaries have various defined contribution plans, in which all eligible employees may participate. In the U.S., the 401(k) plan is a contributory plan. Matching contributions are based upon the amount of the employees’ contributions. The Company’s expenses for material defined contribution plans for the years ended December 31, 2016, 2015 and 2014 were $26 million, $28 million and $31 million, respectively.

[0000068505-17-000002:notes:322]
Under the 401(k) plan, the Company may make an additional discretionary 401(k) plan matching contribution to eligible employees. For the years ended December 31, 2016, 2015, and 2014 the Company made no discretionary matching contributions.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000068505-17-000002:notes:323]
Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (buildings and building equipment, five to forty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000068505-17-000002:notes:324]
Quarterly and Other Financial Data (unaudited)

[0000068505-17-000002:notes:325]
|  | 2016 |  | 2015 |
|  | 1st |  | 2nd |  | 3rd |  | 4th |  | 1st |  | 2nd |  | 3rd |  | 4th |
| Operating Results |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 1,193 |  |  | $ | 1,430 |  |  | $ | 1,532 |  |  | $ | 1,883 |  |  | $ | 1,223 |  |  | $ | 1,368 |  |  | $ | 1,422 |  |  | $ | 1,682 |  |
| Costs of sales | 691 |  |  | 754 |  |  | 770 |  |  | 955 |  |  | 675 |  |  | 720 |  |  | 737 |  |  | 844 |  |
| Gross margin | 502 |  |  | 676 |  |  | 762 |  |  | 928 |  |  | 548 |  |  | 648 |  |  | 685 |  |  | 838 |  |
| Selling, general and administrative expenses | 234 |  |  | 240 |  |  | 247 |  |  | 277 |  |  | 256 |  |  | 254 |  |  | 259 |  |  | 252 |  |
| Research and development expenditures | 135 |  |  | 138 |  |  | 137 |  |  | 142 |  |  | 159 |  |  | 156 |  |  | 153 |  |  | 152 |  |
| Other charges | 33 |  |  | 74 |  |  | 37 |  |  | 106 |  |  | 14 |  |  | (16 | ) |  | 42 |  |  | 44 |  |
| Operating earnings | 100 |  |  | 224 |  |  | 341 |  |  | 403 |  |  | 119 |  |  | 254 |  |  | 231 |  |  | 390 |  |
| Earnings from continuing operations* | 17 |  |  | 107 |  |  | 192 |  |  | 243 |  |  | 87 |  |  | 150 |  |  | 126 |  |  | 277 |  |
| Net earnings* | 17 |  |  | 107 |  |  | 192 |  |  | 243 |  |  | 74 |  |  | 142 |  |  | 115 |  |  | 279 |  |
| Per Share Data (in dollars) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings (loss) from Continuing operations*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per common share | $ | 0.10 |  |  | $ | 0.62 |  |  | $ | 1.15 |  |  | $ | 1.47 |  |  | $ | 0.40 |  |  | $ | 0.72 |  |  | $ | 0.63 |  |  | $ | 1.58 |  |
| Diluted earnings (loss) per common share | 0.10 |  |  | 0.61 |  |  | 1.13 |  |  | 1.43 |  |  | 0.40 |  |  | 0.72 |  |  | 0.63 |  |  | 1.56 |  |
| Net earnings*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per common share | $ | 0.10 |  |  | $ | 0.62 |  |  | $ | 1.15 |  |  | $ | 1.47 |  |  | $ | 0.34 |  |  | $ | 0.68 |  |  | $ | 0.58 |  |  | $ | 1.60 |  |
| Diluted earnings per common share | 0.10 |  |  | 0.61 |  |  | 1.13 |  |  | 1.43 |  |  | 0.34 |  |  | 0.68 |  |  | 0.57 |  |  | 1.57 |  |
| Dividends declared | $ | 0.41 |  |  | $ | 0.41 |  |  | $ | 0.41 |  |  | $ | 0.47 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.41 |  |
| Dividends paid | 0.41 |  |  | 0.41 |  |  | 0.41 |  |  | 0.41 |  |  | 0.34 |  |  | 0.34 |  |  | 0.34 |  |  | 0.34 |  |
| Stock prices |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High | $ | 76.11 |  |  | $ | 76.32 |  |  | $ | 78.32 |  |  | $ | 84.00 |  |  | $ | 70.00 |  |  | $ | 62.53 |  |  | $ | 69.61 |  |  | $ | 72.45 |  |
| Low | $ | 60.36 |  |  | $ | 63.08 |  |  | $ | 64.77 |  |  | $ | 71.29 |  |  | $ | 62.41 |  |  | $ | 57.14 |  |  | $ | 56.79 |  |  | $ | 65.24 |  |

[0000068505-17-000002:notes:326]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.


## us-gaap:ReceivablesPolicyTextBlock

[0000068505-17-000002:notes:327]
Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under a workout or restructuring for four consecutive quarters.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-17-000002:notes:328]
Reorganization of Businesses

[0000068505-17-000002:notes:329]
The Company maintains a formal Involuntary Severance Plan (the “Severance Plan”), which permits the Company to offer eligible employees severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or restructuring. The Severance Plan includes defined formulas to calculate employees’ termination benefits.  In addition to the Involuntary Severance Plan, during the year ended December 31, 2016, the Company accepted voluntary applications to its Severance Plan from a defined subset of employees within the United States.  Voluntary applicants received termination benefits based on the formulas defined in the Severance Plan. However, termination benefits, which are normally different based on employment level grade and capped at six months of salary, were equialized for all employment level grades and capped at a full year’s salary.

[0000068505-17-000002:notes:330]
The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance, or were redeployed due to circumstances not foreseen when the original plans were approved. In these cases, the Company reverses accruals through the consolidated statements of operations where the original charges were recorded when it is determined they are no longer needed.

[0000068505-17-000002:notes:331]
During 2016, 2015, and 2014 the Company continued to implement various productivity improvement plans aimed at achieving long-term, sustainable profitability by driving efficiencies and reducing operating costs. Both of the Company’s segments were impacted by these plans. The employees affected were located in all geographic regions.

[0000068505-17-000002:notes:332]
2016 Charges

[0000068505-17-000002:notes:333]
During 2016, the Company recorded net reorganization of business charges of $140 million, including $43 million of charges in Costs of sales and $97 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the $140 million were charges of: (i) $120 million for employee separation costs, (ii) a $17 million building impairment charge, (iii) $5 million for exit costs, and (iv) $3 million for the impairment of the corporate aircraft, partially offset by $5 million of reversals of accruals no longer needed.

[0000068505-17-000002:notes:334]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2016 to December 31, 2016:

[0000068505-17-000002:notes:335]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 9 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | (6 | ) |  | $ | 7 |  |
| Employee separation costs | 51 |  |  | 120 |  |  | (4 | ) |  | (73 | ) |  | 94 |  |
|  | $ | 60 |  |  | $ | 125 |  |  | $ | (5 | ) |  | $ | (79 | ) |  | $ | 101 |  |

[0000068505-17-000002:notes:336]
Exit Costs

[0000068505-17-000002:notes:337]
At January 1, 2016, the Company had $9 million accrual for exit costs. There were $5 million of additional charges in 2016. The $6 million used in 2016 reflects cash payments. The remaining accrual of $7 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2016, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-17-000002:notes:338]
Employee Separation Costs

[0000068505-17-000002:notes:339]
At January 1, 2016, the Company had an accrual of $51 million for employee separation costs. The 2016 additional charges of $120 million represent severance costs for approximately an additional 1,300 employees, of which 400 were direct employees and 900 were indirect employees. The adjustments of $4 million reflect reversals of accruals no longer needed. The $73 million used in 2016 reflects cash payments to severed employees. The remaining accrual of $94 million, which is included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2016, is expected to be paid, primarily within one year to: (i) severed employees who have already begun to receive payments and (ii) approximately 300 employees to be separated in 2017.

[0000068505-17-000002:notes:340]
2015 Charges

[0000068505-17-000002:notes:341]
During 2015, the Company recorded net reorganization of business charges of $117 million, including $9 million of charges in Costs of sales and $108 million of charges under Other charges in the Company’s consolidated statements of operations. Included in the aggregate $117 million are charges of: (i) $74 million for employee separation costs, (ii) $31 million for the impairment of the corporate aircraft, (iii) $10 million for exit costs, and (iv) a $6 million building impairment charge, partially offset by $4 million of reversals of accruals no longer needed.

[0000068505-17-000002:notes:342]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2015 to December 31, 2015:

[0000068505-17-000002:notes:343]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 9 |  |
| Employee separation costs | 57 |  |  | 74 |  |  | (10 | ) |  | (70 | ) |  | 51 |  |
|  | $ | 57 |  |  | $ | 84 |  |  | $ | (10 | ) |  | $ | (71 | ) |  | $ | 60 |  |

[0000068505-17-000002:notes:344]
At January 1, 2015, the Company had no accrual for exit costs. There were $10 million of additional charges in 2015. The $1 million used in 2015 reflects cash payments. The remaining accrual of $9 million, which was included in Accrued liabilities in the Company’s consolidated balance sheets at December 31, 2015, primarily represented future cash payments for lease obligations.

[0000068505-17-000002:notes:345]
At January 1, 2015, the Company had an accrual of $57 million for employee separation costs. The additional 2015 charges of $74 million represent severance costs for approximately an additional 1,100 employees, of which 200 were direct employees and 900 were indirect employees. The adjustments of $10 million reflect $4 million of reversals of accruals no longer needed and $6 million of reversals of accruals held for employees separated from discontinued operations. The $70 million used in 2015 reflects cash payments to severed employees. The remaining accrual of $51 million, which was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2015.

[0000068505-17-000002:notes:346]
2014 Charges

[0000068505-17-000002:notes:347]
During 2014, the Company recorded net reorganization of business charges of $73 million, including $9 million of charges in Costs of sales and $64 million of charges in Other charges in the Company’s consolidated statements of operations. Included in the aggregate $73 million are charges of: (i) $67 million for employee separation costs and (ii) $7 million of charges for exit costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-17-000002:notes:348]
The following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs, including those related to discontinued operations which were maintained by the Company after the sale of the Enterprise business, from January 1, 2014 to December 31, 2014:

[0000068505-17-000002:notes:349]
|  | Accruals atJanuary 1 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | Accruals atDecember 31 |
| Exit costs | $ | 6 |  |  | $ | 7 |  |  | $ | — |  |  | $ | (13 | ) |  | $ | — |  |
| Employee separation costs | 103 |  |  | 93 |  |  | (4 | ) |  | (135 | ) |  | 57 |  |
|  | $ | 109 |  |  | $ | 100 |  |  | $ | (4 | ) |  | $ | (148 | ) |  | $ | 57 |  |

[0000068505-17-000002:notes:350]
At January 1, 2014, the Company had an accrual of $6 million for exit costs attributable to lease terminations. There were $7 million of additional charges in 2014. The $13 million used in 2014 reflects cash payments. There was no remaining accrual as of December 31, 2014.

[0000068505-17-000002:notes:351]
At January 1, 2014, the Company had an accrual of $103 million for employee separation costs. The additional 2014 charges of $93 million represent severance costs, of which $26 million related to employees of the Enterprise business and were recorded within discontinued operations.  The charges represent severance for approximately an additional 1,200 employees, of which 300 were direct employees and 900 were indirect employees. The adjustments of $4 million reflect reversals of accruals no longer needed. The $135 million used in 2014 reflects cash payments to these separated employees, including $50 million related to employees of the Enterprise business and included in cash flow from discontinued operations. The remaining accrual of $57 million was included in Accrued liabilities in the Company’s consolidated balance sheet at December 31, 2014.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000068505-17-000002:notes:352]
Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its products and services due to the needs of its customers. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. The Company recognizes revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  The Company recognizes revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) stand alone sales of software products or software upgrades, (ii) stand alone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-17-000002:notes:353]
Products

[0000068505-17-000002:notes:354]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. The Company bases its estimates of these allowances on historical experience taking into consideration the type of products sold, the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, the Company defers revenue until the incentive has been finalized with the customer.  The Company includes shipping charges billed to customers in net revenue, and includes the related shipping costs in cost of sales.

[0000068505-17-000002:notes:355]
The Company sells software and equipment obtained from other companies.  The Company establishes its own pricing and retains related inventory risk, is the primary obligor in sales transactions with customers, and assumes the credit risk for amounts billed to customers. Accordingly, the Company generally recognizes revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-17-000002:notes:356]
Long-Term Contracts

[0000068505-17-000002:notes:357]
For long-term contracts that involve customization of equipment and/or software, the Company generally recognizes revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). The components of estimated costs to complete a contract and management’s process for reviewing Estimated Costs at Completion and progress toward completion are discussed further below.  Contracts may be combined or segmented in accordance with the applicable criteria under contract accounting principles.  In certain instances, when revenues or costs associated with long-term contracts cannot be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained.

[0000068505-17-000002:notes:358]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs.  Due to the nature of the work required to be performed under many of the Company’s long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables.  The Company has a standard and disciplined quarterly Estimated Costs at Completion process in which management reviews the progress and performance of open contracts. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors, among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. These adjustments may result from positive project performance, and may result in an increase in operating income during the performance of individual contracts. Likewise, these adjustments may result in a decrease in operating income if Estimated Costs at Completion increase. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on Operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2016, 2015, and 2014.  When estimates of total costs to be incurred on a contract exceed total estimates of revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-17-000002:notes:359]
Hardware and Software Services Support

[0000068505-17-000002:notes:360]
Revenue under equipment and software maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term.

[0000068505-17-000002:notes:361]
Software and Licenses

[0000068505-17-000002:notes:362]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other revenue recognition criteria are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period of the license.

[0000068505-17-000002:notes:363]
Multiple-Element Arrangements

[0000068505-17-000002:notes:364]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements that include products containing software that functions together with the equipment to deliver its essential functionality, undelivered software elements that relate to the product's essential software, and undelivered non-software services deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in the control of the Company.

[0000068505-17-000002:notes:365]
In these arrangements, the Company allocates revenue to all deliverables based on their relative selling prices.  The Company uses the following hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence (“VSOE”) of fair value, (ii) third-party evidence (“TPE”) of selling price, and (iii) best estimate of selling price (“ESP”).

[0000068505-17-000002:notes:366]
The Company determines VSOE based on its normal pricing and discounting practices for the specific product or service when that same product or service is sold separately. In determining VSOE, the Company requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate.

[0000068505-17-000002:notes:367]
When VSOE does not exist, the Company attempts to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, the Company's go-to-market strategy for many of its products differs from that of its competitors and its offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold by other companies cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE.

[0000068505-17-000002:notes:368]
When both VSOE and TPE are unavailable, the Company uses ESP. The Company determines ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product, and other inputs based on its normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0000068505-17-000002:notes:369]
The Company also considers the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE, TPE, and ESP.

[0000068505-17-000002:notes:370]
Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above.

[0000068505-17-000002:notes:371]
The Company's arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. The revenue for these multiple-element arrangements is allocated to the software deliverable(s) and the non-software deliverable(s) based on the relative selling prices of all of the deliverables in the arrangement using the fair value hierarchy outlined above. In circumstances where the Company cannot determine VSOE or TPE of the selling price for any of the deliverables in the arrangement, ESP is used for the purpose of allocating the arrangement consideration between software and non-software deliverables.

[0000068505-17-000002:notes:372]
The Company allocates arrangement consideration to multiple software or software-related deliverables, including the sale of software upgrades or software support agreements to previously sold software, in accordance with software accounting guidance. For such arrangements, revenue is allocated to the deliverables based on the relative fair value of each element, and fair value is determined using VSOE. Where VSOE does not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established, whichever occurs first. When the final undelivered software element is post contract support, service revenue is recognized on a ratable basis over the remaining service period.  When VSOE of a delivered element has not been established, but VSOE exists for the undelivered elements, the Company uses the residual method to recognize revenue when the fair value of all undelivered elements is determinable. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the arrangement consideration is allocated to the delivered elements and is recognized as revenue.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000068505-17-000002:notes:373]
|  | Net Sales |  | Assets |
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| United States | $ | 3,566 |  |  | $ | 3,473 |  |  | $ | 3,354 |  |  | $ | 5,653 |  |  | $ | 6,213 |  |  | $ | 8,468 |  |
| United Kingdom | 528 |  |  | 96 |  |  | 128 |  |  | 2,300 |  |  | 1,127 |  |  | 966 |  |
| Other, net of eliminations | 1,944 |  |  | 2,126 |  |  | 2,399 |  |  | 510 |  |  | 1,006 |  |  | 989 |  |
|  | $ | 6,038 |  |  | $ | 5,695 |  |  | $ | 5,881 |  |  | $ | 8,463 |  |  | $ | 8,346 |  |  | $ | 10,423 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-17-000002:notes:374]
The following table summarizes Net sales and Operating earnings by segment:

[0000068505-17-000002:notes:375]
|  | Net Sales |  | Operating Earnings (Loss) |
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Products | $ | 3,649 |  |  | $ | 3,676 |  |  | $ | 3,807 |  |  | $ | 734 |  |  | $ | 704 |  |  | $ | (667 | ) |
| Services | 2,389 |  |  | 2,019 |  |  | 2,074 |  |  | 333 |  |  | 290 |  |  | (339 | ) |
|  | $ | 6,038 |  |  | $ | 5,695 |  |  | $ | 5,881 |  |  | 1,067 |  |  | 994 |  |  | (1,006 | ) |
| Total other expense |  |  |  |  |  |  | (223 | ) |  | (77 | ) |  | (155 | ) |
| Earnings (loss) from continuing operations before income taxes |  |  |  |  |  |  | $ | 844 |  |  | $ | 917 |  |  | $ | (1,161 | ) |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000068505-17-000002:notes:376]
Valuation and Qualifying Accounts


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-17-000002:notes:377]
Information by Segment and Geographic Region

[0000068505-17-000002:notes:378]
The Company conducts its business globally and manages it through the following two segments:

[0000068505-17-000002:notes:379]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle-mounted radios, accessories, software features, and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In 2016, the segment’s net sales were $3.6 billion, representing 60% of the Company's consolidated net sales.

[0000068505-17-000002:notes:380]
Services: The Services segment provides a full set of offerings for government, public safety and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes implementation, optimization, and integration of networks, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support and hardware maintenance. More advanced offerings include network monitoring, software maintenance and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services and SaaS offerings are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2016, the segment’s net sales were $2.4 billion, representing 40% of the Company's consolidated net sales.

[0000068505-17-000002:notes:381]
For the years ended December 31, 2016, 2015 and 2014, no single customer accounted for more than 10% of the Company's net sales.

[0000068505-17-000002:notes:382]
Segment Information

[0000068505-17-000002:notes:383]
The Company's "chief operating decision maker" does not review or allocate resources based on segment assets.

[0000068505-17-000002:notes:384]
Geographic Area Information


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000068505-17-000002:notes:385]
Summary of Significant Accounting Policies

[0000068505-17-000002:notes:386]
Principles of Consolidation:  The consolidated financial statements include the accounts of Motorola Solutions, Inc. (the “Company” or “Motorola Solutions”) and all controlled subsidiaries. All intercompany transactions and balances have been eliminated.

[0000068505-17-000002:notes:387]
Use of Estimates:   The preparation of financial statements in conformity with United States ("U.S.") Generally Accepted Accounting Principles ("GAAP") requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.

[0000068505-17-000002:notes:388]
Revenue Recognition:   Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its products and services due to the needs of its customers. The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. The Company recognizes revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  The Company recognizes revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) stand alone sales of software products or software upgrades, (ii) stand alone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-17-000002:notes:389]
Cash Equivalents:    The Company considers all highly-liquid investments purchased with an original maturity of three months or less to be cash equivalents. Restricted cash was $63 million at both December 31, 2016 and December 31, 2015.

[0000068505-17-000002:notes:390]
Investments:    Investments in equity and debt securities classified as available-for-sale are carried at fair value.  When applicable, debt securities classified as held-to-maturity are carried at amortized cost. Equity securities that are restricted for more than one year or that are not publicly traded are carried at cost. Certain investments are accounted for using the equity method if the Company has significant influence over the issuing entity.

[0000068505-17-000002:notes:391]
Inventories:    Inventories are valued at the lower of average cost (which approximates cost on a first-in, first-out basis) or market (net realizable value or replacement cost).

[0000068505-17-000002:notes:392]
Property, Plant and Equipment:    Property, plant and equipment are stated at cost less accumulated depreciation. Depreciation is recorded on a straight-line basis, based on the estimated useful lives of the assets (buildings and building equipment, five to forty years; machinery and equipment, two to ten years) and commences once the assets are ready for their intended use.

[0000068505-17-000002:notes:393]
Goodwill and Intangible Assets:    Goodwill is assessed for impairment at least annually at the reporting unit level. The Company performs its annual assessment of goodwill for impairment in the fourth quarter of each fiscal year.  The annual assessment is performed using the two-step goodwill test which may also include the optional qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount prior to performing the two-step goodwill impairment test.  If this is the case, the two-step goodwill impairment test is required. If it is more-likely-than-not that the fair value of a reporting unit is greater than its carrying amount, the two-step goodwill impairment test is not required.

[0000068505-17-000002:notes:394]
Impairment of Long-Lived Assets:    Long-lived assets, which include intangible assets, held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets may not be recoverable. The Company evaluates recoverability of assets to be held and used by comparing the carrying amount of an asset (group) to future net undiscounted cash flows to be generated by the asset (group). If an asset (group) is considered to be impaired, the impairment to be recognized is equal to the amount by which the carrying amount of the asset (group) exceeds the asset's (group's) fair value calculated using a discounted future cash flows analysis or market comparable analysis. Assets held for sale, if any, are reported at the lower of the carrying amount or fair value less cost to sell.

[0000068505-17-000002:notes:395]
Income Taxes:    The Company records deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company's deferred and other tax balances are based on management's interpretation of the tax regulations and rulings in numerous tax jurisdictions. Income tax expense and liabilities recognized by the Company also reflect its best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company's various tax planning strategies, and uncertain tax positions. Future tax authority rulings and changes in tax laws, changes in projected levels of taxable income, and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company.

[0000068505-17-000002:notes:396]
Sales and Use Taxes:     The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes, on a net basis with such taxes excluded from revenue.

[0000068505-17-000002:notes:397]
Long-term Receivables:    Long-term receivables include trade receivables where contractual terms of the note agreement are greater than one year. Long-term receivables are considered impaired when management determines collection of all amounts due according to the contractual terms of the note agreement, including principal and interest, is no longer probable. Impaired long-term receivables are valued based on the present value of expected future cash flows discounted at the receivable’s effective interest rate, or the fair value of the collateral if the receivable is collateral dependent. Interest income and late fees on impaired long-term receivables are recognized only when payments are received. Previously impaired long-term receivables are no longer considered impaired and are reclassified to performing when they have performed under a workout or restructuring for four consecutive quarters.

[0000068505-17-000002:notes:398]
Foreign Currency:    Certain of the Company’s non-U.S. operations use their respective local currency as their functional currency. Those operations that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date and revenues and expenses using rates that approximate those in effect during the period. The resulting translation adjustments are included as a component of Accumulated other comprehensive income (loss) in the Company’s consolidated balance sheets. For those operations that have the U.S. dollar as their functional currency, transactions denominated in the local currency are measured in U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets. Gains and losses from remeasurement of monetary assets and liabilities are included in Other within Other income (expense) within the Company’s consolidated statements of operations.

[0000068505-17-000002:notes:399]
Derivative Instruments:    Gains and losses on hedges of existing assets or liabilities are marked-to-market and the result is included in Other within Other income (expense) within the Company’s consolidated statements of operations. Certain financial instruments are used to hedge firm future commitments or forecasted transactions.  Gains and losses pertaining to those instruments that qualify for hedge accounting are deferred until such time as the underlying transactions are recognized and subsequently recognized in the same line within the consolidated statements of operations as the hedged item. Gains and losses pertaining to those instruments that do not qualify for hedge accounting are recorded immediately in Other income (expense) within the consolidated statements of operations.

[0000068505-17-000002:notes:400]
Earnings Per Share:    The Company calculates its basic earnings (loss) per share based on the weighted-average number of common shares issued and outstanding. Net earnings (loss) attributable to Motorola Solutions, Inc. is divided by the weighted average common shares outstanding during the period to arrive at the basic earnings (loss) per share. Diluted earnings (loss) per share is calculated by dividing net earnings (loss) attributable to Motorola Solutions, Inc. by the sum of the weighted average number of common shares used in the basic earnings (loss) per share calculation and the weighted average number of common shares that would be issued assuming exercise or conversion of all potentially dilutive securities, excluding those securities that would be anti-dilutive to the earnings (loss) per share calculation. Both basic and diluted earnings (loss) per share amounts are calculated for earnings (loss) from continuing operations and net earnings attributable to Motorola Solutions, Inc. for all periods presented.

[0000068505-17-000002:notes:401]
Share-Based Compensation Costs:    The Company grants share-based compensation awards and offers an employee stock purchase plan. The amount of compensation cost for these share-based awards is generally measured based on the fair value of the awards as of the date that the share-based awards are issued and adjusted to the estimated number of awards that are expected to vest. The fair values of stock options and stock appreciation rights are generally determined using a Black-Scholes option pricing model which incorporates assumptions about expected volatility, risk free rate, dividend yield, and expected life. Performance based stock options, performance-contingent stock options, and market stock units vest based on market conditions and are therefore measured under a Monte Carlo simulation in order to simulate a range of possible future unit prices for Motorola Solutions over the performance period. Compensation cost for share-based awards is recognized on a straight-line basis over the vesting period.

[0000068505-17-000002:notes:402]
Retirement Benefits:    The Company records annual expenses relating to its pension benefit and postretirement plans based on calculations which include various actuarial assumptions, including discount rates, assumed asset rates of return, compensation increases, and turnover rates. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends. The effects of the gains, losses, and prior service costs and credits are amortized either over the average service life or over the average remaining lifetime of the participants, depending on the number of active employees in the plan. The funded status, or projected benefit obligation less plan assets, for each plan, is reflected in the Company’s consolidated balance sheets using a December 31 measurement date.

[0000068505-17-000002:notes:403]
Recent Accounting Pronouncements:  In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods or services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.
