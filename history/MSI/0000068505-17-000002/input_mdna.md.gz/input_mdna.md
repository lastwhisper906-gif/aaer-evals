# MSI MD&A — 0000068505-17-000002


## mdna

[0000068505-17-000002:mdna:1]
Item 7: Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000068505-17-000002:mdna:2]
The following is a discussion and analysis of our financial position as of December 31, 2016 and 2015 and results of operations for each of the three years in the period ended December 31, 2016. This commentary should be read in conjunction with our consolidated financial statements and the notes thereto appearing under “Item 8: Financial Statements and Supplementary Data.”

[0000068505-17-000002:mdna:3]
Executive Overview

[0000068505-17-000002:mdna:4]
Recent Developments

[0000068505-17-000002:mdna:5]
On February 19, 2016, we completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which we invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. We will make a deferred cash payment of £64 million on November 15, 2018. We funded the investment with a $675 million term loan (the "Term Loan"), which was subsequently repaid on December 30, 2016, and approximately $400 million of international cash on hand. The acquisition of GDCL enables us to geographically diversify our global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers.

[0000068505-17-000002:mdna:6]
On November 10, 2016, we completed the acquisition of Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions, for a gross purchase price of $217 million using cash on hand. The acquisition expands our Command Center software and services portfolio and enables us to offer a full suite of solutions to a broader customer base.

[0000068505-17-000002:mdna:7]
During the year ended December 31, 2016, we relocated our global headquarters from Schaumburg, IL to Chicago, IL. The move provides us with access to key talent and allows the Company to optimize the Schaumburg campus for current space requirements.

[0000068505-17-000002:mdna:8]
Our Business

[0000068505-17-000002:mdna:9]
We are a leading global provider of mission-critical communication infrastructure, devices, accessories, software, and services. Our products and services help government, public safety, and commercial customers improve their operations through increased effectiveness, efficiency, and safety of their mobile workforces. We serve our customers with a global footprint of sales in more than 100 countries and 14,000 employees worldwide based on our industry leading innovation and a deep portfolio of products and services.

[0000068505-17-000002:mdna:10]
We conduct our business globally and manage it by two segments:

[0000068505-17-000002:mdna:11]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In 2016, the segment’s net sales were $3.6 billion, representing 60% of our consolidated net sales.

[0000068505-17-000002:mdna:12]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services and SaaS offerings are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In 2016, the segment’s net sales were $2.4 billion, representing 40% of our consolidated net sales.

[0000068505-17-000002:mdna:13]
Trends Affecting Our Business

[0000068505-17-000002:mdna:14]
Impact of Macroeconomic Conditions: The stronger U.S. dollar and weakening economic conditions have had a negative impact on sales, particularly in Latin America, parts of EMEA, and China. Additionally, the strengthening dollar has reduced the purchasing power of our customers, and economic challenges have negatively impacted government budgets and funds available for the purchase of our products in these regions.

[0000068505-17-000002:mdna:15]
The impact of foreign exchange rate fluctuations on net earnings is mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sales, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion of our operating expenses are denominated in foreign currencies as a result of our offshore R&D and selling, general, and administrative ("SG&A") footprint.

[0000068505-17-000002:mdna:16]
Growth of Our Services Portfolio: Our Services segment is expected to grow at a higher rate than our Products segment. Overall, the Services segment has a lower gross margin percentage than the Products segment, but we expect consolidated operating margins to continue to expand.

[0000068505-17-000002:mdna:17]
iDEN: We have experienced a downward trend in iDEN product and services sales over recent years due to decreased demand as a result of the dated nature of the technology. We expect the downward trend to continue as service contracts expire and new technology replaces iDEN equipment in the marketplace. This trend primarily relates to our Services segment as the majority of iDEN sales are hardware and software maintenance services. The expected decline in iDEN sales of approximately $50 million in 2017 will impact both revenues and gross margins within the Services segment as iDEN services’ gross margins are generally higher than the remainder of our services portfolio.

[0000068505-17-000002:mdna:18]
Change in Presentation

[0000068505-17-000002:mdna:19]
During the first quarter of 2016, we restructured our regions operationally combining the Europe and Africa and Middle East regions into one region which is now reflected as Europe, Middle East, and Africa ("EMEA"). Accordingly, we now report net sales in the following four geographic regions: North America, Latin America, EMEA, and Asia Pacific ("AP"). We have updated all periods presented to reflect this change in presentation.

[0000068505-17-000002:mdna:20]
2016 financial results and accomplishments

[0000068505-17-000002:mdna:21]
| • | Ended 2016 with a record backlog position of $8.4 billion, up 29% compared to 2015 |

[0000068505-17-000002:mdna:22]
| • | Net sales were $6.0 billion in 2016 compared to $5.7 billion in 2015. Net sales grew in EMEA, including $462 million from the acquisition of GDCL, North America and AP |

[0000068505-17-000002:mdna:23]
| • | Operating earnings were $1.1 billion in 2016, compared to $1.0 billion in 2015 |

[0000068505-17-000002:mdna:24]
| • | Earnings from continuing operations were $560 million, or $3.24 per diluted common share in 2016, compared to earnings of $640 million, or $3.17 per diluted common share in 2015 |

[0000068505-17-000002:mdna:25]
| • | Operating cash flow increased $144 million to $1.2 billion in 2016 |

[0000068505-17-000002:mdna:26]
| • | Returned $1.1 billion of capital in the form of $842 million in share repurchases and $280 million in dividends 2016 |

[0000068505-17-000002:mdna:27]
| • | Invested $1.3 billion in four acquisitions of software and services companies |

[0000068505-17-000002:mdna:28]
| • | Increased our quarterly dividend by 15% to $0.47 per share in November 2016 |

[0000068505-17-000002:mdna:29]
Financial results for our two segments in 2016

[0000068505-17-000002:mdna:30]
| • | In the Products segment, net sales were $3.6 billion in 2016, a decrease of $27 million, or 1%, compared to $3.7 billion in 2015. On a geographic basis, net sales decreased in EMEA and Latin America and increased in North America and AP, compared to 2015. Operating earnings were $734 million in 2016, compared to $704 million in 2015. Operating margin increased in 2016 to 20.1% from 19.2% in 2015. |

[0000068505-17-000002:mdna:31]
| • | In the Services segment, net sales were $2.4 billion in 2016, an increase of $370 million, or 18%, compared to $2.0 billion in 2015. Managed & Support services grew 49% primarily due to the acquisition of GDCL. Managed & Support services grew 5% organically. On a geographic basis, net sales increased in EMEA, North America, and AP and decreased in LA compared to 2015. Operating earnings were $333 million in 2016, compared to $290 million in 2015. Operating margin decreased in 2016 to 13.9% from 14.4% in 2015. |

[0000068505-17-000002:mdna:32]
Looking Forward

[0000068505-17-000002:mdna:33]
We remain committed to driving shareholder value with revenue growth, operating leverage, cash flow generation, and efficient capital deployment. We strive to optimize our capital structure to enable prioritized investments in the business and targeted acquisitions as a source of generating solid future operating cash flows.  These potential investments are balanced against returning excess capital to shareholders through dividends and share repurchases. We expect to continue the quarterly dividends that were initiated in 2011, as well as the opportunity to return capital to shareholders through share repurchases. Our share repurchase program has approximately $2.2 billion of authority available as of December 31, 2016.

[0000068505-17-000002:mdna:34]
Entering 2017, we believe we are well-positioned to compete in both our core markets and adjacent growth areas. We have a broad, compelling products and services portfolio specifically tailored for our mission-critical communications customer base that spans many layers of governments, public safety, and first responders, as well as commercial and industrial customers in a number of key verticals. As we add new products, features, and software upgrades, we ensure our solutions are interoperable and backward-compatible, enabling customers to confidently invest for their future needs while allowing them to utilize their prior investment in our technology.

[0000068505-17-000002:mdna:35]
Supplementing our traditional core business is our investment in our Managed & Support services business and software solutions in the Command Center. As communication networks have become increasingly complex, software-centric, and data-driven, we have shifted our offerings to align with this technology trend in serving our customers. We expect to continue to see growing demands for our Managed & Support services going forward. These services offerings help customers manage, support, and upgrade their networks as well as utilize features, applications, and data in new ways including predictive policing, proactive support, or smarter response strategies. We expect our overall revenue mix to continue to shift towards software and services over time. On February 19, 2016, the Company expanded our Managed & Support services business with the acquisition of GDCL, the largest private operator of a public safety network in the world, delivering mission-critical voice and data communications to more than 300 public service agencies in Great Britain. Additionally, we expanded our software solutions

[0000068505-17-000002:mdna:36]
portfolio in 2016 with the acquisition of three software and services businesses that provide software solutions in the Command Center and mobile applications for public safety.

[0000068505-17-000002:mdna:37]
Another key technology trend complementing our existing business is the expanded use of broadband LTE by our customers. We have been proactively investing in next-generation public safety broadband solutions for years, as we believe public safety LTE solutions are the next-generation tool for our public safety first-responder customers. We believe our expertise in both public and private networks makes us uniquely qualified to provide these public safety broadband solutions to this customer base. We have now won the four largest public safety LTE network installations awarded to date and expect LTE sales to represent a larger portion of our revenue in the coming years.

[0000068505-17-000002:mdna:38]
28

[0000068505-17-000002:mdna:39]
Results of Operations

[0000068505-17-000002:mdna:40]
|  | Years ended December 31 |
| (Dollars in millions, except per share amounts) | 2016 |  | % ofSales ** |  | 2015 |  | % ofSales ** |  | 2014 |  | % ofSales ** |
| Net sales from products | $ | 3,649 |  |  |  |  | $ | 3,676 |  |  |  |  | $ | 3,807 |  |  |  |
| Net sales from services | 2,389 |  |  |  |  | 2,019 |  |  |  |  | 2,074 |  |  |  |
| Net sales | 6,038 |  |  |  |  | 5,695 |  |  |  |  | 5,881 |  |  |  |
| Costs of product sales | 1,649 |  |  | 45.2 | % |  | 1,625 |  |  | 44.2 | % |  | 1,678 |  |  | 44.1 | % |
| Costs of services sales | 1,520 |  |  | 63.6 | % |  | 1,351 |  |  | 66.9 | % |  | 1,372 |  |  | 66.2 | % |
| Costs of sales | 3,169 |  |  | 52.5 | % |  | 2,976 |  |  | 52.3 | % |  | 3,050 |  |  | 51.9 | % |
| Gross margin | 2,869 |  |  | 47.5 | % |  | 2,719 |  |  | 47.7 | % |  | 2,831 |  |  | 48.1 | % |
| Selling, general and administrative expenses | 1,000 |  |  | 16.6 | % |  | 1,021 |  |  | 17.9 | % |  | 1,184 |  |  | 20.1 | % |
| Research and development expenditures | 553 |  |  | 9.2 | % |  | 620 |  |  | 10.9 | % |  | 681 |  |  | 11.6 | % |
| Other charges | 249 |  |  | 4.1 | % |  | 84 |  |  | 1.5 | % |  | 1,972 |  |  | 33.5 | % |
| Operating earnings (loss) | 1,067 |  |  | 17.7 | % |  | 994 |  |  | 17.5 | % |  | (1,006 | ) |  | (17.1 | )% |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (205 | ) |  | (3.4 | )% |  | (173 | ) |  | (3.0 | )% |  | (126 | ) |  | (2.1 | )% |
| Gains (losses) on sales of investments and businesses, net | (6 | ) |  | (0.1 | )% |  | 107 |  |  | 1.9 | % |  | 5 |  |  | 0.1 | % |
| Other | (12 | ) |  | (0.2 | )% |  | (11 | ) |  | (0.2 | )% |  | (34 | ) |  | (0.6 | )% |
| Total other expense | (223 | ) |  | (3.7 | )% |  | (77 | ) |  | (1.4 | )% |  | (155 | ) |  | (2.6 | )% |
| Earnings (loss) from continuing operations before income taxes | 844 |  |  | 14.0 | % |  | 917 |  |  | 16.1 | % |  | (1,161 | ) |  | (19.7 | )% |
| Income tax expense (benefit) | 282 |  |  | 4.7 | % |  | 274 |  |  | 4.8 | % |  | (465 | ) |  | (7.9 | )% |
| Earnings (loss) from continuing operations | 562 |  |  | 9.3 | % |  | 643 |  |  | 11.3 | % |  | (696 | ) |  | (11.8 | )% |
| Less: Earnings attributable to noncontrolling interests | 2 |  |  | — | % |  | 3 |  |  | 0.1 | % |  | 1 |  |  | — | % |
| Earnings (loss) from continuing operations* | 560 |  |  | 9.3 | % |  | 640 |  |  | 11.2 | % |  | (697 | ) |  | (11.9 | )% |
| Earnings (loss) from discontinued operations, net of tax | — |  |  | — | % |  | (30 | ) |  | (0.5 | )% |  | 1,996 |  |  | 33.9 | % |
| Net earnings* | $ | 560 |  |  | 9.3 | % |  | $ | 610 |  |  | 10.7 | % |  | $ | 1,299 |  |  | 22.1 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 3.24 |  |  |  |  | $ | 3.17 |  |  |  |  | $ | (2.84 | ) |  |  |
| Discontinued operations | — |  |  |  |  | (0.15 | ) |  |  |  | 8.13 |  |  |  |
| Earnings per diluted common share* | $ | 3.24 |  |  |  |  | $ | 3.02 |  |  |  |  | $ | 5.29 |  |  |  |

[0000068505-17-000002:mdna:41]
*    Amounts attributable to Motorola Solutions, Inc. common shareholders.

[0000068505-17-000002:mdna:42]
**    Percentages may not add due to rounding.

[0000068505-17-000002:mdna:43]
Geographic Market Sales by Locale of End Customer

[0000068505-17-000002:mdna:44]
|  | 2016 |  | 2015 |  | 2014 |
| North America | 63 | % |  | 65 | % |  | 61 | % |
| Latin America | 5 | % |  | 6 | % |  | 9 | % |
| EMEA | 21 | % |  | 17 | % |  | 19 | % |
| AP | 11 | % |  | 12 | % |  | 11 | % |
|  | 100 | % |  | 100 | % |  | 100 | % |

[0000068505-17-000002:mdna:45]
29

[0000068505-17-000002:mdna:46]
Results of Operations—2016 Compared to 2015

[0000068505-17-000002:mdna:47]
Net Sales

[0000068505-17-000002:mdna:48]
Net sales were $6.0 billion in 2016, up $343 million, or 6%, compared to $5.7 billion in 2015. The increase in net sales is reflective of growth in EMEA, North America, and AP partially offset by a decrease in Latin America. EMEA grew on Services sales, partially offset by lower Products sales. The increase in EMEA Services sales was due to expansion of our Managed & Support services, primarily from the acquisition of GDCL which provided $462 million of net sales during the year ended December 31, 2016. North America and AP grew on both Services and Products sales. The decrease in Latin America was the result of lower Products and Services sales primarily due to macroeconomic pressures.

[0000068505-17-000002:mdna:49]
Gross Margin

[0000068505-17-000002:mdna:50]
Gross margin was $2.9 billion, or 47.5% of net sales in 2016, compared to $2.7 billion, or 47.7% of net sales in 2015. The decrease in gross margin percentage was driven by higher employee separation costs as a result of headcount reductions, offset by gross margin expansion within the Services segment driven by our Managed & Support services portfolio, primarily due to the acquisition of GDCL, which has higher margins than our legacy portfolio.

[0000068505-17-000002:mdna:51]
Selling, General and Administrative Expenses

[0000068505-17-000002:mdna:52]
SG&A expenses decreased 2% to $1.0 billion, or 16.6% of net sales in 2016, compared to $1.0 billion, or 17.9% of net sales in 2015. The decrease in SG&A expenditures is primarily due to cost savings initiatives, including headcount reductions, partially offset by higher incentive compensation and acquisitions costs.

[0000068505-17-000002:mdna:53]
Research and Development Expenditures

[0000068505-17-000002:mdna:54]
R&D expenditures decreased 11% to $553 million, or 9.2% of net sales in 2016, compared to $620 million, or 10.9% of net sales in 2015. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, and (ii) the movement of employees to lower cost work sites.

[0000068505-17-000002:mdna:55]
Other Charges

[0000068505-17-000002:mdna:56]
We recorded net other charges of $249 million in 2016, compared to net charges of $84 million in 2015. The charges in 2016 included: (i) $113 million of charges relating to the amortization of intangibles, (ii) $97 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment on our corporate aircraft, (iii) $26 million of losses on settlements within a non-U.S. pension plan, and (iv) $13 million of transaction fees on the acquisition of GDCL. The charges in 2015 included: (i) $108 million of net reorganization of business charges, including a $31 million impairment of our corporate aircraft which was sold and (ii) $8 million of charges relating to the amortization of intangibles, partially offset by a $32 million non-U.S. pension curtailment gain. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-17-000002:mdna:57]
Net Interest Expense

[0000068505-17-000002:mdna:58]
Net interest expense was $205 million in 2016 compared to $173 million in 2015. The increase in net interest expense in 2016 compared to 2015 was a result of higher outstanding debt balances.

[0000068505-17-000002:mdna:59]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-17-000002:mdna:60]
Net losses on sales of investments and businesses were $6 million in 2016, compared to net gains on sales of investments and businesses of $107 million in 2015. The net losses in 2016 consisted primarily of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities and (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $20 million of gains on the sales of equity investments. The net gains in 2015 were related to the sales of equity investments.

[0000068505-17-000002:mdna:61]
Other

[0000068505-17-000002:mdna:62]
Net Other expense was $12 million in 2016, compared to $11 million in 2015. The net Other expense in 2016 was primarily comprised of: (i) a $56 million loss on derivative instruments, (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of GDCL, (iii) a $4 million investment impairment, and (iv) a $2 million loss on the extinguishment of long-term debt, partially offset by: (i) a $46 million foreign currency gain, (ii) $9 million of other non-operating gains, and (iii) a $5 million gain on equity method investments. The net Other expense in 2015 was primarily comprised of: (i) a $23 million foreign currency loss and (ii) a $6 million investment impairment, partially offset by: (i) a $7 million gain on derivative instruments, (ii) a $6 million gain on equity method investments, and (iii) $5 million of other non-operating gains.

[0000068505-17-000002:mdna:63]
Effective Tax Rate

[0000068505-17-000002:mdna:64]
We recorded $282 million of net tax expense in 2016, resulting in an effective tax rate of 33%, compared to $274 million of net tax expense in 2015, resulting in an effective tax rate of 30%. Our effective tax rate in 2016 and 2015 were lower than the U.S. statutory tax rate of 35% primarily due to lower tax rates on non-U.S. income.

[0000068505-17-000002:mdna:65]
Our effective tax rate will change from period to period based on non-recurring events, such as the settlement of income tax audits, changes in valuation allowances, and the tax impact of significant unusual or extraordinary items, as well as recurring factors including changes in the geographic mix of income and effects of various global income tax strategies.

[0000068505-17-000002:mdna:66]
30

[0000068505-17-000002:mdna:67]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-17-000002:mdna:68]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $560 million, or $3.24 per diluted share, in 2016, compared to $640 million, or $3.17 per diluted share, in 2015.

[0000068505-17-000002:mdna:69]
The decrease in earnings from continuing operations in 2016, as compared to 2015, was primarily driven by: (i) a $165 million increase in Other charges primarily due to the increase in intangible amortization expense and (ii) a $113 million decrease in Gains on sales of investments and businesses, partially offset by: (i) a $150 million increase in Gross margin, (ii) a $67 million decrease in R&D, and (iii) a $21 million decrease in SG&A. The increase in earnings from continuing operations per diluted share was driven by lower shares outstanding as a result of repurchases made through our ongoing share repurchase program, offset by a decrease in earnings from continuing operations.

[0000068505-17-000002:mdna:70]
Earnings from Discontinued Operations

[0000068505-17-000002:mdna:71]
In 2016, we reported no earnings from discontinued operations, compared to a loss from discontinued operations of $30 million, or $0.15 per diluted share, in 2015. The loss from discontinued operations in 2015 was related to the sale of the Enterprise business.

[0000068505-17-000002:mdna:72]
Results of Operations—2015 Compared to 2014

[0000068505-17-000002:mdna:73]
Net Sales

[0000068505-17-000002:mdna:74]
Net sales were $5.7 billion in 2015, down $186 million, or 3% compared to $5.9 billion in 2014. The decline in net sales is reflective of decreases in EMEA and Latin America, partially offset by growth in North America and AP. The decrease in EMEA and Latin America was primarily the result of lower Products and Services sales, driven by challenging macroeconomic conditions in Latin America and Eastern Europe, and foreign exchange rate unfavorability. North America grew on strong Products and Services sales and AP grew on stronger Products sales.

[0000068505-17-000002:mdna:75]
Gross Margin

[0000068505-17-000002:mdna:76]
Gross margin was $2.7 billion, or 47.7% of net sales in 2015, compared to $2.8 billion, or 48.1% of net sales in 2014. The  decrease in gross margin was primarily a result of foreign exchange rate unfavorability. The decrease in gross margin percentage is primarily attributable to a decrease in gross margin as a percentage of sales within the Services segment while the gross margin percentage of the Products segment remained relatively flat. The decrease in gross margin percentage in the Services segment was primarily driven by: (i) a decrease in North America Integration services margins due to the deployment of certain large projects at lower gross margins and (ii) lower net sales in iDEN services which have a slightly higher gross margin percentage compared to the rest of the services portfolio.

[0000068505-17-000002:mdna:77]
Selling, General and Administrative Expenses

[0000068505-17-000002:mdna:78]
SG&A expenses decreased 14% to $1.0 billion, or 17.9% of net sales in 2015, compared to $1.2 billion, or 20.1% of net sales in 2014. The decrease in SG&A is primarily due to: (i) cost savings initiatives, including headcount reductions, (ii) lower pension expenses, and (iii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-17-000002:mdna:79]
Research and Development Expenditures

[0000068505-17-000002:mdna:80]
R&D expenditures decreased 9% to $620 million, or 10.9% of net sales in 2015, compared to $681 million, or 11.6% of net sales in 2014. The decrease in R&D expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, and the movement of employees to lower cost work sites and (ii) the favorable impact of foreign exchange rates, partially offset by higher incentive compensation accruals.

[0000068505-17-000002:mdna:81]
Other Charges

[0000068505-17-000002:mdna:82]
We recorded net charges of $84 million in 2015, compared to net charges of $2.0 billion in 2014. The charges in 2015 included: (i) $108 million of net reorganization of business charges, including a $31 million impairment of the corporate aircraft and (ii) $8 million of charges relating to the amortization of intangibles, partially offset by a $32 million non-U.S. pension curtailment gain. The charges in 2014 included: (i) a $1.9 billion charge related to the settlement of a U.S. pension plan, (ii) $64 million of net reorganization of business charges, (iii) $8 million of legal settlement charges, and (iv) $4 million of charges relating to the amortization of intangibles, partially offset by a $21 million gain on the sale of a building and land. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-17-000002:mdna:83]
Net Interest Expense

[0000068505-17-000002:mdna:84]
Net interest expense was $173 million in 2015, compared to net interest expense of $126 million in 2014. The increase in interest expense in 2015 compared to 2014 was a result of higher outstanding debt balances.

[0000068505-17-000002:mdna:85]
Gains (losses) on Sales of Investments and Businesses, net

[0000068505-17-000002:mdna:86]
Net gains on sales of investments and businesses were $107 million in 2015, compared to $5 million in 2014. The net gains in 2015 and 2014 were related to the sales of equity investments.

[0000068505-17-000002:mdna:87]
Other

[0000068505-17-000002:mdna:88]
Net Other expense was $11 million in 2015, compared to net Other expense of $34 million in 2014. The net Other expense in 2015 was primarily comprised of: (i) a $23 million foreign currency loss and (ii) a $6 million investment impairment, partially offset by: (i) a $7 million gain on derivative instruments, (ii) a $6 million gain on equity method investments, and (iii) $5 million of other non-operating gains. Net Other expense in 2014 was primarily comprised of: (i) a $37 million loss on the extinguishment of debt, (ii) a $4 million loss on derivative instruments, (iii) a $3 million foreign currency loss, and (iv) $6 million of other non-operating losses, partially offset by a $16 million gain on equity method investments.

[0000068505-17-000002:mdna:89]
Effective Tax Rate

[0000068505-17-000002:mdna:90]
We recorded a $274 million net tax expense in 2015, resulting in an effective tax rate of 30%, compared to $465 million of net tax benefit in 2014, resulting in an effective tax rate of 40%. Our effective tax rate in 2015 was lower than the U.S. statutory tax rate of 35% primarily due to lower tax rates on non-U.S. income.

[0000068505-17-000002:mdna:91]
Our effective tax rate in 2014 was favorably impacted by: (i) state tax benefits on the pension settlement loss, (ii) $29 million in tax benefits associated with the net reduction in unrecognized tax benefits, and (iii) $19 million in net reduction in our deferred tax liability for undistributed foreign earnings primarily due to changes in permanent reinvestment assertions. These benefits were partially offset by tax expense for the establishment of a $55 million valuation allowance on certain foreign deferred tax assets.

[0000068505-17-000002:mdna:92]
Earnings (Loss) from Continuing Operations Attributable to Motorola Solutions, Inc.

[0000068505-17-000002:mdna:93]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $640 million, or $3.17 per diluted share, in 2015, compared to a net loss from continuing operations attributable to Motorola Solutions, Inc. of $697 million, or a loss of $2.84 per diluted share, in 2014.

[0000068505-17-000002:mdna:94]
The increase in earnings (loss) from continuing operations in 2015, as compared to 2014, was primarily driven by: (i) a $1.9 billion decrease in Other charges, (ii) a $163 million decrease in SG&A, and (ii) a $61 million decrease in R&D. The increase in earnings from continuing operations per diluted share was driven by a reduction in shares outstanding, primarily as a result of our "Dutch auction" tender offer, as well as repurchases made through our ongoing share repurchase program, and an increase in earnings from continuing operations.

[0000068505-17-000002:mdna:95]
Earnings from Discontinued Operations

[0000068505-17-000002:mdna:96]
In 2015, we reported a $30 million, or $0.15 per diluted share, loss from discontinued operations, compared to earnings from discontinued operations of $2.0 billion, or $8.13 per diluted share, in 2014. The earnings (loss) from discontinued operations in both 2015 and 2014 were primarily related to the sale of the Enterprise business.

[0000068505-17-000002:mdna:97]
Segment Information

[0000068505-17-000002:mdna:98]
The following commentary should be read in conjunction with the financial results of each operating business segment as detailed in Note 12, “Information by Segment and Geographic Region,” of our consolidated financial statements. Net sales and operating results for our two segments for 2016, 2015, and 2014 are presented below.

[0000068505-17-000002:mdna:99]
Products Segment

[0000068505-17-000002:mdna:100]
The Products segment’s net sales represented 60% of our consolidated net sales in 2016, compared to 65% in 2015 and  2014.

[0000068505-17-000002:mdna:101]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2016 |  | 2015 |  | 2014 |  | 2016—2015 |  | 2015—2014 |
| Segment net sales | $ | 3,649 |  |  | $ | 3,676 |  |  | $ | 3,807 |  |  | (1 | )% |  | (3 | )% |
| Operating earnings (loss) | 734 |  |  | 704 |  |  | (667 | ) |  | 4 | % |  | N/M |  |

[0000068505-17-000002:mdna:102]
* N/M = Percent Change is not meaningful due to the comparison using prior year operating losses as a basis for the calculation.

[0000068505-17-000002:mdna:103]
Segment Results—2016 Compared to 2015

[0000068505-17-000002:mdna:104]
The segment’s net sales decreased $27 million, or 1%, to $3.6 billion in 2016, as compared to $3.7 billion in 2015. The decrease in the segment's net sales was primarily driven by: (i) a decrease in global systems sales, (ii) decreases in both devices and systems sales in Latin America primarily due to macroeconomic conditions, and (iii) unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP, partially offset by growth in devices in NA. On a geographic basis, net sales decreased in EMEA and Latin America and increased in North America and AP in 2016, compared to 2015. The segment's backlog was $1.5 billion at December 31, 2016 and $1.2 billion at December 31, 2015.

[0000068505-17-000002:mdna:105]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 69% of the segment’s net sales in 2016, up from 67% of the segment’s net sales in 2015.

[0000068505-17-000002:mdna:106]
The segment had operating earnings of $734 million in 2016, compared to $704 million in 2015. The increase in operating earnings in 2016 compared to 2015 was driven primarily by: (i) lower SG&A and R&D expenditures as a result of cost savings initiatives including headcount reductions, partially offset by an increase in Other charges.

[0000068505-17-000002:mdna:107]
Segment Results—2015 Compared to 2014

[0000068505-17-000002:mdna:108]
The segment’s net sales decreased $131 million, or 3%, to $3.7 billion in 2015, as compared to $3.8 billion in 2014. The decrease in the segment's net sales was primarily driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP, (ii) decreases in devices and systems sales in Latin America and EMEA impacted by the reduced purchasing power of our customers caused by the devaluation of their local currency and macroeconomic conditions, (iii) a decrease in systems sales in North America, and (iv) a decline in devices sales in AP, partially offset by: (i) growth in devices sales in North America and (ii) increased systems sales in AP. On a geographic basis, net sales decreased in EMEA and Latin America and increased in North America and AP in 2015, compared to 2014. The segment's backlog was $1.2 billion at both December 31, 2015 and December 31, 2014.

[0000068505-17-000002:mdna:109]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 67% of the segment’s net sales in 2015, up from 62% of the segment’s net sales in 2014.

[0000068505-17-000002:mdna:110]
The segment had operating earnings of $704 million in 2015, compared to an operating loss of $667 million in 2014. The increase in operating earnings in 2015 compared to 2014 was driven primarily by: (i) a decrease in Other charges as a result of a $1.3 billion expense related to the 2014 settlement of a U.S. pension plan, (ii) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses, and (iii) lower R&D expenditures driven by cost savings initiatives and the favorable impact of foreign exchange rates.

[0000068505-17-000002:mdna:111]
Services Segment

[0000068505-17-000002:mdna:112]
The Services segment’s net sales represented 40% of our consolidated net sales in 2016, compared to 35% in 2015 and 2014 respectively.

[0000068505-17-000002:mdna:113]
|  | Years ended December 31 |  | Percent Change |
| (Dollars in millions) | 2016 |  | 2015 |  | 2014 |  | 2016—2015 |  | 2015—2014 |
| Segment net sales | $ | 2,389 |  |  | $ | 2,019 |  |  | $ | 2,074 |  |  | 18 | % |  | (3 | )% |
| Operating earnings (loss) | 333 |  |  | 290 |  |  | (339 | ) |  | 15 | % |  | N/M |  |

[0000068505-17-000002:mdna:114]
* N/M = Percent Change is not meaningful due to the comparison using prior year operating losses as a basis for the calculation.

[0000068505-17-000002:mdna:115]
Segment Results—2016 Compared to 2015

[0000068505-17-000002:mdna:116]
The segment’s net sales increased $370 million, or 18%, to $2.4 billion in 2016, as compared to $2.0 billion in 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both the acquisition of GDCL as well as organic growth. The acquisition of GDCL provided $462 million of net sales within EMEA during the year ended December 31, 2016, while the organic Managed & Support services business grew in North America and AP. This sales growth was partially offset by: (i) a decrease in Integration services sales, with a significant decrease in EMEA related to the winding down of a large system implementation, (ii) declining iDEN services sales in Latin America, and (iii) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales increased in EMEA, North America, and AP and decreased in Latin America in 2016, compared to 2015. The segment's backlog was $6.9 billion at December 31, 2016 and $5.2 billion at December 31, 2015. The increase in the segment's backlog in 2016 compared to 2015 was driven in part by $1.2 billion from the acquisition of GDCL.

[0000068505-17-000002:mdna:117]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 54% of the segment’s net sales in 2016, down from 62% of the segment’s net sales in 2015.

[0000068505-17-000002:mdna:118]
The segment had operating earnings of $333 million in 2016 compared to $290 million in 2015. The increase in operating earnings in 2016 compared to 2015 was driven primarily by: (i) increased sales volume generating higher gross margin on our Managed & Support services, primarily in EMEA due to the acquisition of GDCL, and (ii) lower SG&A expenditures due to cost savings initiatives, including headcount reductions, partially offset by an increase in Other charges, including $105 million of intangible amortization expense, primarily associated with the GDCL acquisition.

[0000068505-17-000002:mdna:119]
Segment Results—2015 Compared to 2014

[0000068505-17-000002:mdna:120]
The segment’s net sales decreased $55 million, or 3%, to $2.0 billion in 2015, as compared to $2.1 billion in 2014. The decrease in the segment's net sales was primarily driven by: (i) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP, (ii) lower Integration services sales, primarily in EMEA, related to the winding down of a large system implementation in Norway, and (iii) declining iDEN services sales in Latin America, partially offset by an increase in Managed & Support services in North America. On a geographic basis, net sales for 2015 decreased in EMEA, Latin America, and AP and increased in North America, compared to 2014. The segment's backlog was $5.2 billion at December 31, 2015 and $4.6 billion at December 31, 2014. The increase in the segment's backlog in 2015 compared to 2014 was driven in part by the United Kingdom government LTE contract awarded in 2015.

[0000068505-17-000002:mdna:121]
33

[0000068505-17-000002:mdna:122]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 62% of the segment’s net sales in 2015, up from 59% of the segment’s net sales in 2014.

[0000068505-17-000002:mdna:123]
The segment had operating earnings of $290 million in 2015, compared to an operating loss of $339 million in 2014. The increase in operating earnings in 2015 compared to 2014 was driven primarily by: (i) a decrease in Other charges as a result of a $584 million expense related to the 2014 settlement of a U.S. pension plan and (ii) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, the favorable impact of foreign exchange rates, and reduced pension expenses.

[0000068505-17-000002:mdna:124]
Reorganization of Businesses

[0000068505-17-000002:mdna:125]
During 2016 we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. In 2016, we recorded net reorganization of business charges of $140 million relating to the separation of 1,300 employees, of which 900 were indirect employees and 400 were direct employees. The $140 million of charges included $43 million recorded to Cost of sales and $97 million recorded to Other charges. Included in the aggregate $140 million are charges of: (i) $120 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-17-000002:mdna:126]
During 2015, we recorded net reorganization of business charges of $117 million relating to the separation of 1,100 employees, of which 900 were indirect employees and 200 were direct employees. The $117 million of charges in earnings from continuing operations included $9 million recorded to Cost of sales and $108 million recorded to Other charges. Included in the aggregate $117 million are charges of: (i) $74 million for employee separation costs, (ii) $31 million for the impairment of the corporate aircraft, (iii) $10 million for exit costs, and (iv) a $6 million building impairment charge, partially offset by $4 million of reversals for accruals no longer needed.

[0000068505-17-000002:mdna:127]
During 2014, we recorded net reorganization of business charges of $96 million relating to the separation of 1,200 employees, of which 900 were indirect employees and 300 were direct employees. Of these charges, $23 million was related to discontinued operations. The remaining $73 million of charges in earnings (loss) from continuing operations included $9 million recorded to Cost of sales and $64 million recorded to Other charges. Included in the aggregate $73 million are charges of: (i) $67 million for employee separation costs and (ii) $7 million related to charges for exit costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-17-000002:mdna:128]
The following table displays the net charges incurred by business segment:

[0000068505-17-000002:mdna:129]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Products | $ | 106 |  |  | $ | 84 |  |  | $ | 48 |  |
| Services | 34 |  |  | 33 |  |  | 25 |  |
|  | $ | 140 |  |  | $ | 117 |  |  | $ | 73 |  |

[0000068505-17-000002:mdna:130]
Cash payments for exit costs and employee severance in connection with the reorganization of business plans were $79 million, $71 million, and $148 million in 2016, 2015, and 2014, respectively. The reorganization of business accruals at December 31, 2016 were $101 million, of which $94 million relates to employee separation costs that are expected to be paid within one year and $7 million relates primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-17-000002:mdna:131]
Liquidity and Capital Resources

[0000068505-17-000002:mdna:132]
We decreased the aggregate of our cash and cash equivalent balances from $2.0 billion as of December 31, 2015 to $1.0 billion as of December 31, 2016. The decrease is primarily due to: (i)  $1.1 billion of capital returned to shareholders through share repurchases and dividends paid, and (ii) $1.0 billion paid in the acquisition of GDCL, offset by $1.2 billion of cash generated by operating activities.

[0000068505-17-000002:mdna:133]
As highlighted in the consolidated statements of cash flows, our liquidity and available capital resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0000068505-17-000002:mdna:134]
Cash and Cash Equivalents

[0000068505-17-000002:mdna:135]
At December 31, 2016, $575 million of the $1.0 billion cash and cash equivalents balance was held in the U.S. and $455 million was held by the Company or its subsidiaries in other countries, with approximately $138 million held in the United Kingdom. Restricted cash was approximately $63 million at both December 31, 2016 and December 31, 2015.

[0000068505-17-000002:mdna:136]
We continue to analyze and review various repatriation strategies to efficiently repatriate cash. In 2016, we repatriated approximately $288 million in cash to the U.S. from international jurisdictions. Undistributed earnings that we intend to reinvest indefinitely, and for which no U.S. income taxes have been provided, aggregate to $1.6 billion at December 31, 2016. We currently have no plans to repatriate the foreign earnings permanently reinvested. If circumstances change and it becomes

[0000068505-17-000002:mdna:137]
34

[0000068505-17-000002:mdna:138]
apparent that some or all of the permanently reinvested earnings will be remitted to the U.S. in the foreseeable future, an additional income tax charge may be necessary.

[0000068505-17-000002:mdna:139]
Where appropriate, we may also pursue capital reduction activities; however, such activities can be involved and lengthy.  While we regularly repatriate funds, and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of some of these funds may be subject to delay for local country approvals and could have potential adverse cash tax consequences.

[0000068505-17-000002:mdna:140]
Operating Activities

[0000068505-17-000002:mdna:141]
Net cash provided by operating activities from continuing operations in 2016 was $1.2 billion, compared to cash provided by operating activities from continuing operations of $1.0 billion in 2015 and cash used by operating activities from continuing operations of $637 million in 2014. Operating cash flows in 2016, as compared to 2015, were positively impacted by high earnings from continuing operations (adjusted for net non-cash charges), offset by higher employee incentive compensation payments. Operating cash flows in 2015, as compared to 2014, were positively impacted by: (i) an increase in earnings from continuing operations, (ii) reduced pension contributions, and (iii) higher sales of accounts receivable.

[0000068505-17-000002:mdna:142]
We made $3 million of contributions to our U.S. pension plans during 2016, compared to $3 million contributed in 2015, and $1.1 billion contributed in 2014. In addition, we contributed $8 million, $10 million, and $237 million to our Non-U.S. Pension Plans during 2016, 2015, and 2014, respectively. We expect to make approximately $9 million of cash contributions in 2017, primarily to our Non-U.S. Pension Benefit Plans in 2017.

[0000068505-17-000002:mdna:143]
Investing Activities

[0000068505-17-000002:mdna:144]
Net cash used by investing activities from continuing operations was $1 billion in 2016, compared to net cash used by investing activities from continuing operations of $528 million in 2015 and net cash provided by investing activities from continuing operations of $3.2 billion in 2014. The $474 million increase in net cash used by investing activities from 2015 to 2016 was primarily due to the acquisition of GDCL for $1.0 billion and Spillman for $217 million, offset by the sale of an investment of $382 million used to fund the acquisition of GDCL. The $3.7 billion decrease in net cash provided by investing activities from 2014 to 2015 was primarily due to proceeds provided by the sale of the Enterprise business in 2014 compared to cash used for a $401 million investment earmarked for the purchase of GDCL in 2015.

[0000068505-17-000002:mdna:145]
Acquisitions and Investments:  We used net cash of $1.5 billion for acquisitions and new investment activities in 2016, compared to $586 million in 2015, and $47 million in 2014. We paid cash of $1.0 billion during 2016 related to the acquisition of GDCL, $217 million for the acquisition of Spillman, and $26 million related to the acquisition of other software and services related businesses. The remainder of the cash was used for several debt and equity investments. In 2015, we invested $401 million in order to partially offset our foreign currency risk associated with the purchase of GDCL. We liquidated these investments in February 2016 to partially fund the acquisition. Additionally, we paid $49 million for the acquisition of two public safety software solution providers, as well as several debt and equity investments. The cash used in 2014 was for the acquisition of an equipment provider for $22 million and a number of equity investments.

[0000068505-17-000002:mdna:146]
Sales of Investments and Businesses:  We received $670 million of proceeds in 2016 compared to $230 million in 2015 and $3.4 billion in 2014. The $670 million of cash provided by investments in 2016 primarily consisted of: (i) $382 million from the sale of an investment used to finance the acquisition of GDCL, (ii) $242 million from the sales of various debt and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations. The $230 million of cash received in 2015 was primarily comprised of: (i) $49 million reimbursement from Zebra for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale, (ii) $107 million from the sale of two equity investments, (iii) $13 million net cash received from Zebra for the final purchase price adjustment, as well as for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest. The $3.4 billion of cash received in 2014 was primarily comprised of proceeds from the sale of the Enterprise business.

[0000068505-17-000002:mdna:147]
Capital Expenditures:  Capital expenditures were $271 million in 2016, compared to $175 million in 2015, and $181 million in 2014. The increase in capital spending in 2016, as compared to 2015, was primarily driven by a increase in revenue-generating network expenditures, information technology spend and facilities expenditures. The decrease in capital spending in 2015, as compared to 2014, was primarily driven by an decrease in revenue-generating network expenditures.

[0000068505-17-000002:mdna:148]
Sales of Property, Plant, and Equipment:  We had $73 million of proceeds related to the sale of property, plant, and equipment in 2016, compared to $3 million in 2015 and $33 million in 2014. The proceeds in 2016 were comprised of $54 million from the sale of buildings and land on the Schaumburg, IL campus and $19 million received from the sale of fixed assets. The proceeds in 2015 and 2014 were primarily comprised of sales of buildings and land.

[0000068505-17-000002:mdna:149]
Financing Activities

[0000068505-17-000002:mdna:150]
Net cash used for financing activities was $1.0 billion in 2016 compared to $2.4 billion in 2015 and $1.8 billion in 2014.  Cash used for financing activities in 2016 was primarily comprised of: (i) $842 million used for purchases of common stock under our share repurchase program and (ii) $280 million of cash used for the payment of dividends, partially offset by $93 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-17-000002:mdna:151]
Cash used for financing activities in 2015 was primarily comprised of: (i) $3.2 billion used for purchases of common stock under our share repurchase program and (ii) $277 million of cash used for the payment of dividends, partially offset by: (i) $971 million of net proceeds from the issuance of the Senior Convertible Notes and (ii) $84 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans.

[0000068505-17-000002:mdna:152]
Cash used for financing activities in 2014 was primarily comprised of: (i) $2.5 billion used for purchases of our common stock under our share repurchase program, (ii) $465 million of cash used for the repayment of debt, and (iii) $318 million of cash used for the payment of dividends, partially offset by: (i) $1.4 billion of net proceeds from the issuance of debt, (ii) $87 million of net proceeds from the issuance of common stock in connection with our employee stock option and employee stock purchase plans, and (iii) $93 million of distributions received from discontinued operations.

[0000068505-17-000002:mdna:153]
Current and Long-Term Debt:  We had outstanding long-term debt of $4.4 billion and $4.3 billion, including the current portions of $4 million, at December 31, 2016 and December 31, 2015, respectively.

[0000068505-17-000002:mdna:154]
On August 25, 2015, we entered into an agreement with Silver Lake Partners to issue $1.0 billion of 2% Senior Convertible Notes which mature in September 2020. Interest on these notes is payable semiannually. The notes are convertible anytime on or after two years from their issuance date, except in certain limited circumstances including, for example, if the volume weighted average price of the Company's stock exceeds $85 for ten consecutive trading days, then up to 20% of the notes may be transferred or converted to shares of Company stock. The notes are convertible based on a conversion rate of 14.5985 per $1,000 principal amount (which is equal to an initial conversion price of $68.50 per share). In the event of conversion, we intend to settle the principal amount of the Senior Convertible Notes in cash.

[0000068505-17-000002:mdna:155]
In connection with the completion of the acquisition of GDCL, we entered into a new term loan credit agreement (the “Term Loan Agreement”), under which we borrowed a term loan (the “Term Loan”) with an initial principal amount of $675 million. Interest on the Term Loan was variable and indexed to LIBOR. We have repaid all amounts borrowed under the Term Loan as of December 31, 2016.

[0000068505-17-000002:mdna:156]
We have investment grade ratings on our senior unsecured long-term debt from the three largest U.S. national rating agencies. We believe that we will be able to maintain sufficient access to the capital markets. Any future disruptions, uncertainty, volatility in the capital markets, or deterioration in our credit ratings may result in higher funding costs for us and adversely affect our ability to access funds.

[0000068505-17-000002:mdna:157]
We may, from time to time, seek to retire certain of our outstanding debt through open market cash purchases, privately-negotiated transactions or otherwise. Such repurchases, if any, will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors.

[0000068505-17-000002:mdna:158]
Share Repurchase Program:  Through actions taken on July 28, 2011, January 30, 2012, July 25, 2012, July 22, 2013, November 4, 2014, and August 3, 2016, the Board of Directors has authorized an aggregate share repurchase amount of up to $14.0 billion of our outstanding shares of common stock (the “share repurchase program”). The share repurchase program does not have an expiration date. As of December 31, 2016, we have used approximately $11.8 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving approximately $2.2 billion of authority available for future repurchases.

[0000068505-17-000002:mdna:159]
During 2016, we paid an aggregate of $842 million, including transaction costs, to repurchase 12.0 million shares at an average price of $70.28 per share. During 2015, we paid an aggregate of $3.2 billion, including transaction costs, to repurchase 48.0 million shares at an average price of $66.22. Shares repurchased in 2015 include 30.1 million shares repurchased under a modified "Dutch auction" tender offer at a tender price of $66.50 for an aggregate of $2.0 billion, including transaction costs. During 2014, we paid an aggregate of $2.5 billion, including transaction costs, to repurchase 39.4 million shares at an average price of $64.63.

[0000068505-17-000002:mdna:160]
Payment of Dividends:  We paid cash dividends to holders of our common stock of $280 million in 2016, $277 million in 2015, and $318 million in 2014. Subsequent to quarter end, we paid an additional $77 million in cash dividends to holders of our common stock.

[0000068505-17-000002:mdna:161]
Credit Facilities

[0000068505-17-000002:mdna:162]
As of December 31, 2016, we had a $2.1 billion unsecured syndicated revolving credit facility (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of December 31, 2016. We did not borrow under the 2014 Motorola Solutions Credit Agreement during the twelve months ended December 31, 2016.  No letters of credit were issued under the revolving credit facility as of December 31, 2016.

[0000068505-17-000002:mdna:163]
Contractual Obligations and Other Purchase Commitments

[0000068505-17-000002:mdna:164]
Summarized in the table and text below are our obligations and commitments to make future payments under long-term debt obligations, lease obligations, purchase obligations and tax obligations as of December 31, 2016.

[0000068505-17-000002:mdna:165]
|  | Payments Due by Period |
| (in millions) | Total |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | UncertainTimeframe |  | Thereafter |
| Long-term debt obligations | $ | 4,437 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 1,003 |  |  | $ | 400 |  |  | $ | — |  |  | $ | 3,020 |  |
| Lease obligations | 481 |  |  | 62 |  |  | 58 |  |  | 52 |  |  | 49 |  |  | 42 |  |  | — |  |  | 218 |  |
| Purchase obligations* | 169 |  |  | 125 |  |  | 30 |  |  | 9 |  |  | 4 |  |  | 1 |  |  | — |  |  | — |  |
| Tax obligations | 68 |  |  | 29 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 39 |  |  | — |  |
| Total contractual obligations | $ | 5,155 |  |  | $ | 220 |  |  | $ | 93 |  |  | $ | 66 |  |  | $ | 1,056 |  |  | $ | 443 |  |  | $ | 39 |  |  | $ | 3,238 |  |

[0000068505-17-000002:mdna:166]
*Amounts included represent firm, non-cancelable commitments.

[0000068505-17-000002:mdna:167]
Lease Obligations:  We lease certain office, factory and warehouse space, land, information technology and other equipment, principally under non-cancelable operating leases. Our future minimum lease obligations, net of minimum sublease rentals, totaled $481 million. Rental expense, net of sublease income, was $84 million in 2016, $42 million in 2015, and $62 million in 2014.

[0000068505-17-000002:mdna:168]
Purchase Obligations:  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. In addition, we have entered into software license agreements which are firm commitments and are not cancelable. We had entered into firm, noncancelable, and unconditional commitments under such arrangements through 2017. The total payments expected to be made under these agreements are $169 million, of which $168 million relate to take or pay obligations from arrangements with suppliers for the sourcing of inventory supplies and materials. We do not anticipate the cancellation of any of our take or pay agreements in the future and estimate that purchases from these suppliers will exceed the minimum obligations during the agreement periods.

[0000068505-17-000002:mdna:169]
Tax Obligations:  We have approximately $68 million of unrecognized income tax benefits relating to multiple tax jurisdictions and tax years. Based on the potential outcome of our global tax examinations, or the expiration of the statute of limitations for specific jurisdictions, it is reasonably possible that the unrecognized tax benefits will change within the next twelve months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $50 million tax charge to a $30 million tax benefit, with cash payments not expected to exceed $30 million.

[0000068505-17-000002:mdna:170]
Commitments Under Other Long-Term Agreements:  We have entered into certain long-term agreements to purchase software, components, supplies and materials from suppliers which are not "take or pay" in nature. Most of the agreements extend for periods of one to three years (three to five years for software). Generally, these agreements do not obligate us to make any purchases, and many permit us to terminate the agreement with advance notice (usually ranging from 60 to 180 days). If we were to terminate these agreements, we generally would be liable for certain termination charges, typically based on work performed and supplier on-hand inventory and raw materials attributable to canceled orders. Our liability would only arise in the event we terminate the agreements for reasons other than “cause.”

[0000068505-17-000002:mdna:171]
We outsource certain corporate functions, such as benefit administration and information technology-related services, under third-party contracts, the longest of which is expected to expire in 2019. Our remaining payments under these contracts are approximately $237 million over the remaining life of the contracts; however, these contracts can be terminated. Termination would result in a penalty substantially less than the remaining annual contract payments. We would also be required to find another source for these services, including the possibility of performing them in-house.

[0000068505-17-000002:mdna:172]
As is customary in bidding for and completing certain projects and pursuant to a practice we have followed for many years, we have a number of performance/bid bonds, standby letters of credit and surety bonds outstanding (collectively, referred to as “Performance Bonds”), primarily relating to projects with our government customers. These Performance Bonds normally have maturities of multiple years and are standard in the industry as a way to give customers a convenient mechanism to seek resolution if a contractor does not satisfy certain requirements under a contract. Typically, a customer can draw on the

[0000068505-17-000002:mdna:173]
Performance Bond only if we do not fulfill all terms of a project contract. If such an occasion occurred, we would be obligated to reimburse the institution that issued the Performance Bond for the amounts paid. In our long history, it has been rare for us to have a Performance Bond drawn upon. At December 31, 2016, outstanding Performance Bonds totaled approximately $2.2 billion, compared to $1.8 billion at December 31, 2015. Any future disruptions, uncertainty, or volatility in bank, insurance or capital markets, or a change in our credit ratings could adversely affect our ability to obtain Performance Bonds and may result in higher funding costs to obtain such Performance Bonds.

[0000068505-17-000002:mdna:174]
Off-Balance Sheet Arrangements:  At December 31, 2016, we had no significant off-balance sheet arrangements other than operating leases and guarantees to third parties as described in Note 11 to the consolidated financial statements and our obligation to settle the embedded conversion option under the Senior Convertible Notes described in Note 4 to the consolidated financial statements.

[0000068505-17-000002:mdna:175]
Long-term Customer Financing Commitments

[0000068505-17-000002:mdna:176]
Outstanding Commitments:  Certain purchasers of our products and services may request that we provide long-term financing (defined as financing with a term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the products and services. Our obligation to provide long-term financing may be conditioned on the issuance of a letter of credit in favor of us by a reputable bank to support the purchaser's credit or a pre-existing commitment from a reputable bank to purchase the long-term receivables from us. We had outstanding commitments to provide long-term financing to third-parties totaling $125 million at December 31, 2016, compared to $112 million at December 31, 2015.

[0000068505-17-000002:mdna:177]
Outstanding Long-Term Receivables:  We had non-current long-term receivables of $49 million at December 31, 2016, compared to $47 million at December 31, 2015. There were $2 million of allowances for losses in 2016 and $1 million of allowances for losses in 2015. These long-term receivables are generally interest bearing, with interest rates ranging from 0% to 11%.

[0000068505-17-000002:mdna:178]
Sales of Receivables

[0000068505-17-000002:mdna:179]
From time to time, we sell accounts receivable and long-term receivables to third-parties under one-time arrangements. We may or may not retain the obligation to service the sold accounts receivable and long-term receivables. Servicing obligations are limited to collection activities for sold accounts receivables and long-term receivables.

[0000068505-17-000002:mdna:180]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the years ended December 31, 2016, 2015, and 2014:

[0000068505-17-000002:mdna:181]
| Years ended December 31 | 2016 |  | 2015 |  | 2014 |
| Accounts receivable sales proceeds | $ | 51 |  |  | $ | 29 |  |  | $ | 50 |  |
| Long-term receivables sales proceeds | 289 |  |  | 196 |  |  | 124 |  |
| Total proceeds from receivable sales | $ | 340 |  |  | $ | 225 |  |  | $ | 174 |  |

[0000068505-17-000002:mdna:182]
At December 31, 2016, the Company had retained servicing obligations for $774 million of long-term receivables, compared to $668 million of long-term receivables at December 31, 2015. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-17-000002:mdna:183]
Adequate Internal Funding Resources

[0000068505-17-000002:mdna:184]
We believe that we have adequate internal resources available to fund expected working capital and capital expenditure requirements for the next twelve months as supported by the level of cash and cash equivalents in the U.S., the ability to repatriate funds from foreign jurisdictions, as well as cash provided by operations.

[0000068505-17-000002:mdna:185]
Other Contingencies

[0000068505-17-000002:mdna:186]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:  In certain circumstances, we enter into contracts with customers pursuant to which the damages that could be claimed by the customer for failed performance might exceed the revenue we receive from the contract. Contracts with these types of uncapped damages provisions are fairly rare, but individual contracts could still represent meaningful risk. There is a possibility that a claim by a counterparty to one of these contracts could result in expenses that are far in excess of the revenue received from the counterparty in connection with the contract.

[0000068505-17-000002:mdna:187]
Indemnification Provisions:  We may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial, intellectual property and divestiture agreements. Historically, we have not made significant payments under these agreements, nor have there been significant claims asserted against us. However, there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by us is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow us to challenge the other party’s claims. In some instances we may have recourse against third-parties for certain payments made by us. Further, our obligations under divestiture agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 18 months, and for amounts not in excess of a percentage of the contract value.

[0000068505-17-000002:mdna:188]
Legal Matters:  We are a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on our consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on our consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-17-000002:mdna:189]
Significant Accounting Policies

[0000068505-17-000002:mdna:190]
Management’s Discussion and Analysis of Financial Condition and Results of Operations discusses our consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP"). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period.

[0000068505-17-000002:mdna:191]
Management bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates.

[0000068505-17-000002:mdna:192]
Revenue Recognition

[0000068505-17-000002:mdna:193]
Net sales consist of a wide range of activities including the delivery of stand-alone equipment or services, custom design and installation over a period of time, and bundled sales of equipment, software and services. We enter into revenue arrangements that may consist of multiple deliverables of our products and services due to the needs of our customers. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectability of the sales price is reasonably assured. We recognize revenue from the sale of equipment, equipment containing both software and nonsoftware components that function together to deliver the equipment’s essential functionality, and services in accordance with general revenue recognition accounting principles.  We recognize revenue in accordance with software accounting guidance for the following types of sales transactions:  (i) stand alone sales of software products or software upgrades, (ii) stand alone sales of software maintenance agreements, and (iii) sales of software bundled with equipment where the software is not essential to the functionality of that equipment.

[0000068505-17-000002:mdna:194]
Products

[0000068505-17-000002:mdna:195]
For equipment sales, in addition to the criteria mentioned above, revenue recognition occurs when title and risk of loss has transferred to the customer, objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be reliably estimated. Recorded revenues are reduced by these allowances. We base our estimates of these allowances on historical experience taking into consideration the type of products sold, the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, we defer revenue until the incentive has been finalized with the customer.  We include shipping charges billed to customers in net revenue, and include the related shipping costs in cost of sales.

[0000068505-17-000002:mdna:196]
We sell software and equipment obtained from other companies.  We establish our own pricing and retain related inventory risk, are the primary obligor in sales transactions with customers, and assume the credit risk for amounts billed to customers. Accordingly, we generally recognize revenue for the sale of products obtained from other companies based on the gross amount billed.

[0000068505-17-000002:mdna:197]
Long-Term Contracts

[0000068505-17-000002:mdna:198]
For long-term contracts that involve customization of equipment and/or software, we generally recognize revenue using the percentage of completion method based on the percentage of costs incurred to date compared to the total estimated costs to complete the contract (“Estimated Costs at Completion”). The components of estimated costs to complete a contract and management’s process for reviewing Estimated Costs at Completion and progress toward completion are discussed further below.  Contracts may be combined or segmented in accordance with the applicable criteria under contract accounting principles.  In certain instances, when revenues or costs associated with long-term contracts cannot be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained.

[0000068505-17-000002:mdna:199]
Total Estimated Costs at Completion include direct labor, material and subcontracting costs.  Due to the nature of the work required to be performed under many of our long-term contracts, determining Estimated Costs at Completion is complex and subject to many variables. We have a standard and disciplined quarterly process in which management reviews the progress and performance of open contracts in order to determine the best estimate of Estimated Costs at Completion. As part of this process, management reviews information including, but not limited to, any outstanding key contract matters, progress towards completion, the project schedule, identified risks and opportunities, and the related changes in estimates of revenues and costs. The risks and opportunities include management's judgment about the ability and cost to achieve the project schedule, technical requirements, and other contract requirements. Management must make assumptions and estimates regarding labor productivity and availability, the complexity of the work to be performed, the availability of materials, and performance by subcontractors,

[0000068505-17-000002:mdna:200]
39

[0000068505-17-000002:mdna:201]
among other variables. Based on this analysis, any quarterly adjustments to net sales, cost of sales, and the related impact to operating income are recorded as necessary in the period they become known. These adjustments may result from positive project performance, and may result in an increase in operating income during the performance of individual contracts. Likewise, these adjustments may result in a decrease in operating income if Estimated Costs at Completion increase. Changes in estimates of net sales or cost of sales could affect the profitability of one or more of our contracts. The impact on operating earnings as a result of changes in Estimated Costs at Completion was not significant for the years 2016, 2015, and 2014.  When estimates of total costs to be incurred on a contract exceed estimates of total revenue to be earned, a provision for the entire loss on the contract is recorded in the period the loss is determined.

[0000068505-17-000002:mdna:202]
Hardware and Software Services Support

[0000068505-17-000002:mdna:203]
Revenue under equipment and software support and maintenance agreements, which do not contain specified future software upgrades, is recognized ratably over the contract term.

[0000068505-17-000002:mdna:204]
Software and Licenses

[0000068505-17-000002:mdna:205]
Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other revenue recognition criteria are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period of the license.

[0000068505-17-000002:mdna:206]
Multiple-Element Arrangements

[0000068505-17-000002:mdna:207]
Arrangements with customers may include multiple deliverables, including any combination of products, services and software. These multiple-element arrangements could also include an element accounted for as a long-term contract coupled with other products, services and software. For multiple-element arrangements that include products containing software that function together with the equipment to deliver its essential functionality, undelivered software elements that relate to the product's essential software, and undelivered non-software services, deliverables are separated into more than one unit of accounting when: (i) the delivered element(s) have value to the customer on a stand-alone basis and (ii) delivery of the undelivered element(s) is probable and substantially in our control.

[0000068505-17-000002:mdna:208]
In these arrangements, we allocate revenue to all deliverables based on their relative selling prices.  We use the following hierarchy to determine the selling price to be used for allocating revenue to deliverables: (i) vendor-specific objective evidence (“VSOE”) of fair value, (ii) third-party evidence (“TPE”) of selling price, and (iii) best estimate of selling price (“ESP”).

[0000068505-17-000002:mdna:209]
We determine VSOE based on our normal pricing and discounting practices for the specific product or service when that same product or service is sold separately. In determining VSOE, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate.

[0000068505-17-000002:mdna:210]
When VSOE does not exist, we attempt to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy for many of our products differs from that of our competitors and our offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold by other companies cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE.

[0000068505-17-000002:mdna:211]
When both VSOE and TPE are unavailable, we use ESP. We determine ESP by: (i) collecting all reasonably available data points including sales, cost and margin analysis of the product, and other inputs based on our normal pricing and discounting practices, (ii) making any reasonably required adjustments to the data based on market and Company-specific factors, and (iii) stratifying the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0000068505-17-000002:mdna:212]
We also consider the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE, TPE, and ESP.

[0000068505-17-000002:mdna:213]
Once elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as described above.

[0000068505-17-000002:mdna:214]
Our arrangements with multiple deliverables may also contain one or more software deliverables that are subject to software revenue recognition guidance. The revenue for these multiple-element arrangements is allocated to the software deliverable(s) and the non-software deliverable(s) based on the relative selling prices of all of the deliverables in the arrangement using the fair value hierarchy outlined above. In circumstances where we cannot determine VSOE or TPE for any of the deliverables in the arrangement, ESP is used for the purpose of allocating the arrangement consideration between software and non-software deliverables.

[0000068505-17-000002:mdna:215]
We allocate arrangement consideration to multiple software or software-related deliverables, including the sale of software upgrades or software support agreements to previously sold software, in accordance with software accounting guidance. For such arrangements, revenue is allocated to the deliverables based on the relative fair value of each element of the software, with fair value determined using VSOE. Where VSOE does not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established, whichever occurs first. When the final undelivered software element is post contract support, revenue is recognized on a ratable basis over the remaining service period. When VSOE of a delivered element has not been established, but VSOE exists for the undelivered elements, we use the residual method to recognize revenue when the fair value of all undelivered elements is determinable. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the arrangement consideration is allocated to the delivered elements and is recognized as revenue.

[0000068505-17-000002:mdna:216]
Inventory Valuation

[0000068505-17-000002:mdna:217]
We record valuation reserves on our inventory for estimated excess or obsolescence. The amount of the reserve is equal to the difference between the cost of the inventory and the estimated market value based upon assumptions about future demand and market conditions. On a quarterly basis, management performs an analysis based on future demand requirement estimates of the underlying inventory to identify reserves needed for excess and obsolescence. In addition, we adjust the carrying value of inventory if the current market value of that inventory is below our cost.

[0000068505-17-000002:mdna:218]
At December 31, 2016 and 2015, Inventories consisted of the following:

[0000068505-17-000002:mdna:219]
| December 31 | 2016 |  | 2015 |
| Finished goods | $ | 151 |  |  | $ | 151 |  |
| Work-in-process and production materials | 253 |  |  | 287 |  |
|  | 404 |  |  | 438 |  |
| Less inventory reserves | (131 | ) |  | (142 | ) |
|  | $ | 273 |  |  | $ | 296 |  |

[0000068505-17-000002:mdna:220]
We balance the need to maintain strategic inventory levels to ensure competitive delivery performance to our customers against the risk of inventory obsolescence due to changes in technology and customer requirements. As reflected above, our inventory reserves represented 33% of the gross inventory balance at December 31, 2016, compared to 32% of the gross inventory balance at December 31, 2015. We have inventory reserves for excess inventory, pending cancellations of product lines due to technology changes, long-life cycle products, lifetime buys at the end of supplier production runs, business exits, and a shift of production to outsourced manufacturing.

[0000068505-17-000002:mdna:221]
If future demand or market conditions are less favorable than those projected by management, additional inventory writedowns may be required.

[0000068505-17-000002:mdna:222]
Income Taxes

[0000068505-17-000002:mdna:223]
We record deferred income tax assets and liabilities based on the estimated future tax effects of differences between the financial and tax bases of assets and liabilities based on currently enacted tax laws. The Company’s deferred and other tax balances are based on management’s interpretation of the tax regulations and rulings in numerous taxing jurisdictions. Income tax expense and liabilities recognized by the Company also reflect our best estimates and assumptions regarding, among other things, the level of future taxable income, the effect of the Company’s various tax planning strategies and uncertain tax positions. Future tax authority rulings and changes in tax laws and projected levels of taxable income and future tax planning strategies could affect the actual effective tax rate and tax balances recorded by the Company. We evaluate deferred income tax asset balances on a quarterly basis to determine if valuation allowances are required by considering available evidence, including historical and projected taxable income and tax planning strategies that are both prudent and feasible. Tax related interest and penalties are classified as a component of interest expense.

[0000068505-17-000002:mdna:224]
Retirement Benefits

[0000068505-17-000002:mdna:225]
Our benefit obligations and net periodic pension cost (benefits) associated with our domestic noncontributory pension plans (“U.S. Pension Benefit Plans”), our foreign noncontributory pension plans (“Non-U.S. Plans”), as well as our domestic postretirement health care plan (“Postretirement Health Care Benefits”), are determined using actuarial assumptions.  The assumptions are based on management’s best estimates, after consulting with outside investment advisors and actuaries.

[0000068505-17-000002:mdna:226]
Accounting methodologies use an attribution approach that generally spreads the effects of individual events over the service lives of the participants in the plan, or estimated average lifetime when almost all of the plan participants are considered "inactive." Examples of “events” are plan amendments and changes in actuarial assumptions such as discount rate, expected long-term rate of return on plan assets, and rate of compensation increases.

[0000068505-17-000002:mdna:227]
There are various assumptions used in calculating the net periodic cost (benefit) and related benefit obligations. One of these assumptions is the expected long-term rate of return on plan assets. The required use of the expected long-term rate of return on plan assets may result in recognized pension income that is greater or less than the actual returns of those plan assets in any given year. Over time, however, the expected long-term returns are designed to approximate the actual long-term returns.   We use a five-year, market-related asset value method of recognizing asset related gains and losses.

[0000068505-17-000002:mdna:228]
We use long-term historical actual return experience with consideration of the expected investment mix of the plans’ assets, as well as future estimates of long-term investment returns, to develop our expected rate of return assumption used in calculating the net periodic pension cost and the net retirement healthcare expense. Our investment return assumption for the U.S. Pension Benefit Plans and Postretirement Healthcare Benefits Plan was 7.00% in both 2016 and 2015. Our investment return assumption for the Non-U.S. Plan was 5.90% in 2016 and 2015. At December 31, 2016, the pension plans, including the U.S. Pension Benefit Plans and Non-U.S. Plans investment portfolios were comprised of approximately 33% equity investments, while the Postretirement Health Care Benefits Plan was all comprised of approximately 37% equity investments .

[0000068505-17-000002:mdna:229]
A second key assumption is the discount rate. The discount rate assumptions used for pension benefits and postretirement health care benefits reflect, at December 31 of each year, the prevailing market rates for high-quality, fixed-income debt instruments that, if the obligation was settled at the measurement date, would provide the necessary future cash

[0000068505-17-000002:mdna:230]
flows to pay the benefit obligation when due. Our discount rates for measuring our U.S. pension benefit obligations were 4.42% and 4.73% at December 2016 and 2015, respectively. Our weighted average discount rates for measuring our Non-U.S. Plans were 2.54% and 3.57% at December 2016 and 2015, respectively. Our discount rates for measuring the Postretirement Health Care Benefits Plan obligation were 4.11% and 4.26% at December 31, 2016 and 2015, respectively.

[0000068505-17-000002:mdna:231]
Effective on January 1, 2016, we changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and Post retirement Health Care Benefit Plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. We have elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. We made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. We have concluded that this change is a change in estimate and, accordingly, will account for it prospectively beginning in 2016. The impact of the change in estimate is a reduction of the interest and service cost components within net periodic cost in 2016 by approximately $18 million for the U.S. Pension Benefit Plans, $4 million for the Non-U.S. Pension Benefit Plans, and $6 million for the Postretirement Health Care Benefits Plan compared to the prior year approach.

[0000068505-17-000002:mdna:232]
A final set of assumptions involves the cost drivers of the underlying benefits. The rate of compensation increase is determined based upon long-term plans for such increases. For the Non-U.S. defined benefit plan, we assumed a weighted average rate for future compensation increases of 0.46% and 0.41% for 2016 and 2015, respectively. During 2015, the Non-U.S. defined benefit plan within the United Kingdom was amended to close future benefit accruals to all participants effective December 31, 2015. As such, no compensation increases have been included in our estimates for the defined benefit plan within the United Kingdom. Benefits under the U.S. Pension Plans have been frozen, and therefore future compensation increases are no longer a relevant assumption in the calculation of the benefit obligation on those plans. Historically, the Company utilized health care cost trend rates to determine the accumulated benefit obligation and net periodic benefit. However, the Postretirement Health Care Benefits Plan was amended in 2014 such that all eligible participants would receive an annual subsidy for the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.  As such, assumptions over increases in health care costs are no longer considered necessary to determine the accumulated postretirement benefit obligation.

[0000068505-17-000002:mdna:233]
Under relevant accounting rules, when almost all of the plan participants are considered inactive, the amortization period for certain unrecognized losses changes from the average remaining service period to the average remaining lifetime of the participant. As such, depending on the specific plan, we amortize gains and losses over periods ranging from eleven to thirty-four years. Prior service costs are being amortized over periods ranging from one to eight years. Benefits under all pension plans are valued based on the projected unit credit cost method.

[0000068505-17-000002:mdna:234]
Valuation and Recoverability of Goodwill

[0000068505-17-000002:mdna:235]
We assess the recorded amount of goodwill for recovery on an annual basis in the fourth quarter of each fiscal year. Goodwill is assessed more frequently if an event occurs or circumstances change that would indicate it is more-likely-than-not that the fair value of a reporting unit is below its carrying amount. We continually assess whether any such events and circumstances have occurred, which requires a significant amount of judgment. Such events and circumstances may include: adverse changes in macroeconomic conditions, adverse changes in the industry or market in which we transact, changes in cost factors negatively impacting earnings and cash flows, negative or declining overall financial performance, events affecting the carrying value or composition of a reporting unit, or a sustained decrease in share price, among others.  Any such adverse event or change in circumstances could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000068505-17-000002:mdna:236]
The goodwill impairment assessment is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a “component”). A component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components are aggregated and deemed a single reporting unit. An operating segment is deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component. Based on this guidance, we have determined that our Products and Services segments each meet the definition of a reporting unit. We performed a qualitative assessment of goodwill and determined that it was not more-likely-than-not that the fair value of each reporting unit was less than its carrying amount for the fiscal years 2016, 2015, and 2014. In performing this qualitative assessment we assessed relevant events and circumstances including macroeconomic conditions, industry and market conditions, cost factors, overall financial performance, changes in enterprise value, and entity-specific events. For fiscal years 2016, 2015, and 2014, we concluded it was more-likely-than-not that the fair value of each reporting unit exceeded its carrying value.

[0000068505-17-000002:mdna:237]
Recent Accounting Pronouncements

[0000068505-17-000002:mdna:238]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance

[0000068505-17-000002:mdna:239]
42

[0000068505-17-000002:mdna:240]
in U.S. GAAP. The core principle of the ASU is the recognition of revenue for the transfer of goods or services equal to the amount an entity expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017.

[0000068505-17-000002:mdna:241]
We have begun to analyze the impact of the new standard on our financial results based on an inventory of our current contracts with customers. We have obtained an understanding of the new standard and currently believe that we will retain much of the same accounting treatment as used to recognize revenue under current standards. Revenue on a significant portion of our contracts is currently recognized under percentage of completion accounting, applying a cost-to-cost method. We believe under the new standard we will continue to recognize revenue on these contracts using a cost-to-cost method based on the continuous transfer of control to the customer over time. Transfer of control in our contracts is demonstrated by creating a customized asset for our customers, in conjunction with contract terms which provide the right to receive payment for goods and services.

[0000068505-17-000002:mdna:242]
In addition, we understand that the standard may generally cause issuers to accelerate revenue recognition in contracts which were previously limited by current software revenue recognition rules. While we may have contracts which fall under these accounting rules in the current standard, we have not historically deferred significant amounts of revenue under these rules as many arrangements are single-element software arrangements or sales of software with a tangible product which falls out of the scope of the current software rules. Based on the contracts currently in place, we do not anticipate a significant acceleration of revenue upon applying the new standard to our current contracts under these fact patterns.

[0000068505-17-000002:mdna:243]
We continue to evaluate the impact of ASU No. 2014-09 on our financial results and prepare for the adoption of the standard on January 1, 2018, including readying our internal processes and control environment for new requirements, particularly around enhanced disclosures, under the new standard. The standard allows for both retrospective and modified retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and the impact on our consolidated financial statements and footnote disclosures, and will continue to provide enhanced disclosures as we continue our assessment.

[0000068505-17-000002:mdna:244]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us January 1, 2019 and interim periods within that reporting period.  The ASU requires a modified retrospective method upon adoption. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000002:mdna:245]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for us January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so in which case it must be retrospectively applied at the earliest date practical. Upon adoption, we do not anticipate significant changes to our existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-17-000002:mdna:246]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption is permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. We are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-17-000002:mdna:247]
We elected to adopt ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” as of January 1, 2016. ASU 2016-09, which was issued by the FASB in March 2016, simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $5 million income tax benefit during the year ended December 31, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $17 million, $16 million, and $48 million for the years ended December 31, 2016, 2015 and 2014. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $6 million for the year ended December 31, 2016.

[0000068505-17-000002:mdna:248]
We adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs," effective January 1, 2016. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with

[0000068505-17-000002:mdna:249]
debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of December 31, 2016 and December 31, 2015, $25 million and $41 million of debt issuance costs, respectively, have been presented as a component of long-term debt.

[0000068505-17-000002:mdna:250]
Forward-Looking Statements

[0000068505-17-000002:mdna:251]
Some of the risk factors that affect our business and financial results are discussed in “Item 1A: Risk Factors.” We caution the reader that the risk factors discussed in “Item 1A: Risk Factors,” and those described elsewhere in this report or in our other Securities and Exchange Commission filings, could cause our actual results to differ materially from those stated in the forward-looking statements.
