# MSI note change history — 0000068505-16-000026 → 0000068505-16-000031


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-04):
[0000068505-16-000031:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at October 1, 2016.
  (was, 2016-08-05, similarity 0.9908):
[0000068505-16-000026:note_history:1]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at July 2, 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-04):
[0000068505-16-000031:note_history:2]
The condensed consolidated financial statements as of October 1, 2016 and for the three and nine months ended October 1, 2016 and October 3, 2015 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2016-08-05, similarity 0.9373):
[0000068505-16-000026:note_history:2]
The condensed consolidated financial statements as of July 2, 2016 and for the three and six months ended July 2, 2016 and July 4, 2015 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2016-11-04):
[0000068505-16-000031:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2015. The results of operations for the three and nine months ended October 1, 2016 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2016-08-05, similarity 0.849):
[0000068505-16-000026:note_history:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2015. The results of operations for the three and six months ended July 2, 2016 are not necessarily indicative of the operating results to be expected for the full year.

- added (2016-11-04):
[0000068505-16-000031:note_history:4]
During the three months ended October 1, 2016, Motorola Solutions relocated its global headquarters from Schaumburg, IL to Chicago, IL. The move provides the Company with access to key talent and allows the Company to optimize the Schaumburg campus for current space requirements.

- added (2016-11-04):
[0000068505-16-000031:note_history:5]
On September 23, 2016, the Company entered into a stock purchase agreement with Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions. The acquisition, which is expected to close in the fourth quarter of 2016, will expand the Company's smart public safety portfolio and will enable the Company to offer a full suite of command center solutions to a broader customer base.

- changed (2016-11-04):
[0000068505-16-000031:note_history:6]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.
  (was, 2016-08-05, similarity 0.979):
[0000068505-16-000026:note_history:6]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- added (2016-11-04):
[0000068505-16-000031:note_history:7]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so for which it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

- added (2016-11-04):
[0000068505-16-000031:note_history:8]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

- changed (2016-11-04):
[0000068505-16-000031:note_history:9]
The Company elected to adopt ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” as of January 1, 2016. ASU 2016-09, which was issued by the FASB in March 2016, simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $5 million income tax benefit during the nine months ended October 1, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $16 million for both the nine months ended October 1, 2016 and October 3, 2015. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $5 million for the nine months ended October 1, 2016.
  (was, 2016-08-05, similarity 0.9274):
[0000068505-16-000026:note_history:9]
The Company elected to adopt ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” as of January 1, 2016. ASU 2016-09, which was issued by the FASB in March 2016, simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $3 million income tax benefit during the six months ended July 2, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $14 million for both the six months ended July 2, 2016 and July 4, 2015. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $3 million for the six months ended July 2, 2016.

- changed (2016-11-04):
[0000068505-16-000031:note_history:10]
The Company adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs," effective January 1, 2016. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We have retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of October 1, 2016 and December 31, 2015, $31 million and $41 million, respectively, have been presented as a component of long-term debt.
  (was, 2016-08-05, similarity 0.9936):
[0000068505-16-000026:note_history:10]
The Company adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs," effective January 1, 2016. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We have retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of July 2, 2016 and December 31, 2015, $35 million and $41 million, respectively, have been presented as a component of long-term debt.

- removed (2016-11-04):
[0000068505-16-000026:note_history:11]
In March 2016, the FASB issued ASU 2016-07, "Investments - Equity Method and Joint Ventures: Simplifying the Transition to the Equity Method of Accounting," which eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. ASU 2016-07 is effective for the Company January 1, 2017 and interim periods within that reporting period. The adoption of ASU 2016-07 is not expected to have a material effect on the Company’s consolidated financial statements.

- removed (2016-11-04):
[0000068505-16-000026:note_history:12]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurements of Credit Losses on Financial Instruments," which requires measurement and recognition of expected credit losses for financial assets held.  The ASU is effective for the Company January 1, 2020 and interim periods within that reporting period. The adoption of ASU 2016-13 is not expected to have a material effect on the Company’s consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-04):
[0000068505-16-000031:note_history:13]
As of October 1, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 1, 2016. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the nine months ended October 1, 2016.
  (was, 2016-08-05, similarity 0.8943):
[0000068505-16-000026:note_history:13]
As of July 2, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of July 2, 2016. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the six months ended July 2, 2016.

- changed (2016-11-04):
[0000068505-16-000031:note_history:14]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a term loan with an initial principal amount of $675 million and a maturity date of February 18, 2019 (the "Term Loan"). Interest on the Term Loan is variable and indexed to LIBOR. Interest expense on the Term Loan is payable quarterly in February, May, August, and November. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed.
  (was, 2016-08-05, similarity 0.8456):
[0000068505-16-000026:note_history:14]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a term loan with an initial principal amount of $675 million and a maturity date of February 18, 2019 (the "Term Loan"). Interest on the Term Loan is variable and indexed to LIBOR. Interest expense on the Term Loan is payable quarterly in February, May, August, and November. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed. The Company's borrowing capacity under the 2014 Motorola Solutions Credit Agreement may be partially limited during the third quarter of 2016 due to the additional indebtedness incurred in connection with the Term Loan.

- changed (2016-11-04):
[0000068505-16-000031:note_history:15]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, the Company has revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of October 1, 2016 and December 31, 2015, $31 million and $41 million, respectively, have been reclassified to be presented as a component of long-term debt.
  (was, 2016-08-05, similarity 0.9691):
[0000068505-16-000026:note_history:15]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, we have revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of July 2, 2016 and December 31, 2015, $35 million and $41 million, respectively, have been reclassified to be presented as a component of long-term debt.
