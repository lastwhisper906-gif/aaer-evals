# MSI notes — 0000068505-16-000031


## msi:CashEquivalentsAndInvestmentsTableTextBlock

[0000068505-16-000031:notes:1]
[same as prior period, unchanged from 0000068505-16-000026:notes:2]

[0000068505-16-000031:notes:2]
| October 1, 2016 | Cost Basis |  | Unrealized Gains |  | Unrealized Losses |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 50 |  |  | $ | — |  |  | $ | — |  |  | $ | 50 |  |
| Corporate bonds | 5 |  |  | — |  |  | — |  |  | 5 |  |
| Common stock | — |  |  | 1 |  |  | — |  |  | 1 |  |
|  | 55 |  |  | 1 |  |  | — |  |  | 56 |  |
| Other investments, at cost | 217 |  |  | — |  |  | — |  |  | 217 |  |
| Equity method investments | 10 |  |  | — |  |  | — |  |  | 10 |  |
|  | $ | 282 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 283 |  |
| Less: current portion of available-for-sale securities |  |  |  |  |  |  | 45 |  |
|  |  |  |  |  |  |  | $ | 238 |  |

[0000068505-16-000031:notes:3]
| December 31, 2015 | Cost Basis |  | Unrealized Gains |  | Unrealized Losses |  | Investments |
| Available-for-sale securities: |  |  |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | 455 |  |  | $ | — |  |  | $ | (11 | ) |  | $ | 444 |  |
| Corporate bonds | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Common stock | — |  |  | 6 |  |  | — |  |  | 6 |  |
|  | 462 |  |  | 6 |  |  | (11 | ) |  | 457 |  |
| Other investments, at cost | 203 |  |  | — |  |  | — |  |  | 203 |  |
| Equity method investments | 9 |  |  | — |  |  | — |  |  | 9 |  |
|  | $ | 674 |  |  | $ | 6 |  |  | $ | (11 | ) |  | $ | 669 |  |
| Less: current portion of available-for-sale securities |  |  |  |  |  |  | 438 |  |
|  |  |  |  |  |  |  | $ | 231 |  |


## msi:FairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0000068505-16-000031:notes:4]
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of October 1, 2016 and December 31, 2015 were as follows:

[0000068505-16-000031:notes:5]
| October 1, 2016 | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Available-for-sale securities: |  |  |  |  |  |
| Government, agency, and government-sponsored enterprise obligations | $ | — |  |  | $ | 50 |  |  | $ | 50 |  |
| Corporate bonds | — |  |  | 5 |  |  | 5 |  |
| Common stock | 1 |  |  | — |  |  | 1 |  |
| Liabilities: |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 18 |  |  | $ | 18 |  |
| Interest rate swap | — |  |  | 1 |  |  | 1 |  |

[0000068505-16-000031:notes:6]
[same as prior period, unchanged from 0000068505-16-000026:notes:7]


## msi:LongtermCustomerFinancingandSalesofReceivablesTextBlock

[0000068505-16-000031:notes:7]
[same as prior period, unchanged from 0000068505-16-000026:notes:8]

[0000068505-16-000031:notes:8]
[same as prior period, unchanged from 0000068505-16-000026:notes:9]

[0000068505-16-000031:notes:9]
[same as prior period, unchanged from 0000068505-16-000026:notes:10]

[0000068505-16-000031:notes:10]
|  | October 1, 2016 |  | December 31, 2015 |
| Long-term receivables, net | 54 |  |  | 60 |  |
| Less current portion | (11 | ) |  | (13 | ) |
| Non-current long-term receivables, net | $ | 43 |  |  | $ | 47 |  |

[0000068505-16-000031:notes:11]
The current portion of long-term receivables is included in Accounts receivable, net and the non-current portion of long-term receivables is included in Other assets in the Company’s condensed consolidated balance sheets. The Company had outstanding commitments to provide long-term financing to third parties totaling $214 million at October 1, 2016, compared to $112 million at December 31, 2015.

[0000068505-16-000031:notes:12]
[same as prior period, unchanged from 0000068505-16-000026:notes:13]

[0000068505-16-000031:notes:13]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and nine months ended October 1, 2016 and October 3, 2015:

[0000068505-16-000031:notes:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Accounts receivable sales proceeds | $ | 8 |  |  | $ | 5 |  |  | $ | 15 |  |  | $ | 16 |  |
| Long-term receivables sales proceeds | 39 |  |  | 24 |  |  | 173 |  |  | 132 |  |
| Total proceeds from receivable sales | $ | 47 |  |  | $ | 29 |  |  | $ | 188 |  |  | $ | 148 |  |

[0000068505-16-000031:notes:15]
At October 1, 2016, the Company had retained servicing obligations for $685 million of long-term receivables, compared to $668 million of long-term receivables at December 31, 2015. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-16-000031:notes:16]
[same as prior period, unchanged from 0000068505-16-000026:notes:17]

[0000068505-16-000031:notes:17]
An aging analysis of financing receivables at October 1, 2016 and December 31, 2015 is as follows:

[0000068505-16-000031:notes:18]
| October 1, 2016 | TotalLong-termReceivable |  | Current BilledDue |  | Past Due Under 90 Days |  | Past Due Over 90 Days |
| Municipal leases secured tax exempt | $ | 12 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial loans and leases secured | 42 |  |  | — |  |  | 1 |  |  | 1 |  |
| Total gross long-term receivables, including current portion | $ | 54 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-16-000031:notes:19]
[same as prior period, unchanged from 0000068505-16-000026:notes:20]


## msi:OtherChargesTableTextBlock

[0000068505-16-000031:notes:20]
[same as prior period, unchanged from 0000068505-16-000026:notes:21]

[0000068505-16-000031:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Other charges: |  |  |  |  |  |  |  |
| Intangibles amortization | $ | 31 |  |  | $ | 2 |  |  | $ | 83 |  |  | $ | 6 |  |
| Reorganization of business | 6 |  |  | 8 |  |  | 28 |  |  | 33 |  |
| Building impairment | — |  |  | 6 |  |  | 17 |  |  | 6 |  |
| Non-U.S. pension curtailment gain | — |  |  | — |  |  | — |  |  | (32 | ) |
| Impairment of corporate aircraft | — |  |  | 26 |  |  | 3 |  |  | 26 |  |
| Acquisition-related transaction fees | — |  |  | — |  |  | 13 |  |  | — |  |
|  | $ | 37 |  |  | $ | 42 |  |  | $ | 144 |  |  | $ | 39 |  |


## msi:RestructuringAndRelatedActivitiesReportableSegmentTableTextBlock

[0000068505-16-000031:notes:22]
[same as prior period, unchanged from 0000068505-16-000026:notes:23]

[0000068505-16-000031:notes:23]
| October 1, 2016 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 5 |  |  | $ | 59 |  |
| Services | 2 |  |  | 15 |  |
|  | $ | 7 |  |  | $ | 74 |  |

[0000068505-16-000031:notes:24]
| October 3, 2015 | Three Months Ended |  | Nine Months Ended |
| Products | $ | 29 |  |  | $ | 51 |  |
| Services | 12 |  |  | 19 |  |
|  | $ | 41 |  |  | $ | 70 |  |


## msi:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTableTextBlock

[0000068505-16-000031:notes:25]
[same as prior period, unchanged from 0000068505-16-000026:notes:26]

[0000068505-16-000031:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 2 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 7 |  |
| Selling, general and administrative expenses | 12 |  |  | 13 |  |  | 35 |  |  | 38 |  |
| Research and development expenditures | 3 |  |  | 3 |  |  | 10 |  |  | 13 |  |
| Share-based compensation expense included in Operating earnings | 17 |  |  | 18 |  |  | 52 |  |  | 58 |  |
| Tax benefit | 5 |  |  | 6 |  |  | 16 |  |  | 19 |  |
| Share-based compensation expense, net of tax | $ | 12 |  |  | $ | 12 |  |  | $ | 36 |  |  | $ | 39 |  |
| Decrease in basic earnings per share | $ | (0.07 | ) |  | $ | (0.06 | ) |  | $ | (0.21 | ) |  | $ | (0.19 | ) |
| Decrease in diluted earnings per share | $ | (0.07 | ) |  | $ | (0.06 | ) |  | $ | (0.21 | ) |  | $ | (0.19 | ) |


## msi:ScheduleOfIntangibleAssetsByReportingSegmentTableTextBlock

[0000068505-16-000031:notes:27]
[same as prior period, unchanged from 0000068505-16-000026:notes:28]

[0000068505-16-000031:notes:28]
|  | October 1, 2016 |  | December 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products | $ | 86 |  |  | $ | 61 |  |  | $ | 89 |  |  | $ | 60 |  |
| Services | 820 |  |  | 76 |  |  | 22 |  |  | 2 |  |
|  | $ | 906 |  |  | $ | 137 |  |  | $ | 111 |  |  | $ | 62 |  |


## msi:ScheduleOfOtherLiabilitiesTableTextBlock

[0000068505-16-000031:notes:29]
[same as prior period, unchanged from 0000068505-16-000026:notes:30]

[0000068505-16-000031:notes:30]
|  | October 1, 2016 |  | December 31, 2015 |
| Defined benefit plans | $ | 1,486 |  |  | $ | 1,512 |  |
| Postretirement Health Care Benefit Plan | — |  |  | 49 |  |
| Deferred revenue | 126 |  |  | 113 |  |
| Unrecognized tax benefits | 42 |  |  | 50 |  |
| Deferred income taxes | 119 |  |  | — |  |
| Deferred consideration (Note 14) | 76 |  |  | — |  |
| Other | 213 |  |  | 180 |  |
|  | $ | 2,062 |  |  | $ | 1,904 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-16-000031:notes:31]
[same as prior period, unchanged from 0000068505-16-000026:notes:32]

[0000068505-16-000031:notes:32]
[same as prior period, unchanged from 0000068505-16-000026:notes:33]

[0000068505-16-000031:notes:33]
[same as prior period, unchanged from 0000068505-16-000026:notes:34]

[0000068505-16-000031:notes:34]
[same as prior period, unchanged from 0000068505-16-000026:notes:35]

[0000068505-16-000031:notes:35]
[same as prior period, unchanged from 0000068505-16-000026:notes:36]

[0000068505-16-000031:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Interest income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (58 | ) |  | $ | (47 | ) |  | $ | (169 | ) |  | $ | (132 | ) |
| Interest income | 4 |  |  | 4 |  |  | 12 |  |  | 10 |  |
|  | $ | (54 | ) |  | $ | (43 | ) |  | $ | (157 | ) |  | $ | (122 | ) |
| Other: |  |  |  |  |  |  |  |
| Investment impairments | (2 | ) |  | — |  |  | (2 | ) |  | (3 | ) |
| Foreign currency gain (loss) | 7 |  |  | (29 | ) |  | $ | 34 |  |  | $ | (23 | ) |
| Gain (loss) on derivative instruments | (11 | ) |  | 25 |  |  | (41 | ) |  | 13 |  |
| Gains on equity method investments | — |  |  | 2 |  |  | 2 |  |  | 6 |  |
| Realized foreign currency loss on acquisition | — |  |  | — |  |  | (10 | ) |  | — |  |
| Other | 5 |  |  | 1 |  |  | 5 |  |  | 4 |  |
|  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (12 | ) |  | $ | (3 | ) |

[0000068505-16-000031:notes:37]
[same as prior period, unchanged from 0000068505-16-000026:notes:38]

[0000068505-16-000031:notes:38]
[same as prior period, unchanged from 0000068505-16-000026:notes:39]

[0000068505-16-000031:notes:39]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Three Months Ended | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 192 |  |  | $ | 126 |  |  | $ | 192 |  |  | $ | 115 |  |
| Weighted average common shares outstanding | 166.3 |  |  | 199.2 |  |  | 166.3 |  |  | 199.2 |  |
| Per share amount | $ | 1.15 |  |  | $ | 0.63 |  |  | $ | 1.15 |  |  | $ | 0.58 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 192 |  |  | $ | 126 |  |  | $ | 192 |  |  | $ | 115 |  |
| Weighted average common shares outstanding | 166.3 |  |  | 199.2 |  |  | 166.3 |  |  | 199.2 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.4 |  |  | 2.1 |  |  | 2.4 |  |  | 2.1 |  |
| Senior Convertible Notes | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |
| Diluted weighted average common shares outstanding | 169.6 |  |  | 201.3 |  |  | 169.6 |  |  | 201.3 |  |
| Per share amount | $ | 1.13 |  |  | $ | 0.63 |  |  | $ | 1.13 |  |  | $ | 0.57 |  |

[0000068505-16-000031:notes:40]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Earnings from Continuing Operations, net of tax |  | Net Earnings |
| Nine Months Ended | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 317 |  |  | $ | 363 |  |  | $ | 317 |  |  | $ | 331 |  |
| Weighted average common shares outstanding | 171.0 |  |  | 207.2 |  |  | 171.0 |  |  | 207.2 |  |
| Per share amount | $ | 1.85 |  |  | $ | 1.75 |  |  | $ | 1.85 |  |  | $ | 1.60 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 317 |  |  | $ | 363 |  |  | $ | 317 |  |  | $ | 331 |  |
| Weighted average common shares outstanding | 171.0 |  |  | 207.2 |  |  | 171.0 |  |  | 207.2 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.5 |  |  | 2.0 |  |  | 2.5 |  |  | 2.0 |  |
| Senior Convertible Notes | 0.5 |  |  | — |  |  | 0.5 |  |  | — |  |
| Diluted weighted average common shares outstanding | 174.0 |  |  | 209.2 |  |  | 174.0 |  |  | 209.2 |  |
| Per share amount | $ | 1.82 |  |  | $ | 1.74 |  |  | $ | 1.82 |  |  | $ | 1.58 |  |

[0000068505-16-000031:notes:41]
In the computation of diluted earnings per common share from both continuing operations and on a net earnings basis for the three months ended October 1, 2016, the assumed exercise of 2.5 million options were excluded because their inclusion would have been antidilutive. For the nine months ended October 1, 2016, the assumed exercise of 2.9 million options and the assumed vesting of 0.4 million restricted stock units ("RSUs") were excluded because their inclusion would have been antidilutive.

[0000068505-16-000031:notes:42]
For the three months ended October 3, 2015, the assumed exercise of 3.9 million stock options were excluded because their inclusion would have been antidilutive. For the nine months ended October 3, 2015, the assumed exercise of 2.6 million options and the assumed vesting of 0.4 million RSUs were excluded because their inclusion would have been antidilutive.

[0000068505-16-000031:notes:43]
[same as prior period, unchanged from 0000068505-16-000026:notes:44]

[0000068505-16-000031:notes:44]
Because of the Company’s intention to settle the par value of the Senior Convertible Notes in cash upon conversion, Motorola Solutions does not reflect any shares underlying the Senior Convertible Notes in its diluted weighted average shares outstanding until the average stock price per share for the period exceeds the conversion price. In this case, only the number of shares that would be issuable (under the treasury stock method of accounting for share dilution) will be included, which is based upon the amount by which the average stock price exceeds the conversion price of $68.50. For the three and nine months ended October 1, 2016, the dilutive impact of the Senior Convertible Notes was 0.9 million shares and 0.5 million shares, respectively.

[0000068505-16-000031:notes:45]
[same as prior period, unchanged from 0000068505-16-000026:notes:46]

[0000068505-16-000031:notes:46]
[same as prior period, unchanged from 0000068505-16-000026:notes:47]

[0000068505-16-000031:notes:47]
The Company’s cash and cash equivalents were $1.7 billion at October 1, 2016 and $2.0 billion at December 31, 2015. Of these amounts, $63 million was restricted at both October 1, 2016 and December 31, 2015.

[0000068505-16-000031:notes:48]
[same as prior period, unchanged from 0000068505-16-000026:notes:49]

[0000068505-16-000031:notes:49]
[same as prior period, unchanged from 0000068505-16-000026:notes:50]

[0000068505-16-000031:notes:50]
|  | October 1, 2016 |  | December 31, 2015 |
| Accounts receivable | $ | 1,207 |  |  | $ | 1,390 |  |
| Less allowance for doubtful accounts | (43 | ) |  | (28 | ) |
|  | $ | 1,164 |  |  | $ | 1,362 |  |

[0000068505-16-000031:notes:51]
[same as prior period, unchanged from 0000068505-16-000026:notes:52]

[0000068505-16-000031:notes:52]
[same as prior period, unchanged from 0000068505-16-000026:notes:53]

[0000068505-16-000031:notes:53]
|  | October 1, 2016 |  | December 31, 2015 |
| Finished goods | $ | 154 |  |  | $ | 151 |  |
| Work-in-process and production materials | 265 |  |  | 287 |  |
|  | 419 |  |  | 438 |  |
| Less inventory reserves | (136 | ) |  | (142 | ) |
|  | $ | 283 |  |  | $ | 296 |  |

[0000068505-16-000031:notes:54]
[same as prior period, unchanged from 0000068505-16-000026:notes:55]

[0000068505-16-000031:notes:55]
[same as prior period, unchanged from 0000068505-16-000026:notes:56]

[0000068505-16-000031:notes:56]
|  | October 1, 2016 |  | December 31, 2015 |
| Available-for-sale securities | $ | 45 |  |  | $ | 438 |  |
| Costs and earnings in excess of billings | 413 |  |  | 374 |  |
| Tax-related refunds receivable | 100 |  |  | 44 |  |
| Other | 112 |  |  | 98 |  |
|  | $ | 670 |  |  | $ | 954 |  |

[0000068505-16-000031:notes:57]
[same as prior period, unchanged from 0000068505-16-000026:notes:58]

[0000068505-16-000031:notes:58]
[same as prior period, unchanged from 0000068505-16-000026:notes:59]

[0000068505-16-000031:notes:59]
|  | October 1, 2016 |  | December 31, 2015 |
| Land | $ | 14 |  |  | $ | 17 |  |
| Building | 293 |  |  | 523 |  |
| Machinery and equipment | 1,920 |  |  | 1,585 |  |
|  | 2,227 |  |  | 2,125 |  |
| Less accumulated depreciation | (1,447 | ) |  | (1,638 | ) |
|  | $ | 780 |  |  | $ | 487 |  |

[0000068505-16-000031:notes:60]
Depreciation expense for the three months ended October 1, 2016 and October 3, 2015 was $45 million and $30 million, respectively. Depreciation expense for the nine months ended October 1, 2016 and October 3, 2015 was $137 million and $107 million, respectively.

[0000068505-16-000031:notes:61]
On February 1, 2016, the Company completed the sale of its Penang, Malaysia manufacturing operations, including the land, building, equipment, and inventory, as well as the transfer of employees to a contract manufacturer. During the nine months ended October 1, 2016, the Company incurred a loss of $7 million on the sale of its Penang, Malaysia facility and manufacturing operations, which is included within Gains (losses) on sales of investments and businesses, net.

[0000068505-16-000031:notes:62]
The Company acquired property, plant and equipment, including network-related assets, with a fair value of $245 million in the acquisition of GDCL on February 19, 2016. See discussion in Note 14.

[0000068505-16-000031:notes:63]
During the nine months ended October 1, 2016, the Company sold all remaining parcels of its Schaumburg, IL headquarters campus. A building impairment loss of $17 million has been recognized in Other charges during the nine months ended October 1, 2016 related to the excess carrying value of the long-lived assets in relation to the selling price.

[0000068505-16-000031:notes:64]
During the three months ended October 1, 2016, Motorola Solutions relocated its global headquarters from Schaumburg, IL to Chicago, IL. The move provides the Company with access to key talent and allows the Company to optimize the Schaumburg campus for current space requirements.

[0000068505-16-000031:notes:65]
Investments

[0000068505-16-000031:notes:66]
In December 2015, the Company invested $401 million in United Kingdom treasury securities in order to partially offset the risk associated with fluctuations in the British Pound Sterling in the period before the closing of the purchase of GDCL. The investments were recorded within Other current assets in the Company's consolidated balance sheets. The Company liquidated these investments in February 2016 to partially fund the acquisition of GDCL. During the nine months ended October 1, 2016, the Company realized a loss of $19 million associated with the sale of the treasury securities, of which, $11 million was unrealized as of December 31, 2015.

[0000068505-16-000031:notes:67]
[same as prior period, unchanged from 0000068505-16-000026:notes:66]

[0000068505-16-000031:notes:68]
[same as prior period, unchanged from 0000068505-16-000026:notes:67]

[0000068505-16-000031:notes:69]
|  | October 1, 2016 |  | December 31, 2015 |
| Intangible assets, net (Note 14) | $ | 769 |  |  | $ | 49 |  |
| Non-current long-term receivables, net | 43 |  |  | 47 |  |
| Defined benefit plan assets | 163 |  |  | 128 |  |
| Other | 38 |  |  | 47 |  |
|  | $ | 1,013 |  |  | $ | 271 |  |

[0000068505-16-000031:notes:70]
[same as prior period, unchanged from 0000068505-16-000026:notes:69]

[0000068505-16-000031:notes:71]
[same as prior period, unchanged from 0000068505-16-000026:notes:70]

[0000068505-16-000031:notes:72]
|  | October 1, 2016 |  | December 31, 2015 |
| Deferred revenue | $ | 404 |  |  | $ | 390 |  |
| Compensation | 196 |  |  | 241 |  |
| Billings in excess of costs and earnings | 329 |  |  | 337 |  |
| Tax liabilities | 72 |  |  | 48 |  |
| Dividend payable | 68 |  |  | 71 |  |
| Trade liabilities | 159 |  |  | 135 |  |
| Other | 522 |  |  | 449 |  |
|  | $ | 1,750 |  |  | $ | 1,671 |  |

[0000068505-16-000031:notes:73]
[same as prior period, unchanged from 0000068505-16-000026:notes:72]

[0000068505-16-000031:notes:74]
[same as prior period, unchanged from 0000068505-16-000026:notes:73]

[0000068505-16-000031:notes:75]
[same as prior period, unchanged from 0000068505-16-000026:notes:74]

[0000068505-16-000031:notes:76]
During the nine months ended October 1, 2016, the Company paid an aggregate of $728 million, including transaction costs, to repurchase approximately 10.5 million shares at an average price of $69.31 per share. As of October 1, 2016, the Company had used approximately $11.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $2.3 billion of authority available for future repurchases.

[0000068505-16-000031:notes:77]
Payment of Dividends:  On November 3, 2016, the Company announced that its Board of Directors approved an increase in the quarterly cash dividend from $0.41 per share to $0.47 per share of common stock. During both the three months ended October 1, 2016 and October 3, 2015, the Company paid $70 million in cash dividends to holders of its common stock. During the nine months ended October 1, 2016 and October 3, 2015, the Company paid $213 million and $218 million, respectively, in cash dividends to holders of its common stock.

[0000068505-16-000031:notes:78]
[same as prior period, unchanged from 0000068505-16-000026:notes:77]

[0000068505-16-000031:notes:79]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the condensed consolidated statements of operations during the three and nine months ended October 1, 2016 and October 3, 2015:

[0000068505-16-000031:notes:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (351 | ) |  | $ | (223 | ) |  | $ | (266 | ) |  | $ | (204 | ) |
| Other comprehensive loss before reclassification adjustment | (47 | ) |  | (17 | ) |  | (131 | ) |  | (35 | ) |
| Tax (expense) benefit | (2 | ) |  | 1 |  |  | (3 | ) |  | — |  |
| Other comprehensive loss, net of tax | (49 | ) |  | (16 | ) |  | (134 | ) |  | (35 | ) |
| Balance at end of period | $ | (400 | ) |  | $ | (239 | ) |  | $ | (400 | ) |  | $ | (239 | ) |
| Available-for-Sale Securities: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | — |  |  | $ | 15 |  |  | $ | (3 | ) |  | $ | 44 |  |
| Other comprehensive income (loss) before reclassification adjustment | 1 |  |  | — |  |  | (1 | ) |  | (2 | ) |
| Tax benefit | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 1 |  |  | — |  |  | — |  |  | (1 | ) |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net | — |  |  | (8 | ) |  | 6 |  |  | (54 | ) |
| Tax expense (benefit) | — |  |  | 3 |  |  | (2 | ) |  | 21 |  |
| Reclassification adjustment into Gains (losses) on sales of investments and businesses, net of tax | — |  |  | (5 | ) |  | 4 |  |  | (33 | ) |
| Other comprehensive income (loss), net of tax | 1 |  |  | (5 | ) |  | 4 |  |  | (34 | ) |
| Balance at end of period | $ | 1 |  |  | $ | 10 |  |  | $ | 1 |  |  | $ | 10 |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | (1,537 | ) |  | (1,777 | ) |  | $ | (1,597 | ) |  | $ | (1,695 | ) |
| Other comprehensive income (loss) before reclassification adjustment | — |  |  | — |  |  | 53 |  |  | (53 | ) |
| Tax expense | — |  |  | — |  |  | (16 | ) |  | — |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | — |  |  | — |  |  | 37 |  |  | (53 | ) |
| Reclassification adjustment - Actuarial net losses into Selling, general, and administrative expenses | 13 |  |  | 20 |  |  | 40 |  |  | 56 |  |
| Reclassification adjustment - Prior service benefits into Selling, general, and administrative expenses | (7 | ) |  | (20 | ) |  | (20 | ) |  | (52 | ) |
| Reclassification adjustment - Non-U.S. pension curtailment gain into Other charges | — |  |  | — |  |  | — |  |  | (32 | ) |
| Tax expense (benefit) | (1 | ) |  | — |  |  | 8 |  |  | (1 | ) |
| Reclassification adjustment into Selling, general, and administrative expenses, net of tax | 5 |  |  | — |  |  | 28 |  |  | (29 | ) |
| Other comprehensive income (loss), net of tax | 5 |  |  | — |  |  | 65 |  |  | (82 | ) |
| Balance at end of period | $ | (1,532 | ) |  | $ | (1,777 | ) |  | $ | (1,532 | ) |  | $ | (1,777 | ) |
| Total Accumulated other comprehensive loss | $ | (1,931 | ) |  | $ | (2,006 | ) |  | $ | (1,931 | ) |  | $ | (2,006 | ) |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000068505-16-000031:notes:81]
The condensed consolidated financial statements as of October 1, 2016 and for the three and nine months ended October 1, 2016 and October 3, 2015 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the condensed consolidated balance sheets, statements of operations, statements of comprehensive income, statement of stockholders' equity, and statements of cash flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-16-000031:notes:82]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2015. The results of operations for the three and nine months ended October 1, 2016 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-16-000031:notes:83]
The preparation of financial statements in conformity with U.S. GAAP requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000068505-16-000031:notes:84]
The following table presents the unaudited pro forma combined results of operations of the Company and GDCL for the three and nine months ended October 1, 2016 and October 3, 2015 as if the acquisition of GDCL had occurred on January 1, 2016 and January 1, 2015, respectively, (in millions, except per share amounts):

[0000068505-16-000031:notes:85]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Revenues | $ | 1,532 |  |  | $ | 1,570 |  |  | $ | 4,226 |  |  | $ | 4,450 |  |
| Earnings from continuing operations | 192 |  |  | 152 |  |  | 340 |  |  | (464 | ) |
| Basic earnings per share from continuing operations | 1.15 |  |  | 0.76 |  |  | 1.99 |  |  | (2.24 | ) |
| Diluted earnings per share from continuing operations | 1.13 |  |  | 0.76 |  |  | 1.95 |  |  | (2.22 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-16-000031:notes:86]
Commitments and Contingencies

[0000068505-16-000031:notes:87]
Legal Matters

[0000068505-16-000031:notes:88]
The Company is a defendant in various lawsuits, claims, and actions, which arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's condensed consolidated financial position, liquidity, or results of operations. However, an unfavorable resolution could have a material adverse effect on the Company's consolidated financial position, liquidity, or results of operations in the periods in which the matters are ultimately resolved, or in the periods in which more information is obtained that changes management's opinion of the ultimate disposition.

[0000068505-16-000031:notes:89]
Other Indemnifications

[0000068505-16-000031:notes:90]
The Company is a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. In some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0000068505-16-000031:notes:91]
Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. The Company's obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration and to amounts not in excess of a percentage of the contract value. The Company had no accruals for any such obligations at October 1, 2016.

[0000068505-16-000031:notes:92]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property agreements. Historically, the Company has not made significant payments under these agreements.


## us-gaap:DebtDisclosureTextBlock

[0000068505-16-000031:notes:93]
Debt and Credit Facilities

[0000068505-16-000031:notes:94]
As of October 1, 2016, the Company had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. The Company must comply with certain customary covenants, including a maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of October 1, 2016. The Company did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the nine months ended October 1, 2016.

[0000068505-16-000031:notes:95]
In connection with the completion of the acquisition of GDCL, the Company entered into a new term loan credit agreement (the “Term Loan Agreement”), under which the Company borrowed a term loan with an initial principal amount of $675 million and a maturity date of February 18, 2019 (the "Term Loan"). Interest on the Term Loan is variable and indexed to LIBOR. Interest expense on the Term Loan is payable quarterly in February, May, August, and November. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-16-000031:notes:96]
Effective January 1, 2016, the Company retrospectively adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." Under this guidance, the Company has revised the presentation of debt issuance costs which were previously capitalized in other assets in the consolidated balance sheet to be presented as a reduction to long-term debt. As of October 1, 2016 and December 31, 2015, $31 million and $41 million, respectively, have been reclassified to be presented as a component of long-term debt.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-16-000031:notes:97]
[same as prior period, unchanged from 0000068505-16-000026:notes:93]

[0000068505-16-000031:notes:98]
[same as prior period, unchanged from 0000068505-16-000026:notes:94]

[0000068505-16-000031:notes:99]
As of October 1, 2016, the Company had outstanding foreign exchange contracts with notional amounts totaling $744 million, compared to $494 million outstanding at December 31, 2015. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-16-000031:notes:100]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of October 1, 2016, and the corresponding positions as of December 31, 2015:

[0000068505-16-000031:notes:101]
|  | Notional Amount |
| Net Buy (Sell) by Currency | October 1, 2016 |  | December 31, 2015 |
| Euro | $ | 211 |  |  | $ | 99 |  |
| British Pound | 192 |  |  | 62 |  |
| Chinese Renminbi | (98 | ) |  | (114 | ) |
| Australian Dollar | (61 | ) |  | (60 | ) |
| Brazilian Real | (59 | ) |  | (44 | ) |

[0000068505-16-000031:notes:102]
[same as prior period, unchanged from 0000068505-16-000026:notes:98]

[0000068505-16-000031:notes:103]
One of the Company’s European subsidiaries has Euro-denominated loans. The interest on the Euro-denominated loans is variable. The Company has interest rate swap agreements in place which change the characteristics of interest rate payments from variable to maximum fixed-rate payments. The interest rate swaps are not designated as a hedge. As such, changes in the fair value of the interest rate swaps are included in Other income (expense) in the Company’s condensed consolidated statements of operations. The fair value of the interest rate swap was in a liability position of $1 million at both October 1, 2016 and December 31, 2015.

[0000068505-16-000031:notes:104]
The Company is exposed to interest rate risk on its Term Loan which has a variable interest rate that is indexed to LIBOR.

[0000068505-16-000031:notes:105]
[same as prior period, unchanged from 0000068505-16-000026:notes:100]

[0000068505-16-000031:notes:106]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of October 1, 2016, all of the counterparties have investment grade credit ratings. As of October 1, 2016, the aggregate net credit risk with all counterparties was de minimus.

[0000068505-16-000031:notes:107]
The following tables summarize the fair values and locations in the condensed consolidated balance sheets of all derivative financial instruments held by the Company as of October 1, 2016 and December 31, 2015:

[0000068505-16-000031:notes:108]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| October 1, 2016 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | Other current assets |  | $ | 18 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | — |  |  |  |  | $ | 19 |  |  |  |

[0000068505-16-000031:notes:109]
|  | Fair Values of Derivative Instruments |
|  | Assets |  | Liabilities |
| December 31, 2015 | FairValue |  | BalanceSheetLocation |  | FairValue |  | BalanceSheetLocation |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | 6 |  |  | Other current assets |  | $ | 2 |  |  | Accrued liabilities |
| Interest rate swap | — |  |  | Other current assets |  | 1 |  |  | Accrued liabilities |
| Total derivatives | $ | 6 |  |  |  |  | $ | 3 |  |  |  |

[0000068505-16-000031:notes:110]
The following table summarizes the effect of derivatives not designated as hedging instruments on the Company's condensed consolidated statements of operations for the three and nine months ended October 1, 2016 and October 3, 2015:

[0000068505-16-000031:notes:111]
|  | Three Months Ended |  | Nine Months Ended |  | Statements ofOperations Location |
| Gain (loss) on Derivative Instruments | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |  |
| Interest rate swap | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | Other income (expense) |
| Foreign exchange contracts | (11 | ) |  | 25 |  |  | (41 | ) |  | 12 |  |  | Other income (expense) |
| Total derivatives | $ | (11 | ) |  | $ | 25 |  |  | $ | (41 | ) |  | $ | 13 |  |  |  |

[0000068505-16-000031:notes:112]
The Company had no instruments designated as hedging instruments for the three and nine months ended October 1, 2016 and October 3, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-16-000031:notes:113]
[same as prior period, unchanged from 0000068505-16-000026:notes:108]

[0000068505-16-000031:notes:114]
During the nine months ended October 1, 2016, the Company granted 0.7 million RSUs and market stock units ("MSUs") and 0.7 million stock options and performance options ("POs"). The total aggregate compensation expense, net of estimated forfeitures, for these RSUs and MSUs was $42 million and stock options and POs was $10 million, respectively, which will generally be recognized over the vesting period of three years.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000068505-16-000031:notes:115]
[same as prior period, unchanged from 0000068505-16-000026:notes:110]

[0000068505-16-000031:notes:116]
[same as prior period, unchanged from 0000068505-16-000026:notes:111]

[0000068505-16-000031:notes:117]
During the three and nine months ended October 1, 2016, the Company had no earnings from discontinued operations in the condensed consolidated statements of operations. During the three and nine months ended October 3, 2015, the Company recorded losses from discontinued operations of $11 million and $32 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-16-000031:notes:118]
[same as prior period, unchanged from 0000068505-16-000026:notes:113]

[0000068505-16-000031:notes:119]
[same as prior period, unchanged from 0000068505-16-000026:notes:114]

[0000068505-16-000031:notes:120]
[same as prior period, unchanged from 0000068505-16-000026:notes:115]

[0000068505-16-000031:notes:121]
[same as prior period, unchanged from 0000068505-16-000026:notes:116]

[0000068505-16-000031:notes:122]
[same as prior period, unchanged from 0000068505-16-000026:notes:117]

[0000068505-16-000031:notes:123]
[same as prior period, unchanged from 0000068505-16-000026:notes:118]

[0000068505-16-000031:notes:124]
The Company had no Level 3 holdings as of October 1, 2016 or December 31, 2015.

[0000068505-16-000031:notes:125]
At October 1, 2016 and December 31, 2015, the Company had $1.1 billion and $1.3 billion, respectively, of investments in money market mutual funds (Level 2) classified as Cash and cash equivalents in its condensed consolidated balance sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-16-000031:notes:126]
Using quoted market prices and market interest rates, the Company determined that the fair value of long-term debt at October 1, 2016 and December 31, 2015 was $5.2 billion and $4.1 billion (Level 2), respectively.

[0000068505-16-000031:notes:127]
[same as prior period, unchanged from 0000068505-16-000026:notes:122]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-16-000031:notes:128]
[same as prior period, unchanged from 0000068505-16-000026:notes:123]

[0000068505-16-000031:notes:129]
[same as prior period, unchanged from 0000068505-16-000026:notes:124]

[0000068505-16-000031:notes:130]
[same as prior period, unchanged from 0000068505-16-000026:notes:125]

[0000068505-16-000031:notes:131]
[same as prior period, unchanged from 0000068505-16-000026:notes:126]

[0000068505-16-000031:notes:132]
The acquisition of GDCL enables the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. During the nine months ended October 1, 2016, the Company recorded $338 million within Net sales and $71 million within Net earnings from the operations of Airwave.

[0000068505-16-000031:notes:133]
The acquisition of GDCL has been accounted for at fair value as of the acquisition date, based on the fair value of the total consideration transferred which has been attributed to all identifiable assets acquired and liabilities assumed and measured at fair value.

[0000068505-16-000031:notes:134]
[same as prior period, unchanged from 0000068505-16-000026:notes:129]

[0000068505-16-000031:notes:135]
| Cash |  | $ | 86 |  |
| Accounts receivable, net |  | 55 |  |
| Other current assets |  | 36 |  |
| Property, plant and equipment, net |  | 245 |  |
| Deferred income taxes |  | 78 |  |
| Accounts payable |  | (18 | ) |
| Accrued liabilities |  | (181 | ) |
| Other liabilities |  | (289 | ) |
| Goodwill |  | 195 |  |
| Intangible assets |  | 875 |  |
| Total consideration |  | $ | 1,082 |  |
| Net present value of deferred consideration payment to former owners |  | (82 | ) |
| Net cash consideration at purchase |  | $ | 1,000 |  |

[0000068505-16-000031:notes:136]
Acquired intangible assets consist of $846 million of customer relationships and $29 million of trade names. All intangibles have a useful life of seven years, over which amortization expense will be recognized on a straight line basis.

[0000068505-16-000031:notes:137]
[same as prior period, unchanged from 0000068505-16-000026:notes:132]

[0000068505-16-000031:notes:138]
[same as prior period, unchanged from 0000068505-16-000026:notes:133]

[0000068505-16-000031:notes:139]
[same as prior period, unchanged from 0000068505-16-000026:notes:134]

[0000068505-16-000031:notes:140]
On August 9, 2016, the Company completed the acquisition of a provider of communications systems support and two-way radios, for a gross purchase price of $6 million, recognizing $5 million of identifiable intangible assets, which will be amortized over a period of five years. The results of operations for these acquisitions have been included in the Company’s condensed consolidated statements of operations subsequent to the acquisition date.

[0000068505-16-000031:notes:141]
On September 23, 2016, the Company entered into a stock purchase agreement with Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions. The acquisition, which is expected to close in the fourth quarter of 2016, will expand the Company's smart public safety portfolio and will enable the Company to offer a full suite of command center solutions to a broader customer base.

[0000068505-16-000031:notes:142]
[same as prior period, unchanged from 0000068505-16-000026:notes:135]

[0000068505-16-000031:notes:143]
The Company did not adjust the effects of an $884 million goodwill impairment charge reported in the historic results of GDCL for the nine months ended October 3, 2015 on the basis that the goodwill impairment charge was not directly attributable to the acquisition of GDCL by the Company. However, this goodwill impairment charge should be highlighted as unusual and non-recurring.

[0000068505-16-000031:notes:144]
[same as prior period, unchanged from 0000068505-16-000026:notes:137]

[0000068505-16-000031:notes:145]
[same as prior period, unchanged from 0000068505-16-000026:notes:138]

[0000068505-16-000031:notes:146]
[same as prior period, unchanged from 0000068505-16-000026:notes:139]

[0000068505-16-000031:notes:147]
|  | October 1, 2016 |  | December 31, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Completed technology | $ | 60 |  |  | $ | 36 |  |  | $ | 60 |  |  | $ | 32 |  |
| Patents | 8 |  |  | 6 |  |  | 8 |  |  | 5 |  |
| Customer-related | 795 |  |  | 79 |  |  | 23 |  |  | 10 |  |
| Other intangibles | 43 |  |  | 16 |  |  | 20 |  |  | 15 |  |
|  | $ | 906 |  |  | $ | 137 |  |  | $ | 111 |  |  | $ | 62 |  |

[0000068505-16-000031:notes:148]
Amortization expense on intangible assets was $31 million for the three months ended October 1, 2016 and $83 million for the nine months ended October 1, 2016. Amortization expense on intangible assets was $2 million for the three months ended October 3, 2015 and $6 million for the nine months ended October 3, 2015. The increase in amortization expense is due to the acquisition of GDCL. As of October 1, 2016, annual amortization expense is estimated to be $114 million in 2016, $123 million in 2017,  $122 million in 2018 and 2019, $119 million in 2020, and $118 million in 2021.

[0000068505-16-000031:notes:149]
[same as prior period, unchanged from 0000068505-16-000026:notes:142]

[0000068505-16-000031:notes:150]
The following table displays a rollforward of the carrying amount of goodwill by segment from January 1, 2016 to October 1, 2016:

[0000068505-16-000031:notes:151]
|  | Products |  | Services |  | Total |
| Balance as of January 1, 2016 |  |  |  |  |  |
| Aggregate goodwill | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 150 |  |  | $ | 420 |  |
| Goodwill acquired | — |  |  | 170 |  |  | 170 |  |
| Purchase accounting adjustments | — |  |  | 25 |  |  | 25 |  |
| Foreign currency | — |  |  | (18 | ) |  | (18 | ) |
| Balance as of October 1, 2016 |  |  |  |  |  |
| Aggregate goodwill | $ | 270 |  |  | $ | 327 |  |  | $ | 597 |  |
| Accumulated impairment losses | — |  |  | — |  |  | — |  |
| Goodwill, net of impairment losses | $ | 270 |  |  | $ | 327 |  |  | $ | 597 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-16-000031:notes:152]
[same as prior period, unchanged from 0000068505-16-000026:notes:145]

[0000068505-16-000031:notes:153]
[same as prior period, unchanged from 0000068505-16-000026:notes:146]

[0000068505-16-000031:notes:154]
[same as prior period, unchanged from 0000068505-16-000026:notes:147]

[0000068505-16-000031:notes:155]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Earnings from continuing operations before income taxes | $ | 293 |  |  | $ | 197 |  |  | $ | 482 |  |  | $ | 540 |  |
| Income tax expense | 100 |  |  | 71 |  |  | 164 |  |  | 175 |  |
| Effective tax rate | 34 | % |  | 36 | % |  | 34 | % |  | 32 | % |

[0000068505-16-000031:notes:156]
The Company recorded $100 million of net tax expense in the third quarter of 2016 resulting in an effective tax rate of 34%, compared to $71 million of net tax expense in the third quarter of 2015 resulting in an effective tax rate of 36%. The effective tax rate in the third quarter of 2016 was lower than the U.S. statutory tax rate of 35% partly due to favorable discrete adjustments to deferred tax assets of foreign subsidiaries. The effective tax rate in the third quarter of 2015 was higher than the U.S. statutory tax rate of 35% primarily due to higher income in the U.S. relative to foreign operations.

[0000068505-16-000031:notes:157]
The Company recorded $164 million of net tax expense in the first nine months of 2016 resulting in an effective tax rate of 34%, compared to $175 million of net tax expense resulting in an effective tax rate of 32% in the first nine months of 2015. The effective tax rate for the first nine months of 2016 was lower than the U.S. statutory tax rate of 35% partly due to the recognition of excess tax benefits on share-based compensation. The effective tax rate in the first nine months of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S. domestic production tax deduction.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000068505-16-000031:notes:158]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. This ASU requires additional disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the Company’s annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, "Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)" which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. In April of 2016, the FASB issued ASU 2016-10, "Revenue from Contracts with Customers (Topic 606) - Identifying Performance Obligations and Licensing,” which reduces the complexity when applying the guidance for identifying performance obligations and improves the operability and understandability of the license implementation guidance. In May 2016, the FASB issued ASU 2016-12 “Revenue from Contracts with Customers (Topic 606) - Narrow-Scope Improvements and Practical Expedients,” which amends the guidance on transition, collectability, non-cash consideration, and the presentation of sales and other similar taxes. ASU 2016-12 clarifies that, for a contract to be considered completed at transition, all (or substantially all) of the revenue must have been recognized under legacy GAAP. In addition, ASU 2016-12 clarifies how an entity should evaluate the collectability threshold and when an entity can recognize nonrefundable consideration received as revenue if an arrangement does not meet the standard’s contract criteria. The standard allows for both retrospective and modified retrospective methods of adoption. The Company is in the process of determining the method of adoption it will elect and is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-16-000031:notes:159]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for the Company January 1, 2019 and interim periods within that reporting period. The ASU requires a modified retrospective method upon adoption. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-16-000031:notes:160]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for the Company January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so for which it must be retrospectively applied at the earliest date practical. Upon adoption, the Company does not anticipate significant changes to the Company's existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-16-000031:notes:161]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for the Company on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact of this ASU on its consolidated financial statements and footnote disclosures.

[0000068505-16-000031:notes:162]
The Company elected to adopt ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting,” as of January 1, 2016. ASU 2016-09, which was issued by the FASB in March 2016, simplifies several aspects of the accounting for employee share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The impact of the prospective adoption of the provisions related to the recognition of excess tax benefits in income tax expense was a $5 million income tax benefit during the nine months ended October 1, 2016. Additionally, as a result of the adoption of this accounting standard, excess tax benefits on share-based compensation have been reported as a component of operating cash rather than within financing cash flows as previously presented, while the payment of withholding taxes on the settlement of share-based awards has been reported as a component of financing cash flows rather than within operating cash flows as previously presented. The change in presentation of withholding taxes within the condensed consolidated statements of cash flows has been adopted retrospectively, thereby increasing operating cash flows and reducing financing cash flows by $16 million for both the nine months ended October 1, 2016 and October 3, 2015. The presentation of excess tax benefits on share-based compensation has been adjusted prospectively within the condensed consolidated statement of cash flows, increasing operating cash flow and decreasing financing cash flow by $5 million for the nine months ended October 1, 2016.

[0000068505-16-000031:notes:163]
The Company adopted ASU No. 2015-03, "Interest-Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs," effective January 1, 2016. Under this guidance, debt issuance costs related to a recognized debt liability are required to be presented in the balance sheet as a direct reduction from the carrying amount of such debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by this guidance. We have retrospectively adopted ASU 2015-03 effective January 1, 2016. As a result, debt issuance costs which were previously capitalized in other assets in the condensed consolidated balance sheet have been presented as a reduction to long-term debt. As of October 1, 2016 and December 31, 2015, $31 million and $41 million, respectively, have been presented as a component of long-term debt.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-16-000031:notes:164]
[same as prior period, unchanged from 0000068505-16-000026:notes:158]

[0000068505-16-000031:notes:165]
[same as prior period, unchanged from 0000068505-16-000026:notes:162]

[0000068505-16-000031:notes:166]
On February 19, 2016, the Company completed the acquisition of Guardian Digital Communications Limited ("GDCL"), a holding company of Airwave Solutions Limited ("Airwave"), the largest private operator of a public safety network in the world. All of the outstanding equity of GDCL was acquired for the sum of £1, after which the Company invested into GDCL £698 million, net of cash acquired, or approximately $1.0 billion, to settle all third party debt. The Company will make a deferred cash payment of £64 million on November 15, 2018. The Company funded the investment with a $675 million term loan (the “Term Loan”) and approximately $400 million of international cash on hand. The acquisition has been reported within our Services segment, enabling the Company to geographically diversify its global Managed & Support services offerings, while offering a proven service delivery platform to build on for providing innovative, leading, mission-critical communications solutions and services to customers. See discussion in Note 14.

[0000068505-16-000031:notes:167]
Recent Accounting Pronouncements


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-16-000031:notes:168]
[same as prior period, unchanged from 0000068505-16-000026:notes:164]

[0000068505-16-000031:notes:169]
[same as prior period, unchanged from 0000068505-16-000026:notes:165]

[0000068505-16-000031:notes:170]
[same as prior period, unchanged from 0000068505-16-000026:notes:166]

[0000068505-16-000031:notes:171]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 46 |  |  | 48 |  |  | 13 |  |  | 14 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (55 | ) |  | (53 | ) |  | (23 | ) |  | (23 | ) |  | (2 | ) |  | (2 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 9 |  |  | 12 |  |  | 3 |  |  | 5 |  |  | 1 |  |  | 3 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (1 | ) |  | (7 | ) |  | (15 | ) |
| Net periodic pension cost (benefit) | $ | — |  |  | $ | 7 |  |  | $ | (5 | ) |  | $ | (2 | ) |  | $ | (7 | ) |  | $ | (12 | ) |

[0000068505-16-000031:notes:172]
The Company made no contributions to its U.S. Pension Benefit Plans during both the three months ended October 1, 2016 and October 3, 2015. The Company made $2 million of contributions to its Non U.S. Pension Benefit Plans during both the three months ended October 1, 2016 and October 3, 2015.

[0000068505-16-000031:notes:173]
|  | U.S. Pension Benefit Plans |  | Non U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Nine Months Ended | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 6 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 138 |  |  | 144 |  |  | 41 |  |  | 49 |  |  | 3 |  |  | 6 |  |
| Expected return on plan assets | (165 | ) |  | (159 | ) |  | (71 | ) |  | (79 | ) |  | (7 | ) |  | (7 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 27 |  |  | 35 |  |  | 9 |  |  | 13 |  |  | 4 |  |  | 8 |  |
| Unrecognized prior service benefit | — |  |  | — |  |  | — |  |  | (3 | ) |  | (20 | ) |  | (45 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | — |  |
| Net periodic cost (benefit) | $ | — |  |  | $ | 20 |  |  | $ | (15 | ) |  | $ | (42 | ) |  | $ | (20 | ) |  | $ | (37 | ) |

[0000068505-16-000031:notes:174]
The Company made $2 million of contributions to its U.S. Pension Benefit Plans during the nine months ended October 1, 2016 and no contributions to its U.S. Pension Benefit Plans during the nine months ended October 3, 2015. During the nine months ended October 1, 2016 and October 3, 2015, the Company made $7 million and $8 million of contributions to its Non U.S. Pension Benefit Plans, respectively.

[0000068505-16-000031:notes:175]
During the nine months ended October 1, 2016, the Company made an amendment to the Postretirement Health Care Benefits Plan (the “Amendment”). As a result of the Amendment, all eligible retirees under the age of 65 will be provided an annual subsidy per household, versus per individual, toward the purchase of their own health care coverage from private insurance companies and for the reimbursement of eligible health care expenses.

[0000068505-16-000031:notes:176]
The Amendment to the Postretirement Health Care Benefits Plan required a remeasurement of the plan, resulting in a $53 million reduction in the accumulated Postretirement Benefit Obligation. A substantial portion of the decrease is related to a prior service credit and will be recognized as a credit to the condensed consolidated statements of operations over approximately five years, or the period in which the remaining employees eligible for the plan will qualify for benefits under the plan.

[0000068505-16-000031:notes:177]
During the nine months ended October 3, 2015, the Company amended its Non U.S. defined benefit plan within the United Kingdom by closing future benefit accruals to all participants effective December 31, 2015.  As a result, the Company recorded a curtailment gain of $32 million to Other charges in the Company’s condensed consolidated statements of operations.

[0000068505-16-000031:notes:178]
Effective January 1, 2016, the Company changed the method used to estimate the interest and service cost components of net periodic cost for defined benefit pension and other post-retirement benefit plans. Historically, the interest and service cost components were estimated using a single weighted-average discount rate derived from the yield curve used to measure the projected benefit obligation at the beginning of the period. The Company has elected to use a full yield curve approach in the estimation of these components of net periodic cost by applying the specific spot rates along the yield curve used in the determination of the projected benefit obligation to the relevant projected cash flows. The Company made this change to improve the correlation between projected benefit cash flows and the corresponding yield curve spot rates and to provide a more precise measurement of interest and service costs. This change does not affect the measurement of total benefit obligations as the change in interest and service cost is completely offset in the actuarial loss reported in the period. The Company has concluded that this change is a change in estimate and, therefore, has accounted for it prospectively beginning January 1, 2016. Based on the change in estimate, the Company experienced no reduction in service costs and a $21 million reduction in interest costs for the nine months ended October 1, 2016 compared to the prior approach. The overall reduction in the interest cost for the nine months ended October 1, 2016 is comprised of $14 million related to the U.S. Pension Benefit Plans, $3 million related to the Postretirement Health Care Benefit Plans, and $4 million related to the Non U.S. Pension Benefits Plan.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-16-000031:notes:179]
[same as prior period, unchanged from 0000068505-16-000026:notes:173]

[0000068505-16-000031:notes:180]
[same as prior period, unchanged from 0000068505-16-000026:notes:174]

[0000068505-16-000031:notes:181]
During the three months ended October 1, 2016, the Company recorded net reorganization of business charges of $7 million including $6 million of charges in Other charges and $1 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-16-000031:notes:182]
During the nine months ended October 1, 2016, the Company recorded net reorganization of business charges of $74 million including $48 million of charges in Other charges and $26 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $74 million were charges of: (i) $54 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-16-000031:notes:183]
The following table displays a rollforward of the reorganization of business accruals established for lease exit costs and employee separation costs from January 1, 2016 to October 1, 2016:

[0000068505-16-000031:notes:184]
|  | January 1, 2016 |  | AdditionalCharges |  | Adjustments |  | AmountUsed |  | October 1, 2016 |
| Exit costs | $ | 9 |  |  | $ | 5 |  |  | $ | — |  |  | $ | (5 | ) |  | $ | 9 |  |
| Employee separation costs | 51 |  |  | 54 |  |  | (5 | ) |  | (54 | ) |  | 46 |  |
|  | $ | 60 |  |  | $ | 59 |  |  | $ | (5 | ) |  | $ | (59 | ) |  | $ | 55 |  |

[0000068505-16-000031:notes:185]
[same as prior period, unchanged from 0000068505-16-000026:notes:179]

[0000068505-16-000031:notes:186]
At January 1, 2016, the Company had $9 million of accruals for exit costs. During the nine months ended October 1, 2016, there were $5 million of additional charges and $5 million of cash payments related to the exit of leased facilities. The remaining accrual of $9 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at October 1, 2016, primarily represents future cash payments for lease obligations that are expected to be paid over a number of years.

[0000068505-16-000031:notes:187]
[same as prior period, unchanged from 0000068505-16-000026:notes:181]

[0000068505-16-000031:notes:188]
At January 1, 2016, the Company had an accrual of $51 million for employee separation costs. The 2016 additional charges of $54 million represent severance costs for approximately 600 employees. The adjustment of $5 million reflects reversals for accruals no longer needed. The $54 million used reflects cash payments to severed employees. The remaining accrual of $46 million, which is included in Accrued liabilities in the Company’s condensed consolidated balance sheets at October 1, 2016, is expected to be paid, primarily within one year, to approximately 500 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-16-000031:notes:189]
[same as prior period, unchanged from 0000068505-16-000026:notes:183]

[0000068505-16-000031:notes:190]
During the three months ended October 3, 2015, the Company recorded net reorganization of business charges of $41 million including $40 million of charges in Other charges and $1 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $41 million were charges of: (i) $26 million for the impairment of corporate aircraft, (ii) $11 million of charges related to employee separation costs, and (iii) a $6 million building impairment charge, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-16-000031:notes:191]
During the nine months ended October 3, 2015, the Company recorded net reorganization of business charges of $70 million including $65 million of charges in Other charges and $5 million of charges in Cost of sales in the Company's condensed consolidated statements of operations. Included in the $70 million were charges of: (i) $36 million related to employee separation costs, (ii) $26 million for the impairment of the corporate aircraft, (iii) a $6 million building impairment charge, and (iv) $4 million for exit costs, partially offset by $2 million of reversals for accruals no longer needed.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000068505-16-000031:notes:192]
[same as prior period, unchanged from 0000068505-16-000026:notes:186]

[0000068505-16-000031:notes:193]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Products | $ | 920 |  |  | $ | 925 |  |  | $ | 2,423 |  |  | $ | 2,550 |  |
| Services | 612 |  |  | 497 |  |  | 1,732 |  |  | 1,463 |  |
|  | $ | 1,532 |  |  | $ | 1,422 |  |  | $ | 4,155 |  |  | $ | 4,013 |  |

[0000068505-16-000031:notes:194]
[same as prior period, unchanged from 0000068505-16-000026:notes:188]

[0000068505-16-000031:notes:195]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Products | $ | 225 |  |  | $ | 178 |  |  | $ | 404 |  |  | $ | 413 |  |
| Services | 116 |  |  | 53 |  |  | 260 |  |  | 192 |  |
| Operating earnings | 341 |  |  | 231 |  |  | 664 |  |  | 605 |  |
| Total other expense | (48 | ) |  | (34 | ) |  | (182 | ) |  | (65 | ) |
| Earnings from continuing operations before income taxes | $ | 293 |  |  | $ | 197 |  |  | $ | 482 |  |  | $ | 540 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-16-000031:notes:196]
[same as prior period, unchanged from 0000068505-16-000026:notes:190]

[0000068505-16-000031:notes:197]
[same as prior period, unchanged from 0000068505-16-000026:notes:191]

[0000068505-16-000031:notes:198]
[same as prior period, unchanged from 0000068505-16-000026:notes:192]

[0000068505-16-000031:notes:199]
[same as prior period, unchanged from 0000068505-16-000026:notes:193]
