# MSI 8-K — 0001193125-16-758852 filed 2016-11-03

## item codes, every 8-K on or before 2016-11-04

- 2016-11-03 0001193125-16-758852 — 2.02, 8.01, 9.01
- 2016-08-04 0001193125-16-671842 — 2.02, 8.01, 9.01
- 2016-05-18 0001193125-16-593797 — 5.07
- 2016-05-11 0001193125-16-586357 — 8.01
- 2016-05-06 0001193125-16-582060 — 7.01
- 2016-05-06 0000068505-16-000023 — 9.01 — amendment of 0001193125-16-419974
- 2016-05-05 0001193125-16-579931 — 2.02, 9.01
- 2016-03-09 0001193125-16-497479 — 5.02
- 2016-02-22 0001193125-16-471662 — 2.02, 9.01
- 2016-02-22 0001193125-16-471656 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2016-02-04 0001193125-16-450694 — 5.02 — amendment, the index does not say of what
- 2016-01-04 0001193125-16-419974 — 5.02
- 2015-12-03 0001193125-15-394401 — 1.01, 7.01, 9.01
- 2015-11-12 0001193125-15-374665 — 5.02
- 2015-11-04 0001193125-15-365195 — 2.02, 9.01
- 2015-08-27 0001193125-15-304989 — 8.01
- 2015-08-26 0001193125-15-302296 — 1.01, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-08-19 0001193125-15-296211 — 5.02
- 2015-08-05 0001193125-15-277673 — 1.01, 2.02, 2.03, 3.02, 5.02, 8.01, 9.01
- 2015-05-21 0001193125-15-196530 — 5.02, 5.07, 9.01
- 2015-05-06 0001193125-15-173187 — 2.02, 9.01
- 2015-03-11 0001193125-15-087345 — 5.02, 9.01
- 2015-02-04 0001193125-15-032592 — 2.02, 9.01
- 2014-12-03 0001193125-14-432314 — 8.01
- 2014-12-02 0001193125-14-430940 — 8.01
- 2014-11-14 0001193125-14-412634 — 5.02, 5.03, 9.01
- 2014-11-05 0001193125-14-397470 — 1.01, 8.01, 9.01
- 2014-11-04 0001193125-14-395045 — 2.02, 8.01, 9.01
- 2014-10-27 0001193125-14-382899 — 2.01, 8.01, 9.01
- 2014-09-25 0001193125-14-352425 — 1.01, 8.01
- 2014-09-25 0001193125-14-352184 — 7.01, 9.01
- 2014-08-19 0001193125-14-314669 — 8.01
- 2014-08-19 0001104659-14-061954 — 8.01, 9.01
- 2014-08-14 0001104659-14-061134 — 8.01, 9.01
- 2014-08-12 0001104659-14-059600 — 8.01, 9.01
- 2014-08-07 0000068505-14-000013 — 8.01, 9.01
- 2014-08-06 0001193125-14-296963 — 8.01
- 2014-08-05 0001193125-14-294493 — 2.02, 9.01
- 2014-07-31 0001193125-14-289918 — 2.02, 9.01
- 2014-06-02 0001193125-14-222463 — 1.01, 1.02, 2.03, 9.01
- 2014-05-21 0001193125-14-207499 — 5.02
- 2014-05-07 0001193125-14-187556 — 5.07
- 2014-05-01 0001193125-14-176111 — 2.02, 9.01
- 2014-05-01 0001193125-14-174469 — 2.02, 9.01
- 2014-04-16 0001193125-14-144987 — 1.01, 9.01
- 2014-04-15 0001193125-14-143406 — 2.02, 7.01, 8.01, 9.01
- 2014-03-13 0001193125-14-097794 — 5.02, 9.01
- 2014-01-22 0001193125-14-016644 — 2.02, 9.01
- 2013-12-20 0001193125-13-480957 — 5.02
- 2013-12-10 0001193125-13-468436 — 5.02
- 2013-11-22 0001193125-13-451323 — 8.01
- 2013-11-15 0001193125-13-443971 — 5.02, 9.01
- 2013-10-23 0001193125-13-407345 — 2.02, 9.01
- 2013-08-15 0001193125-13-336611 — 8.01
- 2013-08-14 0001193125-13-334770 — 5.02, 9.01
- 2013-07-24 0001193125-13-299649 — 2.02, 8.01, 9.01
- 2013-06-14 0001193125-13-259567 — 5.02, 9.01
- 2013-06-05 0001193125-13-248649 — 5.02, 9.01
- 2013-05-23 0001193125-13-233410 — 5.02
- 2013-05-08 0001193125-13-207659 — 5.02, 5.07, 9.01
- 2013-04-24 0001193125-13-168755 — 2.02, 9.01
- 2013-02-28 0001193125-13-082786 — 8.01, 9.01
- 2013-02-13 0001193125-13-055477 — 8.01
- 2013-01-23 0001193125-13-019977 — 2.02, 9.01
- 2013-01-17 0001193125-13-015999 — 5.02, 5.03, 9.01
- 2013-01-07 0001193125-13-004747 — 5.02
- 2012-12-13 0001193125-12-500889 — 5.02
- 2012-11-08 0001193125-12-459892 — 8.01
- 2012-10-26 0001193125-12-437017 — 5.02, 9.01
- 2012-10-24 0001193125-12-432293 — 2.02, 9.01
- 2012-07-25 0001193125-12-313360 — 2.02, 8.01, 9.01
- 2012-05-15 0001193125-12-235026 — 8.01, 9.01
- 2012-05-11 0001193125-12-227168 — 5.02
- 2012-05-01 0001193125-12-201277 — 5.07
- 2012-04-25 0001193125-12-180265 — 2.02, 9.01
- 2012-02-27 0001193125-12-079815 — 1.01, 5.02, 8.01, 9.01
- 2012-01-30 0001193125-12-028157 — 8.01, 9.01
- 2012-01-25 0001193125-12-022552 — 2.02, 9.01
- 2011-10-27 0001193125-11-283059 — 2.02, 9.01
- 2011-07-28 0001193125-11-199834 — 2.02, 5.02, 8.01, 9.01
- 2011-06-21 0001193125-11-169498 — 8.01, 9.01
- 2011-05-12 0001193125-11-137663 — 8.01, 9.01
- 2011-05-05 0001193125-11-128276 — 5.07, 8.01
- 2011-05-02 0001193125-11-120834 — 2.01, 7.01, 9.01
- 2011-04-28 0001193125-11-113445 — 2.02, 9.01
- 2011-04-14 0001193125-11-097289 — 2.02, 9.01
- 2011-04-13 0001193125-11-095863 — 1.01
- 2011-03-17 0001193125-11-070135 — 5.02, 9.01
- 2011-01-31 0001193125-11-018893 — 5.02, 9.01
- 2011-01-28 0001193125-11-017574 — 5.02, 9.01
- 2011-01-27 0001193125-11-015379 — 2.02, 9.01
- 2011-01-10 0001104659-11-001040 — 1.01, 1.02, 2.01, 2.03, 5.03, 8.01, 9.01
- 2010-12-01 0001104659-10-060618 — 5.02, 5.07, 8.01, 9.01
- 2010-10-28 0001104659-10-054147 — 2.02, 9.01
- 2010-09-30 0001104659-10-050666 — 2.02, 9.01
- 2010-08-05 0001104659-10-042358 — 5.02, 8.01, 9.01
- 2010-07-30 0001104659-10-040738 — 5.02, 9.01
- 2010-07-29 0001104659-10-040311 — 2.02, 9.01
- 2010-07-19 0001104659-10-038421 — 1.01, 7.01, 9.01
- 2010-07-01 0001193125-10-152606 — 8.01, 9.01
- 2010-05-28 0001104659-10-031602 — 5.02, 9.01
- 2010-05-25 0001104659-10-030723 — 8.01, 9.01
- 2010-05-05 0001104659-10-025794 — 5.07
- 2010-05-05 0001047469-10-004773 — 8.01, 9.01
- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2016-11-04

- none on or before 2016-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-758852:8k_2_02:1]
EX-99.1
2
d286199dex991.htm
EX-99.1

[0001193125-16-758852:8k_2_02:2]
EX-99.1

[0001193125-16-758852:8k_2_02:3]
Exhibit 99.1

[0001193125-16-758852:8k_2_02:4]
Motorola Solutions Reports Third-Quarter 2016 Financial Results

[0001193125-16-758852:8k_2_02:5]
Announces dividend increase of 15 percent to 47 cents per share

[0001193125-16-758852:8k_2_02:6]
|  | • |  | Sales of $1.5 billion, up 8 percent from a year ago, including $131 million from Airwave |

[0001193125-16-758852:8k_2_02:7]
|  | • |  | Managed and Support Services up 55 percent; up 5 percent excluding Airwave |

[0001193125-16-758852:8k_2_02:8]
|  | • |  | North America up 4 percent on strength in both Products and Services |

[0001193125-16-758852:8k_2_02:9]
|  | • |  | Operating cash flow of $348 million, up 16 percent |

[0001193125-16-758852:8k_2_02:10]
|  | • |  | GAAP earnings per share (EPS) from continuing operations1 of $1.13, up 79 percent |

[0001193125-16-758852:8k_2_02:11]
|  | • |  | Non-GAAP EPS from continuing operations* of $1.37, up 67 percent |

[0001193125-16-758852:8k_2_02:12]
CHICAGO – Nov. 3, 2016 – Motorola Solutions, Inc. (NYSE: MSI) today reported its earnings results for the third quarter of 2016.
Click here for a printable news release and financial tables.

[0001193125-16-758852:8k_2_02:13]
The company also today announced that its board of directors has increased its
regular quarterly dividend by 15 percent to 47 cents per share. The next quarterly dividend will be payable in cash on Jan. 13, 2017, to stockholders of record at the close of business on Dec. 15, 2016.

[0001193125-16-758852:8k_2_02:14]
“Q3 was an excellent quarter,” said Greg Brown, chairman and CEO of Motorola Solutions. “I’m pleased with our revenue growth and continued
strong performance in earnings and cash flow generation.”

[0001193125-16-758852:8k_2_02:15]
KEY FINANCIAL RESULTS (presented in millions, except per share data and
percentages)

[0001193125-16-758852:8k_2_02:16]
|  |  | Q3 2016 |  |  | Q3 2015 |  |  | % Change |  |
| Sales |  | $ | 1,532 |  |  | $ | 1,422 |  |  |  | 8 | % |
| GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 341 |  |  | $ | 231 |  |  |  | 48 | % |
| % of Sales |  |  | 22.3 | % |  |  | 16.2 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 1.13 |  |  | $ | 0.63 |  |  |  | 79 | % |
| Non-GAAP |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Earnings |  | $ | 396 |  |  | $ | 292 |  |  |  | 36 | % |
| % of Sales |  |  | 25.8 | % |  |  | 20.5 | % |  |  |  |  |
| EPS from continuing operations |  | $ | 1.37 |  |  | $ | 0.82 |  |  |  | 67 | % |
| Products Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 920 |  |  | $ | 925 |  |  |  | (1 | )% |
| GAAP Operating Earnings |  | $ | 225 |  |  | $ | 178 |  |  |  | 26 | % |
| % of Sales |  |  | 24.5 | % |  |  | 19.2 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 243 |  |  | $ | 221 |  |  |  | 10 | % |
| % of Sales |  |  | 26.4 | % |  |  | 23.9 | % |  |  |  |  |
| Services Segment |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales |  | $ | 612 |  |  | $ | 497 |  |  |  | 23 | % |
| GAAP Operating Earnings |  | $ | 116 |  |  | $ | 53 |  |  |  | 119 | % |
| % of Sales |  |  | 19.0 | % |  |  | 10.7 | % |  |  |  |  |
| Non-GAAP Operating Earnings |  | $ | 153 |  |  | $ | 71 |  |  |  | 115 | % |
| % of Sales |  |  | 25.0 | % |  |  | 14.3 | % |  |  |  |  |

[0001193125-16-758852:8k_2_02:17]
| * | Non-GAAP financial information excludes the after-tax impact of approximately $0.24 per diluted share related to share-based compensation, intangible assets amortization expense and highlighted items. Details on these non-GAAP adjustments and the use of non-GAAP measures are included later in this news release. |

[0001193125-16-758852:8k_2_02:18]
OTHER SELECTED FINANCIAL RESULTS

[0001193125-16-758852:8k_2_02:19]
|  | • |  | Revenue – Sales increased 8 percent, including $131 million in Airwave sales. Products segment sales declined 1 percent due to softness in Africa and China. The Services segment grew 23 percent including Airwave, while Managed and Support Services grew 5 percent excluding Airwave. |

[0001193125-16-758852:8k_2_02:20]
|  | • |  | Operating margin – GAAP operating margin was 22.3 percent of sales, compared with 16.2 percent in the year-ago quarter. The improvement reflects higher sales and gross margin associated with Airwave, as well as lower operating expenses. Non-GAAP operating margin was 25.8 percent of sales, compared with 20.5 percent in the year-ago quarter, driven by higher sales and gross margin as well as $27 million in lower operating expenses compared with the year-ago quarter. |

[0001193125-16-758852:8k_2_02:21]
|  | • |  | Taxes – The GAAP effective tax rate was 34 percent, compared with a tax rate of 36 percent in the year-ago quarter. The non-GAAP tax rate was 33 percent, compared with a non-GAAP tax rate of 35 percent in the year-ago quarter. |

[0001193125-16-758852:8k_2_02:22]
|  | • |  | Cash flow – The company generated $348 million in operating cash from continuing operations, reflecting an increase of $47 million from the year-ago quarter. Free cash flow2 was up $29 million to $280 million, driven by higher earnings. |

[0001193125-16-758852:8k_2_02:23]
|  | • |  | Cash and cash equivalents – The company ended the quarter with cash and cash equivalents of $1.7 billion and a net debt position of approximately $3.4 billion3. The company repurchased approximately $109 million of its common stock and paid approximately $70 million in cash dividends. |

[0001193125-16-758852:8k_2_02:24]
KEY HIGHLIGHTS

[0001193125-16-758852:8k_2_02:25]
Strategic wins

[0001193125-16-758852:8k_2_02:26]
|  | • |  | $37 million to expand a nationwide TETRA network in North Africa |

[0001193125-16-758852:8k_2_02:27]
|  | • |  | $34 million in two P25 contracts with the U.S. federal government |

[0001193125-16-758852:8k_2_02:28]
|  | • |  | $28 million for a P25 network in Latin America |

[0001193125-16-758852:8k_2_02:29]
|  | • |  | $20 million for a P25 network with U.S. utility provider Xcel Energy |

[0001193125-16-758852:8k_2_02:30]
|  | • |  | $12 million for call-taking and computer-aided dispatch (CAD) solutions, including five-year service contract with Los Angeles Police Department |

[0001193125-16-758852:8k_2_02:31]
Innovation and investments in growth

[0001193125-16-758852:8k_2_02:32]
|  | • |  | Announced plans to acquire Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions for computer-aided dispatch and records management systems. Spillman complements our high tier command center software offerings, which will help us meet the needs of a broader customer base |

[0001193125-16-758852:8k_2_02:33]
|  | • |  | Announced new APXTM 8500 P25 all-band mobile radio, updated P25 network features and IMPRESTM 2 energy management system |

[0001193125-16-758852:8k_2_02:34]
BUSINESS OUTLOOK

[0001193125-16-758852:8k_2_02:35]
Motorola
Solutions expects fourth quarter revenue growth of 9 to 10 percent compared with the fourth quarter of 2015. This includes approximately $120 million of Airwave revenue. The company expects fourth-quarter non-GAAP earnings per share from
continuing operations in the range of $1.82 to $1.87 per share.

[0001193125-16-758852:8k_2_02:36]
CONFERENCE CALL AND WEBCAST

[0001193125-16-758852:8k_2_02:37]
Motorola Solutions will host its quarterly conference call beginning at 4 p.m. U.S. Central Daylight Time (5 p.m. U.S. Eastern Daylight Time) on Thursday, Nov
3. The conference call will be webcast live with audio and slides at www.motorolasolutions.com/investor.

[0001193125-16-758852:8k_2_02:38]
CONSOLIDATED GAAP RESULTS (presented
in millions, except per share data)

[0001193125-16-758852:8k_2_02:39]
A comparison of results from operations is as follows:

[0001193125-16-758852:8k_2_02:40]
|  |  | Q3 2016 |  |  | Q3 2015 |  |
| Net sales |  | $ | 1,532 |  |  | $ | 1,422 |  |
| Gross margin |  |  | 762 |  |  |  | 685 |  |
| Operating earnings |  |  | 341 |  |  |  | 231 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  |  | 192 |  |  |  | 126 |  |
| Net earnings |  |  | 192 |  |  |  | 115 |  |
| Diluted EPS from continuing operations |  | $ | 1.13 |  |  | $ | 0.63 |  |
| Weighted average diluted common shares outstanding |  |  | 169.6 |  |  |  | 201.3 |  |

[0001193125-16-758852:8k_2_02:41]
HIGHLIGHTED ITEMS AND SHARE-BASED COMPENSATION EXPENSE

[0001193125-16-758852:8k_2_02:42]
The table below includes highlighted items, share-based compensation expense and intangible amortization for the third quarter of 2016.

[0001193125-16-758852:8k_2_02:43]
| (per diluted common share) |  | Q3 2016 |  |
| GAAP Earnings from Continuing Operations |  | $ | 1.13 |  |
| Highlighted Items: |  |  |  |  |
| Share-based compensation expense |  |  | 0.07 |  |
| Reorganization of business charges |  |  | 0.03 |  |
| Intangibles amortization expense |  |  | 0.14 |  |
| Total Highlighted Items |  |  | 0.24 |  |
| Non-GAAP Diluted EPS from Continuing Operations |  | $ | 1.37 |  |

[0001193125-16-758852:8k_2_02:44]
USE OF NON-GAAP FINANCIAL INFORMATION

[0001193125-16-758852:8k_2_02:45]
In addition to the GAAP results included in this presentation, Motorola Solutions also has included non-GAAP measurements of results. The company has provided
these non-GAAP measurements to help investors better understand its core operating performance, enhance comparisons of core operating performance from period to period and allow better comparisons of operating performance to its competitors. Among
other things, management uses these operating results, excluding the identified items, to evaluate performance of the businesses and to evaluate results relative to certain incentive compensation targets. Management uses operating results excluding
these items because it believes this measurement enables it to make better period-to-period evaluations of the financial performance of core business operations. The non-GAAP measurements are intended only as a supplement to the comparable GAAP
measurements and the company compensates for the limitations inherent in the use of non-GAAP measurements by using GAAP measures in conjunction with the non-GAAP measurements. As a result, investors should consider these non-GAAP measurements in
addition to, and not in substitution for or as superior to, measurements of financial performance prepared in accordance with generally accepted accounting principles.

[0001193125-16-758852:8k_2_02:46]
Highlighted items: The company has excluded the effects of highlighted items (and any reversals of
highlighted items recorded in prior periods) from its non-GAAP operating expenses and net income measurements because the company believes that these historical items do not reflect expected future operating earnings or expenses and do not
contribute to a meaningful evaluation of the company’s current operating performance or comparisons to the company’s past operating performance.

[0001193125-16-758852:8k_2_02:47]
Share-based compensation expense: The company has excluded share-based compensation expense from its non-GAAP operating expenses and net income
measurements. Although share-based compensation is a key incentive offered to the company’s employees and the company believes such compensation contributed to the revenue earned during the periods presented and also believes it will contribute
to the generation of future period revenues, the company continues to evaluate its performance excluding share-based compensation expense primarily because it represents a significant non-cash expense. Share-based compensation expense will recur in
future periods.

[0001193125-16-758852:8k_2_02:48]
Intangible assets amortization expense: The company has excluded intangible assets amortization expense from its Non-GAAP
operating expenses and net earnings measurements, primarily because it represents a non-cash expense and because the company evaluates its performance excluding intangible assets amortization expense. Amortization of intangible assets is consistent
in amount and frequency but is significantly affected by the timing and size of the company’s acquisitions. Investors should note that the use of intangible assets contributed to the company’s revenues earned during the periods presented
and will contribute to the company’s future period revenues as well. Intangible assets amortization expense will recur in future periods.

[0001193125-16-758852:8k_2_02:49]
Details of
the above items and reconciliations of the non-GAAP measurements to the corresponding GAAP measurements can be found at the end of this press release.

[0001193125-16-758852:8k_2_02:50]
BUSINESS RISKS

[0001193125-16-758852:8k_2_02:51]
company’s products; (4) the company’s ability to refresh existing and introduce new products and technologies in a timely manner; (5) negative impact on the company’s business from
global economic and political conditions, which may include: (i) continued deferment or cancellation of purchase orders by customers; (ii) the inability of customers to obtain financing for purchases of the company’s products; (iii) increased
demand to provide vendor financing to customers; (iv) increased financial pressures on third-party dealers, distributors and retailers; (v) the viability of the company’s suppliers that may no longer have access to necessary financing; (vi)
counterparty failures negatively impacting the company’s financial position; (vii) changes in the value of investments held by the company’s pension plan and other defined benefit plans, which could impact future required or voluntary
pension contributions; and (viii) the company’s ability to access the capital markets on acceptable terms and conditions; (6) the impact of a security breach or other significant disruption in the company’s IT systems, those of its
partners or suppliers or those it sells to or operates or maintains for its customers; (7) the outcome of ongoing and future tax matters; (8) the company’s ability to purchase sufficient materials, parts and components to meet customer demand,
particularly in light of global economic conditions and reductions in the company’s purchasing power; (9) risks related to dependence on certain key suppliers, subcontractors, third-party distributors and other representatives; (10) the impact
on the company’s performance and financial results from strategic acquisitions or divestitures, including the acquisition of Airwave; (11) risks related to the company’s manufacturing and business operations in foreign countries; (12) the
creditworthiness of the company’s customers and distributors, particularly purchasers of large infrastructure systems; (13) exposure under large systems and managed services contracts, including risks related to the fact that certain customers
require that the company build, own and operate their systems, often over a multi-year period; (14) the ownership of certain logos, trademarks, trade names and service marks including “MOTOROLA” by Motorola Mobility Holdings, Inc.; (15)
variability in income received from licensing the company’s intellectual property to others, as well as expenses incurred when the company licenses intellectual property from others; (16) unexpected liabilities or expenses, including
unfavorable outcomes to any pending or future litigation or regulatory or similar proceedings; (17) the impact of the percentage of cash and cash equivalents held outside of the United States; (18) the ability of the company to pay future dividends
due to possible adverse market conditions or adverse impacts on the company’s cash flow; (19) the ability of the company to repurchase shares under its repurchase program due to possible adverse market conditions or adverse impacts on the
company’s cash flow; (20) the impact of changes in governmental policies, laws or regulations; (21) negative consequences from the company’s outsourcing of various activities, including certain manufacturing operations, information
technology and administrative functions; (22) the impact of the sale of the company’s legacy information systems, including components of the enterprise resource planning (ERP) system and the implementation of a new ERP system; and (23) the
company’s ability to settle the par value of its Senior Convertible Notes in cash. Motorola Solutions undertakes no obligation to publicly update any forward-looking statement or risk factor, whether as a result of new information, future
events or otherwise.

[0001193125-16-758852:8k_2_02:52]
DEFINITIONS

[0001193125-16-758852:8k_2_02:53]
| 1 | Amounts attributable to Motorola Solutions, Inc. common shareholders |

[0001193125-16-758852:8k_2_02:54]
| 2 | Free cash flow represents operating cash flow less capital expenditures |

[0001193125-16-758852:8k_2_02:55]
| 3 | Net debt represents cash and cash equivalents less long-term debt, including current portion |

[0001193125-16-758852:8k_2_02:56]
ABOUT MOTOROLA SOLUTIONS

[0001193125-16-758852:8k_2_02:57]
Motorola Solutions (NYSE: MSI) creates innovative, mission-critical communication solutions and services that help public safety and commercial customers build
safer cities and thriving communities. For ongoing news, visit www.motorolasolutions.com/newsroom or subscribe to a news feed.

[0001193125-16-758852:8k_2_02:58]
MEDIA
CONTACT

[0001193125-16-758852:8k_2_02:59]
Tama McWhinney

[0001193125-16-758852:8k_2_02:60]
Motorola Solutions

[0001193125-16-758852:8k_2_02:61]
+1 847-538-1865

[0001193125-16-758852:8k_2_02:62]
tama.mcwhinney@motorolasolutions.com

[0001193125-16-758852:8k_2_02:63]
INVESTOR CONTACT

[0001193125-16-758852:8k_2_02:64]
Chris Kutsor

[0001193125-16-758852:8k_2_02:65]
Motorola Solutions

[0001193125-16-758852:8k_2_02:66]
+1 847-576-4995

[0001193125-16-758852:8k_2_02:67]
chris.kutsor@motorolasolutions.com

[0001193125-16-758852:8k_2_02:68]
MOTOROLA, MOTOROLA
SOLUTIONS and the Stylized M Logo are trademarks or registered trademarks of Motorola Trademark Holdings, LLC and are used under license. All other trademarks are the property of their respective owners.
©2016 Motorola Solutions, Inc. All rights reserved.

[0001193125-16-758852:8k_2_02:69]
GAAP-1

[0001193125-16-758852:8k_2_02:70]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:71]
Condensed Consolidated Statements of Operations

[0001193125-16-758852:8k_2_02:72]
(In millions, except per share amounts)

[0001193125-16-758852:8k_2_02:73]
|  |  | Three Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Net sales from products |  | $ | 920 |  |  | $ | 925 |  |
| Net sales from services |  |  | 612 |  |  |  | 497 |  |
| Net sales |  |  | 1,532 |  |  |  | 1,422 |  |
| Costs of products sales |  |  | 398 |  |  |  | 395 |  |
| Costs of services sales |  |  | 372 |  |  |  | 342 |  |
| Costs of sales |  |  | 770 |  |  |  | 737 |  |
| Gross margin |  |  | 762 |  |  |  | 685 |  |
| Selling, general and administrative expenses |  |  | 247 |  |  |  | 259 |  |
| Research and development expenditures |  |  | 137 |  |  |  | 153 |  |
| Other charges |  |  | 6 |  |  |  | 40 |  |
| Intangibles amortization |  |  | 31 |  |  |  | 2 |  |
| Operating earnings |  |  | 341 |  |  |  | 231 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (54 | ) |  |  | (43 | ) |
| Gains on sales of investments and businesses, net |  |  | 7 |  |  |  | 10 |  |
| Other |  |  | (1 | ) |  |  | (1 | ) |
| Total other expense |  |  | (48 | ) |  |  | (34 | ) |
| Earnings from continuing operations before income taxes |  |  | 293 |  |  |  | 197 |  |
| Income tax expense |  |  | 100 |  |  |  | 71 |  |
| Earnings from continuing operations |  |  | 193 |  |  |  | 126 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (11 | ) |
| Net earnings |  |  | 193 |  |  |  | 115 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 192 |  |  | $ | 115 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 192 |  |  | $ | 126 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (11 | ) |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 192 |  |  | $ | 115 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.15 |  |  | $ | 0.63 |  |
| Discontinued operations |  |  | — |  |  |  | (0.05 | ) |
|  |  | $ | 1.15 |  |  | $ | 0.58 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.13 |  |  | $ | 0.63 |  |
| Discontinued operations |  |  | — |  |  |  | (0.06 | ) |
|  |  | $ | 1.13 |  |  | $ | 0.57 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 166.3 |  |  |  | 199.2 |  |
| Diluted |  |  | 169.6 |  |  |  | 201.3 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 60.1 | % |  |  | 65.0 | % |
| Net sales from services |  |  | 39.9 | % |  |  | 35.0 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 43.3 | % |  |  | 42.7 | % |
| Costs of services sales |  |  | 60.8 | % |  |  | 68.8 | % |
| Costs of sales |  |  | 50.3 | % |  |  | 51.8 | % |
| Gross margin |  |  | 49.7 | % |  |  | 48.2 | % |
| Selling, general and administrative expenses |  |  | 16.1 | % |  |  | 18.2 | % |
| Research and development expenditures |  |  | 8.9 | % |  |  | 10.8 | % |
| Other charges |  |  | 0.4 | % |  |  | 2.8 | % |
| Intangibles amortization |  |  | 2.0 | % |  |  | 0.1 | % |
| Operating earnings |  |  | 22.3 | % |  |  | 16.2 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.5 | )% |  |  | (3.0 | )% |
| Gains on sales of investments and businesses, net |  |  | 0.5 | % |  |  | 0.7 | % |
| Other |  |  | (0.1 | )% |  |  | (0.1 | )% |
| Total other expense |  |  | (3.1 | )% |  |  | (2.4 | )% |
| Earnings from continuing operations before income taxes |  |  | 19.1 | % |  |  | 13.9 | % |
| Income tax expense |  |  | 6.5 | % |  |  | 5.0 | % |
| Earnings from continuing operations |  |  | 12.6 | % |  |  | 8.9 | % |
| Loss from discontinued operations, net of tax |  |  | — | % |  |  | (0.8 | )% |
| Net earnings |  |  | 12.6 | % |  |  | 8.1 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | 0.1 | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 12.5 | % |  |  | 8.1 | % |

[0001193125-16-758852:8k_2_02:74]
| * | Percentages may not add up due to rounding |

[0001193125-16-758852:8k_2_02:75]
GAAP-2

[0001193125-16-758852:8k_2_02:76]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:77]
Condensed Consolidated Statements of Operations

[0001193125-16-758852:8k_2_02:78]
(In millions, except per share amounts)

[0001193125-16-758852:8k_2_02:79]
|  |  | Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Net sales from products |  | $ | 2,423 |  |  | $ | 2,550 |  |
| Net sales from services |  |  | 1,732 |  |  |  | 1,463 |  |
| Net sales |  |  | 4,155 |  |  |  | 4,013 |  |
| Costs of products sales |  |  | 1,124 |  |  |  | 1,139 |  |
| Costs of services sales |  |  | 1,090 |  |  |  | 993 |  |
| Costs of sales |  |  | 2,214 |  |  |  | 2,132 |  |
| Gross margin |  |  | 1,941 |  |  |  | 1,881 |  |
| Selling, general and administrative expenses |  |  | 722 |  |  |  | 769 |  |
| Research and development expenditures |  |  | 411 |  |  |  | 468 |  |
| Other charges |  |  | 61 |  |  |  | 33 |  |
| Intangibles amortization |  |  | 83 |  |  |  | 6 |  |
| Operating earnings |  |  | 664 |  |  |  | 605 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (157 | ) |  |  | (122 | ) |
| Gains (losses) on sales of investments and businesses, net |  |  | (13 | ) |  |  | 60 |  |
| Other |  |  | (12 | ) |  |  | (3 | ) |
| Total other expense |  |  | (182 | ) |  |  | (65 | ) |
| Earnings from continuing operations before income taxes |  |  | 482 |  |  |  | 540 |  |
| Income tax expense |  |  | 164 |  |  |  | 175 |  |
| Earnings from continuing operations |  |  | 318 |  |  |  | 365 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (32 | ) |
| Net earnings |  |  | 318 |  |  |  | 333 |  |
| Less: Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 2 |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 317 |  |  | $ | 331 |  |
| Amounts attributable to Motorola Solutions, Inc. common stockholders: |  |  |  |  |  |  |  |  |
| Earnings from continuing operations, net of tax |  | $ | 317 |  |  | $ | 363 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (32 | ) |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 317 |  |  | $ | 331 |  |
| Earnings (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.85 |  |  | $ | 1.75 |  |
| Discontinued operations |  |  | — |  |  |  | (0.15 | ) |
|  |  | $ | 1.85 |  |  | $ | 1.60 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.82 |  |  | $ | 1.74 |  |
| Discontinued operations |  |  | — |  |  |  | (0.16 | ) |
|  |  | $ | 1.82 |  |  | $ | 1.58 |  |
| Weighted average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 171.0 |  |  |  | 207.2 |  |
| Diluted |  |  | 174.0 |  |  |  | 209.2 |  |
|  |  | Percentage of Net Sales* |  |
| Net sales from products |  |  | 58.3 | % |  |  | 63.5 | % |
| Net sales from services |  |  | 41.7 | % |  |  | 36.5 | % |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Costs of products sales |  |  | 46.4 | % |  |  | 44.7 | % |
| Costs of services sales |  |  | 62.9 | % |  |  | 67.9 | % |
| Costs of sales |  |  | 53.3 | % |  |  | 53.1 | % |
| Gross margin |  |  | 46.7 | % |  |  | 46.9 | % |
| Selling, general and administrative expenses |  |  | 17.4 | % |  |  | 19.2 | % |
| Research and development expenditures |  |  | 9.9 | % |  |  | 11.7 | % |
| Other charges |  |  | 1.5 | % |  |  | 0.8 | % |
| Intangibles amortization |  |  | 2.0 | % |  |  | 0.1 | % |
| Operating earnings |  |  | 16.0 | % |  |  | 15.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense, net |  |  | (3.8 | )% |  |  | (3.0 | )% |
| Gains (losses) on sales of investments and businesses, net |  |  | (0.3 | )% |  |  | 1.5 | % |
| Other |  |  | (0.3 | )% |  |  | (0.1 | )% |
| Total other expense |  |  | (4.4 | )% |  |  | (1.6 | )% |
| Earnings from continuing operations before income taxes |  |  | 11.6 | % |  |  | 13.5 | % |
| Income tax expense |  |  | 3.9 | % |  |  | 4.4 | % |
| Earnings from continuing operations |  |  | 7.7 | % |  |  | 9.1 | % |
| Loss from discontinued operations, net of tax |  |  | — | % |  |  | (0.8 | )% |
| Net earnings |  |  | 7.7 | % |  |  | 8.3 | % |
| Less: Earnings attributable to noncontrolling interests |  |  | — | % |  |  | — | % |
| Net earnings attributable to Motorola Solutions, Inc. |  |  | 7.6 | % |  |  | 8.2 | % |

[0001193125-16-758852:8k_2_02:80]
| * | Percentages may not add up due to rounding |

[0001193125-16-758852:8k_2_02:81]
GAAP-3

[0001193125-16-758852:8k_2_02:82]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:83]
Condensed Consolidated Balance Sheets

[0001193125-16-758852:8k_2_02:84]
(In millions)

[0001193125-16-758852:8k_2_02:85]
|  |  | October 1, 2016 |  |  | December 31, 2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,687 |  |  | $ | 1,980 |  |
| Accounts receivable, net |  |  | 1,164 |  |  |  | 1,362 |  |
| Inventories, net |  |  | 283 |  |  |  | 296 |  |
| Other current assets |  |  | 670 |  |  |  | 954 |  |
| Current assets held for disposition |  |  | — |  |  |  | 27 |  |
| Total current assets |  |  | 3,804 |  |  |  | 4,619 |  |
| Property, plant and equipment, net |  |  | 780 |  |  |  | 487 |  |
| Investments |  |  | 238 |  |  |  | 231 |  |
| Deferred income taxes |  |  | 2,187 |  |  |  | 2,278 |  |
| Goodwill |  |  | 597 |  |  |  | 420 |  |
| Other assets |  |  | 1,013 |  |  |  | 271 |  |
| Non-current assets held for disposition |  |  | — |  |  |  | 40 |  |
| Total assets |  | $ | 8,619 |  |  | $ | 8,346 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 5 |  |  | $ | 4 |  |
| Accounts payable |  |  | 406 |  |  |  | 518 |  |
| Accrued liabilities |  |  | 1,750 |  |  |  | 1,671 |  |
| Total current liabilities |  |  | 2,161 |  |  |  | 2,193 |  |
| Long-term debt |  |  | 5,044 |  |  |  | 4,345 |  |
| Other liabilities |  |  | 2,062 |  |  |  | 1,904 |  |
| Total Motorola Solutions, Inc. stockholders’ equity (deficit) |  |  | (659 | ) |  |  | (106 | ) |
| Noncontrolling interests |  |  | 11 |  |  |  | 10 |  |
| Total liabilities and stockholders’ equity |  | $ | 8,619 |  |  | $ | 8,346 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Net cash (debt)* |  | $ | (3,362 | ) |  | $ | (2,369 | ) |

[0001193125-16-758852:8k_2_02:86]
| * | Net cash (debt) = Total cash - Current portion of long-term debt - Long-term debt |

[0001193125-16-758852:8k_2_02:87]
GAAP-4

[0001193125-16-758852:8k_2_02:88]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:89]
Condensed Consolidated Statements of Cash Flows

[0001193125-16-758852:8k_2_02:90]
(In millions)

[0001193125-16-758852:8k_2_02:91]
|  |  | Three Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 192 |  |  | $ | 115 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | — |  |
| Net earnings |  |  | 193 |  |  |  | 115 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (11 | ) |
| Earnings from continuing operations, net of tax |  |  | 193 |  |  |  | 126 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 76 |  |  |  | 32 |  |
| Non-cash other charges |  |  | 8 |  |  |  | 38 |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 18 |  |
| Gains on sales of investments and businesses, net |  |  | (7 | ) |  |  | (10 | ) |
| Deferred income taxes |  |  | 72 |  |  |  | 72 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (82 | ) |  |  | (88 | ) |
| Inventories |  |  | 2 |  |  |  | 4 |  |
| Other current assets |  |  | (37 | ) |  |  | 10 |  |
| Accounts payable and accrued liabilities |  |  | 138 |  |  |  | 96 |  |
| Other assets and liabilities |  |  | (31 | ) |  |  | 3 |  |
| Net cash provided by operating activities |  |  | 348 |  |  |  | 301 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (95 | ) |  |  | (57 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 84 |  |  |  | 39 |  |
| Capital expenditures |  |  | (68 | ) |  |  | (50 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 22 |  |  |  | 1 |  |
| Net cash used for investing activities |  |  | (57 | ) |  |  | (67 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (1 | ) |  |  | (1 | ) |
| Net proceeds from issuance of debt |  |  | — |  |  |  | 976 |  |
| Issuance of common stock |  |  | 41 |  |  |  | 33 |  |
| Purchase of common stock |  |  | (109 | ) |  |  | (2,058 | ) |
| Payment of dividends |  |  | (70 | ) |  |  | (70 | ) |
| Net cash used for financing activities |  |  | (139 | ) |  |  | (1,120 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (10 | ) |  |  | (26 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 142 |  |  |  | (912 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,545 |  |  |  | 3,112 |  |
| Cash and cash equivalents, end of period |  | $ | 1,687 |  |  | $ | 2,200 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 280 |  |  | $ | 251 |  |

[0001193125-16-758852:8k_2_02:92]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-758852:8k_2_02:93]
GAAP-5

[0001193125-16-758852:8k_2_02:94]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:95]
Condensed Consolidated Statements of Cash Flows

[0001193125-16-758852:8k_2_02:96]
(In millions)

[0001193125-16-758852:8k_2_02:97]
|  |  | Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Operating |  |  |  |  |  |  |  |  |
| Net earnings attributable to Motorola Solutions, Inc. |  | $ | 317 |  |  | $ | 331 |  |
| Earnings attributable to noncontrolling interests |  |  | 1 |  |  |  | 2 |  |
| Net earnings |  |  | 318 |  |  |  | 333 |  |
| Loss from discontinued operations, net of tax |  |  | — |  |  |  | (32 | ) |
| Earnings from continuing operations, net of tax |  |  | 318 |  |  |  | 365 |  |
| Adjustments to reconcile Earnings from continuing operations to Net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 220 |  |  |  | 113 |  |
| Non-cash other charges |  |  | 43 |  |  |  | 43 |  |
| Non-U.S. pension curtailment gain |  |  | — |  |  |  | (32 | ) |
| Share-based compensation expense |  |  | 52 |  |  |  | 58 |  |
| Losses (gains) on sales of investments and businesses, net |  |  | 13 |  |  |  | (60 | ) |
| Deferred income taxes |  |  | 143 |  |  |  | 127 |  |
| Changes in assets and liabilities, net of effects of acquisitions, dispositions, and foreign currency translation adjustments: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 245 |  |  |  | 167 |  |
| Inventories |  |  | — |  |  |  | (21 | ) |
| Other current assets |  |  | (102 | ) |  |  | 38 |  |
| Accounts payable and accrued liabilities |  |  | (224 | ) |  |  | (152 | ) |
| Other assets and liabilities |  |  | (56 | ) |  |  | (39 | ) |
| Net cash provided by operating activities |  |  | 652 |  |  |  | 607 |  |
| Investing |  |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  |  | (1,215 | ) |  |  | (150 | ) |
| Proceeds from sales of investments and businesses, net |  |  | 637 |  |  |  | 150 |  |
| Capital expenditures |  |  | (211 | ) |  |  | (131 | ) |
| Proceeds from sales of property, plant and equipment |  |  | 68 |  |  |  | 2 |  |
| Net cash used for investing activities |  |  | (721 | ) |  |  | (129 | ) |
| Financing |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (3 | ) |  |  | (3 | ) |
| Net proceeds from issuance of debt |  |  | 673 |  |  |  | 976 |  |
| Issuance of common stock |  |  | 80 |  |  |  | 69 |  |
| Purchase of common stock |  |  | (728 | ) |  |  | (2,996 | ) |
| Excess tax benefit from share-based compensation |  |  | — |  |  |  | 1 |  |
| Payment of dividends |  |  | (213 | ) |  |  | (218 | ) |
| Net cash used for financing activities |  |  | (191 | ) |  |  | (2,171 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (33 | ) |  |  | (61 | ) |
| Net decrease in cash and cash equivalents |  |  | (293 | ) |  |  | (1,754 | ) |
| Cash and cash equivalents, beginning of period |  |  | 1,980 |  |  |  | 3,954 |  |
| Cash and cash equivalents, end of period |  | $ | 1,687 |  |  | $ | 2,200 |  |
| Financial Ratios: |  |  |  |  |  |  |  |  |
| Free cash flow* |  | $ | 441 |  |  | $ | 476 |  |

[0001193125-16-758852:8k_2_02:98]
| * | Free cash flow = Net cash provided by operating activities - Capital Expenditures |

[0001193125-16-758852:8k_2_02:99]
GAAP-6

[0001193125-16-758852:8k_2_02:100]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:101]
Segment Information

[0001193125-16-758852:8k_2_02:102]
(In
millions)

[0001193125-16-758852:8k_2_02:103]
Net Sales

[0001193125-16-758852:8k_2_02:104]
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 920 |  |  | $ | 925 |  |  |  | (1 | )% |
| Services |  |  | 612 |  |  |  | 497 |  |  |  | 23 | % |
| Total Motorola Solutions |  | $ | 1,532 |  |  | $ | 1,422 |  |  |  | 8 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 2,423 |  |  | $ | 2,550 |  |  |  | (5 | )% |
| Services |  |  | 1,732 |  |  |  | 1,463 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 4,155 |  |  | $ | 4,013 |  |  |  | 4 | % |

[0001193125-16-758852:8k_2_02:105]
Operating Earnings

[0001193125-16-758852:8k_2_02:106]
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 225 |  |  | $ | 178 |  |  |  | 26 | % |
| Services |  |  | 116 |  |  |  | 53 |  |  |  | 119 | % |
| Total Motorola Solutions |  | $ | 341 |  |  | $ | 231 |  |  |  | 48 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 404 |  |  | $ | 413 |  |  |  | (2 | )% |
| Services |  |  | 260 |  |  |  | 192 |  |  |  | 35 | % |
| Total Motorola Solutions |  | $ | 664 |  |  | $ | 605 |  |  |  | 10 | % |

[0001193125-16-758852:8k_2_02:107]
Operating Earnings %

[0001193125-16-758852:8k_2_02:108]
|  |  | Three Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Products |  |  | 24.5 | % |  |  | 19.2 | % |
| Services |  |  | 19.0 | % |  |  | 10.7 | % |
| Total Motorola Solutions |  |  | 22.3 | % |  |  | 16.2 | % |
|  |  | Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Products |  |  | 16.7 | % |  |  | 16.2 | % |
| Services |  |  | 15.0 | % |  |  | 13.1 | % |
| Total Motorola Solutions |  |  | 16.0 | % |  |  | 15.1 | % |

[0001193125-16-758852:8k_2_02:109]
Non-GAAP-1

[0001193125-16-758852:8k_2_02:110]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:111]
Non-GAAP Adjustments (Intangibles Amortization Expense, Share-Based Compensation Expense and Highlighted Items)

[0001193125-16-758852:8k_2_02:112]
Q1 2016

[0001193125-16-758852:8k_2_02:113]
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 0.06 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 23 |  |  |  | 8 |  |  |  | 15 |  |  |  | 0.08 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 13 |  |  |  | 3 |  |  |  | 10 |  |  |  | 0.06 |  |
| Acquisition related transaction fees |  | Other charges |  |  | 13 |  |  |  | — |  |  |  | 13 |  |  |  | 0.07 |  |
| Loss on investment in United Kingdom treasuries |  | Other expense (income) |  |  | 19 |  |  |  | 7 |  |  |  | 12 |  |  |  | 0.07 |  |
| Realized foreign currency loss on acquisition |  | Other expense (income) |  |  | 10 |  |  |  | 3 |  |  |  | 7 |  |  |  | 0.04 |  |
| Loss on sale of Malaysia facility and operations |  | Other expense (income) |  |  | 7 |  |  |  | — |  |  |  | 7 |  |  |  | 0.04 |  |
| Total impact on Net earnings |  |  |  | $ | 102 |  |  | $ | 27 |  |  | $ | 75 |  |  | $ | 0.42 |  |

[0001193125-16-758852:8k_2_02:114]
Q2 2016

[0001193125-16-758852:8k_2_02:115]
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 18 |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 27 |  |  |  | 7 |  |  |  | 20 |  |  |  | 0.12 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 38 |  |  |  | 8 |  |  |  | 30 |  |  |  | 0.17 |  |
| Building impairment |  | Other charges |  |  | 17 |  |  |  | 6 |  |  |  | 11 |  |  |  | 0.06 |  |
| Total impact on Net earnings |  |  |  | $ | 100 |  |  | $ | 27 |  |  | $ | 73 |  |  | $ | 0.42 |  |

[0001193125-16-758852:8k_2_02:116]
Q3 2016

[0001193125-16-758852:8k_2_02:117]
| Non-GAAP Adjustments |  | Statement Line |  | PBT(Inc)/Exp |  |  | TaxInc/(Exp) |  |  | PAT(Inc)/Exp |  |  | EPS impact |  |
| Share-based compensation expense |  | Cost of sales, SG&A and R&D |  | $ | 17 |  |  | $ | 5 |  |  | $ | 12 |  |  | $ | 0.07 |  |
| Reorganization of business charges |  | Cost of sales and Other charges |  |  | 7 |  |  |  | 2 |  |  |  | 5 |  |  |  | 0.03 |  |
| Intangibles amortization expense |  | Intangibles amortization |  |  | 31 |  |  |  | 7 |  |  |  | 24 |  |  |  | 0.14 |  |
| Total impact on Net earnings |  |  |  | $ | 55 |  |  | $ | 14 |  |  | $ | 41 |  |  | $ | 0.24 |  |

[0001193125-16-758852:8k_2_02:118]
Non-GAAP-2

[0001193125-16-758852:8k_2_02:119]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:120]
Non-GAAP Segment Information

[0001193125-16-758852:8k_2_02:121]
(In millions)

[0001193125-16-758852:8k_2_02:122]
Net Sales

[0001193125-16-758852:8k_2_02:123]
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 920 |  |  | $ | 925 |  |  |  | (1 | )% |
| Services |  |  | 612 |  |  |  | 497 |  |  |  | 23 | % |
| Total Motorola Solutions |  | $ | 1,532 |  |  | $ | 1,422 |  |  |  | 8 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 2,423 |  |  | $ | 2,550 |  |  |  | (5 | )% |
| Services |  |  | 1,732 |  |  |  | 1,463 |  |  |  | 18 | % |
| Total Motorola Solutions |  | $ | 4,155 |  |  | $ | 4,013 |  |  |  | 4 | % |

[0001193125-16-758852:8k_2_02:124]
Non-GAAP Operating Earnings

[0001193125-16-758852:8k_2_02:125]
|  |  | Three Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 243 |  |  | $ | 221 |  |  |  | 10 | % |
| Services |  |  | 153 |  |  |  | 71 |  |  |  | 115 | % |
| Total Motorola Solutions |  | $ | 396 |  |  | $ | 292 |  |  |  | 36 | % |
|  |  | Nine Months Ended |  |  |  |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |  | % Change |  |
| Products |  | $ | 503 |  |  | $ | 487 |  |  |  | 3 | % |
| Services |  |  | 383 |  |  |  | 221 |  |  |  | 73 | % |
| Total Motorola Solutions |  | $ | 886 |  |  | $ | 708 |  |  |  | 25 | % |

[0001193125-16-758852:8k_2_02:126]
Non-GAAP Operating Earnings %

[0001193125-16-758852:8k_2_02:127]
|  |  | Three Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Products |  |  | 26.4 | % |  |  | 23.9 | % |
| Services |  |  | 25.0 | % |  |  | 14.3 | % |
| Total Motorola Solutions |  |  | 25.8 | % |  |  | 20.5 | % |
|  |  | Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | October 3, 2015 |  |
| Products |  |  | 20.8 | % |  |  | 19.1 | % |
| Services |  |  | 22.1 | % |  |  | 15.1 | % |
| Total Motorola Solutions |  |  | 21.3 | % |  |  | 17.6 | % |

[0001193125-16-758852:8k_2_02:128]
Non-GAAP-3

[0001193125-16-758852:8k_2_02:129]
Motorola Solutions, Inc. and Subsidiaries

[0001193125-16-758852:8k_2_02:130]
Operating Earnings after Non-GAAP Adjustments

[0001193125-16-758852:8k_2_02:131]
Q1 2016

[0001193125-16-758852:8k_2_02:132]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,193 |  |  | $ | 702 |  |  | $ | 491 |  |
| Operating earnings (“OE”) |  | $ | 100 |  |  | $ | 51 |  |  | $ | 49 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 23 |  |  |  | 21 |  |  |  | 2 |  |
| Intangibles amortization expense |  |  | 13 |  |  |  | 1 |  |  |  | 12 |  |
| Acquisition related transaction fees |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Total above-OE non-GAAP adjustments |  |  | 66 |  |  |  | 33 |  |  |  | 33 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 166 |  |  | $ | 84 |  |  | $ | 82 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 8.4 | % |  |  | 7.3 | % |  |  | 10.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 13.9 | % |  |  | 12.0 | % |  |  | 16.7 | % |

[0001193125-16-758852:8k_2_02:133]
Q2 2016

[0001193125-16-758852:8k_2_02:134]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,430 |  |  | $ | 801 |  |  | $ | 629 |  |
| Operating earnings (“OE”) |  | $ | 224 |  |  | $ | 129 |  |  | $ | 95 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 18 |  |  |  | 12 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 27 |  |  |  | 21 |  |  |  | 6 |  |
| Intangibles amortization expense |  |  | 38 |  |  |  | 2 |  |  |  | 36 |  |
| Building impairment |  |  | 17 |  |  |  | 12 |  |  |  | 5 |  |
| Total above-OE non-GAAP adjustments |  |  | 100 |  |  |  | 47 |  |  |  | 53 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 324 |  |  | $ | 176 |  |  | $ | 148 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 15.7 | % |  |  | 16.1 | % |  |  | 15.1 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 22.7 | % |  |  | 22.0 | % |  |  | 23.5 | % |

[0001193125-16-758852:8k_2_02:135]
Q3 2016

[0001193125-16-758852:8k_2_02:136]
|  |  | TOTAL |  |  | Products |  |  | Services |  |
| Net sales |  | $ | 1,532 |  |  | $ | 920 |  |  | $ | 612 |  |
| Operating earnings (“OE”) |  | $ | 341 |  |  | $ | 225 |  |  | $ | 116 |  |
| Above-OE non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 17 |  |  |  | 11 |  |  |  | 6 |  |
| Reorganization of business charges |  |  | 7 |  |  |  | 5 |  |  |  | 2 |  |
| Intangibles amortization expense |  |  | 31 |  |  |  | 2 |  |  |  | 29 |  |
| Total above-OE non-GAAP adjustments |  |  | 55 |  |  |  | 18 |  |  |  | 37 |  |
| Operating earnings after non-GAAP adjustments |  | $ | 396 |  |  | $ | 243 |  |  | $ | 153 |  |
| Operating earnings as a percentage of net sales - GAAP |  |  | 22.3 | % |  |  | 24.5 | % |  |  | 19.0 | % |
| Operating earnings as a percentage of net sales - after non-GAAP adjustments |  |  | 25.8 | % |  |  | 26.4 | % |  |  | 25.0 | % |
